<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-31 02:08:00 --> Config Class Initialized
INFO - 2023-05-31 02:08:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:00 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:00 --> URI Class Initialized
INFO - 2023-05-31 02:08:00 --> Router Class Initialized
INFO - 2023-05-31 02:08:00 --> Output Class Initialized
INFO - 2023-05-31 02:08:00 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:00 --> Input Class Initialized
INFO - 2023-05-31 02:08:00 --> Language Class Initialized
INFO - 2023-05-31 02:08:00 --> Loader Class Initialized
INFO - 2023-05-31 02:08:00 --> Controller Class Initialized
INFO - 2023-05-31 02:08:00 --> Helper loaded: form_helper
INFO - 2023-05-31 02:08:00 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:08:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:00 --> Model "Change_model" initialized
INFO - 2023-05-31 02:08:00 --> Model "Grafana_model" initialized
INFO - 2023-05-31 02:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:01 --> Total execution time: 0.3729
INFO - 2023-05-31 02:08:01 --> Config Class Initialized
INFO - 2023-05-31 02:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:01 --> URI Class Initialized
INFO - 2023-05-31 02:08:01 --> Router Class Initialized
INFO - 2023-05-31 02:08:01 --> Output Class Initialized
INFO - 2023-05-31 02:08:01 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:01 --> Input Class Initialized
INFO - 2023-05-31 02:08:01 --> Language Class Initialized
INFO - 2023-05-31 02:08:01 --> Loader Class Initialized
INFO - 2023-05-31 02:08:01 --> Controller Class Initialized
INFO - 2023-05-31 02:08:01 --> Helper loaded: form_helper
INFO - 2023-05-31 02:08:01 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:01 --> Total execution time: 0.1880
INFO - 2023-05-31 02:08:01 --> Config Class Initialized
INFO - 2023-05-31 02:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:01 --> URI Class Initialized
INFO - 2023-05-31 02:08:01 --> Router Class Initialized
INFO - 2023-05-31 02:08:01 --> Output Class Initialized
INFO - 2023-05-31 02:08:01 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:01 --> Input Class Initialized
INFO - 2023-05-31 02:08:01 --> Language Class Initialized
INFO - 2023-05-31 02:08:01 --> Loader Class Initialized
INFO - 2023-05-31 02:08:01 --> Controller Class Initialized
INFO - 2023-05-31 02:08:01 --> Helper loaded: form_helper
INFO - 2023-05-31 02:08:01 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:01 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:01 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:01 --> Total execution time: 0.3548
INFO - 2023-05-31 02:08:01 --> Config Class Initialized
INFO - 2023-05-31 02:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:01 --> URI Class Initialized
INFO - 2023-05-31 02:08:01 --> Router Class Initialized
INFO - 2023-05-31 02:08:01 --> Output Class Initialized
INFO - 2023-05-31 02:08:01 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:01 --> Input Class Initialized
INFO - 2023-05-31 02:08:01 --> Language Class Initialized
INFO - 2023-05-31 02:08:01 --> Loader Class Initialized
INFO - 2023-05-31 02:08:01 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:01 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:01 --> Total execution time: 0.2628
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:02 --> Total execution time: 0.1804
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:02 --> Total execution time: 0.1784
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:02 --> Model "Login_model" initialized
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:02 --> Total execution time: 0.4320
INFO - 2023-05-31 02:08:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:02 --> Total execution time: 0.2260
INFO - 2023-05-31 02:08:02 --> Config Class Initialized
INFO - 2023-05-31 02:08:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:02 --> URI Class Initialized
INFO - 2023-05-31 02:08:02 --> Router Class Initialized
INFO - 2023-05-31 02:08:02 --> Output Class Initialized
INFO - 2023-05-31 02:08:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:02 --> Input Class Initialized
INFO - 2023-05-31 02:08:02 --> Language Class Initialized
INFO - 2023-05-31 02:08:02 --> Loader Class Initialized
INFO - 2023-05-31 02:08:02 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:03 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:03 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:03 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:03 --> Total execution time: 0.4055
INFO - 2023-05-31 02:08:09 --> Config Class Initialized
INFO - 2023-05-31 02:08:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:09 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:09 --> URI Class Initialized
INFO - 2023-05-31 02:08:09 --> Router Class Initialized
INFO - 2023-05-31 02:08:09 --> Output Class Initialized
INFO - 2023-05-31 02:08:09 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:09 --> Input Class Initialized
INFO - 2023-05-31 02:08:09 --> Language Class Initialized
INFO - 2023-05-31 02:08:10 --> Loader Class Initialized
INFO - 2023-05-31 02:08:10 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:10 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:10 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:10 --> Total execution time: 0.1871
INFO - 2023-05-31 02:08:10 --> Config Class Initialized
INFO - 2023-05-31 02:08:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:10 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:10 --> URI Class Initialized
INFO - 2023-05-31 02:08:10 --> Router Class Initialized
INFO - 2023-05-31 02:08:10 --> Output Class Initialized
INFO - 2023-05-31 02:08:10 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:10 --> Input Class Initialized
INFO - 2023-05-31 02:08:10 --> Language Class Initialized
INFO - 2023-05-31 02:08:10 --> Loader Class Initialized
INFO - 2023-05-31 02:08:10 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:10 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:10 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:10 --> Total execution time: 0.2048
INFO - 2023-05-31 02:08:11 --> Config Class Initialized
INFO - 2023-05-31 02:08:11 --> Config Class Initialized
INFO - 2023-05-31 02:08:11 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:11 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:11 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:11 --> URI Class Initialized
INFO - 2023-05-31 02:08:11 --> URI Class Initialized
INFO - 2023-05-31 02:08:11 --> Router Class Initialized
INFO - 2023-05-31 02:08:11 --> Router Class Initialized
INFO - 2023-05-31 02:08:11 --> Output Class Initialized
INFO - 2023-05-31 02:08:11 --> Output Class Initialized
INFO - 2023-05-31 02:08:11 --> Security Class Initialized
INFO - 2023-05-31 02:08:11 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:11 --> Input Class Initialized
INFO - 2023-05-31 02:08:11 --> Input Class Initialized
INFO - 2023-05-31 02:08:11 --> Language Class Initialized
INFO - 2023-05-31 02:08:11 --> Language Class Initialized
INFO - 2023-05-31 02:08:11 --> Loader Class Initialized
INFO - 2023-05-31 02:08:11 --> Loader Class Initialized
INFO - 2023-05-31 02:08:11 --> Controller Class Initialized
INFO - 2023-05-31 02:08:11 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:08:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:11 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:11 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:11 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:11 --> Total execution time: 0.5716
INFO - 2023-05-31 02:08:11 --> Config Class Initialized
INFO - 2023-05-31 02:08:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:11 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:11 --> URI Class Initialized
INFO - 2023-05-31 02:08:11 --> Router Class Initialized
INFO - 2023-05-31 02:08:11 --> Output Class Initialized
INFO - 2023-05-31 02:08:11 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:11 --> Input Class Initialized
INFO - 2023-05-31 02:08:11 --> Language Class Initialized
INFO - 2023-05-31 02:08:11 --> Loader Class Initialized
INFO - 2023-05-31 02:08:11 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:11 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:12 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:12 --> Total execution time: 0.9341
INFO - 2023-05-31 02:08:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:12 --> Config Class Initialized
INFO - 2023-05-31 02:08:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:12 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:12 --> URI Class Initialized
INFO - 2023-05-31 02:08:12 --> Router Class Initialized
INFO - 2023-05-31 02:08:12 --> Output Class Initialized
INFO - 2023-05-31 02:08:12 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:12 --> Input Class Initialized
INFO - 2023-05-31 02:08:12 --> Language Class Initialized
INFO - 2023-05-31 02:08:12 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:12 --> Total execution time: 0.4705
INFO - 2023-05-31 02:08:12 --> Loader Class Initialized
INFO - 2023-05-31 02:08:12 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:12 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:12 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:12 --> Total execution time: 0.6511
INFO - 2023-05-31 02:08:13 --> Config Class Initialized
INFO - 2023-05-31 02:08:13 --> Config Class Initialized
INFO - 2023-05-31 02:08:13 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:13 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:13 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:13 --> URI Class Initialized
INFO - 2023-05-31 02:08:13 --> URI Class Initialized
INFO - 2023-05-31 02:08:13 --> Router Class Initialized
INFO - 2023-05-31 02:08:13 --> Router Class Initialized
INFO - 2023-05-31 02:08:13 --> Output Class Initialized
INFO - 2023-05-31 02:08:13 --> Output Class Initialized
INFO - 2023-05-31 02:08:13 --> Security Class Initialized
INFO - 2023-05-31 02:08:13 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:13 --> Input Class Initialized
INFO - 2023-05-31 02:08:13 --> Input Class Initialized
INFO - 2023-05-31 02:08:14 --> Language Class Initialized
INFO - 2023-05-31 02:08:14 --> Language Class Initialized
INFO - 2023-05-31 02:08:14 --> Loader Class Initialized
INFO - 2023-05-31 02:08:14 --> Loader Class Initialized
INFO - 2023-05-31 02:08:14 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:14 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:14 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:14 --> Total execution time: 0.2371
INFO - 2023-05-31 02:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:14 --> Config Class Initialized
INFO - 2023-05-31 02:08:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:14 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:14 --> URI Class Initialized
INFO - 2023-05-31 02:08:14 --> Router Class Initialized
INFO - 2023-05-31 02:08:14 --> Output Class Initialized
INFO - 2023-05-31 02:08:14 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:14 --> Input Class Initialized
INFO - 2023-05-31 02:08:14 --> Language Class Initialized
INFO - 2023-05-31 02:08:14 --> Loader Class Initialized
INFO - 2023-05-31 02:08:14 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:14 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:14 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:14 --> Total execution time: 0.2176
INFO - 2023-05-31 02:08:14 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:14 --> Total execution time: 1.0329
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:15 --> Total execution time: 0.5505
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Final output sent to browser
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Total execution time: 0.5663
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
DEBUG - 2023-05-31 02:08:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:15 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> URI Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Router Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
INFO - 2023-05-31 02:08:15 --> Output Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Security Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:15 --> Input Class Initialized
INFO - 2023-05-31 02:08:15 --> Language Class Initialized
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Loader Class Initialized
INFO - 2023-05-31 02:08:15 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:15 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:15 --> Total execution time: 0.9666
INFO - 2023-05-31 02:08:15 --> Config Class Initialized
INFO - 2023-05-31 02:08:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:16 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:16 --> URI Class Initialized
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.4379
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.5463
INFO - 2023-05-31 02:08:16 --> Router Class Initialized
INFO - 2023-05-31 02:08:16 --> Output Class Initialized
INFO - 2023-05-31 02:08:16 --> Security Class Initialized
INFO - 2023-05-31 02:08:16 --> Config Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:16 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:16 --> Input Class Initialized
INFO - 2023-05-31 02:08:16 --> Config Class Initialized
INFO - 2023-05-31 02:08:16 --> Language Class Initialized
INFO - 2023-05-31 02:08:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:16 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:16 --> Loader Class Initialized
DEBUG - 2023-05-31 02:08:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:16 --> URI Class Initialized
INFO - 2023-05-31 02:08:16 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:16 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:16 --> URI Class Initialized
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.5203
INFO - 2023-05-31 02:08:16 --> Router Class Initialized
INFO - 2023-05-31 02:08:16 --> Router Class Initialized
INFO - 2023-05-31 02:08:16 --> Output Class Initialized
INFO - 2023-05-31 02:08:16 --> Security Class Initialized
INFO - 2023-05-31 02:08:16 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:16 --> Output Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:16 --> Input Class Initialized
INFO - 2023-05-31 02:08:16 --> Security Class Initialized
INFO - 2023-05-31 02:08:16 --> Language Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:16 --> Input Class Initialized
INFO - 2023-05-31 02:08:16 --> Language Class Initialized
INFO - 2023-05-31 02:08:16 --> Loader Class Initialized
INFO - 2023-05-31 02:08:16 --> Controller Class Initialized
INFO - 2023-05-31 02:08:16 --> Loader Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:16 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:16 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:16 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:16 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:16 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:16 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:16 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.3963
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.4234
INFO - 2023-05-31 02:08:16 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:16 --> Total execution time: 0.4412
INFO - 2023-05-31 02:08:25 --> Config Class Initialized
INFO - 2023-05-31 02:08:25 --> Config Class Initialized
INFO - 2023-05-31 02:08:25 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:08:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:25 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:25 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:25 --> URI Class Initialized
INFO - 2023-05-31 02:08:25 --> URI Class Initialized
INFO - 2023-05-31 02:08:25 --> Router Class Initialized
INFO - 2023-05-31 02:08:25 --> Router Class Initialized
INFO - 2023-05-31 02:08:25 --> Output Class Initialized
INFO - 2023-05-31 02:08:25 --> Output Class Initialized
INFO - 2023-05-31 02:08:25 --> Security Class Initialized
INFO - 2023-05-31 02:08:25 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:25 --> Input Class Initialized
INFO - 2023-05-31 02:08:25 --> Input Class Initialized
INFO - 2023-05-31 02:08:25 --> Language Class Initialized
INFO - 2023-05-31 02:08:25 --> Language Class Initialized
INFO - 2023-05-31 02:08:25 --> Loader Class Initialized
INFO - 2023-05-31 02:08:25 --> Loader Class Initialized
INFO - 2023-05-31 02:08:25 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:25 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:25 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:25 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:25 --> Total execution time: 0.1844
INFO - 2023-05-31 02:08:25 --> Config Class Initialized
INFO - 2023-05-31 02:08:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:25 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:25 --> URI Class Initialized
INFO - 2023-05-31 02:08:25 --> Router Class Initialized
INFO - 2023-05-31 02:08:25 --> Output Class Initialized
INFO - 2023-05-31 02:08:25 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:25 --> Input Class Initialized
INFO - 2023-05-31 02:08:25 --> Language Class Initialized
INFO - 2023-05-31 02:08:25 --> Loader Class Initialized
INFO - 2023-05-31 02:08:25 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:25 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:25 --> Total execution time: 0.2079
INFO - 2023-05-31 02:08:35 --> Config Class Initialized
INFO - 2023-05-31 02:08:35 --> Hooks Class Initialized
INFO - 2023-05-31 02:08:35 --> Config Class Initialized
INFO - 2023-05-31 02:08:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:35 --> Utf8 Class Initialized
DEBUG - 2023-05-31 02:08:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:35 --> URI Class Initialized
INFO - 2023-05-31 02:08:35 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:35 --> URI Class Initialized
INFO - 2023-05-31 02:08:35 --> Router Class Initialized
INFO - 2023-05-31 02:08:35 --> Router Class Initialized
INFO - 2023-05-31 02:08:35 --> Output Class Initialized
INFO - 2023-05-31 02:08:35 --> Output Class Initialized
INFO - 2023-05-31 02:08:35 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:35 --> Security Class Initialized
INFO - 2023-05-31 02:08:35 --> Input Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:35 --> Language Class Initialized
INFO - 2023-05-31 02:08:35 --> Input Class Initialized
INFO - 2023-05-31 02:08:35 --> Language Class Initialized
INFO - 2023-05-31 02:08:35 --> Loader Class Initialized
INFO - 2023-05-31 02:08:35 --> Loader Class Initialized
INFO - 2023-05-31 02:08:35 --> Controller Class Initialized
INFO - 2023-05-31 02:08:35 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:35 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:35 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:35 --> Total execution time: 0.2175
INFO - 2023-05-31 02:08:35 --> Config Class Initialized
INFO - 2023-05-31 02:08:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:35 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:35 --> URI Class Initialized
INFO - 2023-05-31 02:08:35 --> Router Class Initialized
INFO - 2023-05-31 02:08:35 --> Output Class Initialized
INFO - 2023-05-31 02:08:35 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:35 --> Input Class Initialized
INFO - 2023-05-31 02:08:35 --> Language Class Initialized
INFO - 2023-05-31 02:08:35 --> Loader Class Initialized
INFO - 2023-05-31 02:08:35 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:35 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:35 --> Total execution time: 0.2082
INFO - 2023-05-31 02:08:36 --> Config Class Initialized
INFO - 2023-05-31 02:08:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:36 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:36 --> URI Class Initialized
INFO - 2023-05-31 02:08:36 --> Router Class Initialized
INFO - 2023-05-31 02:08:36 --> Output Class Initialized
INFO - 2023-05-31 02:08:36 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:36 --> Input Class Initialized
INFO - 2023-05-31 02:08:36 --> Language Class Initialized
INFO - 2023-05-31 02:08:36 --> Loader Class Initialized
INFO - 2023-05-31 02:08:36 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:36 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:36 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:36 --> Total execution time: 0.4444
INFO - 2023-05-31 02:08:36 --> Config Class Initialized
INFO - 2023-05-31 02:08:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:36 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:36 --> URI Class Initialized
INFO - 2023-05-31 02:08:36 --> Router Class Initialized
INFO - 2023-05-31 02:08:36 --> Output Class Initialized
INFO - 2023-05-31 02:08:36 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:36 --> Input Class Initialized
INFO - 2023-05-31 02:08:36 --> Language Class Initialized
INFO - 2023-05-31 02:08:36 --> Loader Class Initialized
INFO - 2023-05-31 02:08:36 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:36 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:36 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:36 --> Total execution time: 0.2203
INFO - 2023-05-31 02:08:37 --> Config Class Initialized
INFO - 2023-05-31 02:08:37 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:37 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:37 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:37 --> URI Class Initialized
INFO - 2023-05-31 02:08:37 --> Router Class Initialized
INFO - 2023-05-31 02:08:37 --> Output Class Initialized
INFO - 2023-05-31 02:08:37 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:37 --> Input Class Initialized
INFO - 2023-05-31 02:08:37 --> Language Class Initialized
INFO - 2023-05-31 02:08:37 --> Loader Class Initialized
INFO - 2023-05-31 02:08:37 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:37 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:37 --> Total execution time: 0.1253
INFO - 2023-05-31 02:08:37 --> Config Class Initialized
INFO - 2023-05-31 02:08:37 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:37 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:37 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:37 --> URI Class Initialized
INFO - 2023-05-31 02:08:37 --> Router Class Initialized
INFO - 2023-05-31 02:08:37 --> Output Class Initialized
INFO - 2023-05-31 02:08:37 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:37 --> Input Class Initialized
INFO - 2023-05-31 02:08:37 --> Language Class Initialized
INFO - 2023-05-31 02:08:37 --> Loader Class Initialized
INFO - 2023-05-31 02:08:37 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:37 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:37 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:37 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:37 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:37 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:37 --> Total execution time: 0.2059
INFO - 2023-05-31 02:08:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:38 --> Total execution time: 13.2683
INFO - 2023-05-31 02:08:38 --> Config Class Initialized
INFO - 2023-05-31 02:08:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:38 --> URI Class Initialized
INFO - 2023-05-31 02:08:38 --> Router Class Initialized
INFO - 2023-05-31 02:08:38 --> Output Class Initialized
INFO - 2023-05-31 02:08:38 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:38 --> Input Class Initialized
INFO - 2023-05-31 02:08:38 --> Language Class Initialized
INFO - 2023-05-31 02:08:38 --> Loader Class Initialized
INFO - 2023-05-31 02:08:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:38 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:45 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:45 --> Total execution time: 10.5979
INFO - 2023-05-31 02:08:50 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:50 --> Total execution time: 11.7752
INFO - 2023-05-31 02:08:50 --> Config Class Initialized
INFO - 2023-05-31 02:08:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:50 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:50 --> URI Class Initialized
INFO - 2023-05-31 02:08:50 --> Router Class Initialized
INFO - 2023-05-31 02:08:50 --> Output Class Initialized
INFO - 2023-05-31 02:08:50 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:50 --> Input Class Initialized
INFO - 2023-05-31 02:08:50 --> Language Class Initialized
INFO - 2023-05-31 02:08:50 --> Loader Class Initialized
INFO - 2023-05-31 02:08:50 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:50 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:50 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:50 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:50 --> Model "Login_model" initialized
INFO - 2023-05-31 02:08:53 --> Config Class Initialized
INFO - 2023-05-31 02:08:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:53 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:53 --> URI Class Initialized
INFO - 2023-05-31 02:08:54 --> Router Class Initialized
INFO - 2023-05-31 02:08:54 --> Output Class Initialized
INFO - 2023-05-31 02:08:54 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:54 --> Input Class Initialized
INFO - 2023-05-31 02:08:54 --> Language Class Initialized
INFO - 2023-05-31 02:08:54 --> Loader Class Initialized
INFO - 2023-05-31 02:08:54 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:54 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:54 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:54 --> Total execution time: 0.2868
INFO - 2023-05-31 02:08:54 --> Config Class Initialized
INFO - 2023-05-31 02:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:54 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:54 --> URI Class Initialized
INFO - 2023-05-31 02:08:54 --> Router Class Initialized
INFO - 2023-05-31 02:08:54 --> Output Class Initialized
INFO - 2023-05-31 02:08:54 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:54 --> Input Class Initialized
INFO - 2023-05-31 02:08:54 --> Language Class Initialized
INFO - 2023-05-31 02:08:54 --> Loader Class Initialized
INFO - 2023-05-31 02:08:54 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:54 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:54 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:54 --> Total execution time: 0.2055
INFO - 2023-05-31 02:08:57 --> Config Class Initialized
INFO - 2023-05-31 02:08:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:57 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:57 --> URI Class Initialized
INFO - 2023-05-31 02:08:57 --> Router Class Initialized
INFO - 2023-05-31 02:08:57 --> Output Class Initialized
INFO - 2023-05-31 02:08:57 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:57 --> Input Class Initialized
INFO - 2023-05-31 02:08:57 --> Language Class Initialized
INFO - 2023-05-31 02:08:57 --> Loader Class Initialized
INFO - 2023-05-31 02:08:57 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:57 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:57 --> Total execution time: 0.1511
INFO - 2023-05-31 02:08:58 --> Config Class Initialized
INFO - 2023-05-31 02:08:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:58 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:58 --> URI Class Initialized
INFO - 2023-05-31 02:08:58 --> Router Class Initialized
INFO - 2023-05-31 02:08:58 --> Output Class Initialized
INFO - 2023-05-31 02:08:58 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:58 --> Input Class Initialized
INFO - 2023-05-31 02:08:58 --> Language Class Initialized
INFO - 2023-05-31 02:08:58 --> Loader Class Initialized
INFO - 2023-05-31 02:08:58 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:58 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:58 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:58 --> Total execution time: 0.1748
INFO - 2023-05-31 02:08:59 --> Config Class Initialized
INFO - 2023-05-31 02:08:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:59 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:59 --> URI Class Initialized
INFO - 2023-05-31 02:08:59 --> Router Class Initialized
INFO - 2023-05-31 02:08:59 --> Output Class Initialized
INFO - 2023-05-31 02:08:59 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:59 --> Input Class Initialized
INFO - 2023-05-31 02:08:59 --> Language Class Initialized
INFO - 2023-05-31 02:08:59 --> Loader Class Initialized
INFO - 2023-05-31 02:08:59 --> Controller Class Initialized
DEBUG - 2023-05-31 02:08:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:08:59 --> Database Driver Class Initialized
INFO - 2023-05-31 02:08:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:08:59 --> Final output sent to browser
DEBUG - 2023-05-31 02:08:59 --> Total execution time: 0.1831
INFO - 2023-05-31 02:08:59 --> Config Class Initialized
INFO - 2023-05-31 02:08:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:08:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:08:59 --> Utf8 Class Initialized
INFO - 2023-05-31 02:08:59 --> URI Class Initialized
INFO - 2023-05-31 02:08:59 --> Router Class Initialized
INFO - 2023-05-31 02:08:59 --> Output Class Initialized
INFO - 2023-05-31 02:08:59 --> Security Class Initialized
DEBUG - 2023-05-31 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:08:59 --> Input Class Initialized
INFO - 2023-05-31 02:08:59 --> Language Class Initialized
INFO - 2023-05-31 02:09:00 --> Loader Class Initialized
INFO - 2023-05-31 02:09:00 --> Controller Class Initialized
DEBUG - 2023-05-31 02:09:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:09:00 --> Database Driver Class Initialized
INFO - 2023-05-31 02:09:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:09:00 --> Final output sent to browser
DEBUG - 2023-05-31 02:09:00 --> Total execution time: 0.2016
INFO - 2023-05-31 02:09:08 --> Final output sent to browser
DEBUG - 2023-05-31 02:09:08 --> Total execution time: 18.5106
INFO - 2023-05-31 02:11:53 --> Config Class Initialized
INFO - 2023-05-31 02:11:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:11:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:11:53 --> Utf8 Class Initialized
INFO - 2023-05-31 02:11:53 --> URI Class Initialized
INFO - 2023-05-31 02:11:53 --> Router Class Initialized
INFO - 2023-05-31 02:11:53 --> Output Class Initialized
INFO - 2023-05-31 02:11:53 --> Security Class Initialized
DEBUG - 2023-05-31 02:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:11:53 --> Input Class Initialized
INFO - 2023-05-31 02:11:53 --> Language Class Initialized
INFO - 2023-05-31 02:11:53 --> Loader Class Initialized
INFO - 2023-05-31 02:11:53 --> Controller Class Initialized
DEBUG - 2023-05-31 02:11:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:11:53 --> Database Driver Class Initialized
INFO - 2023-05-31 02:11:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:11:53 --> Final output sent to browser
DEBUG - 2023-05-31 02:11:53 --> Total execution time: 0.2682
INFO - 2023-05-31 02:11:54 --> Config Class Initialized
INFO - 2023-05-31 02:11:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:11:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:11:54 --> Utf8 Class Initialized
INFO - 2023-05-31 02:11:54 --> URI Class Initialized
INFO - 2023-05-31 02:11:54 --> Router Class Initialized
INFO - 2023-05-31 02:11:54 --> Output Class Initialized
INFO - 2023-05-31 02:11:54 --> Security Class Initialized
DEBUG - 2023-05-31 02:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:11:54 --> Input Class Initialized
INFO - 2023-05-31 02:11:54 --> Language Class Initialized
INFO - 2023-05-31 02:11:54 --> Loader Class Initialized
INFO - 2023-05-31 02:11:54 --> Controller Class Initialized
DEBUG - 2023-05-31 02:11:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:11:54 --> Database Driver Class Initialized
INFO - 2023-05-31 02:11:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:11:54 --> Final output sent to browser
DEBUG - 2023-05-31 02:11:54 --> Total execution time: 0.3612
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.1938
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2039
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2328
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:27 --> Utf8 Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> URI Class Initialized
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Router Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Output Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
INFO - 2023-05-31 02:14:27 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:27 --> Input Class Initialized
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:27 --> Language Class Initialized
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Loader Class Initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Controller Class Initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2112
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2421
INFO - 2023-05-31 02:14:27 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:27 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:27 --> Total execution time: 0.2542
INFO - 2023-05-31 02:14:27 --> Config Class Initialized
INFO - 2023-05-31 02:14:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:28 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:28 --> URI Class Initialized
INFO - 2023-05-31 02:14:28 --> Router Class Initialized
INFO - 2023-05-31 02:14:28 --> Output Class Initialized
INFO - 2023-05-31 02:14:28 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:28 --> Input Class Initialized
INFO - 2023-05-31 02:14:28 --> Language Class Initialized
INFO - 2023-05-31 02:14:28 --> Loader Class Initialized
INFO - 2023-05-31 02:14:28 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:28 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:28 --> Config Class Initialized
INFO - 2023-05-31 02:14:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:28 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:28 --> URI Class Initialized
INFO - 2023-05-31 02:14:28 --> Router Class Initialized
INFO - 2023-05-31 02:14:28 --> Output Class Initialized
INFO - 2023-05-31 02:14:28 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:28 --> Input Class Initialized
INFO - 2023-05-31 02:14:28 --> Language Class Initialized
INFO - 2023-05-31 02:14:28 --> Loader Class Initialized
INFO - 2023-05-31 02:14:28 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:28 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:29 --> Config Class Initialized
INFO - 2023-05-31 02:14:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:29 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:29 --> URI Class Initialized
INFO - 2023-05-31 02:14:29 --> Router Class Initialized
INFO - 2023-05-31 02:14:29 --> Output Class Initialized
INFO - 2023-05-31 02:14:29 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:29 --> Input Class Initialized
INFO - 2023-05-31 02:14:29 --> Language Class Initialized
INFO - 2023-05-31 02:14:29 --> Loader Class Initialized
INFO - 2023-05-31 02:14:29 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:29 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:29 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:29 --> Total execution time: 0.2139
INFO - 2023-05-31 02:14:29 --> Config Class Initialized
INFO - 2023-05-31 02:14:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:29 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:29 --> URI Class Initialized
INFO - 2023-05-31 02:14:29 --> Router Class Initialized
INFO - 2023-05-31 02:14:29 --> Output Class Initialized
INFO - 2023-05-31 02:14:29 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:29 --> Input Class Initialized
INFO - 2023-05-31 02:14:29 --> Language Class Initialized
INFO - 2023-05-31 02:14:29 --> Loader Class Initialized
INFO - 2023-05-31 02:14:29 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:29 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:29 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:29 --> Total execution time: 0.1835
INFO - 2023-05-31 02:14:34 --> Config Class Initialized
INFO - 2023-05-31 02:14:34 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:34 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:34 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:34 --> URI Class Initialized
INFO - 2023-05-31 02:14:34 --> Router Class Initialized
INFO - 2023-05-31 02:14:34 --> Output Class Initialized
INFO - 2023-05-31 02:14:34 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:34 --> Input Class Initialized
INFO - 2023-05-31 02:14:34 --> Language Class Initialized
INFO - 2023-05-31 02:14:34 --> Loader Class Initialized
INFO - 2023-05-31 02:14:34 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:34 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:34 --> Total execution time: 0.1488
INFO - 2023-05-31 02:14:35 --> Config Class Initialized
INFO - 2023-05-31 02:14:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:35 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:35 --> URI Class Initialized
INFO - 2023-05-31 02:14:35 --> Router Class Initialized
INFO - 2023-05-31 02:14:35 --> Output Class Initialized
INFO - 2023-05-31 02:14:35 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:35 --> Input Class Initialized
INFO - 2023-05-31 02:14:35 --> Language Class Initialized
INFO - 2023-05-31 02:14:35 --> Loader Class Initialized
INFO - 2023-05-31 02:14:35 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:35 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:35 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:35 --> Total execution time: 0.1932
INFO - 2023-05-31 02:14:38 --> Config Class Initialized
INFO - 2023-05-31 02:14:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:38 --> URI Class Initialized
INFO - 2023-05-31 02:14:38 --> Router Class Initialized
INFO - 2023-05-31 02:14:38 --> Output Class Initialized
INFO - 2023-05-31 02:14:38 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:38 --> Input Class Initialized
INFO - 2023-05-31 02:14:38 --> Language Class Initialized
INFO - 2023-05-31 02:14:38 --> Loader Class Initialized
INFO - 2023-05-31 02:14:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:38 --> Total execution time: 0.1904
INFO - 2023-05-31 02:14:38 --> Config Class Initialized
INFO - 2023-05-31 02:14:38 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:38 --> Config Class Initialized
DEBUG - 2023-05-31 02:14:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:38 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:38 --> URI Class Initialized
DEBUG - 2023-05-31 02:14:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:38 --> Router Class Initialized
INFO - 2023-05-31 02:14:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:38 --> URI Class Initialized
INFO - 2023-05-31 02:14:38 --> Output Class Initialized
INFO - 2023-05-31 02:14:38 --> Security Class Initialized
INFO - 2023-05-31 02:14:38 --> Router Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:38 --> Input Class Initialized
INFO - 2023-05-31 02:14:38 --> Output Class Initialized
INFO - 2023-05-31 02:14:38 --> Language Class Initialized
INFO - 2023-05-31 02:14:38 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:38 --> Input Class Initialized
INFO - 2023-05-31 02:14:38 --> Language Class Initialized
INFO - 2023-05-31 02:14:38 --> Loader Class Initialized
INFO - 2023-05-31 02:14:38 --> Loader Class Initialized
INFO - 2023-05-31 02:14:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:38 --> Total execution time: 0.2047
INFO - 2023-05-31 02:14:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:38 --> Total execution time: 0.1917
INFO - 2023-05-31 02:14:38 --> Config Class Initialized
INFO - 2023-05-31 02:14:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:38 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:38 --> URI Class Initialized
INFO - 2023-05-31 02:14:38 --> Router Class Initialized
INFO - 2023-05-31 02:14:38 --> Output Class Initialized
INFO - 2023-05-31 02:14:38 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:38 --> Input Class Initialized
INFO - 2023-05-31 02:14:38 --> Language Class Initialized
INFO - 2023-05-31 02:14:38 --> Loader Class Initialized
INFO - 2023-05-31 02:14:38 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:38 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:38 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:38 --> Total execution time: 0.1909
INFO - 2023-05-31 02:14:44 --> Config Class Initialized
INFO - 2023-05-31 02:14:44 --> Hooks Class Initialized
INFO - 2023-05-31 02:14:44 --> Config Class Initialized
INFO - 2023-05-31 02:14:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:44 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:44 --> URI Class Initialized
DEBUG - 2023-05-31 02:14:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:44 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:44 --> Router Class Initialized
INFO - 2023-05-31 02:14:44 --> URI Class Initialized
INFO - 2023-05-31 02:14:44 --> Output Class Initialized
INFO - 2023-05-31 02:14:44 --> Router Class Initialized
INFO - 2023-05-31 02:14:44 --> Security Class Initialized
INFO - 2023-05-31 02:14:44 --> Output Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:44 --> Input Class Initialized
INFO - 2023-05-31 02:14:44 --> Security Class Initialized
INFO - 2023-05-31 02:14:44 --> Language Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:44 --> Input Class Initialized
INFO - 2023-05-31 02:14:44 --> Language Class Initialized
INFO - 2023-05-31 02:14:44 --> Loader Class Initialized
INFO - 2023-05-31 02:14:44 --> Loader Class Initialized
INFO - 2023-05-31 02:14:44 --> Controller Class Initialized
INFO - 2023-05-31 02:14:44 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:14:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:44 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:44 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:44 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:44 --> Total execution time: 0.1827
INFO - 2023-05-31 02:14:44 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:44 --> Model "Login_model" initialized
INFO - 2023-05-31 02:14:44 --> Config Class Initialized
INFO - 2023-05-31 02:14:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:44 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:44 --> URI Class Initialized
INFO - 2023-05-31 02:14:44 --> Router Class Initialized
INFO - 2023-05-31 02:14:44 --> Output Class Initialized
INFO - 2023-05-31 02:14:44 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:44 --> Input Class Initialized
INFO - 2023-05-31 02:14:44 --> Language Class Initialized
INFO - 2023-05-31 02:14:44 --> Loader Class Initialized
INFO - 2023-05-31 02:14:44 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:44 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:44 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:44 --> Total execution time: 0.1860
INFO - 2023-05-31 02:14:45 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:45 --> Total execution time: 0.6973
INFO - 2023-05-31 02:14:45 --> Config Class Initialized
INFO - 2023-05-31 02:14:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:45 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:45 --> URI Class Initialized
INFO - 2023-05-31 02:14:45 --> Router Class Initialized
INFO - 2023-05-31 02:14:45 --> Output Class Initialized
INFO - 2023-05-31 02:14:45 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:45 --> Input Class Initialized
INFO - 2023-05-31 02:14:45 --> Language Class Initialized
INFO - 2023-05-31 02:14:45 --> Loader Class Initialized
INFO - 2023-05-31 02:14:45 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:45 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:45 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:45 --> Model "Login_model" initialized
INFO - 2023-05-31 02:14:45 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:45 --> Total execution time: 0.3247
INFO - 2023-05-31 02:14:47 --> Config Class Initialized
INFO - 2023-05-31 02:14:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:47 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:47 --> URI Class Initialized
INFO - 2023-05-31 02:14:47 --> Router Class Initialized
INFO - 2023-05-31 02:14:47 --> Output Class Initialized
INFO - 2023-05-31 02:14:47 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:47 --> Input Class Initialized
INFO - 2023-05-31 02:14:47 --> Language Class Initialized
INFO - 2023-05-31 02:14:47 --> Loader Class Initialized
INFO - 2023-05-31 02:14:47 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:47 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:47 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:47 --> Total execution time: 0.1739
INFO - 2023-05-31 02:14:47 --> Config Class Initialized
INFO - 2023-05-31 02:14:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:47 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:47 --> URI Class Initialized
INFO - 2023-05-31 02:14:47 --> Router Class Initialized
INFO - 2023-05-31 02:14:47 --> Output Class Initialized
INFO - 2023-05-31 02:14:47 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:47 --> Input Class Initialized
INFO - 2023-05-31 02:14:47 --> Language Class Initialized
INFO - 2023-05-31 02:14:47 --> Loader Class Initialized
INFO - 2023-05-31 02:14:47 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:47 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:47 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:47 --> Total execution time: 0.1957
INFO - 2023-05-31 02:14:49 --> Config Class Initialized
INFO - 2023-05-31 02:14:49 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:49 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:49 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:49 --> URI Class Initialized
INFO - 2023-05-31 02:14:49 --> Router Class Initialized
INFO - 2023-05-31 02:14:49 --> Output Class Initialized
INFO - 2023-05-31 02:14:49 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:49 --> Input Class Initialized
INFO - 2023-05-31 02:14:49 --> Language Class Initialized
INFO - 2023-05-31 02:14:49 --> Loader Class Initialized
INFO - 2023-05-31 02:14:49 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:49 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:49 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:49 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:49 --> Total execution time: 0.1642
INFO - 2023-05-31 02:14:49 --> Config Class Initialized
INFO - 2023-05-31 02:14:49 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:14:49 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:14:49 --> Utf8 Class Initialized
INFO - 2023-05-31 02:14:49 --> URI Class Initialized
INFO - 2023-05-31 02:14:49 --> Router Class Initialized
INFO - 2023-05-31 02:14:49 --> Output Class Initialized
INFO - 2023-05-31 02:14:49 --> Security Class Initialized
DEBUG - 2023-05-31 02:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:14:49 --> Input Class Initialized
INFO - 2023-05-31 02:14:49 --> Language Class Initialized
INFO - 2023-05-31 02:14:49 --> Loader Class Initialized
INFO - 2023-05-31 02:14:49 --> Controller Class Initialized
DEBUG - 2023-05-31 02:14:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:14:49 --> Database Driver Class Initialized
INFO - 2023-05-31 02:14:49 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:14:49 --> Final output sent to browser
DEBUG - 2023-05-31 02:14:49 --> Total execution time: 0.1713
INFO - 2023-05-31 02:15:00 --> Config Class Initialized
INFO - 2023-05-31 02:15:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:15:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:15:00 --> Utf8 Class Initialized
INFO - 2023-05-31 02:15:00 --> URI Class Initialized
INFO - 2023-05-31 02:15:00 --> Router Class Initialized
INFO - 2023-05-31 02:15:00 --> Output Class Initialized
INFO - 2023-05-31 02:15:00 --> Security Class Initialized
DEBUG - 2023-05-31 02:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:15:00 --> Input Class Initialized
INFO - 2023-05-31 02:15:00 --> Language Class Initialized
INFO - 2023-05-31 02:15:00 --> Loader Class Initialized
INFO - 2023-05-31 02:15:00 --> Controller Class Initialized
DEBUG - 2023-05-31 02:15:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:15:00 --> Database Driver Class Initialized
INFO - 2023-05-31 02:15:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:15:00 --> Final output sent to browser
DEBUG - 2023-05-31 02:15:00 --> Total execution time: 0.1743
INFO - 2023-05-31 02:15:00 --> Config Class Initialized
INFO - 2023-05-31 02:15:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:15:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:15:00 --> Utf8 Class Initialized
INFO - 2023-05-31 02:15:00 --> URI Class Initialized
INFO - 2023-05-31 02:15:00 --> Router Class Initialized
INFO - 2023-05-31 02:15:00 --> Output Class Initialized
INFO - 2023-05-31 02:15:00 --> Security Class Initialized
DEBUG - 2023-05-31 02:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:15:00 --> Input Class Initialized
INFO - 2023-05-31 02:15:00 --> Language Class Initialized
INFO - 2023-05-31 02:15:00 --> Loader Class Initialized
INFO - 2023-05-31 02:15:00 --> Controller Class Initialized
DEBUG - 2023-05-31 02:15:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:15:00 --> Database Driver Class Initialized
INFO - 2023-05-31 02:15:00 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 02:15:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'lock wait timeout = 4556' at line 1 - Invalid query: set global innodb lock wait timeout = 4556
INFO - 2023-05-31 02:15:00 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-31 02:58:01 --> Config Class Initialized
INFO - 2023-05-31 02:58:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:58:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:58:01 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:01 --> URI Class Initialized
INFO - 2023-05-31 02:58:01 --> Router Class Initialized
INFO - 2023-05-31 02:58:01 --> Output Class Initialized
INFO - 2023-05-31 02:58:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:58:02 --> Input Class Initialized
INFO - 2023-05-31 02:58:02 --> Language Class Initialized
INFO - 2023-05-31 02:58:02 --> Loader Class Initialized
INFO - 2023-05-31 02:58:02 --> Controller Class Initialized
INFO - 2023-05-31 02:58:02 --> Helper loaded: form_helper
INFO - 2023-05-31 02:58:02 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:58:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:58:02 --> Model "Change_model" initialized
INFO - 2023-05-31 02:58:02 --> Model "Grafana_model" initialized
INFO - 2023-05-31 02:58:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:02 --> Total execution time: 0.7215
INFO - 2023-05-31 02:58:02 --> Config Class Initialized
INFO - 2023-05-31 02:58:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:58:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:58:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:02 --> URI Class Initialized
INFO - 2023-05-31 02:58:02 --> Router Class Initialized
INFO - 2023-05-31 02:58:02 --> Output Class Initialized
INFO - 2023-05-31 02:58:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:58:02 --> Input Class Initialized
INFO - 2023-05-31 02:58:02 --> Language Class Initialized
INFO - 2023-05-31 02:58:02 --> Loader Class Initialized
INFO - 2023-05-31 02:58:02 --> Controller Class Initialized
INFO - 2023-05-31 02:58:02 --> Helper loaded: form_helper
INFO - 2023-05-31 02:58:02 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:58:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:58:02 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:02 --> Total execution time: 0.2165
INFO - 2023-05-31 02:58:02 --> Config Class Initialized
INFO - 2023-05-31 02:58:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:58:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:58:02 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:02 --> URI Class Initialized
INFO - 2023-05-31 02:58:02 --> Router Class Initialized
INFO - 2023-05-31 02:58:02 --> Output Class Initialized
INFO - 2023-05-31 02:58:02 --> Security Class Initialized
DEBUG - 2023-05-31 02:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:58:02 --> Input Class Initialized
INFO - 2023-05-31 02:58:02 --> Language Class Initialized
INFO - 2023-05-31 02:58:02 --> Loader Class Initialized
INFO - 2023-05-31 02:58:02 --> Controller Class Initialized
INFO - 2023-05-31 02:58:02 --> Helper loaded: form_helper
INFO - 2023-05-31 02:58:02 --> Helper loaded: url_helper
DEBUG - 2023-05-31 02:58:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:58:02 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:03 --> Model "Login_model" initialized
INFO - 2023-05-31 02:58:03 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:03 --> Total execution time: 0.3388
INFO - 2023-05-31 02:58:03 --> Config Class Initialized
INFO - 2023-05-31 02:58:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:58:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:58:03 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:03 --> URI Class Initialized
INFO - 2023-05-31 02:58:03 --> Router Class Initialized
INFO - 2023-05-31 02:58:03 --> Output Class Initialized
INFO - 2023-05-31 02:58:03 --> Security Class Initialized
DEBUG - 2023-05-31 02:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:58:03 --> Input Class Initialized
INFO - 2023-05-31 02:58:03 --> Language Class Initialized
INFO - 2023-05-31 02:58:03 --> Loader Class Initialized
INFO - 2023-05-31 02:58:03 --> Controller Class Initialized
DEBUG - 2023-05-31 02:58:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:58:03 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:58:03 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:03 --> Total execution time: 0.2203
INFO - 2023-05-31 02:58:03 --> Config Class Initialized
INFO - 2023-05-31 02:58:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:58:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:58:03 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:03 --> URI Class Initialized
INFO - 2023-05-31 02:58:03 --> Router Class Initialized
INFO - 2023-05-31 02:58:03 --> Output Class Initialized
INFO - 2023-05-31 02:58:03 --> Security Class Initialized
DEBUG - 2023-05-31 02:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:58:03 --> Input Class Initialized
INFO - 2023-05-31 02:58:03 --> Language Class Initialized
INFO - 2023-05-31 02:58:03 --> Loader Class Initialized
INFO - 2023-05-31 02:58:03 --> Controller Class Initialized
DEBUG - 2023-05-31 02:58:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:58:03 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:58:03 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:03 --> Total execution time: 0.2133
INFO - 2023-05-31 02:58:03 --> Config Class Initialized
INFO - 2023-05-31 02:58:03 --> Config Class Initialized
INFO - 2023-05-31 02:58:03 --> Hooks Class Initialized
INFO - 2023-05-31 02:58:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:58:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 02:58:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:58:03 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:03 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:03 --> URI Class Initialized
INFO - 2023-05-31 02:58:03 --> URI Class Initialized
INFO - 2023-05-31 02:58:03 --> Router Class Initialized
INFO - 2023-05-31 02:58:03 --> Router Class Initialized
INFO - 2023-05-31 02:58:03 --> Output Class Initialized
INFO - 2023-05-31 02:58:03 --> Output Class Initialized
INFO - 2023-05-31 02:58:03 --> Security Class Initialized
INFO - 2023-05-31 02:58:03 --> Security Class Initialized
DEBUG - 2023-05-31 02:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 02:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:58:03 --> Input Class Initialized
INFO - 2023-05-31 02:58:03 --> Input Class Initialized
INFO - 2023-05-31 02:58:03 --> Language Class Initialized
INFO - 2023-05-31 02:58:03 --> Language Class Initialized
INFO - 2023-05-31 02:58:03 --> Loader Class Initialized
INFO - 2023-05-31 02:58:03 --> Loader Class Initialized
INFO - 2023-05-31 02:58:03 --> Controller Class Initialized
INFO - 2023-05-31 02:58:03 --> Controller Class Initialized
DEBUG - 2023-05-31 02:58:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 02:58:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:58:03 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:03 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:58:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:58:03 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:03 --> Total execution time: 0.1720
INFO - 2023-05-31 02:58:03 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:03 --> Model "Login_model" initialized
INFO - 2023-05-31 02:58:03 --> Config Class Initialized
INFO - 2023-05-31 02:58:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:58:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:58:03 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:03 --> URI Class Initialized
INFO - 2023-05-31 02:58:03 --> Router Class Initialized
INFO - 2023-05-31 02:58:04 --> Output Class Initialized
INFO - 2023-05-31 02:58:04 --> Security Class Initialized
DEBUG - 2023-05-31 02:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:58:04 --> Input Class Initialized
INFO - 2023-05-31 02:58:04 --> Language Class Initialized
INFO - 2023-05-31 02:58:04 --> Loader Class Initialized
INFO - 2023-05-31 02:58:04 --> Controller Class Initialized
DEBUG - 2023-05-31 02:58:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:58:04 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:58:04 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:04 --> Total execution time: 0.2025
INFO - 2023-05-31 02:58:04 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:04 --> Total execution time: 0.4290
INFO - 2023-05-31 02:58:04 --> Config Class Initialized
INFO - 2023-05-31 02:58:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 02:58:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 02:58:04 --> Utf8 Class Initialized
INFO - 2023-05-31 02:58:04 --> URI Class Initialized
INFO - 2023-05-31 02:58:04 --> Router Class Initialized
INFO - 2023-05-31 02:58:04 --> Output Class Initialized
INFO - 2023-05-31 02:58:04 --> Security Class Initialized
DEBUG - 2023-05-31 02:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 02:58:04 --> Input Class Initialized
INFO - 2023-05-31 02:58:04 --> Language Class Initialized
INFO - 2023-05-31 02:58:04 --> Loader Class Initialized
INFO - 2023-05-31 02:58:04 --> Controller Class Initialized
DEBUG - 2023-05-31 02:58:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 02:58:04 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 02:58:04 --> Database Driver Class Initialized
INFO - 2023-05-31 02:58:04 --> Model "Login_model" initialized
INFO - 2023-05-31 02:58:04 --> Final output sent to browser
DEBUG - 2023-05-31 02:58:04 --> Total execution time: 0.5422
INFO - 2023-05-31 03:07:26 --> Config Class Initialized
INFO - 2023-05-31 03:07:26 --> Config Class Initialized
INFO - 2023-05-31 03:07:26 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:07:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:07:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:26 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:26 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:26 --> URI Class Initialized
INFO - 2023-05-31 03:07:26 --> URI Class Initialized
INFO - 2023-05-31 03:07:26 --> Router Class Initialized
INFO - 2023-05-31 03:07:26 --> Router Class Initialized
INFO - 2023-05-31 03:07:26 --> Output Class Initialized
INFO - 2023-05-31 03:07:26 --> Output Class Initialized
INFO - 2023-05-31 03:07:26 --> Security Class Initialized
INFO - 2023-05-31 03:07:26 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:26 --> Input Class Initialized
INFO - 2023-05-31 03:07:26 --> Input Class Initialized
INFO - 2023-05-31 03:07:26 --> Language Class Initialized
INFO - 2023-05-31 03:07:26 --> Language Class Initialized
INFO - 2023-05-31 03:07:26 --> Loader Class Initialized
INFO - 2023-05-31 03:07:26 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:26 --> Loader Class Initialized
INFO - 2023-05-31 03:07:26 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:26 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:27 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:27 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:27 --> Total execution time: 0.2762
INFO - 2023-05-31 03:07:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:27 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:27 --> Config Class Initialized
INFO - 2023-05-31 03:07:27 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:27 --> Model "Login_model" initialized
DEBUG - 2023-05-31 03:07:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:27 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:27 --> URI Class Initialized
INFO - 2023-05-31 03:07:27 --> Router Class Initialized
INFO - 2023-05-31 03:07:27 --> Output Class Initialized
INFO - 2023-05-31 03:07:27 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:27 --> Input Class Initialized
INFO - 2023-05-31 03:07:27 --> Language Class Initialized
INFO - 2023-05-31 03:07:27 --> Loader Class Initialized
INFO - 2023-05-31 03:07:27 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:27 --> Total execution time: 0.5435
INFO - 2023-05-31 03:07:27 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:27 --> Config Class Initialized
INFO - 2023-05-31 03:07:27 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:27 --> Database Driver Class Initialized
DEBUG - 2023-05-31 03:07:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:27 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:27 --> URI Class Initialized
INFO - 2023-05-31 03:07:27 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:27 --> Total execution time: 0.3043
INFO - 2023-05-31 03:07:27 --> Router Class Initialized
INFO - 2023-05-31 03:07:27 --> Output Class Initialized
INFO - 2023-05-31 03:07:27 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:27 --> Input Class Initialized
INFO - 2023-05-31 03:07:27 --> Language Class Initialized
INFO - 2023-05-31 03:07:27 --> Loader Class Initialized
INFO - 2023-05-31 03:07:27 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:27 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:27 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:27 --> Model "Login_model" initialized
INFO - 2023-05-31 03:07:27 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:27 --> Total execution time: 0.4530
INFO - 2023-05-31 03:07:50 --> Config Class Initialized
INFO - 2023-05-31 03:07:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:07:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:50 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:50 --> URI Class Initialized
INFO - 2023-05-31 03:07:50 --> Router Class Initialized
INFO - 2023-05-31 03:07:50 --> Output Class Initialized
INFO - 2023-05-31 03:07:50 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:50 --> Input Class Initialized
INFO - 2023-05-31 03:07:50 --> Language Class Initialized
INFO - 2023-05-31 03:07:50 --> Loader Class Initialized
INFO - 2023-05-31 03:07:50 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:50 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:50 --> Model "Login_model" initialized
INFO - 2023-05-31 03:07:50 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:50 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:50 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:50 --> Total execution time: 0.2643
INFO - 2023-05-31 03:07:50 --> Config Class Initialized
INFO - 2023-05-31 03:07:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:07:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:50 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:50 --> URI Class Initialized
INFO - 2023-05-31 03:07:50 --> Router Class Initialized
INFO - 2023-05-31 03:07:50 --> Output Class Initialized
INFO - 2023-05-31 03:07:50 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:50 --> Input Class Initialized
INFO - 2023-05-31 03:07:50 --> Language Class Initialized
INFO - 2023-05-31 03:07:50 --> Loader Class Initialized
INFO - 2023-05-31 03:07:50 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:50 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:50 --> Model "Login_model" initialized
INFO - 2023-05-31 03:07:50 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:50 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:50 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:50 --> Total execution time: 0.2491
INFO - 2023-05-31 03:07:50 --> Config Class Initialized
INFO - 2023-05-31 03:07:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:07:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:50 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:51 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:51 --> Total execution time: 0.1319
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:51 --> Model "Login_model" initialized
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:51 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:51 --> Total execution time: 0.2570
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:51 --> Final output sent to browser
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Total execution time: 0.2020
INFO - 2023-05-31 03:07:51 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:51 --> Total execution time: 0.2127
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> Model "Login_model" initialized
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> Final output sent to browser
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Total execution time: 0.2658
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:51 --> Model "Cluster_model" initialized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Final output sent to browser
INFO - 2023-05-31 03:07:51 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:51 --> Total execution time: 0.2218
DEBUG - 2023-05-31 03:07:51 --> Total execution time: 0.2295
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:51 --> Config Class Initialized
INFO - 2023-05-31 03:07:51 --> Hooks Class Initialized
INFO - 2023-05-31 03:07:51 --> Database Driver Class Initialized
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> Utf8 Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> URI Class Initialized
INFO - 2023-05-31 03:07:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Router Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
INFO - 2023-05-31 03:07:51 --> Output Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
INFO - 2023-05-31 03:07:51 --> Security Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Input Class Initialized
INFO - 2023-05-31 03:07:51 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:51 --> Total execution time: 0.2452
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Language Class Initialized
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
INFO - 2023-05-31 03:07:51 --> Loader Class Initialized
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
INFO - 2023-05-31 03:07:51 --> Controller Class Initialized
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:07:52 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:52 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:52 --> Database Driver Class Initialized
INFO - 2023-05-31 03:07:52 --> Model "Login_model" initialized
INFO - 2023-05-31 03:07:52 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:07:52 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:52 --> Total execution time: 0.1996
INFO - 2023-05-31 03:07:52 --> Final output sent to browser
DEBUG - 2023-05-31 03:07:52 --> Total execution time: 0.2041
INFO - 2023-05-31 03:08:01 --> Config Class Initialized
INFO - 2023-05-31 03:08:01 --> Config Class Initialized
INFO - 2023-05-31 03:08:01 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:01 --> URI Class Initialized
INFO - 2023-05-31 03:08:01 --> URI Class Initialized
INFO - 2023-05-31 03:08:01 --> Router Class Initialized
INFO - 2023-05-31 03:08:01 --> Router Class Initialized
INFO - 2023-05-31 03:08:01 --> Output Class Initialized
INFO - 2023-05-31 03:08:01 --> Output Class Initialized
INFO - 2023-05-31 03:08:01 --> Security Class Initialized
INFO - 2023-05-31 03:08:01 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:01 --> Input Class Initialized
INFO - 2023-05-31 03:08:01 --> Input Class Initialized
INFO - 2023-05-31 03:08:01 --> Language Class Initialized
INFO - 2023-05-31 03:08:01 --> Language Class Initialized
INFO - 2023-05-31 03:08:01 --> Loader Class Initialized
INFO - 2023-05-31 03:08:01 --> Loader Class Initialized
INFO - 2023-05-31 03:08:01 --> Controller Class Initialized
INFO - 2023-05-31 03:08:01 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:01 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:01 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:01 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:01 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:01 --> Total execution time: 0.2047
INFO - 2023-05-31 03:08:01 --> Config Class Initialized
INFO - 2023-05-31 03:08:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:01 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:01 --> URI Class Initialized
INFO - 2023-05-31 03:08:01 --> Router Class Initialized
INFO - 2023-05-31 03:08:01 --> Output Class Initialized
INFO - 2023-05-31 03:08:01 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:01 --> Input Class Initialized
INFO - 2023-05-31 03:08:01 --> Language Class Initialized
INFO - 2023-05-31 03:08:01 --> Loader Class Initialized
INFO - 2023-05-31 03:08:01 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:01 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:01 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:01 --> Total execution time: 0.2318
INFO - 2023-05-31 03:08:04 --> Config Class Initialized
INFO - 2023-05-31 03:08:04 --> Config Class Initialized
INFO - 2023-05-31 03:08:04 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:08:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:04 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:04 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:04 --> URI Class Initialized
INFO - 2023-05-31 03:08:04 --> URI Class Initialized
INFO - 2023-05-31 03:08:04 --> Router Class Initialized
INFO - 2023-05-31 03:08:04 --> Router Class Initialized
INFO - 2023-05-31 03:08:04 --> Output Class Initialized
INFO - 2023-05-31 03:08:04 --> Output Class Initialized
INFO - 2023-05-31 03:08:04 --> Security Class Initialized
INFO - 2023-05-31 03:08:04 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:04 --> Input Class Initialized
INFO - 2023-05-31 03:08:04 --> Input Class Initialized
INFO - 2023-05-31 03:08:04 --> Language Class Initialized
INFO - 2023-05-31 03:08:04 --> Language Class Initialized
INFO - 2023-05-31 03:08:04 --> Loader Class Initialized
INFO - 2023-05-31 03:08:04 --> Loader Class Initialized
INFO - 2023-05-31 03:08:04 --> Controller Class Initialized
INFO - 2023-05-31 03:08:04 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:08:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:04 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:04 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:04 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:04 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:04 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:04 --> Total execution time: 0.2670
INFO - 2023-05-31 03:08:04 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:04 --> Total execution time: 0.2744
INFO - 2023-05-31 03:08:05 --> Config Class Initialized
INFO - 2023-05-31 03:08:05 --> Config Class Initialized
INFO - 2023-05-31 03:08:05 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:05 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:08:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:05 --> URI Class Initialized
INFO - 2023-05-31 03:08:05 --> URI Class Initialized
INFO - 2023-05-31 03:08:05 --> Router Class Initialized
INFO - 2023-05-31 03:08:05 --> Router Class Initialized
INFO - 2023-05-31 03:08:05 --> Output Class Initialized
INFO - 2023-05-31 03:08:05 --> Output Class Initialized
INFO - 2023-05-31 03:08:05 --> Security Class Initialized
INFO - 2023-05-31 03:08:05 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:05 --> Input Class Initialized
INFO - 2023-05-31 03:08:05 --> Input Class Initialized
INFO - 2023-05-31 03:08:05 --> Language Class Initialized
INFO - 2023-05-31 03:08:05 --> Language Class Initialized
INFO - 2023-05-31 03:08:05 --> Loader Class Initialized
INFO - 2023-05-31 03:08:05 --> Loader Class Initialized
INFO - 2023-05-31 03:08:05 --> Controller Class Initialized
INFO - 2023-05-31 03:08:05 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:08:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:05 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:05 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:05 --> Total execution time: 0.1719
INFO - 2023-05-31 03:08:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:05 --> Total execution time: 0.1853
INFO - 2023-05-31 03:08:05 --> Config Class Initialized
INFO - 2023-05-31 03:08:05 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:05 --> Config Class Initialized
INFO - 2023-05-31 03:08:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:05 --> URI Class Initialized
DEBUG - 2023-05-31 03:08:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:05 --> URI Class Initialized
INFO - 2023-05-31 03:08:05 --> Router Class Initialized
INFO - 2023-05-31 03:08:05 --> Router Class Initialized
INFO - 2023-05-31 03:08:05 --> Output Class Initialized
INFO - 2023-05-31 03:08:05 --> Config Class Initialized
INFO - 2023-05-31 03:08:05 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:05 --> Output Class Initialized
INFO - 2023-05-31 03:08:05 --> Security Class Initialized
INFO - 2023-05-31 03:08:05 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:05 --> Input Class Initialized
DEBUG - 2023-05-31 03:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:05 --> Input Class Initialized
INFO - 2023-05-31 03:08:05 --> Language Class Initialized
INFO - 2023-05-31 03:08:05 --> Language Class Initialized
DEBUG - 2023-05-31 03:08:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:05 --> Loader Class Initialized
INFO - 2023-05-31 03:08:05 --> URI Class Initialized
INFO - 2023-05-31 03:08:05 --> Loader Class Initialized
INFO - 2023-05-31 03:08:05 --> Controller Class Initialized
INFO - 2023-05-31 03:08:05 --> Router Class Initialized
INFO - 2023-05-31 03:08:05 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:08:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:05 --> Output Class Initialized
INFO - 2023-05-31 03:08:05 --> Security Class Initialized
INFO - 2023-05-31 03:08:05 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:05 --> Database Driver Class Initialized
DEBUG - 2023-05-31 03:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:05 --> Input Class Initialized
INFO - 2023-05-31 03:08:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:05 --> Language Class Initialized
INFO - 2023-05-31 03:08:05 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:05 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:05 --> Total execution time: 0.2360
INFO - 2023-05-31 03:08:05 --> Loader Class Initialized
INFO - 2023-05-31 03:08:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:05 --> Total execution time: 0.2435
INFO - 2023-05-31 03:08:05 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:05 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:05 --> Total execution time: 0.2825
INFO - 2023-05-31 03:08:13 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:13 --> Total execution time: 11.5520
INFO - 2023-05-31 03:08:14 --> Config Class Initialized
INFO - 2023-05-31 03:08:14 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:14 --> Config Class Initialized
INFO - 2023-05-31 03:08:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:14 --> Utf8 Class Initialized
DEBUG - 2023-05-31 03:08:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:14 --> URI Class Initialized
INFO - 2023-05-31 03:08:14 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:14 --> URI Class Initialized
INFO - 2023-05-31 03:08:14 --> Router Class Initialized
INFO - 2023-05-31 03:08:14 --> Router Class Initialized
INFO - 2023-05-31 03:08:14 --> Output Class Initialized
INFO - 2023-05-31 03:08:14 --> Security Class Initialized
INFO - 2023-05-31 03:08:14 --> Output Class Initialized
INFO - 2023-05-31 03:08:14 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:14 --> Input Class Initialized
DEBUG - 2023-05-31 03:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:14 --> Language Class Initialized
INFO - 2023-05-31 03:08:14 --> Input Class Initialized
INFO - 2023-05-31 03:08:14 --> Language Class Initialized
INFO - 2023-05-31 03:08:14 --> Loader Class Initialized
INFO - 2023-05-31 03:08:14 --> Controller Class Initialized
INFO - 2023-05-31 03:08:14 --> Loader Class Initialized
DEBUG - 2023-05-31 03:08:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:14 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:14 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:14 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:14 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:14 --> Total execution time: 0.2165
INFO - 2023-05-31 03:08:14 --> Config Class Initialized
INFO - 2023-05-31 03:08:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:14 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:14 --> URI Class Initialized
INFO - 2023-05-31 03:08:15 --> Router Class Initialized
INFO - 2023-05-31 03:08:15 --> Output Class Initialized
INFO - 2023-05-31 03:08:15 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:15 --> Input Class Initialized
INFO - 2023-05-31 03:08:15 --> Language Class Initialized
INFO - 2023-05-31 03:08:15 --> Loader Class Initialized
INFO - 2023-05-31 03:08:15 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:15 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:15 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:15 --> Total execution time: 0.1941
INFO - 2023-05-31 03:08:22 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:22 --> Total execution time: 7.5556
INFO - 2023-05-31 03:08:24 --> Config Class Initialized
INFO - 2023-05-31 03:08:24 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:24 --> Config Class Initialized
INFO - 2023-05-31 03:08:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:24 --> Utf8 Class Initialized
DEBUG - 2023-05-31 03:08:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:24 --> URI Class Initialized
INFO - 2023-05-31 03:08:24 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:24 --> URI Class Initialized
INFO - 2023-05-31 03:08:24 --> Router Class Initialized
INFO - 2023-05-31 03:08:24 --> Router Class Initialized
INFO - 2023-05-31 03:08:24 --> Output Class Initialized
INFO - 2023-05-31 03:08:24 --> Output Class Initialized
INFO - 2023-05-31 03:08:24 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:24 --> Security Class Initialized
INFO - 2023-05-31 03:08:24 --> Input Class Initialized
DEBUG - 2023-05-31 03:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:24 --> Language Class Initialized
INFO - 2023-05-31 03:08:24 --> Input Class Initialized
INFO - 2023-05-31 03:08:24 --> Language Class Initialized
INFO - 2023-05-31 03:08:24 --> Loader Class Initialized
INFO - 2023-05-31 03:08:24 --> Loader Class Initialized
INFO - 2023-05-31 03:08:24 --> Controller Class Initialized
INFO - 2023-05-31 03:08:24 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:08:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:24 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:24 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:24 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:24 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:24 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:24 --> Total execution time: 0.1891
INFO - 2023-05-31 03:08:24 --> Config Class Initialized
INFO - 2023-05-31 03:08:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:24 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:24 --> URI Class Initialized
INFO - 2023-05-31 03:08:24 --> Router Class Initialized
INFO - 2023-05-31 03:08:24 --> Output Class Initialized
INFO - 2023-05-31 03:08:25 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:25 --> Input Class Initialized
INFO - 2023-05-31 03:08:25 --> Language Class Initialized
INFO - 2023-05-31 03:08:25 --> Loader Class Initialized
INFO - 2023-05-31 03:08:25 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:25 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:25 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:25 --> Total execution time: 0.2992
INFO - 2023-05-31 03:08:34 --> Config Class Initialized
INFO - 2023-05-31 03:08:34 --> Config Class Initialized
INFO - 2023-05-31 03:08:34 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:34 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:08:34 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:34 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:34 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:34 --> URI Class Initialized
INFO - 2023-05-31 03:08:34 --> URI Class Initialized
INFO - 2023-05-31 03:08:34 --> Router Class Initialized
INFO - 2023-05-31 03:08:34 --> Router Class Initialized
INFO - 2023-05-31 03:08:34 --> Output Class Initialized
INFO - 2023-05-31 03:08:34 --> Output Class Initialized
INFO - 2023-05-31 03:08:34 --> Security Class Initialized
INFO - 2023-05-31 03:08:34 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:34 --> Input Class Initialized
INFO - 2023-05-31 03:08:34 --> Input Class Initialized
INFO - 2023-05-31 03:08:34 --> Language Class Initialized
INFO - 2023-05-31 03:08:34 --> Language Class Initialized
INFO - 2023-05-31 03:08:34 --> Loader Class Initialized
INFO - 2023-05-31 03:08:34 --> Loader Class Initialized
INFO - 2023-05-31 03:08:34 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:34 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:34 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:34 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:34 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:34 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:34 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:34 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:34 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:34 --> Total execution time: 0.2041
INFO - 2023-05-31 03:08:34 --> Config Class Initialized
INFO - 2023-05-31 03:08:34 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:34 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:34 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:34 --> URI Class Initialized
INFO - 2023-05-31 03:08:35 --> Router Class Initialized
INFO - 2023-05-31 03:08:35 --> Output Class Initialized
INFO - 2023-05-31 03:08:35 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:35 --> Input Class Initialized
INFO - 2023-05-31 03:08:35 --> Language Class Initialized
INFO - 2023-05-31 03:08:35 --> Loader Class Initialized
INFO - 2023-05-31 03:08:35 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:35 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:35 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:35 --> Total execution time: 0.2081
INFO - 2023-05-31 03:08:36 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:36 --> Total execution time: 11.6988
INFO - 2023-05-31 03:08:36 --> Config Class Initialized
INFO - 2023-05-31 03:08:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:36 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:36 --> URI Class Initialized
INFO - 2023-05-31 03:08:36 --> Router Class Initialized
INFO - 2023-05-31 03:08:36 --> Output Class Initialized
INFO - 2023-05-31 03:08:36 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:36 --> Input Class Initialized
INFO - 2023-05-31 03:08:36 --> Language Class Initialized
INFO - 2023-05-31 03:08:36 --> Loader Class Initialized
INFO - 2023-05-31 03:08:36 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:36 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:36 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:36 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:44 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:44 --> Total execution time: 9.9238
INFO - 2023-05-31 03:08:44 --> Config Class Initialized
INFO - 2023-05-31 03:08:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:44 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:44 --> URI Class Initialized
INFO - 2023-05-31 03:08:44 --> Router Class Initialized
INFO - 2023-05-31 03:08:44 --> Output Class Initialized
INFO - 2023-05-31 03:08:44 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:44 --> Input Class Initialized
INFO - 2023-05-31 03:08:44 --> Language Class Initialized
INFO - 2023-05-31 03:08:44 --> Loader Class Initialized
INFO - 2023-05-31 03:08:44 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:44 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:44 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:44 --> Total execution time: 0.1808
INFO - 2023-05-31 03:08:44 --> Config Class Initialized
INFO - 2023-05-31 03:08:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:44 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:44 --> URI Class Initialized
INFO - 2023-05-31 03:08:44 --> Router Class Initialized
INFO - 2023-05-31 03:08:44 --> Output Class Initialized
INFO - 2023-05-31 03:08:44 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:45 --> Input Class Initialized
INFO - 2023-05-31 03:08:45 --> Language Class Initialized
INFO - 2023-05-31 03:08:45 --> Loader Class Initialized
INFO - 2023-05-31 03:08:45 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:45 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:45 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:45 --> Total execution time: 0.1971
INFO - 2023-05-31 03:08:47 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:47 --> Total execution time: 11.3641
INFO - 2023-05-31 03:08:47 --> Config Class Initialized
INFO - 2023-05-31 03:08:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:47 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:47 --> URI Class Initialized
INFO - 2023-05-31 03:08:47 --> Router Class Initialized
INFO - 2023-05-31 03:08:47 --> Output Class Initialized
INFO - 2023-05-31 03:08:47 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:47 --> Input Class Initialized
INFO - 2023-05-31 03:08:47 --> Language Class Initialized
INFO - 2023-05-31 03:08:47 --> Loader Class Initialized
INFO - 2023-05-31 03:08:47 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:47 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:48 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:48 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:54 --> Config Class Initialized
INFO - 2023-05-31 03:08:54 --> Hooks Class Initialized
INFO - 2023-05-31 03:08:54 --> Config Class Initialized
INFO - 2023-05-31 03:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:54 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:54 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:54 --> URI Class Initialized
INFO - 2023-05-31 03:08:54 --> URI Class Initialized
INFO - 2023-05-31 03:08:54 --> Router Class Initialized
INFO - 2023-05-31 03:08:54 --> Router Class Initialized
INFO - 2023-05-31 03:08:54 --> Output Class Initialized
INFO - 2023-05-31 03:08:54 --> Output Class Initialized
INFO - 2023-05-31 03:08:54 --> Security Class Initialized
INFO - 2023-05-31 03:08:54 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:54 --> Input Class Initialized
INFO - 2023-05-31 03:08:54 --> Input Class Initialized
INFO - 2023-05-31 03:08:54 --> Language Class Initialized
INFO - 2023-05-31 03:08:54 --> Language Class Initialized
INFO - 2023-05-31 03:08:54 --> Loader Class Initialized
INFO - 2023-05-31 03:08:54 --> Loader Class Initialized
INFO - 2023-05-31 03:08:54 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:54 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:54 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:54 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:54 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:54 --> Model "Login_model" initialized
INFO - 2023-05-31 03:08:54 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:54 --> Total execution time: 0.1736
INFO - 2023-05-31 03:08:54 --> Config Class Initialized
INFO - 2023-05-31 03:08:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:54 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:54 --> URI Class Initialized
INFO - 2023-05-31 03:08:54 --> Router Class Initialized
INFO - 2023-05-31 03:08:54 --> Output Class Initialized
INFO - 2023-05-31 03:08:54 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:54 --> Input Class Initialized
INFO - 2023-05-31 03:08:54 --> Language Class Initialized
INFO - 2023-05-31 03:08:55 --> Loader Class Initialized
INFO - 2023-05-31 03:08:55 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:55 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:55 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:55 --> Total execution time: 0.4068
INFO - 2023-05-31 03:08:59 --> Final output sent to browser
DEBUG - 2023-05-31 03:08:59 --> Total execution time: 11.3005
INFO - 2023-05-31 03:08:59 --> Config Class Initialized
INFO - 2023-05-31 03:08:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:08:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:08:59 --> Utf8 Class Initialized
INFO - 2023-05-31 03:08:59 --> URI Class Initialized
INFO - 2023-05-31 03:08:59 --> Router Class Initialized
INFO - 2023-05-31 03:08:59 --> Output Class Initialized
INFO - 2023-05-31 03:08:59 --> Security Class Initialized
DEBUG - 2023-05-31 03:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:08:59 --> Input Class Initialized
INFO - 2023-05-31 03:08:59 --> Language Class Initialized
INFO - 2023-05-31 03:08:59 --> Loader Class Initialized
INFO - 2023-05-31 03:08:59 --> Controller Class Initialized
DEBUG - 2023-05-31 03:08:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:08:59 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:08:59 --> Database Driver Class Initialized
INFO - 2023-05-31 03:08:59 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:03 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:03 --> Total execution time: 8.5713
INFO - 2023-05-31 03:09:04 --> Config Class Initialized
INFO - 2023-05-31 03:09:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:04 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:04 --> URI Class Initialized
INFO - 2023-05-31 03:09:04 --> Router Class Initialized
INFO - 2023-05-31 03:09:04 --> Output Class Initialized
INFO - 2023-05-31 03:09:04 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:04 --> Input Class Initialized
INFO - 2023-05-31 03:09:04 --> Language Class Initialized
INFO - 2023-05-31 03:09:04 --> Loader Class Initialized
INFO - 2023-05-31 03:09:04 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:04 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:05 --> Total execution time: 0.3680
INFO - 2023-05-31 03:09:05 --> Config Class Initialized
INFO - 2023-05-31 03:09:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:05 --> URI Class Initialized
INFO - 2023-05-31 03:09:05 --> Router Class Initialized
INFO - 2023-05-31 03:09:05 --> Output Class Initialized
INFO - 2023-05-31 03:09:05 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:05 --> Input Class Initialized
INFO - 2023-05-31 03:09:05 --> Language Class Initialized
INFO - 2023-05-31 03:09:05 --> Loader Class Initialized
INFO - 2023-05-31 03:09:05 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:05 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:05 --> Total execution time: 0.3040
INFO - 2023-05-31 03:09:06 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:06 --> Total execution time: 7.4706
INFO - 2023-05-31 03:09:06 --> Config Class Initialized
INFO - 2023-05-31 03:09:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:06 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:06 --> URI Class Initialized
INFO - 2023-05-31 03:09:06 --> Router Class Initialized
INFO - 2023-05-31 03:09:06 --> Output Class Initialized
INFO - 2023-05-31 03:09:06 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:06 --> Input Class Initialized
INFO - 2023-05-31 03:09:06 --> Language Class Initialized
INFO - 2023-05-31 03:09:06 --> Loader Class Initialized
INFO - 2023-05-31 03:09:06 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:06 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:06 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:06 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:13 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:13 --> Total execution time: 6.8187
INFO - 2023-05-31 03:09:13 --> Config Class Initialized
INFO - 2023-05-31 03:09:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:13 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:13 --> URI Class Initialized
INFO - 2023-05-31 03:09:13 --> Router Class Initialized
INFO - 2023-05-31 03:09:13 --> Output Class Initialized
INFO - 2023-05-31 03:09:13 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:13 --> Input Class Initialized
INFO - 2023-05-31 03:09:13 --> Language Class Initialized
INFO - 2023-05-31 03:09:13 --> Loader Class Initialized
INFO - 2023-05-31 03:09:13 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:13 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:13 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:13 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:14 --> Config Class Initialized
INFO - 2023-05-31 03:09:14 --> Hooks Class Initialized
INFO - 2023-05-31 03:09:14 --> Config Class Initialized
INFO - 2023-05-31 03:09:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:14 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:14 --> URI Class Initialized
DEBUG - 2023-05-31 03:09:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:14 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:14 --> Router Class Initialized
INFO - 2023-05-31 03:09:14 --> URI Class Initialized
INFO - 2023-05-31 03:09:14 --> Output Class Initialized
INFO - 2023-05-31 03:09:14 --> Router Class Initialized
INFO - 2023-05-31 03:09:14 --> Security Class Initialized
INFO - 2023-05-31 03:09:14 --> Output Class Initialized
DEBUG - 2023-05-31 03:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:14 --> Input Class Initialized
INFO - 2023-05-31 03:09:14 --> Security Class Initialized
INFO - 2023-05-31 03:09:14 --> Language Class Initialized
DEBUG - 2023-05-31 03:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:14 --> Input Class Initialized
INFO - 2023-05-31 03:09:14 --> Language Class Initialized
INFO - 2023-05-31 03:09:14 --> Loader Class Initialized
INFO - 2023-05-31 03:09:14 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:14 --> Loader Class Initialized
INFO - 2023-05-31 03:09:14 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:14 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:14 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:14 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:14 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:14 --> Total execution time: 0.2088
INFO - 2023-05-31 03:09:14 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:14 --> Config Class Initialized
INFO - 2023-05-31 03:09:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:14 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:14 --> URI Class Initialized
INFO - 2023-05-31 03:09:15 --> Router Class Initialized
INFO - 2023-05-31 03:09:15 --> Output Class Initialized
INFO - 2023-05-31 03:09:15 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:15 --> Input Class Initialized
INFO - 2023-05-31 03:09:15 --> Language Class Initialized
INFO - 2023-05-31 03:09:15 --> Loader Class Initialized
INFO - 2023-05-31 03:09:15 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:15 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:15 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:15 --> Total execution time: 0.1920
INFO - 2023-05-31 03:09:24 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:24 --> Total execution time: 10.9626
INFO - 2023-05-31 03:09:24 --> Config Class Initialized
INFO - 2023-05-31 03:09:24 --> Config Class Initialized
INFO - 2023-05-31 03:09:24 --> Hooks Class Initialized
INFO - 2023-05-31 03:09:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:09:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:24 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:24 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:24 --> URI Class Initialized
INFO - 2023-05-31 03:09:24 --> URI Class Initialized
INFO - 2023-05-31 03:09:24 --> Router Class Initialized
INFO - 2023-05-31 03:09:24 --> Router Class Initialized
INFO - 2023-05-31 03:09:24 --> Output Class Initialized
INFO - 2023-05-31 03:09:24 --> Output Class Initialized
INFO - 2023-05-31 03:09:24 --> Security Class Initialized
INFO - 2023-05-31 03:09:24 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:24 --> Input Class Initialized
DEBUG - 2023-05-31 03:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:24 --> Language Class Initialized
INFO - 2023-05-31 03:09:24 --> Input Class Initialized
INFO - 2023-05-31 03:09:24 --> Language Class Initialized
INFO - 2023-05-31 03:09:24 --> Loader Class Initialized
INFO - 2023-05-31 03:09:24 --> Loader Class Initialized
INFO - 2023-05-31 03:09:24 --> Controller Class Initialized
INFO - 2023-05-31 03:09:24 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:09:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:24 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:24 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:24 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:24 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:24 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:24 --> Total execution time: 0.1753
INFO - 2023-05-31 03:09:24 --> Config Class Initialized
INFO - 2023-05-31 03:09:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:24 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:24 --> URI Class Initialized
INFO - 2023-05-31 03:09:24 --> Router Class Initialized
INFO - 2023-05-31 03:09:24 --> Output Class Initialized
INFO - 2023-05-31 03:09:24 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:24 --> Input Class Initialized
INFO - 2023-05-31 03:09:25 --> Language Class Initialized
INFO - 2023-05-31 03:09:25 --> Loader Class Initialized
INFO - 2023-05-31 03:09:25 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:25 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:25 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:25 --> Total execution time: 10.3563
INFO - 2023-05-31 03:09:25 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:25 --> Total execution time: 0.1999
INFO - 2023-05-31 03:09:25 --> Config Class Initialized
INFO - 2023-05-31 03:09:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:25 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:25 --> URI Class Initialized
INFO - 2023-05-31 03:09:25 --> Router Class Initialized
INFO - 2023-05-31 03:09:25 --> Output Class Initialized
INFO - 2023-05-31 03:09:25 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:25 --> Input Class Initialized
INFO - 2023-05-31 03:09:25 --> Language Class Initialized
INFO - 2023-05-31 03:09:25 --> Loader Class Initialized
INFO - 2023-05-31 03:09:25 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:25 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:25 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:25 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:33 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:33 --> Total execution time: 9.2568
INFO - 2023-05-31 03:09:34 --> Config Class Initialized
INFO - 2023-05-31 03:09:34 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:34 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:34 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:34 --> URI Class Initialized
INFO - 2023-05-31 03:09:34 --> Router Class Initialized
INFO - 2023-05-31 03:09:34 --> Output Class Initialized
INFO - 2023-05-31 03:09:34 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:34 --> Input Class Initialized
INFO - 2023-05-31 03:09:34 --> Language Class Initialized
INFO - 2023-05-31 03:09:34 --> Loader Class Initialized
INFO - 2023-05-31 03:09:34 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:34 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:34 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:35 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:35 --> Total execution time: 0.3939
INFO - 2023-05-31 03:09:35 --> Config Class Initialized
INFO - 2023-05-31 03:09:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:35 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:35 --> URI Class Initialized
INFO - 2023-05-31 03:09:35 --> Router Class Initialized
INFO - 2023-05-31 03:09:35 --> Output Class Initialized
INFO - 2023-05-31 03:09:35 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:35 --> Input Class Initialized
INFO - 2023-05-31 03:09:35 --> Language Class Initialized
INFO - 2023-05-31 03:09:35 --> Loader Class Initialized
INFO - 2023-05-31 03:09:35 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:35 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:35 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:35 --> Total execution time: 10.1801
INFO - 2023-05-31 03:09:35 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:35 --> Total execution time: 0.1808
INFO - 2023-05-31 03:09:35 --> Config Class Initialized
INFO - 2023-05-31 03:09:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:35 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:35 --> URI Class Initialized
INFO - 2023-05-31 03:09:35 --> Router Class Initialized
INFO - 2023-05-31 03:09:35 --> Output Class Initialized
INFO - 2023-05-31 03:09:35 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:35 --> Input Class Initialized
INFO - 2023-05-31 03:09:35 --> Language Class Initialized
INFO - 2023-05-31 03:09:35 --> Loader Class Initialized
INFO - 2023-05-31 03:09:35 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:35 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:35 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:35 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:44 --> Config Class Initialized
INFO - 2023-05-31 03:09:44 --> Config Class Initialized
INFO - 2023-05-31 03:09:44 --> Hooks Class Initialized
INFO - 2023-05-31 03:09:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:09:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:44 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:44 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:44 --> URI Class Initialized
INFO - 2023-05-31 03:09:44 --> URI Class Initialized
INFO - 2023-05-31 03:09:44 --> Router Class Initialized
INFO - 2023-05-31 03:09:44 --> Router Class Initialized
INFO - 2023-05-31 03:09:44 --> Output Class Initialized
INFO - 2023-05-31 03:09:44 --> Output Class Initialized
INFO - 2023-05-31 03:09:44 --> Security Class Initialized
INFO - 2023-05-31 03:09:44 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:44 --> Input Class Initialized
INFO - 2023-05-31 03:09:44 --> Input Class Initialized
INFO - 2023-05-31 03:09:44 --> Language Class Initialized
INFO - 2023-05-31 03:09:44 --> Language Class Initialized
INFO - 2023-05-31 03:09:44 --> Loader Class Initialized
INFO - 2023-05-31 03:09:44 --> Controller Class Initialized
INFO - 2023-05-31 03:09:44 --> Loader Class Initialized
DEBUG - 2023-05-31 03:09:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:44 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:44 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:44 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:44 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:44 --> Total execution time: 0.1647
INFO - 2023-05-31 03:09:44 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:44 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:44 --> Config Class Initialized
INFO - 2023-05-31 03:09:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:44 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:44 --> URI Class Initialized
INFO - 2023-05-31 03:09:44 --> Router Class Initialized
INFO - 2023-05-31 03:09:44 --> Output Class Initialized
INFO - 2023-05-31 03:09:45 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:45 --> Input Class Initialized
INFO - 2023-05-31 03:09:45 --> Language Class Initialized
INFO - 2023-05-31 03:09:45 --> Loader Class Initialized
INFO - 2023-05-31 03:09:45 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:45 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:45 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:45 --> Total execution time: 0.2070
INFO - 2023-05-31 03:09:48 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:48 --> Total execution time: 12.9342
INFO - 2023-05-31 03:09:48 --> Config Class Initialized
INFO - 2023-05-31 03:09:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:48 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:48 --> URI Class Initialized
INFO - 2023-05-31 03:09:48 --> Router Class Initialized
INFO - 2023-05-31 03:09:48 --> Output Class Initialized
INFO - 2023-05-31 03:09:48 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:48 --> Input Class Initialized
INFO - 2023-05-31 03:09:48 --> Language Class Initialized
INFO - 2023-05-31 03:09:48 --> Loader Class Initialized
INFO - 2023-05-31 03:09:48 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:48 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:48 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:48 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:48 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:55 --> Config Class Initialized
INFO - 2023-05-31 03:09:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:55 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:55 --> URI Class Initialized
INFO - 2023-05-31 03:09:55 --> Router Class Initialized
INFO - 2023-05-31 03:09:55 --> Output Class Initialized
INFO - 2023-05-31 03:09:55 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:55 --> Input Class Initialized
INFO - 2023-05-31 03:09:55 --> Language Class Initialized
INFO - 2023-05-31 03:09:55 --> Loader Class Initialized
INFO - 2023-05-31 03:09:55 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:55 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:55 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:55 --> Total execution time: 0.2842
INFO - 2023-05-31 03:09:55 --> Config Class Initialized
INFO - 2023-05-31 03:09:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:55 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:55 --> URI Class Initialized
INFO - 2023-05-31 03:09:55 --> Router Class Initialized
INFO - 2023-05-31 03:09:55 --> Output Class Initialized
INFO - 2023-05-31 03:09:55 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:55 --> Input Class Initialized
INFO - 2023-05-31 03:09:55 --> Language Class Initialized
INFO - 2023-05-31 03:09:55 --> Loader Class Initialized
INFO - 2023-05-31 03:09:55 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:55 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:56 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:56 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:56 --> Total execution time: 0.2232
INFO - 2023-05-31 03:09:56 --> Config Class Initialized
INFO - 2023-05-31 03:09:56 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:09:56 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:09:56 --> Utf8 Class Initialized
INFO - 2023-05-31 03:09:56 --> URI Class Initialized
INFO - 2023-05-31 03:09:56 --> Router Class Initialized
INFO - 2023-05-31 03:09:56 --> Output Class Initialized
INFO - 2023-05-31 03:09:56 --> Security Class Initialized
DEBUG - 2023-05-31 03:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:09:56 --> Input Class Initialized
INFO - 2023-05-31 03:09:56 --> Language Class Initialized
INFO - 2023-05-31 03:09:56 --> Loader Class Initialized
INFO - 2023-05-31 03:09:56 --> Controller Class Initialized
DEBUG - 2023-05-31 03:09:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:09:56 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:56 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:09:56 --> Database Driver Class Initialized
INFO - 2023-05-31 03:09:56 --> Model "Login_model" initialized
INFO - 2023-05-31 03:09:57 --> Final output sent to browser
DEBUG - 2023-05-31 03:09:57 --> Total execution time: 12.3850
INFO - 2023-05-31 03:10:03 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:03 --> Total execution time: 14.7705
INFO - 2023-05-31 03:10:03 --> Config Class Initialized
INFO - 2023-05-31 03:10:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:03 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:03 --> URI Class Initialized
INFO - 2023-05-31 03:10:03 --> Router Class Initialized
INFO - 2023-05-31 03:10:03 --> Output Class Initialized
INFO - 2023-05-31 03:10:03 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:03 --> Input Class Initialized
INFO - 2023-05-31 03:10:03 --> Language Class Initialized
INFO - 2023-05-31 03:10:03 --> Loader Class Initialized
INFO - 2023-05-31 03:10:03 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:03 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:03 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:03 --> Model "Login_model" initialized
INFO - 2023-05-31 03:10:05 --> Config Class Initialized
INFO - 2023-05-31 03:10:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:05 --> URI Class Initialized
INFO - 2023-05-31 03:10:05 --> Router Class Initialized
INFO - 2023-05-31 03:10:05 --> Output Class Initialized
INFO - 2023-05-31 03:10:05 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:05 --> Input Class Initialized
INFO - 2023-05-31 03:10:05 --> Language Class Initialized
INFO - 2023-05-31 03:10:05 --> Loader Class Initialized
INFO - 2023-05-31 03:10:05 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:05 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:05 --> Total execution time: 0.2005
INFO - 2023-05-31 03:10:05 --> Config Class Initialized
INFO - 2023-05-31 03:10:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:05 --> URI Class Initialized
INFO - 2023-05-31 03:10:05 --> Router Class Initialized
INFO - 2023-05-31 03:10:05 --> Output Class Initialized
INFO - 2023-05-31 03:10:05 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:05 --> Input Class Initialized
INFO - 2023-05-31 03:10:05 --> Language Class Initialized
INFO - 2023-05-31 03:10:05 --> Loader Class Initialized
INFO - 2023-05-31 03:10:05 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:05 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:05 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:05 --> Total execution time: 0.2030
INFO - 2023-05-31 03:10:06 --> Config Class Initialized
INFO - 2023-05-31 03:10:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:06 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:06 --> URI Class Initialized
INFO - 2023-05-31 03:10:06 --> Router Class Initialized
INFO - 2023-05-31 03:10:06 --> Output Class Initialized
INFO - 2023-05-31 03:10:06 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:06 --> Input Class Initialized
INFO - 2023-05-31 03:10:06 --> Language Class Initialized
INFO - 2023-05-31 03:10:06 --> Loader Class Initialized
INFO - 2023-05-31 03:10:06 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:06 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:06 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:06 --> Model "Login_model" initialized
INFO - 2023-05-31 03:10:08 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:08 --> Total execution time: 12.4866
INFO - 2023-05-31 03:10:13 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:13 --> Total execution time: 10.0201
INFO - 2023-05-31 03:10:13 --> Config Class Initialized
INFO - 2023-05-31 03:10:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:13 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:13 --> URI Class Initialized
INFO - 2023-05-31 03:10:13 --> Router Class Initialized
INFO - 2023-05-31 03:10:13 --> Output Class Initialized
INFO - 2023-05-31 03:10:13 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:13 --> Input Class Initialized
INFO - 2023-05-31 03:10:13 --> Language Class Initialized
INFO - 2023-05-31 03:10:13 --> Loader Class Initialized
INFO - 2023-05-31 03:10:13 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:13 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:13 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:13 --> Model "Login_model" initialized
INFO - 2023-05-31 03:10:15 --> Config Class Initialized
INFO - 2023-05-31 03:10:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:15 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:15 --> URI Class Initialized
INFO - 2023-05-31 03:10:15 --> Router Class Initialized
INFO - 2023-05-31 03:10:15 --> Output Class Initialized
INFO - 2023-05-31 03:10:15 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:15 --> Input Class Initialized
INFO - 2023-05-31 03:10:15 --> Language Class Initialized
INFO - 2023-05-31 03:10:15 --> Loader Class Initialized
INFO - 2023-05-31 03:10:15 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:15 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:15 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:15 --> Total execution time: 9.2377
INFO - 2023-05-31 03:10:15 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:15 --> Total execution time: 0.2681
INFO - 2023-05-31 03:10:15 --> Config Class Initialized
INFO - 2023-05-31 03:10:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:15 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:15 --> URI Class Initialized
INFO - 2023-05-31 03:10:15 --> Router Class Initialized
INFO - 2023-05-31 03:10:15 --> Output Class Initialized
INFO - 2023-05-31 03:10:15 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:15 --> Input Class Initialized
INFO - 2023-05-31 03:10:15 --> Language Class Initialized
INFO - 2023-05-31 03:10:15 --> Loader Class Initialized
INFO - 2023-05-31 03:10:15 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:16 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:16 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:16 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:16 --> Total execution time: 0.2172
INFO - 2023-05-31 03:10:19 --> Config Class Initialized
INFO - 2023-05-31 03:10:19 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:19 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:19 --> URI Class Initialized
INFO - 2023-05-31 03:10:19 --> Router Class Initialized
INFO - 2023-05-31 03:10:19 --> Output Class Initialized
INFO - 2023-05-31 03:10:19 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:19 --> Input Class Initialized
INFO - 2023-05-31 03:10:19 --> Language Class Initialized
INFO - 2023-05-31 03:10:20 --> Loader Class Initialized
INFO - 2023-05-31 03:10:20 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:20 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:20 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:20 --> Total execution time: 0.3347
INFO - 2023-05-31 03:10:20 --> Config Class Initialized
INFO - 2023-05-31 03:10:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:20 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:20 --> URI Class Initialized
INFO - 2023-05-31 03:10:20 --> Router Class Initialized
INFO - 2023-05-31 03:10:20 --> Output Class Initialized
INFO - 2023-05-31 03:10:20 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:20 --> Input Class Initialized
INFO - 2023-05-31 03:10:20 --> Language Class Initialized
INFO - 2023-05-31 03:10:20 --> Loader Class Initialized
INFO - 2023-05-31 03:10:20 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:20 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:20 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:20 --> Total execution time: 0.2038
INFO - 2023-05-31 03:10:23 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:23 --> Total execution time: 10.0906
INFO - 2023-05-31 03:10:23 --> Config Class Initialized
INFO - 2023-05-31 03:10:23 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:23 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:23 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:23 --> URI Class Initialized
INFO - 2023-05-31 03:10:23 --> Router Class Initialized
INFO - 2023-05-31 03:10:23 --> Output Class Initialized
INFO - 2023-05-31 03:10:23 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:23 --> Input Class Initialized
INFO - 2023-05-31 03:10:23 --> Language Class Initialized
INFO - 2023-05-31 03:10:23 --> Loader Class Initialized
INFO - 2023-05-31 03:10:23 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:23 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:23 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:23 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:23 --> Model "Login_model" initialized
INFO - 2023-05-31 03:10:24 --> Config Class Initialized
INFO - 2023-05-31 03:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:24 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:24 --> URI Class Initialized
INFO - 2023-05-31 03:10:24 --> Router Class Initialized
INFO - 2023-05-31 03:10:24 --> Output Class Initialized
INFO - 2023-05-31 03:10:24 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:24 --> Input Class Initialized
INFO - 2023-05-31 03:10:24 --> Language Class Initialized
INFO - 2023-05-31 03:10:24 --> Loader Class Initialized
INFO - 2023-05-31 03:10:24 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:24 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:24 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:24 --> Total execution time: 0.2078
INFO - 2023-05-31 03:10:24 --> Config Class Initialized
INFO - 2023-05-31 03:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:24 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:24 --> URI Class Initialized
INFO - 2023-05-31 03:10:24 --> Router Class Initialized
INFO - 2023-05-31 03:10:24 --> Output Class Initialized
INFO - 2023-05-31 03:10:24 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:24 --> Input Class Initialized
INFO - 2023-05-31 03:10:24 --> Language Class Initialized
INFO - 2023-05-31 03:10:24 --> Loader Class Initialized
INFO - 2023-05-31 03:10:24 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:24 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:24 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:24 --> Total execution time: 0.1952
INFO - 2023-05-31 03:10:27 --> Config Class Initialized
INFO - 2023-05-31 03:10:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:27 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:27 --> URI Class Initialized
INFO - 2023-05-31 03:10:27 --> Router Class Initialized
INFO - 2023-05-31 03:10:27 --> Output Class Initialized
INFO - 2023-05-31 03:10:27 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:27 --> Input Class Initialized
INFO - 2023-05-31 03:10:27 --> Language Class Initialized
INFO - 2023-05-31 03:10:27 --> Loader Class Initialized
INFO - 2023-05-31 03:10:27 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:27 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:27 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:27 --> Total execution time: 0.1979
INFO - 2023-05-31 03:10:27 --> Config Class Initialized
INFO - 2023-05-31 03:10:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:27 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:27 --> URI Class Initialized
INFO - 2023-05-31 03:10:27 --> Router Class Initialized
INFO - 2023-05-31 03:10:27 --> Output Class Initialized
INFO - 2023-05-31 03:10:27 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:27 --> Input Class Initialized
INFO - 2023-05-31 03:10:27 --> Language Class Initialized
INFO - 2023-05-31 03:10:27 --> Loader Class Initialized
INFO - 2023-05-31 03:10:27 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:27 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:27 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:27 --> Total execution time: 0.1854
INFO - 2023-05-31 03:10:36 --> Config Class Initialized
INFO - 2023-05-31 03:10:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:10:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:10:36 --> Utf8 Class Initialized
INFO - 2023-05-31 03:10:36 --> URI Class Initialized
INFO - 2023-05-31 03:10:36 --> Router Class Initialized
INFO - 2023-05-31 03:10:36 --> Output Class Initialized
INFO - 2023-05-31 03:10:36 --> Security Class Initialized
DEBUG - 2023-05-31 03:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:10:36 --> Input Class Initialized
INFO - 2023-05-31 03:10:36 --> Language Class Initialized
INFO - 2023-05-31 03:10:36 --> Loader Class Initialized
INFO - 2023-05-31 03:10:36 --> Controller Class Initialized
DEBUG - 2023-05-31 03:10:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:10:36 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:36 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:10:36 --> Database Driver Class Initialized
INFO - 2023-05-31 03:10:36 --> Model "Login_model" initialized
INFO - 2023-05-31 03:10:36 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:36 --> Total execution time: 13.5870
INFO - 2023-05-31 03:10:50 --> Final output sent to browser
DEBUG - 2023-05-31 03:10:50 --> Total execution time: 13.8098
INFO - 2023-05-31 03:31:26 --> Config Class Initialized
INFO - 2023-05-31 03:31:26 --> Config Class Initialized
INFO - 2023-05-31 03:31:26 --> Hooks Class Initialized
INFO - 2023-05-31 03:31:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:31:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:31:26 --> Config Class Initialized
DEBUG - 2023-05-31 03:31:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:31:26 --> Utf8 Class Initialized
INFO - 2023-05-31 03:31:26 --> Hooks Class Initialized
INFO - 2023-05-31 03:31:26 --> Utf8 Class Initialized
INFO - 2023-05-31 03:31:26 --> URI Class Initialized
INFO - 2023-05-31 03:31:26 --> URI Class Initialized
INFO - 2023-05-31 03:31:26 --> Router Class Initialized
INFO - 2023-05-31 03:31:26 --> Router Class Initialized
INFO - 2023-05-31 03:31:26 --> Output Class Initialized
INFO - 2023-05-31 03:31:26 --> Output Class Initialized
INFO - 2023-05-31 03:31:26 --> Security Class Initialized
DEBUG - 2023-05-31 03:31:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:31:26 --> Security Class Initialized
INFO - 2023-05-31 03:31:26 --> Utf8 Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:31:26 --> Input Class Initialized
INFO - 2023-05-31 03:31:26 --> Input Class Initialized
INFO - 2023-05-31 03:31:26 --> URI Class Initialized
INFO - 2023-05-31 03:31:26 --> Language Class Initialized
INFO - 2023-05-31 03:31:26 --> Language Class Initialized
INFO - 2023-05-31 03:31:26 --> Router Class Initialized
INFO - 2023-05-31 03:31:26 --> Loader Class Initialized
INFO - 2023-05-31 03:31:26 --> Output Class Initialized
INFO - 2023-05-31 03:31:26 --> Controller Class Initialized
INFO - 2023-05-31 03:31:26 --> Security Class Initialized
INFO - 2023-05-31 03:31:26 --> Loader Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:31:26 --> Input Class Initialized
INFO - 2023-05-31 03:31:26 --> Language Class Initialized
INFO - 2023-05-31 03:31:26 --> Controller Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:31:26 --> Loader Class Initialized
INFO - 2023-05-31 03:31:26 --> Database Driver Class Initialized
INFO - 2023-05-31 03:31:26 --> Controller Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:31:26 --> Database Driver Class Initialized
INFO - 2023-05-31 03:31:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:26 --> Final output sent to browser
DEBUG - 2023-05-31 03:31:26 --> Total execution time: 0.4065
INFO - 2023-05-31 03:31:26 --> Final output sent to browser
DEBUG - 2023-05-31 03:31:26 --> Total execution time: 0.4130
INFO - 2023-05-31 03:31:26 --> Database Driver Class Initialized
INFO - 2023-05-31 03:31:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:26 --> Config Class Initialized
INFO - 2023-05-31 03:31:26 --> Config Class Initialized
INFO - 2023-05-31 03:31:26 --> Hooks Class Initialized
INFO - 2023-05-31 03:31:26 --> Hooks Class Initialized
INFO - 2023-05-31 03:31:26 --> Final output sent to browser
DEBUG - 2023-05-31 03:31:26 --> Total execution time: 0.4182
DEBUG - 2023-05-31 03:31:26 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:31:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:31:26 --> Utf8 Class Initialized
INFO - 2023-05-31 03:31:26 --> Utf8 Class Initialized
INFO - 2023-05-31 03:31:26 --> URI Class Initialized
INFO - 2023-05-31 03:31:26 --> URI Class Initialized
INFO - 2023-05-31 03:31:26 --> Router Class Initialized
INFO - 2023-05-31 03:31:26 --> Router Class Initialized
INFO - 2023-05-31 03:31:26 --> Output Class Initialized
INFO - 2023-05-31 03:31:26 --> Output Class Initialized
INFO - 2023-05-31 03:31:26 --> Security Class Initialized
INFO - 2023-05-31 03:31:26 --> Security Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:31:26 --> Config Class Initialized
INFO - 2023-05-31 03:31:26 --> Input Class Initialized
INFO - 2023-05-31 03:31:26 --> Input Class Initialized
INFO - 2023-05-31 03:31:26 --> Hooks Class Initialized
INFO - 2023-05-31 03:31:26 --> Language Class Initialized
INFO - 2023-05-31 03:31:26 --> Language Class Initialized
DEBUG - 2023-05-31 03:31:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:31:26 --> Loader Class Initialized
INFO - 2023-05-31 03:31:26 --> Utf8 Class Initialized
INFO - 2023-05-31 03:31:26 --> Controller Class Initialized
INFO - 2023-05-31 03:31:26 --> URI Class Initialized
INFO - 2023-05-31 03:31:26 --> Loader Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:31:26 --> Router Class Initialized
INFO - 2023-05-31 03:31:26 --> Controller Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:31:26 --> Output Class Initialized
INFO - 2023-05-31 03:31:26 --> Security Class Initialized
INFO - 2023-05-31 03:31:26 --> Database Driver Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:31:26 --> Input Class Initialized
INFO - 2023-05-31 03:31:26 --> Language Class Initialized
INFO - 2023-05-31 03:31:26 --> Database Driver Class Initialized
INFO - 2023-05-31 03:31:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:26 --> Final output sent to browser
INFO - 2023-05-31 03:31:26 --> Loader Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Total execution time: 0.2259
INFO - 2023-05-31 03:31:26 --> Controller Class Initialized
INFO - 2023-05-31 03:31:26 --> Final output sent to browser
DEBUG - 2023-05-31 03:31:26 --> Total execution time: 0.2427
DEBUG - 2023-05-31 03:31:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:31:26 --> Database Driver Class Initialized
INFO - 2023-05-31 03:31:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:26 --> Final output sent to browser
DEBUG - 2023-05-31 03:31:26 --> Total execution time: 0.2490
INFO - 2023-05-31 03:31:26 --> Config Class Initialized
INFO - 2023-05-31 03:31:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:31:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:31:26 --> Utf8 Class Initialized
INFO - 2023-05-31 03:31:26 --> URI Class Initialized
INFO - 2023-05-31 03:31:26 --> Router Class Initialized
INFO - 2023-05-31 03:31:26 --> Output Class Initialized
INFO - 2023-05-31 03:31:26 --> Security Class Initialized
DEBUG - 2023-05-31 03:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:31:26 --> Input Class Initialized
INFO - 2023-05-31 03:31:26 --> Language Class Initialized
INFO - 2023-05-31 03:31:27 --> Loader Class Initialized
INFO - 2023-05-31 03:31:27 --> Controller Class Initialized
DEBUG - 2023-05-31 03:31:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:31:27 --> Database Driver Class Initialized
INFO - 2023-05-31 03:31:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:27 --> Config Class Initialized
INFO - 2023-05-31 03:31:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:31:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:31:27 --> Utf8 Class Initialized
INFO - 2023-05-31 03:31:27 --> URI Class Initialized
INFO - 2023-05-31 03:31:27 --> Router Class Initialized
INFO - 2023-05-31 03:31:27 --> Output Class Initialized
INFO - 2023-05-31 03:31:27 --> Security Class Initialized
DEBUG - 2023-05-31 03:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:31:27 --> Input Class Initialized
INFO - 2023-05-31 03:31:27 --> Language Class Initialized
INFO - 2023-05-31 03:31:27 --> Loader Class Initialized
INFO - 2023-05-31 03:31:27 --> Controller Class Initialized
DEBUG - 2023-05-31 03:31:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:31:27 --> Database Driver Class Initialized
INFO - 2023-05-31 03:31:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:29 --> Config Class Initialized
INFO - 2023-05-31 03:31:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:31:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:31:29 --> Utf8 Class Initialized
INFO - 2023-05-31 03:31:29 --> URI Class Initialized
INFO - 2023-05-31 03:31:29 --> Router Class Initialized
INFO - 2023-05-31 03:31:29 --> Output Class Initialized
INFO - 2023-05-31 03:31:29 --> Security Class Initialized
DEBUG - 2023-05-31 03:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:31:29 --> Input Class Initialized
INFO - 2023-05-31 03:31:29 --> Language Class Initialized
INFO - 2023-05-31 03:31:29 --> Loader Class Initialized
INFO - 2023-05-31 03:31:29 --> Controller Class Initialized
DEBUG - 2023-05-31 03:31:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:31:29 --> Database Driver Class Initialized
INFO - 2023-05-31 03:31:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:31:29 --> Final output sent to browser
DEBUG - 2023-05-31 03:31:29 --> Total execution time: 0.4357
INFO - 2023-05-31 03:47:09 --> Config Class Initialized
INFO - 2023-05-31 03:47:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:47:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:47:09 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:09 --> URI Class Initialized
INFO - 2023-05-31 03:47:09 --> Router Class Initialized
INFO - 2023-05-31 03:47:09 --> Output Class Initialized
INFO - 2023-05-31 03:47:09 --> Security Class Initialized
DEBUG - 2023-05-31 03:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:47:09 --> Input Class Initialized
INFO - 2023-05-31 03:47:09 --> Language Class Initialized
INFO - 2023-05-31 03:47:09 --> Loader Class Initialized
INFO - 2023-05-31 03:47:09 --> Controller Class Initialized
DEBUG - 2023-05-31 03:47:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:09 --> Database Driver Class Initialized
ERROR - 2023-05-31 03:47:09 --> Exception of type 'Error' occurred with Message: Cannot access private property Cluster::$Cluster_model in File /var/www/html/KunlunMonitor/system/core/Loader.php at Line 358
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(27): CI_Loader->model(Object(Cluster_model))
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(518): Cluster->__construct()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 03:47:09 --> Config Class Initialized
INFO - 2023-05-31 03:47:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:47:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:47:09 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:09 --> URI Class Initialized
INFO - 2023-05-31 03:47:09 --> Router Class Initialized
INFO - 2023-05-31 03:47:09 --> Output Class Initialized
INFO - 2023-05-31 03:47:09 --> Security Class Initialized
DEBUG - 2023-05-31 03:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:47:09 --> Input Class Initialized
INFO - 2023-05-31 03:47:09 --> Language Class Initialized
INFO - 2023-05-31 03:47:09 --> Loader Class Initialized
INFO - 2023-05-31 03:47:09 --> Controller Class Initialized
DEBUG - 2023-05-31 03:47:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:09 --> Database Driver Class Initialized
ERROR - 2023-05-31 03:47:09 --> Exception of type 'Error' occurred with Message: Cannot access private property Cluster::$Cluster_model in File /var/www/html/KunlunMonitor/system/core/Loader.php at Line 358
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(27): CI_Loader->model(Object(Cluster_model))
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(518): Cluster->__construct()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 03:47:20 --> Config Class Initialized
INFO - 2023-05-31 03:47:20 --> Config Class Initialized
INFO - 2023-05-31 03:47:20 --> Config Class Initialized
INFO - 2023-05-31 03:47:20 --> Hooks Class Initialized
INFO - 2023-05-31 03:47:20 --> Hooks Class Initialized
INFO - 2023-05-31 03:47:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:47:20 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:47:20 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:47:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:47:20 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:20 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:20 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:20 --> URI Class Initialized
INFO - 2023-05-31 03:47:20 --> URI Class Initialized
INFO - 2023-05-31 03:47:20 --> URI Class Initialized
INFO - 2023-05-31 03:47:20 --> Router Class Initialized
INFO - 2023-05-31 03:47:20 --> Router Class Initialized
INFO - 2023-05-31 03:47:20 --> Router Class Initialized
INFO - 2023-05-31 03:47:20 --> Output Class Initialized
INFO - 2023-05-31 03:47:20 --> Output Class Initialized
INFO - 2023-05-31 03:47:20 --> Output Class Initialized
INFO - 2023-05-31 03:47:20 --> Security Class Initialized
INFO - 2023-05-31 03:47:20 --> Security Class Initialized
INFO - 2023-05-31 03:47:20 --> Security Class Initialized
DEBUG - 2023-05-31 03:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:47:20 --> Input Class Initialized
INFO - 2023-05-31 03:47:20 --> Input Class Initialized
INFO - 2023-05-31 03:47:20 --> Input Class Initialized
INFO - 2023-05-31 03:47:20 --> Language Class Initialized
INFO - 2023-05-31 03:47:20 --> Language Class Initialized
INFO - 2023-05-31 03:47:20 --> Language Class Initialized
INFO - 2023-05-31 03:47:20 --> Loader Class Initialized
INFO - 2023-05-31 03:47:20 --> Loader Class Initialized
INFO - 2023-05-31 03:47:20 --> Controller Class Initialized
INFO - 2023-05-31 03:47:20 --> Controller Class Initialized
DEBUG - 2023-05-31 03:47:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:47:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:20 --> Loader Class Initialized
INFO - 2023-05-31 03:47:20 --> Controller Class Initialized
DEBUG - 2023-05-31 03:47:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:20 --> Database Driver Class Initialized
INFO - 2023-05-31 03:47:20 --> Database Driver Class Initialized
INFO - 2023-05-31 03:47:20 --> Database Driver Class Initialized
INFO - 2023-05-31 03:47:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:47:20 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 03:47:20 --> Exception of type 'Error' occurred with Message: Cannot access private property Cluster::$Cluster_model in File /var/www/html/KunlunMonitor/system/core/Loader.php at Line 358
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(27): CI_Loader->model(Object(Cluster_model))
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(518): Cluster->__construct()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 03:47:20 --> Final output sent to browser
INFO - 2023-05-31 03:47:20 --> Final output sent to browser
DEBUG - 2023-05-31 03:47:20 --> Total execution time: 0.2045
DEBUG - 2023-05-31 03:47:20 --> Total execution time: 0.2056
INFO - 2023-05-31 03:47:20 --> Config Class Initialized
INFO - 2023-05-31 03:47:20 --> Config Class Initialized
INFO - 2023-05-31 03:47:20 --> Config Class Initialized
INFO - 2023-05-31 03:47:20 --> Hooks Class Initialized
INFO - 2023-05-31 03:47:20 --> Hooks Class Initialized
INFO - 2023-05-31 03:47:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:47:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:47:21 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:21 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:21 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:21 --> URI Class Initialized
INFO - 2023-05-31 03:47:21 --> URI Class Initialized
INFO - 2023-05-31 03:47:21 --> URI Class Initialized
INFO - 2023-05-31 03:47:21 --> Router Class Initialized
INFO - 2023-05-31 03:47:21 --> Router Class Initialized
INFO - 2023-05-31 03:47:21 --> Router Class Initialized
INFO - 2023-05-31 03:47:21 --> Output Class Initialized
INFO - 2023-05-31 03:47:21 --> Output Class Initialized
INFO - 2023-05-31 03:47:21 --> Output Class Initialized
INFO - 2023-05-31 03:47:21 --> Security Class Initialized
INFO - 2023-05-31 03:47:21 --> Security Class Initialized
INFO - 2023-05-31 03:47:21 --> Security Class Initialized
DEBUG - 2023-05-31 03:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:47:21 --> Input Class Initialized
INFO - 2023-05-31 03:47:21 --> Input Class Initialized
INFO - 2023-05-31 03:47:21 --> Input Class Initialized
INFO - 2023-05-31 03:47:21 --> Language Class Initialized
INFO - 2023-05-31 03:47:21 --> Language Class Initialized
INFO - 2023-05-31 03:47:21 --> Language Class Initialized
INFO - 2023-05-31 03:47:21 --> Loader Class Initialized
INFO - 2023-05-31 03:47:21 --> Loader Class Initialized
INFO - 2023-05-31 03:47:21 --> Controller Class Initialized
INFO - 2023-05-31 03:47:21 --> Controller Class Initialized
DEBUG - 2023-05-31 03:47:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:47:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:21 --> Loader Class Initialized
INFO - 2023-05-31 03:47:21 --> Controller Class Initialized
INFO - 2023-05-31 03:47:21 --> Database Driver Class Initialized
INFO - 2023-05-31 03:47:21 --> Database Driver Class Initialized
DEBUG - 2023-05-31 03:47:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:47:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:47:21 --> Final output sent to browser
INFO - 2023-05-31 03:47:21 --> Final output sent to browser
DEBUG - 2023-05-31 03:47:21 --> Total execution time: 0.1601
DEBUG - 2023-05-31 03:47:21 --> Total execution time: 0.1590
INFO - 2023-05-31 03:47:21 --> Database Driver Class Initialized
ERROR - 2023-05-31 03:47:21 --> Exception of type 'Error' occurred with Message: Cannot access private property Cluster::$Cluster_model in File /var/www/html/KunlunMonitor/system/core/Loader.php at Line 358
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(27): CI_Loader->model(Object(Cluster_model))
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(518): Cluster->__construct()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 03:47:21 --> Config Class Initialized
INFO - 2023-05-31 03:47:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:47:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:47:21 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:21 --> URI Class Initialized
INFO - 2023-05-31 03:47:21 --> Router Class Initialized
INFO - 2023-05-31 03:47:21 --> Output Class Initialized
INFO - 2023-05-31 03:47:21 --> Security Class Initialized
DEBUG - 2023-05-31 03:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:47:21 --> Input Class Initialized
INFO - 2023-05-31 03:47:21 --> Language Class Initialized
INFO - 2023-05-31 03:47:21 --> Loader Class Initialized
INFO - 2023-05-31 03:47:21 --> Controller Class Initialized
DEBUG - 2023-05-31 03:47:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:21 --> Database Driver Class Initialized
INFO - 2023-05-31 03:47:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:47:21 --> Config Class Initialized
INFO - 2023-05-31 03:47:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:47:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:47:21 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:21 --> URI Class Initialized
INFO - 2023-05-31 03:47:21 --> Router Class Initialized
INFO - 2023-05-31 03:47:21 --> Output Class Initialized
INFO - 2023-05-31 03:47:21 --> Security Class Initialized
DEBUG - 2023-05-31 03:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:47:21 --> Input Class Initialized
INFO - 2023-05-31 03:47:21 --> Language Class Initialized
INFO - 2023-05-31 03:47:21 --> Loader Class Initialized
INFO - 2023-05-31 03:47:21 --> Controller Class Initialized
DEBUG - 2023-05-31 03:47:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:21 --> Database Driver Class Initialized
INFO - 2023-05-31 03:47:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:47:45 --> Config Class Initialized
INFO - 2023-05-31 03:47:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:47:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:47:45 --> Utf8 Class Initialized
INFO - 2023-05-31 03:47:45 --> URI Class Initialized
INFO - 2023-05-31 03:47:45 --> Router Class Initialized
INFO - 2023-05-31 03:47:45 --> Output Class Initialized
INFO - 2023-05-31 03:47:45 --> Security Class Initialized
DEBUG - 2023-05-31 03:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:47:45 --> Input Class Initialized
INFO - 2023-05-31 03:47:45 --> Language Class Initialized
INFO - 2023-05-31 03:47:45 --> Loader Class Initialized
INFO - 2023-05-31 03:47:45 --> Controller Class Initialized
DEBUG - 2023-05-31 03:47:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:47:45 --> Database Driver Class Initialized
ERROR - 2023-05-31 03:47:45 --> Exception of type 'Error' occurred with Message: Cannot access private property Cluster::$Cluster_model in File /var/www/html/KunlunMonitor/system/core/Loader.php at Line 358
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(27): CI_Loader->model(Object(Cluster_model))
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(518): Cluster->__construct()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 03:48:08 --> Config Class Initialized
INFO - 2023-05-31 03:48:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:48:08 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:48:08 --> Utf8 Class Initialized
INFO - 2023-05-31 03:48:09 --> URI Class Initialized
INFO - 2023-05-31 03:48:09 --> Router Class Initialized
INFO - 2023-05-31 03:48:09 --> Output Class Initialized
INFO - 2023-05-31 03:48:09 --> Security Class Initialized
DEBUG - 2023-05-31 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:48:09 --> Input Class Initialized
INFO - 2023-05-31 03:48:09 --> Language Class Initialized
INFO - 2023-05-31 03:48:09 --> Loader Class Initialized
INFO - 2023-05-31 03:48:09 --> Controller Class Initialized
DEBUG - 2023-05-31 03:48:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:48:09 --> Database Driver Class Initialized
INFO - 2023-05-31 03:48:09 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 03:48:09 --> Exception of type 'RuntimeException' occurred with Message: Unable to locate the model you have specified: 'Cluster_model' in File /var/www/html/KunlunMonitor/system/core/Loader.php at Line 348
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(28): CI_Loader->model(''Cluster_model'')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(518): Cluster->__construct()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 03:48:13 --> Config Class Initialized
INFO - 2023-05-31 03:48:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:48:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:48:13 --> Utf8 Class Initialized
INFO - 2023-05-31 03:48:13 --> URI Class Initialized
INFO - 2023-05-31 03:48:13 --> Router Class Initialized
INFO - 2023-05-31 03:48:13 --> Output Class Initialized
INFO - 2023-05-31 03:48:13 --> Security Class Initialized
DEBUG - 2023-05-31 03:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:48:13 --> Input Class Initialized
INFO - 2023-05-31 03:48:13 --> Language Class Initialized
INFO - 2023-05-31 03:48:13 --> Loader Class Initialized
INFO - 2023-05-31 03:48:13 --> Controller Class Initialized
DEBUG - 2023-05-31 03:48:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:48:13 --> Database Driver Class Initialized
INFO - 2023-05-31 03:48:13 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 03:48:13 --> Exception of type 'RuntimeException' occurred with Message: Unable to locate the model you have specified: 'Cluster_model' in File /var/www/html/KunlunMonitor/system/core/Loader.php at Line 348
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(28): CI_Loader->model(''Cluster_model'')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(518): Cluster->__construct()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 03:49:13 --> Config Class Initialized
INFO - 2023-05-31 03:49:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:49:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:49:13 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:13 --> URI Class Initialized
INFO - 2023-05-31 03:49:13 --> Router Class Initialized
INFO - 2023-05-31 03:49:13 --> Output Class Initialized
INFO - 2023-05-31 03:49:13 --> Security Class Initialized
DEBUG - 2023-05-31 03:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:49:13 --> Input Class Initialized
INFO - 2023-05-31 03:49:13 --> Language Class Initialized
INFO - 2023-05-31 03:49:13 --> Loader Class Initialized
INFO - 2023-05-31 03:49:13 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:13 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:13 --> Final output sent to browser
DEBUG - 2023-05-31 03:49:13 --> Total execution time: 0.3362
INFO - 2023-05-31 03:49:21 --> Config Class Initialized
INFO - 2023-05-31 03:49:21 --> Config Class Initialized
INFO - 2023-05-31 03:49:21 --> Config Class Initialized
INFO - 2023-05-31 03:49:21 --> Hooks Class Initialized
INFO - 2023-05-31 03:49:21 --> Hooks Class Initialized
INFO - 2023-05-31 03:49:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:49:22 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:49:22 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:22 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:22 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:22 --> URI Class Initialized
INFO - 2023-05-31 03:49:22 --> URI Class Initialized
INFO - 2023-05-31 03:49:22 --> URI Class Initialized
INFO - 2023-05-31 03:49:22 --> Router Class Initialized
INFO - 2023-05-31 03:49:22 --> Router Class Initialized
INFO - 2023-05-31 03:49:22 --> Router Class Initialized
INFO - 2023-05-31 03:49:22 --> Output Class Initialized
INFO - 2023-05-31 03:49:22 --> Output Class Initialized
INFO - 2023-05-31 03:49:22 --> Output Class Initialized
INFO - 2023-05-31 03:49:22 --> Security Class Initialized
INFO - 2023-05-31 03:49:22 --> Security Class Initialized
INFO - 2023-05-31 03:49:22 --> Security Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:49:22 --> Input Class Initialized
INFO - 2023-05-31 03:49:22 --> Input Class Initialized
INFO - 2023-05-31 03:49:22 --> Input Class Initialized
INFO - 2023-05-31 03:49:22 --> Language Class Initialized
INFO - 2023-05-31 03:49:22 --> Language Class Initialized
INFO - 2023-05-31 03:49:22 --> Language Class Initialized
INFO - 2023-05-31 03:49:22 --> Loader Class Initialized
INFO - 2023-05-31 03:49:22 --> Loader Class Initialized
INFO - 2023-05-31 03:49:22 --> Controller Class Initialized
INFO - 2023-05-31 03:49:22 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:22 --> Loader Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:22 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:22 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:22 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:22 --> Final output sent to browser
INFO - 2023-05-31 03:49:22 --> Final output sent to browser
DEBUG - 2023-05-31 03:49:22 --> Total execution time: 0.2901
DEBUG - 2023-05-31 03:49:22 --> Total execution time: 0.2905
INFO - 2023-05-31 03:49:22 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:22 --> Final output sent to browser
INFO - 2023-05-31 03:49:22 --> Config Class Initialized
INFO - 2023-05-31 03:49:22 --> Config Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Total execution time: 0.3361
INFO - 2023-05-31 03:49:22 --> Hooks Class Initialized
INFO - 2023-05-31 03:49:22 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 03:49:22 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:49:22 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:22 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:22 --> URI Class Initialized
INFO - 2023-05-31 03:49:22 --> URI Class Initialized
INFO - 2023-05-31 03:49:22 --> Router Class Initialized
INFO - 2023-05-31 03:49:22 --> Router Class Initialized
INFO - 2023-05-31 03:49:22 --> Config Class Initialized
INFO - 2023-05-31 03:49:22 --> Output Class Initialized
INFO - 2023-05-31 03:49:22 --> Output Class Initialized
INFO - 2023-05-31 03:49:22 --> Hooks Class Initialized
INFO - 2023-05-31 03:49:22 --> Security Class Initialized
INFO - 2023-05-31 03:49:22 --> Security Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 03:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:49:22 --> Input Class Initialized
INFO - 2023-05-31 03:49:22 --> Input Class Initialized
INFO - 2023-05-31 03:49:22 --> Language Class Initialized
INFO - 2023-05-31 03:49:22 --> Language Class Initialized
DEBUG - 2023-05-31 03:49:22 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:49:22 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:22 --> URI Class Initialized
INFO - 2023-05-31 03:49:22 --> Loader Class Initialized
INFO - 2023-05-31 03:49:22 --> Loader Class Initialized
INFO - 2023-05-31 03:49:22 --> Controller Class Initialized
INFO - 2023-05-31 03:49:22 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 03:49:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:22 --> Router Class Initialized
INFO - 2023-05-31 03:49:22 --> Output Class Initialized
INFO - 2023-05-31 03:49:22 --> Security Class Initialized
INFO - 2023-05-31 03:49:22 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:22 --> Database Driver Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:49:22 --> Input Class Initialized
INFO - 2023-05-31 03:49:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:22 --> Language Class Initialized
INFO - 2023-05-31 03:49:22 --> Final output sent to browser
INFO - 2023-05-31 03:49:22 --> Final output sent to browser
DEBUG - 2023-05-31 03:49:22 --> Total execution time: 0.2221
DEBUG - 2023-05-31 03:49:22 --> Total execution time: 0.2228
INFO - 2023-05-31 03:49:22 --> Loader Class Initialized
INFO - 2023-05-31 03:49:22 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:22 --> Config Class Initialized
INFO - 2023-05-31 03:49:22 --> Hooks Class Initialized
INFO - 2023-05-31 03:49:22 --> Database Driver Class Initialized
DEBUG - 2023-05-31 03:49:22 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:49:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:22 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:22 --> URI Class Initialized
INFO - 2023-05-31 03:49:22 --> Final output sent to browser
INFO - 2023-05-31 03:49:22 --> Router Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Total execution time: 0.3051
INFO - 2023-05-31 03:49:22 --> Output Class Initialized
INFO - 2023-05-31 03:49:22 --> Security Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:49:22 --> Input Class Initialized
INFO - 2023-05-31 03:49:22 --> Language Class Initialized
INFO - 2023-05-31 03:49:22 --> Loader Class Initialized
INFO - 2023-05-31 03:49:22 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:22 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:22 --> Config Class Initialized
INFO - 2023-05-31 03:49:22 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:49:22 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:49:22 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:22 --> URI Class Initialized
INFO - 2023-05-31 03:49:22 --> Router Class Initialized
INFO - 2023-05-31 03:49:22 --> Output Class Initialized
INFO - 2023-05-31 03:49:22 --> Security Class Initialized
DEBUG - 2023-05-31 03:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:49:22 --> Input Class Initialized
INFO - 2023-05-31 03:49:22 --> Language Class Initialized
INFO - 2023-05-31 03:49:23 --> Loader Class Initialized
INFO - 2023-05-31 03:49:23 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:23 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:23 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:55 --> Config Class Initialized
INFO - 2023-05-31 03:49:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:49:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:49:55 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:55 --> URI Class Initialized
INFO - 2023-05-31 03:49:55 --> Router Class Initialized
INFO - 2023-05-31 03:49:55 --> Output Class Initialized
INFO - 2023-05-31 03:49:55 --> Security Class Initialized
DEBUG - 2023-05-31 03:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:49:55 --> Input Class Initialized
INFO - 2023-05-31 03:49:55 --> Language Class Initialized
INFO - 2023-05-31 03:49:55 --> Loader Class Initialized
INFO - 2023-05-31 03:49:55 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:55 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:55 --> Final output sent to browser
DEBUG - 2023-05-31 03:49:55 --> Total execution time: 0.4003
INFO - 2023-05-31 03:49:55 --> Config Class Initialized
INFO - 2023-05-31 03:49:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:49:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:49:55 --> Utf8 Class Initialized
INFO - 2023-05-31 03:49:56 --> URI Class Initialized
INFO - 2023-05-31 03:49:56 --> Router Class Initialized
INFO - 2023-05-31 03:49:56 --> Output Class Initialized
INFO - 2023-05-31 03:49:56 --> Security Class Initialized
DEBUG - 2023-05-31 03:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:49:56 --> Input Class Initialized
INFO - 2023-05-31 03:49:56 --> Language Class Initialized
INFO - 2023-05-31 03:49:56 --> Loader Class Initialized
INFO - 2023-05-31 03:49:56 --> Controller Class Initialized
DEBUG - 2023-05-31 03:49:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:49:56 --> Database Driver Class Initialized
INFO - 2023-05-31 03:49:56 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:49:56 --> Final output sent to browser
DEBUG - 2023-05-31 03:49:56 --> Total execution time: 0.4350
INFO - 2023-05-31 03:56:05 --> Config Class Initialized
INFO - 2023-05-31 03:56:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:56:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:56:05 --> Utf8 Class Initialized
INFO - 2023-05-31 03:56:06 --> URI Class Initialized
INFO - 2023-05-31 03:56:06 --> Router Class Initialized
INFO - 2023-05-31 03:56:06 --> Output Class Initialized
INFO - 2023-05-31 03:56:06 --> Security Class Initialized
DEBUG - 2023-05-31 03:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:56:06 --> Input Class Initialized
INFO - 2023-05-31 03:56:06 --> Language Class Initialized
INFO - 2023-05-31 03:56:06 --> Loader Class Initialized
INFO - 2023-05-31 03:56:06 --> Controller Class Initialized
DEBUG - 2023-05-31 03:56:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:56:06 --> Database Driver Class Initialized
INFO - 2023-05-31 03:56:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:56:06 --> Final output sent to browser
DEBUG - 2023-05-31 03:56:06 --> Total execution time: 0.2424
INFO - 2023-05-31 03:56:06 --> Config Class Initialized
INFO - 2023-05-31 03:56:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 03:56:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 03:56:06 --> Utf8 Class Initialized
INFO - 2023-05-31 03:56:06 --> URI Class Initialized
INFO - 2023-05-31 03:56:06 --> Router Class Initialized
INFO - 2023-05-31 03:56:06 --> Output Class Initialized
INFO - 2023-05-31 03:56:06 --> Security Class Initialized
DEBUG - 2023-05-31 03:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 03:56:06 --> Input Class Initialized
INFO - 2023-05-31 03:56:06 --> Language Class Initialized
INFO - 2023-05-31 03:56:06 --> Loader Class Initialized
INFO - 2023-05-31 03:56:06 --> Controller Class Initialized
DEBUG - 2023-05-31 03:56:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 03:56:06 --> Database Driver Class Initialized
INFO - 2023-05-31 03:56:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 03:56:06 --> Final output sent to browser
DEBUG - 2023-05-31 03:56:06 --> Total execution time: 0.2256
INFO - 2023-05-31 04:02:21 --> Config Class Initialized
INFO - 2023-05-31 04:02:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 04:02:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 04:02:21 --> Utf8 Class Initialized
INFO - 2023-05-31 04:02:21 --> URI Class Initialized
INFO - 2023-05-31 04:02:21 --> Router Class Initialized
INFO - 2023-05-31 04:02:21 --> Output Class Initialized
INFO - 2023-05-31 04:02:21 --> Security Class Initialized
DEBUG - 2023-05-31 04:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 04:02:21 --> Input Class Initialized
INFO - 2023-05-31 04:02:21 --> Language Class Initialized
INFO - 2023-05-31 04:02:21 --> Loader Class Initialized
INFO - 2023-05-31 04:02:21 --> Controller Class Initialized
DEBUG - 2023-05-31 04:02:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 04:02:21 --> Database Driver Class Initialized
INFO - 2023-05-31 04:02:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 04:02:21 --> Final output sent to browser
DEBUG - 2023-05-31 04:02:21 --> Total execution time: 0.3060
INFO - 2023-05-31 04:02:21 --> Config Class Initialized
INFO - 2023-05-31 04:02:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 04:02:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 04:02:21 --> Utf8 Class Initialized
INFO - 2023-05-31 04:02:21 --> URI Class Initialized
INFO - 2023-05-31 04:02:21 --> Router Class Initialized
INFO - 2023-05-31 04:02:21 --> Output Class Initialized
INFO - 2023-05-31 04:02:21 --> Security Class Initialized
DEBUG - 2023-05-31 04:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 04:02:21 --> Input Class Initialized
INFO - 2023-05-31 04:02:21 --> Language Class Initialized
INFO - 2023-05-31 04:02:21 --> Loader Class Initialized
INFO - 2023-05-31 04:02:21 --> Controller Class Initialized
DEBUG - 2023-05-31 04:02:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 04:02:21 --> Database Driver Class Initialized
INFO - 2023-05-31 04:02:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 04:02:21 --> Final output sent to browser
DEBUG - 2023-05-31 04:02:21 --> Total execution time: 0.3287
INFO - 2023-05-31 06:45:05 --> Config Class Initialized
INFO - 2023-05-31 06:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:05 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:05 --> URI Class Initialized
INFO - 2023-05-31 06:45:05 --> Router Class Initialized
INFO - 2023-05-31 06:45:05 --> Output Class Initialized
INFO - 2023-05-31 06:45:05 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:05 --> Input Class Initialized
INFO - 2023-05-31 06:45:05 --> Language Class Initialized
INFO - 2023-05-31 06:45:05 --> Loader Class Initialized
INFO - 2023-05-31 06:45:05 --> Controller Class Initialized
INFO - 2023-05-31 06:45:05 --> Helper loaded: form_helper
INFO - 2023-05-31 06:45:05 --> Helper loaded: url_helper
DEBUG - 2023-05-31 06:45:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:05 --> Model "Change_model" initialized
INFO - 2023-05-31 06:45:05 --> Model "Grafana_model" initialized
INFO - 2023-05-31 06:45:05 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:05 --> Total execution time: 0.3270
INFO - 2023-05-31 06:45:05 --> Config Class Initialized
INFO - 2023-05-31 06:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:05 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:05 --> URI Class Initialized
INFO - 2023-05-31 06:45:05 --> Router Class Initialized
INFO - 2023-05-31 06:45:05 --> Output Class Initialized
INFO - 2023-05-31 06:45:05 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:05 --> Input Class Initialized
INFO - 2023-05-31 06:45:05 --> Language Class Initialized
INFO - 2023-05-31 06:45:05 --> Loader Class Initialized
INFO - 2023-05-31 06:45:05 --> Controller Class Initialized
INFO - 2023-05-31 06:45:05 --> Helper loaded: form_helper
INFO - 2023-05-31 06:45:05 --> Helper loaded: url_helper
DEBUG - 2023-05-31 06:45:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:05 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:05 --> Total execution time: 0.1806
INFO - 2023-05-31 06:45:05 --> Config Class Initialized
INFO - 2023-05-31 06:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:05 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:05 --> URI Class Initialized
INFO - 2023-05-31 06:45:05 --> Router Class Initialized
INFO - 2023-05-31 06:45:05 --> Output Class Initialized
INFO - 2023-05-31 06:45:05 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:05 --> Input Class Initialized
INFO - 2023-05-31 06:45:05 --> Language Class Initialized
INFO - 2023-05-31 06:45:05 --> Loader Class Initialized
INFO - 2023-05-31 06:45:06 --> Controller Class Initialized
INFO - 2023-05-31 06:45:06 --> Helper loaded: form_helper
INFO - 2023-05-31 06:45:06 --> Helper loaded: url_helper
DEBUG - 2023-05-31 06:45:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:06 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:06 --> Model "Login_model" initialized
INFO - 2023-05-31 06:45:06 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:06 --> Total execution time: 0.2913
INFO - 2023-05-31 06:45:06 --> Config Class Initialized
INFO - 2023-05-31 06:45:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:06 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:06 --> URI Class Initialized
INFO - 2023-05-31 06:45:06 --> Router Class Initialized
INFO - 2023-05-31 06:45:06 --> Output Class Initialized
INFO - 2023-05-31 06:45:06 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:06 --> Input Class Initialized
INFO - 2023-05-31 06:45:06 --> Language Class Initialized
INFO - 2023-05-31 06:45:06 --> Loader Class Initialized
INFO - 2023-05-31 06:45:06 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:06 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:06 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:06 --> Total execution time: 0.2171
INFO - 2023-05-31 06:45:06 --> Config Class Initialized
INFO - 2023-05-31 06:45:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:06 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:06 --> URI Class Initialized
INFO - 2023-05-31 06:45:06 --> Router Class Initialized
INFO - 2023-05-31 06:45:06 --> Output Class Initialized
INFO - 2023-05-31 06:45:06 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:06 --> Input Class Initialized
INFO - 2023-05-31 06:45:06 --> Language Class Initialized
INFO - 2023-05-31 06:45:06 --> Loader Class Initialized
INFO - 2023-05-31 06:45:06 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:06 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:06 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:06 --> Total execution time: 0.1897
INFO - 2023-05-31 06:45:06 --> Config Class Initialized
INFO - 2023-05-31 06:45:06 --> Config Class Initialized
INFO - 2023-05-31 06:45:06 --> Hooks Class Initialized
INFO - 2023-05-31 06:45:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:45:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:06 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:06 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:06 --> URI Class Initialized
INFO - 2023-05-31 06:45:06 --> URI Class Initialized
INFO - 2023-05-31 06:45:06 --> Router Class Initialized
INFO - 2023-05-31 06:45:06 --> Router Class Initialized
INFO - 2023-05-31 06:45:06 --> Output Class Initialized
INFO - 2023-05-31 06:45:06 --> Output Class Initialized
INFO - 2023-05-31 06:45:06 --> Security Class Initialized
INFO - 2023-05-31 06:45:06 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:06 --> Input Class Initialized
INFO - 2023-05-31 06:45:06 --> Input Class Initialized
INFO - 2023-05-31 06:45:06 --> Language Class Initialized
INFO - 2023-05-31 06:45:06 --> Language Class Initialized
INFO - 2023-05-31 06:45:06 --> Loader Class Initialized
INFO - 2023-05-31 06:45:06 --> Controller Class Initialized
INFO - 2023-05-31 06:45:06 --> Loader Class Initialized
DEBUG - 2023-05-31 06:45:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:06 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:06 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:06 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:06 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:06 --> Total execution time: 0.1765
INFO - 2023-05-31 06:45:07 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:07 --> Model "Login_model" initialized
INFO - 2023-05-31 06:45:07 --> Config Class Initialized
INFO - 2023-05-31 06:45:07 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:07 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:07 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:07 --> URI Class Initialized
INFO - 2023-05-31 06:45:07 --> Router Class Initialized
INFO - 2023-05-31 06:45:07 --> Output Class Initialized
INFO - 2023-05-31 06:45:07 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:07 --> Input Class Initialized
INFO - 2023-05-31 06:45:07 --> Language Class Initialized
INFO - 2023-05-31 06:45:07 --> Loader Class Initialized
INFO - 2023-05-31 06:45:07 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:07 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:07 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:07 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:07 --> Total execution time: 0.1876
INFO - 2023-05-31 06:45:07 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:07 --> Total execution time: 0.6449
INFO - 2023-05-31 06:45:07 --> Config Class Initialized
INFO - 2023-05-31 06:45:07 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:07 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:07 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:07 --> URI Class Initialized
INFO - 2023-05-31 06:45:07 --> Router Class Initialized
INFO - 2023-05-31 06:45:07 --> Output Class Initialized
INFO - 2023-05-31 06:45:07 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:07 --> Input Class Initialized
INFO - 2023-05-31 06:45:07 --> Language Class Initialized
INFO - 2023-05-31 06:45:07 --> Loader Class Initialized
INFO - 2023-05-31 06:45:07 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:07 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:07 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:07 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:07 --> Model "Login_model" initialized
INFO - 2023-05-31 06:45:08 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:08 --> Total execution time: 1.2045
INFO - 2023-05-31 06:45:18 --> Config Class Initialized
INFO - 2023-05-31 06:45:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:18 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:18 --> URI Class Initialized
INFO - 2023-05-31 06:45:18 --> Router Class Initialized
INFO - 2023-05-31 06:45:18 --> Output Class Initialized
INFO - 2023-05-31 06:45:18 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:18 --> Input Class Initialized
INFO - 2023-05-31 06:45:18 --> Language Class Initialized
INFO - 2023-05-31 06:45:18 --> Loader Class Initialized
INFO - 2023-05-31 06:45:18 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:18 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:18 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:18 --> Total execution time: 0.1800
INFO - 2023-05-31 06:45:18 --> Config Class Initialized
INFO - 2023-05-31 06:45:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:18 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:18 --> URI Class Initialized
INFO - 2023-05-31 06:45:18 --> Router Class Initialized
INFO - 2023-05-31 06:45:18 --> Output Class Initialized
INFO - 2023-05-31 06:45:18 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:18 --> Input Class Initialized
INFO - 2023-05-31 06:45:18 --> Language Class Initialized
INFO - 2023-05-31 06:45:18 --> Loader Class Initialized
INFO - 2023-05-31 06:45:18 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:18 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:18 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:18 --> Model "Login_model" initialized
INFO - 2023-05-31 06:45:18 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:18 --> Total execution time: 0.2526
INFO - 2023-05-31 06:45:18 --> Config Class Initialized
INFO - 2023-05-31 06:45:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:18 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:18 --> URI Class Initialized
INFO - 2023-05-31 06:45:18 --> Router Class Initialized
INFO - 2023-05-31 06:45:18 --> Output Class Initialized
INFO - 2023-05-31 06:45:18 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:18 --> Input Class Initialized
INFO - 2023-05-31 06:45:18 --> Language Class Initialized
INFO - 2023-05-31 06:45:18 --> Loader Class Initialized
INFO - 2023-05-31 06:45:18 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:18 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:18 --> Config Class Initialized
INFO - 2023-05-31 06:45:18 --> Hooks Class Initialized
INFO - 2023-05-31 06:45:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:18 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:18 --> Total execution time: 0.1769
DEBUG - 2023-05-31 06:45:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:18 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:18 --> URI Class Initialized
INFO - 2023-05-31 06:45:18 --> Router Class Initialized
INFO - 2023-05-31 06:45:18 --> Config Class Initialized
INFO - 2023-05-31 06:45:18 --> Hooks Class Initialized
INFO - 2023-05-31 06:45:18 --> Output Class Initialized
INFO - 2023-05-31 06:45:18 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:18 --> Input Class Initialized
INFO - 2023-05-31 06:45:18 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:18 --> Language Class Initialized
INFO - 2023-05-31 06:45:18 --> URI Class Initialized
INFO - 2023-05-31 06:45:18 --> Router Class Initialized
INFO - 2023-05-31 06:45:18 --> Output Class Initialized
INFO - 2023-05-31 06:45:18 --> Loader Class Initialized
INFO - 2023-05-31 06:45:18 --> Security Class Initialized
INFO - 2023-05-31 06:45:18 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:18 --> Input Class Initialized
INFO - 2023-05-31 06:45:18 --> Language Class Initialized
INFO - 2023-05-31 06:45:18 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:18 --> Loader Class Initialized
INFO - 2023-05-31 06:45:18 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:18 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:18 --> Total execution time: 0.2247
INFO - 2023-05-31 06:45:18 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:18 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:18 --> Config Class Initialized
INFO - 2023-05-31 06:45:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:18 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:19 --> URI Class Initialized
INFO - 2023-05-31 06:45:19 --> Router Class Initialized
INFO - 2023-05-31 06:45:19 --> Output Class Initialized
INFO - 2023-05-31 06:45:19 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:19 --> Model "Login_model" initialized
INFO - 2023-05-31 06:45:19 --> Input Class Initialized
INFO - 2023-05-31 06:45:19 --> Language Class Initialized
INFO - 2023-05-31 06:45:19 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:19 --> Total execution time: 0.3114
INFO - 2023-05-31 06:45:19 --> Loader Class Initialized
INFO - 2023-05-31 06:45:19 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:19 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:19 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:19 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:19 --> Total execution time: 0.2084
INFO - 2023-05-31 06:45:27 --> Config Class Initialized
INFO - 2023-05-31 06:45:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:27 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:27 --> URI Class Initialized
INFO - 2023-05-31 06:45:27 --> Router Class Initialized
INFO - 2023-05-31 06:45:27 --> Output Class Initialized
INFO - 2023-05-31 06:45:27 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:27 --> Input Class Initialized
INFO - 2023-05-31 06:45:27 --> Language Class Initialized
INFO - 2023-05-31 06:45:27 --> Loader Class Initialized
INFO - 2023-05-31 06:45:27 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:27 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:27 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:27 --> Total execution time: 0.1862
INFO - 2023-05-31 06:45:27 --> Config Class Initialized
INFO - 2023-05-31 06:45:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:27 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:27 --> URI Class Initialized
INFO - 2023-05-31 06:45:27 --> Router Class Initialized
INFO - 2023-05-31 06:45:27 --> Output Class Initialized
INFO - 2023-05-31 06:45:27 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:27 --> Input Class Initialized
INFO - 2023-05-31 06:45:27 --> Language Class Initialized
INFO - 2023-05-31 06:45:27 --> Loader Class Initialized
INFO - 2023-05-31 06:45:27 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:27 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:27 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:27 --> Model "Login_model" initialized
INFO - 2023-05-31 06:45:27 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:27 --> Total execution time: 0.2222
INFO - 2023-05-31 06:45:27 --> Config Class Initialized
INFO - 2023-05-31 06:45:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:27 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:27 --> URI Class Initialized
INFO - 2023-05-31 06:45:27 --> Router Class Initialized
INFO - 2023-05-31 06:45:27 --> Output Class Initialized
INFO - 2023-05-31 06:45:27 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:28 --> Input Class Initialized
INFO - 2023-05-31 06:45:28 --> Language Class Initialized
INFO - 2023-05-31 06:45:28 --> Loader Class Initialized
INFO - 2023-05-31 06:45:28 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:28 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:28 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:28 --> Total execution time: 0.1850
INFO - 2023-05-31 06:45:28 --> Config Class Initialized
INFO - 2023-05-31 06:45:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:28 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:28 --> URI Class Initialized
INFO - 2023-05-31 06:45:28 --> Router Class Initialized
INFO - 2023-05-31 06:45:28 --> Output Class Initialized
INFO - 2023-05-31 06:45:28 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:28 --> Input Class Initialized
INFO - 2023-05-31 06:45:28 --> Language Class Initialized
INFO - 2023-05-31 06:45:28 --> Loader Class Initialized
INFO - 2023-05-31 06:45:28 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:28 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:28 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:28 --> Config Class Initialized
INFO - 2023-05-31 06:45:28 --> Config Class Initialized
INFO - 2023-05-31 06:45:28 --> Hooks Class Initialized
INFO - 2023-05-31 06:45:28 --> Hooks Class Initialized
INFO - 2023-05-31 06:45:28 --> Model "Login_model" initialized
DEBUG - 2023-05-31 06:45:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:45:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:28 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:28 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:28 --> URI Class Initialized
INFO - 2023-05-31 06:45:28 --> Final output sent to browser
INFO - 2023-05-31 06:45:28 --> URI Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Total execution time: 0.4385
INFO - 2023-05-31 06:45:28 --> Router Class Initialized
INFO - 2023-05-31 06:45:28 --> Router Class Initialized
INFO - 2023-05-31 06:45:28 --> Output Class Initialized
INFO - 2023-05-31 06:45:28 --> Output Class Initialized
INFO - 2023-05-31 06:45:28 --> Security Class Initialized
INFO - 2023-05-31 06:45:28 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:28 --> Input Class Initialized
INFO - 2023-05-31 06:45:28 --> Input Class Initialized
INFO - 2023-05-31 06:45:28 --> Language Class Initialized
INFO - 2023-05-31 06:45:28 --> Language Class Initialized
INFO - 2023-05-31 06:45:28 --> Loader Class Initialized
INFO - 2023-05-31 06:45:28 --> Loader Class Initialized
INFO - 2023-05-31 06:45:28 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:28 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:28 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:28 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:28 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:28 --> Total execution time: 0.1763
INFO - 2023-05-31 06:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:28 --> Config Class Initialized
INFO - 2023-05-31 06:45:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:28 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:28 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:28 --> URI Class Initialized
INFO - 2023-05-31 06:45:28 --> Router Class Initialized
INFO - 2023-05-31 06:45:28 --> Model "Login_model" initialized
INFO - 2023-05-31 06:45:28 --> Output Class Initialized
INFO - 2023-05-31 06:45:28 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:28 --> Input Class Initialized
INFO - 2023-05-31 06:45:28 --> Language Class Initialized
INFO - 2023-05-31 06:45:28 --> Loader Class Initialized
INFO - 2023-05-31 06:45:28 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:28 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:28 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:28 --> Total execution time: 0.1947
INFO - 2023-05-31 06:45:28 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:28 --> Total execution time: 0.4377
INFO - 2023-05-31 06:45:29 --> Config Class Initialized
INFO - 2023-05-31 06:45:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:29 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:29 --> URI Class Initialized
INFO - 2023-05-31 06:45:29 --> Router Class Initialized
INFO - 2023-05-31 06:45:29 --> Output Class Initialized
INFO - 2023-05-31 06:45:29 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:29 --> Input Class Initialized
INFO - 2023-05-31 06:45:29 --> Language Class Initialized
INFO - 2023-05-31 06:45:29 --> Loader Class Initialized
INFO - 2023-05-31 06:45:29 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:29 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:29 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:29 --> Model "Login_model" initialized
INFO - 2023-05-31 06:45:29 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:29 --> Total execution time: 0.3632
INFO - 2023-05-31 06:45:51 --> Config Class Initialized
INFO - 2023-05-31 06:45:51 --> Config Class Initialized
INFO - 2023-05-31 06:45:51 --> Hooks Class Initialized
INFO - 2023-05-31 06:45:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:45:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:51 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:51 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:51 --> URI Class Initialized
INFO - 2023-05-31 06:45:51 --> URI Class Initialized
INFO - 2023-05-31 06:45:51 --> Router Class Initialized
INFO - 2023-05-31 06:45:51 --> Router Class Initialized
INFO - 2023-05-31 06:45:51 --> Output Class Initialized
INFO - 2023-05-31 06:45:51 --> Output Class Initialized
INFO - 2023-05-31 06:45:51 --> Security Class Initialized
INFO - 2023-05-31 06:45:51 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:51 --> Input Class Initialized
INFO - 2023-05-31 06:45:51 --> Input Class Initialized
INFO - 2023-05-31 06:45:51 --> Language Class Initialized
INFO - 2023-05-31 06:45:51 --> Language Class Initialized
INFO - 2023-05-31 06:45:51 --> Loader Class Initialized
INFO - 2023-05-31 06:45:51 --> Loader Class Initialized
INFO - 2023-05-31 06:45:51 --> Controller Class Initialized
INFO - 2023-05-31 06:45:51 --> Controller Class Initialized
DEBUG - 2023-05-31 06:45:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 06:45:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:51 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:51 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:52 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:52 --> Total execution time: 0.1892
INFO - 2023-05-31 06:45:52 --> Config Class Initialized
INFO - 2023-05-31 06:45:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:45:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:52 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:52 --> Final output sent to browser
INFO - 2023-05-31 06:45:52 --> URI Class Initialized
DEBUG - 2023-05-31 06:45:52 --> Total execution time: 0.2647
INFO - 2023-05-31 06:45:52 --> Router Class Initialized
INFO - 2023-05-31 06:45:52 --> Output Class Initialized
INFO - 2023-05-31 06:45:52 --> Security Class Initialized
INFO - 2023-05-31 06:45:52 --> Config Class Initialized
DEBUG - 2023-05-31 06:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:52 --> Input Class Initialized
INFO - 2023-05-31 06:45:52 --> Hooks Class Initialized
INFO - 2023-05-31 06:45:52 --> Language Class Initialized
DEBUG - 2023-05-31 06:45:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:45:52 --> Utf8 Class Initialized
INFO - 2023-05-31 06:45:52 --> URI Class Initialized
INFO - 2023-05-31 06:45:52 --> Loader Class Initialized
INFO - 2023-05-31 06:45:52 --> Controller Class Initialized
INFO - 2023-05-31 06:45:52 --> Router Class Initialized
DEBUG - 2023-05-31 06:45:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:52 --> Output Class Initialized
INFO - 2023-05-31 06:45:52 --> Security Class Initialized
DEBUG - 2023-05-31 06:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:45:52 --> Input Class Initialized
INFO - 2023-05-31 06:45:52 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:52 --> Language Class Initialized
INFO - 2023-05-31 06:45:52 --> Loader Class Initialized
INFO - 2023-05-31 06:45:52 --> Controller Class Initialized
INFO - 2023-05-31 06:45:52 --> Model "Cluster_model" initialized
DEBUG - 2023-05-31 06:45:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:45:52 --> Database Driver Class Initialized
INFO - 2023-05-31 06:45:52 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:45:52 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:52 --> Total execution time: 0.2736
INFO - 2023-05-31 06:45:52 --> Final output sent to browser
DEBUG - 2023-05-31 06:45:52 --> Total execution time: 0.3293
INFO - 2023-05-31 06:46:59 --> Config Class Initialized
INFO - 2023-05-31 06:46:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:46:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:46:59 --> Utf8 Class Initialized
INFO - 2023-05-31 06:46:59 --> URI Class Initialized
INFO - 2023-05-31 06:46:59 --> Router Class Initialized
INFO - 2023-05-31 06:46:59 --> Output Class Initialized
INFO - 2023-05-31 06:46:59 --> Security Class Initialized
DEBUG - 2023-05-31 06:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:46:59 --> Input Class Initialized
INFO - 2023-05-31 06:46:59 --> Language Class Initialized
INFO - 2023-05-31 06:46:59 --> Loader Class Initialized
INFO - 2023-05-31 06:46:59 --> Controller Class Initialized
DEBUG - 2023-05-31 06:46:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:46:59 --> Database Driver Class Initialized
INFO - 2023-05-31 06:46:59 --> Model "Login_model" initialized
INFO - 2023-05-31 06:46:59 --> Database Driver Class Initialized
INFO - 2023-05-31 06:46:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:46:59 --> Final output sent to browser
DEBUG - 2023-05-31 06:46:59 --> Total execution time: 0.2330
INFO - 2023-05-31 06:46:59 --> Config Class Initialized
INFO - 2023-05-31 06:46:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:46:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:46:59 --> Utf8 Class Initialized
INFO - 2023-05-31 06:46:59 --> URI Class Initialized
INFO - 2023-05-31 06:46:59 --> Router Class Initialized
INFO - 2023-05-31 06:46:59 --> Output Class Initialized
INFO - 2023-05-31 06:46:59 --> Security Class Initialized
DEBUG - 2023-05-31 06:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:46:59 --> Input Class Initialized
INFO - 2023-05-31 06:46:59 --> Language Class Initialized
INFO - 2023-05-31 06:46:59 --> Loader Class Initialized
INFO - 2023-05-31 06:46:59 --> Controller Class Initialized
DEBUG - 2023-05-31 06:46:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:00 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:00 --> Model "Login_model" initialized
INFO - 2023-05-31 06:47:00 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:00 --> Final output sent to browser
DEBUG - 2023-05-31 06:47:00 --> Total execution time: 0.2917
INFO - 2023-05-31 06:47:00 --> Config Class Initialized
INFO - 2023-05-31 06:47:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:00 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:00 --> URI Class Initialized
INFO - 2023-05-31 06:47:00 --> Router Class Initialized
INFO - 2023-05-31 06:47:00 --> Output Class Initialized
INFO - 2023-05-31 06:47:00 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:00 --> Input Class Initialized
INFO - 2023-05-31 06:47:00 --> Language Class Initialized
INFO - 2023-05-31 06:47:00 --> Loader Class Initialized
INFO - 2023-05-31 06:47:00 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:00 --> Final output sent to browser
DEBUG - 2023-05-31 06:47:00 --> Total execution time: 0.1431
INFO - 2023-05-31 06:47:00 --> Config Class Initialized
INFO - 2023-05-31 06:47:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:00 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:00 --> URI Class Initialized
INFO - 2023-05-31 06:47:00 --> Router Class Initialized
INFO - 2023-05-31 06:47:00 --> Output Class Initialized
INFO - 2023-05-31 06:47:00 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:00 --> Input Class Initialized
INFO - 2023-05-31 06:47:00 --> Language Class Initialized
INFO - 2023-05-31 06:47:00 --> Loader Class Initialized
INFO - 2023-05-31 06:47:00 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:00 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:00 --> Model "Login_model" initialized
INFO - 2023-05-31 06:47:00 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:00 --> Final output sent to browser
DEBUG - 2023-05-31 06:47:00 --> Total execution time: 0.4914
INFO - 2023-05-31 06:47:04 --> Config Class Initialized
INFO - 2023-05-31 06:47:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:04 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:04 --> URI Class Initialized
INFO - 2023-05-31 06:47:04 --> Router Class Initialized
INFO - 2023-05-31 06:47:04 --> Output Class Initialized
INFO - 2023-05-31 06:47:04 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:04 --> Input Class Initialized
INFO - 2023-05-31 06:47:04 --> Language Class Initialized
INFO - 2023-05-31 06:47:04 --> Loader Class Initialized
INFO - 2023-05-31 06:47:04 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:04 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:04 --> Final output sent to browser
DEBUG - 2023-05-31 06:47:04 --> Total execution time: 0.1819
INFO - 2023-05-31 06:47:04 --> Config Class Initialized
INFO - 2023-05-31 06:47:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:04 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:04 --> URI Class Initialized
INFO - 2023-05-31 06:47:04 --> Router Class Initialized
INFO - 2023-05-31 06:47:04 --> Output Class Initialized
INFO - 2023-05-31 06:47:04 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:04 --> Input Class Initialized
INFO - 2023-05-31 06:47:04 --> Language Class Initialized
INFO - 2023-05-31 06:47:04 --> Loader Class Initialized
INFO - 2023-05-31 06:47:04 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:04 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:04 --> Final output sent to browser
DEBUG - 2023-05-31 06:47:04 --> Total execution time: 0.2123
INFO - 2023-05-31 06:47:07 --> Config Class Initialized
INFO - 2023-05-31 06:47:07 --> Config Class Initialized
INFO - 2023-05-31 06:47:07 --> Config Class Initialized
INFO - 2023-05-31 06:47:07 --> Hooks Class Initialized
INFO - 2023-05-31 06:47:07 --> Hooks Class Initialized
INFO - 2023-05-31 06:47:07 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:47:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:47:08 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:08 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:08 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:08 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:08 --> URI Class Initialized
INFO - 2023-05-31 06:47:08 --> URI Class Initialized
INFO - 2023-05-31 06:47:08 --> URI Class Initialized
INFO - 2023-05-31 06:47:08 --> Router Class Initialized
INFO - 2023-05-31 06:47:08 --> Router Class Initialized
INFO - 2023-05-31 06:47:08 --> Router Class Initialized
INFO - 2023-05-31 06:47:08 --> Output Class Initialized
INFO - 2023-05-31 06:47:08 --> Output Class Initialized
INFO - 2023-05-31 06:47:08 --> Output Class Initialized
INFO - 2023-05-31 06:47:08 --> Security Class Initialized
INFO - 2023-05-31 06:47:08 --> Security Class Initialized
INFO - 2023-05-31 06:47:08 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:08 --> Input Class Initialized
INFO - 2023-05-31 06:47:08 --> Input Class Initialized
INFO - 2023-05-31 06:47:08 --> Input Class Initialized
INFO - 2023-05-31 06:47:08 --> Language Class Initialized
INFO - 2023-05-31 06:47:08 --> Language Class Initialized
INFO - 2023-05-31 06:47:08 --> Language Class Initialized
INFO - 2023-05-31 06:47:08 --> Loader Class Initialized
INFO - 2023-05-31 06:47:08 --> Loader Class Initialized
INFO - 2023-05-31 06:47:08 --> Controller Class Initialized
INFO - 2023-05-31 06:47:08 --> Controller Class Initialized
INFO - 2023-05-31 06:47:08 --> Loader Class Initialized
DEBUG - 2023-05-31 06:47:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 06:47:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:08 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:08 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:08 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:08 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:08 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:08 --> Final output sent to browser
INFO - 2023-05-31 06:47:08 --> Final output sent to browser
INFO - 2023-05-31 06:47:08 --> Database Driver Class Initialized
DEBUG - 2023-05-31 06:47:08 --> Total execution time: 0.1728
DEBUG - 2023-05-31 06:47:08 --> Total execution time: 0.1729
INFO - 2023-05-31 06:47:08 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:08 --> Config Class Initialized
INFO - 2023-05-31 06:47:08 --> Config Class Initialized
INFO - 2023-05-31 06:47:08 --> Final output sent to browser
INFO - 2023-05-31 06:47:08 --> Hooks Class Initialized
INFO - 2023-05-31 06:47:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:08 --> Total execution time: 0.2145
DEBUG - 2023-05-31 06:47:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:47:08 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:08 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:08 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:08 --> URI Class Initialized
INFO - 2023-05-31 06:47:08 --> URI Class Initialized
INFO - 2023-05-31 06:47:08 --> Router Class Initialized
INFO - 2023-05-31 06:47:08 --> Router Class Initialized
INFO - 2023-05-31 06:47:08 --> Output Class Initialized
INFO - 2023-05-31 06:47:08 --> Output Class Initialized
INFO - 2023-05-31 06:47:08 --> Security Class Initialized
INFO - 2023-05-31 06:47:08 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:08 --> Input Class Initialized
INFO - 2023-05-31 06:47:08 --> Input Class Initialized
INFO - 2023-05-31 06:47:08 --> Language Class Initialized
INFO - 2023-05-31 06:47:08 --> Language Class Initialized
INFO - 2023-05-31 06:47:08 --> Loader Class Initialized
INFO - 2023-05-31 06:47:08 --> Loader Class Initialized
INFO - 2023-05-31 06:47:08 --> Controller Class Initialized
INFO - 2023-05-31 06:47:08 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 06:47:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:08 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:08 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:09 --> Final output sent to browser
INFO - 2023-05-31 06:47:09 --> Final output sent to browser
DEBUG - 2023-05-31 06:47:09 --> Total execution time: 0.8893
DEBUG - 2023-05-31 06:47:09 --> Total execution time: 0.8887
INFO - 2023-05-31 06:47:09 --> Config Class Initialized
INFO - 2023-05-31 06:47:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:09 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:09 --> URI Class Initialized
INFO - 2023-05-31 06:47:09 --> Router Class Initialized
INFO - 2023-05-31 06:47:09 --> Output Class Initialized
INFO - 2023-05-31 06:47:09 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:09 --> Input Class Initialized
INFO - 2023-05-31 06:47:09 --> Language Class Initialized
INFO - 2023-05-31 06:47:09 --> Loader Class Initialized
INFO - 2023-05-31 06:47:09 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:09 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:09 --> Config Class Initialized
INFO - 2023-05-31 06:47:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:09 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:09 --> URI Class Initialized
INFO - 2023-05-31 06:47:09 --> Router Class Initialized
INFO - 2023-05-31 06:47:09 --> Output Class Initialized
INFO - 2023-05-31 06:47:09 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:09 --> Input Class Initialized
INFO - 2023-05-31 06:47:09 --> Language Class Initialized
INFO - 2023-05-31 06:47:09 --> Loader Class Initialized
INFO - 2023-05-31 06:47:09 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:09 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:10 --> Config Class Initialized
INFO - 2023-05-31 06:47:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:10 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:10 --> URI Class Initialized
INFO - 2023-05-31 06:47:10 --> Router Class Initialized
INFO - 2023-05-31 06:47:10 --> Output Class Initialized
INFO - 2023-05-31 06:47:10 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:10 --> Input Class Initialized
INFO - 2023-05-31 06:47:10 --> Language Class Initialized
INFO - 2023-05-31 06:47:10 --> Loader Class Initialized
INFO - 2023-05-31 06:47:10 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:10 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:10 --> Final output sent to browser
DEBUG - 2023-05-31 06:47:10 --> Total execution time: 0.1995
INFO - 2023-05-31 06:47:10 --> Config Class Initialized
INFO - 2023-05-31 06:47:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:47:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:47:10 --> Utf8 Class Initialized
INFO - 2023-05-31 06:47:10 --> URI Class Initialized
INFO - 2023-05-31 06:47:10 --> Router Class Initialized
INFO - 2023-05-31 06:47:10 --> Output Class Initialized
INFO - 2023-05-31 06:47:10 --> Security Class Initialized
DEBUG - 2023-05-31 06:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:47:10 --> Input Class Initialized
INFO - 2023-05-31 06:47:10 --> Language Class Initialized
INFO - 2023-05-31 06:47:10 --> Loader Class Initialized
INFO - 2023-05-31 06:47:10 --> Controller Class Initialized
DEBUG - 2023-05-31 06:47:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:47:10 --> Database Driver Class Initialized
INFO - 2023-05-31 06:47:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:47:10 --> Final output sent to browser
DEBUG - 2023-05-31 06:47:10 --> Total execution time: 0.2305
INFO - 2023-05-31 06:50:46 --> Config Class Initialized
INFO - 2023-05-31 06:50:46 --> Config Class Initialized
INFO - 2023-05-31 06:50:46 --> Config Class Initialized
INFO - 2023-05-31 06:50:46 --> Hooks Class Initialized
INFO - 2023-05-31 06:50:46 --> Hooks Class Initialized
INFO - 2023-05-31 06:50:46 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:50:46 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:50:46 --> Utf8 Class Initialized
INFO - 2023-05-31 06:50:46 --> Utf8 Class Initialized
INFO - 2023-05-31 06:50:46 --> Utf8 Class Initialized
INFO - 2023-05-31 06:50:46 --> URI Class Initialized
INFO - 2023-05-31 06:50:46 --> URI Class Initialized
INFO - 2023-05-31 06:50:46 --> URI Class Initialized
INFO - 2023-05-31 06:50:46 --> Router Class Initialized
INFO - 2023-05-31 06:50:46 --> Router Class Initialized
INFO - 2023-05-31 06:50:46 --> Router Class Initialized
INFO - 2023-05-31 06:50:46 --> Output Class Initialized
INFO - 2023-05-31 06:50:46 --> Output Class Initialized
INFO - 2023-05-31 06:50:46 --> Output Class Initialized
INFO - 2023-05-31 06:50:46 --> Security Class Initialized
INFO - 2023-05-31 06:50:46 --> Security Class Initialized
INFO - 2023-05-31 06:50:46 --> Security Class Initialized
DEBUG - 2023-05-31 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:50:46 --> Input Class Initialized
INFO - 2023-05-31 06:50:46 --> Input Class Initialized
INFO - 2023-05-31 06:50:46 --> Input Class Initialized
INFO - 2023-05-31 06:50:46 --> Language Class Initialized
INFO - 2023-05-31 06:50:46 --> Language Class Initialized
INFO - 2023-05-31 06:50:46 --> Language Class Initialized
INFO - 2023-05-31 06:50:46 --> Loader Class Initialized
INFO - 2023-05-31 06:50:46 --> Loader Class Initialized
INFO - 2023-05-31 06:50:46 --> Controller Class Initialized
INFO - 2023-05-31 06:50:46 --> Controller Class Initialized
DEBUG - 2023-05-31 06:50:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 06:50:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:50:46 --> Loader Class Initialized
INFO - 2023-05-31 06:50:46 --> Controller Class Initialized
INFO - 2023-05-31 06:50:46 --> Database Driver Class Initialized
INFO - 2023-05-31 06:50:46 --> Database Driver Class Initialized
DEBUG - 2023-05-31 06:50:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:50:46 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:50:46 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:50:46 --> Final output sent to browser
INFO - 2023-05-31 06:50:46 --> Final output sent to browser
DEBUG - 2023-05-31 06:50:46 --> Total execution time: 0.2178
DEBUG - 2023-05-31 06:50:46 --> Total execution time: 0.2184
INFO - 2023-05-31 06:50:46 --> Database Driver Class Initialized
INFO - 2023-05-31 06:50:46 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:50:46 --> Final output sent to browser
INFO - 2023-05-31 06:50:46 --> Config Class Initialized
INFO - 2023-05-31 06:50:46 --> Config Class Initialized
DEBUG - 2023-05-31 06:50:46 --> Total execution time: 0.2641
INFO - 2023-05-31 06:50:46 --> Hooks Class Initialized
INFO - 2023-05-31 06:50:46 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 06:50:46 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:50:46 --> Utf8 Class Initialized
INFO - 2023-05-31 06:50:46 --> Utf8 Class Initialized
INFO - 2023-05-31 06:50:46 --> URI Class Initialized
INFO - 2023-05-31 06:50:46 --> URI Class Initialized
INFO - 2023-05-31 06:50:46 --> Router Class Initialized
INFO - 2023-05-31 06:50:46 --> Router Class Initialized
INFO - 2023-05-31 06:50:46 --> Output Class Initialized
INFO - 2023-05-31 06:50:46 --> Output Class Initialized
INFO - 2023-05-31 06:50:46 --> Config Class Initialized
INFO - 2023-05-31 06:50:46 --> Security Class Initialized
INFO - 2023-05-31 06:50:46 --> Security Class Initialized
INFO - 2023-05-31 06:50:46 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:50:46 --> Input Class Initialized
INFO - 2023-05-31 06:50:46 --> Input Class Initialized
INFO - 2023-05-31 06:50:46 --> Language Class Initialized
INFO - 2023-05-31 06:50:46 --> Language Class Initialized
DEBUG - 2023-05-31 06:50:46 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:50:46 --> Utf8 Class Initialized
INFO - 2023-05-31 06:50:46 --> Loader Class Initialized
INFO - 2023-05-31 06:50:46 --> Loader Class Initialized
INFO - 2023-05-31 06:50:46 --> URI Class Initialized
INFO - 2023-05-31 06:50:46 --> Controller Class Initialized
INFO - 2023-05-31 06:50:46 --> Controller Class Initialized
DEBUG - 2023-05-31 06:50:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 06:50:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:50:46 --> Router Class Initialized
INFO - 2023-05-31 06:50:46 --> Database Driver Class Initialized
INFO - 2023-05-31 06:50:46 --> Output Class Initialized
INFO - 2023-05-31 06:50:46 --> Database Driver Class Initialized
INFO - 2023-05-31 06:50:46 --> Security Class Initialized
DEBUG - 2023-05-31 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:50:46 --> Input Class Initialized
INFO - 2023-05-31 06:50:46 --> Language Class Initialized
INFO - 2023-05-31 06:50:46 --> Loader Class Initialized
INFO - 2023-05-31 06:50:46 --> Controller Class Initialized
DEBUG - 2023-05-31 06:50:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:50:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:50:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:50:47 --> Database Driver Class Initialized
INFO - 2023-05-31 06:50:47 --> Final output sent to browser
INFO - 2023-05-31 06:50:47 --> Final output sent to browser
DEBUG - 2023-05-31 06:50:47 --> Total execution time: 0.2727
DEBUG - 2023-05-31 06:50:47 --> Total execution time: 0.2720
INFO - 2023-05-31 06:50:47 --> Config Class Initialized
INFO - 2023-05-31 06:50:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:50:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:50:47 --> Utf8 Class Initialized
INFO - 2023-05-31 06:50:47 --> URI Class Initialized
INFO - 2023-05-31 06:50:47 --> Router Class Initialized
INFO - 2023-05-31 06:50:47 --> Output Class Initialized
INFO - 2023-05-31 06:50:47 --> Security Class Initialized
DEBUG - 2023-05-31 06:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:50:47 --> Input Class Initialized
INFO - 2023-05-31 06:50:47 --> Language Class Initialized
INFO - 2023-05-31 06:50:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:50:47 --> Loader Class Initialized
INFO - 2023-05-31 06:50:47 --> Controller Class Initialized
DEBUG - 2023-05-31 06:50:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:50:47 --> Final output sent to browser
DEBUG - 2023-05-31 06:50:47 --> Total execution time: 0.4768
INFO - 2023-05-31 06:50:47 --> Database Driver Class Initialized
INFO - 2023-05-31 06:50:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 06:50:47 --> Config Class Initialized
INFO - 2023-05-31 06:50:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 06:50:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 06:50:47 --> Utf8 Class Initialized
INFO - 2023-05-31 06:50:47 --> URI Class Initialized
INFO - 2023-05-31 06:50:47 --> Router Class Initialized
INFO - 2023-05-31 06:50:47 --> Output Class Initialized
INFO - 2023-05-31 06:50:47 --> Security Class Initialized
DEBUG - 2023-05-31 06:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 06:50:47 --> Input Class Initialized
INFO - 2023-05-31 06:50:47 --> Language Class Initialized
INFO - 2023-05-31 06:50:47 --> Loader Class Initialized
INFO - 2023-05-31 06:50:47 --> Controller Class Initialized
DEBUG - 2023-05-31 06:50:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 06:50:47 --> Database Driver Class Initialized
INFO - 2023-05-31 06:50:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:09:40 --> Config Class Initialized
INFO - 2023-05-31 07:09:40 --> Config Class Initialized
INFO - 2023-05-31 07:09:40 --> Hooks Class Initialized
INFO - 2023-05-31 07:09:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:09:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:09:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:09:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:09:40 --> URI Class Initialized
INFO - 2023-05-31 07:09:40 --> URI Class Initialized
INFO - 2023-05-31 07:09:40 --> Router Class Initialized
INFO - 2023-05-31 07:09:40 --> Router Class Initialized
INFO - 2023-05-31 07:09:40 --> Output Class Initialized
INFO - 2023-05-31 07:09:40 --> Output Class Initialized
INFO - 2023-05-31 07:09:40 --> Security Class Initialized
INFO - 2023-05-31 07:09:40 --> Security Class Initialized
DEBUG - 2023-05-31 07:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:09:40 --> Input Class Initialized
INFO - 2023-05-31 07:09:40 --> Input Class Initialized
INFO - 2023-05-31 07:09:40 --> Language Class Initialized
INFO - 2023-05-31 07:09:40 --> Language Class Initialized
INFO - 2023-05-31 07:09:40 --> Loader Class Initialized
INFO - 2023-05-31 07:09:40 --> Loader Class Initialized
INFO - 2023-05-31 07:09:40 --> Controller Class Initialized
INFO - 2023-05-31 07:09:40 --> Controller Class Initialized
DEBUG - 2023-05-31 07:09:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:09:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:09:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:09:40 --> Total execution time: 0.1476
INFO - 2023-05-31 07:09:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:09:40 --> Config Class Initialized
INFO - 2023-05-31 07:09:40 --> Hooks Class Initialized
INFO - 2023-05-31 07:09:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:09:40 --> Total execution time: 0.2290
DEBUG - 2023-05-31 07:09:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:09:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:09:40 --> URI Class Initialized
INFO - 2023-05-31 07:09:40 --> Router Class Initialized
INFO - 2023-05-31 07:09:40 --> Config Class Initialized
INFO - 2023-05-31 07:09:40 --> Hooks Class Initialized
INFO - 2023-05-31 07:09:40 --> Output Class Initialized
INFO - 2023-05-31 07:09:40 --> Security Class Initialized
DEBUG - 2023-05-31 07:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:09:40 --> Input Class Initialized
INFO - 2023-05-31 07:09:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:09:40 --> Language Class Initialized
INFO - 2023-05-31 07:09:40 --> URI Class Initialized
INFO - 2023-05-31 07:09:40 --> Router Class Initialized
INFO - 2023-05-31 07:09:40 --> Output Class Initialized
INFO - 2023-05-31 07:09:40 --> Loader Class Initialized
INFO - 2023-05-31 07:09:40 --> Security Class Initialized
INFO - 2023-05-31 07:09:40 --> Controller Class Initialized
DEBUG - 2023-05-31 07:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:09:40 --> Input Class Initialized
DEBUG - 2023-05-31 07:09:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:09:40 --> Language Class Initialized
INFO - 2023-05-31 07:09:40 --> Loader Class Initialized
INFO - 2023-05-31 07:09:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:40 --> Controller Class Initialized
DEBUG - 2023-05-31 07:09:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:09:40 --> Model "Login_model" initialized
INFO - 2023-05-31 07:09:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:09:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:09:40 --> Total execution time: 0.2975
INFO - 2023-05-31 07:09:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:09:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:09:40 --> Total execution time: 0.2476
INFO - 2023-05-31 07:09:41 --> Config Class Initialized
INFO - 2023-05-31 07:09:41 --> Hooks Class Initialized
INFO - 2023-05-31 07:09:41 --> Config Class Initialized
INFO - 2023-05-31 07:09:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:09:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:09:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:09:41 --> URI Class Initialized
DEBUG - 2023-05-31 07:09:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:09:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:09:41 --> URI Class Initialized
INFO - 2023-05-31 07:09:41 --> Router Class Initialized
INFO - 2023-05-31 07:09:41 --> Router Class Initialized
INFO - 2023-05-31 07:09:41 --> Output Class Initialized
INFO - 2023-05-31 07:09:41 --> Security Class Initialized
INFO - 2023-05-31 07:09:41 --> Output Class Initialized
DEBUG - 2023-05-31 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:09:41 --> Security Class Initialized
INFO - 2023-05-31 07:09:41 --> Input Class Initialized
INFO - 2023-05-31 07:09:41 --> Language Class Initialized
DEBUG - 2023-05-31 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:09:41 --> Input Class Initialized
INFO - 2023-05-31 07:09:41 --> Language Class Initialized
INFO - 2023-05-31 07:09:41 --> Loader Class Initialized
INFO - 2023-05-31 07:09:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:09:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:09:41 --> Loader Class Initialized
INFO - 2023-05-31 07:09:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:09:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:09:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:09:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:09:41 --> Total execution time: 0.2266
INFO - 2023-05-31 07:09:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:09:41 --> Config Class Initialized
INFO - 2023-05-31 07:09:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:09:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:09:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:09:41 --> Model "Login_model" initialized
INFO - 2023-05-31 07:09:41 --> URI Class Initialized
INFO - 2023-05-31 07:09:41 --> Router Class Initialized
INFO - 2023-05-31 07:09:41 --> Output Class Initialized
INFO - 2023-05-31 07:09:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:09:41 --> Input Class Initialized
INFO - 2023-05-31 07:09:41 --> Language Class Initialized
INFO - 2023-05-31 07:09:41 --> Loader Class Initialized
INFO - 2023-05-31 07:09:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:09:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:09:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:09:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:09:41 --> Total execution time: 0.2161
INFO - 2023-05-31 07:09:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:09:41 --> Total execution time: 0.4888
INFO - 2023-05-31 07:09:41 --> Config Class Initialized
INFO - 2023-05-31 07:09:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:09:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:09:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:09:41 --> URI Class Initialized
INFO - 2023-05-31 07:09:41 --> Router Class Initialized
INFO - 2023-05-31 07:09:41 --> Output Class Initialized
INFO - 2023-05-31 07:09:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:09:41 --> Input Class Initialized
INFO - 2023-05-31 07:09:41 --> Language Class Initialized
INFO - 2023-05-31 07:09:41 --> Loader Class Initialized
INFO - 2023-05-31 07:09:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:09:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:09:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:09:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:09:41 --> Model "Login_model" initialized
INFO - 2023-05-31 07:09:42 --> Final output sent to browser
DEBUG - 2023-05-31 07:09:42 --> Total execution time: 0.5212
INFO - 2023-05-31 07:39:02 --> Config Class Initialized
INFO - 2023-05-31 07:39:02 --> Config Class Initialized
INFO - 2023-05-31 07:39:02 --> Config Class Initialized
INFO - 2023-05-31 07:39:02 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:02 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:02 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:02 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:02 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:02 --> URI Class Initialized
INFO - 2023-05-31 07:39:02 --> URI Class Initialized
INFO - 2023-05-31 07:39:02 --> URI Class Initialized
INFO - 2023-05-31 07:39:02 --> Router Class Initialized
INFO - 2023-05-31 07:39:02 --> Router Class Initialized
INFO - 2023-05-31 07:39:02 --> Router Class Initialized
INFO - 2023-05-31 07:39:02 --> Output Class Initialized
INFO - 2023-05-31 07:39:02 --> Output Class Initialized
INFO - 2023-05-31 07:39:02 --> Output Class Initialized
INFO - 2023-05-31 07:39:02 --> Security Class Initialized
INFO - 2023-05-31 07:39:02 --> Security Class Initialized
INFO - 2023-05-31 07:39:02 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:02 --> Input Class Initialized
INFO - 2023-05-31 07:39:02 --> Input Class Initialized
INFO - 2023-05-31 07:39:02 --> Input Class Initialized
INFO - 2023-05-31 07:39:02 --> Language Class Initialized
INFO - 2023-05-31 07:39:02 --> Language Class Initialized
INFO - 2023-05-31 07:39:02 --> Language Class Initialized
INFO - 2023-05-31 07:39:02 --> Loader Class Initialized
INFO - 2023-05-31 07:39:02 --> Loader Class Initialized
INFO - 2023-05-31 07:39:02 --> Controller Class Initialized
INFO - 2023-05-31 07:39:02 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:39:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:02 --> Loader Class Initialized
INFO - 2023-05-31 07:39:02 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:02 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:02 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:02 --> Final output sent to browser
INFO - 2023-05-31 07:39:02 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:02 --> Total execution time: 0.1914
DEBUG - 2023-05-31 07:39:02 --> Total execution time: 0.1923
INFO - 2023-05-31 07:39:02 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:02 --> Config Class Initialized
INFO - 2023-05-31 07:39:02 --> Config Class Initialized
INFO - 2023-05-31 07:39:02 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:02 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:02 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:02 --> Total execution time: 0.2467
INFO - 2023-05-31 07:39:02 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:02 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:02 --> URI Class Initialized
INFO - 2023-05-31 07:39:02 --> URI Class Initialized
INFO - 2023-05-31 07:39:02 --> Router Class Initialized
INFO - 2023-05-31 07:39:02 --> Router Class Initialized
INFO - 2023-05-31 07:39:02 --> Output Class Initialized
INFO - 2023-05-31 07:39:02 --> Output Class Initialized
INFO - 2023-05-31 07:39:02 --> Security Class Initialized
INFO - 2023-05-31 07:39:02 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:02 --> Input Class Initialized
INFO - 2023-05-31 07:39:02 --> Input Class Initialized
INFO - 2023-05-31 07:39:02 --> Language Class Initialized
INFO - 2023-05-31 07:39:02 --> Config Class Initialized
INFO - 2023-05-31 07:39:02 --> Language Class Initialized
INFO - 2023-05-31 07:39:02 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:02 --> Loader Class Initialized
INFO - 2023-05-31 07:39:02 --> Loader Class Initialized
INFO - 2023-05-31 07:39:02 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:02 --> Controller Class Initialized
INFO - 2023-05-31 07:39:02 --> Utf8 Class Initialized
DEBUG - 2023-05-31 07:39:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:39:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:02 --> URI Class Initialized
INFO - 2023-05-31 07:39:02 --> Router Class Initialized
INFO - 2023-05-31 07:39:02 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:02 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:02 --> Output Class Initialized
INFO - 2023-05-31 07:39:02 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:02 --> Input Class Initialized
INFO - 2023-05-31 07:39:02 --> Language Class Initialized
INFO - 2023-05-31 07:39:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:03 --> Final output sent to browser
INFO - 2023-05-31 07:39:03 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:03 --> Total execution time: 0.1973
DEBUG - 2023-05-31 07:39:03 --> Total execution time: 0.1964
INFO - 2023-05-31 07:39:03 --> Loader Class Initialized
INFO - 2023-05-31 07:39:03 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:03 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:03 --> Config Class Initialized
INFO - 2023-05-31 07:39:03 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:03 --> Model "Cluster_model" initialized
DEBUG - 2023-05-31 07:39:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:03 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:03 --> URI Class Initialized
INFO - 2023-05-31 07:39:03 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:03 --> Total execution time: 0.2354
INFO - 2023-05-31 07:39:03 --> Router Class Initialized
INFO - 2023-05-31 07:39:03 --> Output Class Initialized
INFO - 2023-05-31 07:39:03 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:03 --> Input Class Initialized
INFO - 2023-05-31 07:39:03 --> Language Class Initialized
INFO - 2023-05-31 07:39:03 --> Loader Class Initialized
INFO - 2023-05-31 07:39:03 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:03 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:03 --> Config Class Initialized
INFO - 2023-05-31 07:39:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:03 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:03 --> URI Class Initialized
INFO - 2023-05-31 07:39:03 --> Router Class Initialized
INFO - 2023-05-31 07:39:03 --> Output Class Initialized
INFO - 2023-05-31 07:39:03 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:03 --> Input Class Initialized
INFO - 2023-05-31 07:39:03 --> Language Class Initialized
INFO - 2023-05-31 07:39:03 --> Loader Class Initialized
INFO - 2023-05-31 07:39:03 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:03 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:05 --> Config Class Initialized
INFO - 2023-05-31 07:39:05 --> Config Class Initialized
INFO - 2023-05-31 07:39:05 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:05 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:05 --> URI Class Initialized
INFO - 2023-05-31 07:39:05 --> URI Class Initialized
INFO - 2023-05-31 07:39:05 --> Router Class Initialized
INFO - 2023-05-31 07:39:05 --> Router Class Initialized
INFO - 2023-05-31 07:39:05 --> Output Class Initialized
INFO - 2023-05-31 07:39:05 --> Output Class Initialized
INFO - 2023-05-31 07:39:05 --> Security Class Initialized
INFO - 2023-05-31 07:39:05 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:05 --> Input Class Initialized
INFO - 2023-05-31 07:39:05 --> Input Class Initialized
INFO - 2023-05-31 07:39:05 --> Language Class Initialized
INFO - 2023-05-31 07:39:05 --> Language Class Initialized
INFO - 2023-05-31 07:39:05 --> Loader Class Initialized
INFO - 2023-05-31 07:39:05 --> Loader Class Initialized
INFO - 2023-05-31 07:39:05 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:05 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:05 --> Total execution time: 0.1729
INFO - 2023-05-31 07:39:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:05 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:06 --> Config Class Initialized
INFO - 2023-05-31 07:39:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:06 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:06 --> URI Class Initialized
INFO - 2023-05-31 07:39:06 --> Router Class Initialized
INFO - 2023-05-31 07:39:06 --> Output Class Initialized
INFO - 2023-05-31 07:39:06 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:06 --> Input Class Initialized
INFO - 2023-05-31 07:39:06 --> Language Class Initialized
INFO - 2023-05-31 07:39:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:06 --> Total execution time: 0.3343
INFO - 2023-05-31 07:39:06 --> Loader Class Initialized
INFO - 2023-05-31 07:39:06 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:06 --> Config Class Initialized
INFO - 2023-05-31 07:39:06 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:06 --> Database Driver Class Initialized
DEBUG - 2023-05-31 07:39:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:06 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:06 --> URI Class Initialized
INFO - 2023-05-31 07:39:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:06 --> Total execution time: 0.2118
INFO - 2023-05-31 07:39:06 --> Router Class Initialized
INFO - 2023-05-31 07:39:06 --> Output Class Initialized
INFO - 2023-05-31 07:39:06 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:06 --> Input Class Initialized
INFO - 2023-05-31 07:39:06 --> Language Class Initialized
INFO - 2023-05-31 07:39:06 --> Loader Class Initialized
INFO - 2023-05-31 07:39:06 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:06 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:06 --> Total execution time: 0.5479
INFO - 2023-05-31 07:39:11 --> Config Class Initialized
INFO - 2023-05-31 07:39:11 --> Config Class Initialized
INFO - 2023-05-31 07:39:11 --> Config Class Initialized
INFO - 2023-05-31 07:39:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:11 --> URI Class Initialized
INFO - 2023-05-31 07:39:11 --> URI Class Initialized
INFO - 2023-05-31 07:39:11 --> URI Class Initialized
INFO - 2023-05-31 07:39:11 --> Router Class Initialized
INFO - 2023-05-31 07:39:11 --> Router Class Initialized
INFO - 2023-05-31 07:39:11 --> Router Class Initialized
INFO - 2023-05-31 07:39:11 --> Output Class Initialized
INFO - 2023-05-31 07:39:11 --> Output Class Initialized
INFO - 2023-05-31 07:39:11 --> Output Class Initialized
INFO - 2023-05-31 07:39:11 --> Security Class Initialized
INFO - 2023-05-31 07:39:11 --> Security Class Initialized
INFO - 2023-05-31 07:39:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:11 --> Input Class Initialized
INFO - 2023-05-31 07:39:11 --> Input Class Initialized
INFO - 2023-05-31 07:39:11 --> Input Class Initialized
INFO - 2023-05-31 07:39:11 --> Language Class Initialized
INFO - 2023-05-31 07:39:11 --> Language Class Initialized
INFO - 2023-05-31 07:39:11 --> Language Class Initialized
INFO - 2023-05-31 07:39:11 --> Loader Class Initialized
INFO - 2023-05-31 07:39:11 --> Loader Class Initialized
INFO - 2023-05-31 07:39:11 --> Loader Class Initialized
INFO - 2023-05-31 07:39:11 --> Controller Class Initialized
INFO - 2023-05-31 07:39:11 --> Controller Class Initialized
INFO - 2023-05-31 07:39:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:39:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:39:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:11 --> Final output sent to browser
INFO - 2023-05-31 07:39:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:11 --> Total execution time: 0.2010
DEBUG - 2023-05-31 07:39:11 --> Total execution time: 0.2011
INFO - 2023-05-31 07:39:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:11 --> Total execution time: 0.2081
INFO - 2023-05-31 07:39:11 --> Config Class Initialized
INFO - 2023-05-31 07:39:11 --> Config Class Initialized
INFO - 2023-05-31 07:39:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:11 --> Config Class Initialized
INFO - 2023-05-31 07:39:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:11 --> URI Class Initialized
INFO - 2023-05-31 07:39:11 --> URI Class Initialized
INFO - 2023-05-31 07:39:11 --> Router Class Initialized
INFO - 2023-05-31 07:39:11 --> Router Class Initialized
INFO - 2023-05-31 07:39:11 --> Output Class Initialized
INFO - 2023-05-31 07:39:11 --> Output Class Initialized
INFO - 2023-05-31 07:39:11 --> Security Class Initialized
INFO - 2023-05-31 07:39:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:11 --> Input Class Initialized
INFO - 2023-05-31 07:39:11 --> Input Class Initialized
INFO - 2023-05-31 07:39:11 --> Language Class Initialized
INFO - 2023-05-31 07:39:11 --> Language Class Initialized
DEBUG - 2023-05-31 07:39:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:11 --> URI Class Initialized
INFO - 2023-05-31 07:39:11 --> Config Class Initialized
INFO - 2023-05-31 07:39:11 --> Loader Class Initialized
INFO - 2023-05-31 07:39:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:11 --> Controller Class Initialized
INFO - 2023-05-31 07:39:11 --> Router Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:11 --> Output Class Initialized
INFO - 2023-05-31 07:39:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:11 --> Loader Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:11 --> Input Class Initialized
INFO - 2023-05-31 07:39:11 --> URI Class Initialized
INFO - 2023-05-31 07:39:11 --> Language Class Initialized
INFO - 2023-05-31 07:39:11 --> Controller Class Initialized
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:11 --> Router Class Initialized
INFO - 2023-05-31 07:39:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:11 --> Loader Class Initialized
INFO - 2023-05-31 07:39:11 --> Output Class Initialized
INFO - 2023-05-31 07:39:11 --> Controller Class Initialized
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:11 --> Total execution time: 0.1996
INFO - 2023-05-31 07:39:11 --> Input Class Initialized
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:11 --> Language Class Initialized
INFO - 2023-05-31 07:39:11 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:11 --> Loader Class Initialized
INFO - 2023-05-31 07:39:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:11 --> Total execution time: 0.2465
INFO - 2023-05-31 07:39:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:11 --> Total execution time: 0.2759
INFO - 2023-05-31 07:39:11 --> Config Class Initialized
INFO - 2023-05-31 07:39:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
DEBUG - 2023-05-31 07:39:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:11 --> URI Class Initialized
INFO - 2023-05-31 07:39:11 --> Router Class Initialized
INFO - 2023-05-31 07:39:11 --> Output Class Initialized
INFO - 2023-05-31 07:39:11 --> Security Class Initialized
INFO - 2023-05-31 07:39:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:11 --> Total execution time: 0.2951
INFO - 2023-05-31 07:39:11 --> Input Class Initialized
INFO - 2023-05-31 07:39:11 --> Language Class Initialized
INFO - 2023-05-31 07:39:11 --> Loader Class Initialized
INFO - 2023-05-31 07:39:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:11 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:11 --> Total execution time: 0.2083
INFO - 2023-05-31 07:39:21 --> Config Class Initialized
INFO - 2023-05-31 07:39:21 --> Config Class Initialized
INFO - 2023-05-31 07:39:21 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:21 --> URI Class Initialized
INFO - 2023-05-31 07:39:21 --> URI Class Initialized
INFO - 2023-05-31 07:39:21 --> Router Class Initialized
INFO - 2023-05-31 07:39:21 --> Router Class Initialized
INFO - 2023-05-31 07:39:21 --> Output Class Initialized
INFO - 2023-05-31 07:39:21 --> Output Class Initialized
INFO - 2023-05-31 07:39:21 --> Security Class Initialized
INFO - 2023-05-31 07:39:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:21 --> Input Class Initialized
INFO - 2023-05-31 07:39:21 --> Input Class Initialized
INFO - 2023-05-31 07:39:21 --> Language Class Initialized
INFO - 2023-05-31 07:39:21 --> Language Class Initialized
INFO - 2023-05-31 07:39:21 --> Loader Class Initialized
INFO - 2023-05-31 07:39:21 --> Loader Class Initialized
INFO - 2023-05-31 07:39:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:21 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:21 --> Total execution time: 0.1907
INFO - 2023-05-31 07:39:21 --> Config Class Initialized
INFO - 2023-05-31 07:39:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:21 --> URI Class Initialized
INFO - 2023-05-31 07:39:21 --> Router Class Initialized
INFO - 2023-05-31 07:39:21 --> Output Class Initialized
INFO - 2023-05-31 07:39:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:21 --> Input Class Initialized
INFO - 2023-05-31 07:39:21 --> Language Class Initialized
INFO - 2023-05-31 07:39:21 --> Loader Class Initialized
INFO - 2023-05-31 07:39:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:21 --> Total execution time: 0.2585
INFO - 2023-05-31 07:39:31 --> Config Class Initialized
INFO - 2023-05-31 07:39:31 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:31 --> Config Class Initialized
INFO - 2023-05-31 07:39:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:31 --> URI Class Initialized
DEBUG - 2023-05-31 07:39:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:31 --> Router Class Initialized
INFO - 2023-05-31 07:39:31 --> URI Class Initialized
INFO - 2023-05-31 07:39:31 --> Output Class Initialized
INFO - 2023-05-31 07:39:31 --> Router Class Initialized
INFO - 2023-05-31 07:39:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:31 --> Output Class Initialized
INFO - 2023-05-31 07:39:31 --> Input Class Initialized
INFO - 2023-05-31 07:39:31 --> Security Class Initialized
INFO - 2023-05-31 07:39:31 --> Language Class Initialized
DEBUG - 2023-05-31 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:31 --> Input Class Initialized
INFO - 2023-05-31 07:39:31 --> Language Class Initialized
INFO - 2023-05-31 07:39:31 --> Loader Class Initialized
INFO - 2023-05-31 07:39:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:31 --> Loader Class Initialized
INFO - 2023-05-31 07:39:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:31 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:31 --> Total execution time: 0.3038
INFO - 2023-05-31 07:39:31 --> Config Class Initialized
INFO - 2023-05-31 07:39:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:31 --> URI Class Initialized
INFO - 2023-05-31 07:39:31 --> Router Class Initialized
INFO - 2023-05-31 07:39:31 --> Output Class Initialized
INFO - 2023-05-31 07:39:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:31 --> Input Class Initialized
INFO - 2023-05-31 07:39:31 --> Language Class Initialized
INFO - 2023-05-31 07:39:31 --> Loader Class Initialized
INFO - 2023-05-31 07:39:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:31 --> Total execution time: 0.2624
INFO - 2023-05-31 07:39:34 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:34 --> Total execution time: 13.2806
INFO - 2023-05-31 07:39:34 --> Config Class Initialized
INFO - 2023-05-31 07:39:34 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:34 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:34 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:34 --> URI Class Initialized
INFO - 2023-05-31 07:39:34 --> Router Class Initialized
INFO - 2023-05-31 07:39:34 --> Output Class Initialized
INFO - 2023-05-31 07:39:34 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:34 --> Input Class Initialized
INFO - 2023-05-31 07:39:34 --> Language Class Initialized
INFO - 2023-05-31 07:39:34 --> Loader Class Initialized
INFO - 2023-05-31 07:39:34 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:34 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:34 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:34 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:34 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:39 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:39 --> Total execution time: 8.7612
INFO - 2023-05-31 07:39:41 --> Config Class Initialized
INFO - 2023-05-31 07:39:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:41 --> URI Class Initialized
INFO - 2023-05-31 07:39:41 --> Router Class Initialized
INFO - 2023-05-31 07:39:41 --> Output Class Initialized
INFO - 2023-05-31 07:39:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:41 --> Input Class Initialized
INFO - 2023-05-31 07:39:41 --> Language Class Initialized
INFO - 2023-05-31 07:39:41 --> Loader Class Initialized
INFO - 2023-05-31 07:39:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:41 --> Total execution time: 0.2200
INFO - 2023-05-31 07:39:41 --> Config Class Initialized
INFO - 2023-05-31 07:39:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:41 --> URI Class Initialized
INFO - 2023-05-31 07:39:41 --> Router Class Initialized
INFO - 2023-05-31 07:39:41 --> Output Class Initialized
INFO - 2023-05-31 07:39:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:41 --> Input Class Initialized
INFO - 2023-05-31 07:39:41 --> Language Class Initialized
INFO - 2023-05-31 07:39:41 --> Loader Class Initialized
INFO - 2023-05-31 07:39:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:41 --> Total execution time: 0.1981
INFO - 2023-05-31 07:39:44 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:44 --> Total execution time: 9.6098
INFO - 2023-05-31 07:39:44 --> Config Class Initialized
INFO - 2023-05-31 07:39:44 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:44 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:44 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:44 --> URI Class Initialized
INFO - 2023-05-31 07:39:44 --> Router Class Initialized
INFO - 2023-05-31 07:39:44 --> Output Class Initialized
INFO - 2023-05-31 07:39:44 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:44 --> Input Class Initialized
INFO - 2023-05-31 07:39:44 --> Language Class Initialized
INFO - 2023-05-31 07:39:44 --> Loader Class Initialized
INFO - 2023-05-31 07:39:44 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:44 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:44 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:44 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:51 --> Config Class Initialized
INFO - 2023-05-31 07:39:51 --> Config Class Initialized
INFO - 2023-05-31 07:39:51 --> Hooks Class Initialized
INFO - 2023-05-31 07:39:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:39:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:51 --> URI Class Initialized
INFO - 2023-05-31 07:39:51 --> URI Class Initialized
INFO - 2023-05-31 07:39:51 --> Router Class Initialized
INFO - 2023-05-31 07:39:51 --> Router Class Initialized
INFO - 2023-05-31 07:39:51 --> Output Class Initialized
INFO - 2023-05-31 07:39:51 --> Output Class Initialized
INFO - 2023-05-31 07:39:51 --> Security Class Initialized
INFO - 2023-05-31 07:39:51 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:51 --> Input Class Initialized
INFO - 2023-05-31 07:39:51 --> Input Class Initialized
INFO - 2023-05-31 07:39:51 --> Language Class Initialized
INFO - 2023-05-31 07:39:51 --> Language Class Initialized
INFO - 2023-05-31 07:39:51 --> Loader Class Initialized
INFO - 2023-05-31 07:39:51 --> Controller Class Initialized
INFO - 2023-05-31 07:39:51 --> Loader Class Initialized
DEBUG - 2023-05-31 07:39:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:51 --> Model "Login_model" initialized
INFO - 2023-05-31 07:39:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:51 --> Total execution time: 0.1802
INFO - 2023-05-31 07:39:51 --> Config Class Initialized
INFO - 2023-05-31 07:39:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:51 --> URI Class Initialized
INFO - 2023-05-31 07:39:51 --> Router Class Initialized
INFO - 2023-05-31 07:39:51 --> Output Class Initialized
INFO - 2023-05-31 07:39:51 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:51 --> Input Class Initialized
INFO - 2023-05-31 07:39:51 --> Language Class Initialized
INFO - 2023-05-31 07:39:51 --> Loader Class Initialized
INFO - 2023-05-31 07:39:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:51 --> Total execution time: 0.2206
INFO - 2023-05-31 07:39:56 --> Final output sent to browser
DEBUG - 2023-05-31 07:39:56 --> Total execution time: 12.7710
INFO - 2023-05-31 07:39:56 --> Config Class Initialized
INFO - 2023-05-31 07:39:56 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:39:56 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:39:56 --> Utf8 Class Initialized
INFO - 2023-05-31 07:39:56 --> URI Class Initialized
INFO - 2023-05-31 07:39:56 --> Router Class Initialized
INFO - 2023-05-31 07:39:57 --> Output Class Initialized
INFO - 2023-05-31 07:39:57 --> Security Class Initialized
DEBUG - 2023-05-31 07:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:39:57 --> Input Class Initialized
INFO - 2023-05-31 07:39:57 --> Language Class Initialized
INFO - 2023-05-31 07:39:57 --> Loader Class Initialized
INFO - 2023-05-31 07:39:57 --> Controller Class Initialized
DEBUG - 2023-05-31 07:39:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:39:57 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:39:57 --> Database Driver Class Initialized
INFO - 2023-05-31 07:39:57 --> Model "Login_model" initialized
INFO - 2023-05-31 07:40:00 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:00 --> Total execution time: 9.6539
INFO - 2023-05-31 07:40:01 --> Config Class Initialized
INFO - 2023-05-31 07:40:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:01 --> URI Class Initialized
INFO - 2023-05-31 07:40:01 --> Router Class Initialized
INFO - 2023-05-31 07:40:01 --> Output Class Initialized
INFO - 2023-05-31 07:40:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:01 --> Input Class Initialized
INFO - 2023-05-31 07:40:01 --> Language Class Initialized
INFO - 2023-05-31 07:40:01 --> Loader Class Initialized
INFO - 2023-05-31 07:40:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:01 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:01 --> Total execution time: 0.2021
INFO - 2023-05-31 07:40:01 --> Config Class Initialized
INFO - 2023-05-31 07:40:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:01 --> URI Class Initialized
INFO - 2023-05-31 07:40:01 --> Router Class Initialized
INFO - 2023-05-31 07:40:01 --> Output Class Initialized
INFO - 2023-05-31 07:40:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:01 --> Input Class Initialized
INFO - 2023-05-31 07:40:01 --> Language Class Initialized
INFO - 2023-05-31 07:40:01 --> Loader Class Initialized
INFO - 2023-05-31 07:40:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:01 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:01 --> Total execution time: 0.1949
INFO - 2023-05-31 07:40:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:06 --> Total execution time: 9.9771
INFO - 2023-05-31 07:40:06 --> Config Class Initialized
INFO - 2023-05-31 07:40:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:06 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:06 --> URI Class Initialized
INFO - 2023-05-31 07:40:07 --> Router Class Initialized
INFO - 2023-05-31 07:40:07 --> Output Class Initialized
INFO - 2023-05-31 07:40:07 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:07 --> Input Class Initialized
INFO - 2023-05-31 07:40:07 --> Language Class Initialized
INFO - 2023-05-31 07:40:07 --> Loader Class Initialized
INFO - 2023-05-31 07:40:07 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:07 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:07 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:07 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:07 --> Model "Login_model" initialized
INFO - 2023-05-31 07:40:11 --> Config Class Initialized
INFO - 2023-05-31 07:40:11 --> Config Class Initialized
INFO - 2023-05-31 07:40:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:40:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:40:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:11 --> URI Class Initialized
INFO - 2023-05-31 07:40:11 --> URI Class Initialized
INFO - 2023-05-31 07:40:11 --> Router Class Initialized
INFO - 2023-05-31 07:40:11 --> Router Class Initialized
INFO - 2023-05-31 07:40:11 --> Output Class Initialized
INFO - 2023-05-31 07:40:11 --> Output Class Initialized
INFO - 2023-05-31 07:40:11 --> Security Class Initialized
INFO - 2023-05-31 07:40:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:11 --> Input Class Initialized
INFO - 2023-05-31 07:40:11 --> Input Class Initialized
INFO - 2023-05-31 07:40:11 --> Language Class Initialized
INFO - 2023-05-31 07:40:11 --> Language Class Initialized
INFO - 2023-05-31 07:40:11 --> Loader Class Initialized
INFO - 2023-05-31 07:40:11 --> Loader Class Initialized
INFO - 2023-05-31 07:40:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:11 --> Model "Login_model" initialized
INFO - 2023-05-31 07:40:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:11 --> Total execution time: 0.2229
INFO - 2023-05-31 07:40:11 --> Config Class Initialized
INFO - 2023-05-31 07:40:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:11 --> URI Class Initialized
INFO - 2023-05-31 07:40:11 --> Router Class Initialized
INFO - 2023-05-31 07:40:11 --> Output Class Initialized
INFO - 2023-05-31 07:40:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:11 --> Input Class Initialized
INFO - 2023-05-31 07:40:11 --> Language Class Initialized
INFO - 2023-05-31 07:40:11 --> Loader Class Initialized
INFO - 2023-05-31 07:40:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:11 --> Total execution time: 0.2254
INFO - 2023-05-31 07:40:18 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:18 --> Total execution time: 11.4148
INFO - 2023-05-31 07:40:18 --> Config Class Initialized
INFO - 2023-05-31 07:40:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:18 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:18 --> URI Class Initialized
INFO - 2023-05-31 07:40:18 --> Router Class Initialized
INFO - 2023-05-31 07:40:18 --> Output Class Initialized
INFO - 2023-05-31 07:40:18 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:18 --> Input Class Initialized
INFO - 2023-05-31 07:40:18 --> Language Class Initialized
INFO - 2023-05-31 07:40:18 --> Loader Class Initialized
INFO - 2023-05-31 07:40:18 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:18 --> Model "Login_model" initialized
INFO - 2023-05-31 07:40:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:20 --> Total execution time: 9.1023
INFO - 2023-05-31 07:40:21 --> Config Class Initialized
INFO - 2023-05-31 07:40:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:21 --> URI Class Initialized
INFO - 2023-05-31 07:40:21 --> Router Class Initialized
INFO - 2023-05-31 07:40:21 --> Output Class Initialized
INFO - 2023-05-31 07:40:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:21 --> Input Class Initialized
INFO - 2023-05-31 07:40:21 --> Language Class Initialized
INFO - 2023-05-31 07:40:21 --> Loader Class Initialized
INFO - 2023-05-31 07:40:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:21 --> Total execution time: 0.2163
INFO - 2023-05-31 07:40:21 --> Config Class Initialized
INFO - 2023-05-31 07:40:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:21 --> URI Class Initialized
INFO - 2023-05-31 07:40:21 --> Router Class Initialized
INFO - 2023-05-31 07:40:21 --> Output Class Initialized
INFO - 2023-05-31 07:40:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:21 --> Input Class Initialized
INFO - 2023-05-31 07:40:21 --> Language Class Initialized
INFO - 2023-05-31 07:40:21 --> Loader Class Initialized
INFO - 2023-05-31 07:40:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:21 --> Total execution time: 0.2212
INFO - 2023-05-31 07:40:30 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:30 --> Total execution time: 12.1457
INFO - 2023-05-31 07:40:30 --> Config Class Initialized
INFO - 2023-05-31 07:40:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:30 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:30 --> URI Class Initialized
INFO - 2023-05-31 07:40:30 --> Router Class Initialized
INFO - 2023-05-31 07:40:30 --> Output Class Initialized
INFO - 2023-05-31 07:40:30 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:30 --> Input Class Initialized
INFO - 2023-05-31 07:40:30 --> Language Class Initialized
INFO - 2023-05-31 07:40:30 --> Loader Class Initialized
INFO - 2023-05-31 07:40:30 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:30 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:30 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:30 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:30 --> Model "Login_model" initialized
INFO - 2023-05-31 07:40:31 --> Config Class Initialized
INFO - 2023-05-31 07:40:31 --> Config Class Initialized
INFO - 2023-05-31 07:40:31 --> Hooks Class Initialized
INFO - 2023-05-31 07:40:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:40:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:31 --> URI Class Initialized
INFO - 2023-05-31 07:40:31 --> URI Class Initialized
INFO - 2023-05-31 07:40:31 --> Router Class Initialized
INFO - 2023-05-31 07:40:31 --> Router Class Initialized
INFO - 2023-05-31 07:40:31 --> Output Class Initialized
INFO - 2023-05-31 07:40:31 --> Output Class Initialized
INFO - 2023-05-31 07:40:31 --> Security Class Initialized
INFO - 2023-05-31 07:40:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:31 --> Input Class Initialized
INFO - 2023-05-31 07:40:31 --> Input Class Initialized
INFO - 2023-05-31 07:40:31 --> Language Class Initialized
INFO - 2023-05-31 07:40:31 --> Language Class Initialized
INFO - 2023-05-31 07:40:31 --> Loader Class Initialized
INFO - 2023-05-31 07:40:31 --> Loader Class Initialized
INFO - 2023-05-31 07:40:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:31 --> Model "Login_model" initialized
INFO - 2023-05-31 07:40:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:31 --> Total execution time: 0.2043
INFO - 2023-05-31 07:40:31 --> Config Class Initialized
INFO - 2023-05-31 07:40:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:31 --> URI Class Initialized
INFO - 2023-05-31 07:40:31 --> Router Class Initialized
INFO - 2023-05-31 07:40:31 --> Output Class Initialized
INFO - 2023-05-31 07:40:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:31 --> Input Class Initialized
INFO - 2023-05-31 07:40:31 --> Language Class Initialized
INFO - 2023-05-31 07:40:31 --> Loader Class Initialized
INFO - 2023-05-31 07:40:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:31 --> Total execution time: 0.3386
INFO - 2023-05-31 07:40:39 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:39 --> Total execution time: 9.3992
INFO - 2023-05-31 07:40:40 --> Config Class Initialized
INFO - 2023-05-31 07:40:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:40 --> URI Class Initialized
INFO - 2023-05-31 07:40:40 --> Router Class Initialized
INFO - 2023-05-31 07:40:40 --> Output Class Initialized
INFO - 2023-05-31 07:40:40 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:40 --> Input Class Initialized
INFO - 2023-05-31 07:40:40 --> Language Class Initialized
INFO - 2023-05-31 07:40:40 --> Loader Class Initialized
INFO - 2023-05-31 07:40:40 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:40 --> Model "Login_model" initialized
INFO - 2023-05-31 07:40:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:40 --> Total execution time: 9.0866
INFO - 2023-05-31 07:40:41 --> Config Class Initialized
INFO - 2023-05-31 07:40:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:41 --> URI Class Initialized
INFO - 2023-05-31 07:40:41 --> Router Class Initialized
INFO - 2023-05-31 07:40:41 --> Output Class Initialized
INFO - 2023-05-31 07:40:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:41 --> Input Class Initialized
INFO - 2023-05-31 07:40:41 --> Language Class Initialized
INFO - 2023-05-31 07:40:41 --> Loader Class Initialized
INFO - 2023-05-31 07:40:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:41 --> Total execution time: 0.2422
INFO - 2023-05-31 07:40:41 --> Config Class Initialized
INFO - 2023-05-31 07:40:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:41 --> URI Class Initialized
INFO - 2023-05-31 07:40:41 --> Router Class Initialized
INFO - 2023-05-31 07:40:41 --> Output Class Initialized
INFO - 2023-05-31 07:40:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:41 --> Input Class Initialized
INFO - 2023-05-31 07:40:41 --> Language Class Initialized
INFO - 2023-05-31 07:40:41 --> Loader Class Initialized
INFO - 2023-05-31 07:40:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:41 --> Total execution time: 0.2557
INFO - 2023-05-31 07:40:51 --> Config Class Initialized
INFO - 2023-05-31 07:40:51 --> Hooks Class Initialized
INFO - 2023-05-31 07:40:51 --> Config Class Initialized
INFO - 2023-05-31 07:40:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:51 --> URI Class Initialized
DEBUG - 2023-05-31 07:40:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:51 --> URI Class Initialized
INFO - 2023-05-31 07:40:51 --> Router Class Initialized
INFO - 2023-05-31 07:40:51 --> Output Class Initialized
INFO - 2023-05-31 07:40:51 --> Router Class Initialized
INFO - 2023-05-31 07:40:51 --> Security Class Initialized
INFO - 2023-05-31 07:40:51 --> Output Class Initialized
DEBUG - 2023-05-31 07:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:51 --> Input Class Initialized
INFO - 2023-05-31 07:40:51 --> Security Class Initialized
INFO - 2023-05-31 07:40:51 --> Language Class Initialized
DEBUG - 2023-05-31 07:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:51 --> Input Class Initialized
INFO - 2023-05-31 07:40:51 --> Language Class Initialized
INFO - 2023-05-31 07:40:51 --> Loader Class Initialized
INFO - 2023-05-31 07:40:51 --> Loader Class Initialized
INFO - 2023-05-31 07:40:51 --> Controller Class Initialized
INFO - 2023-05-31 07:40:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:40:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:51 --> Model "Login_model" initialized
INFO - 2023-05-31 07:40:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:51 --> Total execution time: 0.2337
INFO - 2023-05-31 07:40:51 --> Config Class Initialized
INFO - 2023-05-31 07:40:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:51 --> URI Class Initialized
INFO - 2023-05-31 07:40:51 --> Router Class Initialized
INFO - 2023-05-31 07:40:51 --> Output Class Initialized
INFO - 2023-05-31 07:40:51 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:51 --> Input Class Initialized
INFO - 2023-05-31 07:40:51 --> Language Class Initialized
INFO - 2023-05-31 07:40:51 --> Loader Class Initialized
INFO - 2023-05-31 07:40:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:51 --> Total execution time: 0.2195
INFO - 2023-05-31 07:40:53 --> Final output sent to browser
DEBUG - 2023-05-31 07:40:53 --> Total execution time: 13.3463
INFO - 2023-05-31 07:40:53 --> Config Class Initialized
INFO - 2023-05-31 07:40:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:40:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:40:53 --> Utf8 Class Initialized
INFO - 2023-05-31 07:40:53 --> URI Class Initialized
INFO - 2023-05-31 07:40:53 --> Router Class Initialized
INFO - 2023-05-31 07:40:53 --> Output Class Initialized
INFO - 2023-05-31 07:40:53 --> Security Class Initialized
DEBUG - 2023-05-31 07:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:40:53 --> Input Class Initialized
INFO - 2023-05-31 07:40:53 --> Language Class Initialized
INFO - 2023-05-31 07:40:53 --> Loader Class Initialized
INFO - 2023-05-31 07:40:53 --> Controller Class Initialized
DEBUG - 2023-05-31 07:40:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:40:53 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:40:53 --> Database Driver Class Initialized
INFO - 2023-05-31 07:40:53 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:00 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:00 --> Total execution time: 8.9690
INFO - 2023-05-31 07:41:01 --> Config Class Initialized
INFO - 2023-05-31 07:41:01 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:01 --> Config Class Initialized
INFO - 2023-05-31 07:41:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:01 --> URI Class Initialized
DEBUG - 2023-05-31 07:41:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:01 --> Router Class Initialized
INFO - 2023-05-31 07:41:01 --> URI Class Initialized
INFO - 2023-05-31 07:41:01 --> Output Class Initialized
INFO - 2023-05-31 07:41:01 --> Router Class Initialized
INFO - 2023-05-31 07:41:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:01 --> Output Class Initialized
INFO - 2023-05-31 07:41:01 --> Input Class Initialized
INFO - 2023-05-31 07:41:01 --> Language Class Initialized
INFO - 2023-05-31 07:41:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:01 --> Input Class Initialized
INFO - 2023-05-31 07:41:01 --> Language Class Initialized
INFO - 2023-05-31 07:41:01 --> Loader Class Initialized
INFO - 2023-05-31 07:41:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:01 --> Loader Class Initialized
INFO - 2023-05-31 07:41:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:01 --> Final output sent to browser
INFO - 2023-05-31 07:41:01 --> Model "Login_model" initialized
DEBUG - 2023-05-31 07:41:01 --> Total execution time: 0.2634
INFO - 2023-05-31 07:41:01 --> Config Class Initialized
INFO - 2023-05-31 07:41:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:01 --> URI Class Initialized
INFO - 2023-05-31 07:41:01 --> Router Class Initialized
INFO - 2023-05-31 07:41:01 --> Output Class Initialized
INFO - 2023-05-31 07:41:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:01 --> Input Class Initialized
INFO - 2023-05-31 07:41:01 --> Language Class Initialized
INFO - 2023-05-31 07:41:01 --> Loader Class Initialized
INFO - 2023-05-31 07:41:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:01 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:01 --> Total execution time: 0.3833
INFO - 2023-05-31 07:41:03 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:03 --> Total execution time: 9.8165
INFO - 2023-05-31 07:41:03 --> Config Class Initialized
INFO - 2023-05-31 07:41:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:03 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:03 --> URI Class Initialized
INFO - 2023-05-31 07:41:03 --> Router Class Initialized
INFO - 2023-05-31 07:41:03 --> Output Class Initialized
INFO - 2023-05-31 07:41:03 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:03 --> Input Class Initialized
INFO - 2023-05-31 07:41:03 --> Language Class Initialized
INFO - 2023-05-31 07:41:03 --> Loader Class Initialized
INFO - 2023-05-31 07:41:03 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:03 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:03 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:03 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:04 --> Config Class Initialized
INFO - 2023-05-31 07:41:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:04 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:04 --> URI Class Initialized
INFO - 2023-05-31 07:41:04 --> Router Class Initialized
INFO - 2023-05-31 07:41:04 --> Output Class Initialized
INFO - 2023-05-31 07:41:04 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:04 --> Input Class Initialized
INFO - 2023-05-31 07:41:04 --> Language Class Initialized
INFO - 2023-05-31 07:41:04 --> Loader Class Initialized
INFO - 2023-05-31 07:41:04 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:04 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:04 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:04 --> Total execution time: 0.2759
INFO - 2023-05-31 07:41:04 --> Config Class Initialized
INFO - 2023-05-31 07:41:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:04 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:04 --> URI Class Initialized
INFO - 2023-05-31 07:41:04 --> Router Class Initialized
INFO - 2023-05-31 07:41:04 --> Output Class Initialized
INFO - 2023-05-31 07:41:04 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:04 --> Input Class Initialized
INFO - 2023-05-31 07:41:04 --> Language Class Initialized
INFO - 2023-05-31 07:41:04 --> Loader Class Initialized
INFO - 2023-05-31 07:41:04 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:04 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:04 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:04 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:05 --> Total execution time: 0.4690
INFO - 2023-05-31 07:41:05 --> Config Class Initialized
INFO - 2023-05-31 07:41:05 --> Config Class Initialized
INFO - 2023-05-31 07:41:05 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:05 --> URI Class Initialized
INFO - 2023-05-31 07:41:05 --> URI Class Initialized
INFO - 2023-05-31 07:41:05 --> Router Class Initialized
INFO - 2023-05-31 07:41:05 --> Router Class Initialized
INFO - 2023-05-31 07:41:05 --> Output Class Initialized
INFO - 2023-05-31 07:41:05 --> Output Class Initialized
INFO - 2023-05-31 07:41:05 --> Security Class Initialized
INFO - 2023-05-31 07:41:05 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:05 --> Input Class Initialized
INFO - 2023-05-31 07:41:05 --> Input Class Initialized
INFO - 2023-05-31 07:41:05 --> Language Class Initialized
INFO - 2023-05-31 07:41:05 --> Language Class Initialized
INFO - 2023-05-31 07:41:05 --> Loader Class Initialized
INFO - 2023-05-31 07:41:05 --> Loader Class Initialized
INFO - 2023-05-31 07:41:05 --> Controller Class Initialized
INFO - 2023-05-31 07:41:05 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:41:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:05 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:05 --> Total execution time: 0.2194
INFO - 2023-05-31 07:41:05 --> Config Class Initialized
INFO - 2023-05-31 07:41:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:05 --> URI Class Initialized
INFO - 2023-05-31 07:41:05 --> Router Class Initialized
INFO - 2023-05-31 07:41:05 --> Final output sent to browser
INFO - 2023-05-31 07:41:05 --> Output Class Initialized
DEBUG - 2023-05-31 07:41:05 --> Total execution time: 0.3266
INFO - 2023-05-31 07:41:05 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:05 --> Input Class Initialized
INFO - 2023-05-31 07:41:05 --> Language Class Initialized
INFO - 2023-05-31 07:41:05 --> Config Class Initialized
INFO - 2023-05-31 07:41:05 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:05 --> Loader Class Initialized
INFO - 2023-05-31 07:41:05 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:05 --> URI Class Initialized
INFO - 2023-05-31 07:41:05 --> Router Class Initialized
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:05 --> Output Class Initialized
INFO - 2023-05-31 07:41:05 --> Security Class Initialized
INFO - 2023-05-31 07:41:05 --> Model "Cluster_model" initialized
DEBUG - 2023-05-31 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:05 --> Input Class Initialized
INFO - 2023-05-31 07:41:05 --> Language Class Initialized
INFO - 2023-05-31 07:41:05 --> Loader Class Initialized
INFO - 2023-05-31 07:41:05 --> Controller Class Initialized
INFO - 2023-05-31 07:41:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:41:05 --> Total execution time: 0.2403
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:05 --> Config Class Initialized
INFO - 2023-05-31 07:41:05 --> Config Class Initialized
INFO - 2023-05-31 07:41:05 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:05 --> URI Class Initialized
INFO - 2023-05-31 07:41:05 --> URI Class Initialized
INFO - 2023-05-31 07:41:05 --> Router Class Initialized
INFO - 2023-05-31 07:41:05 --> Router Class Initialized
INFO - 2023-05-31 07:41:05 --> Output Class Initialized
INFO - 2023-05-31 07:41:05 --> Output Class Initialized
INFO - 2023-05-31 07:41:05 --> Security Class Initialized
INFO - 2023-05-31 07:41:05 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:05 --> Input Class Initialized
INFO - 2023-05-31 07:41:05 --> Input Class Initialized
INFO - 2023-05-31 07:41:05 --> Language Class Initialized
INFO - 2023-05-31 07:41:05 --> Language Class Initialized
INFO - 2023-05-31 07:41:05 --> Loader Class Initialized
INFO - 2023-05-31 07:41:05 --> Loader Class Initialized
INFO - 2023-05-31 07:41:05 --> Controller Class Initialized
INFO - 2023-05-31 07:41:05 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:41:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:05 --> Total execution time: 0.3247
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:05 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:05 --> Config Class Initialized
INFO - 2023-05-31 07:41:05 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:05 --> Total execution time: 0.2188
DEBUG - 2023-05-31 07:41:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:05 --> URI Class Initialized
INFO - 2023-05-31 07:41:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:05 --> Total execution time: 0.2613
INFO - 2023-05-31 07:41:05 --> Router Class Initialized
INFO - 2023-05-31 07:41:05 --> Output Class Initialized
INFO - 2023-05-31 07:41:05 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:05 --> Input Class Initialized
INFO - 2023-05-31 07:41:05 --> Language Class Initialized
INFO - 2023-05-31 07:41:05 --> Loader Class Initialized
INFO - 2023-05-31 07:41:05 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:06 --> Total execution time: 0.2553
INFO - 2023-05-31 07:41:10 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:10 --> Total execution time: 9.0060
INFO - 2023-05-31 07:41:11 --> Config Class Initialized
INFO - 2023-05-31 07:41:11 --> Config Class Initialized
INFO - 2023-05-31 07:41:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:11 --> URI Class Initialized
INFO - 2023-05-31 07:41:11 --> URI Class Initialized
INFO - 2023-05-31 07:41:11 --> Router Class Initialized
INFO - 2023-05-31 07:41:11 --> Router Class Initialized
INFO - 2023-05-31 07:41:11 --> Output Class Initialized
INFO - 2023-05-31 07:41:11 --> Output Class Initialized
INFO - 2023-05-31 07:41:11 --> Security Class Initialized
INFO - 2023-05-31 07:41:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:11 --> Input Class Initialized
INFO - 2023-05-31 07:41:11 --> Input Class Initialized
INFO - 2023-05-31 07:41:11 --> Language Class Initialized
INFO - 2023-05-31 07:41:11 --> Language Class Initialized
INFO - 2023-05-31 07:41:11 --> Loader Class Initialized
INFO - 2023-05-31 07:41:11 --> Loader Class Initialized
INFO - 2023-05-31 07:41:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:11 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:11 --> Total execution time: 0.2638
INFO - 2023-05-31 07:41:11 --> Config Class Initialized
INFO - 2023-05-31 07:41:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:11 --> URI Class Initialized
INFO - 2023-05-31 07:41:11 --> Router Class Initialized
INFO - 2023-05-31 07:41:11 --> Output Class Initialized
INFO - 2023-05-31 07:41:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:11 --> Input Class Initialized
INFO - 2023-05-31 07:41:11 --> Language Class Initialized
INFO - 2023-05-31 07:41:11 --> Loader Class Initialized
INFO - 2023-05-31 07:41:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:11 --> Total execution time: 0.2727
INFO - 2023-05-31 07:41:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:11 --> Total execution time: 8.7084
INFO - 2023-05-31 07:41:11 --> Config Class Initialized
INFO - 2023-05-31 07:41:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:12 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:12 --> URI Class Initialized
INFO - 2023-05-31 07:41:12 --> Router Class Initialized
INFO - 2023-05-31 07:41:12 --> Output Class Initialized
INFO - 2023-05-31 07:41:12 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:12 --> Input Class Initialized
INFO - 2023-05-31 07:41:12 --> Language Class Initialized
INFO - 2023-05-31 07:41:12 --> Loader Class Initialized
INFO - 2023-05-31 07:41:12 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:12 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:12 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:12 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:16 --> Config Class Initialized
INFO - 2023-05-31 07:41:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:16 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:16 --> URI Class Initialized
INFO - 2023-05-31 07:41:16 --> Router Class Initialized
INFO - 2023-05-31 07:41:16 --> Output Class Initialized
INFO - 2023-05-31 07:41:16 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:16 --> Input Class Initialized
INFO - 2023-05-31 07:41:16 --> Language Class Initialized
INFO - 2023-05-31 07:41:16 --> Loader Class Initialized
INFO - 2023-05-31 07:41:16 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:16 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:16 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:16 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:16 --> Total execution time: 0.2353
INFO - 2023-05-31 07:41:16 --> Config Class Initialized
INFO - 2023-05-31 07:41:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:16 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:16 --> URI Class Initialized
INFO - 2023-05-31 07:41:17 --> Router Class Initialized
INFO - 2023-05-31 07:41:17 --> Output Class Initialized
INFO - 2023-05-31 07:41:17 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:17 --> Input Class Initialized
INFO - 2023-05-31 07:41:17 --> Language Class Initialized
INFO - 2023-05-31 07:41:17 --> Loader Class Initialized
INFO - 2023-05-31 07:41:17 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:17 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:17 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:17 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:17 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:18 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:18 --> Total execution time: 1.3913
INFO - 2023-05-31 07:41:18 --> Config Class Initialized
INFO - 2023-05-31 07:41:18 --> Config Class Initialized
INFO - 2023-05-31 07:41:18 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:18 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:18 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:18 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:18 --> URI Class Initialized
INFO - 2023-05-31 07:41:18 --> URI Class Initialized
INFO - 2023-05-31 07:41:18 --> Router Class Initialized
INFO - 2023-05-31 07:41:18 --> Router Class Initialized
INFO - 2023-05-31 07:41:18 --> Output Class Initialized
INFO - 2023-05-31 07:41:18 --> Output Class Initialized
INFO - 2023-05-31 07:41:18 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:18 --> Security Class Initialized
INFO - 2023-05-31 07:41:18 --> Input Class Initialized
DEBUG - 2023-05-31 07:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:18 --> Language Class Initialized
INFO - 2023-05-31 07:41:18 --> Input Class Initialized
INFO - 2023-05-31 07:41:18 --> Language Class Initialized
INFO - 2023-05-31 07:41:18 --> Loader Class Initialized
INFO - 2023-05-31 07:41:18 --> Loader Class Initialized
INFO - 2023-05-31 07:41:18 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:18 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:18 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:18 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:18 --> Total execution time: 0.2265
INFO - 2023-05-31 07:41:18 --> Config Class Initialized
INFO - 2023-05-31 07:41:18 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:18 --> Config Class Initialized
INFO - 2023-05-31 07:41:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:18 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:18 --> URI Class Initialized
DEBUG - 2023-05-31 07:41:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:18 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:18 --> URI Class Initialized
INFO - 2023-05-31 07:41:18 --> Router Class Initialized
INFO - 2023-05-31 07:41:18 --> Router Class Initialized
INFO - 2023-05-31 07:41:18 --> Output Class Initialized
INFO - 2023-05-31 07:41:18 --> Output Class Initialized
INFO - 2023-05-31 07:41:18 --> Security Class Initialized
INFO - 2023-05-31 07:41:18 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:18 --> Input Class Initialized
INFO - 2023-05-31 07:41:18 --> Input Class Initialized
INFO - 2023-05-31 07:41:18 --> Language Class Initialized
INFO - 2023-05-31 07:41:18 --> Language Class Initialized
INFO - 2023-05-31 07:41:18 --> Loader Class Initialized
INFO - 2023-05-31 07:41:18 --> Controller Class Initialized
INFO - 2023-05-31 07:41:18 --> Loader Class Initialized
DEBUG - 2023-05-31 07:41:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:18 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:18 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:18 --> Total execution time: 0.4496
INFO - 2023-05-31 07:41:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:18 --> Config Class Initialized
INFO - 2023-05-31 07:41:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:18 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:18 --> URI Class Initialized
INFO - 2023-05-31 07:41:18 --> Router Class Initialized
INFO - 2023-05-31 07:41:18 --> Output Class Initialized
INFO - 2023-05-31 07:41:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:18 --> Security Class Initialized
INFO - 2023-05-31 07:41:18 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:18 --> Total execution time: 0.3562
DEBUG - 2023-05-31 07:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:18 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:18 --> Input Class Initialized
INFO - 2023-05-31 07:41:18 --> Language Class Initialized
INFO - 2023-05-31 07:41:19 --> Loader Class Initialized
INFO - 2023-05-31 07:41:19 --> Controller Class Initialized
INFO - 2023-05-31 07:41:19 --> Config Class Initialized
INFO - 2023-05-31 07:41:19 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:41:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:19 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:19 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:19 --> URI Class Initialized
INFO - 2023-05-31 07:41:19 --> Router Class Initialized
INFO - 2023-05-31 07:41:19 --> Output Class Initialized
INFO - 2023-05-31 07:41:19 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:19 --> Input Class Initialized
INFO - 2023-05-31 07:41:19 --> Language Class Initialized
INFO - 2023-05-31 07:41:19 --> Loader Class Initialized
INFO - 2023-05-31 07:41:19 --> Controller Class Initialized
INFO - 2023-05-31 07:41:19 --> Database Driver Class Initialized
DEBUG - 2023-05-31 07:41:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:19 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:19 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:19 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:19 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:19 --> Total execution time: 0.4092
INFO - 2023-05-31 07:41:19 --> Config Class Initialized
INFO - 2023-05-31 07:41:19 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:19 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:19 --> URI Class Initialized
INFO - 2023-05-31 07:41:19 --> Router Class Initialized
INFO - 2023-05-31 07:41:19 --> Output Class Initialized
INFO - 2023-05-31 07:41:19 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:19 --> Input Class Initialized
INFO - 2023-05-31 07:41:19 --> Language Class Initialized
INFO - 2023-05-31 07:41:19 --> Loader Class Initialized
INFO - 2023-05-31 07:41:19 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:19 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:19 --> Total execution time: 0.4627
INFO - 2023-05-31 07:41:19 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:19 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:19 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:19 --> Total execution time: 0.3557
INFO - 2023-05-31 07:41:19 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:19 --> Total execution time: 1.2009
INFO - 2023-05-31 07:41:19 --> Config Class Initialized
INFO - 2023-05-31 07:41:19 --> Config Class Initialized
INFO - 2023-05-31 07:41:19 --> Config Class Initialized
INFO - 2023-05-31 07:41:19 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:19 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:19 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:19 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:19 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:19 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:19 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:19 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:19 --> URI Class Initialized
INFO - 2023-05-31 07:41:19 --> URI Class Initialized
INFO - 2023-05-31 07:41:19 --> URI Class Initialized
INFO - 2023-05-31 07:41:19 --> Router Class Initialized
INFO - 2023-05-31 07:41:19 --> Router Class Initialized
INFO - 2023-05-31 07:41:19 --> Router Class Initialized
INFO - 2023-05-31 07:41:19 --> Output Class Initialized
INFO - 2023-05-31 07:41:19 --> Output Class Initialized
INFO - 2023-05-31 07:41:19 --> Output Class Initialized
INFO - 2023-05-31 07:41:19 --> Security Class Initialized
INFO - 2023-05-31 07:41:19 --> Security Class Initialized
INFO - 2023-05-31 07:41:19 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:19 --> Input Class Initialized
INFO - 2023-05-31 07:41:19 --> Input Class Initialized
INFO - 2023-05-31 07:41:19 --> Input Class Initialized
INFO - 2023-05-31 07:41:19 --> Language Class Initialized
INFO - 2023-05-31 07:41:19 --> Language Class Initialized
INFO - 2023-05-31 07:41:19 --> Language Class Initialized
INFO - 2023-05-31 07:41:19 --> Loader Class Initialized
INFO - 2023-05-31 07:41:19 --> Loader Class Initialized
INFO - 2023-05-31 07:41:19 --> Loader Class Initialized
INFO - 2023-05-31 07:41:19 --> Controller Class Initialized
INFO - 2023-05-31 07:41:19 --> Controller Class Initialized
INFO - 2023-05-31 07:41:19 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:41:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:41:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:20 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:20 --> Total execution time: 0.2410
INFO - 2023-05-31 07:41:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:20 --> Total execution time: 0.2760
INFO - 2023-05-31 07:41:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:20 --> Total execution time: 0.2938
INFO - 2023-05-31 07:41:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:20 --> Total execution time: 9.4297
INFO - 2023-05-31 07:41:21 --> Config Class Initialized
INFO - 2023-05-31 07:41:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:21 --> URI Class Initialized
INFO - 2023-05-31 07:41:21 --> Router Class Initialized
INFO - 2023-05-31 07:41:21 --> Output Class Initialized
INFO - 2023-05-31 07:41:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:21 --> Input Class Initialized
INFO - 2023-05-31 07:41:21 --> Language Class Initialized
INFO - 2023-05-31 07:41:21 --> Loader Class Initialized
INFO - 2023-05-31 07:41:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:21 --> Total execution time: 0.3011
INFO - 2023-05-31 07:41:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:21 --> Total execution time: 9.8225
INFO - 2023-05-31 07:41:21 --> Config Class Initialized
INFO - 2023-05-31 07:41:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:21 --> URI Class Initialized
INFO - 2023-05-31 07:41:21 --> Router Class Initialized
INFO - 2023-05-31 07:41:21 --> Output Class Initialized
INFO - 2023-05-31 07:41:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:21 --> Input Class Initialized
INFO - 2023-05-31 07:41:21 --> Language Class Initialized
INFO - 2023-05-31 07:41:21 --> Loader Class Initialized
INFO - 2023-05-31 07:41:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:22 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:22 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:31 --> Config Class Initialized
INFO - 2023-05-31 07:41:31 --> Config Class Initialized
INFO - 2023-05-31 07:41:31 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:31 --> URI Class Initialized
INFO - 2023-05-31 07:41:31 --> URI Class Initialized
INFO - 2023-05-31 07:41:31 --> Router Class Initialized
INFO - 2023-05-31 07:41:31 --> Router Class Initialized
INFO - 2023-05-31 07:41:31 --> Output Class Initialized
INFO - 2023-05-31 07:41:31 --> Output Class Initialized
INFO - 2023-05-31 07:41:31 --> Security Class Initialized
INFO - 2023-05-31 07:41:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:31 --> Input Class Initialized
INFO - 2023-05-31 07:41:31 --> Input Class Initialized
INFO - 2023-05-31 07:41:31 --> Language Class Initialized
INFO - 2023-05-31 07:41:31 --> Language Class Initialized
INFO - 2023-05-31 07:41:31 --> Loader Class Initialized
INFO - 2023-05-31 07:41:31 --> Loader Class Initialized
INFO - 2023-05-31 07:41:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:31 --> Total execution time: 0.1906
INFO - 2023-05-31 07:41:31 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:31 --> Config Class Initialized
INFO - 2023-05-31 07:41:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:31 --> URI Class Initialized
INFO - 2023-05-31 07:41:31 --> Router Class Initialized
INFO - 2023-05-31 07:41:31 --> Output Class Initialized
INFO - 2023-05-31 07:41:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:31 --> Input Class Initialized
INFO - 2023-05-31 07:41:31 --> Language Class Initialized
INFO - 2023-05-31 07:41:31 --> Loader Class Initialized
INFO - 2023-05-31 07:41:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:31 --> Total execution time: 0.2478
INFO - 2023-05-31 07:41:33 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:33 --> Total execution time: 12.0311
INFO - 2023-05-31 07:41:33 --> Config Class Initialized
INFO - 2023-05-31 07:41:33 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:33 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:33 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:33 --> URI Class Initialized
INFO - 2023-05-31 07:41:33 --> Router Class Initialized
INFO - 2023-05-31 07:41:33 --> Output Class Initialized
INFO - 2023-05-31 07:41:33 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:33 --> Input Class Initialized
INFO - 2023-05-31 07:41:33 --> Language Class Initialized
INFO - 2023-05-31 07:41:34 --> Loader Class Initialized
INFO - 2023-05-31 07:41:34 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:34 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:34 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:34 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:34 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:40 --> Total execution time: 9.7106
INFO - 2023-05-31 07:41:41 --> Config Class Initialized
INFO - 2023-05-31 07:41:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:41 --> URI Class Initialized
INFO - 2023-05-31 07:41:41 --> Router Class Initialized
INFO - 2023-05-31 07:41:41 --> Output Class Initialized
INFO - 2023-05-31 07:41:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:41 --> Input Class Initialized
INFO - 2023-05-31 07:41:41 --> Language Class Initialized
INFO - 2023-05-31 07:41:41 --> Loader Class Initialized
INFO - 2023-05-31 07:41:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:41 --> Total execution time: 0.3517
INFO - 2023-05-31 07:41:41 --> Config Class Initialized
INFO - 2023-05-31 07:41:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:41 --> URI Class Initialized
INFO - 2023-05-31 07:41:41 --> Router Class Initialized
INFO - 2023-05-31 07:41:41 --> Output Class Initialized
INFO - 2023-05-31 07:41:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:41 --> Input Class Initialized
INFO - 2023-05-31 07:41:41 --> Language Class Initialized
INFO - 2023-05-31 07:41:41 --> Loader Class Initialized
INFO - 2023-05-31 07:41:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:41 --> Total execution time: 0.3024
INFO - 2023-05-31 07:41:45 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:45 --> Total execution time: 11.7142
INFO - 2023-05-31 07:41:45 --> Config Class Initialized
INFO - 2023-05-31 07:41:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:45 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:45 --> URI Class Initialized
INFO - 2023-05-31 07:41:45 --> Router Class Initialized
INFO - 2023-05-31 07:41:45 --> Output Class Initialized
INFO - 2023-05-31 07:41:45 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:45 --> Input Class Initialized
INFO - 2023-05-31 07:41:45 --> Language Class Initialized
INFO - 2023-05-31 07:41:45 --> Loader Class Initialized
INFO - 2023-05-31 07:41:45 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:45 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:45 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:45 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:51 --> Config Class Initialized
INFO - 2023-05-31 07:41:51 --> Config Class Initialized
INFO - 2023-05-31 07:41:51 --> Hooks Class Initialized
INFO - 2023-05-31 07:41:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:41:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:51 --> URI Class Initialized
INFO - 2023-05-31 07:41:51 --> URI Class Initialized
INFO - 2023-05-31 07:41:51 --> Router Class Initialized
INFO - 2023-05-31 07:41:51 --> Router Class Initialized
INFO - 2023-05-31 07:41:51 --> Output Class Initialized
INFO - 2023-05-31 07:41:51 --> Output Class Initialized
INFO - 2023-05-31 07:41:51 --> Security Class Initialized
INFO - 2023-05-31 07:41:51 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:51 --> Input Class Initialized
INFO - 2023-05-31 07:41:51 --> Input Class Initialized
INFO - 2023-05-31 07:41:51 --> Language Class Initialized
INFO - 2023-05-31 07:41:51 --> Language Class Initialized
INFO - 2023-05-31 07:41:51 --> Loader Class Initialized
INFO - 2023-05-31 07:41:51 --> Loader Class Initialized
INFO - 2023-05-31 07:41:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:51 --> Model "Login_model" initialized
INFO - 2023-05-31 07:41:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:51 --> Total execution time: 0.1903
INFO - 2023-05-31 07:41:51 --> Config Class Initialized
INFO - 2023-05-31 07:41:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:51 --> URI Class Initialized
INFO - 2023-05-31 07:41:51 --> Router Class Initialized
INFO - 2023-05-31 07:41:51 --> Output Class Initialized
INFO - 2023-05-31 07:41:51 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:51 --> Input Class Initialized
INFO - 2023-05-31 07:41:51 --> Language Class Initialized
INFO - 2023-05-31 07:41:51 --> Loader Class Initialized
INFO - 2023-05-31 07:41:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:51 --> Total execution time: 0.2130
INFO - 2023-05-31 07:41:57 --> Final output sent to browser
DEBUG - 2023-05-31 07:41:57 --> Total execution time: 11.6038
INFO - 2023-05-31 07:41:57 --> Config Class Initialized
INFO - 2023-05-31 07:41:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:41:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:41:57 --> Utf8 Class Initialized
INFO - 2023-05-31 07:41:57 --> URI Class Initialized
INFO - 2023-05-31 07:41:57 --> Router Class Initialized
INFO - 2023-05-31 07:41:57 --> Output Class Initialized
INFO - 2023-05-31 07:41:57 --> Security Class Initialized
DEBUG - 2023-05-31 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:41:57 --> Input Class Initialized
INFO - 2023-05-31 07:41:57 --> Language Class Initialized
INFO - 2023-05-31 07:41:57 --> Loader Class Initialized
INFO - 2023-05-31 07:41:57 --> Controller Class Initialized
DEBUG - 2023-05-31 07:41:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:41:57 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:41:57 --> Database Driver Class Initialized
INFO - 2023-05-31 07:41:57 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:00 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:00 --> Total execution time: 9.2508
INFO - 2023-05-31 07:42:01 --> Config Class Initialized
INFO - 2023-05-31 07:42:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:01 --> URI Class Initialized
INFO - 2023-05-31 07:42:01 --> Router Class Initialized
INFO - 2023-05-31 07:42:01 --> Output Class Initialized
INFO - 2023-05-31 07:42:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:01 --> Input Class Initialized
INFO - 2023-05-31 07:42:01 --> Language Class Initialized
INFO - 2023-05-31 07:42:01 --> Loader Class Initialized
INFO - 2023-05-31 07:42:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:01 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:01 --> Total execution time: 0.2080
INFO - 2023-05-31 07:42:01 --> Config Class Initialized
INFO - 2023-05-31 07:42:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:01 --> URI Class Initialized
INFO - 2023-05-31 07:42:01 --> Router Class Initialized
INFO - 2023-05-31 07:42:01 --> Output Class Initialized
INFO - 2023-05-31 07:42:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:01 --> Input Class Initialized
INFO - 2023-05-31 07:42:01 --> Language Class Initialized
INFO - 2023-05-31 07:42:01 --> Loader Class Initialized
INFO - 2023-05-31 07:42:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:01 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:01 --> Total execution time: 0.2013
INFO - 2023-05-31 07:42:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:06 --> Total execution time: 8.7092
INFO - 2023-05-31 07:42:06 --> Config Class Initialized
INFO - 2023-05-31 07:42:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:06 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:06 --> URI Class Initialized
INFO - 2023-05-31 07:42:06 --> Router Class Initialized
INFO - 2023-05-31 07:42:06 --> Output Class Initialized
INFO - 2023-05-31 07:42:06 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:06 --> Input Class Initialized
INFO - 2023-05-31 07:42:06 --> Language Class Initialized
INFO - 2023-05-31 07:42:06 --> Loader Class Initialized
INFO - 2023-05-31 07:42:06 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:06 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:11 --> Config Class Initialized
INFO - 2023-05-31 07:42:11 --> Config Class Initialized
INFO - 2023-05-31 07:42:11 --> Hooks Class Initialized
INFO - 2023-05-31 07:42:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:42:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:11 --> URI Class Initialized
INFO - 2023-05-31 07:42:11 --> URI Class Initialized
INFO - 2023-05-31 07:42:11 --> Router Class Initialized
INFO - 2023-05-31 07:42:11 --> Router Class Initialized
INFO - 2023-05-31 07:42:11 --> Output Class Initialized
INFO - 2023-05-31 07:42:11 --> Output Class Initialized
INFO - 2023-05-31 07:42:11 --> Security Class Initialized
INFO - 2023-05-31 07:42:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:11 --> Input Class Initialized
INFO - 2023-05-31 07:42:11 --> Input Class Initialized
INFO - 2023-05-31 07:42:11 --> Language Class Initialized
INFO - 2023-05-31 07:42:11 --> Language Class Initialized
INFO - 2023-05-31 07:42:11 --> Loader Class Initialized
INFO - 2023-05-31 07:42:11 --> Loader Class Initialized
INFO - 2023-05-31 07:42:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:11 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:11 --> Total execution time: 0.2471
INFO - 2023-05-31 07:42:11 --> Config Class Initialized
INFO - 2023-05-31 07:42:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:11 --> URI Class Initialized
INFO - 2023-05-31 07:42:11 --> Router Class Initialized
INFO - 2023-05-31 07:42:11 --> Output Class Initialized
INFO - 2023-05-31 07:42:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:11 --> Input Class Initialized
INFO - 2023-05-31 07:42:11 --> Language Class Initialized
INFO - 2023-05-31 07:42:11 --> Loader Class Initialized
INFO - 2023-05-31 07:42:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:11 --> Total execution time: 0.2106
INFO - 2023-05-31 07:42:16 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:16 --> Total execution time: 10.8536
INFO - 2023-05-31 07:42:16 --> Config Class Initialized
INFO - 2023-05-31 07:42:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:16 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:16 --> URI Class Initialized
INFO - 2023-05-31 07:42:16 --> Router Class Initialized
INFO - 2023-05-31 07:42:16 --> Output Class Initialized
INFO - 2023-05-31 07:42:17 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:17 --> Input Class Initialized
INFO - 2023-05-31 07:42:17 --> Language Class Initialized
INFO - 2023-05-31 07:42:17 --> Loader Class Initialized
INFO - 2023-05-31 07:42:17 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:17 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:17 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:17 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:17 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:21 --> Total execution time: 9.8476
INFO - 2023-05-31 07:42:21 --> Config Class Initialized
INFO - 2023-05-31 07:42:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:21 --> URI Class Initialized
INFO - 2023-05-31 07:42:21 --> Router Class Initialized
INFO - 2023-05-31 07:42:21 --> Output Class Initialized
INFO - 2023-05-31 07:42:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:21 --> Input Class Initialized
INFO - 2023-05-31 07:42:21 --> Language Class Initialized
INFO - 2023-05-31 07:42:21 --> Loader Class Initialized
INFO - 2023-05-31 07:42:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:21 --> Total execution time: 0.2089
INFO - 2023-05-31 07:42:21 --> Config Class Initialized
INFO - 2023-05-31 07:42:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:21 --> URI Class Initialized
INFO - 2023-05-31 07:42:21 --> Router Class Initialized
INFO - 2023-05-31 07:42:21 --> Output Class Initialized
INFO - 2023-05-31 07:42:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:21 --> Input Class Initialized
INFO - 2023-05-31 07:42:21 --> Language Class Initialized
INFO - 2023-05-31 07:42:21 --> Loader Class Initialized
INFO - 2023-05-31 07:42:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:21 --> Total execution time: 0.2077
INFO - 2023-05-31 07:42:29 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:29 --> Total execution time: 12.6183
INFO - 2023-05-31 07:42:29 --> Config Class Initialized
INFO - 2023-05-31 07:42:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:29 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:29 --> URI Class Initialized
INFO - 2023-05-31 07:42:29 --> Router Class Initialized
INFO - 2023-05-31 07:42:29 --> Output Class Initialized
INFO - 2023-05-31 07:42:29 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:29 --> Input Class Initialized
INFO - 2023-05-31 07:42:29 --> Language Class Initialized
INFO - 2023-05-31 07:42:29 --> Loader Class Initialized
INFO - 2023-05-31 07:42:29 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:29 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:31 --> Config Class Initialized
INFO - 2023-05-31 07:42:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:31 --> URI Class Initialized
INFO - 2023-05-31 07:42:31 --> Router Class Initialized
INFO - 2023-05-31 07:42:31 --> Output Class Initialized
INFO - 2023-05-31 07:42:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:31 --> Input Class Initialized
INFO - 2023-05-31 07:42:31 --> Language Class Initialized
INFO - 2023-05-31 07:42:31 --> Loader Class Initialized
INFO - 2023-05-31 07:42:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:31 --> Total execution time: 0.3236
INFO - 2023-05-31 07:42:31 --> Config Class Initialized
INFO - 2023-05-31 07:42:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:31 --> URI Class Initialized
INFO - 2023-05-31 07:42:31 --> Router Class Initialized
INFO - 2023-05-31 07:42:31 --> Output Class Initialized
INFO - 2023-05-31 07:42:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:31 --> Input Class Initialized
INFO - 2023-05-31 07:42:31 --> Language Class Initialized
INFO - 2023-05-31 07:42:31 --> Loader Class Initialized
INFO - 2023-05-31 07:42:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:31 --> Total execution time: 0.2177
INFO - 2023-05-31 07:42:32 --> Config Class Initialized
INFO - 2023-05-31 07:42:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:32 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:32 --> URI Class Initialized
INFO - 2023-05-31 07:42:32 --> Router Class Initialized
INFO - 2023-05-31 07:42:32 --> Output Class Initialized
INFO - 2023-05-31 07:42:32 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:32 --> Input Class Initialized
INFO - 2023-05-31 07:42:32 --> Language Class Initialized
INFO - 2023-05-31 07:42:32 --> Loader Class Initialized
INFO - 2023-05-31 07:42:32 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:32 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:41 --> Config Class Initialized
INFO - 2023-05-31 07:42:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:41 --> URI Class Initialized
INFO - 2023-05-31 07:42:41 --> Router Class Initialized
INFO - 2023-05-31 07:42:41 --> Output Class Initialized
INFO - 2023-05-31 07:42:41 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:41 --> Input Class Initialized
INFO - 2023-05-31 07:42:41 --> Language Class Initialized
INFO - 2023-05-31 07:42:41 --> Loader Class Initialized
INFO - 2023-05-31 07:42:41 --> Controller Class Initialized
INFO - 2023-05-31 07:42:41 --> Config Class Initialized
INFO - 2023-05-31 07:42:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:42:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:41 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:41 --> URI Class Initialized
INFO - 2023-05-31 07:42:41 --> Router Class Initialized
INFO - 2023-05-31 07:42:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:41 --> Output Class Initialized
INFO - 2023-05-31 07:42:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:41 --> Security Class Initialized
INFO - 2023-05-31 07:42:41 --> Model "Login_model" initialized
DEBUG - 2023-05-31 07:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:41 --> Input Class Initialized
INFO - 2023-05-31 07:42:41 --> Language Class Initialized
INFO - 2023-05-31 07:42:41 --> Loader Class Initialized
INFO - 2023-05-31 07:42:41 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:41 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:41 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:41 --> Total execution time: 0.2807
INFO - 2023-05-31 07:42:41 --> Config Class Initialized
INFO - 2023-05-31 07:42:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:42 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:42 --> URI Class Initialized
INFO - 2023-05-31 07:42:42 --> Router Class Initialized
INFO - 2023-05-31 07:42:42 --> Output Class Initialized
INFO - 2023-05-31 07:42:42 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:42 --> Input Class Initialized
INFO - 2023-05-31 07:42:42 --> Language Class Initialized
INFO - 2023-05-31 07:42:42 --> Config Class Initialized
INFO - 2023-05-31 07:42:42 --> Hooks Class Initialized
INFO - 2023-05-31 07:42:42 --> Loader Class Initialized
INFO - 2023-05-31 07:42:42 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:42:42 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:42 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:42 --> URI Class Initialized
INFO - 2023-05-31 07:42:42 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:42 --> Router Class Initialized
INFO - 2023-05-31 07:42:42 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:42 --> Output Class Initialized
INFO - 2023-05-31 07:42:42 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:42 --> Input Class Initialized
INFO - 2023-05-31 07:42:42 --> Language Class Initialized
INFO - 2023-05-31 07:42:42 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:42 --> Total execution time: 1.1078
INFO - 2023-05-31 07:42:42 --> Loader Class Initialized
INFO - 2023-05-31 07:42:42 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:42 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:43 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:43 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:43 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:44 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:44 --> Total execution time: 14.7082
INFO - 2023-05-31 07:42:45 --> Config Class Initialized
INFO - 2023-05-31 07:42:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:45 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:45 --> URI Class Initialized
INFO - 2023-05-31 07:42:45 --> Router Class Initialized
INFO - 2023-05-31 07:42:45 --> Output Class Initialized
INFO - 2023-05-31 07:42:45 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:45 --> Input Class Initialized
INFO - 2023-05-31 07:42:45 --> Language Class Initialized
INFO - 2023-05-31 07:42:45 --> Loader Class Initialized
INFO - 2023-05-31 07:42:45 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:45 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:45 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:45 --> Total execution time: 0.4291
INFO - 2023-05-31 07:42:45 --> Config Class Initialized
INFO - 2023-05-31 07:42:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:45 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:45 --> URI Class Initialized
INFO - 2023-05-31 07:42:45 --> Router Class Initialized
INFO - 2023-05-31 07:42:45 --> Output Class Initialized
INFO - 2023-05-31 07:42:45 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:45 --> Input Class Initialized
INFO - 2023-05-31 07:42:45 --> Language Class Initialized
INFO - 2023-05-31 07:42:45 --> Loader Class Initialized
INFO - 2023-05-31 07:42:45 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:45 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:46 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:46 --> Total execution time: 0.4211
INFO - 2023-05-31 07:42:46 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:46 --> Total execution time: 13.9608
INFO - 2023-05-31 07:42:46 --> Config Class Initialized
INFO - 2023-05-31 07:42:46 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:46 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:46 --> URI Class Initialized
INFO - 2023-05-31 07:42:46 --> Router Class Initialized
INFO - 2023-05-31 07:42:46 --> Output Class Initialized
INFO - 2023-05-31 07:42:46 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:46 --> Input Class Initialized
INFO - 2023-05-31 07:42:46 --> Language Class Initialized
INFO - 2023-05-31 07:42:46 --> Loader Class Initialized
INFO - 2023-05-31 07:42:46 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:46 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:46 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:46 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:51 --> Config Class Initialized
INFO - 2023-05-31 07:42:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:51 --> URI Class Initialized
INFO - 2023-05-31 07:42:51 --> Router Class Initialized
INFO - 2023-05-31 07:42:51 --> Output Class Initialized
INFO - 2023-05-31 07:42:51 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:51 --> Input Class Initialized
INFO - 2023-05-31 07:42:51 --> Language Class Initialized
INFO - 2023-05-31 07:42:51 --> Loader Class Initialized
INFO - 2023-05-31 07:42:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:51 --> Total execution time: 0.2233
INFO - 2023-05-31 07:42:51 --> Config Class Initialized
INFO - 2023-05-31 07:42:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:51 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:51 --> URI Class Initialized
INFO - 2023-05-31 07:42:51 --> Router Class Initialized
INFO - 2023-05-31 07:42:51 --> Output Class Initialized
INFO - 2023-05-31 07:42:51 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:51 --> Input Class Initialized
INFO - 2023-05-31 07:42:51 --> Language Class Initialized
INFO - 2023-05-31 07:42:51 --> Loader Class Initialized
INFO - 2023-05-31 07:42:51 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:51 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:51 --> Total execution time: 0.3867
INFO - 2023-05-31 07:42:52 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:52 --> Total execution time: 11.0796
INFO - 2023-05-31 07:42:52 --> Config Class Initialized
INFO - 2023-05-31 07:42:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:52 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:52 --> URI Class Initialized
INFO - 2023-05-31 07:42:52 --> Router Class Initialized
INFO - 2023-05-31 07:42:52 --> Output Class Initialized
INFO - 2023-05-31 07:42:52 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:52 --> Input Class Initialized
INFO - 2023-05-31 07:42:52 --> Language Class Initialized
INFO - 2023-05-31 07:42:52 --> Loader Class Initialized
INFO - 2023-05-31 07:42:52 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:52 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:52 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:52 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:52 --> Model "Login_model" initialized
INFO - 2023-05-31 07:42:53 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:53 --> Total execution time: 10.7029
INFO - 2023-05-31 07:42:55 --> Final output sent to browser
DEBUG - 2023-05-31 07:42:55 --> Total execution time: 9.6331
INFO - 2023-05-31 07:42:55 --> Config Class Initialized
INFO - 2023-05-31 07:42:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:42:56 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:42:56 --> Utf8 Class Initialized
INFO - 2023-05-31 07:42:56 --> URI Class Initialized
INFO - 2023-05-31 07:42:56 --> Router Class Initialized
INFO - 2023-05-31 07:42:56 --> Output Class Initialized
INFO - 2023-05-31 07:42:56 --> Security Class Initialized
DEBUG - 2023-05-31 07:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:42:56 --> Input Class Initialized
INFO - 2023-05-31 07:42:56 --> Language Class Initialized
INFO - 2023-05-31 07:42:56 --> Loader Class Initialized
INFO - 2023-05-31 07:42:56 --> Controller Class Initialized
DEBUG - 2023-05-31 07:42:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:42:56 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:56 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:42:56 --> Database Driver Class Initialized
INFO - 2023-05-31 07:42:56 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:01 --> Config Class Initialized
INFO - 2023-05-31 07:43:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:01 --> URI Class Initialized
INFO - 2023-05-31 07:43:01 --> Router Class Initialized
INFO - 2023-05-31 07:43:01 --> Output Class Initialized
INFO - 2023-05-31 07:43:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:01 --> Input Class Initialized
INFO - 2023-05-31 07:43:01 --> Language Class Initialized
INFO - 2023-05-31 07:43:01 --> Loader Class Initialized
INFO - 2023-05-31 07:43:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:01 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:01 --> Total execution time: 0.1988
INFO - 2023-05-31 07:43:01 --> Config Class Initialized
INFO - 2023-05-31 07:43:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:01 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:01 --> URI Class Initialized
INFO - 2023-05-31 07:43:01 --> Router Class Initialized
INFO - 2023-05-31 07:43:01 --> Output Class Initialized
INFO - 2023-05-31 07:43:01 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:01 --> Input Class Initialized
INFO - 2023-05-31 07:43:01 --> Language Class Initialized
INFO - 2023-05-31 07:43:01 --> Loader Class Initialized
INFO - 2023-05-31 07:43:01 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:01 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:01 --> Total execution time: 0.2267
INFO - 2023-05-31 07:43:02 --> Config Class Initialized
INFO - 2023-05-31 07:43:02 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:02 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:02 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:02 --> URI Class Initialized
INFO - 2023-05-31 07:43:02 --> Router Class Initialized
INFO - 2023-05-31 07:43:02 --> Output Class Initialized
INFO - 2023-05-31 07:43:02 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:02 --> Input Class Initialized
INFO - 2023-05-31 07:43:02 --> Language Class Initialized
INFO - 2023-05-31 07:43:02 --> Loader Class Initialized
INFO - 2023-05-31 07:43:02 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:02 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:02 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:02 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:02 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:02 --> Total execution time: 10.3983
INFO - 2023-05-31 07:43:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:06 --> Total execution time: 10.5746
INFO - 2023-05-31 07:43:06 --> Config Class Initialized
INFO - 2023-05-31 07:43:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:06 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:06 --> URI Class Initialized
INFO - 2023-05-31 07:43:06 --> Router Class Initialized
INFO - 2023-05-31 07:43:06 --> Output Class Initialized
INFO - 2023-05-31 07:43:06 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:06 --> Input Class Initialized
INFO - 2023-05-31 07:43:06 --> Language Class Initialized
INFO - 2023-05-31 07:43:06 --> Loader Class Initialized
INFO - 2023-05-31 07:43:06 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:07 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:07 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:07 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:11 --> Config Class Initialized
INFO - 2023-05-31 07:43:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:11 --> URI Class Initialized
INFO - 2023-05-31 07:43:11 --> Router Class Initialized
INFO - 2023-05-31 07:43:11 --> Output Class Initialized
INFO - 2023-05-31 07:43:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:11 --> Input Class Initialized
INFO - 2023-05-31 07:43:11 --> Language Class Initialized
INFO - 2023-05-31 07:43:11 --> Loader Class Initialized
INFO - 2023-05-31 07:43:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:11 --> Total execution time: 0.2326
INFO - 2023-05-31 07:43:11 --> Config Class Initialized
INFO - 2023-05-31 07:43:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:11 --> URI Class Initialized
INFO - 2023-05-31 07:43:11 --> Router Class Initialized
INFO - 2023-05-31 07:43:11 --> Output Class Initialized
INFO - 2023-05-31 07:43:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:11 --> Input Class Initialized
INFO - 2023-05-31 07:43:11 --> Language Class Initialized
INFO - 2023-05-31 07:43:11 --> Loader Class Initialized
INFO - 2023-05-31 07:43:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:11 --> Total execution time: 0.2672
INFO - 2023-05-31 07:43:12 --> Config Class Initialized
INFO - 2023-05-31 07:43:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:12 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:12 --> URI Class Initialized
INFO - 2023-05-31 07:43:12 --> Router Class Initialized
INFO - 2023-05-31 07:43:12 --> Output Class Initialized
INFO - 2023-05-31 07:43:12 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:12 --> Input Class Initialized
INFO - 2023-05-31 07:43:12 --> Language Class Initialized
INFO - 2023-05-31 07:43:12 --> Loader Class Initialized
INFO - 2023-05-31 07:43:12 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:12 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:12 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:12 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:12 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:12 --> Total execution time: 10.3104
INFO - 2023-05-31 07:43:16 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:16 --> Total execution time: 10.3507
INFO - 2023-05-31 07:43:17 --> Config Class Initialized
INFO - 2023-05-31 07:43:17 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:17 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:17 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:17 --> URI Class Initialized
INFO - 2023-05-31 07:43:17 --> Router Class Initialized
INFO - 2023-05-31 07:43:17 --> Output Class Initialized
INFO - 2023-05-31 07:43:17 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:17 --> Input Class Initialized
INFO - 2023-05-31 07:43:17 --> Language Class Initialized
INFO - 2023-05-31 07:43:17 --> Loader Class Initialized
INFO - 2023-05-31 07:43:17 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:17 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:17 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:17 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:17 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:20 --> Config Class Initialized
INFO - 2023-05-31 07:43:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:20 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:20 --> URI Class Initialized
INFO - 2023-05-31 07:43:20 --> Router Class Initialized
INFO - 2023-05-31 07:43:20 --> Output Class Initialized
INFO - 2023-05-31 07:43:20 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:20 --> Input Class Initialized
INFO - 2023-05-31 07:43:20 --> Language Class Initialized
INFO - 2023-05-31 07:43:20 --> Loader Class Initialized
INFO - 2023-05-31 07:43:20 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:20 --> Total execution time: 0.3351
INFO - 2023-05-31 07:43:20 --> Config Class Initialized
INFO - 2023-05-31 07:43:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:20 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:20 --> URI Class Initialized
INFO - 2023-05-31 07:43:20 --> Router Class Initialized
INFO - 2023-05-31 07:43:20 --> Output Class Initialized
INFO - 2023-05-31 07:43:20 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:20 --> Input Class Initialized
INFO - 2023-05-31 07:43:20 --> Language Class Initialized
INFO - 2023-05-31 07:43:20 --> Loader Class Initialized
INFO - 2023-05-31 07:43:20 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:20 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:20 --> Total execution time: 0.3960
INFO - 2023-05-31 07:43:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:20 --> Total execution time: 8.6460
INFO - 2023-05-31 07:43:20 --> Config Class Initialized
INFO - 2023-05-31 07:43:20 --> Config Class Initialized
INFO - 2023-05-31 07:43:20 --> Hooks Class Initialized
INFO - 2023-05-31 07:43:20 --> Hooks Class Initialized
INFO - 2023-05-31 07:43:21 --> Config Class Initialized
INFO - 2023-05-31 07:43:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:43:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:21 --> URI Class Initialized
INFO - 2023-05-31 07:43:21 --> URI Class Initialized
INFO - 2023-05-31 07:43:21 --> Router Class Initialized
INFO - 2023-05-31 07:43:21 --> Router Class Initialized
DEBUG - 2023-05-31 07:43:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:21 --> Output Class Initialized
INFO - 2023-05-31 07:43:21 --> Output Class Initialized
INFO - 2023-05-31 07:43:21 --> URI Class Initialized
INFO - 2023-05-31 07:43:21 --> Security Class Initialized
INFO - 2023-05-31 07:43:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:21 --> Input Class Initialized
INFO - 2023-05-31 07:43:21 --> Input Class Initialized
INFO - 2023-05-31 07:43:21 --> Router Class Initialized
INFO - 2023-05-31 07:43:21 --> Language Class Initialized
INFO - 2023-05-31 07:43:21 --> Language Class Initialized
INFO - 2023-05-31 07:43:21 --> Output Class Initialized
INFO - 2023-05-31 07:43:21 --> Loader Class Initialized
INFO - 2023-05-31 07:43:21 --> Security Class Initialized
INFO - 2023-05-31 07:43:21 --> Loader Class Initialized
INFO - 2023-05-31 07:43:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:21 --> Controller Class Initialized
INFO - 2023-05-31 07:43:21 --> Input Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:43:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:21 --> Language Class Initialized
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Loader Class Initialized
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:21 --> Total execution time: 0.2316
INFO - 2023-05-31 07:43:21 --> Config Class Initialized
INFO - 2023-05-31 07:43:21 --> Final output sent to browser
INFO - 2023-05-31 07:43:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Total execution time: 0.2426
INFO - 2023-05-31 07:43:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:43:21 --> Total execution time: 0.2733
INFO - 2023-05-31 07:43:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:21 --> Config Class Initialized
INFO - 2023-05-31 07:43:21 --> Hooks Class Initialized
INFO - 2023-05-31 07:43:21 --> URI Class Initialized
INFO - 2023-05-31 07:43:21 --> Config Class Initialized
INFO - 2023-05-31 07:43:21 --> Hooks Class Initialized
INFO - 2023-05-31 07:43:21 --> Router Class Initialized
DEBUG - 2023-05-31 07:43:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:21 --> Output Class Initialized
INFO - 2023-05-31 07:43:21 --> Config Class Initialized
INFO - 2023-05-31 07:43:21 --> URI Class Initialized
INFO - 2023-05-31 07:43:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:21 --> Security Class Initialized
INFO - 2023-05-31 07:43:21 --> URI Class Initialized
INFO - 2023-05-31 07:43:21 --> Router Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:21 --> Input Class Initialized
DEBUG - 2023-05-31 07:43:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:21 --> Output Class Initialized
INFO - 2023-05-31 07:43:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:21 --> Router Class Initialized
INFO - 2023-05-31 07:43:21 --> Language Class Initialized
INFO - 2023-05-31 07:43:21 --> Security Class Initialized
INFO - 2023-05-31 07:43:21 --> URI Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:21 --> Output Class Initialized
INFO - 2023-05-31 07:43:21 --> Input Class Initialized
INFO - 2023-05-31 07:43:21 --> Router Class Initialized
INFO - 2023-05-31 07:43:21 --> Language Class Initialized
INFO - 2023-05-31 07:43:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:21 --> Output Class Initialized
INFO - 2023-05-31 07:43:21 --> Input Class Initialized
INFO - 2023-05-31 07:43:21 --> Loader Class Initialized
INFO - 2023-05-31 07:43:21 --> Security Class Initialized
INFO - 2023-05-31 07:43:21 --> Language Class Initialized
INFO - 2023-05-31 07:43:21 --> Loader Class Initialized
INFO - 2023-05-31 07:43:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:21 --> Controller Class Initialized
INFO - 2023-05-31 07:43:21 --> Input Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:43:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:21 --> Language Class Initialized
INFO - 2023-05-31 07:43:21 --> Loader Class Initialized
INFO - 2023-05-31 07:43:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Loader Class Initialized
INFO - 2023-05-31 07:43:21 --> Controller Class Initialized
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:21 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:21 --> Total execution time: 0.3218
INFO - 2023-05-31 07:43:21 --> Final output sent to browser
INFO - 2023-05-31 07:43:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:21 --> Total execution time: 0.3260
DEBUG - 2023-05-31 07:43:21 --> Total execution time: 0.2886
INFO - 2023-05-31 07:43:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:21 --> Total execution time: 0.4033
INFO - 2023-05-31 07:43:21 --> Config Class Initialized
INFO - 2023-05-31 07:43:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:21 --> URI Class Initialized
INFO - 2023-05-31 07:43:21 --> Router Class Initialized
INFO - 2023-05-31 07:43:21 --> Output Class Initialized
INFO - 2023-05-31 07:43:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:21 --> Input Class Initialized
INFO - 2023-05-31 07:43:21 --> Language Class Initialized
INFO - 2023-05-31 07:43:21 --> Loader Class Initialized
INFO - 2023-05-31 07:43:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:21 --> Total execution time: 0.3046
INFO - 2023-05-31 07:43:26 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:26 --> Total execution time: 9.5001
INFO - 2023-05-31 07:43:26 --> Config Class Initialized
INFO - 2023-05-31 07:43:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:26 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:26 --> URI Class Initialized
INFO - 2023-05-31 07:43:26 --> Router Class Initialized
INFO - 2023-05-31 07:43:26 --> Output Class Initialized
INFO - 2023-05-31 07:43:26 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:26 --> Input Class Initialized
INFO - 2023-05-31 07:43:26 --> Language Class Initialized
INFO - 2023-05-31 07:43:26 --> Loader Class Initialized
INFO - 2023-05-31 07:43:26 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:26 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:26 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:26 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:30 --> Config Class Initialized
INFO - 2023-05-31 07:43:30 --> Config Class Initialized
INFO - 2023-05-31 07:43:30 --> Hooks Class Initialized
INFO - 2023-05-31 07:43:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:43:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:30 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:30 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:30 --> URI Class Initialized
INFO - 2023-05-31 07:43:30 --> URI Class Initialized
INFO - 2023-05-31 07:43:30 --> Router Class Initialized
INFO - 2023-05-31 07:43:30 --> Router Class Initialized
INFO - 2023-05-31 07:43:30 --> Output Class Initialized
INFO - 2023-05-31 07:43:30 --> Output Class Initialized
INFO - 2023-05-31 07:43:30 --> Security Class Initialized
INFO - 2023-05-31 07:43:30 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:30 --> Input Class Initialized
INFO - 2023-05-31 07:43:30 --> Input Class Initialized
INFO - 2023-05-31 07:43:30 --> Language Class Initialized
INFO - 2023-05-31 07:43:30 --> Language Class Initialized
INFO - 2023-05-31 07:43:30 --> Loader Class Initialized
INFO - 2023-05-31 07:43:30 --> Loader Class Initialized
INFO - 2023-05-31 07:43:30 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:30 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:30 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:31 --> Total execution time: 0.1642
INFO - 2023-05-31 07:43:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:31 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:31 --> Config Class Initialized
INFO - 2023-05-31 07:43:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:31 --> URI Class Initialized
INFO - 2023-05-31 07:43:31 --> Router Class Initialized
INFO - 2023-05-31 07:43:31 --> Output Class Initialized
INFO - 2023-05-31 07:43:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:31 --> Input Class Initialized
INFO - 2023-05-31 07:43:31 --> Language Class Initialized
INFO - 2023-05-31 07:43:31 --> Loader Class Initialized
INFO - 2023-05-31 07:43:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:31 --> Total execution time: 0.4174
INFO - 2023-05-31 07:43:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:31 --> Total execution time: 0.2296
INFO - 2023-05-31 07:43:31 --> Config Class Initialized
INFO - 2023-05-31 07:43:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:31 --> URI Class Initialized
INFO - 2023-05-31 07:43:31 --> Router Class Initialized
INFO - 2023-05-31 07:43:31 --> Output Class Initialized
INFO - 2023-05-31 07:43:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:31 --> Input Class Initialized
INFO - 2023-05-31 07:43:31 --> Language Class Initialized
INFO - 2023-05-31 07:43:31 --> Loader Class Initialized
INFO - 2023-05-31 07:43:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:31 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:31 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:31 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:31 --> Total execution time: 0.3759
INFO - 2023-05-31 07:43:36 --> Config Class Initialized
INFO - 2023-05-31 07:43:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:36 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:36 --> URI Class Initialized
INFO - 2023-05-31 07:43:36 --> Router Class Initialized
INFO - 2023-05-31 07:43:36 --> Output Class Initialized
INFO - 2023-05-31 07:43:36 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:36 --> Input Class Initialized
INFO - 2023-05-31 07:43:36 --> Language Class Initialized
INFO - 2023-05-31 07:43:36 --> Loader Class Initialized
INFO - 2023-05-31 07:43:36 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:36 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:36 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:36 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:36 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:36 --> Total execution time: 0.2403
INFO - 2023-05-31 07:43:36 --> Config Class Initialized
INFO - 2023-05-31 07:43:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:36 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:36 --> URI Class Initialized
INFO - 2023-05-31 07:43:36 --> Router Class Initialized
INFO - 2023-05-31 07:43:36 --> Output Class Initialized
INFO - 2023-05-31 07:43:36 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:36 --> Input Class Initialized
INFO - 2023-05-31 07:43:36 --> Language Class Initialized
INFO - 2023-05-31 07:43:36 --> Loader Class Initialized
INFO - 2023-05-31 07:43:36 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:36 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:36 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:36 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:36 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:36 --> Total execution time: 0.2214
INFO - 2023-05-31 07:43:38 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:38 --> Total execution time: 11.6423
INFO - 2023-05-31 07:43:38 --> Config Class Initialized
INFO - 2023-05-31 07:43:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:38 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:38 --> URI Class Initialized
INFO - 2023-05-31 07:43:38 --> Router Class Initialized
INFO - 2023-05-31 07:43:38 --> Output Class Initialized
INFO - 2023-05-31 07:43:38 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:38 --> Input Class Initialized
INFO - 2023-05-31 07:43:38 --> Language Class Initialized
INFO - 2023-05-31 07:43:38 --> Loader Class Initialized
INFO - 2023-05-31 07:43:38 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:38 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:43:38 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:38 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:55 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:55 --> Total execution time: 17.1847
INFO - 2023-05-31 07:43:55 --> Config Class Initialized
INFO - 2023-05-31 07:43:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:55 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:55 --> URI Class Initialized
INFO - 2023-05-31 07:43:55 --> Router Class Initialized
INFO - 2023-05-31 07:43:55 --> Output Class Initialized
INFO - 2023-05-31 07:43:55 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:55 --> Input Class Initialized
INFO - 2023-05-31 07:43:55 --> Language Class Initialized
INFO - 2023-05-31 07:43:55 --> Loader Class Initialized
INFO - 2023-05-31 07:43:55 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:55 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:55 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:55 --> Total execution time: 0.2286
INFO - 2023-05-31 07:43:55 --> Config Class Initialized
INFO - 2023-05-31 07:43:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:43:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:43:55 --> Utf8 Class Initialized
INFO - 2023-05-31 07:43:55 --> URI Class Initialized
INFO - 2023-05-31 07:43:55 --> Router Class Initialized
INFO - 2023-05-31 07:43:55 --> Output Class Initialized
INFO - 2023-05-31 07:43:56 --> Security Class Initialized
DEBUG - 2023-05-31 07:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:43:56 --> Input Class Initialized
INFO - 2023-05-31 07:43:56 --> Language Class Initialized
INFO - 2023-05-31 07:43:56 --> Loader Class Initialized
INFO - 2023-05-31 07:43:56 --> Controller Class Initialized
DEBUG - 2023-05-31 07:43:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:43:56 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:56 --> Database Driver Class Initialized
INFO - 2023-05-31 07:43:56 --> Model "Login_model" initialized
INFO - 2023-05-31 07:43:56 --> Final output sent to browser
DEBUG - 2023-05-31 07:43:56 --> Total execution time: 0.2235
INFO - 2023-05-31 07:44:05 --> Config Class Initialized
INFO - 2023-05-31 07:44:05 --> Hooks Class Initialized
INFO - 2023-05-31 07:44:05 --> Config Class Initialized
INFO - 2023-05-31 07:44:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:05 --> Utf8 Class Initialized
DEBUG - 2023-05-31 07:44:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:05 --> URI Class Initialized
INFO - 2023-05-31 07:44:05 --> URI Class Initialized
INFO - 2023-05-31 07:44:05 --> Router Class Initialized
INFO - 2023-05-31 07:44:05 --> Router Class Initialized
INFO - 2023-05-31 07:44:05 --> Output Class Initialized
INFO - 2023-05-31 07:44:05 --> Output Class Initialized
INFO - 2023-05-31 07:44:05 --> Security Class Initialized
INFO - 2023-05-31 07:44:05 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:05 --> Input Class Initialized
DEBUG - 2023-05-31 07:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:05 --> Language Class Initialized
INFO - 2023-05-31 07:44:05 --> Input Class Initialized
INFO - 2023-05-31 07:44:05 --> Language Class Initialized
INFO - 2023-05-31 07:44:05 --> Loader Class Initialized
INFO - 2023-05-31 07:44:05 --> Controller Class Initialized
INFO - 2023-05-31 07:44:05 --> Loader Class Initialized
DEBUG - 2023-05-31 07:44:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:05 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:05 --> Total execution time: 0.2103
INFO - 2023-05-31 07:44:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:05 --> Model "Login_model" initialized
INFO - 2023-05-31 07:44:05 --> Config Class Initialized
INFO - 2023-05-31 07:44:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:05 --> URI Class Initialized
INFO - 2023-05-31 07:44:05 --> Router Class Initialized
INFO - 2023-05-31 07:44:05 --> Output Class Initialized
INFO - 2023-05-31 07:44:06 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:06 --> Input Class Initialized
INFO - 2023-05-31 07:44:06 --> Language Class Initialized
INFO - 2023-05-31 07:44:06 --> Loader Class Initialized
INFO - 2023-05-31 07:44:06 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:06 --> Total execution time: 0.4126
INFO - 2023-05-31 07:44:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:06 --> Total execution time: 0.1866
INFO - 2023-05-31 07:44:06 --> Config Class Initialized
INFO - 2023-05-31 07:44:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:06 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:06 --> URI Class Initialized
INFO - 2023-05-31 07:44:06 --> Router Class Initialized
INFO - 2023-05-31 07:44:06 --> Output Class Initialized
INFO - 2023-05-31 07:44:06 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:06 --> Input Class Initialized
INFO - 2023-05-31 07:44:06 --> Language Class Initialized
INFO - 2023-05-31 07:44:06 --> Loader Class Initialized
INFO - 2023-05-31 07:44:06 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:06 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:06 --> Model "Login_model" initialized
INFO - 2023-05-31 07:44:06 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:06 --> Total execution time: 0.4949
INFO - 2023-05-31 07:44:26 --> Config Class Initialized
INFO - 2023-05-31 07:44:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:26 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:26 --> URI Class Initialized
INFO - 2023-05-31 07:44:26 --> Router Class Initialized
INFO - 2023-05-31 07:44:26 --> Output Class Initialized
INFO - 2023-05-31 07:44:26 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:26 --> Input Class Initialized
INFO - 2023-05-31 07:44:26 --> Language Class Initialized
INFO - 2023-05-31 07:44:26 --> Loader Class Initialized
INFO - 2023-05-31 07:44:26 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:26 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:26 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:26 --> Total execution time: 0.1950
INFO - 2023-05-31 07:44:26 --> Config Class Initialized
INFO - 2023-05-31 07:44:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:26 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:26 --> URI Class Initialized
INFO - 2023-05-31 07:44:26 --> Router Class Initialized
INFO - 2023-05-31 07:44:26 --> Output Class Initialized
INFO - 2023-05-31 07:44:26 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:26 --> Input Class Initialized
INFO - 2023-05-31 07:44:26 --> Language Class Initialized
INFO - 2023-05-31 07:44:26 --> Loader Class Initialized
INFO - 2023-05-31 07:44:26 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:26 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:26 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:26 --> Total execution time: 0.2164
INFO - 2023-05-31 07:44:28 --> Config Class Initialized
INFO - 2023-05-31 07:44:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:28 --> URI Class Initialized
INFO - 2023-05-31 07:44:28 --> Router Class Initialized
INFO - 2023-05-31 07:44:28 --> Output Class Initialized
INFO - 2023-05-31 07:44:28 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:28 --> Input Class Initialized
INFO - 2023-05-31 07:44:28 --> Language Class Initialized
INFO - 2023-05-31 07:44:28 --> Loader Class Initialized
INFO - 2023-05-31 07:44:28 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:29 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:29 --> Total execution time: 0.3077
INFO - 2023-05-31 07:44:29 --> Config Class Initialized
INFO - 2023-05-31 07:44:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:29 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:29 --> URI Class Initialized
INFO - 2023-05-31 07:44:29 --> Router Class Initialized
INFO - 2023-05-31 07:44:29 --> Output Class Initialized
INFO - 2023-05-31 07:44:29 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:29 --> Input Class Initialized
INFO - 2023-05-31 07:44:29 --> Language Class Initialized
INFO - 2023-05-31 07:44:29 --> Loader Class Initialized
INFO - 2023-05-31 07:44:29 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:29 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:29 --> Total execution time: 0.1895
INFO - 2023-05-31 07:44:31 --> Config Class Initialized
INFO - 2023-05-31 07:44:31 --> Config Class Initialized
INFO - 2023-05-31 07:44:31 --> Hooks Class Initialized
INFO - 2023-05-31 07:44:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:44:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:31 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:31 --> URI Class Initialized
INFO - 2023-05-31 07:44:31 --> URI Class Initialized
INFO - 2023-05-31 07:44:31 --> Router Class Initialized
INFO - 2023-05-31 07:44:31 --> Router Class Initialized
INFO - 2023-05-31 07:44:31 --> Output Class Initialized
INFO - 2023-05-31 07:44:31 --> Output Class Initialized
INFO - 2023-05-31 07:44:31 --> Security Class Initialized
INFO - 2023-05-31 07:44:31 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:31 --> Input Class Initialized
INFO - 2023-05-31 07:44:31 --> Input Class Initialized
INFO - 2023-05-31 07:44:31 --> Language Class Initialized
INFO - 2023-05-31 07:44:31 --> Language Class Initialized
INFO - 2023-05-31 07:44:31 --> Loader Class Initialized
INFO - 2023-05-31 07:44:31 --> Loader Class Initialized
INFO - 2023-05-31 07:44:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:31 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:32 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:32 --> Total execution time: 0.1540
INFO - 2023-05-31 07:44:32 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:32 --> Total execution time: 0.1660
INFO - 2023-05-31 07:44:32 --> Config Class Initialized
INFO - 2023-05-31 07:44:32 --> Config Class Initialized
INFO - 2023-05-31 07:44:32 --> Hooks Class Initialized
INFO - 2023-05-31 07:44:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:32 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:44:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:32 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:32 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:32 --> URI Class Initialized
INFO - 2023-05-31 07:44:32 --> URI Class Initialized
INFO - 2023-05-31 07:44:32 --> Router Class Initialized
INFO - 2023-05-31 07:44:32 --> Router Class Initialized
INFO - 2023-05-31 07:44:32 --> Output Class Initialized
INFO - 2023-05-31 07:44:32 --> Output Class Initialized
INFO - 2023-05-31 07:44:32 --> Security Class Initialized
INFO - 2023-05-31 07:44:32 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:32 --> Input Class Initialized
INFO - 2023-05-31 07:44:32 --> Input Class Initialized
INFO - 2023-05-31 07:44:32 --> Language Class Initialized
INFO - 2023-05-31 07:44:32 --> Language Class Initialized
INFO - 2023-05-31 07:44:32 --> Loader Class Initialized
INFO - 2023-05-31 07:44:32 --> Loader Class Initialized
INFO - 2023-05-31 07:44:32 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:32 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:32 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:32 --> Total execution time: 0.1600
INFO - 2023-05-31 07:44:32 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:32 --> Total execution time: 0.1733
INFO - 2023-05-31 07:44:38 --> Config Class Initialized
INFO - 2023-05-31 07:44:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:38 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:38 --> URI Class Initialized
INFO - 2023-05-31 07:44:38 --> Router Class Initialized
INFO - 2023-05-31 07:44:38 --> Output Class Initialized
INFO - 2023-05-31 07:44:38 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:38 --> Input Class Initialized
INFO - 2023-05-31 07:44:38 --> Language Class Initialized
INFO - 2023-05-31 07:44:38 --> Loader Class Initialized
INFO - 2023-05-31 07:44:38 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:38 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:38 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:38 --> Total execution time: 0.1760
INFO - 2023-05-31 07:44:38 --> Config Class Initialized
INFO - 2023-05-31 07:44:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:38 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:38 --> URI Class Initialized
INFO - 2023-05-31 07:44:38 --> Router Class Initialized
INFO - 2023-05-31 07:44:38 --> Output Class Initialized
INFO - 2023-05-31 07:44:38 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:38 --> Input Class Initialized
INFO - 2023-05-31 07:44:38 --> Language Class Initialized
INFO - 2023-05-31 07:44:38 --> Loader Class Initialized
INFO - 2023-05-31 07:44:38 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:38 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:38 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:38 --> Model "Login_model" initialized
INFO - 2023-05-31 07:44:38 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:38 --> Total execution time: 0.2354
INFO - 2023-05-31 07:44:38 --> Config Class Initialized
INFO - 2023-05-31 07:44:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:38 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:38 --> URI Class Initialized
INFO - 2023-05-31 07:44:38 --> Router Class Initialized
INFO - 2023-05-31 07:44:38 --> Output Class Initialized
INFO - 2023-05-31 07:44:38 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:38 --> Input Class Initialized
INFO - 2023-05-31 07:44:38 --> Language Class Initialized
INFO - 2023-05-31 07:44:38 --> Loader Class Initialized
INFO - 2023-05-31 07:44:38 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:38 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:38 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:38 --> Total execution time: 0.1723
INFO - 2023-05-31 07:44:39 --> Config Class Initialized
INFO - 2023-05-31 07:44:39 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:39 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:39 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:39 --> URI Class Initialized
INFO - 2023-05-31 07:44:39 --> Router Class Initialized
INFO - 2023-05-31 07:44:39 --> Output Class Initialized
INFO - 2023-05-31 07:44:39 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:39 --> Input Class Initialized
INFO - 2023-05-31 07:44:39 --> Language Class Initialized
INFO - 2023-05-31 07:44:39 --> Loader Class Initialized
INFO - 2023-05-31 07:44:39 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:39 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:39 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:39 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:39 --> Total execution time: 0.1760
INFO - 2023-05-31 07:44:43 --> Config Class Initialized
INFO - 2023-05-31 07:44:43 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:43 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:43 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:43 --> URI Class Initialized
INFO - 2023-05-31 07:44:43 --> Router Class Initialized
INFO - 2023-05-31 07:44:43 --> Output Class Initialized
INFO - 2023-05-31 07:44:43 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:43 --> Input Class Initialized
INFO - 2023-05-31 07:44:43 --> Language Class Initialized
INFO - 2023-05-31 07:44:43 --> Loader Class Initialized
INFO - 2023-05-31 07:44:43 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:43 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:43 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:43 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:43 --> Total execution time: 0.2058
INFO - 2023-05-31 07:44:48 --> Config Class Initialized
INFO - 2023-05-31 07:44:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:48 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:48 --> URI Class Initialized
INFO - 2023-05-31 07:44:48 --> Router Class Initialized
INFO - 2023-05-31 07:44:48 --> Output Class Initialized
INFO - 2023-05-31 07:44:48 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:48 --> Input Class Initialized
INFO - 2023-05-31 07:44:48 --> Language Class Initialized
INFO - 2023-05-31 07:44:48 --> Loader Class Initialized
INFO - 2023-05-31 07:44:48 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:48 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:48 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:48 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:48 --> Total execution time: 0.2135
INFO - 2023-05-31 07:44:49 --> Config Class Initialized
INFO - 2023-05-31 07:44:49 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:49 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:49 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:49 --> URI Class Initialized
INFO - 2023-05-31 07:44:49 --> Router Class Initialized
INFO - 2023-05-31 07:44:49 --> Output Class Initialized
INFO - 2023-05-31 07:44:49 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:49 --> Input Class Initialized
INFO - 2023-05-31 07:44:49 --> Language Class Initialized
INFO - 2023-05-31 07:44:49 --> Loader Class Initialized
INFO - 2023-05-31 07:44:49 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:49 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:49 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:49 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:49 --> Total execution time: 0.1901
INFO - 2023-05-31 07:44:53 --> Config Class Initialized
INFO - 2023-05-31 07:44:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:53 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:53 --> URI Class Initialized
INFO - 2023-05-31 07:44:53 --> Router Class Initialized
INFO - 2023-05-31 07:44:53 --> Output Class Initialized
INFO - 2023-05-31 07:44:53 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:53 --> Input Class Initialized
INFO - 2023-05-31 07:44:53 --> Language Class Initialized
INFO - 2023-05-31 07:44:53 --> Loader Class Initialized
INFO - 2023-05-31 07:44:53 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:53 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:53 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:53 --> Total execution time: 0.1681
INFO - 2023-05-31 07:44:58 --> Config Class Initialized
INFO - 2023-05-31 07:44:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:58 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:58 --> URI Class Initialized
INFO - 2023-05-31 07:44:58 --> Router Class Initialized
INFO - 2023-05-31 07:44:58 --> Output Class Initialized
INFO - 2023-05-31 07:44:58 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:58 --> Input Class Initialized
INFO - 2023-05-31 07:44:58 --> Language Class Initialized
INFO - 2023-05-31 07:44:58 --> Loader Class Initialized
INFO - 2023-05-31 07:44:58 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:58 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:58 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:58 --> Total execution time: 0.1656
INFO - 2023-05-31 07:44:58 --> Config Class Initialized
INFO - 2023-05-31 07:44:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:44:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:44:59 --> Utf8 Class Initialized
INFO - 2023-05-31 07:44:59 --> URI Class Initialized
INFO - 2023-05-31 07:44:59 --> Router Class Initialized
INFO - 2023-05-31 07:44:59 --> Output Class Initialized
INFO - 2023-05-31 07:44:59 --> Security Class Initialized
DEBUG - 2023-05-31 07:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:44:59 --> Input Class Initialized
INFO - 2023-05-31 07:44:59 --> Language Class Initialized
INFO - 2023-05-31 07:44:59 --> Loader Class Initialized
INFO - 2023-05-31 07:44:59 --> Controller Class Initialized
DEBUG - 2023-05-31 07:44:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:44:59 --> Database Driver Class Initialized
INFO - 2023-05-31 07:44:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:44:59 --> Final output sent to browser
DEBUG - 2023-05-31 07:44:59 --> Total execution time: 0.2078
INFO - 2023-05-31 07:45:03 --> Config Class Initialized
INFO - 2023-05-31 07:45:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:03 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:03 --> URI Class Initialized
INFO - 2023-05-31 07:45:03 --> Router Class Initialized
INFO - 2023-05-31 07:45:03 --> Output Class Initialized
INFO - 2023-05-31 07:45:03 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:03 --> Input Class Initialized
INFO - 2023-05-31 07:45:03 --> Language Class Initialized
INFO - 2023-05-31 07:45:03 --> Loader Class Initialized
INFO - 2023-05-31 07:45:03 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:03 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:03 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:03 --> Total execution time: 0.1689
INFO - 2023-05-31 07:45:08 --> Config Class Initialized
INFO - 2023-05-31 07:45:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:08 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:08 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:08 --> URI Class Initialized
INFO - 2023-05-31 07:45:08 --> Router Class Initialized
INFO - 2023-05-31 07:45:08 --> Output Class Initialized
INFO - 2023-05-31 07:45:08 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:08 --> Input Class Initialized
INFO - 2023-05-31 07:45:08 --> Language Class Initialized
INFO - 2023-05-31 07:45:08 --> Loader Class Initialized
INFO - 2023-05-31 07:45:08 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:08 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:08 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:08 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:08 --> Total execution time: 0.1572
INFO - 2023-05-31 07:45:08 --> Config Class Initialized
INFO - 2023-05-31 07:45:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:09 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:09 --> URI Class Initialized
INFO - 2023-05-31 07:45:09 --> Router Class Initialized
INFO - 2023-05-31 07:45:09 --> Output Class Initialized
INFO - 2023-05-31 07:45:09 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:09 --> Input Class Initialized
INFO - 2023-05-31 07:45:09 --> Language Class Initialized
INFO - 2023-05-31 07:45:09 --> Loader Class Initialized
INFO - 2023-05-31 07:45:09 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:09 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:09 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:09 --> Total execution time: 0.2459
INFO - 2023-05-31 07:45:13 --> Config Class Initialized
INFO - 2023-05-31 07:45:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:13 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:13 --> URI Class Initialized
INFO - 2023-05-31 07:45:13 --> Router Class Initialized
INFO - 2023-05-31 07:45:13 --> Output Class Initialized
INFO - 2023-05-31 07:45:13 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:13 --> Input Class Initialized
INFO - 2023-05-31 07:45:13 --> Language Class Initialized
INFO - 2023-05-31 07:45:13 --> Loader Class Initialized
INFO - 2023-05-31 07:45:13 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:13 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:13 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:13 --> Total execution time: 0.1641
INFO - 2023-05-31 07:45:18 --> Config Class Initialized
INFO - 2023-05-31 07:45:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:18 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:18 --> URI Class Initialized
INFO - 2023-05-31 07:45:18 --> Router Class Initialized
INFO - 2023-05-31 07:45:18 --> Output Class Initialized
INFO - 2023-05-31 07:45:18 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:18 --> Input Class Initialized
INFO - 2023-05-31 07:45:18 --> Language Class Initialized
INFO - 2023-05-31 07:45:18 --> Loader Class Initialized
INFO - 2023-05-31 07:45:18 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:18 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:18 --> Total execution time: 0.1705
INFO - 2023-05-31 07:45:18 --> Config Class Initialized
INFO - 2023-05-31 07:45:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:19 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:19 --> URI Class Initialized
INFO - 2023-05-31 07:45:19 --> Router Class Initialized
INFO - 2023-05-31 07:45:19 --> Output Class Initialized
INFO - 2023-05-31 07:45:19 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:19 --> Input Class Initialized
INFO - 2023-05-31 07:45:19 --> Language Class Initialized
INFO - 2023-05-31 07:45:19 --> Loader Class Initialized
INFO - 2023-05-31 07:45:19 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:19 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:19 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:19 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:19 --> Total execution time: 0.1695
INFO - 2023-05-31 07:45:23 --> Config Class Initialized
INFO - 2023-05-31 07:45:23 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:23 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:23 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:23 --> URI Class Initialized
INFO - 2023-05-31 07:45:23 --> Router Class Initialized
INFO - 2023-05-31 07:45:23 --> Output Class Initialized
INFO - 2023-05-31 07:45:23 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:23 --> Input Class Initialized
INFO - 2023-05-31 07:45:23 --> Language Class Initialized
INFO - 2023-05-31 07:45:23 --> Loader Class Initialized
INFO - 2023-05-31 07:45:23 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:23 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:23 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:23 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:23 --> Total execution time: 0.1988
INFO - 2023-05-31 07:45:28 --> Config Class Initialized
INFO - 2023-05-31 07:45:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:28 --> URI Class Initialized
INFO - 2023-05-31 07:45:28 --> Router Class Initialized
INFO - 2023-05-31 07:45:28 --> Output Class Initialized
INFO - 2023-05-31 07:45:28 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:28 --> Input Class Initialized
INFO - 2023-05-31 07:45:28 --> Language Class Initialized
INFO - 2023-05-31 07:45:28 --> Loader Class Initialized
INFO - 2023-05-31 07:45:28 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:28 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:28 --> Total execution time: 0.1744
INFO - 2023-05-31 07:45:28 --> Config Class Initialized
INFO - 2023-05-31 07:45:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:29 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:29 --> URI Class Initialized
INFO - 2023-05-31 07:45:29 --> Router Class Initialized
INFO - 2023-05-31 07:45:29 --> Output Class Initialized
INFO - 2023-05-31 07:45:29 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:29 --> Input Class Initialized
INFO - 2023-05-31 07:45:29 --> Language Class Initialized
INFO - 2023-05-31 07:45:29 --> Loader Class Initialized
INFO - 2023-05-31 07:45:29 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:29 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:29 --> Total execution time: 0.1841
INFO - 2023-05-31 07:45:33 --> Config Class Initialized
INFO - 2023-05-31 07:45:33 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:33 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:33 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:33 --> URI Class Initialized
INFO - 2023-05-31 07:45:33 --> Router Class Initialized
INFO - 2023-05-31 07:45:33 --> Output Class Initialized
INFO - 2023-05-31 07:45:33 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:33 --> Input Class Initialized
INFO - 2023-05-31 07:45:33 --> Language Class Initialized
INFO - 2023-05-31 07:45:33 --> Loader Class Initialized
INFO - 2023-05-31 07:45:33 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:33 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:33 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:33 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:33 --> Total execution time: 0.1596
INFO - 2023-05-31 07:45:38 --> Config Class Initialized
INFO - 2023-05-31 07:45:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:38 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:38 --> URI Class Initialized
INFO - 2023-05-31 07:45:38 --> Router Class Initialized
INFO - 2023-05-31 07:45:38 --> Output Class Initialized
INFO - 2023-05-31 07:45:38 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:38 --> Input Class Initialized
INFO - 2023-05-31 07:45:38 --> Language Class Initialized
INFO - 2023-05-31 07:45:38 --> Loader Class Initialized
INFO - 2023-05-31 07:45:38 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:38 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:38 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:38 --> Total execution time: 0.1677
INFO - 2023-05-31 07:45:38 --> Config Class Initialized
INFO - 2023-05-31 07:45:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:38 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:38 --> URI Class Initialized
INFO - 2023-05-31 07:45:39 --> Router Class Initialized
INFO - 2023-05-31 07:45:39 --> Output Class Initialized
INFO - 2023-05-31 07:45:39 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:39 --> Input Class Initialized
INFO - 2023-05-31 07:45:39 --> Language Class Initialized
INFO - 2023-05-31 07:45:39 --> Loader Class Initialized
INFO - 2023-05-31 07:45:39 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:39 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:39 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:39 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:39 --> Total execution time: 0.1723
INFO - 2023-05-31 07:45:43 --> Config Class Initialized
INFO - 2023-05-31 07:45:43 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:43 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:43 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:43 --> URI Class Initialized
INFO - 2023-05-31 07:45:43 --> Router Class Initialized
INFO - 2023-05-31 07:45:43 --> Output Class Initialized
INFO - 2023-05-31 07:45:43 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:43 --> Input Class Initialized
INFO - 2023-05-31 07:45:43 --> Language Class Initialized
INFO - 2023-05-31 07:45:43 --> Loader Class Initialized
INFO - 2023-05-31 07:45:43 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:43 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:44 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:48 --> Config Class Initialized
INFO - 2023-05-31 07:45:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:48 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:48 --> URI Class Initialized
INFO - 2023-05-31 07:45:48 --> Router Class Initialized
INFO - 2023-05-31 07:45:48 --> Output Class Initialized
INFO - 2023-05-31 07:45:48 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:48 --> Input Class Initialized
INFO - 2023-05-31 07:45:48 --> Language Class Initialized
INFO - 2023-05-31 07:45:48 --> Loader Class Initialized
INFO - 2023-05-31 07:45:48 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:48 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:48 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:48 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:48 --> Total execution time: 0.1559
INFO - 2023-05-31 07:45:48 --> Config Class Initialized
INFO - 2023-05-31 07:45:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:48 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:49 --> URI Class Initialized
INFO - 2023-05-31 07:45:49 --> Router Class Initialized
INFO - 2023-05-31 07:45:49 --> Output Class Initialized
INFO - 2023-05-31 07:45:49 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:49 --> Input Class Initialized
INFO - 2023-05-31 07:45:49 --> Language Class Initialized
INFO - 2023-05-31 07:45:49 --> Loader Class Initialized
INFO - 2023-05-31 07:45:49 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:49 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:49 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:51 --> Total execution time: 8.2126
INFO - 2023-05-31 07:45:52 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:52 --> Total execution time: 3.1999
INFO - 2023-05-31 07:45:53 --> Config Class Initialized
INFO - 2023-05-31 07:45:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:53 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:53 --> URI Class Initialized
INFO - 2023-05-31 07:45:53 --> Router Class Initialized
INFO - 2023-05-31 07:45:53 --> Output Class Initialized
INFO - 2023-05-31 07:45:53 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:53 --> Input Class Initialized
INFO - 2023-05-31 07:45:53 --> Language Class Initialized
INFO - 2023-05-31 07:45:53 --> Loader Class Initialized
INFO - 2023-05-31 07:45:53 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:53 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:53 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:53 --> Total execution time: 0.1740
INFO - 2023-05-31 07:45:58 --> Config Class Initialized
INFO - 2023-05-31 07:45:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:58 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:58 --> URI Class Initialized
INFO - 2023-05-31 07:45:58 --> Router Class Initialized
INFO - 2023-05-31 07:45:58 --> Output Class Initialized
INFO - 2023-05-31 07:45:58 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:58 --> Input Class Initialized
INFO - 2023-05-31 07:45:58 --> Language Class Initialized
INFO - 2023-05-31 07:45:58 --> Loader Class Initialized
INFO - 2023-05-31 07:45:58 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:58 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:58 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:58 --> Total execution time: 0.1689
INFO - 2023-05-31 07:45:58 --> Config Class Initialized
INFO - 2023-05-31 07:45:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:45:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:45:58 --> Utf8 Class Initialized
INFO - 2023-05-31 07:45:58 --> URI Class Initialized
INFO - 2023-05-31 07:45:59 --> Router Class Initialized
INFO - 2023-05-31 07:45:59 --> Output Class Initialized
INFO - 2023-05-31 07:45:59 --> Security Class Initialized
DEBUG - 2023-05-31 07:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:45:59 --> Input Class Initialized
INFO - 2023-05-31 07:45:59 --> Language Class Initialized
INFO - 2023-05-31 07:45:59 --> Loader Class Initialized
INFO - 2023-05-31 07:45:59 --> Controller Class Initialized
DEBUG - 2023-05-31 07:45:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:45:59 --> Database Driver Class Initialized
INFO - 2023-05-31 07:45:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:45:59 --> Final output sent to browser
DEBUG - 2023-05-31 07:45:59 --> Total execution time: 0.1769
INFO - 2023-05-31 07:46:03 --> Config Class Initialized
INFO - 2023-05-31 07:46:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:03 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:03 --> URI Class Initialized
INFO - 2023-05-31 07:46:03 --> Router Class Initialized
INFO - 2023-05-31 07:46:03 --> Output Class Initialized
INFO - 2023-05-31 07:46:03 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:03 --> Input Class Initialized
INFO - 2023-05-31 07:46:03 --> Language Class Initialized
INFO - 2023-05-31 07:46:03 --> Loader Class Initialized
INFO - 2023-05-31 07:46:03 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:03 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:03 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:03 --> Total execution time: 0.1739
INFO - 2023-05-31 07:46:08 --> Config Class Initialized
INFO - 2023-05-31 07:46:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:08 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:08 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:08 --> URI Class Initialized
INFO - 2023-05-31 07:46:08 --> Router Class Initialized
INFO - 2023-05-31 07:46:08 --> Output Class Initialized
INFO - 2023-05-31 07:46:08 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:08 --> Input Class Initialized
INFO - 2023-05-31 07:46:08 --> Language Class Initialized
INFO - 2023-05-31 07:46:08 --> Loader Class Initialized
INFO - 2023-05-31 07:46:08 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:08 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:09 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:09 --> Total execution time: 0.2854
INFO - 2023-05-31 07:46:09 --> Config Class Initialized
INFO - 2023-05-31 07:46:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:09 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:09 --> URI Class Initialized
INFO - 2023-05-31 07:46:09 --> Router Class Initialized
INFO - 2023-05-31 07:46:09 --> Output Class Initialized
INFO - 2023-05-31 07:46:09 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:09 --> Input Class Initialized
INFO - 2023-05-31 07:46:09 --> Language Class Initialized
INFO - 2023-05-31 07:46:09 --> Loader Class Initialized
INFO - 2023-05-31 07:46:09 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:09 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:09 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:09 --> Total execution time: 0.1907
INFO - 2023-05-31 07:46:13 --> Config Class Initialized
INFO - 2023-05-31 07:46:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:13 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:13 --> URI Class Initialized
INFO - 2023-05-31 07:46:13 --> Router Class Initialized
INFO - 2023-05-31 07:46:13 --> Output Class Initialized
INFO - 2023-05-31 07:46:13 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:13 --> Input Class Initialized
INFO - 2023-05-31 07:46:13 --> Language Class Initialized
INFO - 2023-05-31 07:46:13 --> Loader Class Initialized
INFO - 2023-05-31 07:46:13 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:13 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:13 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:13 --> Total execution time: 0.2184
INFO - 2023-05-31 07:46:18 --> Config Class Initialized
INFO - 2023-05-31 07:46:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:18 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:18 --> URI Class Initialized
INFO - 2023-05-31 07:46:18 --> Router Class Initialized
INFO - 2023-05-31 07:46:18 --> Output Class Initialized
INFO - 2023-05-31 07:46:18 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:18 --> Input Class Initialized
INFO - 2023-05-31 07:46:18 --> Language Class Initialized
INFO - 2023-05-31 07:46:18 --> Loader Class Initialized
INFO - 2023-05-31 07:46:18 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:18 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:18 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:18 --> Total execution time: 0.1867
INFO - 2023-05-31 07:46:18 --> Config Class Initialized
INFO - 2023-05-31 07:46:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:19 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:19 --> URI Class Initialized
INFO - 2023-05-31 07:46:19 --> Router Class Initialized
INFO - 2023-05-31 07:46:19 --> Output Class Initialized
INFO - 2023-05-31 07:46:19 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:19 --> Input Class Initialized
INFO - 2023-05-31 07:46:19 --> Language Class Initialized
INFO - 2023-05-31 07:46:19 --> Loader Class Initialized
INFO - 2023-05-31 07:46:19 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:19 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:19 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:19 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:19 --> Total execution time: 0.1782
INFO - 2023-05-31 07:46:23 --> Config Class Initialized
INFO - 2023-05-31 07:46:23 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:23 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:23 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:23 --> URI Class Initialized
INFO - 2023-05-31 07:46:23 --> Router Class Initialized
INFO - 2023-05-31 07:46:23 --> Output Class Initialized
INFO - 2023-05-31 07:46:23 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:23 --> Input Class Initialized
INFO - 2023-05-31 07:46:23 --> Language Class Initialized
INFO - 2023-05-31 07:46:23 --> Loader Class Initialized
INFO - 2023-05-31 07:46:23 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:23 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:23 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:24 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:24 --> Total execution time: 0.2424
INFO - 2023-05-31 07:46:28 --> Config Class Initialized
INFO - 2023-05-31 07:46:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:28 --> URI Class Initialized
INFO - 2023-05-31 07:46:28 --> Router Class Initialized
INFO - 2023-05-31 07:46:28 --> Output Class Initialized
INFO - 2023-05-31 07:46:28 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:28 --> Input Class Initialized
INFO - 2023-05-31 07:46:28 --> Language Class Initialized
INFO - 2023-05-31 07:46:28 --> Loader Class Initialized
INFO - 2023-05-31 07:46:28 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:28 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:28 --> Total execution time: 0.1762
INFO - 2023-05-31 07:46:28 --> Config Class Initialized
INFO - 2023-05-31 07:46:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:29 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:29 --> URI Class Initialized
INFO - 2023-05-31 07:46:29 --> Router Class Initialized
INFO - 2023-05-31 07:46:29 --> Output Class Initialized
INFO - 2023-05-31 07:46:29 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:29 --> Input Class Initialized
INFO - 2023-05-31 07:46:29 --> Language Class Initialized
INFO - 2023-05-31 07:46:29 --> Loader Class Initialized
INFO - 2023-05-31 07:46:29 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:29 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:29 --> Total execution time: 0.2118
INFO - 2023-05-31 07:46:33 --> Config Class Initialized
INFO - 2023-05-31 07:46:33 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:33 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:33 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:33 --> URI Class Initialized
INFO - 2023-05-31 07:46:33 --> Router Class Initialized
INFO - 2023-05-31 07:46:33 --> Output Class Initialized
INFO - 2023-05-31 07:46:33 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:33 --> Input Class Initialized
INFO - 2023-05-31 07:46:33 --> Language Class Initialized
INFO - 2023-05-31 07:46:33 --> Loader Class Initialized
INFO - 2023-05-31 07:46:33 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:33 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:33 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:33 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:33 --> Total execution time: 0.1837
INFO - 2023-05-31 07:46:38 --> Config Class Initialized
INFO - 2023-05-31 07:46:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:38 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:38 --> URI Class Initialized
INFO - 2023-05-31 07:46:39 --> Router Class Initialized
INFO - 2023-05-31 07:46:39 --> Output Class Initialized
INFO - 2023-05-31 07:46:39 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:39 --> Input Class Initialized
INFO - 2023-05-31 07:46:39 --> Language Class Initialized
INFO - 2023-05-31 07:46:39 --> Loader Class Initialized
INFO - 2023-05-31 07:46:39 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:39 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:39 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:39 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:39 --> Total execution time: 1.0066
INFO - 2023-05-31 07:46:40 --> Config Class Initialized
INFO - 2023-05-31 07:46:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:40 --> URI Class Initialized
INFO - 2023-05-31 07:46:40 --> Router Class Initialized
INFO - 2023-05-31 07:46:40 --> Output Class Initialized
INFO - 2023-05-31 07:46:40 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:40 --> Input Class Initialized
INFO - 2023-05-31 07:46:40 --> Language Class Initialized
INFO - 2023-05-31 07:46:40 --> Loader Class Initialized
INFO - 2023-05-31 07:46:40 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:40 --> Total execution time: 0.3826
INFO - 2023-05-31 07:46:43 --> Config Class Initialized
INFO - 2023-05-31 07:46:43 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:43 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:43 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:43 --> URI Class Initialized
INFO - 2023-05-31 07:46:43 --> Router Class Initialized
INFO - 2023-05-31 07:46:43 --> Output Class Initialized
INFO - 2023-05-31 07:46:43 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:43 --> Input Class Initialized
INFO - 2023-05-31 07:46:43 --> Language Class Initialized
INFO - 2023-05-31 07:46:43 --> Loader Class Initialized
INFO - 2023-05-31 07:46:43 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:43 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:43 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:43 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:43 --> Total execution time: 0.1785
INFO - 2023-05-31 07:46:48 --> Config Class Initialized
INFO - 2023-05-31 07:46:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:48 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:48 --> URI Class Initialized
INFO - 2023-05-31 07:46:48 --> Router Class Initialized
INFO - 2023-05-31 07:46:48 --> Output Class Initialized
INFO - 2023-05-31 07:46:48 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:48 --> Input Class Initialized
INFO - 2023-05-31 07:46:48 --> Language Class Initialized
INFO - 2023-05-31 07:46:48 --> Loader Class Initialized
INFO - 2023-05-31 07:46:48 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:48 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:48 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:48 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:48 --> Total execution time: 0.1879
INFO - 2023-05-31 07:46:48 --> Config Class Initialized
INFO - 2023-05-31 07:46:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:49 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:49 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:49 --> URI Class Initialized
INFO - 2023-05-31 07:46:49 --> Router Class Initialized
INFO - 2023-05-31 07:46:49 --> Output Class Initialized
INFO - 2023-05-31 07:46:49 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:49 --> Input Class Initialized
INFO - 2023-05-31 07:46:49 --> Language Class Initialized
INFO - 2023-05-31 07:46:49 --> Loader Class Initialized
INFO - 2023-05-31 07:46:49 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:49 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:49 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:49 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:49 --> Total execution time: 0.3927
INFO - 2023-05-31 07:46:53 --> Config Class Initialized
INFO - 2023-05-31 07:46:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:53 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:53 --> URI Class Initialized
INFO - 2023-05-31 07:46:53 --> Router Class Initialized
INFO - 2023-05-31 07:46:53 --> Output Class Initialized
INFO - 2023-05-31 07:46:53 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:53 --> Input Class Initialized
INFO - 2023-05-31 07:46:53 --> Language Class Initialized
INFO - 2023-05-31 07:46:53 --> Loader Class Initialized
INFO - 2023-05-31 07:46:53 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:53 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:53 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:53 --> Total execution time: 0.2050
INFO - 2023-05-31 07:46:58 --> Config Class Initialized
INFO - 2023-05-31 07:46:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:58 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:58 --> URI Class Initialized
INFO - 2023-05-31 07:46:58 --> Router Class Initialized
INFO - 2023-05-31 07:46:58 --> Output Class Initialized
INFO - 2023-05-31 07:46:58 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:58 --> Input Class Initialized
INFO - 2023-05-31 07:46:58 --> Language Class Initialized
INFO - 2023-05-31 07:46:58 --> Loader Class Initialized
INFO - 2023-05-31 07:46:58 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:58 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:58 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:58 --> Total execution time: 0.1799
INFO - 2023-05-31 07:46:58 --> Config Class Initialized
INFO - 2023-05-31 07:46:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:46:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:46:59 --> Utf8 Class Initialized
INFO - 2023-05-31 07:46:59 --> URI Class Initialized
INFO - 2023-05-31 07:46:59 --> Router Class Initialized
INFO - 2023-05-31 07:46:59 --> Output Class Initialized
INFO - 2023-05-31 07:46:59 --> Security Class Initialized
DEBUG - 2023-05-31 07:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:46:59 --> Input Class Initialized
INFO - 2023-05-31 07:46:59 --> Language Class Initialized
INFO - 2023-05-31 07:46:59 --> Loader Class Initialized
INFO - 2023-05-31 07:46:59 --> Controller Class Initialized
DEBUG - 2023-05-31 07:46:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:46:59 --> Database Driver Class Initialized
INFO - 2023-05-31 07:46:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:46:59 --> Final output sent to browser
DEBUG - 2023-05-31 07:46:59 --> Total execution time: 0.1800
INFO - 2023-05-31 07:47:03 --> Config Class Initialized
INFO - 2023-05-31 07:47:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:03 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:03 --> URI Class Initialized
INFO - 2023-05-31 07:47:03 --> Router Class Initialized
INFO - 2023-05-31 07:47:04 --> Output Class Initialized
INFO - 2023-05-31 07:47:04 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:04 --> Input Class Initialized
INFO - 2023-05-31 07:47:04 --> Language Class Initialized
INFO - 2023-05-31 07:47:04 --> Loader Class Initialized
INFO - 2023-05-31 07:47:04 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:04 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:04 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:04 --> Total execution time: 0.5106
INFO - 2023-05-31 07:47:10 --> Config Class Initialized
INFO - 2023-05-31 07:47:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:10 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:10 --> URI Class Initialized
INFO - 2023-05-31 07:47:10 --> Router Class Initialized
INFO - 2023-05-31 07:47:10 --> Output Class Initialized
INFO - 2023-05-31 07:47:10 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:10 --> Input Class Initialized
INFO - 2023-05-31 07:47:10 --> Language Class Initialized
INFO - 2023-05-31 07:47:10 --> Loader Class Initialized
INFO - 2023-05-31 07:47:10 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:11 --> Total execution time: 0.3114
INFO - 2023-05-31 07:47:11 --> Config Class Initialized
INFO - 2023-05-31 07:47:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:11 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:11 --> URI Class Initialized
INFO - 2023-05-31 07:47:11 --> Router Class Initialized
INFO - 2023-05-31 07:47:11 --> Output Class Initialized
INFO - 2023-05-31 07:47:11 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:11 --> Input Class Initialized
INFO - 2023-05-31 07:47:11 --> Language Class Initialized
INFO - 2023-05-31 07:47:11 --> Loader Class Initialized
INFO - 2023-05-31 07:47:11 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:11 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:11 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:11 --> Total execution time: 0.5082
INFO - 2023-05-31 07:47:15 --> Config Class Initialized
INFO - 2023-05-31 07:47:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:15 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:15 --> URI Class Initialized
INFO - 2023-05-31 07:47:15 --> Router Class Initialized
INFO - 2023-05-31 07:47:15 --> Output Class Initialized
INFO - 2023-05-31 07:47:15 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:15 --> Input Class Initialized
INFO - 2023-05-31 07:47:15 --> Language Class Initialized
INFO - 2023-05-31 07:47:15 --> Loader Class Initialized
INFO - 2023-05-31 07:47:15 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:15 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:15 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:15 --> Total execution time: 0.2167
INFO - 2023-05-31 07:47:20 --> Config Class Initialized
INFO - 2023-05-31 07:47:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:20 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:20 --> URI Class Initialized
INFO - 2023-05-31 07:47:20 --> Router Class Initialized
INFO - 2023-05-31 07:47:20 --> Output Class Initialized
INFO - 2023-05-31 07:47:20 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:20 --> Input Class Initialized
INFO - 2023-05-31 07:47:20 --> Language Class Initialized
INFO - 2023-05-31 07:47:20 --> Loader Class Initialized
INFO - 2023-05-31 07:47:20 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:20 --> Total execution time: 0.1627
INFO - 2023-05-31 07:47:20 --> Config Class Initialized
INFO - 2023-05-31 07:47:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:20 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:20 --> URI Class Initialized
INFO - 2023-05-31 07:47:20 --> Router Class Initialized
INFO - 2023-05-31 07:47:20 --> Output Class Initialized
INFO - 2023-05-31 07:47:20 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:20 --> Input Class Initialized
INFO - 2023-05-31 07:47:20 --> Language Class Initialized
INFO - 2023-05-31 07:47:20 --> Loader Class Initialized
INFO - 2023-05-31 07:47:20 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:20 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:20 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:20 --> Total execution time: 0.2171
INFO - 2023-05-31 07:47:25 --> Config Class Initialized
INFO - 2023-05-31 07:47:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:25 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:25 --> URI Class Initialized
INFO - 2023-05-31 07:47:25 --> Router Class Initialized
INFO - 2023-05-31 07:47:25 --> Output Class Initialized
INFO - 2023-05-31 07:47:25 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:25 --> Input Class Initialized
INFO - 2023-05-31 07:47:25 --> Language Class Initialized
INFO - 2023-05-31 07:47:25 --> Loader Class Initialized
INFO - 2023-05-31 07:47:25 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:25 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:25 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:25 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:25 --> Total execution time: 0.1597
INFO - 2023-05-31 07:47:30 --> Config Class Initialized
INFO - 2023-05-31 07:47:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:30 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:30 --> URI Class Initialized
INFO - 2023-05-31 07:47:30 --> Router Class Initialized
INFO - 2023-05-31 07:47:30 --> Output Class Initialized
INFO - 2023-05-31 07:47:30 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:30 --> Input Class Initialized
INFO - 2023-05-31 07:47:30 --> Language Class Initialized
INFO - 2023-05-31 07:47:30 --> Loader Class Initialized
INFO - 2023-05-31 07:47:30 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:30 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:30 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:30 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:30 --> Total execution time: 0.1948
INFO - 2023-05-31 07:47:30 --> Config Class Initialized
INFO - 2023-05-31 07:47:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:30 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:30 --> URI Class Initialized
INFO - 2023-05-31 07:47:30 --> Router Class Initialized
INFO - 2023-05-31 07:47:30 --> Output Class Initialized
INFO - 2023-05-31 07:47:30 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:30 --> Input Class Initialized
INFO - 2023-05-31 07:47:30 --> Language Class Initialized
INFO - 2023-05-31 07:47:30 --> Loader Class Initialized
INFO - 2023-05-31 07:47:30 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:30 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:30 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:30 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:30 --> Total execution time: 0.2576
INFO - 2023-05-31 07:47:35 --> Config Class Initialized
INFO - 2023-05-31 07:47:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:35 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:35 --> URI Class Initialized
INFO - 2023-05-31 07:47:35 --> Router Class Initialized
INFO - 2023-05-31 07:47:35 --> Output Class Initialized
INFO - 2023-05-31 07:47:35 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:35 --> Input Class Initialized
INFO - 2023-05-31 07:47:35 --> Language Class Initialized
INFO - 2023-05-31 07:47:35 --> Loader Class Initialized
INFO - 2023-05-31 07:47:35 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:35 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:35 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:35 --> Total execution time: 0.1692
INFO - 2023-05-31 07:47:40 --> Config Class Initialized
INFO - 2023-05-31 07:47:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:40 --> URI Class Initialized
INFO - 2023-05-31 07:47:40 --> Router Class Initialized
INFO - 2023-05-31 07:47:40 --> Output Class Initialized
INFO - 2023-05-31 07:47:40 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:40 --> Input Class Initialized
INFO - 2023-05-31 07:47:40 --> Language Class Initialized
INFO - 2023-05-31 07:47:40 --> Loader Class Initialized
INFO - 2023-05-31 07:47:40 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:40 --> Total execution time: 0.1566
INFO - 2023-05-31 07:47:40 --> Config Class Initialized
INFO - 2023-05-31 07:47:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:40 --> URI Class Initialized
INFO - 2023-05-31 07:47:40 --> Router Class Initialized
INFO - 2023-05-31 07:47:40 --> Output Class Initialized
INFO - 2023-05-31 07:47:40 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:40 --> Input Class Initialized
INFO - 2023-05-31 07:47:40 --> Language Class Initialized
INFO - 2023-05-31 07:47:40 --> Loader Class Initialized
INFO - 2023-05-31 07:47:40 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:40 --> Total execution time: 0.1701
INFO - 2023-05-31 07:47:45 --> Config Class Initialized
INFO - 2023-05-31 07:47:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:45 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:45 --> URI Class Initialized
INFO - 2023-05-31 07:47:45 --> Router Class Initialized
INFO - 2023-05-31 07:47:45 --> Output Class Initialized
INFO - 2023-05-31 07:47:45 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:45 --> Input Class Initialized
INFO - 2023-05-31 07:47:45 --> Language Class Initialized
INFO - 2023-05-31 07:47:45 --> Loader Class Initialized
INFO - 2023-05-31 07:47:45 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:45 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:45 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:45 --> Total execution time: 0.1763
INFO - 2023-05-31 07:47:50 --> Config Class Initialized
INFO - 2023-05-31 07:47:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:50 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:50 --> URI Class Initialized
INFO - 2023-05-31 07:47:50 --> Router Class Initialized
INFO - 2023-05-31 07:47:50 --> Output Class Initialized
INFO - 2023-05-31 07:47:50 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:50 --> Input Class Initialized
INFO - 2023-05-31 07:47:50 --> Language Class Initialized
INFO - 2023-05-31 07:47:50 --> Loader Class Initialized
INFO - 2023-05-31 07:47:50 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:50 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:50 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:50 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:50 --> Total execution time: 0.2358
INFO - 2023-05-31 07:47:50 --> Config Class Initialized
INFO - 2023-05-31 07:47:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:50 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:50 --> URI Class Initialized
INFO - 2023-05-31 07:47:50 --> Router Class Initialized
INFO - 2023-05-31 07:47:50 --> Output Class Initialized
INFO - 2023-05-31 07:47:50 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:50 --> Input Class Initialized
INFO - 2023-05-31 07:47:50 --> Language Class Initialized
INFO - 2023-05-31 07:47:50 --> Loader Class Initialized
INFO - 2023-05-31 07:47:50 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:50 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:50 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:51 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:51 --> Total execution time: 0.5764
INFO - 2023-05-31 07:47:55 --> Config Class Initialized
INFO - 2023-05-31 07:47:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:47:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:47:55 --> Utf8 Class Initialized
INFO - 2023-05-31 07:47:55 --> URI Class Initialized
INFO - 2023-05-31 07:47:55 --> Router Class Initialized
INFO - 2023-05-31 07:47:55 --> Output Class Initialized
INFO - 2023-05-31 07:47:55 --> Security Class Initialized
DEBUG - 2023-05-31 07:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:47:55 --> Input Class Initialized
INFO - 2023-05-31 07:47:55 --> Language Class Initialized
INFO - 2023-05-31 07:47:55 --> Loader Class Initialized
INFO - 2023-05-31 07:47:55 --> Controller Class Initialized
DEBUG - 2023-05-31 07:47:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:47:55 --> Database Driver Class Initialized
INFO - 2023-05-31 07:47:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:47:55 --> Final output sent to browser
DEBUG - 2023-05-31 07:47:55 --> Total execution time: 0.1861
INFO - 2023-05-31 07:48:00 --> Config Class Initialized
INFO - 2023-05-31 07:48:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:00 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:00 --> URI Class Initialized
INFO - 2023-05-31 07:48:00 --> Router Class Initialized
INFO - 2023-05-31 07:48:00 --> Output Class Initialized
INFO - 2023-05-31 07:48:00 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:00 --> Input Class Initialized
INFO - 2023-05-31 07:48:00 --> Language Class Initialized
INFO - 2023-05-31 07:48:00 --> Loader Class Initialized
INFO - 2023-05-31 07:48:00 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:00 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:00 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:00 --> Total execution time: 0.1594
INFO - 2023-05-31 07:48:00 --> Config Class Initialized
INFO - 2023-05-31 07:48:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:00 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:00 --> URI Class Initialized
INFO - 2023-05-31 07:48:00 --> Router Class Initialized
INFO - 2023-05-31 07:48:00 --> Output Class Initialized
INFO - 2023-05-31 07:48:00 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:00 --> Input Class Initialized
INFO - 2023-05-31 07:48:00 --> Language Class Initialized
INFO - 2023-05-31 07:48:00 --> Loader Class Initialized
INFO - 2023-05-31 07:48:00 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:00 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:00 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:00 --> Total execution time: 0.1878
INFO - 2023-05-31 07:48:24 --> Config Class Initialized
INFO - 2023-05-31 07:48:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:24 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:24 --> URI Class Initialized
INFO - 2023-05-31 07:48:24 --> Router Class Initialized
INFO - 2023-05-31 07:48:24 --> Output Class Initialized
INFO - 2023-05-31 07:48:24 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:24 --> Input Class Initialized
INFO - 2023-05-31 07:48:24 --> Language Class Initialized
INFO - 2023-05-31 07:48:24 --> Loader Class Initialized
INFO - 2023-05-31 07:48:24 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:24 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:24 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:24 --> Total execution time: 0.1758
INFO - 2023-05-31 07:48:24 --> Config Class Initialized
INFO - 2023-05-31 07:48:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:24 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:24 --> URI Class Initialized
INFO - 2023-05-31 07:48:24 --> Router Class Initialized
INFO - 2023-05-31 07:48:24 --> Output Class Initialized
INFO - 2023-05-31 07:48:24 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:24 --> Input Class Initialized
INFO - 2023-05-31 07:48:24 --> Language Class Initialized
INFO - 2023-05-31 07:48:24 --> Loader Class Initialized
INFO - 2023-05-31 07:48:24 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:24 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:24 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:24 --> Total execution time: 0.2566
INFO - 2023-05-31 07:48:29 --> Config Class Initialized
INFO - 2023-05-31 07:48:29 --> Config Class Initialized
INFO - 2023-05-31 07:48:29 --> Hooks Class Initialized
INFO - 2023-05-31 07:48:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:29 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:48:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:29 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:29 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:29 --> URI Class Initialized
INFO - 2023-05-31 07:48:29 --> URI Class Initialized
INFO - 2023-05-31 07:48:29 --> Router Class Initialized
INFO - 2023-05-31 07:48:29 --> Router Class Initialized
INFO - 2023-05-31 07:48:29 --> Output Class Initialized
INFO - 2023-05-31 07:48:29 --> Output Class Initialized
INFO - 2023-05-31 07:48:29 --> Security Class Initialized
INFO - 2023-05-31 07:48:29 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:29 --> Input Class Initialized
INFO - 2023-05-31 07:48:29 --> Input Class Initialized
INFO - 2023-05-31 07:48:29 --> Language Class Initialized
INFO - 2023-05-31 07:48:29 --> Language Class Initialized
INFO - 2023-05-31 07:48:29 --> Loader Class Initialized
INFO - 2023-05-31 07:48:29 --> Loader Class Initialized
INFO - 2023-05-31 07:48:29 --> Controller Class Initialized
INFO - 2023-05-31 07:48:29 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:48:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:29 --> Final output sent to browser
INFO - 2023-05-31 07:48:29 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:29 --> Total execution time: 0.1565
DEBUG - 2023-05-31 07:48:29 --> Total execution time: 0.1562
INFO - 2023-05-31 07:48:35 --> Config Class Initialized
INFO - 2023-05-31 07:48:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:35 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:35 --> URI Class Initialized
INFO - 2023-05-31 07:48:35 --> Router Class Initialized
INFO - 2023-05-31 07:48:35 --> Output Class Initialized
INFO - 2023-05-31 07:48:35 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:35 --> Input Class Initialized
INFO - 2023-05-31 07:48:35 --> Language Class Initialized
INFO - 2023-05-31 07:48:35 --> Loader Class Initialized
INFO - 2023-05-31 07:48:35 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:35 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:35 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:35 --> Total execution time: 0.1675
INFO - 2023-05-31 07:48:35 --> Config Class Initialized
INFO - 2023-05-31 07:48:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:35 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:35 --> URI Class Initialized
INFO - 2023-05-31 07:48:35 --> Router Class Initialized
INFO - 2023-05-31 07:48:35 --> Output Class Initialized
INFO - 2023-05-31 07:48:35 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:35 --> Input Class Initialized
INFO - 2023-05-31 07:48:35 --> Language Class Initialized
INFO - 2023-05-31 07:48:35 --> Loader Class Initialized
INFO - 2023-05-31 07:48:35 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:35 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:35 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:35 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:35 --> Total execution time: 0.1754
INFO - 2023-05-31 07:48:40 --> Config Class Initialized
INFO - 2023-05-31 07:48:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:40 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:40 --> URI Class Initialized
INFO - 2023-05-31 07:48:40 --> Router Class Initialized
INFO - 2023-05-31 07:48:40 --> Output Class Initialized
INFO - 2023-05-31 07:48:40 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:40 --> Input Class Initialized
INFO - 2023-05-31 07:48:40 --> Language Class Initialized
INFO - 2023-05-31 07:48:40 --> Loader Class Initialized
INFO - 2023-05-31 07:48:40 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:40 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:40 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:40 --> Total execution time: 0.1963
INFO - 2023-05-31 07:48:45 --> Config Class Initialized
INFO - 2023-05-31 07:48:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:45 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:45 --> URI Class Initialized
INFO - 2023-05-31 07:48:45 --> Router Class Initialized
INFO - 2023-05-31 07:48:45 --> Output Class Initialized
INFO - 2023-05-31 07:48:45 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:45 --> Input Class Initialized
INFO - 2023-05-31 07:48:45 --> Language Class Initialized
INFO - 2023-05-31 07:48:45 --> Loader Class Initialized
INFO - 2023-05-31 07:48:45 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:45 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:45 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:45 --> Total execution time: 0.2174
INFO - 2023-05-31 07:48:45 --> Config Class Initialized
INFO - 2023-05-31 07:48:45 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:45 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:45 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:45 --> URI Class Initialized
INFO - 2023-05-31 07:48:45 --> Router Class Initialized
INFO - 2023-05-31 07:48:45 --> Output Class Initialized
INFO - 2023-05-31 07:48:45 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:45 --> Input Class Initialized
INFO - 2023-05-31 07:48:45 --> Language Class Initialized
INFO - 2023-05-31 07:48:45 --> Loader Class Initialized
INFO - 2023-05-31 07:48:45 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:45 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:45 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:45 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:45 --> Total execution time: 0.2001
INFO - 2023-05-31 07:48:50 --> Config Class Initialized
INFO - 2023-05-31 07:48:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:50 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:50 --> URI Class Initialized
INFO - 2023-05-31 07:48:50 --> Router Class Initialized
INFO - 2023-05-31 07:48:50 --> Output Class Initialized
INFO - 2023-05-31 07:48:50 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:50 --> Input Class Initialized
INFO - 2023-05-31 07:48:50 --> Language Class Initialized
INFO - 2023-05-31 07:48:50 --> Loader Class Initialized
INFO - 2023-05-31 07:48:50 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:50 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:50 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:50 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:50 --> Total execution time: 0.3248
INFO - 2023-05-31 07:48:55 --> Config Class Initialized
INFO - 2023-05-31 07:48:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:55 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:55 --> URI Class Initialized
INFO - 2023-05-31 07:48:55 --> Router Class Initialized
INFO - 2023-05-31 07:48:55 --> Output Class Initialized
INFO - 2023-05-31 07:48:55 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:55 --> Input Class Initialized
INFO - 2023-05-31 07:48:55 --> Language Class Initialized
INFO - 2023-05-31 07:48:55 --> Loader Class Initialized
INFO - 2023-05-31 07:48:55 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:55 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:55 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:55 --> Total execution time: 0.1911
INFO - 2023-05-31 07:48:55 --> Config Class Initialized
INFO - 2023-05-31 07:48:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:48:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:48:55 --> Utf8 Class Initialized
INFO - 2023-05-31 07:48:55 --> URI Class Initialized
INFO - 2023-05-31 07:48:55 --> Router Class Initialized
INFO - 2023-05-31 07:48:55 --> Output Class Initialized
INFO - 2023-05-31 07:48:55 --> Security Class Initialized
DEBUG - 2023-05-31 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:48:55 --> Input Class Initialized
INFO - 2023-05-31 07:48:55 --> Language Class Initialized
INFO - 2023-05-31 07:48:55 --> Loader Class Initialized
INFO - 2023-05-31 07:48:55 --> Controller Class Initialized
DEBUG - 2023-05-31 07:48:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:48:55 --> Database Driver Class Initialized
INFO - 2023-05-31 07:48:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:48:55 --> Final output sent to browser
DEBUG - 2023-05-31 07:48:55 --> Total execution time: 0.2408
INFO - 2023-05-31 07:49:00 --> Config Class Initialized
INFO - 2023-05-31 07:49:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:49:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:49:00 --> Utf8 Class Initialized
INFO - 2023-05-31 07:49:00 --> URI Class Initialized
INFO - 2023-05-31 07:49:00 --> Router Class Initialized
INFO - 2023-05-31 07:49:00 --> Output Class Initialized
INFO - 2023-05-31 07:49:00 --> Security Class Initialized
DEBUG - 2023-05-31 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:49:00 --> Input Class Initialized
INFO - 2023-05-31 07:49:00 --> Language Class Initialized
INFO - 2023-05-31 07:49:00 --> Loader Class Initialized
INFO - 2023-05-31 07:49:00 --> Controller Class Initialized
DEBUG - 2023-05-31 07:49:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:49:00 --> Database Driver Class Initialized
INFO - 2023-05-31 07:49:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:49:00 --> Final output sent to browser
DEBUG - 2023-05-31 07:49:00 --> Total execution time: 0.1825
INFO - 2023-05-31 07:49:00 --> Config Class Initialized
INFO - 2023-05-31 07:49:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:49:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:49:00 --> Utf8 Class Initialized
INFO - 2023-05-31 07:49:00 --> URI Class Initialized
INFO - 2023-05-31 07:49:00 --> Router Class Initialized
INFO - 2023-05-31 07:49:00 --> Output Class Initialized
INFO - 2023-05-31 07:49:00 --> Security Class Initialized
DEBUG - 2023-05-31 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:49:00 --> Input Class Initialized
INFO - 2023-05-31 07:49:00 --> Language Class Initialized
INFO - 2023-05-31 07:49:00 --> Loader Class Initialized
INFO - 2023-05-31 07:49:00 --> Controller Class Initialized
DEBUG - 2023-05-31 07:49:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:49:00 --> Database Driver Class Initialized
INFO - 2023-05-31 07:49:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:49:00 --> Final output sent to browser
DEBUG - 2023-05-31 07:49:00 --> Total execution time: 0.2611
INFO - 2023-05-31 07:49:00 --> Config Class Initialized
INFO - 2023-05-31 07:49:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:49:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:49:00 --> Utf8 Class Initialized
INFO - 2023-05-31 07:49:00 --> URI Class Initialized
INFO - 2023-05-31 07:49:00 --> Router Class Initialized
INFO - 2023-05-31 07:49:00 --> Output Class Initialized
INFO - 2023-05-31 07:49:00 --> Security Class Initialized
DEBUG - 2023-05-31 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:49:00 --> Input Class Initialized
INFO - 2023-05-31 07:49:00 --> Language Class Initialized
INFO - 2023-05-31 07:49:00 --> Loader Class Initialized
INFO - 2023-05-31 07:49:00 --> Controller Class Initialized
DEBUG - 2023-05-31 07:49:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:49:01 --> Database Driver Class Initialized
INFO - 2023-05-31 07:49:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:49:01 --> Final output sent to browser
DEBUG - 2023-05-31 07:49:01 --> Total execution time: 0.4901
INFO - 2023-05-31 07:51:21 --> Config Class Initialized
INFO - 2023-05-31 07:51:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:21 --> URI Class Initialized
INFO - 2023-05-31 07:51:21 --> Router Class Initialized
INFO - 2023-05-31 07:51:21 --> Output Class Initialized
INFO - 2023-05-31 07:51:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:21 --> Input Class Initialized
INFO - 2023-05-31 07:51:21 --> Language Class Initialized
INFO - 2023-05-31 07:51:21 --> Loader Class Initialized
INFO - 2023-05-31 07:51:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:21 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:21 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:21 --> Total execution time: 0.3624
INFO - 2023-05-31 07:51:21 --> Config Class Initialized
INFO - 2023-05-31 07:51:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:21 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:21 --> URI Class Initialized
INFO - 2023-05-31 07:51:21 --> Router Class Initialized
INFO - 2023-05-31 07:51:21 --> Output Class Initialized
INFO - 2023-05-31 07:51:21 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:21 --> Input Class Initialized
INFO - 2023-05-31 07:51:21 --> Language Class Initialized
INFO - 2023-05-31 07:51:21 --> Loader Class Initialized
INFO - 2023-05-31 07:51:21 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:22 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:22 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:22 --> Total execution time: 0.2534
INFO - 2023-05-31 07:51:28 --> Config Class Initialized
INFO - 2023-05-31 07:51:28 --> Config Class Initialized
INFO - 2023-05-31 07:51:28 --> Config Class Initialized
INFO - 2023-05-31 07:51:28 --> Hooks Class Initialized
INFO - 2023-05-31 07:51:28 --> Hooks Class Initialized
INFO - 2023-05-31 07:51:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:51:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:28 --> URI Class Initialized
INFO - 2023-05-31 07:51:28 --> URI Class Initialized
INFO - 2023-05-31 07:51:28 --> URI Class Initialized
INFO - 2023-05-31 07:51:28 --> Router Class Initialized
INFO - 2023-05-31 07:51:28 --> Router Class Initialized
INFO - 2023-05-31 07:51:28 --> Router Class Initialized
INFO - 2023-05-31 07:51:28 --> Output Class Initialized
INFO - 2023-05-31 07:51:28 --> Output Class Initialized
INFO - 2023-05-31 07:51:28 --> Output Class Initialized
INFO - 2023-05-31 07:51:28 --> Security Class Initialized
INFO - 2023-05-31 07:51:28 --> Security Class Initialized
INFO - 2023-05-31 07:51:28 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:28 --> Input Class Initialized
INFO - 2023-05-31 07:51:28 --> Input Class Initialized
INFO - 2023-05-31 07:51:28 --> Input Class Initialized
INFO - 2023-05-31 07:51:28 --> Language Class Initialized
INFO - 2023-05-31 07:51:28 --> Language Class Initialized
INFO - 2023-05-31 07:51:28 --> Language Class Initialized
INFO - 2023-05-31 07:51:28 --> Loader Class Initialized
INFO - 2023-05-31 07:51:28 --> Loader Class Initialized
INFO - 2023-05-31 07:51:28 --> Loader Class Initialized
INFO - 2023-05-31 07:51:28 --> Controller Class Initialized
INFO - 2023-05-31 07:51:28 --> Controller Class Initialized
INFO - 2023-05-31 07:51:28 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:51:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:51:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:28 --> Model "Login_model" initialized
INFO - 2023-05-31 07:51:28 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:28 --> Total execution time: 0.1921
INFO - 2023-05-31 07:51:28 --> Final output sent to browser
INFO - 2023-05-31 07:51:28 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:28 --> Total execution time: 0.2050
DEBUG - 2023-05-31 07:51:28 --> Total execution time: 0.2090
INFO - 2023-05-31 07:51:28 --> Config Class Initialized
INFO - 2023-05-31 07:51:28 --> Config Class Initialized
INFO - 2023-05-31 07:51:28 --> Config Class Initialized
INFO - 2023-05-31 07:51:28 --> Hooks Class Initialized
INFO - 2023-05-31 07:51:28 --> Hooks Class Initialized
INFO - 2023-05-31 07:51:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:51:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:28 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:28 --> URI Class Initialized
INFO - 2023-05-31 07:51:28 --> URI Class Initialized
INFO - 2023-05-31 07:51:28 --> URI Class Initialized
INFO - 2023-05-31 07:51:28 --> Router Class Initialized
INFO - 2023-05-31 07:51:28 --> Router Class Initialized
INFO - 2023-05-31 07:51:28 --> Router Class Initialized
INFO - 2023-05-31 07:51:28 --> Output Class Initialized
INFO - 2023-05-31 07:51:28 --> Output Class Initialized
INFO - 2023-05-31 07:51:28 --> Output Class Initialized
INFO - 2023-05-31 07:51:28 --> Security Class Initialized
INFO - 2023-05-31 07:51:28 --> Security Class Initialized
INFO - 2023-05-31 07:51:28 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:28 --> Input Class Initialized
INFO - 2023-05-31 07:51:28 --> Input Class Initialized
INFO - 2023-05-31 07:51:28 --> Input Class Initialized
INFO - 2023-05-31 07:51:28 --> Language Class Initialized
INFO - 2023-05-31 07:51:28 --> Language Class Initialized
INFO - 2023-05-31 07:51:28 --> Language Class Initialized
INFO - 2023-05-31 07:51:28 --> Loader Class Initialized
INFO - 2023-05-31 07:51:28 --> Loader Class Initialized
INFO - 2023-05-31 07:51:28 --> Loader Class Initialized
INFO - 2023-05-31 07:51:28 --> Controller Class Initialized
INFO - 2023-05-31 07:51:28 --> Controller Class Initialized
INFO - 2023-05-31 07:51:28 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:51:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 07:51:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:28 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:28 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:28 --> Total execution time: 0.2227
INFO - 2023-05-31 07:51:28 --> Final output sent to browser
INFO - 2023-05-31 07:51:28 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:28 --> Total execution time: 0.2257
DEBUG - 2023-05-31 07:51:28 --> Total execution time: 0.2264
INFO - 2023-05-31 07:51:28 --> Config Class Initialized
INFO - 2023-05-31 07:51:28 --> Hooks Class Initialized
INFO - 2023-05-31 07:51:28 --> Config Class Initialized
INFO - 2023-05-31 07:51:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:29 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:29 --> URI Class Initialized
DEBUG - 2023-05-31 07:51:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:29 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:29 --> URI Class Initialized
INFO - 2023-05-31 07:51:29 --> Router Class Initialized
INFO - 2023-05-31 07:51:29 --> Router Class Initialized
INFO - 2023-05-31 07:51:29 --> Output Class Initialized
INFO - 2023-05-31 07:51:29 --> Output Class Initialized
INFO - 2023-05-31 07:51:29 --> Security Class Initialized
INFO - 2023-05-31 07:51:29 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:29 --> Input Class Initialized
INFO - 2023-05-31 07:51:29 --> Language Class Initialized
DEBUG - 2023-05-31 07:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:29 --> Input Class Initialized
INFO - 2023-05-31 07:51:29 --> Language Class Initialized
INFO - 2023-05-31 07:51:29 --> Loader Class Initialized
INFO - 2023-05-31 07:51:29 --> Loader Class Initialized
INFO - 2023-05-31 07:51:29 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:29 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:29 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:29 --> Model "Login_model" initialized
INFO - 2023-05-31 07:51:29 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:29 --> Total execution time: 0.2452
INFO - 2023-05-31 07:51:29 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:29 --> Total execution time: 0.2546
INFO - 2023-05-31 07:51:32 --> Config Class Initialized
INFO - 2023-05-31 07:51:32 --> Config Class Initialized
INFO - 2023-05-31 07:51:32 --> Hooks Class Initialized
INFO - 2023-05-31 07:51:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:32 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 07:51:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:32 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:32 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:32 --> URI Class Initialized
INFO - 2023-05-31 07:51:32 --> URI Class Initialized
INFO - 2023-05-31 07:51:32 --> Router Class Initialized
INFO - 2023-05-31 07:51:32 --> Router Class Initialized
INFO - 2023-05-31 07:51:32 --> Output Class Initialized
INFO - 2023-05-31 07:51:32 --> Output Class Initialized
INFO - 2023-05-31 07:51:32 --> Security Class Initialized
INFO - 2023-05-31 07:51:32 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 07:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:32 --> Input Class Initialized
INFO - 2023-05-31 07:51:32 --> Input Class Initialized
INFO - 2023-05-31 07:51:32 --> Language Class Initialized
INFO - 2023-05-31 07:51:32 --> Language Class Initialized
INFO - 2023-05-31 07:51:32 --> Loader Class Initialized
INFO - 2023-05-31 07:51:32 --> Loader Class Initialized
INFO - 2023-05-31 07:51:32 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:32 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:32 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:32 --> Total execution time: 0.1698
INFO - 2023-05-31 07:51:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:32 --> Config Class Initialized
INFO - 2023-05-31 07:51:32 --> Model "Login_model" initialized
INFO - 2023-05-31 07:51:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:32 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:32 --> URI Class Initialized
INFO - 2023-05-31 07:51:32 --> Router Class Initialized
INFO - 2023-05-31 07:51:32 --> Output Class Initialized
INFO - 2023-05-31 07:51:32 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:32 --> Input Class Initialized
INFO - 2023-05-31 07:51:32 --> Language Class Initialized
INFO - 2023-05-31 07:51:32 --> Loader Class Initialized
INFO - 2023-05-31 07:51:32 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:32 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:32 --> Total execution time: 0.1834
INFO - 2023-05-31 07:51:32 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:32 --> Total execution time: 0.3921
INFO - 2023-05-31 07:51:32 --> Config Class Initialized
INFO - 2023-05-31 07:51:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:32 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:32 --> URI Class Initialized
INFO - 2023-05-31 07:51:32 --> Router Class Initialized
INFO - 2023-05-31 07:51:32 --> Output Class Initialized
INFO - 2023-05-31 07:51:32 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:32 --> Input Class Initialized
INFO - 2023-05-31 07:51:32 --> Language Class Initialized
INFO - 2023-05-31 07:51:32 --> Loader Class Initialized
INFO - 2023-05-31 07:51:32 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:32 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:33 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:33 --> Model "Login_model" initialized
INFO - 2023-05-31 07:51:33 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:33 --> Total execution time: 0.8396
INFO - 2023-05-31 07:51:37 --> Config Class Initialized
INFO - 2023-05-31 07:51:37 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:37 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:37 --> URI Class Initialized
INFO - 2023-05-31 07:51:37 --> Router Class Initialized
INFO - 2023-05-31 07:51:37 --> Output Class Initialized
INFO - 2023-05-31 07:51:37 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:37 --> Input Class Initialized
INFO - 2023-05-31 07:51:37 --> Language Class Initialized
INFO - 2023-05-31 07:51:37 --> Loader Class Initialized
INFO - 2023-05-31 07:51:37 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:37 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:37 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:37 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:37 --> Total execution time: 0.3937
INFO - 2023-05-31 07:51:37 --> Config Class Initialized
INFO - 2023-05-31 07:51:37 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:37 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:37 --> URI Class Initialized
INFO - 2023-05-31 07:51:37 --> Router Class Initialized
INFO - 2023-05-31 07:51:37 --> Output Class Initialized
INFO - 2023-05-31 07:51:37 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:37 --> Input Class Initialized
INFO - 2023-05-31 07:51:37 --> Language Class Initialized
INFO - 2023-05-31 07:51:37 --> Loader Class Initialized
INFO - 2023-05-31 07:51:37 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:37 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:37 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:37 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:37 --> Total execution time: 0.1850
INFO - 2023-05-31 07:51:42 --> Config Class Initialized
INFO - 2023-05-31 07:51:42 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:42 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:42 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:42 --> URI Class Initialized
INFO - 2023-05-31 07:51:42 --> Router Class Initialized
INFO - 2023-05-31 07:51:42 --> Output Class Initialized
INFO - 2023-05-31 07:51:42 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:42 --> Input Class Initialized
INFO - 2023-05-31 07:51:42 --> Language Class Initialized
INFO - 2023-05-31 07:51:42 --> Loader Class Initialized
INFO - 2023-05-31 07:51:42 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:42 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:42 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:42 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:42 --> Total execution time: 0.2331
INFO - 2023-05-31 07:51:42 --> Config Class Initialized
INFO - 2023-05-31 07:51:42 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:42 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:42 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:42 --> URI Class Initialized
INFO - 2023-05-31 07:51:42 --> Router Class Initialized
INFO - 2023-05-31 07:51:42 --> Output Class Initialized
INFO - 2023-05-31 07:51:42 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:42 --> Input Class Initialized
INFO - 2023-05-31 07:51:42 --> Language Class Initialized
INFO - 2023-05-31 07:51:42 --> Loader Class Initialized
INFO - 2023-05-31 07:51:42 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:42 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:42 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:42 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:42 --> Total execution time: 0.2074
INFO - 2023-05-31 07:51:53 --> Config Class Initialized
INFO - 2023-05-31 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:53 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:53 --> URI Class Initialized
INFO - 2023-05-31 07:51:53 --> Router Class Initialized
INFO - 2023-05-31 07:51:53 --> Output Class Initialized
INFO - 2023-05-31 07:51:53 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:53 --> Input Class Initialized
INFO - 2023-05-31 07:51:53 --> Language Class Initialized
INFO - 2023-05-31 07:51:53 --> Loader Class Initialized
INFO - 2023-05-31 07:51:53 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:53 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:53 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:53 --> Total execution time: 0.2421
INFO - 2023-05-31 07:51:53 --> Config Class Initialized
INFO - 2023-05-31 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:53 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:53 --> URI Class Initialized
INFO - 2023-05-31 07:51:53 --> Router Class Initialized
INFO - 2023-05-31 07:51:53 --> Output Class Initialized
INFO - 2023-05-31 07:51:53 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:53 --> Input Class Initialized
INFO - 2023-05-31 07:51:53 --> Language Class Initialized
INFO - 2023-05-31 07:51:53 --> Loader Class Initialized
INFO - 2023-05-31 07:51:54 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:54 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:54 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:54 --> Total execution time: 0.2061
INFO - 2023-05-31 07:51:55 --> Config Class Initialized
INFO - 2023-05-31 07:51:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:55 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:55 --> URI Class Initialized
INFO - 2023-05-31 07:51:55 --> Router Class Initialized
INFO - 2023-05-31 07:51:55 --> Output Class Initialized
INFO - 2023-05-31 07:51:55 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:55 --> Input Class Initialized
INFO - 2023-05-31 07:51:55 --> Language Class Initialized
INFO - 2023-05-31 07:51:55 --> Loader Class Initialized
INFO - 2023-05-31 07:51:55 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:55 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:55 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:55 --> Total execution time: 0.1839
INFO - 2023-05-31 07:51:55 --> Config Class Initialized
INFO - 2023-05-31 07:51:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:55 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:55 --> URI Class Initialized
INFO - 2023-05-31 07:51:55 --> Router Class Initialized
INFO - 2023-05-31 07:51:55 --> Output Class Initialized
INFO - 2023-05-31 07:51:55 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:55 --> Input Class Initialized
INFO - 2023-05-31 07:51:55 --> Language Class Initialized
INFO - 2023-05-31 07:51:55 --> Loader Class Initialized
INFO - 2023-05-31 07:51:55 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:55 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:55 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:55 --> Total execution time: 0.1921
INFO - 2023-05-31 07:51:56 --> Config Class Initialized
INFO - 2023-05-31 07:51:56 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:56 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:56 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:56 --> URI Class Initialized
INFO - 2023-05-31 07:51:56 --> Router Class Initialized
INFO - 2023-05-31 07:51:56 --> Output Class Initialized
INFO - 2023-05-31 07:51:56 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:56 --> Input Class Initialized
INFO - 2023-05-31 07:51:56 --> Language Class Initialized
INFO - 2023-05-31 07:51:56 --> Loader Class Initialized
INFO - 2023-05-31 07:51:56 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:56 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:56 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:56 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:56 --> Total execution time: 0.1712
INFO - 2023-05-31 07:51:56 --> Config Class Initialized
INFO - 2023-05-31 07:51:56 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:51:56 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:51:56 --> Utf8 Class Initialized
INFO - 2023-05-31 07:51:56 --> URI Class Initialized
INFO - 2023-05-31 07:51:56 --> Router Class Initialized
INFO - 2023-05-31 07:51:56 --> Output Class Initialized
INFO - 2023-05-31 07:51:56 --> Security Class Initialized
DEBUG - 2023-05-31 07:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:51:56 --> Input Class Initialized
INFO - 2023-05-31 07:51:56 --> Language Class Initialized
INFO - 2023-05-31 07:51:56 --> Loader Class Initialized
INFO - 2023-05-31 07:51:56 --> Controller Class Initialized
DEBUG - 2023-05-31 07:51:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:51:56 --> Database Driver Class Initialized
INFO - 2023-05-31 07:51:56 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:51:56 --> Final output sent to browser
DEBUG - 2023-05-31 07:51:56 --> Total execution time: 0.1786
INFO - 2023-05-31 07:52:04 --> Config Class Initialized
INFO - 2023-05-31 07:52:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:52:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:52:04 --> Utf8 Class Initialized
INFO - 2023-05-31 07:52:04 --> URI Class Initialized
INFO - 2023-05-31 07:52:04 --> Router Class Initialized
INFO - 2023-05-31 07:52:04 --> Output Class Initialized
INFO - 2023-05-31 07:52:04 --> Security Class Initialized
DEBUG - 2023-05-31 07:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:52:04 --> Input Class Initialized
INFO - 2023-05-31 07:52:04 --> Language Class Initialized
INFO - 2023-05-31 07:52:04 --> Loader Class Initialized
INFO - 2023-05-31 07:52:04 --> Controller Class Initialized
DEBUG - 2023-05-31 07:52:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:52:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:52:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 07:52:05 --> Final output sent to browser
DEBUG - 2023-05-31 07:52:05 --> Total execution time: 0.2237
INFO - 2023-05-31 07:52:05 --> Config Class Initialized
INFO - 2023-05-31 07:52:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 07:52:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 07:52:05 --> Utf8 Class Initialized
INFO - 2023-05-31 07:52:05 --> URI Class Initialized
INFO - 2023-05-31 07:52:05 --> Router Class Initialized
INFO - 2023-05-31 07:52:05 --> Output Class Initialized
INFO - 2023-05-31 07:52:05 --> Security Class Initialized
DEBUG - 2023-05-31 07:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 07:52:05 --> Input Class Initialized
INFO - 2023-05-31 07:52:05 --> Language Class Initialized
INFO - 2023-05-31 07:52:05 --> Loader Class Initialized
INFO - 2023-05-31 07:52:05 --> Controller Class Initialized
DEBUG - 2023-05-31 07:52:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 07:52:05 --> Database Driver Class Initialized
INFO - 2023-05-31 07:52:05 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 07:52:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '34' at line 1 - Invalid query: 34
INFO - 2023-05-31 07:52:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-31 08:13:59 --> Config Class Initialized
INFO - 2023-05-31 08:13:59 --> Config Class Initialized
INFO - 2023-05-31 08:13:59 --> Hooks Class Initialized
INFO - 2023-05-31 08:13:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:13:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:13:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:13:59 --> Utf8 Class Initialized
INFO - 2023-05-31 08:13:59 --> Utf8 Class Initialized
INFO - 2023-05-31 08:13:59 --> URI Class Initialized
INFO - 2023-05-31 08:13:59 --> URI Class Initialized
INFO - 2023-05-31 08:13:59 --> Router Class Initialized
INFO - 2023-05-31 08:13:59 --> Router Class Initialized
INFO - 2023-05-31 08:13:59 --> Output Class Initialized
INFO - 2023-05-31 08:13:59 --> Output Class Initialized
INFO - 2023-05-31 08:13:59 --> Security Class Initialized
INFO - 2023-05-31 08:13:59 --> Security Class Initialized
DEBUG - 2023-05-31 08:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:13:59 --> Input Class Initialized
INFO - 2023-05-31 08:13:59 --> Input Class Initialized
INFO - 2023-05-31 08:13:59 --> Language Class Initialized
INFO - 2023-05-31 08:13:59 --> Language Class Initialized
INFO - 2023-05-31 08:13:59 --> Loader Class Initialized
INFO - 2023-05-31 08:13:59 --> Loader Class Initialized
INFO - 2023-05-31 08:13:59 --> Controller Class Initialized
DEBUG - 2023-05-31 08:13:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:13:59 --> Controller Class Initialized
DEBUG - 2023-05-31 08:13:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:13:59 --> Database Driver Class Initialized
INFO - 2023-05-31 08:13:59 --> Database Driver Class Initialized
INFO - 2023-05-31 08:13:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:13:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:13:59 --> Final output sent to browser
DEBUG - 2023-05-31 08:13:59 --> Total execution time: 0.3519
INFO - 2023-05-31 08:13:59 --> Database Driver Class Initialized
INFO - 2023-05-31 08:13:59 --> Model "Login_model" initialized
INFO - 2023-05-31 08:13:59 --> Config Class Initialized
INFO - 2023-05-31 08:13:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:13:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:13:59 --> Utf8 Class Initialized
INFO - 2023-05-31 08:13:59 --> URI Class Initialized
INFO - 2023-05-31 08:13:59 --> Router Class Initialized
INFO - 2023-05-31 08:13:59 --> Output Class Initialized
INFO - 2023-05-31 08:13:59 --> Security Class Initialized
DEBUG - 2023-05-31 08:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:13:59 --> Input Class Initialized
INFO - 2023-05-31 08:13:59 --> Language Class Initialized
INFO - 2023-05-31 08:13:59 --> Loader Class Initialized
INFO - 2023-05-31 08:13:59 --> Controller Class Initialized
DEBUG - 2023-05-31 08:13:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:13:59 --> Database Driver Class Initialized
INFO - 2023-05-31 08:13:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:13:59 --> Final output sent to browser
DEBUG - 2023-05-31 08:13:59 --> Total execution time: 0.2856
INFO - 2023-05-31 08:14:00 --> Final output sent to browser
DEBUG - 2023-05-31 08:14:00 --> Total execution time: 0.9968
INFO - 2023-05-31 08:14:00 --> Config Class Initialized
INFO - 2023-05-31 08:14:00 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:00 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:00 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:00 --> URI Class Initialized
INFO - 2023-05-31 08:14:00 --> Router Class Initialized
INFO - 2023-05-31 08:14:00 --> Output Class Initialized
INFO - 2023-05-31 08:14:00 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:00 --> Input Class Initialized
INFO - 2023-05-31 08:14:00 --> Language Class Initialized
INFO - 2023-05-31 08:14:00 --> Loader Class Initialized
INFO - 2023-05-31 08:14:00 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:00 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:00 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:14:00 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:00 --> Model "Login_model" initialized
INFO - 2023-05-31 08:14:00 --> Final output sent to browser
DEBUG - 2023-05-31 08:14:00 --> Total execution time: 0.7117
INFO - 2023-05-31 08:14:04 --> Config Class Initialized
INFO - 2023-05-31 08:14:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:04 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:04 --> URI Class Initialized
INFO - 2023-05-31 08:14:04 --> Router Class Initialized
INFO - 2023-05-31 08:14:04 --> Output Class Initialized
INFO - 2023-05-31 08:14:04 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:04 --> Input Class Initialized
INFO - 2023-05-31 08:14:04 --> Language Class Initialized
INFO - 2023-05-31 08:14:04 --> Loader Class Initialized
INFO - 2023-05-31 08:14:04 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:04 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:14:04 --> Final output sent to browser
DEBUG - 2023-05-31 08:14:04 --> Total execution time: 0.1767
INFO - 2023-05-31 08:14:04 --> Config Class Initialized
INFO - 2023-05-31 08:14:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:04 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:04 --> URI Class Initialized
INFO - 2023-05-31 08:14:04 --> Router Class Initialized
INFO - 2023-05-31 08:14:04 --> Output Class Initialized
INFO - 2023-05-31 08:14:04 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:04 --> Input Class Initialized
INFO - 2023-05-31 08:14:04 --> Language Class Initialized
INFO - 2023-05-31 08:14:04 --> Loader Class Initialized
INFO - 2023-05-31 08:14:04 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:04 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:14:04 --> Final output sent to browser
DEBUG - 2023-05-31 08:14:04 --> Total execution time: 0.2030
INFO - 2023-05-31 08:14:06 --> Config Class Initialized
INFO - 2023-05-31 08:14:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:06 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:06 --> URI Class Initialized
INFO - 2023-05-31 08:14:06 --> Router Class Initialized
INFO - 2023-05-31 08:14:06 --> Output Class Initialized
INFO - 2023-05-31 08:14:06 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:06 --> Input Class Initialized
INFO - 2023-05-31 08:14:06 --> Language Class Initialized
INFO - 2023-05-31 08:14:06 --> Loader Class Initialized
INFO - 2023-05-31 08:14:06 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:06 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:14:06 --> Final output sent to browser
DEBUG - 2023-05-31 08:14:06 --> Total execution time: 0.1892
INFO - 2023-05-31 08:14:06 --> Config Class Initialized
INFO - 2023-05-31 08:14:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:06 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:06 --> URI Class Initialized
INFO - 2023-05-31 08:14:06 --> Router Class Initialized
INFO - 2023-05-31 08:14:06 --> Output Class Initialized
INFO - 2023-05-31 08:14:06 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:06 --> Input Class Initialized
INFO - 2023-05-31 08:14:06 --> Language Class Initialized
INFO - 2023-05-31 08:14:06 --> Loader Class Initialized
INFO - 2023-05-31 08:14:06 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:06 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:14:06 --> Final output sent to browser
DEBUG - 2023-05-31 08:14:06 --> Total execution time: 0.1731
INFO - 2023-05-31 08:14:09 --> Config Class Initialized
INFO - 2023-05-31 08:14:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:09 --> URI Class Initialized
INFO - 2023-05-31 08:14:09 --> Router Class Initialized
INFO - 2023-05-31 08:14:09 --> Output Class Initialized
INFO - 2023-05-31 08:14:09 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:09 --> Input Class Initialized
INFO - 2023-05-31 08:14:09 --> Language Class Initialized
INFO - 2023-05-31 08:14:09 --> Loader Class Initialized
INFO - 2023-05-31 08:14:09 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:14:09 --> Final output sent to browser
DEBUG - 2023-05-31 08:14:09 --> Total execution time: 0.1737
INFO - 2023-05-31 08:14:09 --> Config Class Initialized
INFO - 2023-05-31 08:14:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:09 --> URI Class Initialized
INFO - 2023-05-31 08:14:09 --> Router Class Initialized
INFO - 2023-05-31 08:14:09 --> Output Class Initialized
INFO - 2023-05-31 08:14:09 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:09 --> Input Class Initialized
INFO - 2023-05-31 08:14:09 --> Language Class Initialized
INFO - 2023-05-31 08:14:09 --> Loader Class Initialized
INFO - 2023-05-31 08:14:09 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:09 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:14:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '11' at line 1 - Invalid query: 11
INFO - 2023-05-31 08:14:09 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-31 08:14:31 --> Config Class Initialized
INFO - 2023-05-31 08:14:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:31 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:31 --> URI Class Initialized
INFO - 2023-05-31 08:14:31 --> Router Class Initialized
INFO - 2023-05-31 08:14:31 --> Output Class Initialized
INFO - 2023-05-31 08:14:31 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:31 --> Input Class Initialized
INFO - 2023-05-31 08:14:31 --> Language Class Initialized
INFO - 2023-05-31 08:14:31 --> Loader Class Initialized
INFO - 2023-05-31 08:14:31 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:31 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:14:31 --> Final output sent to browser
DEBUG - 2023-05-31 08:14:31 --> Total execution time: 0.1880
INFO - 2023-05-31 08:14:31 --> Config Class Initialized
INFO - 2023-05-31 08:14:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:14:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:14:31 --> Utf8 Class Initialized
INFO - 2023-05-31 08:14:31 --> URI Class Initialized
INFO - 2023-05-31 08:14:31 --> Router Class Initialized
INFO - 2023-05-31 08:14:31 --> Output Class Initialized
INFO - 2023-05-31 08:14:31 --> Security Class Initialized
DEBUG - 2023-05-31 08:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:14:31 --> Input Class Initialized
INFO - 2023-05-31 08:14:31 --> Language Class Initialized
INFO - 2023-05-31 08:14:31 --> Loader Class Initialized
INFO - 2023-05-31 08:14:31 --> Controller Class Initialized
DEBUG - 2023-05-31 08:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:14:31 --> Database Driver Class Initialized
INFO - 2023-05-31 08:14:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:22:29 --> Config Class Initialized
INFO - 2023-05-31 08:22:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:22:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:22:29 --> Utf8 Class Initialized
INFO - 2023-05-31 08:22:29 --> URI Class Initialized
INFO - 2023-05-31 08:22:29 --> Router Class Initialized
INFO - 2023-05-31 08:22:29 --> Output Class Initialized
INFO - 2023-05-31 08:22:29 --> Security Class Initialized
DEBUG - 2023-05-31 08:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:22:29 --> Input Class Initialized
INFO - 2023-05-31 08:22:29 --> Language Class Initialized
INFO - 2023-05-31 08:22:29 --> Loader Class Initialized
INFO - 2023-05-31 08:22:29 --> Controller Class Initialized
DEBUG - 2023-05-31 08:22:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:22:29 --> Database Driver Class Initialized
INFO - 2023-05-31 08:22:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:22:29 --> Final output sent to browser
DEBUG - 2023-05-31 08:22:29 --> Total execution time: 0.2282
INFO - 2023-05-31 08:22:29 --> Config Class Initialized
INFO - 2023-05-31 08:22:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:22:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:22:29 --> Utf8 Class Initialized
INFO - 2023-05-31 08:22:29 --> URI Class Initialized
INFO - 2023-05-31 08:22:29 --> Router Class Initialized
INFO - 2023-05-31 08:22:29 --> Output Class Initialized
INFO - 2023-05-31 08:22:29 --> Security Class Initialized
DEBUG - 2023-05-31 08:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:22:29 --> Input Class Initialized
INFO - 2023-05-31 08:22:29 --> Language Class Initialized
INFO - 2023-05-31 08:22:29 --> Loader Class Initialized
INFO - 2023-05-31 08:22:29 --> Controller Class Initialized
DEBUG - 2023-05-31 08:22:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:22:29 --> Database Driver Class Initialized
INFO - 2023-05-31 08:22:29 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:22:29 --> Query error: No tables used - Invalid query: SELECT *
INFO - 2023-05-31 08:22:29 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-31 08:22:54 --> Config Class Initialized
INFO - 2023-05-31 08:22:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:22:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:22:54 --> Utf8 Class Initialized
INFO - 2023-05-31 08:22:54 --> URI Class Initialized
INFO - 2023-05-31 08:22:54 --> Router Class Initialized
INFO - 2023-05-31 08:22:54 --> Output Class Initialized
INFO - 2023-05-31 08:22:54 --> Security Class Initialized
DEBUG - 2023-05-31 08:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:22:54 --> Input Class Initialized
INFO - 2023-05-31 08:22:54 --> Language Class Initialized
INFO - 2023-05-31 08:22:54 --> Loader Class Initialized
INFO - 2023-05-31 08:22:54 --> Controller Class Initialized
DEBUG - 2023-05-31 08:22:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:22:54 --> Database Driver Class Initialized
INFO - 2023-05-31 08:22:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:22:54 --> Final output sent to browser
DEBUG - 2023-05-31 08:22:54 --> Total execution time: 0.2694
INFO - 2023-05-31 08:22:54 --> Config Class Initialized
INFO - 2023-05-31 08:22:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:22:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:22:54 --> Utf8 Class Initialized
INFO - 2023-05-31 08:22:54 --> URI Class Initialized
INFO - 2023-05-31 08:22:55 --> Router Class Initialized
INFO - 2023-05-31 08:22:55 --> Output Class Initialized
INFO - 2023-05-31 08:22:55 --> Security Class Initialized
DEBUG - 2023-05-31 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:22:55 --> Input Class Initialized
INFO - 2023-05-31 08:22:55 --> Language Class Initialized
INFO - 2023-05-31 08:22:55 --> Loader Class Initialized
INFO - 2023-05-31 08:22:55 --> Controller Class Initialized
DEBUG - 2023-05-31 08:22:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:22:55 --> Database Driver Class Initialized
INFO - 2023-05-31 08:22:55 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:22:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '11' at line 1 - Invalid query: 11
INFO - 2023-05-31 08:22:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-31 08:36:10 --> Config Class Initialized
INFO - 2023-05-31 08:36:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:36:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:36:10 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:10 --> URI Class Initialized
INFO - 2023-05-31 08:36:10 --> Router Class Initialized
INFO - 2023-05-31 08:36:10 --> Output Class Initialized
INFO - 2023-05-31 08:36:10 --> Security Class Initialized
DEBUG - 2023-05-31 08:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:36:10 --> Input Class Initialized
INFO - 2023-05-31 08:36:10 --> Language Class Initialized
INFO - 2023-05-31 08:36:11 --> Loader Class Initialized
INFO - 2023-05-31 08:36:11 --> Controller Class Initialized
INFO - 2023-05-31 08:36:11 --> Helper loaded: form_helper
INFO - 2023-05-31 08:36:11 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:36:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:11 --> Model "Change_model" initialized
INFO - 2023-05-31 08:36:11 --> Model "Grafana_model" initialized
INFO - 2023-05-31 08:36:11 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:11 --> Total execution time: 0.4874
INFO - 2023-05-31 08:36:11 --> Config Class Initialized
INFO - 2023-05-31 08:36:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:36:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:36:11 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:11 --> URI Class Initialized
INFO - 2023-05-31 08:36:11 --> Router Class Initialized
INFO - 2023-05-31 08:36:11 --> Output Class Initialized
INFO - 2023-05-31 08:36:11 --> Security Class Initialized
DEBUG - 2023-05-31 08:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:36:11 --> Input Class Initialized
INFO - 2023-05-31 08:36:11 --> Language Class Initialized
INFO - 2023-05-31 08:36:11 --> Loader Class Initialized
INFO - 2023-05-31 08:36:11 --> Controller Class Initialized
INFO - 2023-05-31 08:36:11 --> Helper loaded: form_helper
INFO - 2023-05-31 08:36:11 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:36:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:11 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:11 --> Total execution time: 0.1726
INFO - 2023-05-31 08:36:11 --> Config Class Initialized
INFO - 2023-05-31 08:36:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:36:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:36:11 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:11 --> URI Class Initialized
INFO - 2023-05-31 08:36:11 --> Router Class Initialized
INFO - 2023-05-31 08:36:11 --> Output Class Initialized
INFO - 2023-05-31 08:36:11 --> Security Class Initialized
DEBUG - 2023-05-31 08:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:36:11 --> Input Class Initialized
INFO - 2023-05-31 08:36:11 --> Language Class Initialized
INFO - 2023-05-31 08:36:11 --> Loader Class Initialized
INFO - 2023-05-31 08:36:11 --> Controller Class Initialized
INFO - 2023-05-31 08:36:11 --> Helper loaded: form_helper
INFO - 2023-05-31 08:36:11 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:36:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:11 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:11 --> Model "Login_model" initialized
INFO - 2023-05-31 08:36:11 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:11 --> Total execution time: 0.2660
INFO - 2023-05-31 08:36:11 --> Config Class Initialized
INFO - 2023-05-31 08:36:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:36:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:36:11 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:11 --> URI Class Initialized
INFO - 2023-05-31 08:36:11 --> Router Class Initialized
INFO - 2023-05-31 08:36:12 --> Output Class Initialized
INFO - 2023-05-31 08:36:12 --> Security Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:36:12 --> Input Class Initialized
INFO - 2023-05-31 08:36:12 --> Language Class Initialized
INFO - 2023-05-31 08:36:12 --> Loader Class Initialized
INFO - 2023-05-31 08:36:12 --> Controller Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:36:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:12 --> Total execution time: 0.2691
INFO - 2023-05-31 08:36:12 --> Config Class Initialized
INFO - 2023-05-31 08:36:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:36:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:36:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:12 --> URI Class Initialized
INFO - 2023-05-31 08:36:12 --> Router Class Initialized
INFO - 2023-05-31 08:36:12 --> Output Class Initialized
INFO - 2023-05-31 08:36:12 --> Security Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:36:12 --> Input Class Initialized
INFO - 2023-05-31 08:36:12 --> Language Class Initialized
INFO - 2023-05-31 08:36:12 --> Loader Class Initialized
INFO - 2023-05-31 08:36:12 --> Controller Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:36:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:12 --> Total execution time: 0.1859
INFO - 2023-05-31 08:36:12 --> Config Class Initialized
INFO - 2023-05-31 08:36:12 --> Config Class Initialized
INFO - 2023-05-31 08:36:12 --> Hooks Class Initialized
INFO - 2023-05-31 08:36:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:36:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:36:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:36:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:12 --> URI Class Initialized
INFO - 2023-05-31 08:36:12 --> URI Class Initialized
INFO - 2023-05-31 08:36:12 --> Router Class Initialized
INFO - 2023-05-31 08:36:12 --> Router Class Initialized
INFO - 2023-05-31 08:36:12 --> Output Class Initialized
INFO - 2023-05-31 08:36:12 --> Output Class Initialized
INFO - 2023-05-31 08:36:12 --> Security Class Initialized
INFO - 2023-05-31 08:36:12 --> Security Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:36:12 --> Input Class Initialized
INFO - 2023-05-31 08:36:12 --> Input Class Initialized
INFO - 2023-05-31 08:36:12 --> Language Class Initialized
INFO - 2023-05-31 08:36:12 --> Language Class Initialized
INFO - 2023-05-31 08:36:12 --> Loader Class Initialized
INFO - 2023-05-31 08:36:12 --> Loader Class Initialized
INFO - 2023-05-31 08:36:12 --> Controller Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:12 --> Controller Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:36:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:12 --> Total execution time: 0.1753
INFO - 2023-05-31 08:36:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:12 --> Model "Login_model" initialized
INFO - 2023-05-31 08:36:12 --> Config Class Initialized
INFO - 2023-05-31 08:36:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:36:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:36:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:12 --> URI Class Initialized
INFO - 2023-05-31 08:36:12 --> Router Class Initialized
INFO - 2023-05-31 08:36:12 --> Output Class Initialized
INFO - 2023-05-31 08:36:12 --> Security Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:36:12 --> Input Class Initialized
INFO - 2023-05-31 08:36:12 --> Language Class Initialized
INFO - 2023-05-31 08:36:12 --> Loader Class Initialized
INFO - 2023-05-31 08:36:12 --> Controller Class Initialized
DEBUG - 2023-05-31 08:36:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:36:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:12 --> Total execution time: 0.1898
INFO - 2023-05-31 08:36:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:12 --> Total execution time: 0.4113
INFO - 2023-05-31 08:36:12 --> Config Class Initialized
INFO - 2023-05-31 08:36:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:36:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:36:13 --> Utf8 Class Initialized
INFO - 2023-05-31 08:36:13 --> URI Class Initialized
INFO - 2023-05-31 08:36:13 --> Router Class Initialized
INFO - 2023-05-31 08:36:13 --> Output Class Initialized
INFO - 2023-05-31 08:36:13 --> Security Class Initialized
DEBUG - 2023-05-31 08:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:36:13 --> Input Class Initialized
INFO - 2023-05-31 08:36:13 --> Language Class Initialized
INFO - 2023-05-31 08:36:13 --> Loader Class Initialized
INFO - 2023-05-31 08:36:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:36:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:36:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:36:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:36:13 --> Model "Login_model" initialized
INFO - 2023-05-31 08:36:13 --> Final output sent to browser
DEBUG - 2023-05-31 08:36:13 --> Total execution time: 0.9069
INFO - 2023-05-31 08:37:25 --> Config Class Initialized
INFO - 2023-05-31 08:37:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:25 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:25 --> URI Class Initialized
INFO - 2023-05-31 08:37:25 --> Router Class Initialized
INFO - 2023-05-31 08:37:25 --> Output Class Initialized
INFO - 2023-05-31 08:37:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:26 --> Input Class Initialized
INFO - 2023-05-31 08:37:26 --> Language Class Initialized
INFO - 2023-05-31 08:37:26 --> Loader Class Initialized
INFO - 2023-05-31 08:37:26 --> Controller Class Initialized
INFO - 2023-05-31 08:37:26 --> Helper loaded: form_helper
INFO - 2023-05-31 08:37:26 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:37:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:26 --> Model "Change_model" initialized
INFO - 2023-05-31 08:37:26 --> Model "Grafana_model" initialized
INFO - 2023-05-31 08:37:26 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:26 --> Total execution time: 0.4269
INFO - 2023-05-31 08:37:26 --> Config Class Initialized
INFO - 2023-05-31 08:37:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:26 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:26 --> URI Class Initialized
INFO - 2023-05-31 08:37:26 --> Router Class Initialized
INFO - 2023-05-31 08:37:26 --> Output Class Initialized
INFO - 2023-05-31 08:37:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:26 --> Input Class Initialized
INFO - 2023-05-31 08:37:26 --> Language Class Initialized
INFO - 2023-05-31 08:37:26 --> Loader Class Initialized
INFO - 2023-05-31 08:37:26 --> Controller Class Initialized
INFO - 2023-05-31 08:37:26 --> Helper loaded: form_helper
INFO - 2023-05-31 08:37:26 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:37:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:26 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:26 --> Total execution time: 0.1634
INFO - 2023-05-31 08:37:26 --> Config Class Initialized
INFO - 2023-05-31 08:37:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:26 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:26 --> URI Class Initialized
INFO - 2023-05-31 08:37:26 --> Router Class Initialized
INFO - 2023-05-31 08:37:26 --> Output Class Initialized
INFO - 2023-05-31 08:37:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:26 --> Input Class Initialized
INFO - 2023-05-31 08:37:26 --> Language Class Initialized
INFO - 2023-05-31 08:37:26 --> Loader Class Initialized
INFO - 2023-05-31 08:37:26 --> Controller Class Initialized
INFO - 2023-05-31 08:37:26 --> Helper loaded: form_helper
INFO - 2023-05-31 08:37:26 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:37:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:26 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:26 --> Model "Login_model" initialized
INFO - 2023-05-31 08:37:26 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:26 --> Total execution time: 0.3796
INFO - 2023-05-31 08:37:26 --> Config Class Initialized
INFO - 2023-05-31 08:37:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:26 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:26 --> URI Class Initialized
INFO - 2023-05-31 08:37:26 --> Router Class Initialized
INFO - 2023-05-31 08:37:26 --> Output Class Initialized
INFO - 2023-05-31 08:37:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:26 --> Input Class Initialized
INFO - 2023-05-31 08:37:27 --> Language Class Initialized
INFO - 2023-05-31 08:37:27 --> Loader Class Initialized
INFO - 2023-05-31 08:37:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:27 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:27 --> Total execution time: 0.3442
INFO - 2023-05-31 08:37:27 --> Config Class Initialized
INFO - 2023-05-31 08:37:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:27 --> URI Class Initialized
INFO - 2023-05-31 08:37:27 --> Router Class Initialized
INFO - 2023-05-31 08:37:27 --> Output Class Initialized
INFO - 2023-05-31 08:37:27 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:27 --> Input Class Initialized
INFO - 2023-05-31 08:37:27 --> Language Class Initialized
INFO - 2023-05-31 08:37:27 --> Loader Class Initialized
INFO - 2023-05-31 08:37:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:27 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:27 --> Total execution time: 0.1812
INFO - 2023-05-31 08:37:27 --> Config Class Initialized
INFO - 2023-05-31 08:37:27 --> Config Class Initialized
INFO - 2023-05-31 08:37:27 --> Hooks Class Initialized
INFO - 2023-05-31 08:37:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:37:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:27 --> URI Class Initialized
INFO - 2023-05-31 08:37:27 --> URI Class Initialized
INFO - 2023-05-31 08:37:27 --> Router Class Initialized
INFO - 2023-05-31 08:37:27 --> Router Class Initialized
INFO - 2023-05-31 08:37:27 --> Output Class Initialized
INFO - 2023-05-31 08:37:27 --> Output Class Initialized
INFO - 2023-05-31 08:37:27 --> Security Class Initialized
INFO - 2023-05-31 08:37:27 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:27 --> Input Class Initialized
INFO - 2023-05-31 08:37:27 --> Input Class Initialized
INFO - 2023-05-31 08:37:27 --> Language Class Initialized
INFO - 2023-05-31 08:37:27 --> Language Class Initialized
INFO - 2023-05-31 08:37:27 --> Loader Class Initialized
INFO - 2023-05-31 08:37:27 --> Controller Class Initialized
INFO - 2023-05-31 08:37:27 --> Loader Class Initialized
DEBUG - 2023-05-31 08:37:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:27 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:27 --> Total execution time: 0.1810
INFO - 2023-05-31 08:37:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:27 --> Config Class Initialized
INFO - 2023-05-31 08:37:27 --> Hooks Class Initialized
INFO - 2023-05-31 08:37:27 --> Model "Login_model" initialized
DEBUG - 2023-05-31 08:37:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:27 --> URI Class Initialized
INFO - 2023-05-31 08:37:27 --> Router Class Initialized
INFO - 2023-05-31 08:37:27 --> Output Class Initialized
INFO - 2023-05-31 08:37:27 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:27 --> Input Class Initialized
INFO - 2023-05-31 08:37:27 --> Language Class Initialized
INFO - 2023-05-31 08:37:27 --> Loader Class Initialized
INFO - 2023-05-31 08:37:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:27 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:27 --> Total execution time: 0.2095
INFO - 2023-05-31 08:37:28 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:28 --> Total execution time: 0.4422
INFO - 2023-05-31 08:37:28 --> Config Class Initialized
INFO - 2023-05-31 08:37:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:28 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:28 --> URI Class Initialized
INFO - 2023-05-31 08:37:28 --> Router Class Initialized
INFO - 2023-05-31 08:37:28 --> Output Class Initialized
INFO - 2023-05-31 08:37:28 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:28 --> Input Class Initialized
INFO - 2023-05-31 08:37:28 --> Language Class Initialized
INFO - 2023-05-31 08:37:28 --> Loader Class Initialized
INFO - 2023-05-31 08:37:28 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:28 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:28 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:28 --> Model "Login_model" initialized
INFO - 2023-05-31 08:37:28 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:28 --> Total execution time: 0.8004
INFO - 2023-05-31 08:37:51 --> Config Class Initialized
INFO - 2023-05-31 08:37:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:51 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:51 --> URI Class Initialized
INFO - 2023-05-31 08:37:51 --> Router Class Initialized
INFO - 2023-05-31 08:37:51 --> Output Class Initialized
INFO - 2023-05-31 08:37:51 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:51 --> Input Class Initialized
INFO - 2023-05-31 08:37:51 --> Language Class Initialized
INFO - 2023-05-31 08:37:51 --> Loader Class Initialized
INFO - 2023-05-31 08:37:51 --> Controller Class Initialized
INFO - 2023-05-31 08:37:51 --> Helper loaded: form_helper
INFO - 2023-05-31 08:37:51 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:37:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:51 --> Model "Change_model" initialized
INFO - 2023-05-31 08:37:51 --> Model "Grafana_model" initialized
INFO - 2023-05-31 08:37:51 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:51 --> Total execution time: 0.1863
INFO - 2023-05-31 08:37:51 --> Config Class Initialized
INFO - 2023-05-31 08:37:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:51 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:51 --> URI Class Initialized
INFO - 2023-05-31 08:37:51 --> Router Class Initialized
INFO - 2023-05-31 08:37:51 --> Output Class Initialized
INFO - 2023-05-31 08:37:51 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:51 --> Input Class Initialized
INFO - 2023-05-31 08:37:51 --> Language Class Initialized
INFO - 2023-05-31 08:37:51 --> Loader Class Initialized
INFO - 2023-05-31 08:37:51 --> Controller Class Initialized
INFO - 2023-05-31 08:37:51 --> Helper loaded: form_helper
INFO - 2023-05-31 08:37:51 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:37:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:51 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:51 --> Total execution time: 0.1584
INFO - 2023-05-31 08:37:52 --> Config Class Initialized
INFO - 2023-05-31 08:37:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:52 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:52 --> URI Class Initialized
INFO - 2023-05-31 08:37:52 --> Router Class Initialized
INFO - 2023-05-31 08:37:52 --> Output Class Initialized
INFO - 2023-05-31 08:37:52 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:52 --> Input Class Initialized
INFO - 2023-05-31 08:37:52 --> Language Class Initialized
INFO - 2023-05-31 08:37:52 --> Loader Class Initialized
INFO - 2023-05-31 08:37:52 --> Controller Class Initialized
INFO - 2023-05-31 08:37:52 --> Helper loaded: form_helper
INFO - 2023-05-31 08:37:52 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:37:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:52 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:52 --> Model "Login_model" initialized
INFO - 2023-05-31 08:37:52 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:52 --> Total execution time: 0.3048
INFO - 2023-05-31 08:37:52 --> Config Class Initialized
INFO - 2023-05-31 08:37:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:52 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:52 --> URI Class Initialized
INFO - 2023-05-31 08:37:52 --> Router Class Initialized
INFO - 2023-05-31 08:37:52 --> Output Class Initialized
INFO - 2023-05-31 08:37:52 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:52 --> Input Class Initialized
INFO - 2023-05-31 08:37:52 --> Language Class Initialized
INFO - 2023-05-31 08:37:52 --> Loader Class Initialized
INFO - 2023-05-31 08:37:52 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:52 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:52 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:52 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:52 --> Total execution time: 0.2043
INFO - 2023-05-31 08:37:52 --> Config Class Initialized
INFO - 2023-05-31 08:37:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:52 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:52 --> URI Class Initialized
INFO - 2023-05-31 08:37:52 --> Router Class Initialized
INFO - 2023-05-31 08:37:52 --> Output Class Initialized
INFO - 2023-05-31 08:37:52 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:52 --> Input Class Initialized
INFO - 2023-05-31 08:37:52 --> Language Class Initialized
INFO - 2023-05-31 08:37:52 --> Loader Class Initialized
INFO - 2023-05-31 08:37:52 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:52 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:53 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:53 --> Total execution time: 0.4696
INFO - 2023-05-31 08:37:53 --> Config Class Initialized
INFO - 2023-05-31 08:37:53 --> Hooks Class Initialized
INFO - 2023-05-31 08:37:53 --> Config Class Initialized
INFO - 2023-05-31 08:37:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:53 --> Utf8 Class Initialized
DEBUG - 2023-05-31 08:37:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:53 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:53 --> URI Class Initialized
INFO - 2023-05-31 08:37:53 --> URI Class Initialized
INFO - 2023-05-31 08:37:53 --> Router Class Initialized
INFO - 2023-05-31 08:37:53 --> Router Class Initialized
INFO - 2023-05-31 08:37:53 --> Output Class Initialized
INFO - 2023-05-31 08:37:53 --> Output Class Initialized
INFO - 2023-05-31 08:37:53 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:53 --> Security Class Initialized
INFO - 2023-05-31 08:37:53 --> Input Class Initialized
INFO - 2023-05-31 08:37:53 --> Language Class Initialized
DEBUG - 2023-05-31 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:53 --> Input Class Initialized
INFO - 2023-05-31 08:37:53 --> Language Class Initialized
INFO - 2023-05-31 08:37:53 --> Loader Class Initialized
INFO - 2023-05-31 08:37:53 --> Loader Class Initialized
INFO - 2023-05-31 08:37:53 --> Controller Class Initialized
INFO - 2023-05-31 08:37:53 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 08:37:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:53 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:53 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:53 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:53 --> Total execution time: 0.2132
INFO - 2023-05-31 08:37:53 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:53 --> Model "Login_model" initialized
INFO - 2023-05-31 08:37:53 --> Config Class Initialized
INFO - 2023-05-31 08:37:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:53 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:53 --> URI Class Initialized
INFO - 2023-05-31 08:37:53 --> Router Class Initialized
INFO - 2023-05-31 08:37:53 --> Output Class Initialized
INFO - 2023-05-31 08:37:53 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:53 --> Input Class Initialized
INFO - 2023-05-31 08:37:53 --> Language Class Initialized
INFO - 2023-05-31 08:37:53 --> Loader Class Initialized
INFO - 2023-05-31 08:37:53 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:53 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:53 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:53 --> Total execution time: 0.2606
INFO - 2023-05-31 08:37:53 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:53 --> Total execution time: 0.5381
INFO - 2023-05-31 08:37:53 --> Config Class Initialized
INFO - 2023-05-31 08:37:53 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:53 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:53 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:53 --> URI Class Initialized
INFO - 2023-05-31 08:37:53 --> Router Class Initialized
INFO - 2023-05-31 08:37:53 --> Output Class Initialized
INFO - 2023-05-31 08:37:53 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:53 --> Input Class Initialized
INFO - 2023-05-31 08:37:53 --> Language Class Initialized
INFO - 2023-05-31 08:37:53 --> Loader Class Initialized
INFO - 2023-05-31 08:37:53 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:53 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:53 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:53 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:53 --> Model "Login_model" initialized
INFO - 2023-05-31 08:37:54 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:54 --> Total execution time: 0.5982
INFO - 2023-05-31 08:37:58 --> Config Class Initialized
INFO - 2023-05-31 08:37:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:58 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:58 --> URI Class Initialized
INFO - 2023-05-31 08:37:58 --> Router Class Initialized
INFO - 2023-05-31 08:37:58 --> Output Class Initialized
INFO - 2023-05-31 08:37:58 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:58 --> Input Class Initialized
INFO - 2023-05-31 08:37:58 --> Language Class Initialized
INFO - 2023-05-31 08:37:58 --> Loader Class Initialized
INFO - 2023-05-31 08:37:58 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:58 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:58 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:58 --> Total execution time: 0.2881
INFO - 2023-05-31 08:37:58 --> Config Class Initialized
INFO - 2023-05-31 08:37:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:37:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:37:58 --> Utf8 Class Initialized
INFO - 2023-05-31 08:37:58 --> URI Class Initialized
INFO - 2023-05-31 08:37:58 --> Router Class Initialized
INFO - 2023-05-31 08:37:58 --> Output Class Initialized
INFO - 2023-05-31 08:37:58 --> Security Class Initialized
DEBUG - 2023-05-31 08:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:37:58 --> Input Class Initialized
INFO - 2023-05-31 08:37:58 --> Language Class Initialized
INFO - 2023-05-31 08:37:58 --> Loader Class Initialized
INFO - 2023-05-31 08:37:58 --> Controller Class Initialized
DEBUG - 2023-05-31 08:37:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:37:58 --> Database Driver Class Initialized
INFO - 2023-05-31 08:37:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:37:58 --> Final output sent to browser
DEBUG - 2023-05-31 08:37:58 --> Total execution time: 0.1845
INFO - 2023-05-31 08:38:01 --> Config Class Initialized
INFO - 2023-05-31 08:38:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:38:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:38:01 --> Utf8 Class Initialized
INFO - 2023-05-31 08:38:01 --> URI Class Initialized
INFO - 2023-05-31 08:38:01 --> Router Class Initialized
INFO - 2023-05-31 08:38:01 --> Output Class Initialized
INFO - 2023-05-31 08:38:01 --> Security Class Initialized
DEBUG - 2023-05-31 08:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:38:01 --> Input Class Initialized
INFO - 2023-05-31 08:38:01 --> Language Class Initialized
INFO - 2023-05-31 08:38:01 --> Loader Class Initialized
INFO - 2023-05-31 08:38:01 --> Controller Class Initialized
DEBUG - 2023-05-31 08:38:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:38:01 --> Database Driver Class Initialized
INFO - 2023-05-31 08:38:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:38:01 --> Final output sent to browser
DEBUG - 2023-05-31 08:38:01 --> Total execution time: 0.3762
INFO - 2023-05-31 08:38:01 --> Config Class Initialized
INFO - 2023-05-31 08:38:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:38:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:38:01 --> Utf8 Class Initialized
INFO - 2023-05-31 08:38:01 --> URI Class Initialized
INFO - 2023-05-31 08:38:01 --> Router Class Initialized
INFO - 2023-05-31 08:38:01 --> Output Class Initialized
INFO - 2023-05-31 08:38:01 --> Security Class Initialized
DEBUG - 2023-05-31 08:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:38:01 --> Input Class Initialized
INFO - 2023-05-31 08:38:01 --> Language Class Initialized
INFO - 2023-05-31 08:38:01 --> Loader Class Initialized
INFO - 2023-05-31 08:38:01 --> Controller Class Initialized
DEBUG - 2023-05-31 08:38:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:38:01 --> Database Driver Class Initialized
INFO - 2023-05-31 08:38:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:38:01 --> Final output sent to browser
DEBUG - 2023-05-31 08:38:01 --> Total execution time: 0.2089
INFO - 2023-05-31 08:38:04 --> Config Class Initialized
INFO - 2023-05-31 08:38:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:38:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:38:04 --> Utf8 Class Initialized
INFO - 2023-05-31 08:38:04 --> URI Class Initialized
INFO - 2023-05-31 08:38:04 --> Router Class Initialized
INFO - 2023-05-31 08:38:04 --> Output Class Initialized
INFO - 2023-05-31 08:38:04 --> Security Class Initialized
DEBUG - 2023-05-31 08:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:38:04 --> Input Class Initialized
INFO - 2023-05-31 08:38:04 --> Language Class Initialized
INFO - 2023-05-31 08:38:04 --> Loader Class Initialized
INFO - 2023-05-31 08:38:04 --> Controller Class Initialized
DEBUG - 2023-05-31 08:38:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:38:04 --> Database Driver Class Initialized
INFO - 2023-05-31 08:38:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:38:04 --> Final output sent to browser
DEBUG - 2023-05-31 08:38:04 --> Total execution time: 0.1780
INFO - 2023-05-31 08:38:04 --> Config Class Initialized
INFO - 2023-05-31 08:38:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:38:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:38:04 --> Utf8 Class Initialized
INFO - 2023-05-31 08:38:04 --> URI Class Initialized
INFO - 2023-05-31 08:38:04 --> Router Class Initialized
INFO - 2023-05-31 08:38:04 --> Output Class Initialized
INFO - 2023-05-31 08:38:04 --> Security Class Initialized
DEBUG - 2023-05-31 08:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:38:04 --> Input Class Initialized
INFO - 2023-05-31 08:38:04 --> Language Class Initialized
INFO - 2023-05-31 08:38:04 --> Loader Class Initialized
INFO - 2023-05-31 08:38:04 --> Controller Class Initialized
DEBUG - 2023-05-31 08:38:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:38:04 --> Database Driver Class Initialized
INFO - 2023-05-31 08:38:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:38:04 --> Final output sent to browser
DEBUG - 2023-05-31 08:38:04 --> Total execution time: 0.2060
INFO - 2023-05-31 08:38:09 --> Config Class Initialized
INFO - 2023-05-31 08:38:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:38:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:38:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:38:09 --> URI Class Initialized
INFO - 2023-05-31 08:38:09 --> Router Class Initialized
INFO - 2023-05-31 08:38:09 --> Output Class Initialized
INFO - 2023-05-31 08:38:09 --> Security Class Initialized
DEBUG - 2023-05-31 08:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:38:09 --> Input Class Initialized
INFO - 2023-05-31 08:38:09 --> Language Class Initialized
INFO - 2023-05-31 08:38:09 --> Loader Class Initialized
INFO - 2023-05-31 08:38:09 --> Controller Class Initialized
DEBUG - 2023-05-31 08:38:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:38:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:38:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:38:09 --> Final output sent to browser
DEBUG - 2023-05-31 08:38:09 --> Total execution time: 0.2142
INFO - 2023-05-31 08:38:09 --> Config Class Initialized
INFO - 2023-05-31 08:38:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:38:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:38:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:38:09 --> URI Class Initialized
INFO - 2023-05-31 08:38:09 --> Router Class Initialized
INFO - 2023-05-31 08:38:09 --> Output Class Initialized
INFO - 2023-05-31 08:38:09 --> Security Class Initialized
DEBUG - 2023-05-31 08:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:38:09 --> Input Class Initialized
INFO - 2023-05-31 08:38:09 --> Language Class Initialized
INFO - 2023-05-31 08:38:09 --> Loader Class Initialized
INFO - 2023-05-31 08:38:09 --> Controller Class Initialized
DEBUG - 2023-05-31 08:38:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:38:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:38:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:38:09 --> Final output sent to browser
DEBUG - 2023-05-31 08:38:09 --> Total execution time: 0.2371
INFO - 2023-05-31 08:38:13 --> Config Class Initialized
INFO - 2023-05-31 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:38:13 --> Utf8 Class Initialized
INFO - 2023-05-31 08:38:13 --> URI Class Initialized
INFO - 2023-05-31 08:38:13 --> Router Class Initialized
INFO - 2023-05-31 08:38:13 --> Output Class Initialized
INFO - 2023-05-31 08:38:13 --> Security Class Initialized
DEBUG - 2023-05-31 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:38:13 --> Input Class Initialized
INFO - 2023-05-31 08:38:13 --> Language Class Initialized
INFO - 2023-05-31 08:38:13 --> Loader Class Initialized
INFO - 2023-05-31 08:38:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:38:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:38:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:38:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:38:13 --> Final output sent to browser
DEBUG - 2023-05-31 08:38:13 --> Total execution time: 0.2579
INFO - 2023-05-31 08:38:14 --> Config Class Initialized
INFO - 2023-05-31 08:38:14 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:38:14 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:38:14 --> Utf8 Class Initialized
INFO - 2023-05-31 08:38:14 --> URI Class Initialized
INFO - 2023-05-31 08:38:14 --> Router Class Initialized
INFO - 2023-05-31 08:38:14 --> Output Class Initialized
INFO - 2023-05-31 08:38:14 --> Security Class Initialized
DEBUG - 2023-05-31 08:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:38:14 --> Input Class Initialized
INFO - 2023-05-31 08:38:14 --> Language Class Initialized
INFO - 2023-05-31 08:38:14 --> Loader Class Initialized
INFO - 2023-05-31 08:38:14 --> Controller Class Initialized
DEBUG - 2023-05-31 08:38:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:38:14 --> Database Driver Class Initialized
INFO - 2023-05-31 08:38:14 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:38:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:38:14 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-31 08:39:25 --> Config Class Initialized
INFO - 2023-05-31 08:39:25 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:25 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:25 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:25 --> URI Class Initialized
INFO - 2023-05-31 08:39:26 --> Router Class Initialized
INFO - 2023-05-31 08:39:26 --> Output Class Initialized
INFO - 2023-05-31 08:39:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:26 --> Input Class Initialized
INFO - 2023-05-31 08:39:26 --> Language Class Initialized
INFO - 2023-05-31 08:39:26 --> Loader Class Initialized
INFO - 2023-05-31 08:39:26 --> Controller Class Initialized
INFO - 2023-05-31 08:39:26 --> Helper loaded: form_helper
INFO - 2023-05-31 08:39:26 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:39:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:26 --> Model "Change_model" initialized
INFO - 2023-05-31 08:39:26 --> Model "Grafana_model" initialized
INFO - 2023-05-31 08:39:26 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:26 --> Total execution time: 0.6995
INFO - 2023-05-31 08:39:26 --> Config Class Initialized
INFO - 2023-05-31 08:39:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:26 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:26 --> URI Class Initialized
INFO - 2023-05-31 08:39:26 --> Router Class Initialized
INFO - 2023-05-31 08:39:26 --> Output Class Initialized
INFO - 2023-05-31 08:39:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:26 --> Input Class Initialized
INFO - 2023-05-31 08:39:26 --> Language Class Initialized
INFO - 2023-05-31 08:39:26 --> Loader Class Initialized
INFO - 2023-05-31 08:39:26 --> Controller Class Initialized
INFO - 2023-05-31 08:39:26 --> Helper loaded: form_helper
INFO - 2023-05-31 08:39:26 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:39:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:26 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:26 --> Total execution time: 0.1679
INFO - 2023-05-31 08:39:26 --> Config Class Initialized
INFO - 2023-05-31 08:39:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:26 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:26 --> URI Class Initialized
INFO - 2023-05-31 08:39:26 --> Router Class Initialized
INFO - 2023-05-31 08:39:26 --> Output Class Initialized
INFO - 2023-05-31 08:39:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:26 --> Input Class Initialized
INFO - 2023-05-31 08:39:26 --> Language Class Initialized
INFO - 2023-05-31 08:39:26 --> Loader Class Initialized
INFO - 2023-05-31 08:39:26 --> Controller Class Initialized
INFO - 2023-05-31 08:39:26 --> Helper loaded: form_helper
INFO - 2023-05-31 08:39:26 --> Helper loaded: url_helper
DEBUG - 2023-05-31 08:39:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:26 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:26 --> Model "Login_model" initialized
INFO - 2023-05-31 08:39:26 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:26 --> Total execution time: 0.2093
INFO - 2023-05-31 08:39:27 --> Config Class Initialized
INFO - 2023-05-31 08:39:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:27 --> URI Class Initialized
INFO - 2023-05-31 08:39:27 --> Router Class Initialized
INFO - 2023-05-31 08:39:27 --> Output Class Initialized
INFO - 2023-05-31 08:39:27 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:27 --> Input Class Initialized
INFO - 2023-05-31 08:39:27 --> Language Class Initialized
INFO - 2023-05-31 08:39:27 --> Loader Class Initialized
INFO - 2023-05-31 08:39:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:39:27 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:27 --> Total execution time: 0.1902
INFO - 2023-05-31 08:39:27 --> Config Class Initialized
INFO - 2023-05-31 08:39:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:27 --> URI Class Initialized
INFO - 2023-05-31 08:39:27 --> Router Class Initialized
INFO - 2023-05-31 08:39:27 --> Output Class Initialized
INFO - 2023-05-31 08:39:27 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:27 --> Input Class Initialized
INFO - 2023-05-31 08:39:27 --> Language Class Initialized
INFO - 2023-05-31 08:39:27 --> Loader Class Initialized
INFO - 2023-05-31 08:39:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:39:27 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:27 --> Total execution time: 0.1834
INFO - 2023-05-31 08:39:27 --> Config Class Initialized
INFO - 2023-05-31 08:39:27 --> Config Class Initialized
INFO - 2023-05-31 08:39:27 --> Hooks Class Initialized
INFO - 2023-05-31 08:39:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:39:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:27 --> URI Class Initialized
INFO - 2023-05-31 08:39:27 --> URI Class Initialized
INFO - 2023-05-31 08:39:27 --> Router Class Initialized
INFO - 2023-05-31 08:39:27 --> Router Class Initialized
INFO - 2023-05-31 08:39:27 --> Output Class Initialized
INFO - 2023-05-31 08:39:27 --> Output Class Initialized
INFO - 2023-05-31 08:39:27 --> Security Class Initialized
INFO - 2023-05-31 08:39:27 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:27 --> Input Class Initialized
INFO - 2023-05-31 08:39:27 --> Input Class Initialized
INFO - 2023-05-31 08:39:27 --> Language Class Initialized
INFO - 2023-05-31 08:39:27 --> Language Class Initialized
INFO - 2023-05-31 08:39:27 --> Loader Class Initialized
INFO - 2023-05-31 08:39:27 --> Loader Class Initialized
INFO - 2023-05-31 08:39:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:39:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:27 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:27 --> Total execution time: 0.1717
INFO - 2023-05-31 08:39:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:39:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:27 --> Config Class Initialized
INFO - 2023-05-31 08:39:27 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:27 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:27 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:27 --> URI Class Initialized
INFO - 2023-05-31 08:39:27 --> Router Class Initialized
INFO - 2023-05-31 08:39:27 --> Output Class Initialized
INFO - 2023-05-31 08:39:27 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:27 --> Input Class Initialized
INFO - 2023-05-31 08:39:27 --> Language Class Initialized
INFO - 2023-05-31 08:39:27 --> Loader Class Initialized
INFO - 2023-05-31 08:39:27 --> Controller Class Initialized
DEBUG - 2023-05-31 08:39:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:27 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:27 --> Model "Login_model" initialized
INFO - 2023-05-31 08:39:27 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:39:27 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:27 --> Total execution time: 0.1902
INFO - 2023-05-31 08:39:28 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:28 --> Total execution time: 0.5123
INFO - 2023-05-31 08:39:28 --> Config Class Initialized
INFO - 2023-05-31 08:39:28 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:28 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:28 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:28 --> URI Class Initialized
INFO - 2023-05-31 08:39:28 --> Router Class Initialized
INFO - 2023-05-31 08:39:28 --> Output Class Initialized
INFO - 2023-05-31 08:39:28 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:28 --> Input Class Initialized
INFO - 2023-05-31 08:39:28 --> Language Class Initialized
INFO - 2023-05-31 08:39:28 --> Loader Class Initialized
INFO - 2023-05-31 08:39:28 --> Controller Class Initialized
DEBUG - 2023-05-31 08:39:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:28 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:28 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:39:28 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:28 --> Model "Login_model" initialized
INFO - 2023-05-31 08:39:28 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:28 --> Total execution time: 0.3833
INFO - 2023-05-31 08:39:52 --> Config Class Initialized
INFO - 2023-05-31 08:39:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:52 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:52 --> URI Class Initialized
INFO - 2023-05-31 08:39:52 --> Router Class Initialized
INFO - 2023-05-31 08:39:52 --> Output Class Initialized
INFO - 2023-05-31 08:39:52 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:52 --> Input Class Initialized
INFO - 2023-05-31 08:39:52 --> Language Class Initialized
INFO - 2023-05-31 08:39:52 --> Loader Class Initialized
INFO - 2023-05-31 08:39:52 --> Controller Class Initialized
DEBUG - 2023-05-31 08:39:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:52 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:52 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:39:52 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:52 --> Total execution time: 0.2010
INFO - 2023-05-31 08:39:52 --> Config Class Initialized
INFO - 2023-05-31 08:39:52 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:39:52 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:39:52 --> Utf8 Class Initialized
INFO - 2023-05-31 08:39:52 --> URI Class Initialized
INFO - 2023-05-31 08:39:52 --> Router Class Initialized
INFO - 2023-05-31 08:39:52 --> Output Class Initialized
INFO - 2023-05-31 08:39:52 --> Security Class Initialized
DEBUG - 2023-05-31 08:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:39:52 --> Input Class Initialized
INFO - 2023-05-31 08:39:52 --> Language Class Initialized
INFO - 2023-05-31 08:39:52 --> Loader Class Initialized
INFO - 2023-05-31 08:39:52 --> Controller Class Initialized
DEBUG - 2023-05-31 08:39:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:39:52 --> Database Driver Class Initialized
INFO - 2023-05-31 08:39:52 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:39:52 --> Final output sent to browser
DEBUG - 2023-05-31 08:39:52 --> Total execution time: 0.1794
INFO - 2023-05-31 08:40:09 --> Config Class Initialized
INFO - 2023-05-31 08:40:09 --> Config Class Initialized
INFO - 2023-05-31 08:40:09 --> Hooks Class Initialized
INFO - 2023-05-31 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:09 --> URI Class Initialized
INFO - 2023-05-31 08:40:09 --> URI Class Initialized
INFO - 2023-05-31 08:40:09 --> Router Class Initialized
INFO - 2023-05-31 08:40:09 --> Router Class Initialized
INFO - 2023-05-31 08:40:09 --> Output Class Initialized
INFO - 2023-05-31 08:40:09 --> Output Class Initialized
INFO - 2023-05-31 08:40:09 --> Security Class Initialized
INFO - 2023-05-31 08:40:09 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:09 --> Input Class Initialized
INFO - 2023-05-31 08:40:09 --> Input Class Initialized
INFO - 2023-05-31 08:40:09 --> Language Class Initialized
INFO - 2023-05-31 08:40:09 --> Language Class Initialized
INFO - 2023-05-31 08:40:09 --> Loader Class Initialized
INFO - 2023-05-31 08:40:09 --> Loader Class Initialized
INFO - 2023-05-31 08:40:09 --> Controller Class Initialized
INFO - 2023-05-31 08:40:09 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 08:40:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:09 --> Final output sent to browser
INFO - 2023-05-31 08:40:09 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:09 --> Total execution time: 0.2292
DEBUG - 2023-05-31 08:40:09 --> Total execution time: 0.2340
INFO - 2023-05-31 08:40:09 --> Config Class Initialized
INFO - 2023-05-31 08:40:09 --> Config Class Initialized
INFO - 2023-05-31 08:40:09 --> Hooks Class Initialized
INFO - 2023-05-31 08:40:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:40:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:09 --> URI Class Initialized
INFO - 2023-05-31 08:40:09 --> URI Class Initialized
INFO - 2023-05-31 08:40:09 --> Router Class Initialized
INFO - 2023-05-31 08:40:09 --> Router Class Initialized
INFO - 2023-05-31 08:40:09 --> Output Class Initialized
INFO - 2023-05-31 08:40:09 --> Output Class Initialized
INFO - 2023-05-31 08:40:09 --> Security Class Initialized
INFO - 2023-05-31 08:40:09 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:10 --> Input Class Initialized
INFO - 2023-05-31 08:40:10 --> Input Class Initialized
INFO - 2023-05-31 08:40:10 --> Language Class Initialized
INFO - 2023-05-31 08:40:10 --> Language Class Initialized
INFO - 2023-05-31 08:40:10 --> Loader Class Initialized
INFO - 2023-05-31 08:40:10 --> Loader Class Initialized
INFO - 2023-05-31 08:40:10 --> Config Class Initialized
INFO - 2023-05-31 08:40:10 --> Controller Class Initialized
INFO - 2023-05-31 08:40:10 --> Hooks Class Initialized
INFO - 2023-05-31 08:40:10 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 08:40:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 08:40:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:10 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:10 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:10 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:10 --> URI Class Initialized
INFO - 2023-05-31 08:40:10 --> Router Class Initialized
INFO - 2023-05-31 08:40:10 --> Output Class Initialized
INFO - 2023-05-31 08:40:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:10 --> Security Class Initialized
INFO - 2023-05-31 08:40:10 --> Final output sent to browser
INFO - 2023-05-31 08:40:10 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:40:10 --> Total execution time: 0.2008
DEBUG - 2023-05-31 08:40:10 --> Total execution time: 0.2003
INFO - 2023-05-31 08:40:10 --> Input Class Initialized
INFO - 2023-05-31 08:40:10 --> Language Class Initialized
INFO - 2023-05-31 08:40:10 --> Loader Class Initialized
INFO - 2023-05-31 08:40:10 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:10 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:10 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:10 --> Total execution time: 0.3657
INFO - 2023-05-31 08:40:10 --> Config Class Initialized
INFO - 2023-05-31 08:40:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:10 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:10 --> URI Class Initialized
INFO - 2023-05-31 08:40:10 --> Router Class Initialized
INFO - 2023-05-31 08:40:10 --> Output Class Initialized
INFO - 2023-05-31 08:40:10 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:10 --> Input Class Initialized
INFO - 2023-05-31 08:40:10 --> Language Class Initialized
INFO - 2023-05-31 08:40:10 --> Loader Class Initialized
INFO - 2023-05-31 08:40:10 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:10 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:10 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:10 --> Total execution time: 0.2161
INFO - 2023-05-31 08:40:15 --> Config Class Initialized
INFO - 2023-05-31 08:40:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:15 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:15 --> URI Class Initialized
INFO - 2023-05-31 08:40:15 --> Router Class Initialized
INFO - 2023-05-31 08:40:15 --> Output Class Initialized
INFO - 2023-05-31 08:40:15 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:15 --> Input Class Initialized
INFO - 2023-05-31 08:40:15 --> Language Class Initialized
INFO - 2023-05-31 08:40:15 --> Loader Class Initialized
INFO - 2023-05-31 08:40:15 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:15 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:15 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:15 --> Total execution time: 0.2388
INFO - 2023-05-31 08:40:15 --> Config Class Initialized
INFO - 2023-05-31 08:40:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:15 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:15 --> URI Class Initialized
INFO - 2023-05-31 08:40:15 --> Router Class Initialized
INFO - 2023-05-31 08:40:15 --> Output Class Initialized
INFO - 2023-05-31 08:40:15 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:15 --> Input Class Initialized
INFO - 2023-05-31 08:40:15 --> Language Class Initialized
INFO - 2023-05-31 08:40:15 --> Loader Class Initialized
INFO - 2023-05-31 08:40:15 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:16 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:16 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:16 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:16 --> Total execution time: 0.1818
INFO - 2023-05-31 08:40:16 --> Config Class Initialized
INFO - 2023-05-31 08:40:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:16 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:16 --> URI Class Initialized
INFO - 2023-05-31 08:40:16 --> Router Class Initialized
INFO - 2023-05-31 08:40:16 --> Output Class Initialized
INFO - 2023-05-31 08:40:16 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:16 --> Input Class Initialized
INFO - 2023-05-31 08:40:16 --> Language Class Initialized
INFO - 2023-05-31 08:40:16 --> Loader Class Initialized
INFO - 2023-05-31 08:40:16 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:16 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:16 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:16 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:16 --> Total execution time: 0.2302
INFO - 2023-05-31 08:40:16 --> Config Class Initialized
INFO - 2023-05-31 08:40:16 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:16 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:16 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:16 --> URI Class Initialized
INFO - 2023-05-31 08:40:16 --> Router Class Initialized
INFO - 2023-05-31 08:40:16 --> Output Class Initialized
INFO - 2023-05-31 08:40:16 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:16 --> Input Class Initialized
INFO - 2023-05-31 08:40:16 --> Language Class Initialized
INFO - 2023-05-31 08:40:16 --> Loader Class Initialized
INFO - 2023-05-31 08:40:16 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:16 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:17 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:17 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:17 --> Total execution time: 0.2663
INFO - 2023-05-31 08:40:20 --> Config Class Initialized
INFO - 2023-05-31 08:40:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:20 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:20 --> URI Class Initialized
INFO - 2023-05-31 08:40:20 --> Router Class Initialized
INFO - 2023-05-31 08:40:20 --> Output Class Initialized
INFO - 2023-05-31 08:40:20 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:20 --> Input Class Initialized
INFO - 2023-05-31 08:40:20 --> Language Class Initialized
INFO - 2023-05-31 08:40:20 --> Loader Class Initialized
INFO - 2023-05-31 08:40:20 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:20 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:20 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:20 --> Total execution time: 0.1837
INFO - 2023-05-31 08:40:20 --> Config Class Initialized
INFO - 2023-05-31 08:40:20 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:20 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:20 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:20 --> URI Class Initialized
INFO - 2023-05-31 08:40:20 --> Router Class Initialized
INFO - 2023-05-31 08:40:20 --> Output Class Initialized
INFO - 2023-05-31 08:40:20 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:20 --> Input Class Initialized
INFO - 2023-05-31 08:40:20 --> Language Class Initialized
INFO - 2023-05-31 08:40:20 --> Loader Class Initialized
INFO - 2023-05-31 08:40:20 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:20 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:20 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:20 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:20 --> Total execution time: 0.3842
INFO - 2023-05-31 08:40:21 --> Config Class Initialized
INFO - 2023-05-31 08:40:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:21 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:21 --> URI Class Initialized
INFO - 2023-05-31 08:40:21 --> Router Class Initialized
INFO - 2023-05-31 08:40:21 --> Output Class Initialized
INFO - 2023-05-31 08:40:21 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:21 --> Input Class Initialized
INFO - 2023-05-31 08:40:21 --> Language Class Initialized
INFO - 2023-05-31 08:40:21 --> Loader Class Initialized
INFO - 2023-05-31 08:40:21 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:21 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:21 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:21 --> Total execution time: 0.1710
INFO - 2023-05-31 08:40:21 --> Config Class Initialized
INFO - 2023-05-31 08:40:21 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:21 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:21 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:21 --> URI Class Initialized
INFO - 2023-05-31 08:40:21 --> Router Class Initialized
INFO - 2023-05-31 08:40:21 --> Output Class Initialized
INFO - 2023-05-31 08:40:21 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:21 --> Input Class Initialized
INFO - 2023-05-31 08:40:21 --> Language Class Initialized
INFO - 2023-05-31 08:40:21 --> Loader Class Initialized
INFO - 2023-05-31 08:40:21 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:21 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:21 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:21 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:21 --> Total execution time: 0.1893
INFO - 2023-05-31 08:40:23 --> Config Class Initialized
INFO - 2023-05-31 08:40:23 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:23 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:23 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:23 --> URI Class Initialized
INFO - 2023-05-31 08:40:23 --> Router Class Initialized
INFO - 2023-05-31 08:40:23 --> Output Class Initialized
INFO - 2023-05-31 08:40:23 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:23 --> Input Class Initialized
INFO - 2023-05-31 08:40:23 --> Language Class Initialized
INFO - 2023-05-31 08:40:23 --> Loader Class Initialized
INFO - 2023-05-31 08:40:23 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:23 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:23 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:23 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:23 --> Total execution time: 0.1609
INFO - 2023-05-31 08:40:23 --> Config Class Initialized
INFO - 2023-05-31 08:40:23 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:23 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:23 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:23 --> URI Class Initialized
INFO - 2023-05-31 08:40:23 --> Router Class Initialized
INFO - 2023-05-31 08:40:23 --> Output Class Initialized
INFO - 2023-05-31 08:40:23 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:23 --> Input Class Initialized
INFO - 2023-05-31 08:40:23 --> Language Class Initialized
INFO - 2023-05-31 08:40:24 --> Loader Class Initialized
INFO - 2023-05-31 08:40:24 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:24 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:24 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:24 --> Total execution time: 0.2177
INFO - 2023-05-31 08:40:29 --> Config Class Initialized
INFO - 2023-05-31 08:40:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:29 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:29 --> URI Class Initialized
INFO - 2023-05-31 08:40:29 --> Router Class Initialized
INFO - 2023-05-31 08:40:29 --> Output Class Initialized
INFO - 2023-05-31 08:40:29 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:29 --> Input Class Initialized
INFO - 2023-05-31 08:40:29 --> Language Class Initialized
INFO - 2023-05-31 08:40:29 --> Loader Class Initialized
INFO - 2023-05-31 08:40:29 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:29 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:29 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:40:29 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:29 --> Total execution time: 0.1750
INFO - 2023-05-31 08:40:29 --> Config Class Initialized
INFO - 2023-05-31 08:40:29 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:40:29 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:40:29 --> Utf8 Class Initialized
INFO - 2023-05-31 08:40:29 --> URI Class Initialized
INFO - 2023-05-31 08:40:29 --> Router Class Initialized
INFO - 2023-05-31 08:40:29 --> Output Class Initialized
INFO - 2023-05-31 08:40:29 --> Security Class Initialized
DEBUG - 2023-05-31 08:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:40:29 --> Input Class Initialized
INFO - 2023-05-31 08:40:29 --> Language Class Initialized
INFO - 2023-05-31 08:40:29 --> Loader Class Initialized
INFO - 2023-05-31 08:40:29 --> Controller Class Initialized
DEBUG - 2023-05-31 08:40:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:40:29 --> Database Driver Class Initialized
INFO - 2023-05-31 08:40:29 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:40:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:40:29 --> Final output sent to browser
DEBUG - 2023-05-31 08:40:29 --> Total execution time: 0.2309
INFO - 2023-05-31 08:41:31 --> Config Class Initialized
INFO - 2023-05-31 08:41:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:41:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:41:31 --> Utf8 Class Initialized
INFO - 2023-05-31 08:41:31 --> URI Class Initialized
INFO - 2023-05-31 08:41:31 --> Router Class Initialized
INFO - 2023-05-31 08:41:31 --> Output Class Initialized
INFO - 2023-05-31 08:41:31 --> Security Class Initialized
DEBUG - 2023-05-31 08:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:41:31 --> Input Class Initialized
INFO - 2023-05-31 08:41:31 --> Language Class Initialized
INFO - 2023-05-31 08:41:31 --> Loader Class Initialized
INFO - 2023-05-31 08:41:31 --> Controller Class Initialized
DEBUG - 2023-05-31 08:41:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:41:31 --> Database Driver Class Initialized
INFO - 2023-05-31 08:41:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:41:31 --> Final output sent to browser
DEBUG - 2023-05-31 08:41:31 --> Total execution time: 0.2099
INFO - 2023-05-31 08:41:31 --> Config Class Initialized
INFO - 2023-05-31 08:41:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:41:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:41:31 --> Utf8 Class Initialized
INFO - 2023-05-31 08:41:31 --> URI Class Initialized
INFO - 2023-05-31 08:41:31 --> Router Class Initialized
INFO - 2023-05-31 08:41:31 --> Output Class Initialized
INFO - 2023-05-31 08:41:31 --> Security Class Initialized
DEBUG - 2023-05-31 08:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:41:31 --> Input Class Initialized
INFO - 2023-05-31 08:41:31 --> Language Class Initialized
INFO - 2023-05-31 08:41:31 --> Loader Class Initialized
INFO - 2023-05-31 08:41:31 --> Controller Class Initialized
DEBUG - 2023-05-31 08:41:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:41:31 --> Database Driver Class Initialized
INFO - 2023-05-31 08:41:31 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:41:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:41:31 --> Final output sent to browser
DEBUG - 2023-05-31 08:41:31 --> Total execution time: 0.2067
INFO - 2023-05-31 08:41:42 --> Config Class Initialized
INFO - 2023-05-31 08:41:42 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:41:42 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:41:42 --> Utf8 Class Initialized
INFO - 2023-05-31 08:41:42 --> URI Class Initialized
INFO - 2023-05-31 08:41:42 --> Router Class Initialized
INFO - 2023-05-31 08:41:42 --> Output Class Initialized
INFO - 2023-05-31 08:41:42 --> Security Class Initialized
DEBUG - 2023-05-31 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:41:42 --> Input Class Initialized
INFO - 2023-05-31 08:41:42 --> Language Class Initialized
INFO - 2023-05-31 08:41:42 --> Loader Class Initialized
INFO - 2023-05-31 08:41:42 --> Controller Class Initialized
DEBUG - 2023-05-31 08:41:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:41:42 --> Database Driver Class Initialized
INFO - 2023-05-31 08:41:42 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:41:42 --> Final output sent to browser
DEBUG - 2023-05-31 08:41:42 --> Total execution time: 0.1781
INFO - 2023-05-31 08:41:42 --> Config Class Initialized
INFO - 2023-05-31 08:41:42 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:41:42 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:41:42 --> Utf8 Class Initialized
INFO - 2023-05-31 08:41:42 --> URI Class Initialized
INFO - 2023-05-31 08:41:42 --> Router Class Initialized
INFO - 2023-05-31 08:41:42 --> Output Class Initialized
INFO - 2023-05-31 08:41:42 --> Security Class Initialized
DEBUG - 2023-05-31 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:41:42 --> Input Class Initialized
INFO - 2023-05-31 08:41:42 --> Language Class Initialized
INFO - 2023-05-31 08:41:43 --> Loader Class Initialized
INFO - 2023-05-31 08:41:43 --> Controller Class Initialized
DEBUG - 2023-05-31 08:41:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:41:43 --> Database Driver Class Initialized
INFO - 2023-05-31 08:41:43 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:41:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:41:43 --> Final output sent to browser
DEBUG - 2023-05-31 08:41:43 --> Total execution time: 0.1693
INFO - 2023-05-31 08:43:07 --> Config Class Initialized
INFO - 2023-05-31 08:43:07 --> Config Class Initialized
INFO - 2023-05-31 08:43:07 --> Hooks Class Initialized
INFO - 2023-05-31 08:43:07 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:07 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:43:07 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:07 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:07 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:07 --> URI Class Initialized
INFO - 2023-05-31 08:43:07 --> URI Class Initialized
INFO - 2023-05-31 08:43:07 --> Router Class Initialized
INFO - 2023-05-31 08:43:07 --> Router Class Initialized
INFO - 2023-05-31 08:43:07 --> Output Class Initialized
INFO - 2023-05-31 08:43:07 --> Output Class Initialized
INFO - 2023-05-31 08:43:07 --> Security Class Initialized
INFO - 2023-05-31 08:43:07 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:07 --> Input Class Initialized
INFO - 2023-05-31 08:43:07 --> Input Class Initialized
INFO - 2023-05-31 08:43:07 --> Language Class Initialized
INFO - 2023-05-31 08:43:07 --> Language Class Initialized
INFO - 2023-05-31 08:43:07 --> Loader Class Initialized
INFO - 2023-05-31 08:43:07 --> Loader Class Initialized
INFO - 2023-05-31 08:43:07 --> Controller Class Initialized
INFO - 2023-05-31 08:43:07 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 08:43:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:07 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:07 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:07 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:07 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:07 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:07 --> Total execution time: 0.1819
INFO - 2023-05-31 08:43:07 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:07 --> Config Class Initialized
INFO - 2023-05-31 08:43:07 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:07 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:07 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:07 --> URI Class Initialized
INFO - 2023-05-31 08:43:07 --> Router Class Initialized
INFO - 2023-05-31 08:43:07 --> Output Class Initialized
INFO - 2023-05-31 08:43:07 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:07 --> Input Class Initialized
INFO - 2023-05-31 08:43:07 --> Language Class Initialized
INFO - 2023-05-31 08:43:07 --> Loader Class Initialized
INFO - 2023-05-31 08:43:07 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:07 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:07 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:07 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:07 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:07 --> Total execution time: 0.2269
INFO - 2023-05-31 08:43:08 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:08 --> Total execution time: 1.2387
INFO - 2023-05-31 08:43:08 --> Config Class Initialized
INFO - 2023-05-31 08:43:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:08 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:08 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:08 --> URI Class Initialized
INFO - 2023-05-31 08:43:08 --> Router Class Initialized
INFO - 2023-05-31 08:43:08 --> Output Class Initialized
INFO - 2023-05-31 08:43:08 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:08 --> Input Class Initialized
INFO - 2023-05-31 08:43:08 --> Language Class Initialized
INFO - 2023-05-31 08:43:08 --> Loader Class Initialized
INFO - 2023-05-31 08:43:08 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:08 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:08 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:08 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:08 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:08 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:08 --> Total execution time: 0.5567
INFO - 2023-05-31 08:43:12 --> Config Class Initialized
INFO - 2023-05-31 08:43:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:12 --> URI Class Initialized
INFO - 2023-05-31 08:43:12 --> Router Class Initialized
INFO - 2023-05-31 08:43:12 --> Output Class Initialized
INFO - 2023-05-31 08:43:12 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:12 --> Input Class Initialized
INFO - 2023-05-31 08:43:12 --> Language Class Initialized
INFO - 2023-05-31 08:43:12 --> Loader Class Initialized
INFO - 2023-05-31 08:43:12 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:12 --> Total execution time: 0.1725
INFO - 2023-05-31 08:43:12 --> Config Class Initialized
INFO - 2023-05-31 08:43:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:12 --> URI Class Initialized
INFO - 2023-05-31 08:43:12 --> Router Class Initialized
INFO - 2023-05-31 08:43:12 --> Output Class Initialized
INFO - 2023-05-31 08:43:12 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:13 --> Input Class Initialized
INFO - 2023-05-31 08:43:13 --> Language Class Initialized
INFO - 2023-05-31 08:43:13 --> Loader Class Initialized
INFO - 2023-05-31 08:43:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:13 --> Config Class Initialized
INFO - 2023-05-31 08:43:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:13 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:13 --> URI Class Initialized
INFO - 2023-05-31 08:43:13 --> Router Class Initialized
INFO - 2023-05-31 08:43:13 --> Output Class Initialized
INFO - 2023-05-31 08:43:13 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:13 --> Input Class Initialized
INFO - 2023-05-31 08:43:13 --> Language Class Initialized
INFO - 2023-05-31 08:43:13 --> Loader Class Initialized
INFO - 2023-05-31 08:43:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:13 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:13 --> Total execution time: 0.1968
INFO - 2023-05-31 08:43:13 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:13 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:13 --> Total execution time: 0.4176
INFO - 2023-05-31 08:43:13 --> Config Class Initialized
INFO - 2023-05-31 08:43:13 --> Hooks Class Initialized
INFO - 2023-05-31 08:43:13 --> Config Class Initialized
INFO - 2023-05-31 08:43:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:13 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:13 --> URI Class Initialized
DEBUG - 2023-05-31 08:43:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:13 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:13 --> Router Class Initialized
INFO - 2023-05-31 08:43:13 --> URI Class Initialized
INFO - 2023-05-31 08:43:13 --> Output Class Initialized
INFO - 2023-05-31 08:43:13 --> Router Class Initialized
INFO - 2023-05-31 08:43:13 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:13 --> Output Class Initialized
INFO - 2023-05-31 08:43:13 --> Input Class Initialized
INFO - 2023-05-31 08:43:13 --> Language Class Initialized
INFO - 2023-05-31 08:43:13 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:13 --> Input Class Initialized
INFO - 2023-05-31 08:43:13 --> Language Class Initialized
INFO - 2023-05-31 08:43:13 --> Loader Class Initialized
INFO - 2023-05-31 08:43:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:13 --> Loader Class Initialized
INFO - 2023-05-31 08:43:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:13 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:13 --> Total execution time: 0.4276
INFO - 2023-05-31 08:43:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:13 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:13 --> Total execution time: 0.4162
INFO - 2023-05-31 08:43:13 --> Config Class Initialized
INFO - 2023-05-31 08:43:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:13 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:13 --> URI Class Initialized
INFO - 2023-05-31 08:43:13 --> Router Class Initialized
INFO - 2023-05-31 08:43:13 --> Output Class Initialized
INFO - 2023-05-31 08:43:13 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:13 --> Input Class Initialized
INFO - 2023-05-31 08:43:13 --> Language Class Initialized
INFO - 2023-05-31 08:43:13 --> Loader Class Initialized
INFO - 2023-05-31 08:43:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:14 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:14 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:14 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:14 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:14 --> Total execution time: 0.2186
INFO - 2023-05-31 08:43:40 --> Config Class Initialized
INFO - 2023-05-31 08:43:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:40 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:40 --> URI Class Initialized
INFO - 2023-05-31 08:43:40 --> Router Class Initialized
INFO - 2023-05-31 08:43:40 --> Output Class Initialized
INFO - 2023-05-31 08:43:40 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:40 --> Input Class Initialized
INFO - 2023-05-31 08:43:40 --> Language Class Initialized
INFO - 2023-05-31 08:43:40 --> Loader Class Initialized
INFO - 2023-05-31 08:43:40 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:40 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:40 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:40 --> Total execution time: 0.1785
INFO - 2023-05-31 08:43:40 --> Config Class Initialized
INFO - 2023-05-31 08:43:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:40 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:40 --> URI Class Initialized
INFO - 2023-05-31 08:43:40 --> Router Class Initialized
INFO - 2023-05-31 08:43:40 --> Output Class Initialized
INFO - 2023-05-31 08:43:40 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:40 --> Input Class Initialized
INFO - 2023-05-31 08:43:40 --> Language Class Initialized
INFO - 2023-05-31 08:43:40 --> Loader Class Initialized
INFO - 2023-05-31 08:43:40 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:40 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:40 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:40 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:40 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:40 --> Total execution time: 0.2182
INFO - 2023-05-31 08:43:40 --> Config Class Initialized
INFO - 2023-05-31 08:43:40 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:40 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:40 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:40 --> URI Class Initialized
INFO - 2023-05-31 08:43:40 --> Router Class Initialized
INFO - 2023-05-31 08:43:40 --> Output Class Initialized
INFO - 2023-05-31 08:43:40 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:40 --> Input Class Initialized
INFO - 2023-05-31 08:43:40 --> Language Class Initialized
INFO - 2023-05-31 08:43:40 --> Loader Class Initialized
INFO - 2023-05-31 08:43:40 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:40 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:40 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:40 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:40 --> Total execution time: 0.4294
INFO - 2023-05-31 08:43:41 --> Config Class Initialized
INFO - 2023-05-31 08:43:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:41 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:41 --> URI Class Initialized
INFO - 2023-05-31 08:43:41 --> Router Class Initialized
INFO - 2023-05-31 08:43:41 --> Output Class Initialized
INFO - 2023-05-31 08:43:41 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:41 --> Input Class Initialized
INFO - 2023-05-31 08:43:41 --> Language Class Initialized
INFO - 2023-05-31 08:43:41 --> Loader Class Initialized
INFO - 2023-05-31 08:43:41 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:41 --> Config Class Initialized
INFO - 2023-05-31 08:43:41 --> Config Class Initialized
INFO - 2023-05-31 08:43:41 --> Hooks Class Initialized
INFO - 2023-05-31 08:43:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:43:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:41 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:41 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:41 --> URI Class Initialized
INFO - 2023-05-31 08:43:41 --> URI Class Initialized
INFO - 2023-05-31 08:43:41 --> Router Class Initialized
INFO - 2023-05-31 08:43:41 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:41 --> Router Class Initialized
INFO - 2023-05-31 08:43:41 --> Output Class Initialized
INFO - 2023-05-31 08:43:41 --> Output Class Initialized
INFO - 2023-05-31 08:43:41 --> Security Class Initialized
INFO - 2023-05-31 08:43:41 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:41 --> Input Class Initialized
INFO - 2023-05-31 08:43:41 --> Input Class Initialized
INFO - 2023-05-31 08:43:41 --> Language Class Initialized
INFO - 2023-05-31 08:43:41 --> Language Class Initialized
INFO - 2023-05-31 08:43:41 --> Loader Class Initialized
INFO - 2023-05-31 08:43:41 --> Loader Class Initialized
INFO - 2023-05-31 08:43:41 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:41 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:41 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:41 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:41 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:41 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:41 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:41 --> Total execution time: 0.2230
INFO - 2023-05-31 08:43:41 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:41 --> Total execution time: 0.3774
INFO - 2023-05-31 08:43:41 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:41 --> Config Class Initialized
INFO - 2023-05-31 08:43:41 --> Hooks Class Initialized
INFO - 2023-05-31 08:43:41 --> Model "Login_model" initialized
DEBUG - 2023-05-31 08:43:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:41 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:41 --> URI Class Initialized
INFO - 2023-05-31 08:43:41 --> Router Class Initialized
INFO - 2023-05-31 08:43:41 --> Output Class Initialized
INFO - 2023-05-31 08:43:41 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:41 --> Input Class Initialized
INFO - 2023-05-31 08:43:41 --> Language Class Initialized
INFO - 2023-05-31 08:43:41 --> Loader Class Initialized
INFO - 2023-05-31 08:43:41 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:41 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:41 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:41 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:41 --> Total execution time: 0.2216
INFO - 2023-05-31 08:43:41 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:41 --> Total execution time: 0.7590
INFO - 2023-05-31 08:43:41 --> Config Class Initialized
INFO - 2023-05-31 08:43:41 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:41 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:41 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:41 --> URI Class Initialized
INFO - 2023-05-31 08:43:41 --> Router Class Initialized
INFO - 2023-05-31 08:43:41 --> Output Class Initialized
INFO - 2023-05-31 08:43:41 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:42 --> Input Class Initialized
INFO - 2023-05-31 08:43:42 --> Language Class Initialized
INFO - 2023-05-31 08:43:42 --> Loader Class Initialized
INFO - 2023-05-31 08:43:42 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:42 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:42 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:42 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:42 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:42 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:42 --> Total execution time: 0.8214
INFO - 2023-05-31 08:43:46 --> Config Class Initialized
INFO - 2023-05-31 08:43:46 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:46 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:46 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:46 --> URI Class Initialized
INFO - 2023-05-31 08:43:46 --> Router Class Initialized
INFO - 2023-05-31 08:43:46 --> Output Class Initialized
INFO - 2023-05-31 08:43:46 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:46 --> Input Class Initialized
INFO - 2023-05-31 08:43:46 --> Language Class Initialized
INFO - 2023-05-31 08:43:47 --> Loader Class Initialized
INFO - 2023-05-31 08:43:47 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:47 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:47 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:47 --> Total execution time: 0.1971
INFO - 2023-05-31 08:43:47 --> Config Class Initialized
INFO - 2023-05-31 08:43:47 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:47 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:47 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:47 --> URI Class Initialized
INFO - 2023-05-31 08:43:47 --> Router Class Initialized
INFO - 2023-05-31 08:43:47 --> Output Class Initialized
INFO - 2023-05-31 08:43:47 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:47 --> Input Class Initialized
INFO - 2023-05-31 08:43:47 --> Language Class Initialized
INFO - 2023-05-31 08:43:47 --> Loader Class Initialized
INFO - 2023-05-31 08:43:47 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:47 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:47 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:47 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:47 --> Total execution time: 0.2215
INFO - 2023-05-31 08:43:54 --> Config Class Initialized
INFO - 2023-05-31 08:43:54 --> Config Class Initialized
INFO - 2023-05-31 08:43:54 --> Hooks Class Initialized
INFO - 2023-05-31 08:43:54 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:43:54 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:54 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:54 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:54 --> URI Class Initialized
INFO - 2023-05-31 08:43:54 --> URI Class Initialized
INFO - 2023-05-31 08:43:54 --> Router Class Initialized
INFO - 2023-05-31 08:43:54 --> Router Class Initialized
INFO - 2023-05-31 08:43:54 --> Output Class Initialized
INFO - 2023-05-31 08:43:54 --> Output Class Initialized
INFO - 2023-05-31 08:43:54 --> Security Class Initialized
INFO - 2023-05-31 08:43:54 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:54 --> Input Class Initialized
INFO - 2023-05-31 08:43:54 --> Input Class Initialized
INFO - 2023-05-31 08:43:54 --> Language Class Initialized
INFO - 2023-05-31 08:43:54 --> Language Class Initialized
INFO - 2023-05-31 08:43:54 --> Loader Class Initialized
INFO - 2023-05-31 08:43:54 --> Loader Class Initialized
INFO - 2023-05-31 08:43:54 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:54 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:54 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:54 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:54 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:54 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:54 --> Total execution time: 0.1703
INFO - 2023-05-31 08:43:54 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:54 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:55 --> Config Class Initialized
INFO - 2023-05-31 08:43:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:55 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:55 --> URI Class Initialized
INFO - 2023-05-31 08:43:55 --> Router Class Initialized
INFO - 2023-05-31 08:43:55 --> Output Class Initialized
INFO - 2023-05-31 08:43:55 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:55 --> Input Class Initialized
INFO - 2023-05-31 08:43:55 --> Language Class Initialized
INFO - 2023-05-31 08:43:55 --> Loader Class Initialized
INFO - 2023-05-31 08:43:55 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:55 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:55 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:55 --> Total execution time: 0.1936
INFO - 2023-05-31 08:43:55 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:55 --> Total execution time: 0.4083
INFO - 2023-05-31 08:43:55 --> Config Class Initialized
INFO - 2023-05-31 08:43:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:43:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:43:55 --> Utf8 Class Initialized
INFO - 2023-05-31 08:43:55 --> URI Class Initialized
INFO - 2023-05-31 08:43:55 --> Router Class Initialized
INFO - 2023-05-31 08:43:55 --> Output Class Initialized
INFO - 2023-05-31 08:43:55 --> Security Class Initialized
DEBUG - 2023-05-31 08:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:43:55 --> Input Class Initialized
INFO - 2023-05-31 08:43:55 --> Language Class Initialized
INFO - 2023-05-31 08:43:55 --> Loader Class Initialized
INFO - 2023-05-31 08:43:55 --> Controller Class Initialized
DEBUG - 2023-05-31 08:43:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:43:55 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:43:55 --> Database Driver Class Initialized
INFO - 2023-05-31 08:43:55 --> Model "Login_model" initialized
INFO - 2023-05-31 08:43:55 --> Final output sent to browser
DEBUG - 2023-05-31 08:43:55 --> Total execution time: 0.6162
INFO - 2023-05-31 08:44:09 --> Config Class Initialized
INFO - 2023-05-31 08:44:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:09 --> URI Class Initialized
INFO - 2023-05-31 08:44:09 --> Router Class Initialized
INFO - 2023-05-31 08:44:09 --> Output Class Initialized
INFO - 2023-05-31 08:44:09 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:09 --> Input Class Initialized
INFO - 2023-05-31 08:44:09 --> Language Class Initialized
INFO - 2023-05-31 08:44:09 --> Loader Class Initialized
INFO - 2023-05-31 08:44:09 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:09 --> Model "Login_model" initialized
INFO - 2023-05-31 08:44:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:09 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:09 --> Total execution time: 0.2659
INFO - 2023-05-31 08:44:09 --> Config Class Initialized
INFO - 2023-05-31 08:44:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:09 --> URI Class Initialized
INFO - 2023-05-31 08:44:09 --> Router Class Initialized
INFO - 2023-05-31 08:44:09 --> Output Class Initialized
INFO - 2023-05-31 08:44:09 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:09 --> Input Class Initialized
INFO - 2023-05-31 08:44:09 --> Language Class Initialized
INFO - 2023-05-31 08:44:09 --> Loader Class Initialized
INFO - 2023-05-31 08:44:09 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:09 --> Model "Login_model" initialized
INFO - 2023-05-31 08:44:09 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:09 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:09 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:09 --> Total execution time: 0.2496
INFO - 2023-05-31 08:44:09 --> Config Class Initialized
INFO - 2023-05-31 08:44:09 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:09 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:10 --> URI Class Initialized
INFO - 2023-05-31 08:44:10 --> Router Class Initialized
INFO - 2023-05-31 08:44:10 --> Output Class Initialized
INFO - 2023-05-31 08:44:10 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:10 --> Input Class Initialized
INFO - 2023-05-31 08:44:10 --> Language Class Initialized
INFO - 2023-05-31 08:44:10 --> Loader Class Initialized
INFO - 2023-05-31 08:44:10 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:10 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:10 --> Total execution time: 0.1432
INFO - 2023-05-31 08:44:10 --> Config Class Initialized
INFO - 2023-05-31 08:44:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:10 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:10 --> URI Class Initialized
INFO - 2023-05-31 08:44:10 --> Router Class Initialized
INFO - 2023-05-31 08:44:10 --> Output Class Initialized
INFO - 2023-05-31 08:44:10 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:10 --> Input Class Initialized
INFO - 2023-05-31 08:44:10 --> Language Class Initialized
INFO - 2023-05-31 08:44:10 --> Loader Class Initialized
INFO - 2023-05-31 08:44:10 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:10 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:10 --> Model "Login_model" initialized
INFO - 2023-05-31 08:44:10 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:10 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:10 --> Total execution time: 0.2080
INFO - 2023-05-31 08:44:12 --> Config Class Initialized
INFO - 2023-05-31 08:44:12 --> Config Class Initialized
INFO - 2023-05-31 08:44:12 --> Config Class Initialized
INFO - 2023-05-31 08:44:12 --> Hooks Class Initialized
INFO - 2023-05-31 08:44:12 --> Hooks Class Initialized
INFO - 2023-05-31 08:44:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:44:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:12 --> URI Class Initialized
INFO - 2023-05-31 08:44:12 --> URI Class Initialized
INFO - 2023-05-31 08:44:12 --> URI Class Initialized
INFO - 2023-05-31 08:44:12 --> Router Class Initialized
INFO - 2023-05-31 08:44:12 --> Router Class Initialized
INFO - 2023-05-31 08:44:12 --> Router Class Initialized
INFO - 2023-05-31 08:44:12 --> Output Class Initialized
INFO - 2023-05-31 08:44:12 --> Output Class Initialized
INFO - 2023-05-31 08:44:12 --> Output Class Initialized
INFO - 2023-05-31 08:44:12 --> Security Class Initialized
INFO - 2023-05-31 08:44:12 --> Security Class Initialized
INFO - 2023-05-31 08:44:12 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:12 --> Input Class Initialized
INFO - 2023-05-31 08:44:12 --> Input Class Initialized
INFO - 2023-05-31 08:44:12 --> Input Class Initialized
INFO - 2023-05-31 08:44:12 --> Language Class Initialized
INFO - 2023-05-31 08:44:12 --> Language Class Initialized
INFO - 2023-05-31 08:44:12 --> Language Class Initialized
INFO - 2023-05-31 08:44:12 --> Loader Class Initialized
INFO - 2023-05-31 08:44:12 --> Loader Class Initialized
INFO - 2023-05-31 08:44:12 --> Controller Class Initialized
INFO - 2023-05-31 08:44:12 --> Loader Class Initialized
DEBUG - 2023-05-31 08:44:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:12 --> Controller Class Initialized
INFO - 2023-05-31 08:44:12 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 08:44:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:12 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:12 --> Total execution time: 0.1848
INFO - 2023-05-31 08:44:12 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:12 --> Total execution time: 0.1995
INFO - 2023-05-31 08:44:12 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:12 --> Total execution time: 0.2070
INFO - 2023-05-31 08:44:12 --> Config Class Initialized
INFO - 2023-05-31 08:44:12 --> Hooks Class Initialized
INFO - 2023-05-31 08:44:12 --> Config Class Initialized
INFO - 2023-05-31 08:44:12 --> Hooks Class Initialized
INFO - 2023-05-31 08:44:12 --> Config Class Initialized
INFO - 2023-05-31 08:44:12 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:12 --> URI Class Initialized
DEBUG - 2023-05-31 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:44:12 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:12 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:12 --> URI Class Initialized
INFO - 2023-05-31 08:44:12 --> URI Class Initialized
INFO - 2023-05-31 08:44:12 --> Router Class Initialized
INFO - 2023-05-31 08:44:12 --> Router Class Initialized
INFO - 2023-05-31 08:44:12 --> Router Class Initialized
INFO - 2023-05-31 08:44:12 --> Output Class Initialized
INFO - 2023-05-31 08:44:12 --> Output Class Initialized
INFO - 2023-05-31 08:44:12 --> Security Class Initialized
INFO - 2023-05-31 08:44:12 --> Output Class Initialized
INFO - 2023-05-31 08:44:12 --> Security Class Initialized
INFO - 2023-05-31 08:44:12 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:12 --> Input Class Initialized
DEBUG - 2023-05-31 08:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:13 --> Language Class Initialized
INFO - 2023-05-31 08:44:13 --> Input Class Initialized
INFO - 2023-05-31 08:44:13 --> Input Class Initialized
INFO - 2023-05-31 08:44:13 --> Language Class Initialized
INFO - 2023-05-31 08:44:13 --> Language Class Initialized
INFO - 2023-05-31 08:44:13 --> Loader Class Initialized
INFO - 2023-05-31 08:44:13 --> Loader Class Initialized
INFO - 2023-05-31 08:44:13 --> Controller Class Initialized
INFO - 2023-05-31 08:44:13 --> Loader Class Initialized
INFO - 2023-05-31 08:44:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 08:44:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:13 --> Final output sent to browser
INFO - 2023-05-31 08:44:13 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:13 --> Total execution time: 0.1873
DEBUG - 2023-05-31 08:44:13 --> Total execution time: 0.1788
INFO - 2023-05-31 08:44:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:13 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:13 --> Total execution time: 0.2352
INFO - 2023-05-31 08:44:13 --> Config Class Initialized
INFO - 2023-05-31 08:44:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:13 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:13 --> URI Class Initialized
INFO - 2023-05-31 08:44:13 --> Router Class Initialized
INFO - 2023-05-31 08:44:13 --> Output Class Initialized
INFO - 2023-05-31 08:44:13 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:13 --> Input Class Initialized
INFO - 2023-05-31 08:44:13 --> Language Class Initialized
INFO - 2023-05-31 08:44:13 --> Loader Class Initialized
INFO - 2023-05-31 08:44:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:13 --> Config Class Initialized
INFO - 2023-05-31 08:44:13 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:13 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:13 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:13 --> URI Class Initialized
INFO - 2023-05-31 08:44:13 --> Router Class Initialized
INFO - 2023-05-31 08:44:13 --> Output Class Initialized
INFO - 2023-05-31 08:44:13 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:13 --> Input Class Initialized
INFO - 2023-05-31 08:44:13 --> Language Class Initialized
INFO - 2023-05-31 08:44:13 --> Loader Class Initialized
INFO - 2023-05-31 08:44:13 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:13 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:13 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:18 --> Config Class Initialized
INFO - 2023-05-31 08:44:18 --> Config Class Initialized
INFO - 2023-05-31 08:44:18 --> Hooks Class Initialized
INFO - 2023-05-31 08:44:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:18 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:44:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:18 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:18 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:18 --> URI Class Initialized
INFO - 2023-05-31 08:44:18 --> URI Class Initialized
INFO - 2023-05-31 08:44:18 --> Router Class Initialized
INFO - 2023-05-31 08:44:18 --> Router Class Initialized
INFO - 2023-05-31 08:44:18 --> Output Class Initialized
INFO - 2023-05-31 08:44:18 --> Output Class Initialized
INFO - 2023-05-31 08:44:18 --> Security Class Initialized
INFO - 2023-05-31 08:44:18 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:18 --> Input Class Initialized
INFO - 2023-05-31 08:44:18 --> Input Class Initialized
INFO - 2023-05-31 08:44:18 --> Language Class Initialized
INFO - 2023-05-31 08:44:18 --> Language Class Initialized
INFO - 2023-05-31 08:44:18 --> Loader Class Initialized
INFO - 2023-05-31 08:44:18 --> Loader Class Initialized
INFO - 2023-05-31 08:44:18 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:18 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:18 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:18 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:18 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:18 --> Total execution time: 0.1837
INFO - 2023-05-31 08:44:18 --> Config Class Initialized
INFO - 2023-05-31 08:44:18 --> Hooks Class Initialized
INFO - 2023-05-31 08:44:18 --> Database Driver Class Initialized
DEBUG - 2023-05-31 08:44:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:18 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:18 --> URI Class Initialized
INFO - 2023-05-31 08:44:18 --> Router Class Initialized
INFO - 2023-05-31 08:44:18 --> Output Class Initialized
INFO - 2023-05-31 08:44:18 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:18 --> Input Class Initialized
INFO - 2023-05-31 08:44:18 --> Language Class Initialized
INFO - 2023-05-31 08:44:18 --> Loader Class Initialized
INFO - 2023-05-31 08:44:18 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:18 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:18 --> Model "Login_model" initialized
INFO - 2023-05-31 08:44:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:18 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:18 --> Total execution time: 0.1935
INFO - 2023-05-31 08:44:19 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:19 --> Total execution time: 0.7335
INFO - 2023-05-31 08:44:19 --> Config Class Initialized
INFO - 2023-05-31 08:44:19 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:19 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:19 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:19 --> URI Class Initialized
INFO - 2023-05-31 08:44:19 --> Router Class Initialized
INFO - 2023-05-31 08:44:19 --> Output Class Initialized
INFO - 2023-05-31 08:44:19 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:19 --> Input Class Initialized
INFO - 2023-05-31 08:44:19 --> Language Class Initialized
INFO - 2023-05-31 08:44:19 --> Loader Class Initialized
INFO - 2023-05-31 08:44:19 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:19 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:19 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:19 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:19 --> Model "Login_model" initialized
INFO - 2023-05-31 08:44:20 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:20 --> Total execution time: 0.9712
INFO - 2023-05-31 08:44:51 --> Config Class Initialized
INFO - 2023-05-31 08:44:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:51 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:51 --> URI Class Initialized
INFO - 2023-05-31 08:44:51 --> Router Class Initialized
INFO - 2023-05-31 08:44:51 --> Output Class Initialized
INFO - 2023-05-31 08:44:51 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:51 --> Input Class Initialized
INFO - 2023-05-31 08:44:51 --> Language Class Initialized
INFO - 2023-05-31 08:44:51 --> Loader Class Initialized
INFO - 2023-05-31 08:44:51 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:51 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:51 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:51 --> Total execution time: 0.2049
INFO - 2023-05-31 08:44:51 --> Config Class Initialized
INFO - 2023-05-31 08:44:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:51 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:51 --> URI Class Initialized
INFO - 2023-05-31 08:44:51 --> Router Class Initialized
INFO - 2023-05-31 08:44:51 --> Output Class Initialized
INFO - 2023-05-31 08:44:51 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:51 --> Input Class Initialized
INFO - 2023-05-31 08:44:51 --> Language Class Initialized
INFO - 2023-05-31 08:44:51 --> Loader Class Initialized
INFO - 2023-05-31 08:44:51 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:51 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:51 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:51 --> Total execution time: 0.2162
INFO - 2023-05-31 08:44:51 --> Config Class Initialized
INFO - 2023-05-31 08:44:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:51 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:51 --> URI Class Initialized
INFO - 2023-05-31 08:44:51 --> Router Class Initialized
INFO - 2023-05-31 08:44:51 --> Output Class Initialized
INFO - 2023-05-31 08:44:51 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:51 --> Input Class Initialized
INFO - 2023-05-31 08:44:51 --> Language Class Initialized
INFO - 2023-05-31 08:44:51 --> Loader Class Initialized
INFO - 2023-05-31 08:44:51 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:51 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:51 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:51 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:51 --> Total execution time: 0.1959
INFO - 2023-05-31 08:44:51 --> Config Class Initialized
INFO - 2023-05-31 08:44:51 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:51 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:51 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:51 --> URI Class Initialized
INFO - 2023-05-31 08:44:51 --> Router Class Initialized
INFO - 2023-05-31 08:44:51 --> Output Class Initialized
INFO - 2023-05-31 08:44:51 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:51 --> Input Class Initialized
INFO - 2023-05-31 08:44:51 --> Language Class Initialized
INFO - 2023-05-31 08:44:52 --> Loader Class Initialized
INFO - 2023-05-31 08:44:52 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:52 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:52 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:44:52 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:52 --> Total execution time: 0.1960
INFO - 2023-05-31 08:44:59 --> Config Class Initialized
INFO - 2023-05-31 08:44:59 --> Config Class Initialized
INFO - 2023-05-31 08:44:59 --> Hooks Class Initialized
INFO - 2023-05-31 08:44:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:59 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 08:44:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:59 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:59 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:59 --> URI Class Initialized
INFO - 2023-05-31 08:44:59 --> URI Class Initialized
INFO - 2023-05-31 08:44:59 --> Router Class Initialized
INFO - 2023-05-31 08:44:59 --> Router Class Initialized
INFO - 2023-05-31 08:44:59 --> Output Class Initialized
INFO - 2023-05-31 08:44:59 --> Output Class Initialized
INFO - 2023-05-31 08:44:59 --> Security Class Initialized
INFO - 2023-05-31 08:44:59 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 08:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:59 --> Input Class Initialized
INFO - 2023-05-31 08:44:59 --> Input Class Initialized
INFO - 2023-05-31 08:44:59 --> Language Class Initialized
INFO - 2023-05-31 08:44:59 --> Language Class Initialized
INFO - 2023-05-31 08:44:59 --> Loader Class Initialized
INFO - 2023-05-31 08:44:59 --> Loader Class Initialized
INFO - 2023-05-31 08:44:59 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:59 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:59 --> Final output sent to browser
DEBUG - 2023-05-31 08:44:59 --> Total execution time: 0.1237
INFO - 2023-05-31 08:44:59 --> Database Driver Class Initialized
INFO - 2023-05-31 08:44:59 --> Config Class Initialized
INFO - 2023-05-31 08:44:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:44:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:44:59 --> Utf8 Class Initialized
INFO - 2023-05-31 08:44:59 --> URI Class Initialized
INFO - 2023-05-31 08:44:59 --> Router Class Initialized
INFO - 2023-05-31 08:44:59 --> Output Class Initialized
INFO - 2023-05-31 08:44:59 --> Security Class Initialized
DEBUG - 2023-05-31 08:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:44:59 --> Input Class Initialized
INFO - 2023-05-31 08:44:59 --> Language Class Initialized
INFO - 2023-05-31 08:44:59 --> Loader Class Initialized
INFO - 2023-05-31 08:44:59 --> Controller Class Initialized
DEBUG - 2023-05-31 08:44:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:44:59 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:45:06 --> Final output sent to browser
DEBUG - 2023-05-31 08:45:06 --> Total execution time: 7.1841
INFO - 2023-05-31 08:45:06 --> Config Class Initialized
INFO - 2023-05-31 08:45:06 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:45:06 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:45:06 --> Utf8 Class Initialized
INFO - 2023-05-31 08:45:06 --> URI Class Initialized
INFO - 2023-05-31 08:45:06 --> Router Class Initialized
INFO - 2023-05-31 08:45:06 --> Output Class Initialized
INFO - 2023-05-31 08:45:06 --> Security Class Initialized
DEBUG - 2023-05-31 08:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:45:06 --> Input Class Initialized
INFO - 2023-05-31 08:45:06 --> Language Class Initialized
INFO - 2023-05-31 08:45:06 --> Model "Login_model" initialized
INFO - 2023-05-31 08:45:06 --> Loader Class Initialized
INFO - 2023-05-31 08:45:06 --> Controller Class Initialized
INFO - 2023-05-31 08:45:06 --> Database Driver Class Initialized
DEBUG - 2023-05-31 08:45:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:45:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:45:06 --> Final output sent to browser
DEBUG - 2023-05-31 08:45:06 --> Total execution time: 7.2357
INFO - 2023-05-31 08:45:06 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:45:06 --> Final output sent to browser
DEBUG - 2023-05-31 08:45:06 --> Total execution time: 0.2304
INFO - 2023-05-31 08:45:56 --> Config Class Initialized
INFO - 2023-05-31 08:45:56 --> Hooks Class Initialized
INFO - 2023-05-31 08:45:57 --> Config Class Initialized
DEBUG - 2023-05-31 08:45:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:45:57 --> Hooks Class Initialized
INFO - 2023-05-31 08:45:57 --> Utf8 Class Initialized
INFO - 2023-05-31 08:45:57 --> URI Class Initialized
DEBUG - 2023-05-31 08:45:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:45:57 --> Router Class Initialized
INFO - 2023-05-31 08:45:57 --> Utf8 Class Initialized
INFO - 2023-05-31 08:45:57 --> URI Class Initialized
INFO - 2023-05-31 08:45:57 --> Output Class Initialized
INFO - 2023-05-31 08:45:57 --> Security Class Initialized
INFO - 2023-05-31 08:45:57 --> Router Class Initialized
DEBUG - 2023-05-31 08:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:45:57 --> Input Class Initialized
INFO - 2023-05-31 08:45:57 --> Output Class Initialized
INFO - 2023-05-31 08:45:57 --> Language Class Initialized
INFO - 2023-05-31 08:45:57 --> Security Class Initialized
DEBUG - 2023-05-31 08:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:45:57 --> Input Class Initialized
INFO - 2023-05-31 08:45:57 --> Language Class Initialized
INFO - 2023-05-31 08:45:57 --> Loader Class Initialized
INFO - 2023-05-31 08:45:57 --> Loader Class Initialized
INFO - 2023-05-31 08:45:57 --> Controller Class Initialized
DEBUG - 2023-05-31 08:45:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:45:57 --> Controller Class Initialized
DEBUG - 2023-05-31 08:45:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:45:57 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:57 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:45:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:45:57 --> Final output sent to browser
DEBUG - 2023-05-31 08:45:57 --> Total execution time: 0.6191
INFO - 2023-05-31 08:45:57 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:57 --> Model "Login_model" initialized
INFO - 2023-05-31 08:45:57 --> Config Class Initialized
INFO - 2023-05-31 08:45:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:45:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:45:57 --> Utf8 Class Initialized
INFO - 2023-05-31 08:45:57 --> URI Class Initialized
INFO - 2023-05-31 08:45:57 --> Router Class Initialized
INFO - 2023-05-31 08:45:57 --> Output Class Initialized
INFO - 2023-05-31 08:45:57 --> Security Class Initialized
DEBUG - 2023-05-31 08:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:45:57 --> Input Class Initialized
INFO - 2023-05-31 08:45:57 --> Language Class Initialized
INFO - 2023-05-31 08:45:57 --> Loader Class Initialized
INFO - 2023-05-31 08:45:57 --> Controller Class Initialized
DEBUG - 2023-05-31 08:45:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:45:57 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:45:57 --> Final output sent to browser
DEBUG - 2023-05-31 08:45:57 --> Total execution time: 0.3063
INFO - 2023-05-31 08:45:58 --> Final output sent to browser
DEBUG - 2023-05-31 08:45:58 --> Total execution time: 1.1334
INFO - 2023-05-31 08:45:58 --> Config Class Initialized
INFO - 2023-05-31 08:45:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:45:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:45:58 --> Utf8 Class Initialized
INFO - 2023-05-31 08:45:58 --> URI Class Initialized
INFO - 2023-05-31 08:45:58 --> Router Class Initialized
INFO - 2023-05-31 08:45:58 --> Output Class Initialized
INFO - 2023-05-31 08:45:58 --> Security Class Initialized
DEBUG - 2023-05-31 08:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:45:58 --> Input Class Initialized
INFO - 2023-05-31 08:45:58 --> Language Class Initialized
INFO - 2023-05-31 08:45:58 --> Loader Class Initialized
INFO - 2023-05-31 08:45:58 --> Controller Class Initialized
DEBUG - 2023-05-31 08:45:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:45:58 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:45:58 --> Database Driver Class Initialized
INFO - 2023-05-31 08:45:58 --> Model "Login_model" initialized
INFO - 2023-05-31 08:45:59 --> Final output sent to browser
DEBUG - 2023-05-31 08:45:59 --> Total execution time: 1.0123
INFO - 2023-05-31 08:46:01 --> Config Class Initialized
INFO - 2023-05-31 08:46:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:46:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:46:01 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:01 --> URI Class Initialized
INFO - 2023-05-31 08:46:01 --> Router Class Initialized
INFO - 2023-05-31 08:46:01 --> Output Class Initialized
INFO - 2023-05-31 08:46:01 --> Security Class Initialized
DEBUG - 2023-05-31 08:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:46:01 --> Input Class Initialized
INFO - 2023-05-31 08:46:01 --> Language Class Initialized
INFO - 2023-05-31 08:46:01 --> Loader Class Initialized
INFO - 2023-05-31 08:46:01 --> Controller Class Initialized
DEBUG - 2023-05-31 08:46:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:46:01 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:01 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:46:01 --> Final output sent to browser
DEBUG - 2023-05-31 08:46:01 --> Total execution time: 0.1804
INFO - 2023-05-31 08:46:01 --> Config Class Initialized
INFO - 2023-05-31 08:46:01 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:46:01 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:46:01 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:01 --> URI Class Initialized
INFO - 2023-05-31 08:46:01 --> Router Class Initialized
INFO - 2023-05-31 08:46:01 --> Output Class Initialized
INFO - 2023-05-31 08:46:01 --> Security Class Initialized
DEBUG - 2023-05-31 08:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:46:01 --> Input Class Initialized
INFO - 2023-05-31 08:46:01 --> Language Class Initialized
INFO - 2023-05-31 08:46:01 --> Loader Class Initialized
INFO - 2023-05-31 08:46:01 --> Controller Class Initialized
DEBUG - 2023-05-31 08:46:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:46:02 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:02 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:46:02 --> Final output sent to browser
DEBUG - 2023-05-31 08:46:02 --> Total execution time: 0.2925
INFO - 2023-05-31 08:46:03 --> Config Class Initialized
INFO - 2023-05-31 08:46:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:46:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:46:03 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:03 --> URI Class Initialized
INFO - 2023-05-31 08:46:03 --> Router Class Initialized
INFO - 2023-05-31 08:46:03 --> Output Class Initialized
INFO - 2023-05-31 08:46:03 --> Security Class Initialized
DEBUG - 2023-05-31 08:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:46:03 --> Input Class Initialized
INFO - 2023-05-31 08:46:03 --> Language Class Initialized
INFO - 2023-05-31 08:46:03 --> Loader Class Initialized
INFO - 2023-05-31 08:46:03 --> Controller Class Initialized
DEBUG - 2023-05-31 08:46:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:46:03 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:46:03 --> Final output sent to browser
DEBUG - 2023-05-31 08:46:03 --> Total execution time: 0.2416
INFO - 2023-05-31 08:46:03 --> Config Class Initialized
INFO - 2023-05-31 08:46:03 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:46:03 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:46:03 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:03 --> URI Class Initialized
INFO - 2023-05-31 08:46:03 --> Router Class Initialized
INFO - 2023-05-31 08:46:03 --> Output Class Initialized
INFO - 2023-05-31 08:46:03 --> Security Class Initialized
DEBUG - 2023-05-31 08:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:46:03 --> Input Class Initialized
INFO - 2023-05-31 08:46:03 --> Language Class Initialized
INFO - 2023-05-31 08:46:03 --> Loader Class Initialized
INFO - 2023-05-31 08:46:03 --> Controller Class Initialized
DEBUG - 2023-05-31 08:46:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:46:03 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:03 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:46:03 --> Final output sent to browser
DEBUG - 2023-05-31 08:46:03 --> Total execution time: 0.4327
INFO - 2023-05-31 08:46:05 --> Config Class Initialized
INFO - 2023-05-31 08:46:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:46:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:46:05 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:05 --> URI Class Initialized
INFO - 2023-05-31 08:46:05 --> Router Class Initialized
INFO - 2023-05-31 08:46:05 --> Output Class Initialized
INFO - 2023-05-31 08:46:05 --> Security Class Initialized
DEBUG - 2023-05-31 08:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:46:05 --> Input Class Initialized
INFO - 2023-05-31 08:46:05 --> Language Class Initialized
INFO - 2023-05-31 08:46:05 --> Loader Class Initialized
INFO - 2023-05-31 08:46:05 --> Controller Class Initialized
DEBUG - 2023-05-31 08:46:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:46:05 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:46:05 --> Final output sent to browser
DEBUG - 2023-05-31 08:46:05 --> Total execution time: 0.1754
INFO - 2023-05-31 08:46:05 --> Config Class Initialized
INFO - 2023-05-31 08:46:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:46:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:46:05 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:05 --> URI Class Initialized
INFO - 2023-05-31 08:46:05 --> Router Class Initialized
INFO - 2023-05-31 08:46:05 --> Output Class Initialized
INFO - 2023-05-31 08:46:05 --> Security Class Initialized
DEBUG - 2023-05-31 08:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:46:05 --> Input Class Initialized
INFO - 2023-05-31 08:46:05 --> Language Class Initialized
INFO - 2023-05-31 08:46:05 --> Loader Class Initialized
INFO - 2023-05-31 08:46:05 --> Controller Class Initialized
DEBUG - 2023-05-31 08:46:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:46:05 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:46:05 --> Final output sent to browser
DEBUG - 2023-05-31 08:46:05 --> Total execution time: 0.1815
INFO - 2023-05-31 08:46:10 --> Config Class Initialized
INFO - 2023-05-31 08:46:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:46:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:46:10 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:10 --> URI Class Initialized
INFO - 2023-05-31 08:46:11 --> Router Class Initialized
INFO - 2023-05-31 08:46:11 --> Output Class Initialized
INFO - 2023-05-31 08:46:11 --> Security Class Initialized
DEBUG - 2023-05-31 08:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:46:11 --> Input Class Initialized
INFO - 2023-05-31 08:46:11 --> Language Class Initialized
INFO - 2023-05-31 08:46:11 --> Loader Class Initialized
INFO - 2023-05-31 08:46:11 --> Controller Class Initialized
DEBUG - 2023-05-31 08:46:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:46:11 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:11 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:46:11 --> Final output sent to browser
DEBUG - 2023-05-31 08:46:11 --> Total execution time: 0.1811
INFO - 2023-05-31 08:46:11 --> Config Class Initialized
INFO - 2023-05-31 08:46:11 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:46:11 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:46:11 --> Utf8 Class Initialized
INFO - 2023-05-31 08:46:11 --> URI Class Initialized
INFO - 2023-05-31 08:46:11 --> Router Class Initialized
INFO - 2023-05-31 08:46:11 --> Output Class Initialized
INFO - 2023-05-31 08:46:11 --> Security Class Initialized
DEBUG - 2023-05-31 08:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:46:11 --> Input Class Initialized
INFO - 2023-05-31 08:46:11 --> Language Class Initialized
INFO - 2023-05-31 08:46:11 --> Loader Class Initialized
INFO - 2023-05-31 08:46:11 --> Controller Class Initialized
DEBUG - 2023-05-31 08:46:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:46:11 --> Database Driver Class Initialized
INFO - 2023-05-31 08:46:11 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:46:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:46:11 --> Final output sent to browser
DEBUG - 2023-05-31 08:46:11 --> Total execution time: 0.2244
INFO - 2023-05-31 08:47:26 --> Config Class Initialized
INFO - 2023-05-31 08:47:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:47:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:47:26 --> Utf8 Class Initialized
INFO - 2023-05-31 08:47:26 --> URI Class Initialized
INFO - 2023-05-31 08:47:26 --> Router Class Initialized
INFO - 2023-05-31 08:47:26 --> Output Class Initialized
INFO - 2023-05-31 08:47:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:47:26 --> Input Class Initialized
INFO - 2023-05-31 08:47:26 --> Language Class Initialized
INFO - 2023-05-31 08:47:26 --> Loader Class Initialized
INFO - 2023-05-31 08:47:26 --> Controller Class Initialized
DEBUG - 2023-05-31 08:47:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:47:26 --> Database Driver Class Initialized
INFO - 2023-05-31 08:47:26 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:47:26 --> Final output sent to browser
DEBUG - 2023-05-31 08:47:26 --> Total execution time: 0.1846
INFO - 2023-05-31 08:47:26 --> Config Class Initialized
INFO - 2023-05-31 08:47:26 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:47:26 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:47:26 --> Utf8 Class Initialized
INFO - 2023-05-31 08:47:26 --> URI Class Initialized
INFO - 2023-05-31 08:47:26 --> Router Class Initialized
INFO - 2023-05-31 08:47:26 --> Output Class Initialized
INFO - 2023-05-31 08:47:26 --> Security Class Initialized
DEBUG - 2023-05-31 08:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:47:26 --> Input Class Initialized
INFO - 2023-05-31 08:47:26 --> Language Class Initialized
INFO - 2023-05-31 08:47:26 --> Loader Class Initialized
INFO - 2023-05-31 08:47:26 --> Controller Class Initialized
DEBUG - 2023-05-31 08:47:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:47:26 --> Database Driver Class Initialized
INFO - 2023-05-31 08:47:26 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:47:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:47:26 --> Final output sent to browser
DEBUG - 2023-05-31 08:47:26 --> Total execution time: 0.1867
INFO - 2023-05-31 08:48:10 --> Config Class Initialized
INFO - 2023-05-31 08:48:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:48:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:48:10 --> Utf8 Class Initialized
INFO - 2023-05-31 08:48:10 --> URI Class Initialized
INFO - 2023-05-31 08:48:10 --> Router Class Initialized
INFO - 2023-05-31 08:48:10 --> Output Class Initialized
INFO - 2023-05-31 08:48:10 --> Security Class Initialized
DEBUG - 2023-05-31 08:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:48:10 --> Input Class Initialized
INFO - 2023-05-31 08:48:10 --> Language Class Initialized
INFO - 2023-05-31 08:48:10 --> Loader Class Initialized
INFO - 2023-05-31 08:48:10 --> Controller Class Initialized
DEBUG - 2023-05-31 08:48:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:48:10 --> Database Driver Class Initialized
INFO - 2023-05-31 08:48:10 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:48:10 --> Final output sent to browser
DEBUG - 2023-05-31 08:48:10 --> Total execution time: 0.2318
INFO - 2023-05-31 08:48:10 --> Config Class Initialized
INFO - 2023-05-31 08:48:10 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:48:10 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:48:10 --> Utf8 Class Initialized
INFO - 2023-05-31 08:48:10 --> URI Class Initialized
INFO - 2023-05-31 08:48:10 --> Router Class Initialized
INFO - 2023-05-31 08:48:10 --> Output Class Initialized
INFO - 2023-05-31 08:48:10 --> Security Class Initialized
DEBUG - 2023-05-31 08:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:48:10 --> Input Class Initialized
INFO - 2023-05-31 08:48:10 --> Language Class Initialized
INFO - 2023-05-31 08:48:10 --> Loader Class Initialized
INFO - 2023-05-31 08:48:10 --> Controller Class Initialized
DEBUG - 2023-05-31 08:48:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:48:10 --> Database Driver Class Initialized
INFO - 2023-05-31 08:48:11 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:48:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:48:11 --> Final output sent to browser
DEBUG - 2023-05-31 08:48:11 --> Total execution time: 0.1956
INFO - 2023-05-31 08:48:31 --> Config Class Initialized
INFO - 2023-05-31 08:48:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:48:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:48:31 --> Utf8 Class Initialized
INFO - 2023-05-31 08:48:31 --> URI Class Initialized
INFO - 2023-05-31 08:48:31 --> Router Class Initialized
INFO - 2023-05-31 08:48:31 --> Output Class Initialized
INFO - 2023-05-31 08:48:31 --> Security Class Initialized
DEBUG - 2023-05-31 08:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:48:31 --> Input Class Initialized
INFO - 2023-05-31 08:48:31 --> Language Class Initialized
INFO - 2023-05-31 08:48:31 --> Loader Class Initialized
INFO - 2023-05-31 08:48:31 --> Controller Class Initialized
DEBUG - 2023-05-31 08:48:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:48:31 --> Database Driver Class Initialized
INFO - 2023-05-31 08:48:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:48:31 --> Final output sent to browser
DEBUG - 2023-05-31 08:48:31 --> Total execution time: 0.2314
INFO - 2023-05-31 08:48:31 --> Config Class Initialized
INFO - 2023-05-31 08:48:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:48:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:48:31 --> Utf8 Class Initialized
INFO - 2023-05-31 08:48:31 --> URI Class Initialized
INFO - 2023-05-31 08:48:31 --> Router Class Initialized
INFO - 2023-05-31 08:48:31 --> Output Class Initialized
INFO - 2023-05-31 08:48:31 --> Security Class Initialized
DEBUG - 2023-05-31 08:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:48:32 --> Input Class Initialized
INFO - 2023-05-31 08:48:32 --> Language Class Initialized
INFO - 2023-05-31 08:48:32 --> Loader Class Initialized
INFO - 2023-05-31 08:48:32 --> Controller Class Initialized
DEBUG - 2023-05-31 08:48:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:48:32 --> Database Driver Class Initialized
INFO - 2023-05-31 08:48:32 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:48:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:48:32 --> Final output sent to browser
DEBUG - 2023-05-31 08:48:32 --> Total execution time: 0.1761
INFO - 2023-05-31 08:48:57 --> Config Class Initialized
INFO - 2023-05-31 08:48:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:48:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:48:57 --> Utf8 Class Initialized
INFO - 2023-05-31 08:48:57 --> URI Class Initialized
INFO - 2023-05-31 08:48:57 --> Router Class Initialized
INFO - 2023-05-31 08:48:57 --> Output Class Initialized
INFO - 2023-05-31 08:48:57 --> Security Class Initialized
DEBUG - 2023-05-31 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:48:57 --> Input Class Initialized
INFO - 2023-05-31 08:48:57 --> Language Class Initialized
INFO - 2023-05-31 08:48:57 --> Loader Class Initialized
INFO - 2023-05-31 08:48:57 --> Controller Class Initialized
DEBUG - 2023-05-31 08:48:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:48:57 --> Database Driver Class Initialized
INFO - 2023-05-31 08:48:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:48:57 --> Final output sent to browser
DEBUG - 2023-05-31 08:48:57 --> Total execution time: 0.1983
INFO - 2023-05-31 08:48:57 --> Config Class Initialized
INFO - 2023-05-31 08:48:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:48:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:48:57 --> Utf8 Class Initialized
INFO - 2023-05-31 08:48:57 --> URI Class Initialized
INFO - 2023-05-31 08:48:57 --> Router Class Initialized
INFO - 2023-05-31 08:48:57 --> Output Class Initialized
INFO - 2023-05-31 08:48:57 --> Security Class Initialized
DEBUG - 2023-05-31 08:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:48:57 --> Input Class Initialized
INFO - 2023-05-31 08:48:57 --> Language Class Initialized
INFO - 2023-05-31 08:48:57 --> Loader Class Initialized
INFO - 2023-05-31 08:48:57 --> Controller Class Initialized
DEBUG - 2023-05-31 08:48:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:48:57 --> Database Driver Class Initialized
INFO - 2023-05-31 08:48:57 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:48:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:50:04 --> Config Class Initialized
INFO - 2023-05-31 08:50:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:50:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:50:04 --> Utf8 Class Initialized
INFO - 2023-05-31 08:50:04 --> URI Class Initialized
INFO - 2023-05-31 08:50:04 --> Router Class Initialized
INFO - 2023-05-31 08:50:04 --> Output Class Initialized
INFO - 2023-05-31 08:50:04 --> Security Class Initialized
DEBUG - 2023-05-31 08:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:50:04 --> Input Class Initialized
INFO - 2023-05-31 08:50:04 --> Language Class Initialized
INFO - 2023-05-31 08:50:04 --> Loader Class Initialized
INFO - 2023-05-31 08:50:04 --> Controller Class Initialized
DEBUG - 2023-05-31 08:50:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:50:05 --> Database Driver Class Initialized
INFO - 2023-05-31 08:50:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:50:05 --> Final output sent to browser
DEBUG - 2023-05-31 08:50:05 --> Total execution time: 0.5302
INFO - 2023-05-31 08:50:05 --> Config Class Initialized
INFO - 2023-05-31 08:50:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:50:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:50:05 --> Utf8 Class Initialized
INFO - 2023-05-31 08:50:05 --> URI Class Initialized
INFO - 2023-05-31 08:50:05 --> Router Class Initialized
INFO - 2023-05-31 08:50:05 --> Output Class Initialized
INFO - 2023-05-31 08:50:05 --> Security Class Initialized
DEBUG - 2023-05-31 08:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:50:05 --> Input Class Initialized
INFO - 2023-05-31 08:50:05 --> Language Class Initialized
INFO - 2023-05-31 08:50:05 --> Loader Class Initialized
INFO - 2023-05-31 08:50:05 --> Controller Class Initialized
DEBUG - 2023-05-31 08:50:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:50:05 --> Database Driver Class Initialized
INFO - 2023-05-31 08:50:05 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:50:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:57:50 --> Config Class Initialized
INFO - 2023-05-31 08:57:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:57:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:57:50 --> Utf8 Class Initialized
INFO - 2023-05-31 08:57:50 --> URI Class Initialized
INFO - 2023-05-31 08:57:50 --> Router Class Initialized
INFO - 2023-05-31 08:57:50 --> Output Class Initialized
INFO - 2023-05-31 08:57:50 --> Security Class Initialized
DEBUG - 2023-05-31 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:57:50 --> Input Class Initialized
INFO - 2023-05-31 08:57:50 --> Language Class Initialized
INFO - 2023-05-31 08:57:50 --> Loader Class Initialized
INFO - 2023-05-31 08:57:50 --> Controller Class Initialized
DEBUG - 2023-05-31 08:57:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:57:50 --> Database Driver Class Initialized
INFO - 2023-05-31 08:57:50 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:57:50 --> Final output sent to browser
DEBUG - 2023-05-31 08:57:50 --> Total execution time: 0.2547
INFO - 2023-05-31 08:57:50 --> Config Class Initialized
INFO - 2023-05-31 08:57:50 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:57:50 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:57:50 --> Utf8 Class Initialized
INFO - 2023-05-31 08:57:50 --> URI Class Initialized
INFO - 2023-05-31 08:57:50 --> Router Class Initialized
INFO - 2023-05-31 08:57:50 --> Output Class Initialized
INFO - 2023-05-31 08:57:50 --> Security Class Initialized
DEBUG - 2023-05-31 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:57:50 --> Input Class Initialized
INFO - 2023-05-31 08:57:50 --> Language Class Initialized
INFO - 2023-05-31 08:57:50 --> Loader Class Initialized
INFO - 2023-05-31 08:57:50 --> Controller Class Initialized
DEBUG - 2023-05-31 08:57:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:57:50 --> Database Driver Class Initialized
INFO - 2023-05-31 08:57:50 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:57:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 08:58:15 --> Config Class Initialized
INFO - 2023-05-31 08:58:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:58:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:58:15 --> Utf8 Class Initialized
INFO - 2023-05-31 08:58:15 --> URI Class Initialized
INFO - 2023-05-31 08:58:15 --> Router Class Initialized
INFO - 2023-05-31 08:58:15 --> Output Class Initialized
INFO - 2023-05-31 08:58:15 --> Security Class Initialized
DEBUG - 2023-05-31 08:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:58:15 --> Input Class Initialized
INFO - 2023-05-31 08:58:15 --> Language Class Initialized
INFO - 2023-05-31 08:58:15 --> Loader Class Initialized
INFO - 2023-05-31 08:58:15 --> Controller Class Initialized
DEBUG - 2023-05-31 08:58:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:58:15 --> Database Driver Class Initialized
INFO - 2023-05-31 08:58:15 --> Model "Cluster_model" initialized
INFO - 2023-05-31 08:58:15 --> Final output sent to browser
DEBUG - 2023-05-31 08:58:15 --> Total execution time: 0.2140
INFO - 2023-05-31 08:58:15 --> Config Class Initialized
INFO - 2023-05-31 08:58:15 --> Hooks Class Initialized
DEBUG - 2023-05-31 08:58:15 --> UTF-8 Support Enabled
INFO - 2023-05-31 08:58:15 --> Utf8 Class Initialized
INFO - 2023-05-31 08:58:15 --> URI Class Initialized
INFO - 2023-05-31 08:58:15 --> Router Class Initialized
INFO - 2023-05-31 08:58:15 --> Output Class Initialized
INFO - 2023-05-31 08:58:15 --> Security Class Initialized
DEBUG - 2023-05-31 08:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 08:58:15 --> Input Class Initialized
INFO - 2023-05-31 08:58:15 --> Language Class Initialized
INFO - 2023-05-31 08:58:15 --> Loader Class Initialized
INFO - 2023-05-31 08:58:15 --> Controller Class Initialized
DEBUG - 2023-05-31 08:58:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 08:58:15 --> Database Driver Class Initialized
INFO - 2023-05-31 08:58:15 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 08:58:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:00:56 --> Config Class Initialized
INFO - 2023-05-31 09:00:56 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:00:56 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:00:56 --> Utf8 Class Initialized
INFO - 2023-05-31 09:00:56 --> URI Class Initialized
INFO - 2023-05-31 09:00:56 --> Router Class Initialized
INFO - 2023-05-31 09:00:56 --> Output Class Initialized
INFO - 2023-05-31 09:00:56 --> Security Class Initialized
DEBUG - 2023-05-31 09:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:00:56 --> Input Class Initialized
INFO - 2023-05-31 09:00:56 --> Language Class Initialized
INFO - 2023-05-31 09:00:56 --> Loader Class Initialized
INFO - 2023-05-31 09:00:56 --> Controller Class Initialized
DEBUG - 2023-05-31 09:00:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:00:56 --> Database Driver Class Initialized
INFO - 2023-05-31 09:00:56 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:00:56 --> Final output sent to browser
DEBUG - 2023-05-31 09:00:56 --> Total execution time: 0.2265
INFO - 2023-05-31 09:00:56 --> Config Class Initialized
INFO - 2023-05-31 09:00:56 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:00:56 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:00:56 --> Utf8 Class Initialized
INFO - 2023-05-31 09:00:56 --> URI Class Initialized
INFO - 2023-05-31 09:00:56 --> Router Class Initialized
INFO - 2023-05-31 09:00:56 --> Output Class Initialized
INFO - 2023-05-31 09:00:56 --> Security Class Initialized
DEBUG - 2023-05-31 09:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:00:56 --> Input Class Initialized
INFO - 2023-05-31 09:00:56 --> Language Class Initialized
INFO - 2023-05-31 09:00:56 --> Loader Class Initialized
INFO - 2023-05-31 09:00:56 --> Controller Class Initialized
DEBUG - 2023-05-31 09:00:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:00:56 --> Database Driver Class Initialized
INFO - 2023-05-31 09:00:56 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:00:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:00:56 --> Final output sent to browser
DEBUG - 2023-05-31 09:00:56 --> Total execution time: 0.2172
INFO - 2023-05-31 09:02:33 --> Config Class Initialized
INFO - 2023-05-31 09:02:33 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:02:33 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:02:33 --> Utf8 Class Initialized
INFO - 2023-05-31 09:02:33 --> URI Class Initialized
INFO - 2023-05-31 09:02:33 --> Router Class Initialized
INFO - 2023-05-31 09:02:33 --> Output Class Initialized
INFO - 2023-05-31 09:02:33 --> Security Class Initialized
DEBUG - 2023-05-31 09:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:02:33 --> Input Class Initialized
INFO - 2023-05-31 09:02:33 --> Language Class Initialized
INFO - 2023-05-31 09:02:33 --> Loader Class Initialized
INFO - 2023-05-31 09:02:33 --> Controller Class Initialized
DEBUG - 2023-05-31 09:02:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:02:33 --> Database Driver Class Initialized
INFO - 2023-05-31 09:02:33 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:02:33 --> Final output sent to browser
DEBUG - 2023-05-31 09:02:33 --> Total execution time: 0.2474
INFO - 2023-05-31 09:02:33 --> Config Class Initialized
INFO - 2023-05-31 09:02:33 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:02:33 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:02:33 --> Utf8 Class Initialized
INFO - 2023-05-31 09:02:33 --> URI Class Initialized
INFO - 2023-05-31 09:02:33 --> Router Class Initialized
INFO - 2023-05-31 09:02:33 --> Output Class Initialized
INFO - 2023-05-31 09:02:33 --> Security Class Initialized
DEBUG - 2023-05-31 09:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:02:33 --> Input Class Initialized
INFO - 2023-05-31 09:02:33 --> Language Class Initialized
INFO - 2023-05-31 09:02:33 --> Loader Class Initialized
INFO - 2023-05-31 09:02:33 --> Controller Class Initialized
DEBUG - 2023-05-31 09:02:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:02:33 --> Database Driver Class Initialized
INFO - 2023-05-31 09:02:33 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:02:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:02:33 --> Final output sent to browser
DEBUG - 2023-05-31 09:02:33 --> Total execution time: 0.1727
INFO - 2023-05-31 09:02:48 --> Config Class Initialized
INFO - 2023-05-31 09:02:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:02:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:02:48 --> Utf8 Class Initialized
INFO - 2023-05-31 09:02:48 --> URI Class Initialized
INFO - 2023-05-31 09:02:48 --> Router Class Initialized
INFO - 2023-05-31 09:02:48 --> Output Class Initialized
INFO - 2023-05-31 09:02:48 --> Security Class Initialized
DEBUG - 2023-05-31 09:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:02:48 --> Input Class Initialized
INFO - 2023-05-31 09:02:48 --> Language Class Initialized
INFO - 2023-05-31 09:02:48 --> Loader Class Initialized
INFO - 2023-05-31 09:02:48 --> Controller Class Initialized
DEBUG - 2023-05-31 09:02:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:02:48 --> Database Driver Class Initialized
INFO - 2023-05-31 09:02:48 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:02:48 --> Final output sent to browser
DEBUG - 2023-05-31 09:02:48 --> Total execution time: 0.1710
INFO - 2023-05-31 09:02:48 --> Config Class Initialized
INFO - 2023-05-31 09:02:48 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:02:48 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:02:48 --> Utf8 Class Initialized
INFO - 2023-05-31 09:02:48 --> URI Class Initialized
INFO - 2023-05-31 09:02:48 --> Router Class Initialized
INFO - 2023-05-31 09:02:48 --> Output Class Initialized
INFO - 2023-05-31 09:02:48 --> Security Class Initialized
DEBUG - 2023-05-31 09:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:02:48 --> Input Class Initialized
INFO - 2023-05-31 09:02:48 --> Language Class Initialized
INFO - 2023-05-31 09:02:48 --> Loader Class Initialized
INFO - 2023-05-31 09:02:48 --> Controller Class Initialized
DEBUG - 2023-05-31 09:02:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:02:48 --> Database Driver Class Initialized
INFO - 2023-05-31 09:02:48 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:02:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:02:48 --> Final output sent to browser
DEBUG - 2023-05-31 09:02:48 --> Total execution time: 0.1867
INFO - 2023-05-31 09:04:38 --> Config Class Initialized
INFO - 2023-05-31 09:04:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:04:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:04:38 --> Utf8 Class Initialized
INFO - 2023-05-31 09:04:38 --> URI Class Initialized
INFO - 2023-05-31 09:04:38 --> Router Class Initialized
INFO - 2023-05-31 09:04:38 --> Output Class Initialized
INFO - 2023-05-31 09:04:38 --> Security Class Initialized
DEBUG - 2023-05-31 09:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:04:38 --> Input Class Initialized
INFO - 2023-05-31 09:04:38 --> Language Class Initialized
INFO - 2023-05-31 09:04:38 --> Loader Class Initialized
INFO - 2023-05-31 09:04:38 --> Controller Class Initialized
DEBUG - 2023-05-31 09:04:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:04:38 --> Database Driver Class Initialized
INFO - 2023-05-31 09:04:38 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:04:38 --> Final output sent to browser
DEBUG - 2023-05-31 09:04:38 --> Total execution time: 0.2134
INFO - 2023-05-31 09:04:38 --> Config Class Initialized
INFO - 2023-05-31 09:04:38 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:04:38 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:04:38 --> Utf8 Class Initialized
INFO - 2023-05-31 09:04:38 --> URI Class Initialized
INFO - 2023-05-31 09:04:38 --> Router Class Initialized
INFO - 2023-05-31 09:04:38 --> Output Class Initialized
INFO - 2023-05-31 09:04:38 --> Security Class Initialized
DEBUG - 2023-05-31 09:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:04:38 --> Input Class Initialized
INFO - 2023-05-31 09:04:38 --> Language Class Initialized
INFO - 2023-05-31 09:04:38 --> Loader Class Initialized
INFO - 2023-05-31 09:04:38 --> Controller Class Initialized
DEBUG - 2023-05-31 09:04:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:04:38 --> Database Driver Class Initialized
INFO - 2023-05-31 09:04:38 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:04:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:04:38 --> Final output sent to browser
DEBUG - 2023-05-31 09:04:38 --> Total execution time: 0.2045
INFO - 2023-05-31 09:07:35 --> Config Class Initialized
INFO - 2023-05-31 09:07:35 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:07:35 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:07:35 --> Utf8 Class Initialized
INFO - 2023-05-31 09:07:35 --> URI Class Initialized
INFO - 2023-05-31 09:07:36 --> Router Class Initialized
INFO - 2023-05-31 09:07:36 --> Output Class Initialized
INFO - 2023-05-31 09:07:36 --> Security Class Initialized
DEBUG - 2023-05-31 09:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:07:36 --> Input Class Initialized
INFO - 2023-05-31 09:07:36 --> Language Class Initialized
INFO - 2023-05-31 09:07:36 --> Loader Class Initialized
INFO - 2023-05-31 09:07:36 --> Controller Class Initialized
DEBUG - 2023-05-31 09:07:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:07:36 --> Database Driver Class Initialized
INFO - 2023-05-31 09:07:36 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:07:36 --> Final output sent to browser
DEBUG - 2023-05-31 09:07:36 --> Total execution time: 0.4127
INFO - 2023-05-31 09:07:36 --> Config Class Initialized
INFO - 2023-05-31 09:07:36 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:07:36 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:07:36 --> Utf8 Class Initialized
INFO - 2023-05-31 09:07:36 --> URI Class Initialized
INFO - 2023-05-31 09:07:36 --> Router Class Initialized
INFO - 2023-05-31 09:07:36 --> Output Class Initialized
INFO - 2023-05-31 09:07:36 --> Security Class Initialized
DEBUG - 2023-05-31 09:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:07:36 --> Input Class Initialized
INFO - 2023-05-31 09:07:36 --> Language Class Initialized
INFO - 2023-05-31 09:07:36 --> Loader Class Initialized
INFO - 2023-05-31 09:07:36 --> Controller Class Initialized
DEBUG - 2023-05-31 09:07:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:07:36 --> Database Driver Class Initialized
INFO - 2023-05-31 09:07:36 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:07:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:07:36 --> Final output sent to browser
DEBUG - 2023-05-31 09:07:36 --> Total execution time: 0.3061
INFO - 2023-05-31 09:07:55 --> Config Class Initialized
INFO - 2023-05-31 09:07:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:07:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:07:55 --> Utf8 Class Initialized
INFO - 2023-05-31 09:07:55 --> URI Class Initialized
INFO - 2023-05-31 09:07:55 --> Router Class Initialized
INFO - 2023-05-31 09:07:55 --> Output Class Initialized
INFO - 2023-05-31 09:07:55 --> Security Class Initialized
DEBUG - 2023-05-31 09:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:07:55 --> Input Class Initialized
INFO - 2023-05-31 09:07:55 --> Language Class Initialized
INFO - 2023-05-31 09:07:55 --> Loader Class Initialized
INFO - 2023-05-31 09:07:55 --> Controller Class Initialized
DEBUG - 2023-05-31 09:07:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:07:55 --> Database Driver Class Initialized
INFO - 2023-05-31 09:07:55 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:07:55 --> Final output sent to browser
DEBUG - 2023-05-31 09:07:55 --> Total execution time: 0.1967
INFO - 2023-05-31 09:07:55 --> Config Class Initialized
INFO - 2023-05-31 09:07:55 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:07:55 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:07:55 --> Utf8 Class Initialized
INFO - 2023-05-31 09:07:55 --> URI Class Initialized
INFO - 2023-05-31 09:07:55 --> Router Class Initialized
INFO - 2023-05-31 09:07:55 --> Output Class Initialized
INFO - 2023-05-31 09:07:55 --> Security Class Initialized
DEBUG - 2023-05-31 09:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:07:55 --> Input Class Initialized
INFO - 2023-05-31 09:07:56 --> Language Class Initialized
INFO - 2023-05-31 09:07:56 --> Loader Class Initialized
INFO - 2023-05-31 09:07:56 --> Controller Class Initialized
DEBUG - 2023-05-31 09:07:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:07:56 --> Database Driver Class Initialized
INFO - 2023-05-31 09:07:56 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:07:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:07:56 --> Final output sent to browser
DEBUG - 2023-05-31 09:07:56 --> Total execution time: 0.1673
INFO - 2023-05-31 09:08:32 --> Config Class Initialized
INFO - 2023-05-31 09:08:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:08:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:08:32 --> Utf8 Class Initialized
INFO - 2023-05-31 09:08:32 --> URI Class Initialized
INFO - 2023-05-31 09:08:32 --> Router Class Initialized
INFO - 2023-05-31 09:08:32 --> Output Class Initialized
INFO - 2023-05-31 09:08:32 --> Security Class Initialized
DEBUG - 2023-05-31 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:08:32 --> Input Class Initialized
INFO - 2023-05-31 09:08:32 --> Language Class Initialized
INFO - 2023-05-31 09:08:32 --> Loader Class Initialized
INFO - 2023-05-31 09:08:32 --> Controller Class Initialized
DEBUG - 2023-05-31 09:08:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:08:32 --> Database Driver Class Initialized
INFO - 2023-05-31 09:08:32 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:08:32 --> Final output sent to browser
DEBUG - 2023-05-31 09:08:32 --> Total execution time: 0.2967
INFO - 2023-05-31 09:08:32 --> Config Class Initialized
INFO - 2023-05-31 09:08:32 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:08:32 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:08:32 --> Utf8 Class Initialized
INFO - 2023-05-31 09:08:32 --> URI Class Initialized
INFO - 2023-05-31 09:08:32 --> Router Class Initialized
INFO - 2023-05-31 09:08:32 --> Output Class Initialized
INFO - 2023-05-31 09:08:32 --> Security Class Initialized
DEBUG - 2023-05-31 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:08:32 --> Input Class Initialized
INFO - 2023-05-31 09:08:32 --> Language Class Initialized
INFO - 2023-05-31 09:08:32 --> Loader Class Initialized
INFO - 2023-05-31 09:08:32 --> Controller Class Initialized
DEBUG - 2023-05-31 09:08:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:08:32 --> Database Driver Class Initialized
INFO - 2023-05-31 09:08:32 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:08:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:08:32 --> Final output sent to browser
DEBUG - 2023-05-31 09:08:32 --> Total execution time: 0.1829
INFO - 2023-05-31 09:09:18 --> Config Class Initialized
INFO - 2023-05-31 09:09:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:09:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:09:18 --> Utf8 Class Initialized
INFO - 2023-05-31 09:09:18 --> URI Class Initialized
INFO - 2023-05-31 09:09:18 --> Router Class Initialized
INFO - 2023-05-31 09:09:18 --> Output Class Initialized
INFO - 2023-05-31 09:09:18 --> Security Class Initialized
DEBUG - 2023-05-31 09:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:09:18 --> Input Class Initialized
INFO - 2023-05-31 09:09:18 --> Language Class Initialized
INFO - 2023-05-31 09:09:18 --> Loader Class Initialized
INFO - 2023-05-31 09:09:18 --> Controller Class Initialized
DEBUG - 2023-05-31 09:09:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:09:18 --> Database Driver Class Initialized
INFO - 2023-05-31 09:09:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:09:18 --> Final output sent to browser
DEBUG - 2023-05-31 09:09:18 --> Total execution time: 0.1904
INFO - 2023-05-31 09:09:18 --> Config Class Initialized
INFO - 2023-05-31 09:09:18 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:09:18 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:09:18 --> Utf8 Class Initialized
INFO - 2023-05-31 09:09:18 --> URI Class Initialized
INFO - 2023-05-31 09:09:18 --> Router Class Initialized
INFO - 2023-05-31 09:09:18 --> Output Class Initialized
INFO - 2023-05-31 09:09:18 --> Security Class Initialized
DEBUG - 2023-05-31 09:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:09:18 --> Input Class Initialized
INFO - 2023-05-31 09:09:18 --> Language Class Initialized
INFO - 2023-05-31 09:09:18 --> Loader Class Initialized
INFO - 2023-05-31 09:09:18 --> Controller Class Initialized
DEBUG - 2023-05-31 09:09:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:09:18 --> Database Driver Class Initialized
INFO - 2023-05-31 09:09:18 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:09:18 --> Final output sent to browser
DEBUG - 2023-05-31 09:09:18 --> Total execution time: 0.2121
INFO - 2023-05-31 09:09:22 --> Config Class Initialized
INFO - 2023-05-31 09:09:22 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:09:22 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:09:22 --> Utf8 Class Initialized
INFO - 2023-05-31 09:09:22 --> URI Class Initialized
INFO - 2023-05-31 09:09:22 --> Router Class Initialized
INFO - 2023-05-31 09:09:22 --> Output Class Initialized
INFO - 2023-05-31 09:09:22 --> Security Class Initialized
DEBUG - 2023-05-31 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:09:22 --> Input Class Initialized
INFO - 2023-05-31 09:09:22 --> Language Class Initialized
INFO - 2023-05-31 09:09:22 --> Loader Class Initialized
INFO - 2023-05-31 09:09:22 --> Controller Class Initialized
DEBUG - 2023-05-31 09:09:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:09:22 --> Database Driver Class Initialized
INFO - 2023-05-31 09:09:22 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:09:22 --> Final output sent to browser
DEBUG - 2023-05-31 09:09:22 --> Total execution time: 0.1661
INFO - 2023-05-31 09:09:22 --> Config Class Initialized
INFO - 2023-05-31 09:09:22 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:09:22 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:09:22 --> Utf8 Class Initialized
INFO - 2023-05-31 09:09:22 --> URI Class Initialized
INFO - 2023-05-31 09:09:22 --> Router Class Initialized
INFO - 2023-05-31 09:09:22 --> Output Class Initialized
INFO - 2023-05-31 09:09:22 --> Security Class Initialized
DEBUG - 2023-05-31 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:09:22 --> Input Class Initialized
INFO - 2023-05-31 09:09:22 --> Language Class Initialized
INFO - 2023-05-31 09:09:22 --> Loader Class Initialized
INFO - 2023-05-31 09:09:22 --> Controller Class Initialized
DEBUG - 2023-05-31 09:09:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:09:22 --> Database Driver Class Initialized
INFO - 2023-05-31 09:09:22 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:09:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
ERROR - 2023-05-31 09:09:22 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Cluster_model.php at Line 25
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3141): Cluster_model->getList('1')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getVariable()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 09:09:30 --> Config Class Initialized
INFO - 2023-05-31 09:09:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:09:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:09:30 --> Utf8 Class Initialized
INFO - 2023-05-31 09:09:30 --> URI Class Initialized
INFO - 2023-05-31 09:09:30 --> Router Class Initialized
INFO - 2023-05-31 09:09:30 --> Output Class Initialized
INFO - 2023-05-31 09:09:30 --> Security Class Initialized
DEBUG - 2023-05-31 09:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:09:30 --> Input Class Initialized
INFO - 2023-05-31 09:09:30 --> Language Class Initialized
INFO - 2023-05-31 09:09:30 --> Loader Class Initialized
INFO - 2023-05-31 09:09:30 --> Controller Class Initialized
DEBUG - 2023-05-31 09:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:09:30 --> Database Driver Class Initialized
INFO - 2023-05-31 09:09:30 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:09:30 --> Final output sent to browser
DEBUG - 2023-05-31 09:09:30 --> Total execution time: 0.1624
INFO - 2023-05-31 09:09:30 --> Config Class Initialized
INFO - 2023-05-31 09:09:30 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:09:30 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:09:30 --> Utf8 Class Initialized
INFO - 2023-05-31 09:09:30 --> URI Class Initialized
INFO - 2023-05-31 09:09:30 --> Router Class Initialized
INFO - 2023-05-31 09:09:30 --> Output Class Initialized
INFO - 2023-05-31 09:09:30 --> Security Class Initialized
DEBUG - 2023-05-31 09:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:09:30 --> Input Class Initialized
INFO - 2023-05-31 09:09:30 --> Language Class Initialized
INFO - 2023-05-31 09:09:30 --> Loader Class Initialized
INFO - 2023-05-31 09:09:30 --> Controller Class Initialized
DEBUG - 2023-05-31 09:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:09:30 --> Database Driver Class Initialized
INFO - 2023-05-31 09:09:30 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:09:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
ERROR - 2023-05-31 09:09:30 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Cluster_model.php at Line 25
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3141): Cluster_model->getList('1')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getVariable()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 09:10:04 --> Config Class Initialized
INFO - 2023-05-31 09:10:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:10:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:10:04 --> Utf8 Class Initialized
INFO - 2023-05-31 09:10:04 --> URI Class Initialized
INFO - 2023-05-31 09:10:04 --> Router Class Initialized
INFO - 2023-05-31 09:10:04 --> Output Class Initialized
INFO - 2023-05-31 09:10:04 --> Security Class Initialized
DEBUG - 2023-05-31 09:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:10:04 --> Input Class Initialized
INFO - 2023-05-31 09:10:04 --> Language Class Initialized
INFO - 2023-05-31 09:10:04 --> Loader Class Initialized
INFO - 2023-05-31 09:10:04 --> Controller Class Initialized
DEBUG - 2023-05-31 09:10:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:10:04 --> Database Driver Class Initialized
INFO - 2023-05-31 09:10:04 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:10:04 --> Final output sent to browser
DEBUG - 2023-05-31 09:10:04 --> Total execution time: 0.2216
INFO - 2023-05-31 09:10:04 --> Config Class Initialized
INFO - 2023-05-31 09:10:04 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:10:04 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:10:04 --> Utf8 Class Initialized
INFO - 2023-05-31 09:10:04 --> URI Class Initialized
INFO - 2023-05-31 09:10:04 --> Router Class Initialized
INFO - 2023-05-31 09:10:04 --> Output Class Initialized
INFO - 2023-05-31 09:10:04 --> Security Class Initialized
DEBUG - 2023-05-31 09:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:10:04 --> Input Class Initialized
INFO - 2023-05-31 09:10:04 --> Language Class Initialized
INFO - 2023-05-31 09:10:04 --> Loader Class Initialized
INFO - 2023-05-31 09:10:04 --> Controller Class Initialized
DEBUG - 2023-05-31 09:10:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:10:04 --> Database Driver Class Initialized
INFO - 2023-05-31 09:10:04 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:10:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
ERROR - 2023-05-31 09:10:04 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Cluster_model.php at Line 25
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3141): Cluster_model->getList('1')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getVariable()
#2 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#3 {main}
INFO - 2023-05-31 09:10:23 --> Config Class Initialized
INFO - 2023-05-31 09:10:23 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:10:23 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:10:23 --> Utf8 Class Initialized
INFO - 2023-05-31 09:10:23 --> URI Class Initialized
INFO - 2023-05-31 09:10:23 --> Router Class Initialized
INFO - 2023-05-31 09:10:23 --> Output Class Initialized
INFO - 2023-05-31 09:10:23 --> Security Class Initialized
DEBUG - 2023-05-31 09:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:10:23 --> Input Class Initialized
INFO - 2023-05-31 09:10:23 --> Language Class Initialized
INFO - 2023-05-31 09:10:23 --> Loader Class Initialized
INFO - 2023-05-31 09:10:23 --> Controller Class Initialized
DEBUG - 2023-05-31 09:10:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:10:23 --> Database Driver Class Initialized
INFO - 2023-05-31 09:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:10:24 --> Final output sent to browser
DEBUG - 2023-05-31 09:10:24 --> Total execution time: 0.2185
INFO - 2023-05-31 09:10:24 --> Config Class Initialized
INFO - 2023-05-31 09:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:10:24 --> Utf8 Class Initialized
INFO - 2023-05-31 09:10:24 --> URI Class Initialized
INFO - 2023-05-31 09:10:24 --> Router Class Initialized
INFO - 2023-05-31 09:10:24 --> Output Class Initialized
INFO - 2023-05-31 09:10:24 --> Security Class Initialized
DEBUG - 2023-05-31 09:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:10:24 --> Input Class Initialized
INFO - 2023-05-31 09:10:24 --> Language Class Initialized
INFO - 2023-05-31 09:10:24 --> Loader Class Initialized
INFO - 2023-05-31 09:10:24 --> Controller Class Initialized
DEBUG - 2023-05-31 09:10:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:10:24 --> Database Driver Class Initialized
INFO - 2023-05-31 09:10:24 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:10:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:12:08 --> Config Class Initialized
INFO - 2023-05-31 09:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:12:08 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:12:08 --> Utf8 Class Initialized
INFO - 2023-05-31 09:12:08 --> URI Class Initialized
INFO - 2023-05-31 09:12:08 --> Router Class Initialized
INFO - 2023-05-31 09:12:08 --> Output Class Initialized
INFO - 2023-05-31 09:12:08 --> Security Class Initialized
DEBUG - 2023-05-31 09:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:12:08 --> Input Class Initialized
INFO - 2023-05-31 09:12:08 --> Language Class Initialized
INFO - 2023-05-31 09:12:08 --> Loader Class Initialized
INFO - 2023-05-31 09:12:08 --> Controller Class Initialized
DEBUG - 2023-05-31 09:12:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:12:08 --> Database Driver Class Initialized
INFO - 2023-05-31 09:12:08 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:12:08 --> Final output sent to browser
DEBUG - 2023-05-31 09:12:08 --> Total execution time: 0.2794
INFO - 2023-05-31 09:12:08 --> Config Class Initialized
INFO - 2023-05-31 09:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:12:09 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:12:09 --> Utf8 Class Initialized
INFO - 2023-05-31 09:12:09 --> URI Class Initialized
INFO - 2023-05-31 09:12:09 --> Router Class Initialized
INFO - 2023-05-31 09:12:09 --> Output Class Initialized
INFO - 2023-05-31 09:12:09 --> Security Class Initialized
DEBUG - 2023-05-31 09:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:12:09 --> Input Class Initialized
INFO - 2023-05-31 09:12:09 --> Language Class Initialized
INFO - 2023-05-31 09:12:09 --> Loader Class Initialized
INFO - 2023-05-31 09:12:09 --> Controller Class Initialized
DEBUG - 2023-05-31 09:12:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:12:09 --> Database Driver Class Initialized
INFO - 2023-05-31 09:12:09 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:12:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:12:09 --> Final output sent to browser
DEBUG - 2023-05-31 09:12:09 --> Total execution time: 0.2014
INFO - 2023-05-31 09:16:31 --> Config Class Initialized
INFO - 2023-05-31 09:16:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:16:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:16:31 --> Utf8 Class Initialized
INFO - 2023-05-31 09:16:31 --> URI Class Initialized
INFO - 2023-05-31 09:16:31 --> Router Class Initialized
INFO - 2023-05-31 09:16:31 --> Output Class Initialized
INFO - 2023-05-31 09:16:31 --> Security Class Initialized
DEBUG - 2023-05-31 09:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:16:31 --> Input Class Initialized
INFO - 2023-05-31 09:16:31 --> Language Class Initialized
INFO - 2023-05-31 09:16:31 --> Loader Class Initialized
INFO - 2023-05-31 09:16:31 --> Controller Class Initialized
DEBUG - 2023-05-31 09:16:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:16:31 --> Database Driver Class Initialized
INFO - 2023-05-31 09:16:31 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:16:31 --> Final output sent to browser
DEBUG - 2023-05-31 09:16:31 --> Total execution time: 0.2586
INFO - 2023-05-31 09:16:31 --> Config Class Initialized
INFO - 2023-05-31 09:16:31 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:16:31 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:16:31 --> Utf8 Class Initialized
INFO - 2023-05-31 09:16:31 --> URI Class Initialized
INFO - 2023-05-31 09:16:31 --> Router Class Initialized
INFO - 2023-05-31 09:16:31 --> Output Class Initialized
INFO - 2023-05-31 09:16:31 --> Security Class Initialized
DEBUG - 2023-05-31 09:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:16:31 --> Input Class Initialized
INFO - 2023-05-31 09:16:31 --> Language Class Initialized
INFO - 2023-05-31 09:16:31 --> Loader Class Initialized
INFO - 2023-05-31 09:16:31 --> Controller Class Initialized
DEBUG - 2023-05-31 09:16:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:16:31 --> Database Driver Class Initialized
INFO - 2023-05-31 09:16:31 --> Model "Cluster_model" initialized
ERROR - 2023-05-31 09:16:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1' at line 1 - Invalid query: 1
INFO - 2023-05-31 09:16:31 --> Final output sent to browser
DEBUG - 2023-05-31 09:16:31 --> Total execution time: 0.6068
INFO - 2023-05-31 09:16:43 --> Config Class Initialized
INFO - 2023-05-31 09:16:43 --> Config Class Initialized
INFO - 2023-05-31 09:16:43 --> Hooks Class Initialized
INFO - 2023-05-31 09:16:43 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 09:16:43 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:16:43 --> Utf8 Class Initialized
INFO - 2023-05-31 09:16:43 --> Utf8 Class Initialized
INFO - 2023-05-31 09:16:43 --> URI Class Initialized
INFO - 2023-05-31 09:16:43 --> URI Class Initialized
INFO - 2023-05-31 09:16:43 --> Router Class Initialized
INFO - 2023-05-31 09:16:43 --> Router Class Initialized
INFO - 2023-05-31 09:16:43 --> Output Class Initialized
INFO - 2023-05-31 09:16:43 --> Output Class Initialized
INFO - 2023-05-31 09:16:43 --> Security Class Initialized
INFO - 2023-05-31 09:16:43 --> Security Class Initialized
DEBUG - 2023-05-31 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 09:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:16:43 --> Input Class Initialized
INFO - 2023-05-31 09:16:43 --> Input Class Initialized
INFO - 2023-05-31 09:16:43 --> Language Class Initialized
INFO - 2023-05-31 09:16:43 --> Language Class Initialized
INFO - 2023-05-31 09:16:43 --> Loader Class Initialized
INFO - 2023-05-31 09:16:43 --> Loader Class Initialized
INFO - 2023-05-31 09:16:43 --> Controller Class Initialized
DEBUG - 2023-05-31 09:16:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:16:43 --> Controller Class Initialized
DEBUG - 2023-05-31 09:16:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:16:43 --> Database Driver Class Initialized
INFO - 2023-05-31 09:16:43 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:16:43 --> Database Driver Class Initialized
INFO - 2023-05-31 09:16:43 --> Final output sent to browser
DEBUG - 2023-05-31 09:16:43 --> Total execution time: 0.1661
INFO - 2023-05-31 09:16:43 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:16:43 --> Config Class Initialized
INFO - 2023-05-31 09:16:43 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:16:43 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:16:43 --> Utf8 Class Initialized
INFO - 2023-05-31 09:16:43 --> URI Class Initialized
INFO - 2023-05-31 09:16:43 --> Router Class Initialized
INFO - 2023-05-31 09:16:43 --> Output Class Initialized
INFO - 2023-05-31 09:16:43 --> Security Class Initialized
DEBUG - 2023-05-31 09:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:16:43 --> Input Class Initialized
INFO - 2023-05-31 09:16:43 --> Language Class Initialized
INFO - 2023-05-31 09:16:43 --> Loader Class Initialized
INFO - 2023-05-31 09:16:43 --> Controller Class Initialized
INFO - 2023-05-31 09:16:43 --> Database Driver Class Initialized
DEBUG - 2023-05-31 09:16:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:16:43 --> Model "Login_model" initialized
INFO - 2023-05-31 09:16:43 --> Database Driver Class Initialized
INFO - 2023-05-31 09:16:43 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:16:43 --> Final output sent to browser
DEBUG - 2023-05-31 09:16:43 --> Total execution time: 0.2221
INFO - 2023-05-31 09:16:43 --> Final output sent to browser
DEBUG - 2023-05-31 09:16:43 --> Total execution time: 0.6944
INFO - 2023-05-31 09:16:43 --> Config Class Initialized
INFO - 2023-05-31 09:16:43 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:16:43 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:16:43 --> Utf8 Class Initialized
INFO - 2023-05-31 09:16:43 --> URI Class Initialized
INFO - 2023-05-31 09:16:43 --> Router Class Initialized
INFO - 2023-05-31 09:16:43 --> Output Class Initialized
INFO - 2023-05-31 09:16:43 --> Security Class Initialized
DEBUG - 2023-05-31 09:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:16:43 --> Input Class Initialized
INFO - 2023-05-31 09:16:43 --> Language Class Initialized
INFO - 2023-05-31 09:16:43 --> Loader Class Initialized
INFO - 2023-05-31 09:16:43 --> Controller Class Initialized
DEBUG - 2023-05-31 09:16:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:16:43 --> Database Driver Class Initialized
INFO - 2023-05-31 09:16:43 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:16:43 --> Database Driver Class Initialized
INFO - 2023-05-31 09:16:44 --> Model "Login_model" initialized
INFO - 2023-05-31 09:16:44 --> Final output sent to browser
DEBUG - 2023-05-31 09:16:44 --> Total execution time: 1.0756
INFO - 2023-05-31 09:33:57 --> Config Class Initialized
INFO - 2023-05-31 09:33:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:33:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:33:57 --> Utf8 Class Initialized
INFO - 2023-05-31 09:33:57 --> URI Class Initialized
INFO - 2023-05-31 09:33:57 --> Router Class Initialized
INFO - 2023-05-31 09:33:57 --> Output Class Initialized
INFO - 2023-05-31 09:33:57 --> Security Class Initialized
DEBUG - 2023-05-31 09:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:33:57 --> Input Class Initialized
INFO - 2023-05-31 09:33:57 --> Language Class Initialized
INFO - 2023-05-31 09:33:57 --> Loader Class Initialized
INFO - 2023-05-31 09:33:57 --> Controller Class Initialized
DEBUG - 2023-05-31 09:33:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:33:57 --> Database Driver Class Initialized
INFO - 2023-05-31 09:33:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:33:57 --> Final output sent to browser
DEBUG - 2023-05-31 09:33:57 --> Total execution time: 0.2701
INFO - 2023-05-31 09:33:57 --> Config Class Initialized
INFO - 2023-05-31 09:33:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:33:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:33:57 --> Utf8 Class Initialized
INFO - 2023-05-31 09:33:57 --> URI Class Initialized
INFO - 2023-05-31 09:33:57 --> Router Class Initialized
INFO - 2023-05-31 09:33:57 --> Output Class Initialized
INFO - 2023-05-31 09:33:57 --> Security Class Initialized
DEBUG - 2023-05-31 09:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:33:57 --> Input Class Initialized
INFO - 2023-05-31 09:33:57 --> Language Class Initialized
INFO - 2023-05-31 09:33:57 --> Loader Class Initialized
INFO - 2023-05-31 09:33:57 --> Controller Class Initialized
DEBUG - 2023-05-31 09:33:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:33:57 --> Database Driver Class Initialized
INFO - 2023-05-31 09:33:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:33:57 --> Final output sent to browser
DEBUG - 2023-05-31 09:33:57 --> Total execution time: 0.2533
INFO - 2023-05-31 09:33:58 --> Config Class Initialized
INFO - 2023-05-31 09:33:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:33:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:33:58 --> Utf8 Class Initialized
INFO - 2023-05-31 09:33:58 --> URI Class Initialized
INFO - 2023-05-31 09:33:58 --> Router Class Initialized
INFO - 2023-05-31 09:33:58 --> Output Class Initialized
INFO - 2023-05-31 09:33:58 --> Security Class Initialized
DEBUG - 2023-05-31 09:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:33:59 --> Input Class Initialized
INFO - 2023-05-31 09:33:59 --> Language Class Initialized
INFO - 2023-05-31 09:33:59 --> Loader Class Initialized
INFO - 2023-05-31 09:33:59 --> Controller Class Initialized
DEBUG - 2023-05-31 09:33:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:33:59 --> Database Driver Class Initialized
INFO - 2023-05-31 09:33:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:33:59 --> Final output sent to browser
DEBUG - 2023-05-31 09:33:59 --> Total execution time: 0.4283
INFO - 2023-05-31 09:33:59 --> Config Class Initialized
INFO - 2023-05-31 09:33:59 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:33:59 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:33:59 --> Utf8 Class Initialized
INFO - 2023-05-31 09:33:59 --> URI Class Initialized
INFO - 2023-05-31 09:33:59 --> Router Class Initialized
INFO - 2023-05-31 09:33:59 --> Output Class Initialized
INFO - 2023-05-31 09:33:59 --> Security Class Initialized
DEBUG - 2023-05-31 09:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:33:59 --> Input Class Initialized
INFO - 2023-05-31 09:33:59 --> Language Class Initialized
INFO - 2023-05-31 09:33:59 --> Loader Class Initialized
INFO - 2023-05-31 09:33:59 --> Controller Class Initialized
DEBUG - 2023-05-31 09:33:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:33:59 --> Database Driver Class Initialized
INFO - 2023-05-31 09:33:59 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:33:59 --> Final output sent to browser
DEBUG - 2023-05-31 09:33:59 --> Total execution time: 0.2593
INFO - 2023-05-31 09:34:05 --> Config Class Initialized
INFO - 2023-05-31 09:34:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:34:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:34:05 --> Utf8 Class Initialized
INFO - 2023-05-31 09:34:05 --> URI Class Initialized
INFO - 2023-05-31 09:34:05 --> Router Class Initialized
INFO - 2023-05-31 09:34:05 --> Output Class Initialized
INFO - 2023-05-31 09:34:05 --> Security Class Initialized
DEBUG - 2023-05-31 09:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:34:05 --> Input Class Initialized
INFO - 2023-05-31 09:34:05 --> Language Class Initialized
INFO - 2023-05-31 09:34:05 --> Loader Class Initialized
INFO - 2023-05-31 09:34:05 --> Controller Class Initialized
DEBUG - 2023-05-31 09:34:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:34:05 --> Database Driver Class Initialized
INFO - 2023-05-31 09:34:05 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:34:05 --> Final output sent to browser
DEBUG - 2023-05-31 09:34:05 --> Total execution time: 0.1993
INFO - 2023-05-31 09:34:05 --> Config Class Initialized
INFO - 2023-05-31 09:34:05 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:34:05 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:34:05 --> Utf8 Class Initialized
INFO - 2023-05-31 09:34:05 --> URI Class Initialized
INFO - 2023-05-31 09:34:05 --> Router Class Initialized
INFO - 2023-05-31 09:34:05 --> Output Class Initialized
INFO - 2023-05-31 09:34:05 --> Security Class Initialized
DEBUG - 2023-05-31 09:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:34:05 --> Input Class Initialized
INFO - 2023-05-31 09:34:05 --> Language Class Initialized
INFO - 2023-05-31 09:34:06 --> Loader Class Initialized
INFO - 2023-05-31 09:34:06 --> Controller Class Initialized
DEBUG - 2023-05-31 09:34:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:34:06 --> Database Driver Class Initialized
INFO - 2023-05-31 09:34:06 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:34:06 --> Final output sent to browser
DEBUG - 2023-05-31 09:34:06 --> Total execution time: 0.1893
INFO - 2023-05-31 09:50:57 --> Config Class Initialized
INFO - 2023-05-31 09:50:57 --> Config Class Initialized
INFO - 2023-05-31 09:50:57 --> Hooks Class Initialized
INFO - 2023-05-31 09:50:57 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:50:57 --> UTF-8 Support Enabled
DEBUG - 2023-05-31 09:50:57 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:50:57 --> Utf8 Class Initialized
INFO - 2023-05-31 09:50:57 --> Utf8 Class Initialized
INFO - 2023-05-31 09:50:57 --> URI Class Initialized
INFO - 2023-05-31 09:50:57 --> URI Class Initialized
INFO - 2023-05-31 09:50:57 --> Router Class Initialized
INFO - 2023-05-31 09:50:57 --> Router Class Initialized
INFO - 2023-05-31 09:50:57 --> Output Class Initialized
INFO - 2023-05-31 09:50:57 --> Output Class Initialized
INFO - 2023-05-31 09:50:57 --> Security Class Initialized
INFO - 2023-05-31 09:50:57 --> Security Class Initialized
DEBUG - 2023-05-31 09:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-31 09:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:50:57 --> Input Class Initialized
INFO - 2023-05-31 09:50:57 --> Input Class Initialized
INFO - 2023-05-31 09:50:57 --> Language Class Initialized
INFO - 2023-05-31 09:50:57 --> Language Class Initialized
INFO - 2023-05-31 09:50:57 --> Loader Class Initialized
INFO - 2023-05-31 09:50:57 --> Loader Class Initialized
INFO - 2023-05-31 09:50:57 --> Controller Class Initialized
DEBUG - 2023-05-31 09:50:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:50:57 --> Controller Class Initialized
DEBUG - 2023-05-31 09:50:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:50:57 --> Database Driver Class Initialized
INFO - 2023-05-31 09:50:57 --> Database Driver Class Initialized
INFO - 2023-05-31 09:50:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:50:57 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:50:57 --> Final output sent to browser
DEBUG - 2023-05-31 09:50:58 --> Total execution time: 0.6950
INFO - 2023-05-31 09:50:58 --> Database Driver Class Initialized
INFO - 2023-05-31 09:50:58 --> Model "Login_model" initialized
INFO - 2023-05-31 09:50:58 --> Config Class Initialized
INFO - 2023-05-31 09:50:58 --> Hooks Class Initialized
DEBUG - 2023-05-31 09:50:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:50:58 --> Utf8 Class Initialized
INFO - 2023-05-31 09:50:58 --> URI Class Initialized
INFO - 2023-05-31 09:50:58 --> Router Class Initialized
INFO - 2023-05-31 09:50:58 --> Output Class Initialized
INFO - 2023-05-31 09:50:58 --> Security Class Initialized
DEBUG - 2023-05-31 09:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:50:58 --> Input Class Initialized
INFO - 2023-05-31 09:50:58 --> Language Class Initialized
INFO - 2023-05-31 09:50:58 --> Loader Class Initialized
INFO - 2023-05-31 09:50:58 --> Controller Class Initialized
INFO - 2023-05-31 09:50:58 --> Final output sent to browser
DEBUG - 2023-05-31 09:50:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-31 09:50:58 --> Total execution time: 1.1057
INFO - 2023-05-31 09:50:58 --> Config Class Initialized
INFO - 2023-05-31 09:50:58 --> Database Driver Class Initialized
INFO - 2023-05-31 09:50:58 --> Hooks Class Initialized
INFO - 2023-05-31 09:50:58 --> Model "Cluster_model" initialized
DEBUG - 2023-05-31 09:50:58 --> UTF-8 Support Enabled
INFO - 2023-05-31 09:50:58 --> Utf8 Class Initialized
INFO - 2023-05-31 09:50:58 --> URI Class Initialized
INFO - 2023-05-31 09:50:58 --> Final output sent to browser
DEBUG - 2023-05-31 09:50:58 --> Total execution time: 0.4367
INFO - 2023-05-31 09:50:58 --> Router Class Initialized
INFO - 2023-05-31 09:50:58 --> Output Class Initialized
INFO - 2023-05-31 09:50:58 --> Security Class Initialized
DEBUG - 2023-05-31 09:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-31 09:50:58 --> Input Class Initialized
INFO - 2023-05-31 09:50:58 --> Language Class Initialized
INFO - 2023-05-31 09:50:58 --> Loader Class Initialized
INFO - 2023-05-31 09:50:58 --> Controller Class Initialized
DEBUG - 2023-05-31 09:50:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-31 09:50:58 --> Database Driver Class Initialized
INFO - 2023-05-31 09:50:58 --> Model "Cluster_model" initialized
INFO - 2023-05-31 09:50:58 --> Database Driver Class Initialized
INFO - 2023-05-31 09:50:58 --> Model "Login_model" initialized
INFO - 2023-05-31 09:50:59 --> Final output sent to browser
DEBUG - 2023-05-31 09:50:59 --> Total execution time: 0.8960
