<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-09 02:05:14 --> Config Class Initialized
INFO - 2023-05-09 02:05:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:05:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:05:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:05:14 --> URI Class Initialized
INFO - 2023-05-09 02:05:14 --> Router Class Initialized
INFO - 2023-05-09 02:05:14 --> Output Class Initialized
INFO - 2023-05-09 02:05:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:05:14 --> Input Class Initialized
INFO - 2023-05-09 02:05:14 --> Language Class Initialized
INFO - 2023-05-09 02:05:14 --> Loader Class Initialized
INFO - 2023-05-09 02:05:14 --> Controller Class Initialized
INFO - 2023-05-09 02:05:14 --> Helper loaded: form_helper
INFO - 2023-05-09 02:05:14 --> Helper loaded: url_helper
DEBUG - 2023-05-09 02:05:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:05:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:05:14 --> Total execution time: 0.0111
INFO - 2023-05-09 02:06:11 --> Config Class Initialized
INFO - 2023-05-09 02:06:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:06:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:06:11 --> Utf8 Class Initialized
INFO - 2023-05-09 02:06:11 --> URI Class Initialized
INFO - 2023-05-09 02:06:11 --> Router Class Initialized
INFO - 2023-05-09 02:06:11 --> Output Class Initialized
INFO - 2023-05-09 02:06:11 --> Security Class Initialized
DEBUG - 2023-05-09 02:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:06:11 --> Input Class Initialized
INFO - 2023-05-09 02:06:11 --> Language Class Initialized
INFO - 2023-05-09 02:06:11 --> Loader Class Initialized
INFO - 2023-05-09 02:06:11 --> Controller Class Initialized
INFO - 2023-05-09 02:06:11 --> Helper loaded: form_helper
INFO - 2023-05-09 02:06:11 --> Helper loaded: url_helper
DEBUG - 2023-05-09 02:06:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:06:11 --> Final output sent to browser
DEBUG - 2023-05-09 02:06:11 --> Total execution time: 0.0061
INFO - 2023-05-09 02:06:11 --> Config Class Initialized
INFO - 2023-05-09 02:06:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:06:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:06:11 --> Utf8 Class Initialized
INFO - 2023-05-09 02:06:11 --> URI Class Initialized
INFO - 2023-05-09 02:06:11 --> Router Class Initialized
INFO - 2023-05-09 02:06:11 --> Output Class Initialized
INFO - 2023-05-09 02:06:11 --> Security Class Initialized
DEBUG - 2023-05-09 02:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:06:11 --> Input Class Initialized
INFO - 2023-05-09 02:06:11 --> Language Class Initialized
INFO - 2023-05-09 02:06:11 --> Loader Class Initialized
INFO - 2023-05-09 02:06:11 --> Controller Class Initialized
INFO - 2023-05-09 02:06:11 --> Helper loaded: form_helper
INFO - 2023-05-09 02:06:11 --> Helper loaded: url_helper
DEBUG - 2023-05-09 02:06:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:06:11 --> Final output sent to browser
DEBUG - 2023-05-09 02:06:11 --> Total execution time: 0.1245
INFO - 2023-05-09 02:10:53 --> Config Class Initialized
INFO - 2023-05-09 02:10:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:10:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:53 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:53 --> URI Class Initialized
INFO - 2023-05-09 02:10:53 --> Router Class Initialized
INFO - 2023-05-09 02:10:53 --> Output Class Initialized
INFO - 2023-05-09 02:10:53 --> Security Class Initialized
DEBUG - 2023-05-09 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:53 --> Input Class Initialized
INFO - 2023-05-09 02:10:53 --> Language Class Initialized
INFO - 2023-05-09 02:10:53 --> Loader Class Initialized
INFO - 2023-05-09 02:10:53 --> Controller Class Initialized
INFO - 2023-05-09 02:10:53 --> Helper loaded: form_helper
INFO - 2023-05-09 02:10:53 --> Helper loaded: url_helper
DEBUG - 2023-05-09 02:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:53 --> Model "Change_model" initialized
INFO - 2023-05-09 02:10:53 --> Model "Grafana_model" initialized
INFO - 2023-05-09 02:10:53 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:53 --> Total execution time: 0.0342
INFO - 2023-05-09 02:10:53 --> Config Class Initialized
INFO - 2023-05-09 02:10:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:10:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:53 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:53 --> URI Class Initialized
INFO - 2023-05-09 02:10:53 --> Router Class Initialized
INFO - 2023-05-09 02:10:53 --> Output Class Initialized
INFO - 2023-05-09 02:10:53 --> Security Class Initialized
DEBUG - 2023-05-09 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:53 --> Input Class Initialized
INFO - 2023-05-09 02:10:53 --> Language Class Initialized
INFO - 2023-05-09 02:10:53 --> Loader Class Initialized
INFO - 2023-05-09 02:10:53 --> Controller Class Initialized
INFO - 2023-05-09 02:10:53 --> Helper loaded: form_helper
INFO - 2023-05-09 02:10:53 --> Helper loaded: url_helper
DEBUG - 2023-05-09 02:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:53 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:53 --> Total execution time: 0.0034
INFO - 2023-05-09 02:10:53 --> Config Class Initialized
INFO - 2023-05-09 02:10:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:10:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:53 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:53 --> URI Class Initialized
INFO - 2023-05-09 02:10:53 --> Router Class Initialized
INFO - 2023-05-09 02:10:53 --> Output Class Initialized
INFO - 2023-05-09 02:10:53 --> Security Class Initialized
DEBUG - 2023-05-09 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:53 --> Input Class Initialized
INFO - 2023-05-09 02:10:53 --> Language Class Initialized
INFO - 2023-05-09 02:10:53 --> Loader Class Initialized
INFO - 2023-05-09 02:10:53 --> Controller Class Initialized
INFO - 2023-05-09 02:10:53 --> Helper loaded: form_helper
INFO - 2023-05-09 02:10:53 --> Helper loaded: url_helper
DEBUG - 2023-05-09 02:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:53 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:53 --> Model "Login_model" initialized
INFO - 2023-05-09 02:10:53 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:53 --> Total execution time: 0.0222
INFO - 2023-05-09 02:10:53 --> Config Class Initialized
INFO - 2023-05-09 02:10:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:10:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:53 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:53 --> URI Class Initialized
INFO - 2023-05-09 02:10:53 --> Router Class Initialized
INFO - 2023-05-09 02:10:53 --> Output Class Initialized
INFO - 2023-05-09 02:10:53 --> Security Class Initialized
DEBUG - 2023-05-09 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:53 --> Input Class Initialized
INFO - 2023-05-09 02:10:53 --> Language Class Initialized
INFO - 2023-05-09 02:10:53 --> Loader Class Initialized
INFO - 2023-05-09 02:10:53 --> Controller Class Initialized
DEBUG - 2023-05-09 02:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:53 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:53 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:10:53 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:53 --> Total execution time: 0.0768
INFO - 2023-05-09 02:10:53 --> Config Class Initialized
INFO - 2023-05-09 02:10:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:10:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:53 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:53 --> URI Class Initialized
INFO - 2023-05-09 02:10:53 --> Router Class Initialized
INFO - 2023-05-09 02:10:53 --> Output Class Initialized
INFO - 2023-05-09 02:10:53 --> Security Class Initialized
DEBUG - 2023-05-09 02:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:53 --> Input Class Initialized
INFO - 2023-05-09 02:10:53 --> Language Class Initialized
INFO - 2023-05-09 02:10:53 --> Loader Class Initialized
INFO - 2023-05-09 02:10:53 --> Controller Class Initialized
DEBUG - 2023-05-09 02:10:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:53 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:53 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:10:53 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:53 --> Total execution time: 0.0164
INFO - 2023-05-09 02:10:54 --> Config Class Initialized
INFO - 2023-05-09 02:10:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:10:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:54 --> URI Class Initialized
INFO - 2023-05-09 02:10:54 --> Router Class Initialized
INFO - 2023-05-09 02:10:54 --> Config Class Initialized
INFO - 2023-05-09 02:10:54 --> Hooks Class Initialized
INFO - 2023-05-09 02:10:54 --> Output Class Initialized
DEBUG - 2023-05-09 02:10:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:54 --> URI Class Initialized
INFO - 2023-05-09 02:10:54 --> Input Class Initialized
INFO - 2023-05-09 02:10:54 --> Router Class Initialized
INFO - 2023-05-09 02:10:54 --> Language Class Initialized
INFO - 2023-05-09 02:10:54 --> Output Class Initialized
INFO - 2023-05-09 02:10:54 --> Security Class Initialized
INFO - 2023-05-09 02:10:54 --> Loader Class Initialized
DEBUG - 2023-05-09 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:54 --> Input Class Initialized
INFO - 2023-05-09 02:10:54 --> Language Class Initialized
INFO - 2023-05-09 02:10:54 --> Loader Class Initialized
INFO - 2023-05-09 02:10:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:10:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:54 --> Total execution time: 0.0244
INFO - 2023-05-09 02:10:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:10:54 --> Config Class Initialized
INFO - 2023-05-09 02:10:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:10:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:54 --> URI Class Initialized
INFO - 2023-05-09 02:10:54 --> Router Class Initialized
INFO - 2023-05-09 02:10:54 --> Output Class Initialized
INFO - 2023-05-09 02:10:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:54 --> Input Class Initialized
INFO - 2023-05-09 02:10:54 --> Language Class Initialized
INFO - 2023-05-09 02:10:54 --> Loader Class Initialized
INFO - 2023-05-09 02:10:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:54 --> Model "Login_model" initialized
INFO - 2023-05-09 02:10:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:10:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:54 --> Total execution time: 0.0547
INFO - 2023-05-09 02:10:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:54 --> Total execution time: 0.1407
INFO - 2023-05-09 02:10:54 --> Config Class Initialized
INFO - 2023-05-09 02:10:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:10:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:10:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:10:54 --> URI Class Initialized
INFO - 2023-05-09 02:10:54 --> Router Class Initialized
INFO - 2023-05-09 02:10:54 --> Output Class Initialized
INFO - 2023-05-09 02:10:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:10:54 --> Input Class Initialized
INFO - 2023-05-09 02:10:54 --> Language Class Initialized
INFO - 2023-05-09 02:10:54 --> Loader Class Initialized
INFO - 2023-05-09 02:10:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:10:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:10:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:10:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:10:54 --> Model "Login_model" initialized
INFO - 2023-05-09 02:10:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:10:54 --> Total execution time: 0.1515
INFO - 2023-05-09 02:11:41 --> Config Class Initialized
INFO - 2023-05-09 02:11:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:41 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:41 --> URI Class Initialized
INFO - 2023-05-09 02:11:41 --> Router Class Initialized
INFO - 2023-05-09 02:11:41 --> Output Class Initialized
INFO - 2023-05-09 02:11:41 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:41 --> Input Class Initialized
INFO - 2023-05-09 02:11:41 --> Language Class Initialized
INFO - 2023-05-09 02:11:41 --> Loader Class Initialized
INFO - 2023-05-09 02:11:41 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:41 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:41 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:41 --> Total execution time: 0.0121
INFO - 2023-05-09 02:11:41 --> Config Class Initialized
INFO - 2023-05-09 02:11:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:41 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:41 --> URI Class Initialized
INFO - 2023-05-09 02:11:41 --> Router Class Initialized
INFO - 2023-05-09 02:11:41 --> Output Class Initialized
INFO - 2023-05-09 02:11:41 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:41 --> Input Class Initialized
INFO - 2023-05-09 02:11:41 --> Language Class Initialized
INFO - 2023-05-09 02:11:41 --> Loader Class Initialized
INFO - 2023-05-09 02:11:41 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:41 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:41 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:41 --> Model "Login_model" initialized
INFO - 2023-05-09 02:11:41 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:41 --> Total execution time: 0.0318
INFO - 2023-05-09 02:11:41 --> Config Class Initialized
INFO - 2023-05-09 02:11:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:41 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:41 --> URI Class Initialized
INFO - 2023-05-09 02:11:41 --> Router Class Initialized
INFO - 2023-05-09 02:11:41 --> Output Class Initialized
INFO - 2023-05-09 02:11:41 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:41 --> Input Class Initialized
INFO - 2023-05-09 02:11:41 --> Language Class Initialized
INFO - 2023-05-09 02:11:41 --> Loader Class Initialized
INFO - 2023-05-09 02:11:41 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:41 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:41 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:41 --> Total execution time: 0.0188
INFO - 2023-05-09 02:11:41 --> Config Class Initialized
INFO - 2023-05-09 02:11:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:41 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:41 --> URI Class Initialized
INFO - 2023-05-09 02:11:41 --> Router Class Initialized
INFO - 2023-05-09 02:11:41 --> Output Class Initialized
INFO - 2023-05-09 02:11:41 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:41 --> Input Class Initialized
INFO - 2023-05-09 02:11:41 --> Language Class Initialized
INFO - 2023-05-09 02:11:41 --> Loader Class Initialized
INFO - 2023-05-09 02:11:41 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:41 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:41 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:41 --> Total execution time: 0.0275
INFO - 2023-05-09 02:11:46 --> Config Class Initialized
INFO - 2023-05-09 02:11:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:46 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:46 --> URI Class Initialized
INFO - 2023-05-09 02:11:46 --> Router Class Initialized
INFO - 2023-05-09 02:11:46 --> Output Class Initialized
INFO - 2023-05-09 02:11:46 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:46 --> Input Class Initialized
INFO - 2023-05-09 02:11:46 --> Language Class Initialized
INFO - 2023-05-09 02:11:46 --> Loader Class Initialized
INFO - 2023-05-09 02:11:46 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:46 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:46 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:46 --> Total execution time: 0.0507
INFO - 2023-05-09 02:11:46 --> Config Class Initialized
INFO - 2023-05-09 02:11:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:46 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:46 --> URI Class Initialized
INFO - 2023-05-09 02:11:46 --> Router Class Initialized
INFO - 2023-05-09 02:11:46 --> Output Class Initialized
INFO - 2023-05-09 02:11:46 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:46 --> Input Class Initialized
INFO - 2023-05-09 02:11:46 --> Language Class Initialized
INFO - 2023-05-09 02:11:46 --> Loader Class Initialized
INFO - 2023-05-09 02:11:46 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:46 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:46 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:46 --> Total execution time: 0.0147
INFO - 2023-05-09 02:11:51 --> Config Class Initialized
INFO - 2023-05-09 02:11:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:51 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:51 --> URI Class Initialized
INFO - 2023-05-09 02:11:51 --> Router Class Initialized
INFO - 2023-05-09 02:11:51 --> Output Class Initialized
INFO - 2023-05-09 02:11:51 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:51 --> Input Class Initialized
INFO - 2023-05-09 02:11:51 --> Language Class Initialized
INFO - 2023-05-09 02:11:51 --> Loader Class Initialized
INFO - 2023-05-09 02:11:51 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:51 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:51 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:51 --> Total execution time: 0.0124
INFO - 2023-05-09 02:11:51 --> Config Class Initialized
INFO - 2023-05-09 02:11:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:51 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:51 --> URI Class Initialized
INFO - 2023-05-09 02:11:51 --> Router Class Initialized
INFO - 2023-05-09 02:11:51 --> Output Class Initialized
INFO - 2023-05-09 02:11:51 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:51 --> Input Class Initialized
INFO - 2023-05-09 02:11:51 --> Language Class Initialized
INFO - 2023-05-09 02:11:51 --> Loader Class Initialized
INFO - 2023-05-09 02:11:51 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:51 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:51 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:51 --> Total execution time: 0.0158
INFO - 2023-05-09 02:11:54 --> Config Class Initialized
INFO - 2023-05-09 02:11:54 --> Config Class Initialized
INFO - 2023-05-09 02:11:54 --> Hooks Class Initialized
INFO - 2023-05-09 02:11:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 02:11:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:54 --> URI Class Initialized
INFO - 2023-05-09 02:11:54 --> URI Class Initialized
INFO - 2023-05-09 02:11:54 --> Router Class Initialized
INFO - 2023-05-09 02:11:54 --> Router Class Initialized
INFO - 2023-05-09 02:11:54 --> Output Class Initialized
INFO - 2023-05-09 02:11:54 --> Output Class Initialized
INFO - 2023-05-09 02:11:54 --> Security Class Initialized
INFO - 2023-05-09 02:11:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 02:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:54 --> Input Class Initialized
INFO - 2023-05-09 02:11:54 --> Input Class Initialized
INFO - 2023-05-09 02:11:54 --> Language Class Initialized
INFO - 2023-05-09 02:11:54 --> Language Class Initialized
INFO - 2023-05-09 02:11:54 --> Loader Class Initialized
INFO - 2023-05-09 02:11:54 --> Loader Class Initialized
INFO - 2023-05-09 02:11:54 --> Controller Class Initialized
INFO - 2023-05-09 02:11:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 02:11:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:54 --> Total execution time: 0.0239
INFO - 2023-05-09 02:11:54 --> Config Class Initialized
INFO - 2023-05-09 02:11:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:54 --> URI Class Initialized
INFO - 2023-05-09 02:11:54 --> Router Class Initialized
INFO - 2023-05-09 02:11:54 --> Output Class Initialized
INFO - 2023-05-09 02:11:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:54 --> Input Class Initialized
INFO - 2023-05-09 02:11:54 --> Language Class Initialized
INFO - 2023-05-09 02:11:54 --> Loader Class Initialized
INFO - 2023-05-09 02:11:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:54 --> Model "Login_model" initialized
INFO - 2023-05-09 02:11:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:54 --> Total execution time: 0.0164
INFO - 2023-05-09 02:11:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:54 --> Total execution time: 0.0998
INFO - 2023-05-09 02:11:54 --> Config Class Initialized
INFO - 2023-05-09 02:11:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:11:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:11:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:11:54 --> URI Class Initialized
INFO - 2023-05-09 02:11:54 --> Router Class Initialized
INFO - 2023-05-09 02:11:54 --> Output Class Initialized
INFO - 2023-05-09 02:11:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:11:54 --> Input Class Initialized
INFO - 2023-05-09 02:11:54 --> Language Class Initialized
INFO - 2023-05-09 02:11:54 --> Loader Class Initialized
INFO - 2023-05-09 02:11:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:11:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:11:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:11:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:11:54 --> Model "Login_model" initialized
INFO - 2023-05-09 02:11:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:11:54 --> Total execution time: 0.0819
INFO - 2023-05-09 02:12:08 --> Config Class Initialized
INFO - 2023-05-09 02:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:08 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:08 --> URI Class Initialized
INFO - 2023-05-09 02:12:08 --> Router Class Initialized
INFO - 2023-05-09 02:12:08 --> Output Class Initialized
INFO - 2023-05-09 02:12:08 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:08 --> Input Class Initialized
INFO - 2023-05-09 02:12:08 --> Language Class Initialized
INFO - 2023-05-09 02:12:08 --> Loader Class Initialized
INFO - 2023-05-09 02:12:08 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:08 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:08 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:08 --> Total execution time: 0.0121
INFO - 2023-05-09 02:12:08 --> Config Class Initialized
INFO - 2023-05-09 02:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:08 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:08 --> URI Class Initialized
INFO - 2023-05-09 02:12:08 --> Router Class Initialized
INFO - 2023-05-09 02:12:08 --> Output Class Initialized
INFO - 2023-05-09 02:12:08 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:08 --> Input Class Initialized
INFO - 2023-05-09 02:12:08 --> Language Class Initialized
INFO - 2023-05-09 02:12:08 --> Loader Class Initialized
INFO - 2023-05-09 02:12:08 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:08 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:08 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:08 --> Model "Login_model" initialized
INFO - 2023-05-09 02:12:08 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:08 --> Total execution time: 0.0416
INFO - 2023-05-09 02:12:08 --> Config Class Initialized
INFO - 2023-05-09 02:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:08 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:08 --> URI Class Initialized
INFO - 2023-05-09 02:12:08 --> Router Class Initialized
INFO - 2023-05-09 02:12:08 --> Output Class Initialized
INFO - 2023-05-09 02:12:08 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:08 --> Input Class Initialized
INFO - 2023-05-09 02:12:08 --> Language Class Initialized
INFO - 2023-05-09 02:12:08 --> Loader Class Initialized
INFO - 2023-05-09 02:12:08 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:08 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:08 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:08 --> Total execution time: 0.0113
INFO - 2023-05-09 02:12:08 --> Config Class Initialized
INFO - 2023-05-09 02:12:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:08 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:08 --> URI Class Initialized
INFO - 2023-05-09 02:12:08 --> Router Class Initialized
INFO - 2023-05-09 02:12:08 --> Output Class Initialized
INFO - 2023-05-09 02:12:08 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:08 --> Input Class Initialized
INFO - 2023-05-09 02:12:08 --> Language Class Initialized
INFO - 2023-05-09 02:12:08 --> Loader Class Initialized
INFO - 2023-05-09 02:12:08 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:08 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:08 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:08 --> Total execution time: 0.0617
INFO - 2023-05-09 02:12:13 --> Config Class Initialized
INFO - 2023-05-09 02:12:13 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:13 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:13 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:13 --> URI Class Initialized
INFO - 2023-05-09 02:12:13 --> Router Class Initialized
INFO - 2023-05-09 02:12:13 --> Output Class Initialized
INFO - 2023-05-09 02:12:13 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:13 --> Input Class Initialized
INFO - 2023-05-09 02:12:13 --> Language Class Initialized
INFO - 2023-05-09 02:12:13 --> Loader Class Initialized
INFO - 2023-05-09 02:12:13 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:13 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:13 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:13 --> Total execution time: 0.0143
INFO - 2023-05-09 02:12:13 --> Config Class Initialized
INFO - 2023-05-09 02:12:13 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:13 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:13 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:13 --> URI Class Initialized
INFO - 2023-05-09 02:12:13 --> Router Class Initialized
INFO - 2023-05-09 02:12:13 --> Output Class Initialized
INFO - 2023-05-09 02:12:13 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:13 --> Input Class Initialized
INFO - 2023-05-09 02:12:13 --> Language Class Initialized
INFO - 2023-05-09 02:12:13 --> Loader Class Initialized
INFO - 2023-05-09 02:12:13 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:13 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:13 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:13 --> Total execution time: 0.0170
INFO - 2023-05-09 02:12:18 --> Config Class Initialized
INFO - 2023-05-09 02:12:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:18 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:18 --> URI Class Initialized
INFO - 2023-05-09 02:12:18 --> Router Class Initialized
INFO - 2023-05-09 02:12:18 --> Output Class Initialized
INFO - 2023-05-09 02:12:18 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:18 --> Input Class Initialized
INFO - 2023-05-09 02:12:18 --> Language Class Initialized
INFO - 2023-05-09 02:12:18 --> Loader Class Initialized
INFO - 2023-05-09 02:12:18 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:18 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:18 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:18 --> Total execution time: 0.0222
INFO - 2023-05-09 02:12:18 --> Config Class Initialized
INFO - 2023-05-09 02:12:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:18 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:18 --> URI Class Initialized
INFO - 2023-05-09 02:12:18 --> Router Class Initialized
INFO - 2023-05-09 02:12:18 --> Output Class Initialized
INFO - 2023-05-09 02:12:18 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:18 --> Input Class Initialized
INFO - 2023-05-09 02:12:18 --> Language Class Initialized
INFO - 2023-05-09 02:12:18 --> Loader Class Initialized
INFO - 2023-05-09 02:12:18 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:18 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:18 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:18 --> Total execution time: 0.0196
INFO - 2023-05-09 02:12:23 --> Config Class Initialized
INFO - 2023-05-09 02:12:23 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:23 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:23 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:23 --> URI Class Initialized
INFO - 2023-05-09 02:12:23 --> Router Class Initialized
INFO - 2023-05-09 02:12:23 --> Output Class Initialized
INFO - 2023-05-09 02:12:23 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:23 --> Input Class Initialized
INFO - 2023-05-09 02:12:23 --> Language Class Initialized
INFO - 2023-05-09 02:12:23 --> Loader Class Initialized
INFO - 2023-05-09 02:12:23 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:23 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:23 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:23 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:23 --> Total execution time: 0.0529
INFO - 2023-05-09 02:12:23 --> Config Class Initialized
INFO - 2023-05-09 02:12:23 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:23 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:23 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:23 --> URI Class Initialized
INFO - 2023-05-09 02:12:23 --> Router Class Initialized
INFO - 2023-05-09 02:12:23 --> Output Class Initialized
INFO - 2023-05-09 02:12:23 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:23 --> Input Class Initialized
INFO - 2023-05-09 02:12:23 --> Language Class Initialized
INFO - 2023-05-09 02:12:23 --> Loader Class Initialized
INFO - 2023-05-09 02:12:23 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:23 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:23 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:23 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:23 --> Total execution time: 0.0139
INFO - 2023-05-09 02:12:28 --> Config Class Initialized
INFO - 2023-05-09 02:12:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:28 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:28 --> URI Class Initialized
INFO - 2023-05-09 02:12:28 --> Router Class Initialized
INFO - 2023-05-09 02:12:28 --> Output Class Initialized
INFO - 2023-05-09 02:12:28 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:28 --> Input Class Initialized
INFO - 2023-05-09 02:12:28 --> Language Class Initialized
INFO - 2023-05-09 02:12:28 --> Loader Class Initialized
INFO - 2023-05-09 02:12:28 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:28 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:28 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:28 --> Total execution time: 0.0100
INFO - 2023-05-09 02:12:28 --> Config Class Initialized
INFO - 2023-05-09 02:12:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:28 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:28 --> URI Class Initialized
INFO - 2023-05-09 02:12:28 --> Router Class Initialized
INFO - 2023-05-09 02:12:28 --> Output Class Initialized
INFO - 2023-05-09 02:12:28 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:28 --> Input Class Initialized
INFO - 2023-05-09 02:12:28 --> Language Class Initialized
INFO - 2023-05-09 02:12:28 --> Loader Class Initialized
INFO - 2023-05-09 02:12:28 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:28 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:28 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:28 --> Total execution time: 0.0134
INFO - 2023-05-09 02:12:41 --> Config Class Initialized
INFO - 2023-05-09 02:12:41 --> Config Class Initialized
INFO - 2023-05-09 02:12:41 --> Hooks Class Initialized
INFO - 2023-05-09 02:12:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:41 --> Utf8 Class Initialized
DEBUG - 2023-05-09 02:12:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:41 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:41 --> URI Class Initialized
INFO - 2023-05-09 02:12:41 --> URI Class Initialized
INFO - 2023-05-09 02:12:41 --> Router Class Initialized
INFO - 2023-05-09 02:12:41 --> Router Class Initialized
INFO - 2023-05-09 02:12:41 --> Output Class Initialized
INFO - 2023-05-09 02:12:41 --> Output Class Initialized
INFO - 2023-05-09 02:12:41 --> Security Class Initialized
INFO - 2023-05-09 02:12:41 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 02:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:41 --> Input Class Initialized
INFO - 2023-05-09 02:12:41 --> Input Class Initialized
INFO - 2023-05-09 02:12:41 --> Language Class Initialized
INFO - 2023-05-09 02:12:41 --> Language Class Initialized
INFO - 2023-05-09 02:12:41 --> Loader Class Initialized
INFO - 2023-05-09 02:12:41 --> Loader Class Initialized
INFO - 2023-05-09 02:12:41 --> Controller Class Initialized
INFO - 2023-05-09 02:12:41 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 02:12:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:41 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:42 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:42 --> Total execution time: 0.0433
INFO - 2023-05-09 02:12:42 --> Config Class Initialized
INFO - 2023-05-09 02:12:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:42 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:42 --> URI Class Initialized
INFO - 2023-05-09 02:12:42 --> Router Class Initialized
INFO - 2023-05-09 02:12:42 --> Output Class Initialized
INFO - 2023-05-09 02:12:42 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:42 --> Input Class Initialized
INFO - 2023-05-09 02:12:42 --> Language Class Initialized
INFO - 2023-05-09 02:12:42 --> Loader Class Initialized
INFO - 2023-05-09 02:12:42 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:42 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:42 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:42 --> Model "Login_model" initialized
INFO - 2023-05-09 02:12:42 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:42 --> Total execution time: 0.0146
INFO - 2023-05-09 02:12:42 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:42 --> Total execution time: 0.1146
INFO - 2023-05-09 02:12:42 --> Config Class Initialized
INFO - 2023-05-09 02:12:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:42 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:42 --> URI Class Initialized
INFO - 2023-05-09 02:12:42 --> Router Class Initialized
INFO - 2023-05-09 02:12:42 --> Output Class Initialized
INFO - 2023-05-09 02:12:42 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:42 --> Input Class Initialized
INFO - 2023-05-09 02:12:42 --> Language Class Initialized
INFO - 2023-05-09 02:12:42 --> Loader Class Initialized
INFO - 2023-05-09 02:12:42 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:42 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:42 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:42 --> Model "Login_model" initialized
INFO - 2023-05-09 02:12:42 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:42 --> Total execution time: 0.0690
INFO - 2023-05-09 02:12:52 --> Config Class Initialized
INFO - 2023-05-09 02:12:52 --> Config Class Initialized
INFO - 2023-05-09 02:12:52 --> Hooks Class Initialized
INFO - 2023-05-09 02:12:52 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 02:12:52 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:52 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:52 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:52 --> URI Class Initialized
INFO - 2023-05-09 02:12:52 --> URI Class Initialized
INFO - 2023-05-09 02:12:52 --> Router Class Initialized
INFO - 2023-05-09 02:12:52 --> Router Class Initialized
INFO - 2023-05-09 02:12:52 --> Output Class Initialized
INFO - 2023-05-09 02:12:52 --> Output Class Initialized
INFO - 2023-05-09 02:12:52 --> Security Class Initialized
INFO - 2023-05-09 02:12:52 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 02:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:52 --> Input Class Initialized
INFO - 2023-05-09 02:12:52 --> Input Class Initialized
INFO - 2023-05-09 02:12:52 --> Language Class Initialized
INFO - 2023-05-09 02:12:52 --> Language Class Initialized
INFO - 2023-05-09 02:12:52 --> Loader Class Initialized
INFO - 2023-05-09 02:12:52 --> Loader Class Initialized
INFO - 2023-05-09 02:12:52 --> Controller Class Initialized
INFO - 2023-05-09 02:12:52 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 02:12:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:52 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:52 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:52 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:52 --> Total execution time: 0.1010
INFO - 2023-05-09 02:12:52 --> Config Class Initialized
INFO - 2023-05-09 02:12:52 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:52 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:52 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:52 --> URI Class Initialized
INFO - 2023-05-09 02:12:52 --> Router Class Initialized
INFO - 2023-05-09 02:12:52 --> Output Class Initialized
INFO - 2023-05-09 02:12:52 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:52 --> Input Class Initialized
INFO - 2023-05-09 02:12:52 --> Language Class Initialized
INFO - 2023-05-09 02:12:52 --> Loader Class Initialized
INFO - 2023-05-09 02:12:52 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:52 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:52 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:52 --> Model "Login_model" initialized
INFO - 2023-05-09 02:12:52 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:52 --> Total execution time: 0.0659
INFO - 2023-05-09 02:12:53 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:53 --> Total execution time: 0.5637
INFO - 2023-05-09 02:12:53 --> Config Class Initialized
INFO - 2023-05-09 02:12:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:12:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:12:53 --> Utf8 Class Initialized
INFO - 2023-05-09 02:12:53 --> URI Class Initialized
INFO - 2023-05-09 02:12:53 --> Router Class Initialized
INFO - 2023-05-09 02:12:53 --> Output Class Initialized
INFO - 2023-05-09 02:12:53 --> Security Class Initialized
DEBUG - 2023-05-09 02:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:12:53 --> Input Class Initialized
INFO - 2023-05-09 02:12:53 --> Language Class Initialized
INFO - 2023-05-09 02:12:53 --> Loader Class Initialized
INFO - 2023-05-09 02:12:53 --> Controller Class Initialized
DEBUG - 2023-05-09 02:12:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:12:53 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:53 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:12:53 --> Database Driver Class Initialized
INFO - 2023-05-09 02:12:53 --> Model "Login_model" initialized
INFO - 2023-05-09 02:12:55 --> Final output sent to browser
DEBUG - 2023-05-09 02:12:55 --> Total execution time: 2.0643
INFO - 2023-05-09 02:13:11 --> Config Class Initialized
INFO - 2023-05-09 02:13:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:11 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:11 --> URI Class Initialized
INFO - 2023-05-09 02:13:11 --> Router Class Initialized
INFO - 2023-05-09 02:13:11 --> Output Class Initialized
INFO - 2023-05-09 02:13:11 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:11 --> Input Class Initialized
INFO - 2023-05-09 02:13:11 --> Language Class Initialized
INFO - 2023-05-09 02:13:11 --> Loader Class Initialized
INFO - 2023-05-09 02:13:11 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:11 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:11 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:11 --> Total execution time: 0.0190
INFO - 2023-05-09 02:13:11 --> Config Class Initialized
INFO - 2023-05-09 02:13:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:11 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:11 --> URI Class Initialized
INFO - 2023-05-09 02:13:11 --> Router Class Initialized
INFO - 2023-05-09 02:13:11 --> Output Class Initialized
INFO - 2023-05-09 02:13:11 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:11 --> Input Class Initialized
INFO - 2023-05-09 02:13:11 --> Language Class Initialized
INFO - 2023-05-09 02:13:11 --> Loader Class Initialized
INFO - 2023-05-09 02:13:11 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:11 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:11 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:11 --> Total execution time: 0.0627
INFO - 2023-05-09 02:13:13 --> Config Class Initialized
INFO - 2023-05-09 02:13:13 --> Config Class Initialized
INFO - 2023-05-09 02:13:13 --> Hooks Class Initialized
INFO - 2023-05-09 02:13:13 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 02:13:13 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:13 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:13 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:13 --> URI Class Initialized
INFO - 2023-05-09 02:13:13 --> URI Class Initialized
INFO - 2023-05-09 02:13:13 --> Router Class Initialized
INFO - 2023-05-09 02:13:13 --> Router Class Initialized
INFO - 2023-05-09 02:13:13 --> Output Class Initialized
INFO - 2023-05-09 02:13:13 --> Output Class Initialized
INFO - 2023-05-09 02:13:13 --> Security Class Initialized
INFO - 2023-05-09 02:13:13 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 02:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:13 --> Input Class Initialized
INFO - 2023-05-09 02:13:13 --> Input Class Initialized
INFO - 2023-05-09 02:13:13 --> Language Class Initialized
INFO - 2023-05-09 02:13:13 --> Language Class Initialized
INFO - 2023-05-09 02:13:13 --> Loader Class Initialized
INFO - 2023-05-09 02:13:13 --> Loader Class Initialized
INFO - 2023-05-09 02:13:13 --> Controller Class Initialized
INFO - 2023-05-09 02:13:13 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 02:13:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:13 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:13 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:13 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:13 --> Total execution time: 0.0312
INFO - 2023-05-09 02:13:13 --> Config Class Initialized
INFO - 2023-05-09 02:13:13 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:13 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:13 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:13 --> URI Class Initialized
INFO - 2023-05-09 02:13:13 --> Router Class Initialized
INFO - 2023-05-09 02:13:13 --> Output Class Initialized
INFO - 2023-05-09 02:13:13 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:13 --> Input Class Initialized
INFO - 2023-05-09 02:13:13 --> Language Class Initialized
INFO - 2023-05-09 02:13:13 --> Loader Class Initialized
INFO - 2023-05-09 02:13:13 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:13 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:13 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:13 --> Total execution time: 0.0129
INFO - 2023-05-09 02:13:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:13 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:13 --> Model "Login_model" initialized
INFO - 2023-05-09 02:13:13 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:13 --> Total execution time: 0.1843
INFO - 2023-05-09 02:13:13 --> Config Class Initialized
INFO - 2023-05-09 02:13:13 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:13 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:13 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:13 --> URI Class Initialized
INFO - 2023-05-09 02:13:13 --> Router Class Initialized
INFO - 2023-05-09 02:13:13 --> Output Class Initialized
INFO - 2023-05-09 02:13:13 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:13 --> Input Class Initialized
INFO - 2023-05-09 02:13:13 --> Language Class Initialized
INFO - 2023-05-09 02:13:13 --> Loader Class Initialized
INFO - 2023-05-09 02:13:13 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:13 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:13 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:13 --> Model "Login_model" initialized
INFO - 2023-05-09 02:13:13 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:13 --> Total execution time: 0.0687
INFO - 2023-05-09 02:13:14 --> Config Class Initialized
INFO - 2023-05-09 02:13:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:14 --> URI Class Initialized
INFO - 2023-05-09 02:13:14 --> Router Class Initialized
INFO - 2023-05-09 02:13:14 --> Output Class Initialized
INFO - 2023-05-09 02:13:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:14 --> Input Class Initialized
INFO - 2023-05-09 02:13:14 --> Language Class Initialized
INFO - 2023-05-09 02:13:14 --> Loader Class Initialized
INFO - 2023-05-09 02:13:14 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:14 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:14 --> Total execution time: 0.0125
INFO - 2023-05-09 02:13:14 --> Config Class Initialized
INFO - 2023-05-09 02:13:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:14 --> URI Class Initialized
INFO - 2023-05-09 02:13:14 --> Router Class Initialized
INFO - 2023-05-09 02:13:14 --> Output Class Initialized
INFO - 2023-05-09 02:13:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:14 --> Input Class Initialized
INFO - 2023-05-09 02:13:14 --> Language Class Initialized
INFO - 2023-05-09 02:13:14 --> Loader Class Initialized
INFO - 2023-05-09 02:13:14 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:14 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:14 --> Total execution time: 0.0525
INFO - 2023-05-09 02:13:14 --> Config Class Initialized
INFO - 2023-05-09 02:13:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:14 --> URI Class Initialized
INFO - 2023-05-09 02:13:14 --> Router Class Initialized
INFO - 2023-05-09 02:13:14 --> Output Class Initialized
INFO - 2023-05-09 02:13:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:14 --> Input Class Initialized
INFO - 2023-05-09 02:13:14 --> Language Class Initialized
INFO - 2023-05-09 02:13:14 --> Loader Class Initialized
INFO - 2023-05-09 02:13:14 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:14 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:14 --> Total execution time: 0.0532
INFO - 2023-05-09 02:13:14 --> Config Class Initialized
INFO - 2023-05-09 02:13:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:13:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:13:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:13:14 --> URI Class Initialized
INFO - 2023-05-09 02:13:14 --> Router Class Initialized
INFO - 2023-05-09 02:13:14 --> Output Class Initialized
INFO - 2023-05-09 02:13:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:13:14 --> Input Class Initialized
INFO - 2023-05-09 02:13:14 --> Language Class Initialized
INFO - 2023-05-09 02:13:14 --> Loader Class Initialized
INFO - 2023-05-09 02:13:14 --> Controller Class Initialized
DEBUG - 2023-05-09 02:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:13:14 --> Database Driver Class Initialized
INFO - 2023-05-09 02:13:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:13:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:13:14 --> Total execution time: 0.0545
INFO - 2023-05-09 02:16:27 --> Config Class Initialized
INFO - 2023-05-09 02:16:27 --> Config Class Initialized
INFO - 2023-05-09 02:16:27 --> Hooks Class Initialized
INFO - 2023-05-09 02:16:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:16:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 02:16:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:16:27 --> Utf8 Class Initialized
INFO - 2023-05-09 02:16:27 --> Utf8 Class Initialized
INFO - 2023-05-09 02:16:27 --> URI Class Initialized
INFO - 2023-05-09 02:16:27 --> URI Class Initialized
INFO - 2023-05-09 02:16:27 --> Router Class Initialized
INFO - 2023-05-09 02:16:27 --> Router Class Initialized
INFO - 2023-05-09 02:16:27 --> Output Class Initialized
INFO - 2023-05-09 02:16:27 --> Output Class Initialized
INFO - 2023-05-09 02:16:27 --> Security Class Initialized
INFO - 2023-05-09 02:16:27 --> Security Class Initialized
DEBUG - 2023-05-09 02:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 02:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:16:27 --> Input Class Initialized
INFO - 2023-05-09 02:16:27 --> Input Class Initialized
INFO - 2023-05-09 02:16:27 --> Language Class Initialized
INFO - 2023-05-09 02:16:27 --> Language Class Initialized
INFO - 2023-05-09 02:16:27 --> Loader Class Initialized
INFO - 2023-05-09 02:16:27 --> Loader Class Initialized
INFO - 2023-05-09 02:16:27 --> Controller Class Initialized
INFO - 2023-05-09 02:16:27 --> Controller Class Initialized
DEBUG - 2023-05-09 02:16:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 02:16:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:16:27 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:27 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:16:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:16:27 --> Final output sent to browser
DEBUG - 2023-05-09 02:16:27 --> Total execution time: 0.2609
INFO - 2023-05-09 02:16:27 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:27 --> Config Class Initialized
INFO - 2023-05-09 02:16:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:16:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:16:27 --> Utf8 Class Initialized
INFO - 2023-05-09 02:16:27 --> URI Class Initialized
INFO - 2023-05-09 02:16:27 --> Router Class Initialized
INFO - 2023-05-09 02:16:27 --> Output Class Initialized
INFO - 2023-05-09 02:16:27 --> Security Class Initialized
DEBUG - 2023-05-09 02:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:16:27 --> Input Class Initialized
INFO - 2023-05-09 02:16:27 --> Language Class Initialized
INFO - 2023-05-09 02:16:27 --> Loader Class Initialized
INFO - 2023-05-09 02:16:27 --> Controller Class Initialized
DEBUG - 2023-05-09 02:16:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:16:27 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:27 --> Model "Login_model" initialized
INFO - 2023-05-09 02:16:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:16:27 --> Final output sent to browser
DEBUG - 2023-05-09 02:16:27 --> Total execution time: 0.0518
INFO - 2023-05-09 02:16:27 --> Final output sent to browser
DEBUG - 2023-05-09 02:16:27 --> Total execution time: 0.3708
INFO - 2023-05-09 02:16:27 --> Config Class Initialized
INFO - 2023-05-09 02:16:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:16:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:16:27 --> Utf8 Class Initialized
INFO - 2023-05-09 02:16:27 --> URI Class Initialized
INFO - 2023-05-09 02:16:27 --> Router Class Initialized
INFO - 2023-05-09 02:16:27 --> Output Class Initialized
INFO - 2023-05-09 02:16:27 --> Security Class Initialized
DEBUG - 2023-05-09 02:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:16:27 --> Input Class Initialized
INFO - 2023-05-09 02:16:27 --> Language Class Initialized
INFO - 2023-05-09 02:16:27 --> Loader Class Initialized
INFO - 2023-05-09 02:16:27 --> Controller Class Initialized
DEBUG - 2023-05-09 02:16:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:16:27 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:16:27 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:27 --> Model "Login_model" initialized
INFO - 2023-05-09 02:16:28 --> Final output sent to browser
DEBUG - 2023-05-09 02:16:28 --> Total execution time: 0.1581
INFO - 2023-05-09 02:16:46 --> Config Class Initialized
INFO - 2023-05-09 02:16:46 --> Config Class Initialized
INFO - 2023-05-09 02:16:46 --> Hooks Class Initialized
INFO - 2023-05-09 02:16:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:16:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:16:46 --> Utf8 Class Initialized
INFO - 2023-05-09 02:16:46 --> URI Class Initialized
DEBUG - 2023-05-09 02:16:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:16:46 --> Utf8 Class Initialized
INFO - 2023-05-09 02:16:46 --> Router Class Initialized
INFO - 2023-05-09 02:16:46 --> URI Class Initialized
INFO - 2023-05-09 02:16:46 --> Output Class Initialized
INFO - 2023-05-09 02:16:46 --> Router Class Initialized
INFO - 2023-05-09 02:16:46 --> Security Class Initialized
INFO - 2023-05-09 02:16:46 --> Output Class Initialized
DEBUG - 2023-05-09 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:16:46 --> Security Class Initialized
INFO - 2023-05-09 02:16:46 --> Input Class Initialized
DEBUG - 2023-05-09 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:16:46 --> Input Class Initialized
INFO - 2023-05-09 02:16:46 --> Language Class Initialized
INFO - 2023-05-09 02:16:46 --> Language Class Initialized
INFO - 2023-05-09 02:16:46 --> Loader Class Initialized
INFO - 2023-05-09 02:16:46 --> Loader Class Initialized
INFO - 2023-05-09 02:16:46 --> Controller Class Initialized
INFO - 2023-05-09 02:16:46 --> Controller Class Initialized
DEBUG - 2023-05-09 02:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 02:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:16:46 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:46 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:16:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:16:46 --> Final output sent to browser
DEBUG - 2023-05-09 02:16:46 --> Total execution time: 0.0938
INFO - 2023-05-09 02:16:46 --> Config Class Initialized
INFO - 2023-05-09 02:16:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:16:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:16:46 --> Utf8 Class Initialized
INFO - 2023-05-09 02:16:46 --> URI Class Initialized
INFO - 2023-05-09 02:16:46 --> Router Class Initialized
INFO - 2023-05-09 02:16:46 --> Output Class Initialized
INFO - 2023-05-09 02:16:46 --> Security Class Initialized
DEBUG - 2023-05-09 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:16:46 --> Input Class Initialized
INFO - 2023-05-09 02:16:46 --> Language Class Initialized
INFO - 2023-05-09 02:16:46 --> Loader Class Initialized
INFO - 2023-05-09 02:16:46 --> Controller Class Initialized
DEBUG - 2023-05-09 02:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:16:46 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:46 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:16:46 --> Final output sent to browser
DEBUG - 2023-05-09 02:16:46 --> Total execution time: 0.0144
INFO - 2023-05-09 02:16:46 --> Model "Login_model" initialized
INFO - 2023-05-09 02:16:46 --> Final output sent to browser
DEBUG - 2023-05-09 02:16:46 --> Total execution time: 0.1622
INFO - 2023-05-09 02:16:46 --> Config Class Initialized
INFO - 2023-05-09 02:16:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:16:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:16:46 --> Utf8 Class Initialized
INFO - 2023-05-09 02:16:46 --> URI Class Initialized
INFO - 2023-05-09 02:16:46 --> Router Class Initialized
INFO - 2023-05-09 02:16:46 --> Output Class Initialized
INFO - 2023-05-09 02:16:46 --> Security Class Initialized
DEBUG - 2023-05-09 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:16:46 --> Input Class Initialized
INFO - 2023-05-09 02:16:46 --> Language Class Initialized
INFO - 2023-05-09 02:16:46 --> Loader Class Initialized
INFO - 2023-05-09 02:16:46 --> Controller Class Initialized
DEBUG - 2023-05-09 02:16:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:16:46 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:16:46 --> Database Driver Class Initialized
INFO - 2023-05-09 02:16:46 --> Model "Login_model" initialized
INFO - 2023-05-09 02:16:46 --> Final output sent to browser
DEBUG - 2023-05-09 02:16:46 --> Total execution time: 0.1080
INFO - 2023-05-09 02:17:00 --> Config Class Initialized
INFO - 2023-05-09 02:17:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:00 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:00 --> URI Class Initialized
INFO - 2023-05-09 02:17:00 --> Router Class Initialized
INFO - 2023-05-09 02:17:00 --> Output Class Initialized
INFO - 2023-05-09 02:17:00 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:00 --> Input Class Initialized
INFO - 2023-05-09 02:17:00 --> Language Class Initialized
INFO - 2023-05-09 02:17:00 --> Loader Class Initialized
INFO - 2023-05-09 02:17:00 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:00 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:00 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:00 --> Total execution time: 0.0146
INFO - 2023-05-09 02:17:00 --> Config Class Initialized
INFO - 2023-05-09 02:17:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:00 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:00 --> URI Class Initialized
INFO - 2023-05-09 02:17:00 --> Router Class Initialized
INFO - 2023-05-09 02:17:00 --> Output Class Initialized
INFO - 2023-05-09 02:17:00 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:00 --> Input Class Initialized
INFO - 2023-05-09 02:17:00 --> Language Class Initialized
INFO - 2023-05-09 02:17:00 --> Loader Class Initialized
INFO - 2023-05-09 02:17:00 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:00 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:00 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:00 --> Total execution time: 0.0503
INFO - 2023-05-09 02:17:00 --> Config Class Initialized
INFO - 2023-05-09 02:17:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:00 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:00 --> URI Class Initialized
INFO - 2023-05-09 02:17:00 --> Router Class Initialized
INFO - 2023-05-09 02:17:00 --> Output Class Initialized
INFO - 2023-05-09 02:17:00 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:00 --> Input Class Initialized
INFO - 2023-05-09 02:17:00 --> Language Class Initialized
INFO - 2023-05-09 02:17:00 --> Loader Class Initialized
INFO - 2023-05-09 02:17:00 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:00 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:00 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:00 --> Total execution time: 0.0341
INFO - 2023-05-09 02:17:00 --> Config Class Initialized
INFO - 2023-05-09 02:17:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:00 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:00 --> URI Class Initialized
INFO - 2023-05-09 02:17:00 --> Router Class Initialized
INFO - 2023-05-09 02:17:00 --> Output Class Initialized
INFO - 2023-05-09 02:17:00 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:00 --> Input Class Initialized
INFO - 2023-05-09 02:17:00 --> Language Class Initialized
INFO - 2023-05-09 02:17:00 --> Loader Class Initialized
INFO - 2023-05-09 02:17:00 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:00 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:00 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:00 --> Total execution time: 0.0387
INFO - 2023-05-09 02:17:29 --> Config Class Initialized
INFO - 2023-05-09 02:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:29 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:29 --> URI Class Initialized
INFO - 2023-05-09 02:17:29 --> Router Class Initialized
INFO - 2023-05-09 02:17:29 --> Output Class Initialized
INFO - 2023-05-09 02:17:29 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:29 --> Input Class Initialized
INFO - 2023-05-09 02:17:29 --> Language Class Initialized
INFO - 2023-05-09 02:17:29 --> Loader Class Initialized
INFO - 2023-05-09 02:17:29 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:29 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:29 --> Total execution time: 0.0120
INFO - 2023-05-09 02:17:29 --> Config Class Initialized
INFO - 2023-05-09 02:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:29 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:29 --> URI Class Initialized
INFO - 2023-05-09 02:17:29 --> Router Class Initialized
INFO - 2023-05-09 02:17:29 --> Output Class Initialized
INFO - 2023-05-09 02:17:29 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:29 --> Input Class Initialized
INFO - 2023-05-09 02:17:29 --> Language Class Initialized
INFO - 2023-05-09 02:17:29 --> Loader Class Initialized
INFO - 2023-05-09 02:17:29 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:29 --> Model "Login_model" initialized
INFO - 2023-05-09 02:17:29 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:29 --> Total execution time: 0.0324
INFO - 2023-05-09 02:17:29 --> Config Class Initialized
INFO - 2023-05-09 02:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:29 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:29 --> URI Class Initialized
INFO - 2023-05-09 02:17:29 --> Router Class Initialized
INFO - 2023-05-09 02:17:29 --> Output Class Initialized
INFO - 2023-05-09 02:17:29 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:29 --> Input Class Initialized
INFO - 2023-05-09 02:17:29 --> Language Class Initialized
INFO - 2023-05-09 02:17:29 --> Loader Class Initialized
INFO - 2023-05-09 02:17:29 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:29 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:29 --> Total execution time: 0.0999
INFO - 2023-05-09 02:17:29 --> Config Class Initialized
INFO - 2023-05-09 02:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:29 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:29 --> URI Class Initialized
INFO - 2023-05-09 02:17:29 --> Router Class Initialized
INFO - 2023-05-09 02:17:29 --> Output Class Initialized
INFO - 2023-05-09 02:17:29 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:29 --> Input Class Initialized
INFO - 2023-05-09 02:17:29 --> Language Class Initialized
INFO - 2023-05-09 02:17:29 --> Loader Class Initialized
INFO - 2023-05-09 02:17:29 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:29 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:29 --> Total execution time: 0.0606
INFO - 2023-05-09 02:17:34 --> Config Class Initialized
INFO - 2023-05-09 02:17:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:34 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:34 --> URI Class Initialized
INFO - 2023-05-09 02:17:34 --> Router Class Initialized
INFO - 2023-05-09 02:17:34 --> Output Class Initialized
INFO - 2023-05-09 02:17:34 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:34 --> Input Class Initialized
INFO - 2023-05-09 02:17:34 --> Language Class Initialized
INFO - 2023-05-09 02:17:34 --> Loader Class Initialized
INFO - 2023-05-09 02:17:34 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:34 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:34 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:34 --> Total execution time: 0.0170
INFO - 2023-05-09 02:17:34 --> Config Class Initialized
INFO - 2023-05-09 02:17:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:34 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:34 --> URI Class Initialized
INFO - 2023-05-09 02:17:34 --> Router Class Initialized
INFO - 2023-05-09 02:17:34 --> Output Class Initialized
INFO - 2023-05-09 02:17:34 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:34 --> Input Class Initialized
INFO - 2023-05-09 02:17:34 --> Language Class Initialized
INFO - 2023-05-09 02:17:34 --> Loader Class Initialized
INFO - 2023-05-09 02:17:34 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:34 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:34 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:34 --> Total execution time: 0.5760
INFO - 2023-05-09 02:17:39 --> Config Class Initialized
INFO - 2023-05-09 02:17:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:39 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:39 --> URI Class Initialized
INFO - 2023-05-09 02:17:39 --> Router Class Initialized
INFO - 2023-05-09 02:17:39 --> Output Class Initialized
INFO - 2023-05-09 02:17:39 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:39 --> Input Class Initialized
INFO - 2023-05-09 02:17:39 --> Language Class Initialized
INFO - 2023-05-09 02:17:39 --> Loader Class Initialized
INFO - 2023-05-09 02:17:39 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:39 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:39 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:39 --> Total execution time: 0.0155
INFO - 2023-05-09 02:17:39 --> Config Class Initialized
INFO - 2023-05-09 02:17:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:39 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:39 --> URI Class Initialized
INFO - 2023-05-09 02:17:39 --> Router Class Initialized
INFO - 2023-05-09 02:17:39 --> Output Class Initialized
INFO - 2023-05-09 02:17:39 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:39 --> Input Class Initialized
INFO - 2023-05-09 02:17:39 --> Language Class Initialized
INFO - 2023-05-09 02:17:39 --> Loader Class Initialized
INFO - 2023-05-09 02:17:39 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:39 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:39 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:39 --> Total execution time: 0.0228
INFO - 2023-05-09 02:17:44 --> Config Class Initialized
INFO - 2023-05-09 02:17:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:44 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:44 --> URI Class Initialized
INFO - 2023-05-09 02:17:44 --> Router Class Initialized
INFO - 2023-05-09 02:17:44 --> Output Class Initialized
INFO - 2023-05-09 02:17:44 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:44 --> Input Class Initialized
INFO - 2023-05-09 02:17:44 --> Language Class Initialized
INFO - 2023-05-09 02:17:44 --> Loader Class Initialized
INFO - 2023-05-09 02:17:44 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:44 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:44 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:44 --> Total execution time: 0.0245
INFO - 2023-05-09 02:17:44 --> Config Class Initialized
INFO - 2023-05-09 02:17:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:44 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:44 --> URI Class Initialized
INFO - 2023-05-09 02:17:44 --> Router Class Initialized
INFO - 2023-05-09 02:17:44 --> Output Class Initialized
INFO - 2023-05-09 02:17:44 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:44 --> Input Class Initialized
INFO - 2023-05-09 02:17:44 --> Language Class Initialized
INFO - 2023-05-09 02:17:44 --> Loader Class Initialized
INFO - 2023-05-09 02:17:44 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:44 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:44 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:44 --> Total execution time: 0.0173
INFO - 2023-05-09 02:17:49 --> Config Class Initialized
INFO - 2023-05-09 02:17:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:49 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:49 --> URI Class Initialized
INFO - 2023-05-09 02:17:49 --> Router Class Initialized
INFO - 2023-05-09 02:17:49 --> Output Class Initialized
INFO - 2023-05-09 02:17:49 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:49 --> Input Class Initialized
INFO - 2023-05-09 02:17:49 --> Language Class Initialized
INFO - 2023-05-09 02:17:49 --> Loader Class Initialized
INFO - 2023-05-09 02:17:49 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:49 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:49 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:49 --> Total execution time: 0.0612
INFO - 2023-05-09 02:17:49 --> Config Class Initialized
INFO - 2023-05-09 02:17:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:49 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:49 --> URI Class Initialized
INFO - 2023-05-09 02:17:49 --> Router Class Initialized
INFO - 2023-05-09 02:17:49 --> Output Class Initialized
INFO - 2023-05-09 02:17:49 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:49 --> Input Class Initialized
INFO - 2023-05-09 02:17:49 --> Language Class Initialized
INFO - 2023-05-09 02:17:49 --> Loader Class Initialized
INFO - 2023-05-09 02:17:49 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:49 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:49 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:49 --> Total execution time: 0.0625
INFO - 2023-05-09 02:17:54 --> Config Class Initialized
INFO - 2023-05-09 02:17:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:54 --> URI Class Initialized
INFO - 2023-05-09 02:17:54 --> Router Class Initialized
INFO - 2023-05-09 02:17:54 --> Output Class Initialized
INFO - 2023-05-09 02:17:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:54 --> Input Class Initialized
INFO - 2023-05-09 02:17:54 --> Language Class Initialized
INFO - 2023-05-09 02:17:54 --> Loader Class Initialized
INFO - 2023-05-09 02:17:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:54 --> Total execution time: 0.0201
INFO - 2023-05-09 02:17:54 --> Config Class Initialized
INFO - 2023-05-09 02:17:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:54 --> URI Class Initialized
INFO - 2023-05-09 02:17:54 --> Router Class Initialized
INFO - 2023-05-09 02:17:54 --> Output Class Initialized
INFO - 2023-05-09 02:17:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:54 --> Input Class Initialized
INFO - 2023-05-09 02:17:54 --> Language Class Initialized
INFO - 2023-05-09 02:17:54 --> Loader Class Initialized
INFO - 2023-05-09 02:17:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:54 --> Total execution time: 0.0325
INFO - 2023-05-09 02:17:59 --> Config Class Initialized
INFO - 2023-05-09 02:17:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:59 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:59 --> URI Class Initialized
INFO - 2023-05-09 02:17:59 --> Router Class Initialized
INFO - 2023-05-09 02:17:59 --> Output Class Initialized
INFO - 2023-05-09 02:17:59 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:59 --> Input Class Initialized
INFO - 2023-05-09 02:17:59 --> Language Class Initialized
INFO - 2023-05-09 02:17:59 --> Loader Class Initialized
INFO - 2023-05-09 02:17:59 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:59 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:17:59 --> Final output sent to browser
DEBUG - 2023-05-09 02:17:59 --> Total execution time: 0.0173
INFO - 2023-05-09 02:17:59 --> Config Class Initialized
INFO - 2023-05-09 02:17:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:17:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:17:59 --> Utf8 Class Initialized
INFO - 2023-05-09 02:17:59 --> URI Class Initialized
INFO - 2023-05-09 02:17:59 --> Router Class Initialized
INFO - 2023-05-09 02:17:59 --> Output Class Initialized
INFO - 2023-05-09 02:17:59 --> Security Class Initialized
DEBUG - 2023-05-09 02:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:17:59 --> Input Class Initialized
INFO - 2023-05-09 02:17:59 --> Language Class Initialized
INFO - 2023-05-09 02:17:59 --> Loader Class Initialized
INFO - 2023-05-09 02:17:59 --> Controller Class Initialized
DEBUG - 2023-05-09 02:17:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:17:59 --> Database Driver Class Initialized
INFO - 2023-05-09 02:17:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:00 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:00 --> Total execution time: 0.9293
INFO - 2023-05-09 02:18:04 --> Config Class Initialized
INFO - 2023-05-09 02:18:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:04 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:04 --> URI Class Initialized
INFO - 2023-05-09 02:18:04 --> Router Class Initialized
INFO - 2023-05-09 02:18:04 --> Output Class Initialized
INFO - 2023-05-09 02:18:04 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:04 --> Input Class Initialized
INFO - 2023-05-09 02:18:04 --> Language Class Initialized
INFO - 2023-05-09 02:18:04 --> Loader Class Initialized
INFO - 2023-05-09 02:18:04 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:04 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:04 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:04 --> Total execution time: 0.0195
INFO - 2023-05-09 02:18:04 --> Config Class Initialized
INFO - 2023-05-09 02:18:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:04 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:04 --> URI Class Initialized
INFO - 2023-05-09 02:18:04 --> Router Class Initialized
INFO - 2023-05-09 02:18:04 --> Output Class Initialized
INFO - 2023-05-09 02:18:04 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:04 --> Input Class Initialized
INFO - 2023-05-09 02:18:04 --> Language Class Initialized
INFO - 2023-05-09 02:18:04 --> Loader Class Initialized
INFO - 2023-05-09 02:18:04 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:04 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:04 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:04 --> Total execution time: 0.4043
INFO - 2023-05-09 02:18:09 --> Config Class Initialized
INFO - 2023-05-09 02:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:09 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:09 --> URI Class Initialized
INFO - 2023-05-09 02:18:09 --> Router Class Initialized
INFO - 2023-05-09 02:18:09 --> Output Class Initialized
INFO - 2023-05-09 02:18:09 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:09 --> Input Class Initialized
INFO - 2023-05-09 02:18:09 --> Language Class Initialized
INFO - 2023-05-09 02:18:09 --> Loader Class Initialized
INFO - 2023-05-09 02:18:09 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:09 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:09 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:09 --> Total execution time: 0.0215
INFO - 2023-05-09 02:18:09 --> Config Class Initialized
INFO - 2023-05-09 02:18:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:09 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:09 --> URI Class Initialized
INFO - 2023-05-09 02:18:09 --> Router Class Initialized
INFO - 2023-05-09 02:18:09 --> Output Class Initialized
INFO - 2023-05-09 02:18:09 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:09 --> Input Class Initialized
INFO - 2023-05-09 02:18:09 --> Language Class Initialized
INFO - 2023-05-09 02:18:09 --> Loader Class Initialized
INFO - 2023-05-09 02:18:09 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:09 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:09 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:09 --> Total execution time: 0.0226
INFO - 2023-05-09 02:18:14 --> Config Class Initialized
INFO - 2023-05-09 02:18:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:14 --> URI Class Initialized
INFO - 2023-05-09 02:18:14 --> Router Class Initialized
INFO - 2023-05-09 02:18:14 --> Output Class Initialized
INFO - 2023-05-09 02:18:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:14 --> Input Class Initialized
INFO - 2023-05-09 02:18:14 --> Language Class Initialized
INFO - 2023-05-09 02:18:14 --> Loader Class Initialized
INFO - 2023-05-09 02:18:14 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:14 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:14 --> Total execution time: 0.0942
INFO - 2023-05-09 02:18:14 --> Config Class Initialized
INFO - 2023-05-09 02:18:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:14 --> URI Class Initialized
INFO - 2023-05-09 02:18:14 --> Router Class Initialized
INFO - 2023-05-09 02:18:14 --> Output Class Initialized
INFO - 2023-05-09 02:18:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:14 --> Input Class Initialized
INFO - 2023-05-09 02:18:14 --> Language Class Initialized
INFO - 2023-05-09 02:18:14 --> Loader Class Initialized
INFO - 2023-05-09 02:18:14 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:14 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:14 --> Total execution time: 0.0248
INFO - 2023-05-09 02:18:19 --> Config Class Initialized
INFO - 2023-05-09 02:18:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:19 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:19 --> URI Class Initialized
INFO - 2023-05-09 02:18:19 --> Router Class Initialized
INFO - 2023-05-09 02:18:19 --> Output Class Initialized
INFO - 2023-05-09 02:18:19 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:19 --> Input Class Initialized
INFO - 2023-05-09 02:18:19 --> Language Class Initialized
INFO - 2023-05-09 02:18:19 --> Loader Class Initialized
INFO - 2023-05-09 02:18:19 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:19 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:19 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:19 --> Total execution time: 0.0190
INFO - 2023-05-09 02:18:19 --> Config Class Initialized
INFO - 2023-05-09 02:18:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:19 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:19 --> URI Class Initialized
INFO - 2023-05-09 02:18:19 --> Router Class Initialized
INFO - 2023-05-09 02:18:19 --> Output Class Initialized
INFO - 2023-05-09 02:18:19 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:19 --> Input Class Initialized
INFO - 2023-05-09 02:18:19 --> Language Class Initialized
INFO - 2023-05-09 02:18:19 --> Loader Class Initialized
INFO - 2023-05-09 02:18:19 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:19 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:20 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:20 --> Total execution time: 1.0899
INFO - 2023-05-09 02:18:24 --> Config Class Initialized
INFO - 2023-05-09 02:18:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:24 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:24 --> URI Class Initialized
INFO - 2023-05-09 02:18:24 --> Router Class Initialized
INFO - 2023-05-09 02:18:24 --> Output Class Initialized
INFO - 2023-05-09 02:18:24 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:24 --> Input Class Initialized
INFO - 2023-05-09 02:18:24 --> Language Class Initialized
INFO - 2023-05-09 02:18:24 --> Loader Class Initialized
INFO - 2023-05-09 02:18:24 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:24 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:24 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:24 --> Total execution time: 0.0184
INFO - 2023-05-09 02:18:24 --> Config Class Initialized
INFO - 2023-05-09 02:18:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:24 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:24 --> URI Class Initialized
INFO - 2023-05-09 02:18:24 --> Router Class Initialized
INFO - 2023-05-09 02:18:24 --> Output Class Initialized
INFO - 2023-05-09 02:18:24 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:24 --> Input Class Initialized
INFO - 2023-05-09 02:18:24 --> Language Class Initialized
INFO - 2023-05-09 02:18:24 --> Loader Class Initialized
INFO - 2023-05-09 02:18:24 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:24 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:26 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:26 --> Total execution time: 2.7963
INFO - 2023-05-09 02:18:29 --> Config Class Initialized
INFO - 2023-05-09 02:18:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:29 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:29 --> URI Class Initialized
INFO - 2023-05-09 02:18:29 --> Router Class Initialized
INFO - 2023-05-09 02:18:29 --> Output Class Initialized
INFO - 2023-05-09 02:18:29 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:29 --> Input Class Initialized
INFO - 2023-05-09 02:18:29 --> Language Class Initialized
INFO - 2023-05-09 02:18:29 --> Loader Class Initialized
INFO - 2023-05-09 02:18:29 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:29 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:29 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:29 --> Total execution time: 0.0218
INFO - 2023-05-09 02:18:29 --> Config Class Initialized
INFO - 2023-05-09 02:18:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:29 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:29 --> URI Class Initialized
INFO - 2023-05-09 02:18:29 --> Router Class Initialized
INFO - 2023-05-09 02:18:29 --> Output Class Initialized
INFO - 2023-05-09 02:18:29 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:29 --> Input Class Initialized
INFO - 2023-05-09 02:18:29 --> Language Class Initialized
INFO - 2023-05-09 02:18:29 --> Loader Class Initialized
INFO - 2023-05-09 02:18:29 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:29 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:29 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:29 --> Total execution time: 0.0209
INFO - 2023-05-09 02:18:34 --> Config Class Initialized
INFO - 2023-05-09 02:18:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:34 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:34 --> URI Class Initialized
INFO - 2023-05-09 02:18:34 --> Router Class Initialized
INFO - 2023-05-09 02:18:34 --> Output Class Initialized
INFO - 2023-05-09 02:18:34 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:34 --> Input Class Initialized
INFO - 2023-05-09 02:18:34 --> Language Class Initialized
INFO - 2023-05-09 02:18:34 --> Loader Class Initialized
INFO - 2023-05-09 02:18:34 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:34 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:34 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:34 --> Total execution time: 0.0939
INFO - 2023-05-09 02:18:34 --> Config Class Initialized
INFO - 2023-05-09 02:18:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:34 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:34 --> URI Class Initialized
INFO - 2023-05-09 02:18:34 --> Router Class Initialized
INFO - 2023-05-09 02:18:34 --> Output Class Initialized
INFO - 2023-05-09 02:18:34 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:34 --> Input Class Initialized
INFO - 2023-05-09 02:18:34 --> Language Class Initialized
INFO - 2023-05-09 02:18:34 --> Loader Class Initialized
INFO - 2023-05-09 02:18:34 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:34 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:34 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:34 --> Total execution time: 0.0337
INFO - 2023-05-09 02:18:39 --> Config Class Initialized
INFO - 2023-05-09 02:18:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:39 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:39 --> URI Class Initialized
INFO - 2023-05-09 02:18:39 --> Router Class Initialized
INFO - 2023-05-09 02:18:39 --> Output Class Initialized
INFO - 2023-05-09 02:18:39 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:39 --> Input Class Initialized
INFO - 2023-05-09 02:18:39 --> Language Class Initialized
INFO - 2023-05-09 02:18:39 --> Loader Class Initialized
INFO - 2023-05-09 02:18:39 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:39 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:39 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:39 --> Total execution time: 0.0139
INFO - 2023-05-09 02:18:39 --> Config Class Initialized
INFO - 2023-05-09 02:18:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:39 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:39 --> URI Class Initialized
INFO - 2023-05-09 02:18:39 --> Router Class Initialized
INFO - 2023-05-09 02:18:39 --> Output Class Initialized
INFO - 2023-05-09 02:18:39 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:39 --> Input Class Initialized
INFO - 2023-05-09 02:18:39 --> Language Class Initialized
INFO - 2023-05-09 02:18:39 --> Loader Class Initialized
INFO - 2023-05-09 02:18:39 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:39 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:40 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:40 --> Total execution time: 1.6233
INFO - 2023-05-09 02:18:44 --> Config Class Initialized
INFO - 2023-05-09 02:18:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:44 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:44 --> URI Class Initialized
INFO - 2023-05-09 02:18:44 --> Router Class Initialized
INFO - 2023-05-09 02:18:44 --> Output Class Initialized
INFO - 2023-05-09 02:18:44 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:44 --> Input Class Initialized
INFO - 2023-05-09 02:18:44 --> Language Class Initialized
INFO - 2023-05-09 02:18:44 --> Loader Class Initialized
INFO - 2023-05-09 02:18:44 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:44 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:44 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:44 --> Total execution time: 0.0143
INFO - 2023-05-09 02:18:44 --> Config Class Initialized
INFO - 2023-05-09 02:18:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:44 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:44 --> URI Class Initialized
INFO - 2023-05-09 02:18:44 --> Router Class Initialized
INFO - 2023-05-09 02:18:44 --> Output Class Initialized
INFO - 2023-05-09 02:18:44 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:44 --> Input Class Initialized
INFO - 2023-05-09 02:18:44 --> Language Class Initialized
INFO - 2023-05-09 02:18:44 --> Loader Class Initialized
INFO - 2023-05-09 02:18:44 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:44 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:44 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:44 --> Total execution time: 0.0220
INFO - 2023-05-09 02:18:49 --> Config Class Initialized
INFO - 2023-05-09 02:18:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:49 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:49 --> URI Class Initialized
INFO - 2023-05-09 02:18:49 --> Router Class Initialized
INFO - 2023-05-09 02:18:49 --> Output Class Initialized
INFO - 2023-05-09 02:18:49 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:49 --> Input Class Initialized
INFO - 2023-05-09 02:18:49 --> Language Class Initialized
INFO - 2023-05-09 02:18:49 --> Loader Class Initialized
INFO - 2023-05-09 02:18:49 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:49 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:49 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:49 --> Total execution time: 0.0124
INFO - 2023-05-09 02:18:49 --> Config Class Initialized
INFO - 2023-05-09 02:18:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:49 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:49 --> URI Class Initialized
INFO - 2023-05-09 02:18:49 --> Router Class Initialized
INFO - 2023-05-09 02:18:49 --> Output Class Initialized
INFO - 2023-05-09 02:18:49 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:49 --> Input Class Initialized
INFO - 2023-05-09 02:18:49 --> Language Class Initialized
INFO - 2023-05-09 02:18:49 --> Loader Class Initialized
INFO - 2023-05-09 02:18:49 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:49 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:49 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:49 --> Total execution time: 0.0184
INFO - 2023-05-09 02:18:54 --> Config Class Initialized
INFO - 2023-05-09 02:18:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:54 --> URI Class Initialized
INFO - 2023-05-09 02:18:54 --> Router Class Initialized
INFO - 2023-05-09 02:18:54 --> Output Class Initialized
INFO - 2023-05-09 02:18:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:54 --> Input Class Initialized
INFO - 2023-05-09 02:18:54 --> Language Class Initialized
INFO - 2023-05-09 02:18:54 --> Loader Class Initialized
INFO - 2023-05-09 02:18:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:54 --> Total execution time: 0.0141
INFO - 2023-05-09 02:18:54 --> Config Class Initialized
INFO - 2023-05-09 02:18:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:54 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:54 --> URI Class Initialized
INFO - 2023-05-09 02:18:54 --> Router Class Initialized
INFO - 2023-05-09 02:18:54 --> Output Class Initialized
INFO - 2023-05-09 02:18:54 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:54 --> Input Class Initialized
INFO - 2023-05-09 02:18:54 --> Language Class Initialized
INFO - 2023-05-09 02:18:54 --> Loader Class Initialized
INFO - 2023-05-09 02:18:54 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:54 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:54 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:54 --> Total execution time: 0.0152
INFO - 2023-05-09 02:18:59 --> Config Class Initialized
INFO - 2023-05-09 02:18:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:59 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:59 --> URI Class Initialized
INFO - 2023-05-09 02:18:59 --> Router Class Initialized
INFO - 2023-05-09 02:18:59 --> Output Class Initialized
INFO - 2023-05-09 02:18:59 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:59 --> Input Class Initialized
INFO - 2023-05-09 02:18:59 --> Language Class Initialized
INFO - 2023-05-09 02:18:59 --> Loader Class Initialized
INFO - 2023-05-09 02:18:59 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:59 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:59 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:59 --> Total execution time: 0.0143
INFO - 2023-05-09 02:18:59 --> Config Class Initialized
INFO - 2023-05-09 02:18:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:18:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:18:59 --> Utf8 Class Initialized
INFO - 2023-05-09 02:18:59 --> URI Class Initialized
INFO - 2023-05-09 02:18:59 --> Router Class Initialized
INFO - 2023-05-09 02:18:59 --> Output Class Initialized
INFO - 2023-05-09 02:18:59 --> Security Class Initialized
DEBUG - 2023-05-09 02:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:18:59 --> Input Class Initialized
INFO - 2023-05-09 02:18:59 --> Language Class Initialized
INFO - 2023-05-09 02:18:59 --> Loader Class Initialized
INFO - 2023-05-09 02:18:59 --> Controller Class Initialized
DEBUG - 2023-05-09 02:18:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:18:59 --> Database Driver Class Initialized
INFO - 2023-05-09 02:18:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:18:59 --> Final output sent to browser
DEBUG - 2023-05-09 02:18:59 --> Total execution time: 0.0145
INFO - 2023-05-09 02:19:04 --> Config Class Initialized
INFO - 2023-05-09 02:19:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:04 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:04 --> URI Class Initialized
INFO - 2023-05-09 02:19:04 --> Router Class Initialized
INFO - 2023-05-09 02:19:04 --> Output Class Initialized
INFO - 2023-05-09 02:19:04 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:04 --> Input Class Initialized
INFO - 2023-05-09 02:19:04 --> Language Class Initialized
INFO - 2023-05-09 02:19:04 --> Loader Class Initialized
INFO - 2023-05-09 02:19:04 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:04 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:04 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:04 --> Total execution time: 0.0131
INFO - 2023-05-09 02:19:04 --> Config Class Initialized
INFO - 2023-05-09 02:19:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:04 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:04 --> URI Class Initialized
INFO - 2023-05-09 02:19:04 --> Router Class Initialized
INFO - 2023-05-09 02:19:04 --> Output Class Initialized
INFO - 2023-05-09 02:19:04 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:04 --> Input Class Initialized
INFO - 2023-05-09 02:19:04 --> Language Class Initialized
INFO - 2023-05-09 02:19:04 --> Loader Class Initialized
INFO - 2023-05-09 02:19:04 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:04 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:04 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:04 --> Total execution time: 0.1233
INFO - 2023-05-09 02:19:09 --> Config Class Initialized
INFO - 2023-05-09 02:19:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:09 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:09 --> URI Class Initialized
INFO - 2023-05-09 02:19:09 --> Router Class Initialized
INFO - 2023-05-09 02:19:09 --> Output Class Initialized
INFO - 2023-05-09 02:19:09 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:09 --> Input Class Initialized
INFO - 2023-05-09 02:19:09 --> Language Class Initialized
INFO - 2023-05-09 02:19:09 --> Loader Class Initialized
INFO - 2023-05-09 02:19:09 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:09 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:09 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:09 --> Total execution time: 0.0136
INFO - 2023-05-09 02:19:09 --> Config Class Initialized
INFO - 2023-05-09 02:19:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:09 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:09 --> URI Class Initialized
INFO - 2023-05-09 02:19:09 --> Router Class Initialized
INFO - 2023-05-09 02:19:09 --> Output Class Initialized
INFO - 2023-05-09 02:19:09 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:09 --> Input Class Initialized
INFO - 2023-05-09 02:19:09 --> Language Class Initialized
INFO - 2023-05-09 02:19:09 --> Loader Class Initialized
INFO - 2023-05-09 02:19:09 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:09 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:09 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:09 --> Total execution time: 0.0130
INFO - 2023-05-09 02:19:14 --> Config Class Initialized
INFO - 2023-05-09 02:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:14 --> URI Class Initialized
INFO - 2023-05-09 02:19:14 --> Router Class Initialized
INFO - 2023-05-09 02:19:14 --> Output Class Initialized
INFO - 2023-05-09 02:19:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:14 --> Input Class Initialized
INFO - 2023-05-09 02:19:14 --> Language Class Initialized
INFO - 2023-05-09 02:19:14 --> Loader Class Initialized
INFO - 2023-05-09 02:19:14 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:14 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:14 --> Total execution time: 0.0504
INFO - 2023-05-09 02:19:14 --> Config Class Initialized
INFO - 2023-05-09 02:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:14 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:14 --> URI Class Initialized
INFO - 2023-05-09 02:19:14 --> Router Class Initialized
INFO - 2023-05-09 02:19:14 --> Output Class Initialized
INFO - 2023-05-09 02:19:14 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:14 --> Input Class Initialized
INFO - 2023-05-09 02:19:14 --> Language Class Initialized
INFO - 2023-05-09 02:19:14 --> Loader Class Initialized
INFO - 2023-05-09 02:19:14 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:14 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:14 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:14 --> Total execution time: 0.0148
INFO - 2023-05-09 02:19:19 --> Config Class Initialized
INFO - 2023-05-09 02:19:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:19 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:19 --> URI Class Initialized
INFO - 2023-05-09 02:19:19 --> Router Class Initialized
INFO - 2023-05-09 02:19:19 --> Output Class Initialized
INFO - 2023-05-09 02:19:19 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:19 --> Input Class Initialized
INFO - 2023-05-09 02:19:19 --> Language Class Initialized
INFO - 2023-05-09 02:19:19 --> Loader Class Initialized
INFO - 2023-05-09 02:19:19 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:19 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:19 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:19 --> Total execution time: 0.0188
INFO - 2023-05-09 02:19:19 --> Config Class Initialized
INFO - 2023-05-09 02:19:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:19 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:19 --> URI Class Initialized
INFO - 2023-05-09 02:19:19 --> Router Class Initialized
INFO - 2023-05-09 02:19:19 --> Output Class Initialized
INFO - 2023-05-09 02:19:19 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:19 --> Input Class Initialized
INFO - 2023-05-09 02:19:19 --> Language Class Initialized
INFO - 2023-05-09 02:19:19 --> Loader Class Initialized
INFO - 2023-05-09 02:19:19 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:19 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:19 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:19 --> Total execution time: 0.2018
INFO - 2023-05-09 02:19:24 --> Config Class Initialized
INFO - 2023-05-09 02:19:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:24 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:24 --> URI Class Initialized
INFO - 2023-05-09 02:19:24 --> Router Class Initialized
INFO - 2023-05-09 02:19:24 --> Output Class Initialized
INFO - 2023-05-09 02:19:24 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:24 --> Input Class Initialized
INFO - 2023-05-09 02:19:24 --> Language Class Initialized
INFO - 2023-05-09 02:19:24 --> Loader Class Initialized
INFO - 2023-05-09 02:19:24 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:24 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:24 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:24 --> Total execution time: 0.0161
INFO - 2023-05-09 02:19:24 --> Config Class Initialized
INFO - 2023-05-09 02:19:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:24 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:24 --> URI Class Initialized
INFO - 2023-05-09 02:19:24 --> Router Class Initialized
INFO - 2023-05-09 02:19:24 --> Output Class Initialized
INFO - 2023-05-09 02:19:24 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:24 --> Input Class Initialized
INFO - 2023-05-09 02:19:24 --> Language Class Initialized
INFO - 2023-05-09 02:19:24 --> Loader Class Initialized
INFO - 2023-05-09 02:19:24 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:24 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:24 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:24 --> Total execution time: 0.0121
INFO - 2023-05-09 02:19:35 --> Config Class Initialized
INFO - 2023-05-09 02:19:35 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:35 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:35 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:35 --> URI Class Initialized
INFO - 2023-05-09 02:19:35 --> Router Class Initialized
INFO - 2023-05-09 02:19:35 --> Output Class Initialized
INFO - 2023-05-09 02:19:35 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:35 --> Input Class Initialized
INFO - 2023-05-09 02:19:35 --> Language Class Initialized
INFO - 2023-05-09 02:19:35 --> Loader Class Initialized
INFO - 2023-05-09 02:19:35 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:35 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:35 --> Total execution time: 0.0461
INFO - 2023-05-09 02:19:35 --> Config Class Initialized
INFO - 2023-05-09 02:19:35 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:35 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:35 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:35 --> URI Class Initialized
INFO - 2023-05-09 02:19:35 --> Router Class Initialized
INFO - 2023-05-09 02:19:35 --> Output Class Initialized
INFO - 2023-05-09 02:19:35 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:35 --> Input Class Initialized
INFO - 2023-05-09 02:19:35 --> Language Class Initialized
INFO - 2023-05-09 02:19:35 --> Loader Class Initialized
INFO - 2023-05-09 02:19:35 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:35 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:35 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:35 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:35 --> Total execution time: 0.0516
INFO - 2023-05-09 02:19:40 --> Config Class Initialized
INFO - 2023-05-09 02:19:40 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:40 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:40 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:40 --> URI Class Initialized
INFO - 2023-05-09 02:19:40 --> Router Class Initialized
INFO - 2023-05-09 02:19:40 --> Output Class Initialized
INFO - 2023-05-09 02:19:40 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:40 --> Input Class Initialized
INFO - 2023-05-09 02:19:40 --> Language Class Initialized
INFO - 2023-05-09 02:19:40 --> Loader Class Initialized
INFO - 2023-05-09 02:19:40 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:40 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:40 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:40 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:40 --> Total execution time: 0.0455
INFO - 2023-05-09 02:19:40 --> Config Class Initialized
INFO - 2023-05-09 02:19:40 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:40 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:40 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:40 --> URI Class Initialized
INFO - 2023-05-09 02:19:40 --> Router Class Initialized
INFO - 2023-05-09 02:19:40 --> Output Class Initialized
INFO - 2023-05-09 02:19:40 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:40 --> Input Class Initialized
INFO - 2023-05-09 02:19:40 --> Language Class Initialized
INFO - 2023-05-09 02:19:40 --> Loader Class Initialized
INFO - 2023-05-09 02:19:40 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:40 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:40 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:40 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:40 --> Total execution time: 0.0529
INFO - 2023-05-09 02:19:45 --> Config Class Initialized
INFO - 2023-05-09 02:19:45 --> Config Class Initialized
INFO - 2023-05-09 02:19:45 --> Hooks Class Initialized
INFO - 2023-05-09 02:19:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:45 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:45 --> URI Class Initialized
DEBUG - 2023-05-09 02:19:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:45 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:45 --> Router Class Initialized
INFO - 2023-05-09 02:19:45 --> Output Class Initialized
INFO - 2023-05-09 02:19:45 --> URI Class Initialized
INFO - 2023-05-09 02:19:45 --> Security Class Initialized
INFO - 2023-05-09 02:19:45 --> Router Class Initialized
DEBUG - 2023-05-09 02:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:45 --> Output Class Initialized
INFO - 2023-05-09 02:19:45 --> Input Class Initialized
INFO - 2023-05-09 02:19:45 --> Language Class Initialized
INFO - 2023-05-09 02:19:45 --> Security Class Initialized
INFO - 2023-05-09 02:19:45 --> Loader Class Initialized
DEBUG - 2023-05-09 02:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:45 --> Input Class Initialized
INFO - 2023-05-09 02:19:45 --> Controller Class Initialized
INFO - 2023-05-09 02:19:45 --> Language Class Initialized
DEBUG - 2023-05-09 02:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:45 --> Loader Class Initialized
INFO - 2023-05-09 02:19:45 --> Controller Class Initialized
INFO - 2023-05-09 02:19:45 --> Database Driver Class Initialized
DEBUG - 2023-05-09 02:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:45 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:45 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:45 --> Total execution time: 0.0203
INFO - 2023-05-09 02:19:45 --> Config Class Initialized
INFO - 2023-05-09 02:19:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:45 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:45 --> URI Class Initialized
INFO - 2023-05-09 02:19:45 --> Router Class Initialized
INFO - 2023-05-09 02:19:45 --> Output Class Initialized
INFO - 2023-05-09 02:19:45 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:45 --> Input Class Initialized
INFO - 2023-05-09 02:19:45 --> Language Class Initialized
INFO - 2023-05-09 02:19:45 --> Loader Class Initialized
INFO - 2023-05-09 02:19:45 --> Controller Class Initialized
INFO - 2023-05-09 02:19:45 --> Database Driver Class Initialized
DEBUG - 2023-05-09 02:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:45 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:45 --> Model "Login_model" initialized
INFO - 2023-05-09 02:19:45 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:45 --> Total execution time: 0.0143
INFO - 2023-05-09 02:19:45 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:45 --> Total execution time: 0.0754
INFO - 2023-05-09 02:19:45 --> Config Class Initialized
INFO - 2023-05-09 02:19:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 02:19:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 02:19:45 --> Utf8 Class Initialized
INFO - 2023-05-09 02:19:45 --> URI Class Initialized
INFO - 2023-05-09 02:19:45 --> Router Class Initialized
INFO - 2023-05-09 02:19:45 --> Output Class Initialized
INFO - 2023-05-09 02:19:45 --> Security Class Initialized
DEBUG - 2023-05-09 02:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 02:19:45 --> Input Class Initialized
INFO - 2023-05-09 02:19:45 --> Language Class Initialized
INFO - 2023-05-09 02:19:45 --> Loader Class Initialized
INFO - 2023-05-09 02:19:45 --> Controller Class Initialized
DEBUG - 2023-05-09 02:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 02:19:45 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 02:19:45 --> Database Driver Class Initialized
INFO - 2023-05-09 02:19:45 --> Model "Login_model" initialized
INFO - 2023-05-09 02:19:45 --> Final output sent to browser
DEBUG - 2023-05-09 02:19:45 --> Total execution time: 0.0601
INFO - 2023-05-09 03:12:39 --> Config Class Initialized
INFO - 2023-05-09 03:12:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:39 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:39 --> URI Class Initialized
INFO - 2023-05-09 03:12:39 --> Router Class Initialized
INFO - 2023-05-09 03:12:39 --> Output Class Initialized
INFO - 2023-05-09 03:12:39 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:39 --> Input Class Initialized
INFO - 2023-05-09 03:12:39 --> Language Class Initialized
INFO - 2023-05-09 03:12:39 --> Loader Class Initialized
INFO - 2023-05-09 03:12:39 --> Controller Class Initialized
INFO - 2023-05-09 03:12:39 --> Helper loaded: form_helper
INFO - 2023-05-09 03:12:39 --> Helper loaded: url_helper
DEBUG - 2023-05-09 03:12:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:39 --> Model "Change_model" initialized
INFO - 2023-05-09 03:12:39 --> Model "Grafana_model" initialized
INFO - 2023-05-09 03:12:39 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:39 --> Total execution time: 0.0346
INFO - 2023-05-09 03:12:39 --> Config Class Initialized
INFO - 2023-05-09 03:12:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:39 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:39 --> URI Class Initialized
INFO - 2023-05-09 03:12:39 --> Router Class Initialized
INFO - 2023-05-09 03:12:39 --> Output Class Initialized
INFO - 2023-05-09 03:12:39 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:39 --> Input Class Initialized
INFO - 2023-05-09 03:12:39 --> Language Class Initialized
INFO - 2023-05-09 03:12:39 --> Loader Class Initialized
INFO - 2023-05-09 03:12:39 --> Controller Class Initialized
INFO - 2023-05-09 03:12:39 --> Helper loaded: form_helper
INFO - 2023-05-09 03:12:39 --> Helper loaded: url_helper
DEBUG - 2023-05-09 03:12:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:39 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:39 --> Total execution time: 0.0052
INFO - 2023-05-09 03:12:39 --> Config Class Initialized
INFO - 2023-05-09 03:12:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:39 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:39 --> URI Class Initialized
INFO - 2023-05-09 03:12:39 --> Router Class Initialized
INFO - 2023-05-09 03:12:39 --> Output Class Initialized
INFO - 2023-05-09 03:12:39 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:39 --> Input Class Initialized
INFO - 2023-05-09 03:12:39 --> Language Class Initialized
INFO - 2023-05-09 03:12:39 --> Loader Class Initialized
INFO - 2023-05-09 03:12:39 --> Controller Class Initialized
INFO - 2023-05-09 03:12:39 --> Helper loaded: form_helper
INFO - 2023-05-09 03:12:39 --> Helper loaded: url_helper
DEBUG - 2023-05-09 03:12:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:39 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:39 --> Model "Login_model" initialized
INFO - 2023-05-09 03:12:39 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:39 --> Total execution time: 0.0158
INFO - 2023-05-09 03:12:46 --> Config Class Initialized
INFO - 2023-05-09 03:12:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:46 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:46 --> URI Class Initialized
INFO - 2023-05-09 03:12:46 --> Router Class Initialized
INFO - 2023-05-09 03:12:46 --> Output Class Initialized
INFO - 2023-05-09 03:12:46 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:46 --> Input Class Initialized
INFO - 2023-05-09 03:12:46 --> Language Class Initialized
INFO - 2023-05-09 03:12:46 --> Loader Class Initialized
INFO - 2023-05-09 03:12:46 --> Controller Class Initialized
INFO - 2023-05-09 03:12:46 --> Helper loaded: form_helper
INFO - 2023-05-09 03:12:46 --> Helper loaded: url_helper
DEBUG - 2023-05-09 03:12:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:46 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:46 --> Total execution time: 0.0047
INFO - 2023-05-09 03:12:46 --> Config Class Initialized
INFO - 2023-05-09 03:12:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:46 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:46 --> URI Class Initialized
INFO - 2023-05-09 03:12:46 --> Router Class Initialized
INFO - 2023-05-09 03:12:46 --> Output Class Initialized
INFO - 2023-05-09 03:12:46 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:46 --> Input Class Initialized
INFO - 2023-05-09 03:12:46 --> Language Class Initialized
INFO - 2023-05-09 03:12:46 --> Loader Class Initialized
INFO - 2023-05-09 03:12:46 --> Controller Class Initialized
INFO - 2023-05-09 03:12:46 --> Helper loaded: form_helper
INFO - 2023-05-09 03:12:46 --> Helper loaded: url_helper
DEBUG - 2023-05-09 03:12:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:46 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:46 --> Model "Login_model" initialized
INFO - 2023-05-09 03:12:46 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:46 --> Total execution time: 0.0228
INFO - 2023-05-09 03:12:50 --> Config Class Initialized
INFO - 2023-05-09 03:12:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:50 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:50 --> URI Class Initialized
INFO - 2023-05-09 03:12:50 --> Router Class Initialized
INFO - 2023-05-09 03:12:50 --> Output Class Initialized
INFO - 2023-05-09 03:12:50 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:50 --> Input Class Initialized
INFO - 2023-05-09 03:12:50 --> Language Class Initialized
INFO - 2023-05-09 03:12:50 --> Loader Class Initialized
INFO - 2023-05-09 03:12:50 --> Controller Class Initialized
INFO - 2023-05-09 03:12:50 --> Helper loaded: form_helper
INFO - 2023-05-09 03:12:50 --> Helper loaded: url_helper
DEBUG - 2023-05-09 03:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:50 --> Model "Change_model" initialized
INFO - 2023-05-09 03:12:50 --> Model "Grafana_model" initialized
INFO - 2023-05-09 03:12:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:50 --> Total execution time: 0.0642
INFO - 2023-05-09 03:12:50 --> Config Class Initialized
INFO - 2023-05-09 03:12:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:50 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:50 --> URI Class Initialized
INFO - 2023-05-09 03:12:50 --> Router Class Initialized
INFO - 2023-05-09 03:12:50 --> Output Class Initialized
INFO - 2023-05-09 03:12:50 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:50 --> Input Class Initialized
INFO - 2023-05-09 03:12:50 --> Language Class Initialized
INFO - 2023-05-09 03:12:50 --> Loader Class Initialized
INFO - 2023-05-09 03:12:50 --> Controller Class Initialized
INFO - 2023-05-09 03:12:50 --> Helper loaded: form_helper
INFO - 2023-05-09 03:12:50 --> Helper loaded: url_helper
DEBUG - 2023-05-09 03:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:50 --> Total execution time: 0.0422
INFO - 2023-05-09 03:12:50 --> Config Class Initialized
INFO - 2023-05-09 03:12:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:50 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:50 --> URI Class Initialized
INFO - 2023-05-09 03:12:50 --> Router Class Initialized
INFO - 2023-05-09 03:12:50 --> Output Class Initialized
INFO - 2023-05-09 03:12:50 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:50 --> Input Class Initialized
INFO - 2023-05-09 03:12:50 --> Language Class Initialized
INFO - 2023-05-09 03:12:50 --> Loader Class Initialized
INFO - 2023-05-09 03:12:50 --> Controller Class Initialized
INFO - 2023-05-09 03:12:50 --> Helper loaded: form_helper
INFO - 2023-05-09 03:12:50 --> Helper loaded: url_helper
DEBUG - 2023-05-09 03:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:50 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:50 --> Model "Login_model" initialized
INFO - 2023-05-09 03:12:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:50 --> Total execution time: 0.0145
INFO - 2023-05-09 03:12:50 --> Config Class Initialized
INFO - 2023-05-09 03:12:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:50 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:50 --> URI Class Initialized
INFO - 2023-05-09 03:12:50 --> Router Class Initialized
INFO - 2023-05-09 03:12:50 --> Output Class Initialized
INFO - 2023-05-09 03:12:50 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:50 --> Input Class Initialized
INFO - 2023-05-09 03:12:50 --> Language Class Initialized
INFO - 2023-05-09 03:12:50 --> Loader Class Initialized
INFO - 2023-05-09 03:12:50 --> Controller Class Initialized
DEBUG - 2023-05-09 03:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:50 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:50 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:12:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:50 --> Total execution time: 0.0581
INFO - 2023-05-09 03:12:50 --> Config Class Initialized
INFO - 2023-05-09 03:12:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:50 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:50 --> URI Class Initialized
INFO - 2023-05-09 03:12:50 --> Router Class Initialized
INFO - 2023-05-09 03:12:50 --> Output Class Initialized
INFO - 2023-05-09 03:12:50 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:50 --> Input Class Initialized
INFO - 2023-05-09 03:12:50 --> Language Class Initialized
INFO - 2023-05-09 03:12:50 --> Loader Class Initialized
INFO - 2023-05-09 03:12:50 --> Controller Class Initialized
DEBUG - 2023-05-09 03:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:50 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:50 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:12:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:50 --> Total execution time: 0.0122
INFO - 2023-05-09 03:12:51 --> Config Class Initialized
INFO - 2023-05-09 03:12:51 --> Config Class Initialized
INFO - 2023-05-09 03:12:51 --> Hooks Class Initialized
INFO - 2023-05-09 03:12:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:12:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:51 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:51 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:51 --> URI Class Initialized
INFO - 2023-05-09 03:12:51 --> URI Class Initialized
INFO - 2023-05-09 03:12:51 --> Router Class Initialized
INFO - 2023-05-09 03:12:51 --> Router Class Initialized
INFO - 2023-05-09 03:12:51 --> Output Class Initialized
INFO - 2023-05-09 03:12:51 --> Output Class Initialized
INFO - 2023-05-09 03:12:51 --> Security Class Initialized
INFO - 2023-05-09 03:12:51 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:51 --> Input Class Initialized
INFO - 2023-05-09 03:12:51 --> Language Class Initialized
INFO - 2023-05-09 03:12:51 --> Input Class Initialized
INFO - 2023-05-09 03:12:51 --> Language Class Initialized
INFO - 2023-05-09 03:12:51 --> Loader Class Initialized
INFO - 2023-05-09 03:12:51 --> Loader Class Initialized
INFO - 2023-05-09 03:12:51 --> Controller Class Initialized
INFO - 2023-05-09 03:12:51 --> Controller Class Initialized
DEBUG - 2023-05-09 03:12:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:12:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:51 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:51 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:12:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:12:51 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:51 --> Total execution time: 0.0595
INFO - 2023-05-09 03:12:51 --> Final output sent to browser
INFO - 2023-05-09 03:12:51 --> Config Class Initialized
INFO - 2023-05-09 03:12:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:51 --> Total execution time: 0.0620
DEBUG - 2023-05-09 03:12:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:51 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:51 --> URI Class Initialized
INFO - 2023-05-09 03:12:51 --> Router Class Initialized
INFO - 2023-05-09 03:12:51 --> Output Class Initialized
INFO - 2023-05-09 03:12:51 --> Config Class Initialized
INFO - 2023-05-09 03:12:51 --> Security Class Initialized
INFO - 2023-05-09 03:12:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:51 --> Input Class Initialized
DEBUG - 2023-05-09 03:12:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:12:51 --> Language Class Initialized
INFO - 2023-05-09 03:12:51 --> Utf8 Class Initialized
INFO - 2023-05-09 03:12:51 --> Loader Class Initialized
INFO - 2023-05-09 03:12:51 --> URI Class Initialized
INFO - 2023-05-09 03:12:51 --> Controller Class Initialized
DEBUG - 2023-05-09 03:12:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:51 --> Router Class Initialized
INFO - 2023-05-09 03:12:51 --> Output Class Initialized
INFO - 2023-05-09 03:12:51 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:51 --> Security Class Initialized
DEBUG - 2023-05-09 03:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:12:51 --> Input Class Initialized
INFO - 2023-05-09 03:12:51 --> Language Class Initialized
INFO - 2023-05-09 03:12:51 --> Loader Class Initialized
INFO - 2023-05-09 03:12:51 --> Controller Class Initialized
DEBUG - 2023-05-09 03:12:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:12:51 --> Database Driver Class Initialized
INFO - 2023-05-09 03:12:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:12:51 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:51 --> Total execution time: 0.0873
INFO - 2023-05-09 03:12:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:12:51 --> Final output sent to browser
DEBUG - 2023-05-09 03:12:51 --> Total execution time: 0.1129
INFO - 2023-05-09 03:13:14 --> Config Class Initialized
INFO - 2023-05-09 03:13:14 --> Config Class Initialized
INFO - 2023-05-09 03:13:14 --> Hooks Class Initialized
INFO - 2023-05-09 03:13:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:13:14 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:13:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:13:14 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:14 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:14 --> URI Class Initialized
INFO - 2023-05-09 03:13:14 --> URI Class Initialized
INFO - 2023-05-09 03:13:14 --> Router Class Initialized
INFO - 2023-05-09 03:13:14 --> Router Class Initialized
INFO - 2023-05-09 03:13:14 --> Output Class Initialized
INFO - 2023-05-09 03:13:14 --> Output Class Initialized
INFO - 2023-05-09 03:13:14 --> Security Class Initialized
INFO - 2023-05-09 03:13:14 --> Security Class Initialized
DEBUG - 2023-05-09 03:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:14 --> Input Class Initialized
INFO - 2023-05-09 03:13:14 --> Input Class Initialized
INFO - 2023-05-09 03:13:14 --> Language Class Initialized
INFO - 2023-05-09 03:13:14 --> Language Class Initialized
INFO - 2023-05-09 03:13:14 --> Loader Class Initialized
INFO - 2023-05-09 03:13:14 --> Loader Class Initialized
INFO - 2023-05-09 03:13:14 --> Controller Class Initialized
INFO - 2023-05-09 03:13:14 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:14 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:14 --> Total execution time: 0.0061
INFO - 2023-05-09 03:13:14 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:14 --> Config Class Initialized
INFO - 2023-05-09 03:13:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:13:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:13:14 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:14 --> URI Class Initialized
INFO - 2023-05-09 03:13:14 --> Router Class Initialized
INFO - 2023-05-09 03:13:14 --> Output Class Initialized
INFO - 2023-05-09 03:13:14 --> Security Class Initialized
DEBUG - 2023-05-09 03:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:14 --> Input Class Initialized
INFO - 2023-05-09 03:13:14 --> Language Class Initialized
INFO - 2023-05-09 03:13:14 --> Loader Class Initialized
INFO - 2023-05-09 03:13:14 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:14 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:14 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:14 --> Total execution time: 0.0569
INFO - 2023-05-09 03:13:14 --> Config Class Initialized
INFO - 2023-05-09 03:13:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:13:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:13:14 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:14 --> URI Class Initialized
INFO - 2023-05-09 03:13:14 --> Router Class Initialized
INFO - 2023-05-09 03:13:14 --> Output Class Initialized
INFO - 2023-05-09 03:13:14 --> Security Class Initialized
DEBUG - 2023-05-09 03:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:14 --> Input Class Initialized
INFO - 2023-05-09 03:13:14 --> Language Class Initialized
INFO - 2023-05-09 03:13:14 --> Loader Class Initialized
INFO - 2023-05-09 03:13:14 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:14 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:14 --> Model "Login_model" initialized
INFO - 2023-05-09 03:13:14 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:14 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:14 --> Total execution time: 0.0150
INFO - 2023-05-09 03:13:14 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:14 --> Total execution time: 0.0648
INFO - 2023-05-09 03:13:55 --> Config Class Initialized
INFO - 2023-05-09 03:13:55 --> Config Class Initialized
INFO - 2023-05-09 03:13:55 --> Hooks Class Initialized
INFO - 2023-05-09 03:13:55 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:13:55 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:13:55 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:55 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:55 --> URI Class Initialized
INFO - 2023-05-09 03:13:55 --> URI Class Initialized
INFO - 2023-05-09 03:13:55 --> Router Class Initialized
INFO - 2023-05-09 03:13:55 --> Router Class Initialized
INFO - 2023-05-09 03:13:55 --> Output Class Initialized
INFO - 2023-05-09 03:13:55 --> Output Class Initialized
INFO - 2023-05-09 03:13:55 --> Security Class Initialized
INFO - 2023-05-09 03:13:55 --> Security Class Initialized
DEBUG - 2023-05-09 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:55 --> Input Class Initialized
INFO - 2023-05-09 03:13:55 --> Input Class Initialized
INFO - 2023-05-09 03:13:55 --> Language Class Initialized
INFO - 2023-05-09 03:13:55 --> Language Class Initialized
INFO - 2023-05-09 03:13:55 --> Loader Class Initialized
INFO - 2023-05-09 03:13:55 --> Loader Class Initialized
INFO - 2023-05-09 03:13:55 --> Controller Class Initialized
INFO - 2023-05-09 03:13:55 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:55 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:55 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:55 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:55 --> Total execution time: 0.0273
INFO - 2023-05-09 03:13:55 --> Config Class Initialized
INFO - 2023-05-09 03:13:55 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:13:55 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:13:55 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:55 --> URI Class Initialized
INFO - 2023-05-09 03:13:55 --> Router Class Initialized
INFO - 2023-05-09 03:13:55 --> Output Class Initialized
INFO - 2023-05-09 03:13:55 --> Security Class Initialized
DEBUG - 2023-05-09 03:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:55 --> Input Class Initialized
INFO - 2023-05-09 03:13:55 --> Language Class Initialized
INFO - 2023-05-09 03:13:55 --> Loader Class Initialized
INFO - 2023-05-09 03:13:55 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:55 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:55 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:55 --> Total execution time: 0.0328
INFO - 2023-05-09 03:13:55 --> Config Class Initialized
INFO - 2023-05-09 03:13:55 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:13:55 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:13:55 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:55 --> URI Class Initialized
INFO - 2023-05-09 03:13:55 --> Router Class Initialized
INFO - 2023-05-09 03:13:55 --> Output Class Initialized
INFO - 2023-05-09 03:13:55 --> Security Class Initialized
DEBUG - 2023-05-09 03:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:55 --> Input Class Initialized
INFO - 2023-05-09 03:13:55 --> Language Class Initialized
INFO - 2023-05-09 03:13:55 --> Loader Class Initialized
INFO - 2023-05-09 03:13:55 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:55 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:55 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:55 --> Total execution time: 0.0132
INFO - 2023-05-09 03:13:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:55 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:55 --> Total execution time: 0.0579
INFO - 2023-05-09 03:13:56 --> Config Class Initialized
INFO - 2023-05-09 03:13:56 --> Hooks Class Initialized
INFO - 2023-05-09 03:13:56 --> Config Class Initialized
INFO - 2023-05-09 03:13:56 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:13:56 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:13:56 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:13:56 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:56 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:56 --> URI Class Initialized
INFO - 2023-05-09 03:13:56 --> URI Class Initialized
INFO - 2023-05-09 03:13:56 --> Router Class Initialized
INFO - 2023-05-09 03:13:56 --> Router Class Initialized
INFO - 2023-05-09 03:13:56 --> Output Class Initialized
INFO - 2023-05-09 03:13:56 --> Output Class Initialized
INFO - 2023-05-09 03:13:56 --> Security Class Initialized
INFO - 2023-05-09 03:13:56 --> Security Class Initialized
DEBUG - 2023-05-09 03:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:56 --> Input Class Initialized
DEBUG - 2023-05-09 03:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:56 --> Language Class Initialized
INFO - 2023-05-09 03:13:56 --> Input Class Initialized
INFO - 2023-05-09 03:13:56 --> Language Class Initialized
INFO - 2023-05-09 03:13:56 --> Loader Class Initialized
INFO - 2023-05-09 03:13:56 --> Loader Class Initialized
INFO - 2023-05-09 03:13:56 --> Controller Class Initialized
INFO - 2023-05-09 03:13:56 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:13:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:56 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:56 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:56 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:56 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:56 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:56 --> Total execution time: 0.0174
INFO - 2023-05-09 03:13:56 --> Final output sent to browser
INFO - 2023-05-09 03:13:56 --> Config Class Initialized
DEBUG - 2023-05-09 03:13:57 --> Total execution time: 0.0220
INFO - 2023-05-09 03:13:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:13:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:13:57 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:57 --> URI Class Initialized
INFO - 2023-05-09 03:13:57 --> Router Class Initialized
INFO - 2023-05-09 03:13:57 --> Output Class Initialized
INFO - 2023-05-09 03:13:57 --> Config Class Initialized
INFO - 2023-05-09 03:13:57 --> Hooks Class Initialized
INFO - 2023-05-09 03:13:57 --> Security Class Initialized
DEBUG - 2023-05-09 03:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:13:57 --> Utf8 Class Initialized
INFO - 2023-05-09 03:13:57 --> Input Class Initialized
INFO - 2023-05-09 03:13:57 --> URI Class Initialized
INFO - 2023-05-09 03:13:57 --> Language Class Initialized
INFO - 2023-05-09 03:13:57 --> Router Class Initialized
INFO - 2023-05-09 03:13:57 --> Output Class Initialized
INFO - 2023-05-09 03:13:57 --> Loader Class Initialized
INFO - 2023-05-09 03:13:57 --> Security Class Initialized
INFO - 2023-05-09 03:13:57 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:13:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:57 --> Input Class Initialized
INFO - 2023-05-09 03:13:57 --> Language Class Initialized
INFO - 2023-05-09 03:13:57 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:57 --> Loader Class Initialized
INFO - 2023-05-09 03:13:57 --> Controller Class Initialized
DEBUG - 2023-05-09 03:13:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:13:57 --> Database Driver Class Initialized
INFO - 2023-05-09 03:13:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:13:57 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:57 --> Total execution time: 0.0909
INFO - 2023-05-09 03:13:57 --> Final output sent to browser
DEBUG - 2023-05-09 03:13:57 --> Total execution time: 0.0509
INFO - 2023-05-09 03:14:06 --> Config Class Initialized
INFO - 2023-05-09 03:14:06 --> Config Class Initialized
INFO - 2023-05-09 03:14:06 --> Hooks Class Initialized
INFO - 2023-05-09 03:14:06 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:06 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:06 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:06 --> URI Class Initialized
INFO - 2023-05-09 03:14:06 --> URI Class Initialized
INFO - 2023-05-09 03:14:06 --> Router Class Initialized
INFO - 2023-05-09 03:14:06 --> Router Class Initialized
INFO - 2023-05-09 03:14:06 --> Output Class Initialized
INFO - 2023-05-09 03:14:06 --> Output Class Initialized
INFO - 2023-05-09 03:14:06 --> Security Class Initialized
INFO - 2023-05-09 03:14:06 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:06 --> Input Class Initialized
INFO - 2023-05-09 03:14:06 --> Input Class Initialized
INFO - 2023-05-09 03:14:06 --> Language Class Initialized
INFO - 2023-05-09 03:14:06 --> Language Class Initialized
INFO - 2023-05-09 03:14:06 --> Loader Class Initialized
INFO - 2023-05-09 03:14:06 --> Loader Class Initialized
INFO - 2023-05-09 03:14:06 --> Controller Class Initialized
INFO - 2023-05-09 03:14:06 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:14:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:06 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:06 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:06 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:06 --> Total execution time: 0.0141
INFO - 2023-05-09 03:14:06 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:06 --> Total execution time: 0.0155
INFO - 2023-05-09 03:14:06 --> Config Class Initialized
INFO - 2023-05-09 03:14:06 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:06 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:06 --> Config Class Initialized
INFO - 2023-05-09 03:14:06 --> URI Class Initialized
INFO - 2023-05-09 03:14:06 --> Hooks Class Initialized
INFO - 2023-05-09 03:14:06 --> Router Class Initialized
DEBUG - 2023-05-09 03:14:06 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:06 --> Output Class Initialized
INFO - 2023-05-09 03:14:06 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:06 --> Security Class Initialized
INFO - 2023-05-09 03:14:06 --> URI Class Initialized
DEBUG - 2023-05-09 03:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:06 --> Input Class Initialized
INFO - 2023-05-09 03:14:06 --> Router Class Initialized
INFO - 2023-05-09 03:14:06 --> Language Class Initialized
INFO - 2023-05-09 03:14:06 --> Output Class Initialized
INFO - 2023-05-09 03:14:06 --> Loader Class Initialized
INFO - 2023-05-09 03:14:06 --> Security Class Initialized
INFO - 2023-05-09 03:14:06 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:14:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:06 --> Input Class Initialized
INFO - 2023-05-09 03:14:06 --> Language Class Initialized
INFO - 2023-05-09 03:14:06 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:06 --> Loader Class Initialized
INFO - 2023-05-09 03:14:06 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:06 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:06 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:06 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:06 --> Total execution time: 0.0153
INFO - 2023-05-09 03:14:06 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:06 --> Total execution time: 0.0167
INFO - 2023-05-09 03:14:07 --> Config Class Initialized
INFO - 2023-05-09 03:14:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:07 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:07 --> URI Class Initialized
INFO - 2023-05-09 03:14:07 --> Router Class Initialized
INFO - 2023-05-09 03:14:07 --> Output Class Initialized
INFO - 2023-05-09 03:14:07 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:07 --> Input Class Initialized
INFO - 2023-05-09 03:14:07 --> Language Class Initialized
INFO - 2023-05-09 03:14:07 --> Loader Class Initialized
INFO - 2023-05-09 03:14:07 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:07 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:07 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:07 --> Total execution time: 0.0116
INFO - 2023-05-09 03:14:07 --> Config Class Initialized
INFO - 2023-05-09 03:14:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:07 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:07 --> URI Class Initialized
INFO - 2023-05-09 03:14:07 --> Router Class Initialized
INFO - 2023-05-09 03:14:07 --> Output Class Initialized
INFO - 2023-05-09 03:14:07 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:07 --> Input Class Initialized
INFO - 2023-05-09 03:14:07 --> Language Class Initialized
INFO - 2023-05-09 03:14:07 --> Loader Class Initialized
INFO - 2023-05-09 03:14:07 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:07 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:07 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:07 --> Total execution time: 0.0515
INFO - 2023-05-09 03:14:07 --> Config Class Initialized
INFO - 2023-05-09 03:14:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:07 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:07 --> URI Class Initialized
INFO - 2023-05-09 03:14:07 --> Router Class Initialized
INFO - 2023-05-09 03:14:07 --> Output Class Initialized
INFO - 2023-05-09 03:14:07 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:07 --> Input Class Initialized
INFO - 2023-05-09 03:14:07 --> Language Class Initialized
INFO - 2023-05-09 03:14:07 --> Loader Class Initialized
INFO - 2023-05-09 03:14:07 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:07 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:07 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:07 --> Total execution time: 0.0481
INFO - 2023-05-09 03:14:07 --> Config Class Initialized
INFO - 2023-05-09 03:14:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:08 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:08 --> URI Class Initialized
INFO - 2023-05-09 03:14:08 --> Router Class Initialized
INFO - 2023-05-09 03:14:08 --> Output Class Initialized
INFO - 2023-05-09 03:14:08 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:08 --> Input Class Initialized
INFO - 2023-05-09 03:14:08 --> Language Class Initialized
INFO - 2023-05-09 03:14:08 --> Loader Class Initialized
INFO - 2023-05-09 03:14:08 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:08 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:08 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:08 --> Total execution time: 0.0551
INFO - 2023-05-09 03:14:34 --> Config Class Initialized
INFO - 2023-05-09 03:14:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:34 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:34 --> URI Class Initialized
INFO - 2023-05-09 03:14:34 --> Router Class Initialized
INFO - 2023-05-09 03:14:34 --> Output Class Initialized
INFO - 2023-05-09 03:14:34 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:34 --> Input Class Initialized
INFO - 2023-05-09 03:14:34 --> Language Class Initialized
INFO - 2023-05-09 03:14:34 --> Loader Class Initialized
INFO - 2023-05-09 03:14:34 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:34 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:34 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:34 --> Total execution time: 0.0146
INFO - 2023-05-09 03:14:34 --> Config Class Initialized
INFO - 2023-05-09 03:14:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:34 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:34 --> URI Class Initialized
INFO - 2023-05-09 03:14:34 --> Router Class Initialized
INFO - 2023-05-09 03:14:34 --> Output Class Initialized
INFO - 2023-05-09 03:14:34 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:34 --> Input Class Initialized
INFO - 2023-05-09 03:14:34 --> Language Class Initialized
INFO - 2023-05-09 03:14:34 --> Loader Class Initialized
INFO - 2023-05-09 03:14:34 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:34 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:34 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:34 --> Model "Login_model" initialized
INFO - 2023-05-09 03:14:34 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:34 --> Total execution time: 0.0342
INFO - 2023-05-09 03:14:34 --> Config Class Initialized
INFO - 2023-05-09 03:14:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:34 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:34 --> URI Class Initialized
INFO - 2023-05-09 03:14:34 --> Router Class Initialized
INFO - 2023-05-09 03:14:34 --> Output Class Initialized
INFO - 2023-05-09 03:14:34 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:34 --> Input Class Initialized
INFO - 2023-05-09 03:14:34 --> Language Class Initialized
INFO - 2023-05-09 03:14:34 --> Loader Class Initialized
INFO - 2023-05-09 03:14:34 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:34 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:34 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:34 --> Total execution time: 0.0126
INFO - 2023-05-09 03:14:34 --> Config Class Initialized
INFO - 2023-05-09 03:14:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:34 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:34 --> URI Class Initialized
INFO - 2023-05-09 03:14:34 --> Router Class Initialized
INFO - 2023-05-09 03:14:34 --> Output Class Initialized
INFO - 2023-05-09 03:14:34 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:34 --> Input Class Initialized
INFO - 2023-05-09 03:14:34 --> Language Class Initialized
INFO - 2023-05-09 03:14:34 --> Loader Class Initialized
INFO - 2023-05-09 03:14:34 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:34 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:34 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:34 --> Total execution time: 0.2037
INFO - 2023-05-09 03:14:39 --> Config Class Initialized
INFO - 2023-05-09 03:14:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:39 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:39 --> URI Class Initialized
INFO - 2023-05-09 03:14:39 --> Router Class Initialized
INFO - 2023-05-09 03:14:39 --> Output Class Initialized
INFO - 2023-05-09 03:14:39 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:39 --> Input Class Initialized
INFO - 2023-05-09 03:14:39 --> Language Class Initialized
INFO - 2023-05-09 03:14:39 --> Loader Class Initialized
INFO - 2023-05-09 03:14:39 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:39 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:39 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:39 --> Total execution time: 0.0431
INFO - 2023-05-09 03:14:39 --> Config Class Initialized
INFO - 2023-05-09 03:14:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:39 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:39 --> URI Class Initialized
INFO - 2023-05-09 03:14:39 --> Router Class Initialized
INFO - 2023-05-09 03:14:39 --> Output Class Initialized
INFO - 2023-05-09 03:14:39 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:39 --> Input Class Initialized
INFO - 2023-05-09 03:14:39 --> Language Class Initialized
INFO - 2023-05-09 03:14:39 --> Loader Class Initialized
INFO - 2023-05-09 03:14:39 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:39 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:39 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:39 --> Total execution time: 0.0146
INFO - 2023-05-09 03:14:44 --> Config Class Initialized
INFO - 2023-05-09 03:14:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:44 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:44 --> URI Class Initialized
INFO - 2023-05-09 03:14:44 --> Router Class Initialized
INFO - 2023-05-09 03:14:44 --> Output Class Initialized
INFO - 2023-05-09 03:14:44 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:44 --> Input Class Initialized
INFO - 2023-05-09 03:14:44 --> Language Class Initialized
INFO - 2023-05-09 03:14:44 --> Loader Class Initialized
INFO - 2023-05-09 03:14:44 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:44 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:44 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:44 --> Total execution time: 0.0133
INFO - 2023-05-09 03:14:44 --> Config Class Initialized
INFO - 2023-05-09 03:14:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:44 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:44 --> URI Class Initialized
INFO - 2023-05-09 03:14:44 --> Router Class Initialized
INFO - 2023-05-09 03:14:44 --> Output Class Initialized
INFO - 2023-05-09 03:14:44 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:44 --> Input Class Initialized
INFO - 2023-05-09 03:14:44 --> Language Class Initialized
INFO - 2023-05-09 03:14:44 --> Loader Class Initialized
INFO - 2023-05-09 03:14:44 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:44 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:44 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:44 --> Total execution time: 0.0154
INFO - 2023-05-09 03:14:49 --> Config Class Initialized
INFO - 2023-05-09 03:14:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:49 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:49 --> URI Class Initialized
INFO - 2023-05-09 03:14:49 --> Router Class Initialized
INFO - 2023-05-09 03:14:49 --> Output Class Initialized
INFO - 2023-05-09 03:14:49 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:49 --> Input Class Initialized
INFO - 2023-05-09 03:14:49 --> Language Class Initialized
INFO - 2023-05-09 03:14:49 --> Loader Class Initialized
INFO - 2023-05-09 03:14:49 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:49 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:49 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:49 --> Total execution time: 0.0124
INFO - 2023-05-09 03:14:49 --> Config Class Initialized
INFO - 2023-05-09 03:14:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:49 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:49 --> URI Class Initialized
INFO - 2023-05-09 03:14:49 --> Router Class Initialized
INFO - 2023-05-09 03:14:49 --> Output Class Initialized
INFO - 2023-05-09 03:14:49 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:49 --> Input Class Initialized
INFO - 2023-05-09 03:14:49 --> Language Class Initialized
INFO - 2023-05-09 03:14:49 --> Loader Class Initialized
INFO - 2023-05-09 03:14:49 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:49 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:49 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:49 --> Total execution time: 0.0157
INFO - 2023-05-09 03:14:54 --> Config Class Initialized
INFO - 2023-05-09 03:14:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:54 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:54 --> URI Class Initialized
INFO - 2023-05-09 03:14:54 --> Router Class Initialized
INFO - 2023-05-09 03:14:54 --> Output Class Initialized
INFO - 2023-05-09 03:14:54 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:54 --> Input Class Initialized
INFO - 2023-05-09 03:14:54 --> Language Class Initialized
INFO - 2023-05-09 03:14:54 --> Loader Class Initialized
INFO - 2023-05-09 03:14:54 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:54 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:54 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:54 --> Total execution time: 0.0124
INFO - 2023-05-09 03:14:54 --> Config Class Initialized
INFO - 2023-05-09 03:14:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:54 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:54 --> URI Class Initialized
INFO - 2023-05-09 03:14:54 --> Router Class Initialized
INFO - 2023-05-09 03:14:54 --> Output Class Initialized
INFO - 2023-05-09 03:14:54 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:54 --> Input Class Initialized
INFO - 2023-05-09 03:14:54 --> Language Class Initialized
INFO - 2023-05-09 03:14:54 --> Loader Class Initialized
INFO - 2023-05-09 03:14:54 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:54 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:54 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:54 --> Total execution time: 0.0142
INFO - 2023-05-09 03:14:57 --> Config Class Initialized
INFO - 2023-05-09 03:14:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:57 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:57 --> URI Class Initialized
INFO - 2023-05-09 03:14:57 --> Router Class Initialized
INFO - 2023-05-09 03:14:57 --> Output Class Initialized
INFO - 2023-05-09 03:14:57 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:57 --> Input Class Initialized
INFO - 2023-05-09 03:14:57 --> Language Class Initialized
INFO - 2023-05-09 03:14:57 --> Loader Class Initialized
INFO - 2023-05-09 03:14:57 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:57 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:57 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:57 --> Model "Login_model" initialized
INFO - 2023-05-09 03:14:57 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:57 --> Total execution time: 0.0450
INFO - 2023-05-09 03:14:57 --> Config Class Initialized
INFO - 2023-05-09 03:14:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:14:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:14:57 --> Utf8 Class Initialized
INFO - 2023-05-09 03:14:57 --> URI Class Initialized
INFO - 2023-05-09 03:14:57 --> Router Class Initialized
INFO - 2023-05-09 03:14:57 --> Output Class Initialized
INFO - 2023-05-09 03:14:57 --> Security Class Initialized
DEBUG - 2023-05-09 03:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:14:57 --> Input Class Initialized
INFO - 2023-05-09 03:14:57 --> Language Class Initialized
INFO - 2023-05-09 03:14:57 --> Loader Class Initialized
INFO - 2023-05-09 03:14:57 --> Controller Class Initialized
DEBUG - 2023-05-09 03:14:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:14:57 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:14:57 --> Database Driver Class Initialized
INFO - 2023-05-09 03:14:57 --> Model "Login_model" initialized
INFO - 2023-05-09 03:14:57 --> Final output sent to browser
DEBUG - 2023-05-09 03:14:57 --> Total execution time: 0.0395
INFO - 2023-05-09 03:15:38 --> Config Class Initialized
INFO - 2023-05-09 03:15:38 --> Config Class Initialized
INFO - 2023-05-09 03:15:38 --> Hooks Class Initialized
INFO - 2023-05-09 03:15:38 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:15:38 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:15:38 --> Utf8 Class Initialized
DEBUG - 2023-05-09 03:15:38 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:15:38 --> URI Class Initialized
INFO - 2023-05-09 03:15:38 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:38 --> URI Class Initialized
INFO - 2023-05-09 03:15:38 --> Router Class Initialized
INFO - 2023-05-09 03:15:38 --> Router Class Initialized
INFO - 2023-05-09 03:15:38 --> Output Class Initialized
INFO - 2023-05-09 03:15:38 --> Output Class Initialized
INFO - 2023-05-09 03:15:38 --> Security Class Initialized
INFO - 2023-05-09 03:15:38 --> Security Class Initialized
DEBUG - 2023-05-09 03:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:15:38 --> Input Class Initialized
DEBUG - 2023-05-09 03:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:15:38 --> Input Class Initialized
INFO - 2023-05-09 03:15:38 --> Language Class Initialized
INFO - 2023-05-09 03:15:38 --> Language Class Initialized
INFO - 2023-05-09 03:15:38 --> Loader Class Initialized
INFO - 2023-05-09 03:15:38 --> Loader Class Initialized
INFO - 2023-05-09 03:15:38 --> Controller Class Initialized
INFO - 2023-05-09 03:15:38 --> Controller Class Initialized
DEBUG - 2023-05-09 03:15:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:15:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:15:38 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:38 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:38 --> Final output sent to browser
DEBUG - 2023-05-09 03:15:38 --> Total execution time: 0.1037
INFO - 2023-05-09 03:15:38 --> Config Class Initialized
INFO - 2023-05-09 03:15:38 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:15:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:15:39 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:39 --> URI Class Initialized
INFO - 2023-05-09 03:15:39 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:39 --> Router Class Initialized
INFO - 2023-05-09 03:15:39 --> Output Class Initialized
INFO - 2023-05-09 03:15:39 --> Security Class Initialized
DEBUG - 2023-05-09 03:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:15:39 --> Input Class Initialized
INFO - 2023-05-09 03:15:39 --> Language Class Initialized
INFO - 2023-05-09 03:15:39 --> Loader Class Initialized
INFO - 2023-05-09 03:15:39 --> Controller Class Initialized
DEBUG - 2023-05-09 03:15:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:15:39 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:39 --> Model "Login_model" initialized
INFO - 2023-05-09 03:15:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:39 --> Final output sent to browser
DEBUG - 2023-05-09 03:15:39 --> Total execution time: 0.0162
INFO - 2023-05-09 03:15:39 --> Final output sent to browser
DEBUG - 2023-05-09 03:15:39 --> Total execution time: 0.1366
INFO - 2023-05-09 03:15:39 --> Config Class Initialized
INFO - 2023-05-09 03:15:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:15:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:15:39 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:39 --> URI Class Initialized
INFO - 2023-05-09 03:15:39 --> Router Class Initialized
INFO - 2023-05-09 03:15:39 --> Output Class Initialized
INFO - 2023-05-09 03:15:39 --> Security Class Initialized
DEBUG - 2023-05-09 03:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:15:39 --> Input Class Initialized
INFO - 2023-05-09 03:15:39 --> Language Class Initialized
INFO - 2023-05-09 03:15:39 --> Loader Class Initialized
INFO - 2023-05-09 03:15:39 --> Controller Class Initialized
DEBUG - 2023-05-09 03:15:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:15:39 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:39 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:39 --> Model "Login_model" initialized
INFO - 2023-05-09 03:15:39 --> Final output sent to browser
DEBUG - 2023-05-09 03:15:39 --> Total execution time: 0.0410
INFO - 2023-05-09 03:15:48 --> Config Class Initialized
INFO - 2023-05-09 03:15:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:15:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:15:48 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:48 --> URI Class Initialized
INFO - 2023-05-09 03:15:48 --> Router Class Initialized
INFO - 2023-05-09 03:15:48 --> Output Class Initialized
INFO - 2023-05-09 03:15:48 --> Security Class Initialized
DEBUG - 2023-05-09 03:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:15:48 --> Input Class Initialized
INFO - 2023-05-09 03:15:48 --> Language Class Initialized
INFO - 2023-05-09 03:15:48 --> Loader Class Initialized
INFO - 2023-05-09 03:15:48 --> Controller Class Initialized
DEBUG - 2023-05-09 03:15:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:15:48 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:48 --> Config Class Initialized
INFO - 2023-05-09 03:15:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:15:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:15:48 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:48 --> URI Class Initialized
INFO - 2023-05-09 03:15:48 --> Router Class Initialized
INFO - 2023-05-09 03:15:48 --> Output Class Initialized
INFO - 2023-05-09 03:15:48 --> Security Class Initialized
DEBUG - 2023-05-09 03:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:15:48 --> Input Class Initialized
INFO - 2023-05-09 03:15:48 --> Language Class Initialized
INFO - 2023-05-09 03:15:48 --> Loader Class Initialized
INFO - 2023-05-09 03:15:48 --> Controller Class Initialized
DEBUG - 2023-05-09 03:15:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:15:48 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:49 --> Config Class Initialized
INFO - 2023-05-09 03:15:49 --> Config Class Initialized
INFO - 2023-05-09 03:15:49 --> Hooks Class Initialized
INFO - 2023-05-09 03:15:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:15:49 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:15:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:15:49 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:49 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:49 --> URI Class Initialized
INFO - 2023-05-09 03:15:49 --> URI Class Initialized
INFO - 2023-05-09 03:15:49 --> Router Class Initialized
INFO - 2023-05-09 03:15:49 --> Router Class Initialized
INFO - 2023-05-09 03:15:49 --> Output Class Initialized
INFO - 2023-05-09 03:15:49 --> Output Class Initialized
INFO - 2023-05-09 03:15:49 --> Security Class Initialized
INFO - 2023-05-09 03:15:49 --> Security Class Initialized
DEBUG - 2023-05-09 03:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:15:49 --> Input Class Initialized
INFO - 2023-05-09 03:15:49 --> Input Class Initialized
INFO - 2023-05-09 03:15:49 --> Language Class Initialized
INFO - 2023-05-09 03:15:49 --> Language Class Initialized
INFO - 2023-05-09 03:15:49 --> Loader Class Initialized
INFO - 2023-05-09 03:15:49 --> Controller Class Initialized
INFO - 2023-05-09 03:15:49 --> Loader Class Initialized
DEBUG - 2023-05-09 03:15:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:15:49 --> Controller Class Initialized
DEBUG - 2023-05-09 03:15:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:15:49 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:49 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:49 --> Final output sent to browser
DEBUG - 2023-05-09 03:15:49 --> Total execution time: 0.0170
INFO - 2023-05-09 03:15:49 --> Config Class Initialized
INFO - 2023-05-09 03:15:49 --> Config Class Initialized
INFO - 2023-05-09 03:15:49 --> Hooks Class Initialized
INFO - 2023-05-09 03:15:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:15:49 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:15:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:15:49 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:49 --> Utf8 Class Initialized
INFO - 2023-05-09 03:15:49 --> URI Class Initialized
INFO - 2023-05-09 03:15:49 --> URI Class Initialized
INFO - 2023-05-09 03:15:49 --> Router Class Initialized
INFO - 2023-05-09 03:15:49 --> Router Class Initialized
INFO - 2023-05-09 03:15:49 --> Output Class Initialized
INFO - 2023-05-09 03:15:49 --> Output Class Initialized
INFO - 2023-05-09 03:15:49 --> Security Class Initialized
INFO - 2023-05-09 03:15:49 --> Security Class Initialized
DEBUG - 2023-05-09 03:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:15:49 --> Input Class Initialized
INFO - 2023-05-09 03:15:49 --> Input Class Initialized
INFO - 2023-05-09 03:15:49 --> Language Class Initialized
INFO - 2023-05-09 03:15:49 --> Language Class Initialized
INFO - 2023-05-09 03:15:49 --> Loader Class Initialized
INFO - 2023-05-09 03:15:49 --> Loader Class Initialized
INFO - 2023-05-09 03:15:49 --> Controller Class Initialized
INFO - 2023-05-09 03:15:49 --> Controller Class Initialized
DEBUG - 2023-05-09 03:15:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:15:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:15:49 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:49 --> Database Driver Class Initialized
INFO - 2023-05-09 03:15:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:15:49 --> Final output sent to browser
DEBUG - 2023-05-09 03:15:49 --> Total execution time: 0.0575
INFO - 2023-05-09 03:16:02 --> Config Class Initialized
INFO - 2023-05-09 03:16:02 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:02 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:02 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:02 --> URI Class Initialized
INFO - 2023-05-09 03:16:02 --> Router Class Initialized
INFO - 2023-05-09 03:16:02 --> Output Class Initialized
INFO - 2023-05-09 03:16:02 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:02 --> Input Class Initialized
INFO - 2023-05-09 03:16:02 --> Language Class Initialized
INFO - 2023-05-09 03:16:02 --> Loader Class Initialized
INFO - 2023-05-09 03:16:02 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:02 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:02 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:02 --> Config Class Initialized
INFO - 2023-05-09 03:16:02 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:02 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:02 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:02 --> URI Class Initialized
INFO - 2023-05-09 03:16:02 --> Router Class Initialized
INFO - 2023-05-09 03:16:02 --> Output Class Initialized
INFO - 2023-05-09 03:16:02 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:02 --> Input Class Initialized
INFO - 2023-05-09 03:16:02 --> Language Class Initialized
INFO - 2023-05-09 03:16:02 --> Loader Class Initialized
INFO - 2023-05-09 03:16:02 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:02 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:02 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:30 --> Config Class Initialized
INFO - 2023-05-09 03:16:30 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:30 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:30 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:30 --> URI Class Initialized
INFO - 2023-05-09 03:16:30 --> Router Class Initialized
INFO - 2023-05-09 03:16:30 --> Output Class Initialized
INFO - 2023-05-09 03:16:30 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:30 --> Input Class Initialized
INFO - 2023-05-09 03:16:30 --> Language Class Initialized
INFO - 2023-05-09 03:16:30 --> Loader Class Initialized
INFO - 2023-05-09 03:16:30 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-05-09 03:16:30 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 250
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-05-09 03:16:30 --> Config Class Initialized
INFO - 2023-05-09 03:16:30 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:30 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:30 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:30 --> URI Class Initialized
INFO - 2023-05-09 03:16:30 --> Router Class Initialized
INFO - 2023-05-09 03:16:30 --> Output Class Initialized
INFO - 2023-05-09 03:16:30 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:30 --> Input Class Initialized
INFO - 2023-05-09 03:16:30 --> Language Class Initialized
INFO - 2023-05-09 03:16:30 --> Loader Class Initialized
INFO - 2023-05-09 03:16:30 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:30 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:30 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:30 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:30 --> Total execution time: 0.0203
INFO - 2023-05-09 03:16:31 --> Config Class Initialized
INFO - 2023-05-09 03:16:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:31 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:31 --> URI Class Initialized
INFO - 2023-05-09 03:16:31 --> Router Class Initialized
INFO - 2023-05-09 03:16:31 --> Output Class Initialized
INFO - 2023-05-09 03:16:31 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:31 --> Input Class Initialized
INFO - 2023-05-09 03:16:31 --> Language Class Initialized
INFO - 2023-05-09 03:16:31 --> Loader Class Initialized
INFO - 2023-05-09 03:16:31 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:31 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:31 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:31 --> Total execution time: 0.0236
INFO - 2023-05-09 03:16:31 --> Config Class Initialized
INFO - 2023-05-09 03:16:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:31 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:31 --> URI Class Initialized
INFO - 2023-05-09 03:16:31 --> Router Class Initialized
INFO - 2023-05-09 03:16:31 --> Output Class Initialized
INFO - 2023-05-09 03:16:31 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:31 --> Input Class Initialized
INFO - 2023-05-09 03:16:31 --> Language Class Initialized
INFO - 2023-05-09 03:16:31 --> Loader Class Initialized
INFO - 2023-05-09 03:16:31 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:31 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:31 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:31 --> Total execution time: 0.0169
INFO - 2023-05-09 03:16:41 --> Config Class Initialized
INFO - 2023-05-09 03:16:41 --> Config Class Initialized
INFO - 2023-05-09 03:16:41 --> Hooks Class Initialized
INFO - 2023-05-09 03:16:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:16:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:41 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:41 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:41 --> URI Class Initialized
INFO - 2023-05-09 03:16:41 --> URI Class Initialized
INFO - 2023-05-09 03:16:41 --> Router Class Initialized
INFO - 2023-05-09 03:16:41 --> Router Class Initialized
INFO - 2023-05-09 03:16:41 --> Output Class Initialized
INFO - 2023-05-09 03:16:41 --> Output Class Initialized
INFO - 2023-05-09 03:16:41 --> Security Class Initialized
INFO - 2023-05-09 03:16:41 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:41 --> Input Class Initialized
INFO - 2023-05-09 03:16:41 --> Input Class Initialized
INFO - 2023-05-09 03:16:41 --> Language Class Initialized
INFO - 2023-05-09 03:16:41 --> Language Class Initialized
INFO - 2023-05-09 03:16:41 --> Loader Class Initialized
INFO - 2023-05-09 03:16:41 --> Loader Class Initialized
INFO - 2023-05-09 03:16:41 --> Controller Class Initialized
INFO - 2023-05-09 03:16:41 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:16:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:41 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:41 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:41 --> Total execution time: 0.0047
INFO - 2023-05-09 03:16:41 --> Config Class Initialized
INFO - 2023-05-09 03:16:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:41 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:41 --> URI Class Initialized
INFO - 2023-05-09 03:16:41 --> Router Class Initialized
INFO - 2023-05-09 03:16:41 --> Output Class Initialized
INFO - 2023-05-09 03:16:41 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:41 --> Input Class Initialized
INFO - 2023-05-09 03:16:41 --> Language Class Initialized
INFO - 2023-05-09 03:16:41 --> Loader Class Initialized
INFO - 2023-05-09 03:16:41 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:41 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:41 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:41 --> Total execution time: 0.0195
INFO - 2023-05-09 03:16:41 --> Config Class Initialized
INFO - 2023-05-09 03:16:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:41 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:41 --> URI Class Initialized
INFO - 2023-05-09 03:16:41 --> Router Class Initialized
INFO - 2023-05-09 03:16:41 --> Output Class Initialized
INFO - 2023-05-09 03:16:41 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:41 --> Input Class Initialized
INFO - 2023-05-09 03:16:41 --> Language Class Initialized
INFO - 2023-05-09 03:16:41 --> Loader Class Initialized
INFO - 2023-05-09 03:16:41 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:41 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:41 --> Model "Login_model" initialized
INFO - 2023-05-09 03:16:41 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:41 --> Final output sent to browser
INFO - 2023-05-09 03:16:41 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:41 --> Total execution time: 0.0629
DEBUG - 2023-05-09 03:16:41 --> Total execution time: 0.0477
INFO - 2023-05-09 03:16:42 --> Config Class Initialized
INFO - 2023-05-09 03:16:42 --> Hooks Class Initialized
INFO - 2023-05-09 03:16:42 --> Config Class Initialized
DEBUG - 2023-05-09 03:16:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:42 --> Hooks Class Initialized
INFO - 2023-05-09 03:16:42 --> Utf8 Class Initialized
DEBUG - 2023-05-09 03:16:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:42 --> URI Class Initialized
INFO - 2023-05-09 03:16:42 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:42 --> Router Class Initialized
INFO - 2023-05-09 03:16:42 --> URI Class Initialized
INFO - 2023-05-09 03:16:42 --> Output Class Initialized
INFO - 2023-05-09 03:16:42 --> Router Class Initialized
INFO - 2023-05-09 03:16:42 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:42 --> Output Class Initialized
INFO - 2023-05-09 03:16:42 --> Input Class Initialized
INFO - 2023-05-09 03:16:42 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:42 --> Language Class Initialized
INFO - 2023-05-09 03:16:42 --> Input Class Initialized
INFO - 2023-05-09 03:16:42 --> Language Class Initialized
INFO - 2023-05-09 03:16:42 --> Loader Class Initialized
INFO - 2023-05-09 03:16:42 --> Controller Class Initialized
INFO - 2023-05-09 03:16:42 --> Loader Class Initialized
DEBUG - 2023-05-09 03:16:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:42 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:42 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:42 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:42 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:42 --> Total execution time: 0.0490
INFO - 2023-05-09 03:16:42 --> Config Class Initialized
INFO - 2023-05-09 03:16:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:42 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:42 --> URI Class Initialized
INFO - 2023-05-09 03:16:42 --> Router Class Initialized
INFO - 2023-05-09 03:16:42 --> Output Class Initialized
INFO - 2023-05-09 03:16:42 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:42 --> Input Class Initialized
INFO - 2023-05-09 03:16:42 --> Language Class Initialized
INFO - 2023-05-09 03:16:42 --> Loader Class Initialized
INFO - 2023-05-09 03:16:42 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:42 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:42 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:42 --> Total execution time: 0.0531
INFO - 2023-05-09 03:16:42 --> Config Class Initialized
INFO - 2023-05-09 03:16:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:16:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:16:43 --> Utf8 Class Initialized
INFO - 2023-05-09 03:16:43 --> URI Class Initialized
INFO - 2023-05-09 03:16:43 --> Router Class Initialized
INFO - 2023-05-09 03:16:43 --> Output Class Initialized
INFO - 2023-05-09 03:16:43 --> Security Class Initialized
DEBUG - 2023-05-09 03:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:16:43 --> Input Class Initialized
INFO - 2023-05-09 03:16:43 --> Language Class Initialized
INFO - 2023-05-09 03:16:43 --> Loader Class Initialized
INFO - 2023-05-09 03:16:43 --> Controller Class Initialized
DEBUG - 2023-05-09 03:16:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:16:43 --> Database Driver Class Initialized
INFO - 2023-05-09 03:16:43 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:43 --> Total execution time: 0.0910
INFO - 2023-05-09 03:16:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:16:43 --> Final output sent to browser
DEBUG - 2023-05-09 03:16:43 --> Total execution time: 0.1518
INFO - 2023-05-09 03:17:11 --> Config Class Initialized
INFO - 2023-05-09 03:17:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:11 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:11 --> URI Class Initialized
INFO - 2023-05-09 03:17:11 --> Router Class Initialized
INFO - 2023-05-09 03:17:11 --> Output Class Initialized
INFO - 2023-05-09 03:17:11 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:11 --> Input Class Initialized
INFO - 2023-05-09 03:17:11 --> Language Class Initialized
INFO - 2023-05-09 03:17:11 --> Loader Class Initialized
INFO - 2023-05-09 03:17:11 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:11 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:11 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:11 --> Total execution time: 0.0303
INFO - 2023-05-09 03:17:11 --> Config Class Initialized
INFO - 2023-05-09 03:17:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:11 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:11 --> URI Class Initialized
INFO - 2023-05-09 03:17:11 --> Router Class Initialized
INFO - 2023-05-09 03:17:11 --> Output Class Initialized
INFO - 2023-05-09 03:17:11 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:11 --> Input Class Initialized
INFO - 2023-05-09 03:17:11 --> Language Class Initialized
INFO - 2023-05-09 03:17:11 --> Loader Class Initialized
INFO - 2023-05-09 03:17:11 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:11 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:11 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:11 --> Total execution time: 0.0582
INFO - 2023-05-09 03:17:24 --> Config Class Initialized
INFO - 2023-05-09 03:17:24 --> Config Class Initialized
INFO - 2023-05-09 03:17:24 --> Hooks Class Initialized
INFO - 2023-05-09 03:17:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:17:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:24 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:24 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:24 --> URI Class Initialized
INFO - 2023-05-09 03:17:24 --> URI Class Initialized
INFO - 2023-05-09 03:17:24 --> Router Class Initialized
INFO - 2023-05-09 03:17:24 --> Router Class Initialized
INFO - 2023-05-09 03:17:24 --> Output Class Initialized
INFO - 2023-05-09 03:17:24 --> Output Class Initialized
INFO - 2023-05-09 03:17:24 --> Security Class Initialized
INFO - 2023-05-09 03:17:24 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:24 --> Input Class Initialized
INFO - 2023-05-09 03:17:24 --> Input Class Initialized
INFO - 2023-05-09 03:17:24 --> Language Class Initialized
INFO - 2023-05-09 03:17:24 --> Language Class Initialized
INFO - 2023-05-09 03:17:24 --> Loader Class Initialized
INFO - 2023-05-09 03:17:24 --> Loader Class Initialized
INFO - 2023-05-09 03:17:24 --> Controller Class Initialized
INFO - 2023-05-09 03:17:24 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:17:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:24 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:24 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:24 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:24 --> Total execution time: 0.0197
INFO - 2023-05-09 03:17:24 --> Config Class Initialized
INFO - 2023-05-09 03:17:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:24 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:24 --> URI Class Initialized
INFO - 2023-05-09 03:17:24 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:24 --> Router Class Initialized
INFO - 2023-05-09 03:17:24 --> Output Class Initialized
INFO - 2023-05-09 03:17:24 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:24 --> Input Class Initialized
INFO - 2023-05-09 03:17:24 --> Language Class Initialized
INFO - 2023-05-09 03:17:24 --> Loader Class Initialized
INFO - 2023-05-09 03:17:24 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:24 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:24 --> Model "Login_model" initialized
INFO - 2023-05-09 03:17:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:24 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:24 --> Total execution time: 0.0133
INFO - 2023-05-09 03:17:24 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:25 --> Total execution time: 0.0439
INFO - 2023-05-09 03:17:25 --> Config Class Initialized
INFO - 2023-05-09 03:17:25 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:25 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:25 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:25 --> URI Class Initialized
INFO - 2023-05-09 03:17:25 --> Router Class Initialized
INFO - 2023-05-09 03:17:25 --> Output Class Initialized
INFO - 2023-05-09 03:17:25 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:25 --> Input Class Initialized
INFO - 2023-05-09 03:17:25 --> Language Class Initialized
INFO - 2023-05-09 03:17:25 --> Loader Class Initialized
INFO - 2023-05-09 03:17:25 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:25 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:25 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:25 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:25 --> Model "Login_model" initialized
INFO - 2023-05-09 03:17:25 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:25 --> Total execution time: 0.0361
INFO - 2023-05-09 03:17:27 --> Config Class Initialized
INFO - 2023-05-09 03:17:27 --> Config Class Initialized
INFO - 2023-05-09 03:17:27 --> Hooks Class Initialized
INFO - 2023-05-09 03:17:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:17:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:27 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:27 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:27 --> URI Class Initialized
INFO - 2023-05-09 03:17:27 --> URI Class Initialized
INFO - 2023-05-09 03:17:27 --> Router Class Initialized
INFO - 2023-05-09 03:17:27 --> Router Class Initialized
INFO - 2023-05-09 03:17:27 --> Output Class Initialized
INFO - 2023-05-09 03:17:27 --> Output Class Initialized
INFO - 2023-05-09 03:17:27 --> Security Class Initialized
INFO - 2023-05-09 03:17:27 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:27 --> Input Class Initialized
INFO - 2023-05-09 03:17:27 --> Input Class Initialized
INFO - 2023-05-09 03:17:27 --> Language Class Initialized
INFO - 2023-05-09 03:17:27 --> Language Class Initialized
INFO - 2023-05-09 03:17:27 --> Loader Class Initialized
INFO - 2023-05-09 03:17:27 --> Loader Class Initialized
INFO - 2023-05-09 03:17:27 --> Controller Class Initialized
INFO - 2023-05-09 03:17:27 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:17:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:27 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:27 --> Total execution time: 0.0040
INFO - 2023-05-09 03:17:27 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:27 --> Config Class Initialized
INFO - 2023-05-09 03:17:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:27 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:27 --> URI Class Initialized
INFO - 2023-05-09 03:17:27 --> Router Class Initialized
INFO - 2023-05-09 03:17:27 --> Output Class Initialized
INFO - 2023-05-09 03:17:27 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:27 --> Input Class Initialized
INFO - 2023-05-09 03:17:27 --> Language Class Initialized
INFO - 2023-05-09 03:17:27 --> Loader Class Initialized
INFO - 2023-05-09 03:17:27 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:27 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:27 --> Model "Login_model" initialized
INFO - 2023-05-09 03:17:27 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:27 --> Total execution time: 0.0158
INFO - 2023-05-09 03:17:27 --> Config Class Initialized
INFO - 2023-05-09 03:17:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:27 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:27 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:27 --> URI Class Initialized
INFO - 2023-05-09 03:17:27 --> Router Class Initialized
INFO - 2023-05-09 03:17:27 --> Output Class Initialized
INFO - 2023-05-09 03:17:27 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:27 --> Input Class Initialized
INFO - 2023-05-09 03:17:27 --> Language Class Initialized
INFO - 2023-05-09 03:17:27 --> Loader Class Initialized
INFO - 2023-05-09 03:17:27 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:27 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:27 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:27 --> Total execution time: 0.0216
INFO - 2023-05-09 03:17:27 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:27 --> Total execution time: 0.0134
INFO - 2023-05-09 03:17:29 --> Config Class Initialized
INFO - 2023-05-09 03:17:29 --> Hooks Class Initialized
INFO - 2023-05-09 03:17:29 --> Config Class Initialized
DEBUG - 2023-05-09 03:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:29 --> Hooks Class Initialized
INFO - 2023-05-09 03:17:29 --> Utf8 Class Initialized
DEBUG - 2023-05-09 03:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:29 --> URI Class Initialized
INFO - 2023-05-09 03:17:29 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:29 --> Router Class Initialized
INFO - 2023-05-09 03:17:29 --> URI Class Initialized
INFO - 2023-05-09 03:17:29 --> Output Class Initialized
INFO - 2023-05-09 03:17:29 --> Router Class Initialized
INFO - 2023-05-09 03:17:29 --> Security Class Initialized
INFO - 2023-05-09 03:17:29 --> Output Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:29 --> Security Class Initialized
INFO - 2023-05-09 03:17:29 --> Input Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:29 --> Language Class Initialized
INFO - 2023-05-09 03:17:29 --> Input Class Initialized
INFO - 2023-05-09 03:17:29 --> Language Class Initialized
INFO - 2023-05-09 03:17:29 --> Loader Class Initialized
INFO - 2023-05-09 03:17:29 --> Controller Class Initialized
INFO - 2023-05-09 03:17:29 --> Loader Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:29 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:29 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:29 --> Total execution time: 0.0177
INFO - 2023-05-09 03:17:29 --> Config Class Initialized
INFO - 2023-05-09 03:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:29 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:29 --> URI Class Initialized
INFO - 2023-05-09 03:17:29 --> Router Class Initialized
INFO - 2023-05-09 03:17:29 --> Output Class Initialized
INFO - 2023-05-09 03:17:29 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:29 --> Input Class Initialized
INFO - 2023-05-09 03:17:29 --> Final output sent to browser
INFO - 2023-05-09 03:17:29 --> Language Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Total execution time: 0.0212
INFO - 2023-05-09 03:17:29 --> Loader Class Initialized
INFO - 2023-05-09 03:17:29 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:29 --> Config Class Initialized
INFO - 2023-05-09 03:17:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:17:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:17:29 --> Utf8 Class Initialized
INFO - 2023-05-09 03:17:29 --> URI Class Initialized
INFO - 2023-05-09 03:17:29 --> Router Class Initialized
INFO - 2023-05-09 03:17:29 --> Output Class Initialized
INFO - 2023-05-09 03:17:29 --> Security Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:17:29 --> Input Class Initialized
INFO - 2023-05-09 03:17:29 --> Language Class Initialized
INFO - 2023-05-09 03:17:29 --> Loader Class Initialized
INFO - 2023-05-09 03:17:29 --> Controller Class Initialized
DEBUG - 2023-05-09 03:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:17:29 --> Database Driver Class Initialized
INFO - 2023-05-09 03:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:17:29 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:29 --> Total execution time: 0.0175
INFO - 2023-05-09 03:17:29 --> Final output sent to browser
DEBUG - 2023-05-09 03:17:29 --> Total execution time: 0.0214
INFO - 2023-05-09 03:20:25 --> Config Class Initialized
INFO - 2023-05-09 03:20:25 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:20:25 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:20:25 --> Utf8 Class Initialized
INFO - 2023-05-09 03:20:25 --> URI Class Initialized
INFO - 2023-05-09 03:20:25 --> Router Class Initialized
INFO - 2023-05-09 03:20:25 --> Output Class Initialized
INFO - 2023-05-09 03:20:25 --> Security Class Initialized
DEBUG - 2023-05-09 03:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:20:25 --> Input Class Initialized
INFO - 2023-05-09 03:20:25 --> Language Class Initialized
INFO - 2023-05-09 03:20:25 --> Loader Class Initialized
INFO - 2023-05-09 03:20:25 --> Controller Class Initialized
DEBUG - 2023-05-09 03:20:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:20:25 --> Database Driver Class Initialized
INFO - 2023-05-09 03:20:25 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:20:25 --> Final output sent to browser
DEBUG - 2023-05-09 03:20:25 --> Total execution time: 0.0201
INFO - 2023-05-09 03:20:25 --> Config Class Initialized
INFO - 2023-05-09 03:20:25 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:20:25 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:20:25 --> Utf8 Class Initialized
INFO - 2023-05-09 03:20:25 --> URI Class Initialized
INFO - 2023-05-09 03:20:25 --> Router Class Initialized
INFO - 2023-05-09 03:20:25 --> Output Class Initialized
INFO - 2023-05-09 03:20:25 --> Security Class Initialized
DEBUG - 2023-05-09 03:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:20:25 --> Input Class Initialized
INFO - 2023-05-09 03:20:25 --> Language Class Initialized
INFO - 2023-05-09 03:20:25 --> Loader Class Initialized
INFO - 2023-05-09 03:20:25 --> Controller Class Initialized
DEBUG - 2023-05-09 03:20:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:20:25 --> Database Driver Class Initialized
INFO - 2023-05-09 03:20:25 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:20:25 --> Final output sent to browser
DEBUG - 2023-05-09 03:20:25 --> Total execution time: 0.0709
INFO - 2023-05-09 03:20:28 --> Config Class Initialized
INFO - 2023-05-09 03:20:28 --> Hooks Class Initialized
INFO - 2023-05-09 03:20:28 --> Config Class Initialized
DEBUG - 2023-05-09 03:20:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:20:28 --> Utf8 Class Initialized
INFO - 2023-05-09 03:20:28 --> URI Class Initialized
INFO - 2023-05-09 03:20:28 --> Router Class Initialized
INFO - 2023-05-09 03:20:28 --> Hooks Class Initialized
INFO - 2023-05-09 03:20:28 --> Output Class Initialized
DEBUG - 2023-05-09 03:20:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:20:28 --> Security Class Initialized
INFO - 2023-05-09 03:20:28 --> Utf8 Class Initialized
DEBUG - 2023-05-09 03:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:20:28 --> URI Class Initialized
INFO - 2023-05-09 03:20:28 --> Input Class Initialized
INFO - 2023-05-09 03:20:28 --> Router Class Initialized
INFO - 2023-05-09 03:20:28 --> Language Class Initialized
INFO - 2023-05-09 03:20:28 --> Output Class Initialized
INFO - 2023-05-09 03:20:28 --> Security Class Initialized
DEBUG - 2023-05-09 03:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:20:28 --> Loader Class Initialized
INFO - 2023-05-09 03:20:28 --> Input Class Initialized
INFO - 2023-05-09 03:20:28 --> Language Class Initialized
INFO - 2023-05-09 03:20:28 --> Controller Class Initialized
INFO - 2023-05-09 03:20:28 --> Loader Class Initialized
INFO - 2023-05-09 03:20:28 --> Controller Class Initialized
DEBUG - 2023-05-09 03:20:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:20:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:20:28 --> Database Driver Class Initialized
INFO - 2023-05-09 03:20:28 --> Database Driver Class Initialized
INFO - 2023-05-09 03:20:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:20:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:20:28 --> Final output sent to browser
DEBUG - 2023-05-09 03:20:28 --> Total execution time: 0.0919
INFO - 2023-05-09 03:20:28 --> Config Class Initialized
INFO - 2023-05-09 03:20:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:20:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:20:28 --> Utf8 Class Initialized
INFO - 2023-05-09 03:20:28 --> URI Class Initialized
INFO - 2023-05-09 03:20:28 --> Router Class Initialized
INFO - 2023-05-09 03:20:28 --> Output Class Initialized
INFO - 2023-05-09 03:20:28 --> Security Class Initialized
DEBUG - 2023-05-09 03:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:20:28 --> Input Class Initialized
INFO - 2023-05-09 03:20:28 --> Language Class Initialized
INFO - 2023-05-09 03:20:28 --> Loader Class Initialized
INFO - 2023-05-09 03:20:28 --> Controller Class Initialized
DEBUG - 2023-05-09 03:20:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:20:28 --> Database Driver Class Initialized
INFO - 2023-05-09 03:20:28 --> Final output sent to browser
DEBUG - 2023-05-09 03:20:28 --> Total execution time: 0.1300
INFO - 2023-05-09 03:20:28 --> Config Class Initialized
INFO - 2023-05-09 03:20:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:20:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:20:28 --> Utf8 Class Initialized
INFO - 2023-05-09 03:20:28 --> URI Class Initialized
INFO - 2023-05-09 03:20:28 --> Router Class Initialized
INFO - 2023-05-09 03:20:28 --> Output Class Initialized
INFO - 2023-05-09 03:20:28 --> Security Class Initialized
DEBUG - 2023-05-09 03:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:20:28 --> Input Class Initialized
INFO - 2023-05-09 03:20:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:20:28 --> Language Class Initialized
INFO - 2023-05-09 03:20:28 --> Loader Class Initialized
INFO - 2023-05-09 03:20:28 --> Controller Class Initialized
DEBUG - 2023-05-09 03:20:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:20:28 --> Final output sent to browser
INFO - 2023-05-09 03:20:28 --> Database Driver Class Initialized
DEBUG - 2023-05-09 03:20:28 --> Total execution time: 0.0511
INFO - 2023-05-09 03:20:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:20:28 --> Final output sent to browser
DEBUG - 2023-05-09 03:20:28 --> Total execution time: 0.0750
INFO - 2023-05-09 03:46:44 --> Config Class Initialized
INFO - 2023-05-09 03:46:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:46:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:44 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:44 --> URI Class Initialized
INFO - 2023-05-09 03:46:44 --> Router Class Initialized
INFO - 2023-05-09 03:46:44 --> Output Class Initialized
INFO - 2023-05-09 03:46:44 --> Security Class Initialized
DEBUG - 2023-05-09 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:44 --> Input Class Initialized
INFO - 2023-05-09 03:46:44 --> Language Class Initialized
INFO - 2023-05-09 03:46:44 --> Loader Class Initialized
INFO - 2023-05-09 03:46:44 --> Controller Class Initialized
DEBUG - 2023-05-09 03:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:44 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:44 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:44 --> Total execution time: 0.0202
INFO - 2023-05-09 03:46:44 --> Config Class Initialized
INFO - 2023-05-09 03:46:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:46:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:44 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:44 --> URI Class Initialized
INFO - 2023-05-09 03:46:44 --> Router Class Initialized
INFO - 2023-05-09 03:46:44 --> Output Class Initialized
INFO - 2023-05-09 03:46:44 --> Security Class Initialized
DEBUG - 2023-05-09 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:44 --> Input Class Initialized
INFO - 2023-05-09 03:46:44 --> Language Class Initialized
INFO - 2023-05-09 03:46:44 --> Loader Class Initialized
INFO - 2023-05-09 03:46:44 --> Controller Class Initialized
DEBUG - 2023-05-09 03:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:44 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:44 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:44 --> Total execution time: 0.0586
INFO - 2023-05-09 03:46:45 --> Config Class Initialized
INFO - 2023-05-09 03:46:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:46:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:45 --> URI Class Initialized
INFO - 2023-05-09 03:46:45 --> Router Class Initialized
INFO - 2023-05-09 03:46:45 --> Output Class Initialized
INFO - 2023-05-09 03:46:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:45 --> Input Class Initialized
INFO - 2023-05-09 03:46:45 --> Language Class Initialized
INFO - 2023-05-09 03:46:45 --> Loader Class Initialized
INFO - 2023-05-09 03:46:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:45 --> Config Class Initialized
INFO - 2023-05-09 03:46:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:46:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:45 --> URI Class Initialized
INFO - 2023-05-09 03:46:45 --> Router Class Initialized
INFO - 2023-05-09 03:46:45 --> Output Class Initialized
INFO - 2023-05-09 03:46:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:45 --> Input Class Initialized
INFO - 2023-05-09 03:46:45 --> Language Class Initialized
INFO - 2023-05-09 03:46:45 --> Loader Class Initialized
INFO - 2023-05-09 03:46:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:45 --> Total execution time: 0.0183
INFO - 2023-05-09 03:46:45 --> Final output sent to browser
INFO - 2023-05-09 03:46:45 --> Config Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Total execution time: 0.0361
INFO - 2023-05-09 03:46:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:46:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:45 --> Config Class Initialized
INFO - 2023-05-09 03:46:45 --> Hooks Class Initialized
INFO - 2023-05-09 03:46:45 --> URI Class Initialized
DEBUG - 2023-05-09 03:46:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:45 --> Router Class Initialized
INFO - 2023-05-09 03:46:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:45 --> Output Class Initialized
INFO - 2023-05-09 03:46:45 --> URI Class Initialized
INFO - 2023-05-09 03:46:45 --> Security Class Initialized
INFO - 2023-05-09 03:46:45 --> Router Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:45 --> Output Class Initialized
INFO - 2023-05-09 03:46:45 --> Input Class Initialized
INFO - 2023-05-09 03:46:45 --> Security Class Initialized
INFO - 2023-05-09 03:46:45 --> Language Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:45 --> Input Class Initialized
INFO - 2023-05-09 03:46:45 --> Loader Class Initialized
INFO - 2023-05-09 03:46:45 --> Language Class Initialized
INFO - 2023-05-09 03:46:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:45 --> Loader Class Initialized
INFO - 2023-05-09 03:46:45 --> Controller Class Initialized
INFO - 2023-05-09 03:46:45 --> Database Driver Class Initialized
DEBUG - 2023-05-09 03:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:45 --> Total execution time: 0.0965
INFO - 2023-05-09 03:46:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:45 --> Total execution time: 0.0625
INFO - 2023-05-09 03:46:46 --> Config Class Initialized
INFO - 2023-05-09 03:46:46 --> Config Class Initialized
INFO - 2023-05-09 03:46:46 --> Hooks Class Initialized
INFO - 2023-05-09 03:46:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:46:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:46:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:46 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:46 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:46 --> URI Class Initialized
INFO - 2023-05-09 03:46:46 --> URI Class Initialized
INFO - 2023-05-09 03:46:46 --> Router Class Initialized
INFO - 2023-05-09 03:46:46 --> Router Class Initialized
INFO - 2023-05-09 03:46:46 --> Output Class Initialized
INFO - 2023-05-09 03:46:46 --> Output Class Initialized
INFO - 2023-05-09 03:46:46 --> Security Class Initialized
INFO - 2023-05-09 03:46:46 --> Security Class Initialized
DEBUG - 2023-05-09 03:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:46 --> Input Class Initialized
INFO - 2023-05-09 03:46:46 --> Input Class Initialized
INFO - 2023-05-09 03:46:46 --> Language Class Initialized
INFO - 2023-05-09 03:46:46 --> Language Class Initialized
INFO - 2023-05-09 03:46:46 --> Loader Class Initialized
INFO - 2023-05-09 03:46:46 --> Loader Class Initialized
INFO - 2023-05-09 03:46:46 --> Controller Class Initialized
INFO - 2023-05-09 03:46:46 --> Controller Class Initialized
DEBUG - 2023-05-09 03:46:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:46:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:46 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:46 --> Total execution time: 0.0053
INFO - 2023-05-09 03:46:46 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:46 --> Config Class Initialized
INFO - 2023-05-09 03:46:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:46:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:47 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:47 --> URI Class Initialized
INFO - 2023-05-09 03:46:47 --> Router Class Initialized
INFO - 2023-05-09 03:46:47 --> Output Class Initialized
INFO - 2023-05-09 03:46:47 --> Security Class Initialized
DEBUG - 2023-05-09 03:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:47 --> Input Class Initialized
INFO - 2023-05-09 03:46:47 --> Language Class Initialized
INFO - 2023-05-09 03:46:47 --> Loader Class Initialized
INFO - 2023-05-09 03:46:47 --> Controller Class Initialized
DEBUG - 2023-05-09 03:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:47 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:47 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:47 --> Total execution time: 0.0538
INFO - 2023-05-09 03:46:47 --> Config Class Initialized
INFO - 2023-05-09 03:46:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:46:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:46:47 --> Utf8 Class Initialized
INFO - 2023-05-09 03:46:47 --> URI Class Initialized
INFO - 2023-05-09 03:46:47 --> Router Class Initialized
INFO - 2023-05-09 03:46:47 --> Output Class Initialized
INFO - 2023-05-09 03:46:47 --> Security Class Initialized
DEBUG - 2023-05-09 03:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:46:47 --> Input Class Initialized
INFO - 2023-05-09 03:46:47 --> Language Class Initialized
INFO - 2023-05-09 03:46:47 --> Loader Class Initialized
INFO - 2023-05-09 03:46:47 --> Controller Class Initialized
DEBUG - 2023-05-09 03:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:46:47 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:47 --> Model "Login_model" initialized
INFO - 2023-05-09 03:46:47 --> Database Driver Class Initialized
INFO - 2023-05-09 03:46:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:47 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:47 --> Total execution time: 0.0136
INFO - 2023-05-09 03:46:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:46:47 --> Final output sent to browser
DEBUG - 2023-05-09 03:46:47 --> Total execution time: 0.1064
INFO - 2023-05-09 03:50:45 --> Config Class Initialized
INFO - 2023-05-09 03:50:45 --> Hooks Class Initialized
INFO - 2023-05-09 03:50:45 --> Config Class Initialized
INFO - 2023-05-09 03:50:45 --> Config Class Initialized
INFO - 2023-05-09 03:50:45 --> Hooks Class Initialized
INFO - 2023-05-09 03:50:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:45 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:50:45 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:50:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:45 --> URI Class Initialized
INFO - 2023-05-09 03:50:45 --> URI Class Initialized
INFO - 2023-05-09 03:50:45 --> URI Class Initialized
INFO - 2023-05-09 03:50:45 --> Router Class Initialized
INFO - 2023-05-09 03:50:45 --> Router Class Initialized
INFO - 2023-05-09 03:50:45 --> Router Class Initialized
INFO - 2023-05-09 03:50:45 --> Output Class Initialized
INFO - 2023-05-09 03:50:45 --> Output Class Initialized
INFO - 2023-05-09 03:50:45 --> Output Class Initialized
INFO - 2023-05-09 03:50:45 --> Security Class Initialized
INFO - 2023-05-09 03:50:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:45 --> Input Class Initialized
INFO - 2023-05-09 03:50:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:45 --> Language Class Initialized
INFO - 2023-05-09 03:50:45 --> Input Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:45 --> Language Class Initialized
INFO - 2023-05-09 03:50:45 --> Input Class Initialized
INFO - 2023-05-09 03:50:45 --> Loader Class Initialized
INFO - 2023-05-09 03:50:45 --> Loader Class Initialized
INFO - 2023-05-09 03:50:45 --> Language Class Initialized
INFO - 2023-05-09 03:50:45 --> Controller Class Initialized
INFO - 2023-05-09 03:50:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:45 --> Loader Class Initialized
INFO - 2023-05-09 03:50:45 --> Controller Class Initialized
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:45 --> Model "Login_model" initialized
INFO - 2023-05-09 03:50:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:45 --> Total execution time: 0.0333
INFO - 2023-05-09 03:50:45 --> Config Class Initialized
INFO - 2023-05-09 03:50:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:45 --> URI Class Initialized
INFO - 2023-05-09 03:50:45 --> Router Class Initialized
INFO - 2023-05-09 03:50:45 --> Output Class Initialized
INFO - 2023-05-09 03:50:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:45 --> Input Class Initialized
INFO - 2023-05-09 03:50:45 --> Language Class Initialized
INFO - 2023-05-09 03:50:45 --> Loader Class Initialized
INFO - 2023-05-09 03:50:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:45 --> Total execution time: 0.4385
INFO - 2023-05-09 03:50:45 --> Config Class Initialized
INFO - 2023-05-09 03:50:45 --> Hooks Class Initialized
INFO - 2023-05-09 03:50:45 --> Final output sent to browser
INFO - 2023-05-09 03:50:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:45 --> Total execution time: 0.4430
DEBUG - 2023-05-09 03:50:45 --> Total execution time: 0.4089
DEBUG - 2023-05-09 03:50:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:45 --> URI Class Initialized
INFO - 2023-05-09 03:50:45 --> Config Class Initialized
INFO - 2023-05-09 03:50:45 --> Router Class Initialized
INFO - 2023-05-09 03:50:45 --> Hooks Class Initialized
INFO - 2023-05-09 03:50:45 --> Output Class Initialized
DEBUG - 2023-05-09 03:50:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:45 --> Security Class Initialized
INFO - 2023-05-09 03:50:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:45 --> Config Class Initialized
INFO - 2023-05-09 03:50:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:45 --> URI Class Initialized
INFO - 2023-05-09 03:50:45 --> Input Class Initialized
DEBUG - 2023-05-09 03:50:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:45 --> Language Class Initialized
INFO - 2023-05-09 03:50:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:45 --> Router Class Initialized
INFO - 2023-05-09 03:50:45 --> URI Class Initialized
INFO - 2023-05-09 03:50:45 --> Loader Class Initialized
INFO - 2023-05-09 03:50:45 --> Output Class Initialized
INFO - 2023-05-09 03:50:45 --> Controller Class Initialized
INFO - 2023-05-09 03:50:45 --> Router Class Initialized
INFO - 2023-05-09 03:50:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:45 --> Output Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:45 --> Security Class Initialized
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:45 --> Input Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:45 --> Language Class Initialized
INFO - 2023-05-09 03:50:45 --> Input Class Initialized
INFO - 2023-05-09 03:50:45 --> Loader Class Initialized
INFO - 2023-05-09 03:50:45 --> Language Class Initialized
INFO - 2023-05-09 03:50:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:45 --> Loader Class Initialized
INFO - 2023-05-09 03:50:45 --> Controller Class Initialized
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:45 --> Model "Login_model" initialized
INFO - 2023-05-09 03:50:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:45 --> Total execution time: 0.1047
INFO - 2023-05-09 03:50:45 --> Config Class Initialized
INFO - 2023-05-09 03:50:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:45 --> URI Class Initialized
INFO - 2023-05-09 03:50:45 --> Router Class Initialized
INFO - 2023-05-09 03:50:45 --> Output Class Initialized
INFO - 2023-05-09 03:50:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:45 --> Input Class Initialized
INFO - 2023-05-09 03:50:45 --> Language Class Initialized
INFO - 2023-05-09 03:50:45 --> Loader Class Initialized
INFO - 2023-05-09 03:50:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:45 --> Total execution time: 0.1398
INFO - 2023-05-09 03:50:45 --> Final output sent to browser
INFO - 2023-05-09 03:50:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:46 --> Total execution time: 0.1407
DEBUG - 2023-05-09 03:50:46 --> Total execution time: 0.0873
INFO - 2023-05-09 03:50:46 --> Config Class Initialized
INFO - 2023-05-09 03:50:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:46 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:46 --> URI Class Initialized
INFO - 2023-05-09 03:50:46 --> Router Class Initialized
INFO - 2023-05-09 03:50:46 --> Output Class Initialized
INFO - 2023-05-09 03:50:46 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:46 --> Input Class Initialized
INFO - 2023-05-09 03:50:46 --> Language Class Initialized
INFO - 2023-05-09 03:50:46 --> Loader Class Initialized
INFO - 2023-05-09 03:50:46 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:46 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:46 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:46 --> Total execution time: 0.0177
INFO - 2023-05-09 03:50:46 --> Config Class Initialized
INFO - 2023-05-09 03:50:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:46 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:46 --> URI Class Initialized
INFO - 2023-05-09 03:50:46 --> Router Class Initialized
INFO - 2023-05-09 03:50:46 --> Output Class Initialized
INFO - 2023-05-09 03:50:46 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:46 --> Input Class Initialized
INFO - 2023-05-09 03:50:46 --> Language Class Initialized
INFO - 2023-05-09 03:50:46 --> Loader Class Initialized
INFO - 2023-05-09 03:50:46 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:46 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:46 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:46 --> Total execution time: 0.0508
INFO - 2023-05-09 03:50:48 --> Config Class Initialized
INFO - 2023-05-09 03:50:48 --> Config Class Initialized
INFO - 2023-05-09 03:50:48 --> Hooks Class Initialized
INFO - 2023-05-09 03:50:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:50:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:48 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:48 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:48 --> URI Class Initialized
INFO - 2023-05-09 03:50:48 --> URI Class Initialized
INFO - 2023-05-09 03:50:48 --> Router Class Initialized
INFO - 2023-05-09 03:50:48 --> Router Class Initialized
INFO - 2023-05-09 03:50:48 --> Output Class Initialized
INFO - 2023-05-09 03:50:48 --> Output Class Initialized
INFO - 2023-05-09 03:50:48 --> Security Class Initialized
INFO - 2023-05-09 03:50:48 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:48 --> Input Class Initialized
DEBUG - 2023-05-09 03:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:48 --> Language Class Initialized
INFO - 2023-05-09 03:50:48 --> Input Class Initialized
INFO - 2023-05-09 03:50:48 --> Language Class Initialized
INFO - 2023-05-09 03:50:48 --> Loader Class Initialized
INFO - 2023-05-09 03:50:48 --> Loader Class Initialized
INFO - 2023-05-09 03:50:48 --> Controller Class Initialized
INFO - 2023-05-09 03:50:48 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:50:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:48 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:48 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:48 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:48 --> Total execution time: 0.0226
INFO - 2023-05-09 03:50:48 --> Config Class Initialized
INFO - 2023-05-09 03:50:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:48 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:48 --> URI Class Initialized
INFO - 2023-05-09 03:50:48 --> Router Class Initialized
INFO - 2023-05-09 03:50:48 --> Output Class Initialized
INFO - 2023-05-09 03:50:48 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:48 --> Input Class Initialized
INFO - 2023-05-09 03:50:48 --> Language Class Initialized
INFO - 2023-05-09 03:50:48 --> Loader Class Initialized
INFO - 2023-05-09 03:50:48 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:48 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:48 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:48 --> Total execution time: 0.0325
INFO - 2023-05-09 03:50:48 --> Config Class Initialized
INFO - 2023-05-09 03:50:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:48 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:48 --> URI Class Initialized
INFO - 2023-05-09 03:50:48 --> Router Class Initialized
INFO - 2023-05-09 03:50:48 --> Output Class Initialized
INFO - 2023-05-09 03:50:48 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:48 --> Input Class Initialized
INFO - 2023-05-09 03:50:48 --> Language Class Initialized
INFO - 2023-05-09 03:50:48 --> Loader Class Initialized
INFO - 2023-05-09 03:50:48 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:48 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:48 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:48 --> Total execution time: 0.0182
INFO - 2023-05-09 03:50:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:48 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:48 --> Total execution time: 0.0637
INFO - 2023-05-09 03:50:50 --> Config Class Initialized
INFO - 2023-05-09 03:50:50 --> Config Class Initialized
INFO - 2023-05-09 03:50:50 --> Hooks Class Initialized
INFO - 2023-05-09 03:50:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:50 --> Utf8 Class Initialized
DEBUG - 2023-05-09 03:50:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:50 --> URI Class Initialized
INFO - 2023-05-09 03:50:50 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:50 --> Router Class Initialized
INFO - 2023-05-09 03:50:50 --> URI Class Initialized
INFO - 2023-05-09 03:50:50 --> Output Class Initialized
INFO - 2023-05-09 03:50:50 --> Router Class Initialized
INFO - 2023-05-09 03:50:50 --> Security Class Initialized
INFO - 2023-05-09 03:50:50 --> Output Class Initialized
DEBUG - 2023-05-09 03:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:50 --> Security Class Initialized
INFO - 2023-05-09 03:50:50 --> Input Class Initialized
DEBUG - 2023-05-09 03:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:50 --> Language Class Initialized
INFO - 2023-05-09 03:50:50 --> Input Class Initialized
INFO - 2023-05-09 03:50:50 --> Language Class Initialized
INFO - 2023-05-09 03:50:50 --> Loader Class Initialized
INFO - 2023-05-09 03:50:50 --> Loader Class Initialized
INFO - 2023-05-09 03:50:50 --> Controller Class Initialized
INFO - 2023-05-09 03:50:50 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:50 --> Total execution time: 0.0044
INFO - 2023-05-09 03:50:50 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:50 --> Config Class Initialized
INFO - 2023-05-09 03:50:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:50:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:50 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:50 --> URI Class Initialized
INFO - 2023-05-09 03:50:50 --> Router Class Initialized
INFO - 2023-05-09 03:50:50 --> Output Class Initialized
INFO - 2023-05-09 03:50:50 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:50 --> Input Class Initialized
INFO - 2023-05-09 03:50:50 --> Language Class Initialized
INFO - 2023-05-09 03:50:50 --> Loader Class Initialized
INFO - 2023-05-09 03:50:50 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:50 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:50 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:50 --> Total execution time: 0.0165
INFO - 2023-05-09 03:50:50 --> Config Class Initialized
INFO - 2023-05-09 03:50:50 --> Hooks Class Initialized
INFO - 2023-05-09 03:50:50 --> Model "Login_model" initialized
DEBUG - 2023-05-09 03:50:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:50:50 --> Utf8 Class Initialized
INFO - 2023-05-09 03:50:50 --> URI Class Initialized
INFO - 2023-05-09 03:50:50 --> Router Class Initialized
INFO - 2023-05-09 03:50:50 --> Output Class Initialized
INFO - 2023-05-09 03:50:50 --> Security Class Initialized
DEBUG - 2023-05-09 03:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:50:50 --> Input Class Initialized
INFO - 2023-05-09 03:50:50 --> Language Class Initialized
INFO - 2023-05-09 03:50:50 --> Loader Class Initialized
INFO - 2023-05-09 03:50:50 --> Controller Class Initialized
DEBUG - 2023-05-09 03:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:50:50 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:50 --> Database Driver Class Initialized
INFO - 2023-05-09 03:50:50 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:50 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:50:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:50 --> Total execution time: 0.0253
INFO - 2023-05-09 03:50:50 --> Final output sent to browser
DEBUG - 2023-05-09 03:50:51 --> Total execution time: 0.0172
INFO - 2023-05-09 03:53:09 --> Config Class Initialized
INFO - 2023-05-09 03:53:09 --> Config Class Initialized
INFO - 2023-05-09 03:53:09 --> Hooks Class Initialized
INFO - 2023-05-09 03:53:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:53:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:53:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:53:09 --> Utf8 Class Initialized
INFO - 2023-05-09 03:53:09 --> Utf8 Class Initialized
INFO - 2023-05-09 03:53:09 --> URI Class Initialized
INFO - 2023-05-09 03:53:09 --> URI Class Initialized
INFO - 2023-05-09 03:53:09 --> Router Class Initialized
INFO - 2023-05-09 03:53:09 --> Router Class Initialized
INFO - 2023-05-09 03:53:09 --> Output Class Initialized
INFO - 2023-05-09 03:53:09 --> Output Class Initialized
INFO - 2023-05-09 03:53:09 --> Security Class Initialized
INFO - 2023-05-09 03:53:09 --> Security Class Initialized
DEBUG - 2023-05-09 03:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:53:09 --> Input Class Initialized
INFO - 2023-05-09 03:53:09 --> Input Class Initialized
INFO - 2023-05-09 03:53:09 --> Language Class Initialized
INFO - 2023-05-09 03:53:09 --> Language Class Initialized
INFO - 2023-05-09 03:53:09 --> Loader Class Initialized
INFO - 2023-05-09 03:53:09 --> Loader Class Initialized
INFO - 2023-05-09 03:53:09 --> Controller Class Initialized
INFO - 2023-05-09 03:53:09 --> Controller Class Initialized
DEBUG - 2023-05-09 03:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:53:09 --> Database Driver Class Initialized
INFO - 2023-05-09 03:53:09 --> Database Driver Class Initialized
INFO - 2023-05-09 03:53:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:53:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:53:09 --> Final output sent to browser
DEBUG - 2023-05-09 03:53:09 --> Total execution time: 0.0553
INFO - 2023-05-09 03:53:09 --> Config Class Initialized
INFO - 2023-05-09 03:53:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:53:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:53:09 --> Utf8 Class Initialized
INFO - 2023-05-09 03:53:09 --> URI Class Initialized
INFO - 2023-05-09 03:53:09 --> Router Class Initialized
INFO - 2023-05-09 03:53:09 --> Output Class Initialized
INFO - 2023-05-09 03:53:09 --> Security Class Initialized
DEBUG - 2023-05-09 03:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:53:09 --> Input Class Initialized
INFO - 2023-05-09 03:53:09 --> Language Class Initialized
INFO - 2023-05-09 03:53:09 --> Loader Class Initialized
INFO - 2023-05-09 03:53:09 --> Controller Class Initialized
DEBUG - 2023-05-09 03:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:53:09 --> Database Driver Class Initialized
INFO - 2023-05-09 03:53:09 --> Final output sent to browser
DEBUG - 2023-05-09 03:53:09 --> Total execution time: 0.0669
INFO - 2023-05-09 03:53:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:53:09 --> Config Class Initialized
INFO - 2023-05-09 03:53:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:53:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:53:09 --> Utf8 Class Initialized
INFO - 2023-05-09 03:53:09 --> URI Class Initialized
INFO - 2023-05-09 03:53:09 --> Router Class Initialized
INFO - 2023-05-09 03:53:09 --> Output Class Initialized
INFO - 2023-05-09 03:53:09 --> Security Class Initialized
DEBUG - 2023-05-09 03:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:53:09 --> Input Class Initialized
INFO - 2023-05-09 03:53:09 --> Language Class Initialized
INFO - 2023-05-09 03:53:09 --> Loader Class Initialized
INFO - 2023-05-09 03:53:09 --> Controller Class Initialized
DEBUG - 2023-05-09 03:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:53:09 --> Database Driver Class Initialized
INFO - 2023-05-09 03:53:09 --> Final output sent to browser
DEBUG - 2023-05-09 03:53:09 --> Total execution time: 0.0558
INFO - 2023-05-09 03:53:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:53:09 --> Final output sent to browser
DEBUG - 2023-05-09 03:53:09 --> Total execution time: 0.1007
INFO - 2023-05-09 03:53:11 --> Config Class Initialized
INFO - 2023-05-09 03:53:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:53:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:53:11 --> Utf8 Class Initialized
INFO - 2023-05-09 03:53:11 --> URI Class Initialized
INFO - 2023-05-09 03:53:11 --> Router Class Initialized
INFO - 2023-05-09 03:53:11 --> Output Class Initialized
INFO - 2023-05-09 03:53:11 --> Security Class Initialized
DEBUG - 2023-05-09 03:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:53:11 --> Input Class Initialized
INFO - 2023-05-09 03:53:11 --> Language Class Initialized
INFO - 2023-05-09 03:53:11 --> Loader Class Initialized
INFO - 2023-05-09 03:53:11 --> Controller Class Initialized
DEBUG - 2023-05-09 03:53:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:53:11 --> Database Driver Class Initialized
INFO - 2023-05-09 03:53:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:53:11 --> Final output sent to browser
DEBUG - 2023-05-09 03:53:11 --> Total execution time: 0.0567
INFO - 2023-05-09 03:53:11 --> Config Class Initialized
INFO - 2023-05-09 03:53:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:53:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:53:11 --> Utf8 Class Initialized
INFO - 2023-05-09 03:53:11 --> URI Class Initialized
INFO - 2023-05-09 03:53:11 --> Router Class Initialized
INFO - 2023-05-09 03:53:11 --> Output Class Initialized
INFO - 2023-05-09 03:53:11 --> Security Class Initialized
DEBUG - 2023-05-09 03:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:53:11 --> Input Class Initialized
INFO - 2023-05-09 03:53:11 --> Language Class Initialized
INFO - 2023-05-09 03:53:11 --> Loader Class Initialized
INFO - 2023-05-09 03:53:11 --> Controller Class Initialized
DEBUG - 2023-05-09 03:53:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:53:11 --> Database Driver Class Initialized
INFO - 2023-05-09 03:53:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:53:11 --> Final output sent to browser
DEBUG - 2023-05-09 03:53:11 --> Total execution time: 0.0149
INFO - 2023-05-09 03:55:22 --> Config Class Initialized
INFO - 2023-05-09 03:55:22 --> Config Class Initialized
INFO - 2023-05-09 03:55:22 --> Hooks Class Initialized
INFO - 2023-05-09 03:55:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:55:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:22 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:22 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:22 --> URI Class Initialized
INFO - 2023-05-09 03:55:22 --> URI Class Initialized
INFO - 2023-05-09 03:55:22 --> Router Class Initialized
INFO - 2023-05-09 03:55:22 --> Router Class Initialized
INFO - 2023-05-09 03:55:22 --> Output Class Initialized
INFO - 2023-05-09 03:55:22 --> Output Class Initialized
INFO - 2023-05-09 03:55:22 --> Security Class Initialized
INFO - 2023-05-09 03:55:22 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:22 --> Input Class Initialized
INFO - 2023-05-09 03:55:22 --> Input Class Initialized
INFO - 2023-05-09 03:55:22 --> Language Class Initialized
INFO - 2023-05-09 03:55:22 --> Language Class Initialized
INFO - 2023-05-09 03:55:22 --> Loader Class Initialized
INFO - 2023-05-09 03:55:22 --> Loader Class Initialized
INFO - 2023-05-09 03:55:22 --> Controller Class Initialized
INFO - 2023-05-09 03:55:22 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:55:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:22 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:22 --> Total execution time: 0.0045
INFO - 2023-05-09 03:55:22 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:22 --> Config Class Initialized
INFO - 2023-05-09 03:55:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:22 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:22 --> URI Class Initialized
INFO - 2023-05-09 03:55:22 --> Router Class Initialized
INFO - 2023-05-09 03:55:22 --> Output Class Initialized
INFO - 2023-05-09 03:55:22 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:22 --> Input Class Initialized
INFO - 2023-05-09 03:55:22 --> Language Class Initialized
INFO - 2023-05-09 03:55:22 --> Loader Class Initialized
INFO - 2023-05-09 03:55:22 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:22 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:22 --> Model "Login_model" initialized
INFO - 2023-05-09 03:55:22 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:22 --> Total execution time: 0.0223
INFO - 2023-05-09 03:55:22 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:22 --> Config Class Initialized
INFO - 2023-05-09 03:55:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:22 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:22 --> URI Class Initialized
INFO - 2023-05-09 03:55:22 --> Router Class Initialized
INFO - 2023-05-09 03:55:22 --> Output Class Initialized
INFO - 2023-05-09 03:55:22 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:22 --> Input Class Initialized
INFO - 2023-05-09 03:55:22 --> Language Class Initialized
INFO - 2023-05-09 03:55:22 --> Loader Class Initialized
INFO - 2023-05-09 03:55:22 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:22 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:22 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:22 --> Total execution time: 0.0281
INFO - 2023-05-09 03:55:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:22 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:22 --> Total execution time: 0.0556
INFO - 2023-05-09 03:55:23 --> Config Class Initialized
INFO - 2023-05-09 03:55:23 --> Config Class Initialized
INFO - 2023-05-09 03:55:23 --> Hooks Class Initialized
INFO - 2023-05-09 03:55:23 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:23 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:23 --> Utf8 Class Initialized
DEBUG - 2023-05-09 03:55:23 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:23 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:23 --> URI Class Initialized
INFO - 2023-05-09 03:55:23 --> URI Class Initialized
INFO - 2023-05-09 03:55:23 --> Router Class Initialized
INFO - 2023-05-09 03:55:23 --> Router Class Initialized
INFO - 2023-05-09 03:55:23 --> Output Class Initialized
INFO - 2023-05-09 03:55:23 --> Output Class Initialized
INFO - 2023-05-09 03:55:23 --> Security Class Initialized
INFO - 2023-05-09 03:55:23 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:23 --> Input Class Initialized
INFO - 2023-05-09 03:55:23 --> Input Class Initialized
INFO - 2023-05-09 03:55:23 --> Language Class Initialized
INFO - 2023-05-09 03:55:23 --> Language Class Initialized
INFO - 2023-05-09 03:55:23 --> Loader Class Initialized
INFO - 2023-05-09 03:55:23 --> Loader Class Initialized
INFO - 2023-05-09 03:55:23 --> Controller Class Initialized
INFO - 2023-05-09 03:55:23 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:23 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:23 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:23 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:23 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:23 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:23 --> Total execution time: 0.0149
INFO - 2023-05-09 03:55:23 --> Config Class Initialized
INFO - 2023-05-09 03:55:23 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:23 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:23 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:23 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:23 --> URI Class Initialized
INFO - 2023-05-09 03:55:23 --> Router Class Initialized
INFO - 2023-05-09 03:55:23 --> Output Class Initialized
INFO - 2023-05-09 03:55:23 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:23 --> Input Class Initialized
INFO - 2023-05-09 03:55:23 --> Language Class Initialized
INFO - 2023-05-09 03:55:23 --> Loader Class Initialized
INFO - 2023-05-09 03:55:23 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:23 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:23 --> Model "Login_model" initialized
INFO - 2023-05-09 03:55:23 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:23 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:23 --> Total execution time: 0.0522
INFO - 2023-05-09 03:55:23 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:23 --> Total execution time: 0.0782
INFO - 2023-05-09 03:55:23 --> Config Class Initialized
INFO - 2023-05-09 03:55:23 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:23 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:23 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:23 --> URI Class Initialized
INFO - 2023-05-09 03:55:23 --> Router Class Initialized
INFO - 2023-05-09 03:55:23 --> Output Class Initialized
INFO - 2023-05-09 03:55:23 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:23 --> Input Class Initialized
INFO - 2023-05-09 03:55:23 --> Language Class Initialized
INFO - 2023-05-09 03:55:23 --> Loader Class Initialized
INFO - 2023-05-09 03:55:23 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:23 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:23 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:23 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:23 --> Model "Login_model" initialized
INFO - 2023-05-09 03:55:23 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:23 --> Total execution time: 0.0800
INFO - 2023-05-09 03:55:27 --> Config Class Initialized
INFO - 2023-05-09 03:55:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:27 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:27 --> URI Class Initialized
INFO - 2023-05-09 03:55:27 --> Router Class Initialized
INFO - 2023-05-09 03:55:27 --> Output Class Initialized
INFO - 2023-05-09 03:55:27 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:27 --> Input Class Initialized
INFO - 2023-05-09 03:55:27 --> Language Class Initialized
INFO - 2023-05-09 03:55:27 --> Loader Class Initialized
INFO - 2023-05-09 03:55:27 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:27 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:27 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:27 --> Total execution time: 0.0127
INFO - 2023-05-09 03:55:27 --> Config Class Initialized
INFO - 2023-05-09 03:55:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:27 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:27 --> URI Class Initialized
INFO - 2023-05-09 03:55:27 --> Router Class Initialized
INFO - 2023-05-09 03:55:27 --> Output Class Initialized
INFO - 2023-05-09 03:55:27 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:27 --> Input Class Initialized
INFO - 2023-05-09 03:55:27 --> Language Class Initialized
INFO - 2023-05-09 03:55:27 --> Loader Class Initialized
INFO - 2023-05-09 03:55:27 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:27 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:27 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:27 --> Total execution time: 0.0535
INFO - 2023-05-09 03:55:27 --> Config Class Initialized
INFO - 2023-05-09 03:55:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:27 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:27 --> URI Class Initialized
INFO - 2023-05-09 03:55:27 --> Router Class Initialized
INFO - 2023-05-09 03:55:27 --> Output Class Initialized
INFO - 2023-05-09 03:55:27 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:27 --> Input Class Initialized
INFO - 2023-05-09 03:55:27 --> Language Class Initialized
INFO - 2023-05-09 03:55:27 --> Loader Class Initialized
INFO - 2023-05-09 03:55:27 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:27 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:27 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:27 --> Total execution time: 0.0540
INFO - 2023-05-09 03:55:27 --> Config Class Initialized
INFO - 2023-05-09 03:55:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:28 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:28 --> URI Class Initialized
INFO - 2023-05-09 03:55:28 --> Router Class Initialized
INFO - 2023-05-09 03:55:28 --> Output Class Initialized
INFO - 2023-05-09 03:55:28 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:28 --> Input Class Initialized
INFO - 2023-05-09 03:55:28 --> Language Class Initialized
INFO - 2023-05-09 03:55:28 --> Loader Class Initialized
INFO - 2023-05-09 03:55:28 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:28 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:28 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:28 --> Total execution time: 0.0539
INFO - 2023-05-09 03:55:43 --> Config Class Initialized
INFO - 2023-05-09 03:55:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:43 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:43 --> URI Class Initialized
INFO - 2023-05-09 03:55:43 --> Router Class Initialized
INFO - 2023-05-09 03:55:43 --> Output Class Initialized
INFO - 2023-05-09 03:55:43 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:43 --> Input Class Initialized
INFO - 2023-05-09 03:55:43 --> Language Class Initialized
INFO - 2023-05-09 03:55:43 --> Loader Class Initialized
INFO - 2023-05-09 03:55:43 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:43 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:43 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:43 --> Total execution time: 0.0154
INFO - 2023-05-09 03:55:43 --> Config Class Initialized
INFO - 2023-05-09 03:55:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:43 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:43 --> URI Class Initialized
INFO - 2023-05-09 03:55:43 --> Router Class Initialized
INFO - 2023-05-09 03:55:43 --> Output Class Initialized
INFO - 2023-05-09 03:55:43 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:43 --> Input Class Initialized
INFO - 2023-05-09 03:55:43 --> Language Class Initialized
INFO - 2023-05-09 03:55:43 --> Loader Class Initialized
INFO - 2023-05-09 03:55:43 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:43 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:43 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:43 --> Total execution time: 0.0147
INFO - 2023-05-09 03:55:45 --> Config Class Initialized
INFO - 2023-05-09 03:55:45 --> Hooks Class Initialized
INFO - 2023-05-09 03:55:45 --> Config Class Initialized
INFO - 2023-05-09 03:55:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:45 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 03:55:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:45 --> URI Class Initialized
INFO - 2023-05-09 03:55:45 --> URI Class Initialized
INFO - 2023-05-09 03:55:45 --> Router Class Initialized
INFO - 2023-05-09 03:55:45 --> Router Class Initialized
INFO - 2023-05-09 03:55:45 --> Output Class Initialized
INFO - 2023-05-09 03:55:45 --> Output Class Initialized
INFO - 2023-05-09 03:55:45 --> Security Class Initialized
INFO - 2023-05-09 03:55:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 03:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:45 --> Input Class Initialized
INFO - 2023-05-09 03:55:45 --> Input Class Initialized
INFO - 2023-05-09 03:55:45 --> Language Class Initialized
INFO - 2023-05-09 03:55:45 --> Language Class Initialized
INFO - 2023-05-09 03:55:45 --> Loader Class Initialized
INFO - 2023-05-09 03:55:45 --> Loader Class Initialized
INFO - 2023-05-09 03:55:45 --> Controller Class Initialized
INFO - 2023-05-09 03:55:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 03:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:45 --> Total execution time: 0.0240
INFO - 2023-05-09 03:55:45 --> Config Class Initialized
INFO - 2023-05-09 03:55:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:45 --> URI Class Initialized
INFO - 2023-05-09 03:55:45 --> Router Class Initialized
INFO - 2023-05-09 03:55:45 --> Output Class Initialized
INFO - 2023-05-09 03:55:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:45 --> Input Class Initialized
INFO - 2023-05-09 03:55:45 --> Language Class Initialized
INFO - 2023-05-09 03:55:45 --> Loader Class Initialized
INFO - 2023-05-09 03:55:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:45 --> Total execution time: 0.0346
INFO - 2023-05-09 03:55:45 --> Config Class Initialized
INFO - 2023-05-09 03:55:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 03:55:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 03:55:45 --> Utf8 Class Initialized
INFO - 2023-05-09 03:55:45 --> URI Class Initialized
INFO - 2023-05-09 03:55:45 --> Router Class Initialized
INFO - 2023-05-09 03:55:45 --> Output Class Initialized
INFO - 2023-05-09 03:55:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:45 --> Security Class Initialized
DEBUG - 2023-05-09 03:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 03:55:45 --> Input Class Initialized
INFO - 2023-05-09 03:55:45 --> Language Class Initialized
INFO - 2023-05-09 03:55:45 --> Loader Class Initialized
INFO - 2023-05-09 03:55:45 --> Controller Class Initialized
DEBUG - 2023-05-09 03:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 03:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 03:55:45 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:45 --> Total execution time: 0.0144
INFO - 2023-05-09 03:55:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 03:55:46 --> Final output sent to browser
DEBUG - 2023-05-09 03:55:46 --> Total execution time: 0.0406
INFO - 2023-05-09 04:43:30 --> Config Class Initialized
INFO - 2023-05-09 04:43:30 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:30 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:30 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:30 --> URI Class Initialized
INFO - 2023-05-09 04:43:30 --> Router Class Initialized
INFO - 2023-05-09 04:43:30 --> Output Class Initialized
INFO - 2023-05-09 04:43:30 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:30 --> Input Class Initialized
INFO - 2023-05-09 04:43:30 --> Language Class Initialized
INFO - 2023-05-09 04:43:30 --> Loader Class Initialized
INFO - 2023-05-09 04:43:30 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:30 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:30 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:30 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:30 --> Total execution time: 0.0625
INFO - 2023-05-09 04:43:30 --> Config Class Initialized
INFO - 2023-05-09 04:43:30 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:30 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:30 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:30 --> URI Class Initialized
INFO - 2023-05-09 04:43:30 --> Router Class Initialized
INFO - 2023-05-09 04:43:30 --> Output Class Initialized
INFO - 2023-05-09 04:43:30 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:30 --> Input Class Initialized
INFO - 2023-05-09 04:43:30 --> Language Class Initialized
INFO - 2023-05-09 04:43:30 --> Loader Class Initialized
INFO - 2023-05-09 04:43:30 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:30 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:30 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:30 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:30 --> Total execution time: 0.0584
INFO - 2023-05-09 04:43:32 --> Config Class Initialized
INFO - 2023-05-09 04:43:32 --> Hooks Class Initialized
INFO - 2023-05-09 04:43:32 --> Config Class Initialized
DEBUG - 2023-05-09 04:43:32 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:32 --> Hooks Class Initialized
INFO - 2023-05-09 04:43:32 --> Utf8 Class Initialized
DEBUG - 2023-05-09 04:43:32 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:32 --> URI Class Initialized
INFO - 2023-05-09 04:43:32 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:32 --> Router Class Initialized
INFO - 2023-05-09 04:43:32 --> Output Class Initialized
INFO - 2023-05-09 04:43:32 --> URI Class Initialized
INFO - 2023-05-09 04:43:32 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:32 --> Router Class Initialized
INFO - 2023-05-09 04:43:32 --> Input Class Initialized
INFO - 2023-05-09 04:43:32 --> Output Class Initialized
INFO - 2023-05-09 04:43:32 --> Language Class Initialized
INFO - 2023-05-09 04:43:32 --> Security Class Initialized
INFO - 2023-05-09 04:43:32 --> Loader Class Initialized
DEBUG - 2023-05-09 04:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:32 --> Input Class Initialized
INFO - 2023-05-09 04:43:32 --> Controller Class Initialized
INFO - 2023-05-09 04:43:32 --> Language Class Initialized
DEBUG - 2023-05-09 04:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:32 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:32 --> Loader Class Initialized
INFO - 2023-05-09 04:43:32 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:32 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:32 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:32 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:32 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:32 --> Total execution time: 0.0220
INFO - 2023-05-09 04:43:32 --> Config Class Initialized
INFO - 2023-05-09 04:43:32 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:32 --> Total execution time: 0.0293
INFO - 2023-05-09 04:43:32 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:32 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:32 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:32 --> URI Class Initialized
INFO - 2023-05-09 04:43:32 --> Router Class Initialized
INFO - 2023-05-09 04:43:32 --> Config Class Initialized
INFO - 2023-05-09 04:43:32 --> Hooks Class Initialized
INFO - 2023-05-09 04:43:32 --> Output Class Initialized
DEBUG - 2023-05-09 04:43:32 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:32 --> Security Class Initialized
INFO - 2023-05-09 04:43:32 --> Utf8 Class Initialized
DEBUG - 2023-05-09 04:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:32 --> URI Class Initialized
INFO - 2023-05-09 04:43:32 --> Input Class Initialized
INFO - 2023-05-09 04:43:32 --> Router Class Initialized
INFO - 2023-05-09 04:43:32 --> Language Class Initialized
INFO - 2023-05-09 04:43:32 --> Output Class Initialized
INFO - 2023-05-09 04:43:32 --> Loader Class Initialized
INFO - 2023-05-09 04:43:32 --> Security Class Initialized
INFO - 2023-05-09 04:43:32 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 04:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:32 --> Input Class Initialized
INFO - 2023-05-09 04:43:32 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:32 --> Language Class Initialized
INFO - 2023-05-09 04:43:32 --> Loader Class Initialized
INFO - 2023-05-09 04:43:32 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:32 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:32 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:32 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:32 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:32 --> Total execution time: 0.0965
INFO - 2023-05-09 04:43:32 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:32 --> Total execution time: 0.0611
INFO - 2023-05-09 04:43:33 --> Config Class Initialized
INFO - 2023-05-09 04:43:33 --> Config Class Initialized
INFO - 2023-05-09 04:43:33 --> Hooks Class Initialized
INFO - 2023-05-09 04:43:33 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:33 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:33 --> Utf8 Class Initialized
DEBUG - 2023-05-09 04:43:33 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:33 --> URI Class Initialized
INFO - 2023-05-09 04:43:33 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:33 --> Router Class Initialized
INFO - 2023-05-09 04:43:33 --> URI Class Initialized
INFO - 2023-05-09 04:43:33 --> Output Class Initialized
INFO - 2023-05-09 04:43:33 --> Router Class Initialized
INFO - 2023-05-09 04:43:33 --> Output Class Initialized
INFO - 2023-05-09 04:43:33 --> Security Class Initialized
INFO - 2023-05-09 04:43:33 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 04:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:33 --> Input Class Initialized
INFO - 2023-05-09 04:43:33 --> Input Class Initialized
INFO - 2023-05-09 04:43:33 --> Language Class Initialized
INFO - 2023-05-09 04:43:33 --> Language Class Initialized
INFO - 2023-05-09 04:43:33 --> Loader Class Initialized
INFO - 2023-05-09 04:43:33 --> Loader Class Initialized
INFO - 2023-05-09 04:43:33 --> Controller Class Initialized
INFO - 2023-05-09 04:43:33 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 04:43:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:33 --> Final output sent to browser
INFO - 2023-05-09 04:43:33 --> Database Driver Class Initialized
DEBUG - 2023-05-09 04:43:33 --> Total execution time: 0.0061
INFO - 2023-05-09 04:43:33 --> Config Class Initialized
INFO - 2023-05-09 04:43:33 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:34 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:34 --> URI Class Initialized
INFO - 2023-05-09 04:43:34 --> Router Class Initialized
INFO - 2023-05-09 04:43:34 --> Output Class Initialized
INFO - 2023-05-09 04:43:34 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:34 --> Input Class Initialized
INFO - 2023-05-09 04:43:34 --> Language Class Initialized
INFO - 2023-05-09 04:43:34 --> Loader Class Initialized
INFO - 2023-05-09 04:43:34 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:34 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:34 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:34 --> Total execution time: 0.0538
INFO - 2023-05-09 04:43:34 --> Config Class Initialized
INFO - 2023-05-09 04:43:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:34 --> Model "Login_model" initialized
INFO - 2023-05-09 04:43:34 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:34 --> URI Class Initialized
INFO - 2023-05-09 04:43:34 --> Router Class Initialized
INFO - 2023-05-09 04:43:34 --> Output Class Initialized
INFO - 2023-05-09 04:43:34 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:34 --> Input Class Initialized
INFO - 2023-05-09 04:43:34 --> Language Class Initialized
INFO - 2023-05-09 04:43:34 --> Loader Class Initialized
INFO - 2023-05-09 04:43:34 --> Controller Class Initialized
INFO - 2023-05-09 04:43:34 --> Database Driver Class Initialized
DEBUG - 2023-05-09 04:43:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:34 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:34 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:34 --> Total execution time: 0.0653
INFO - 2023-05-09 04:43:34 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:34 --> Total execution time: 0.0612
INFO - 2023-05-09 04:43:35 --> Config Class Initialized
INFO - 2023-05-09 04:43:35 --> Hooks Class Initialized
INFO - 2023-05-09 04:43:35 --> Config Class Initialized
INFO - 2023-05-09 04:43:35 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:35 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 04:43:35 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:35 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:35 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:35 --> URI Class Initialized
INFO - 2023-05-09 04:43:35 --> URI Class Initialized
INFO - 2023-05-09 04:43:35 --> Router Class Initialized
INFO - 2023-05-09 04:43:35 --> Router Class Initialized
INFO - 2023-05-09 04:43:35 --> Output Class Initialized
INFO - 2023-05-09 04:43:35 --> Security Class Initialized
INFO - 2023-05-09 04:43:35 --> Output Class Initialized
DEBUG - 2023-05-09 04:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:35 --> Security Class Initialized
INFO - 2023-05-09 04:43:35 --> Input Class Initialized
DEBUG - 2023-05-09 04:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:35 --> Language Class Initialized
INFO - 2023-05-09 04:43:35 --> Input Class Initialized
INFO - 2023-05-09 04:43:35 --> Language Class Initialized
INFO - 2023-05-09 04:43:35 --> Loader Class Initialized
INFO - 2023-05-09 04:43:35 --> Loader Class Initialized
INFO - 2023-05-09 04:43:35 --> Controller Class Initialized
INFO - 2023-05-09 04:43:35 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 04:43:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:35 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:35 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:35 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:35 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:35 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:35 --> Total execution time: 0.0186
INFO - 2023-05-09 04:43:35 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:35 --> Total execution time: 0.0265
INFO - 2023-05-09 04:43:48 --> Config Class Initialized
INFO - 2023-05-09 04:43:48 --> Config Class Initialized
INFO - 2023-05-09 04:43:48 --> Hooks Class Initialized
INFO - 2023-05-09 04:43:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 04:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:48 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:48 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:48 --> URI Class Initialized
INFO - 2023-05-09 04:43:48 --> URI Class Initialized
INFO - 2023-05-09 04:43:48 --> Router Class Initialized
INFO - 2023-05-09 04:43:48 --> Router Class Initialized
INFO - 2023-05-09 04:43:48 --> Output Class Initialized
INFO - 2023-05-09 04:43:48 --> Output Class Initialized
INFO - 2023-05-09 04:43:48 --> Security Class Initialized
INFO - 2023-05-09 04:43:48 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 04:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:48 --> Input Class Initialized
INFO - 2023-05-09 04:43:48 --> Input Class Initialized
INFO - 2023-05-09 04:43:48 --> Language Class Initialized
INFO - 2023-05-09 04:43:48 --> Language Class Initialized
INFO - 2023-05-09 04:43:48 --> Loader Class Initialized
INFO - 2023-05-09 04:43:48 --> Loader Class Initialized
INFO - 2023-05-09 04:43:48 --> Controller Class Initialized
INFO - 2023-05-09 04:43:48 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 04:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:48 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:48 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:48 --> Total execution time: 0.0045
INFO - 2023-05-09 04:43:48 --> Config Class Initialized
INFO - 2023-05-09 04:43:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:48 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:48 --> URI Class Initialized
INFO - 2023-05-09 04:43:48 --> Router Class Initialized
INFO - 2023-05-09 04:43:48 --> Output Class Initialized
INFO - 2023-05-09 04:43:48 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:48 --> Input Class Initialized
INFO - 2023-05-09 04:43:48 --> Language Class Initialized
INFO - 2023-05-09 04:43:48 --> Loader Class Initialized
INFO - 2023-05-09 04:43:48 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:48 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:48 --> Model "Login_model" initialized
INFO - 2023-05-09 04:43:48 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:48 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:48 --> Total execution time: 0.0188
INFO - 2023-05-09 04:43:48 --> Config Class Initialized
INFO - 2023-05-09 04:43:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:48 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:48 --> URI Class Initialized
INFO - 2023-05-09 04:43:48 --> Router Class Initialized
INFO - 2023-05-09 04:43:48 --> Output Class Initialized
INFO - 2023-05-09 04:43:48 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:48 --> Input Class Initialized
INFO - 2023-05-09 04:43:48 --> Language Class Initialized
INFO - 2023-05-09 04:43:48 --> Loader Class Initialized
INFO - 2023-05-09 04:43:48 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:48 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:48 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:48 --> Total execution time: 0.0221
INFO - 2023-05-09 04:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:48 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:48 --> Total execution time: 0.0560
INFO - 2023-05-09 04:43:51 --> Config Class Initialized
INFO - 2023-05-09 04:43:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:51 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:51 --> URI Class Initialized
INFO - 2023-05-09 04:43:51 --> Router Class Initialized
INFO - 2023-05-09 04:43:51 --> Output Class Initialized
INFO - 2023-05-09 04:43:51 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:51 --> Input Class Initialized
INFO - 2023-05-09 04:43:51 --> Language Class Initialized
INFO - 2023-05-09 04:43:51 --> Loader Class Initialized
INFO - 2023-05-09 04:43:51 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:51 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:51 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:51 --> Total execution time: 0.0251
INFO - 2023-05-09 04:43:51 --> Config Class Initialized
INFO - 2023-05-09 04:43:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 04:43:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 04:43:51 --> Utf8 Class Initialized
INFO - 2023-05-09 04:43:51 --> URI Class Initialized
INFO - 2023-05-09 04:43:51 --> Router Class Initialized
INFO - 2023-05-09 04:43:51 --> Output Class Initialized
INFO - 2023-05-09 04:43:51 --> Security Class Initialized
DEBUG - 2023-05-09 04:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 04:43:51 --> Input Class Initialized
INFO - 2023-05-09 04:43:51 --> Language Class Initialized
INFO - 2023-05-09 04:43:51 --> Loader Class Initialized
INFO - 2023-05-09 04:43:51 --> Controller Class Initialized
DEBUG - 2023-05-09 04:43:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 04:43:51 --> Database Driver Class Initialized
INFO - 2023-05-09 04:43:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 04:43:51 --> Final output sent to browser
DEBUG - 2023-05-09 04:43:51 --> Total execution time: 0.0534
INFO - 2023-05-09 05:32:22 --> Config Class Initialized
INFO - 2023-05-09 05:32:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:22 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:22 --> URI Class Initialized
INFO - 2023-05-09 05:32:22 --> Router Class Initialized
INFO - 2023-05-09 05:32:22 --> Output Class Initialized
INFO - 2023-05-09 05:32:22 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:22 --> Input Class Initialized
INFO - 2023-05-09 05:32:22 --> Language Class Initialized
INFO - 2023-05-09 05:32:22 --> Loader Class Initialized
INFO - 2023-05-09 05:32:22 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:22 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:22 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:22 --> Total execution time: 0.1109
INFO - 2023-05-09 05:32:22 --> Config Class Initialized
INFO - 2023-05-09 05:32:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:22 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:22 --> URI Class Initialized
INFO - 2023-05-09 05:32:22 --> Router Class Initialized
INFO - 2023-05-09 05:32:22 --> Output Class Initialized
INFO - 2023-05-09 05:32:22 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:22 --> Input Class Initialized
INFO - 2023-05-09 05:32:22 --> Language Class Initialized
INFO - 2023-05-09 05:32:22 --> Loader Class Initialized
INFO - 2023-05-09 05:32:22 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:22 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:22 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:22 --> Total execution time: 0.0210
INFO - 2023-05-09 05:32:31 --> Config Class Initialized
INFO - 2023-05-09 05:32:31 --> Hooks Class Initialized
INFO - 2023-05-09 05:32:31 --> Config Class Initialized
INFO - 2023-05-09 05:32:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:31 --> Utf8 Class Initialized
DEBUG - 2023-05-09 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:31 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:31 --> URI Class Initialized
INFO - 2023-05-09 05:32:31 --> URI Class Initialized
INFO - 2023-05-09 05:32:31 --> Router Class Initialized
INFO - 2023-05-09 05:32:31 --> Output Class Initialized
INFO - 2023-05-09 05:32:31 --> Router Class Initialized
INFO - 2023-05-09 05:32:31 --> Security Class Initialized
INFO - 2023-05-09 05:32:31 --> Output Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:31 --> Security Class Initialized
INFO - 2023-05-09 05:32:31 --> Input Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:31 --> Language Class Initialized
INFO - 2023-05-09 05:32:31 --> Input Class Initialized
INFO - 2023-05-09 05:32:31 --> Loader Class Initialized
INFO - 2023-05-09 05:32:31 --> Language Class Initialized
INFO - 2023-05-09 05:32:31 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:31 --> Loader Class Initialized
INFO - 2023-05-09 05:32:31 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:31 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:31 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:31 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:31 --> Total execution time: 0.0163
INFO - 2023-05-09 05:32:31 --> Config Class Initialized
INFO - 2023-05-09 05:32:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:31 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:31 --> URI Class Initialized
INFO - 2023-05-09 05:32:31 --> Router Class Initialized
INFO - 2023-05-09 05:32:31 --> Output Class Initialized
INFO - 2023-05-09 05:32:31 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:31 --> Input Class Initialized
INFO - 2023-05-09 05:32:31 --> Language Class Initialized
INFO - 2023-05-09 05:32:31 --> Loader Class Initialized
INFO - 2023-05-09 05:32:31 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:31 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:31 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:31 --> Total execution time: 0.0262
INFO - 2023-05-09 05:32:31 --> Config Class Initialized
INFO - 2023-05-09 05:32:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:31 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:31 --> URI Class Initialized
INFO - 2023-05-09 05:32:31 --> Router Class Initialized
INFO - 2023-05-09 05:32:31 --> Output Class Initialized
INFO - 2023-05-09 05:32:31 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:31 --> Input Class Initialized
INFO - 2023-05-09 05:32:31 --> Language Class Initialized
INFO - 2023-05-09 05:32:31 --> Loader Class Initialized
INFO - 2023-05-09 05:32:31 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:31 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:31 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:31 --> Total execution time: 0.0201
INFO - 2023-05-09 05:32:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:31 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:31 --> Total execution time: 0.0709
INFO - 2023-05-09 05:32:31 --> Config Class Initialized
INFO - 2023-05-09 05:32:31 --> Config Class Initialized
INFO - 2023-05-09 05:32:31 --> Hooks Class Initialized
INFO - 2023-05-09 05:32:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:31 --> Utf8 Class Initialized
DEBUG - 2023-05-09 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:31 --> URI Class Initialized
INFO - 2023-05-09 05:32:31 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:31 --> Router Class Initialized
INFO - 2023-05-09 05:32:31 --> URI Class Initialized
INFO - 2023-05-09 05:32:31 --> Output Class Initialized
INFO - 2023-05-09 05:32:31 --> Security Class Initialized
INFO - 2023-05-09 05:32:31 --> Router Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:31 --> Output Class Initialized
INFO - 2023-05-09 05:32:31 --> Input Class Initialized
INFO - 2023-05-09 05:32:31 --> Security Class Initialized
INFO - 2023-05-09 05:32:31 --> Language Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:31 --> Input Class Initialized
INFO - 2023-05-09 05:32:31 --> Loader Class Initialized
INFO - 2023-05-09 05:32:31 --> Language Class Initialized
INFO - 2023-05-09 05:32:31 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:31 --> Loader Class Initialized
INFO - 2023-05-09 05:32:31 --> Controller Class Initialized
INFO - 2023-05-09 05:32:31 --> Database Driver Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:31 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:31 --> Total execution time: 0.0048
INFO - 2023-05-09 05:32:31 --> Config Class Initialized
INFO - 2023-05-09 05:32:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:31 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:31 --> URI Class Initialized
INFO - 2023-05-09 05:32:31 --> Router Class Initialized
INFO - 2023-05-09 05:32:31 --> Output Class Initialized
INFO - 2023-05-09 05:32:31 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:31 --> Input Class Initialized
INFO - 2023-05-09 05:32:31 --> Language Class Initialized
INFO - 2023-05-09 05:32:31 --> Loader Class Initialized
INFO - 2023-05-09 05:32:31 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:31 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:31 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:31 --> Total execution time: 0.0183
INFO - 2023-05-09 05:32:31 --> Config Class Initialized
INFO - 2023-05-09 05:32:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:31 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:31 --> URI Class Initialized
INFO - 2023-05-09 05:32:31 --> Router Class Initialized
INFO - 2023-05-09 05:32:31 --> Output Class Initialized
INFO - 2023-05-09 05:32:31 --> Model "Login_model" initialized
INFO - 2023-05-09 05:32:31 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:31 --> Input Class Initialized
INFO - 2023-05-09 05:32:31 --> Language Class Initialized
INFO - 2023-05-09 05:32:31 --> Loader Class Initialized
INFO - 2023-05-09 05:32:31 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:31 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:31 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:31 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:31 --> Total execution time: 0.0288
INFO - 2023-05-09 05:32:31 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:31 --> Total execution time: 0.0191
INFO - 2023-05-09 05:32:34 --> Config Class Initialized
INFO - 2023-05-09 05:32:34 --> Hooks Class Initialized
INFO - 2023-05-09 05:32:34 --> Config Class Initialized
INFO - 2023-05-09 05:32:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 05:32:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:34 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:34 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:34 --> URI Class Initialized
INFO - 2023-05-09 05:32:34 --> URI Class Initialized
INFO - 2023-05-09 05:32:34 --> Router Class Initialized
INFO - 2023-05-09 05:32:34 --> Router Class Initialized
INFO - 2023-05-09 05:32:34 --> Output Class Initialized
INFO - 2023-05-09 05:32:34 --> Output Class Initialized
INFO - 2023-05-09 05:32:34 --> Security Class Initialized
INFO - 2023-05-09 05:32:34 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 05:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:34 --> Input Class Initialized
INFO - 2023-05-09 05:32:34 --> Input Class Initialized
INFO - 2023-05-09 05:32:34 --> Language Class Initialized
INFO - 2023-05-09 05:32:34 --> Language Class Initialized
INFO - 2023-05-09 05:32:34 --> Loader Class Initialized
INFO - 2023-05-09 05:32:34 --> Loader Class Initialized
INFO - 2023-05-09 05:32:34 --> Controller Class Initialized
INFO - 2023-05-09 05:32:34 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 05:32:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:34 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:34 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:34 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:34 --> Total execution time: 0.0295
INFO - 2023-05-09 05:32:34 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:34 --> Total execution time: 0.0397
INFO - 2023-05-09 05:32:35 --> Config Class Initialized
INFO - 2023-05-09 05:32:35 --> Config Class Initialized
INFO - 2023-05-09 05:32:35 --> Hooks Class Initialized
INFO - 2023-05-09 05:32:35 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:35 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 05:32:35 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:35 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:35 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:35 --> URI Class Initialized
INFO - 2023-05-09 05:32:35 --> URI Class Initialized
INFO - 2023-05-09 05:32:35 --> Router Class Initialized
INFO - 2023-05-09 05:32:35 --> Router Class Initialized
INFO - 2023-05-09 05:32:35 --> Output Class Initialized
INFO - 2023-05-09 05:32:35 --> Output Class Initialized
INFO - 2023-05-09 05:32:35 --> Security Class Initialized
INFO - 2023-05-09 05:32:35 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:35 --> Input Class Initialized
DEBUG - 2023-05-09 05:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:35 --> Input Class Initialized
INFO - 2023-05-09 05:32:35 --> Language Class Initialized
INFO - 2023-05-09 05:32:35 --> Language Class Initialized
INFO - 2023-05-09 05:32:35 --> Loader Class Initialized
INFO - 2023-05-09 05:32:35 --> Loader Class Initialized
INFO - 2023-05-09 05:32:35 --> Controller Class Initialized
INFO - 2023-05-09 05:32:35 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 05:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:35 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:35 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:35 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:35 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:35 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:35 --> Total execution time: 0.0203
INFO - 2023-05-09 05:32:35 --> Config Class Initialized
INFO - 2023-05-09 05:32:35 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:35 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:35 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:35 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:35 --> URI Class Initialized
INFO - 2023-05-09 05:32:35 --> Router Class Initialized
INFO - 2023-05-09 05:32:35 --> Output Class Initialized
INFO - 2023-05-09 05:32:35 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:35 --> Input Class Initialized
INFO - 2023-05-09 05:32:35 --> Language Class Initialized
INFO - 2023-05-09 05:32:35 --> Loader Class Initialized
INFO - 2023-05-09 05:32:35 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:35 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:35 --> Model "Login_model" initialized
INFO - 2023-05-09 05:32:35 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:35 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:35 --> Total execution time: 0.0825
INFO - 2023-05-09 05:32:35 --> Config Class Initialized
INFO - 2023-05-09 05:32:35 --> Hooks Class Initialized
DEBUG - 2023-05-09 05:32:35 --> UTF-8 Support Enabled
INFO - 2023-05-09 05:32:35 --> Utf8 Class Initialized
INFO - 2023-05-09 05:32:35 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:35 --> Total execution time: 0.0935
INFO - 2023-05-09 05:32:35 --> URI Class Initialized
INFO - 2023-05-09 05:32:35 --> Router Class Initialized
INFO - 2023-05-09 05:32:35 --> Output Class Initialized
INFO - 2023-05-09 05:32:35 --> Security Class Initialized
DEBUG - 2023-05-09 05:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 05:32:35 --> Input Class Initialized
INFO - 2023-05-09 05:32:35 --> Language Class Initialized
INFO - 2023-05-09 05:32:35 --> Loader Class Initialized
INFO - 2023-05-09 05:32:35 --> Controller Class Initialized
DEBUG - 2023-05-09 05:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 05:32:35 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:35 --> Model "Cluster_model" initialized
INFO - 2023-05-09 05:32:35 --> Database Driver Class Initialized
INFO - 2023-05-09 05:32:35 --> Model "Login_model" initialized
INFO - 2023-05-09 05:32:35 --> Final output sent to browser
DEBUG - 2023-05-09 05:32:35 --> Total execution time: 0.0763
INFO - 2023-05-09 06:06:57 --> Config Class Initialized
INFO - 2023-05-09 06:06:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:06:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:06:57 --> Utf8 Class Initialized
INFO - 2023-05-09 06:06:57 --> URI Class Initialized
INFO - 2023-05-09 06:06:57 --> Router Class Initialized
INFO - 2023-05-09 06:06:57 --> Output Class Initialized
INFO - 2023-05-09 06:06:57 --> Security Class Initialized
DEBUG - 2023-05-09 06:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:06:57 --> Input Class Initialized
INFO - 2023-05-09 06:06:57 --> Language Class Initialized
INFO - 2023-05-09 06:06:57 --> Loader Class Initialized
INFO - 2023-05-09 06:06:57 --> Controller Class Initialized
DEBUG - 2023-05-09 06:06:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:06:57 --> Database Driver Class Initialized
INFO - 2023-05-09 06:06:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:06:57 --> Final output sent to browser
DEBUG - 2023-05-09 06:06:57 --> Total execution time: 0.0212
INFO - 2023-05-09 06:06:57 --> Config Class Initialized
INFO - 2023-05-09 06:06:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:06:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:06:57 --> Utf8 Class Initialized
INFO - 2023-05-09 06:06:57 --> URI Class Initialized
INFO - 2023-05-09 06:06:57 --> Router Class Initialized
INFO - 2023-05-09 06:06:57 --> Output Class Initialized
INFO - 2023-05-09 06:06:57 --> Security Class Initialized
DEBUG - 2023-05-09 06:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:06:57 --> Input Class Initialized
INFO - 2023-05-09 06:06:57 --> Language Class Initialized
INFO - 2023-05-09 06:06:57 --> Loader Class Initialized
INFO - 2023-05-09 06:06:57 --> Controller Class Initialized
DEBUG - 2023-05-09 06:06:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:06:57 --> Database Driver Class Initialized
INFO - 2023-05-09 06:06:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:06:57 --> Final output sent to browser
DEBUG - 2023-05-09 06:06:57 --> Total execution time: 0.0539
INFO - 2023-05-09 06:07:02 --> Config Class Initialized
INFO - 2023-05-09 06:07:02 --> Hooks Class Initialized
INFO - 2023-05-09 06:07:02 --> Config Class Initialized
INFO - 2023-05-09 06:07:02 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 06:07:02 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:02 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:02 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:02 --> URI Class Initialized
INFO - 2023-05-09 06:07:02 --> URI Class Initialized
INFO - 2023-05-09 06:07:02 --> Router Class Initialized
INFO - 2023-05-09 06:07:02 --> Output Class Initialized
INFO - 2023-05-09 06:07:02 --> Router Class Initialized
INFO - 2023-05-09 06:07:02 --> Security Class Initialized
INFO - 2023-05-09 06:07:02 --> Output Class Initialized
DEBUG - 2023-05-09 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:02 --> Security Class Initialized
INFO - 2023-05-09 06:07:02 --> Input Class Initialized
DEBUG - 2023-05-09 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:02 --> Language Class Initialized
INFO - 2023-05-09 06:07:02 --> Input Class Initialized
INFO - 2023-05-09 06:07:02 --> Language Class Initialized
INFO - 2023-05-09 06:07:02 --> Loader Class Initialized
INFO - 2023-05-09 06:07:02 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:02 --> Loader Class Initialized
INFO - 2023-05-09 06:07:02 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:02 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:02 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:02 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:02 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:02 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:02 --> Total execution time: 0.0206
INFO - 2023-05-09 06:07:02 --> Config Class Initialized
INFO - 2023-05-09 06:07:02 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:02 --> Total execution time: 0.0249
INFO - 2023-05-09 06:07:02 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:02 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:02 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:02 --> URI Class Initialized
INFO - 2023-05-09 06:07:02 --> Router Class Initialized
INFO - 2023-05-09 06:07:02 --> Config Class Initialized
INFO - 2023-05-09 06:07:02 --> Hooks Class Initialized
INFO - 2023-05-09 06:07:02 --> Output Class Initialized
DEBUG - 2023-05-09 06:07:02 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:02 --> Security Class Initialized
INFO - 2023-05-09 06:07:02 --> Utf8 Class Initialized
DEBUG - 2023-05-09 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:02 --> URI Class Initialized
INFO - 2023-05-09 06:07:02 --> Input Class Initialized
INFO - 2023-05-09 06:07:02 --> Language Class Initialized
INFO - 2023-05-09 06:07:02 --> Router Class Initialized
INFO - 2023-05-09 06:07:02 --> Loader Class Initialized
INFO - 2023-05-09 06:07:02 --> Output Class Initialized
INFO - 2023-05-09 06:07:02 --> Controller Class Initialized
INFO - 2023-05-09 06:07:02 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:02 --> Input Class Initialized
INFO - 2023-05-09 06:07:02 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:02 --> Language Class Initialized
INFO - 2023-05-09 06:07:02 --> Loader Class Initialized
INFO - 2023-05-09 06:07:02 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:02 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:02 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:02 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:02 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:02 --> Total execution time: 0.0958
INFO - 2023-05-09 06:07:02 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:02 --> Total execution time: 0.0618
INFO - 2023-05-09 06:07:04 --> Config Class Initialized
INFO - 2023-05-09 06:07:04 --> Config Class Initialized
INFO - 2023-05-09 06:07:04 --> Hooks Class Initialized
INFO - 2023-05-09 06:07:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:04 --> Utf8 Class Initialized
DEBUG - 2023-05-09 06:07:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:04 --> URI Class Initialized
INFO - 2023-05-09 06:07:04 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:04 --> Router Class Initialized
INFO - 2023-05-09 06:07:04 --> URI Class Initialized
INFO - 2023-05-09 06:07:04 --> Output Class Initialized
INFO - 2023-05-09 06:07:04 --> Router Class Initialized
INFO - 2023-05-09 06:07:04 --> Security Class Initialized
INFO - 2023-05-09 06:07:04 --> Output Class Initialized
DEBUG - 2023-05-09 06:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:04 --> Security Class Initialized
INFO - 2023-05-09 06:07:04 --> Input Class Initialized
DEBUG - 2023-05-09 06:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:04 --> Language Class Initialized
INFO - 2023-05-09 06:07:04 --> Input Class Initialized
INFO - 2023-05-09 06:07:04 --> Language Class Initialized
INFO - 2023-05-09 06:07:04 --> Loader Class Initialized
INFO - 2023-05-09 06:07:04 --> Loader Class Initialized
INFO - 2023-05-09 06:07:04 --> Controller Class Initialized
INFO - 2023-05-09 06:07:04 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:07:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:04 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:04 --> Total execution time: 0.0022
INFO - 2023-05-09 06:07:04 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:04 --> Config Class Initialized
INFO - 2023-05-09 06:07:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:04 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:04 --> URI Class Initialized
INFO - 2023-05-09 06:07:04 --> Router Class Initialized
INFO - 2023-05-09 06:07:04 --> Output Class Initialized
INFO - 2023-05-09 06:07:04 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:04 --> Input Class Initialized
INFO - 2023-05-09 06:07:04 --> Language Class Initialized
INFO - 2023-05-09 06:07:04 --> Loader Class Initialized
INFO - 2023-05-09 06:07:04 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:04 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:04 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:04 --> Total execution time: 0.0509
INFO - 2023-05-09 06:07:04 --> Config Class Initialized
INFO - 2023-05-09 06:07:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:04 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:04 --> URI Class Initialized
INFO - 2023-05-09 06:07:04 --> Router Class Initialized
INFO - 2023-05-09 06:07:04 --> Output Class Initialized
INFO - 2023-05-09 06:07:04 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:04 --> Input Class Initialized
INFO - 2023-05-09 06:07:04 --> Language Class Initialized
INFO - 2023-05-09 06:07:04 --> Model "Login_model" initialized
INFO - 2023-05-09 06:07:04 --> Loader Class Initialized
INFO - 2023-05-09 06:07:04 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:04 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:04 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:04 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:04 --> Total execution time: 0.0629
INFO - 2023-05-09 06:07:04 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:04 --> Total execution time: 0.0161
INFO - 2023-05-09 06:07:52 --> Config Class Initialized
INFO - 2023-05-09 06:07:52 --> Config Class Initialized
INFO - 2023-05-09 06:07:52 --> Hooks Class Initialized
INFO - 2023-05-09 06:07:52 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 06:07:52 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:52 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:52 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:52 --> URI Class Initialized
INFO - 2023-05-09 06:07:52 --> URI Class Initialized
INFO - 2023-05-09 06:07:52 --> Router Class Initialized
INFO - 2023-05-09 06:07:52 --> Router Class Initialized
INFO - 2023-05-09 06:07:52 --> Output Class Initialized
INFO - 2023-05-09 06:07:52 --> Output Class Initialized
INFO - 2023-05-09 06:07:52 --> Security Class Initialized
INFO - 2023-05-09 06:07:52 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:52 --> Input Class Initialized
INFO - 2023-05-09 06:07:52 --> Input Class Initialized
INFO - 2023-05-09 06:07:52 --> Language Class Initialized
INFO - 2023-05-09 06:07:52 --> Language Class Initialized
INFO - 2023-05-09 06:07:52 --> Loader Class Initialized
INFO - 2023-05-09 06:07:52 --> Loader Class Initialized
INFO - 2023-05-09 06:07:52 --> Controller Class Initialized
INFO - 2023-05-09 06:07:52 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:07:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:52 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:52 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:52 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:52 --> Total execution time: 0.0562
INFO - 2023-05-09 06:07:52 --> Config Class Initialized
INFO - 2023-05-09 06:07:52 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:52 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:52 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:52 --> URI Class Initialized
INFO - 2023-05-09 06:07:52 --> Router Class Initialized
INFO - 2023-05-09 06:07:52 --> Output Class Initialized
INFO - 2023-05-09 06:07:52 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:52 --> Input Class Initialized
INFO - 2023-05-09 06:07:52 --> Language Class Initialized
INFO - 2023-05-09 06:07:52 --> Loader Class Initialized
INFO - 2023-05-09 06:07:52 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:52 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:52 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:52 --> Total execution time: 0.0885
INFO - 2023-05-09 06:07:52 --> Config Class Initialized
INFO - 2023-05-09 06:07:52 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:52 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:52 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:52 --> URI Class Initialized
INFO - 2023-05-09 06:07:52 --> Router Class Initialized
INFO - 2023-05-09 06:07:52 --> Output Class Initialized
INFO - 2023-05-09 06:07:52 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:52 --> Input Class Initialized
INFO - 2023-05-09 06:07:52 --> Language Class Initialized
INFO - 2023-05-09 06:07:52 --> Loader Class Initialized
INFO - 2023-05-09 06:07:52 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:52 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:52 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:52 --> Total execution time: 0.0450
INFO - 2023-05-09 06:07:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:52 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:52 --> Total execution time: 0.0890
INFO - 2023-05-09 06:07:53 --> Config Class Initialized
INFO - 2023-05-09 06:07:53 --> Config Class Initialized
INFO - 2023-05-09 06:07:53 --> Hooks Class Initialized
INFO - 2023-05-09 06:07:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:53 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 06:07:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:53 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:53 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:53 --> URI Class Initialized
INFO - 2023-05-09 06:07:53 --> URI Class Initialized
INFO - 2023-05-09 06:07:53 --> Router Class Initialized
INFO - 2023-05-09 06:07:53 --> Router Class Initialized
INFO - 2023-05-09 06:07:53 --> Output Class Initialized
INFO - 2023-05-09 06:07:53 --> Output Class Initialized
INFO - 2023-05-09 06:07:53 --> Security Class Initialized
INFO - 2023-05-09 06:07:53 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:53 --> Input Class Initialized
INFO - 2023-05-09 06:07:53 --> Input Class Initialized
INFO - 2023-05-09 06:07:53 --> Language Class Initialized
INFO - 2023-05-09 06:07:53 --> Language Class Initialized
INFO - 2023-05-09 06:07:53 --> Loader Class Initialized
INFO - 2023-05-09 06:07:53 --> Loader Class Initialized
INFO - 2023-05-09 06:07:53 --> Controller Class Initialized
INFO - 2023-05-09 06:07:53 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:07:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:53 --> Final output sent to browser
INFO - 2023-05-09 06:07:53 --> Database Driver Class Initialized
DEBUG - 2023-05-09 06:07:53 --> Total execution time: 0.0022
INFO - 2023-05-09 06:07:53 --> Config Class Initialized
INFO - 2023-05-09 06:07:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:53 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:53 --> URI Class Initialized
INFO - 2023-05-09 06:07:53 --> Router Class Initialized
INFO - 2023-05-09 06:07:53 --> Output Class Initialized
INFO - 2023-05-09 06:07:53 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:53 --> Input Class Initialized
INFO - 2023-05-09 06:07:53 --> Language Class Initialized
INFO - 2023-05-09 06:07:53 --> Loader Class Initialized
INFO - 2023-05-09 06:07:53 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:53 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:53 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:53 --> Model "Login_model" initialized
INFO - 2023-05-09 06:07:53 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:53 --> Total execution time: 0.0148
INFO - 2023-05-09 06:07:53 --> Config Class Initialized
INFO - 2023-05-09 06:07:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:53 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:53 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:53 --> URI Class Initialized
INFO - 2023-05-09 06:07:53 --> Router Class Initialized
INFO - 2023-05-09 06:07:53 --> Output Class Initialized
INFO - 2023-05-09 06:07:53 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:53 --> Input Class Initialized
INFO - 2023-05-09 06:07:53 --> Language Class Initialized
INFO - 2023-05-09 06:07:53 --> Loader Class Initialized
INFO - 2023-05-09 06:07:53 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:53 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:53 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:53 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:53 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:53 --> Total execution time: 0.0229
INFO - 2023-05-09 06:07:53 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:53 --> Total execution time: 0.0147
INFO - 2023-05-09 06:07:56 --> Config Class Initialized
INFO - 2023-05-09 06:07:56 --> Config Class Initialized
INFO - 2023-05-09 06:07:56 --> Hooks Class Initialized
INFO - 2023-05-09 06:07:56 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:56 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:56 --> Utf8 Class Initialized
DEBUG - 2023-05-09 06:07:56 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:56 --> URI Class Initialized
INFO - 2023-05-09 06:07:56 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:56 --> Router Class Initialized
INFO - 2023-05-09 06:07:56 --> URI Class Initialized
INFO - 2023-05-09 06:07:56 --> Output Class Initialized
INFO - 2023-05-09 06:07:56 --> Router Class Initialized
INFO - 2023-05-09 06:07:56 --> Security Class Initialized
INFO - 2023-05-09 06:07:56 --> Output Class Initialized
DEBUG - 2023-05-09 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:56 --> Security Class Initialized
INFO - 2023-05-09 06:07:56 --> Input Class Initialized
DEBUG - 2023-05-09 06:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:56 --> Language Class Initialized
INFO - 2023-05-09 06:07:56 --> Input Class Initialized
INFO - 2023-05-09 06:07:56 --> Language Class Initialized
INFO - 2023-05-09 06:07:56 --> Loader Class Initialized
INFO - 2023-05-09 06:07:56 --> Loader Class Initialized
INFO - 2023-05-09 06:07:56 --> Controller Class Initialized
INFO - 2023-05-09 06:07:56 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:07:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:56 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:56 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:56 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:56 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:56 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:56 --> Total execution time: 0.0345
INFO - 2023-05-09 06:07:56 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:56 --> Total execution time: 0.0412
INFO - 2023-05-09 06:07:57 --> Config Class Initialized
INFO - 2023-05-09 06:07:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:57 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:57 --> URI Class Initialized
INFO - 2023-05-09 06:07:57 --> Router Class Initialized
INFO - 2023-05-09 06:07:57 --> Output Class Initialized
INFO - 2023-05-09 06:07:57 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:57 --> Input Class Initialized
INFO - 2023-05-09 06:07:57 --> Language Class Initialized
INFO - 2023-05-09 06:07:57 --> Loader Class Initialized
INFO - 2023-05-09 06:07:57 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:57 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:57 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:57 --> Total execution time: 0.0139
INFO - 2023-05-09 06:07:57 --> Config Class Initialized
INFO - 2023-05-09 06:07:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:07:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:07:57 --> Utf8 Class Initialized
INFO - 2023-05-09 06:07:57 --> URI Class Initialized
INFO - 2023-05-09 06:07:57 --> Router Class Initialized
INFO - 2023-05-09 06:07:57 --> Output Class Initialized
INFO - 2023-05-09 06:07:57 --> Security Class Initialized
DEBUG - 2023-05-09 06:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:07:57 --> Input Class Initialized
INFO - 2023-05-09 06:07:57 --> Language Class Initialized
INFO - 2023-05-09 06:07:57 --> Loader Class Initialized
INFO - 2023-05-09 06:07:57 --> Controller Class Initialized
DEBUG - 2023-05-09 06:07:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:07:57 --> Database Driver Class Initialized
INFO - 2023-05-09 06:07:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:07:57 --> Final output sent to browser
DEBUG - 2023-05-09 06:07:57 --> Total execution time: 0.0122
INFO - 2023-05-09 06:08:19 --> Config Class Initialized
INFO - 2023-05-09 06:08:19 --> Config Class Initialized
INFO - 2023-05-09 06:08:19 --> Hooks Class Initialized
INFO - 2023-05-09 06:08:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 06:08:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:19 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:19 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:19 --> URI Class Initialized
INFO - 2023-05-09 06:08:19 --> URI Class Initialized
INFO - 2023-05-09 06:08:19 --> Router Class Initialized
INFO - 2023-05-09 06:08:19 --> Router Class Initialized
INFO - 2023-05-09 06:08:19 --> Output Class Initialized
INFO - 2023-05-09 06:08:19 --> Output Class Initialized
INFO - 2023-05-09 06:08:19 --> Security Class Initialized
INFO - 2023-05-09 06:08:19 --> Security Class Initialized
DEBUG - 2023-05-09 06:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 06:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:19 --> Input Class Initialized
INFO - 2023-05-09 06:08:19 --> Input Class Initialized
INFO - 2023-05-09 06:08:19 --> Language Class Initialized
INFO - 2023-05-09 06:08:19 --> Language Class Initialized
INFO - 2023-05-09 06:08:19 --> Loader Class Initialized
INFO - 2023-05-09 06:08:19 --> Loader Class Initialized
INFO - 2023-05-09 06:08:19 --> Controller Class Initialized
INFO - 2023-05-09 06:08:19 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:19 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:19 --> Total execution time: 0.0026
INFO - 2023-05-09 06:08:19 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:19 --> Config Class Initialized
INFO - 2023-05-09 06:08:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:19 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:19 --> URI Class Initialized
INFO - 2023-05-09 06:08:19 --> Router Class Initialized
INFO - 2023-05-09 06:08:19 --> Output Class Initialized
INFO - 2023-05-09 06:08:19 --> Security Class Initialized
DEBUG - 2023-05-09 06:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:19 --> Input Class Initialized
INFO - 2023-05-09 06:08:19 --> Language Class Initialized
INFO - 2023-05-09 06:08:19 --> Loader Class Initialized
INFO - 2023-05-09 06:08:19 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:19 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:19 --> Model "Login_model" initialized
INFO - 2023-05-09 06:08:19 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:19 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:19 --> Total execution time: 0.0176
INFO - 2023-05-09 06:08:19 --> Config Class Initialized
INFO - 2023-05-09 06:08:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:19 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:19 --> URI Class Initialized
INFO - 2023-05-09 06:08:19 --> Router Class Initialized
INFO - 2023-05-09 06:08:19 --> Output Class Initialized
INFO - 2023-05-09 06:08:19 --> Security Class Initialized
DEBUG - 2023-05-09 06:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:19 --> Input Class Initialized
INFO - 2023-05-09 06:08:19 --> Language Class Initialized
INFO - 2023-05-09 06:08:19 --> Loader Class Initialized
INFO - 2023-05-09 06:08:19 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:19 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:19 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:19 --> Total execution time: 0.0256
INFO - 2023-05-09 06:08:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:19 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:19 --> Total execution time: 0.0593
INFO - 2023-05-09 06:08:21 --> Config Class Initialized
INFO - 2023-05-09 06:08:21 --> Hooks Class Initialized
INFO - 2023-05-09 06:08:21 --> Config Class Initialized
INFO - 2023-05-09 06:08:21 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 06:08:21 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:21 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:21 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:21 --> URI Class Initialized
INFO - 2023-05-09 06:08:21 --> URI Class Initialized
INFO - 2023-05-09 06:08:21 --> Router Class Initialized
INFO - 2023-05-09 06:08:21 --> Router Class Initialized
INFO - 2023-05-09 06:08:21 --> Output Class Initialized
INFO - 2023-05-09 06:08:21 --> Output Class Initialized
INFO - 2023-05-09 06:08:21 --> Security Class Initialized
INFO - 2023-05-09 06:08:21 --> Security Class Initialized
DEBUG - 2023-05-09 06:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 06:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:21 --> Input Class Initialized
INFO - 2023-05-09 06:08:21 --> Input Class Initialized
INFO - 2023-05-09 06:08:21 --> Language Class Initialized
INFO - 2023-05-09 06:08:21 --> Language Class Initialized
INFO - 2023-05-09 06:08:21 --> Loader Class Initialized
INFO - 2023-05-09 06:08:21 --> Loader Class Initialized
INFO - 2023-05-09 06:08:21 --> Controller Class Initialized
INFO - 2023-05-09 06:08:21 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:21 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:21 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:21 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:21 --> Total execution time: 0.0201
INFO - 2023-05-09 06:08:21 --> Config Class Initialized
INFO - 2023-05-09 06:08:21 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:21 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:21 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:21 --> URI Class Initialized
INFO - 2023-05-09 06:08:21 --> Router Class Initialized
INFO - 2023-05-09 06:08:21 --> Output Class Initialized
INFO - 2023-05-09 06:08:21 --> Security Class Initialized
DEBUG - 2023-05-09 06:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:21 --> Input Class Initialized
INFO - 2023-05-09 06:08:21 --> Language Class Initialized
INFO - 2023-05-09 06:08:21 --> Loader Class Initialized
INFO - 2023-05-09 06:08:21 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:21 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:21 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:21 --> Total execution time: 0.0277
INFO - 2023-05-09 06:08:21 --> Config Class Initialized
INFO - 2023-05-09 06:08:21 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:21 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:21 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:21 --> URI Class Initialized
INFO - 2023-05-09 06:08:21 --> Router Class Initialized
INFO - 2023-05-09 06:08:21 --> Output Class Initialized
INFO - 2023-05-09 06:08:21 --> Security Class Initialized
DEBUG - 2023-05-09 06:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:21 --> Input Class Initialized
INFO - 2023-05-09 06:08:21 --> Language Class Initialized
INFO - 2023-05-09 06:08:21 --> Loader Class Initialized
INFO - 2023-05-09 06:08:21 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:21 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:21 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:21 --> Total execution time: 0.0157
INFO - 2023-05-09 06:08:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:21 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:21 --> Total execution time: 0.0626
INFO - 2023-05-09 06:08:22 --> Config Class Initialized
INFO - 2023-05-09 06:08:22 --> Config Class Initialized
INFO - 2023-05-09 06:08:22 --> Hooks Class Initialized
INFO - 2023-05-09 06:08:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:22 --> Utf8 Class Initialized
DEBUG - 2023-05-09 06:08:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:22 --> URI Class Initialized
INFO - 2023-05-09 06:08:22 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:22 --> Router Class Initialized
INFO - 2023-05-09 06:08:22 --> URI Class Initialized
INFO - 2023-05-09 06:08:22 --> Output Class Initialized
INFO - 2023-05-09 06:08:22 --> Router Class Initialized
INFO - 2023-05-09 06:08:22 --> Security Class Initialized
INFO - 2023-05-09 06:08:22 --> Output Class Initialized
DEBUG - 2023-05-09 06:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:22 --> Security Class Initialized
INFO - 2023-05-09 06:08:22 --> Input Class Initialized
INFO - 2023-05-09 06:08:22 --> Language Class Initialized
DEBUG - 2023-05-09 06:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:22 --> Input Class Initialized
INFO - 2023-05-09 06:08:22 --> Loader Class Initialized
INFO - 2023-05-09 06:08:22 --> Language Class Initialized
INFO - 2023-05-09 06:08:22 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:22 --> Loader Class Initialized
INFO - 2023-05-09 06:08:22 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:22 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:22 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:22 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:22 --> Total execution time: 0.0410
INFO - 2023-05-09 06:08:22 --> Config Class Initialized
INFO - 2023-05-09 06:08:22 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:22 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:22 --> URI Class Initialized
INFO - 2023-05-09 06:08:22 --> Router Class Initialized
INFO - 2023-05-09 06:08:22 --> Output Class Initialized
INFO - 2023-05-09 06:08:22 --> Security Class Initialized
DEBUG - 2023-05-09 06:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:22 --> Input Class Initialized
INFO - 2023-05-09 06:08:22 --> Language Class Initialized
INFO - 2023-05-09 06:08:22 --> Loader Class Initialized
INFO - 2023-05-09 06:08:22 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:22 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:22 --> Model "Login_model" initialized
INFO - 2023-05-09 06:08:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:22 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:22 --> Total execution time: 0.0516
INFO - 2023-05-09 06:08:22 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:22 --> Total execution time: 0.1057
INFO - 2023-05-09 06:08:22 --> Config Class Initialized
INFO - 2023-05-09 06:08:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:08:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:08:22 --> Utf8 Class Initialized
INFO - 2023-05-09 06:08:22 --> URI Class Initialized
INFO - 2023-05-09 06:08:22 --> Router Class Initialized
INFO - 2023-05-09 06:08:22 --> Output Class Initialized
INFO - 2023-05-09 06:08:22 --> Security Class Initialized
DEBUG - 2023-05-09 06:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:08:22 --> Input Class Initialized
INFO - 2023-05-09 06:08:22 --> Language Class Initialized
INFO - 2023-05-09 06:08:22 --> Loader Class Initialized
INFO - 2023-05-09 06:08:22 --> Controller Class Initialized
DEBUG - 2023-05-09 06:08:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:08:22 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:08:22 --> Database Driver Class Initialized
INFO - 2023-05-09 06:08:22 --> Model "Login_model" initialized
INFO - 2023-05-09 06:08:22 --> Final output sent to browser
DEBUG - 2023-05-09 06:08:22 --> Total execution time: 0.0406
INFO - 2023-05-09 06:31:24 --> Config Class Initialized
INFO - 2023-05-09 06:31:24 --> Config Class Initialized
INFO - 2023-05-09 06:31:24 --> Hooks Class Initialized
INFO - 2023-05-09 06:31:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:31:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 06:31:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:31:24 --> Utf8 Class Initialized
INFO - 2023-05-09 06:31:24 --> Utf8 Class Initialized
INFO - 2023-05-09 06:31:24 --> URI Class Initialized
INFO - 2023-05-09 06:31:24 --> URI Class Initialized
INFO - 2023-05-09 06:31:24 --> Router Class Initialized
INFO - 2023-05-09 06:31:24 --> Router Class Initialized
INFO - 2023-05-09 06:31:24 --> Output Class Initialized
INFO - 2023-05-09 06:31:24 --> Output Class Initialized
INFO - 2023-05-09 06:31:24 --> Security Class Initialized
INFO - 2023-05-09 06:31:24 --> Security Class Initialized
DEBUG - 2023-05-09 06:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 06:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:31:24 --> Input Class Initialized
INFO - 2023-05-09 06:31:24 --> Input Class Initialized
INFO - 2023-05-09 06:31:24 --> Language Class Initialized
INFO - 2023-05-09 06:31:24 --> Language Class Initialized
INFO - 2023-05-09 06:31:24 --> Loader Class Initialized
INFO - 2023-05-09 06:31:24 --> Loader Class Initialized
INFO - 2023-05-09 06:31:24 --> Controller Class Initialized
INFO - 2023-05-09 06:31:24 --> Controller Class Initialized
DEBUG - 2023-05-09 06:31:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:31:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:31:24 --> Database Driver Class Initialized
INFO - 2023-05-09 06:31:24 --> Database Driver Class Initialized
INFO - 2023-05-09 06:31:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:31:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:31:24 --> Final output sent to browser
DEBUG - 2023-05-09 06:31:24 --> Total execution time: 0.1005
INFO - 2023-05-09 06:31:24 --> Config Class Initialized
INFO - 2023-05-09 06:31:24 --> Database Driver Class Initialized
INFO - 2023-05-09 06:31:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:31:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:31:24 --> Utf8 Class Initialized
INFO - 2023-05-09 06:31:24 --> URI Class Initialized
INFO - 2023-05-09 06:31:24 --> Router Class Initialized
INFO - 2023-05-09 06:31:24 --> Output Class Initialized
INFO - 2023-05-09 06:31:24 --> Security Class Initialized
DEBUG - 2023-05-09 06:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:31:24 --> Input Class Initialized
INFO - 2023-05-09 06:31:24 --> Language Class Initialized
INFO - 2023-05-09 06:31:24 --> Loader Class Initialized
INFO - 2023-05-09 06:31:24 --> Controller Class Initialized
DEBUG - 2023-05-09 06:31:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:31:24 --> Database Driver Class Initialized
INFO - 2023-05-09 06:31:24 --> Model "Login_model" initialized
INFO - 2023-05-09 06:31:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:31:24 --> Final output sent to browser
DEBUG - 2023-05-09 06:31:24 --> Total execution time: 0.0589
INFO - 2023-05-09 06:31:24 --> Final output sent to browser
DEBUG - 2023-05-09 06:31:24 --> Total execution time: 0.1650
INFO - 2023-05-09 06:31:24 --> Config Class Initialized
INFO - 2023-05-09 06:31:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:31:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:31:24 --> Utf8 Class Initialized
INFO - 2023-05-09 06:31:24 --> URI Class Initialized
INFO - 2023-05-09 06:31:24 --> Router Class Initialized
INFO - 2023-05-09 06:31:24 --> Output Class Initialized
INFO - 2023-05-09 06:31:24 --> Security Class Initialized
DEBUG - 2023-05-09 06:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:31:24 --> Input Class Initialized
INFO - 2023-05-09 06:31:24 --> Language Class Initialized
INFO - 2023-05-09 06:31:24 --> Loader Class Initialized
INFO - 2023-05-09 06:31:24 --> Controller Class Initialized
DEBUG - 2023-05-09 06:31:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:31:24 --> Database Driver Class Initialized
INFO - 2023-05-09 06:31:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:31:24 --> Database Driver Class Initialized
INFO - 2023-05-09 06:31:24 --> Model "Login_model" initialized
INFO - 2023-05-09 06:31:24 --> Final output sent to browser
DEBUG - 2023-05-09 06:31:24 --> Total execution time: 0.0435
INFO - 2023-05-09 06:31:30 --> Config Class Initialized
INFO - 2023-05-09 06:31:30 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:31:30 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:31:30 --> Utf8 Class Initialized
INFO - 2023-05-09 06:31:30 --> URI Class Initialized
INFO - 2023-05-09 06:31:30 --> Router Class Initialized
INFO - 2023-05-09 06:31:30 --> Output Class Initialized
INFO - 2023-05-09 06:31:30 --> Security Class Initialized
DEBUG - 2023-05-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:31:30 --> Input Class Initialized
INFO - 2023-05-09 06:31:30 --> Language Class Initialized
INFO - 2023-05-09 06:31:30 --> Loader Class Initialized
INFO - 2023-05-09 06:31:30 --> Controller Class Initialized
DEBUG - 2023-05-09 06:31:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:31:30 --> Database Driver Class Initialized
INFO - 2023-05-09 06:31:30 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:31:30 --> Config Class Initialized
INFO - 2023-05-09 06:31:30 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:31:30 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:31:30 --> Utf8 Class Initialized
INFO - 2023-05-09 06:31:30 --> URI Class Initialized
INFO - 2023-05-09 06:31:30 --> Router Class Initialized
INFO - 2023-05-09 06:31:30 --> Output Class Initialized
INFO - 2023-05-09 06:31:30 --> Security Class Initialized
DEBUG - 2023-05-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:31:30 --> Input Class Initialized
INFO - 2023-05-09 06:31:30 --> Language Class Initialized
INFO - 2023-05-09 06:31:30 --> Loader Class Initialized
INFO - 2023-05-09 06:31:30 --> Controller Class Initialized
DEBUG - 2023-05-09 06:31:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:31:30 --> Database Driver Class Initialized
INFO - 2023-05-09 06:31:30 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:32:18 --> Config Class Initialized
INFO - 2023-05-09 06:32:18 --> Config Class Initialized
INFO - 2023-05-09 06:32:18 --> Hooks Class Initialized
INFO - 2023-05-09 06:32:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:32:18 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 06:32:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:32:18 --> Utf8 Class Initialized
INFO - 2023-05-09 06:32:18 --> Utf8 Class Initialized
INFO - 2023-05-09 06:32:18 --> URI Class Initialized
INFO - 2023-05-09 06:32:18 --> URI Class Initialized
INFO - 2023-05-09 06:32:18 --> Router Class Initialized
INFO - 2023-05-09 06:32:18 --> Router Class Initialized
INFO - 2023-05-09 06:32:18 --> Output Class Initialized
INFO - 2023-05-09 06:32:18 --> Output Class Initialized
INFO - 2023-05-09 06:32:18 --> Security Class Initialized
INFO - 2023-05-09 06:32:18 --> Security Class Initialized
DEBUG - 2023-05-09 06:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 06:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:32:18 --> Input Class Initialized
INFO - 2023-05-09 06:32:18 --> Input Class Initialized
INFO - 2023-05-09 06:32:18 --> Language Class Initialized
INFO - 2023-05-09 06:32:18 --> Language Class Initialized
INFO - 2023-05-09 06:32:18 --> Loader Class Initialized
INFO - 2023-05-09 06:32:18 --> Loader Class Initialized
INFO - 2023-05-09 06:32:18 --> Controller Class Initialized
INFO - 2023-05-09 06:32:18 --> Controller Class Initialized
DEBUG - 2023-05-09 06:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 06:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:32:18 --> Database Driver Class Initialized
INFO - 2023-05-09 06:32:18 --> Database Driver Class Initialized
INFO - 2023-05-09 06:32:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:32:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:32:18 --> Final output sent to browser
DEBUG - 2023-05-09 06:32:18 --> Total execution time: 0.0164
INFO - 2023-05-09 06:32:18 --> Config Class Initialized
INFO - 2023-05-09 06:32:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:32:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:32:18 --> Utf8 Class Initialized
INFO - 2023-05-09 06:32:18 --> URI Class Initialized
INFO - 2023-05-09 06:32:18 --> Router Class Initialized
INFO - 2023-05-09 06:32:18 --> Output Class Initialized
INFO - 2023-05-09 06:32:18 --> Security Class Initialized
DEBUG - 2023-05-09 06:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:32:18 --> Input Class Initialized
INFO - 2023-05-09 06:32:18 --> Language Class Initialized
INFO - 2023-05-09 06:32:18 --> Loader Class Initialized
INFO - 2023-05-09 06:32:18 --> Controller Class Initialized
DEBUG - 2023-05-09 06:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:32:18 --> Database Driver Class Initialized
INFO - 2023-05-09 06:32:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 06:32:18 --> Final output sent to browser
DEBUG - 2023-05-09 06:32:18 --> Total execution time: 0.0495
INFO - 2023-05-09 06:32:18 --> Config Class Initialized
INFO - 2023-05-09 06:32:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 06:32:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 06:32:18 --> Utf8 Class Initialized
INFO - 2023-05-09 06:32:18 --> URI Class Initialized
INFO - 2023-05-09 06:32:18 --> Router Class Initialized
INFO - 2023-05-09 06:32:18 --> Output Class Initialized
INFO - 2023-05-09 06:32:18 --> Security Class Initialized
DEBUG - 2023-05-09 06:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 06:32:18 --> Input Class Initialized
INFO - 2023-05-09 06:32:18 --> Language Class Initialized
INFO - 2023-05-09 06:32:18 --> Loader Class Initialized
INFO - 2023-05-09 06:32:18 --> Controller Class Initialized
DEBUG - 2023-05-09 06:32:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 06:32:18 --> Database Driver Class Initialized
INFO - 2023-05-09 06:32:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:46 --> Config Class Initialized
INFO - 2023-05-09 07:43:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 07:43:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:46 --> Utf8 Class Initialized
INFO - 2023-05-09 07:43:46 --> URI Class Initialized
INFO - 2023-05-09 07:43:46 --> Router Class Initialized
INFO - 2023-05-09 07:43:46 --> Output Class Initialized
INFO - 2023-05-09 07:43:46 --> Security Class Initialized
DEBUG - 2023-05-09 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:46 --> Input Class Initialized
INFO - 2023-05-09 07:43:46 --> Language Class Initialized
INFO - 2023-05-09 07:43:46 --> Loader Class Initialized
INFO - 2023-05-09 07:43:46 --> Controller Class Initialized
DEBUG - 2023-05-09 07:43:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:46 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:46 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:46 --> Total execution time: 0.0195
INFO - 2023-05-09 07:43:46 --> Config Class Initialized
INFO - 2023-05-09 07:43:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 07:43:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:46 --> Utf8 Class Initialized
INFO - 2023-05-09 07:43:46 --> URI Class Initialized
INFO - 2023-05-09 07:43:46 --> Router Class Initialized
INFO - 2023-05-09 07:43:46 --> Output Class Initialized
INFO - 2023-05-09 07:43:46 --> Security Class Initialized
DEBUG - 2023-05-09 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:46 --> Input Class Initialized
INFO - 2023-05-09 07:43:46 --> Language Class Initialized
INFO - 2023-05-09 07:43:46 --> Loader Class Initialized
INFO - 2023-05-09 07:43:46 --> Controller Class Initialized
DEBUG - 2023-05-09 07:43:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:46 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:46 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:46 --> Total execution time: 0.0582
INFO - 2023-05-09 07:43:48 --> Config Class Initialized
INFO - 2023-05-09 07:43:48 --> Config Class Initialized
INFO - 2023-05-09 07:43:48 --> Hooks Class Initialized
INFO - 2023-05-09 07:43:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 07:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 07:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:48 --> Utf8 Class Initialized
INFO - 2023-05-09 07:43:48 --> Utf8 Class Initialized
INFO - 2023-05-09 07:43:48 --> URI Class Initialized
INFO - 2023-05-09 07:43:48 --> URI Class Initialized
INFO - 2023-05-09 07:43:48 --> Router Class Initialized
INFO - 2023-05-09 07:43:48 --> Router Class Initialized
INFO - 2023-05-09 07:43:48 --> Output Class Initialized
INFO - 2023-05-09 07:43:48 --> Output Class Initialized
INFO - 2023-05-09 07:43:48 --> Security Class Initialized
INFO - 2023-05-09 07:43:48 --> Security Class Initialized
DEBUG - 2023-05-09 07:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:48 --> Input Class Initialized
INFO - 2023-05-09 07:43:48 --> Input Class Initialized
INFO - 2023-05-09 07:43:48 --> Language Class Initialized
INFO - 2023-05-09 07:43:48 --> Language Class Initialized
INFO - 2023-05-09 07:43:48 --> Loader Class Initialized
INFO - 2023-05-09 07:43:48 --> Controller Class Initialized
DEBUG - 2023-05-09 07:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:48 --> Loader Class Initialized
INFO - 2023-05-09 07:43:48 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:48 --> Controller Class Initialized
DEBUG - 2023-05-09 07:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:48 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:48 --> Final output sent to browser
INFO - 2023-05-09 07:43:48 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:48 --> Total execution time: 0.2459
DEBUG - 2023-05-09 07:43:48 --> Total execution time: 0.2326
INFO - 2023-05-09 07:43:48 --> Config Class Initialized
INFO - 2023-05-09 07:43:48 --> Config Class Initialized
INFO - 2023-05-09 07:43:48 --> Hooks Class Initialized
INFO - 2023-05-09 07:43:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 07:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:48 --> Utf8 Class Initialized
DEBUG - 2023-05-09 07:43:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:48 --> URI Class Initialized
INFO - 2023-05-09 07:43:48 --> Utf8 Class Initialized
INFO - 2023-05-09 07:43:48 --> Router Class Initialized
INFO - 2023-05-09 07:43:48 --> URI Class Initialized
INFO - 2023-05-09 07:43:48 --> Output Class Initialized
INFO - 2023-05-09 07:43:48 --> Router Class Initialized
INFO - 2023-05-09 07:43:48 --> Security Class Initialized
INFO - 2023-05-09 07:43:48 --> Output Class Initialized
DEBUG - 2023-05-09 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:48 --> Security Class Initialized
INFO - 2023-05-09 07:43:48 --> Input Class Initialized
DEBUG - 2023-05-09 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:48 --> Language Class Initialized
INFO - 2023-05-09 07:43:48 --> Input Class Initialized
INFO - 2023-05-09 07:43:48 --> Loader Class Initialized
INFO - 2023-05-09 07:43:48 --> Language Class Initialized
INFO - 2023-05-09 07:43:48 --> Controller Class Initialized
INFO - 2023-05-09 07:43:48 --> Loader Class Initialized
DEBUG - 2023-05-09 07:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:48 --> Controller Class Initialized
DEBUG - 2023-05-09 07:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:48 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:48 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:48 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:48 --> Total execution time: 0.0378
INFO - 2023-05-09 07:43:48 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:48 --> Total execution time: 0.0451
INFO - 2023-05-09 07:43:51 --> Config Class Initialized
INFO - 2023-05-09 07:43:51 --> Config Class Initialized
INFO - 2023-05-09 07:43:51 --> Hooks Class Initialized
INFO - 2023-05-09 07:43:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 07:43:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:51 --> Utf8 Class Initialized
DEBUG - 2023-05-09 07:43:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:51 --> URI Class Initialized
INFO - 2023-05-09 07:43:51 --> Utf8 Class Initialized
INFO - 2023-05-09 07:43:51 --> Router Class Initialized
INFO - 2023-05-09 07:43:51 --> URI Class Initialized
INFO - 2023-05-09 07:43:51 --> Output Class Initialized
INFO - 2023-05-09 07:43:51 --> Router Class Initialized
INFO - 2023-05-09 07:43:51 --> Security Class Initialized
INFO - 2023-05-09 07:43:51 --> Output Class Initialized
DEBUG - 2023-05-09 07:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:51 --> Security Class Initialized
INFO - 2023-05-09 07:43:51 --> Input Class Initialized
DEBUG - 2023-05-09 07:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:51 --> Language Class Initialized
INFO - 2023-05-09 07:43:51 --> Input Class Initialized
INFO - 2023-05-09 07:43:51 --> Language Class Initialized
INFO - 2023-05-09 07:43:51 --> Loader Class Initialized
INFO - 2023-05-09 07:43:51 --> Controller Class Initialized
INFO - 2023-05-09 07:43:51 --> Loader Class Initialized
DEBUG - 2023-05-09 07:43:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:51 --> Controller Class Initialized
DEBUG - 2023-05-09 07:43:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:51 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:51 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:51 --> Total execution time: 0.0258
INFO - 2023-05-09 07:43:51 --> Config Class Initialized
INFO - 2023-05-09 07:43:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 07:43:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:51 --> Utf8 Class Initialized
INFO - 2023-05-09 07:43:51 --> URI Class Initialized
INFO - 2023-05-09 07:43:51 --> Router Class Initialized
INFO - 2023-05-09 07:43:51 --> Output Class Initialized
INFO - 2023-05-09 07:43:51 --> Security Class Initialized
DEBUG - 2023-05-09 07:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:51 --> Input Class Initialized
INFO - 2023-05-09 07:43:51 --> Language Class Initialized
INFO - 2023-05-09 07:43:51 --> Loader Class Initialized
INFO - 2023-05-09 07:43:51 --> Controller Class Initialized
DEBUG - 2023-05-09 07:43:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:51 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:51 --> Model "Login_model" initialized
INFO - 2023-05-09 07:43:51 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:51 --> Total execution time: 0.0656
INFO - 2023-05-09 07:43:51 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:51 --> Config Class Initialized
INFO - 2023-05-09 07:43:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 07:43:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 07:43:51 --> Utf8 Class Initialized
INFO - 2023-05-09 07:43:51 --> URI Class Initialized
INFO - 2023-05-09 07:43:51 --> Router Class Initialized
INFO - 2023-05-09 07:43:51 --> Output Class Initialized
INFO - 2023-05-09 07:43:51 --> Security Class Initialized
DEBUG - 2023-05-09 07:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 07:43:51 --> Input Class Initialized
INFO - 2023-05-09 07:43:51 --> Language Class Initialized
INFO - 2023-05-09 07:43:51 --> Loader Class Initialized
INFO - 2023-05-09 07:43:51 --> Controller Class Initialized
DEBUG - 2023-05-09 07:43:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 07:43:51 --> Database Driver Class Initialized
INFO - 2023-05-09 07:43:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:51 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:51 --> Total execution time: 0.0474
INFO - 2023-05-09 07:43:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 07:43:51 --> Final output sent to browser
DEBUG - 2023-05-09 07:43:51 --> Total execution time: 0.1422
INFO - 2023-05-09 08:10:24 --> Config Class Initialized
INFO - 2023-05-09 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-09 08:10:24 --> URI Class Initialized
INFO - 2023-05-09 08:10:24 --> Router Class Initialized
INFO - 2023-05-09 08:10:24 --> Output Class Initialized
INFO - 2023-05-09 08:10:24 --> Security Class Initialized
DEBUG - 2023-05-09 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:10:24 --> Input Class Initialized
INFO - 2023-05-09 08:10:24 --> Language Class Initialized
INFO - 2023-05-09 08:10:24 --> Loader Class Initialized
INFO - 2023-05-09 08:10:24 --> Controller Class Initialized
DEBUG - 2023-05-09 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-09 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-09 08:10:24 --> Total execution time: 0.0415
INFO - 2023-05-09 08:10:24 --> Config Class Initialized
INFO - 2023-05-09 08:10:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:10:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:10:24 --> Utf8 Class Initialized
INFO - 2023-05-09 08:10:24 --> URI Class Initialized
INFO - 2023-05-09 08:10:24 --> Router Class Initialized
INFO - 2023-05-09 08:10:24 --> Output Class Initialized
INFO - 2023-05-09 08:10:24 --> Security Class Initialized
DEBUG - 2023-05-09 08:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:10:24 --> Input Class Initialized
INFO - 2023-05-09 08:10:24 --> Language Class Initialized
INFO - 2023-05-09 08:10:24 --> Loader Class Initialized
INFO - 2023-05-09 08:10:24 --> Controller Class Initialized
DEBUG - 2023-05-09 08:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:10:24 --> Database Driver Class Initialized
INFO - 2023-05-09 08:10:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:10:24 --> Final output sent to browser
DEBUG - 2023-05-09 08:10:24 --> Total execution time: 0.0617
INFO - 2023-05-09 08:10:27 --> Config Class Initialized
INFO - 2023-05-09 08:10:27 --> Config Class Initialized
INFO - 2023-05-09 08:10:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:10:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:10:27 --> Utf8 Class Initialized
INFO - 2023-05-09 08:10:27 --> URI Class Initialized
INFO - 2023-05-09 08:10:27 --> Router Class Initialized
INFO - 2023-05-09 08:10:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:10:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:10:27 --> Utf8 Class Initialized
INFO - 2023-05-09 08:10:27 --> Output Class Initialized
INFO - 2023-05-09 08:10:27 --> Security Class Initialized
DEBUG - 2023-05-09 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:10:27 --> Input Class Initialized
INFO - 2023-05-09 08:10:27 --> Language Class Initialized
INFO - 2023-05-09 08:10:27 --> URI Class Initialized
INFO - 2023-05-09 08:10:27 --> Router Class Initialized
INFO - 2023-05-09 08:10:27 --> Loader Class Initialized
INFO - 2023-05-09 08:10:27 --> Controller Class Initialized
DEBUG - 2023-05-09 08:10:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:10:27 --> Output Class Initialized
INFO - 2023-05-09 08:10:27 --> Security Class Initialized
INFO - 2023-05-09 08:10:27 --> Database Driver Class Initialized
DEBUG - 2023-05-09 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:10:27 --> Input Class Initialized
INFO - 2023-05-09 08:10:27 --> Language Class Initialized
ERROR - 2023-05-09 08:10:27 --> 404 Page Not Found: user/Cluster/getLogicalBackUpList
INFO - 2023-05-09 08:10:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:10:27 --> Final output sent to browser
DEBUG - 2023-05-09 08:10:27 --> Total execution time: 0.1312
INFO - 2023-05-09 08:10:27 --> Config Class Initialized
INFO - 2023-05-09 08:10:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:10:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:10:27 --> Utf8 Class Initialized
INFO - 2023-05-09 08:10:27 --> URI Class Initialized
INFO - 2023-05-09 08:10:27 --> Router Class Initialized
INFO - 2023-05-09 08:10:27 --> Output Class Initialized
INFO - 2023-05-09 08:10:27 --> Security Class Initialized
DEBUG - 2023-05-09 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:10:27 --> Input Class Initialized
INFO - 2023-05-09 08:10:27 --> Language Class Initialized
INFO - 2023-05-09 08:10:27 --> Loader Class Initialized
INFO - 2023-05-09 08:10:27 --> Controller Class Initialized
DEBUG - 2023-05-09 08:10:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:10:27 --> Database Driver Class Initialized
INFO - 2023-05-09 08:10:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:10:27 --> Final output sent to browser
DEBUG - 2023-05-09 08:10:27 --> Total execution time: 0.0187
INFO - 2023-05-09 08:49:00 --> Config Class Initialized
INFO - 2023-05-09 08:49:00 --> Config Class Initialized
INFO - 2023-05-09 08:49:00 --> Hooks Class Initialized
INFO - 2023-05-09 08:49:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:00 --> Utf8 Class Initialized
DEBUG - 2023-05-09 08:49:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:00 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:00 --> URI Class Initialized
INFO - 2023-05-09 08:49:00 --> URI Class Initialized
INFO - 2023-05-09 08:49:00 --> Router Class Initialized
INFO - 2023-05-09 08:49:00 --> Router Class Initialized
INFO - 2023-05-09 08:49:00 --> Output Class Initialized
INFO - 2023-05-09 08:49:00 --> Output Class Initialized
INFO - 2023-05-09 08:49:00 --> Security Class Initialized
INFO - 2023-05-09 08:49:00 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:00 --> Input Class Initialized
DEBUG - 2023-05-09 08:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:00 --> Language Class Initialized
INFO - 2023-05-09 08:49:00 --> Input Class Initialized
INFO - 2023-05-09 08:49:00 --> Language Class Initialized
INFO - 2023-05-09 08:49:00 --> Loader Class Initialized
INFO - 2023-05-09 08:49:00 --> Loader Class Initialized
INFO - 2023-05-09 08:49:00 --> Controller Class Initialized
INFO - 2023-05-09 08:49:00 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 08:49:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:00 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:00 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:00 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:00 --> Total execution time: 0.0836
INFO - 2023-05-09 08:49:00 --> Config Class Initialized
INFO - 2023-05-09 08:49:00 --> Final output sent to browser
INFO - 2023-05-09 08:49:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:00 --> Total execution time: 0.1311
DEBUG - 2023-05-09 08:49:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:00 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:00 --> URI Class Initialized
INFO - 2023-05-09 08:49:00 --> Router Class Initialized
INFO - 2023-05-09 08:49:00 --> Config Class Initialized
INFO - 2023-05-09 08:49:00 --> Hooks Class Initialized
INFO - 2023-05-09 08:49:00 --> Output Class Initialized
DEBUG - 2023-05-09 08:49:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:00 --> Security Class Initialized
INFO - 2023-05-09 08:49:00 --> Utf8 Class Initialized
DEBUG - 2023-05-09 08:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:00 --> URI Class Initialized
INFO - 2023-05-09 08:49:00 --> Input Class Initialized
INFO - 2023-05-09 08:49:00 --> Router Class Initialized
INFO - 2023-05-09 08:49:00 --> Language Class Initialized
INFO - 2023-05-09 08:49:00 --> Output Class Initialized
INFO - 2023-05-09 08:49:00 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:00 --> Loader Class Initialized
INFO - 2023-05-09 08:49:00 --> Input Class Initialized
INFO - 2023-05-09 08:49:00 --> Controller Class Initialized
INFO - 2023-05-09 08:49:00 --> Language Class Initialized
DEBUG - 2023-05-09 08:49:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:00 --> Loader Class Initialized
INFO - 2023-05-09 08:49:00 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:00 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:00 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:00 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:00 --> Total execution time: 0.0975
INFO - 2023-05-09 08:49:00 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:01 --> Total execution time: 0.0622
INFO - 2023-05-09 08:49:04 --> Config Class Initialized
INFO - 2023-05-09 08:49:04 --> Config Class Initialized
INFO - 2023-05-09 08:49:04 --> Hooks Class Initialized
INFO - 2023-05-09 08:49:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:04 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 08:49:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:04 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:04 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:04 --> URI Class Initialized
INFO - 2023-05-09 08:49:04 --> URI Class Initialized
INFO - 2023-05-09 08:49:04 --> Router Class Initialized
INFO - 2023-05-09 08:49:04 --> Router Class Initialized
INFO - 2023-05-09 08:49:04 --> Output Class Initialized
INFO - 2023-05-09 08:49:04 --> Output Class Initialized
INFO - 2023-05-09 08:49:04 --> Security Class Initialized
INFO - 2023-05-09 08:49:04 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:04 --> Input Class Initialized
INFO - 2023-05-09 08:49:04 --> Input Class Initialized
INFO - 2023-05-09 08:49:04 --> Language Class Initialized
INFO - 2023-05-09 08:49:04 --> Language Class Initialized
INFO - 2023-05-09 08:49:04 --> Loader Class Initialized
INFO - 2023-05-09 08:49:04 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:04 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:04 --> Loader Class Initialized
INFO - 2023-05-09 08:49:04 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:04 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:04 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:04 --> Total execution time: 0.0201
INFO - 2023-05-09 08:49:04 --> Config Class Initialized
INFO - 2023-05-09 08:49:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:04 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:04 --> URI Class Initialized
INFO - 2023-05-09 08:49:04 --> Router Class Initialized
INFO - 2023-05-09 08:49:04 --> Output Class Initialized
INFO - 2023-05-09 08:49:04 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:04 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:04 --> Input Class Initialized
INFO - 2023-05-09 08:49:04 --> Language Class Initialized
INFO - 2023-05-09 08:49:04 --> Loader Class Initialized
INFO - 2023-05-09 08:49:04 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:04 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:04 --> Model "Login_model" initialized
INFO - 2023-05-09 08:49:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:04 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:04 --> Total execution time: 0.0498
INFO - 2023-05-09 08:49:04 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:04 --> Total execution time: 0.0831
INFO - 2023-05-09 08:49:04 --> Config Class Initialized
INFO - 2023-05-09 08:49:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:04 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:04 --> URI Class Initialized
INFO - 2023-05-09 08:49:04 --> Router Class Initialized
INFO - 2023-05-09 08:49:04 --> Output Class Initialized
INFO - 2023-05-09 08:49:04 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:04 --> Input Class Initialized
INFO - 2023-05-09 08:49:04 --> Language Class Initialized
INFO - 2023-05-09 08:49:04 --> Loader Class Initialized
INFO - 2023-05-09 08:49:04 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:04 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:04 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:04 --> Model "Login_model" initialized
INFO - 2023-05-09 08:49:04 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:04 --> Total execution time: 0.0764
INFO - 2023-05-09 08:49:07 --> Config Class Initialized
INFO - 2023-05-09 08:49:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:07 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:07 --> URI Class Initialized
INFO - 2023-05-09 08:49:07 --> Router Class Initialized
INFO - 2023-05-09 08:49:07 --> Output Class Initialized
INFO - 2023-05-09 08:49:07 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:07 --> Input Class Initialized
INFO - 2023-05-09 08:49:07 --> Language Class Initialized
INFO - 2023-05-09 08:49:07 --> Loader Class Initialized
INFO - 2023-05-09 08:49:07 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:07 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:07 --> Config Class Initialized
INFO - 2023-05-09 08:49:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:07 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:07 --> URI Class Initialized
INFO - 2023-05-09 08:49:07 --> Router Class Initialized
INFO - 2023-05-09 08:49:07 --> Output Class Initialized
INFO - 2023-05-09 08:49:07 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:07 --> Input Class Initialized
INFO - 2023-05-09 08:49:07 --> Language Class Initialized
INFO - 2023-05-09 08:49:07 --> Loader Class Initialized
INFO - 2023-05-09 08:49:07 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:07 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:08 --> Config Class Initialized
INFO - 2023-05-09 08:49:08 --> Config Class Initialized
INFO - 2023-05-09 08:49:08 --> Hooks Class Initialized
INFO - 2023-05-09 08:49:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:08 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 08:49:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:08 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:08 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:08 --> URI Class Initialized
INFO - 2023-05-09 08:49:08 --> URI Class Initialized
INFO - 2023-05-09 08:49:08 --> Router Class Initialized
INFO - 2023-05-09 08:49:08 --> Router Class Initialized
INFO - 2023-05-09 08:49:08 --> Output Class Initialized
INFO - 2023-05-09 08:49:08 --> Output Class Initialized
INFO - 2023-05-09 08:49:08 --> Security Class Initialized
INFO - 2023-05-09 08:49:08 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 08:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:08 --> Input Class Initialized
INFO - 2023-05-09 08:49:08 --> Input Class Initialized
INFO - 2023-05-09 08:49:08 --> Language Class Initialized
INFO - 2023-05-09 08:49:08 --> Language Class Initialized
INFO - 2023-05-09 08:49:08 --> Loader Class Initialized
INFO - 2023-05-09 08:49:08 --> Loader Class Initialized
INFO - 2023-05-09 08:49:08 --> Controller Class Initialized
INFO - 2023-05-09 08:49:08 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 08:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:08 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:08 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:08 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:08 --> Total execution time: 0.0399
INFO - 2023-05-09 08:49:08 --> Config Class Initialized
INFO - 2023-05-09 08:49:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:08 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:08 --> URI Class Initialized
INFO - 2023-05-09 08:49:08 --> Router Class Initialized
INFO - 2023-05-09 08:49:08 --> Output Class Initialized
INFO - 2023-05-09 08:49:08 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:08 --> Input Class Initialized
INFO - 2023-05-09 08:49:08 --> Language Class Initialized
INFO - 2023-05-09 08:49:08 --> Loader Class Initialized
INFO - 2023-05-09 08:49:08 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:08 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:08 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:08 --> Total execution time: 0.0972
INFO - 2023-05-09 08:49:59 --> Config Class Initialized
INFO - 2023-05-09 08:49:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:59 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:59 --> URI Class Initialized
INFO - 2023-05-09 08:49:59 --> Router Class Initialized
INFO - 2023-05-09 08:49:59 --> Output Class Initialized
INFO - 2023-05-09 08:49:59 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:59 --> Input Class Initialized
INFO - 2023-05-09 08:49:59 --> Language Class Initialized
INFO - 2023-05-09 08:49:59 --> Loader Class Initialized
INFO - 2023-05-09 08:49:59 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-05-09 08:49:59 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 250
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-05-09 08:49:59 --> Config Class Initialized
INFO - 2023-05-09 08:49:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:49:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:49:59 --> Utf8 Class Initialized
INFO - 2023-05-09 08:49:59 --> URI Class Initialized
INFO - 2023-05-09 08:49:59 --> Router Class Initialized
INFO - 2023-05-09 08:49:59 --> Output Class Initialized
INFO - 2023-05-09 08:49:59 --> Security Class Initialized
DEBUG - 2023-05-09 08:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:49:59 --> Input Class Initialized
INFO - 2023-05-09 08:49:59 --> Language Class Initialized
INFO - 2023-05-09 08:49:59 --> Loader Class Initialized
INFO - 2023-05-09 08:49:59 --> Controller Class Initialized
DEBUG - 2023-05-09 08:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:49:59 --> Database Driver Class Initialized
INFO - 2023-05-09 08:49:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:49:59 --> Final output sent to browser
DEBUG - 2023-05-09 08:49:59 --> Total execution time: 0.0217
INFO - 2023-05-09 08:50:00 --> Config Class Initialized
INFO - 2023-05-09 08:50:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:50:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:50:00 --> Utf8 Class Initialized
INFO - 2023-05-09 08:50:00 --> URI Class Initialized
INFO - 2023-05-09 08:50:00 --> Router Class Initialized
INFO - 2023-05-09 08:50:00 --> Output Class Initialized
INFO - 2023-05-09 08:50:00 --> Security Class Initialized
DEBUG - 2023-05-09 08:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:50:00 --> Input Class Initialized
INFO - 2023-05-09 08:50:00 --> Language Class Initialized
INFO - 2023-05-09 08:50:00 --> Loader Class Initialized
INFO - 2023-05-09 08:50:00 --> Controller Class Initialized
DEBUG - 2023-05-09 08:50:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:50:00 --> Database Driver Class Initialized
INFO - 2023-05-09 08:50:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:50:00 --> Final output sent to browser
DEBUG - 2023-05-09 08:50:00 --> Total execution time: 0.0143
INFO - 2023-05-09 08:50:00 --> Config Class Initialized
INFO - 2023-05-09 08:50:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:50:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:50:00 --> Utf8 Class Initialized
INFO - 2023-05-09 08:50:00 --> URI Class Initialized
INFO - 2023-05-09 08:50:00 --> Router Class Initialized
INFO - 2023-05-09 08:50:00 --> Output Class Initialized
INFO - 2023-05-09 08:50:00 --> Security Class Initialized
DEBUG - 2023-05-09 08:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:50:00 --> Input Class Initialized
INFO - 2023-05-09 08:50:00 --> Language Class Initialized
INFO - 2023-05-09 08:50:00 --> Loader Class Initialized
INFO - 2023-05-09 08:50:00 --> Controller Class Initialized
DEBUG - 2023-05-09 08:50:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:50:00 --> Database Driver Class Initialized
INFO - 2023-05-09 08:50:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:50:00 --> Final output sent to browser
DEBUG - 2023-05-09 08:50:00 --> Total execution time: 0.0178
INFO - 2023-05-09 08:58:29 --> Config Class Initialized
INFO - 2023-05-09 08:58:29 --> Config Class Initialized
INFO - 2023-05-09 08:58:29 --> Hooks Class Initialized
INFO - 2023-05-09 08:58:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:58:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:58:29 --> Utf8 Class Initialized
DEBUG - 2023-05-09 08:58:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:58:29 --> URI Class Initialized
INFO - 2023-05-09 08:58:29 --> Utf8 Class Initialized
INFO - 2023-05-09 08:58:29 --> URI Class Initialized
INFO - 2023-05-09 08:58:29 --> Router Class Initialized
INFO - 2023-05-09 08:58:29 --> Router Class Initialized
INFO - 2023-05-09 08:58:29 --> Output Class Initialized
INFO - 2023-05-09 08:58:29 --> Output Class Initialized
INFO - 2023-05-09 08:58:29 --> Security Class Initialized
INFO - 2023-05-09 08:58:29 --> Security Class Initialized
DEBUG - 2023-05-09 08:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:58:29 --> Input Class Initialized
INFO - 2023-05-09 08:58:29 --> Input Class Initialized
INFO - 2023-05-09 08:58:29 --> Language Class Initialized
INFO - 2023-05-09 08:58:29 --> Language Class Initialized
INFO - 2023-05-09 08:58:29 --> Loader Class Initialized
INFO - 2023-05-09 08:58:29 --> Loader Class Initialized
INFO - 2023-05-09 08:58:29 --> Controller Class Initialized
INFO - 2023-05-09 08:58:29 --> Controller Class Initialized
DEBUG - 2023-05-09 08:58:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 08:58:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:58:29 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:29 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:58:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:58:29 --> Final output sent to browser
DEBUG - 2023-05-09 08:58:29 --> Total execution time: 0.4019
INFO - 2023-05-09 08:58:29 --> Config Class Initialized
INFO - 2023-05-09 08:58:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:58:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:58:29 --> Utf8 Class Initialized
INFO - 2023-05-09 08:58:29 --> URI Class Initialized
INFO - 2023-05-09 08:58:29 --> Router Class Initialized
INFO - 2023-05-09 08:58:29 --> Output Class Initialized
INFO - 2023-05-09 08:58:29 --> Security Class Initialized
DEBUG - 2023-05-09 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:58:29 --> Input Class Initialized
INFO - 2023-05-09 08:58:29 --> Language Class Initialized
INFO - 2023-05-09 08:58:29 --> Loader Class Initialized
INFO - 2023-05-09 08:58:29 --> Controller Class Initialized
DEBUG - 2023-05-09 08:58:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:58:29 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:29 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:58:29 --> Final output sent to browser
DEBUG - 2023-05-09 08:58:29 --> Total execution time: 0.0447
INFO - 2023-05-09 08:58:29 --> Model "Login_model" initialized
INFO - 2023-05-09 08:58:29 --> Final output sent to browser
DEBUG - 2023-05-09 08:58:29 --> Total execution time: 0.5215
INFO - 2023-05-09 08:58:29 --> Config Class Initialized
INFO - 2023-05-09 08:58:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:58:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:58:29 --> Utf8 Class Initialized
INFO - 2023-05-09 08:58:29 --> URI Class Initialized
INFO - 2023-05-09 08:58:29 --> Router Class Initialized
INFO - 2023-05-09 08:58:29 --> Output Class Initialized
INFO - 2023-05-09 08:58:29 --> Security Class Initialized
DEBUG - 2023-05-09 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:58:29 --> Input Class Initialized
INFO - 2023-05-09 08:58:29 --> Language Class Initialized
INFO - 2023-05-09 08:58:29 --> Loader Class Initialized
INFO - 2023-05-09 08:58:29 --> Controller Class Initialized
DEBUG - 2023-05-09 08:58:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:58:29 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:58:29 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:29 --> Model "Login_model" initialized
INFO - 2023-05-09 08:58:29 --> Final output sent to browser
DEBUG - 2023-05-09 08:58:29 --> Total execution time: 0.0412
INFO - 2023-05-09 08:58:54 --> Config Class Initialized
INFO - 2023-05-09 08:58:54 --> Config Class Initialized
INFO - 2023-05-09 08:58:54 --> Hooks Class Initialized
INFO - 2023-05-09 08:58:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:58:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 08:58:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:58:54 --> Utf8 Class Initialized
INFO - 2023-05-09 08:58:54 --> Utf8 Class Initialized
INFO - 2023-05-09 08:58:54 --> URI Class Initialized
INFO - 2023-05-09 08:58:54 --> URI Class Initialized
INFO - 2023-05-09 08:58:54 --> Router Class Initialized
INFO - 2023-05-09 08:58:54 --> Router Class Initialized
INFO - 2023-05-09 08:58:54 --> Output Class Initialized
INFO - 2023-05-09 08:58:54 --> Output Class Initialized
INFO - 2023-05-09 08:58:54 --> Security Class Initialized
INFO - 2023-05-09 08:58:54 --> Security Class Initialized
DEBUG - 2023-05-09 08:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:58:54 --> Input Class Initialized
DEBUG - 2023-05-09 08:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:58:54 --> Input Class Initialized
INFO - 2023-05-09 08:58:54 --> Language Class Initialized
INFO - 2023-05-09 08:58:54 --> Language Class Initialized
INFO - 2023-05-09 08:58:54 --> Loader Class Initialized
INFO - 2023-05-09 08:58:54 --> Loader Class Initialized
INFO - 2023-05-09 08:58:54 --> Controller Class Initialized
INFO - 2023-05-09 08:58:54 --> Controller Class Initialized
DEBUG - 2023-05-09 08:58:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 08:58:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:58:54 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:54 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:58:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:58:54 --> Final output sent to browser
DEBUG - 2023-05-09 08:58:54 --> Total execution time: 0.1013
INFO - 2023-05-09 08:58:54 --> Config Class Initialized
INFO - 2023-05-09 08:58:54 --> Hooks Class Initialized
INFO - 2023-05-09 08:58:54 --> Database Driver Class Initialized
DEBUG - 2023-05-09 08:58:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:58:54 --> Utf8 Class Initialized
INFO - 2023-05-09 08:58:54 --> URI Class Initialized
INFO - 2023-05-09 08:58:54 --> Router Class Initialized
INFO - 2023-05-09 08:58:54 --> Output Class Initialized
INFO - 2023-05-09 08:58:54 --> Security Class Initialized
DEBUG - 2023-05-09 08:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:58:54 --> Input Class Initialized
INFO - 2023-05-09 08:58:54 --> Language Class Initialized
INFO - 2023-05-09 08:58:54 --> Loader Class Initialized
INFO - 2023-05-09 08:58:54 --> Controller Class Initialized
DEBUG - 2023-05-09 08:58:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:58:54 --> Model "Login_model" initialized
INFO - 2023-05-09 08:58:54 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:54 --> Final output sent to browser
INFO - 2023-05-09 08:58:54 --> Model "Cluster_model" initialized
DEBUG - 2023-05-09 08:58:54 --> Total execution time: 0.2334
INFO - 2023-05-09 08:58:54 --> Final output sent to browser
DEBUG - 2023-05-09 08:58:54 --> Total execution time: 0.1804
INFO - 2023-05-09 08:58:54 --> Config Class Initialized
INFO - 2023-05-09 08:58:54 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:58:54 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:58:54 --> Utf8 Class Initialized
INFO - 2023-05-09 08:58:54 --> URI Class Initialized
INFO - 2023-05-09 08:58:54 --> Router Class Initialized
INFO - 2023-05-09 08:58:54 --> Output Class Initialized
INFO - 2023-05-09 08:58:54 --> Security Class Initialized
DEBUG - 2023-05-09 08:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:58:54 --> Input Class Initialized
INFO - 2023-05-09 08:58:54 --> Language Class Initialized
INFO - 2023-05-09 08:58:54 --> Loader Class Initialized
INFO - 2023-05-09 08:58:54 --> Controller Class Initialized
DEBUG - 2023-05-09 08:58:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:58:54 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:54 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:58:54 --> Database Driver Class Initialized
INFO - 2023-05-09 08:58:54 --> Model "Login_model" initialized
INFO - 2023-05-09 08:58:55 --> Final output sent to browser
DEBUG - 2023-05-09 08:58:55 --> Total execution time: 0.3535
INFO - 2023-05-09 08:59:20 --> Config Class Initialized
INFO - 2023-05-09 08:59:20 --> Hooks Class Initialized
DEBUG - 2023-05-09 08:59:20 --> UTF-8 Support Enabled
INFO - 2023-05-09 08:59:20 --> Utf8 Class Initialized
INFO - 2023-05-09 08:59:20 --> URI Class Initialized
INFO - 2023-05-09 08:59:20 --> Router Class Initialized
INFO - 2023-05-09 08:59:20 --> Output Class Initialized
INFO - 2023-05-09 08:59:20 --> Security Class Initialized
DEBUG - 2023-05-09 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 08:59:20 --> Input Class Initialized
INFO - 2023-05-09 08:59:20 --> Language Class Initialized
INFO - 2023-05-09 08:59:20 --> Loader Class Initialized
INFO - 2023-05-09 08:59:20 --> Controller Class Initialized
DEBUG - 2023-05-09 08:59:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 08:59:20 --> Database Driver Class Initialized
INFO - 2023-05-09 08:59:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 08:59:21 --> Database Driver Class Initialized
INFO - 2023-05-09 08:59:21 --> Model "Login_model" initialized
INFO - 2023-05-09 08:59:22 --> Final output sent to browser
DEBUG - 2023-05-09 08:59:22 --> Total execution time: 1.1331
INFO - 2023-05-09 09:05:46 --> Config Class Initialized
INFO - 2023-05-09 09:05:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:46 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:46 --> URI Class Initialized
INFO - 2023-05-09 09:05:46 --> Router Class Initialized
INFO - 2023-05-09 09:05:46 --> Output Class Initialized
INFO - 2023-05-09 09:05:46 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:46 --> Input Class Initialized
INFO - 2023-05-09 09:05:46 --> Language Class Initialized
INFO - 2023-05-09 09:05:46 --> Loader Class Initialized
INFO - 2023-05-09 09:05:46 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:46 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:46 --> Final output sent to browser
DEBUG - 2023-05-09 09:05:46 --> Total execution time: 0.0214
INFO - 2023-05-09 09:05:46 --> Config Class Initialized
INFO - 2023-05-09 09:05:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:46 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:46 --> URI Class Initialized
INFO - 2023-05-09 09:05:46 --> Router Class Initialized
INFO - 2023-05-09 09:05:46 --> Output Class Initialized
INFO - 2023-05-09 09:05:46 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:46 --> Input Class Initialized
INFO - 2023-05-09 09:05:46 --> Language Class Initialized
INFO - 2023-05-09 09:05:46 --> Loader Class Initialized
INFO - 2023-05-09 09:05:46 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:46 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:46 --> Final output sent to browser
DEBUG - 2023-05-09 09:05:46 --> Total execution time: 0.0962
INFO - 2023-05-09 09:05:47 --> Config Class Initialized
INFO - 2023-05-09 09:05:47 --> Config Class Initialized
INFO - 2023-05-09 09:05:47 --> Hooks Class Initialized
INFO - 2023-05-09 09:05:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:47 --> Utf8 Class Initialized
DEBUG - 2023-05-09 09:05:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:47 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:47 --> URI Class Initialized
INFO - 2023-05-09 09:05:47 --> URI Class Initialized
INFO - 2023-05-09 09:05:47 --> Router Class Initialized
INFO - 2023-05-09 09:05:47 --> Router Class Initialized
INFO - 2023-05-09 09:05:47 --> Output Class Initialized
INFO - 2023-05-09 09:05:47 --> Output Class Initialized
INFO - 2023-05-09 09:05:47 --> Security Class Initialized
INFO - 2023-05-09 09:05:47 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:47 --> Input Class Initialized
INFO - 2023-05-09 09:05:47 --> Input Class Initialized
INFO - 2023-05-09 09:05:47 --> Language Class Initialized
INFO - 2023-05-09 09:05:47 --> Language Class Initialized
INFO - 2023-05-09 09:05:47 --> Loader Class Initialized
INFO - 2023-05-09 09:05:47 --> Loader Class Initialized
INFO - 2023-05-09 09:05:47 --> Controller Class Initialized
INFO - 2023-05-09 09:05:47 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:05:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:47 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:47 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:47 --> Final output sent to browser
DEBUG - 2023-05-09 09:05:47 --> Total execution time: 0.0203
INFO - 2023-05-09 09:05:47 --> Config Class Initialized
INFO - 2023-05-09 09:05:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:47 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:47 --> URI Class Initialized
INFO - 2023-05-09 09:05:47 --> Final output sent to browser
INFO - 2023-05-09 09:05:47 --> Router Class Initialized
DEBUG - 2023-05-09 09:05:47 --> Total execution time: 0.0242
INFO - 2023-05-09 09:05:47 --> Output Class Initialized
INFO - 2023-05-09 09:05:47 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:47 --> Input Class Initialized
INFO - 2023-05-09 09:05:47 --> Language Class Initialized
INFO - 2023-05-09 09:05:47 --> Loader Class Initialized
INFO - 2023-05-09 09:05:47 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:47 --> Config Class Initialized
INFO - 2023-05-09 09:05:47 --> Hooks Class Initialized
INFO - 2023-05-09 09:05:47 --> Database Driver Class Initialized
DEBUG - 2023-05-09 09:05:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:47 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:47 --> URI Class Initialized
INFO - 2023-05-09 09:05:47 --> Router Class Initialized
INFO - 2023-05-09 09:05:47 --> Output Class Initialized
INFO - 2023-05-09 09:05:47 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:47 --> Input Class Initialized
INFO - 2023-05-09 09:05:47 --> Language Class Initialized
INFO - 2023-05-09 09:05:47 --> Loader Class Initialized
INFO - 2023-05-09 09:05:47 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:47 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:47 --> Final output sent to browser
INFO - 2023-05-09 09:05:47 --> Final output sent to browser
DEBUG - 2023-05-09 09:05:47 --> Total execution time: 0.2682
DEBUG - 2023-05-09 09:05:47 --> Total execution time: 0.2649
INFO - 2023-05-09 09:05:50 --> Config Class Initialized
INFO - 2023-05-09 09:05:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:50 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:50 --> URI Class Initialized
INFO - 2023-05-09 09:05:50 --> Router Class Initialized
INFO - 2023-05-09 09:05:50 --> Output Class Initialized
INFO - 2023-05-09 09:05:50 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:50 --> Input Class Initialized
INFO - 2023-05-09 09:05:50 --> Language Class Initialized
INFO - 2023-05-09 09:05:50 --> Loader Class Initialized
INFO - 2023-05-09 09:05:50 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:50 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:50 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:50 --> Final output sent to browser
DEBUG - 2023-05-09 09:05:50 --> Total execution time: 0.0489
INFO - 2023-05-09 09:05:50 --> Config Class Initialized
INFO - 2023-05-09 09:05:50 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:50 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:50 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:50 --> URI Class Initialized
INFO - 2023-05-09 09:05:50 --> Router Class Initialized
INFO - 2023-05-09 09:05:50 --> Output Class Initialized
INFO - 2023-05-09 09:05:50 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:50 --> Input Class Initialized
INFO - 2023-05-09 09:05:50 --> Language Class Initialized
INFO - 2023-05-09 09:05:50 --> Loader Class Initialized
INFO - 2023-05-09 09:05:50 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:50 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:50 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:50 --> Final output sent to browser
DEBUG - 2023-05-09 09:05:50 --> Total execution time: 0.2559
INFO - 2023-05-09 09:05:51 --> Config Class Initialized
INFO - 2023-05-09 09:05:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:51 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:51 --> URI Class Initialized
INFO - 2023-05-09 09:05:51 --> Router Class Initialized
INFO - 2023-05-09 09:05:51 --> Output Class Initialized
INFO - 2023-05-09 09:05:51 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:51 --> Input Class Initialized
INFO - 2023-05-09 09:05:51 --> Language Class Initialized
INFO - 2023-05-09 09:05:51 --> Loader Class Initialized
INFO - 2023-05-09 09:05:51 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:51 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:51 --> Config Class Initialized
INFO - 2023-05-09 09:05:51 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:51 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:51 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:51 --> URI Class Initialized
INFO - 2023-05-09 09:05:51 --> Router Class Initialized
INFO - 2023-05-09 09:05:51 --> Output Class Initialized
INFO - 2023-05-09 09:05:51 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:51 --> Input Class Initialized
INFO - 2023-05-09 09:05:51 --> Language Class Initialized
INFO - 2023-05-09 09:05:51 --> Loader Class Initialized
INFO - 2023-05-09 09:05:51 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:51 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:51 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:55 --> Config Class Initialized
INFO - 2023-05-09 09:05:55 --> Config Class Initialized
INFO - 2023-05-09 09:05:55 --> Hooks Class Initialized
INFO - 2023-05-09 09:05:55 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:05:55 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:55 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:55 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:55 --> URI Class Initialized
INFO - 2023-05-09 09:05:55 --> URI Class Initialized
INFO - 2023-05-09 09:05:55 --> Router Class Initialized
INFO - 2023-05-09 09:05:55 --> Router Class Initialized
INFO - 2023-05-09 09:05:55 --> Output Class Initialized
INFO - 2023-05-09 09:05:55 --> Output Class Initialized
INFO - 2023-05-09 09:05:55 --> Security Class Initialized
INFO - 2023-05-09 09:05:55 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:55 --> Input Class Initialized
INFO - 2023-05-09 09:05:55 --> Input Class Initialized
INFO - 2023-05-09 09:05:55 --> Language Class Initialized
INFO - 2023-05-09 09:05:55 --> Language Class Initialized
INFO - 2023-05-09 09:05:55 --> Loader Class Initialized
INFO - 2023-05-09 09:05:55 --> Loader Class Initialized
INFO - 2023-05-09 09:05:55 --> Controller Class Initialized
INFO - 2023-05-09 09:05:55 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:55 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:55 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:55 --> Final output sent to browser
DEBUG - 2023-05-09 09:05:55 --> Total execution time: 0.1420
INFO - 2023-05-09 09:05:55 --> Config Class Initialized
INFO - 2023-05-09 09:05:55 --> Config Class Initialized
INFO - 2023-05-09 09:05:55 --> Hooks Class Initialized
INFO - 2023-05-09 09:05:55 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:05:55 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:55 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:55 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:55 --> URI Class Initialized
INFO - 2023-05-09 09:05:55 --> URI Class Initialized
INFO - 2023-05-09 09:05:55 --> Router Class Initialized
INFO - 2023-05-09 09:05:55 --> Router Class Initialized
INFO - 2023-05-09 09:05:55 --> Output Class Initialized
INFO - 2023-05-09 09:05:55 --> Output Class Initialized
INFO - 2023-05-09 09:05:55 --> Security Class Initialized
INFO - 2023-05-09 09:05:55 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:55 --> Input Class Initialized
INFO - 2023-05-09 09:05:55 --> Input Class Initialized
INFO - 2023-05-09 09:05:55 --> Language Class Initialized
INFO - 2023-05-09 09:05:55 --> Language Class Initialized
INFO - 2023-05-09 09:05:55 --> Loader Class Initialized
INFO - 2023-05-09 09:05:55 --> Loader Class Initialized
INFO - 2023-05-09 09:05:55 --> Controller Class Initialized
INFO - 2023-05-09 09:05:55 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:55 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:55 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:05:55 --> Final output sent to browser
DEBUG - 2023-05-09 09:05:55 --> Total execution time: 0.0535
INFO - 2023-05-09 09:05:55 --> Config Class Initialized
INFO - 2023-05-09 09:05:55 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:05:55 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:05:55 --> Utf8 Class Initialized
INFO - 2023-05-09 09:05:55 --> URI Class Initialized
INFO - 2023-05-09 09:05:55 --> Router Class Initialized
INFO - 2023-05-09 09:05:55 --> Output Class Initialized
INFO - 2023-05-09 09:05:55 --> Security Class Initialized
DEBUG - 2023-05-09 09:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:05:55 --> Input Class Initialized
INFO - 2023-05-09 09:05:55 --> Language Class Initialized
INFO - 2023-05-09 09:05:55 --> Loader Class Initialized
INFO - 2023-05-09 09:05:55 --> Controller Class Initialized
DEBUG - 2023-05-09 09:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:05:55 --> Database Driver Class Initialized
INFO - 2023-05-09 09:05:55 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:20:17 --> Config Class Initialized
INFO - 2023-05-09 09:20:17 --> Config Class Initialized
INFO - 2023-05-09 09:20:17 --> Hooks Class Initialized
INFO - 2023-05-09 09:20:17 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:20:17 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:20:17 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:20:17 --> Utf8 Class Initialized
INFO - 2023-05-09 09:20:17 --> Utf8 Class Initialized
INFO - 2023-05-09 09:20:17 --> URI Class Initialized
INFO - 2023-05-09 09:20:17 --> URI Class Initialized
INFO - 2023-05-09 09:20:17 --> Router Class Initialized
INFO - 2023-05-09 09:20:17 --> Router Class Initialized
INFO - 2023-05-09 09:20:17 --> Output Class Initialized
INFO - 2023-05-09 09:20:17 --> Security Class Initialized
INFO - 2023-05-09 09:20:17 --> Output Class Initialized
DEBUG - 2023-05-09 09:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:20:17 --> Security Class Initialized
INFO - 2023-05-09 09:20:17 --> Input Class Initialized
DEBUG - 2023-05-09 09:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:20:17 --> Language Class Initialized
INFO - 2023-05-09 09:20:17 --> Input Class Initialized
INFO - 2023-05-09 09:20:17 --> Language Class Initialized
INFO - 2023-05-09 09:20:17 --> Loader Class Initialized
INFO - 2023-05-09 09:20:17 --> Loader Class Initialized
INFO - 2023-05-09 09:20:17 --> Controller Class Initialized
DEBUG - 2023-05-09 09:20:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:20:17 --> Controller Class Initialized
DEBUG - 2023-05-09 09:20:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:20:17 --> Database Driver Class Initialized
INFO - 2023-05-09 09:20:17 --> Database Driver Class Initialized
INFO - 2023-05-09 09:20:17 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:20:17 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:20:17 --> Final output sent to browser
DEBUG - 2023-05-09 09:20:17 --> Total execution time: 0.1168
INFO - 2023-05-09 09:20:17 --> Config Class Initialized
INFO - 2023-05-09 09:20:17 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:20:17 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:20:17 --> Utf8 Class Initialized
INFO - 2023-05-09 09:20:17 --> URI Class Initialized
INFO - 2023-05-09 09:20:17 --> Router Class Initialized
INFO - 2023-05-09 09:20:17 --> Output Class Initialized
INFO - 2023-05-09 09:20:17 --> Security Class Initialized
DEBUG - 2023-05-09 09:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:20:17 --> Input Class Initialized
INFO - 2023-05-09 09:20:17 --> Language Class Initialized
INFO - 2023-05-09 09:20:17 --> Loader Class Initialized
INFO - 2023-05-09 09:20:17 --> Controller Class Initialized
INFO - 2023-05-09 09:20:17 --> Database Driver Class Initialized
DEBUG - 2023-05-09 09:20:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:20:17 --> Database Driver Class Initialized
INFO - 2023-05-09 09:20:17 --> Model "Login_model" initialized
INFO - 2023-05-09 09:20:17 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:20:17 --> Final output sent to browser
DEBUG - 2023-05-09 09:20:17 --> Total execution time: 0.0148
INFO - 2023-05-09 09:20:17 --> Final output sent to browser
DEBUG - 2023-05-09 09:20:17 --> Total execution time: 0.1468
INFO - 2023-05-09 09:20:17 --> Config Class Initialized
INFO - 2023-05-09 09:20:17 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:20:17 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:20:17 --> Utf8 Class Initialized
INFO - 2023-05-09 09:20:17 --> URI Class Initialized
INFO - 2023-05-09 09:20:17 --> Router Class Initialized
INFO - 2023-05-09 09:20:17 --> Output Class Initialized
INFO - 2023-05-09 09:20:17 --> Security Class Initialized
DEBUG - 2023-05-09 09:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:20:17 --> Input Class Initialized
INFO - 2023-05-09 09:20:17 --> Language Class Initialized
INFO - 2023-05-09 09:20:17 --> Loader Class Initialized
INFO - 2023-05-09 09:20:17 --> Controller Class Initialized
DEBUG - 2023-05-09 09:20:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:20:17 --> Database Driver Class Initialized
INFO - 2023-05-09 09:20:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:20:18 --> Database Driver Class Initialized
INFO - 2023-05-09 09:20:18 --> Model "Login_model" initialized
INFO - 2023-05-09 09:20:18 --> Final output sent to browser
DEBUG - 2023-05-09 09:20:18 --> Total execution time: 0.2365
INFO - 2023-05-09 09:21:42 --> Config Class Initialized
INFO - 2023-05-09 09:21:42 --> Config Class Initialized
INFO - 2023-05-09 09:21:42 --> Hooks Class Initialized
INFO - 2023-05-09 09:21:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:21:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:21:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:21:42 --> Utf8 Class Initialized
INFO - 2023-05-09 09:21:42 --> Utf8 Class Initialized
INFO - 2023-05-09 09:21:42 --> URI Class Initialized
INFO - 2023-05-09 09:21:42 --> URI Class Initialized
INFO - 2023-05-09 09:21:42 --> Router Class Initialized
INFO - 2023-05-09 09:21:42 --> Router Class Initialized
INFO - 2023-05-09 09:21:42 --> Output Class Initialized
INFO - 2023-05-09 09:21:42 --> Output Class Initialized
INFO - 2023-05-09 09:21:42 --> Security Class Initialized
INFO - 2023-05-09 09:21:42 --> Security Class Initialized
DEBUG - 2023-05-09 09:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:21:42 --> Input Class Initialized
INFO - 2023-05-09 09:21:42 --> Input Class Initialized
INFO - 2023-05-09 09:21:42 --> Language Class Initialized
INFO - 2023-05-09 09:21:42 --> Language Class Initialized
INFO - 2023-05-09 09:21:42 --> Loader Class Initialized
INFO - 2023-05-09 09:21:42 --> Loader Class Initialized
INFO - 2023-05-09 09:21:42 --> Controller Class Initialized
INFO - 2023-05-09 09:21:42 --> Controller Class Initialized
DEBUG - 2023-05-09 09:21:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:21:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:21:42 --> Database Driver Class Initialized
INFO - 2023-05-09 09:21:42 --> Database Driver Class Initialized
INFO - 2023-05-09 09:21:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:21:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:21:42 --> Final output sent to browser
DEBUG - 2023-05-09 09:21:42 --> Total execution time: 0.0152
INFO - 2023-05-09 09:21:42 --> Config Class Initialized
INFO - 2023-05-09 09:21:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:21:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:21:42 --> Utf8 Class Initialized
INFO - 2023-05-09 09:21:42 --> URI Class Initialized
INFO - 2023-05-09 09:21:42 --> Router Class Initialized
INFO - 2023-05-09 09:21:42 --> Output Class Initialized
INFO - 2023-05-09 09:21:42 --> Security Class Initialized
DEBUG - 2023-05-09 09:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:21:42 --> Input Class Initialized
INFO - 2023-05-09 09:21:42 --> Language Class Initialized
INFO - 2023-05-09 09:21:42 --> Loader Class Initialized
INFO - 2023-05-09 09:21:42 --> Controller Class Initialized
DEBUG - 2023-05-09 09:21:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:21:42 --> Database Driver Class Initialized
INFO - 2023-05-09 09:21:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:21:42 --> Final output sent to browser
DEBUG - 2023-05-09 09:21:42 --> Total execution time: 0.3053
INFO - 2023-05-09 09:21:42 --> Config Class Initialized
INFO - 2023-05-09 09:21:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:21:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:21:42 --> Utf8 Class Initialized
INFO - 2023-05-09 09:21:42 --> URI Class Initialized
INFO - 2023-05-09 09:21:42 --> Router Class Initialized
INFO - 2023-05-09 09:21:42 --> Output Class Initialized
INFO - 2023-05-09 09:21:42 --> Security Class Initialized
DEBUG - 2023-05-09 09:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:21:42 --> Input Class Initialized
INFO - 2023-05-09 09:21:42 --> Language Class Initialized
INFO - 2023-05-09 09:21:42 --> Loader Class Initialized
INFO - 2023-05-09 09:21:42 --> Controller Class Initialized
DEBUG - 2023-05-09 09:21:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:21:42 --> Database Driver Class Initialized
INFO - 2023-05-09 09:21:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:34:38 --> Config Class Initialized
INFO - 2023-05-09 09:34:38 --> Config Class Initialized
INFO - 2023-05-09 09:34:38 --> Hooks Class Initialized
INFO - 2023-05-09 09:34:38 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:34:38 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:34:38 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:34:38 --> Utf8 Class Initialized
INFO - 2023-05-09 09:34:38 --> Utf8 Class Initialized
INFO - 2023-05-09 09:34:38 --> URI Class Initialized
INFO - 2023-05-09 09:34:38 --> URI Class Initialized
INFO - 2023-05-09 09:34:38 --> Router Class Initialized
INFO - 2023-05-09 09:34:38 --> Router Class Initialized
INFO - 2023-05-09 09:34:38 --> Output Class Initialized
INFO - 2023-05-09 09:34:38 --> Output Class Initialized
INFO - 2023-05-09 09:34:38 --> Security Class Initialized
INFO - 2023-05-09 09:34:38 --> Security Class Initialized
DEBUG - 2023-05-09 09:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:34:38 --> Input Class Initialized
INFO - 2023-05-09 09:34:38 --> Input Class Initialized
INFO - 2023-05-09 09:34:38 --> Language Class Initialized
INFO - 2023-05-09 09:34:38 --> Language Class Initialized
INFO - 2023-05-09 09:34:38 --> Loader Class Initialized
INFO - 2023-05-09 09:34:38 --> Loader Class Initialized
INFO - 2023-05-09 09:34:38 --> Controller Class Initialized
INFO - 2023-05-09 09:34:38 --> Controller Class Initialized
DEBUG - 2023-05-09 09:34:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:34:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:34:38 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:38 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:34:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:34:38 --> Final output sent to browser
DEBUG - 2023-05-09 09:34:38 --> Total execution time: 0.3601
INFO - 2023-05-09 09:34:38 --> Config Class Initialized
INFO - 2023-05-09 09:34:38 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:34:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:34:39 --> Utf8 Class Initialized
INFO - 2023-05-09 09:34:39 --> URI Class Initialized
INFO - 2023-05-09 09:34:39 --> Router Class Initialized
INFO - 2023-05-09 09:34:39 --> Output Class Initialized
INFO - 2023-05-09 09:34:39 --> Security Class Initialized
DEBUG - 2023-05-09 09:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:34:39 --> Input Class Initialized
INFO - 2023-05-09 09:34:39 --> Language Class Initialized
INFO - 2023-05-09 09:34:39 --> Loader Class Initialized
INFO - 2023-05-09 09:34:39 --> Controller Class Initialized
DEBUG - 2023-05-09 09:34:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:34:39 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:39 --> Model "Login_model" initialized
INFO - 2023-05-09 09:34:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:34:39 --> Final output sent to browser
DEBUG - 2023-05-09 09:34:39 --> Total execution time: 0.0603
INFO - 2023-05-09 09:34:39 --> Final output sent to browser
DEBUG - 2023-05-09 09:34:39 --> Total execution time: 0.4365
INFO - 2023-05-09 09:34:39 --> Config Class Initialized
INFO - 2023-05-09 09:34:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:34:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:34:39 --> Utf8 Class Initialized
INFO - 2023-05-09 09:34:39 --> URI Class Initialized
INFO - 2023-05-09 09:34:39 --> Router Class Initialized
INFO - 2023-05-09 09:34:39 --> Output Class Initialized
INFO - 2023-05-09 09:34:39 --> Security Class Initialized
DEBUG - 2023-05-09 09:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:34:39 --> Input Class Initialized
INFO - 2023-05-09 09:34:39 --> Language Class Initialized
INFO - 2023-05-09 09:34:39 --> Loader Class Initialized
INFO - 2023-05-09 09:34:39 --> Controller Class Initialized
DEBUG - 2023-05-09 09:34:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:34:39 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:34:39 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:39 --> Model "Login_model" initialized
INFO - 2023-05-09 09:34:39 --> Final output sent to browser
DEBUG - 2023-05-09 09:34:39 --> Total execution time: 0.0899
INFO - 2023-05-09 09:34:45 --> Config Class Initialized
INFO - 2023-05-09 09:34:45 --> Config Class Initialized
INFO - 2023-05-09 09:34:45 --> Hooks Class Initialized
INFO - 2023-05-09 09:34:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:34:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:34:45 --> Utf8 Class Initialized
INFO - 2023-05-09 09:34:45 --> Utf8 Class Initialized
INFO - 2023-05-09 09:34:45 --> URI Class Initialized
INFO - 2023-05-09 09:34:45 --> URI Class Initialized
INFO - 2023-05-09 09:34:45 --> Router Class Initialized
INFO - 2023-05-09 09:34:45 --> Router Class Initialized
INFO - 2023-05-09 09:34:45 --> Output Class Initialized
INFO - 2023-05-09 09:34:45 --> Output Class Initialized
INFO - 2023-05-09 09:34:45 --> Security Class Initialized
INFO - 2023-05-09 09:34:45 --> Security Class Initialized
DEBUG - 2023-05-09 09:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:34:45 --> Input Class Initialized
INFO - 2023-05-09 09:34:45 --> Input Class Initialized
INFO - 2023-05-09 09:34:45 --> Language Class Initialized
INFO - 2023-05-09 09:34:45 --> Language Class Initialized
INFO - 2023-05-09 09:34:45 --> Loader Class Initialized
INFO - 2023-05-09 09:34:45 --> Loader Class Initialized
INFO - 2023-05-09 09:34:45 --> Controller Class Initialized
INFO - 2023-05-09 09:34:45 --> Controller Class Initialized
DEBUG - 2023-05-09 09:34:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:34:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:34:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:34:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:34:45 --> Final output sent to browser
DEBUG - 2023-05-09 09:34:45 --> Total execution time: 0.0209
INFO - 2023-05-09 09:34:45 --> Config Class Initialized
INFO - 2023-05-09 09:34:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:34:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:34:45 --> Utf8 Class Initialized
INFO - 2023-05-09 09:34:45 --> URI Class Initialized
INFO - 2023-05-09 09:34:45 --> Router Class Initialized
INFO - 2023-05-09 09:34:45 --> Output Class Initialized
INFO - 2023-05-09 09:34:45 --> Security Class Initialized
DEBUG - 2023-05-09 09:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:34:45 --> Input Class Initialized
INFO - 2023-05-09 09:34:45 --> Language Class Initialized
INFO - 2023-05-09 09:34:45 --> Loader Class Initialized
INFO - 2023-05-09 09:34:45 --> Controller Class Initialized
DEBUG - 2023-05-09 09:34:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:34:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:34:45 --> Final output sent to browser
DEBUG - 2023-05-09 09:34:45 --> Total execution time: 0.2666
INFO - 2023-05-09 09:34:45 --> Config Class Initialized
INFO - 2023-05-09 09:34:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:34:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:34:45 --> Utf8 Class Initialized
INFO - 2023-05-09 09:34:45 --> URI Class Initialized
INFO - 2023-05-09 09:34:45 --> Router Class Initialized
INFO - 2023-05-09 09:34:45 --> Output Class Initialized
INFO - 2023-05-09 09:34:45 --> Security Class Initialized
DEBUG - 2023-05-09 09:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:34:45 --> Input Class Initialized
INFO - 2023-05-09 09:34:45 --> Language Class Initialized
INFO - 2023-05-09 09:34:45 --> Loader Class Initialized
INFO - 2023-05-09 09:34:45 --> Controller Class Initialized
DEBUG - 2023-05-09 09:34:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:34:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:34:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:17 --> Config Class Initialized
INFO - 2023-05-09 09:37:17 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:37:17 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:17 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:17 --> URI Class Initialized
INFO - 2023-05-09 09:37:17 --> Router Class Initialized
INFO - 2023-05-09 09:37:17 --> Output Class Initialized
INFO - 2023-05-09 09:37:17 --> Security Class Initialized
DEBUG - 2023-05-09 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:37:17 --> Input Class Initialized
INFO - 2023-05-09 09:37:17 --> Language Class Initialized
INFO - 2023-05-09 09:37:17 --> Loader Class Initialized
INFO - 2023-05-09 09:37:17 --> Controller Class Initialized
DEBUG - 2023-05-09 09:37:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:37:17 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:17 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:17 --> Config Class Initialized
INFO - 2023-05-09 09:37:17 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:37:17 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:17 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:17 --> URI Class Initialized
INFO - 2023-05-09 09:37:17 --> Router Class Initialized
INFO - 2023-05-09 09:37:17 --> Output Class Initialized
INFO - 2023-05-09 09:37:17 --> Security Class Initialized
DEBUG - 2023-05-09 09:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:37:17 --> Input Class Initialized
INFO - 2023-05-09 09:37:17 --> Language Class Initialized
INFO - 2023-05-09 09:37:17 --> Loader Class Initialized
INFO - 2023-05-09 09:37:17 --> Controller Class Initialized
DEBUG - 2023-05-09 09:37:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:37:17 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:17 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:18 --> Config Class Initialized
INFO - 2023-05-09 09:37:18 --> Config Class Initialized
INFO - 2023-05-09 09:37:18 --> Hooks Class Initialized
INFO - 2023-05-09 09:37:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:37:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:18 --> Utf8 Class Initialized
DEBUG - 2023-05-09 09:37:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:18 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:18 --> URI Class Initialized
INFO - 2023-05-09 09:37:18 --> URI Class Initialized
INFO - 2023-05-09 09:37:18 --> Router Class Initialized
INFO - 2023-05-09 09:37:18 --> Router Class Initialized
INFO - 2023-05-09 09:37:18 --> Output Class Initialized
INFO - 2023-05-09 09:37:18 --> Output Class Initialized
INFO - 2023-05-09 09:37:18 --> Security Class Initialized
INFO - 2023-05-09 09:37:18 --> Security Class Initialized
DEBUG - 2023-05-09 09:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:37:18 --> Input Class Initialized
INFO - 2023-05-09 09:37:18 --> Input Class Initialized
INFO - 2023-05-09 09:37:18 --> Language Class Initialized
INFO - 2023-05-09 09:37:18 --> Language Class Initialized
INFO - 2023-05-09 09:37:18 --> Loader Class Initialized
INFO - 2023-05-09 09:37:18 --> Loader Class Initialized
INFO - 2023-05-09 09:37:18 --> Controller Class Initialized
INFO - 2023-05-09 09:37:18 --> Controller Class Initialized
DEBUG - 2023-05-09 09:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:37:18 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:18 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:18 --> Final output sent to browser
DEBUG - 2023-05-09 09:37:18 --> Total execution time: 0.0215
INFO - 2023-05-09 09:37:18 --> Config Class Initialized
INFO - 2023-05-09 09:37:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:37:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:18 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:18 --> URI Class Initialized
INFO - 2023-05-09 09:37:18 --> Router Class Initialized
INFO - 2023-05-09 09:37:18 --> Output Class Initialized
INFO - 2023-05-09 09:37:18 --> Security Class Initialized
DEBUG - 2023-05-09 09:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:37:18 --> Input Class Initialized
INFO - 2023-05-09 09:37:18 --> Language Class Initialized
INFO - 2023-05-09 09:37:18 --> Loader Class Initialized
INFO - 2023-05-09 09:37:18 --> Controller Class Initialized
DEBUG - 2023-05-09 09:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:37:18 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:18 --> Final output sent to browser
DEBUG - 2023-05-09 09:37:18 --> Total execution time: 0.0179
INFO - 2023-05-09 09:37:18 --> Config Class Initialized
INFO - 2023-05-09 09:37:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:37:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:19 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:19 --> URI Class Initialized
INFO - 2023-05-09 09:37:19 --> Router Class Initialized
INFO - 2023-05-09 09:37:19 --> Output Class Initialized
INFO - 2023-05-09 09:37:19 --> Security Class Initialized
DEBUG - 2023-05-09 09:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:37:19 --> Input Class Initialized
INFO - 2023-05-09 09:37:19 --> Language Class Initialized
INFO - 2023-05-09 09:37:19 --> Loader Class Initialized
INFO - 2023-05-09 09:37:19 --> Controller Class Initialized
DEBUG - 2023-05-09 09:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:37:19 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:49 --> Config Class Initialized
INFO - 2023-05-09 09:37:49 --> Config Class Initialized
INFO - 2023-05-09 09:37:49 --> Hooks Class Initialized
INFO - 2023-05-09 09:37:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:37:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:49 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:49 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:49 --> URI Class Initialized
INFO - 2023-05-09 09:37:49 --> URI Class Initialized
INFO - 2023-05-09 09:37:49 --> Router Class Initialized
INFO - 2023-05-09 09:37:49 --> Router Class Initialized
INFO - 2023-05-09 09:37:49 --> Output Class Initialized
INFO - 2023-05-09 09:37:49 --> Output Class Initialized
INFO - 2023-05-09 09:37:49 --> Security Class Initialized
INFO - 2023-05-09 09:37:49 --> Security Class Initialized
DEBUG - 2023-05-09 09:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:37:49 --> Input Class Initialized
INFO - 2023-05-09 09:37:49 --> Input Class Initialized
INFO - 2023-05-09 09:37:49 --> Language Class Initialized
INFO - 2023-05-09 09:37:49 --> Language Class Initialized
INFO - 2023-05-09 09:37:49 --> Loader Class Initialized
INFO - 2023-05-09 09:37:49 --> Loader Class Initialized
INFO - 2023-05-09 09:37:49 --> Controller Class Initialized
INFO - 2023-05-09 09:37:49 --> Controller Class Initialized
DEBUG - 2023-05-09 09:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:37:49 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:49 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:49 --> Final output sent to browser
DEBUG - 2023-05-09 09:37:49 --> Total execution time: 0.0172
INFO - 2023-05-09 09:37:49 --> Config Class Initialized
INFO - 2023-05-09 09:37:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:37:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:49 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:49 --> URI Class Initialized
INFO - 2023-05-09 09:37:49 --> Router Class Initialized
INFO - 2023-05-09 09:37:49 --> Output Class Initialized
INFO - 2023-05-09 09:37:49 --> Security Class Initialized
DEBUG - 2023-05-09 09:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:37:49 --> Input Class Initialized
INFO - 2023-05-09 09:37:49 --> Language Class Initialized
INFO - 2023-05-09 09:37:49 --> Loader Class Initialized
INFO - 2023-05-09 09:37:49 --> Controller Class Initialized
DEBUG - 2023-05-09 09:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:37:49 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:37:49 --> Final output sent to browser
DEBUG - 2023-05-09 09:37:49 --> Total execution time: 0.0127
INFO - 2023-05-09 09:37:49 --> Config Class Initialized
INFO - 2023-05-09 09:37:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:37:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:37:49 --> Utf8 Class Initialized
INFO - 2023-05-09 09:37:49 --> URI Class Initialized
INFO - 2023-05-09 09:37:49 --> Router Class Initialized
INFO - 2023-05-09 09:37:49 --> Output Class Initialized
INFO - 2023-05-09 09:37:49 --> Security Class Initialized
DEBUG - 2023-05-09 09:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:37:49 --> Input Class Initialized
INFO - 2023-05-09 09:37:49 --> Language Class Initialized
INFO - 2023-05-09 09:37:49 --> Loader Class Initialized
INFO - 2023-05-09 09:37:49 --> Controller Class Initialized
DEBUG - 2023-05-09 09:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:37:49 --> Database Driver Class Initialized
INFO - 2023-05-09 09:37:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:11 --> Config Class Initialized
INFO - 2023-05-09 09:40:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:11 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:11 --> URI Class Initialized
INFO - 2023-05-09 09:40:11 --> Router Class Initialized
INFO - 2023-05-09 09:40:11 --> Output Class Initialized
INFO - 2023-05-09 09:40:11 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:11 --> Input Class Initialized
INFO - 2023-05-09 09:40:11 --> Language Class Initialized
INFO - 2023-05-09 09:40:11 --> Loader Class Initialized
INFO - 2023-05-09 09:40:11 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:11 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:11 --> Config Class Initialized
INFO - 2023-05-09 09:40:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:11 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:11 --> URI Class Initialized
INFO - 2023-05-09 09:40:11 --> Router Class Initialized
INFO - 2023-05-09 09:40:11 --> Output Class Initialized
INFO - 2023-05-09 09:40:11 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:11 --> Input Class Initialized
INFO - 2023-05-09 09:40:11 --> Language Class Initialized
INFO - 2023-05-09 09:40:11 --> Loader Class Initialized
INFO - 2023-05-09 09:40:11 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:11 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:22 --> Config Class Initialized
INFO - 2023-05-09 09:40:22 --> Config Class Initialized
INFO - 2023-05-09 09:40:22 --> Hooks Class Initialized
INFO - 2023-05-09 09:40:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:22 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:40:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:22 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:22 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:22 --> URI Class Initialized
INFO - 2023-05-09 09:40:22 --> URI Class Initialized
INFO - 2023-05-09 09:40:22 --> Router Class Initialized
INFO - 2023-05-09 09:40:22 --> Router Class Initialized
INFO - 2023-05-09 09:40:22 --> Output Class Initialized
INFO - 2023-05-09 09:40:22 --> Output Class Initialized
INFO - 2023-05-09 09:40:22 --> Security Class Initialized
INFO - 2023-05-09 09:40:22 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:22 --> Input Class Initialized
INFO - 2023-05-09 09:40:22 --> Input Class Initialized
INFO - 2023-05-09 09:40:22 --> Language Class Initialized
INFO - 2023-05-09 09:40:22 --> Language Class Initialized
INFO - 2023-05-09 09:40:22 --> Loader Class Initialized
INFO - 2023-05-09 09:40:22 --> Loader Class Initialized
INFO - 2023-05-09 09:40:22 --> Controller Class Initialized
INFO - 2023-05-09 09:40:22 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:22 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:22 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:22 --> Final output sent to browser
DEBUG - 2023-05-09 09:40:22 --> Total execution time: 0.2298
INFO - 2023-05-09 09:40:22 --> Config Class Initialized
INFO - 2023-05-09 09:40:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:22 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:22 --> URI Class Initialized
INFO - 2023-05-09 09:40:22 --> Router Class Initialized
INFO - 2023-05-09 09:40:22 --> Output Class Initialized
INFO - 2023-05-09 09:40:22 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:22 --> Input Class Initialized
INFO - 2023-05-09 09:40:22 --> Language Class Initialized
INFO - 2023-05-09 09:40:22 --> Loader Class Initialized
INFO - 2023-05-09 09:40:22 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:22 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:22 --> Final output sent to browser
DEBUG - 2023-05-09 09:40:22 --> Total execution time: 0.0136
INFO - 2023-05-09 09:40:22 --> Config Class Initialized
INFO - 2023-05-09 09:40:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:22 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:22 --> URI Class Initialized
INFO - 2023-05-09 09:40:22 --> Router Class Initialized
INFO - 2023-05-09 09:40:22 --> Output Class Initialized
INFO - 2023-05-09 09:40:22 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:22 --> Input Class Initialized
INFO - 2023-05-09 09:40:22 --> Language Class Initialized
INFO - 2023-05-09 09:40:22 --> Loader Class Initialized
INFO - 2023-05-09 09:40:22 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:22 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:22 --> Config Class Initialized
INFO - 2023-05-09 09:40:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:22 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:22 --> URI Class Initialized
INFO - 2023-05-09 09:40:22 --> Router Class Initialized
INFO - 2023-05-09 09:40:22 --> Output Class Initialized
INFO - 2023-05-09 09:40:22 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:22 --> Input Class Initialized
INFO - 2023-05-09 09:40:22 --> Language Class Initialized
INFO - 2023-05-09 09:40:22 --> Loader Class Initialized
INFO - 2023-05-09 09:40:22 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:22 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:22 --> Config Class Initialized
INFO - 2023-05-09 09:40:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:22 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:22 --> URI Class Initialized
INFO - 2023-05-09 09:40:22 --> Router Class Initialized
INFO - 2023-05-09 09:40:22 --> Output Class Initialized
INFO - 2023-05-09 09:40:22 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:22 --> Input Class Initialized
INFO - 2023-05-09 09:40:22 --> Language Class Initialized
INFO - 2023-05-09 09:40:22 --> Loader Class Initialized
INFO - 2023-05-09 09:40:22 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:22 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:37 --> Config Class Initialized
INFO - 2023-05-09 09:40:37 --> Config Class Initialized
INFO - 2023-05-09 09:40:37 --> Hooks Class Initialized
INFO - 2023-05-09 09:40:37 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:37 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:40:37 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:37 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:37 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:37 --> URI Class Initialized
INFO - 2023-05-09 09:40:37 --> URI Class Initialized
INFO - 2023-05-09 09:40:37 --> Router Class Initialized
INFO - 2023-05-09 09:40:37 --> Router Class Initialized
INFO - 2023-05-09 09:40:37 --> Output Class Initialized
INFO - 2023-05-09 09:40:37 --> Output Class Initialized
INFO - 2023-05-09 09:40:37 --> Security Class Initialized
INFO - 2023-05-09 09:40:37 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:37 --> Input Class Initialized
INFO - 2023-05-09 09:40:37 --> Input Class Initialized
INFO - 2023-05-09 09:40:37 --> Language Class Initialized
INFO - 2023-05-09 09:40:37 --> Language Class Initialized
INFO - 2023-05-09 09:40:37 --> Loader Class Initialized
INFO - 2023-05-09 09:40:37 --> Loader Class Initialized
INFO - 2023-05-09 09:40:37 --> Controller Class Initialized
INFO - 2023-05-09 09:40:37 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:40:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:37 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:37 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:38 --> Final output sent to browser
DEBUG - 2023-05-09 09:40:38 --> Total execution time: 0.1149
INFO - 2023-05-09 09:40:38 --> Config Class Initialized
INFO - 2023-05-09 09:40:38 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:38 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:38 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:38 --> URI Class Initialized
INFO - 2023-05-09 09:40:38 --> Router Class Initialized
INFO - 2023-05-09 09:40:38 --> Output Class Initialized
INFO - 2023-05-09 09:40:38 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:38 --> Input Class Initialized
INFO - 2023-05-09 09:40:38 --> Language Class Initialized
INFO - 2023-05-09 09:40:38 --> Loader Class Initialized
INFO - 2023-05-09 09:40:38 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:38 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:38 --> Final output sent to browser
DEBUG - 2023-05-09 09:40:38 --> Total execution time: 0.0113
INFO - 2023-05-09 09:40:38 --> Config Class Initialized
INFO - 2023-05-09 09:40:38 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:38 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:38 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:38 --> URI Class Initialized
INFO - 2023-05-09 09:40:38 --> Router Class Initialized
INFO - 2023-05-09 09:40:38 --> Output Class Initialized
INFO - 2023-05-09 09:40:38 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:38 --> Input Class Initialized
INFO - 2023-05-09 09:40:38 --> Language Class Initialized
INFO - 2023-05-09 09:40:38 --> Loader Class Initialized
INFO - 2023-05-09 09:40:38 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:38 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:38 --> Config Class Initialized
INFO - 2023-05-09 09:40:38 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:38 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:38 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:38 --> URI Class Initialized
INFO - 2023-05-09 09:40:38 --> Router Class Initialized
INFO - 2023-05-09 09:40:38 --> Output Class Initialized
INFO - 2023-05-09 09:40:38 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:38 --> Input Class Initialized
INFO - 2023-05-09 09:40:38 --> Language Class Initialized
INFO - 2023-05-09 09:40:38 --> Loader Class Initialized
INFO - 2023-05-09 09:40:38 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:38 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:38 --> Config Class Initialized
INFO - 2023-05-09 09:40:38 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:38 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:38 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:38 --> URI Class Initialized
INFO - 2023-05-09 09:40:38 --> Router Class Initialized
INFO - 2023-05-09 09:40:38 --> Output Class Initialized
INFO - 2023-05-09 09:40:38 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:38 --> Input Class Initialized
INFO - 2023-05-09 09:40:38 --> Language Class Initialized
INFO - 2023-05-09 09:40:38 --> Loader Class Initialized
INFO - 2023-05-09 09:40:38 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:38 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:40 --> Config Class Initialized
INFO - 2023-05-09 09:40:40 --> Config Class Initialized
INFO - 2023-05-09 09:40:40 --> Hooks Class Initialized
INFO - 2023-05-09 09:40:40 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:40 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:40:40 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:40 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:40 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:40 --> URI Class Initialized
INFO - 2023-05-09 09:40:40 --> URI Class Initialized
INFO - 2023-05-09 09:40:40 --> Router Class Initialized
INFO - 2023-05-09 09:40:40 --> Output Class Initialized
INFO - 2023-05-09 09:40:40 --> Router Class Initialized
INFO - 2023-05-09 09:40:40 --> Security Class Initialized
INFO - 2023-05-09 09:40:40 --> Output Class Initialized
DEBUG - 2023-05-09 09:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:40 --> Security Class Initialized
INFO - 2023-05-09 09:40:40 --> Input Class Initialized
DEBUG - 2023-05-09 09:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:40 --> Language Class Initialized
INFO - 2023-05-09 09:40:40 --> Input Class Initialized
INFO - 2023-05-09 09:40:40 --> Loader Class Initialized
INFO - 2023-05-09 09:40:40 --> Language Class Initialized
INFO - 2023-05-09 09:40:40 --> Loader Class Initialized
INFO - 2023-05-09 09:40:40 --> Controller Class Initialized
INFO - 2023-05-09 09:40:40 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:40 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:40 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:40 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:40 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:40 --> Final output sent to browser
DEBUG - 2023-05-09 09:40:40 --> Total execution time: 0.0169
INFO - 2023-05-09 09:40:46 --> Config Class Initialized
INFO - 2023-05-09 09:40:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:46 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:46 --> URI Class Initialized
INFO - 2023-05-09 09:40:46 --> Router Class Initialized
INFO - 2023-05-09 09:40:46 --> Output Class Initialized
INFO - 2023-05-09 09:40:46 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:46 --> Input Class Initialized
INFO - 2023-05-09 09:40:46 --> Language Class Initialized
INFO - 2023-05-09 09:40:46 --> Loader Class Initialized
INFO - 2023-05-09 09:40:46 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:46 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:46 --> Config Class Initialized
INFO - 2023-05-09 09:40:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:46 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:46 --> URI Class Initialized
INFO - 2023-05-09 09:40:46 --> Router Class Initialized
INFO - 2023-05-09 09:40:46 --> Output Class Initialized
INFO - 2023-05-09 09:40:46 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:46 --> Input Class Initialized
INFO - 2023-05-09 09:40:46 --> Language Class Initialized
INFO - 2023-05-09 09:40:46 --> Loader Class Initialized
INFO - 2023-05-09 09:40:46 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:46 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:46 --> Config Class Initialized
INFO - 2023-05-09 09:40:46 --> Config Class Initialized
INFO - 2023-05-09 09:40:46 --> Hooks Class Initialized
INFO - 2023-05-09 09:40:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:46 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:40:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:46 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:46 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:46 --> URI Class Initialized
INFO - 2023-05-09 09:40:46 --> URI Class Initialized
INFO - 2023-05-09 09:40:46 --> Router Class Initialized
INFO - 2023-05-09 09:40:46 --> Router Class Initialized
INFO - 2023-05-09 09:40:46 --> Output Class Initialized
INFO - 2023-05-09 09:40:46 --> Output Class Initialized
INFO - 2023-05-09 09:40:46 --> Security Class Initialized
INFO - 2023-05-09 09:40:46 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:46 --> Input Class Initialized
INFO - 2023-05-09 09:40:46 --> Input Class Initialized
INFO - 2023-05-09 09:40:46 --> Language Class Initialized
INFO - 2023-05-09 09:40:46 --> Language Class Initialized
INFO - 2023-05-09 09:40:46 --> Loader Class Initialized
INFO - 2023-05-09 09:40:46 --> Loader Class Initialized
INFO - 2023-05-09 09:40:46 --> Controller Class Initialized
INFO - 2023-05-09 09:40:46 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:40:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:46 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:46 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:47 --> Final output sent to browser
DEBUG - 2023-05-09 09:40:47 --> Total execution time: 0.2635
INFO - 2023-05-09 09:40:47 --> Config Class Initialized
INFO - 2023-05-09 09:40:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:47 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:47 --> URI Class Initialized
INFO - 2023-05-09 09:40:47 --> Router Class Initialized
INFO - 2023-05-09 09:40:47 --> Output Class Initialized
INFO - 2023-05-09 09:40:47 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:47 --> Input Class Initialized
INFO - 2023-05-09 09:40:47 --> Language Class Initialized
INFO - 2023-05-09 09:40:47 --> Loader Class Initialized
INFO - 2023-05-09 09:40:47 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:47 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:40:47 --> Final output sent to browser
DEBUG - 2023-05-09 09:40:47 --> Total execution time: 0.0127
INFO - 2023-05-09 09:40:47 --> Config Class Initialized
INFO - 2023-05-09 09:40:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:40:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:40:47 --> Utf8 Class Initialized
INFO - 2023-05-09 09:40:47 --> URI Class Initialized
INFO - 2023-05-09 09:40:47 --> Router Class Initialized
INFO - 2023-05-09 09:40:47 --> Output Class Initialized
INFO - 2023-05-09 09:40:47 --> Security Class Initialized
DEBUG - 2023-05-09 09:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:40:47 --> Input Class Initialized
INFO - 2023-05-09 09:40:47 --> Language Class Initialized
INFO - 2023-05-09 09:40:47 --> Loader Class Initialized
INFO - 2023-05-09 09:40:47 --> Controller Class Initialized
DEBUG - 2023-05-09 09:40:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:40:47 --> Database Driver Class Initialized
INFO - 2023-05-09 09:40:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:45:57 --> Config Class Initialized
INFO - 2023-05-09 09:45:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:45:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:45:57 --> Utf8 Class Initialized
INFO - 2023-05-09 09:45:57 --> URI Class Initialized
INFO - 2023-05-09 09:45:57 --> Router Class Initialized
INFO - 2023-05-09 09:45:57 --> Output Class Initialized
INFO - 2023-05-09 09:45:57 --> Security Class Initialized
DEBUG - 2023-05-09 09:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:45:57 --> Input Class Initialized
INFO - 2023-05-09 09:45:57 --> Language Class Initialized
INFO - 2023-05-09 09:45:57 --> Loader Class Initialized
INFO - 2023-05-09 09:45:57 --> Controller Class Initialized
DEBUG - 2023-05-09 09:45:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:45:57 --> Database Driver Class Initialized
INFO - 2023-05-09 09:45:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:45:58 --> Config Class Initialized
INFO - 2023-05-09 09:45:58 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:45:58 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:45:58 --> Utf8 Class Initialized
INFO - 2023-05-09 09:45:58 --> URI Class Initialized
INFO - 2023-05-09 09:45:58 --> Router Class Initialized
INFO - 2023-05-09 09:45:58 --> Output Class Initialized
INFO - 2023-05-09 09:45:58 --> Security Class Initialized
DEBUG - 2023-05-09 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:45:58 --> Input Class Initialized
INFO - 2023-05-09 09:45:58 --> Language Class Initialized
INFO - 2023-05-09 09:45:58 --> Loader Class Initialized
INFO - 2023-05-09 09:45:58 --> Controller Class Initialized
DEBUG - 2023-05-09 09:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:45:58 --> Database Driver Class Initialized
INFO - 2023-05-09 09:45:58 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:45:59 --> Config Class Initialized
INFO - 2023-05-09 09:45:59 --> Config Class Initialized
INFO - 2023-05-09 09:45:59 --> Hooks Class Initialized
INFO - 2023-05-09 09:45:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:45:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:45:59 --> Utf8 Class Initialized
DEBUG - 2023-05-09 09:45:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:45:59 --> URI Class Initialized
INFO - 2023-05-09 09:45:59 --> Utf8 Class Initialized
INFO - 2023-05-09 09:45:59 --> Router Class Initialized
INFO - 2023-05-09 09:45:59 --> URI Class Initialized
INFO - 2023-05-09 09:45:59 --> Output Class Initialized
INFO - 2023-05-09 09:45:59 --> Router Class Initialized
INFO - 2023-05-09 09:45:59 --> Output Class Initialized
INFO - 2023-05-09 09:45:59 --> Security Class Initialized
INFO - 2023-05-09 09:45:59 --> Security Class Initialized
DEBUG - 2023-05-09 09:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:45:59 --> Input Class Initialized
INFO - 2023-05-09 09:45:59 --> Input Class Initialized
INFO - 2023-05-09 09:45:59 --> Language Class Initialized
INFO - 2023-05-09 09:45:59 --> Language Class Initialized
INFO - 2023-05-09 09:45:59 --> Loader Class Initialized
INFO - 2023-05-09 09:45:59 --> Loader Class Initialized
INFO - 2023-05-09 09:45:59 --> Controller Class Initialized
INFO - 2023-05-09 09:45:59 --> Controller Class Initialized
DEBUG - 2023-05-09 09:45:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:45:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:45:59 --> Database Driver Class Initialized
INFO - 2023-05-09 09:45:59 --> Database Driver Class Initialized
INFO - 2023-05-09 09:45:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:45:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:45:59 --> Final output sent to browser
DEBUG - 2023-05-09 09:45:59 --> Total execution time: 0.0193
INFO - 2023-05-09 09:45:59 --> Config Class Initialized
INFO - 2023-05-09 09:45:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:45:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:45:59 --> Utf8 Class Initialized
INFO - 2023-05-09 09:45:59 --> URI Class Initialized
INFO - 2023-05-09 09:45:59 --> Router Class Initialized
INFO - 2023-05-09 09:45:59 --> Output Class Initialized
INFO - 2023-05-09 09:45:59 --> Security Class Initialized
DEBUG - 2023-05-09 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:45:59 --> Input Class Initialized
INFO - 2023-05-09 09:45:59 --> Language Class Initialized
INFO - 2023-05-09 09:45:59 --> Loader Class Initialized
INFO - 2023-05-09 09:45:59 --> Controller Class Initialized
DEBUG - 2023-05-09 09:45:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:45:59 --> Database Driver Class Initialized
INFO - 2023-05-09 09:45:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:45:59 --> Final output sent to browser
DEBUG - 2023-05-09 09:45:59 --> Total execution time: 0.0147
INFO - 2023-05-09 09:45:59 --> Config Class Initialized
INFO - 2023-05-09 09:45:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:45:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:45:59 --> Utf8 Class Initialized
INFO - 2023-05-09 09:45:59 --> URI Class Initialized
INFO - 2023-05-09 09:45:59 --> Router Class Initialized
INFO - 2023-05-09 09:45:59 --> Output Class Initialized
INFO - 2023-05-09 09:45:59 --> Security Class Initialized
DEBUG - 2023-05-09 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:45:59 --> Input Class Initialized
INFO - 2023-05-09 09:45:59 --> Language Class Initialized
INFO - 2023-05-09 09:45:59 --> Loader Class Initialized
INFO - 2023-05-09 09:45:59 --> Controller Class Initialized
DEBUG - 2023-05-09 09:45:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:45:59 --> Database Driver Class Initialized
INFO - 2023-05-09 09:45:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:46:00 --> Config Class Initialized
INFO - 2023-05-09 09:46:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:46:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:46:00 --> Utf8 Class Initialized
INFO - 2023-05-09 09:46:00 --> URI Class Initialized
INFO - 2023-05-09 09:46:00 --> Router Class Initialized
INFO - 2023-05-09 09:46:00 --> Output Class Initialized
INFO - 2023-05-09 09:46:00 --> Security Class Initialized
DEBUG - 2023-05-09 09:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:46:00 --> Input Class Initialized
INFO - 2023-05-09 09:46:00 --> Language Class Initialized
INFO - 2023-05-09 09:46:00 --> Loader Class Initialized
INFO - 2023-05-09 09:46:00 --> Controller Class Initialized
DEBUG - 2023-05-09 09:46:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:46:00 --> Database Driver Class Initialized
INFO - 2023-05-09 09:46:01 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:46:20 --> Config Class Initialized
INFO - 2023-05-09 09:46:20 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:46:20 --> Utf8 Class Initialized
INFO - 2023-05-09 09:46:20 --> URI Class Initialized
INFO - 2023-05-09 09:46:20 --> Router Class Initialized
INFO - 2023-05-09 09:46:20 --> Output Class Initialized
INFO - 2023-05-09 09:46:20 --> Security Class Initialized
DEBUG - 2023-05-09 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:46:20 --> Input Class Initialized
INFO - 2023-05-09 09:46:20 --> Language Class Initialized
INFO - 2023-05-09 09:46:20 --> Loader Class Initialized
INFO - 2023-05-09 09:46:20 --> Controller Class Initialized
DEBUG - 2023-05-09 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-05-09 09:46:20 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 250
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-05-09 09:46:20 --> Config Class Initialized
INFO - 2023-05-09 09:46:20 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:46:20 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:46:20 --> Utf8 Class Initialized
INFO - 2023-05-09 09:46:20 --> URI Class Initialized
INFO - 2023-05-09 09:46:20 --> Router Class Initialized
INFO - 2023-05-09 09:46:20 --> Output Class Initialized
INFO - 2023-05-09 09:46:20 --> Security Class Initialized
DEBUG - 2023-05-09 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:46:20 --> Input Class Initialized
INFO - 2023-05-09 09:46:20 --> Language Class Initialized
INFO - 2023-05-09 09:46:20 --> Loader Class Initialized
INFO - 2023-05-09 09:46:20 --> Controller Class Initialized
DEBUG - 2023-05-09 09:46:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:46:20 --> Database Driver Class Initialized
INFO - 2023-05-09 09:46:20 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:46:20 --> Final output sent to browser
DEBUG - 2023-05-09 09:46:20 --> Total execution time: 0.0206
INFO - 2023-05-09 09:46:21 --> Config Class Initialized
INFO - 2023-05-09 09:46:21 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:46:21 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:46:21 --> Utf8 Class Initialized
INFO - 2023-05-09 09:46:21 --> URI Class Initialized
INFO - 2023-05-09 09:46:21 --> Router Class Initialized
INFO - 2023-05-09 09:46:21 --> Output Class Initialized
INFO - 2023-05-09 09:46:21 --> Security Class Initialized
DEBUG - 2023-05-09 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:46:21 --> Input Class Initialized
INFO - 2023-05-09 09:46:21 --> Language Class Initialized
INFO - 2023-05-09 09:46:21 --> Loader Class Initialized
INFO - 2023-05-09 09:46:21 --> Controller Class Initialized
DEBUG - 2023-05-09 09:46:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:46:21 --> Database Driver Class Initialized
INFO - 2023-05-09 09:46:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:46:21 --> Final output sent to browser
DEBUG - 2023-05-09 09:46:21 --> Total execution time: 0.0127
INFO - 2023-05-09 09:46:21 --> Config Class Initialized
INFO - 2023-05-09 09:46:21 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:46:21 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:46:21 --> Utf8 Class Initialized
INFO - 2023-05-09 09:46:21 --> URI Class Initialized
INFO - 2023-05-09 09:46:21 --> Router Class Initialized
INFO - 2023-05-09 09:46:21 --> Output Class Initialized
INFO - 2023-05-09 09:46:21 --> Security Class Initialized
DEBUG - 2023-05-09 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:46:21 --> Input Class Initialized
INFO - 2023-05-09 09:46:21 --> Language Class Initialized
INFO - 2023-05-09 09:46:21 --> Loader Class Initialized
INFO - 2023-05-09 09:46:21 --> Controller Class Initialized
DEBUG - 2023-05-09 09:46:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:46:21 --> Database Driver Class Initialized
INFO - 2023-05-09 09:46:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:46:21 --> Final output sent to browser
DEBUG - 2023-05-09 09:46:21 --> Total execution time: 0.0129
INFO - 2023-05-09 09:47:12 --> Config Class Initialized
INFO - 2023-05-09 09:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-09 09:47:12 --> URI Class Initialized
INFO - 2023-05-09 09:47:12 --> Router Class Initialized
INFO - 2023-05-09 09:47:12 --> Output Class Initialized
INFO - 2023-05-09 09:47:12 --> Security Class Initialized
DEBUG - 2023-05-09 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:47:12 --> Input Class Initialized
INFO - 2023-05-09 09:47:12 --> Language Class Initialized
INFO - 2023-05-09 09:47:12 --> Loader Class Initialized
INFO - 2023-05-09 09:47:12 --> Controller Class Initialized
DEBUG - 2023-05-09 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-09 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:47:12 --> Final output sent to browser
DEBUG - 2023-05-09 09:47:12 --> Total execution time: 0.0373
INFO - 2023-05-09 09:47:12 --> Config Class Initialized
INFO - 2023-05-09 09:47:12 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:47:12 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:47:12 --> Utf8 Class Initialized
INFO - 2023-05-09 09:47:12 --> URI Class Initialized
INFO - 2023-05-09 09:47:12 --> Router Class Initialized
INFO - 2023-05-09 09:47:12 --> Output Class Initialized
INFO - 2023-05-09 09:47:12 --> Security Class Initialized
DEBUG - 2023-05-09 09:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:47:12 --> Input Class Initialized
INFO - 2023-05-09 09:47:12 --> Language Class Initialized
INFO - 2023-05-09 09:47:12 --> Loader Class Initialized
INFO - 2023-05-09 09:47:12 --> Controller Class Initialized
DEBUG - 2023-05-09 09:47:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:47:12 --> Database Driver Class Initialized
INFO - 2023-05-09 09:47:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:47:12 --> Final output sent to browser
DEBUG - 2023-05-09 09:47:12 --> Total execution time: 0.2958
INFO - 2023-05-09 09:47:15 --> Config Class Initialized
INFO - 2023-05-09 09:47:15 --> Hooks Class Initialized
INFO - 2023-05-09 09:47:15 --> Config Class Initialized
DEBUG - 2023-05-09 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:47:15 --> Hooks Class Initialized
INFO - 2023-05-09 09:47:15 --> Utf8 Class Initialized
DEBUG - 2023-05-09 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:47:15 --> URI Class Initialized
INFO - 2023-05-09 09:47:15 --> Utf8 Class Initialized
INFO - 2023-05-09 09:47:15 --> Router Class Initialized
INFO - 2023-05-09 09:47:15 --> URI Class Initialized
INFO - 2023-05-09 09:47:15 --> Output Class Initialized
INFO - 2023-05-09 09:47:15 --> Router Class Initialized
INFO - 2023-05-09 09:47:15 --> Security Class Initialized
INFO - 2023-05-09 09:47:15 --> Output Class Initialized
DEBUG - 2023-05-09 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:47:15 --> Input Class Initialized
INFO - 2023-05-09 09:47:15 --> Security Class Initialized
INFO - 2023-05-09 09:47:15 --> Language Class Initialized
DEBUG - 2023-05-09 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:47:15 --> Input Class Initialized
INFO - 2023-05-09 09:47:15 --> Loader Class Initialized
INFO - 2023-05-09 09:47:15 --> Language Class Initialized
INFO - 2023-05-09 09:47:15 --> Controller Class Initialized
INFO - 2023-05-09 09:47:15 --> Loader Class Initialized
DEBUG - 2023-05-09 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:47:15 --> Controller Class Initialized
DEBUG - 2023-05-09 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:47:15 --> Database Driver Class Initialized
INFO - 2023-05-09 09:47:15 --> Database Driver Class Initialized
INFO - 2023-05-09 09:47:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:47:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:47:15 --> Final output sent to browser
DEBUG - 2023-05-09 09:47:15 --> Total execution time: 0.0188
INFO - 2023-05-09 09:47:15 --> Config Class Initialized
INFO - 2023-05-09 09:47:15 --> Final output sent to browser
DEBUG - 2023-05-09 09:47:15 --> Total execution time: 0.0268
INFO - 2023-05-09 09:47:15 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:47:15 --> Utf8 Class Initialized
INFO - 2023-05-09 09:47:15 --> URI Class Initialized
INFO - 2023-05-09 09:47:15 --> Router Class Initialized
INFO - 2023-05-09 09:47:15 --> Config Class Initialized
INFO - 2023-05-09 09:47:15 --> Hooks Class Initialized
INFO - 2023-05-09 09:47:15 --> Output Class Initialized
DEBUG - 2023-05-09 09:47:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:47:15 --> Security Class Initialized
INFO - 2023-05-09 09:47:15 --> Utf8 Class Initialized
DEBUG - 2023-05-09 09:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:47:15 --> URI Class Initialized
INFO - 2023-05-09 09:47:15 --> Input Class Initialized
INFO - 2023-05-09 09:47:15 --> Router Class Initialized
INFO - 2023-05-09 09:47:15 --> Language Class Initialized
INFO - 2023-05-09 09:47:15 --> Output Class Initialized
INFO - 2023-05-09 09:47:15 --> Loader Class Initialized
INFO - 2023-05-09 09:47:15 --> Security Class Initialized
INFO - 2023-05-09 09:47:15 --> Controller Class Initialized
DEBUG - 2023-05-09 09:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:47:15 --> Input Class Initialized
INFO - 2023-05-09 09:47:15 --> Database Driver Class Initialized
INFO - 2023-05-09 09:47:15 --> Language Class Initialized
INFO - 2023-05-09 09:47:15 --> Loader Class Initialized
INFO - 2023-05-09 09:47:15 --> Controller Class Initialized
DEBUG - 2023-05-09 09:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:47:15 --> Database Driver Class Initialized
INFO - 2023-05-09 09:47:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:47:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:47:15 --> Final output sent to browser
DEBUG - 2023-05-09 09:47:15 --> Total execution time: 0.0972
INFO - 2023-05-09 09:47:15 --> Final output sent to browser
DEBUG - 2023-05-09 09:47:15 --> Total execution time: 0.0967
INFO - 2023-05-09 09:47:18 --> Config Class Initialized
INFO - 2023-05-09 09:47:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:47:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:47:18 --> Utf8 Class Initialized
INFO - 2023-05-09 09:47:18 --> URI Class Initialized
INFO - 2023-05-09 09:47:18 --> Router Class Initialized
INFO - 2023-05-09 09:47:18 --> Output Class Initialized
INFO - 2023-05-09 09:47:18 --> Security Class Initialized
DEBUG - 2023-05-09 09:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:47:18 --> Input Class Initialized
INFO - 2023-05-09 09:47:18 --> Language Class Initialized
INFO - 2023-05-09 09:47:18 --> Loader Class Initialized
INFO - 2023-05-09 09:47:18 --> Controller Class Initialized
DEBUG - 2023-05-09 09:47:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:47:18 --> Database Driver Class Initialized
INFO - 2023-05-09 09:47:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:47:18 --> Final output sent to browser
DEBUG - 2023-05-09 09:47:18 --> Total execution time: 0.0316
INFO - 2023-05-09 09:47:18 --> Config Class Initialized
INFO - 2023-05-09 09:47:18 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:47:18 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:47:18 --> Utf8 Class Initialized
INFO - 2023-05-09 09:47:18 --> URI Class Initialized
INFO - 2023-05-09 09:47:18 --> Router Class Initialized
INFO - 2023-05-09 09:47:18 --> Output Class Initialized
INFO - 2023-05-09 09:47:18 --> Security Class Initialized
DEBUG - 2023-05-09 09:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:47:18 --> Input Class Initialized
INFO - 2023-05-09 09:47:18 --> Language Class Initialized
INFO - 2023-05-09 09:47:18 --> Loader Class Initialized
INFO - 2023-05-09 09:47:18 --> Controller Class Initialized
DEBUG - 2023-05-09 09:47:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:47:18 --> Database Driver Class Initialized
INFO - 2023-05-09 09:47:18 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:47:18 --> Final output sent to browser
DEBUG - 2023-05-09 09:47:18 --> Total execution time: 0.0604
INFO - 2023-05-09 09:49:07 --> Config Class Initialized
INFO - 2023-05-09 09:49:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:07 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:07 --> URI Class Initialized
INFO - 2023-05-09 09:49:07 --> Router Class Initialized
INFO - 2023-05-09 09:49:07 --> Output Class Initialized
INFO - 2023-05-09 09:49:07 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:07 --> Input Class Initialized
INFO - 2023-05-09 09:49:07 --> Language Class Initialized
INFO - 2023-05-09 09:49:07 --> Loader Class Initialized
INFO - 2023-05-09 09:49:07 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:07 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:07 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:07 --> Total execution time: 0.0144
INFO - 2023-05-09 09:49:07 --> Config Class Initialized
INFO - 2023-05-09 09:49:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:07 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:07 --> URI Class Initialized
INFO - 2023-05-09 09:49:07 --> Router Class Initialized
INFO - 2023-05-09 09:49:07 --> Output Class Initialized
INFO - 2023-05-09 09:49:07 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:07 --> Input Class Initialized
INFO - 2023-05-09 09:49:07 --> Language Class Initialized
INFO - 2023-05-09 09:49:07 --> Loader Class Initialized
INFO - 2023-05-09 09:49:07 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:07 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:07 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:07 --> Total execution time: 0.0164
INFO - 2023-05-09 09:49:19 --> Config Class Initialized
INFO - 2023-05-09 09:49:19 --> Config Class Initialized
INFO - 2023-05-09 09:49:19 --> Hooks Class Initialized
INFO - 2023-05-09 09:49:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:19 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:49:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:19 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:19 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:19 --> URI Class Initialized
INFO - 2023-05-09 09:49:19 --> URI Class Initialized
INFO - 2023-05-09 09:49:19 --> Router Class Initialized
INFO - 2023-05-09 09:49:19 --> Router Class Initialized
INFO - 2023-05-09 09:49:19 --> Output Class Initialized
INFO - 2023-05-09 09:49:19 --> Output Class Initialized
INFO - 2023-05-09 09:49:19 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:19 --> Security Class Initialized
INFO - 2023-05-09 09:49:19 --> Input Class Initialized
DEBUG - 2023-05-09 09:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:19 --> Language Class Initialized
INFO - 2023-05-09 09:49:19 --> Input Class Initialized
INFO - 2023-05-09 09:49:19 --> Language Class Initialized
INFO - 2023-05-09 09:49:19 --> Loader Class Initialized
INFO - 2023-05-09 09:49:19 --> Loader Class Initialized
INFO - 2023-05-09 09:49:19 --> Controller Class Initialized
INFO - 2023-05-09 09:49:19 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:49:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:19 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:19 --> Total execution time: 0.0047
INFO - 2023-05-09 09:49:19 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:19 --> Config Class Initialized
INFO - 2023-05-09 09:49:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:20 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:20 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:20 --> URI Class Initialized
INFO - 2023-05-09 09:49:20 --> Router Class Initialized
INFO - 2023-05-09 09:49:20 --> Output Class Initialized
INFO - 2023-05-09 09:49:20 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:20 --> Input Class Initialized
INFO - 2023-05-09 09:49:20 --> Language Class Initialized
INFO - 2023-05-09 09:49:20 --> Loader Class Initialized
INFO - 2023-05-09 09:49:20 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:20 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:20 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:20 --> Total execution time: 0.0505
INFO - 2023-05-09 09:49:20 --> Config Class Initialized
INFO - 2023-05-09 09:49:20 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:20 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:20 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:20 --> URI Class Initialized
INFO - 2023-05-09 09:49:20 --> Router Class Initialized
INFO - 2023-05-09 09:49:20 --> Output Class Initialized
INFO - 2023-05-09 09:49:20 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:20 --> Input Class Initialized
INFO - 2023-05-09 09:49:20 --> Language Class Initialized
INFO - 2023-05-09 09:49:20 --> Loader Class Initialized
INFO - 2023-05-09 09:49:20 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:20 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:20 --> Model "Login_model" initialized
INFO - 2023-05-09 09:49:20 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:20 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:20 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:20 --> Total execution time: 0.0165
INFO - 2023-05-09 09:49:20 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:20 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:20 --> Total execution time: 0.3019
INFO - 2023-05-09 09:49:21 --> Config Class Initialized
INFO - 2023-05-09 09:49:21 --> Config Class Initialized
INFO - 2023-05-09 09:49:21 --> Hooks Class Initialized
INFO - 2023-05-09 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:21 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:21 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:21 --> URI Class Initialized
INFO - 2023-05-09 09:49:21 --> URI Class Initialized
INFO - 2023-05-09 09:49:21 --> Router Class Initialized
INFO - 2023-05-09 09:49:21 --> Router Class Initialized
INFO - 2023-05-09 09:49:21 --> Output Class Initialized
INFO - 2023-05-09 09:49:21 --> Output Class Initialized
INFO - 2023-05-09 09:49:21 --> Security Class Initialized
INFO - 2023-05-09 09:49:21 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:21 --> Input Class Initialized
INFO - 2023-05-09 09:49:21 --> Input Class Initialized
INFO - 2023-05-09 09:49:21 --> Language Class Initialized
INFO - 2023-05-09 09:49:21 --> Language Class Initialized
INFO - 2023-05-09 09:49:21 --> Loader Class Initialized
INFO - 2023-05-09 09:49:21 --> Loader Class Initialized
INFO - 2023-05-09 09:49:21 --> Controller Class Initialized
INFO - 2023-05-09 09:49:21 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:21 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:21 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:21 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:21 --> Total execution time: 0.1055
INFO - 2023-05-09 09:49:21 --> Config Class Initialized
INFO - 2023-05-09 09:49:21 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:21 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:21 --> Model "Login_model" initialized
INFO - 2023-05-09 09:49:21 --> URI Class Initialized
INFO - 2023-05-09 09:49:21 --> Router Class Initialized
INFO - 2023-05-09 09:49:21 --> Output Class Initialized
INFO - 2023-05-09 09:49:21 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:21 --> Input Class Initialized
INFO - 2023-05-09 09:49:21 --> Language Class Initialized
INFO - 2023-05-09 09:49:21 --> Loader Class Initialized
INFO - 2023-05-09 09:49:21 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:21 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:21 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:21 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:21 --> Total execution time: 0.1355
INFO - 2023-05-09 09:49:21 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:22 --> Total execution time: 0.2468
INFO - 2023-05-09 09:49:22 --> Config Class Initialized
INFO - 2023-05-09 09:49:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:22 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:22 --> URI Class Initialized
INFO - 2023-05-09 09:49:22 --> Router Class Initialized
INFO - 2023-05-09 09:49:22 --> Output Class Initialized
INFO - 2023-05-09 09:49:22 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:22 --> Input Class Initialized
INFO - 2023-05-09 09:49:22 --> Language Class Initialized
INFO - 2023-05-09 09:49:22 --> Loader Class Initialized
INFO - 2023-05-09 09:49:22 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:22 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:22 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:22 --> Model "Login_model" initialized
INFO - 2023-05-09 09:49:22 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:22 --> Total execution time: 0.0836
INFO - 2023-05-09 09:49:25 --> Config Class Initialized
INFO - 2023-05-09 09:49:25 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:25 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:25 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:25 --> URI Class Initialized
INFO - 2023-05-09 09:49:25 --> Router Class Initialized
INFO - 2023-05-09 09:49:25 --> Output Class Initialized
INFO - 2023-05-09 09:49:25 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:25 --> Input Class Initialized
INFO - 2023-05-09 09:49:25 --> Language Class Initialized
INFO - 2023-05-09 09:49:25 --> Loader Class Initialized
INFO - 2023-05-09 09:49:25 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:25 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:25 --> Total execution time: 0.0441
INFO - 2023-05-09 09:49:25 --> Config Class Initialized
INFO - 2023-05-09 09:49:25 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:25 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:25 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:25 --> URI Class Initialized
INFO - 2023-05-09 09:49:25 --> Router Class Initialized
INFO - 2023-05-09 09:49:25 --> Output Class Initialized
INFO - 2023-05-09 09:49:25 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:25 --> Input Class Initialized
INFO - 2023-05-09 09:49:25 --> Language Class Initialized
INFO - 2023-05-09 09:49:25 --> Loader Class Initialized
INFO - 2023-05-09 09:49:25 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:25 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:25 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:25 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:25 --> Total execution time: 0.2388
INFO - 2023-05-09 09:49:27 --> Config Class Initialized
INFO - 2023-05-09 09:49:27 --> Hooks Class Initialized
INFO - 2023-05-09 09:49:27 --> Config Class Initialized
DEBUG - 2023-05-09 09:49:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:27 --> Hooks Class Initialized
INFO - 2023-05-09 09:49:27 --> Config Class Initialized
INFO - 2023-05-09 09:49:27 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:27 --> URI Class Initialized
INFO - 2023-05-09 09:49:27 --> Utf8 Class Initialized
DEBUG - 2023-05-09 09:49:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:27 --> Router Class Initialized
INFO - 2023-05-09 09:49:27 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:27 --> URI Class Initialized
INFO - 2023-05-09 09:49:27 --> Router Class Initialized
INFO - 2023-05-09 09:49:27 --> Output Class Initialized
INFO - 2023-05-09 09:49:27 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:27 --> Input Class Initialized
INFO - 2023-05-09 09:49:27 --> Language Class Initialized
INFO - 2023-05-09 09:49:27 --> Output Class Initialized
INFO - 2023-05-09 09:49:27 --> URI Class Initialized
INFO - 2023-05-09 09:49:27 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:27 --> Input Class Initialized
INFO - 2023-05-09 09:49:27 --> Router Class Initialized
INFO - 2023-05-09 09:49:27 --> Language Class Initialized
INFO - 2023-05-09 09:49:27 --> Output Class Initialized
INFO - 2023-05-09 09:49:27 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:27 --> Input Class Initialized
INFO - 2023-05-09 09:49:27 --> Language Class Initialized
INFO - 2023-05-09 09:49:27 --> Loader Class Initialized
INFO - 2023-05-09 09:49:27 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:27 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:27 --> Loader Class Initialized
INFO - 2023-05-09 09:49:27 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:27 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:27 --> Loader Class Initialized
INFO - 2023-05-09 09:49:27 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:27 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Model "Login_model" initialized
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.2024
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.2065
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.2079
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.1025
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Model "Login_model" initialized
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.1420
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.1333
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.0896
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.1341
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.0042
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.0181
INFO - 2023-05-09 09:49:28 --> Model "Login_model" initialized
INFO - 2023-05-09 09:49:28 --> Config Class Initialized
INFO - 2023-05-09 09:49:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:49:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:49:28 --> URI Class Initialized
INFO - 2023-05-09 09:49:28 --> Router Class Initialized
INFO - 2023-05-09 09:49:28 --> Output Class Initialized
INFO - 2023-05-09 09:49:28 --> Security Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:49:28 --> Input Class Initialized
INFO - 2023-05-09 09:49:28 --> Language Class Initialized
INFO - 2023-05-09 09:49:28 --> Loader Class Initialized
INFO - 2023-05-09 09:49:28 --> Controller Class Initialized
DEBUG - 2023-05-09 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
INFO - 2023-05-09 09:49:28 --> Final output sent to browser
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.0298
DEBUG - 2023-05-09 09:49:28 --> Total execution time: 0.0152
INFO - 2023-05-09 09:52:28 --> Config Class Initialized
INFO - 2023-05-09 09:52:28 --> Config Class Initialized
INFO - 2023-05-09 09:52:28 --> Hooks Class Initialized
INFO - 2023-05-09 09:52:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:52:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:52:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:52:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:52:28 --> Utf8 Class Initialized
INFO - 2023-05-09 09:52:28 --> URI Class Initialized
INFO - 2023-05-09 09:52:28 --> URI Class Initialized
INFO - 2023-05-09 09:52:28 --> Router Class Initialized
INFO - 2023-05-09 09:52:28 --> Router Class Initialized
INFO - 2023-05-09 09:52:28 --> Output Class Initialized
INFO - 2023-05-09 09:52:28 --> Output Class Initialized
INFO - 2023-05-09 09:52:28 --> Security Class Initialized
INFO - 2023-05-09 09:52:28 --> Security Class Initialized
DEBUG - 2023-05-09 09:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:52:28 --> Input Class Initialized
INFO - 2023-05-09 09:52:28 --> Input Class Initialized
INFO - 2023-05-09 09:52:28 --> Language Class Initialized
INFO - 2023-05-09 09:52:28 --> Language Class Initialized
INFO - 2023-05-09 09:52:28 --> Loader Class Initialized
INFO - 2023-05-09 09:52:28 --> Loader Class Initialized
INFO - 2023-05-09 09:52:28 --> Controller Class Initialized
INFO - 2023-05-09 09:52:28 --> Controller Class Initialized
DEBUG - 2023-05-09 09:52:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:52:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:52:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:52:28 --> Database Driver Class Initialized
INFO - 2023-05-09 09:52:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:52:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:52:29 --> Final output sent to browser
DEBUG - 2023-05-09 09:52:29 --> Total execution time: 0.2416
INFO - 2023-05-09 09:52:29 --> Config Class Initialized
INFO - 2023-05-09 09:52:29 --> Database Driver Class Initialized
INFO - 2023-05-09 09:52:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:52:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:52:29 --> Utf8 Class Initialized
INFO - 2023-05-09 09:52:29 --> URI Class Initialized
INFO - 2023-05-09 09:52:29 --> Router Class Initialized
INFO - 2023-05-09 09:52:29 --> Output Class Initialized
INFO - 2023-05-09 09:52:29 --> Security Class Initialized
DEBUG - 2023-05-09 09:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:52:29 --> Input Class Initialized
INFO - 2023-05-09 09:52:29 --> Language Class Initialized
INFO - 2023-05-09 09:52:29 --> Loader Class Initialized
INFO - 2023-05-09 09:52:29 --> Controller Class Initialized
DEBUG - 2023-05-09 09:52:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:52:29 --> Database Driver Class Initialized
INFO - 2023-05-09 09:52:29 --> Model "Login_model" initialized
INFO - 2023-05-09 09:52:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:52:29 --> Final output sent to browser
DEBUG - 2023-05-09 09:52:29 --> Total execution time: 0.0527
INFO - 2023-05-09 09:52:29 --> Final output sent to browser
DEBUG - 2023-05-09 09:52:29 --> Total execution time: 0.3091
INFO - 2023-05-09 09:52:29 --> Config Class Initialized
INFO - 2023-05-09 09:52:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:52:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:52:29 --> Utf8 Class Initialized
INFO - 2023-05-09 09:52:29 --> URI Class Initialized
INFO - 2023-05-09 09:52:29 --> Router Class Initialized
INFO - 2023-05-09 09:52:29 --> Output Class Initialized
INFO - 2023-05-09 09:52:29 --> Security Class Initialized
DEBUG - 2023-05-09 09:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:52:29 --> Input Class Initialized
INFO - 2023-05-09 09:52:29 --> Language Class Initialized
INFO - 2023-05-09 09:52:29 --> Loader Class Initialized
INFO - 2023-05-09 09:52:29 --> Controller Class Initialized
DEBUG - 2023-05-09 09:52:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:52:29 --> Database Driver Class Initialized
INFO - 2023-05-09 09:52:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:52:29 --> Database Driver Class Initialized
INFO - 2023-05-09 09:52:29 --> Model "Login_model" initialized
INFO - 2023-05-09 09:52:29 --> Final output sent to browser
DEBUG - 2023-05-09 09:52:29 --> Total execution time: 0.0384
INFO - 2023-05-09 09:54:05 --> Config Class Initialized
INFO - 2023-05-09 09:54:05 --> Hooks Class Initialized
INFO - 2023-05-09 09:54:05 --> Config Class Initialized
DEBUG - 2023-05-09 09:54:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:05 --> Hooks Class Initialized
INFO - 2023-05-09 09:54:05 --> Utf8 Class Initialized
DEBUG - 2023-05-09 09:54:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:05 --> URI Class Initialized
INFO - 2023-05-09 09:54:05 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:05 --> URI Class Initialized
INFO - 2023-05-09 09:54:05 --> Router Class Initialized
INFO - 2023-05-09 09:54:05 --> Router Class Initialized
INFO - 2023-05-09 09:54:05 --> Output Class Initialized
INFO - 2023-05-09 09:54:05 --> Output Class Initialized
INFO - 2023-05-09 09:54:05 --> Security Class Initialized
INFO - 2023-05-09 09:54:05 --> Security Class Initialized
DEBUG - 2023-05-09 09:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:05 --> Input Class Initialized
INFO - 2023-05-09 09:54:05 --> Input Class Initialized
INFO - 2023-05-09 09:54:05 --> Language Class Initialized
INFO - 2023-05-09 09:54:05 --> Language Class Initialized
INFO - 2023-05-09 09:54:05 --> Loader Class Initialized
INFO - 2023-05-09 09:54:05 --> Loader Class Initialized
INFO - 2023-05-09 09:54:05 --> Controller Class Initialized
INFO - 2023-05-09 09:54:05 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:54:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:05 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:05 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:05 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:05 --> Total execution time: 0.0195
INFO - 2023-05-09 09:54:05 --> Config Class Initialized
INFO - 2023-05-09 09:54:05 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:54:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:05 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:05 --> URI Class Initialized
INFO - 2023-05-09 09:54:05 --> Router Class Initialized
INFO - 2023-05-09 09:54:05 --> Output Class Initialized
INFO - 2023-05-09 09:54:05 --> Security Class Initialized
DEBUG - 2023-05-09 09:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:05 --> Input Class Initialized
INFO - 2023-05-09 09:54:05 --> Language Class Initialized
INFO - 2023-05-09 09:54:05 --> Loader Class Initialized
INFO - 2023-05-09 09:54:05 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:05 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:05 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:05 --> Total execution time: 0.0286
INFO - 2023-05-09 09:54:05 --> Config Class Initialized
INFO - 2023-05-09 09:54:05 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:54:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:05 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:05 --> URI Class Initialized
INFO - 2023-05-09 09:54:05 --> Router Class Initialized
INFO - 2023-05-09 09:54:05 --> Output Class Initialized
INFO - 2023-05-09 09:54:05 --> Security Class Initialized
DEBUG - 2023-05-09 09:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:05 --> Input Class Initialized
INFO - 2023-05-09 09:54:05 --> Language Class Initialized
INFO - 2023-05-09 09:54:05 --> Loader Class Initialized
INFO - 2023-05-09 09:54:05 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:05 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:05 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:05 --> Total execution time: 0.0170
INFO - 2023-05-09 09:54:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:06 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:06 --> Total execution time: 0.3118
INFO - 2023-05-09 09:54:07 --> Config Class Initialized
INFO - 2023-05-09 09:54:07 --> Config Class Initialized
INFO - 2023-05-09 09:54:07 --> Hooks Class Initialized
INFO - 2023-05-09 09:54:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:54:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:07 --> Utf8 Class Initialized
DEBUG - 2023-05-09 09:54:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:07 --> URI Class Initialized
INFO - 2023-05-09 09:54:07 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:07 --> Router Class Initialized
INFO - 2023-05-09 09:54:07 --> URI Class Initialized
INFO - 2023-05-09 09:54:07 --> Output Class Initialized
INFO - 2023-05-09 09:54:07 --> Router Class Initialized
INFO - 2023-05-09 09:54:07 --> Security Class Initialized
INFO - 2023-05-09 09:54:07 --> Output Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:07 --> Input Class Initialized
INFO - 2023-05-09 09:54:07 --> Security Class Initialized
INFO - 2023-05-09 09:54:07 --> Language Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:07 --> Input Class Initialized
INFO - 2023-05-09 09:54:07 --> Loader Class Initialized
INFO - 2023-05-09 09:54:07 --> Language Class Initialized
INFO - 2023-05-09 09:54:07 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:07 --> Loader Class Initialized
INFO - 2023-05-09 09:54:07 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:07 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:07 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:07 --> Total execution time: 0.0043
INFO - 2023-05-09 09:54:07 --> Config Class Initialized
INFO - 2023-05-09 09:54:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:54:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:07 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:07 --> URI Class Initialized
INFO - 2023-05-09 09:54:07 --> Router Class Initialized
INFO - 2023-05-09 09:54:07 --> Output Class Initialized
INFO - 2023-05-09 09:54:07 --> Security Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:07 --> Input Class Initialized
INFO - 2023-05-09 09:54:07 --> Language Class Initialized
INFO - 2023-05-09 09:54:07 --> Loader Class Initialized
INFO - 2023-05-09 09:54:07 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:07 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:07 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:07 --> Total execution time: 0.2583
INFO - 2023-05-09 09:54:07 --> Config Class Initialized
INFO - 2023-05-09 09:54:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:54:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:07 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:07 --> URI Class Initialized
INFO - 2023-05-09 09:54:07 --> Router Class Initialized
INFO - 2023-05-09 09:54:07 --> Output Class Initialized
INFO - 2023-05-09 09:54:07 --> Security Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:07 --> Input Class Initialized
INFO - 2023-05-09 09:54:07 --> Model "Login_model" initialized
INFO - 2023-05-09 09:54:07 --> Language Class Initialized
INFO - 2023-05-09 09:54:07 --> Loader Class Initialized
INFO - 2023-05-09 09:54:07 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:07 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:07 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:07 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:07 --> Total execution time: 0.2675
INFO - 2023-05-09 09:54:07 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:07 --> Total execution time: 0.0613
INFO - 2023-05-09 09:54:07 --> Config Class Initialized
INFO - 2023-05-09 09:54:07 --> Hooks Class Initialized
INFO - 2023-05-09 09:54:07 --> Config Class Initialized
INFO - 2023-05-09 09:54:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:54:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:07 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:07 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:07 --> URI Class Initialized
INFO - 2023-05-09 09:54:07 --> URI Class Initialized
INFO - 2023-05-09 09:54:07 --> Router Class Initialized
INFO - 2023-05-09 09:54:07 --> Output Class Initialized
INFO - 2023-05-09 09:54:07 --> Router Class Initialized
INFO - 2023-05-09 09:54:07 --> Security Class Initialized
INFO - 2023-05-09 09:54:07 --> Output Class Initialized
INFO - 2023-05-09 09:54:07 --> Security Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:07 --> Input Class Initialized
INFO - 2023-05-09 09:54:07 --> Input Class Initialized
INFO - 2023-05-09 09:54:07 --> Language Class Initialized
INFO - 2023-05-09 09:54:07 --> Language Class Initialized
INFO - 2023-05-09 09:54:07 --> Loader Class Initialized
INFO - 2023-05-09 09:54:07 --> Loader Class Initialized
INFO - 2023-05-09 09:54:07 --> Controller Class Initialized
INFO - 2023-05-09 09:54:07 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:07 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:07 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:08 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:08 --> Total execution time: 0.2115
INFO - 2023-05-09 09:54:08 --> Config Class Initialized
INFO - 2023-05-09 09:54:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:54:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:08 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:08 --> URI Class Initialized
INFO - 2023-05-09 09:54:08 --> Router Class Initialized
INFO - 2023-05-09 09:54:08 --> Output Class Initialized
INFO - 2023-05-09 09:54:08 --> Security Class Initialized
DEBUG - 2023-05-09 09:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:08 --> Input Class Initialized
INFO - 2023-05-09 09:54:08 --> Language Class Initialized
INFO - 2023-05-09 09:54:08 --> Loader Class Initialized
INFO - 2023-05-09 09:54:08 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:08 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:08 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:08 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:08 --> Total execution time: 0.0188
INFO - 2023-05-09 09:54:08 --> Model "Login_model" initialized
INFO - 2023-05-09 09:54:08 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:08 --> Total execution time: 0.3367
INFO - 2023-05-09 09:54:08 --> Config Class Initialized
INFO - 2023-05-09 09:54:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:54:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:54:08 --> Utf8 Class Initialized
INFO - 2023-05-09 09:54:08 --> URI Class Initialized
INFO - 2023-05-09 09:54:08 --> Router Class Initialized
INFO - 2023-05-09 09:54:08 --> Output Class Initialized
INFO - 2023-05-09 09:54:08 --> Security Class Initialized
DEBUG - 2023-05-09 09:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:54:08 --> Input Class Initialized
INFO - 2023-05-09 09:54:08 --> Language Class Initialized
INFO - 2023-05-09 09:54:08 --> Loader Class Initialized
INFO - 2023-05-09 09:54:08 --> Controller Class Initialized
DEBUG - 2023-05-09 09:54:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:54:08 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:54:08 --> Database Driver Class Initialized
INFO - 2023-05-09 09:54:08 --> Model "Login_model" initialized
INFO - 2023-05-09 09:54:08 --> Final output sent to browser
DEBUG - 2023-05-09 09:54:08 --> Total execution time: 0.0338
INFO - 2023-05-09 09:55:41 --> Config Class Initialized
INFO - 2023-05-09 09:55:41 --> Config Class Initialized
INFO - 2023-05-09 09:55:41 --> Hooks Class Initialized
INFO - 2023-05-09 09:55:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:55:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:41 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:41 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:41 --> URI Class Initialized
INFO - 2023-05-09 09:55:41 --> URI Class Initialized
INFO - 2023-05-09 09:55:41 --> Router Class Initialized
INFO - 2023-05-09 09:55:41 --> Router Class Initialized
INFO - 2023-05-09 09:55:41 --> Output Class Initialized
INFO - 2023-05-09 09:55:41 --> Output Class Initialized
INFO - 2023-05-09 09:55:41 --> Security Class Initialized
INFO - 2023-05-09 09:55:41 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:41 --> Input Class Initialized
INFO - 2023-05-09 09:55:41 --> Language Class Initialized
INFO - 2023-05-09 09:55:41 --> Input Class Initialized
INFO - 2023-05-09 09:55:41 --> Loader Class Initialized
INFO - 2023-05-09 09:55:41 --> Language Class Initialized
INFO - 2023-05-09 09:55:41 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:41 --> Loader Class Initialized
INFO - 2023-05-09 09:55:41 --> Controller Class Initialized
INFO - 2023-05-09 09:55:41 --> Database Driver Class Initialized
DEBUG - 2023-05-09 09:55:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:41 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:41 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:41 --> Total execution time: 0.0474
INFO - 2023-05-09 09:55:41 --> Config Class Initialized
INFO - 2023-05-09 09:55:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:41 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:41 --> URI Class Initialized
INFO - 2023-05-09 09:55:41 --> Router Class Initialized
INFO - 2023-05-09 09:55:41 --> Output Class Initialized
INFO - 2023-05-09 09:55:41 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:41 --> Input Class Initialized
INFO - 2023-05-09 09:55:41 --> Language Class Initialized
INFO - 2023-05-09 09:55:41 --> Loader Class Initialized
INFO - 2023-05-09 09:55:41 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:41 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:41 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:41 --> Total execution time: 0.0603
INFO - 2023-05-09 09:55:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:41 --> Config Class Initialized
INFO - 2023-05-09 09:55:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:41 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:41 --> URI Class Initialized
INFO - 2023-05-09 09:55:41 --> Router Class Initialized
INFO - 2023-05-09 09:55:41 --> Output Class Initialized
INFO - 2023-05-09 09:55:41 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:41 --> Input Class Initialized
INFO - 2023-05-09 09:55:41 --> Language Class Initialized
INFO - 2023-05-09 09:55:41 --> Loader Class Initialized
INFO - 2023-05-09 09:55:41 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:41 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:41 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:41 --> Total execution time: 0.0169
INFO - 2023-05-09 09:55:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:42 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:42 --> Total execution time: 0.0610
INFO - 2023-05-09 09:55:43 --> Config Class Initialized
INFO - 2023-05-09 09:55:43 --> Config Class Initialized
INFO - 2023-05-09 09:55:43 --> Hooks Class Initialized
INFO - 2023-05-09 09:55:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:55:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:43 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:43 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:43 --> URI Class Initialized
INFO - 2023-05-09 09:55:43 --> URI Class Initialized
INFO - 2023-05-09 09:55:43 --> Router Class Initialized
INFO - 2023-05-09 09:55:43 --> Router Class Initialized
INFO - 2023-05-09 09:55:43 --> Output Class Initialized
INFO - 2023-05-09 09:55:43 --> Output Class Initialized
INFO - 2023-05-09 09:55:43 --> Security Class Initialized
INFO - 2023-05-09 09:55:43 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:43 --> Input Class Initialized
INFO - 2023-05-09 09:55:43 --> Input Class Initialized
INFO - 2023-05-09 09:55:43 --> Language Class Initialized
INFO - 2023-05-09 09:55:43 --> Language Class Initialized
INFO - 2023-05-09 09:55:43 --> Loader Class Initialized
INFO - 2023-05-09 09:55:43 --> Loader Class Initialized
INFO - 2023-05-09 09:55:43 --> Controller Class Initialized
INFO - 2023-05-09 09:55:43 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:55:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:43 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:43 --> Total execution time: 0.0042
INFO - 2023-05-09 09:55:43 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:43 --> Config Class Initialized
INFO - 2023-05-09 09:55:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:43 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:43 --> URI Class Initialized
INFO - 2023-05-09 09:55:43 --> Router Class Initialized
INFO - 2023-05-09 09:55:43 --> Output Class Initialized
INFO - 2023-05-09 09:55:43 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:43 --> Input Class Initialized
INFO - 2023-05-09 09:55:43 --> Language Class Initialized
INFO - 2023-05-09 09:55:43 --> Loader Class Initialized
INFO - 2023-05-09 09:55:43 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:43 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:44 --> Model "Login_model" initialized
INFO - 2023-05-09 09:55:44 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:44 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:44 --> Total execution time: 0.0801
INFO - 2023-05-09 09:55:44 --> Config Class Initialized
INFO - 2023-05-09 09:55:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:44 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:44 --> URI Class Initialized
INFO - 2023-05-09 09:55:44 --> Router Class Initialized
INFO - 2023-05-09 09:55:44 --> Output Class Initialized
INFO - 2023-05-09 09:55:44 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:44 --> Input Class Initialized
INFO - 2023-05-09 09:55:44 --> Language Class Initialized
INFO - 2023-05-09 09:55:44 --> Loader Class Initialized
INFO - 2023-05-09 09:55:44 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:44 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:44 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:44 --> Total execution time: 0.0819
INFO - 2023-05-09 09:55:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:44 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:44 --> Total execution time: 0.0568
INFO - 2023-05-09 09:55:45 --> Config Class Initialized
INFO - 2023-05-09 09:55:45 --> Config Class Initialized
INFO - 2023-05-09 09:55:45 --> Hooks Class Initialized
INFO - 2023-05-09 09:55:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 09:55:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:45 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:45 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:45 --> URI Class Initialized
INFO - 2023-05-09 09:55:45 --> URI Class Initialized
INFO - 2023-05-09 09:55:45 --> Router Class Initialized
INFO - 2023-05-09 09:55:45 --> Router Class Initialized
INFO - 2023-05-09 09:55:45 --> Output Class Initialized
INFO - 2023-05-09 09:55:45 --> Output Class Initialized
INFO - 2023-05-09 09:55:45 --> Security Class Initialized
INFO - 2023-05-09 09:55:45 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:45 --> Input Class Initialized
INFO - 2023-05-09 09:55:45 --> Input Class Initialized
INFO - 2023-05-09 09:55:45 --> Language Class Initialized
INFO - 2023-05-09 09:55:45 --> Language Class Initialized
INFO - 2023-05-09 09:55:45 --> Loader Class Initialized
INFO - 2023-05-09 09:55:45 --> Loader Class Initialized
INFO - 2023-05-09 09:55:45 --> Controller Class Initialized
INFO - 2023-05-09 09:55:45 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:45 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:45 --> Total execution time: 0.0282
INFO - 2023-05-09 09:55:45 --> Config Class Initialized
INFO - 2023-05-09 09:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:45 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:45 --> URI Class Initialized
INFO - 2023-05-09 09:55:45 --> Router Class Initialized
INFO - 2023-05-09 09:55:45 --> Output Class Initialized
INFO - 2023-05-09 09:55:45 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:45 --> Input Class Initialized
INFO - 2023-05-09 09:55:45 --> Language Class Initialized
INFO - 2023-05-09 09:55:45 --> Loader Class Initialized
INFO - 2023-05-09 09:55:45 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:45 --> Model "Login_model" initialized
INFO - 2023-05-09 09:55:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:45 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:45 --> Total execution time: 0.0524
INFO - 2023-05-09 09:55:45 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:45 --> Total execution time: 0.0950
INFO - 2023-05-09 09:55:45 --> Config Class Initialized
INFO - 2023-05-09 09:55:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:45 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:45 --> URI Class Initialized
INFO - 2023-05-09 09:55:45 --> Router Class Initialized
INFO - 2023-05-09 09:55:45 --> Output Class Initialized
INFO - 2023-05-09 09:55:45 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:45 --> Input Class Initialized
INFO - 2023-05-09 09:55:45 --> Language Class Initialized
INFO - 2023-05-09 09:55:45 --> Loader Class Initialized
INFO - 2023-05-09 09:55:45 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:45 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:45 --> Model "Login_model" initialized
INFO - 2023-05-09 09:55:45 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:45 --> Total execution time: 0.0407
INFO - 2023-05-09 09:55:56 --> Config Class Initialized
INFO - 2023-05-09 09:55:56 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:56 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:56 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:56 --> URI Class Initialized
INFO - 2023-05-09 09:55:56 --> Router Class Initialized
INFO - 2023-05-09 09:55:56 --> Output Class Initialized
INFO - 2023-05-09 09:55:56 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:56 --> Input Class Initialized
INFO - 2023-05-09 09:55:56 --> Language Class Initialized
INFO - 2023-05-09 09:55:56 --> Loader Class Initialized
INFO - 2023-05-09 09:55:56 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:56 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:56 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:56 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:56 --> Total execution time: 0.1342
INFO - 2023-05-09 09:55:56 --> Config Class Initialized
INFO - 2023-05-09 09:55:56 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:56 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:56 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:56 --> URI Class Initialized
INFO - 2023-05-09 09:55:56 --> Router Class Initialized
INFO - 2023-05-09 09:55:56 --> Output Class Initialized
INFO - 2023-05-09 09:55:56 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:56 --> Input Class Initialized
INFO - 2023-05-09 09:55:56 --> Language Class Initialized
INFO - 2023-05-09 09:55:56 --> Loader Class Initialized
INFO - 2023-05-09 09:55:56 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:56 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:56 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:56 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:56 --> Total execution time: 0.0611
INFO - 2023-05-09 09:55:58 --> Config Class Initialized
INFO - 2023-05-09 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:58 --> Config Class Initialized
INFO - 2023-05-09 09:55:58 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:58 --> Hooks Class Initialized
INFO - 2023-05-09 09:55:58 --> URI Class Initialized
DEBUG - 2023-05-09 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:58 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:58 --> Router Class Initialized
INFO - 2023-05-09 09:55:58 --> URI Class Initialized
INFO - 2023-05-09 09:55:58 --> Output Class Initialized
INFO - 2023-05-09 09:55:58 --> Router Class Initialized
INFO - 2023-05-09 09:55:58 --> Security Class Initialized
INFO - 2023-05-09 09:55:58 --> Output Class Initialized
DEBUG - 2023-05-09 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:58 --> Security Class Initialized
INFO - 2023-05-09 09:55:58 --> Input Class Initialized
DEBUG - 2023-05-09 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:58 --> Language Class Initialized
INFO - 2023-05-09 09:55:58 --> Input Class Initialized
INFO - 2023-05-09 09:55:58 --> Language Class Initialized
INFO - 2023-05-09 09:55:58 --> Loader Class Initialized
INFO - 2023-05-09 09:55:58 --> Loader Class Initialized
INFO - 2023-05-09 09:55:58 --> Controller Class Initialized
INFO - 2023-05-09 09:55:58 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 09:55:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:58 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:58 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:58 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:58 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:58 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:58 --> Total execution time: 0.0357
INFO - 2023-05-09 09:55:58 --> Config Class Initialized
INFO - 2023-05-09 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:58 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:58 --> URI Class Initialized
INFO - 2023-05-09 09:55:58 --> Router Class Initialized
INFO - 2023-05-09 09:55:58 --> Output Class Initialized
INFO - 2023-05-09 09:55:58 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:58 --> Input Class Initialized
INFO - 2023-05-09 09:55:58 --> Language Class Initialized
INFO - 2023-05-09 09:55:58 --> Loader Class Initialized
INFO - 2023-05-09 09:55:58 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:58 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:58 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:55:58 --> Final output sent to browser
DEBUG - 2023-05-09 09:55:58 --> Total execution time: 0.1821
INFO - 2023-05-09 09:55:58 --> Config Class Initialized
INFO - 2023-05-09 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:55:58 --> Utf8 Class Initialized
INFO - 2023-05-09 09:55:58 --> URI Class Initialized
INFO - 2023-05-09 09:55:58 --> Router Class Initialized
INFO - 2023-05-09 09:55:58 --> Output Class Initialized
INFO - 2023-05-09 09:55:58 --> Security Class Initialized
DEBUG - 2023-05-09 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:55:58 --> Input Class Initialized
INFO - 2023-05-09 09:55:58 --> Language Class Initialized
INFO - 2023-05-09 09:55:58 --> Loader Class Initialized
INFO - 2023-05-09 09:55:58 --> Controller Class Initialized
DEBUG - 2023-05-09 09:55:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:55:58 --> Database Driver Class Initialized
INFO - 2023-05-09 09:55:58 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:56:00 --> Config Class Initialized
INFO - 2023-05-09 09:56:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:56:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:56:00 --> Utf8 Class Initialized
INFO - 2023-05-09 09:56:00 --> URI Class Initialized
INFO - 2023-05-09 09:56:00 --> Router Class Initialized
INFO - 2023-05-09 09:56:00 --> Output Class Initialized
INFO - 2023-05-09 09:56:00 --> Security Class Initialized
DEBUG - 2023-05-09 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:56:00 --> Input Class Initialized
INFO - 2023-05-09 09:56:00 --> Language Class Initialized
INFO - 2023-05-09 09:56:00 --> Loader Class Initialized
INFO - 2023-05-09 09:56:00 --> Controller Class Initialized
DEBUG - 2023-05-09 09:56:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:56:00 --> Database Driver Class Initialized
INFO - 2023-05-09 09:56:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 09:56:00 --> Config Class Initialized
INFO - 2023-05-09 09:56:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 09:56:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 09:56:00 --> Utf8 Class Initialized
INFO - 2023-05-09 09:56:00 --> URI Class Initialized
INFO - 2023-05-09 09:56:00 --> Router Class Initialized
INFO - 2023-05-09 09:56:00 --> Output Class Initialized
INFO - 2023-05-09 09:56:00 --> Security Class Initialized
DEBUG - 2023-05-09 09:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 09:56:00 --> Input Class Initialized
INFO - 2023-05-09 09:56:00 --> Language Class Initialized
INFO - 2023-05-09 09:56:00 --> Loader Class Initialized
INFO - 2023-05-09 09:56:00 --> Controller Class Initialized
DEBUG - 2023-05-09 09:56:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 09:56:00 --> Database Driver Class Initialized
INFO - 2023-05-09 09:56:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:01 --> Config Class Initialized
INFO - 2023-05-09 10:04:01 --> Config Class Initialized
INFO - 2023-05-09 10:04:01 --> Hooks Class Initialized
INFO - 2023-05-09 10:04:01 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:04:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:04:01 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:04:01 --> Utf8 Class Initialized
INFO - 2023-05-09 10:04:01 --> Utf8 Class Initialized
INFO - 2023-05-09 10:04:01 --> URI Class Initialized
INFO - 2023-05-09 10:04:01 --> URI Class Initialized
INFO - 2023-05-09 10:04:01 --> Router Class Initialized
INFO - 2023-05-09 10:04:01 --> Router Class Initialized
INFO - 2023-05-09 10:04:01 --> Output Class Initialized
INFO - 2023-05-09 10:04:01 --> Output Class Initialized
INFO - 2023-05-09 10:04:01 --> Security Class Initialized
INFO - 2023-05-09 10:04:01 --> Security Class Initialized
DEBUG - 2023-05-09 10:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:04:01 --> Input Class Initialized
INFO - 2023-05-09 10:04:01 --> Input Class Initialized
INFO - 2023-05-09 10:04:01 --> Language Class Initialized
INFO - 2023-05-09 10:04:01 --> Language Class Initialized
INFO - 2023-05-09 10:04:01 --> Loader Class Initialized
INFO - 2023-05-09 10:04:01 --> Loader Class Initialized
INFO - 2023-05-09 10:04:01 --> Controller Class Initialized
INFO - 2023-05-09 10:04:01 --> Controller Class Initialized
DEBUG - 2023-05-09 10:04:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:04:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:04:01 --> Database Driver Class Initialized
INFO - 2023-05-09 10:04:01 --> Database Driver Class Initialized
INFO - 2023-05-09 10:04:01 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:01 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:01 --> Final output sent to browser
DEBUG - 2023-05-09 10:04:01 --> Total execution time: 0.0132
INFO - 2023-05-09 10:04:01 --> Config Class Initialized
INFO - 2023-05-09 10:04:01 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:04:01 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:04:01 --> Utf8 Class Initialized
INFO - 2023-05-09 10:04:01 --> URI Class Initialized
INFO - 2023-05-09 10:04:01 --> Router Class Initialized
INFO - 2023-05-09 10:04:01 --> Output Class Initialized
INFO - 2023-05-09 10:04:01 --> Security Class Initialized
DEBUG - 2023-05-09 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:04:01 --> Input Class Initialized
INFO - 2023-05-09 10:04:01 --> Language Class Initialized
INFO - 2023-05-09 10:04:01 --> Loader Class Initialized
INFO - 2023-05-09 10:04:01 --> Controller Class Initialized
DEBUG - 2023-05-09 10:04:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:04:01 --> Database Driver Class Initialized
INFO - 2023-05-09 10:04:01 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:01 --> Final output sent to browser
DEBUG - 2023-05-09 10:04:01 --> Total execution time: 0.2703
INFO - 2023-05-09 10:04:01 --> Config Class Initialized
INFO - 2023-05-09 10:04:01 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:04:01 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:04:01 --> Utf8 Class Initialized
INFO - 2023-05-09 10:04:01 --> URI Class Initialized
INFO - 2023-05-09 10:04:01 --> Router Class Initialized
INFO - 2023-05-09 10:04:01 --> Output Class Initialized
INFO - 2023-05-09 10:04:01 --> Security Class Initialized
DEBUG - 2023-05-09 10:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:04:01 --> Input Class Initialized
INFO - 2023-05-09 10:04:01 --> Language Class Initialized
INFO - 2023-05-09 10:04:01 --> Loader Class Initialized
INFO - 2023-05-09 10:04:01 --> Controller Class Initialized
DEBUG - 2023-05-09 10:04:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:04:01 --> Database Driver Class Initialized
INFO - 2023-05-09 10:04:01 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:11 --> Config Class Initialized
INFO - 2023-05-09 10:04:11 --> Config Class Initialized
INFO - 2023-05-09 10:04:11 --> Hooks Class Initialized
INFO - 2023-05-09 10:04:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:04:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:04:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:04:11 --> Utf8 Class Initialized
INFO - 2023-05-09 10:04:11 --> Utf8 Class Initialized
INFO - 2023-05-09 10:04:11 --> URI Class Initialized
INFO - 2023-05-09 10:04:11 --> URI Class Initialized
INFO - 2023-05-09 10:04:11 --> Router Class Initialized
INFO - 2023-05-09 10:04:11 --> Router Class Initialized
INFO - 2023-05-09 10:04:11 --> Output Class Initialized
INFO - 2023-05-09 10:04:11 --> Output Class Initialized
INFO - 2023-05-09 10:04:11 --> Security Class Initialized
DEBUG - 2023-05-09 10:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:04:11 --> Security Class Initialized
INFO - 2023-05-09 10:04:11 --> Input Class Initialized
DEBUG - 2023-05-09 10:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:04:11 --> Language Class Initialized
INFO - 2023-05-09 10:04:11 --> Input Class Initialized
INFO - 2023-05-09 10:04:11 --> Loader Class Initialized
INFO - 2023-05-09 10:04:11 --> Language Class Initialized
INFO - 2023-05-09 10:04:11 --> Controller Class Initialized
INFO - 2023-05-09 10:04:11 --> Loader Class Initialized
DEBUG - 2023-05-09 10:04:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:04:11 --> Controller Class Initialized
DEBUG - 2023-05-09 10:04:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:04:11 --> Database Driver Class Initialized
INFO - 2023-05-09 10:04:11 --> Database Driver Class Initialized
INFO - 2023-05-09 10:04:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:12 --> Final output sent to browser
INFO - 2023-05-09 10:04:12 --> Final output sent to browser
DEBUG - 2023-05-09 10:04:12 --> Total execution time: 0.1826
DEBUG - 2023-05-09 10:04:12 --> Total execution time: 0.1844
INFO - 2023-05-09 10:04:12 --> Config Class Initialized
INFO - 2023-05-09 10:04:12 --> Config Class Initialized
INFO - 2023-05-09 10:04:12 --> Hooks Class Initialized
INFO - 2023-05-09 10:04:12 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:04:12 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:04:12 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:04:12 --> Utf8 Class Initialized
INFO - 2023-05-09 10:04:12 --> Utf8 Class Initialized
INFO - 2023-05-09 10:04:12 --> URI Class Initialized
INFO - 2023-05-09 10:04:12 --> URI Class Initialized
INFO - 2023-05-09 10:04:12 --> Router Class Initialized
INFO - 2023-05-09 10:04:12 --> Router Class Initialized
INFO - 2023-05-09 10:04:12 --> Output Class Initialized
INFO - 2023-05-09 10:04:12 --> Security Class Initialized
INFO - 2023-05-09 10:04:12 --> Output Class Initialized
DEBUG - 2023-05-09 10:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:04:12 --> Security Class Initialized
INFO - 2023-05-09 10:04:12 --> Input Class Initialized
DEBUG - 2023-05-09 10:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:04:12 --> Input Class Initialized
INFO - 2023-05-09 10:04:12 --> Language Class Initialized
INFO - 2023-05-09 10:04:12 --> Language Class Initialized
INFO - 2023-05-09 10:04:12 --> Loader Class Initialized
INFO - 2023-05-09 10:04:12 --> Loader Class Initialized
INFO - 2023-05-09 10:04:12 --> Controller Class Initialized
INFO - 2023-05-09 10:04:12 --> Controller Class Initialized
DEBUG - 2023-05-09 10:04:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:04:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:04:12 --> Database Driver Class Initialized
INFO - 2023-05-09 10:04:12 --> Database Driver Class Initialized
INFO - 2023-05-09 10:04:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:04:12 --> Final output sent to browser
INFO - 2023-05-09 10:04:12 --> Final output sent to browser
DEBUG - 2023-05-09 10:04:12 --> Total execution time: 0.0873
DEBUG - 2023-05-09 10:04:12 --> Total execution time: 0.0877
INFO - 2023-05-09 10:06:04 --> Config Class Initialized
INFO - 2023-05-09 10:06:04 --> Config Class Initialized
INFO - 2023-05-09 10:06:04 --> Hooks Class Initialized
INFO - 2023-05-09 10:06:04 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:04 --> Utf8 Class Initialized
DEBUG - 2023-05-09 10:06:04 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:04 --> URI Class Initialized
INFO - 2023-05-09 10:06:04 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:04 --> URI Class Initialized
INFO - 2023-05-09 10:06:04 --> Router Class Initialized
INFO - 2023-05-09 10:06:04 --> Router Class Initialized
INFO - 2023-05-09 10:06:04 --> Output Class Initialized
INFO - 2023-05-09 10:06:04 --> Output Class Initialized
INFO - 2023-05-09 10:06:04 --> Security Class Initialized
INFO - 2023-05-09 10:06:04 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:04 --> Input Class Initialized
INFO - 2023-05-09 10:06:04 --> Input Class Initialized
INFO - 2023-05-09 10:06:04 --> Language Class Initialized
INFO - 2023-05-09 10:06:04 --> Language Class Initialized
INFO - 2023-05-09 10:06:04 --> Loader Class Initialized
INFO - 2023-05-09 10:06:04 --> Loader Class Initialized
INFO - 2023-05-09 10:06:04 --> Controller Class Initialized
INFO - 2023-05-09 10:06:04 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:06:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:04 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:04 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:04 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:04 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:04 --> Total execution time: 0.0736
INFO - 2023-05-09 10:06:04 --> Config Class Initialized
INFO - 2023-05-09 10:06:04 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:04 --> Hooks Class Initialized
INFO - 2023-05-09 10:06:04 --> Model "Login_model" initialized
DEBUG - 2023-05-09 10:06:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:05 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:05 --> URI Class Initialized
INFO - 2023-05-09 10:06:05 --> Router Class Initialized
INFO - 2023-05-09 10:06:05 --> Output Class Initialized
INFO - 2023-05-09 10:06:05 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:05 --> Input Class Initialized
INFO - 2023-05-09 10:06:05 --> Language Class Initialized
INFO - 2023-05-09 10:06:05 --> Loader Class Initialized
INFO - 2023-05-09 10:06:05 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:05 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:05 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:05 --> Total execution time: 0.1342
INFO - 2023-05-09 10:06:05 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:05 --> Total execution time: 0.2244
INFO - 2023-05-09 10:06:05 --> Config Class Initialized
INFO - 2023-05-09 10:06:05 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:05 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:05 --> URI Class Initialized
INFO - 2023-05-09 10:06:05 --> Router Class Initialized
INFO - 2023-05-09 10:06:05 --> Output Class Initialized
INFO - 2023-05-09 10:06:05 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:05 --> Input Class Initialized
INFO - 2023-05-09 10:06:05 --> Language Class Initialized
INFO - 2023-05-09 10:06:05 --> Loader Class Initialized
INFO - 2023-05-09 10:06:05 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:05 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:05 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:05 --> Model "Login_model" initialized
INFO - 2023-05-09 10:06:05 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:05 --> Total execution time: 0.3566
INFO - 2023-05-09 10:06:12 --> Config Class Initialized
INFO - 2023-05-09 10:06:12 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:12 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:12 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:12 --> URI Class Initialized
INFO - 2023-05-09 10:06:12 --> Router Class Initialized
INFO - 2023-05-09 10:06:12 --> Output Class Initialized
INFO - 2023-05-09 10:06:12 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:12 --> Input Class Initialized
INFO - 2023-05-09 10:06:12 --> Language Class Initialized
INFO - 2023-05-09 10:06:12 --> Loader Class Initialized
INFO - 2023-05-09 10:06:12 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:12 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:12 --> Config Class Initialized
INFO - 2023-05-09 10:06:12 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:12 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:12 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:12 --> URI Class Initialized
INFO - 2023-05-09 10:06:12 --> Router Class Initialized
INFO - 2023-05-09 10:06:12 --> Output Class Initialized
INFO - 2023-05-09 10:06:12 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:12 --> Input Class Initialized
INFO - 2023-05-09 10:06:12 --> Language Class Initialized
INFO - 2023-05-09 10:06:12 --> Loader Class Initialized
INFO - 2023-05-09 10:06:12 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:12 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:13 --> Config Class Initialized
INFO - 2023-05-09 10:06:13 --> Config Class Initialized
INFO - 2023-05-09 10:06:13 --> Hooks Class Initialized
INFO - 2023-05-09 10:06:13 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:06:13 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:13 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:13 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:13 --> URI Class Initialized
INFO - 2023-05-09 10:06:13 --> URI Class Initialized
INFO - 2023-05-09 10:06:13 --> Router Class Initialized
INFO - 2023-05-09 10:06:13 --> Router Class Initialized
INFO - 2023-05-09 10:06:13 --> Output Class Initialized
INFO - 2023-05-09 10:06:13 --> Output Class Initialized
INFO - 2023-05-09 10:06:13 --> Security Class Initialized
INFO - 2023-05-09 10:06:13 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:13 --> Input Class Initialized
INFO - 2023-05-09 10:06:13 --> Input Class Initialized
INFO - 2023-05-09 10:06:13 --> Language Class Initialized
INFO - 2023-05-09 10:06:13 --> Language Class Initialized
INFO - 2023-05-09 10:06:13 --> Loader Class Initialized
INFO - 2023-05-09 10:06:13 --> Loader Class Initialized
INFO - 2023-05-09 10:06:13 --> Controller Class Initialized
INFO - 2023-05-09 10:06:13 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:06:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:13 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:13 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:13 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:13 --> Total execution time: 0.0146
INFO - 2023-05-09 10:06:13 --> Config Class Initialized
INFO - 2023-05-09 10:06:13 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:13 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:13 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:13 --> URI Class Initialized
INFO - 2023-05-09 10:06:13 --> Router Class Initialized
INFO - 2023-05-09 10:06:13 --> Output Class Initialized
INFO - 2023-05-09 10:06:13 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:13 --> Input Class Initialized
INFO - 2023-05-09 10:06:13 --> Language Class Initialized
INFO - 2023-05-09 10:06:13 --> Loader Class Initialized
INFO - 2023-05-09 10:06:13 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:13 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:13 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:13 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:13 --> Total execution time: 0.0499
INFO - 2023-05-09 10:06:14 --> Config Class Initialized
INFO - 2023-05-09 10:06:14 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:14 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:14 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:14 --> URI Class Initialized
INFO - 2023-05-09 10:06:14 --> Router Class Initialized
INFO - 2023-05-09 10:06:14 --> Output Class Initialized
INFO - 2023-05-09 10:06:14 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:14 --> Input Class Initialized
INFO - 2023-05-09 10:06:14 --> Language Class Initialized
INFO - 2023-05-09 10:06:14 --> Loader Class Initialized
INFO - 2023-05-09 10:06:14 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:14 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:14 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:26 --> Config Class Initialized
INFO - 2023-05-09 10:06:26 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:26 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:26 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:26 --> URI Class Initialized
INFO - 2023-05-09 10:06:26 --> Router Class Initialized
INFO - 2023-05-09 10:06:26 --> Output Class Initialized
INFO - 2023-05-09 10:06:26 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:26 --> Input Class Initialized
INFO - 2023-05-09 10:06:26 --> Language Class Initialized
INFO - 2023-05-09 10:06:26 --> Loader Class Initialized
INFO - 2023-05-09 10:06:26 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-05-09 10:06:26 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 250
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-05-09 10:06:26 --> Config Class Initialized
INFO - 2023-05-09 10:06:26 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:26 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:26 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:26 --> URI Class Initialized
INFO - 2023-05-09 10:06:26 --> Router Class Initialized
INFO - 2023-05-09 10:06:26 --> Output Class Initialized
INFO - 2023-05-09 10:06:26 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:26 --> Input Class Initialized
INFO - 2023-05-09 10:06:26 --> Language Class Initialized
INFO - 2023-05-09 10:06:26 --> Loader Class Initialized
INFO - 2023-05-09 10:06:26 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:26 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:26 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:26 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:26 --> Total execution time: 0.1120
INFO - 2023-05-09 10:06:27 --> Config Class Initialized
INFO - 2023-05-09 10:06:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:27 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:27 --> URI Class Initialized
INFO - 2023-05-09 10:06:27 --> Router Class Initialized
INFO - 2023-05-09 10:06:27 --> Output Class Initialized
INFO - 2023-05-09 10:06:27 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:27 --> Input Class Initialized
INFO - 2023-05-09 10:06:27 --> Language Class Initialized
INFO - 2023-05-09 10:06:27 --> Loader Class Initialized
INFO - 2023-05-09 10:06:27 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:27 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:27 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:27 --> Total execution time: 0.0126
INFO - 2023-05-09 10:06:27 --> Config Class Initialized
INFO - 2023-05-09 10:06:27 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:27 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:27 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:27 --> URI Class Initialized
INFO - 2023-05-09 10:06:27 --> Router Class Initialized
INFO - 2023-05-09 10:06:27 --> Output Class Initialized
INFO - 2023-05-09 10:06:27 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:27 --> Input Class Initialized
INFO - 2023-05-09 10:06:27 --> Language Class Initialized
INFO - 2023-05-09 10:06:27 --> Loader Class Initialized
INFO - 2023-05-09 10:06:27 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:27 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:27 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:27 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:27 --> Total execution time: 0.0131
INFO - 2023-05-09 10:06:28 --> Config Class Initialized
INFO - 2023-05-09 10:06:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:28 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:28 --> URI Class Initialized
INFO - 2023-05-09 10:06:28 --> Router Class Initialized
INFO - 2023-05-09 10:06:28 --> Output Class Initialized
INFO - 2023-05-09 10:06:28 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:28 --> Input Class Initialized
INFO - 2023-05-09 10:06:28 --> Language Class Initialized
INFO - 2023-05-09 10:06:28 --> Loader Class Initialized
INFO - 2023-05-09 10:06:28 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:28 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:28 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:28 --> Total execution time: 0.0483
INFO - 2023-05-09 10:06:33 --> Config Class Initialized
INFO - 2023-05-09 10:06:33 --> Config Class Initialized
INFO - 2023-05-09 10:06:33 --> Hooks Class Initialized
INFO - 2023-05-09 10:06:33 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:33 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:06:33 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:33 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:33 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:33 --> URI Class Initialized
INFO - 2023-05-09 10:06:33 --> URI Class Initialized
INFO - 2023-05-09 10:06:33 --> Router Class Initialized
INFO - 2023-05-09 10:06:33 --> Router Class Initialized
INFO - 2023-05-09 10:06:33 --> Output Class Initialized
INFO - 2023-05-09 10:06:33 --> Output Class Initialized
INFO - 2023-05-09 10:06:33 --> Security Class Initialized
INFO - 2023-05-09 10:06:33 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:33 --> Input Class Initialized
INFO - 2023-05-09 10:06:33 --> Input Class Initialized
INFO - 2023-05-09 10:06:33 --> Language Class Initialized
INFO - 2023-05-09 10:06:33 --> Language Class Initialized
INFO - 2023-05-09 10:06:33 --> Loader Class Initialized
INFO - 2023-05-09 10:06:33 --> Loader Class Initialized
INFO - 2023-05-09 10:06:33 --> Controller Class Initialized
INFO - 2023-05-09 10:06:33 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:06:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:33 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:33 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:33 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:33 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:33 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:33 --> Total execution time: 0.3475
INFO - 2023-05-09 10:06:33 --> Config Class Initialized
INFO - 2023-05-09 10:06:33 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:33 --> Total execution time: 0.3686
INFO - 2023-05-09 10:06:33 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:33 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:33 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:33 --> URI Class Initialized
INFO - 2023-05-09 10:06:33 --> Router Class Initialized
INFO - 2023-05-09 10:06:33 --> Output Class Initialized
INFO - 2023-05-09 10:06:33 --> Security Class Initialized
INFO - 2023-05-09 10:06:33 --> Config Class Initialized
INFO - 2023-05-09 10:06:33 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:33 --> Input Class Initialized
DEBUG - 2023-05-09 10:06:33 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:33 --> Language Class Initialized
INFO - 2023-05-09 10:06:33 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:33 --> Loader Class Initialized
INFO - 2023-05-09 10:06:33 --> URI Class Initialized
INFO - 2023-05-09 10:06:33 --> Controller Class Initialized
INFO - 2023-05-09 10:06:33 --> Router Class Initialized
DEBUG - 2023-05-09 10:06:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:33 --> Output Class Initialized
INFO - 2023-05-09 10:06:33 --> Security Class Initialized
INFO - 2023-05-09 10:06:33 --> Database Driver Class Initialized
DEBUG - 2023-05-09 10:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:33 --> Input Class Initialized
INFO - 2023-05-09 10:06:33 --> Language Class Initialized
INFO - 2023-05-09 10:06:33 --> Loader Class Initialized
INFO - 2023-05-09 10:06:33 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:33 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:33 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:33 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:33 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:33 --> Total execution time: 0.1086
INFO - 2023-05-09 10:06:33 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:33 --> Total execution time: 0.0815
INFO - 2023-05-09 10:06:34 --> Config Class Initialized
INFO - 2023-05-09 10:06:34 --> Config Class Initialized
INFO - 2023-05-09 10:06:34 --> Hooks Class Initialized
INFO - 2023-05-09 10:06:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:06:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:34 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:34 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:34 --> URI Class Initialized
INFO - 2023-05-09 10:06:34 --> URI Class Initialized
INFO - 2023-05-09 10:06:34 --> Router Class Initialized
INFO - 2023-05-09 10:06:34 --> Router Class Initialized
INFO - 2023-05-09 10:06:34 --> Output Class Initialized
INFO - 2023-05-09 10:06:34 --> Output Class Initialized
INFO - 2023-05-09 10:06:34 --> Security Class Initialized
INFO - 2023-05-09 10:06:34 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:34 --> Input Class Initialized
INFO - 2023-05-09 10:06:34 --> Input Class Initialized
INFO - 2023-05-09 10:06:34 --> Language Class Initialized
INFO - 2023-05-09 10:06:34 --> Language Class Initialized
INFO - 2023-05-09 10:06:34 --> Loader Class Initialized
INFO - 2023-05-09 10:06:34 --> Loader Class Initialized
INFO - 2023-05-09 10:06:34 --> Controller Class Initialized
INFO - 2023-05-09 10:06:34 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:06:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:34 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:34 --> Total execution time: 0.0043
INFO - 2023-05-09 10:06:34 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:34 --> Config Class Initialized
INFO - 2023-05-09 10:06:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:34 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:34 --> URI Class Initialized
INFO - 2023-05-09 10:06:34 --> Router Class Initialized
INFO - 2023-05-09 10:06:34 --> Output Class Initialized
INFO - 2023-05-09 10:06:34 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:34 --> Input Class Initialized
INFO - 2023-05-09 10:06:34 --> Language Class Initialized
INFO - 2023-05-09 10:06:34 --> Loader Class Initialized
INFO - 2023-05-09 10:06:34 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:34 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:34 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:34 --> Total execution time: 0.2723
INFO - 2023-05-09 10:06:34 --> Model "Login_model" initialized
INFO - 2023-05-09 10:06:34 --> Config Class Initialized
INFO - 2023-05-09 10:06:34 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:34 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:34 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:34 --> URI Class Initialized
INFO - 2023-05-09 10:06:34 --> Router Class Initialized
INFO - 2023-05-09 10:06:34 --> Output Class Initialized
INFO - 2023-05-09 10:06:34 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:34 --> Input Class Initialized
INFO - 2023-05-09 10:06:34 --> Language Class Initialized
INFO - 2023-05-09 10:06:34 --> Loader Class Initialized
INFO - 2023-05-09 10:06:34 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:34 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:34 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:34 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:34 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:34 --> Total execution time: 0.2821
INFO - 2023-05-09 10:06:34 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:34 --> Total execution time: 0.0156
INFO - 2023-05-09 10:06:36 --> Config Class Initialized
INFO - 2023-05-09 10:06:36 --> Config Class Initialized
INFO - 2023-05-09 10:06:36 --> Hooks Class Initialized
INFO - 2023-05-09 10:06:36 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:06:36 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:36 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:36 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:36 --> URI Class Initialized
INFO - 2023-05-09 10:06:36 --> URI Class Initialized
INFO - 2023-05-09 10:06:36 --> Router Class Initialized
INFO - 2023-05-09 10:06:36 --> Router Class Initialized
INFO - 2023-05-09 10:06:36 --> Output Class Initialized
INFO - 2023-05-09 10:06:36 --> Output Class Initialized
INFO - 2023-05-09 10:06:36 --> Security Class Initialized
INFO - 2023-05-09 10:06:36 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:36 --> Input Class Initialized
INFO - 2023-05-09 10:06:36 --> Input Class Initialized
INFO - 2023-05-09 10:06:36 --> Language Class Initialized
INFO - 2023-05-09 10:06:36 --> Language Class Initialized
INFO - 2023-05-09 10:06:36 --> Loader Class Initialized
INFO - 2023-05-09 10:06:36 --> Loader Class Initialized
INFO - 2023-05-09 10:06:36 --> Controller Class Initialized
INFO - 2023-05-09 10:06:36 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:06:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:36 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:36 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:36 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:36 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:36 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:36 --> Total execution time: 0.0155
INFO - 2023-05-09 10:06:36 --> Config Class Initialized
INFO - 2023-05-09 10:06:36 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:36 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:36 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:36 --> URI Class Initialized
INFO - 2023-05-09 10:06:36 --> Router Class Initialized
INFO - 2023-05-09 10:06:36 --> Output Class Initialized
INFO - 2023-05-09 10:06:36 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:36 --> Input Class Initialized
INFO - 2023-05-09 10:06:36 --> Language Class Initialized
INFO - 2023-05-09 10:06:36 --> Loader Class Initialized
INFO - 2023-05-09 10:06:36 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:36 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:36 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:36 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:36 --> Model "Login_model" initialized
INFO - 2023-05-09 10:06:36 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:36 --> Total execution time: 0.0137
INFO - 2023-05-09 10:06:36 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:36 --> Total execution time: 0.3065
INFO - 2023-05-09 10:06:36 --> Config Class Initialized
INFO - 2023-05-09 10:06:36 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:06:36 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:06:36 --> Utf8 Class Initialized
INFO - 2023-05-09 10:06:36 --> URI Class Initialized
INFO - 2023-05-09 10:06:36 --> Router Class Initialized
INFO - 2023-05-09 10:06:36 --> Output Class Initialized
INFO - 2023-05-09 10:06:36 --> Security Class Initialized
DEBUG - 2023-05-09 10:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:06:36 --> Input Class Initialized
INFO - 2023-05-09 10:06:36 --> Language Class Initialized
INFO - 2023-05-09 10:06:36 --> Loader Class Initialized
INFO - 2023-05-09 10:06:36 --> Controller Class Initialized
DEBUG - 2023-05-09 10:06:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:06:36 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:36 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:06:36 --> Database Driver Class Initialized
INFO - 2023-05-09 10:06:36 --> Model "Login_model" initialized
INFO - 2023-05-09 10:06:36 --> Final output sent to browser
DEBUG - 2023-05-09 10:06:36 --> Total execution time: 0.0646
INFO - 2023-05-09 10:07:53 --> Config Class Initialized
INFO - 2023-05-09 10:07:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:07:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:07:53 --> Utf8 Class Initialized
INFO - 2023-05-09 10:07:53 --> URI Class Initialized
INFO - 2023-05-09 10:07:53 --> Router Class Initialized
INFO - 2023-05-09 10:07:53 --> Output Class Initialized
INFO - 2023-05-09 10:07:53 --> Security Class Initialized
DEBUG - 2023-05-09 10:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:07:53 --> Input Class Initialized
INFO - 2023-05-09 10:07:53 --> Language Class Initialized
INFO - 2023-05-09 10:07:53 --> Loader Class Initialized
INFO - 2023-05-09 10:07:53 --> Controller Class Initialized
DEBUG - 2023-05-09 10:07:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:07:53 --> Database Driver Class Initialized
INFO - 2023-05-09 10:07:53 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:07:53 --> Final output sent to browser
DEBUG - 2023-05-09 10:07:53 --> Total execution time: 0.2068
INFO - 2023-05-09 10:07:53 --> Config Class Initialized
INFO - 2023-05-09 10:07:53 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:07:53 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:07:53 --> Utf8 Class Initialized
INFO - 2023-05-09 10:07:53 --> URI Class Initialized
INFO - 2023-05-09 10:07:53 --> Router Class Initialized
INFO - 2023-05-09 10:07:53 --> Output Class Initialized
INFO - 2023-05-09 10:07:53 --> Security Class Initialized
DEBUG - 2023-05-09 10:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:07:53 --> Input Class Initialized
INFO - 2023-05-09 10:07:53 --> Language Class Initialized
INFO - 2023-05-09 10:07:53 --> Loader Class Initialized
INFO - 2023-05-09 10:07:53 --> Controller Class Initialized
DEBUG - 2023-05-09 10:07:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:07:53 --> Database Driver Class Initialized
INFO - 2023-05-09 10:07:53 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:07:53 --> Final output sent to browser
DEBUG - 2023-05-09 10:07:53 --> Total execution time: 0.0573
INFO - 2023-05-09 10:08:08 --> Config Class Initialized
INFO - 2023-05-09 10:08:08 --> Config Class Initialized
INFO - 2023-05-09 10:08:08 --> Hooks Class Initialized
INFO - 2023-05-09 10:08:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:08:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:08 --> Utf8 Class Initialized
DEBUG - 2023-05-09 10:08:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:08 --> URI Class Initialized
INFO - 2023-05-09 10:08:08 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:08 --> Router Class Initialized
INFO - 2023-05-09 10:08:08 --> URI Class Initialized
INFO - 2023-05-09 10:08:08 --> Output Class Initialized
INFO - 2023-05-09 10:08:08 --> Router Class Initialized
INFO - 2023-05-09 10:08:08 --> Security Class Initialized
INFO - 2023-05-09 10:08:08 --> Output Class Initialized
DEBUG - 2023-05-09 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:08 --> Security Class Initialized
INFO - 2023-05-09 10:08:08 --> Input Class Initialized
DEBUG - 2023-05-09 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:08 --> Language Class Initialized
INFO - 2023-05-09 10:08:08 --> Input Class Initialized
INFO - 2023-05-09 10:08:08 --> Loader Class Initialized
INFO - 2023-05-09 10:08:08 --> Language Class Initialized
INFO - 2023-05-09 10:08:08 --> Controller Class Initialized
INFO - 2023-05-09 10:08:08 --> Loader Class Initialized
DEBUG - 2023-05-09 10:08:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:08 --> Controller Class Initialized
INFO - 2023-05-09 10:08:08 --> Database Driver Class Initialized
DEBUG - 2023-05-09 10:08:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:08 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:08 --> Total execution time: 0.0052
INFO - 2023-05-09 10:08:08 --> Config Class Initialized
INFO - 2023-05-09 10:08:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:08:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:08 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:08 --> URI Class Initialized
INFO - 2023-05-09 10:08:08 --> Router Class Initialized
INFO - 2023-05-09 10:08:08 --> Output Class Initialized
INFO - 2023-05-09 10:08:08 --> Security Class Initialized
DEBUG - 2023-05-09 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:08 --> Input Class Initialized
INFO - 2023-05-09 10:08:08 --> Language Class Initialized
INFO - 2023-05-09 10:08:08 --> Loader Class Initialized
INFO - 2023-05-09 10:08:08 --> Controller Class Initialized
DEBUG - 2023-05-09 10:08:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:08 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:08 --> Model "Login_model" initialized
INFO - 2023-05-09 10:08:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:08:08 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:08 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:08 --> Total execution time: 0.0613
INFO - 2023-05-09 10:08:08 --> Config Class Initialized
INFO - 2023-05-09 10:08:08 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:08:08 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:08 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:08 --> URI Class Initialized
INFO - 2023-05-09 10:08:08 --> Router Class Initialized
INFO - 2023-05-09 10:08:08 --> Output Class Initialized
INFO - 2023-05-09 10:08:08 --> Security Class Initialized
DEBUG - 2023-05-09 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:08 --> Input Class Initialized
INFO - 2023-05-09 10:08:08 --> Language Class Initialized
INFO - 2023-05-09 10:08:08 --> Loader Class Initialized
INFO - 2023-05-09 10:08:08 --> Controller Class Initialized
INFO - 2023-05-09 10:08:08 --> Model "Cluster_model" initialized
DEBUG - 2023-05-09 10:08:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:08 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:08 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:08 --> Total execution time: 0.0611
INFO - 2023-05-09 10:08:08 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:08:08 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:08 --> Total execution time: 0.0585
INFO - 2023-05-09 10:08:10 --> Config Class Initialized
INFO - 2023-05-09 10:08:10 --> Config Class Initialized
INFO - 2023-05-09 10:08:10 --> Hooks Class Initialized
INFO - 2023-05-09 10:08:10 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:08:10 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:08:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:10 --> URI Class Initialized
INFO - 2023-05-09 10:08:10 --> URI Class Initialized
INFO - 2023-05-09 10:08:10 --> Router Class Initialized
INFO - 2023-05-09 10:08:10 --> Router Class Initialized
INFO - 2023-05-09 10:08:10 --> Output Class Initialized
INFO - 2023-05-09 10:08:10 --> Output Class Initialized
INFO - 2023-05-09 10:08:10 --> Security Class Initialized
INFO - 2023-05-09 10:08:10 --> Security Class Initialized
DEBUG - 2023-05-09 10:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:10 --> Input Class Initialized
INFO - 2023-05-09 10:08:10 --> Input Class Initialized
INFO - 2023-05-09 10:08:10 --> Language Class Initialized
INFO - 2023-05-09 10:08:10 --> Language Class Initialized
INFO - 2023-05-09 10:08:10 --> Loader Class Initialized
INFO - 2023-05-09 10:08:10 --> Controller Class Initialized
INFO - 2023-05-09 10:08:10 --> Loader Class Initialized
DEBUG - 2023-05-09 10:08:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:10 --> Controller Class Initialized
DEBUG - 2023-05-09 10:08:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:08:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:08:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:10 --> Total execution time: 0.0520
INFO - 2023-05-09 10:08:10 --> Config Class Initialized
INFO - 2023-05-09 10:08:10 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:08:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:10 --> URI Class Initialized
INFO - 2023-05-09 10:08:10 --> Router Class Initialized
INFO - 2023-05-09 10:08:10 --> Output Class Initialized
INFO - 2023-05-09 10:08:10 --> Security Class Initialized
DEBUG - 2023-05-09 10:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:10 --> Input Class Initialized
INFO - 2023-05-09 10:08:10 --> Language Class Initialized
INFO - 2023-05-09 10:08:10 --> Loader Class Initialized
INFO - 2023-05-09 10:08:10 --> Controller Class Initialized
DEBUG - 2023-05-09 10:08:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:08:10 --> Model "Login_model" initialized
INFO - 2023-05-09 10:08:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:10 --> Total execution time: 0.0121
INFO - 2023-05-09 10:08:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:10 --> Total execution time: 0.0807
INFO - 2023-05-09 10:08:10 --> Config Class Initialized
INFO - 2023-05-09 10:08:10 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:08:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:10 --> URI Class Initialized
INFO - 2023-05-09 10:08:10 --> Router Class Initialized
INFO - 2023-05-09 10:08:10 --> Output Class Initialized
INFO - 2023-05-09 10:08:10 --> Security Class Initialized
DEBUG - 2023-05-09 10:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:10 --> Input Class Initialized
INFO - 2023-05-09 10:08:10 --> Language Class Initialized
INFO - 2023-05-09 10:08:10 --> Loader Class Initialized
INFO - 2023-05-09 10:08:10 --> Controller Class Initialized
DEBUG - 2023-05-09 10:08:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:08:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:10 --> Model "Login_model" initialized
INFO - 2023-05-09 10:08:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:10 --> Total execution time: 0.0369
INFO - 2023-05-09 10:08:16 --> Config Class Initialized
INFO - 2023-05-09 10:08:16 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:08:16 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:16 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:16 --> URI Class Initialized
INFO - 2023-05-09 10:08:16 --> Router Class Initialized
INFO - 2023-05-09 10:08:16 --> Output Class Initialized
INFO - 2023-05-09 10:08:16 --> Security Class Initialized
DEBUG - 2023-05-09 10:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:16 --> Input Class Initialized
INFO - 2023-05-09 10:08:16 --> Language Class Initialized
INFO - 2023-05-09 10:08:16 --> Loader Class Initialized
INFO - 2023-05-09 10:08:16 --> Controller Class Initialized
DEBUG - 2023-05-09 10:08:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:16 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:16 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:08:16 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:16 --> Total execution time: 0.1173
INFO - 2023-05-09 10:08:16 --> Config Class Initialized
INFO - 2023-05-09 10:08:17 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:08:17 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:08:17 --> Utf8 Class Initialized
INFO - 2023-05-09 10:08:17 --> URI Class Initialized
INFO - 2023-05-09 10:08:17 --> Router Class Initialized
INFO - 2023-05-09 10:08:17 --> Output Class Initialized
INFO - 2023-05-09 10:08:17 --> Security Class Initialized
DEBUG - 2023-05-09 10:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:08:17 --> Input Class Initialized
INFO - 2023-05-09 10:08:17 --> Language Class Initialized
INFO - 2023-05-09 10:08:17 --> Loader Class Initialized
INFO - 2023-05-09 10:08:17 --> Controller Class Initialized
DEBUG - 2023-05-09 10:08:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:08:17 --> Database Driver Class Initialized
INFO - 2023-05-09 10:08:17 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:08:17 --> Final output sent to browser
DEBUG - 2023-05-09 10:08:17 --> Total execution time: 0.0526
INFO - 2023-05-09 10:09:43 --> Config Class Initialized
INFO - 2023-05-09 10:09:43 --> Config Class Initialized
INFO - 2023-05-09 10:09:43 --> Hooks Class Initialized
INFO - 2023-05-09 10:09:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:09:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:43 --> URI Class Initialized
INFO - 2023-05-09 10:09:43 --> URI Class Initialized
INFO - 2023-05-09 10:09:43 --> Router Class Initialized
INFO - 2023-05-09 10:09:43 --> Router Class Initialized
INFO - 2023-05-09 10:09:43 --> Output Class Initialized
INFO - 2023-05-09 10:09:43 --> Output Class Initialized
INFO - 2023-05-09 10:09:43 --> Security Class Initialized
INFO - 2023-05-09 10:09:43 --> Security Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:43 --> Input Class Initialized
INFO - 2023-05-09 10:09:43 --> Language Class Initialized
INFO - 2023-05-09 10:09:43 --> Input Class Initialized
INFO - 2023-05-09 10:09:43 --> Language Class Initialized
INFO - 2023-05-09 10:09:43 --> Loader Class Initialized
INFO - 2023-05-09 10:09:43 --> Loader Class Initialized
INFO - 2023-05-09 10:09:43 --> Controller Class Initialized
INFO - 2023-05-09 10:09:43 --> Controller Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:43 --> Total execution time: 0.0057
INFO - 2023-05-09 10:09:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:43 --> Config Class Initialized
INFO - 2023-05-09 10:09:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:09:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:43 --> URI Class Initialized
INFO - 2023-05-09 10:09:43 --> Router Class Initialized
INFO - 2023-05-09 10:09:43 --> Output Class Initialized
INFO - 2023-05-09 10:09:43 --> Security Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:43 --> Input Class Initialized
INFO - 2023-05-09 10:09:43 --> Language Class Initialized
INFO - 2023-05-09 10:09:43 --> Loader Class Initialized
INFO - 2023-05-09 10:09:43 --> Controller Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:43 --> Total execution time: 0.0506
INFO - 2023-05-09 10:09:43 --> Config Class Initialized
INFO - 2023-05-09 10:09:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:09:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:43 --> URI Class Initialized
INFO - 2023-05-09 10:09:43 --> Router Class Initialized
INFO - 2023-05-09 10:09:43 --> Output Class Initialized
INFO - 2023-05-09 10:09:43 --> Security Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:43 --> Input Class Initialized
INFO - 2023-05-09 10:09:43 --> Language Class Initialized
INFO - 2023-05-09 10:09:43 --> Loader Class Initialized
INFO - 2023-05-09 10:09:43 --> Controller Class Initialized
INFO - 2023-05-09 10:09:43 --> Model "Login_model" initialized
DEBUG - 2023-05-09 10:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:43 --> Total execution time: 0.0180
INFO - 2023-05-09 10:09:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:43 --> Total execution time: 0.0657
INFO - 2023-05-09 10:09:43 --> Config Class Initialized
INFO - 2023-05-09 10:09:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:09:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:43 --> URI Class Initialized
INFO - 2023-05-09 10:09:43 --> Router Class Initialized
INFO - 2023-05-09 10:09:43 --> Output Class Initialized
INFO - 2023-05-09 10:09:43 --> Security Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:43 --> Input Class Initialized
INFO - 2023-05-09 10:09:43 --> Language Class Initialized
INFO - 2023-05-09 10:09:43 --> Loader Class Initialized
INFO - 2023-05-09 10:09:43 --> Controller Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:43 --> Total execution time: 0.2490
INFO - 2023-05-09 10:09:43 --> Config Class Initialized
INFO - 2023-05-09 10:09:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:09:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:43 --> URI Class Initialized
INFO - 2023-05-09 10:09:43 --> Router Class Initialized
INFO - 2023-05-09 10:09:43 --> Output Class Initialized
INFO - 2023-05-09 10:09:43 --> Security Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:43 --> Input Class Initialized
INFO - 2023-05-09 10:09:43 --> Language Class Initialized
INFO - 2023-05-09 10:09:43 --> Loader Class Initialized
INFO - 2023-05-09 10:09:43 --> Controller Class Initialized
DEBUG - 2023-05-09 10:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:43 --> Total execution time: 0.0580
INFO - 2023-05-09 10:09:59 --> Config Class Initialized
INFO - 2023-05-09 10:09:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:09:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:59 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:59 --> URI Class Initialized
INFO - 2023-05-09 10:09:59 --> Config Class Initialized
INFO - 2023-05-09 10:09:59 --> Hooks Class Initialized
INFO - 2023-05-09 10:09:59 --> Router Class Initialized
DEBUG - 2023-05-09 10:09:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:59 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:59 --> Output Class Initialized
INFO - 2023-05-09 10:09:59 --> URI Class Initialized
INFO - 2023-05-09 10:09:59 --> Security Class Initialized
INFO - 2023-05-09 10:09:59 --> Router Class Initialized
DEBUG - 2023-05-09 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:59 --> Output Class Initialized
INFO - 2023-05-09 10:09:59 --> Security Class Initialized
INFO - 2023-05-09 10:09:59 --> Input Class Initialized
DEBUG - 2023-05-09 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:59 --> Language Class Initialized
INFO - 2023-05-09 10:09:59 --> Input Class Initialized
INFO - 2023-05-09 10:09:59 --> Loader Class Initialized
INFO - 2023-05-09 10:09:59 --> Language Class Initialized
INFO - 2023-05-09 10:09:59 --> Controller Class Initialized
INFO - 2023-05-09 10:09:59 --> Loader Class Initialized
DEBUG - 2023-05-09 10:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:59 --> Controller Class Initialized
DEBUG - 2023-05-09 10:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:59 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:59 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:59 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:59 --> Total execution time: 0.0429
INFO - 2023-05-09 10:09:59 --> Config Class Initialized
INFO - 2023-05-09 10:09:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:09:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:59 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:59 --> URI Class Initialized
INFO - 2023-05-09 10:09:59 --> Router Class Initialized
INFO - 2023-05-09 10:09:59 --> Output Class Initialized
INFO - 2023-05-09 10:09:59 --> Security Class Initialized
DEBUG - 2023-05-09 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:59 --> Input Class Initialized
INFO - 2023-05-09 10:09:59 --> Language Class Initialized
INFO - 2023-05-09 10:09:59 --> Loader Class Initialized
INFO - 2023-05-09 10:09:59 --> Controller Class Initialized
DEBUG - 2023-05-09 10:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:59 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:59 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:59 --> Total execution time: 0.0444
INFO - 2023-05-09 10:09:59 --> Config Class Initialized
INFO - 2023-05-09 10:09:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:09:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:09:59 --> Utf8 Class Initialized
INFO - 2023-05-09 10:09:59 --> URI Class Initialized
INFO - 2023-05-09 10:09:59 --> Router Class Initialized
INFO - 2023-05-09 10:09:59 --> Output Class Initialized
INFO - 2023-05-09 10:09:59 --> Security Class Initialized
DEBUG - 2023-05-09 10:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:09:59 --> Input Class Initialized
INFO - 2023-05-09 10:09:59 --> Language Class Initialized
INFO - 2023-05-09 10:09:59 --> Loader Class Initialized
INFO - 2023-05-09 10:09:59 --> Controller Class Initialized
DEBUG - 2023-05-09 10:09:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:09:59 --> Database Driver Class Initialized
INFO - 2023-05-09 10:09:59 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:59 --> Total execution time: 0.0884
INFO - 2023-05-09 10:09:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:09:59 --> Final output sent to browser
DEBUG - 2023-05-09 10:09:59 --> Total execution time: 0.1383
INFO - 2023-05-09 10:10:29 --> Config Class Initialized
INFO - 2023-05-09 10:10:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:10:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:10:29 --> Utf8 Class Initialized
INFO - 2023-05-09 10:10:29 --> URI Class Initialized
INFO - 2023-05-09 10:10:29 --> Router Class Initialized
INFO - 2023-05-09 10:10:29 --> Output Class Initialized
INFO - 2023-05-09 10:10:29 --> Security Class Initialized
DEBUG - 2023-05-09 10:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:10:29 --> Input Class Initialized
INFO - 2023-05-09 10:10:29 --> Language Class Initialized
INFO - 2023-05-09 10:10:29 --> Loader Class Initialized
INFO - 2023-05-09 10:10:29 --> Controller Class Initialized
DEBUG - 2023-05-09 10:10:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:10:29 --> Database Driver Class Initialized
INFO - 2023-05-09 10:10:30 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:10:30 --> Final output sent to browser
DEBUG - 2023-05-09 10:10:30 --> Total execution time: 0.2404
INFO - 2023-05-09 10:10:30 --> Config Class Initialized
INFO - 2023-05-09 10:10:30 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:10:30 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:10:30 --> Utf8 Class Initialized
INFO - 2023-05-09 10:10:30 --> URI Class Initialized
INFO - 2023-05-09 10:10:30 --> Router Class Initialized
INFO - 2023-05-09 10:10:30 --> Output Class Initialized
INFO - 2023-05-09 10:10:30 --> Security Class Initialized
DEBUG - 2023-05-09 10:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:10:30 --> Input Class Initialized
INFO - 2023-05-09 10:10:30 --> Language Class Initialized
INFO - 2023-05-09 10:10:30 --> Loader Class Initialized
INFO - 2023-05-09 10:10:30 --> Controller Class Initialized
DEBUG - 2023-05-09 10:10:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:10:30 --> Database Driver Class Initialized
INFO - 2023-05-09 10:10:30 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:10:30 --> Final output sent to browser
DEBUG - 2023-05-09 10:10:30 --> Total execution time: 0.0159
INFO - 2023-05-09 10:11:49 --> Config Class Initialized
INFO - 2023-05-09 10:11:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:49 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:49 --> URI Class Initialized
INFO - 2023-05-09 10:11:49 --> Router Class Initialized
INFO - 2023-05-09 10:11:49 --> Output Class Initialized
INFO - 2023-05-09 10:11:49 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:49 --> Input Class Initialized
INFO - 2023-05-09 10:11:49 --> Language Class Initialized
INFO - 2023-05-09 10:11:49 --> Loader Class Initialized
INFO - 2023-05-09 10:11:49 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:49 --> Final output sent to browser
DEBUG - 2023-05-09 10:11:49 --> Total execution time: 0.0470
INFO - 2023-05-09 10:11:49 --> Config Class Initialized
INFO - 2023-05-09 10:11:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:49 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:49 --> URI Class Initialized
INFO - 2023-05-09 10:11:49 --> Router Class Initialized
INFO - 2023-05-09 10:11:49 --> Output Class Initialized
INFO - 2023-05-09 10:11:49 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:49 --> Input Class Initialized
INFO - 2023-05-09 10:11:49 --> Language Class Initialized
INFO - 2023-05-09 10:11:49 --> Loader Class Initialized
INFO - 2023-05-09 10:11:49 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:49 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:11:49 --> Final output sent to browser
DEBUG - 2023-05-09 10:11:49 --> Total execution time: 0.0538
INFO - 2023-05-09 10:11:52 --> Config Class Initialized
INFO - 2023-05-09 10:11:52 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:52 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:52 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:52 --> URI Class Initialized
INFO - 2023-05-09 10:11:52 --> Router Class Initialized
INFO - 2023-05-09 10:11:52 --> Output Class Initialized
INFO - 2023-05-09 10:11:52 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:52 --> Input Class Initialized
INFO - 2023-05-09 10:11:52 --> Language Class Initialized
INFO - 2023-05-09 10:11:52 --> Loader Class Initialized
INFO - 2023-05-09 10:11:52 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:52 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:11:52 --> Final output sent to browser
DEBUG - 2023-05-09 10:11:52 --> Total execution time: 0.0379
INFO - 2023-05-09 10:11:52 --> Config Class Initialized
INFO - 2023-05-09 10:11:52 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:52 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:52 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:52 --> URI Class Initialized
INFO - 2023-05-09 10:11:52 --> Router Class Initialized
INFO - 2023-05-09 10:11:52 --> Output Class Initialized
INFO - 2023-05-09 10:11:52 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:52 --> Input Class Initialized
INFO - 2023-05-09 10:11:52 --> Language Class Initialized
INFO - 2023-05-09 10:11:52 --> Loader Class Initialized
INFO - 2023-05-09 10:11:52 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:52 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:52 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:11:52 --> Final output sent to browser
DEBUG - 2023-05-09 10:11:52 --> Total execution time: 0.2781
INFO - 2023-05-09 10:11:56 --> Config Class Initialized
INFO - 2023-05-09 10:11:56 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:56 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:56 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:56 --> URI Class Initialized
INFO - 2023-05-09 10:11:56 --> Router Class Initialized
INFO - 2023-05-09 10:11:56 --> Output Class Initialized
INFO - 2023-05-09 10:11:56 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:56 --> Input Class Initialized
INFO - 2023-05-09 10:11:56 --> Language Class Initialized
INFO - 2023-05-09 10:11:56 --> Loader Class Initialized
INFO - 2023-05-09 10:11:56 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:56 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:56 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:11:56 --> Final output sent to browser
DEBUG - 2023-05-09 10:11:56 --> Total execution time: 0.1791
INFO - 2023-05-09 10:11:56 --> Config Class Initialized
INFO - 2023-05-09 10:11:56 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:56 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:56 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:56 --> URI Class Initialized
INFO - 2023-05-09 10:11:56 --> Router Class Initialized
INFO - 2023-05-09 10:11:56 --> Output Class Initialized
INFO - 2023-05-09 10:11:56 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:56 --> Input Class Initialized
INFO - 2023-05-09 10:11:56 --> Language Class Initialized
INFO - 2023-05-09 10:11:56 --> Loader Class Initialized
INFO - 2023-05-09 10:11:56 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:56 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:56 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:11:56 --> Final output sent to browser
DEBUG - 2023-05-09 10:11:56 --> Total execution time: 0.0163
INFO - 2023-05-09 10:11:57 --> Config Class Initialized
INFO - 2023-05-09 10:11:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:57 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:57 --> URI Class Initialized
INFO - 2023-05-09 10:11:57 --> Router Class Initialized
INFO - 2023-05-09 10:11:57 --> Output Class Initialized
INFO - 2023-05-09 10:11:57 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:57 --> Input Class Initialized
INFO - 2023-05-09 10:11:57 --> Language Class Initialized
INFO - 2023-05-09 10:11:57 --> Loader Class Initialized
INFO - 2023-05-09 10:11:57 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:57 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:11:57 --> Final output sent to browser
DEBUG - 2023-05-09 10:11:57 --> Total execution time: 0.0451
INFO - 2023-05-09 10:11:57 --> Config Class Initialized
INFO - 2023-05-09 10:11:57 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:57 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:57 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:57 --> URI Class Initialized
INFO - 2023-05-09 10:11:57 --> Router Class Initialized
INFO - 2023-05-09 10:11:57 --> Output Class Initialized
INFO - 2023-05-09 10:11:57 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:57 --> Input Class Initialized
INFO - 2023-05-09 10:11:57 --> Language Class Initialized
INFO - 2023-05-09 10:11:57 --> Loader Class Initialized
INFO - 2023-05-09 10:11:57 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:57 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:57 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:11:58 --> Config Class Initialized
INFO - 2023-05-09 10:11:58 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:58 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:58 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:58 --> URI Class Initialized
INFO - 2023-05-09 10:11:58 --> Router Class Initialized
INFO - 2023-05-09 10:11:58 --> Output Class Initialized
INFO - 2023-05-09 10:11:58 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:58 --> Input Class Initialized
INFO - 2023-05-09 10:11:58 --> Language Class Initialized
INFO - 2023-05-09 10:11:58 --> Loader Class Initialized
INFO - 2023-05-09 10:11:58 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:58 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:58 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:11:59 --> Config Class Initialized
INFO - 2023-05-09 10:11:59 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:11:59 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:11:59 --> Utf8 Class Initialized
INFO - 2023-05-09 10:11:59 --> URI Class Initialized
INFO - 2023-05-09 10:11:59 --> Router Class Initialized
INFO - 2023-05-09 10:11:59 --> Output Class Initialized
INFO - 2023-05-09 10:11:59 --> Security Class Initialized
DEBUG - 2023-05-09 10:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:11:59 --> Input Class Initialized
INFO - 2023-05-09 10:11:59 --> Language Class Initialized
INFO - 2023-05-09 10:11:59 --> Loader Class Initialized
INFO - 2023-05-09 10:11:59 --> Controller Class Initialized
DEBUG - 2023-05-09 10:11:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:11:59 --> Database Driver Class Initialized
INFO - 2023-05-09 10:11:59 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:00 --> Config Class Initialized
INFO - 2023-05-09 10:12:00 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:00 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:00 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:00 --> URI Class Initialized
INFO - 2023-05-09 10:12:00 --> Router Class Initialized
INFO - 2023-05-09 10:12:00 --> Output Class Initialized
INFO - 2023-05-09 10:12:00 --> Security Class Initialized
DEBUG - 2023-05-09 10:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:00 --> Input Class Initialized
INFO - 2023-05-09 10:12:00 --> Language Class Initialized
INFO - 2023-05-09 10:12:00 --> Loader Class Initialized
INFO - 2023-05-09 10:12:00 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:00 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:00 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:01 --> Config Class Initialized
INFO - 2023-05-09 10:12:01 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:01 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:01 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:01 --> URI Class Initialized
INFO - 2023-05-09 10:12:01 --> Router Class Initialized
INFO - 2023-05-09 10:12:01 --> Output Class Initialized
INFO - 2023-05-09 10:12:01 --> Security Class Initialized
DEBUG - 2023-05-09 10:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:01 --> Input Class Initialized
INFO - 2023-05-09 10:12:01 --> Language Class Initialized
INFO - 2023-05-09 10:12:01 --> Loader Class Initialized
INFO - 2023-05-09 10:12:01 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:01 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:01 --> Final output sent to browser
INFO - 2023-05-09 10:12:01 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:01 --> Total execution time: 3.1240
INFO - 2023-05-09 10:12:01 --> Final output sent to browser
INFO - 2023-05-09 10:12:01 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:01 --> Total execution time: 4.0725
DEBUG - 2023-05-09 10:12:01 --> Total execution time: 2.1219
DEBUG - 2023-05-09 10:12:01 --> Total execution time: 1.1106
INFO - 2023-05-09 10:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:01 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:01 --> Total execution time: 0.1361
INFO - 2023-05-09 10:12:01 --> Config Class Initialized
INFO - 2023-05-09 10:12:01 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:01 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:01 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:01 --> URI Class Initialized
INFO - 2023-05-09 10:12:01 --> Router Class Initialized
INFO - 2023-05-09 10:12:01 --> Output Class Initialized
INFO - 2023-05-09 10:12:01 --> Security Class Initialized
DEBUG - 2023-05-09 10:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:01 --> Input Class Initialized
INFO - 2023-05-09 10:12:01 --> Language Class Initialized
INFO - 2023-05-09 10:12:01 --> Loader Class Initialized
INFO - 2023-05-09 10:12:01 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:01 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:01 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:01 --> Total execution time: 0.0135
INFO - 2023-05-09 10:12:01 --> Config Class Initialized
INFO - 2023-05-09 10:12:01 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:01 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:01 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:01 --> URI Class Initialized
INFO - 2023-05-09 10:12:01 --> Router Class Initialized
INFO - 2023-05-09 10:12:01 --> Output Class Initialized
INFO - 2023-05-09 10:12:01 --> Security Class Initialized
DEBUG - 2023-05-09 10:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:01 --> Input Class Initialized
INFO - 2023-05-09 10:12:01 --> Language Class Initialized
INFO - 2023-05-09 10:12:01 --> Loader Class Initialized
INFO - 2023-05-09 10:12:01 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:01 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:01 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:01 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:01 --> Total execution time: 0.0114
INFO - 2023-05-09 10:12:19 --> Config Class Initialized
INFO - 2023-05-09 10:12:19 --> Config Class Initialized
INFO - 2023-05-09 10:12:19 --> Hooks Class Initialized
INFO - 2023-05-09 10:12:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:19 --> Utf8 Class Initialized
DEBUG - 2023-05-09 10:12:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:19 --> URI Class Initialized
INFO - 2023-05-09 10:12:19 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:19 --> Router Class Initialized
INFO - 2023-05-09 10:12:19 --> URI Class Initialized
INFO - 2023-05-09 10:12:19 --> Output Class Initialized
INFO - 2023-05-09 10:12:19 --> Router Class Initialized
INFO - 2023-05-09 10:12:19 --> Security Class Initialized
INFO - 2023-05-09 10:12:19 --> Output Class Initialized
DEBUG - 2023-05-09 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:19 --> Security Class Initialized
INFO - 2023-05-09 10:12:19 --> Input Class Initialized
INFO - 2023-05-09 10:12:19 --> Language Class Initialized
DEBUG - 2023-05-09 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:19 --> Input Class Initialized
INFO - 2023-05-09 10:12:19 --> Loader Class Initialized
INFO - 2023-05-09 10:12:19 --> Language Class Initialized
INFO - 2023-05-09 10:12:19 --> Controller Class Initialized
INFO - 2023-05-09 10:12:19 --> Loader Class Initialized
DEBUG - 2023-05-09 10:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:19 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:19 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:19 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:19 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:19 --> Total execution time: 0.0530
INFO - 2023-05-09 10:12:19 --> Config Class Initialized
INFO - 2023-05-09 10:12:19 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:19 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:19 --> URI Class Initialized
INFO - 2023-05-09 10:12:19 --> Router Class Initialized
INFO - 2023-05-09 10:12:19 --> Output Class Initialized
INFO - 2023-05-09 10:12:19 --> Security Class Initialized
DEBUG - 2023-05-09 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:19 --> Input Class Initialized
INFO - 2023-05-09 10:12:19 --> Language Class Initialized
INFO - 2023-05-09 10:12:19 --> Loader Class Initialized
INFO - 2023-05-09 10:12:19 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:19 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:19 --> Model "Login_model" initialized
INFO - 2023-05-09 10:12:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:19 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:19 --> Total execution time: 0.0503
INFO - 2023-05-09 10:12:19 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:19 --> Total execution time: 0.1139
INFO - 2023-05-09 10:12:19 --> Config Class Initialized
INFO - 2023-05-09 10:12:19 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:19 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:19 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:19 --> URI Class Initialized
INFO - 2023-05-09 10:12:19 --> Router Class Initialized
INFO - 2023-05-09 10:12:19 --> Output Class Initialized
INFO - 2023-05-09 10:12:19 --> Security Class Initialized
DEBUG - 2023-05-09 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:19 --> Input Class Initialized
INFO - 2023-05-09 10:12:19 --> Language Class Initialized
INFO - 2023-05-09 10:12:19 --> Loader Class Initialized
INFO - 2023-05-09 10:12:19 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:19 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:19 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:19 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:19 --> Model "Login_model" initialized
INFO - 2023-05-09 10:12:19 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:19 --> Total execution time: 0.0775
INFO - 2023-05-09 10:12:22 --> Config Class Initialized
INFO - 2023-05-09 10:12:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:22 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:22 --> URI Class Initialized
INFO - 2023-05-09 10:12:22 --> Router Class Initialized
INFO - 2023-05-09 10:12:22 --> Output Class Initialized
INFO - 2023-05-09 10:12:22 --> Security Class Initialized
DEBUG - 2023-05-09 10:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:22 --> Input Class Initialized
INFO - 2023-05-09 10:12:22 --> Language Class Initialized
INFO - 2023-05-09 10:12:22 --> Loader Class Initialized
INFO - 2023-05-09 10:12:22 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:22 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:22 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:22 --> Total execution time: 0.0455
INFO - 2023-05-09 10:12:22 --> Config Class Initialized
INFO - 2023-05-09 10:12:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:12:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:12:22 --> Utf8 Class Initialized
INFO - 2023-05-09 10:12:22 --> URI Class Initialized
INFO - 2023-05-09 10:12:22 --> Router Class Initialized
INFO - 2023-05-09 10:12:22 --> Output Class Initialized
INFO - 2023-05-09 10:12:22 --> Security Class Initialized
DEBUG - 2023-05-09 10:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:12:22 --> Input Class Initialized
INFO - 2023-05-09 10:12:22 --> Language Class Initialized
INFO - 2023-05-09 10:12:22 --> Loader Class Initialized
INFO - 2023-05-09 10:12:22 --> Controller Class Initialized
DEBUG - 2023-05-09 10:12:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:12:22 --> Database Driver Class Initialized
INFO - 2023-05-09 10:12:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:12:22 --> Final output sent to browser
DEBUG - 2023-05-09 10:12:22 --> Total execution time: 0.0124
INFO - 2023-05-09 10:25:09 --> Config Class Initialized
INFO - 2023-05-09 10:25:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:09 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:09 --> URI Class Initialized
INFO - 2023-05-09 10:25:09 --> Router Class Initialized
INFO - 2023-05-09 10:25:09 --> Output Class Initialized
INFO - 2023-05-09 10:25:09 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:09 --> Input Class Initialized
INFO - 2023-05-09 10:25:09 --> Language Class Initialized
INFO - 2023-05-09 10:25:09 --> Loader Class Initialized
INFO - 2023-05-09 10:25:09 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:09 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:09 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:09 --> Total execution time: 0.0107
INFO - 2023-05-09 10:25:09 --> Config Class Initialized
INFO - 2023-05-09 10:25:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:09 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:09 --> URI Class Initialized
INFO - 2023-05-09 10:25:09 --> Router Class Initialized
INFO - 2023-05-09 10:25:09 --> Output Class Initialized
INFO - 2023-05-09 10:25:09 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:09 --> Input Class Initialized
INFO - 2023-05-09 10:25:09 --> Language Class Initialized
INFO - 2023-05-09 10:25:09 --> Loader Class Initialized
INFO - 2023-05-09 10:25:09 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:09 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:09 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:09 --> Total execution time: 0.2444
INFO - 2023-05-09 10:25:10 --> Config Class Initialized
INFO - 2023-05-09 10:25:10 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:10 --> URI Class Initialized
INFO - 2023-05-09 10:25:10 --> Router Class Initialized
INFO - 2023-05-09 10:25:10 --> Output Class Initialized
INFO - 2023-05-09 10:25:10 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:10 --> Input Class Initialized
INFO - 2023-05-09 10:25:10 --> Language Class Initialized
INFO - 2023-05-09 10:25:10 --> Loader Class Initialized
INFO - 2023-05-09 10:25:10 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:10 --> Total execution time: 0.0299
INFO - 2023-05-09 10:25:10 --> Config Class Initialized
INFO - 2023-05-09 10:25:10 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:10 --> URI Class Initialized
INFO - 2023-05-09 10:25:10 --> Router Class Initialized
INFO - 2023-05-09 10:25:10 --> Output Class Initialized
INFO - 2023-05-09 10:25:10 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:10 --> Input Class Initialized
INFO - 2023-05-09 10:25:10 --> Language Class Initialized
INFO - 2023-05-09 10:25:10 --> Loader Class Initialized
INFO - 2023-05-09 10:25:10 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:10 --> Total execution time: 0.0166
INFO - 2023-05-09 10:25:10 --> Config Class Initialized
INFO - 2023-05-09 10:25:10 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:10 --> URI Class Initialized
INFO - 2023-05-09 10:25:10 --> Router Class Initialized
INFO - 2023-05-09 10:25:10 --> Output Class Initialized
INFO - 2023-05-09 10:25:10 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:10 --> Input Class Initialized
INFO - 2023-05-09 10:25:10 --> Language Class Initialized
INFO - 2023-05-09 10:25:10 --> Loader Class Initialized
INFO - 2023-05-09 10:25:10 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:10 --> Total execution time: 0.0128
INFO - 2023-05-09 10:25:10 --> Config Class Initialized
INFO - 2023-05-09 10:25:10 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:10 --> URI Class Initialized
INFO - 2023-05-09 10:25:10 --> Router Class Initialized
INFO - 2023-05-09 10:25:10 --> Output Class Initialized
INFO - 2023-05-09 10:25:10 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:10 --> Input Class Initialized
INFO - 2023-05-09 10:25:10 --> Language Class Initialized
INFO - 2023-05-09 10:25:10 --> Loader Class Initialized
INFO - 2023-05-09 10:25:10 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:10 --> Total execution time: 0.0546
INFO - 2023-05-09 10:25:15 --> Config Class Initialized
INFO - 2023-05-09 10:25:15 --> Config Class Initialized
INFO - 2023-05-09 10:25:15 --> Hooks Class Initialized
INFO - 2023-05-09 10:25:15 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:15 --> Utf8 Class Initialized
DEBUG - 2023-05-09 10:25:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:15 --> URI Class Initialized
INFO - 2023-05-09 10:25:15 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:15 --> Router Class Initialized
INFO - 2023-05-09 10:25:15 --> URI Class Initialized
INFO - 2023-05-09 10:25:15 --> Output Class Initialized
INFO - 2023-05-09 10:25:15 --> Router Class Initialized
INFO - 2023-05-09 10:25:15 --> Security Class Initialized
INFO - 2023-05-09 10:25:15 --> Output Class Initialized
DEBUG - 2023-05-09 10:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:15 --> Security Class Initialized
INFO - 2023-05-09 10:25:15 --> Input Class Initialized
DEBUG - 2023-05-09 10:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:15 --> Language Class Initialized
INFO - 2023-05-09 10:25:15 --> Input Class Initialized
INFO - 2023-05-09 10:25:15 --> Language Class Initialized
INFO - 2023-05-09 10:25:15 --> Loader Class Initialized
INFO - 2023-05-09 10:25:15 --> Loader Class Initialized
INFO - 2023-05-09 10:25:15 --> Controller Class Initialized
INFO - 2023-05-09 10:25:15 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:25:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:15 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:15 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:15 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:15 --> Total execution time: 0.0241
INFO - 2023-05-09 10:25:15 --> Config Class Initialized
INFO - 2023-05-09 10:25:15 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:15 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:15 --> URI Class Initialized
INFO - 2023-05-09 10:25:15 --> Router Class Initialized
INFO - 2023-05-09 10:25:15 --> Output Class Initialized
INFO - 2023-05-09 10:25:15 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:15 --> Input Class Initialized
INFO - 2023-05-09 10:25:15 --> Language Class Initialized
INFO - 2023-05-09 10:25:15 --> Loader Class Initialized
INFO - 2023-05-09 10:25:15 --> Controller Class Initialized
INFO - 2023-05-09 10:25:15 --> Database Driver Class Initialized
DEBUG - 2023-05-09 10:25:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:15 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:15 --> Model "Login_model" initialized
INFO - 2023-05-09 10:25:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:15 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:15 --> Total execution time: 0.0145
INFO - 2023-05-09 10:25:15 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:15 --> Total execution time: 0.0562
INFO - 2023-05-09 10:25:15 --> Config Class Initialized
INFO - 2023-05-09 10:25:15 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:15 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:15 --> URI Class Initialized
INFO - 2023-05-09 10:25:15 --> Router Class Initialized
INFO - 2023-05-09 10:25:15 --> Output Class Initialized
INFO - 2023-05-09 10:25:15 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:15 --> Input Class Initialized
INFO - 2023-05-09 10:25:15 --> Language Class Initialized
INFO - 2023-05-09 10:25:15 --> Loader Class Initialized
INFO - 2023-05-09 10:25:15 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:15 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:15 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:15 --> Model "Login_model" initialized
INFO - 2023-05-09 10:25:15 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:15 --> Total execution time: 0.0410
INFO - 2023-05-09 10:25:22 --> Config Class Initialized
INFO - 2023-05-09 10:25:22 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:22 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:22 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:22 --> URI Class Initialized
INFO - 2023-05-09 10:25:22 --> Router Class Initialized
INFO - 2023-05-09 10:25:22 --> Output Class Initialized
INFO - 2023-05-09 10:25:22 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:22 --> Input Class Initialized
INFO - 2023-05-09 10:25:22 --> Language Class Initialized
INFO - 2023-05-09 10:25:22 --> Loader Class Initialized
INFO - 2023-05-09 10:25:22 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:22 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:22 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:22 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:22 --> Total execution time: 0.1974
INFO - 2023-05-09 10:25:22 --> Config Class Initialized
INFO - 2023-05-09 10:25:23 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:23 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:23 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:23 --> URI Class Initialized
INFO - 2023-05-09 10:25:23 --> Router Class Initialized
INFO - 2023-05-09 10:25:23 --> Output Class Initialized
INFO - 2023-05-09 10:25:23 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:23 --> Input Class Initialized
INFO - 2023-05-09 10:25:23 --> Language Class Initialized
INFO - 2023-05-09 10:25:23 --> Loader Class Initialized
INFO - 2023-05-09 10:25:23 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:23 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:23 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:23 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:23 --> Total execution time: 0.0538
INFO - 2023-05-09 10:25:25 --> Config Class Initialized
INFO - 2023-05-09 10:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:25 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:25 --> URI Class Initialized
INFO - 2023-05-09 10:25:25 --> Router Class Initialized
INFO - 2023-05-09 10:25:25 --> Output Class Initialized
INFO - 2023-05-09 10:25:25 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:25 --> Input Class Initialized
INFO - 2023-05-09 10:25:25 --> Language Class Initialized
INFO - 2023-05-09 10:25:25 --> Loader Class Initialized
INFO - 2023-05-09 10:25:25 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:25 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:25 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:25 --> Total execution time: 0.3116
INFO - 2023-05-09 10:25:25 --> Config Class Initialized
INFO - 2023-05-09 10:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:25 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:25 --> URI Class Initialized
INFO - 2023-05-09 10:25:25 --> Router Class Initialized
INFO - 2023-05-09 10:25:25 --> Output Class Initialized
INFO - 2023-05-09 10:25:25 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:25 --> Input Class Initialized
INFO - 2023-05-09 10:25:25 --> Language Class Initialized
INFO - 2023-05-09 10:25:25 --> Loader Class Initialized
INFO - 2023-05-09 10:25:25 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:25 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:25 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:25 --> Total execution time: 0.0138
INFO - 2023-05-09 10:25:31 --> Config Class Initialized
INFO - 2023-05-09 10:25:31 --> Config Class Initialized
INFO - 2023-05-09 10:25:31 --> Hooks Class Initialized
INFO - 2023-05-09 10:25:31 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:25:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:31 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:31 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:31 --> URI Class Initialized
INFO - 2023-05-09 10:25:31 --> URI Class Initialized
INFO - 2023-05-09 10:25:31 --> Router Class Initialized
INFO - 2023-05-09 10:25:31 --> Router Class Initialized
INFO - 2023-05-09 10:25:31 --> Output Class Initialized
INFO - 2023-05-09 10:25:31 --> Output Class Initialized
INFO - 2023-05-09 10:25:31 --> Security Class Initialized
INFO - 2023-05-09 10:25:31 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:31 --> Input Class Initialized
INFO - 2023-05-09 10:25:31 --> Input Class Initialized
INFO - 2023-05-09 10:25:31 --> Language Class Initialized
INFO - 2023-05-09 10:25:31 --> Language Class Initialized
INFO - 2023-05-09 10:25:31 --> Loader Class Initialized
INFO - 2023-05-09 10:25:31 --> Controller Class Initialized
INFO - 2023-05-09 10:25:31 --> Loader Class Initialized
DEBUG - 2023-05-09 10:25:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:31 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:31 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:31 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:31 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:31 --> Total execution time: 0.0621
INFO - 2023-05-09 10:25:31 --> Config Class Initialized
INFO - 2023-05-09 10:25:31 --> Hooks Class Initialized
INFO - 2023-05-09 10:25:31 --> Config Class Initialized
DEBUG - 2023-05-09 10:25:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:31 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:31 --> Hooks Class Initialized
INFO - 2023-05-09 10:25:31 --> URI Class Initialized
DEBUG - 2023-05-09 10:25:31 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:31 --> Router Class Initialized
INFO - 2023-05-09 10:25:31 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:31 --> Output Class Initialized
INFO - 2023-05-09 10:25:31 --> Security Class Initialized
INFO - 2023-05-09 10:25:31 --> URI Class Initialized
DEBUG - 2023-05-09 10:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:31 --> Router Class Initialized
INFO - 2023-05-09 10:25:31 --> Input Class Initialized
INFO - 2023-05-09 10:25:31 --> Output Class Initialized
INFO - 2023-05-09 10:25:31 --> Language Class Initialized
INFO - 2023-05-09 10:25:31 --> Security Class Initialized
INFO - 2023-05-09 10:25:31 --> Loader Class Initialized
DEBUG - 2023-05-09 10:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:31 --> Controller Class Initialized
INFO - 2023-05-09 10:25:31 --> Input Class Initialized
DEBUG - 2023-05-09 10:25:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:31 --> Language Class Initialized
INFO - 2023-05-09 10:25:31 --> Loader Class Initialized
INFO - 2023-05-09 10:25:31 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:31 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:31 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:31 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:31 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:31 --> Total execution time: 0.1363
INFO - 2023-05-09 10:25:33 --> Config Class Initialized
INFO - 2023-05-09 10:25:33 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:33 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:33 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:33 --> URI Class Initialized
INFO - 2023-05-09 10:25:33 --> Router Class Initialized
INFO - 2023-05-09 10:25:33 --> Output Class Initialized
INFO - 2023-05-09 10:25:33 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:33 --> Input Class Initialized
INFO - 2023-05-09 10:25:33 --> Language Class Initialized
INFO - 2023-05-09 10:25:33 --> Loader Class Initialized
INFO - 2023-05-09 10:25:33 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:33 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:33 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:46 --> Config Class Initialized
INFO - 2023-05-09 10:25:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:46 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:46 --> URI Class Initialized
INFO - 2023-05-09 10:25:46 --> Router Class Initialized
INFO - 2023-05-09 10:25:46 --> Output Class Initialized
INFO - 2023-05-09 10:25:46 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:46 --> Input Class Initialized
INFO - 2023-05-09 10:25:46 --> Language Class Initialized
INFO - 2023-05-09 10:25:46 --> Loader Class Initialized
INFO - 2023-05-09 10:25:46 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-05-09 10:25:46 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 250
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-05-09 10:25:46 --> Config Class Initialized
INFO - 2023-05-09 10:25:46 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:46 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:46 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:46 --> URI Class Initialized
INFO - 2023-05-09 10:25:46 --> Router Class Initialized
INFO - 2023-05-09 10:25:46 --> Output Class Initialized
INFO - 2023-05-09 10:25:46 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:46 --> Input Class Initialized
INFO - 2023-05-09 10:25:46 --> Language Class Initialized
INFO - 2023-05-09 10:25:46 --> Loader Class Initialized
INFO - 2023-05-09 10:25:46 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:46 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:46 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:46 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:46 --> Total execution time: 0.0500
INFO - 2023-05-09 10:25:47 --> Config Class Initialized
INFO - 2023-05-09 10:25:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:47 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:47 --> URI Class Initialized
INFO - 2023-05-09 10:25:47 --> Router Class Initialized
INFO - 2023-05-09 10:25:47 --> Output Class Initialized
INFO - 2023-05-09 10:25:47 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:47 --> Input Class Initialized
INFO - 2023-05-09 10:25:47 --> Language Class Initialized
INFO - 2023-05-09 10:25:47 --> Loader Class Initialized
INFO - 2023-05-09 10:25:47 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:47 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:47 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:47 --> Total execution time: 0.0594
INFO - 2023-05-09 10:25:47 --> Config Class Initialized
INFO - 2023-05-09 10:25:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:47 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:47 --> URI Class Initialized
INFO - 2023-05-09 10:25:47 --> Router Class Initialized
INFO - 2023-05-09 10:25:47 --> Output Class Initialized
INFO - 2023-05-09 10:25:47 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:47 --> Input Class Initialized
INFO - 2023-05-09 10:25:47 --> Language Class Initialized
INFO - 2023-05-09 10:25:47 --> Loader Class Initialized
INFO - 2023-05-09 10:25:47 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:47 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:47 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:47 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:47 --> Total execution time: 0.0133
INFO - 2023-05-09 10:25:48 --> Config Class Initialized
INFO - 2023-05-09 10:25:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:48 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:48 --> URI Class Initialized
INFO - 2023-05-09 10:25:48 --> Router Class Initialized
INFO - 2023-05-09 10:25:48 --> Output Class Initialized
INFO - 2023-05-09 10:25:48 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:48 --> Input Class Initialized
INFO - 2023-05-09 10:25:48 --> Language Class Initialized
INFO - 2023-05-09 10:25:48 --> Loader Class Initialized
INFO - 2023-05-09 10:25:48 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:48 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:48 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:48 --> Total execution time: 0.1826
INFO - 2023-05-09 10:25:49 --> Config Class Initialized
INFO - 2023-05-09 10:25:49 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:25:49 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:25:49 --> Utf8 Class Initialized
INFO - 2023-05-09 10:25:49 --> URI Class Initialized
INFO - 2023-05-09 10:25:49 --> Router Class Initialized
INFO - 2023-05-09 10:25:49 --> Output Class Initialized
INFO - 2023-05-09 10:25:49 --> Security Class Initialized
DEBUG - 2023-05-09 10:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:25:49 --> Input Class Initialized
INFO - 2023-05-09 10:25:49 --> Language Class Initialized
INFO - 2023-05-09 10:25:49 --> Loader Class Initialized
INFO - 2023-05-09 10:25:49 --> Controller Class Initialized
DEBUG - 2023-05-09 10:25:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:25:49 --> Database Driver Class Initialized
INFO - 2023-05-09 10:25:49 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:25:49 --> Final output sent to browser
DEBUG - 2023-05-09 10:25:49 --> Total execution time: 0.1222
INFO - 2023-05-09 10:26:42 --> Config Class Initialized
INFO - 2023-05-09 10:26:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:26:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:26:42 --> Utf8 Class Initialized
INFO - 2023-05-09 10:26:42 --> URI Class Initialized
INFO - 2023-05-09 10:26:42 --> Router Class Initialized
INFO - 2023-05-09 10:26:42 --> Output Class Initialized
INFO - 2023-05-09 10:26:42 --> Security Class Initialized
DEBUG - 2023-05-09 10:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:26:42 --> Input Class Initialized
INFO - 2023-05-09 10:26:42 --> Language Class Initialized
INFO - 2023-05-09 10:26:42 --> Loader Class Initialized
INFO - 2023-05-09 10:26:42 --> Controller Class Initialized
DEBUG - 2023-05-09 10:26:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-05-09 10:26:42 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 250
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-05-09 10:26:42 --> Config Class Initialized
INFO - 2023-05-09 10:26:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:26:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:26:42 --> Utf8 Class Initialized
INFO - 2023-05-09 10:26:42 --> URI Class Initialized
INFO - 2023-05-09 10:26:42 --> Router Class Initialized
INFO - 2023-05-09 10:26:42 --> Output Class Initialized
INFO - 2023-05-09 10:26:42 --> Security Class Initialized
DEBUG - 2023-05-09 10:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:26:42 --> Input Class Initialized
INFO - 2023-05-09 10:26:42 --> Language Class Initialized
INFO - 2023-05-09 10:26:42 --> Loader Class Initialized
INFO - 2023-05-09 10:26:42 --> Controller Class Initialized
DEBUG - 2023-05-09 10:26:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:26:42 --> Database Driver Class Initialized
INFO - 2023-05-09 10:26:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:26:42 --> Final output sent to browser
DEBUG - 2023-05-09 10:26:42 --> Total execution time: 0.0659
INFO - 2023-05-09 10:26:43 --> Config Class Initialized
INFO - 2023-05-09 10:26:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:26:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:26:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:26:43 --> URI Class Initialized
INFO - 2023-05-09 10:26:43 --> Router Class Initialized
INFO - 2023-05-09 10:26:43 --> Output Class Initialized
INFO - 2023-05-09 10:26:43 --> Security Class Initialized
DEBUG - 2023-05-09 10:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:26:43 --> Input Class Initialized
INFO - 2023-05-09 10:26:43 --> Language Class Initialized
INFO - 2023-05-09 10:26:43 --> Loader Class Initialized
INFO - 2023-05-09 10:26:43 --> Controller Class Initialized
DEBUG - 2023-05-09 10:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:26:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:26:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:26:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:26:43 --> Total execution time: 0.0136
INFO - 2023-05-09 10:26:43 --> Config Class Initialized
INFO - 2023-05-09 10:26:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:26:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:26:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:26:43 --> URI Class Initialized
INFO - 2023-05-09 10:26:43 --> Router Class Initialized
INFO - 2023-05-09 10:26:43 --> Output Class Initialized
INFO - 2023-05-09 10:26:43 --> Security Class Initialized
DEBUG - 2023-05-09 10:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:26:43 --> Input Class Initialized
INFO - 2023-05-09 10:26:43 --> Language Class Initialized
INFO - 2023-05-09 10:26:43 --> Loader Class Initialized
INFO - 2023-05-09 10:26:43 --> Controller Class Initialized
DEBUG - 2023-05-09 10:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:26:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:26:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:26:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:26:43 --> Total execution time: 0.0172
INFO - 2023-05-09 10:26:44 --> Config Class Initialized
INFO - 2023-05-09 10:26:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:26:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:26:44 --> Utf8 Class Initialized
INFO - 2023-05-09 10:26:44 --> URI Class Initialized
INFO - 2023-05-09 10:26:44 --> Router Class Initialized
INFO - 2023-05-09 10:26:44 --> Output Class Initialized
INFO - 2023-05-09 10:26:44 --> Security Class Initialized
DEBUG - 2023-05-09 10:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:26:44 --> Input Class Initialized
INFO - 2023-05-09 10:26:44 --> Language Class Initialized
INFO - 2023-05-09 10:26:44 --> Loader Class Initialized
INFO - 2023-05-09 10:26:44 --> Controller Class Initialized
DEBUG - 2023-05-09 10:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:26:44 --> Database Driver Class Initialized
INFO - 2023-05-09 10:26:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:26:44 --> Final output sent to browser
DEBUG - 2023-05-09 10:26:44 --> Total execution time: 0.0215
INFO - 2023-05-09 10:26:45 --> Config Class Initialized
INFO - 2023-05-09 10:26:45 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:26:45 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:26:45 --> Utf8 Class Initialized
INFO - 2023-05-09 10:26:45 --> URI Class Initialized
INFO - 2023-05-09 10:26:45 --> Router Class Initialized
INFO - 2023-05-09 10:26:45 --> Output Class Initialized
INFO - 2023-05-09 10:26:45 --> Security Class Initialized
DEBUG - 2023-05-09 10:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:26:45 --> Input Class Initialized
INFO - 2023-05-09 10:26:45 --> Language Class Initialized
INFO - 2023-05-09 10:26:45 --> Loader Class Initialized
INFO - 2023-05-09 10:26:45 --> Controller Class Initialized
DEBUG - 2023-05-09 10:26:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:26:45 --> Database Driver Class Initialized
INFO - 2023-05-09 10:26:45 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:26:45 --> Final output sent to browser
DEBUG - 2023-05-09 10:26:45 --> Total execution time: 0.0201
INFO - 2023-05-09 10:35:11 --> Config Class Initialized
INFO - 2023-05-09 10:35:11 --> Config Class Initialized
INFO - 2023-05-09 10:35:11 --> Hooks Class Initialized
INFO - 2023-05-09 10:35:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:11 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:35:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:11 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:11 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:11 --> URI Class Initialized
INFO - 2023-05-09 10:35:11 --> URI Class Initialized
INFO - 2023-05-09 10:35:11 --> Router Class Initialized
INFO - 2023-05-09 10:35:11 --> Router Class Initialized
INFO - 2023-05-09 10:35:11 --> Output Class Initialized
INFO - 2023-05-09 10:35:11 --> Output Class Initialized
INFO - 2023-05-09 10:35:11 --> Security Class Initialized
INFO - 2023-05-09 10:35:11 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:11 --> Input Class Initialized
INFO - 2023-05-09 10:35:11 --> Input Class Initialized
INFO - 2023-05-09 10:35:11 --> Language Class Initialized
INFO - 2023-05-09 10:35:11 --> Language Class Initialized
INFO - 2023-05-09 10:35:11 --> Loader Class Initialized
INFO - 2023-05-09 10:35:11 --> Loader Class Initialized
INFO - 2023-05-09 10:35:11 --> Controller Class Initialized
INFO - 2023-05-09 10:35:11 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:35:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:11 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:11 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:11 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:11 --> Total execution time: 0.1533
INFO - 2023-05-09 10:35:11 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:11 --> Config Class Initialized
INFO - 2023-05-09 10:35:11 --> Model "Login_model" initialized
INFO - 2023-05-09 10:35:11 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:11 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:11 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:11 --> URI Class Initialized
INFO - 2023-05-09 10:35:11 --> Router Class Initialized
INFO - 2023-05-09 10:35:11 --> Output Class Initialized
INFO - 2023-05-09 10:35:11 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:11 --> Input Class Initialized
INFO - 2023-05-09 10:35:11 --> Language Class Initialized
INFO - 2023-05-09 10:35:11 --> Loader Class Initialized
INFO - 2023-05-09 10:35:11 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:11 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:11 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:11 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:11 --> Total execution time: 0.0935
INFO - 2023-05-09 10:35:11 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:11 --> Total execution time: 0.2857
INFO - 2023-05-09 10:35:11 --> Config Class Initialized
INFO - 2023-05-09 10:35:12 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:12 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:12 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:12 --> URI Class Initialized
INFO - 2023-05-09 10:35:12 --> Router Class Initialized
INFO - 2023-05-09 10:35:12 --> Output Class Initialized
INFO - 2023-05-09 10:35:12 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:12 --> Input Class Initialized
INFO - 2023-05-09 10:35:12 --> Language Class Initialized
INFO - 2023-05-09 10:35:12 --> Loader Class Initialized
INFO - 2023-05-09 10:35:12 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:12 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:12 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:12 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:12 --> Model "Login_model" initialized
INFO - 2023-05-09 10:35:12 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:12 --> Total execution time: 0.4185
INFO - 2023-05-09 10:35:15 --> Config Class Initialized
INFO - 2023-05-09 10:35:15 --> Config Class Initialized
INFO - 2023-05-09 10:35:15 --> Hooks Class Initialized
INFO - 2023-05-09 10:35:15 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:15 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:35:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:15 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:15 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:15 --> URI Class Initialized
INFO - 2023-05-09 10:35:15 --> URI Class Initialized
INFO - 2023-05-09 10:35:15 --> Router Class Initialized
INFO - 2023-05-09 10:35:15 --> Router Class Initialized
INFO - 2023-05-09 10:35:15 --> Output Class Initialized
INFO - 2023-05-09 10:35:15 --> Output Class Initialized
INFO - 2023-05-09 10:35:15 --> Security Class Initialized
INFO - 2023-05-09 10:35:15 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:15 --> Input Class Initialized
INFO - 2023-05-09 10:35:15 --> Input Class Initialized
INFO - 2023-05-09 10:35:15 --> Language Class Initialized
INFO - 2023-05-09 10:35:15 --> Language Class Initialized
INFO - 2023-05-09 10:35:15 --> Loader Class Initialized
INFO - 2023-05-09 10:35:15 --> Loader Class Initialized
INFO - 2023-05-09 10:35:15 --> Controller Class Initialized
INFO - 2023-05-09 10:35:15 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:15 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:15 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:15 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:15 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:15 --> Total execution time: 0.1815
INFO - 2023-05-09 10:35:15 --> Config Class Initialized
INFO - 2023-05-09 10:35:15 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:15 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:15 --> Config Class Initialized
INFO - 2023-05-09 10:35:16 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:16 --> Hooks Class Initialized
INFO - 2023-05-09 10:35:16 --> URI Class Initialized
DEBUG - 2023-05-09 10:35:16 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:16 --> Router Class Initialized
INFO - 2023-05-09 10:35:16 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:16 --> Output Class Initialized
INFO - 2023-05-09 10:35:16 --> URI Class Initialized
INFO - 2023-05-09 10:35:16 --> Security Class Initialized
INFO - 2023-05-09 10:35:16 --> Router Class Initialized
DEBUG - 2023-05-09 10:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:16 --> Output Class Initialized
INFO - 2023-05-09 10:35:16 --> Input Class Initialized
INFO - 2023-05-09 10:35:16 --> Security Class Initialized
INFO - 2023-05-09 10:35:16 --> Language Class Initialized
DEBUG - 2023-05-09 10:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:16 --> Loader Class Initialized
INFO - 2023-05-09 10:35:16 --> Input Class Initialized
INFO - 2023-05-09 10:35:16 --> Controller Class Initialized
INFO - 2023-05-09 10:35:16 --> Language Class Initialized
DEBUG - 2023-05-09 10:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:16 --> Loader Class Initialized
INFO - 2023-05-09 10:35:16 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:16 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:16 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:16 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:16 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:16 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:16 --> Total execution time: 0.1814
INFO - 2023-05-09 10:35:24 --> Config Class Initialized
INFO - 2023-05-09 10:35:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:24 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:24 --> URI Class Initialized
INFO - 2023-05-09 10:35:24 --> Router Class Initialized
INFO - 2023-05-09 10:35:24 --> Output Class Initialized
INFO - 2023-05-09 10:35:24 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:24 --> Input Class Initialized
INFO - 2023-05-09 10:35:24 --> Language Class Initialized
INFO - 2023-05-09 10:35:24 --> Loader Class Initialized
INFO - 2023-05-09 10:35:24 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:24 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:24 --> Config Class Initialized
INFO - 2023-05-09 10:35:24 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:24 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:24 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:24 --> URI Class Initialized
INFO - 2023-05-09 10:35:24 --> Router Class Initialized
INFO - 2023-05-09 10:35:24 --> Output Class Initialized
INFO - 2023-05-09 10:35:24 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:24 --> Input Class Initialized
INFO - 2023-05-09 10:35:24 --> Language Class Initialized
INFO - 2023-05-09 10:35:24 --> Loader Class Initialized
INFO - 2023-05-09 10:35:24 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:24 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:24 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:39 --> Config Class Initialized
INFO - 2023-05-09 10:35:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:39 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:39 --> URI Class Initialized
INFO - 2023-05-09 10:35:39 --> Router Class Initialized
INFO - 2023-05-09 10:35:39 --> Output Class Initialized
INFO - 2023-05-09 10:35:39 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:39 --> Input Class Initialized
INFO - 2023-05-09 10:35:39 --> Language Class Initialized
INFO - 2023-05-09 10:35:39 --> Loader Class Initialized
INFO - 2023-05-09 10:35:39 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-05-09 10:35:39 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 250
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-05-09 10:35:39 --> Config Class Initialized
INFO - 2023-05-09 10:35:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:39 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:39 --> URI Class Initialized
INFO - 2023-05-09 10:35:39 --> Router Class Initialized
INFO - 2023-05-09 10:35:39 --> Output Class Initialized
INFO - 2023-05-09 10:35:39 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:39 --> Input Class Initialized
INFO - 2023-05-09 10:35:39 --> Language Class Initialized
INFO - 2023-05-09 10:35:39 --> Loader Class Initialized
INFO - 2023-05-09 10:35:39 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:39 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:39 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:39 --> Total execution time: 0.0567
INFO - 2023-05-09 10:35:40 --> Config Class Initialized
INFO - 2023-05-09 10:35:40 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:40 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:40 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:40 --> URI Class Initialized
INFO - 2023-05-09 10:35:40 --> Router Class Initialized
INFO - 2023-05-09 10:35:40 --> Output Class Initialized
INFO - 2023-05-09 10:35:40 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:40 --> Input Class Initialized
INFO - 2023-05-09 10:35:40 --> Language Class Initialized
INFO - 2023-05-09 10:35:40 --> Loader Class Initialized
INFO - 2023-05-09 10:35:40 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:40 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:40 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:40 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:40 --> Total execution time: 0.0509
INFO - 2023-05-09 10:35:40 --> Config Class Initialized
INFO - 2023-05-09 10:35:40 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:40 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:40 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:40 --> URI Class Initialized
INFO - 2023-05-09 10:35:40 --> Router Class Initialized
INFO - 2023-05-09 10:35:40 --> Output Class Initialized
INFO - 2023-05-09 10:35:40 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:40 --> Input Class Initialized
INFO - 2023-05-09 10:35:40 --> Language Class Initialized
INFO - 2023-05-09 10:35:40 --> Loader Class Initialized
INFO - 2023-05-09 10:35:40 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:40 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:40 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:40 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:40 --> Total execution time: 0.1096
INFO - 2023-05-09 10:35:41 --> Config Class Initialized
INFO - 2023-05-09 10:35:41 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:41 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:41 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:41 --> URI Class Initialized
INFO - 2023-05-09 10:35:41 --> Router Class Initialized
INFO - 2023-05-09 10:35:41 --> Output Class Initialized
INFO - 2023-05-09 10:35:41 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:41 --> Input Class Initialized
INFO - 2023-05-09 10:35:41 --> Language Class Initialized
INFO - 2023-05-09 10:35:41 --> Loader Class Initialized
INFO - 2023-05-09 10:35:41 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:41 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:41 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:41 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:41 --> Total execution time: 0.0737
INFO - 2023-05-09 10:35:42 --> Config Class Initialized
INFO - 2023-05-09 10:35:42 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:42 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:42 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:42 --> URI Class Initialized
INFO - 2023-05-09 10:35:42 --> Router Class Initialized
INFO - 2023-05-09 10:35:42 --> Output Class Initialized
INFO - 2023-05-09 10:35:42 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:42 --> Input Class Initialized
INFO - 2023-05-09 10:35:42 --> Language Class Initialized
INFO - 2023-05-09 10:35:42 --> Loader Class Initialized
INFO - 2023-05-09 10:35:42 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:42 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:42 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:42 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:42 --> Total execution time: 0.1480
INFO - 2023-05-09 10:35:43 --> Config Class Initialized
INFO - 2023-05-09 10:35:43 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:43 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:43 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:43 --> URI Class Initialized
INFO - 2023-05-09 10:35:43 --> Router Class Initialized
INFO - 2023-05-09 10:35:43 --> Output Class Initialized
INFO - 2023-05-09 10:35:43 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:43 --> Input Class Initialized
INFO - 2023-05-09 10:35:43 --> Language Class Initialized
INFO - 2023-05-09 10:35:43 --> Loader Class Initialized
INFO - 2023-05-09 10:35:43 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:43 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:43 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:43 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:43 --> Total execution time: 0.1602
INFO - 2023-05-09 10:35:44 --> Config Class Initialized
INFO - 2023-05-09 10:35:44 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:35:44 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:35:44 --> Utf8 Class Initialized
INFO - 2023-05-09 10:35:44 --> URI Class Initialized
INFO - 2023-05-09 10:35:44 --> Router Class Initialized
INFO - 2023-05-09 10:35:44 --> Output Class Initialized
INFO - 2023-05-09 10:35:44 --> Security Class Initialized
DEBUG - 2023-05-09 10:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:35:44 --> Input Class Initialized
INFO - 2023-05-09 10:35:44 --> Language Class Initialized
INFO - 2023-05-09 10:35:44 --> Loader Class Initialized
INFO - 2023-05-09 10:35:44 --> Controller Class Initialized
DEBUG - 2023-05-09 10:35:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:35:44 --> Database Driver Class Initialized
INFO - 2023-05-09 10:35:44 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:35:44 --> Final output sent to browser
DEBUG - 2023-05-09 10:35:44 --> Total execution time: 0.2144
INFO - 2023-05-09 10:37:35 --> Config Class Initialized
INFO - 2023-05-09 10:37:35 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:37:35 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:37:35 --> Utf8 Class Initialized
INFO - 2023-05-09 10:37:35 --> URI Class Initialized
INFO - 2023-05-09 10:37:35 --> Router Class Initialized
INFO - 2023-05-09 10:37:35 --> Output Class Initialized
INFO - 2023-05-09 10:37:35 --> Security Class Initialized
DEBUG - 2023-05-09 10:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:37:35 --> Input Class Initialized
INFO - 2023-05-09 10:37:35 --> Language Class Initialized
INFO - 2023-05-09 10:37:35 --> Loader Class Initialized
INFO - 2023-05-09 10:37:35 --> Controller Class Initialized
DEBUG - 2023-05-09 10:37:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-05-09 10:37:35 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 250
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-05-09 10:37:35 --> Config Class Initialized
INFO - 2023-05-09 10:37:35 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:37:35 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:37:35 --> Utf8 Class Initialized
INFO - 2023-05-09 10:37:35 --> URI Class Initialized
INFO - 2023-05-09 10:37:35 --> Router Class Initialized
INFO - 2023-05-09 10:37:35 --> Output Class Initialized
INFO - 2023-05-09 10:37:35 --> Security Class Initialized
DEBUG - 2023-05-09 10:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:37:35 --> Input Class Initialized
INFO - 2023-05-09 10:37:35 --> Language Class Initialized
INFO - 2023-05-09 10:37:35 --> Loader Class Initialized
INFO - 2023-05-09 10:37:35 --> Controller Class Initialized
DEBUG - 2023-05-09 10:37:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:37:35 --> Database Driver Class Initialized
INFO - 2023-05-09 10:37:35 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:37:35 --> Final output sent to browser
DEBUG - 2023-05-09 10:37:35 --> Total execution time: 0.0289
INFO - 2023-05-09 10:37:36 --> Config Class Initialized
INFO - 2023-05-09 10:37:36 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:37:36 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:37:36 --> Utf8 Class Initialized
INFO - 2023-05-09 10:37:36 --> URI Class Initialized
INFO - 2023-05-09 10:37:36 --> Router Class Initialized
INFO - 2023-05-09 10:37:36 --> Output Class Initialized
INFO - 2023-05-09 10:37:36 --> Security Class Initialized
DEBUG - 2023-05-09 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:37:36 --> Input Class Initialized
INFO - 2023-05-09 10:37:36 --> Language Class Initialized
INFO - 2023-05-09 10:37:36 --> Loader Class Initialized
INFO - 2023-05-09 10:37:36 --> Controller Class Initialized
DEBUG - 2023-05-09 10:37:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:37:36 --> Database Driver Class Initialized
INFO - 2023-05-09 10:37:36 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:37:36 --> Final output sent to browser
DEBUG - 2023-05-09 10:37:36 --> Total execution time: 0.0639
INFO - 2023-05-09 10:37:36 --> Config Class Initialized
INFO - 2023-05-09 10:37:36 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:37:36 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:37:36 --> Utf8 Class Initialized
INFO - 2023-05-09 10:37:36 --> URI Class Initialized
INFO - 2023-05-09 10:37:36 --> Router Class Initialized
INFO - 2023-05-09 10:37:36 --> Output Class Initialized
INFO - 2023-05-09 10:37:36 --> Security Class Initialized
DEBUG - 2023-05-09 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:37:36 --> Input Class Initialized
INFO - 2023-05-09 10:37:36 --> Language Class Initialized
INFO - 2023-05-09 10:37:36 --> Loader Class Initialized
INFO - 2023-05-09 10:37:36 --> Controller Class Initialized
DEBUG - 2023-05-09 10:37:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:37:36 --> Database Driver Class Initialized
INFO - 2023-05-09 10:37:36 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:37:36 --> Final output sent to browser
DEBUG - 2023-05-09 10:37:36 --> Total execution time: 0.0391
INFO - 2023-05-09 10:37:37 --> Config Class Initialized
INFO - 2023-05-09 10:37:37 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:37:37 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:37:37 --> Utf8 Class Initialized
INFO - 2023-05-09 10:37:37 --> URI Class Initialized
INFO - 2023-05-09 10:37:37 --> Router Class Initialized
INFO - 2023-05-09 10:37:37 --> Output Class Initialized
INFO - 2023-05-09 10:37:37 --> Security Class Initialized
DEBUG - 2023-05-09 10:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:37:37 --> Input Class Initialized
INFO - 2023-05-09 10:37:37 --> Language Class Initialized
INFO - 2023-05-09 10:37:37 --> Loader Class Initialized
INFO - 2023-05-09 10:37:37 --> Controller Class Initialized
DEBUG - 2023-05-09 10:37:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:37:37 --> Database Driver Class Initialized
INFO - 2023-05-09 10:37:37 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:37:37 --> Final output sent to browser
DEBUG - 2023-05-09 10:37:37 --> Total execution time: 0.0839
INFO - 2023-05-09 10:37:38 --> Config Class Initialized
INFO - 2023-05-09 10:37:38 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:37:38 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:37:38 --> Utf8 Class Initialized
INFO - 2023-05-09 10:37:38 --> URI Class Initialized
INFO - 2023-05-09 10:37:38 --> Router Class Initialized
INFO - 2023-05-09 10:37:38 --> Output Class Initialized
INFO - 2023-05-09 10:37:38 --> Security Class Initialized
DEBUG - 2023-05-09 10:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:37:38 --> Input Class Initialized
INFO - 2023-05-09 10:37:38 --> Language Class Initialized
INFO - 2023-05-09 10:37:38 --> Loader Class Initialized
INFO - 2023-05-09 10:37:38 --> Controller Class Initialized
DEBUG - 2023-05-09 10:37:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:37:38 --> Database Driver Class Initialized
INFO - 2023-05-09 10:37:38 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:37:38 --> Final output sent to browser
DEBUG - 2023-05-09 10:37:38 --> Total execution time: 0.1291
INFO - 2023-05-09 10:37:39 --> Config Class Initialized
INFO - 2023-05-09 10:37:39 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:37:39 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:37:39 --> Utf8 Class Initialized
INFO - 2023-05-09 10:37:39 --> URI Class Initialized
INFO - 2023-05-09 10:37:39 --> Router Class Initialized
INFO - 2023-05-09 10:37:39 --> Output Class Initialized
INFO - 2023-05-09 10:37:39 --> Security Class Initialized
DEBUG - 2023-05-09 10:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:37:39 --> Input Class Initialized
INFO - 2023-05-09 10:37:39 --> Language Class Initialized
INFO - 2023-05-09 10:37:39 --> Loader Class Initialized
INFO - 2023-05-09 10:37:39 --> Controller Class Initialized
DEBUG - 2023-05-09 10:37:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:37:39 --> Database Driver Class Initialized
INFO - 2023-05-09 10:37:39 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:37:39 --> Final output sent to browser
DEBUG - 2023-05-09 10:37:39 --> Total execution time: 0.2071
INFO - 2023-05-09 10:37:40 --> Config Class Initialized
INFO - 2023-05-09 10:37:40 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:37:40 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:37:40 --> Utf8 Class Initialized
INFO - 2023-05-09 10:37:40 --> URI Class Initialized
INFO - 2023-05-09 10:37:40 --> Router Class Initialized
INFO - 2023-05-09 10:37:40 --> Output Class Initialized
INFO - 2023-05-09 10:37:40 --> Security Class Initialized
DEBUG - 2023-05-09 10:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:37:40 --> Input Class Initialized
INFO - 2023-05-09 10:37:40 --> Language Class Initialized
INFO - 2023-05-09 10:37:40 --> Loader Class Initialized
INFO - 2023-05-09 10:37:40 --> Controller Class Initialized
DEBUG - 2023-05-09 10:37:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:37:40 --> Database Driver Class Initialized
INFO - 2023-05-09 10:37:40 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:37:40 --> Final output sent to browser
DEBUG - 2023-05-09 10:37:40 --> Total execution time: 0.2248
INFO - 2023-05-09 10:41:06 --> Config Class Initialized
INFO - 2023-05-09 10:41:06 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:41:06 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:06 --> Utf8 Class Initialized
INFO - 2023-05-09 10:41:06 --> URI Class Initialized
INFO - 2023-05-09 10:41:06 --> Router Class Initialized
INFO - 2023-05-09 10:41:06 --> Output Class Initialized
INFO - 2023-05-09 10:41:06 --> Security Class Initialized
DEBUG - 2023-05-09 10:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:06 --> Input Class Initialized
INFO - 2023-05-09 10:41:06 --> Language Class Initialized
INFO - 2023-05-09 10:41:06 --> Loader Class Initialized
INFO - 2023-05-09 10:41:06 --> Controller Class Initialized
DEBUG - 2023-05-09 10:41:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:41:06 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:06 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:06 --> Final output sent to browser
DEBUG - 2023-05-09 10:41:06 --> Total execution time: 0.0172
INFO - 2023-05-09 10:41:06 --> Config Class Initialized
INFO - 2023-05-09 10:41:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:41:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:07 --> Utf8 Class Initialized
INFO - 2023-05-09 10:41:07 --> URI Class Initialized
INFO - 2023-05-09 10:41:07 --> Router Class Initialized
INFO - 2023-05-09 10:41:07 --> Output Class Initialized
INFO - 2023-05-09 10:41:07 --> Security Class Initialized
DEBUG - 2023-05-09 10:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:07 --> Input Class Initialized
INFO - 2023-05-09 10:41:07 --> Language Class Initialized
INFO - 2023-05-09 10:41:07 --> Loader Class Initialized
INFO - 2023-05-09 10:41:07 --> Controller Class Initialized
DEBUG - 2023-05-09 10:41:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:41:07 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:07 --> Final output sent to browser
DEBUG - 2023-05-09 10:41:07 --> Total execution time: 0.0572
INFO - 2023-05-09 10:41:09 --> Config Class Initialized
INFO - 2023-05-09 10:41:09 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:41:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:09 --> Utf8 Class Initialized
INFO - 2023-05-09 10:41:09 --> Config Class Initialized
INFO - 2023-05-09 10:41:09 --> Hooks Class Initialized
INFO - 2023-05-09 10:41:09 --> URI Class Initialized
DEBUG - 2023-05-09 10:41:09 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:09 --> Utf8 Class Initialized
INFO - 2023-05-09 10:41:09 --> Router Class Initialized
INFO - 2023-05-09 10:41:09 --> URI Class Initialized
INFO - 2023-05-09 10:41:09 --> Output Class Initialized
INFO - 2023-05-09 10:41:09 --> Router Class Initialized
INFO - 2023-05-09 10:41:09 --> Security Class Initialized
INFO - 2023-05-09 10:41:09 --> Output Class Initialized
DEBUG - 2023-05-09 10:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:09 --> Security Class Initialized
INFO - 2023-05-09 10:41:09 --> Input Class Initialized
DEBUG - 2023-05-09 10:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:09 --> Language Class Initialized
INFO - 2023-05-09 10:41:09 --> Input Class Initialized
INFO - 2023-05-09 10:41:09 --> Loader Class Initialized
INFO - 2023-05-09 10:41:09 --> Language Class Initialized
INFO - 2023-05-09 10:41:09 --> Controller Class Initialized
INFO - 2023-05-09 10:41:09 --> Loader Class Initialized
DEBUG - 2023-05-09 10:41:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:41:09 --> Controller Class Initialized
DEBUG - 2023-05-09 10:41:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:41:09 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:09 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:09 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:41:10 --> Total execution time: 0.2903
INFO - 2023-05-09 10:41:10 --> Final output sent to browser
INFO - 2023-05-09 10:41:10 --> Config Class Initialized
INFO - 2023-05-09 10:41:10 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:41:10 --> Total execution time: 0.2960
DEBUG - 2023-05-09 10:41:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:10 --> Utf8 Class Initialized
INFO - 2023-05-09 10:41:10 --> URI Class Initialized
INFO - 2023-05-09 10:41:10 --> Router Class Initialized
INFO - 2023-05-09 10:41:10 --> Config Class Initialized
INFO - 2023-05-09 10:41:10 --> Hooks Class Initialized
INFO - 2023-05-09 10:41:10 --> Output Class Initialized
DEBUG - 2023-05-09 10:41:10 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:10 --> Security Class Initialized
INFO - 2023-05-09 10:41:10 --> Utf8 Class Initialized
DEBUG - 2023-05-09 10:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:10 --> URI Class Initialized
INFO - 2023-05-09 10:41:10 --> Input Class Initialized
INFO - 2023-05-09 10:41:10 --> Language Class Initialized
INFO - 2023-05-09 10:41:10 --> Router Class Initialized
INFO - 2023-05-09 10:41:10 --> Loader Class Initialized
INFO - 2023-05-09 10:41:10 --> Output Class Initialized
INFO - 2023-05-09 10:41:10 --> Controller Class Initialized
INFO - 2023-05-09 10:41:10 --> Security Class Initialized
DEBUG - 2023-05-09 10:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:10 --> Input Class Initialized
INFO - 2023-05-09 10:41:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:10 --> Language Class Initialized
INFO - 2023-05-09 10:41:10 --> Loader Class Initialized
INFO - 2023-05-09 10:41:10 --> Controller Class Initialized
DEBUG - 2023-05-09 10:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:41:10 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:10 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:41:10 --> Total execution time: 0.1043
INFO - 2023-05-09 10:41:10 --> Final output sent to browser
DEBUG - 2023-05-09 10:41:10 --> Total execution time: 0.0694
INFO - 2023-05-09 10:41:47 --> Config Class Initialized
INFO - 2023-05-09 10:41:47 --> Config Class Initialized
INFO - 2023-05-09 10:41:47 --> Hooks Class Initialized
INFO - 2023-05-09 10:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:47 --> Utf8 Class Initialized
DEBUG - 2023-05-09 10:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:47 --> Utf8 Class Initialized
INFO - 2023-05-09 10:41:47 --> URI Class Initialized
INFO - 2023-05-09 10:41:47 --> URI Class Initialized
INFO - 2023-05-09 10:41:47 --> Router Class Initialized
INFO - 2023-05-09 10:41:47 --> Router Class Initialized
INFO - 2023-05-09 10:41:47 --> Output Class Initialized
INFO - 2023-05-09 10:41:47 --> Security Class Initialized
INFO - 2023-05-09 10:41:47 --> Output Class Initialized
DEBUG - 2023-05-09 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:47 --> Security Class Initialized
INFO - 2023-05-09 10:41:47 --> Input Class Initialized
INFO - 2023-05-09 10:41:47 --> Language Class Initialized
DEBUG - 2023-05-09 10:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:47 --> Input Class Initialized
INFO - 2023-05-09 10:41:47 --> Language Class Initialized
INFO - 2023-05-09 10:41:47 --> Loader Class Initialized
INFO - 2023-05-09 10:41:47 --> Loader Class Initialized
INFO - 2023-05-09 10:41:47 --> Controller Class Initialized
INFO - 2023-05-09 10:41:47 --> Controller Class Initialized
DEBUG - 2023-05-09 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:47 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:48 --> Final output sent to browser
DEBUG - 2023-05-09 10:41:48 --> Total execution time: 0.1544
INFO - 2023-05-09 10:41:48 --> Config Class Initialized
INFO - 2023-05-09 10:41:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:41:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:48 --> Utf8 Class Initialized
INFO - 2023-05-09 10:41:48 --> URI Class Initialized
INFO - 2023-05-09 10:41:48 --> Router Class Initialized
INFO - 2023-05-09 10:41:48 --> Output Class Initialized
INFO - 2023-05-09 10:41:48 --> Security Class Initialized
DEBUG - 2023-05-09 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:48 --> Input Class Initialized
INFO - 2023-05-09 10:41:48 --> Language Class Initialized
INFO - 2023-05-09 10:41:48 --> Loader Class Initialized
INFO - 2023-05-09 10:41:48 --> Final output sent to browser
INFO - 2023-05-09 10:41:48 --> Controller Class Initialized
DEBUG - 2023-05-09 10:41:48 --> Total execution time: 0.1603
DEBUG - 2023-05-09 10:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:41:48 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:48 --> Config Class Initialized
INFO - 2023-05-09 10:41:48 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:41:48 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:41:48 --> Utf8 Class Initialized
INFO - 2023-05-09 10:41:48 --> URI Class Initialized
INFO - 2023-05-09 10:41:48 --> Router Class Initialized
INFO - 2023-05-09 10:41:48 --> Output Class Initialized
INFO - 2023-05-09 10:41:48 --> Security Class Initialized
DEBUG - 2023-05-09 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:41:48 --> Input Class Initialized
INFO - 2023-05-09 10:41:48 --> Language Class Initialized
INFO - 2023-05-09 10:41:48 --> Loader Class Initialized
INFO - 2023-05-09 10:41:48 --> Controller Class Initialized
DEBUG - 2023-05-09 10:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:41:48 --> Database Driver Class Initialized
INFO - 2023-05-09 10:41:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:48 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:41:48 --> Final output sent to browser
DEBUG - 2023-05-09 10:41:48 --> Total execution time: 0.2868
INFO - 2023-05-09 10:41:48 --> Final output sent to browser
DEBUG - 2023-05-09 10:41:48 --> Total execution time: 0.2912
INFO - 2023-05-09 10:42:29 --> Config Class Initialized
INFO - 2023-05-09 10:42:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:42:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:42:29 --> Utf8 Class Initialized
INFO - 2023-05-09 10:42:29 --> URI Class Initialized
INFO - 2023-05-09 10:42:29 --> Router Class Initialized
INFO - 2023-05-09 10:42:29 --> Output Class Initialized
INFO - 2023-05-09 10:42:29 --> Security Class Initialized
DEBUG - 2023-05-09 10:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:42:29 --> Input Class Initialized
INFO - 2023-05-09 10:42:29 --> Language Class Initialized
INFO - 2023-05-09 10:42:29 --> Loader Class Initialized
INFO - 2023-05-09 10:42:29 --> Controller Class Initialized
DEBUG - 2023-05-09 10:42:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:42:29 --> Database Driver Class Initialized
INFO - 2023-05-09 10:42:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:42:29 --> Final output sent to browser
DEBUG - 2023-05-09 10:42:29 --> Total execution time: 0.1345
INFO - 2023-05-09 10:42:29 --> Config Class Initialized
INFO - 2023-05-09 10:42:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:42:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:42:29 --> Utf8 Class Initialized
INFO - 2023-05-09 10:42:29 --> URI Class Initialized
INFO - 2023-05-09 10:42:29 --> Router Class Initialized
INFO - 2023-05-09 10:42:29 --> Output Class Initialized
INFO - 2023-05-09 10:42:29 --> Security Class Initialized
DEBUG - 2023-05-09 10:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:42:29 --> Input Class Initialized
INFO - 2023-05-09 10:42:29 --> Language Class Initialized
INFO - 2023-05-09 10:42:29 --> Loader Class Initialized
INFO - 2023-05-09 10:42:29 --> Controller Class Initialized
DEBUG - 2023-05-09 10:42:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:42:29 --> Database Driver Class Initialized
INFO - 2023-05-09 10:42:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:42:29 --> Final output sent to browser
DEBUG - 2023-05-09 10:42:29 --> Total execution time: 0.0123
INFO - 2023-05-09 10:42:32 --> Config Class Initialized
INFO - 2023-05-09 10:42:32 --> Hooks Class Initialized
INFO - 2023-05-09 10:42:32 --> Config Class Initialized
INFO - 2023-05-09 10:42:32 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:42:32 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:42:32 --> Utf8 Class Initialized
INFO - 2023-05-09 10:42:32 --> Utf8 Class Initialized
INFO - 2023-05-09 10:42:32 --> URI Class Initialized
INFO - 2023-05-09 10:42:32 --> URI Class Initialized
INFO - 2023-05-09 10:42:32 --> Router Class Initialized
INFO - 2023-05-09 10:42:32 --> Router Class Initialized
INFO - 2023-05-09 10:42:32 --> Output Class Initialized
INFO - 2023-05-09 10:42:32 --> Output Class Initialized
INFO - 2023-05-09 10:42:32 --> Security Class Initialized
INFO - 2023-05-09 10:42:32 --> Security Class Initialized
DEBUG - 2023-05-09 10:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:42:32 --> Input Class Initialized
INFO - 2023-05-09 10:42:32 --> Input Class Initialized
INFO - 2023-05-09 10:42:32 --> Language Class Initialized
INFO - 2023-05-09 10:42:32 --> Language Class Initialized
INFO - 2023-05-09 10:42:32 --> Loader Class Initialized
INFO - 2023-05-09 10:42:32 --> Loader Class Initialized
INFO - 2023-05-09 10:42:32 --> Controller Class Initialized
INFO - 2023-05-09 10:42:32 --> Controller Class Initialized
DEBUG - 2023-05-09 10:42:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:42:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:42:32 --> Database Driver Class Initialized
INFO - 2023-05-09 10:42:32 --> Database Driver Class Initialized
INFO - 2023-05-09 10:42:32 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:42:32 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:42:32 --> Final output sent to browser
DEBUG - 2023-05-09 10:42:32 --> Total execution time: 0.0318
INFO - 2023-05-09 10:42:32 --> Config Class Initialized
INFO - 2023-05-09 10:42:32 --> Final output sent to browser
DEBUG - 2023-05-09 10:42:32 --> Total execution time: 0.0506
INFO - 2023-05-09 10:42:32 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:42:32 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:42:32 --> Utf8 Class Initialized
INFO - 2023-05-09 10:42:32 --> URI Class Initialized
INFO - 2023-05-09 10:42:32 --> Router Class Initialized
INFO - 2023-05-09 10:42:32 --> Output Class Initialized
INFO - 2023-05-09 10:42:32 --> Config Class Initialized
INFO - 2023-05-09 10:42:33 --> Hooks Class Initialized
INFO - 2023-05-09 10:42:33 --> Security Class Initialized
DEBUG - 2023-05-09 10:42:33 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:42:33 --> Utf8 Class Initialized
INFO - 2023-05-09 10:42:33 --> Input Class Initialized
INFO - 2023-05-09 10:42:33 --> Language Class Initialized
INFO - 2023-05-09 10:42:33 --> URI Class Initialized
INFO - 2023-05-09 10:42:33 --> Loader Class Initialized
INFO - 2023-05-09 10:42:33 --> Router Class Initialized
INFO - 2023-05-09 10:42:33 --> Controller Class Initialized
INFO - 2023-05-09 10:42:33 --> Output Class Initialized
DEBUG - 2023-05-09 10:42:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:42:33 --> Security Class Initialized
DEBUG - 2023-05-09 10:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:42:33 --> Database Driver Class Initialized
INFO - 2023-05-09 10:42:33 --> Input Class Initialized
INFO - 2023-05-09 10:42:33 --> Language Class Initialized
INFO - 2023-05-09 10:42:33 --> Loader Class Initialized
INFO - 2023-05-09 10:42:33 --> Controller Class Initialized
DEBUG - 2023-05-09 10:42:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:42:33 --> Database Driver Class Initialized
INFO - 2023-05-09 10:42:33 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:42:33 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:42:33 --> Final output sent to browser
DEBUG - 2023-05-09 10:42:33 --> Total execution time: 0.1022
INFO - 2023-05-09 10:42:33 --> Final output sent to browser
DEBUG - 2023-05-09 10:42:33 --> Total execution time: 0.0666
INFO - 2023-05-09 10:45:02 --> Config Class Initialized
INFO - 2023-05-09 10:45:02 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:02 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:02 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:02 --> URI Class Initialized
INFO - 2023-05-09 10:45:02 --> Router Class Initialized
INFO - 2023-05-09 10:45:02 --> Output Class Initialized
INFO - 2023-05-09 10:45:02 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:02 --> Input Class Initialized
INFO - 2023-05-09 10:45:02 --> Language Class Initialized
INFO - 2023-05-09 10:45:02 --> Loader Class Initialized
INFO - 2023-05-09 10:45:02 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:02 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:02 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:02 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:02 --> Total execution time: 0.0221
INFO - 2023-05-09 10:45:02 --> Config Class Initialized
INFO - 2023-05-09 10:45:02 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:02 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:02 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:02 --> URI Class Initialized
INFO - 2023-05-09 10:45:02 --> Router Class Initialized
INFO - 2023-05-09 10:45:02 --> Output Class Initialized
INFO - 2023-05-09 10:45:02 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:02 --> Input Class Initialized
INFO - 2023-05-09 10:45:02 --> Language Class Initialized
INFO - 2023-05-09 10:45:02 --> Loader Class Initialized
INFO - 2023-05-09 10:45:02 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:02 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:02 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:02 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:02 --> Total execution time: 0.0110
INFO - 2023-05-09 10:45:05 --> Config Class Initialized
INFO - 2023-05-09 10:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:05 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:05 --> Config Class Initialized
INFO - 2023-05-09 10:45:05 --> Hooks Class Initialized
INFO - 2023-05-09 10:45:05 --> URI Class Initialized
DEBUG - 2023-05-09 10:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:05 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:05 --> Router Class Initialized
INFO - 2023-05-09 10:45:05 --> URI Class Initialized
INFO - 2023-05-09 10:45:05 --> Output Class Initialized
INFO - 2023-05-09 10:45:05 --> Router Class Initialized
INFO - 2023-05-09 10:45:05 --> Output Class Initialized
INFO - 2023-05-09 10:45:05 --> Security Class Initialized
INFO - 2023-05-09 10:45:05 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:05 --> Input Class Initialized
INFO - 2023-05-09 10:45:05 --> Input Class Initialized
INFO - 2023-05-09 10:45:05 --> Language Class Initialized
INFO - 2023-05-09 10:45:05 --> Language Class Initialized
INFO - 2023-05-09 10:45:05 --> Loader Class Initialized
INFO - 2023-05-09 10:45:05 --> Loader Class Initialized
INFO - 2023-05-09 10:45:05 --> Controller Class Initialized
INFO - 2023-05-09 10:45:05 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-09 10:45:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:05 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:05 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:05 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:05 --> Total execution time: 0.1706
INFO - 2023-05-09 10:45:05 --> Config Class Initialized
INFO - 2023-05-09 10:45:05 --> Final output sent to browser
INFO - 2023-05-09 10:45:05 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:05 --> Total execution time: 0.1792
DEBUG - 2023-05-09 10:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:05 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:05 --> URI Class Initialized
INFO - 2023-05-09 10:45:05 --> Router Class Initialized
INFO - 2023-05-09 10:45:05 --> Output Class Initialized
INFO - 2023-05-09 10:45:05 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:05 --> Config Class Initialized
INFO - 2023-05-09 10:45:05 --> Input Class Initialized
INFO - 2023-05-09 10:45:05 --> Hooks Class Initialized
INFO - 2023-05-09 10:45:05 --> Language Class Initialized
DEBUG - 2023-05-09 10:45:05 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:05 --> Loader Class Initialized
INFO - 2023-05-09 10:45:05 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:05 --> Controller Class Initialized
INFO - 2023-05-09 10:45:05 --> URI Class Initialized
DEBUG - 2023-05-09 10:45:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:05 --> Router Class Initialized
INFO - 2023-05-09 10:45:05 --> Output Class Initialized
INFO - 2023-05-09 10:45:05 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:05 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:05 --> Input Class Initialized
INFO - 2023-05-09 10:45:05 --> Language Class Initialized
INFO - 2023-05-09 10:45:05 --> Loader Class Initialized
INFO - 2023-05-09 10:45:05 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:05 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:05 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:05 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:05 --> Total execution time: 0.0788
INFO - 2023-05-09 10:45:05 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:05 --> Total execution time: 0.0489
INFO - 2023-05-09 10:45:07 --> Config Class Initialized
INFO - 2023-05-09 10:45:07 --> Config Class Initialized
INFO - 2023-05-09 10:45:07 --> Hooks Class Initialized
INFO - 2023-05-09 10:45:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:07 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:45:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:07 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:07 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:07 --> URI Class Initialized
INFO - 2023-05-09 10:45:07 --> URI Class Initialized
INFO - 2023-05-09 10:45:07 --> Router Class Initialized
INFO - 2023-05-09 10:45:07 --> Router Class Initialized
INFO - 2023-05-09 10:45:07 --> Output Class Initialized
INFO - 2023-05-09 10:45:07 --> Output Class Initialized
INFO - 2023-05-09 10:45:07 --> Security Class Initialized
INFO - 2023-05-09 10:45:07 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-09 10:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:07 --> Input Class Initialized
INFO - 2023-05-09 10:45:07 --> Input Class Initialized
INFO - 2023-05-09 10:45:07 --> Language Class Initialized
INFO - 2023-05-09 10:45:07 --> Language Class Initialized
INFO - 2023-05-09 10:45:07 --> Loader Class Initialized
INFO - 2023-05-09 10:45:07 --> Loader Class Initialized
INFO - 2023-05-09 10:45:07 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:07 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:07 --> Total execution time: 0.0061
INFO - 2023-05-09 10:45:07 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:07 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:07 --> Config Class Initialized
INFO - 2023-05-09 10:45:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:07 --> Final output sent to browser
INFO - 2023-05-09 10:45:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:07 --> Total execution time: 0.0505
DEBUG - 2023-05-09 10:45:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:07 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:07 --> URI Class Initialized
INFO - 2023-05-09 10:45:07 --> Router Class Initialized
INFO - 2023-05-09 10:45:07 --> Output Class Initialized
INFO - 2023-05-09 10:45:07 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:07 --> Input Class Initialized
INFO - 2023-05-09 10:45:07 --> Language Class Initialized
INFO - 2023-05-09 10:45:07 --> Loader Class Initialized
INFO - 2023-05-09 10:45:07 --> Controller Class Initialized
INFO - 2023-05-09 10:45:07 --> Config Class Initialized
DEBUG - 2023-05-09 10:45:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:07 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:07 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:07 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:07 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:07 --> URI Class Initialized
INFO - 2023-05-09 10:45:07 --> Router Class Initialized
INFO - 2023-05-09 10:45:07 --> Output Class Initialized
INFO - 2023-05-09 10:45:07 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:07 --> Input Class Initialized
INFO - 2023-05-09 10:45:07 --> Language Class Initialized
INFO - 2023-05-09 10:45:07 --> Loader Class Initialized
INFO - 2023-05-09 10:45:07 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:07 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:07 --> Model "Login_model" initialized
INFO - 2023-05-09 10:45:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:07 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:07 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:07 --> Total execution time: 0.0147
INFO - 2023-05-09 10:45:07 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:07 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:07 --> Total execution time: 0.1013
INFO - 2023-05-09 10:45:28 --> Config Class Initialized
INFO - 2023-05-09 10:45:28 --> Config Class Initialized
INFO - 2023-05-09 10:45:28 --> Hooks Class Initialized
INFO - 2023-05-09 10:45:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:28 --> UTF-8 Support Enabled
DEBUG - 2023-05-09 10:45:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:28 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:28 --> URI Class Initialized
INFO - 2023-05-09 10:45:28 --> Router Class Initialized
INFO - 2023-05-09 10:45:28 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:28 --> Output Class Initialized
INFO - 2023-05-09 10:45:28 --> URI Class Initialized
INFO - 2023-05-09 10:45:28 --> Security Class Initialized
INFO - 2023-05-09 10:45:28 --> Router Class Initialized
DEBUG - 2023-05-09 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:28 --> Output Class Initialized
INFO - 2023-05-09 10:45:28 --> Input Class Initialized
INFO - 2023-05-09 10:45:28 --> Security Class Initialized
INFO - 2023-05-09 10:45:28 --> Language Class Initialized
DEBUG - 2023-05-09 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:28 --> Input Class Initialized
INFO - 2023-05-09 10:45:28 --> Loader Class Initialized
INFO - 2023-05-09 10:45:28 --> Language Class Initialized
INFO - 2023-05-09 10:45:28 --> Controller Class Initialized
INFO - 2023-05-09 10:45:28 --> Loader Class Initialized
DEBUG - 2023-05-09 10:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:28 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:28 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:28 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:28 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:28 --> Total execution time: 0.0990
INFO - 2023-05-09 10:45:28 --> Config Class Initialized
INFO - 2023-05-09 10:45:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:28 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:28 --> URI Class Initialized
INFO - 2023-05-09 10:45:28 --> Router Class Initialized
INFO - 2023-05-09 10:45:28 --> Output Class Initialized
INFO - 2023-05-09 10:45:28 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:28 --> Input Class Initialized
INFO - 2023-05-09 10:45:28 --> Language Class Initialized
INFO - 2023-05-09 10:45:28 --> Loader Class Initialized
INFO - 2023-05-09 10:45:28 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:28 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:28 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:28 --> Total execution time: 0.1065
INFO - 2023-05-09 10:45:28 --> Config Class Initialized
INFO - 2023-05-09 10:45:28 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:28 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:28 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:28 --> URI Class Initialized
INFO - 2023-05-09 10:45:28 --> Router Class Initialized
INFO - 2023-05-09 10:45:28 --> Output Class Initialized
INFO - 2023-05-09 10:45:28 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:28 --> Input Class Initialized
INFO - 2023-05-09 10:45:28 --> Language Class Initialized
INFO - 2023-05-09 10:45:28 --> Loader Class Initialized
INFO - 2023-05-09 10:45:28 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:28 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:28 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:28 --> Total execution time: 0.0201
INFO - 2023-05-09 10:45:28 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:28 --> Total execution time: 0.0270
INFO - 2023-05-09 10:45:29 --> Config Class Initialized
INFO - 2023-05-09 10:45:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:29 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:29 --> URI Class Initialized
INFO - 2023-05-09 10:45:29 --> Router Class Initialized
INFO - 2023-05-09 10:45:29 --> Output Class Initialized
INFO - 2023-05-09 10:45:29 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:29 --> Input Class Initialized
INFO - 2023-05-09 10:45:29 --> Language Class Initialized
INFO - 2023-05-09 10:45:29 --> Loader Class Initialized
INFO - 2023-05-09 10:45:29 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:29 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:29 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:29 --> Total execution time: 0.0155
INFO - 2023-05-09 10:45:29 --> Config Class Initialized
INFO - 2023-05-09 10:45:29 --> Hooks Class Initialized
DEBUG - 2023-05-09 10:45:29 --> UTF-8 Support Enabled
INFO - 2023-05-09 10:45:29 --> Utf8 Class Initialized
INFO - 2023-05-09 10:45:29 --> URI Class Initialized
INFO - 2023-05-09 10:45:29 --> Router Class Initialized
INFO - 2023-05-09 10:45:29 --> Output Class Initialized
INFO - 2023-05-09 10:45:29 --> Security Class Initialized
DEBUG - 2023-05-09 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-09 10:45:29 --> Input Class Initialized
INFO - 2023-05-09 10:45:29 --> Language Class Initialized
INFO - 2023-05-09 10:45:29 --> Loader Class Initialized
INFO - 2023-05-09 10:45:29 --> Controller Class Initialized
DEBUG - 2023-05-09 10:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-09 10:45:29 --> Database Driver Class Initialized
INFO - 2023-05-09 10:45:29 --> Model "Cluster_model" initialized
INFO - 2023-05-09 10:45:29 --> Final output sent to browser
DEBUG - 2023-05-09 10:45:29 --> Total execution time: 0.0129
