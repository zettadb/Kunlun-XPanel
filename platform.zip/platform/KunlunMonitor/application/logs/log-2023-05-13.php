<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-13 01:32:32 --> Config Class Initialized
INFO - 2023-05-13 01:32:32 --> Hooks Class Initialized
DEBUG - 2023-05-13 01:32:32 --> UTF-8 Support Enabled
INFO - 2023-05-13 01:32:32 --> Utf8 Class Initialized
INFO - 2023-05-13 01:32:32 --> URI Class Initialized
INFO - 2023-05-13 01:32:32 --> Router Class Initialized
INFO - 2023-05-13 01:32:32 --> Output Class Initialized
INFO - 2023-05-13 01:32:32 --> Security Class Initialized
DEBUG - 2023-05-13 01:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-13 01:32:32 --> Input Class Initialized
INFO - 2023-05-13 01:32:32 --> Language Class Initialized
ERROR - 2023-05-13 01:32:32 --> 404 Page Not Found: Faviconico/index
