<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-05 03:22:52 --> Config Class Initialized
INFO - 2023-06-05 03:22:52 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:22:52 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:22:52 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:52 --> URI Class Initialized
INFO - 2023-06-05 03:22:52 --> Router Class Initialized
INFO - 2023-06-05 03:22:52 --> Output Class Initialized
INFO - 2023-06-05 03:22:52 --> Security Class Initialized
DEBUG - 2023-06-05 03:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:22:52 --> Input Class Initialized
INFO - 2023-06-05 03:22:52 --> Language Class Initialized
INFO - 2023-06-05 03:22:53 --> Loader Class Initialized
INFO - 2023-06-05 03:22:53 --> Controller Class Initialized
INFO - 2023-06-05 03:22:53 --> Helper loaded: form_helper
INFO - 2023-06-05 03:22:53 --> Helper loaded: url_helper
DEBUG - 2023-06-05 03:22:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:22:53 --> Model "Change_model" initialized
INFO - 2023-06-05 03:22:53 --> Model "Grafana_model" initialized
INFO - 2023-06-05 03:22:53 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:53 --> Total execution time: 0.6293
INFO - 2023-06-05 03:22:53 --> Config Class Initialized
INFO - 2023-06-05 03:22:53 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:22:53 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:22:53 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:53 --> URI Class Initialized
INFO - 2023-06-05 03:22:53 --> Router Class Initialized
INFO - 2023-06-05 03:22:53 --> Output Class Initialized
INFO - 2023-06-05 03:22:53 --> Security Class Initialized
DEBUG - 2023-06-05 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:22:53 --> Input Class Initialized
INFO - 2023-06-05 03:22:53 --> Language Class Initialized
INFO - 2023-06-05 03:22:53 --> Loader Class Initialized
INFO - 2023-06-05 03:22:53 --> Controller Class Initialized
INFO - 2023-06-05 03:22:53 --> Helper loaded: form_helper
INFO - 2023-06-05 03:22:53 --> Helper loaded: url_helper
DEBUG - 2023-06-05 03:22:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:22:53 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:53 --> Total execution time: 0.2169
INFO - 2023-06-05 03:22:53 --> Config Class Initialized
INFO - 2023-06-05 03:22:53 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:22:53 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:22:53 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:53 --> URI Class Initialized
INFO - 2023-06-05 03:22:53 --> Router Class Initialized
INFO - 2023-06-05 03:22:53 --> Output Class Initialized
INFO - 2023-06-05 03:22:53 --> Security Class Initialized
DEBUG - 2023-06-05 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:22:53 --> Input Class Initialized
INFO - 2023-06-05 03:22:53 --> Language Class Initialized
INFO - 2023-06-05 03:22:53 --> Loader Class Initialized
INFO - 2023-06-05 03:22:53 --> Controller Class Initialized
INFO - 2023-06-05 03:22:53 --> Helper loaded: form_helper
INFO - 2023-06-05 03:22:53 --> Helper loaded: url_helper
DEBUG - 2023-06-05 03:22:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:22:53 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:54 --> Model "Login_model" initialized
INFO - 2023-06-05 03:22:54 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:54 --> Total execution time: 0.5501
INFO - 2023-06-05 03:22:54 --> Config Class Initialized
INFO - 2023-06-05 03:22:54 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:22:54 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:22:54 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:54 --> URI Class Initialized
INFO - 2023-06-05 03:22:54 --> Router Class Initialized
INFO - 2023-06-05 03:22:54 --> Output Class Initialized
INFO - 2023-06-05 03:22:54 --> Security Class Initialized
DEBUG - 2023-06-05 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:22:54 --> Input Class Initialized
INFO - 2023-06-05 03:22:54 --> Language Class Initialized
INFO - 2023-06-05 03:22:54 --> Loader Class Initialized
INFO - 2023-06-05 03:22:54 --> Controller Class Initialized
DEBUG - 2023-06-05 03:22:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:22:54 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:54 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:22:54 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:54 --> Total execution time: 0.2340
INFO - 2023-06-05 03:22:54 --> Config Class Initialized
INFO - 2023-06-05 03:22:54 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:22:54 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:22:54 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:54 --> URI Class Initialized
INFO - 2023-06-05 03:22:54 --> Router Class Initialized
INFO - 2023-06-05 03:22:54 --> Output Class Initialized
INFO - 2023-06-05 03:22:54 --> Security Class Initialized
DEBUG - 2023-06-05 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:22:54 --> Input Class Initialized
INFO - 2023-06-05 03:22:54 --> Language Class Initialized
INFO - 2023-06-05 03:22:54 --> Loader Class Initialized
INFO - 2023-06-05 03:22:54 --> Controller Class Initialized
DEBUG - 2023-06-05 03:22:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:22:54 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:54 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:22:54 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:54 --> Total execution time: 0.1787
INFO - 2023-06-05 03:22:55 --> Config Class Initialized
INFO - 2023-06-05 03:22:55 --> Config Class Initialized
INFO - 2023-06-05 03:22:55 --> Hooks Class Initialized
INFO - 2023-06-05 03:22:55 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:22:55 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:22:55 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:55 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:55 --> URI Class Initialized
INFO - 2023-06-05 03:22:55 --> URI Class Initialized
INFO - 2023-06-05 03:22:55 --> Router Class Initialized
INFO - 2023-06-05 03:22:55 --> Router Class Initialized
INFO - 2023-06-05 03:22:55 --> Output Class Initialized
INFO - 2023-06-05 03:22:55 --> Output Class Initialized
INFO - 2023-06-05 03:22:55 --> Security Class Initialized
INFO - 2023-06-05 03:22:55 --> Security Class Initialized
DEBUG - 2023-06-05 03:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:22:55 --> Input Class Initialized
INFO - 2023-06-05 03:22:55 --> Input Class Initialized
INFO - 2023-06-05 03:22:55 --> Language Class Initialized
INFO - 2023-06-05 03:22:55 --> Language Class Initialized
INFO - 2023-06-05 03:22:55 --> Loader Class Initialized
INFO - 2023-06-05 03:22:55 --> Loader Class Initialized
INFO - 2023-06-05 03:22:55 --> Controller Class Initialized
INFO - 2023-06-05 03:22:55 --> Controller Class Initialized
DEBUG - 2023-06-05 03:22:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 03:22:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:22:55 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:55 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:55 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:22:55 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:22:55 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:55 --> Total execution time: 0.2020
INFO - 2023-06-05 03:22:55 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:55 --> Model "Login_model" initialized
INFO - 2023-06-05 03:22:55 --> Config Class Initialized
INFO - 2023-06-05 03:22:55 --> Hooks Class Initialized
INFO - 2023-06-05 03:22:55 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:22:55 --> Total execution time: 0.2948
INFO - 2023-06-05 03:22:55 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:55 --> URI Class Initialized
INFO - 2023-06-05 03:22:55 --> Router Class Initialized
INFO - 2023-06-05 03:22:55 --> Output Class Initialized
INFO - 2023-06-05 03:22:55 --> Config Class Initialized
INFO - 2023-06-05 03:22:55 --> Security Class Initialized
INFO - 2023-06-05 03:22:55 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:22:55 --> Input Class Initialized
INFO - 2023-06-05 03:22:55 --> Language Class Initialized
DEBUG - 2023-06-05 03:22:55 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:22:55 --> Utf8 Class Initialized
INFO - 2023-06-05 03:22:55 --> URI Class Initialized
INFO - 2023-06-05 03:22:55 --> Loader Class Initialized
INFO - 2023-06-05 03:22:55 --> Controller Class Initialized
INFO - 2023-06-05 03:22:55 --> Router Class Initialized
DEBUG - 2023-06-05 03:22:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:22:55 --> Output Class Initialized
INFO - 2023-06-05 03:22:55 --> Security Class Initialized
DEBUG - 2023-06-05 03:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:22:55 --> Input Class Initialized
INFO - 2023-06-05 03:22:55 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:55 --> Language Class Initialized
INFO - 2023-06-05 03:22:55 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:22:55 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:55 --> Total execution time: 0.2386
INFO - 2023-06-05 03:22:55 --> Loader Class Initialized
INFO - 2023-06-05 03:22:55 --> Controller Class Initialized
DEBUG - 2023-06-05 03:22:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:22:55 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:55 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:22:55 --> Database Driver Class Initialized
INFO - 2023-06-05 03:22:55 --> Model "Login_model" initialized
INFO - 2023-06-05 03:22:55 --> Final output sent to browser
DEBUG - 2023-06-05 03:22:55 --> Total execution time: 0.3539
INFO - 2023-06-05 03:27:30 --> Config Class Initialized
INFO - 2023-06-05 03:27:30 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:27:30 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:30 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:30 --> URI Class Initialized
INFO - 2023-06-05 03:27:30 --> Router Class Initialized
INFO - 2023-06-05 03:27:30 --> Output Class Initialized
INFO - 2023-06-05 03:27:30 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:30 --> Input Class Initialized
INFO - 2023-06-05 03:27:30 --> Language Class Initialized
INFO - 2023-06-05 03:27:30 --> Loader Class Initialized
INFO - 2023-06-05 03:27:30 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:31 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:31 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:31 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:31 --> Total execution time: 0.2756
INFO - 2023-06-05 03:27:31 --> Config Class Initialized
INFO - 2023-06-05 03:27:31 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:27:31 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:31 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:31 --> URI Class Initialized
INFO - 2023-06-05 03:27:31 --> Router Class Initialized
INFO - 2023-06-05 03:27:31 --> Output Class Initialized
INFO - 2023-06-05 03:27:31 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:31 --> Input Class Initialized
INFO - 2023-06-05 03:27:31 --> Language Class Initialized
INFO - 2023-06-05 03:27:31 --> Loader Class Initialized
INFO - 2023-06-05 03:27:31 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:31 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:31 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:31 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:31 --> Total execution time: 0.2485
INFO - 2023-06-05 03:27:32 --> Config Class Initialized
INFO - 2023-06-05 03:27:32 --> Config Class Initialized
INFO - 2023-06-05 03:27:32 --> Hooks Class Initialized
INFO - 2023-06-05 03:27:32 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:27:32 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:27:32 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:32 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:32 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:32 --> URI Class Initialized
INFO - 2023-06-05 03:27:32 --> URI Class Initialized
INFO - 2023-06-05 03:27:32 --> Router Class Initialized
INFO - 2023-06-05 03:27:32 --> Router Class Initialized
INFO - 2023-06-05 03:27:32 --> Output Class Initialized
INFO - 2023-06-05 03:27:32 --> Output Class Initialized
INFO - 2023-06-05 03:27:32 --> Security Class Initialized
INFO - 2023-06-05 03:27:32 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:32 --> Input Class Initialized
INFO - 2023-06-05 03:27:32 --> Input Class Initialized
INFO - 2023-06-05 03:27:32 --> Language Class Initialized
INFO - 2023-06-05 03:27:32 --> Language Class Initialized
INFO - 2023-06-05 03:27:32 --> Loader Class Initialized
INFO - 2023-06-05 03:27:32 --> Controller Class Initialized
INFO - 2023-06-05 03:27:32 --> Loader Class Initialized
DEBUG - 2023-06-05 03:27:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:32 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:32 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:32 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:32 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:32 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:32 --> Total execution time: 0.1857
INFO - 2023-06-05 03:27:32 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:33 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:33 --> Model "Login_model" initialized
INFO - 2023-06-05 03:27:33 --> Config Class Initialized
INFO - 2023-06-05 03:27:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:27:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:33 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:33 --> URI Class Initialized
INFO - 2023-06-05 03:27:33 --> Router Class Initialized
INFO - 2023-06-05 03:27:33 --> Output Class Initialized
INFO - 2023-06-05 03:27:33 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:33 --> Input Class Initialized
INFO - 2023-06-05 03:27:33 --> Language Class Initialized
INFO - 2023-06-05 03:27:33 --> Loader Class Initialized
INFO - 2023-06-05 03:27:33 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:33 --> Total execution time: 0.4321
INFO - 2023-06-05 03:27:33 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:33 --> Config Class Initialized
INFO - 2023-06-05 03:27:33 --> Hooks Class Initialized
INFO - 2023-06-05 03:27:33 --> Database Driver Class Initialized
DEBUG - 2023-06-05 03:27:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:33 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:33 --> URI Class Initialized
INFO - 2023-06-05 03:27:33 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:33 --> Total execution time: 0.2950
INFO - 2023-06-05 03:27:33 --> Router Class Initialized
INFO - 2023-06-05 03:27:33 --> Output Class Initialized
INFO - 2023-06-05 03:27:33 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:33 --> Input Class Initialized
INFO - 2023-06-05 03:27:33 --> Language Class Initialized
INFO - 2023-06-05 03:27:33 --> Loader Class Initialized
INFO - 2023-06-05 03:27:33 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:33 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:33 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:33 --> Model "Login_model" initialized
INFO - 2023-06-05 03:27:33 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:33 --> Total execution time: 0.2741
INFO - 2023-06-05 03:27:35 --> Config Class Initialized
INFO - 2023-06-05 03:27:35 --> Config Class Initialized
INFO - 2023-06-05 03:27:35 --> Config Class Initialized
INFO - 2023-06-05 03:27:35 --> Hooks Class Initialized
INFO - 2023-06-05 03:27:35 --> Hooks Class Initialized
INFO - 2023-06-05 03:27:35 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:27:35 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:35 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:35 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:35 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:35 --> URI Class Initialized
INFO - 2023-06-05 03:27:35 --> URI Class Initialized
INFO - 2023-06-05 03:27:35 --> URI Class Initialized
INFO - 2023-06-05 03:27:35 --> Router Class Initialized
INFO - 2023-06-05 03:27:35 --> Router Class Initialized
INFO - 2023-06-05 03:27:35 --> Router Class Initialized
INFO - 2023-06-05 03:27:35 --> Output Class Initialized
INFO - 2023-06-05 03:27:35 --> Output Class Initialized
INFO - 2023-06-05 03:27:35 --> Output Class Initialized
INFO - 2023-06-05 03:27:35 --> Security Class Initialized
INFO - 2023-06-05 03:27:35 --> Security Class Initialized
INFO - 2023-06-05 03:27:35 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:35 --> Input Class Initialized
INFO - 2023-06-05 03:27:35 --> Input Class Initialized
INFO - 2023-06-05 03:27:35 --> Input Class Initialized
INFO - 2023-06-05 03:27:35 --> Language Class Initialized
INFO - 2023-06-05 03:27:35 --> Language Class Initialized
INFO - 2023-06-05 03:27:35 --> Language Class Initialized
INFO - 2023-06-05 03:27:35 --> Loader Class Initialized
INFO - 2023-06-05 03:27:35 --> Loader Class Initialized
INFO - 2023-06-05 03:27:35 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:35 --> Loader Class Initialized
INFO - 2023-06-05 03:27:35 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:35 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:35 --> Final output sent to browser
INFO - 2023-06-05 03:27:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:35 --> Total execution time: 0.2195
DEBUG - 2023-06-05 03:27:35 --> Total execution time: 0.2195
INFO - 2023-06-05 03:27:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:35 --> Total execution time: 0.2452
INFO - 2023-06-05 03:27:35 --> Config Class Initialized
INFO - 2023-06-05 03:27:35 --> Config Class Initialized
INFO - 2023-06-05 03:27:35 --> Hooks Class Initialized
INFO - 2023-06-05 03:27:35 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:27:35 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:35 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:35 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:35 --> URI Class Initialized
INFO - 2023-06-05 03:27:35 --> URI Class Initialized
INFO - 2023-06-05 03:27:35 --> Config Class Initialized
INFO - 2023-06-05 03:27:35 --> Hooks Class Initialized
INFO - 2023-06-05 03:27:35 --> Router Class Initialized
INFO - 2023-06-05 03:27:35 --> Router Class Initialized
INFO - 2023-06-05 03:27:35 --> Output Class Initialized
INFO - 2023-06-05 03:27:35 --> Output Class Initialized
INFO - 2023-06-05 03:27:35 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:35 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:35 --> Security Class Initialized
INFO - 2023-06-05 03:27:35 --> Utf8 Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:35 --> URI Class Initialized
INFO - 2023-06-05 03:27:35 --> Input Class Initialized
INFO - 2023-06-05 03:27:35 --> Input Class Initialized
INFO - 2023-06-05 03:27:35 --> Language Class Initialized
INFO - 2023-06-05 03:27:35 --> Language Class Initialized
INFO - 2023-06-05 03:27:35 --> Router Class Initialized
INFO - 2023-06-05 03:27:35 --> Loader Class Initialized
INFO - 2023-06-05 03:27:35 --> Output Class Initialized
INFO - 2023-06-05 03:27:35 --> Security Class Initialized
INFO - 2023-06-05 03:27:35 --> Loader Class Initialized
INFO - 2023-06-05 03:27:35 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:27:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:35 --> Controller Class Initialized
INFO - 2023-06-05 03:27:35 --> Input Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:35 --> Language Class Initialized
INFO - 2023-06-05 03:27:35 --> Loader Class Initialized
INFO - 2023-06-05 03:27:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:35 --> Controller Class Initialized
INFO - 2023-06-05 03:27:35 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 03:27:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:35 --> Total execution time: 0.1995
INFO - 2023-06-05 03:27:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:27:35 --> Total execution time: 0.2135
INFO - 2023-06-05 03:27:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:35 --> Final output sent to browser
INFO - 2023-06-05 03:27:35 --> Config Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Total execution time: 0.2338
INFO - 2023-06-05 03:27:35 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:27:35 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:35 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:35 --> URI Class Initialized
INFO - 2023-06-05 03:27:35 --> Router Class Initialized
INFO - 2023-06-05 03:27:35 --> Output Class Initialized
INFO - 2023-06-05 03:27:35 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:35 --> Input Class Initialized
INFO - 2023-06-05 03:27:35 --> Language Class Initialized
INFO - 2023-06-05 03:27:35 --> Loader Class Initialized
INFO - 2023-06-05 03:27:35 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:27:36 --> Config Class Initialized
INFO - 2023-06-05 03:27:36 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:27:36 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:27:36 --> Utf8 Class Initialized
INFO - 2023-06-05 03:27:36 --> URI Class Initialized
INFO - 2023-06-05 03:27:36 --> Router Class Initialized
INFO - 2023-06-05 03:27:36 --> Output Class Initialized
INFO - 2023-06-05 03:27:36 --> Security Class Initialized
DEBUG - 2023-06-05 03:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:27:36 --> Input Class Initialized
INFO - 2023-06-05 03:27:36 --> Language Class Initialized
INFO - 2023-06-05 03:27:36 --> Loader Class Initialized
INFO - 2023-06-05 03:27:36 --> Controller Class Initialized
DEBUG - 2023-06-05 03:27:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:27:36 --> Database Driver Class Initialized
INFO - 2023-06-05 03:27:36 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:31:41 --> Config Class Initialized
INFO - 2023-06-05 03:31:41 --> Config Class Initialized
INFO - 2023-06-05 03:31:41 --> Config Class Initialized
INFO - 2023-06-05 03:31:41 --> Hooks Class Initialized
INFO - 2023-06-05 03:31:41 --> Hooks Class Initialized
INFO - 2023-06-05 03:31:41 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:31:41 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:31:41 --> Utf8 Class Initialized
INFO - 2023-06-05 03:31:41 --> Utf8 Class Initialized
INFO - 2023-06-05 03:31:41 --> Utf8 Class Initialized
INFO - 2023-06-05 03:31:41 --> URI Class Initialized
INFO - 2023-06-05 03:31:41 --> URI Class Initialized
INFO - 2023-06-05 03:31:41 --> URI Class Initialized
INFO - 2023-06-05 03:31:41 --> Router Class Initialized
INFO - 2023-06-05 03:31:41 --> Router Class Initialized
INFO - 2023-06-05 03:31:41 --> Router Class Initialized
INFO - 2023-06-05 03:31:41 --> Output Class Initialized
INFO - 2023-06-05 03:31:41 --> Output Class Initialized
INFO - 2023-06-05 03:31:41 --> Output Class Initialized
INFO - 2023-06-05 03:31:41 --> Security Class Initialized
INFO - 2023-06-05 03:31:41 --> Security Class Initialized
INFO - 2023-06-05 03:31:41 --> Security Class Initialized
DEBUG - 2023-06-05 03:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:31:41 --> Input Class Initialized
INFO - 2023-06-05 03:31:41 --> Input Class Initialized
INFO - 2023-06-05 03:31:41 --> Input Class Initialized
INFO - 2023-06-05 03:31:41 --> Language Class Initialized
INFO - 2023-06-05 03:31:41 --> Language Class Initialized
INFO - 2023-06-05 03:31:41 --> Language Class Initialized
INFO - 2023-06-05 03:31:41 --> Loader Class Initialized
INFO - 2023-06-05 03:31:41 --> Loader Class Initialized
INFO - 2023-06-05 03:31:42 --> Controller Class Initialized
INFO - 2023-06-05 03:31:42 --> Controller Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 03:31:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:31:42 --> Loader Class Initialized
INFO - 2023-06-05 03:31:42 --> Controller Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:31:42 --> Database Driver Class Initialized
INFO - 2023-06-05 03:31:42 --> Database Driver Class Initialized
INFO - 2023-06-05 03:31:42 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:31:42 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:31:42 --> Final output sent to browser
INFO - 2023-06-05 03:31:42 --> Final output sent to browser
DEBUG - 2023-06-05 03:31:42 --> Total execution time: 0.2388
DEBUG - 2023-06-05 03:31:42 --> Total execution time: 0.2381
INFO - 2023-06-05 03:31:42 --> Database Driver Class Initialized
INFO - 2023-06-05 03:31:42 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:31:42 --> Final output sent to browser
DEBUG - 2023-06-05 03:31:42 --> Total execution time: 0.2847
INFO - 2023-06-05 03:31:42 --> Config Class Initialized
INFO - 2023-06-05 03:31:42 --> Config Class Initialized
INFO - 2023-06-05 03:31:42 --> Hooks Class Initialized
INFO - 2023-06-05 03:31:42 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:31:42 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:31:42 --> Utf8 Class Initialized
INFO - 2023-06-05 03:31:42 --> Utf8 Class Initialized
INFO - 2023-06-05 03:31:42 --> URI Class Initialized
INFO - 2023-06-05 03:31:42 --> URI Class Initialized
INFO - 2023-06-05 03:31:42 --> Router Class Initialized
INFO - 2023-06-05 03:31:42 --> Router Class Initialized
INFO - 2023-06-05 03:31:42 --> Config Class Initialized
INFO - 2023-06-05 03:31:42 --> Output Class Initialized
INFO - 2023-06-05 03:31:42 --> Output Class Initialized
INFO - 2023-06-05 03:31:42 --> Hooks Class Initialized
INFO - 2023-06-05 03:31:42 --> Security Class Initialized
INFO - 2023-06-05 03:31:42 --> Security Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:31:42 --> Input Class Initialized
INFO - 2023-06-05 03:31:42 --> Input Class Initialized
INFO - 2023-06-05 03:31:42 --> Language Class Initialized
DEBUG - 2023-06-05 03:31:42 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:31:42 --> Language Class Initialized
INFO - 2023-06-05 03:31:42 --> Utf8 Class Initialized
INFO - 2023-06-05 03:31:42 --> URI Class Initialized
INFO - 2023-06-05 03:31:42 --> Loader Class Initialized
INFO - 2023-06-05 03:31:42 --> Loader Class Initialized
INFO - 2023-06-05 03:31:42 --> Router Class Initialized
INFO - 2023-06-05 03:31:42 --> Controller Class Initialized
INFO - 2023-06-05 03:31:42 --> Controller Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 03:31:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:31:42 --> Output Class Initialized
INFO - 2023-06-05 03:31:42 --> Security Class Initialized
INFO - 2023-06-05 03:31:42 --> Database Driver Class Initialized
INFO - 2023-06-05 03:31:42 --> Database Driver Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:31:42 --> Input Class Initialized
INFO - 2023-06-05 03:31:42 --> Language Class Initialized
INFO - 2023-06-05 03:31:42 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:31:42 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:31:42 --> Final output sent to browser
INFO - 2023-06-05 03:31:42 --> Final output sent to browser
DEBUG - 2023-06-05 03:31:42 --> Total execution time: 0.1943
DEBUG - 2023-06-05 03:31:42 --> Total execution time: 0.1934
INFO - 2023-06-05 03:31:42 --> Loader Class Initialized
INFO - 2023-06-05 03:31:42 --> Controller Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:31:42 --> Config Class Initialized
INFO - 2023-06-05 03:31:42 --> Hooks Class Initialized
INFO - 2023-06-05 03:31:42 --> Database Driver Class Initialized
INFO - 2023-06-05 03:31:42 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 03:31:42 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:31:42 --> Utf8 Class Initialized
INFO - 2023-06-05 03:31:42 --> Final output sent to browser
INFO - 2023-06-05 03:31:42 --> URI Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Total execution time: 0.2550
INFO - 2023-06-05 03:31:42 --> Router Class Initialized
INFO - 2023-06-05 03:31:42 --> Output Class Initialized
INFO - 2023-06-05 03:31:42 --> Security Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:31:42 --> Input Class Initialized
INFO - 2023-06-05 03:31:42 --> Language Class Initialized
INFO - 2023-06-05 03:31:42 --> Loader Class Initialized
INFO - 2023-06-05 03:31:42 --> Controller Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:31:42 --> Database Driver Class Initialized
INFO - 2023-06-05 03:31:42 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:31:42 --> Config Class Initialized
INFO - 2023-06-05 03:31:42 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:31:42 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:31:42 --> Utf8 Class Initialized
INFO - 2023-06-05 03:31:42 --> URI Class Initialized
INFO - 2023-06-05 03:31:42 --> Router Class Initialized
INFO - 2023-06-05 03:31:42 --> Output Class Initialized
INFO - 2023-06-05 03:31:42 --> Security Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:31:42 --> Input Class Initialized
INFO - 2023-06-05 03:31:42 --> Language Class Initialized
INFO - 2023-06-05 03:31:42 --> Loader Class Initialized
INFO - 2023-06-05 03:31:42 --> Controller Class Initialized
DEBUG - 2023-06-05 03:31:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:31:42 --> Database Driver Class Initialized
INFO - 2023-06-05 03:31:42 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:44:26 --> Config Class Initialized
INFO - 2023-06-05 03:44:26 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:44:26 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:44:26 --> Utf8 Class Initialized
INFO - 2023-06-05 03:44:26 --> URI Class Initialized
INFO - 2023-06-05 03:44:26 --> Router Class Initialized
INFO - 2023-06-05 03:44:26 --> Output Class Initialized
INFO - 2023-06-05 03:44:26 --> Security Class Initialized
DEBUG - 2023-06-05 03:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:44:26 --> Input Class Initialized
INFO - 2023-06-05 03:44:26 --> Language Class Initialized
INFO - 2023-06-05 03:44:26 --> Loader Class Initialized
INFO - 2023-06-05 03:44:26 --> Controller Class Initialized
DEBUG - 2023-06-05 03:44:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:44:26 --> Database Driver Class Initialized
INFO - 2023-06-05 03:44:26 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:44:26 --> Final output sent to browser
DEBUG - 2023-06-05 03:44:26 --> Total execution time: 0.2151
INFO - 2023-06-05 03:44:26 --> Config Class Initialized
INFO - 2023-06-05 03:44:26 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:44:26 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:44:26 --> Utf8 Class Initialized
INFO - 2023-06-05 03:44:26 --> URI Class Initialized
INFO - 2023-06-05 03:44:26 --> Router Class Initialized
INFO - 2023-06-05 03:44:26 --> Output Class Initialized
INFO - 2023-06-05 03:44:26 --> Security Class Initialized
DEBUG - 2023-06-05 03:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:44:26 --> Input Class Initialized
INFO - 2023-06-05 03:44:26 --> Language Class Initialized
INFO - 2023-06-05 03:44:26 --> Loader Class Initialized
INFO - 2023-06-05 03:44:26 --> Controller Class Initialized
DEBUG - 2023-06-05 03:44:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:44:26 --> Database Driver Class Initialized
INFO - 2023-06-05 03:44:27 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:44:27 --> Final output sent to browser
DEBUG - 2023-06-05 03:44:27 --> Total execution time: 0.2369
INFO - 2023-06-05 03:44:54 --> Config Class Initialized
INFO - 2023-06-05 03:44:54 --> Config Class Initialized
INFO - 2023-06-05 03:44:54 --> Hooks Class Initialized
INFO - 2023-06-05 03:44:54 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:44:54 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:44:54 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:44:54 --> Utf8 Class Initialized
INFO - 2023-06-05 03:44:54 --> Utf8 Class Initialized
INFO - 2023-06-05 03:44:54 --> URI Class Initialized
INFO - 2023-06-05 03:44:54 --> URI Class Initialized
INFO - 2023-06-05 03:44:54 --> Router Class Initialized
INFO - 2023-06-05 03:44:54 --> Router Class Initialized
INFO - 2023-06-05 03:44:54 --> Output Class Initialized
INFO - 2023-06-05 03:44:54 --> Output Class Initialized
INFO - 2023-06-05 03:44:54 --> Security Class Initialized
INFO - 2023-06-05 03:44:54 --> Security Class Initialized
DEBUG - 2023-06-05 03:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:44:54 --> Input Class Initialized
INFO - 2023-06-05 03:44:54 --> Input Class Initialized
INFO - 2023-06-05 03:44:54 --> Language Class Initialized
INFO - 2023-06-05 03:44:54 --> Language Class Initialized
INFO - 2023-06-05 03:44:54 --> Loader Class Initialized
INFO - 2023-06-05 03:44:54 --> Loader Class Initialized
INFO - 2023-06-05 03:44:54 --> Controller Class Initialized
DEBUG - 2023-06-05 03:44:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:44:54 --> Controller Class Initialized
DEBUG - 2023-06-05 03:44:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:44:54 --> Database Driver Class Initialized
INFO - 2023-06-05 03:44:54 --> Database Driver Class Initialized
INFO - 2023-06-05 03:44:54 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:44:54 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:44:54 --> Final output sent to browser
DEBUG - 2023-06-05 03:44:54 --> Total execution time: 0.1846
INFO - 2023-06-05 03:44:54 --> Database Driver Class Initialized
INFO - 2023-06-05 03:44:54 --> Model "Login_model" initialized
INFO - 2023-06-05 03:44:54 --> Config Class Initialized
INFO - 2023-06-05 03:44:54 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:44:54 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:44:54 --> Utf8 Class Initialized
INFO - 2023-06-05 03:44:54 --> URI Class Initialized
INFO - 2023-06-05 03:44:54 --> Router Class Initialized
INFO - 2023-06-05 03:44:54 --> Output Class Initialized
INFO - 2023-06-05 03:44:54 --> Security Class Initialized
DEBUG - 2023-06-05 03:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:44:54 --> Input Class Initialized
INFO - 2023-06-05 03:44:54 --> Language Class Initialized
INFO - 2023-06-05 03:44:54 --> Loader Class Initialized
INFO - 2023-06-05 03:44:54 --> Controller Class Initialized
DEBUG - 2023-06-05 03:44:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:44:54 --> Database Driver Class Initialized
INFO - 2023-06-05 03:44:54 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:44:54 --> Final output sent to browser
INFO - 2023-06-05 03:44:54 --> Final output sent to browser
DEBUG - 2023-06-05 03:44:54 --> Total execution time: 0.1717
DEBUG - 2023-06-05 03:44:54 --> Total execution time: 0.3895
INFO - 2023-06-05 03:44:54 --> Config Class Initialized
INFO - 2023-06-05 03:44:54 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:44:54 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:44:54 --> Utf8 Class Initialized
INFO - 2023-06-05 03:44:54 --> URI Class Initialized
INFO - 2023-06-05 03:44:54 --> Router Class Initialized
INFO - 2023-06-05 03:44:54 --> Output Class Initialized
INFO - 2023-06-05 03:44:54 --> Security Class Initialized
DEBUG - 2023-06-05 03:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:44:54 --> Input Class Initialized
INFO - 2023-06-05 03:44:54 --> Language Class Initialized
INFO - 2023-06-05 03:44:54 --> Loader Class Initialized
INFO - 2023-06-05 03:44:54 --> Controller Class Initialized
DEBUG - 2023-06-05 03:44:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:44:54 --> Database Driver Class Initialized
INFO - 2023-06-05 03:44:54 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:44:55 --> Database Driver Class Initialized
INFO - 2023-06-05 03:44:55 --> Model "Login_model" initialized
INFO - 2023-06-05 03:44:55 --> Final output sent to browser
DEBUG - 2023-06-05 03:44:55 --> Total execution time: 0.4929
INFO - 2023-06-05 03:46:43 --> Config Class Initialized
INFO - 2023-06-05 03:46:43 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:46:43 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:46:43 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:43 --> URI Class Initialized
INFO - 2023-06-05 03:46:43 --> Router Class Initialized
INFO - 2023-06-05 03:46:43 --> Output Class Initialized
INFO - 2023-06-05 03:46:43 --> Security Class Initialized
DEBUG - 2023-06-05 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:46:43 --> Input Class Initialized
INFO - 2023-06-05 03:46:43 --> Language Class Initialized
INFO - 2023-06-05 03:46:43 --> Loader Class Initialized
INFO - 2023-06-05 03:46:43 --> Controller Class Initialized
DEBUG - 2023-06-05 03:46:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:43 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:43 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2566
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
INFO - 2023-06-05 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2744
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2787
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2360
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
INFO - 2023-06-05 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:46:44 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2338
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2466
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.1491
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2005
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> Config Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
INFO - 2023-06-05 03:46:44 --> Hooks Class Initialized
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
DEBUG - 2023-06-05 03:46:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:46:44 --> Utf8 Class Initialized
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
INFO - 2023-06-05 03:46:44 --> URI Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Router Class Initialized
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
INFO - 2023-06-05 03:46:44 --> Output Class Initialized
INFO - 2023-06-05 03:46:44 --> Security Class Initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:46:44 --> Input Class Initialized
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:44 --> Language Class Initialized
INFO - 2023-06-05 03:46:44 --> Loader Class Initialized
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:44 --> Controller Class Initialized
INFO - 2023-06-05 03:46:44 --> Model "Login_model" initialized
DEBUG - 2023-06-05 03:46:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:44 --> Database Driver Class Initialized
INFO - 2023-06-05 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2291
INFO - 2023-06-05 03:46:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:46:44 --> Final output sent to browser
DEBUG - 2023-06-05 03:46:44 --> Total execution time: 0.2054
INFO - 2023-06-05 03:47:10 --> Config Class Initialized
INFO - 2023-06-05 03:47:10 --> Config Class Initialized
INFO - 2023-06-05 03:47:10 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:10 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:10 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:47:10 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:10 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:10 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:10 --> URI Class Initialized
INFO - 2023-06-05 03:47:10 --> URI Class Initialized
INFO - 2023-06-05 03:47:10 --> Router Class Initialized
INFO - 2023-06-05 03:47:10 --> Router Class Initialized
INFO - 2023-06-05 03:47:10 --> Output Class Initialized
INFO - 2023-06-05 03:47:10 --> Output Class Initialized
INFO - 2023-06-05 03:47:10 --> Security Class Initialized
INFO - 2023-06-05 03:47:10 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:10 --> Input Class Initialized
INFO - 2023-06-05 03:47:10 --> Input Class Initialized
INFO - 2023-06-05 03:47:10 --> Language Class Initialized
INFO - 2023-06-05 03:47:10 --> Language Class Initialized
INFO - 2023-06-05 03:47:10 --> Loader Class Initialized
INFO - 2023-06-05 03:47:10 --> Loader Class Initialized
INFO - 2023-06-05 03:47:10 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:10 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:10 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:10 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:11 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:11 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:11 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:11 --> Total execution time: 0.1687
INFO - 2023-06-05 03:47:11 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:11 --> Model "Login_model" initialized
INFO - 2023-06-05 03:47:11 --> Config Class Initialized
INFO - 2023-06-05 03:47:11 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:11 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:11 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:11 --> URI Class Initialized
INFO - 2023-06-05 03:47:11 --> Router Class Initialized
INFO - 2023-06-05 03:47:11 --> Output Class Initialized
INFO - 2023-06-05 03:47:11 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:11 --> Input Class Initialized
INFO - 2023-06-05 03:47:11 --> Language Class Initialized
INFO - 2023-06-05 03:47:11 --> Loader Class Initialized
INFO - 2023-06-05 03:47:11 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:11 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:11 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:11 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:11 --> Total execution time: 0.4029
INFO - 2023-06-05 03:47:11 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:11 --> Total execution time: 0.2084
INFO - 2023-06-05 03:47:11 --> Config Class Initialized
INFO - 2023-06-05 03:47:11 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:11 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:11 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:11 --> URI Class Initialized
INFO - 2023-06-05 03:47:11 --> Router Class Initialized
INFO - 2023-06-05 03:47:11 --> Output Class Initialized
INFO - 2023-06-05 03:47:11 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:11 --> Input Class Initialized
INFO - 2023-06-05 03:47:11 --> Language Class Initialized
INFO - 2023-06-05 03:47:11 --> Loader Class Initialized
INFO - 2023-06-05 03:47:11 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:11 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:11 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:11 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:11 --> Model "Login_model" initialized
INFO - 2023-06-05 03:47:11 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:11 --> Total execution time: 0.3104
INFO - 2023-06-05 03:47:12 --> Config Class Initialized
INFO - 2023-06-05 03:47:12 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:13 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:13 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:13 --> URI Class Initialized
INFO - 2023-06-05 03:47:13 --> Router Class Initialized
INFO - 2023-06-05 03:47:13 --> Output Class Initialized
INFO - 2023-06-05 03:47:13 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:13 --> Input Class Initialized
INFO - 2023-06-05 03:47:13 --> Language Class Initialized
INFO - 2023-06-05 03:47:13 --> Loader Class Initialized
INFO - 2023-06-05 03:47:13 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:13 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:13 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:13 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:13 --> Total execution time: 0.2127
INFO - 2023-06-05 03:47:13 --> Config Class Initialized
INFO - 2023-06-05 03:47:13 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:13 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:13 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:13 --> URI Class Initialized
INFO - 2023-06-05 03:47:13 --> Router Class Initialized
INFO - 2023-06-05 03:47:13 --> Output Class Initialized
INFO - 2023-06-05 03:47:13 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:13 --> Input Class Initialized
INFO - 2023-06-05 03:47:13 --> Language Class Initialized
INFO - 2023-06-05 03:47:13 --> Loader Class Initialized
INFO - 2023-06-05 03:47:13 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:13 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:13 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:13 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:13 --> Total execution time: 0.2086
INFO - 2023-06-05 03:47:28 --> Config Class Initialized
INFO - 2023-06-05 03:47:28 --> Config Class Initialized
INFO - 2023-06-05 03:47:28 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:28 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:47:28 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:28 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:28 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:28 --> URI Class Initialized
INFO - 2023-06-05 03:47:28 --> URI Class Initialized
INFO - 2023-06-05 03:47:28 --> Router Class Initialized
INFO - 2023-06-05 03:47:28 --> Router Class Initialized
INFO - 2023-06-05 03:47:28 --> Output Class Initialized
INFO - 2023-06-05 03:47:28 --> Output Class Initialized
INFO - 2023-06-05 03:47:28 --> Security Class Initialized
INFO - 2023-06-05 03:47:28 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:28 --> Input Class Initialized
INFO - 2023-06-05 03:47:28 --> Input Class Initialized
INFO - 2023-06-05 03:47:28 --> Language Class Initialized
INFO - 2023-06-05 03:47:28 --> Language Class Initialized
INFO - 2023-06-05 03:47:28 --> Loader Class Initialized
INFO - 2023-06-05 03:47:28 --> Loader Class Initialized
INFO - 2023-06-05 03:47:28 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:28 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:28 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:28 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:28 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:28 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:28 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:28 --> Total execution time: 0.1781
INFO - 2023-06-05 03:47:28 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:28 --> Model "Login_model" initialized
INFO - 2023-06-05 03:47:28 --> Config Class Initialized
INFO - 2023-06-05 03:47:28 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:28 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:28 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:28 --> URI Class Initialized
INFO - 2023-06-05 03:47:28 --> Router Class Initialized
INFO - 2023-06-05 03:47:28 --> Output Class Initialized
INFO - 2023-06-05 03:47:28 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:28 --> Input Class Initialized
INFO - 2023-06-05 03:47:28 --> Language Class Initialized
INFO - 2023-06-05 03:47:28 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:28 --> Total execution time: 0.3283
INFO - 2023-06-05 03:47:28 --> Loader Class Initialized
INFO - 2023-06-05 03:47:28 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:28 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:28 --> Config Class Initialized
INFO - 2023-06-05 03:47:28 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:28 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:28 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:47:28 --> Total execution time: 0.2055
INFO - 2023-06-05 03:47:28 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:28 --> URI Class Initialized
INFO - 2023-06-05 03:47:28 --> Router Class Initialized
INFO - 2023-06-05 03:47:28 --> Output Class Initialized
INFO - 2023-06-05 03:47:28 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:28 --> Input Class Initialized
INFO - 2023-06-05 03:47:28 --> Language Class Initialized
INFO - 2023-06-05 03:47:28 --> Loader Class Initialized
INFO - 2023-06-05 03:47:28 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:28 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:28 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:28 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:28 --> Model "Login_model" initialized
INFO - 2023-06-05 03:47:28 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:28 --> Total execution time: 0.2792
INFO - 2023-06-05 03:47:34 --> Config Class Initialized
INFO - 2023-06-05 03:47:34 --> Config Class Initialized
INFO - 2023-06-05 03:47:34 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:47:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:34 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:34 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:34 --> URI Class Initialized
INFO - 2023-06-05 03:47:34 --> URI Class Initialized
INFO - 2023-06-05 03:47:34 --> Router Class Initialized
INFO - 2023-06-05 03:47:34 --> Router Class Initialized
INFO - 2023-06-05 03:47:34 --> Output Class Initialized
INFO - 2023-06-05 03:47:34 --> Output Class Initialized
INFO - 2023-06-05 03:47:34 --> Security Class Initialized
INFO - 2023-06-05 03:47:34 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:34 --> Input Class Initialized
INFO - 2023-06-05 03:47:34 --> Input Class Initialized
INFO - 2023-06-05 03:47:34 --> Language Class Initialized
INFO - 2023-06-05 03:47:34 --> Language Class Initialized
INFO - 2023-06-05 03:47:34 --> Loader Class Initialized
INFO - 2023-06-05 03:47:34 --> Loader Class Initialized
INFO - 2023-06-05 03:47:34 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:34 --> Controller Class Initialized
INFO - 2023-06-05 03:47:34 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:34 --> Total execution time: 0.1004
DEBUG - 2023-06-05 03:47:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:34 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:34 --> Config Class Initialized
INFO - 2023-06-05 03:47:34 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:34 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:34 --> Total execution time: 0.1625
DEBUG - 2023-06-05 03:47:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:34 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:34 --> URI Class Initialized
INFO - 2023-06-05 03:47:34 --> Router Class Initialized
INFO - 2023-06-05 03:47:34 --> Config Class Initialized
INFO - 2023-06-05 03:47:34 --> Output Class Initialized
INFO - 2023-06-05 03:47:34 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:34 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:34 --> Input Class Initialized
DEBUG - 2023-06-05 03:47:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:34 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:34 --> Language Class Initialized
INFO - 2023-06-05 03:47:34 --> URI Class Initialized
INFO - 2023-06-05 03:47:34 --> Router Class Initialized
INFO - 2023-06-05 03:47:34 --> Loader Class Initialized
INFO - 2023-06-05 03:47:34 --> Controller Class Initialized
INFO - 2023-06-05 03:47:34 --> Output Class Initialized
DEBUG - 2023-06-05 03:47:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:34 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:34 --> Input Class Initialized
INFO - 2023-06-05 03:47:35 --> Language Class Initialized
INFO - 2023-06-05 03:47:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:35 --> Model "Login_model" initialized
INFO - 2023-06-05 03:47:35 --> Loader Class Initialized
INFO - 2023-06-05 03:47:35 --> Controller Class Initialized
INFO - 2023-06-05 03:47:35 --> Database Driver Class Initialized
DEBUG - 2023-06-05 03:47:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:35 --> Total execution time: 0.2313
INFO - 2023-06-05 03:47:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:35 --> Total execution time: 0.4159
INFO - 2023-06-05 03:47:36 --> Config Class Initialized
INFO - 2023-06-05 03:47:36 --> Config Class Initialized
INFO - 2023-06-05 03:47:36 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:36 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:47:36 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:36 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:36 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:36 --> URI Class Initialized
INFO - 2023-06-05 03:47:36 --> URI Class Initialized
INFO - 2023-06-05 03:47:36 --> Router Class Initialized
INFO - 2023-06-05 03:47:36 --> Router Class Initialized
INFO - 2023-06-05 03:47:36 --> Output Class Initialized
INFO - 2023-06-05 03:47:36 --> Output Class Initialized
INFO - 2023-06-05 03:47:36 --> Security Class Initialized
INFO - 2023-06-05 03:47:36 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:36 --> Input Class Initialized
INFO - 2023-06-05 03:47:36 --> Input Class Initialized
INFO - 2023-06-05 03:47:36 --> Language Class Initialized
INFO - 2023-06-05 03:47:36 --> Language Class Initialized
INFO - 2023-06-05 03:47:36 --> Loader Class Initialized
INFO - 2023-06-05 03:47:36 --> Loader Class Initialized
INFO - 2023-06-05 03:47:36 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:36 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:36 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:36 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:36 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:36 --> Total execution time: 0.1761
INFO - 2023-06-05 03:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:36 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:36 --> Config Class Initialized
INFO - 2023-06-05 03:47:36 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:36 --> Model "Login_model" initialized
DEBUG - 2023-06-05 03:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:36 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:36 --> URI Class Initialized
INFO - 2023-06-05 03:47:36 --> Router Class Initialized
INFO - 2023-06-05 03:47:36 --> Output Class Initialized
INFO - 2023-06-05 03:47:36 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:36 --> Total execution time: 0.2903
INFO - 2023-06-05 03:47:36 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:36 --> Input Class Initialized
INFO - 2023-06-05 03:47:36 --> Language Class Initialized
INFO - 2023-06-05 03:47:36 --> Loader Class Initialized
INFO - 2023-06-05 03:47:36 --> Config Class Initialized
INFO - 2023-06-05 03:47:36 --> Hooks Class Initialized
INFO - 2023-06-05 03:47:36 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 03:47:36 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:47:36 --> Utf8 Class Initialized
INFO - 2023-06-05 03:47:36 --> URI Class Initialized
INFO - 2023-06-05 03:47:36 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:36 --> Router Class Initialized
INFO - 2023-06-05 03:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:36 --> Output Class Initialized
INFO - 2023-06-05 03:47:36 --> Final output sent to browser
INFO - 2023-06-05 03:47:36 --> Security Class Initialized
DEBUG - 2023-06-05 03:47:36 --> Total execution time: 0.1982
DEBUG - 2023-06-05 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:47:36 --> Input Class Initialized
INFO - 2023-06-05 03:47:36 --> Language Class Initialized
INFO - 2023-06-05 03:47:36 --> Loader Class Initialized
INFO - 2023-06-05 03:47:36 --> Controller Class Initialized
DEBUG - 2023-06-05 03:47:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:47:36 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:36 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:47:36 --> Database Driver Class Initialized
INFO - 2023-06-05 03:47:36 --> Model "Login_model" initialized
INFO - 2023-06-05 03:47:36 --> Final output sent to browser
DEBUG - 2023-06-05 03:47:36 --> Total execution time: 0.2508
INFO - 2023-06-05 03:59:04 --> Config Class Initialized
INFO - 2023-06-05 03:59:04 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:04 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:04 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:04 --> URI Class Initialized
INFO - 2023-06-05 03:59:04 --> Router Class Initialized
INFO - 2023-06-05 03:59:04 --> Output Class Initialized
INFO - 2023-06-05 03:59:04 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:04 --> Input Class Initialized
INFO - 2023-06-05 03:59:04 --> Language Class Initialized
INFO - 2023-06-05 03:59:04 --> Loader Class Initialized
INFO - 2023-06-05 03:59:04 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:04 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:04 --> Model "Login_model" initialized
INFO - 2023-06-05 03:59:04 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:04 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:04 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:04 --> Total execution time: 0.2518
INFO - 2023-06-05 03:59:04 --> Config Class Initialized
INFO - 2023-06-05 03:59:04 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:04 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:04 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:04 --> URI Class Initialized
INFO - 2023-06-05 03:59:04 --> Router Class Initialized
INFO - 2023-06-05 03:59:04 --> Output Class Initialized
INFO - 2023-06-05 03:59:05 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:05 --> Input Class Initialized
INFO - 2023-06-05 03:59:05 --> Language Class Initialized
INFO - 2023-06-05 03:59:05 --> Loader Class Initialized
INFO - 2023-06-05 03:59:05 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:05 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:05 --> Model "Login_model" initialized
INFO - 2023-06-05 03:59:05 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:05 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:05 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:05 --> Total execution time: 0.2616
INFO - 2023-06-05 03:59:05 --> Config Class Initialized
INFO - 2023-06-05 03:59:05 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:05 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:05 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:05 --> URI Class Initialized
INFO - 2023-06-05 03:59:05 --> Router Class Initialized
INFO - 2023-06-05 03:59:05 --> Output Class Initialized
INFO - 2023-06-05 03:59:05 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:05 --> Input Class Initialized
INFO - 2023-06-05 03:59:05 --> Language Class Initialized
INFO - 2023-06-05 03:59:05 --> Loader Class Initialized
INFO - 2023-06-05 03:59:05 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:05 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:05 --> Total execution time: 0.1536
INFO - 2023-06-05 03:59:05 --> Config Class Initialized
INFO - 2023-06-05 03:59:05 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:05 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:05 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:05 --> URI Class Initialized
INFO - 2023-06-05 03:59:05 --> Router Class Initialized
INFO - 2023-06-05 03:59:05 --> Output Class Initialized
INFO - 2023-06-05 03:59:05 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:05 --> Input Class Initialized
INFO - 2023-06-05 03:59:05 --> Language Class Initialized
INFO - 2023-06-05 03:59:05 --> Loader Class Initialized
INFO - 2023-06-05 03:59:05 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:05 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:05 --> Model "Login_model" initialized
INFO - 2023-06-05 03:59:05 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:05 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:05 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:05 --> Total execution time: 0.2387
INFO - 2023-06-05 03:59:06 --> Config Class Initialized
INFO - 2023-06-05 03:59:06 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:06 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:06 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:06 --> URI Class Initialized
INFO - 2023-06-05 03:59:06 --> Router Class Initialized
INFO - 2023-06-05 03:59:06 --> Output Class Initialized
INFO - 2023-06-05 03:59:06 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:06 --> Input Class Initialized
INFO - 2023-06-05 03:59:06 --> Language Class Initialized
INFO - 2023-06-05 03:59:06 --> Loader Class Initialized
INFO - 2023-06-05 03:59:06 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:06 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:06 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:06 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:06 --> Total execution time: 0.1738
INFO - 2023-06-05 03:59:06 --> Config Class Initialized
INFO - 2023-06-05 03:59:06 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:06 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:06 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:06 --> URI Class Initialized
INFO - 2023-06-05 03:59:06 --> Router Class Initialized
INFO - 2023-06-05 03:59:06 --> Output Class Initialized
INFO - 2023-06-05 03:59:06 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:06 --> Input Class Initialized
INFO - 2023-06-05 03:59:06 --> Language Class Initialized
INFO - 2023-06-05 03:59:06 --> Loader Class Initialized
INFO - 2023-06-05 03:59:06 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:06 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:06 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:06 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:06 --> Total execution time: 0.1822
INFO - 2023-06-05 03:59:33 --> Config Class Initialized
INFO - 2023-06-05 03:59:33 --> Config Class Initialized
INFO - 2023-06-05 03:59:33 --> Hooks Class Initialized
INFO - 2023-06-05 03:59:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:33 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:59:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:33 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:33 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:33 --> URI Class Initialized
INFO - 2023-06-05 03:59:33 --> URI Class Initialized
INFO - 2023-06-05 03:59:33 --> Router Class Initialized
INFO - 2023-06-05 03:59:33 --> Router Class Initialized
INFO - 2023-06-05 03:59:33 --> Output Class Initialized
INFO - 2023-06-05 03:59:33 --> Output Class Initialized
INFO - 2023-06-05 03:59:33 --> Security Class Initialized
INFO - 2023-06-05 03:59:33 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:33 --> Input Class Initialized
INFO - 2023-06-05 03:59:33 --> Input Class Initialized
INFO - 2023-06-05 03:59:33 --> Language Class Initialized
INFO - 2023-06-05 03:59:33 --> Language Class Initialized
INFO - 2023-06-05 03:59:33 --> Loader Class Initialized
INFO - 2023-06-05 03:59:33 --> Loader Class Initialized
INFO - 2023-06-05 03:59:33 --> Controller Class Initialized
INFO - 2023-06-05 03:59:33 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 03:59:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:33 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:33 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:33 --> Final output sent to browser
INFO - 2023-06-05 03:59:33 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:33 --> Total execution time: 0.1849
DEBUG - 2023-06-05 03:59:33 --> Total execution time: 0.1820
INFO - 2023-06-05 03:59:33 --> Config Class Initialized
INFO - 2023-06-05 03:59:33 --> Config Class Initialized
INFO - 2023-06-05 03:59:33 --> Hooks Class Initialized
INFO - 2023-06-05 03:59:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:33 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 03:59:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:33 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:33 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:33 --> URI Class Initialized
INFO - 2023-06-05 03:59:33 --> URI Class Initialized
INFO - 2023-06-05 03:59:33 --> Router Class Initialized
INFO - 2023-06-05 03:59:33 --> Router Class Initialized
INFO - 2023-06-05 03:59:33 --> Output Class Initialized
INFO - 2023-06-05 03:59:33 --> Output Class Initialized
INFO - 2023-06-05 03:59:33 --> Security Class Initialized
INFO - 2023-06-05 03:59:33 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 03:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:33 --> Input Class Initialized
INFO - 2023-06-05 03:59:33 --> Input Class Initialized
INFO - 2023-06-05 03:59:33 --> Language Class Initialized
INFO - 2023-06-05 03:59:33 --> Language Class Initialized
INFO - 2023-06-05 03:59:33 --> Loader Class Initialized
INFO - 2023-06-05 03:59:33 --> Loader Class Initialized
INFO - 2023-06-05 03:59:33 --> Controller Class Initialized
INFO - 2023-06-05 03:59:33 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 03:59:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:33 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:33 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:33 --> Final output sent to browser
INFO - 2023-06-05 03:59:33 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:33 --> Total execution time: 0.1655
DEBUG - 2023-06-05 03:59:33 --> Total execution time: 0.1686
INFO - 2023-06-05 03:59:33 --> Config Class Initialized
INFO - 2023-06-05 03:59:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:33 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:33 --> URI Class Initialized
INFO - 2023-06-05 03:59:33 --> Router Class Initialized
INFO - 2023-06-05 03:59:33 --> Output Class Initialized
INFO - 2023-06-05 03:59:33 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:33 --> Input Class Initialized
INFO - 2023-06-05 03:59:33 --> Language Class Initialized
INFO - 2023-06-05 03:59:33 --> Loader Class Initialized
INFO - 2023-06-05 03:59:33 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:34 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:34 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:34 --> Total execution time: 0.3848
INFO - 2023-06-05 03:59:34 --> Config Class Initialized
INFO - 2023-06-05 03:59:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:34 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:34 --> URI Class Initialized
INFO - 2023-06-05 03:59:34 --> Router Class Initialized
INFO - 2023-06-05 03:59:34 --> Output Class Initialized
INFO - 2023-06-05 03:59:34 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:34 --> Input Class Initialized
INFO - 2023-06-05 03:59:34 --> Language Class Initialized
INFO - 2023-06-05 03:59:34 --> Loader Class Initialized
INFO - 2023-06-05 03:59:34 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:34 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:34 --> Config Class Initialized
INFO - 2023-06-05 03:59:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:34 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:34 --> URI Class Initialized
INFO - 2023-06-05 03:59:34 --> Router Class Initialized
INFO - 2023-06-05 03:59:34 --> Output Class Initialized
INFO - 2023-06-05 03:59:34 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:34 --> Total execution time: 0.3886
INFO - 2023-06-05 03:59:34 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:34 --> Input Class Initialized
INFO - 2023-06-05 03:59:34 --> Language Class Initialized
INFO - 2023-06-05 03:59:34 --> Loader Class Initialized
INFO - 2023-06-05 03:59:34 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:34 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:34 --> Model "Login_model" initialized
INFO - 2023-06-05 03:59:34 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:34 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:34 --> Total execution time: 0.1894
INFO - 2023-06-05 03:59:34 --> Config Class Initialized
INFO - 2023-06-05 03:59:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:34 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:34 --> URI Class Initialized
INFO - 2023-06-05 03:59:34 --> Router Class Initialized
INFO - 2023-06-05 03:59:34 --> Output Class Initialized
INFO - 2023-06-05 03:59:34 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:34 --> Input Class Initialized
INFO - 2023-06-05 03:59:34 --> Language Class Initialized
INFO - 2023-06-05 03:59:34 --> Loader Class Initialized
INFO - 2023-06-05 03:59:34 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:34 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:34 --> Model "Login_model" initialized
INFO - 2023-06-05 03:59:34 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:35 --> Total execution time: 0.2163
INFO - 2023-06-05 03:59:35 --> Config Class Initialized
INFO - 2023-06-05 03:59:35 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:35 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:35 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:35 --> URI Class Initialized
INFO - 2023-06-05 03:59:35 --> Router Class Initialized
INFO - 2023-06-05 03:59:35 --> Output Class Initialized
INFO - 2023-06-05 03:59:35 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:35 --> Input Class Initialized
INFO - 2023-06-05 03:59:35 --> Language Class Initialized
INFO - 2023-06-05 03:59:35 --> Loader Class Initialized
INFO - 2023-06-05 03:59:35 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:35 --> Total execution time: 0.1362
INFO - 2023-06-05 03:59:35 --> Config Class Initialized
INFO - 2023-06-05 03:59:35 --> Hooks Class Initialized
DEBUG - 2023-06-05 03:59:35 --> UTF-8 Support Enabled
INFO - 2023-06-05 03:59:35 --> Utf8 Class Initialized
INFO - 2023-06-05 03:59:35 --> URI Class Initialized
INFO - 2023-06-05 03:59:35 --> Router Class Initialized
INFO - 2023-06-05 03:59:35 --> Output Class Initialized
INFO - 2023-06-05 03:59:35 --> Security Class Initialized
DEBUG - 2023-06-05 03:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 03:59:35 --> Input Class Initialized
INFO - 2023-06-05 03:59:35 --> Language Class Initialized
INFO - 2023-06-05 03:59:35 --> Loader Class Initialized
INFO - 2023-06-05 03:59:35 --> Controller Class Initialized
DEBUG - 2023-06-05 03:59:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 03:59:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:35 --> Model "Login_model" initialized
INFO - 2023-06-05 03:59:35 --> Database Driver Class Initialized
INFO - 2023-06-05 03:59:35 --> Model "Cluster_model" initialized
INFO - 2023-06-05 03:59:35 --> Final output sent to browser
DEBUG - 2023-06-05 03:59:35 --> Total execution time: 0.1991
INFO - 2023-06-05 05:32:21 --> Config Class Initialized
INFO - 2023-06-05 05:32:21 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:21 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:21 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:21 --> URI Class Initialized
INFO - 2023-06-05 05:32:21 --> Router Class Initialized
INFO - 2023-06-05 05:32:21 --> Output Class Initialized
INFO - 2023-06-05 05:32:21 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:21 --> Input Class Initialized
INFO - 2023-06-05 05:32:21 --> Language Class Initialized
INFO - 2023-06-05 05:32:21 --> Loader Class Initialized
INFO - 2023-06-05 05:32:21 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:21 --> Config Class Initialized
INFO - 2023-06-05 05:32:21 --> Config Class Initialized
INFO - 2023-06-05 05:32:21 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:21 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:21 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 05:32:21 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:21 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:21 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:21 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:21 --> URI Class Initialized
INFO - 2023-06-05 05:32:21 --> URI Class Initialized
INFO - 2023-06-05 05:32:21 --> Router Class Initialized
INFO - 2023-06-05 05:32:21 --> Router Class Initialized
INFO - 2023-06-05 05:32:21 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:21 --> Output Class Initialized
INFO - 2023-06-05 05:32:21 --> Output Class Initialized
INFO - 2023-06-05 05:32:21 --> Security Class Initialized
INFO - 2023-06-05 05:32:21 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:21 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:21 --> Input Class Initialized
DEBUG - 2023-06-05 05:32:21 --> Total execution time: 0.2693
INFO - 2023-06-05 05:32:21 --> Input Class Initialized
INFO - 2023-06-05 05:32:21 --> Language Class Initialized
INFO - 2023-06-05 05:32:21 --> Language Class Initialized
INFO - 2023-06-05 05:32:22 --> Loader Class Initialized
INFO - 2023-06-05 05:32:22 --> Loader Class Initialized
INFO - 2023-06-05 05:32:22 --> Controller Class Initialized
INFO - 2023-06-05 05:32:22 --> Controller Class Initialized
INFO - 2023-06-05 05:32:22 --> Config Class Initialized
DEBUG - 2023-06-05 05:32:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 05:32:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:22 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:22 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:22 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:22 --> URI Class Initialized
INFO - 2023-06-05 05:32:22 --> Router Class Initialized
INFO - 2023-06-05 05:32:22 --> Output Class Initialized
INFO - 2023-06-05 05:32:22 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:22 --> Input Class Initialized
INFO - 2023-06-05 05:32:22 --> Language Class Initialized
INFO - 2023-06-05 05:32:22 --> Loader Class Initialized
INFO - 2023-06-05 05:32:22 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:22 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:22 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:22 --> Total execution time: 0.2025
INFO - 2023-06-05 05:32:22 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:22 --> Total execution time: 0.3262
INFO - 2023-06-05 05:32:22 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:22 --> Total execution time: 0.3369
INFO - 2023-06-05 05:32:22 --> Config Class Initialized
INFO - 2023-06-05 05:32:22 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:22 --> Config Class Initialized
INFO - 2023-06-05 05:32:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:22 --> Utf8 Class Initialized
DEBUG - 2023-06-05 05:32:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:22 --> URI Class Initialized
INFO - 2023-06-05 05:32:22 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:22 --> URI Class Initialized
INFO - 2023-06-05 05:32:22 --> Router Class Initialized
INFO - 2023-06-05 05:32:22 --> Router Class Initialized
INFO - 2023-06-05 05:32:22 --> Output Class Initialized
INFO - 2023-06-05 05:32:22 --> Output Class Initialized
INFO - 2023-06-05 05:32:22 --> Security Class Initialized
INFO - 2023-06-05 05:32:22 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:22 --> Input Class Initialized
DEBUG - 2023-06-05 05:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:22 --> Language Class Initialized
INFO - 2023-06-05 05:32:22 --> Input Class Initialized
INFO - 2023-06-05 05:32:22 --> Language Class Initialized
INFO - 2023-06-05 05:32:22 --> Loader Class Initialized
INFO - 2023-06-05 05:32:22 --> Loader Class Initialized
INFO - 2023-06-05 05:32:22 --> Controller Class Initialized
INFO - 2023-06-05 05:32:22 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 05:32:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:22 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:22 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:22 --> Final output sent to browser
INFO - 2023-06-05 05:32:22 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:22 --> Total execution time: 0.1946
DEBUG - 2023-06-05 05:32:22 --> Total execution time: 0.1880
INFO - 2023-06-05 05:32:24 --> Config Class Initialized
INFO - 2023-06-05 05:32:24 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:24 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:24 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:24 --> URI Class Initialized
INFO - 2023-06-05 05:32:24 --> Router Class Initialized
INFO - 2023-06-05 05:32:24 --> Output Class Initialized
INFO - 2023-06-05 05:32:24 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:24 --> Input Class Initialized
INFO - 2023-06-05 05:32:24 --> Language Class Initialized
INFO - 2023-06-05 05:32:24 --> Loader Class Initialized
INFO - 2023-06-05 05:32:24 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:24 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:24 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:24 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:25 --> Total execution time: 0.2219
INFO - 2023-06-05 05:32:25 --> Config Class Initialized
INFO - 2023-06-05 05:32:25 --> Config Class Initialized
INFO - 2023-06-05 05:32:25 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:25 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:25 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 05:32:25 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:25 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:25 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:25 --> URI Class Initialized
INFO - 2023-06-05 05:32:25 --> URI Class Initialized
INFO - 2023-06-05 05:32:25 --> Router Class Initialized
INFO - 2023-06-05 05:32:25 --> Router Class Initialized
INFO - 2023-06-05 05:32:25 --> Output Class Initialized
INFO - 2023-06-05 05:32:25 --> Output Class Initialized
INFO - 2023-06-05 05:32:25 --> Security Class Initialized
INFO - 2023-06-05 05:32:25 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 05:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:25 --> Input Class Initialized
INFO - 2023-06-05 05:32:25 --> Input Class Initialized
INFO - 2023-06-05 05:32:25 --> Language Class Initialized
INFO - 2023-06-05 05:32:25 --> Language Class Initialized
INFO - 2023-06-05 05:32:25 --> Loader Class Initialized
INFO - 2023-06-05 05:32:25 --> Loader Class Initialized
INFO - 2023-06-05 05:32:25 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:25 --> Controller Class Initialized
INFO - 2023-06-05 05:32:25 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 05:32:25 --> Total execution time: 0.1084
INFO - 2023-06-05 05:32:25 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:25 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:25 --> Config Class Initialized
INFO - 2023-06-05 05:32:25 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:25 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:25 --> Total execution time: 0.1613
DEBUG - 2023-06-05 05:32:25 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:25 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:25 --> URI Class Initialized
INFO - 2023-06-05 05:32:25 --> Router Class Initialized
INFO - 2023-06-05 05:32:25 --> Config Class Initialized
INFO - 2023-06-05 05:32:25 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:25 --> Output Class Initialized
INFO - 2023-06-05 05:32:25 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:25 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 05:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:25 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:25 --> Input Class Initialized
INFO - 2023-06-05 05:32:25 --> URI Class Initialized
INFO - 2023-06-05 05:32:25 --> Language Class Initialized
INFO - 2023-06-05 05:32:25 --> Router Class Initialized
INFO - 2023-06-05 05:32:25 --> Loader Class Initialized
INFO - 2023-06-05 05:32:25 --> Output Class Initialized
INFO - 2023-06-05 05:32:25 --> Security Class Initialized
INFO - 2023-06-05 05:32:25 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 05:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:25 --> Input Class Initialized
INFO - 2023-06-05 05:32:25 --> Language Class Initialized
INFO - 2023-06-05 05:32:25 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:25 --> Loader Class Initialized
INFO - 2023-06-05 05:32:25 --> Model "Login_model" initialized
INFO - 2023-06-05 05:32:25 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:25 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:25 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:25 --> Final output sent to browser
INFO - 2023-06-05 05:32:25 --> Database Driver Class Initialized
DEBUG - 2023-06-05 05:32:25 --> Total execution time: 0.2228
INFO - 2023-06-05 05:32:25 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:25 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:25 --> Total execution time: 0.1861
INFO - 2023-06-05 05:32:32 --> Config Class Initialized
INFO - 2023-06-05 05:32:32 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:32 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:32 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:32 --> URI Class Initialized
INFO - 2023-06-05 05:32:32 --> Router Class Initialized
INFO - 2023-06-05 05:32:32 --> Output Class Initialized
INFO - 2023-06-05 05:32:32 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:32 --> Input Class Initialized
INFO - 2023-06-05 05:32:32 --> Language Class Initialized
INFO - 2023-06-05 05:32:32 --> Loader Class Initialized
INFO - 2023-06-05 05:32:32 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:32 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:32 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:32 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:32 --> Total execution time: 0.1870
INFO - 2023-06-05 05:32:32 --> Config Class Initialized
INFO - 2023-06-05 05:32:32 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:32 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:32 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:32 --> URI Class Initialized
INFO - 2023-06-05 05:32:32 --> Router Class Initialized
INFO - 2023-06-05 05:32:32 --> Output Class Initialized
INFO - 2023-06-05 05:32:32 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:32 --> Input Class Initialized
INFO - 2023-06-05 05:32:32 --> Language Class Initialized
INFO - 2023-06-05 05:32:32 --> Loader Class Initialized
INFO - 2023-06-05 05:32:32 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:32 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:32 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:32 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:32 --> Total execution time: 0.4076
INFO - 2023-06-05 05:32:48 --> Config Class Initialized
INFO - 2023-06-05 05:32:48 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:48 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:48 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:48 --> URI Class Initialized
INFO - 2023-06-05 05:32:48 --> Router Class Initialized
INFO - 2023-06-05 05:32:48 --> Output Class Initialized
INFO - 2023-06-05 05:32:48 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:48 --> Input Class Initialized
INFO - 2023-06-05 05:32:48 --> Language Class Initialized
INFO - 2023-06-05 05:32:48 --> Loader Class Initialized
INFO - 2023-06-05 05:32:48 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:48 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:48 --> Model "Login_model" initialized
INFO - 2023-06-05 05:32:48 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:48 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:48 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:48 --> Total execution time: 0.2623
INFO - 2023-06-05 05:32:48 --> Config Class Initialized
INFO - 2023-06-05 05:32:48 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:48 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:48 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:48 --> URI Class Initialized
INFO - 2023-06-05 05:32:48 --> Router Class Initialized
INFO - 2023-06-05 05:32:48 --> Output Class Initialized
INFO - 2023-06-05 05:32:48 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:48 --> Input Class Initialized
INFO - 2023-06-05 05:32:48 --> Language Class Initialized
INFO - 2023-06-05 05:32:48 --> Loader Class Initialized
INFO - 2023-06-05 05:32:48 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:48 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:48 --> Model "Login_model" initialized
INFO - 2023-06-05 05:32:48 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:48 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:48 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:48 --> Total execution time: 0.1904
INFO - 2023-06-05 05:32:48 --> Config Class Initialized
INFO - 2023-06-05 05:32:48 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:48 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:48 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:48 --> URI Class Initialized
INFO - 2023-06-05 05:32:48 --> Router Class Initialized
INFO - 2023-06-05 05:32:48 --> Output Class Initialized
INFO - 2023-06-05 05:32:48 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:48 --> Input Class Initialized
INFO - 2023-06-05 05:32:48 --> Language Class Initialized
INFO - 2023-06-05 05:32:48 --> Loader Class Initialized
INFO - 2023-06-05 05:32:48 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:48 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:48 --> Total execution time: 0.1323
INFO - 2023-06-05 05:32:48 --> Config Class Initialized
INFO - 2023-06-05 05:32:48 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:48 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:48 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:48 --> URI Class Initialized
INFO - 2023-06-05 05:32:48 --> Router Class Initialized
INFO - 2023-06-05 05:32:48 --> Config Class Initialized
INFO - 2023-06-05 05:32:48 --> Config Class Initialized
INFO - 2023-06-05 05:32:48 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:48 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:48 --> Output Class Initialized
DEBUG - 2023-06-05 05:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 05:32:48 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:48 --> Security Class Initialized
INFO - 2023-06-05 05:32:48 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:48 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:48 --> URI Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:48 --> URI Class Initialized
INFO - 2023-06-05 05:32:48 --> Input Class Initialized
INFO - 2023-06-05 05:32:48 --> Language Class Initialized
INFO - 2023-06-05 05:32:48 --> Router Class Initialized
INFO - 2023-06-05 05:32:48 --> Router Class Initialized
INFO - 2023-06-05 05:32:48 --> Output Class Initialized
INFO - 2023-06-05 05:32:48 --> Output Class Initialized
INFO - 2023-06-05 05:32:48 --> Loader Class Initialized
INFO - 2023-06-05 05:32:48 --> Security Class Initialized
INFO - 2023-06-05 05:32:48 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:48 --> Input Class Initialized
INFO - 2023-06-05 05:32:48 --> Input Class Initialized
INFO - 2023-06-05 05:32:48 --> Controller Class Initialized
INFO - 2023-06-05 05:32:48 --> Language Class Initialized
INFO - 2023-06-05 05:32:48 --> Language Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:48 --> Loader Class Initialized
INFO - 2023-06-05 05:32:48 --> Controller Class Initialized
INFO - 2023-06-05 05:32:48 --> Loader Class Initialized
INFO - 2023-06-05 05:32:48 --> Database Driver Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:48 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:48 --> Model "Login_model" initialized
INFO - 2023-06-05 05:32:48 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:48 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:49 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:49 --> Final output sent to browser
INFO - 2023-06-05 05:32:49 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:49 --> Total execution time: 0.1833
DEBUG - 2023-06-05 05:32:49 --> Total execution time: 0.1819
INFO - 2023-06-05 05:32:49 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:49 --> Total execution time: 0.2651
INFO - 2023-06-05 05:32:49 --> Config Class Initialized
INFO - 2023-06-05 05:32:49 --> Config Class Initialized
INFO - 2023-06-05 05:32:49 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:49 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 05:32:49 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:49 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:49 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:49 --> URI Class Initialized
INFO - 2023-06-05 05:32:49 --> Config Class Initialized
INFO - 2023-06-05 05:32:49 --> URI Class Initialized
INFO - 2023-06-05 05:32:49 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:49 --> Router Class Initialized
INFO - 2023-06-05 05:32:49 --> Router Class Initialized
INFO - 2023-06-05 05:32:49 --> Output Class Initialized
INFO - 2023-06-05 05:32:49 --> Output Class Initialized
DEBUG - 2023-06-05 05:32:49 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:49 --> Security Class Initialized
INFO - 2023-06-05 05:32:49 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:49 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:49 --> URI Class Initialized
INFO - 2023-06-05 05:32:49 --> Input Class Initialized
INFO - 2023-06-05 05:32:49 --> Input Class Initialized
INFO - 2023-06-05 05:32:49 --> Language Class Initialized
INFO - 2023-06-05 05:32:49 --> Language Class Initialized
INFO - 2023-06-05 05:32:49 --> Router Class Initialized
INFO - 2023-06-05 05:32:49 --> Loader Class Initialized
INFO - 2023-06-05 05:32:49 --> Loader Class Initialized
INFO - 2023-06-05 05:32:49 --> Output Class Initialized
INFO - 2023-06-05 05:32:49 --> Controller Class Initialized
INFO - 2023-06-05 05:32:49 --> Controller Class Initialized
INFO - 2023-06-05 05:32:49 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 05:32:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:49 --> Input Class Initialized
INFO - 2023-06-05 05:32:49 --> Language Class Initialized
INFO - 2023-06-05 05:32:49 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:49 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:49 --> Final output sent to browser
INFO - 2023-06-05 05:32:49 --> Loader Class Initialized
INFO - 2023-06-05 05:32:49 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:49 --> Total execution time: 0.1739
DEBUG - 2023-06-05 05:32:49 --> Total execution time: 0.1730
INFO - 2023-06-05 05:32:49 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:49 --> Config Class Initialized
INFO - 2023-06-05 05:32:49 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:49 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:49 --> Config Class Initialized
INFO - 2023-06-05 05:32:49 --> Hooks Class Initialized
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 05:32:49 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:49 --> Utf8 Class Initialized
DEBUG - 2023-06-05 05:32:49 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:49 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:49 --> URI Class Initialized
INFO - 2023-06-05 05:32:49 --> URI Class Initialized
INFO - 2023-06-05 05:32:49 --> Router Class Initialized
INFO - 2023-06-05 05:32:49 --> Router Class Initialized
INFO - 2023-06-05 05:32:49 --> Output Class Initialized
INFO - 2023-06-05 05:32:49 --> Security Class Initialized
INFO - 2023-06-05 05:32:49 --> Output Class Initialized
INFO - 2023-06-05 05:32:49 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:49 --> Input Class Initialized
INFO - 2023-06-05 05:32:49 --> Final output sent to browser
DEBUG - 2023-06-05 05:32:49 --> Total execution time: 0.2923
DEBUG - 2023-06-05 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:49 --> Language Class Initialized
INFO - 2023-06-05 05:32:49 --> Input Class Initialized
INFO - 2023-06-05 05:32:49 --> Language Class Initialized
INFO - 2023-06-05 05:32:49 --> Loader Class Initialized
INFO - 2023-06-05 05:32:49 --> Loader Class Initialized
INFO - 2023-06-05 05:32:49 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:49 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:49 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:49 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:32:49 --> Final output sent to browser
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 05:32:49 --> Total execution time: 0.2055
INFO - 2023-06-05 05:32:49 --> Config Class Initialized
INFO - 2023-06-05 05:32:49 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:32:49 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:32:49 --> Utf8 Class Initialized
INFO - 2023-06-05 05:32:49 --> URI Class Initialized
INFO - 2023-06-05 05:32:49 --> Router Class Initialized
INFO - 2023-06-05 05:32:49 --> Output Class Initialized
INFO - 2023-06-05 05:32:49 --> Security Class Initialized
DEBUG - 2023-06-05 05:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:32:49 --> Input Class Initialized
INFO - 2023-06-05 05:32:49 --> Language Class Initialized
INFO - 2023-06-05 05:32:49 --> Loader Class Initialized
INFO - 2023-06-05 05:32:49 --> Controller Class Initialized
DEBUG - 2023-06-05 05:32:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:32:49 --> Database Driver Class Initialized
INFO - 2023-06-05 05:32:49 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:39 --> Config Class Initialized
INFO - 2023-06-05 05:50:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:50:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:50:39 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:39 --> URI Class Initialized
INFO - 2023-06-05 05:50:39 --> Router Class Initialized
INFO - 2023-06-05 05:50:39 --> Output Class Initialized
INFO - 2023-06-05 05:50:39 --> Security Class Initialized
DEBUG - 2023-06-05 05:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:50:39 --> Input Class Initialized
INFO - 2023-06-05 05:50:39 --> Language Class Initialized
INFO - 2023-06-05 05:50:39 --> Loader Class Initialized
INFO - 2023-06-05 05:50:39 --> Controller Class Initialized
DEBUG - 2023-06-05 05:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:50:39 --> Database Driver Class Initialized
INFO - 2023-06-05 05:50:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:39 --> Final output sent to browser
DEBUG - 2023-06-05 05:50:39 --> Total execution time: 0.2169
INFO - 2023-06-05 05:50:39 --> Config Class Initialized
INFO - 2023-06-05 05:50:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:50:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:50:39 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:39 --> URI Class Initialized
INFO - 2023-06-05 05:50:39 --> Router Class Initialized
INFO - 2023-06-05 05:50:39 --> Output Class Initialized
INFO - 2023-06-05 05:50:39 --> Security Class Initialized
DEBUG - 2023-06-05 05:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:50:39 --> Input Class Initialized
INFO - 2023-06-05 05:50:39 --> Language Class Initialized
INFO - 2023-06-05 05:50:39 --> Loader Class Initialized
INFO - 2023-06-05 05:50:39 --> Controller Class Initialized
DEBUG - 2023-06-05 05:50:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:50:39 --> Database Driver Class Initialized
INFO - 2023-06-05 05:50:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:39 --> Final output sent to browser
DEBUG - 2023-06-05 05:50:39 --> Total execution time: 0.2276
INFO - 2023-06-05 05:50:44 --> Config Class Initialized
INFO - 2023-06-05 05:50:44 --> Config Class Initialized
INFO - 2023-06-05 05:50:44 --> Config Class Initialized
INFO - 2023-06-05 05:50:44 --> Hooks Class Initialized
INFO - 2023-06-05 05:50:44 --> Hooks Class Initialized
INFO - 2023-06-05 05:50:44 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 05:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 05:50:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:50:44 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:44 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:44 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:44 --> URI Class Initialized
INFO - 2023-06-05 05:50:44 --> URI Class Initialized
INFO - 2023-06-05 05:50:44 --> URI Class Initialized
INFO - 2023-06-05 05:50:44 --> Router Class Initialized
INFO - 2023-06-05 05:50:44 --> Router Class Initialized
INFO - 2023-06-05 05:50:44 --> Router Class Initialized
INFO - 2023-06-05 05:50:44 --> Output Class Initialized
INFO - 2023-06-05 05:50:44 --> Output Class Initialized
INFO - 2023-06-05 05:50:44 --> Output Class Initialized
INFO - 2023-06-05 05:50:44 --> Security Class Initialized
INFO - 2023-06-05 05:50:44 --> Security Class Initialized
INFO - 2023-06-05 05:50:44 --> Security Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 05:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 05:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:50:44 --> Input Class Initialized
INFO - 2023-06-05 05:50:44 --> Input Class Initialized
INFO - 2023-06-05 05:50:44 --> Input Class Initialized
INFO - 2023-06-05 05:50:44 --> Language Class Initialized
INFO - 2023-06-05 05:50:44 --> Language Class Initialized
INFO - 2023-06-05 05:50:44 --> Language Class Initialized
INFO - 2023-06-05 05:50:44 --> Loader Class Initialized
INFO - 2023-06-05 05:50:44 --> Loader Class Initialized
INFO - 2023-06-05 05:50:44 --> Controller Class Initialized
INFO - 2023-06-05 05:50:44 --> Controller Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 05:50:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:50:44 --> Loader Class Initialized
INFO - 2023-06-05 05:50:44 --> Controller Class Initialized
INFO - 2023-06-05 05:50:44 --> Database Driver Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:50:44 --> Database Driver Class Initialized
INFO - 2023-06-05 05:50:44 --> Database Driver Class Initialized
INFO - 2023-06-05 05:50:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:44 --> Final output sent to browser
INFO - 2023-06-05 05:50:44 --> Final output sent to browser
DEBUG - 2023-06-05 05:50:44 --> Total execution time: 0.1932
DEBUG - 2023-06-05 05:50:44 --> Total execution time: 0.1929
INFO - 2023-06-05 05:50:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:44 --> Final output sent to browser
DEBUG - 2023-06-05 05:50:44 --> Total execution time: 0.2222
INFO - 2023-06-05 05:50:44 --> Config Class Initialized
INFO - 2023-06-05 05:50:44 --> Config Class Initialized
INFO - 2023-06-05 05:50:44 --> Hooks Class Initialized
INFO - 2023-06-05 05:50:44 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 05:50:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:50:44 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:44 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:44 --> URI Class Initialized
INFO - 2023-06-05 05:50:44 --> URI Class Initialized
INFO - 2023-06-05 05:50:44 --> Router Class Initialized
INFO - 2023-06-05 05:50:44 --> Router Class Initialized
INFO - 2023-06-05 05:50:44 --> Output Class Initialized
INFO - 2023-06-05 05:50:44 --> Output Class Initialized
INFO - 2023-06-05 05:50:44 --> Security Class Initialized
INFO - 2023-06-05 05:50:44 --> Security Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 05:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:50:44 --> Input Class Initialized
INFO - 2023-06-05 05:50:44 --> Input Class Initialized
INFO - 2023-06-05 05:50:44 --> Language Class Initialized
INFO - 2023-06-05 05:50:44 --> Language Class Initialized
INFO - 2023-06-05 05:50:44 --> Loader Class Initialized
INFO - 2023-06-05 05:50:44 --> Loader Class Initialized
INFO - 2023-06-05 05:50:44 --> Controller Class Initialized
INFO - 2023-06-05 05:50:44 --> Controller Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 05:50:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:50:44 --> Database Driver Class Initialized
INFO - 2023-06-05 05:50:44 --> Database Driver Class Initialized
INFO - 2023-06-05 05:50:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:44 --> Final output sent to browser
INFO - 2023-06-05 05:50:44 --> Final output sent to browser
DEBUG - 2023-06-05 05:50:44 --> Total execution time: 0.1528
DEBUG - 2023-06-05 05:50:44 --> Total execution time: 0.1524
INFO - 2023-06-05 05:50:44 --> Config Class Initialized
INFO - 2023-06-05 05:50:44 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:50:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:50:44 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:44 --> URI Class Initialized
INFO - 2023-06-05 05:50:44 --> Router Class Initialized
INFO - 2023-06-05 05:50:44 --> Output Class Initialized
INFO - 2023-06-05 05:50:44 --> Security Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:50:44 --> Input Class Initialized
INFO - 2023-06-05 05:50:44 --> Language Class Initialized
INFO - 2023-06-05 05:50:44 --> Loader Class Initialized
INFO - 2023-06-05 05:50:44 --> Controller Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:50:44 --> Database Driver Class Initialized
INFO - 2023-06-05 05:50:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:50:44 --> Config Class Initialized
INFO - 2023-06-05 05:50:44 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:50:44 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:50:44 --> Utf8 Class Initialized
INFO - 2023-06-05 05:50:44 --> URI Class Initialized
INFO - 2023-06-05 05:50:44 --> Router Class Initialized
INFO - 2023-06-05 05:50:44 --> Output Class Initialized
INFO - 2023-06-05 05:50:44 --> Security Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:50:44 --> Input Class Initialized
INFO - 2023-06-05 05:50:44 --> Language Class Initialized
INFO - 2023-06-05 05:50:44 --> Loader Class Initialized
INFO - 2023-06-05 05:50:44 --> Controller Class Initialized
DEBUG - 2023-06-05 05:50:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:50:44 --> Database Driver Class Initialized
INFO - 2023-06-05 05:50:44 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:52:53 --> Config Class Initialized
INFO - 2023-06-05 05:52:53 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:52:53 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:52:53 --> Utf8 Class Initialized
INFO - 2023-06-05 05:52:53 --> URI Class Initialized
INFO - 2023-06-05 05:52:53 --> Router Class Initialized
INFO - 2023-06-05 05:52:53 --> Output Class Initialized
INFO - 2023-06-05 05:52:53 --> Security Class Initialized
DEBUG - 2023-06-05 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:52:53 --> Input Class Initialized
INFO - 2023-06-05 05:52:53 --> Language Class Initialized
INFO - 2023-06-05 05:52:53 --> Loader Class Initialized
INFO - 2023-06-05 05:52:53 --> Controller Class Initialized
DEBUG - 2023-06-05 05:52:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:52:53 --> Database Driver Class Initialized
INFO - 2023-06-05 05:52:53 --> Model "Cluster_model" initialized
INFO - 2023-06-05 05:52:53 --> Config Class Initialized
INFO - 2023-06-05 05:52:53 --> Hooks Class Initialized
DEBUG - 2023-06-05 05:52:53 --> UTF-8 Support Enabled
INFO - 2023-06-05 05:52:53 --> Utf8 Class Initialized
INFO - 2023-06-05 05:52:53 --> URI Class Initialized
INFO - 2023-06-05 05:52:53 --> Router Class Initialized
INFO - 2023-06-05 05:52:53 --> Output Class Initialized
INFO - 2023-06-05 05:52:53 --> Security Class Initialized
DEBUG - 2023-06-05 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 05:52:53 --> Input Class Initialized
INFO - 2023-06-05 05:52:53 --> Language Class Initialized
INFO - 2023-06-05 05:52:53 --> Loader Class Initialized
INFO - 2023-06-05 05:52:53 --> Controller Class Initialized
DEBUG - 2023-06-05 05:52:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 05:52:53 --> Database Driver Class Initialized
INFO - 2023-06-05 05:52:53 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:06:50 --> Config Class Initialized
INFO - 2023-06-05 06:06:50 --> Config Class Initialized
INFO - 2023-06-05 06:06:50 --> Config Class Initialized
INFO - 2023-06-05 06:06:50 --> Hooks Class Initialized
INFO - 2023-06-05 06:06:50 --> Hooks Class Initialized
INFO - 2023-06-05 06:06:50 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:06:50 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:06:50 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:06:50 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:06:50 --> Utf8 Class Initialized
INFO - 2023-06-05 06:06:50 --> Utf8 Class Initialized
INFO - 2023-06-05 06:06:50 --> Utf8 Class Initialized
INFO - 2023-06-05 06:06:50 --> URI Class Initialized
INFO - 2023-06-05 06:06:50 --> URI Class Initialized
INFO - 2023-06-05 06:06:50 --> URI Class Initialized
INFO - 2023-06-05 06:06:50 --> Router Class Initialized
INFO - 2023-06-05 06:06:50 --> Router Class Initialized
INFO - 2023-06-05 06:06:50 --> Router Class Initialized
INFO - 2023-06-05 06:06:50 --> Output Class Initialized
INFO - 2023-06-05 06:06:50 --> Output Class Initialized
INFO - 2023-06-05 06:06:50 --> Output Class Initialized
INFO - 2023-06-05 06:06:50 --> Security Class Initialized
INFO - 2023-06-05 06:06:50 --> Security Class Initialized
INFO - 2023-06-05 06:06:50 --> Security Class Initialized
DEBUG - 2023-06-05 06:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:06:50 --> Input Class Initialized
INFO - 2023-06-05 06:06:50 --> Input Class Initialized
INFO - 2023-06-05 06:06:50 --> Input Class Initialized
INFO - 2023-06-05 06:06:50 --> Language Class Initialized
INFO - 2023-06-05 06:06:50 --> Language Class Initialized
INFO - 2023-06-05 06:06:50 --> Language Class Initialized
INFO - 2023-06-05 06:06:50 --> Loader Class Initialized
INFO - 2023-06-05 06:06:50 --> Loader Class Initialized
INFO - 2023-06-05 06:06:50 --> Controller Class Initialized
INFO - 2023-06-05 06:06:50 --> Controller Class Initialized
DEBUG - 2023-06-05 06:06:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:06:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:06:50 --> Loader Class Initialized
INFO - 2023-06-05 06:06:50 --> Controller Class Initialized
INFO - 2023-06-05 06:06:50 --> Database Driver Class Initialized
INFO - 2023-06-05 06:06:50 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:06:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:06:50 --> Database Driver Class Initialized
INFO - 2023-06-05 06:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:06:50 --> Final output sent to browser
DEBUG - 2023-06-05 06:06:50 --> Total execution time: 0.2974
INFO - 2023-06-05 06:06:50 --> Final output sent to browser
INFO - 2023-06-05 06:06:50 --> Final output sent to browser
DEBUG - 2023-06-05 06:06:50 --> Total execution time: 0.3078
DEBUG - 2023-06-05 06:06:50 --> Total execution time: 0.3092
INFO - 2023-06-05 06:06:50 --> Config Class Initialized
INFO - 2023-06-05 06:06:50 --> Config Class Initialized
INFO - 2023-06-05 06:06:50 --> Config Class Initialized
INFO - 2023-06-05 06:06:50 --> Hooks Class Initialized
INFO - 2023-06-05 06:06:50 --> Hooks Class Initialized
INFO - 2023-06-05 06:06:50 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:06:50 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:06:50 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:06:50 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:06:50 --> Utf8 Class Initialized
INFO - 2023-06-05 06:06:50 --> Utf8 Class Initialized
INFO - 2023-06-05 06:06:50 --> Utf8 Class Initialized
INFO - 2023-06-05 06:06:50 --> URI Class Initialized
INFO - 2023-06-05 06:06:50 --> URI Class Initialized
INFO - 2023-06-05 06:06:50 --> URI Class Initialized
INFO - 2023-06-05 06:06:50 --> Router Class Initialized
INFO - 2023-06-05 06:06:50 --> Router Class Initialized
INFO - 2023-06-05 06:06:50 --> Router Class Initialized
INFO - 2023-06-05 06:06:50 --> Output Class Initialized
INFO - 2023-06-05 06:06:50 --> Output Class Initialized
INFO - 2023-06-05 06:06:50 --> Output Class Initialized
INFO - 2023-06-05 06:06:50 --> Security Class Initialized
INFO - 2023-06-05 06:06:50 --> Security Class Initialized
INFO - 2023-06-05 06:06:50 --> Security Class Initialized
DEBUG - 2023-06-05 06:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:06:50 --> Input Class Initialized
INFO - 2023-06-05 06:06:50 --> Input Class Initialized
INFO - 2023-06-05 06:06:50 --> Input Class Initialized
INFO - 2023-06-05 06:06:50 --> Language Class Initialized
INFO - 2023-06-05 06:06:50 --> Language Class Initialized
INFO - 2023-06-05 06:06:50 --> Language Class Initialized
INFO - 2023-06-05 06:06:50 --> Loader Class Initialized
INFO - 2023-06-05 06:06:50 --> Loader Class Initialized
INFO - 2023-06-05 06:06:50 --> Controller Class Initialized
INFO - 2023-06-05 06:06:50 --> Controller Class Initialized
INFO - 2023-06-05 06:06:50 --> Loader Class Initialized
DEBUG - 2023-06-05 06:06:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:06:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:06:50 --> Controller Class Initialized
DEBUG - 2023-06-05 06:06:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:06:50 --> Database Driver Class Initialized
INFO - 2023-06-05 06:06:50 --> Database Driver Class Initialized
INFO - 2023-06-05 06:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:06:50 --> Database Driver Class Initialized
INFO - 2023-06-05 06:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:06:50 --> Final output sent to browser
INFO - 2023-06-05 06:06:50 --> Final output sent to browser
DEBUG - 2023-06-05 06:06:50 --> Total execution time: 0.2157
DEBUG - 2023-06-05 06:06:50 --> Total execution time: 0.2164
INFO - 2023-06-05 06:06:50 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:06:50 --> Final output sent to browser
DEBUG - 2023-06-05 06:06:50 --> Total execution time: 0.2420
INFO - 2023-06-05 06:06:50 --> Config Class Initialized
INFO - 2023-06-05 06:06:50 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:06:50 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:06:50 --> Utf8 Class Initialized
INFO - 2023-06-05 06:06:50 --> URI Class Initialized
INFO - 2023-06-05 06:06:50 --> Router Class Initialized
INFO - 2023-06-05 06:06:50 --> Output Class Initialized
INFO - 2023-06-05 06:06:50 --> Security Class Initialized
DEBUG - 2023-06-05 06:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:06:50 --> Input Class Initialized
INFO - 2023-06-05 06:06:50 --> Language Class Initialized
INFO - 2023-06-05 06:06:51 --> Loader Class Initialized
INFO - 2023-06-05 06:06:51 --> Controller Class Initialized
DEBUG - 2023-06-05 06:06:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:06:51 --> Database Driver Class Initialized
INFO - 2023-06-05 06:06:51 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:06:51 --> Config Class Initialized
INFO - 2023-06-05 06:06:51 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:06:51 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:06:51 --> Utf8 Class Initialized
INFO - 2023-06-05 06:06:51 --> URI Class Initialized
INFO - 2023-06-05 06:06:51 --> Router Class Initialized
INFO - 2023-06-05 06:06:51 --> Output Class Initialized
INFO - 2023-06-05 06:06:51 --> Security Class Initialized
DEBUG - 2023-06-05 06:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:06:51 --> Input Class Initialized
INFO - 2023-06-05 06:06:51 --> Language Class Initialized
INFO - 2023-06-05 06:06:51 --> Loader Class Initialized
INFO - 2023-06-05 06:06:51 --> Controller Class Initialized
DEBUG - 2023-06-05 06:06:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:06:51 --> Database Driver Class Initialized
INFO - 2023-06-05 06:06:51 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:24 --> Config Class Initialized
INFO - 2023-06-05 06:11:24 --> Config Class Initialized
INFO - 2023-06-05 06:11:24 --> Config Class Initialized
INFO - 2023-06-05 06:11:24 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:24 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:24 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:11:24 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:24 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:24 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:24 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:24 --> URI Class Initialized
INFO - 2023-06-05 06:11:24 --> URI Class Initialized
INFO - 2023-06-05 06:11:24 --> URI Class Initialized
INFO - 2023-06-05 06:11:24 --> Router Class Initialized
INFO - 2023-06-05 06:11:24 --> Router Class Initialized
INFO - 2023-06-05 06:11:24 --> Router Class Initialized
INFO - 2023-06-05 06:11:24 --> Output Class Initialized
INFO - 2023-06-05 06:11:24 --> Output Class Initialized
INFO - 2023-06-05 06:11:24 --> Output Class Initialized
INFO - 2023-06-05 06:11:24 --> Security Class Initialized
INFO - 2023-06-05 06:11:24 --> Security Class Initialized
INFO - 2023-06-05 06:11:24 --> Security Class Initialized
DEBUG - 2023-06-05 06:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:24 --> Input Class Initialized
INFO - 2023-06-05 06:11:24 --> Input Class Initialized
INFO - 2023-06-05 06:11:24 --> Input Class Initialized
INFO - 2023-06-05 06:11:24 --> Language Class Initialized
INFO - 2023-06-05 06:11:24 --> Language Class Initialized
INFO - 2023-06-05 06:11:24 --> Language Class Initialized
INFO - 2023-06-05 06:11:24 --> Loader Class Initialized
INFO - 2023-06-05 06:11:24 --> Loader Class Initialized
INFO - 2023-06-05 06:11:24 --> Controller Class Initialized
INFO - 2023-06-05 06:11:24 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:11:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:24 --> Loader Class Initialized
INFO - 2023-06-05 06:11:24 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:24 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:24 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:24 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:24 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:24 --> Final output sent to browser
INFO - 2023-06-05 06:11:24 --> Final output sent to browser
DEBUG - 2023-06-05 06:11:24 --> Total execution time: 0.2130
DEBUG - 2023-06-05 06:11:24 --> Total execution time: 0.2135
INFO - 2023-06-05 06:11:24 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:24 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:24 --> Final output sent to browser
DEBUG - 2023-06-05 06:11:24 --> Total execution time: 0.2568
INFO - 2023-06-05 06:11:24 --> Config Class Initialized
INFO - 2023-06-05 06:11:24 --> Config Class Initialized
INFO - 2023-06-05 06:11:24 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:24 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:11:24 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:24 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:24 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:25 --> URI Class Initialized
INFO - 2023-06-05 06:11:25 --> URI Class Initialized
INFO - 2023-06-05 06:11:25 --> Router Class Initialized
INFO - 2023-06-05 06:11:25 --> Router Class Initialized
INFO - 2023-06-05 06:11:25 --> Output Class Initialized
INFO - 2023-06-05 06:11:25 --> Output Class Initialized
INFO - 2023-06-05 06:11:25 --> Config Class Initialized
INFO - 2023-06-05 06:11:25 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:25 --> Security Class Initialized
INFO - 2023-06-05 06:11:25 --> Security Class Initialized
DEBUG - 2023-06-05 06:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:25 --> Input Class Initialized
INFO - 2023-06-05 06:11:25 --> Input Class Initialized
INFO - 2023-06-05 06:11:25 --> Language Class Initialized
INFO - 2023-06-05 06:11:25 --> Language Class Initialized
DEBUG - 2023-06-05 06:11:25 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:25 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:25 --> Loader Class Initialized
INFO - 2023-06-05 06:11:25 --> Loader Class Initialized
INFO - 2023-06-05 06:11:25 --> URI Class Initialized
INFO - 2023-06-05 06:11:25 --> Controller Class Initialized
INFO - 2023-06-05 06:11:25 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:11:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:25 --> Router Class Initialized
INFO - 2023-06-05 06:11:25 --> Output Class Initialized
INFO - 2023-06-05 06:11:25 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:25 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:25 --> Security Class Initialized
INFO - 2023-06-05 06:11:25 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 06:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:25 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:25 --> Input Class Initialized
INFO - 2023-06-05 06:11:25 --> Language Class Initialized
INFO - 2023-06-05 06:11:25 --> Final output sent to browser
INFO - 2023-06-05 06:11:25 --> Final output sent to browser
DEBUG - 2023-06-05 06:11:25 --> Total execution time: 0.1710
DEBUG - 2023-06-05 06:11:25 --> Total execution time: 0.1717
INFO - 2023-06-05 06:11:25 --> Loader Class Initialized
INFO - 2023-06-05 06:11:25 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:25 --> Config Class Initialized
INFO - 2023-06-05 06:11:25 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:25 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:11:25 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:25 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:25 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:25 --> URI Class Initialized
INFO - 2023-06-05 06:11:25 --> Final output sent to browser
DEBUG - 2023-06-05 06:11:25 --> Total execution time: 0.2298
INFO - 2023-06-05 06:11:25 --> Router Class Initialized
INFO - 2023-06-05 06:11:25 --> Output Class Initialized
INFO - 2023-06-05 06:11:25 --> Security Class Initialized
DEBUG - 2023-06-05 06:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:25 --> Input Class Initialized
INFO - 2023-06-05 06:11:25 --> Language Class Initialized
INFO - 2023-06-05 06:11:25 --> Loader Class Initialized
INFO - 2023-06-05 06:11:25 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:25 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:25 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:25 --> Config Class Initialized
INFO - 2023-06-05 06:11:25 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:11:25 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:25 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:25 --> URI Class Initialized
INFO - 2023-06-05 06:11:25 --> Router Class Initialized
INFO - 2023-06-05 06:11:25 --> Output Class Initialized
INFO - 2023-06-05 06:11:25 --> Security Class Initialized
DEBUG - 2023-06-05 06:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:25 --> Input Class Initialized
INFO - 2023-06-05 06:11:25 --> Language Class Initialized
INFO - 2023-06-05 06:11:25 --> Loader Class Initialized
INFO - 2023-06-05 06:11:25 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:25 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:25 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:45 --> Config Class Initialized
INFO - 2023-06-05 06:11:45 --> Config Class Initialized
INFO - 2023-06-05 06:11:45 --> Config Class Initialized
INFO - 2023-06-05 06:11:45 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:45 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:11:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:45 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:45 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:45 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:45 --> URI Class Initialized
INFO - 2023-06-05 06:11:45 --> URI Class Initialized
INFO - 2023-06-05 06:11:45 --> URI Class Initialized
INFO - 2023-06-05 06:11:45 --> Router Class Initialized
INFO - 2023-06-05 06:11:45 --> Router Class Initialized
INFO - 2023-06-05 06:11:45 --> Router Class Initialized
INFO - 2023-06-05 06:11:45 --> Output Class Initialized
INFO - 2023-06-05 06:11:45 --> Output Class Initialized
INFO - 2023-06-05 06:11:45 --> Output Class Initialized
INFO - 2023-06-05 06:11:45 --> Security Class Initialized
INFO - 2023-06-05 06:11:45 --> Security Class Initialized
INFO - 2023-06-05 06:11:45 --> Security Class Initialized
DEBUG - 2023-06-05 06:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:45 --> Input Class Initialized
INFO - 2023-06-05 06:11:45 --> Input Class Initialized
INFO - 2023-06-05 06:11:45 --> Input Class Initialized
INFO - 2023-06-05 06:11:45 --> Language Class Initialized
INFO - 2023-06-05 06:11:45 --> Language Class Initialized
INFO - 2023-06-05 06:11:45 --> Language Class Initialized
INFO - 2023-06-05 06:11:45 --> Loader Class Initialized
INFO - 2023-06-05 06:11:45 --> Loader Class Initialized
INFO - 2023-06-05 06:11:45 --> Controller Class Initialized
INFO - 2023-06-05 06:11:45 --> Controller Class Initialized
INFO - 2023-06-05 06:11:45 --> Loader Class Initialized
DEBUG - 2023-06-05 06:11:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:11:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:45 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:45 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:45 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:45 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:45 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:45 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:45 --> Final output sent to browser
INFO - 2023-06-05 06:11:45 --> Final output sent to browser
DEBUG - 2023-06-05 06:11:45 --> Total execution time: 0.1749
DEBUG - 2023-06-05 06:11:45 --> Total execution time: 0.1742
INFO - 2023-06-05 06:11:45 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:45 --> Final output sent to browser
DEBUG - 2023-06-05 06:11:45 --> Total execution time: 0.2070
INFO - 2023-06-05 06:11:45 --> Config Class Initialized
INFO - 2023-06-05 06:11:45 --> Config Class Initialized
INFO - 2023-06-05 06:11:45 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:45 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:11:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:45 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:45 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:45 --> URI Class Initialized
INFO - 2023-06-05 06:11:45 --> URI Class Initialized
INFO - 2023-06-05 06:11:45 --> Router Class Initialized
INFO - 2023-06-05 06:11:45 --> Router Class Initialized
INFO - 2023-06-05 06:11:45 --> Config Class Initialized
INFO - 2023-06-05 06:11:45 --> Output Class Initialized
INFO - 2023-06-05 06:11:45 --> Output Class Initialized
INFO - 2023-06-05 06:11:45 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:45 --> Security Class Initialized
INFO - 2023-06-05 06:11:45 --> Security Class Initialized
DEBUG - 2023-06-05 06:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:45 --> Input Class Initialized
INFO - 2023-06-05 06:11:45 --> Input Class Initialized
INFO - 2023-06-05 06:11:45 --> Language Class Initialized
INFO - 2023-06-05 06:11:45 --> Language Class Initialized
DEBUG - 2023-06-05 06:11:45 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:45 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:45 --> URI Class Initialized
INFO - 2023-06-05 06:11:45 --> Loader Class Initialized
INFO - 2023-06-05 06:11:45 --> Loader Class Initialized
INFO - 2023-06-05 06:11:45 --> Router Class Initialized
INFO - 2023-06-05 06:11:45 --> Controller Class Initialized
INFO - 2023-06-05 06:11:45 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:11:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:45 --> Output Class Initialized
INFO - 2023-06-05 06:11:45 --> Security Class Initialized
INFO - 2023-06-05 06:11:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:46 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:46 --> Input Class Initialized
INFO - 2023-06-05 06:11:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:46 --> Language Class Initialized
INFO - 2023-06-05 06:11:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:46 --> Final output sent to browser
INFO - 2023-06-05 06:11:46 --> Final output sent to browser
DEBUG - 2023-06-05 06:11:46 --> Total execution time: 0.1629
DEBUG - 2023-06-05 06:11:46 --> Total execution time: 0.1639
INFO - 2023-06-05 06:11:46 --> Loader Class Initialized
INFO - 2023-06-05 06:11:46 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:46 --> Config Class Initialized
INFO - 2023-06-05 06:11:46 --> Hooks Class Initialized
INFO - 2023-06-05 06:11:46 --> Final output sent to browser
DEBUG - 2023-06-05 06:11:46 --> Total execution time: 0.2259
DEBUG - 2023-06-05 06:11:46 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:46 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:46 --> URI Class Initialized
INFO - 2023-06-05 06:11:46 --> Router Class Initialized
INFO - 2023-06-05 06:11:46 --> Output Class Initialized
INFO - 2023-06-05 06:11:46 --> Security Class Initialized
DEBUG - 2023-06-05 06:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:46 --> Input Class Initialized
INFO - 2023-06-05 06:11:46 --> Language Class Initialized
INFO - 2023-06-05 06:11:46 --> Loader Class Initialized
INFO - 2023-06-05 06:11:46 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:11:46 --> Config Class Initialized
INFO - 2023-06-05 06:11:46 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:11:46 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:11:46 --> Utf8 Class Initialized
INFO - 2023-06-05 06:11:46 --> URI Class Initialized
INFO - 2023-06-05 06:11:46 --> Router Class Initialized
INFO - 2023-06-05 06:11:46 --> Output Class Initialized
INFO - 2023-06-05 06:11:46 --> Security Class Initialized
DEBUG - 2023-06-05 06:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:11:46 --> Input Class Initialized
INFO - 2023-06-05 06:11:46 --> Language Class Initialized
INFO - 2023-06-05 06:11:46 --> Loader Class Initialized
INFO - 2023-06-05 06:11:46 --> Controller Class Initialized
DEBUG - 2023-06-05 06:11:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:11:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:11:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:12:39 --> Config Class Initialized
INFO - 2023-06-05 06:12:39 --> Config Class Initialized
INFO - 2023-06-05 06:12:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:12:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:12:39 --> Config Class Initialized
DEBUG - 2023-06-05 06:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:12:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:12:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:12:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:12:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:12:39 --> URI Class Initialized
INFO - 2023-06-05 06:12:39 --> URI Class Initialized
INFO - 2023-06-05 06:12:39 --> Router Class Initialized
INFO - 2023-06-05 06:12:39 --> Router Class Initialized
DEBUG - 2023-06-05 06:12:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:12:39 --> Output Class Initialized
INFO - 2023-06-05 06:12:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:12:39 --> Output Class Initialized
INFO - 2023-06-05 06:12:39 --> Security Class Initialized
INFO - 2023-06-05 06:12:39 --> Security Class Initialized
INFO - 2023-06-05 06:12:39 --> URI Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:12:39 --> Input Class Initialized
INFO - 2023-06-05 06:12:39 --> Input Class Initialized
INFO - 2023-06-05 06:12:39 --> Language Class Initialized
INFO - 2023-06-05 06:12:39 --> Router Class Initialized
INFO - 2023-06-05 06:12:39 --> Language Class Initialized
INFO - 2023-06-05 06:12:39 --> Output Class Initialized
INFO - 2023-06-05 06:12:39 --> Loader Class Initialized
INFO - 2023-06-05 06:12:39 --> Loader Class Initialized
INFO - 2023-06-05 06:12:39 --> Security Class Initialized
INFO - 2023-06-05 06:12:39 --> Controller Class Initialized
INFO - 2023-06-05 06:12:39 --> Controller Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:12:39 --> Input Class Initialized
INFO - 2023-06-05 06:12:39 --> Language Class Initialized
INFO - 2023-06-05 06:12:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:12:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:12:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:12:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:12:39 --> Loader Class Initialized
INFO - 2023-06-05 06:12:39 --> Final output sent to browser
INFO - 2023-06-05 06:12:39 --> Final output sent to browser
INFO - 2023-06-05 06:12:39 --> Controller Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Total execution time: 0.2568
DEBUG - 2023-06-05 06:12:39 --> Total execution time: 0.2553
DEBUG - 2023-06-05 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:12:39 --> Config Class Initialized
INFO - 2023-06-05 06:12:39 --> Config Class Initialized
INFO - 2023-06-05 06:12:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:12:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:12:39 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:12:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:12:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:12:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:12:39 --> URI Class Initialized
INFO - 2023-06-05 06:12:39 --> URI Class Initialized
INFO - 2023-06-05 06:12:39 --> Router Class Initialized
INFO - 2023-06-05 06:12:39 --> Router Class Initialized
INFO - 2023-06-05 06:12:39 --> Output Class Initialized
INFO - 2023-06-05 06:12:39 --> Output Class Initialized
INFO - 2023-06-05 06:12:39 --> Security Class Initialized
INFO - 2023-06-05 06:12:39 --> Security Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:12:39 --> Input Class Initialized
INFO - 2023-06-05 06:12:39 --> Language Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:12:39 --> Input Class Initialized
INFO - 2023-06-05 06:12:39 --> Language Class Initialized
INFO - 2023-06-05 06:12:39 --> Loader Class Initialized
INFO - 2023-06-05 06:12:39 --> Controller Class Initialized
INFO - 2023-06-05 06:12:39 --> Loader Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:12:39 --> Controller Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:12:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:12:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:12:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:12:39 --> Final output sent to browser
DEBUG - 2023-06-05 06:12:39 --> Total execution time: 0.4967
INFO - 2023-06-05 06:12:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:12:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:12:39 --> Final output sent to browser
DEBUG - 2023-06-05 06:12:39 --> Total execution time: 0.2594
INFO - 2023-06-05 06:12:39 --> Config Class Initialized
INFO - 2023-06-05 06:12:39 --> Final output sent to browser
INFO - 2023-06-05 06:12:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Total execution time: 0.2694
DEBUG - 2023-06-05 06:12:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:12:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:12:39 --> URI Class Initialized
INFO - 2023-06-05 06:12:39 --> Router Class Initialized
INFO - 2023-06-05 06:12:39 --> Config Class Initialized
INFO - 2023-06-05 06:12:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:12:39 --> Output Class Initialized
INFO - 2023-06-05 06:12:39 --> Security Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:12:39 --> Input Class Initialized
DEBUG - 2023-06-05 06:12:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:12:39 --> Language Class Initialized
INFO - 2023-06-05 06:12:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:12:39 --> URI Class Initialized
INFO - 2023-06-05 06:12:39 --> Router Class Initialized
INFO - 2023-06-05 06:12:39 --> Loader Class Initialized
INFO - 2023-06-05 06:12:39 --> Output Class Initialized
INFO - 2023-06-05 06:12:39 --> Controller Class Initialized
INFO - 2023-06-05 06:12:39 --> Security Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:12:39 --> Input Class Initialized
INFO - 2023-06-05 06:12:39 --> Language Class Initialized
INFO - 2023-06-05 06:12:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:12:39 --> Loader Class Initialized
INFO - 2023-06-05 06:12:39 --> Controller Class Initialized
DEBUG - 2023-06-05 06:12:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:12:40 --> Database Driver Class Initialized
INFO - 2023-06-05 06:12:40 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:12:40 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:12:40 --> Final output sent to browser
DEBUG - 2023-06-05 06:12:40 --> Total execution time: 0.2609
INFO - 2023-06-05 06:12:40 --> Config Class Initialized
INFO - 2023-06-05 06:12:40 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:12:40 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:12:40 --> Utf8 Class Initialized
INFO - 2023-06-05 06:12:40 --> URI Class Initialized
INFO - 2023-06-05 06:12:40 --> Router Class Initialized
INFO - 2023-06-05 06:12:40 --> Output Class Initialized
INFO - 2023-06-05 06:12:40 --> Security Class Initialized
DEBUG - 2023-06-05 06:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:12:40 --> Input Class Initialized
INFO - 2023-06-05 06:12:40 --> Language Class Initialized
INFO - 2023-06-05 06:12:40 --> Loader Class Initialized
INFO - 2023-06-05 06:12:40 --> Controller Class Initialized
DEBUG - 2023-06-05 06:12:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:12:40 --> Database Driver Class Initialized
INFO - 2023-06-05 06:12:40 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:14:32 --> Config Class Initialized
INFO - 2023-06-05 06:14:32 --> Config Class Initialized
INFO - 2023-06-05 06:14:32 --> Config Class Initialized
INFO - 2023-06-05 06:14:32 --> Hooks Class Initialized
INFO - 2023-06-05 06:14:32 --> Hooks Class Initialized
INFO - 2023-06-05 06:14:32 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:14:32 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:14:32 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:14:32 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:14:32 --> Utf8 Class Initialized
INFO - 2023-06-05 06:14:32 --> Utf8 Class Initialized
INFO - 2023-06-05 06:14:32 --> Utf8 Class Initialized
INFO - 2023-06-05 06:14:32 --> URI Class Initialized
INFO - 2023-06-05 06:14:32 --> URI Class Initialized
INFO - 2023-06-05 06:14:32 --> URI Class Initialized
INFO - 2023-06-05 06:14:32 --> Router Class Initialized
INFO - 2023-06-05 06:14:32 --> Router Class Initialized
INFO - 2023-06-05 06:14:32 --> Router Class Initialized
INFO - 2023-06-05 06:14:32 --> Output Class Initialized
INFO - 2023-06-05 06:14:32 --> Output Class Initialized
INFO - 2023-06-05 06:14:32 --> Output Class Initialized
INFO - 2023-06-05 06:14:32 --> Security Class Initialized
INFO - 2023-06-05 06:14:32 --> Security Class Initialized
INFO - 2023-06-05 06:14:32 --> Security Class Initialized
DEBUG - 2023-06-05 06:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:14:32 --> Input Class Initialized
INFO - 2023-06-05 06:14:32 --> Input Class Initialized
INFO - 2023-06-05 06:14:32 --> Input Class Initialized
INFO - 2023-06-05 06:14:32 --> Language Class Initialized
INFO - 2023-06-05 06:14:32 --> Language Class Initialized
INFO - 2023-06-05 06:14:32 --> Language Class Initialized
INFO - 2023-06-05 06:14:32 --> Loader Class Initialized
INFO - 2023-06-05 06:14:32 --> Loader Class Initialized
INFO - 2023-06-05 06:14:32 --> Controller Class Initialized
INFO - 2023-06-05 06:14:32 --> Controller Class Initialized
DEBUG - 2023-06-05 06:14:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:14:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:14:32 --> Loader Class Initialized
INFO - 2023-06-05 06:14:32 --> Controller Class Initialized
INFO - 2023-06-05 06:14:32 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:14:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:14:32 --> Database Driver Class Initialized
INFO - 2023-06-05 06:14:32 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:14:32 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:14:32 --> Final output sent to browser
INFO - 2023-06-05 06:14:32 --> Final output sent to browser
DEBUG - 2023-06-05 06:14:32 --> Total execution time: 0.1739
DEBUG - 2023-06-05 06:14:32 --> Total execution time: 0.1726
INFO - 2023-06-05 06:14:33 --> Database Driver Class Initialized
INFO - 2023-06-05 06:14:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:14:33 --> Final output sent to browser
INFO - 2023-06-05 06:14:33 --> Config Class Initialized
INFO - 2023-06-05 06:14:33 --> Config Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Total execution time: 0.2130
INFO - 2023-06-05 06:14:33 --> Hooks Class Initialized
INFO - 2023-06-05 06:14:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:14:33 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:14:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:14:33 --> Utf8 Class Initialized
INFO - 2023-06-05 06:14:33 --> Utf8 Class Initialized
INFO - 2023-06-05 06:14:33 --> URI Class Initialized
INFO - 2023-06-05 06:14:33 --> URI Class Initialized
INFO - 2023-06-05 06:14:33 --> Router Class Initialized
INFO - 2023-06-05 06:14:33 --> Router Class Initialized
INFO - 2023-06-05 06:14:33 --> Output Class Initialized
INFO - 2023-06-05 06:14:33 --> Output Class Initialized
INFO - 2023-06-05 06:14:33 --> Config Class Initialized
INFO - 2023-06-05 06:14:33 --> Hooks Class Initialized
INFO - 2023-06-05 06:14:33 --> Security Class Initialized
INFO - 2023-06-05 06:14:33 --> Security Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:14:33 --> Input Class Initialized
INFO - 2023-06-05 06:14:33 --> Input Class Initialized
INFO - 2023-06-05 06:14:33 --> Language Class Initialized
INFO - 2023-06-05 06:14:33 --> Language Class Initialized
DEBUG - 2023-06-05 06:14:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:14:33 --> Utf8 Class Initialized
INFO - 2023-06-05 06:14:33 --> Loader Class Initialized
INFO - 2023-06-05 06:14:33 --> URI Class Initialized
INFO - 2023-06-05 06:14:33 --> Loader Class Initialized
INFO - 2023-06-05 06:14:33 --> Controller Class Initialized
INFO - 2023-06-05 06:14:33 --> Controller Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:14:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:14:33 --> Router Class Initialized
INFO - 2023-06-05 06:14:33 --> Output Class Initialized
INFO - 2023-06-05 06:14:33 --> Security Class Initialized
INFO - 2023-06-05 06:14:33 --> Database Driver Class Initialized
INFO - 2023-06-05 06:14:33 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:14:33 --> Input Class Initialized
INFO - 2023-06-05 06:14:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:14:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:14:33 --> Language Class Initialized
INFO - 2023-06-05 06:14:33 --> Final output sent to browser
INFO - 2023-06-05 06:14:33 --> Final output sent to browser
DEBUG - 2023-06-05 06:14:33 --> Total execution time: 0.1569
DEBUG - 2023-06-05 06:14:33 --> Total execution time: 0.1560
INFO - 2023-06-05 06:14:33 --> Loader Class Initialized
INFO - 2023-06-05 06:14:33 --> Controller Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:14:33 --> Database Driver Class Initialized
INFO - 2023-06-05 06:14:33 --> Config Class Initialized
INFO - 2023-06-05 06:14:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:14:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:14:33 --> Utf8 Class Initialized
INFO - 2023-06-05 06:14:33 --> URI Class Initialized
INFO - 2023-06-05 06:14:33 --> Router Class Initialized
INFO - 2023-06-05 06:14:33 --> Output Class Initialized
INFO - 2023-06-05 06:14:33 --> Security Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:14:33 --> Input Class Initialized
INFO - 2023-06-05 06:14:33 --> Language Class Initialized
INFO - 2023-06-05 06:14:33 --> Loader Class Initialized
INFO - 2023-06-05 06:14:33 --> Controller Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:14:33 --> Database Driver Class Initialized
INFO - 2023-06-05 06:14:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:14:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:14:33 --> Final output sent to browser
DEBUG - 2023-06-05 06:14:33 --> Total execution time: 0.4179
INFO - 2023-06-05 06:14:33 --> Config Class Initialized
INFO - 2023-06-05 06:14:33 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:14:33 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:14:33 --> Utf8 Class Initialized
INFO - 2023-06-05 06:14:33 --> URI Class Initialized
INFO - 2023-06-05 06:14:33 --> Router Class Initialized
INFO - 2023-06-05 06:14:33 --> Output Class Initialized
INFO - 2023-06-05 06:14:33 --> Security Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:14:33 --> Input Class Initialized
INFO - 2023-06-05 06:14:33 --> Language Class Initialized
INFO - 2023-06-05 06:14:33 --> Loader Class Initialized
INFO - 2023-06-05 06:14:33 --> Controller Class Initialized
DEBUG - 2023-06-05 06:14:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:14:33 --> Database Driver Class Initialized
INFO - 2023-06-05 06:14:33 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:16:56 --> Config Class Initialized
INFO - 2023-06-05 06:16:56 --> Hooks Class Initialized
INFO - 2023-06-05 06:16:56 --> Config Class Initialized
INFO - 2023-06-05 06:16:56 --> Hooks Class Initialized
INFO - 2023-06-05 06:16:56 --> Config Class Initialized
INFO - 2023-06-05 06:16:56 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:16:56 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:16:56 --> Utf8 Class Initialized
INFO - 2023-06-05 06:16:56 --> Utf8 Class Initialized
INFO - 2023-06-05 06:16:56 --> URI Class Initialized
INFO - 2023-06-05 06:16:56 --> URI Class Initialized
DEBUG - 2023-06-05 06:16:56 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:16:56 --> Router Class Initialized
INFO - 2023-06-05 06:16:56 --> Utf8 Class Initialized
INFO - 2023-06-05 06:16:56 --> Router Class Initialized
INFO - 2023-06-05 06:16:56 --> URI Class Initialized
INFO - 2023-06-05 06:16:56 --> Output Class Initialized
INFO - 2023-06-05 06:16:56 --> Output Class Initialized
INFO - 2023-06-05 06:16:56 --> Security Class Initialized
INFO - 2023-06-05 06:16:56 --> Security Class Initialized
DEBUG - 2023-06-05 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:16:56 --> Router Class Initialized
DEBUG - 2023-06-05 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:16:56 --> Input Class Initialized
INFO - 2023-06-05 06:16:56 --> Input Class Initialized
INFO - 2023-06-05 06:16:56 --> Language Class Initialized
INFO - 2023-06-05 06:16:56 --> Language Class Initialized
INFO - 2023-06-05 06:16:56 --> Output Class Initialized
INFO - 2023-06-05 06:16:56 --> Loader Class Initialized
INFO - 2023-06-05 06:16:56 --> Loader Class Initialized
INFO - 2023-06-05 06:16:56 --> Security Class Initialized
INFO - 2023-06-05 06:16:56 --> Controller Class Initialized
DEBUG - 2023-06-05 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:16:56 --> Controller Class Initialized
INFO - 2023-06-05 06:16:56 --> Input Class Initialized
DEBUG - 2023-06-05 06:16:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:16:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:16:56 --> Language Class Initialized
INFO - 2023-06-05 06:16:56 --> Database Driver Class Initialized
INFO - 2023-06-05 06:16:56 --> Database Driver Class Initialized
INFO - 2023-06-05 06:16:56 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:16:56 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:16:56 --> Loader Class Initialized
INFO - 2023-06-05 06:16:56 --> Final output sent to browser
INFO - 2023-06-05 06:16:56 --> Final output sent to browser
DEBUG - 2023-06-05 06:16:56 --> Total execution time: 0.2217
DEBUG - 2023-06-05 06:16:56 --> Total execution time: 0.2225
INFO - 2023-06-05 06:16:56 --> Controller Class Initialized
DEBUG - 2023-06-05 06:16:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:16:56 --> Config Class Initialized
INFO - 2023-06-05 06:16:56 --> Config Class Initialized
INFO - 2023-06-05 06:16:56 --> Hooks Class Initialized
INFO - 2023-06-05 06:16:56 --> Hooks Class Initialized
INFO - 2023-06-05 06:16:56 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:16:56 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:16:56 --> Utf8 Class Initialized
INFO - 2023-06-05 06:16:56 --> Utf8 Class Initialized
INFO - 2023-06-05 06:16:56 --> URI Class Initialized
INFO - 2023-06-05 06:16:56 --> URI Class Initialized
INFO - 2023-06-05 06:16:56 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:16:56 --> Final output sent to browser
DEBUG - 2023-06-05 06:16:56 --> Total execution time: 0.2976
INFO - 2023-06-05 06:16:56 --> Router Class Initialized
INFO - 2023-06-05 06:16:56 --> Router Class Initialized
INFO - 2023-06-05 06:16:56 --> Output Class Initialized
INFO - 2023-06-05 06:16:56 --> Output Class Initialized
INFO - 2023-06-05 06:16:56 --> Security Class Initialized
INFO - 2023-06-05 06:16:56 --> Security Class Initialized
DEBUG - 2023-06-05 06:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:16:56 --> Input Class Initialized
INFO - 2023-06-05 06:16:56 --> Input Class Initialized
INFO - 2023-06-05 06:16:56 --> Language Class Initialized
INFO - 2023-06-05 06:16:56 --> Language Class Initialized
INFO - 2023-06-05 06:16:56 --> Config Class Initialized
INFO - 2023-06-05 06:16:56 --> Hooks Class Initialized
INFO - 2023-06-05 06:16:57 --> Loader Class Initialized
INFO - 2023-06-05 06:16:57 --> Loader Class Initialized
INFO - 2023-06-05 06:16:57 --> Controller Class Initialized
INFO - 2023-06-05 06:16:57 --> Controller Class Initialized
DEBUG - 2023-06-05 06:16:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:16:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:16:57 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:16:57 --> Utf8 Class Initialized
INFO - 2023-06-05 06:16:57 --> URI Class Initialized
INFO - 2023-06-05 06:16:57 --> Database Driver Class Initialized
INFO - 2023-06-05 06:16:57 --> Database Driver Class Initialized
INFO - 2023-06-05 06:16:57 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:16:57 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:16:57 --> Router Class Initialized
INFO - 2023-06-05 06:16:57 --> Final output sent to browser
INFO - 2023-06-05 06:16:57 --> Final output sent to browser
DEBUG - 2023-06-05 06:16:57 --> Total execution time: 0.1691
DEBUG - 2023-06-05 06:16:57 --> Total execution time: 0.1701
INFO - 2023-06-05 06:16:57 --> Output Class Initialized
INFO - 2023-06-05 06:16:57 --> Security Class Initialized
DEBUG - 2023-06-05 06:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:16:57 --> Input Class Initialized
INFO - 2023-06-05 06:16:57 --> Language Class Initialized
INFO - 2023-06-05 06:16:57 --> Config Class Initialized
INFO - 2023-06-05 06:16:57 --> Loader Class Initialized
INFO - 2023-06-05 06:16:57 --> Hooks Class Initialized
INFO - 2023-06-05 06:16:57 --> Controller Class Initialized
DEBUG - 2023-06-05 06:16:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:16:57 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:16:57 --> Utf8 Class Initialized
INFO - 2023-06-05 06:16:57 --> URI Class Initialized
INFO - 2023-06-05 06:16:57 --> Router Class Initialized
INFO - 2023-06-05 06:16:57 --> Database Driver Class Initialized
INFO - 2023-06-05 06:16:57 --> Output Class Initialized
INFO - 2023-06-05 06:16:57 --> Security Class Initialized
DEBUG - 2023-06-05 06:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:16:57 --> Input Class Initialized
INFO - 2023-06-05 06:16:57 --> Language Class Initialized
INFO - 2023-06-05 06:16:57 --> Loader Class Initialized
INFO - 2023-06-05 06:16:57 --> Controller Class Initialized
DEBUG - 2023-06-05 06:16:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:16:57 --> Database Driver Class Initialized
INFO - 2023-06-05 06:16:57 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:16:57 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:16:57 --> Final output sent to browser
DEBUG - 2023-06-05 06:16:57 --> Total execution time: 0.3241
INFO - 2023-06-05 06:16:57 --> Config Class Initialized
INFO - 2023-06-05 06:16:57 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:16:57 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:16:57 --> Utf8 Class Initialized
INFO - 2023-06-05 06:16:57 --> URI Class Initialized
INFO - 2023-06-05 06:16:57 --> Router Class Initialized
INFO - 2023-06-05 06:16:57 --> Output Class Initialized
INFO - 2023-06-05 06:16:57 --> Security Class Initialized
DEBUG - 2023-06-05 06:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:16:57 --> Input Class Initialized
INFO - 2023-06-05 06:16:57 --> Language Class Initialized
INFO - 2023-06-05 06:16:57 --> Loader Class Initialized
INFO - 2023-06-05 06:16:57 --> Controller Class Initialized
DEBUG - 2023-06-05 06:16:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:16:57 --> Database Driver Class Initialized
INFO - 2023-06-05 06:16:57 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:22:07 --> Config Class Initialized
INFO - 2023-06-05 06:22:07 --> Config Class Initialized
INFO - 2023-06-05 06:22:07 --> Config Class Initialized
INFO - 2023-06-05 06:22:07 --> Hooks Class Initialized
INFO - 2023-06-05 06:22:07 --> Hooks Class Initialized
INFO - 2023-06-05 06:22:07 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:22:07 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:22:07 --> Utf8 Class Initialized
INFO - 2023-06-05 06:22:07 --> Utf8 Class Initialized
INFO - 2023-06-05 06:22:07 --> Utf8 Class Initialized
INFO - 2023-06-05 06:22:07 --> URI Class Initialized
INFO - 2023-06-05 06:22:07 --> URI Class Initialized
INFO - 2023-06-05 06:22:07 --> URI Class Initialized
INFO - 2023-06-05 06:22:07 --> Router Class Initialized
INFO - 2023-06-05 06:22:07 --> Router Class Initialized
INFO - 2023-06-05 06:22:07 --> Router Class Initialized
INFO - 2023-06-05 06:22:07 --> Output Class Initialized
INFO - 2023-06-05 06:22:07 --> Output Class Initialized
INFO - 2023-06-05 06:22:07 --> Output Class Initialized
INFO - 2023-06-05 06:22:07 --> Security Class Initialized
INFO - 2023-06-05 06:22:07 --> Security Class Initialized
INFO - 2023-06-05 06:22:07 --> Security Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:22:07 --> Input Class Initialized
INFO - 2023-06-05 06:22:07 --> Input Class Initialized
INFO - 2023-06-05 06:22:07 --> Input Class Initialized
INFO - 2023-06-05 06:22:07 --> Language Class Initialized
INFO - 2023-06-05 06:22:07 --> Language Class Initialized
INFO - 2023-06-05 06:22:07 --> Language Class Initialized
INFO - 2023-06-05 06:22:07 --> Loader Class Initialized
INFO - 2023-06-05 06:22:07 --> Loader Class Initialized
INFO - 2023-06-05 06:22:07 --> Controller Class Initialized
INFO - 2023-06-05 06:22:07 --> Controller Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:22:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:22:07 --> Loader Class Initialized
INFO - 2023-06-05 06:22:07 --> Controller Class Initialized
INFO - 2023-06-05 06:22:07 --> Database Driver Class Initialized
INFO - 2023-06-05 06:22:07 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:22:07 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:22:07 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:22:07 --> Final output sent to browser
INFO - 2023-06-05 06:22:07 --> Final output sent to browser
DEBUG - 2023-06-05 06:22:07 --> Total execution time: 0.2548
DEBUG - 2023-06-05 06:22:07 --> Total execution time: 0.2565
INFO - 2023-06-05 06:22:07 --> Database Driver Class Initialized
INFO - 2023-06-05 06:22:07 --> Config Class Initialized
INFO - 2023-06-05 06:22:07 --> Config Class Initialized
INFO - 2023-06-05 06:22:07 --> Hooks Class Initialized
INFO - 2023-06-05 06:22:07 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:22:07 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:22:07 --> Utf8 Class Initialized
INFO - 2023-06-05 06:22:07 --> Utf8 Class Initialized
INFO - 2023-06-05 06:22:07 --> URI Class Initialized
INFO - 2023-06-05 06:22:07 --> URI Class Initialized
INFO - 2023-06-05 06:22:07 --> Router Class Initialized
INFO - 2023-06-05 06:22:07 --> Router Class Initialized
INFO - 2023-06-05 06:22:07 --> Output Class Initialized
INFO - 2023-06-05 06:22:07 --> Output Class Initialized
INFO - 2023-06-05 06:22:07 --> Security Class Initialized
INFO - 2023-06-05 06:22:07 --> Security Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:22:07 --> Input Class Initialized
INFO - 2023-06-05 06:22:07 --> Input Class Initialized
INFO - 2023-06-05 06:22:07 --> Language Class Initialized
INFO - 2023-06-05 06:22:07 --> Language Class Initialized
INFO - 2023-06-05 06:22:07 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:22:07 --> Final output sent to browser
INFO - 2023-06-05 06:22:07 --> Loader Class Initialized
INFO - 2023-06-05 06:22:07 --> Loader Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Total execution time: 0.4765
INFO - 2023-06-05 06:22:07 --> Controller Class Initialized
INFO - 2023-06-05 06:22:07 --> Controller Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:22:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:22:07 --> Database Driver Class Initialized
INFO - 2023-06-05 06:22:07 --> Database Driver Class Initialized
INFO - 2023-06-05 06:22:07 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:22:07 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:22:07 --> Final output sent to browser
INFO - 2023-06-05 06:22:07 --> Final output sent to browser
DEBUG - 2023-06-05 06:22:07 --> Total execution time: 0.2433
DEBUG - 2023-06-05 06:22:07 --> Total execution time: 0.2461
INFO - 2023-06-05 06:22:07 --> Config Class Initialized
INFO - 2023-06-05 06:22:07 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:22:07 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:22:07 --> Utf8 Class Initialized
INFO - 2023-06-05 06:22:07 --> URI Class Initialized
INFO - 2023-06-05 06:22:07 --> Router Class Initialized
INFO - 2023-06-05 06:22:07 --> Config Class Initialized
INFO - 2023-06-05 06:22:07 --> Output Class Initialized
INFO - 2023-06-05 06:22:07 --> Hooks Class Initialized
INFO - 2023-06-05 06:22:07 --> Security Class Initialized
DEBUG - 2023-06-05 06:22:07 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:22:07 --> Utf8 Class Initialized
INFO - 2023-06-05 06:22:07 --> Input Class Initialized
INFO - 2023-06-05 06:22:07 --> URI Class Initialized
INFO - 2023-06-05 06:22:07 --> Language Class Initialized
INFO - 2023-06-05 06:22:07 --> Router Class Initialized
INFO - 2023-06-05 06:22:07 --> Output Class Initialized
INFO - 2023-06-05 06:22:07 --> Security Class Initialized
INFO - 2023-06-05 06:22:07 --> Loader Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:22:07 --> Input Class Initialized
INFO - 2023-06-05 06:22:07 --> Controller Class Initialized
INFO - 2023-06-05 06:22:07 --> Language Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:22:07 --> Loader Class Initialized
INFO - 2023-06-05 06:22:07 --> Controller Class Initialized
DEBUG - 2023-06-05 06:22:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:22:08 --> Database Driver Class Initialized
INFO - 2023-06-05 06:22:08 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:22:08 --> Database Driver Class Initialized
INFO - 2023-06-05 06:22:08 --> Final output sent to browser
DEBUG - 2023-06-05 06:22:08 --> Total execution time: 0.3339
INFO - 2023-06-05 06:22:08 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:22:08 --> Config Class Initialized
INFO - 2023-06-05 06:22:08 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:22:08 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:22:08 --> Utf8 Class Initialized
INFO - 2023-06-05 06:22:08 --> URI Class Initialized
INFO - 2023-06-05 06:22:08 --> Router Class Initialized
INFO - 2023-06-05 06:22:08 --> Output Class Initialized
INFO - 2023-06-05 06:22:08 --> Security Class Initialized
DEBUG - 2023-06-05 06:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:22:08 --> Input Class Initialized
INFO - 2023-06-05 06:22:08 --> Language Class Initialized
INFO - 2023-06-05 06:22:08 --> Loader Class Initialized
INFO - 2023-06-05 06:22:08 --> Controller Class Initialized
DEBUG - 2023-06-05 06:22:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:22:08 --> Database Driver Class Initialized
INFO - 2023-06-05 06:22:08 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:33:30 --> Config Class Initialized
INFO - 2023-06-05 06:33:30 --> Config Class Initialized
INFO - 2023-06-05 06:33:30 --> Config Class Initialized
INFO - 2023-06-05 06:33:30 --> Hooks Class Initialized
INFO - 2023-06-05 06:33:30 --> Hooks Class Initialized
INFO - 2023-06-05 06:33:30 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:33:30 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:33:30 --> Utf8 Class Initialized
INFO - 2023-06-05 06:33:30 --> Utf8 Class Initialized
INFO - 2023-06-05 06:33:30 --> Utf8 Class Initialized
INFO - 2023-06-05 06:33:30 --> URI Class Initialized
INFO - 2023-06-05 06:33:30 --> URI Class Initialized
INFO - 2023-06-05 06:33:30 --> URI Class Initialized
INFO - 2023-06-05 06:33:30 --> Router Class Initialized
INFO - 2023-06-05 06:33:30 --> Router Class Initialized
INFO - 2023-06-05 06:33:30 --> Router Class Initialized
INFO - 2023-06-05 06:33:30 --> Output Class Initialized
INFO - 2023-06-05 06:33:30 --> Output Class Initialized
INFO - 2023-06-05 06:33:30 --> Output Class Initialized
INFO - 2023-06-05 06:33:30 --> Security Class Initialized
INFO - 2023-06-05 06:33:30 --> Security Class Initialized
INFO - 2023-06-05 06:33:30 --> Security Class Initialized
DEBUG - 2023-06-05 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:33:30 --> Input Class Initialized
INFO - 2023-06-05 06:33:30 --> Input Class Initialized
INFO - 2023-06-05 06:33:30 --> Input Class Initialized
INFO - 2023-06-05 06:33:30 --> Language Class Initialized
INFO - 2023-06-05 06:33:30 --> Language Class Initialized
INFO - 2023-06-05 06:33:30 --> Language Class Initialized
INFO - 2023-06-05 06:33:30 --> Loader Class Initialized
INFO - 2023-06-05 06:33:30 --> Loader Class Initialized
INFO - 2023-06-05 06:33:30 --> Controller Class Initialized
INFO - 2023-06-05 06:33:30 --> Controller Class Initialized
INFO - 2023-06-05 06:33:30 --> Loader Class Initialized
DEBUG - 2023-06-05 06:33:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:33:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:33:30 --> Controller Class Initialized
DEBUG - 2023-06-05 06:33:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:33:30 --> Database Driver Class Initialized
INFO - 2023-06-05 06:33:30 --> Database Driver Class Initialized
INFO - 2023-06-05 06:33:30 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:33:30 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:33:30 --> Final output sent to browser
INFO - 2023-06-05 06:33:30 --> Final output sent to browser
DEBUG - 2023-06-05 06:33:30 --> Total execution time: 0.2522
DEBUG - 2023-06-05 06:33:30 --> Total execution time: 0.2518
INFO - 2023-06-05 06:33:30 --> Database Driver Class Initialized
INFO - 2023-06-05 06:33:30 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:33:30 --> Final output sent to browser
DEBUG - 2023-06-05 06:33:30 --> Total execution time: 0.2917
INFO - 2023-06-05 06:33:30 --> Config Class Initialized
INFO - 2023-06-05 06:33:30 --> Config Class Initialized
INFO - 2023-06-05 06:33:30 --> Hooks Class Initialized
INFO - 2023-06-05 06:33:30 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:33:30 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:33:30 --> Utf8 Class Initialized
INFO - 2023-06-05 06:33:30 --> Utf8 Class Initialized
INFO - 2023-06-05 06:33:30 --> URI Class Initialized
INFO - 2023-06-05 06:33:30 --> URI Class Initialized
INFO - 2023-06-05 06:33:30 --> Router Class Initialized
INFO - 2023-06-05 06:33:30 --> Router Class Initialized
INFO - 2023-06-05 06:33:30 --> Config Class Initialized
INFO - 2023-06-05 06:33:30 --> Output Class Initialized
INFO - 2023-06-05 06:33:30 --> Hooks Class Initialized
INFO - 2023-06-05 06:33:30 --> Output Class Initialized
INFO - 2023-06-05 06:33:30 --> Security Class Initialized
INFO - 2023-06-05 06:33:30 --> Security Class Initialized
DEBUG - 2023-06-05 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:33:30 --> Input Class Initialized
INFO - 2023-06-05 06:33:30 --> Input Class Initialized
INFO - 2023-06-05 06:33:30 --> Language Class Initialized
DEBUG - 2023-06-05 06:33:30 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:33:30 --> Language Class Initialized
INFO - 2023-06-05 06:33:30 --> Utf8 Class Initialized
INFO - 2023-06-05 06:33:30 --> URI Class Initialized
INFO - 2023-06-05 06:33:30 --> Loader Class Initialized
INFO - 2023-06-05 06:33:30 --> Loader Class Initialized
INFO - 2023-06-05 06:33:30 --> Router Class Initialized
INFO - 2023-06-05 06:33:30 --> Controller Class Initialized
INFO - 2023-06-05 06:33:30 --> Controller Class Initialized
DEBUG - 2023-06-05 06:33:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:33:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:33:30 --> Output Class Initialized
INFO - 2023-06-05 06:33:30 --> Security Class Initialized
INFO - 2023-06-05 06:33:30 --> Database Driver Class Initialized
INFO - 2023-06-05 06:33:30 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:33:30 --> Input Class Initialized
INFO - 2023-06-05 06:33:30 --> Language Class Initialized
INFO - 2023-06-05 06:33:30 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:33:30 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:33:30 --> Final output sent to browser
INFO - 2023-06-05 06:33:30 --> Final output sent to browser
DEBUG - 2023-06-05 06:33:30 --> Total execution time: 0.2091
DEBUG - 2023-06-05 06:33:30 --> Total execution time: 0.2077
INFO - 2023-06-05 06:33:30 --> Loader Class Initialized
INFO - 2023-06-05 06:33:30 --> Controller Class Initialized
DEBUG - 2023-06-05 06:33:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:33:31 --> Database Driver Class Initialized
INFO - 2023-06-05 06:33:31 --> Config Class Initialized
INFO - 2023-06-05 06:33:31 --> Hooks Class Initialized
INFO - 2023-06-05 06:33:31 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:33:31 --> Final output sent to browser
DEBUG - 2023-06-05 06:33:31 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:33:31 --> Total execution time: 0.2602
INFO - 2023-06-05 06:33:31 --> Utf8 Class Initialized
INFO - 2023-06-05 06:33:31 --> URI Class Initialized
INFO - 2023-06-05 06:33:31 --> Router Class Initialized
INFO - 2023-06-05 06:33:31 --> Output Class Initialized
INFO - 2023-06-05 06:33:31 --> Security Class Initialized
DEBUG - 2023-06-05 06:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:33:31 --> Input Class Initialized
INFO - 2023-06-05 06:33:31 --> Language Class Initialized
INFO - 2023-06-05 06:33:31 --> Loader Class Initialized
INFO - 2023-06-05 06:33:31 --> Controller Class Initialized
DEBUG - 2023-06-05 06:33:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:33:31 --> Database Driver Class Initialized
INFO - 2023-06-05 06:33:31 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:33:31 --> Config Class Initialized
INFO - 2023-06-05 06:33:31 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:33:31 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:33:31 --> Utf8 Class Initialized
INFO - 2023-06-05 06:33:31 --> URI Class Initialized
INFO - 2023-06-05 06:33:31 --> Router Class Initialized
INFO - 2023-06-05 06:33:31 --> Output Class Initialized
INFO - 2023-06-05 06:33:31 --> Security Class Initialized
DEBUG - 2023-06-05 06:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:33:31 --> Input Class Initialized
INFO - 2023-06-05 06:33:31 --> Language Class Initialized
INFO - 2023-06-05 06:33:31 --> Loader Class Initialized
INFO - 2023-06-05 06:33:31 --> Controller Class Initialized
DEBUG - 2023-06-05 06:33:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:33:31 --> Database Driver Class Initialized
INFO - 2023-06-05 06:33:31 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:48:39 --> Config Class Initialized
INFO - 2023-06-05 06:48:39 --> Config Class Initialized
INFO - 2023-06-05 06:48:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:48:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:48:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:48:39 --> Config Class Initialized
INFO - 2023-06-05 06:48:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:48:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:48:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:48:39 --> URI Class Initialized
INFO - 2023-06-05 06:48:39 --> URI Class Initialized
INFO - 2023-06-05 06:48:39 --> Router Class Initialized
INFO - 2023-06-05 06:48:39 --> Router Class Initialized
INFO - 2023-06-05 06:48:39 --> Output Class Initialized
INFO - 2023-06-05 06:48:39 --> Output Class Initialized
DEBUG - 2023-06-05 06:48:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:48:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:48:39 --> Security Class Initialized
INFO - 2023-06-05 06:48:39 --> Security Class Initialized
DEBUG - 2023-06-05 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:48:39 --> URI Class Initialized
DEBUG - 2023-06-05 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:48:39 --> Input Class Initialized
INFO - 2023-06-05 06:48:39 --> Input Class Initialized
INFO - 2023-06-05 06:48:39 --> Language Class Initialized
INFO - 2023-06-05 06:48:39 --> Language Class Initialized
INFO - 2023-06-05 06:48:39 --> Router Class Initialized
INFO - 2023-06-05 06:48:39 --> Loader Class Initialized
INFO - 2023-06-05 06:48:39 --> Loader Class Initialized
INFO - 2023-06-05 06:48:39 --> Output Class Initialized
INFO - 2023-06-05 06:48:39 --> Controller Class Initialized
INFO - 2023-06-05 06:48:39 --> Controller Class Initialized
DEBUG - 2023-06-05 06:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:48:39 --> Security Class Initialized
DEBUG - 2023-06-05 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:48:39 --> Input Class Initialized
INFO - 2023-06-05 06:48:39 --> Language Class Initialized
INFO - 2023-06-05 06:48:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:48:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:48:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:48:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:48:39 --> Final output sent to browser
INFO - 2023-06-05 06:48:39 --> Loader Class Initialized
INFO - 2023-06-05 06:48:39 --> Final output sent to browser
DEBUG - 2023-06-05 06:48:39 --> Total execution time: 0.1949
DEBUG - 2023-06-05 06:48:39 --> Total execution time: 0.1955
INFO - 2023-06-05 06:48:39 --> Controller Class Initialized
DEBUG - 2023-06-05 06:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:48:39 --> Config Class Initialized
INFO - 2023-06-05 06:48:39 --> Config Class Initialized
INFO - 2023-06-05 06:48:39 --> Hooks Class Initialized
INFO - 2023-06-05 06:48:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:48:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:48:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:48:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:48:39 --> URI Class Initialized
INFO - 2023-06-05 06:48:39 --> URI Class Initialized
INFO - 2023-06-05 06:48:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:48:39 --> Router Class Initialized
INFO - 2023-06-05 06:48:39 --> Router Class Initialized
INFO - 2023-06-05 06:48:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:48:39 --> Output Class Initialized
INFO - 2023-06-05 06:48:39 --> Final output sent to browser
INFO - 2023-06-05 06:48:39 --> Output Class Initialized
DEBUG - 2023-06-05 06:48:39 --> Total execution time: 0.2573
INFO - 2023-06-05 06:48:39 --> Security Class Initialized
INFO - 2023-06-05 06:48:39 --> Security Class Initialized
DEBUG - 2023-06-05 06:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:48:39 --> Input Class Initialized
INFO - 2023-06-05 06:48:39 --> Input Class Initialized
INFO - 2023-06-05 06:48:39 --> Language Class Initialized
INFO - 2023-06-05 06:48:39 --> Language Class Initialized
INFO - 2023-06-05 06:48:39 --> Loader Class Initialized
INFO - 2023-06-05 06:48:39 --> Loader Class Initialized
INFO - 2023-06-05 06:48:39 --> Controller Class Initialized
INFO - 2023-06-05 06:48:39 --> Config Class Initialized
INFO - 2023-06-05 06:48:39 --> Controller Class Initialized
INFO - 2023-06-05 06:48:39 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:48:39 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:48:39 --> Utf8 Class Initialized
INFO - 2023-06-05 06:48:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:48:39 --> Database Driver Class Initialized
INFO - 2023-06-05 06:48:39 --> URI Class Initialized
INFO - 2023-06-05 06:48:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:48:39 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:48:40 --> Final output sent to browser
INFO - 2023-06-05 06:48:40 --> Final output sent to browser
INFO - 2023-06-05 06:48:40 --> Router Class Initialized
DEBUG - 2023-06-05 06:48:40 --> Total execution time: 0.1578
DEBUG - 2023-06-05 06:48:40 --> Total execution time: 0.1587
INFO - 2023-06-05 06:48:40 --> Output Class Initialized
INFO - 2023-06-05 06:48:40 --> Security Class Initialized
DEBUG - 2023-06-05 06:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:48:40 --> Input Class Initialized
INFO - 2023-06-05 06:48:40 --> Language Class Initialized
INFO - 2023-06-05 06:48:40 --> Config Class Initialized
INFO - 2023-06-05 06:48:40 --> Hooks Class Initialized
INFO - 2023-06-05 06:48:40 --> Loader Class Initialized
DEBUG - 2023-06-05 06:48:40 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:48:40 --> Controller Class Initialized
INFO - 2023-06-05 06:48:40 --> Utf8 Class Initialized
DEBUG - 2023-06-05 06:48:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:48:40 --> URI Class Initialized
INFO - 2023-06-05 06:48:40 --> Router Class Initialized
INFO - 2023-06-05 06:48:40 --> Database Driver Class Initialized
INFO - 2023-06-05 06:48:40 --> Output Class Initialized
INFO - 2023-06-05 06:48:40 --> Security Class Initialized
INFO - 2023-06-05 06:48:40 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 06:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:48:40 --> Input Class Initialized
INFO - 2023-06-05 06:48:40 --> Language Class Initialized
INFO - 2023-06-05 06:48:40 --> Final output sent to browser
DEBUG - 2023-06-05 06:48:40 --> Total execution time: 0.2150
INFO - 2023-06-05 06:48:40 --> Loader Class Initialized
INFO - 2023-06-05 06:48:40 --> Controller Class Initialized
DEBUG - 2023-06-05 06:48:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:48:40 --> Database Driver Class Initialized
INFO - 2023-06-05 06:48:40 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:48:40 --> Config Class Initialized
INFO - 2023-06-05 06:48:40 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:48:40 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:48:40 --> Utf8 Class Initialized
INFO - 2023-06-05 06:48:40 --> URI Class Initialized
INFO - 2023-06-05 06:48:40 --> Router Class Initialized
INFO - 2023-06-05 06:48:40 --> Output Class Initialized
INFO - 2023-06-05 06:48:40 --> Security Class Initialized
DEBUG - 2023-06-05 06:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:48:40 --> Input Class Initialized
INFO - 2023-06-05 06:48:40 --> Language Class Initialized
INFO - 2023-06-05 06:48:40 --> Loader Class Initialized
INFO - 2023-06-05 06:48:40 --> Controller Class Initialized
DEBUG - 2023-06-05 06:48:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:48:40 --> Database Driver Class Initialized
INFO - 2023-06-05 06:48:40 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:49:46 --> Config Class Initialized
INFO - 2023-06-05 06:49:46 --> Config Class Initialized
INFO - 2023-06-05 06:49:46 --> Config Class Initialized
INFO - 2023-06-05 06:49:46 --> Hooks Class Initialized
INFO - 2023-06-05 06:49:46 --> Hooks Class Initialized
INFO - 2023-06-05 06:49:46 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:49:46 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:49:46 --> Utf8 Class Initialized
INFO - 2023-06-05 06:49:46 --> Utf8 Class Initialized
INFO - 2023-06-05 06:49:46 --> Utf8 Class Initialized
INFO - 2023-06-05 06:49:46 --> URI Class Initialized
INFO - 2023-06-05 06:49:46 --> URI Class Initialized
INFO - 2023-06-05 06:49:46 --> URI Class Initialized
INFO - 2023-06-05 06:49:46 --> Router Class Initialized
INFO - 2023-06-05 06:49:46 --> Router Class Initialized
INFO - 2023-06-05 06:49:46 --> Router Class Initialized
INFO - 2023-06-05 06:49:46 --> Output Class Initialized
INFO - 2023-06-05 06:49:46 --> Output Class Initialized
INFO - 2023-06-05 06:49:46 --> Output Class Initialized
INFO - 2023-06-05 06:49:46 --> Security Class Initialized
INFO - 2023-06-05 06:49:46 --> Security Class Initialized
INFO - 2023-06-05 06:49:46 --> Security Class Initialized
DEBUG - 2023-06-05 06:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:49:46 --> Input Class Initialized
INFO - 2023-06-05 06:49:46 --> Input Class Initialized
INFO - 2023-06-05 06:49:46 --> Input Class Initialized
INFO - 2023-06-05 06:49:46 --> Language Class Initialized
INFO - 2023-06-05 06:49:46 --> Language Class Initialized
INFO - 2023-06-05 06:49:46 --> Language Class Initialized
INFO - 2023-06-05 06:49:46 --> Loader Class Initialized
INFO - 2023-06-05 06:49:46 --> Loader Class Initialized
INFO - 2023-06-05 06:49:46 --> Controller Class Initialized
INFO - 2023-06-05 06:49:46 --> Controller Class Initialized
DEBUG - 2023-06-05 06:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:49:46 --> Loader Class Initialized
INFO - 2023-06-05 06:49:46 --> Controller Class Initialized
INFO - 2023-06-05 06:49:46 --> Database Driver Class Initialized
DEBUG - 2023-06-05 06:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:49:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:49:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:49:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:49:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:49:46 --> Final output sent to browser
DEBUG - 2023-06-05 06:49:46 --> Total execution time: 0.2452
INFO - 2023-06-05 06:49:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:49:46 --> Final output sent to browser
DEBUG - 2023-06-05 06:49:46 --> Total execution time: 0.2558
INFO - 2023-06-05 06:49:46 --> Final output sent to browser
DEBUG - 2023-06-05 06:49:46 --> Total execution time: 0.2596
INFO - 2023-06-05 06:49:46 --> Config Class Initialized
INFO - 2023-06-05 06:49:46 --> Config Class Initialized
INFO - 2023-06-05 06:49:46 --> Hooks Class Initialized
INFO - 2023-06-05 06:49:46 --> Hooks Class Initialized
INFO - 2023-06-05 06:49:46 --> Config Class Initialized
DEBUG - 2023-06-05 06:49:46 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:49:46 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:49:46 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:49:46 --> Utf8 Class Initialized
INFO - 2023-06-05 06:49:46 --> Utf8 Class Initialized
INFO - 2023-06-05 06:49:46 --> URI Class Initialized
INFO - 2023-06-05 06:49:46 --> URI Class Initialized
INFO - 2023-06-05 06:49:46 --> Router Class Initialized
INFO - 2023-06-05 06:49:46 --> Router Class Initialized
DEBUG - 2023-06-05 06:49:46 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:49:46 --> Utf8 Class Initialized
INFO - 2023-06-05 06:49:46 --> Output Class Initialized
INFO - 2023-06-05 06:49:46 --> Output Class Initialized
INFO - 2023-06-05 06:49:46 --> Security Class Initialized
INFO - 2023-06-05 06:49:46 --> Security Class Initialized
INFO - 2023-06-05 06:49:46 --> URI Class Initialized
DEBUG - 2023-06-05 06:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:49:46 --> Input Class Initialized
INFO - 2023-06-05 06:49:46 --> Input Class Initialized
INFO - 2023-06-05 06:49:46 --> Router Class Initialized
INFO - 2023-06-05 06:49:46 --> Language Class Initialized
INFO - 2023-06-05 06:49:46 --> Language Class Initialized
INFO - 2023-06-05 06:49:46 --> Output Class Initialized
INFO - 2023-06-05 06:49:46 --> Loader Class Initialized
INFO - 2023-06-05 06:49:46 --> Loader Class Initialized
INFO - 2023-06-05 06:49:46 --> Security Class Initialized
INFO - 2023-06-05 06:49:46 --> Controller Class Initialized
INFO - 2023-06-05 06:49:46 --> Controller Class Initialized
DEBUG - 2023-06-05 06:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:49:46 --> Input Class Initialized
INFO - 2023-06-05 06:49:46 --> Language Class Initialized
INFO - 2023-06-05 06:49:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:49:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:49:46 --> Loader Class Initialized
INFO - 2023-06-05 06:49:46 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:49:46 --> Controller Class Initialized
INFO - 2023-06-05 06:49:46 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 06:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:49:46 --> Final output sent to browser
INFO - 2023-06-05 06:49:46 --> Final output sent to browser
DEBUG - 2023-06-05 06:49:46 --> Total execution time: 0.1849
DEBUG - 2023-06-05 06:49:46 --> Total execution time: 0.1891
INFO - 2023-06-05 06:49:46 --> Database Driver Class Initialized
INFO - 2023-06-05 06:49:47 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:49:47 --> Config Class Initialized
INFO - 2023-06-05 06:49:47 --> Final output sent to browser
INFO - 2023-06-05 06:49:47 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:49:47 --> Total execution time: 0.2500
DEBUG - 2023-06-05 06:49:47 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:49:47 --> Utf8 Class Initialized
INFO - 2023-06-05 06:49:47 --> URI Class Initialized
INFO - 2023-06-05 06:49:47 --> Router Class Initialized
INFO - 2023-06-05 06:49:47 --> Output Class Initialized
INFO - 2023-06-05 06:49:47 --> Security Class Initialized
DEBUG - 2023-06-05 06:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:49:47 --> Input Class Initialized
INFO - 2023-06-05 06:49:47 --> Language Class Initialized
INFO - 2023-06-05 06:49:47 --> Loader Class Initialized
INFO - 2023-06-05 06:49:47 --> Controller Class Initialized
DEBUG - 2023-06-05 06:49:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:49:47 --> Database Driver Class Initialized
INFO - 2023-06-05 06:49:47 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:49:47 --> Config Class Initialized
INFO - 2023-06-05 06:49:47 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:49:47 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:49:47 --> Utf8 Class Initialized
INFO - 2023-06-05 06:49:47 --> URI Class Initialized
INFO - 2023-06-05 06:49:47 --> Router Class Initialized
INFO - 2023-06-05 06:49:47 --> Output Class Initialized
INFO - 2023-06-05 06:49:47 --> Security Class Initialized
DEBUG - 2023-06-05 06:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:49:47 --> Input Class Initialized
INFO - 2023-06-05 06:49:47 --> Language Class Initialized
INFO - 2023-06-05 06:49:47 --> Loader Class Initialized
INFO - 2023-06-05 06:49:47 --> Controller Class Initialized
DEBUG - 2023-06-05 06:49:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:49:47 --> Database Driver Class Initialized
INFO - 2023-06-05 06:49:47 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:53:09 --> Config Class Initialized
INFO - 2023-06-05 06:53:09 --> Config Class Initialized
INFO - 2023-06-05 06:53:09 --> Config Class Initialized
INFO - 2023-06-05 06:53:09 --> Hooks Class Initialized
INFO - 2023-06-05 06:53:09 --> Hooks Class Initialized
INFO - 2023-06-05 06:53:09 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:53:09 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:53:09 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:53:09 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:53:09 --> Utf8 Class Initialized
INFO - 2023-06-05 06:53:09 --> Utf8 Class Initialized
INFO - 2023-06-05 06:53:09 --> Utf8 Class Initialized
INFO - 2023-06-05 06:53:09 --> URI Class Initialized
INFO - 2023-06-05 06:53:09 --> URI Class Initialized
INFO - 2023-06-05 06:53:09 --> URI Class Initialized
INFO - 2023-06-05 06:53:09 --> Router Class Initialized
INFO - 2023-06-05 06:53:09 --> Router Class Initialized
INFO - 2023-06-05 06:53:09 --> Router Class Initialized
INFO - 2023-06-05 06:53:09 --> Output Class Initialized
INFO - 2023-06-05 06:53:09 --> Output Class Initialized
INFO - 2023-06-05 06:53:09 --> Output Class Initialized
INFO - 2023-06-05 06:53:09 --> Security Class Initialized
INFO - 2023-06-05 06:53:09 --> Security Class Initialized
INFO - 2023-06-05 06:53:09 --> Security Class Initialized
DEBUG - 2023-06-05 06:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:53:09 --> Input Class Initialized
INFO - 2023-06-05 06:53:09 --> Input Class Initialized
INFO - 2023-06-05 06:53:09 --> Input Class Initialized
INFO - 2023-06-05 06:53:10 --> Language Class Initialized
INFO - 2023-06-05 06:53:10 --> Language Class Initialized
INFO - 2023-06-05 06:53:10 --> Language Class Initialized
INFO - 2023-06-05 06:53:10 --> Loader Class Initialized
INFO - 2023-06-05 06:53:10 --> Loader Class Initialized
INFO - 2023-06-05 06:53:10 --> Controller Class Initialized
INFO - 2023-06-05 06:53:10 --> Loader Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:53:10 --> Controller Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:53:10 --> Controller Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:53:10 --> Database Driver Class Initialized
INFO - 2023-06-05 06:53:10 --> Database Driver Class Initialized
INFO - 2023-06-05 06:53:10 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:53:10 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:53:10 --> Database Driver Class Initialized
INFO - 2023-06-05 06:53:10 --> Final output sent to browser
INFO - 2023-06-05 06:53:10 --> Final output sent to browser
DEBUG - 2023-06-05 06:53:10 --> Total execution time: 0.2513
DEBUG - 2023-06-05 06:53:10 --> Total execution time: 0.2521
INFO - 2023-06-05 06:53:10 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:53:10 --> Final output sent to browser
DEBUG - 2023-06-05 06:53:10 --> Total execution time: 0.2750
INFO - 2023-06-05 06:53:10 --> Config Class Initialized
INFO - 2023-06-05 06:53:10 --> Config Class Initialized
INFO - 2023-06-05 06:53:10 --> Hooks Class Initialized
INFO - 2023-06-05 06:53:10 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:53:10 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 06:53:10 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:53:10 --> Utf8 Class Initialized
INFO - 2023-06-05 06:53:10 --> Utf8 Class Initialized
INFO - 2023-06-05 06:53:10 --> URI Class Initialized
INFO - 2023-06-05 06:53:10 --> Config Class Initialized
INFO - 2023-06-05 06:53:10 --> URI Class Initialized
INFO - 2023-06-05 06:53:10 --> Hooks Class Initialized
INFO - 2023-06-05 06:53:10 --> Router Class Initialized
INFO - 2023-06-05 06:53:10 --> Router Class Initialized
INFO - 2023-06-05 06:53:10 --> Output Class Initialized
INFO - 2023-06-05 06:53:10 --> Output Class Initialized
INFO - 2023-06-05 06:53:10 --> Security Class Initialized
DEBUG - 2023-06-05 06:53:10 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:53:10 --> Security Class Initialized
INFO - 2023-06-05 06:53:10 --> Utf8 Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 06:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:53:10 --> Input Class Initialized
INFO - 2023-06-05 06:53:10 --> Input Class Initialized
INFO - 2023-06-05 06:53:10 --> URI Class Initialized
INFO - 2023-06-05 06:53:10 --> Language Class Initialized
INFO - 2023-06-05 06:53:10 --> Language Class Initialized
INFO - 2023-06-05 06:53:10 --> Router Class Initialized
INFO - 2023-06-05 06:53:10 --> Loader Class Initialized
INFO - 2023-06-05 06:53:10 --> Loader Class Initialized
INFO - 2023-06-05 06:53:10 --> Controller Class Initialized
INFO - 2023-06-05 06:53:10 --> Controller Class Initialized
INFO - 2023-06-05 06:53:10 --> Output Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 06:53:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:53:10 --> Security Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:53:10 --> Input Class Initialized
INFO - 2023-06-05 06:53:10 --> Language Class Initialized
INFO - 2023-06-05 06:53:10 --> Database Driver Class Initialized
INFO - 2023-06-05 06:53:10 --> Database Driver Class Initialized
INFO - 2023-06-05 06:53:10 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:53:10 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:53:10 --> Loader Class Initialized
INFO - 2023-06-05 06:53:10 --> Final output sent to browser
INFO - 2023-06-05 06:53:10 --> Final output sent to browser
DEBUG - 2023-06-05 06:53:10 --> Total execution time: 0.2467
DEBUG - 2023-06-05 06:53:10 --> Total execution time: 0.2476
INFO - 2023-06-05 06:53:10 --> Controller Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:53:10 --> Database Driver Class Initialized
INFO - 2023-06-05 06:53:10 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:53:10 --> Config Class Initialized
INFO - 2023-06-05 06:53:10 --> Hooks Class Initialized
INFO - 2023-06-05 06:53:10 --> Final output sent to browser
DEBUG - 2023-06-05 06:53:10 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:53:10 --> Utf8 Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Total execution time: 0.3230
INFO - 2023-06-05 06:53:10 --> URI Class Initialized
INFO - 2023-06-05 06:53:10 --> Router Class Initialized
INFO - 2023-06-05 06:53:10 --> Output Class Initialized
INFO - 2023-06-05 06:53:10 --> Security Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:53:10 --> Input Class Initialized
INFO - 2023-06-05 06:53:10 --> Language Class Initialized
INFO - 2023-06-05 06:53:10 --> Loader Class Initialized
INFO - 2023-06-05 06:53:10 --> Controller Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:53:10 --> Database Driver Class Initialized
INFO - 2023-06-05 06:53:10 --> Model "Cluster_model" initialized
INFO - 2023-06-05 06:53:10 --> Config Class Initialized
INFO - 2023-06-05 06:53:10 --> Hooks Class Initialized
DEBUG - 2023-06-05 06:53:10 --> UTF-8 Support Enabled
INFO - 2023-06-05 06:53:10 --> Utf8 Class Initialized
INFO - 2023-06-05 06:53:10 --> URI Class Initialized
INFO - 2023-06-05 06:53:10 --> Router Class Initialized
INFO - 2023-06-05 06:53:10 --> Output Class Initialized
INFO - 2023-06-05 06:53:10 --> Security Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 06:53:10 --> Input Class Initialized
INFO - 2023-06-05 06:53:10 --> Language Class Initialized
INFO - 2023-06-05 06:53:10 --> Loader Class Initialized
INFO - 2023-06-05 06:53:10 --> Controller Class Initialized
DEBUG - 2023-06-05 06:53:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 06:53:10 --> Database Driver Class Initialized
INFO - 2023-06-05 06:53:10 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:00:22 --> Config Class Initialized
INFO - 2023-06-05 07:00:22 --> Config Class Initialized
INFO - 2023-06-05 07:00:22 --> Hooks Class Initialized
INFO - 2023-06-05 07:00:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:00:22 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:00:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:00:22 --> Config Class Initialized
INFO - 2023-06-05 07:00:22 --> Utf8 Class Initialized
INFO - 2023-06-05 07:00:22 --> Utf8 Class Initialized
INFO - 2023-06-05 07:00:22 --> Hooks Class Initialized
INFO - 2023-06-05 07:00:22 --> URI Class Initialized
INFO - 2023-06-05 07:00:22 --> URI Class Initialized
INFO - 2023-06-05 07:00:22 --> Router Class Initialized
INFO - 2023-06-05 07:00:22 --> Router Class Initialized
INFO - 2023-06-05 07:00:22 --> Output Class Initialized
INFO - 2023-06-05 07:00:22 --> Output Class Initialized
DEBUG - 2023-06-05 07:00:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:00:22 --> Utf8 Class Initialized
INFO - 2023-06-05 07:00:22 --> Security Class Initialized
INFO - 2023-06-05 07:00:22 --> Security Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:00:22 --> URI Class Initialized
INFO - 2023-06-05 07:00:22 --> Input Class Initialized
INFO - 2023-06-05 07:00:22 --> Input Class Initialized
INFO - 2023-06-05 07:00:22 --> Language Class Initialized
INFO - 2023-06-05 07:00:22 --> Language Class Initialized
INFO - 2023-06-05 07:00:22 --> Router Class Initialized
INFO - 2023-06-05 07:00:22 --> Loader Class Initialized
INFO - 2023-06-05 07:00:22 --> Output Class Initialized
INFO - 2023-06-05 07:00:22 --> Loader Class Initialized
INFO - 2023-06-05 07:00:22 --> Security Class Initialized
INFO - 2023-06-05 07:00:22 --> Controller Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:00:22 --> Input Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:00:22 --> Controller Class Initialized
INFO - 2023-06-05 07:00:22 --> Language Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:00:22 --> Loader Class Initialized
INFO - 2023-06-05 07:00:22 --> Database Driver Class Initialized
INFO - 2023-06-05 07:00:22 --> Database Driver Class Initialized
INFO - 2023-06-05 07:00:22 --> Controller Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:00:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:00:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:00:22 --> Final output sent to browser
DEBUG - 2023-06-05 07:00:22 --> Total execution time: 0.3249
INFO - 2023-06-05 07:00:22 --> Final output sent to browser
DEBUG - 2023-06-05 07:00:22 --> Total execution time: 0.3445
INFO - 2023-06-05 07:00:22 --> Database Driver Class Initialized
INFO - 2023-06-05 07:00:22 --> Config Class Initialized
INFO - 2023-06-05 07:00:22 --> Config Class Initialized
INFO - 2023-06-05 07:00:22 --> Hooks Class Initialized
INFO - 2023-06-05 07:00:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:00:22 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:00:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:00:22 --> Utf8 Class Initialized
INFO - 2023-06-05 07:00:22 --> Utf8 Class Initialized
INFO - 2023-06-05 07:00:22 --> URI Class Initialized
INFO - 2023-06-05 07:00:22 --> URI Class Initialized
INFO - 2023-06-05 07:00:22 --> Router Class Initialized
INFO - 2023-06-05 07:00:22 --> Router Class Initialized
INFO - 2023-06-05 07:00:22 --> Output Class Initialized
INFO - 2023-06-05 07:00:22 --> Output Class Initialized
INFO - 2023-06-05 07:00:22 --> Security Class Initialized
INFO - 2023-06-05 07:00:22 --> Security Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:00:22 --> Input Class Initialized
INFO - 2023-06-05 07:00:22 --> Input Class Initialized
INFO - 2023-06-05 07:00:22 --> Language Class Initialized
INFO - 2023-06-05 07:00:22 --> Language Class Initialized
INFO - 2023-06-05 07:00:22 --> Loader Class Initialized
INFO - 2023-06-05 07:00:22 --> Controller Class Initialized
INFO - 2023-06-05 07:00:22 --> Loader Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:00:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:00:22 --> Controller Class Initialized
INFO - 2023-06-05 07:00:22 --> Final output sent to browser
DEBUG - 2023-06-05 07:00:22 --> Total execution time: 0.5569
DEBUG - 2023-06-05 07:00:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:00:22 --> Database Driver Class Initialized
INFO - 2023-06-05 07:00:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:00:22 --> Database Driver Class Initialized
INFO - 2023-06-05 07:00:22 --> Final output sent to browser
DEBUG - 2023-06-05 07:00:22 --> Total execution time: 0.2381
INFO - 2023-06-05 07:00:22 --> Config Class Initialized
INFO - 2023-06-05 07:00:22 --> Hooks Class Initialized
INFO - 2023-06-05 07:00:22 --> Model "Cluster_model" initialized
DEBUG - 2023-06-05 07:00:22 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:00:22 --> Utf8 Class Initialized
INFO - 2023-06-05 07:00:22 --> Final output sent to browser
INFO - 2023-06-05 07:00:22 --> URI Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Total execution time: 0.2959
INFO - 2023-06-05 07:00:22 --> Router Class Initialized
INFO - 2023-06-05 07:00:22 --> Output Class Initialized
INFO - 2023-06-05 07:00:22 --> Security Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:00:22 --> Input Class Initialized
INFO - 2023-06-05 07:00:22 --> Language Class Initialized
INFO - 2023-06-05 07:00:22 --> Loader Class Initialized
INFO - 2023-06-05 07:00:22 --> Controller Class Initialized
DEBUG - 2023-06-05 07:00:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:00:22 --> Database Driver Class Initialized
INFO - 2023-06-05 07:00:22 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:00:22 --> Final output sent to browser
DEBUG - 2023-06-05 07:00:22 --> Total execution time: 0.2383
INFO - 2023-06-05 07:00:22 --> Config Class Initialized
INFO - 2023-06-05 07:00:22 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:00:23 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:00:23 --> Utf8 Class Initialized
INFO - 2023-06-05 07:00:23 --> URI Class Initialized
INFO - 2023-06-05 07:00:23 --> Router Class Initialized
INFO - 2023-06-05 07:00:23 --> Output Class Initialized
INFO - 2023-06-05 07:00:23 --> Security Class Initialized
DEBUG - 2023-06-05 07:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:00:23 --> Input Class Initialized
INFO - 2023-06-05 07:00:23 --> Language Class Initialized
INFO - 2023-06-05 07:00:23 --> Loader Class Initialized
INFO - 2023-06-05 07:00:23 --> Controller Class Initialized
DEBUG - 2023-06-05 07:00:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:00:23 --> Database Driver Class Initialized
INFO - 2023-06-05 07:00:23 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:00:23 --> Config Class Initialized
INFO - 2023-06-05 07:00:23 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:00:23 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:00:23 --> Utf8 Class Initialized
INFO - 2023-06-05 07:00:23 --> URI Class Initialized
INFO - 2023-06-05 07:00:23 --> Router Class Initialized
INFO - 2023-06-05 07:00:23 --> Output Class Initialized
INFO - 2023-06-05 07:00:23 --> Security Class Initialized
DEBUG - 2023-06-05 07:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:00:23 --> Input Class Initialized
INFO - 2023-06-05 07:00:23 --> Language Class Initialized
INFO - 2023-06-05 07:00:23 --> Loader Class Initialized
INFO - 2023-06-05 07:00:23 --> Controller Class Initialized
DEBUG - 2023-06-05 07:00:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:00:23 --> Database Driver Class Initialized
INFO - 2023-06-05 07:00:23 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:19 --> Config Class Initialized
INFO - 2023-06-05 07:05:19 --> Config Class Initialized
INFO - 2023-06-05 07:05:19 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:19 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:19 --> Config Class Initialized
DEBUG - 2023-06-05 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:05:19 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:19 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:19 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:19 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:19 --> URI Class Initialized
INFO - 2023-06-05 07:05:19 --> URI Class Initialized
INFO - 2023-06-05 07:05:19 --> Router Class Initialized
INFO - 2023-06-05 07:05:19 --> Router Class Initialized
INFO - 2023-06-05 07:05:19 --> Output Class Initialized
INFO - 2023-06-05 07:05:19 --> Output Class Initialized
DEBUG - 2023-06-05 07:05:19 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:19 --> Security Class Initialized
INFO - 2023-06-05 07:05:19 --> Security Class Initialized
INFO - 2023-06-05 07:05:19 --> Utf8 Class Initialized
DEBUG - 2023-06-05 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:19 --> URI Class Initialized
INFO - 2023-06-05 07:05:19 --> Input Class Initialized
INFO - 2023-06-05 07:05:19 --> Input Class Initialized
INFO - 2023-06-05 07:05:19 --> Language Class Initialized
INFO - 2023-06-05 07:05:19 --> Language Class Initialized
INFO - 2023-06-05 07:05:19 --> Router Class Initialized
INFO - 2023-06-05 07:05:19 --> Loader Class Initialized
INFO - 2023-06-05 07:05:19 --> Loader Class Initialized
INFO - 2023-06-05 07:05:19 --> Output Class Initialized
INFO - 2023-06-05 07:05:19 --> Controller Class Initialized
INFO - 2023-06-05 07:05:19 --> Controller Class Initialized
INFO - 2023-06-05 07:05:19 --> Security Class Initialized
DEBUG - 2023-06-05 07:05:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 07:05:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:19 --> Input Class Initialized
INFO - 2023-06-05 07:05:19 --> Language Class Initialized
INFO - 2023-06-05 07:05:19 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:19 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:19 --> Loader Class Initialized
INFO - 2023-06-05 07:05:19 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:19 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:19 --> Final output sent to browser
INFO - 2023-06-05 07:05:19 --> Controller Class Initialized
INFO - 2023-06-05 07:05:19 --> Final output sent to browser
DEBUG - 2023-06-05 07:05:19 --> Total execution time: 0.3338
DEBUG - 2023-06-05 07:05:19 --> Total execution time: 0.3321
DEBUG - 2023-06-05 07:05:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:19 --> Config Class Initialized
INFO - 2023-06-05 07:05:19 --> Config Class Initialized
INFO - 2023-06-05 07:05:19 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:19 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:05:19 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:19 --> Database Driver Class Initialized
DEBUG - 2023-06-05 07:05:19 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:19 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:19 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:19 --> URI Class Initialized
INFO - 2023-06-05 07:05:19 --> URI Class Initialized
INFO - 2023-06-05 07:05:19 --> Router Class Initialized
INFO - 2023-06-05 07:05:19 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.5367
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.2144
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.2172
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.1992
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.1860
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.1840
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.2006
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.2079
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.2175
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
INFO - 2023-06-05 07:05:20 --> Final output sent to browser
DEBUG - 2023-06-05 07:05:20 --> Total execution time: 0.2923
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:20 --> Security Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:20 --> Input Class Initialized
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Language Class Initialized
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:20 --> Loader Class Initialized
INFO - 2023-06-05 07:05:20 --> Controller Class Initialized
DEBUG - 2023-06-05 07:05:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:20 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:20 --> Config Class Initialized
INFO - 2023-06-05 07:05:20 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:05:20 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:20 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:20 --> URI Class Initialized
INFO - 2023-06-05 07:05:20 --> Router Class Initialized
INFO - 2023-06-05 07:05:20 --> Output Class Initialized
INFO - 2023-06-05 07:05:21 --> Security Class Initialized
DEBUG - 2023-06-05 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:21 --> Input Class Initialized
INFO - 2023-06-05 07:05:21 --> Language Class Initialized
INFO - 2023-06-05 07:05:21 --> Loader Class Initialized
INFO - 2023-06-05 07:05:21 --> Controller Class Initialized
DEBUG - 2023-06-05 07:05:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:21 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:21 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:05:21 --> Config Class Initialized
INFO - 2023-06-05 07:05:21 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:05:21 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:05:21 --> Utf8 Class Initialized
INFO - 2023-06-05 07:05:21 --> URI Class Initialized
INFO - 2023-06-05 07:05:21 --> Router Class Initialized
INFO - 2023-06-05 07:05:21 --> Output Class Initialized
INFO - 2023-06-05 07:05:21 --> Security Class Initialized
DEBUG - 2023-06-05 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:05:21 --> Input Class Initialized
INFO - 2023-06-05 07:05:21 --> Language Class Initialized
INFO - 2023-06-05 07:05:21 --> Loader Class Initialized
INFO - 2023-06-05 07:05:21 --> Controller Class Initialized
DEBUG - 2023-06-05 07:05:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:05:21 --> Database Driver Class Initialized
INFO - 2023-06-05 07:05:21 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:39:34 --> Config Class Initialized
INFO - 2023-06-05 07:39:34 --> Config Class Initialized
INFO - 2023-06-05 07:39:34 --> Config Class Initialized
INFO - 2023-06-05 07:39:34 --> Hooks Class Initialized
INFO - 2023-06-05 07:39:34 --> Hooks Class Initialized
INFO - 2023-06-05 07:39:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:39:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:39:34 --> Utf8 Class Initialized
INFO - 2023-06-05 07:39:34 --> Utf8 Class Initialized
INFO - 2023-06-05 07:39:34 --> Utf8 Class Initialized
INFO - 2023-06-05 07:39:34 --> URI Class Initialized
INFO - 2023-06-05 07:39:34 --> URI Class Initialized
INFO - 2023-06-05 07:39:34 --> URI Class Initialized
INFO - 2023-06-05 07:39:34 --> Router Class Initialized
INFO - 2023-06-05 07:39:34 --> Router Class Initialized
INFO - 2023-06-05 07:39:34 --> Router Class Initialized
INFO - 2023-06-05 07:39:34 --> Output Class Initialized
INFO - 2023-06-05 07:39:34 --> Output Class Initialized
INFO - 2023-06-05 07:39:34 --> Output Class Initialized
INFO - 2023-06-05 07:39:34 --> Security Class Initialized
INFO - 2023-06-05 07:39:34 --> Security Class Initialized
INFO - 2023-06-05 07:39:34 --> Security Class Initialized
DEBUG - 2023-06-05 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:39:34 --> Input Class Initialized
INFO - 2023-06-05 07:39:34 --> Input Class Initialized
INFO - 2023-06-05 07:39:34 --> Input Class Initialized
INFO - 2023-06-05 07:39:34 --> Language Class Initialized
INFO - 2023-06-05 07:39:34 --> Language Class Initialized
INFO - 2023-06-05 07:39:34 --> Language Class Initialized
INFO - 2023-06-05 07:39:34 --> Loader Class Initialized
INFO - 2023-06-05 07:39:34 --> Loader Class Initialized
INFO - 2023-06-05 07:39:34 --> Controller Class Initialized
INFO - 2023-06-05 07:39:34 --> Controller Class Initialized
INFO - 2023-06-05 07:39:34 --> Loader Class Initialized
DEBUG - 2023-06-05 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:39:34 --> Controller Class Initialized
DEBUG - 2023-06-05 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:39:34 --> Database Driver Class Initialized
INFO - 2023-06-05 07:39:34 --> Database Driver Class Initialized
INFO - 2023-06-05 07:39:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:39:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:39:34 --> Database Driver Class Initialized
INFO - 2023-06-05 07:39:34 --> Final output sent to browser
INFO - 2023-06-05 07:39:34 --> Final output sent to browser
DEBUG - 2023-06-05 07:39:34 --> Total execution time: 0.2298
DEBUG - 2023-06-05 07:39:34 --> Total execution time: 0.2303
INFO - 2023-06-05 07:39:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:39:34 --> Final output sent to browser
DEBUG - 2023-06-05 07:39:34 --> Total execution time: 0.2363
INFO - 2023-06-05 07:39:34 --> Config Class Initialized
INFO - 2023-06-05 07:39:34 --> Config Class Initialized
INFO - 2023-06-05 07:39:34 --> Hooks Class Initialized
INFO - 2023-06-05 07:39:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2023-06-05 07:39:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:39:34 --> Config Class Initialized
INFO - 2023-06-05 07:39:34 --> Utf8 Class Initialized
INFO - 2023-06-05 07:39:34 --> Utf8 Class Initialized
INFO - 2023-06-05 07:39:34 --> Hooks Class Initialized
INFO - 2023-06-05 07:39:34 --> URI Class Initialized
INFO - 2023-06-05 07:39:34 --> URI Class Initialized
INFO - 2023-06-05 07:39:34 --> Router Class Initialized
INFO - 2023-06-05 07:39:34 --> Router Class Initialized
DEBUG - 2023-06-05 07:39:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:39:34 --> Utf8 Class Initialized
INFO - 2023-06-05 07:39:34 --> Output Class Initialized
INFO - 2023-06-05 07:39:34 --> Output Class Initialized
INFO - 2023-06-05 07:39:34 --> Security Class Initialized
INFO - 2023-06-05 07:39:34 --> URI Class Initialized
INFO - 2023-06-05 07:39:34 --> Security Class Initialized
DEBUG - 2023-06-05 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:39:34 --> Input Class Initialized
INFO - 2023-06-05 07:39:34 --> Input Class Initialized
INFO - 2023-06-05 07:39:34 --> Language Class Initialized
INFO - 2023-06-05 07:39:34 --> Language Class Initialized
INFO - 2023-06-05 07:39:34 --> Router Class Initialized
INFO - 2023-06-05 07:39:34 --> Output Class Initialized
INFO - 2023-06-05 07:39:34 --> Loader Class Initialized
INFO - 2023-06-05 07:39:34 --> Loader Class Initialized
INFO - 2023-06-05 07:39:34 --> Security Class Initialized
INFO - 2023-06-05 07:39:34 --> Controller Class Initialized
INFO - 2023-06-05 07:39:34 --> Controller Class Initialized
DEBUG - 2023-06-05 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-06-05 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-06-05 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:39:34 --> Input Class Initialized
INFO - 2023-06-05 07:39:34 --> Language Class Initialized
INFO - 2023-06-05 07:39:34 --> Database Driver Class Initialized
INFO - 2023-06-05 07:39:34 --> Database Driver Class Initialized
INFO - 2023-06-05 07:39:34 --> Loader Class Initialized
INFO - 2023-06-05 07:39:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:39:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:39:34 --> Controller Class Initialized
DEBUG - 2023-06-05 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:39:34 --> Final output sent to browser
INFO - 2023-06-05 07:39:34 --> Final output sent to browser
DEBUG - 2023-06-05 07:39:34 --> Total execution time: 0.1820
DEBUG - 2023-06-05 07:39:34 --> Total execution time: 0.1815
INFO - 2023-06-05 07:39:34 --> Database Driver Class Initialized
INFO - 2023-06-05 07:39:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:39:34 --> Final output sent to browser
DEBUG - 2023-06-05 07:39:34 --> Total execution time: 0.2335
INFO - 2023-06-05 07:39:34 --> Config Class Initialized
INFO - 2023-06-05 07:39:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:39:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:39:34 --> Utf8 Class Initialized
INFO - 2023-06-05 07:39:34 --> URI Class Initialized
INFO - 2023-06-05 07:39:34 --> Router Class Initialized
INFO - 2023-06-05 07:39:34 --> Output Class Initialized
INFO - 2023-06-05 07:39:34 --> Security Class Initialized
DEBUG - 2023-06-05 07:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:39:34 --> Input Class Initialized
INFO - 2023-06-05 07:39:34 --> Language Class Initialized
INFO - 2023-06-05 07:39:34 --> Loader Class Initialized
INFO - 2023-06-05 07:39:34 --> Controller Class Initialized
DEBUG - 2023-06-05 07:39:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:39:34 --> Database Driver Class Initialized
INFO - 2023-06-05 07:39:34 --> Model "Cluster_model" initialized
INFO - 2023-06-05 07:39:34 --> Config Class Initialized
INFO - 2023-06-05 07:39:34 --> Hooks Class Initialized
DEBUG - 2023-06-05 07:39:34 --> UTF-8 Support Enabled
INFO - 2023-06-05 07:39:34 --> Utf8 Class Initialized
INFO - 2023-06-05 07:39:34 --> URI Class Initialized
INFO - 2023-06-05 07:39:34 --> Router Class Initialized
INFO - 2023-06-05 07:39:34 --> Output Class Initialized
INFO - 2023-06-05 07:39:35 --> Security Class Initialized
DEBUG - 2023-06-05 07:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-05 07:39:35 --> Input Class Initialized
INFO - 2023-06-05 07:39:35 --> Language Class Initialized
INFO - 2023-06-05 07:39:35 --> Loader Class Initialized
INFO - 2023-06-05 07:39:35 --> Controller Class Initialized
DEBUG - 2023-06-05 07:39:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-06-05 07:39:35 --> Database Driver Class Initialized
INFO - 2023-06-05 07:39:35 --> Model "Cluster_model" initialized
