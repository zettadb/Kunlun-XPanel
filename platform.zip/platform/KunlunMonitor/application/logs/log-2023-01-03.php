<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-03 01:38:24 --> Config Class Initialized
INFO - 2023-01-03 01:38:24 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:24 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:24 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:24 --> URI Class Initialized
INFO - 2023-01-03 01:38:24 --> Router Class Initialized
INFO - 2023-01-03 01:38:24 --> Output Class Initialized
INFO - 2023-01-03 01:38:24 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:24 --> Input Class Initialized
INFO - 2023-01-03 01:38:24 --> Language Class Initialized
INFO - 2023-01-03 01:38:25 --> Loader Class Initialized
INFO - 2023-01-03 01:38:25 --> Controller Class Initialized
INFO - 2023-01-03 01:38:25 --> Helper loaded: form_helper
INFO - 2023-01-03 01:38:25 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:38:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:25 --> Model "Change_model" initialized
INFO - 2023-01-03 01:38:26 --> Model "Grafana_model" initialized
INFO - 2023-01-03 01:38:26 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:26 --> Total execution time: 1.2963
INFO - 2023-01-03 01:38:26 --> Config Class Initialized
INFO - 2023-01-03 01:38:26 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:26 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:26 --> URI Class Initialized
INFO - 2023-01-03 01:38:26 --> Router Class Initialized
INFO - 2023-01-03 01:38:26 --> Output Class Initialized
INFO - 2023-01-03 01:38:26 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:26 --> Input Class Initialized
INFO - 2023-01-03 01:38:26 --> Language Class Initialized
INFO - 2023-01-03 01:38:26 --> Loader Class Initialized
INFO - 2023-01-03 01:38:26 --> Controller Class Initialized
INFO - 2023-01-03 01:38:26 --> Helper loaded: form_helper
INFO - 2023-01-03 01:38:26 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:38:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:26 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:26 --> Total execution time: 0.1489
INFO - 2023-01-03 01:38:26 --> Config Class Initialized
INFO - 2023-01-03 01:38:26 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:26 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:26 --> URI Class Initialized
INFO - 2023-01-03 01:38:26 --> Router Class Initialized
INFO - 2023-01-03 01:38:26 --> Output Class Initialized
INFO - 2023-01-03 01:38:26 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:26 --> Input Class Initialized
INFO - 2023-01-03 01:38:26 --> Language Class Initialized
INFO - 2023-01-03 01:38:26 --> Loader Class Initialized
INFO - 2023-01-03 01:38:26 --> Controller Class Initialized
INFO - 2023-01-03 01:38:26 --> Helper loaded: form_helper
INFO - 2023-01-03 01:38:26 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:38:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:26 --> Database Driver Class Initialized
INFO - 2023-01-03 01:38:26 --> Model "Login_model" initialized
INFO - 2023-01-03 01:38:26 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:26 --> Total execution time: 0.1748
INFO - 2023-01-03 01:38:26 --> Config Class Initialized
INFO - 2023-01-03 01:38:26 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:26 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:26 --> URI Class Initialized
INFO - 2023-01-03 01:38:26 --> Router Class Initialized
INFO - 2023-01-03 01:38:26 --> Output Class Initialized
INFO - 2023-01-03 01:38:26 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:26 --> Input Class Initialized
INFO - 2023-01-03 01:38:26 --> Language Class Initialized
INFO - 2023-01-03 01:38:26 --> Loader Class Initialized
INFO - 2023-01-03 01:38:26 --> Controller Class Initialized
DEBUG - 2023-01-03 01:38:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:26 --> Database Driver Class Initialized
INFO - 2023-01-03 01:38:26 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:38:26 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:26 --> Total execution time: 0.1466
INFO - 2023-01-03 01:38:26 --> Config Class Initialized
INFO - 2023-01-03 01:38:26 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:26 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:26 --> URI Class Initialized
INFO - 2023-01-03 01:38:26 --> Router Class Initialized
INFO - 2023-01-03 01:38:26 --> Output Class Initialized
INFO - 2023-01-03 01:38:26 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:26 --> Input Class Initialized
INFO - 2023-01-03 01:38:26 --> Language Class Initialized
INFO - 2023-01-03 01:38:26 --> Loader Class Initialized
INFO - 2023-01-03 01:38:26 --> Controller Class Initialized
DEBUG - 2023-01-03 01:38:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:26 --> Database Driver Class Initialized
INFO - 2023-01-03 01:38:26 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:38:30 --> Config Class Initialized
INFO - 2023-01-03 01:38:30 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:30 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:30 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:30 --> URI Class Initialized
INFO - 2023-01-03 01:38:30 --> Router Class Initialized
INFO - 2023-01-03 01:38:30 --> Output Class Initialized
INFO - 2023-01-03 01:38:30 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:30 --> Input Class Initialized
INFO - 2023-01-03 01:38:30 --> Language Class Initialized
INFO - 2023-01-03 01:38:30 --> Loader Class Initialized
INFO - 2023-01-03 01:38:30 --> Controller Class Initialized
INFO - 2023-01-03 01:38:30 --> Helper loaded: form_helper
INFO - 2023-01-03 01:38:30 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:38:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:30 --> Model "Change_model" initialized
INFO - 2023-01-03 01:38:30 --> Model "Grafana_model" initialized
INFO - 2023-01-03 01:38:30 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:30 --> Total execution time: 0.1540
INFO - 2023-01-03 01:38:30 --> Config Class Initialized
INFO - 2023-01-03 01:38:30 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:31 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:31 --> URI Class Initialized
INFO - 2023-01-03 01:38:31 --> Router Class Initialized
INFO - 2023-01-03 01:38:31 --> Output Class Initialized
INFO - 2023-01-03 01:38:31 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:31 --> Input Class Initialized
INFO - 2023-01-03 01:38:31 --> Language Class Initialized
INFO - 2023-01-03 01:38:31 --> Loader Class Initialized
INFO - 2023-01-03 01:38:31 --> Controller Class Initialized
INFO - 2023-01-03 01:38:31 --> Helper loaded: form_helper
INFO - 2023-01-03 01:38:31 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:38:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:31 --> Database Driver Class Initialized
INFO - 2023-01-03 01:38:31 --> Model "Login_model" initialized
INFO - 2023-01-03 01:38:31 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:31 --> Total execution time: 0.1611
INFO - 2023-01-03 01:38:31 --> Config Class Initialized
INFO - 2023-01-03 01:38:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:31 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:31 --> URI Class Initialized
INFO - 2023-01-03 01:38:31 --> Router Class Initialized
INFO - 2023-01-03 01:38:31 --> Output Class Initialized
INFO - 2023-01-03 01:38:31 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:31 --> Input Class Initialized
INFO - 2023-01-03 01:38:31 --> Language Class Initialized
INFO - 2023-01-03 01:38:31 --> Loader Class Initialized
INFO - 2023-01-03 01:38:31 --> Controller Class Initialized
DEBUG - 2023-01-03 01:38:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:31 --> Database Driver Class Initialized
INFO - 2023-01-03 01:38:31 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:38:52 --> Config Class Initialized
INFO - 2023-01-03 01:38:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:52 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:52 --> URI Class Initialized
INFO - 2023-01-03 01:38:52 --> Router Class Initialized
INFO - 2023-01-03 01:38:52 --> Output Class Initialized
INFO - 2023-01-03 01:38:52 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:52 --> Input Class Initialized
INFO - 2023-01-03 01:38:52 --> Language Class Initialized
INFO - 2023-01-03 01:38:52 --> Loader Class Initialized
INFO - 2023-01-03 01:38:52 --> Controller Class Initialized
INFO - 2023-01-03 01:38:52 --> Helper loaded: form_helper
INFO - 2023-01-03 01:38:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:38:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:52 --> Model "Change_model" initialized
INFO - 2023-01-03 01:38:52 --> Model "Grafana_model" initialized
INFO - 2023-01-03 01:38:52 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:52 --> Total execution time: 0.2540
INFO - 2023-01-03 01:38:52 --> Config Class Initialized
INFO - 2023-01-03 01:38:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:52 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:52 --> URI Class Initialized
INFO - 2023-01-03 01:38:52 --> Router Class Initialized
INFO - 2023-01-03 01:38:52 --> Output Class Initialized
INFO - 2023-01-03 01:38:52 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:52 --> Input Class Initialized
INFO - 2023-01-03 01:38:52 --> Language Class Initialized
INFO - 2023-01-03 01:38:52 --> Loader Class Initialized
INFO - 2023-01-03 01:38:52 --> Controller Class Initialized
INFO - 2023-01-03 01:38:52 --> Helper loaded: form_helper
INFO - 2023-01-03 01:38:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:38:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:52 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:52 --> Total execution time: 0.1178
INFO - 2023-01-03 01:38:52 --> Config Class Initialized
INFO - 2023-01-03 01:38:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:52 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:52 --> URI Class Initialized
INFO - 2023-01-03 01:38:52 --> Router Class Initialized
INFO - 2023-01-03 01:38:52 --> Output Class Initialized
INFO - 2023-01-03 01:38:52 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:52 --> Input Class Initialized
INFO - 2023-01-03 01:38:52 --> Language Class Initialized
INFO - 2023-01-03 01:38:52 --> Loader Class Initialized
INFO - 2023-01-03 01:38:52 --> Controller Class Initialized
INFO - 2023-01-03 01:38:52 --> Helper loaded: form_helper
INFO - 2023-01-03 01:38:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:38:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:52 --> Database Driver Class Initialized
INFO - 2023-01-03 01:38:52 --> Model "Login_model" initialized
INFO - 2023-01-03 01:38:52 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:52 --> Total execution time: 0.1646
INFO - 2023-01-03 01:38:52 --> Config Class Initialized
INFO - 2023-01-03 01:38:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:52 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:52 --> URI Class Initialized
INFO - 2023-01-03 01:38:52 --> Router Class Initialized
INFO - 2023-01-03 01:38:52 --> Output Class Initialized
INFO - 2023-01-03 01:38:52 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:52 --> Input Class Initialized
INFO - 2023-01-03 01:38:52 --> Language Class Initialized
INFO - 2023-01-03 01:38:52 --> Loader Class Initialized
INFO - 2023-01-03 01:38:52 --> Controller Class Initialized
DEBUG - 2023-01-03 01:38:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:52 --> Database Driver Class Initialized
INFO - 2023-01-03 01:38:52 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:38:52 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:52 --> Total execution time: 0.1411
INFO - 2023-01-03 01:38:52 --> Config Class Initialized
INFO - 2023-01-03 01:38:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:38:53 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:38:53 --> Utf8 Class Initialized
INFO - 2023-01-03 01:38:53 --> URI Class Initialized
INFO - 2023-01-03 01:38:53 --> Router Class Initialized
INFO - 2023-01-03 01:38:53 --> Output Class Initialized
INFO - 2023-01-03 01:38:53 --> Security Class Initialized
DEBUG - 2023-01-03 01:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:38:53 --> Input Class Initialized
INFO - 2023-01-03 01:38:53 --> Language Class Initialized
INFO - 2023-01-03 01:38:53 --> Loader Class Initialized
INFO - 2023-01-03 01:38:53 --> Controller Class Initialized
DEBUG - 2023-01-03 01:38:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:38:53 --> Database Driver Class Initialized
INFO - 2023-01-03 01:38:53 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:38:56 --> Final output sent to browser
DEBUG - 2023-01-03 01:38:56 --> Total execution time: 30.1445
INFO - 2023-01-03 01:39:01 --> Final output sent to browser
DEBUG - 2023-01-03 01:39:01 --> Total execution time: 30.1524
INFO - 2023-01-03 01:39:08 --> Config Class Initialized
INFO - 2023-01-03 01:39:08 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:39:08 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:39:08 --> Utf8 Class Initialized
INFO - 2023-01-03 01:39:08 --> URI Class Initialized
INFO - 2023-01-03 01:39:08 --> Router Class Initialized
INFO - 2023-01-03 01:39:08 --> Output Class Initialized
INFO - 2023-01-03 01:39:08 --> Security Class Initialized
DEBUG - 2023-01-03 01:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:39:08 --> Input Class Initialized
INFO - 2023-01-03 01:39:08 --> Language Class Initialized
INFO - 2023-01-03 01:39:08 --> Loader Class Initialized
INFO - 2023-01-03 01:39:08 --> Controller Class Initialized
INFO - 2023-01-03 01:39:08 --> Helper loaded: form_helper
INFO - 2023-01-03 01:39:08 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:39:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:39:08 --> Model "Change_model" initialized
INFO - 2023-01-03 01:39:08 --> Model "Grafana_model" initialized
INFO - 2023-01-03 01:39:08 --> Final output sent to browser
DEBUG - 2023-01-03 01:39:08 --> Total execution time: 0.1630
INFO - 2023-01-03 01:39:08 --> Config Class Initialized
INFO - 2023-01-03 01:39:08 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:39:08 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:39:08 --> Utf8 Class Initialized
INFO - 2023-01-03 01:39:08 --> URI Class Initialized
INFO - 2023-01-03 01:39:08 --> Router Class Initialized
INFO - 2023-01-03 01:39:08 --> Output Class Initialized
INFO - 2023-01-03 01:39:08 --> Security Class Initialized
DEBUG - 2023-01-03 01:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:39:08 --> Input Class Initialized
INFO - 2023-01-03 01:39:08 --> Language Class Initialized
INFO - 2023-01-03 01:39:08 --> Loader Class Initialized
INFO - 2023-01-03 01:39:08 --> Controller Class Initialized
INFO - 2023-01-03 01:39:08 --> Helper loaded: form_helper
INFO - 2023-01-03 01:39:08 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:39:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:39:08 --> Final output sent to browser
DEBUG - 2023-01-03 01:39:08 --> Total execution time: 0.1200
INFO - 2023-01-03 01:39:08 --> Config Class Initialized
INFO - 2023-01-03 01:39:08 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:39:08 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:39:08 --> Utf8 Class Initialized
INFO - 2023-01-03 01:39:08 --> URI Class Initialized
INFO - 2023-01-03 01:39:08 --> Router Class Initialized
INFO - 2023-01-03 01:39:08 --> Output Class Initialized
INFO - 2023-01-03 01:39:08 --> Security Class Initialized
DEBUG - 2023-01-03 01:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:39:08 --> Input Class Initialized
INFO - 2023-01-03 01:39:08 --> Language Class Initialized
INFO - 2023-01-03 01:39:08 --> Loader Class Initialized
INFO - 2023-01-03 01:39:08 --> Controller Class Initialized
INFO - 2023-01-03 01:39:08 --> Helper loaded: form_helper
INFO - 2023-01-03 01:39:08 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:39:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:39:08 --> Database Driver Class Initialized
INFO - 2023-01-03 01:39:08 --> Model "Login_model" initialized
INFO - 2023-01-03 01:39:08 --> Final output sent to browser
DEBUG - 2023-01-03 01:39:08 --> Total execution time: 0.1572
INFO - 2023-01-03 01:39:09 --> Config Class Initialized
INFO - 2023-01-03 01:39:09 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:39:09 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:39:09 --> Utf8 Class Initialized
INFO - 2023-01-03 01:39:09 --> URI Class Initialized
INFO - 2023-01-03 01:39:09 --> Router Class Initialized
INFO - 2023-01-03 01:39:09 --> Output Class Initialized
INFO - 2023-01-03 01:39:09 --> Security Class Initialized
DEBUG - 2023-01-03 01:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:39:09 --> Input Class Initialized
INFO - 2023-01-03 01:39:09 --> Language Class Initialized
INFO - 2023-01-03 01:39:09 --> Loader Class Initialized
INFO - 2023-01-03 01:39:09 --> Controller Class Initialized
DEBUG - 2023-01-03 01:39:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:39:09 --> Database Driver Class Initialized
INFO - 2023-01-03 01:39:09 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:39:09 --> Final output sent to browser
DEBUG - 2023-01-03 01:39:09 --> Total execution time: 0.1398
INFO - 2023-01-03 01:39:09 --> Config Class Initialized
INFO - 2023-01-03 01:39:09 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:39:09 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:39:09 --> Utf8 Class Initialized
INFO - 2023-01-03 01:39:09 --> URI Class Initialized
INFO - 2023-01-03 01:39:09 --> Router Class Initialized
INFO - 2023-01-03 01:39:09 --> Output Class Initialized
INFO - 2023-01-03 01:39:09 --> Security Class Initialized
DEBUG - 2023-01-03 01:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:39:09 --> Input Class Initialized
INFO - 2023-01-03 01:39:09 --> Language Class Initialized
INFO - 2023-01-03 01:39:09 --> Loader Class Initialized
INFO - 2023-01-03 01:39:09 --> Controller Class Initialized
DEBUG - 2023-01-03 01:39:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:39:09 --> Database Driver Class Initialized
INFO - 2023-01-03 01:39:09 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:39:23 --> Final output sent to browser
DEBUG - 2023-01-03 01:39:23 --> Total execution time: 30.1438
INFO - 2023-01-03 01:39:39 --> Final output sent to browser
DEBUG - 2023-01-03 01:39:39 --> Total execution time: 30.1403
INFO - 2023-01-03 01:42:35 --> Config Class Initialized
INFO - 2023-01-03 01:42:35 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:42:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:42:35 --> Utf8 Class Initialized
INFO - 2023-01-03 01:42:35 --> URI Class Initialized
INFO - 2023-01-03 01:42:35 --> Router Class Initialized
INFO - 2023-01-03 01:42:35 --> Output Class Initialized
INFO - 2023-01-03 01:42:35 --> Security Class Initialized
DEBUG - 2023-01-03 01:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:42:35 --> Input Class Initialized
INFO - 2023-01-03 01:42:35 --> Language Class Initialized
INFO - 2023-01-03 01:42:35 --> Loader Class Initialized
INFO - 2023-01-03 01:42:35 --> Controller Class Initialized
INFO - 2023-01-03 01:42:35 --> Helper loaded: form_helper
INFO - 2023-01-03 01:42:35 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:42:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:42:35 --> Model "Change_model" initialized
INFO - 2023-01-03 01:42:35 --> Model "Grafana_model" initialized
INFO - 2023-01-03 01:42:36 --> Final output sent to browser
DEBUG - 2023-01-03 01:42:36 --> Total execution time: 0.2422
INFO - 2023-01-03 01:42:36 --> Config Class Initialized
INFO - 2023-01-03 01:42:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:42:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:42:36 --> Utf8 Class Initialized
INFO - 2023-01-03 01:42:36 --> URI Class Initialized
INFO - 2023-01-03 01:42:36 --> Router Class Initialized
INFO - 2023-01-03 01:42:36 --> Output Class Initialized
INFO - 2023-01-03 01:42:36 --> Security Class Initialized
DEBUG - 2023-01-03 01:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:42:36 --> Input Class Initialized
INFO - 2023-01-03 01:42:36 --> Language Class Initialized
INFO - 2023-01-03 01:42:36 --> Loader Class Initialized
INFO - 2023-01-03 01:42:36 --> Controller Class Initialized
INFO - 2023-01-03 01:42:36 --> Helper loaded: form_helper
INFO - 2023-01-03 01:42:36 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:42:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:42:36 --> Final output sent to browser
DEBUG - 2023-01-03 01:42:36 --> Total execution time: 0.1086
INFO - 2023-01-03 01:42:36 --> Config Class Initialized
INFO - 2023-01-03 01:42:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:42:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:42:36 --> Utf8 Class Initialized
INFO - 2023-01-03 01:42:36 --> URI Class Initialized
INFO - 2023-01-03 01:42:36 --> Router Class Initialized
INFO - 2023-01-03 01:42:36 --> Output Class Initialized
INFO - 2023-01-03 01:42:36 --> Security Class Initialized
DEBUG - 2023-01-03 01:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:42:36 --> Input Class Initialized
INFO - 2023-01-03 01:42:36 --> Language Class Initialized
INFO - 2023-01-03 01:42:36 --> Loader Class Initialized
INFO - 2023-01-03 01:42:36 --> Controller Class Initialized
INFO - 2023-01-03 01:42:36 --> Helper loaded: form_helper
INFO - 2023-01-03 01:42:36 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:42:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:42:36 --> Database Driver Class Initialized
INFO - 2023-01-03 01:42:36 --> Model "Login_model" initialized
INFO - 2023-01-03 01:42:36 --> Final output sent to browser
DEBUG - 2023-01-03 01:42:36 --> Total execution time: 0.1347
INFO - 2023-01-03 01:42:36 --> Config Class Initialized
INFO - 2023-01-03 01:42:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:42:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:42:36 --> Utf8 Class Initialized
INFO - 2023-01-03 01:42:36 --> URI Class Initialized
INFO - 2023-01-03 01:42:36 --> Router Class Initialized
INFO - 2023-01-03 01:42:36 --> Output Class Initialized
INFO - 2023-01-03 01:42:36 --> Security Class Initialized
DEBUG - 2023-01-03 01:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:42:36 --> Input Class Initialized
INFO - 2023-01-03 01:42:36 --> Language Class Initialized
INFO - 2023-01-03 01:42:36 --> Loader Class Initialized
INFO - 2023-01-03 01:42:36 --> Controller Class Initialized
DEBUG - 2023-01-03 01:42:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:42:36 --> Database Driver Class Initialized
INFO - 2023-01-03 01:42:36 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:42:36 --> Final output sent to browser
DEBUG - 2023-01-03 01:42:36 --> Total execution time: 0.1336
INFO - 2023-01-03 01:42:36 --> Config Class Initialized
INFO - 2023-01-03 01:42:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:42:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:42:36 --> Utf8 Class Initialized
INFO - 2023-01-03 01:42:36 --> URI Class Initialized
INFO - 2023-01-03 01:42:36 --> Router Class Initialized
INFO - 2023-01-03 01:42:36 --> Output Class Initialized
INFO - 2023-01-03 01:42:36 --> Security Class Initialized
DEBUG - 2023-01-03 01:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:42:36 --> Input Class Initialized
INFO - 2023-01-03 01:42:36 --> Language Class Initialized
INFO - 2023-01-03 01:42:36 --> Loader Class Initialized
INFO - 2023-01-03 01:42:36 --> Controller Class Initialized
DEBUG - 2023-01-03 01:42:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:42:36 --> Database Driver Class Initialized
INFO - 2023-01-03 01:42:36 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:43:06 --> Final output sent to browser
DEBUG - 2023-01-03 01:43:06 --> Total execution time: 30.1490
INFO - 2023-01-03 01:53:21 --> Config Class Initialized
INFO - 2023-01-03 01:53:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:21 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:21 --> URI Class Initialized
INFO - 2023-01-03 01:53:21 --> Router Class Initialized
INFO - 2023-01-03 01:53:21 --> Output Class Initialized
INFO - 2023-01-03 01:53:21 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:21 --> Input Class Initialized
INFO - 2023-01-03 01:53:21 --> Language Class Initialized
INFO - 2023-01-03 01:53:21 --> Loader Class Initialized
INFO - 2023-01-03 01:53:21 --> Controller Class Initialized
INFO - 2023-01-03 01:53:21 --> Helper loaded: form_helper
INFO - 2023-01-03 01:53:21 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:21 --> Model "Change_model" initialized
INFO - 2023-01-03 01:53:21 --> Model "Grafana_model" initialized
INFO - 2023-01-03 01:53:21 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:21 --> Total execution time: 0.1786
INFO - 2023-01-03 01:53:21 --> Config Class Initialized
INFO - 2023-01-03 01:53:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:21 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:21 --> URI Class Initialized
INFO - 2023-01-03 01:53:21 --> Router Class Initialized
INFO - 2023-01-03 01:53:21 --> Output Class Initialized
INFO - 2023-01-03 01:53:21 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:21 --> Input Class Initialized
INFO - 2023-01-03 01:53:21 --> Language Class Initialized
INFO - 2023-01-03 01:53:21 --> Loader Class Initialized
INFO - 2023-01-03 01:53:21 --> Controller Class Initialized
INFO - 2023-01-03 01:53:21 --> Helper loaded: form_helper
INFO - 2023-01-03 01:53:21 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:21 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:21 --> Total execution time: 0.1259
INFO - 2023-01-03 01:53:21 --> Config Class Initialized
INFO - 2023-01-03 01:53:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:21 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:21 --> URI Class Initialized
INFO - 2023-01-03 01:53:21 --> Router Class Initialized
INFO - 2023-01-03 01:53:21 --> Output Class Initialized
INFO - 2023-01-03 01:53:21 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:21 --> Input Class Initialized
INFO - 2023-01-03 01:53:21 --> Language Class Initialized
INFO - 2023-01-03 01:53:21 --> Loader Class Initialized
INFO - 2023-01-03 01:53:21 --> Controller Class Initialized
INFO - 2023-01-03 01:53:21 --> Helper loaded: form_helper
INFO - 2023-01-03 01:53:21 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:21 --> Database Driver Class Initialized
INFO - 2023-01-03 01:53:21 --> Model "Login_model" initialized
INFO - 2023-01-03 01:53:21 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:21 --> Total execution time: 0.1384
INFO - 2023-01-03 01:53:21 --> Config Class Initialized
INFO - 2023-01-03 01:53:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:21 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:21 --> URI Class Initialized
INFO - 2023-01-03 01:53:21 --> Router Class Initialized
INFO - 2023-01-03 01:53:21 --> Output Class Initialized
INFO - 2023-01-03 01:53:21 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:21 --> Input Class Initialized
INFO - 2023-01-03 01:53:21 --> Language Class Initialized
INFO - 2023-01-03 01:53:21 --> Loader Class Initialized
INFO - 2023-01-03 01:53:21 --> Controller Class Initialized
DEBUG - 2023-01-03 01:53:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:21 --> Database Driver Class Initialized
INFO - 2023-01-03 01:53:21 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:53:21 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:21 --> Total execution time: 0.1271
INFO - 2023-01-03 01:53:22 --> Config Class Initialized
INFO - 2023-01-03 01:53:22 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:22 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:22 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:22 --> URI Class Initialized
INFO - 2023-01-03 01:53:22 --> Router Class Initialized
INFO - 2023-01-03 01:53:22 --> Output Class Initialized
INFO - 2023-01-03 01:53:22 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:22 --> Input Class Initialized
INFO - 2023-01-03 01:53:22 --> Language Class Initialized
INFO - 2023-01-03 01:53:22 --> Loader Class Initialized
INFO - 2023-01-03 01:53:22 --> Controller Class Initialized
DEBUG - 2023-01-03 01:53:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:22 --> Database Driver Class Initialized
INFO - 2023-01-03 01:53:22 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:53:43 --> Config Class Initialized
INFO - 2023-01-03 01:53:43 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:43 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:43 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:43 --> URI Class Initialized
INFO - 2023-01-03 01:53:43 --> Router Class Initialized
INFO - 2023-01-03 01:53:43 --> Output Class Initialized
INFO - 2023-01-03 01:53:43 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:43 --> Input Class Initialized
INFO - 2023-01-03 01:53:43 --> Language Class Initialized
INFO - 2023-01-03 01:53:43 --> Loader Class Initialized
INFO - 2023-01-03 01:53:43 --> Controller Class Initialized
INFO - 2023-01-03 01:53:43 --> Helper loaded: form_helper
INFO - 2023-01-03 01:53:43 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:53:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:43 --> Model "Change_model" initialized
INFO - 2023-01-03 01:53:43 --> Model "Grafana_model" initialized
INFO - 2023-01-03 01:53:43 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:43 --> Total execution time: 0.1484
INFO - 2023-01-03 01:53:43 --> Config Class Initialized
INFO - 2023-01-03 01:53:43 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:43 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:43 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:43 --> URI Class Initialized
INFO - 2023-01-03 01:53:43 --> Router Class Initialized
INFO - 2023-01-03 01:53:43 --> Output Class Initialized
INFO - 2023-01-03 01:53:43 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:43 --> Input Class Initialized
INFO - 2023-01-03 01:53:43 --> Language Class Initialized
INFO - 2023-01-03 01:53:43 --> Loader Class Initialized
INFO - 2023-01-03 01:53:43 --> Controller Class Initialized
INFO - 2023-01-03 01:53:43 --> Helper loaded: form_helper
INFO - 2023-01-03 01:53:43 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:53:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:43 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:43 --> Total execution time: 0.1121
INFO - 2023-01-03 01:53:43 --> Config Class Initialized
INFO - 2023-01-03 01:53:43 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:43 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:43 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:43 --> URI Class Initialized
INFO - 2023-01-03 01:53:43 --> Router Class Initialized
INFO - 2023-01-03 01:53:43 --> Output Class Initialized
INFO - 2023-01-03 01:53:43 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:43 --> Input Class Initialized
INFO - 2023-01-03 01:53:43 --> Language Class Initialized
INFO - 2023-01-03 01:53:43 --> Loader Class Initialized
INFO - 2023-01-03 01:53:43 --> Controller Class Initialized
INFO - 2023-01-03 01:53:43 --> Helper loaded: form_helper
INFO - 2023-01-03 01:53:43 --> Helper loaded: url_helper
DEBUG - 2023-01-03 01:53:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:43 --> Database Driver Class Initialized
INFO - 2023-01-03 01:53:44 --> Model "Login_model" initialized
INFO - 2023-01-03 01:53:44 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:44 --> Total execution time: 0.1489
INFO - 2023-01-03 01:53:44 --> Config Class Initialized
INFO - 2023-01-03 01:53:44 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:44 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:44 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:44 --> URI Class Initialized
INFO - 2023-01-03 01:53:44 --> Router Class Initialized
INFO - 2023-01-03 01:53:44 --> Output Class Initialized
INFO - 2023-01-03 01:53:44 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:44 --> Input Class Initialized
INFO - 2023-01-03 01:53:44 --> Language Class Initialized
INFO - 2023-01-03 01:53:44 --> Loader Class Initialized
INFO - 2023-01-03 01:53:44 --> Controller Class Initialized
DEBUG - 2023-01-03 01:53:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:44 --> Database Driver Class Initialized
INFO - 2023-01-03 01:53:44 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:53:44 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:44 --> Total execution time: 0.1477
INFO - 2023-01-03 01:53:44 --> Config Class Initialized
INFO - 2023-01-03 01:53:44 --> Hooks Class Initialized
DEBUG - 2023-01-03 01:53:44 --> UTF-8 Support Enabled
INFO - 2023-01-03 01:53:44 --> Utf8 Class Initialized
INFO - 2023-01-03 01:53:44 --> URI Class Initialized
INFO - 2023-01-03 01:53:44 --> Router Class Initialized
INFO - 2023-01-03 01:53:44 --> Output Class Initialized
INFO - 2023-01-03 01:53:44 --> Security Class Initialized
DEBUG - 2023-01-03 01:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 01:53:44 --> Input Class Initialized
INFO - 2023-01-03 01:53:44 --> Language Class Initialized
INFO - 2023-01-03 01:53:44 --> Loader Class Initialized
INFO - 2023-01-03 01:53:44 --> Controller Class Initialized
DEBUG - 2023-01-03 01:53:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 01:53:44 --> Database Driver Class Initialized
INFO - 2023-01-03 01:53:44 --> Model "Cluster_model" initialized
INFO - 2023-01-03 01:53:52 --> Final output sent to browser
DEBUG - 2023-01-03 01:53:52 --> Total execution time: 30.1345
INFO - 2023-01-03 01:54:14 --> Final output sent to browser
DEBUG - 2023-01-03 01:54:14 --> Total execution time: 30.1360
INFO - 2023-01-03 02:16:51 --> Config Class Initialized
INFO - 2023-01-03 02:16:51 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:16:51 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:16:51 --> Utf8 Class Initialized
INFO - 2023-01-03 02:16:51 --> URI Class Initialized
INFO - 2023-01-03 02:16:51 --> Router Class Initialized
INFO - 2023-01-03 02:16:51 --> Output Class Initialized
INFO - 2023-01-03 02:16:51 --> Security Class Initialized
DEBUG - 2023-01-03 02:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:16:51 --> Input Class Initialized
INFO - 2023-01-03 02:16:51 --> Language Class Initialized
INFO - 2023-01-03 02:16:52 --> Loader Class Initialized
INFO - 2023-01-03 02:16:52 --> Controller Class Initialized
INFO - 2023-01-03 02:16:52 --> Helper loaded: form_helper
INFO - 2023-01-03 02:16:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:16:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:16:52 --> Model "Change_model" initialized
INFO - 2023-01-03 02:16:52 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:16:52 --> Final output sent to browser
DEBUG - 2023-01-03 02:16:52 --> Total execution time: 0.1602
INFO - 2023-01-03 02:16:52 --> Config Class Initialized
INFO - 2023-01-03 02:16:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:16:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:16:52 --> Utf8 Class Initialized
INFO - 2023-01-03 02:16:52 --> URI Class Initialized
INFO - 2023-01-03 02:16:52 --> Router Class Initialized
INFO - 2023-01-03 02:16:52 --> Output Class Initialized
INFO - 2023-01-03 02:16:52 --> Security Class Initialized
DEBUG - 2023-01-03 02:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:16:52 --> Input Class Initialized
INFO - 2023-01-03 02:16:52 --> Language Class Initialized
INFO - 2023-01-03 02:16:52 --> Loader Class Initialized
INFO - 2023-01-03 02:16:52 --> Controller Class Initialized
INFO - 2023-01-03 02:16:52 --> Helper loaded: form_helper
INFO - 2023-01-03 02:16:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:16:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:16:52 --> Final output sent to browser
DEBUG - 2023-01-03 02:16:52 --> Total execution time: 0.1110
INFO - 2023-01-03 02:16:52 --> Config Class Initialized
INFO - 2023-01-03 02:16:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:16:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:16:52 --> Utf8 Class Initialized
INFO - 2023-01-03 02:16:52 --> URI Class Initialized
INFO - 2023-01-03 02:16:52 --> Router Class Initialized
INFO - 2023-01-03 02:16:52 --> Output Class Initialized
INFO - 2023-01-03 02:16:52 --> Security Class Initialized
DEBUG - 2023-01-03 02:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:16:52 --> Input Class Initialized
INFO - 2023-01-03 02:16:52 --> Language Class Initialized
INFO - 2023-01-03 02:16:52 --> Loader Class Initialized
INFO - 2023-01-03 02:16:52 --> Controller Class Initialized
INFO - 2023-01-03 02:16:52 --> Helper loaded: form_helper
INFO - 2023-01-03 02:16:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:16:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-01-03 02:16:52 --> Exception of type 'ParseError' occurred with Message: syntax error, unexpected ',' in File /var/www/html/KunlunMonitor/application/config/database.php at Line 9
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/Loader.php(391): DB('role', NULL)
#1 /var/www/html/KunlunMonitor/application/models/Login_model.php(6): CI_Loader->database('role', true)
#2 /var/www/html/KunlunMonitor/system/core/Loader.php(357): Login_model->__construct()
#3 /var/www/html/KunlunMonitor/application/controllers/Login.php(36): CI_Loader->model('Login_model')
#4 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Login->userCheck()
#5 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#6 {main}
INFO - 2023-01-03 02:30:18 --> Config Class Initialized
INFO - 2023-01-03 02:30:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:30:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:30:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:30:18 --> URI Class Initialized
INFO - 2023-01-03 02:30:18 --> Router Class Initialized
INFO - 2023-01-03 02:30:18 --> Output Class Initialized
INFO - 2023-01-03 02:30:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:30:18 --> Input Class Initialized
INFO - 2023-01-03 02:30:18 --> Language Class Initialized
INFO - 2023-01-03 02:30:18 --> Loader Class Initialized
INFO - 2023-01-03 02:30:18 --> Controller Class Initialized
INFO - 2023-01-03 02:30:18 --> Helper loaded: form_helper
INFO - 2023-01-03 02:30:18 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:30:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:30:18 --> Model "Change_model" initialized
INFO - 2023-01-03 02:30:18 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:30:18 --> Final output sent to browser
DEBUG - 2023-01-03 02:30:18 --> Total execution time: 0.2048
INFO - 2023-01-03 02:30:18 --> Config Class Initialized
INFO - 2023-01-03 02:30:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:30:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:30:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:30:18 --> URI Class Initialized
INFO - 2023-01-03 02:30:18 --> Router Class Initialized
INFO - 2023-01-03 02:30:18 --> Output Class Initialized
INFO - 2023-01-03 02:30:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:30:18 --> Input Class Initialized
INFO - 2023-01-03 02:30:18 --> Language Class Initialized
INFO - 2023-01-03 02:30:18 --> Loader Class Initialized
INFO - 2023-01-03 02:30:18 --> Controller Class Initialized
INFO - 2023-01-03 02:30:18 --> Helper loaded: form_helper
INFO - 2023-01-03 02:30:18 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:30:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:30:18 --> Final output sent to browser
DEBUG - 2023-01-03 02:30:18 --> Total execution time: 0.1170
INFO - 2023-01-03 02:30:18 --> Config Class Initialized
INFO - 2023-01-03 02:30:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:30:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:30:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:30:18 --> URI Class Initialized
INFO - 2023-01-03 02:30:18 --> Router Class Initialized
INFO - 2023-01-03 02:30:18 --> Output Class Initialized
INFO - 2023-01-03 02:30:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:30:18 --> Input Class Initialized
INFO - 2023-01-03 02:30:18 --> Language Class Initialized
INFO - 2023-01-03 02:30:18 --> Loader Class Initialized
INFO - 2023-01-03 02:30:18 --> Controller Class Initialized
INFO - 2023-01-03 02:30:18 --> Helper loaded: form_helper
INFO - 2023-01-03 02:30:18 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:30:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-01-03 02:30:18 --> Exception of type 'ParseError' occurred with Message: syntax error, unexpected ',' in File /var/www/html/KunlunMonitor/application/config/database.php at Line 9
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/Loader.php(391): DB('role', NULL)
#1 /var/www/html/KunlunMonitor/application/models/Login_model.php(6): CI_Loader->database('role', true)
#2 /var/www/html/KunlunMonitor/system/core/Loader.php(357): Login_model->__construct()
#3 /var/www/html/KunlunMonitor/application/controllers/Login.php(36): CI_Loader->model('Login_model')
#4 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Login->userCheck()
#5 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#6 {main}
INFO - 2023-01-03 02:31:19 --> Config Class Initialized
INFO - 2023-01-03 02:31:19 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:31:19 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:31:19 --> Utf8 Class Initialized
INFO - 2023-01-03 02:31:19 --> URI Class Initialized
INFO - 2023-01-03 02:31:19 --> Router Class Initialized
INFO - 2023-01-03 02:31:19 --> Output Class Initialized
INFO - 2023-01-03 02:31:19 --> Security Class Initialized
DEBUG - 2023-01-03 02:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:31:19 --> Input Class Initialized
INFO - 2023-01-03 02:31:19 --> Language Class Initialized
INFO - 2023-01-03 02:31:20 --> Loader Class Initialized
INFO - 2023-01-03 02:31:20 --> Controller Class Initialized
INFO - 2023-01-03 02:31:20 --> Helper loaded: form_helper
INFO - 2023-01-03 02:31:20 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:31:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:31:20 --> Model "Change_model" initialized
INFO - 2023-01-03 02:31:20 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:31:20 --> Final output sent to browser
DEBUG - 2023-01-03 02:31:20 --> Total execution time: 0.1860
INFO - 2023-01-03 02:31:20 --> Config Class Initialized
INFO - 2023-01-03 02:31:20 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:31:20 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:31:20 --> Utf8 Class Initialized
INFO - 2023-01-03 02:31:20 --> URI Class Initialized
INFO - 2023-01-03 02:31:20 --> Router Class Initialized
INFO - 2023-01-03 02:31:20 --> Output Class Initialized
INFO - 2023-01-03 02:31:20 --> Security Class Initialized
DEBUG - 2023-01-03 02:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:31:20 --> Input Class Initialized
INFO - 2023-01-03 02:31:20 --> Language Class Initialized
INFO - 2023-01-03 02:31:20 --> Loader Class Initialized
INFO - 2023-01-03 02:31:20 --> Controller Class Initialized
INFO - 2023-01-03 02:31:20 --> Helper loaded: form_helper
INFO - 2023-01-03 02:31:20 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:31:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:31:20 --> Final output sent to browser
DEBUG - 2023-01-03 02:31:20 --> Total execution time: 0.1224
INFO - 2023-01-03 02:31:20 --> Config Class Initialized
INFO - 2023-01-03 02:31:20 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:31:20 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:31:20 --> Utf8 Class Initialized
INFO - 2023-01-03 02:31:20 --> URI Class Initialized
INFO - 2023-01-03 02:31:20 --> Router Class Initialized
INFO - 2023-01-03 02:31:20 --> Output Class Initialized
INFO - 2023-01-03 02:31:20 --> Security Class Initialized
DEBUG - 2023-01-03 02:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:31:20 --> Input Class Initialized
INFO - 2023-01-03 02:31:20 --> Language Class Initialized
INFO - 2023-01-03 02:31:20 --> Loader Class Initialized
INFO - 2023-01-03 02:31:20 --> Controller Class Initialized
INFO - 2023-01-03 02:31:20 --> Helper loaded: form_helper
INFO - 2023-01-03 02:31:20 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:31:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-01-03 02:31:20 --> Exception of type 'ParseError' occurred with Message: syntax error, unexpected ',' in File /var/www/html/KunlunMonitor/application/config/database.php at Line 9
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/Loader.php(391): DB('role', NULL)
#1 /var/www/html/KunlunMonitor/application/models/Login_model.php(6): CI_Loader->database('role', true)
#2 /var/www/html/KunlunMonitor/system/core/Loader.php(357): Login_model->__construct()
#3 /var/www/html/KunlunMonitor/application/controllers/Login.php(36): CI_Loader->model('Login_model')
#4 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Login->userCheck()
#5 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#6 {main}
INFO - 2023-01-03 02:33:49 --> Config Class Initialized
INFO - 2023-01-03 02:33:49 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:33:49 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:33:49 --> Utf8 Class Initialized
INFO - 2023-01-03 02:33:49 --> URI Class Initialized
INFO - 2023-01-03 02:33:49 --> Router Class Initialized
INFO - 2023-01-03 02:33:49 --> Output Class Initialized
INFO - 2023-01-03 02:33:49 --> Security Class Initialized
DEBUG - 2023-01-03 02:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:33:49 --> Input Class Initialized
INFO - 2023-01-03 02:33:49 --> Language Class Initialized
INFO - 2023-01-03 02:33:49 --> Loader Class Initialized
INFO - 2023-01-03 02:33:49 --> Controller Class Initialized
INFO - 2023-01-03 02:33:49 --> Helper loaded: form_helper
INFO - 2023-01-03 02:33:49 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:33:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:33:49 --> Model "Change_model" initialized
INFO - 2023-01-03 02:33:49 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:33:49 --> Final output sent to browser
DEBUG - 2023-01-03 02:33:49 --> Total execution time: 0.6098
INFO - 2023-01-03 02:35:20 --> Config Class Initialized
INFO - 2023-01-03 02:35:20 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:35:20 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:35:20 --> Utf8 Class Initialized
INFO - 2023-01-03 02:35:20 --> URI Class Initialized
INFO - 2023-01-03 02:35:20 --> Router Class Initialized
INFO - 2023-01-03 02:35:20 --> Output Class Initialized
INFO - 2023-01-03 02:35:20 --> Security Class Initialized
DEBUG - 2023-01-03 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:35:20 --> Input Class Initialized
INFO - 2023-01-03 02:35:20 --> Language Class Initialized
INFO - 2023-01-03 02:35:20 --> Loader Class Initialized
INFO - 2023-01-03 02:35:20 --> Controller Class Initialized
INFO - 2023-01-03 02:35:21 --> Helper loaded: form_helper
INFO - 2023-01-03 02:35:21 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:35:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:35:21 --> Model "Change_model" initialized
INFO - 2023-01-03 02:35:21 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:49:38 --> Config Class Initialized
INFO - 2023-01-03 02:49:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:49:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:49:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:49:38 --> URI Class Initialized
INFO - 2023-01-03 02:49:38 --> Router Class Initialized
INFO - 2023-01-03 02:49:38 --> Output Class Initialized
INFO - 2023-01-03 02:49:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:49:38 --> Input Class Initialized
INFO - 2023-01-03 02:49:38 --> Language Class Initialized
INFO - 2023-01-03 02:49:38 --> Loader Class Initialized
INFO - 2023-01-03 02:49:38 --> Controller Class Initialized
INFO - 2023-01-03 02:49:38 --> Helper loaded: form_helper
INFO - 2023-01-03 02:49:38 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:49:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:49:38 --> Model "Change_model" initialized
INFO - 2023-01-03 02:49:38 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:50:17 --> Config Class Initialized
INFO - 2023-01-03 02:50:17 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:50:17 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:50:17 --> Utf8 Class Initialized
INFO - 2023-01-03 02:50:17 --> URI Class Initialized
INFO - 2023-01-03 02:50:17 --> Router Class Initialized
INFO - 2023-01-03 02:50:17 --> Output Class Initialized
INFO - 2023-01-03 02:50:17 --> Security Class Initialized
DEBUG - 2023-01-03 02:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:50:17 --> Input Class Initialized
INFO - 2023-01-03 02:50:17 --> Language Class Initialized
INFO - 2023-01-03 02:50:17 --> Loader Class Initialized
INFO - 2023-01-03 02:50:17 --> Controller Class Initialized
INFO - 2023-01-03 02:50:17 --> Helper loaded: form_helper
INFO - 2023-01-03 02:50:17 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:50:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:50:17 --> Model "Change_model" initialized
INFO - 2023-01-03 02:50:17 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:50:38 --> Config Class Initialized
INFO - 2023-01-03 02:50:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:50:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:50:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:50:38 --> URI Class Initialized
INFO - 2023-01-03 02:50:38 --> Router Class Initialized
INFO - 2023-01-03 02:50:38 --> Output Class Initialized
INFO - 2023-01-03 02:50:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:50:38 --> Input Class Initialized
INFO - 2023-01-03 02:50:38 --> Language Class Initialized
INFO - 2023-01-03 02:50:38 --> Loader Class Initialized
INFO - 2023-01-03 02:50:38 --> Controller Class Initialized
INFO - 2023-01-03 02:50:38 --> Helper loaded: form_helper
INFO - 2023-01-03 02:50:38 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:50:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:50:38 --> Model "Change_model" initialized
INFO - 2023-01-03 02:50:38 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:50:40 --> Config Class Initialized
INFO - 2023-01-03 02:50:40 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:50:40 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:50:40 --> Utf8 Class Initialized
INFO - 2023-01-03 02:50:40 --> URI Class Initialized
INFO - 2023-01-03 02:50:40 --> Router Class Initialized
INFO - 2023-01-03 02:50:40 --> Output Class Initialized
INFO - 2023-01-03 02:50:40 --> Security Class Initialized
DEBUG - 2023-01-03 02:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:50:40 --> Input Class Initialized
INFO - 2023-01-03 02:50:40 --> Language Class Initialized
INFO - 2023-01-03 02:50:40 --> Loader Class Initialized
INFO - 2023-01-03 02:50:40 --> Controller Class Initialized
INFO - 2023-01-03 02:50:40 --> Helper loaded: form_helper
INFO - 2023-01-03 02:50:40 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:50:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:50:40 --> Model "Change_model" initialized
INFO - 2023-01-03 02:50:40 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:51:51 --> Config Class Initialized
INFO - 2023-01-03 02:51:51 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:51:51 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:51:51 --> Utf8 Class Initialized
INFO - 2023-01-03 02:51:51 --> URI Class Initialized
INFO - 2023-01-03 02:51:51 --> Router Class Initialized
INFO - 2023-01-03 02:51:51 --> Output Class Initialized
INFO - 2023-01-03 02:51:51 --> Security Class Initialized
DEBUG - 2023-01-03 02:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:51:51 --> Input Class Initialized
INFO - 2023-01-03 02:51:51 --> Language Class Initialized
INFO - 2023-01-03 02:51:51 --> Loader Class Initialized
INFO - 2023-01-03 02:51:51 --> Controller Class Initialized
INFO - 2023-01-03 02:51:51 --> Helper loaded: form_helper
INFO - 2023-01-03 02:51:51 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:51:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:51:51 --> Model "Change_model" initialized
INFO - 2023-01-03 02:51:51 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:51:51 --> Final output sent to browser
DEBUG - 2023-01-03 02:51:51 --> Total execution time: 0.3219
INFO - 2023-01-03 02:51:51 --> Config Class Initialized
INFO - 2023-01-03 02:51:51 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:51:51 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:51:51 --> Utf8 Class Initialized
INFO - 2023-01-03 02:51:51 --> URI Class Initialized
INFO - 2023-01-03 02:51:51 --> Router Class Initialized
INFO - 2023-01-03 02:51:51 --> Output Class Initialized
INFO - 2023-01-03 02:51:51 --> Security Class Initialized
DEBUG - 2023-01-03 02:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:51:51 --> Input Class Initialized
INFO - 2023-01-03 02:51:51 --> Language Class Initialized
INFO - 2023-01-03 02:51:51 --> Loader Class Initialized
INFO - 2023-01-03 02:51:51 --> Controller Class Initialized
INFO - 2023-01-03 02:51:51 --> Helper loaded: form_helper
INFO - 2023-01-03 02:51:51 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:51:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:51:51 --> Final output sent to browser
DEBUG - 2023-01-03 02:51:51 --> Total execution time: 0.1165
INFO - 2023-01-03 02:51:51 --> Config Class Initialized
INFO - 2023-01-03 02:51:51 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:51:51 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:51:51 --> Utf8 Class Initialized
INFO - 2023-01-03 02:51:51 --> URI Class Initialized
INFO - 2023-01-03 02:51:51 --> Router Class Initialized
INFO - 2023-01-03 02:51:51 --> Output Class Initialized
INFO - 2023-01-03 02:51:51 --> Security Class Initialized
DEBUG - 2023-01-03 02:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:51:51 --> Input Class Initialized
INFO - 2023-01-03 02:51:51 --> Language Class Initialized
INFO - 2023-01-03 02:51:51 --> Loader Class Initialized
INFO - 2023-01-03 02:51:51 --> Controller Class Initialized
INFO - 2023-01-03 02:51:51 --> Helper loaded: form_helper
INFO - 2023-01-03 02:51:51 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:51:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:51:51 --> Database Driver Class Initialized
INFO - 2023-01-03 02:51:51 --> Model "Login_model" initialized
INFO - 2023-01-03 02:51:51 --> Final output sent to browser
DEBUG - 2023-01-03 02:51:51 --> Total execution time: 0.1518
INFO - 2023-01-03 02:52:05 --> Config Class Initialized
INFO - 2023-01-03 02:52:05 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:05 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:05 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:05 --> URI Class Initialized
INFO - 2023-01-03 02:52:05 --> Router Class Initialized
INFO - 2023-01-03 02:52:05 --> Output Class Initialized
INFO - 2023-01-03 02:52:05 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:05 --> Input Class Initialized
INFO - 2023-01-03 02:52:05 --> Language Class Initialized
INFO - 2023-01-03 02:52:05 --> Loader Class Initialized
INFO - 2023-01-03 02:52:05 --> Controller Class Initialized
INFO - 2023-01-03 02:52:05 --> Helper loaded: form_helper
INFO - 2023-01-03 02:52:05 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:52:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:05 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:05 --> Total execution time: 0.1425
INFO - 2023-01-03 02:52:05 --> Config Class Initialized
INFO - 2023-01-03 02:52:05 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:05 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:05 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:05 --> URI Class Initialized
INFO - 2023-01-03 02:52:05 --> Router Class Initialized
INFO - 2023-01-03 02:52:05 --> Output Class Initialized
INFO - 2023-01-03 02:52:05 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:05 --> Input Class Initialized
INFO - 2023-01-03 02:52:05 --> Language Class Initialized
INFO - 2023-01-03 02:52:05 --> Loader Class Initialized
INFO - 2023-01-03 02:52:05 --> Controller Class Initialized
INFO - 2023-01-03 02:52:05 --> Helper loaded: form_helper
INFO - 2023-01-03 02:52:05 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:52:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:05 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:05 --> Model "Login_model" initialized
INFO - 2023-01-03 02:52:05 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:05 --> Total execution time: 0.1508
INFO - 2023-01-03 02:52:25 --> Config Class Initialized
INFO - 2023-01-03 02:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:25 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:25 --> URI Class Initialized
INFO - 2023-01-03 02:52:25 --> Router Class Initialized
INFO - 2023-01-03 02:52:25 --> Output Class Initialized
INFO - 2023-01-03 02:52:25 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:25 --> Input Class Initialized
INFO - 2023-01-03 02:52:25 --> Language Class Initialized
INFO - 2023-01-03 02:52:25 --> Loader Class Initialized
INFO - 2023-01-03 02:52:25 --> Controller Class Initialized
INFO - 2023-01-03 02:52:25 --> Helper loaded: form_helper
INFO - 2023-01-03 02:52:25 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:52:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:25 --> Model "Change_model" initialized
INFO - 2023-01-03 02:52:25 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:52:25 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:25 --> Total execution time: 0.1649
INFO - 2023-01-03 02:52:25 --> Config Class Initialized
INFO - 2023-01-03 02:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:25 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:25 --> URI Class Initialized
INFO - 2023-01-03 02:52:25 --> Router Class Initialized
INFO - 2023-01-03 02:52:25 --> Output Class Initialized
INFO - 2023-01-03 02:52:25 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:25 --> Input Class Initialized
INFO - 2023-01-03 02:52:25 --> Language Class Initialized
INFO - 2023-01-03 02:52:25 --> Loader Class Initialized
INFO - 2023-01-03 02:52:25 --> Controller Class Initialized
INFO - 2023-01-03 02:52:25 --> Helper loaded: form_helper
INFO - 2023-01-03 02:52:25 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:52:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:25 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:25 --> Total execution time: 0.1249
INFO - 2023-01-03 02:52:25 --> Config Class Initialized
INFO - 2023-01-03 02:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:25 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:25 --> URI Class Initialized
INFO - 2023-01-03 02:52:25 --> Router Class Initialized
INFO - 2023-01-03 02:52:25 --> Output Class Initialized
INFO - 2023-01-03 02:52:25 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:25 --> Input Class Initialized
INFO - 2023-01-03 02:52:25 --> Language Class Initialized
INFO - 2023-01-03 02:52:25 --> Loader Class Initialized
INFO - 2023-01-03 02:52:25 --> Controller Class Initialized
INFO - 2023-01-03 02:52:25 --> Helper loaded: form_helper
INFO - 2023-01-03 02:52:25 --> Helper loaded: url_helper
DEBUG - 2023-01-03 02:52:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:25 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:25 --> Model "Login_model" initialized
INFO - 2023-01-03 02:52:25 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:25 --> Total execution time: 0.1522
INFO - 2023-01-03 02:52:25 --> Config Class Initialized
INFO - 2023-01-03 02:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:25 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:25 --> URI Class Initialized
INFO - 2023-01-03 02:52:25 --> Router Class Initialized
INFO - 2023-01-03 02:52:25 --> Output Class Initialized
INFO - 2023-01-03 02:52:25 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:25 --> Input Class Initialized
INFO - 2023-01-03 02:52:25 --> Language Class Initialized
INFO - 2023-01-03 02:52:25 --> Loader Class Initialized
INFO - 2023-01-03 02:52:25 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:25 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:25 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:25 --> Total execution time: 0.1562
INFO - 2023-01-03 02:52:25 --> Config Class Initialized
INFO - 2023-01-03 02:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:25 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:25 --> URI Class Initialized
INFO - 2023-01-03 02:52:25 --> Router Class Initialized
INFO - 2023-01-03 02:52:25 --> Output Class Initialized
INFO - 2023-01-03 02:52:25 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:25 --> Input Class Initialized
INFO - 2023-01-03 02:52:25 --> Language Class Initialized
INFO - 2023-01-03 02:52:25 --> Loader Class Initialized
INFO - 2023-01-03 02:52:26 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:26 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:26 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:26 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:26 --> Total execution time: 0.1474
INFO - 2023-01-03 02:52:26 --> Config Class Initialized
INFO - 2023-01-03 02:52:26 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:26 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:27 --> URI Class Initialized
INFO - 2023-01-03 02:52:27 --> Router Class Initialized
INFO - 2023-01-03 02:52:27 --> Output Class Initialized
INFO - 2023-01-03 02:52:27 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:27 --> Input Class Initialized
INFO - 2023-01-03 02:52:27 --> Language Class Initialized
INFO - 2023-01-03 02:52:27 --> Loader Class Initialized
INFO - 2023-01-03 02:52:27 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:27 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:27 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:27 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:27 --> Total execution time: 0.2452
INFO - 2023-01-03 02:52:27 --> Config Class Initialized
INFO - 2023-01-03 02:52:27 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:27 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:27 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:27 --> URI Class Initialized
INFO - 2023-01-03 02:52:27 --> Router Class Initialized
INFO - 2023-01-03 02:52:27 --> Output Class Initialized
INFO - 2023-01-03 02:52:27 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:27 --> Input Class Initialized
INFO - 2023-01-03 02:52:27 --> Language Class Initialized
INFO - 2023-01-03 02:52:27 --> Loader Class Initialized
INFO - 2023-01-03 02:52:27 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:27 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:27 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:27 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:27 --> Total execution time: 0.1497
INFO - 2023-01-03 02:52:32 --> Config Class Initialized
INFO - 2023-01-03 02:52:32 --> Config Class Initialized
INFO - 2023-01-03 02:52:32 --> Hooks Class Initialized
INFO - 2023-01-03 02:52:32 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 02:52:32 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:32 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:32 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:32 --> URI Class Initialized
INFO - 2023-01-03 02:52:32 --> URI Class Initialized
INFO - 2023-01-03 02:52:32 --> Router Class Initialized
INFO - 2023-01-03 02:52:32 --> Router Class Initialized
INFO - 2023-01-03 02:52:33 --> Output Class Initialized
INFO - 2023-01-03 02:52:33 --> Output Class Initialized
INFO - 2023-01-03 02:52:33 --> Security Class Initialized
INFO - 2023-01-03 02:52:33 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 02:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:33 --> Input Class Initialized
INFO - 2023-01-03 02:52:33 --> Input Class Initialized
INFO - 2023-01-03 02:52:33 --> Language Class Initialized
INFO - 2023-01-03 02:52:33 --> Language Class Initialized
INFO - 2023-01-03 02:52:33 --> Loader Class Initialized
INFO - 2023-01-03 02:52:33 --> Loader Class Initialized
INFO - 2023-01-03 02:52:33 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:33 --> Controller Class Initialized
INFO - 2023-01-03 02:52:33 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-03 02:52:33 --> Total execution time: 0.3053
INFO - 2023-01-03 02:52:33 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:33 --> Config Class Initialized
INFO - 2023-01-03 02:52:33 --> Final output sent to browser
INFO - 2023-01-03 02:52:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:33 --> Total execution time: 0.3780
DEBUG - 2023-01-03 02:52:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:33 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:33 --> URI Class Initialized
INFO - 2023-01-03 02:52:33 --> Config Class Initialized
INFO - 2023-01-03 02:52:33 --> Hooks Class Initialized
INFO - 2023-01-03 02:52:33 --> Router Class Initialized
INFO - 2023-01-03 02:52:33 --> Output Class Initialized
DEBUG - 2023-01-03 02:52:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:33 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:33 --> Security Class Initialized
INFO - 2023-01-03 02:52:33 --> URI Class Initialized
DEBUG - 2023-01-03 02:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:33 --> Input Class Initialized
INFO - 2023-01-03 02:52:33 --> Router Class Initialized
INFO - 2023-01-03 02:52:33 --> Language Class Initialized
INFO - 2023-01-03 02:52:33 --> Output Class Initialized
INFO - 2023-01-03 02:52:33 --> Loader Class Initialized
INFO - 2023-01-03 02:52:33 --> Security Class Initialized
INFO - 2023-01-03 02:52:33 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:33 --> Input Class Initialized
DEBUG - 2023-01-03 02:52:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:33 --> Language Class Initialized
INFO - 2023-01-03 02:52:33 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:33 --> Loader Class Initialized
INFO - 2023-01-03 02:52:33 --> Model "Login_model" initialized
INFO - 2023-01-03 02:52:33 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:33 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:33 --> Final output sent to browser
INFO - 2023-01-03 02:52:33 --> Database Driver Class Initialized
DEBUG - 2023-01-03 02:52:33 --> Total execution time: 0.2783
INFO - 2023-01-03 02:52:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:33 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:33 --> Total execution time: 0.2344
INFO - 2023-01-03 02:52:34 --> Config Class Initialized
INFO - 2023-01-03 02:52:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:34 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:34 --> URI Class Initialized
INFO - 2023-01-03 02:52:34 --> Router Class Initialized
INFO - 2023-01-03 02:52:34 --> Output Class Initialized
INFO - 2023-01-03 02:52:34 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:34 --> Input Class Initialized
INFO - 2023-01-03 02:52:34 --> Language Class Initialized
INFO - 2023-01-03 02:52:34 --> Loader Class Initialized
INFO - 2023-01-03 02:52:34 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:34 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:34 --> Total execution time: 0.1699
INFO - 2023-01-03 02:52:34 --> Config Class Initialized
INFO - 2023-01-03 02:52:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:34 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:34 --> URI Class Initialized
INFO - 2023-01-03 02:52:34 --> Router Class Initialized
INFO - 2023-01-03 02:52:34 --> Output Class Initialized
INFO - 2023-01-03 02:52:34 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:34 --> Input Class Initialized
INFO - 2023-01-03 02:52:34 --> Language Class Initialized
INFO - 2023-01-03 02:52:34 --> Loader Class Initialized
INFO - 2023-01-03 02:52:34 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:34 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:34 --> Total execution time: 0.1535
INFO - 2023-01-03 02:52:36 --> Config Class Initialized
INFO - 2023-01-03 02:52:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:36 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:36 --> URI Class Initialized
INFO - 2023-01-03 02:52:36 --> Router Class Initialized
INFO - 2023-01-03 02:52:36 --> Output Class Initialized
INFO - 2023-01-03 02:52:36 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:36 --> Input Class Initialized
INFO - 2023-01-03 02:52:36 --> Language Class Initialized
INFO - 2023-01-03 02:52:36 --> Loader Class Initialized
INFO - 2023-01-03 02:52:36 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:36 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:36 --> Total execution time: 0.1405
INFO - 2023-01-03 02:52:36 --> Config Class Initialized
INFO - 2023-01-03 02:52:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:36 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:36 --> URI Class Initialized
INFO - 2023-01-03 02:52:36 --> Router Class Initialized
INFO - 2023-01-03 02:52:36 --> Output Class Initialized
INFO - 2023-01-03 02:52:36 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:36 --> Input Class Initialized
INFO - 2023-01-03 02:52:36 --> Language Class Initialized
INFO - 2023-01-03 02:52:36 --> Loader Class Initialized
INFO - 2023-01-03 02:52:36 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:36 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:36 --> Model "Login_model" initialized
INFO - 2023-01-03 02:52:36 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:36 --> Model "Cluster_model" initialized
ERROR - 2023-01-03 02:52:36 --> Query error:  - Invalid query: 
INFO - 2023-01-03 02:52:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-03 02:52:38 --> Config Class Initialized
INFO - 2023-01-03 02:52:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:38 --> URI Class Initialized
INFO - 2023-01-03 02:52:38 --> Router Class Initialized
INFO - 2023-01-03 02:52:38 --> Output Class Initialized
INFO - 2023-01-03 02:52:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:38 --> Input Class Initialized
INFO - 2023-01-03 02:52:38 --> Language Class Initialized
INFO - 2023-01-03 02:52:38 --> Loader Class Initialized
INFO - 2023-01-03 02:52:38 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:38 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:38 --> Total execution time: 0.1867
INFO - 2023-01-03 02:52:41 --> Config Class Initialized
INFO - 2023-01-03 02:52:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:41 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:41 --> URI Class Initialized
INFO - 2023-01-03 02:52:41 --> Router Class Initialized
INFO - 2023-01-03 02:52:41 --> Output Class Initialized
INFO - 2023-01-03 02:52:41 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:41 --> Input Class Initialized
INFO - 2023-01-03 02:52:41 --> Language Class Initialized
INFO - 2023-01-03 02:52:41 --> Loader Class Initialized
INFO - 2023-01-03 02:52:41 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:41 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:41 --> Total execution time: 0.1250
INFO - 2023-01-03 02:52:41 --> Config Class Initialized
INFO - 2023-01-03 02:52:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:41 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:41 --> URI Class Initialized
INFO - 2023-01-03 02:52:41 --> Router Class Initialized
INFO - 2023-01-03 02:52:41 --> Output Class Initialized
INFO - 2023-01-03 02:52:41 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:41 --> Input Class Initialized
INFO - 2023-01-03 02:52:41 --> Language Class Initialized
INFO - 2023-01-03 02:52:41 --> Loader Class Initialized
INFO - 2023-01-03 02:52:41 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:41 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:41 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:41 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:41 --> Total execution time: 0.1545
INFO - 2023-01-03 02:52:41 --> Config Class Initialized
INFO - 2023-01-03 02:52:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:41 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:41 --> URI Class Initialized
INFO - 2023-01-03 02:52:41 --> Router Class Initialized
INFO - 2023-01-03 02:52:41 --> Output Class Initialized
INFO - 2023-01-03 02:52:41 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:41 --> Input Class Initialized
INFO - 2023-01-03 02:52:41 --> Language Class Initialized
INFO - 2023-01-03 02:52:41 --> Loader Class Initialized
INFO - 2023-01-03 02:52:41 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:41 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:41 --> Total execution time: 0.1142
INFO - 2023-01-03 02:52:41 --> Config Class Initialized
INFO - 2023-01-03 02:52:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:41 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:41 --> URI Class Initialized
INFO - 2023-01-03 02:52:41 --> Router Class Initialized
INFO - 2023-01-03 02:52:41 --> Output Class Initialized
INFO - 2023-01-03 02:52:41 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:41 --> Input Class Initialized
INFO - 2023-01-03 02:52:41 --> Language Class Initialized
INFO - 2023-01-03 02:52:41 --> Loader Class Initialized
INFO - 2023-01-03 02:52:41 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:41 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:41 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:41 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:41 --> Total execution time: 0.1365
INFO - 2023-01-03 02:52:54 --> Config Class Initialized
INFO - 2023-01-03 02:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:54 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:54 --> URI Class Initialized
INFO - 2023-01-03 02:52:54 --> Router Class Initialized
INFO - 2023-01-03 02:52:54 --> Output Class Initialized
INFO - 2023-01-03 02:52:54 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:54 --> Input Class Initialized
INFO - 2023-01-03 02:52:54 --> Language Class Initialized
INFO - 2023-01-03 02:52:54 --> Loader Class Initialized
INFO - 2023-01-03 02:52:54 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:54 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:54 --> Total execution time: 0.1192
INFO - 2023-01-03 02:52:54 --> Config Class Initialized
INFO - 2023-01-03 02:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:54 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:54 --> URI Class Initialized
INFO - 2023-01-03 02:52:54 --> Router Class Initialized
INFO - 2023-01-03 02:52:54 --> Output Class Initialized
INFO - 2023-01-03 02:52:54 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:54 --> Input Class Initialized
INFO - 2023-01-03 02:52:54 --> Language Class Initialized
INFO - 2023-01-03 02:52:54 --> Loader Class Initialized
INFO - 2023-01-03 02:52:54 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:54 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:54 --> Model "Login_model" initialized
INFO - 2023-01-03 02:52:54 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:54 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:54 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:54 --> Total execution time: 0.1597
INFO - 2023-01-03 02:52:54 --> Config Class Initialized
INFO - 2023-01-03 02:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:54 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:54 --> URI Class Initialized
INFO - 2023-01-03 02:52:54 --> Router Class Initialized
INFO - 2023-01-03 02:52:55 --> Output Class Initialized
INFO - 2023-01-03 02:52:55 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:55 --> Input Class Initialized
INFO - 2023-01-03 02:52:55 --> Language Class Initialized
INFO - 2023-01-03 02:52:55 --> Loader Class Initialized
INFO - 2023-01-03 02:52:55 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:55 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:55 --> Total execution time: 0.1288
INFO - 2023-01-03 02:52:55 --> Config Class Initialized
INFO - 2023-01-03 02:52:55 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:55 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:55 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:55 --> URI Class Initialized
INFO - 2023-01-03 02:52:55 --> Router Class Initialized
INFO - 2023-01-03 02:52:55 --> Output Class Initialized
INFO - 2023-01-03 02:52:55 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:55 --> Input Class Initialized
INFO - 2023-01-03 02:52:55 --> Language Class Initialized
INFO - 2023-01-03 02:52:55 --> Loader Class Initialized
INFO - 2023-01-03 02:52:55 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:55 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:55 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:55 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:55 --> Total execution time: 0.1723
INFO - 2023-01-03 02:52:59 --> Config Class Initialized
INFO - 2023-01-03 02:52:59 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:52:59 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:52:59 --> Utf8 Class Initialized
INFO - 2023-01-03 02:52:59 --> URI Class Initialized
INFO - 2023-01-03 02:52:59 --> Router Class Initialized
INFO - 2023-01-03 02:52:59 --> Output Class Initialized
INFO - 2023-01-03 02:52:59 --> Security Class Initialized
DEBUG - 2023-01-03 02:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:52:59 --> Input Class Initialized
INFO - 2023-01-03 02:52:59 --> Language Class Initialized
INFO - 2023-01-03 02:52:59 --> Loader Class Initialized
INFO - 2023-01-03 02:52:59 --> Controller Class Initialized
DEBUG - 2023-01-03 02:52:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:52:59 --> Database Driver Class Initialized
INFO - 2023-01-03 02:52:59 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:52:59 --> Final output sent to browser
DEBUG - 2023-01-03 02:52:59 --> Total execution time: 0.1592
INFO - 2023-01-03 02:53:04 --> Config Class Initialized
INFO - 2023-01-03 02:53:04 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:04 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:04 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:04 --> URI Class Initialized
INFO - 2023-01-03 02:53:04 --> Router Class Initialized
INFO - 2023-01-03 02:53:04 --> Output Class Initialized
INFO - 2023-01-03 02:53:04 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:04 --> Input Class Initialized
INFO - 2023-01-03 02:53:04 --> Language Class Initialized
INFO - 2023-01-03 02:53:04 --> Loader Class Initialized
INFO - 2023-01-03 02:53:04 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:04 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:04 --> Total execution time: 0.0968
INFO - 2023-01-03 02:53:04 --> Config Class Initialized
INFO - 2023-01-03 02:53:04 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:04 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:04 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:04 --> URI Class Initialized
INFO - 2023-01-03 02:53:04 --> Router Class Initialized
INFO - 2023-01-03 02:53:04 --> Output Class Initialized
INFO - 2023-01-03 02:53:04 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:04 --> Input Class Initialized
INFO - 2023-01-03 02:53:04 --> Language Class Initialized
INFO - 2023-01-03 02:53:04 --> Loader Class Initialized
INFO - 2023-01-03 02:53:05 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:05 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:05 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:53:06 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:06 --> Total execution time: 1.7821
INFO - 2023-01-03 02:53:09 --> Config Class Initialized
INFO - 2023-01-03 02:53:09 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:09 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:09 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:09 --> URI Class Initialized
INFO - 2023-01-03 02:53:09 --> Router Class Initialized
INFO - 2023-01-03 02:53:09 --> Output Class Initialized
INFO - 2023-01-03 02:53:09 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:09 --> Input Class Initialized
INFO - 2023-01-03 02:53:09 --> Language Class Initialized
INFO - 2023-01-03 02:53:09 --> Loader Class Initialized
INFO - 2023-01-03 02:53:09 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:09 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:09 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:53:09 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:09 --> Total execution time: 0.1449
INFO - 2023-01-03 02:53:14 --> Config Class Initialized
INFO - 2023-01-03 02:53:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:14 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:14 --> URI Class Initialized
INFO - 2023-01-03 02:53:14 --> Router Class Initialized
INFO - 2023-01-03 02:53:14 --> Output Class Initialized
INFO - 2023-01-03 02:53:14 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:14 --> Input Class Initialized
INFO - 2023-01-03 02:53:14 --> Language Class Initialized
INFO - 2023-01-03 02:53:14 --> Loader Class Initialized
INFO - 2023-01-03 02:53:14 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:14 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:14 --> Total execution time: 0.0950
INFO - 2023-01-03 02:53:14 --> Config Class Initialized
INFO - 2023-01-03 02:53:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:14 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:14 --> URI Class Initialized
INFO - 2023-01-03 02:53:14 --> Router Class Initialized
INFO - 2023-01-03 02:53:14 --> Output Class Initialized
INFO - 2023-01-03 02:53:14 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:14 --> Input Class Initialized
INFO - 2023-01-03 02:53:14 --> Language Class Initialized
INFO - 2023-01-03 02:53:15 --> Loader Class Initialized
INFO - 2023-01-03 02:53:15 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:15 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:53:15 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:15 --> Total execution time: 0.1446
INFO - 2023-01-03 02:53:19 --> Config Class Initialized
INFO - 2023-01-03 02:53:19 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:19 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:19 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:19 --> URI Class Initialized
INFO - 2023-01-03 02:53:19 --> Router Class Initialized
INFO - 2023-01-03 02:53:19 --> Output Class Initialized
INFO - 2023-01-03 02:53:19 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:19 --> Input Class Initialized
INFO - 2023-01-03 02:53:19 --> Language Class Initialized
INFO - 2023-01-03 02:53:19 --> Loader Class Initialized
INFO - 2023-01-03 02:53:19 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:19 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:19 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:53:19 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:19 --> Total execution time: 0.1491
INFO - 2023-01-03 02:53:24 --> Config Class Initialized
INFO - 2023-01-03 02:53:24 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:24 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:24 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:24 --> URI Class Initialized
INFO - 2023-01-03 02:53:24 --> Router Class Initialized
INFO - 2023-01-03 02:53:24 --> Output Class Initialized
INFO - 2023-01-03 02:53:24 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:24 --> Input Class Initialized
INFO - 2023-01-03 02:53:24 --> Language Class Initialized
INFO - 2023-01-03 02:53:24 --> Loader Class Initialized
INFO - 2023-01-03 02:53:24 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:24 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:24 --> Total execution time: 0.0951
INFO - 2023-01-03 02:53:24 --> Config Class Initialized
INFO - 2023-01-03 02:53:24 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:24 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:24 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:24 --> URI Class Initialized
INFO - 2023-01-03 02:53:24 --> Router Class Initialized
INFO - 2023-01-03 02:53:24 --> Output Class Initialized
INFO - 2023-01-03 02:53:24 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:24 --> Input Class Initialized
INFO - 2023-01-03 02:53:24 --> Language Class Initialized
INFO - 2023-01-03 02:53:25 --> Loader Class Initialized
INFO - 2023-01-03 02:53:25 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:25 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:53:25 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:25 --> Total execution time: 0.1325
INFO - 2023-01-03 02:53:28 --> Config Class Initialized
INFO - 2023-01-03 02:53:28 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:28 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:28 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:28 --> URI Class Initialized
INFO - 2023-01-03 02:53:28 --> Router Class Initialized
INFO - 2023-01-03 02:53:28 --> Output Class Initialized
INFO - 2023-01-03 02:53:28 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:28 --> Input Class Initialized
INFO - 2023-01-03 02:53:28 --> Language Class Initialized
INFO - 2023-01-03 02:53:28 --> Loader Class Initialized
INFO - 2023-01-03 02:53:28 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:28 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:28 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:53:28 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:28 --> Model "Login_model" initialized
INFO - 2023-01-03 02:53:28 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:28 --> Total execution time: 0.1991
INFO - 2023-01-03 02:53:28 --> Config Class Initialized
INFO - 2023-01-03 02:53:28 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:53:28 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:53:28 --> Utf8 Class Initialized
INFO - 2023-01-03 02:53:28 --> URI Class Initialized
INFO - 2023-01-03 02:53:28 --> Router Class Initialized
INFO - 2023-01-03 02:53:28 --> Output Class Initialized
INFO - 2023-01-03 02:53:28 --> Security Class Initialized
DEBUG - 2023-01-03 02:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:53:28 --> Input Class Initialized
INFO - 2023-01-03 02:53:28 --> Language Class Initialized
INFO - 2023-01-03 02:53:28 --> Loader Class Initialized
INFO - 2023-01-03 02:53:28 --> Controller Class Initialized
DEBUG - 2023-01-03 02:53:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:53:28 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:28 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:53:28 --> Database Driver Class Initialized
INFO - 2023-01-03 02:53:28 --> Model "Login_model" initialized
INFO - 2023-01-03 02:53:28 --> Final output sent to browser
DEBUG - 2023-01-03 02:53:28 --> Total execution time: 0.1805
INFO - 2023-01-03 02:55:02 --> Config Class Initialized
INFO - 2023-01-03 02:55:02 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:02 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:02 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:02 --> URI Class Initialized
INFO - 2023-01-03 02:55:02 --> Router Class Initialized
INFO - 2023-01-03 02:55:02 --> Output Class Initialized
INFO - 2023-01-03 02:55:02 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:02 --> Input Class Initialized
INFO - 2023-01-03 02:55:02 --> Language Class Initialized
INFO - 2023-01-03 02:55:02 --> Loader Class Initialized
INFO - 2023-01-03 02:55:02 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:02 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:02 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:03 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:03 --> Model "Login_model" initialized
INFO - 2023-01-03 02:55:03 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:03 --> Total execution time: 0.2800
INFO - 2023-01-03 02:55:03 --> Config Class Initialized
INFO - 2023-01-03 02:55:03 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:03 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:03 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:03 --> URI Class Initialized
INFO - 2023-01-03 02:55:03 --> Router Class Initialized
INFO - 2023-01-03 02:55:03 --> Output Class Initialized
INFO - 2023-01-03 02:55:03 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:03 --> Input Class Initialized
INFO - 2023-01-03 02:55:03 --> Language Class Initialized
INFO - 2023-01-03 02:55:03 --> Loader Class Initialized
INFO - 2023-01-03 02:55:03 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:03 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:03 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:03 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:03 --> Model "Login_model" initialized
INFO - 2023-01-03 02:55:03 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:03 --> Total execution time: 0.2765
INFO - 2023-01-03 02:55:13 --> Config Class Initialized
INFO - 2023-01-03 02:55:13 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:13 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:13 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:13 --> URI Class Initialized
INFO - 2023-01-03 02:55:13 --> Router Class Initialized
INFO - 2023-01-03 02:55:13 --> Output Class Initialized
INFO - 2023-01-03 02:55:13 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:13 --> Input Class Initialized
INFO - 2023-01-03 02:55:13 --> Language Class Initialized
INFO - 2023-01-03 02:55:13 --> Loader Class Initialized
INFO - 2023-01-03 02:55:13 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:14 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:14 --> Total execution time: 0.1272
INFO - 2023-01-03 02:55:14 --> Config Class Initialized
INFO - 2023-01-03 02:55:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:14 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:14 --> URI Class Initialized
INFO - 2023-01-03 02:55:14 --> Router Class Initialized
INFO - 2023-01-03 02:55:14 --> Output Class Initialized
INFO - 2023-01-03 02:55:14 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:14 --> Input Class Initialized
INFO - 2023-01-03 02:55:14 --> Language Class Initialized
INFO - 2023-01-03 02:55:14 --> Loader Class Initialized
INFO - 2023-01-03 02:55:14 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:14 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:14 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:14 --> Total execution time: 0.1578
INFO - 2023-01-03 02:55:14 --> Config Class Initialized
INFO - 2023-01-03 02:55:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:14 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:14 --> URI Class Initialized
INFO - 2023-01-03 02:55:14 --> Router Class Initialized
INFO - 2023-01-03 02:55:14 --> Output Class Initialized
INFO - 2023-01-03 02:55:14 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:14 --> Input Class Initialized
INFO - 2023-01-03 02:55:14 --> Language Class Initialized
INFO - 2023-01-03 02:55:14 --> Loader Class Initialized
INFO - 2023-01-03 02:55:14 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:14 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:14 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:14 --> Total execution time: 0.1628
INFO - 2023-01-03 02:55:14 --> Config Class Initialized
INFO - 2023-01-03 02:55:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:14 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:14 --> URI Class Initialized
INFO - 2023-01-03 02:55:14 --> Router Class Initialized
INFO - 2023-01-03 02:55:14 --> Output Class Initialized
INFO - 2023-01-03 02:55:14 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:14 --> Input Class Initialized
INFO - 2023-01-03 02:55:14 --> Language Class Initialized
INFO - 2023-01-03 02:55:14 --> Loader Class Initialized
INFO - 2023-01-03 02:55:14 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:14 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:14 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:14 --> Total execution time: 0.1600
INFO - 2023-01-03 02:55:15 --> Config Class Initialized
INFO - 2023-01-03 02:55:15 --> Config Class Initialized
INFO - 2023-01-03 02:55:15 --> Hooks Class Initialized
INFO - 2023-01-03 02:55:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 02:55:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:15 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:15 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:15 --> URI Class Initialized
INFO - 2023-01-03 02:55:15 --> URI Class Initialized
INFO - 2023-01-03 02:55:15 --> Router Class Initialized
INFO - 2023-01-03 02:55:15 --> Router Class Initialized
INFO - 2023-01-03 02:55:15 --> Output Class Initialized
INFO - 2023-01-03 02:55:15 --> Output Class Initialized
INFO - 2023-01-03 02:55:15 --> Security Class Initialized
INFO - 2023-01-03 02:55:15 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 02:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:15 --> Input Class Initialized
INFO - 2023-01-03 02:55:15 --> Input Class Initialized
INFO - 2023-01-03 02:55:15 --> Language Class Initialized
INFO - 2023-01-03 02:55:15 --> Language Class Initialized
INFO - 2023-01-03 02:55:15 --> Loader Class Initialized
INFO - 2023-01-03 02:55:15 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:15 --> Loader Class Initialized
INFO - 2023-01-03 02:55:15 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:15 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:15 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:15 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:15 --> Total execution time: 0.2506
INFO - 2023-01-03 02:55:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:15 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:15 --> Total execution time: 0.2732
INFO - 2023-01-03 02:55:15 --> Config Class Initialized
INFO - 2023-01-03 02:55:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:15 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:15 --> URI Class Initialized
INFO - 2023-01-03 02:55:15 --> Router Class Initialized
INFO - 2023-01-03 02:55:15 --> Output Class Initialized
INFO - 2023-01-03 02:55:15 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:15 --> Input Class Initialized
INFO - 2023-01-03 02:55:15 --> Language Class Initialized
INFO - 2023-01-03 02:55:15 --> Loader Class Initialized
INFO - 2023-01-03 02:55:15 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:15 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:15 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:15 --> Total execution time: 0.1420
INFO - 2023-01-03 02:55:16 --> Config Class Initialized
INFO - 2023-01-03 02:55:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:16 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:16 --> URI Class Initialized
INFO - 2023-01-03 02:55:16 --> Router Class Initialized
INFO - 2023-01-03 02:55:16 --> Output Class Initialized
INFO - 2023-01-03 02:55:16 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:16 --> Input Class Initialized
INFO - 2023-01-03 02:55:16 --> Language Class Initialized
INFO - 2023-01-03 02:55:16 --> Loader Class Initialized
INFO - 2023-01-03 02:55:17 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:17 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:17 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:17 --> Total execution time: 0.2297
INFO - 2023-01-03 02:55:17 --> Config Class Initialized
INFO - 2023-01-03 02:55:17 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:17 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:17 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:17 --> URI Class Initialized
INFO - 2023-01-03 02:55:17 --> Router Class Initialized
INFO - 2023-01-03 02:55:17 --> Output Class Initialized
INFO - 2023-01-03 02:55:17 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:17 --> Input Class Initialized
INFO - 2023-01-03 02:55:17 --> Language Class Initialized
INFO - 2023-01-03 02:55:17 --> Loader Class Initialized
INFO - 2023-01-03 02:55:17 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:17 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:17 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:17 --> Total execution time: 0.1823
INFO - 2023-01-03 02:55:21 --> Config Class Initialized
INFO - 2023-01-03 02:55:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:21 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:21 --> URI Class Initialized
INFO - 2023-01-03 02:55:21 --> Router Class Initialized
INFO - 2023-01-03 02:55:21 --> Output Class Initialized
INFO - 2023-01-03 02:55:21 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:21 --> Input Class Initialized
INFO - 2023-01-03 02:55:21 --> Language Class Initialized
INFO - 2023-01-03 02:55:21 --> Loader Class Initialized
INFO - 2023-01-03 02:55:21 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:21 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:21 --> Total execution time: 0.1052
INFO - 2023-01-03 02:55:21 --> Config Class Initialized
INFO - 2023-01-03 02:55:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:21 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:21 --> URI Class Initialized
INFO - 2023-01-03 02:55:21 --> Router Class Initialized
INFO - 2023-01-03 02:55:21 --> Output Class Initialized
INFO - 2023-01-03 02:55:21 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:21 --> Input Class Initialized
INFO - 2023-01-03 02:55:21 --> Language Class Initialized
INFO - 2023-01-03 02:55:21 --> Loader Class Initialized
INFO - 2023-01-03 02:55:21 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:21 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:21 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:21 --> Model "Mysql_model" initialized
INFO - 2023-01-03 02:55:21 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:55:21 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:21 --> Total execution time: 0.1545
INFO - 2023-01-03 02:55:25 --> Config Class Initialized
INFO - 2023-01-03 02:55:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:25 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:25 --> URI Class Initialized
INFO - 2023-01-03 02:55:25 --> Router Class Initialized
INFO - 2023-01-03 02:55:25 --> Output Class Initialized
INFO - 2023-01-03 02:55:25 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:25 --> Input Class Initialized
INFO - 2023-01-03 02:55:25 --> Language Class Initialized
INFO - 2023-01-03 02:55:25 --> Loader Class Initialized
INFO - 2023-01-03 02:55:25 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:25 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:25 --> Model "Mysql_model" initialized
INFO - 2023-01-03 02:55:25 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:55:25 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:25 --> Total execution time: 0.1683
INFO - 2023-01-03 02:55:26 --> Config Class Initialized
INFO - 2023-01-03 02:55:26 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:26 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:26 --> URI Class Initialized
INFO - 2023-01-03 02:55:26 --> Router Class Initialized
INFO - 2023-01-03 02:55:26 --> Output Class Initialized
INFO - 2023-01-03 02:55:26 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:26 --> Input Class Initialized
INFO - 2023-01-03 02:55:26 --> Language Class Initialized
INFO - 2023-01-03 02:55:26 --> Loader Class Initialized
INFO - 2023-01-03 02:55:26 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:26 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:26 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:26 --> Model "Mysql_model" initialized
INFO - 2023-01-03 02:55:26 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:55:26 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:26 --> Total execution time: 0.1713
INFO - 2023-01-03 02:55:26 --> Config Class Initialized
INFO - 2023-01-03 02:55:27 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:27 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:27 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:27 --> URI Class Initialized
INFO - 2023-01-03 02:55:27 --> Router Class Initialized
INFO - 2023-01-03 02:55:27 --> Output Class Initialized
INFO - 2023-01-03 02:55:27 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:27 --> Input Class Initialized
INFO - 2023-01-03 02:55:27 --> Language Class Initialized
INFO - 2023-01-03 02:55:27 --> Loader Class Initialized
INFO - 2023-01-03 02:55:27 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:27 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:27 --> Total execution time: 0.0905
INFO - 2023-01-03 02:55:27 --> Config Class Initialized
INFO - 2023-01-03 02:55:27 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:27 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:27 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:27 --> URI Class Initialized
INFO - 2023-01-03 02:55:27 --> Router Class Initialized
INFO - 2023-01-03 02:55:27 --> Output Class Initialized
INFO - 2023-01-03 02:55:27 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:27 --> Input Class Initialized
INFO - 2023-01-03 02:55:27 --> Language Class Initialized
INFO - 2023-01-03 02:55:27 --> Loader Class Initialized
INFO - 2023-01-03 02:55:27 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:27 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:27 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:27 --> Model "Mysql_model" initialized
INFO - 2023-01-03 02:55:27 --> Model "Grafana_model" initialized
INFO - 2023-01-03 02:55:27 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:27 --> Total execution time: 0.1526
INFO - 2023-01-03 02:55:30 --> Config Class Initialized
INFO - 2023-01-03 02:55:30 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:30 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:30 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:30 --> URI Class Initialized
INFO - 2023-01-03 02:55:30 --> Router Class Initialized
INFO - 2023-01-03 02:55:30 --> Output Class Initialized
INFO - 2023-01-03 02:55:30 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:30 --> Input Class Initialized
INFO - 2023-01-03 02:55:30 --> Language Class Initialized
INFO - 2023-01-03 02:55:30 --> Loader Class Initialized
INFO - 2023-01-03 02:55:30 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:30 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:30 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:30 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:30 --> Total execution time: 0.2510
INFO - 2023-01-03 02:55:30 --> Config Class Initialized
INFO - 2023-01-03 02:55:30 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:30 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:30 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:30 --> URI Class Initialized
INFO - 2023-01-03 02:55:30 --> Router Class Initialized
INFO - 2023-01-03 02:55:30 --> Output Class Initialized
INFO - 2023-01-03 02:55:30 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:30 --> Input Class Initialized
INFO - 2023-01-03 02:55:30 --> Language Class Initialized
INFO - 2023-01-03 02:55:30 --> Loader Class Initialized
INFO - 2023-01-03 02:55:30 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:30 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:30 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:30 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:30 --> Total execution time: 0.1543
INFO - 2023-01-03 02:55:33 --> Config Class Initialized
INFO - 2023-01-03 02:55:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:34 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:34 --> URI Class Initialized
INFO - 2023-01-03 02:55:34 --> Router Class Initialized
INFO - 2023-01-03 02:55:34 --> Output Class Initialized
INFO - 2023-01-03 02:55:34 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:34 --> Input Class Initialized
INFO - 2023-01-03 02:55:34 --> Language Class Initialized
INFO - 2023-01-03 02:55:34 --> Loader Class Initialized
INFO - 2023-01-03 02:55:34 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:34 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:34 --> Total execution time: 0.1456
INFO - 2023-01-03 02:55:34 --> Config Class Initialized
INFO - 2023-01-03 02:55:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:34 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:34 --> URI Class Initialized
INFO - 2023-01-03 02:55:34 --> Router Class Initialized
INFO - 2023-01-03 02:55:34 --> Output Class Initialized
INFO - 2023-01-03 02:55:34 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:34 --> Input Class Initialized
INFO - 2023-01-03 02:55:34 --> Language Class Initialized
INFO - 2023-01-03 02:55:34 --> Loader Class Initialized
INFO - 2023-01-03 02:55:34 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:34 --> Model "Login_model" initialized
INFO - 2023-01-03 02:55:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:34 --> Model "Cluster_model" initialized
ERROR - 2023-01-03 02:55:34 --> Query error:  - Invalid query: 
INFO - 2023-01-03 02:55:34 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-03 02:55:53 --> Config Class Initialized
INFO - 2023-01-03 02:55:53 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:53 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:53 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:53 --> URI Class Initialized
INFO - 2023-01-03 02:55:53 --> Router Class Initialized
INFO - 2023-01-03 02:55:53 --> Output Class Initialized
INFO - 2023-01-03 02:55:53 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:53 --> Input Class Initialized
INFO - 2023-01-03 02:55:53 --> Language Class Initialized
INFO - 2023-01-03 02:55:53 --> Loader Class Initialized
INFO - 2023-01-03 02:55:53 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:54 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:54 --> Model "Login_model" initialized
INFO - 2023-01-03 02:55:54 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:54 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:54 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:54 --> Total execution time: 0.1857
INFO - 2023-01-03 02:55:54 --> Config Class Initialized
INFO - 2023-01-03 02:55:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:55:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:55:54 --> Utf8 Class Initialized
INFO - 2023-01-03 02:55:54 --> URI Class Initialized
INFO - 2023-01-03 02:55:54 --> Router Class Initialized
INFO - 2023-01-03 02:55:54 --> Output Class Initialized
INFO - 2023-01-03 02:55:54 --> Security Class Initialized
DEBUG - 2023-01-03 02:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:55:54 --> Input Class Initialized
INFO - 2023-01-03 02:55:54 --> Language Class Initialized
INFO - 2023-01-03 02:55:54 --> Loader Class Initialized
INFO - 2023-01-03 02:55:54 --> Controller Class Initialized
DEBUG - 2023-01-03 02:55:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:55:54 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:54 --> Model "Login_model" initialized
INFO - 2023-01-03 02:55:54 --> Database Driver Class Initialized
INFO - 2023-01-03 02:55:54 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:55:54 --> Final output sent to browser
DEBUG - 2023-01-03 02:55:54 --> Total execution time: 0.1722
INFO - 2023-01-03 02:56:13 --> Config Class Initialized
INFO - 2023-01-03 02:56:13 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:56:13 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:56:13 --> Utf8 Class Initialized
INFO - 2023-01-03 02:56:13 --> URI Class Initialized
INFO - 2023-01-03 02:56:13 --> Router Class Initialized
INFO - 2023-01-03 02:56:13 --> Output Class Initialized
INFO - 2023-01-03 02:56:13 --> Security Class Initialized
DEBUG - 2023-01-03 02:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:56:13 --> Input Class Initialized
INFO - 2023-01-03 02:56:13 --> Language Class Initialized
INFO - 2023-01-03 02:56:14 --> Loader Class Initialized
INFO - 2023-01-03 02:56:14 --> Controller Class Initialized
DEBUG - 2023-01-03 02:56:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:56:14 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:14 --> Model "Login_model" initialized
INFO - 2023-01-03 02:56:14 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:56:14 --> Final output sent to browser
DEBUG - 2023-01-03 02:56:14 --> Total execution time: 0.5171
INFO - 2023-01-03 02:56:14 --> Config Class Initialized
INFO - 2023-01-03 02:56:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:56:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:56:14 --> Utf8 Class Initialized
INFO - 2023-01-03 02:56:14 --> URI Class Initialized
INFO - 2023-01-03 02:56:14 --> Router Class Initialized
INFO - 2023-01-03 02:56:14 --> Output Class Initialized
INFO - 2023-01-03 02:56:14 --> Security Class Initialized
DEBUG - 2023-01-03 02:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:56:14 --> Input Class Initialized
INFO - 2023-01-03 02:56:14 --> Language Class Initialized
INFO - 2023-01-03 02:56:14 --> Loader Class Initialized
INFO - 2023-01-03 02:56:14 --> Controller Class Initialized
DEBUG - 2023-01-03 02:56:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:56:14 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:14 --> Model "Login_model" initialized
INFO - 2023-01-03 02:56:14 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:56:14 --> Final output sent to browser
DEBUG - 2023-01-03 02:56:14 --> Total execution time: 0.4977
INFO - 2023-01-03 02:56:33 --> Config Class Initialized
INFO - 2023-01-03 02:56:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:56:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:56:33 --> Utf8 Class Initialized
INFO - 2023-01-03 02:56:33 --> URI Class Initialized
INFO - 2023-01-03 02:56:33 --> Router Class Initialized
INFO - 2023-01-03 02:56:33 --> Output Class Initialized
INFO - 2023-01-03 02:56:33 --> Security Class Initialized
DEBUG - 2023-01-03 02:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:56:33 --> Input Class Initialized
INFO - 2023-01-03 02:56:33 --> Language Class Initialized
INFO - 2023-01-03 02:56:33 --> Loader Class Initialized
INFO - 2023-01-03 02:56:34 --> Controller Class Initialized
DEBUG - 2023-01-03 02:56:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:56:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:34 --> Model "Login_model" initialized
INFO - 2023-01-03 02:56:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:56:34 --> Final output sent to browser
DEBUG - 2023-01-03 02:56:34 --> Total execution time: 0.5095
INFO - 2023-01-03 02:56:34 --> Config Class Initialized
INFO - 2023-01-03 02:56:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:56:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:56:34 --> Utf8 Class Initialized
INFO - 2023-01-03 02:56:34 --> URI Class Initialized
INFO - 2023-01-03 02:56:34 --> Router Class Initialized
INFO - 2023-01-03 02:56:34 --> Output Class Initialized
INFO - 2023-01-03 02:56:34 --> Security Class Initialized
DEBUG - 2023-01-03 02:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:56:34 --> Input Class Initialized
INFO - 2023-01-03 02:56:34 --> Language Class Initialized
INFO - 2023-01-03 02:56:34 --> Loader Class Initialized
INFO - 2023-01-03 02:56:34 --> Controller Class Initialized
DEBUG - 2023-01-03 02:56:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:56:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:34 --> Model "Login_model" initialized
INFO - 2023-01-03 02:56:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:56:34 --> Final output sent to browser
DEBUG - 2023-01-03 02:56:35 --> Total execution time: 0.5164
INFO - 2023-01-03 02:56:40 --> Config Class Initialized
INFO - 2023-01-03 02:56:40 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:56:40 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:56:40 --> Utf8 Class Initialized
INFO - 2023-01-03 02:56:40 --> URI Class Initialized
INFO - 2023-01-03 02:56:40 --> Router Class Initialized
INFO - 2023-01-03 02:56:40 --> Output Class Initialized
INFO - 2023-01-03 02:56:40 --> Security Class Initialized
DEBUG - 2023-01-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:56:40 --> Input Class Initialized
INFO - 2023-01-03 02:56:40 --> Language Class Initialized
INFO - 2023-01-03 02:56:40 --> Loader Class Initialized
INFO - 2023-01-03 02:56:40 --> Controller Class Initialized
DEBUG - 2023-01-03 02:56:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:56:40 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:40 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:56:40 --> Config Class Initialized
INFO - 2023-01-03 02:56:40 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:56:40 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:56:40 --> Utf8 Class Initialized
INFO - 2023-01-03 02:56:40 --> URI Class Initialized
INFO - 2023-01-03 02:56:40 --> Router Class Initialized
INFO - 2023-01-03 02:56:40 --> Output Class Initialized
INFO - 2023-01-03 02:56:40 --> Security Class Initialized
DEBUG - 2023-01-03 02:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:56:41 --> Input Class Initialized
INFO - 2023-01-03 02:56:41 --> Language Class Initialized
INFO - 2023-01-03 02:56:41 --> Loader Class Initialized
INFO - 2023-01-03 02:56:41 --> Controller Class Initialized
DEBUG - 2023-01-03 02:56:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:56:41 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:41 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:56:43 --> Config Class Initialized
INFO - 2023-01-03 02:56:43 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:56:43 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:56:43 --> Utf8 Class Initialized
INFO - 2023-01-03 02:56:43 --> URI Class Initialized
INFO - 2023-01-03 02:56:43 --> Router Class Initialized
INFO - 2023-01-03 02:56:43 --> Output Class Initialized
INFO - 2023-01-03 02:56:43 --> Security Class Initialized
DEBUG - 2023-01-03 02:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:56:43 --> Input Class Initialized
INFO - 2023-01-03 02:56:43 --> Language Class Initialized
INFO - 2023-01-03 02:56:43 --> Loader Class Initialized
INFO - 2023-01-03 02:56:43 --> Controller Class Initialized
DEBUG - 2023-01-03 02:56:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:56:43 --> Final output sent to browser
DEBUG - 2023-01-03 02:56:43 --> Total execution time: 0.1497
INFO - 2023-01-03 02:56:44 --> Config Class Initialized
INFO - 2023-01-03 02:56:44 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:56:44 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:56:44 --> Utf8 Class Initialized
INFO - 2023-01-03 02:56:44 --> URI Class Initialized
INFO - 2023-01-03 02:56:44 --> Router Class Initialized
INFO - 2023-01-03 02:56:44 --> Output Class Initialized
INFO - 2023-01-03 02:56:44 --> Security Class Initialized
DEBUG - 2023-01-03 02:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:56:44 --> Input Class Initialized
INFO - 2023-01-03 02:56:44 --> Language Class Initialized
INFO - 2023-01-03 02:56:44 --> Loader Class Initialized
INFO - 2023-01-03 02:56:44 --> Controller Class Initialized
DEBUG - 2023-01-03 02:56:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:56:44 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:44 --> Model "Login_model" initialized
INFO - 2023-01-03 02:56:44 --> Database Driver Class Initialized
INFO - 2023-01-03 02:56:44 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:03 --> Config Class Initialized
INFO - 2023-01-03 02:57:03 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:03 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:03 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:03 --> URI Class Initialized
INFO - 2023-01-03 02:57:03 --> Router Class Initialized
INFO - 2023-01-03 02:57:03 --> Output Class Initialized
INFO - 2023-01-03 02:57:03 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:03 --> Input Class Initialized
INFO - 2023-01-03 02:57:03 --> Language Class Initialized
INFO - 2023-01-03 02:57:03 --> Loader Class Initialized
INFO - 2023-01-03 02:57:04 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:04 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:04 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:04 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:04 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:04 --> Config Class Initialized
INFO - 2023-01-03 02:57:04 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:04 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:04 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:04 --> URI Class Initialized
INFO - 2023-01-03 02:57:04 --> Router Class Initialized
INFO - 2023-01-03 02:57:04 --> Output Class Initialized
INFO - 2023-01-03 02:57:04 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:04 --> Input Class Initialized
INFO - 2023-01-03 02:57:04 --> Language Class Initialized
INFO - 2023-01-03 02:57:04 --> Loader Class Initialized
INFO - 2023-01-03 02:57:04 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:04 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:04 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:04 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:04 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:16 --> Config Class Initialized
INFO - 2023-01-03 02:57:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:16 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:16 --> URI Class Initialized
INFO - 2023-01-03 02:57:16 --> Router Class Initialized
INFO - 2023-01-03 02:57:16 --> Output Class Initialized
INFO - 2023-01-03 02:57:17 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:17 --> Input Class Initialized
INFO - 2023-01-03 02:57:17 --> Language Class Initialized
INFO - 2023-01-03 02:57:17 --> Loader Class Initialized
INFO - 2023-01-03 02:57:17 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:17 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:17 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:17 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:17 --> Final output sent to browser
DEBUG - 2023-01-03 02:57:17 --> Total execution time: 0.3156
INFO - 2023-01-03 02:57:17 --> Config Class Initialized
INFO - 2023-01-03 02:57:17 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:17 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:17 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:17 --> URI Class Initialized
INFO - 2023-01-03 02:57:17 --> Router Class Initialized
INFO - 2023-01-03 02:57:17 --> Output Class Initialized
INFO - 2023-01-03 02:57:17 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:17 --> Input Class Initialized
INFO - 2023-01-03 02:57:17 --> Language Class Initialized
INFO - 2023-01-03 02:57:17 --> Loader Class Initialized
INFO - 2023-01-03 02:57:17 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:17 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:17 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:17 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:17 --> Final output sent to browser
DEBUG - 2023-01-03 02:57:17 --> Total execution time: 0.2069
INFO - 2023-01-03 02:57:18 --> Config Class Initialized
INFO - 2023-01-03 02:57:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:18 --> URI Class Initialized
INFO - 2023-01-03 02:57:18 --> Router Class Initialized
INFO - 2023-01-03 02:57:18 --> Output Class Initialized
INFO - 2023-01-03 02:57:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:18 --> Input Class Initialized
INFO - 2023-01-03 02:57:18 --> Language Class Initialized
INFO - 2023-01-03 02:57:18 --> Loader Class Initialized
INFO - 2023-01-03 02:57:18 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:18 --> Final output sent to browser
DEBUG - 2023-01-03 02:57:18 --> Total execution time: 0.1450
INFO - 2023-01-03 02:57:18 --> Config Class Initialized
INFO - 2023-01-03 02:57:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:18 --> URI Class Initialized
INFO - 2023-01-03 02:57:18 --> Router Class Initialized
INFO - 2023-01-03 02:57:18 --> Output Class Initialized
INFO - 2023-01-03 02:57:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:18 --> Input Class Initialized
INFO - 2023-01-03 02:57:18 --> Language Class Initialized
INFO - 2023-01-03 02:57:18 --> Loader Class Initialized
INFO - 2023-01-03 02:57:18 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:18 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:18 --> Model "Cluster_model" initialized
ERROR - 2023-01-03 02:57:18 --> Query error:  - Invalid query: 
INFO - 2023-01-03 02:57:18 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-03 02:57:38 --> Config Class Initialized
INFO - 2023-01-03 02:57:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:38 --> URI Class Initialized
INFO - 2023-01-03 02:57:38 --> Router Class Initialized
INFO - 2023-01-03 02:57:38 --> Output Class Initialized
INFO - 2023-01-03 02:57:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:38 --> Input Class Initialized
INFO - 2023-01-03 02:57:38 --> Language Class Initialized
INFO - 2023-01-03 02:57:38 --> Loader Class Initialized
INFO - 2023-01-03 02:57:38 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:38 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:38 --> Final output sent to browser
DEBUG - 2023-01-03 02:57:38 --> Total execution time: 0.1874
INFO - 2023-01-03 02:57:38 --> Config Class Initialized
INFO - 2023-01-03 02:57:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:38 --> URI Class Initialized
INFO - 2023-01-03 02:57:38 --> Router Class Initialized
INFO - 2023-01-03 02:57:38 --> Output Class Initialized
INFO - 2023-01-03 02:57:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:38 --> Input Class Initialized
INFO - 2023-01-03 02:57:38 --> Language Class Initialized
INFO - 2023-01-03 02:57:38 --> Loader Class Initialized
INFO - 2023-01-03 02:57:38 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:38 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:38 --> Final output sent to browser
DEBUG - 2023-01-03 02:57:38 --> Total execution time: 0.1627
INFO - 2023-01-03 02:57:58 --> Config Class Initialized
INFO - 2023-01-03 02:57:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:58 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:58 --> URI Class Initialized
INFO - 2023-01-03 02:57:58 --> Router Class Initialized
INFO - 2023-01-03 02:57:58 --> Output Class Initialized
INFO - 2023-01-03 02:57:58 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:58 --> Input Class Initialized
INFO - 2023-01-03 02:57:58 --> Language Class Initialized
INFO - 2023-01-03 02:57:58 --> Loader Class Initialized
INFO - 2023-01-03 02:57:58 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:58 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:58 --> Final output sent to browser
DEBUG - 2023-01-03 02:57:58 --> Total execution time: 0.1882
INFO - 2023-01-03 02:57:58 --> Config Class Initialized
INFO - 2023-01-03 02:57:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:57:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:57:58 --> Utf8 Class Initialized
INFO - 2023-01-03 02:57:58 --> URI Class Initialized
INFO - 2023-01-03 02:57:58 --> Router Class Initialized
INFO - 2023-01-03 02:57:58 --> Output Class Initialized
INFO - 2023-01-03 02:57:58 --> Security Class Initialized
DEBUG - 2023-01-03 02:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:57:58 --> Input Class Initialized
INFO - 2023-01-03 02:57:58 --> Language Class Initialized
INFO - 2023-01-03 02:57:58 --> Loader Class Initialized
INFO - 2023-01-03 02:57:58 --> Controller Class Initialized
DEBUG - 2023-01-03 02:57:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:57:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:58 --> Model "Login_model" initialized
INFO - 2023-01-03 02:57:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:57:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:57:58 --> Final output sent to browser
DEBUG - 2023-01-03 02:57:58 --> Total execution time: 0.4872
INFO - 2023-01-03 02:58:18 --> Config Class Initialized
INFO - 2023-01-03 02:58:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:58:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:58:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:58:18 --> URI Class Initialized
INFO - 2023-01-03 02:58:18 --> Router Class Initialized
INFO - 2023-01-03 02:58:18 --> Output Class Initialized
INFO - 2023-01-03 02:58:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:58:18 --> Input Class Initialized
INFO - 2023-01-03 02:58:18 --> Language Class Initialized
INFO - 2023-01-03 02:58:18 --> Loader Class Initialized
INFO - 2023-01-03 02:58:18 --> Controller Class Initialized
DEBUG - 2023-01-03 02:58:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:58:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:18 --> Model "Login_model" initialized
INFO - 2023-01-03 02:58:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:58:18 --> Final output sent to browser
DEBUG - 2023-01-03 02:58:18 --> Total execution time: 0.1875
INFO - 2023-01-03 02:58:18 --> Config Class Initialized
INFO - 2023-01-03 02:58:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:58:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:58:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:58:18 --> URI Class Initialized
INFO - 2023-01-03 02:58:18 --> Router Class Initialized
INFO - 2023-01-03 02:58:18 --> Output Class Initialized
INFO - 2023-01-03 02:58:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:58:18 --> Input Class Initialized
INFO - 2023-01-03 02:58:18 --> Language Class Initialized
INFO - 2023-01-03 02:58:18 --> Loader Class Initialized
INFO - 2023-01-03 02:58:18 --> Controller Class Initialized
DEBUG - 2023-01-03 02:58:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:58:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:18 --> Model "Login_model" initialized
INFO - 2023-01-03 02:58:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:58:18 --> Final output sent to browser
DEBUG - 2023-01-03 02:58:18 --> Total execution time: 0.1713
INFO - 2023-01-03 02:58:38 --> Config Class Initialized
INFO - 2023-01-03 02:58:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:58:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:58:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:58:38 --> URI Class Initialized
INFO - 2023-01-03 02:58:38 --> Router Class Initialized
INFO - 2023-01-03 02:58:38 --> Output Class Initialized
INFO - 2023-01-03 02:58:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:58:38 --> Input Class Initialized
INFO - 2023-01-03 02:58:38 --> Language Class Initialized
INFO - 2023-01-03 02:58:38 --> Loader Class Initialized
INFO - 2023-01-03 02:58:38 --> Controller Class Initialized
DEBUG - 2023-01-03 02:58:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:58:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:38 --> Model "Login_model" initialized
INFO - 2023-01-03 02:58:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:58:38 --> Final output sent to browser
DEBUG - 2023-01-03 02:58:38 --> Total execution time: 0.1818
INFO - 2023-01-03 02:58:38 --> Config Class Initialized
INFO - 2023-01-03 02:58:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:58:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:58:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:58:38 --> URI Class Initialized
INFO - 2023-01-03 02:58:38 --> Router Class Initialized
INFO - 2023-01-03 02:58:38 --> Output Class Initialized
INFO - 2023-01-03 02:58:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:58:38 --> Input Class Initialized
INFO - 2023-01-03 02:58:38 --> Language Class Initialized
INFO - 2023-01-03 02:58:38 --> Loader Class Initialized
INFO - 2023-01-03 02:58:38 --> Controller Class Initialized
DEBUG - 2023-01-03 02:58:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:58:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:38 --> Model "Login_model" initialized
INFO - 2023-01-03 02:58:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:58:38 --> Final output sent to browser
DEBUG - 2023-01-03 02:58:38 --> Total execution time: 0.1814
INFO - 2023-01-03 02:58:58 --> Config Class Initialized
INFO - 2023-01-03 02:58:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:58:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:58:58 --> Utf8 Class Initialized
INFO - 2023-01-03 02:58:58 --> URI Class Initialized
INFO - 2023-01-03 02:58:58 --> Router Class Initialized
INFO - 2023-01-03 02:58:58 --> Output Class Initialized
INFO - 2023-01-03 02:58:58 --> Security Class Initialized
DEBUG - 2023-01-03 02:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:58:58 --> Input Class Initialized
INFO - 2023-01-03 02:58:58 --> Language Class Initialized
INFO - 2023-01-03 02:58:58 --> Loader Class Initialized
INFO - 2023-01-03 02:58:58 --> Controller Class Initialized
DEBUG - 2023-01-03 02:58:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:58:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:58 --> Model "Login_model" initialized
INFO - 2023-01-03 02:58:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:58:58 --> Final output sent to browser
DEBUG - 2023-01-03 02:58:58 --> Total execution time: 0.2860
INFO - 2023-01-03 02:58:58 --> Config Class Initialized
INFO - 2023-01-03 02:58:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:58:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:58:58 --> Utf8 Class Initialized
INFO - 2023-01-03 02:58:58 --> URI Class Initialized
INFO - 2023-01-03 02:58:58 --> Router Class Initialized
INFO - 2023-01-03 02:58:58 --> Output Class Initialized
INFO - 2023-01-03 02:58:58 --> Security Class Initialized
DEBUG - 2023-01-03 02:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:58:58 --> Input Class Initialized
INFO - 2023-01-03 02:58:58 --> Language Class Initialized
INFO - 2023-01-03 02:58:58 --> Loader Class Initialized
INFO - 2023-01-03 02:58:58 --> Controller Class Initialized
DEBUG - 2023-01-03 02:58:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:58:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:58 --> Model "Login_model" initialized
INFO - 2023-01-03 02:58:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:58:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:58:58 --> Final output sent to browser
DEBUG - 2023-01-03 02:58:58 --> Total execution time: 0.2631
INFO - 2023-01-03 02:59:18 --> Config Class Initialized
INFO - 2023-01-03 02:59:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:59:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:59:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:59:18 --> URI Class Initialized
INFO - 2023-01-03 02:59:18 --> Router Class Initialized
INFO - 2023-01-03 02:59:18 --> Output Class Initialized
INFO - 2023-01-03 02:59:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:59:18 --> Input Class Initialized
INFO - 2023-01-03 02:59:18 --> Language Class Initialized
INFO - 2023-01-03 02:59:18 --> Loader Class Initialized
INFO - 2023-01-03 02:59:18 --> Controller Class Initialized
DEBUG - 2023-01-03 02:59:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:59:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:18 --> Model "Login_model" initialized
INFO - 2023-01-03 02:59:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:59:18 --> Final output sent to browser
DEBUG - 2023-01-03 02:59:18 --> Total execution time: 0.1820
INFO - 2023-01-03 02:59:18 --> Config Class Initialized
INFO - 2023-01-03 02:59:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:59:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:59:18 --> Utf8 Class Initialized
INFO - 2023-01-03 02:59:18 --> URI Class Initialized
INFO - 2023-01-03 02:59:18 --> Router Class Initialized
INFO - 2023-01-03 02:59:18 --> Output Class Initialized
INFO - 2023-01-03 02:59:18 --> Security Class Initialized
DEBUG - 2023-01-03 02:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:59:18 --> Input Class Initialized
INFO - 2023-01-03 02:59:18 --> Language Class Initialized
INFO - 2023-01-03 02:59:18 --> Loader Class Initialized
INFO - 2023-01-03 02:59:18 --> Controller Class Initialized
DEBUG - 2023-01-03 02:59:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:59:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:18 --> Model "Login_model" initialized
INFO - 2023-01-03 02:59:18 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:59:18 --> Final output sent to browser
DEBUG - 2023-01-03 02:59:18 --> Total execution time: 0.1770
INFO - 2023-01-03 02:59:34 --> Config Class Initialized
INFO - 2023-01-03 02:59:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:59:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:59:34 --> Utf8 Class Initialized
INFO - 2023-01-03 02:59:34 --> URI Class Initialized
INFO - 2023-01-03 02:59:34 --> Router Class Initialized
INFO - 2023-01-03 02:59:34 --> Output Class Initialized
INFO - 2023-01-03 02:59:34 --> Security Class Initialized
DEBUG - 2023-01-03 02:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:59:34 --> Input Class Initialized
INFO - 2023-01-03 02:59:34 --> Language Class Initialized
INFO - 2023-01-03 02:59:34 --> Loader Class Initialized
INFO - 2023-01-03 02:59:34 --> Controller Class Initialized
DEBUG - 2023-01-03 02:59:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:59:34 --> Final output sent to browser
DEBUG - 2023-01-03 02:59:34 --> Total execution time: 0.2978
INFO - 2023-01-03 02:59:34 --> Config Class Initialized
INFO - 2023-01-03 02:59:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:59:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:59:34 --> Utf8 Class Initialized
INFO - 2023-01-03 02:59:34 --> URI Class Initialized
INFO - 2023-01-03 02:59:34 --> Router Class Initialized
INFO - 2023-01-03 02:59:34 --> Output Class Initialized
INFO - 2023-01-03 02:59:34 --> Security Class Initialized
DEBUG - 2023-01-03 02:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:59:34 --> Input Class Initialized
INFO - 2023-01-03 02:59:34 --> Language Class Initialized
INFO - 2023-01-03 02:59:34 --> Loader Class Initialized
INFO - 2023-01-03 02:59:34 --> Controller Class Initialized
DEBUG - 2023-01-03 02:59:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:59:34 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:36 --> Model "Login_model" initialized
INFO - 2023-01-03 02:59:38 --> Config Class Initialized
INFO - 2023-01-03 02:59:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:59:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:59:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:59:38 --> URI Class Initialized
INFO - 2023-01-03 02:59:38 --> Router Class Initialized
INFO - 2023-01-03 02:59:38 --> Output Class Initialized
INFO - 2023-01-03 02:59:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:59:38 --> Input Class Initialized
INFO - 2023-01-03 02:59:38 --> Language Class Initialized
INFO - 2023-01-03 02:59:38 --> Loader Class Initialized
INFO - 2023-01-03 02:59:38 --> Controller Class Initialized
DEBUG - 2023-01-03 02:59:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:59:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:38 --> Model "Login_model" initialized
INFO - 2023-01-03 02:59:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:59:38 --> Final output sent to browser
DEBUG - 2023-01-03 02:59:38 --> Total execution time: 0.2377
INFO - 2023-01-03 02:59:38 --> Config Class Initialized
INFO - 2023-01-03 02:59:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:59:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:59:38 --> Utf8 Class Initialized
INFO - 2023-01-03 02:59:38 --> URI Class Initialized
INFO - 2023-01-03 02:59:38 --> Router Class Initialized
INFO - 2023-01-03 02:59:38 --> Output Class Initialized
INFO - 2023-01-03 02:59:38 --> Security Class Initialized
DEBUG - 2023-01-03 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:59:38 --> Input Class Initialized
INFO - 2023-01-03 02:59:38 --> Language Class Initialized
INFO - 2023-01-03 02:59:38 --> Loader Class Initialized
INFO - 2023-01-03 02:59:38 --> Controller Class Initialized
DEBUG - 2023-01-03 02:59:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:59:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:38 --> Model "Login_model" initialized
INFO - 2023-01-03 02:59:38 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:59:38 --> Final output sent to browser
DEBUG - 2023-01-03 02:59:38 --> Total execution time: 0.2438
INFO - 2023-01-03 02:59:58 --> Config Class Initialized
INFO - 2023-01-03 02:59:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:59:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:59:58 --> Utf8 Class Initialized
INFO - 2023-01-03 02:59:58 --> URI Class Initialized
INFO - 2023-01-03 02:59:58 --> Router Class Initialized
INFO - 2023-01-03 02:59:58 --> Output Class Initialized
INFO - 2023-01-03 02:59:58 --> Security Class Initialized
DEBUG - 2023-01-03 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:59:58 --> Input Class Initialized
INFO - 2023-01-03 02:59:58 --> Language Class Initialized
INFO - 2023-01-03 02:59:58 --> Loader Class Initialized
INFO - 2023-01-03 02:59:58 --> Controller Class Initialized
DEBUG - 2023-01-03 02:59:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:59:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:58 --> Model "Login_model" initialized
INFO - 2023-01-03 02:59:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:59:58 --> Final output sent to browser
DEBUG - 2023-01-03 02:59:58 --> Total execution time: 0.2879
INFO - 2023-01-03 02:59:58 --> Config Class Initialized
INFO - 2023-01-03 02:59:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 02:59:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 02:59:58 --> Utf8 Class Initialized
INFO - 2023-01-03 02:59:58 --> URI Class Initialized
INFO - 2023-01-03 02:59:58 --> Router Class Initialized
INFO - 2023-01-03 02:59:58 --> Output Class Initialized
INFO - 2023-01-03 02:59:58 --> Security Class Initialized
DEBUG - 2023-01-03 02:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 02:59:58 --> Input Class Initialized
INFO - 2023-01-03 02:59:58 --> Language Class Initialized
INFO - 2023-01-03 02:59:58 --> Loader Class Initialized
INFO - 2023-01-03 02:59:58 --> Controller Class Initialized
DEBUG - 2023-01-03 02:59:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 02:59:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:58 --> Model "Login_model" initialized
INFO - 2023-01-03 02:59:58 --> Database Driver Class Initialized
INFO - 2023-01-03 02:59:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 02:59:58 --> Final output sent to browser
DEBUG - 2023-01-03 02:59:58 --> Total execution time: 0.3262
INFO - 2023-01-03 03:00:14 --> Config Class Initialized
INFO - 2023-01-03 03:00:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:00:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:00:14 --> Utf8 Class Initialized
INFO - 2023-01-03 03:00:14 --> URI Class Initialized
INFO - 2023-01-03 03:00:14 --> Router Class Initialized
INFO - 2023-01-03 03:00:14 --> Output Class Initialized
INFO - 2023-01-03 03:00:14 --> Security Class Initialized
DEBUG - 2023-01-03 03:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:00:14 --> Input Class Initialized
INFO - 2023-01-03 03:00:14 --> Language Class Initialized
INFO - 2023-01-03 03:00:15 --> Loader Class Initialized
INFO - 2023-01-03 03:00:15 --> Controller Class Initialized
DEBUG - 2023-01-03 03:00:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:00:15 --> Final output sent to browser
DEBUG - 2023-01-03 03:00:15 --> Total execution time: 0.2719
INFO - 2023-01-03 03:00:15 --> Config Class Initialized
INFO - 2023-01-03 03:00:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:00:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:00:15 --> Utf8 Class Initialized
INFO - 2023-01-03 03:00:15 --> URI Class Initialized
INFO - 2023-01-03 03:00:15 --> Router Class Initialized
INFO - 2023-01-03 03:00:15 --> Output Class Initialized
INFO - 2023-01-03 03:00:15 --> Security Class Initialized
DEBUG - 2023-01-03 03:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:00:15 --> Input Class Initialized
INFO - 2023-01-03 03:00:15 --> Language Class Initialized
INFO - 2023-01-03 03:00:15 --> Loader Class Initialized
INFO - 2023-01-03 03:00:15 --> Controller Class Initialized
DEBUG - 2023-01-03 03:00:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:00:15 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:15 --> Model "Login_model" initialized
INFO - 2023-01-03 03:00:18 --> Config Class Initialized
INFO - 2023-01-03 03:00:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:00:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:00:18 --> Utf8 Class Initialized
INFO - 2023-01-03 03:00:18 --> URI Class Initialized
INFO - 2023-01-03 03:00:18 --> Router Class Initialized
INFO - 2023-01-03 03:00:18 --> Output Class Initialized
INFO - 2023-01-03 03:00:18 --> Security Class Initialized
DEBUG - 2023-01-03 03:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:00:18 --> Input Class Initialized
INFO - 2023-01-03 03:00:18 --> Language Class Initialized
INFO - 2023-01-03 03:00:18 --> Loader Class Initialized
INFO - 2023-01-03 03:00:18 --> Controller Class Initialized
DEBUG - 2023-01-03 03:00:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:00:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:18 --> Model "Login_model" initialized
INFO - 2023-01-03 03:00:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:00:18 --> Final output sent to browser
DEBUG - 2023-01-03 03:00:18 --> Total execution time: 0.3189
INFO - 2023-01-03 03:00:18 --> Config Class Initialized
INFO - 2023-01-03 03:00:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:00:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:00:18 --> Utf8 Class Initialized
INFO - 2023-01-03 03:00:18 --> URI Class Initialized
INFO - 2023-01-03 03:00:18 --> Router Class Initialized
INFO - 2023-01-03 03:00:18 --> Output Class Initialized
INFO - 2023-01-03 03:00:18 --> Security Class Initialized
DEBUG - 2023-01-03 03:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:00:18 --> Input Class Initialized
INFO - 2023-01-03 03:00:18 --> Language Class Initialized
INFO - 2023-01-03 03:00:18 --> Loader Class Initialized
INFO - 2023-01-03 03:00:18 --> Controller Class Initialized
DEBUG - 2023-01-03 03:00:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:00:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:18 --> Model "Login_model" initialized
INFO - 2023-01-03 03:00:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:00:18 --> Final output sent to browser
DEBUG - 2023-01-03 03:00:18 --> Total execution time: 0.3291
INFO - 2023-01-03 03:00:38 --> Config Class Initialized
INFO - 2023-01-03 03:00:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:00:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:00:38 --> Utf8 Class Initialized
INFO - 2023-01-03 03:00:38 --> URI Class Initialized
INFO - 2023-01-03 03:00:38 --> Router Class Initialized
INFO - 2023-01-03 03:00:38 --> Output Class Initialized
INFO - 2023-01-03 03:00:38 --> Security Class Initialized
DEBUG - 2023-01-03 03:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:00:38 --> Input Class Initialized
INFO - 2023-01-03 03:00:38 --> Language Class Initialized
INFO - 2023-01-03 03:00:38 --> Loader Class Initialized
INFO - 2023-01-03 03:00:38 --> Controller Class Initialized
DEBUG - 2023-01-03 03:00:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:00:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:38 --> Model "Login_model" initialized
INFO - 2023-01-03 03:00:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:00:38 --> Final output sent to browser
DEBUG - 2023-01-03 03:00:38 --> Total execution time: 0.3879
INFO - 2023-01-03 03:00:38 --> Config Class Initialized
INFO - 2023-01-03 03:00:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:00:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:00:38 --> Utf8 Class Initialized
INFO - 2023-01-03 03:00:38 --> URI Class Initialized
INFO - 2023-01-03 03:00:38 --> Router Class Initialized
INFO - 2023-01-03 03:00:38 --> Output Class Initialized
INFO - 2023-01-03 03:00:38 --> Security Class Initialized
DEBUG - 2023-01-03 03:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:00:38 --> Input Class Initialized
INFO - 2023-01-03 03:00:38 --> Language Class Initialized
INFO - 2023-01-03 03:00:38 --> Loader Class Initialized
INFO - 2023-01-03 03:00:38 --> Controller Class Initialized
DEBUG - 2023-01-03 03:00:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:00:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:38 --> Model "Login_model" initialized
INFO - 2023-01-03 03:00:39 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:39 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:00:39 --> Final output sent to browser
DEBUG - 2023-01-03 03:00:39 --> Total execution time: 0.3457
INFO - 2023-01-03 03:00:58 --> Config Class Initialized
INFO - 2023-01-03 03:00:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:00:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:00:58 --> Utf8 Class Initialized
INFO - 2023-01-03 03:00:58 --> URI Class Initialized
INFO - 2023-01-03 03:00:58 --> Router Class Initialized
INFO - 2023-01-03 03:00:58 --> Output Class Initialized
INFO - 2023-01-03 03:00:58 --> Security Class Initialized
DEBUG - 2023-01-03 03:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:00:58 --> Input Class Initialized
INFO - 2023-01-03 03:00:58 --> Language Class Initialized
INFO - 2023-01-03 03:00:58 --> Loader Class Initialized
INFO - 2023-01-03 03:00:58 --> Controller Class Initialized
DEBUG - 2023-01-03 03:00:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:00:58 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:58 --> Model "Login_model" initialized
INFO - 2023-01-03 03:00:58 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:00:58 --> Final output sent to browser
DEBUG - 2023-01-03 03:00:58 --> Total execution time: 0.2297
INFO - 2023-01-03 03:00:58 --> Config Class Initialized
INFO - 2023-01-03 03:00:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:00:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:00:58 --> Utf8 Class Initialized
INFO - 2023-01-03 03:00:58 --> URI Class Initialized
INFO - 2023-01-03 03:00:58 --> Router Class Initialized
INFO - 2023-01-03 03:00:58 --> Output Class Initialized
INFO - 2023-01-03 03:00:58 --> Security Class Initialized
DEBUG - 2023-01-03 03:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:00:58 --> Input Class Initialized
INFO - 2023-01-03 03:00:58 --> Language Class Initialized
INFO - 2023-01-03 03:00:58 --> Loader Class Initialized
INFO - 2023-01-03 03:00:58 --> Controller Class Initialized
DEBUG - 2023-01-03 03:00:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:00:58 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:58 --> Model "Login_model" initialized
INFO - 2023-01-03 03:00:58 --> Database Driver Class Initialized
INFO - 2023-01-03 03:00:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:00:58 --> Final output sent to browser
DEBUG - 2023-01-03 03:00:58 --> Total execution time: 0.2505
INFO - 2023-01-03 03:01:18 --> Config Class Initialized
INFO - 2023-01-03 03:01:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:01:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:01:18 --> Utf8 Class Initialized
INFO - 2023-01-03 03:01:18 --> URI Class Initialized
INFO - 2023-01-03 03:01:18 --> Router Class Initialized
INFO - 2023-01-03 03:01:18 --> Output Class Initialized
INFO - 2023-01-03 03:01:18 --> Security Class Initialized
DEBUG - 2023-01-03 03:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:01:18 --> Input Class Initialized
INFO - 2023-01-03 03:01:18 --> Language Class Initialized
INFO - 2023-01-03 03:01:18 --> Loader Class Initialized
INFO - 2023-01-03 03:01:18 --> Controller Class Initialized
DEBUG - 2023-01-03 03:01:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:01:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:18 --> Model "Login_model" initialized
INFO - 2023-01-03 03:01:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:01:18 --> Final output sent to browser
DEBUG - 2023-01-03 03:01:18 --> Total execution time: 0.2950
INFO - 2023-01-03 03:01:18 --> Config Class Initialized
INFO - 2023-01-03 03:01:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:01:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:01:18 --> Utf8 Class Initialized
INFO - 2023-01-03 03:01:18 --> URI Class Initialized
INFO - 2023-01-03 03:01:18 --> Router Class Initialized
INFO - 2023-01-03 03:01:18 --> Output Class Initialized
INFO - 2023-01-03 03:01:18 --> Security Class Initialized
DEBUG - 2023-01-03 03:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:01:18 --> Input Class Initialized
INFO - 2023-01-03 03:01:18 --> Language Class Initialized
INFO - 2023-01-03 03:01:18 --> Loader Class Initialized
INFO - 2023-01-03 03:01:18 --> Controller Class Initialized
DEBUG - 2023-01-03 03:01:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:01:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:18 --> Model "Login_model" initialized
INFO - 2023-01-03 03:01:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:01:18 --> Final output sent to browser
DEBUG - 2023-01-03 03:01:18 --> Total execution time: 0.3219
INFO - 2023-01-03 03:01:38 --> Config Class Initialized
INFO - 2023-01-03 03:01:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:01:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:01:38 --> Utf8 Class Initialized
INFO - 2023-01-03 03:01:38 --> URI Class Initialized
INFO - 2023-01-03 03:01:38 --> Router Class Initialized
INFO - 2023-01-03 03:01:38 --> Output Class Initialized
INFO - 2023-01-03 03:01:38 --> Security Class Initialized
DEBUG - 2023-01-03 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:01:38 --> Input Class Initialized
INFO - 2023-01-03 03:01:38 --> Language Class Initialized
INFO - 2023-01-03 03:01:38 --> Loader Class Initialized
INFO - 2023-01-03 03:01:38 --> Controller Class Initialized
DEBUG - 2023-01-03 03:01:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:01:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:38 --> Model "Login_model" initialized
INFO - 2023-01-03 03:01:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:01:38 --> Final output sent to browser
DEBUG - 2023-01-03 03:01:38 --> Total execution time: 0.6350
INFO - 2023-01-03 03:01:39 --> Config Class Initialized
INFO - 2023-01-03 03:01:39 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:01:39 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:01:39 --> Utf8 Class Initialized
INFO - 2023-01-03 03:01:39 --> URI Class Initialized
INFO - 2023-01-03 03:01:39 --> Router Class Initialized
INFO - 2023-01-03 03:01:39 --> Output Class Initialized
INFO - 2023-01-03 03:01:39 --> Security Class Initialized
DEBUG - 2023-01-03 03:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:01:39 --> Input Class Initialized
INFO - 2023-01-03 03:01:39 --> Language Class Initialized
INFO - 2023-01-03 03:01:39 --> Loader Class Initialized
INFO - 2023-01-03 03:01:39 --> Controller Class Initialized
DEBUG - 2023-01-03 03:01:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:01:39 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:39 --> Model "Login_model" initialized
INFO - 2023-01-03 03:01:39 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:39 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:01:39 --> Final output sent to browser
DEBUG - 2023-01-03 03:01:39 --> Total execution time: 0.4120
INFO - 2023-01-03 03:01:58 --> Config Class Initialized
INFO - 2023-01-03 03:01:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:01:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:01:58 --> Utf8 Class Initialized
INFO - 2023-01-03 03:01:58 --> URI Class Initialized
INFO - 2023-01-03 03:01:58 --> Router Class Initialized
INFO - 2023-01-03 03:01:58 --> Output Class Initialized
INFO - 2023-01-03 03:01:58 --> Security Class Initialized
DEBUG - 2023-01-03 03:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:01:58 --> Input Class Initialized
INFO - 2023-01-03 03:01:58 --> Language Class Initialized
INFO - 2023-01-03 03:01:58 --> Loader Class Initialized
INFO - 2023-01-03 03:01:58 --> Controller Class Initialized
DEBUG - 2023-01-03 03:01:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:01:58 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:58 --> Model "Login_model" initialized
INFO - 2023-01-03 03:01:58 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:01:58 --> Final output sent to browser
DEBUG - 2023-01-03 03:01:58 --> Total execution time: 0.5732
INFO - 2023-01-03 03:01:58 --> Config Class Initialized
INFO - 2023-01-03 03:01:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:01:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:01:59 --> Utf8 Class Initialized
INFO - 2023-01-03 03:01:59 --> URI Class Initialized
INFO - 2023-01-03 03:01:59 --> Router Class Initialized
INFO - 2023-01-03 03:01:59 --> Output Class Initialized
INFO - 2023-01-03 03:01:59 --> Security Class Initialized
DEBUG - 2023-01-03 03:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:01:59 --> Input Class Initialized
INFO - 2023-01-03 03:01:59 --> Language Class Initialized
INFO - 2023-01-03 03:01:59 --> Loader Class Initialized
INFO - 2023-01-03 03:01:59 --> Controller Class Initialized
DEBUG - 2023-01-03 03:01:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:01:59 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:59 --> Model "Login_model" initialized
INFO - 2023-01-03 03:01:59 --> Database Driver Class Initialized
INFO - 2023-01-03 03:01:59 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:01:59 --> Final output sent to browser
DEBUG - 2023-01-03 03:01:59 --> Total execution time: 0.4498
INFO - 2023-01-03 03:02:00 --> Config Class Initialized
INFO - 2023-01-03 03:02:01 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:01 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:01 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:01 --> URI Class Initialized
INFO - 2023-01-03 03:02:01 --> Router Class Initialized
INFO - 2023-01-03 03:02:01 --> Output Class Initialized
INFO - 2023-01-03 03:02:01 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:01 --> Input Class Initialized
INFO - 2023-01-03 03:02:01 --> Language Class Initialized
INFO - 2023-01-03 03:02:01 --> Loader Class Initialized
INFO - 2023-01-03 03:02:01 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:01 --> Final output sent to browser
DEBUG - 2023-01-03 03:02:01 --> Total execution time: 0.4548
INFO - 2023-01-03 03:02:01 --> Config Class Initialized
INFO - 2023-01-03 03:02:01 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:01 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:01 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:01 --> URI Class Initialized
INFO - 2023-01-03 03:02:01 --> Router Class Initialized
INFO - 2023-01-03 03:02:01 --> Output Class Initialized
INFO - 2023-01-03 03:02:01 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:01 --> Input Class Initialized
INFO - 2023-01-03 03:02:01 --> Language Class Initialized
INFO - 2023-01-03 03:02:01 --> Loader Class Initialized
INFO - 2023-01-03 03:02:01 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:02 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:02 --> Model "Login_model" initialized
INFO - 2023-01-03 03:02:02 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:02 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:02:18 --> Config Class Initialized
INFO - 2023-01-03 03:02:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:18 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:18 --> URI Class Initialized
INFO - 2023-01-03 03:02:18 --> Router Class Initialized
INFO - 2023-01-03 03:02:18 --> Output Class Initialized
INFO - 2023-01-03 03:02:18 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:18 --> Input Class Initialized
INFO - 2023-01-03 03:02:18 --> Language Class Initialized
INFO - 2023-01-03 03:02:18 --> Loader Class Initialized
INFO - 2023-01-03 03:02:18 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:18 --> Model "Login_model" initialized
INFO - 2023-01-03 03:02:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:02:19 --> Final output sent to browser
DEBUG - 2023-01-03 03:02:19 --> Total execution time: 0.7325
INFO - 2023-01-03 03:02:19 --> Config Class Initialized
INFO - 2023-01-03 03:02:19 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:19 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:19 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:19 --> URI Class Initialized
INFO - 2023-01-03 03:02:19 --> Router Class Initialized
INFO - 2023-01-03 03:02:19 --> Output Class Initialized
INFO - 2023-01-03 03:02:19 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:19 --> Input Class Initialized
INFO - 2023-01-03 03:02:19 --> Language Class Initialized
INFO - 2023-01-03 03:02:19 --> Loader Class Initialized
INFO - 2023-01-03 03:02:19 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:19 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:19 --> Model "Login_model" initialized
INFO - 2023-01-03 03:02:19 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:19 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:02:19 --> Final output sent to browser
DEBUG - 2023-01-03 03:02:19 --> Total execution time: 0.5970
INFO - 2023-01-03 03:02:38 --> Config Class Initialized
INFO - 2023-01-03 03:02:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:38 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:38 --> URI Class Initialized
INFO - 2023-01-03 03:02:38 --> Router Class Initialized
INFO - 2023-01-03 03:02:38 --> Output Class Initialized
INFO - 2023-01-03 03:02:38 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:38 --> Input Class Initialized
INFO - 2023-01-03 03:02:38 --> Language Class Initialized
INFO - 2023-01-03 03:02:38 --> Loader Class Initialized
INFO - 2023-01-03 03:02:38 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:38 --> Model "Login_model" initialized
INFO - 2023-01-03 03:02:39 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:39 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:02:39 --> Final output sent to browser
DEBUG - 2023-01-03 03:02:39 --> Total execution time: 0.7933
INFO - 2023-01-03 03:02:39 --> Config Class Initialized
INFO - 2023-01-03 03:02:39 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:39 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:39 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:39 --> URI Class Initialized
INFO - 2023-01-03 03:02:39 --> Router Class Initialized
INFO - 2023-01-03 03:02:39 --> Output Class Initialized
INFO - 2023-01-03 03:02:39 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:39 --> Input Class Initialized
INFO - 2023-01-03 03:02:39 --> Language Class Initialized
INFO - 2023-01-03 03:02:39 --> Loader Class Initialized
INFO - 2023-01-03 03:02:39 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:39 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:39 --> Model "Login_model" initialized
INFO - 2023-01-03 03:02:39 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:39 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:02:39 --> Final output sent to browser
DEBUG - 2023-01-03 03:02:39 --> Total execution time: 0.6100
INFO - 2023-01-03 03:02:44 --> Config Class Initialized
INFO - 2023-01-03 03:02:44 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:45 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:45 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:45 --> URI Class Initialized
INFO - 2023-01-03 03:02:45 --> Router Class Initialized
INFO - 2023-01-03 03:02:45 --> Output Class Initialized
INFO - 2023-01-03 03:02:45 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:45 --> Input Class Initialized
INFO - 2023-01-03 03:02:45 --> Language Class Initialized
INFO - 2023-01-03 03:02:45 --> Loader Class Initialized
INFO - 2023-01-03 03:02:45 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:45 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:45 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:02:45 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:45 --> Model "Login_model" initialized
INFO - 2023-01-03 03:02:45 --> Final output sent to browser
DEBUG - 2023-01-03 03:02:45 --> Total execution time: 0.5947
INFO - 2023-01-03 03:02:45 --> Config Class Initialized
INFO - 2023-01-03 03:02:45 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:45 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:45 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:45 --> URI Class Initialized
INFO - 2023-01-03 03:02:45 --> Router Class Initialized
INFO - 2023-01-03 03:02:45 --> Output Class Initialized
INFO - 2023-01-03 03:02:45 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:45 --> Input Class Initialized
INFO - 2023-01-03 03:02:45 --> Language Class Initialized
INFO - 2023-01-03 03:02:45 --> Loader Class Initialized
INFO - 2023-01-03 03:02:45 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:46 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:46 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:02:46 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:46 --> Model "Login_model" initialized
INFO - 2023-01-03 03:02:46 --> Final output sent to browser
DEBUG - 2023-01-03 03:02:46 --> Total execution time: 0.4666
INFO - 2023-01-03 03:02:48 --> Config Class Initialized
INFO - 2023-01-03 03:02:48 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:48 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:48 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:48 --> URI Class Initialized
INFO - 2023-01-03 03:02:48 --> Router Class Initialized
INFO - 2023-01-03 03:02:48 --> Output Class Initialized
INFO - 2023-01-03 03:02:48 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:48 --> Input Class Initialized
INFO - 2023-01-03 03:02:48 --> Language Class Initialized
INFO - 2023-01-03 03:02:48 --> Loader Class Initialized
INFO - 2023-01-03 03:02:48 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:48 --> Final output sent to browser
DEBUG - 2023-01-03 03:02:48 --> Total execution time: 0.3330
INFO - 2023-01-03 03:02:48 --> Config Class Initialized
INFO - 2023-01-03 03:02:48 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:02:48 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:02:48 --> Utf8 Class Initialized
INFO - 2023-01-03 03:02:48 --> URI Class Initialized
INFO - 2023-01-03 03:02:48 --> Router Class Initialized
INFO - 2023-01-03 03:02:48 --> Output Class Initialized
INFO - 2023-01-03 03:02:48 --> Security Class Initialized
DEBUG - 2023-01-03 03:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:02:48 --> Input Class Initialized
INFO - 2023-01-03 03:02:48 --> Language Class Initialized
INFO - 2023-01-03 03:02:48 --> Loader Class Initialized
INFO - 2023-01-03 03:02:48 --> Controller Class Initialized
DEBUG - 2023-01-03 03:02:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:02:48 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:48 --> Model "Login_model" initialized
INFO - 2023-01-03 03:02:48 --> Database Driver Class Initialized
INFO - 2023-01-03 03:02:48 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:03:08 --> Config Class Initialized
INFO - 2023-01-03 03:03:08 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:03:08 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:03:08 --> Utf8 Class Initialized
INFO - 2023-01-03 03:03:08 --> URI Class Initialized
INFO - 2023-01-03 03:03:08 --> Router Class Initialized
INFO - 2023-01-03 03:03:08 --> Output Class Initialized
INFO - 2023-01-03 03:03:08 --> Security Class Initialized
DEBUG - 2023-01-03 03:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:03:08 --> Input Class Initialized
INFO - 2023-01-03 03:03:08 --> Language Class Initialized
INFO - 2023-01-03 03:03:08 --> Loader Class Initialized
INFO - 2023-01-03 03:03:08 --> Controller Class Initialized
DEBUG - 2023-01-03 03:03:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:03:08 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:08 --> Model "Login_model" initialized
INFO - 2023-01-03 03:03:08 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:08 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:03:08 --> Final output sent to browser
DEBUG - 2023-01-03 03:03:08 --> Total execution time: 0.3384
INFO - 2023-01-03 03:03:08 --> Config Class Initialized
INFO - 2023-01-03 03:03:08 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:03:08 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:03:08 --> Utf8 Class Initialized
INFO - 2023-01-03 03:03:08 --> URI Class Initialized
INFO - 2023-01-03 03:03:08 --> Router Class Initialized
INFO - 2023-01-03 03:03:08 --> Output Class Initialized
INFO - 2023-01-03 03:03:08 --> Security Class Initialized
DEBUG - 2023-01-03 03:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:03:08 --> Input Class Initialized
INFO - 2023-01-03 03:03:08 --> Language Class Initialized
INFO - 2023-01-03 03:03:08 --> Loader Class Initialized
INFO - 2023-01-03 03:03:08 --> Controller Class Initialized
DEBUG - 2023-01-03 03:03:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:03:08 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:08 --> Model "Login_model" initialized
INFO - 2023-01-03 03:03:08 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:08 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:03:08 --> Final output sent to browser
DEBUG - 2023-01-03 03:03:08 --> Total execution time: 0.3170
INFO - 2023-01-03 03:03:22 --> Config Class Initialized
INFO - 2023-01-03 03:03:22 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:03:22 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:03:22 --> Utf8 Class Initialized
INFO - 2023-01-03 03:03:22 --> URI Class Initialized
INFO - 2023-01-03 03:03:22 --> Router Class Initialized
INFO - 2023-01-03 03:03:23 --> Output Class Initialized
INFO - 2023-01-03 03:03:23 --> Security Class Initialized
DEBUG - 2023-01-03 03:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:03:23 --> Input Class Initialized
INFO - 2023-01-03 03:03:23 --> Language Class Initialized
INFO - 2023-01-03 03:03:23 --> Loader Class Initialized
INFO - 2023-01-03 03:03:23 --> Controller Class Initialized
DEBUG - 2023-01-03 03:03:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:03:23 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:23 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:03:23 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:23 --> Model "Login_model" initialized
INFO - 2023-01-03 03:03:23 --> Final output sent to browser
DEBUG - 2023-01-03 03:03:23 --> Total execution time: 1.0992
INFO - 2023-01-03 03:03:23 --> Config Class Initialized
INFO - 2023-01-03 03:03:23 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:03:23 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:03:23 --> Utf8 Class Initialized
INFO - 2023-01-03 03:03:23 --> URI Class Initialized
INFO - 2023-01-03 03:03:24 --> Router Class Initialized
INFO - 2023-01-03 03:03:24 --> Output Class Initialized
INFO - 2023-01-03 03:03:24 --> Security Class Initialized
DEBUG - 2023-01-03 03:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:03:24 --> Input Class Initialized
INFO - 2023-01-03 03:03:24 --> Language Class Initialized
INFO - 2023-01-03 03:03:24 --> Loader Class Initialized
INFO - 2023-01-03 03:03:24 --> Controller Class Initialized
DEBUG - 2023-01-03 03:03:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:03:24 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:24 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:03:24 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:24 --> Model "Login_model" initialized
INFO - 2023-01-03 03:03:24 --> Final output sent to browser
DEBUG - 2023-01-03 03:03:24 --> Total execution time: 0.4982
INFO - 2023-01-03 03:03:27 --> Config Class Initialized
INFO - 2023-01-03 03:03:27 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:03:27 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:03:27 --> Utf8 Class Initialized
INFO - 2023-01-03 03:03:27 --> URI Class Initialized
INFO - 2023-01-03 03:03:27 --> Router Class Initialized
INFO - 2023-01-03 03:03:27 --> Output Class Initialized
INFO - 2023-01-03 03:03:27 --> Security Class Initialized
DEBUG - 2023-01-03 03:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:03:27 --> Input Class Initialized
INFO - 2023-01-03 03:03:27 --> Language Class Initialized
INFO - 2023-01-03 03:03:27 --> Loader Class Initialized
INFO - 2023-01-03 03:03:27 --> Controller Class Initialized
DEBUG - 2023-01-03 03:03:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:03:27 --> Final output sent to browser
DEBUG - 2023-01-03 03:03:27 --> Total execution time: 0.4167
INFO - 2023-01-03 03:03:28 --> Config Class Initialized
INFO - 2023-01-03 03:03:28 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:03:28 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:03:28 --> Utf8 Class Initialized
INFO - 2023-01-03 03:03:28 --> URI Class Initialized
INFO - 2023-01-03 03:03:28 --> Router Class Initialized
INFO - 2023-01-03 03:03:28 --> Output Class Initialized
INFO - 2023-01-03 03:03:28 --> Security Class Initialized
DEBUG - 2023-01-03 03:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:03:28 --> Input Class Initialized
INFO - 2023-01-03 03:03:28 --> Language Class Initialized
INFO - 2023-01-03 03:03:28 --> Loader Class Initialized
INFO - 2023-01-03 03:03:28 --> Controller Class Initialized
DEBUG - 2023-01-03 03:03:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:03:28 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:28 --> Model "Login_model" initialized
INFO - 2023-01-03 03:03:28 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:28 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:03:34 --> Config Class Initialized
INFO - 2023-01-03 03:03:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:03:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:03:34 --> Utf8 Class Initialized
INFO - 2023-01-03 03:03:34 --> URI Class Initialized
INFO - 2023-01-03 03:03:34 --> Router Class Initialized
INFO - 2023-01-03 03:03:34 --> Output Class Initialized
INFO - 2023-01-03 03:03:34 --> Security Class Initialized
DEBUG - 2023-01-03 03:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:03:34 --> Input Class Initialized
INFO - 2023-01-03 03:03:34 --> Language Class Initialized
INFO - 2023-01-03 03:03:34 --> Loader Class Initialized
INFO - 2023-01-03 03:03:34 --> Controller Class Initialized
DEBUG - 2023-01-03 03:03:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:03:34 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:03:34 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:34 --> Model "Login_model" initialized
INFO - 2023-01-03 03:03:34 --> Final output sent to browser
DEBUG - 2023-01-03 03:03:34 --> Total execution time: 0.3548
INFO - 2023-01-03 03:03:34 --> Config Class Initialized
INFO - 2023-01-03 03:03:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:03:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:03:34 --> Utf8 Class Initialized
INFO - 2023-01-03 03:03:34 --> URI Class Initialized
INFO - 2023-01-03 03:03:34 --> Router Class Initialized
INFO - 2023-01-03 03:03:34 --> Output Class Initialized
INFO - 2023-01-03 03:03:34 --> Security Class Initialized
DEBUG - 2023-01-03 03:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:03:34 --> Input Class Initialized
INFO - 2023-01-03 03:03:34 --> Language Class Initialized
INFO - 2023-01-03 03:03:34 --> Loader Class Initialized
INFO - 2023-01-03 03:03:34 --> Controller Class Initialized
DEBUG - 2023-01-03 03:03:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:03:34 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:03:34 --> Database Driver Class Initialized
INFO - 2023-01-03 03:03:34 --> Model "Login_model" initialized
INFO - 2023-01-03 03:03:34 --> Final output sent to browser
DEBUG - 2023-01-03 03:03:34 --> Total execution time: 0.3568
INFO - 2023-01-03 03:04:00 --> Config Class Initialized
INFO - 2023-01-03 03:04:00 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:00 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:00 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:00 --> URI Class Initialized
INFO - 2023-01-03 03:04:00 --> Router Class Initialized
INFO - 2023-01-03 03:04:00 --> Output Class Initialized
INFO - 2023-01-03 03:04:00 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:00 --> Input Class Initialized
INFO - 2023-01-03 03:04:00 --> Language Class Initialized
INFO - 2023-01-03 03:04:00 --> Loader Class Initialized
INFO - 2023-01-03 03:04:00 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:00 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:00 --> Total execution time: 0.4894
INFO - 2023-01-03 03:04:00 --> Config Class Initialized
INFO - 2023-01-03 03:04:00 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:00 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:00 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:00 --> URI Class Initialized
INFO - 2023-01-03 03:04:00 --> Router Class Initialized
INFO - 2023-01-03 03:04:00 --> Output Class Initialized
INFO - 2023-01-03 03:04:00 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:00 --> Input Class Initialized
INFO - 2023-01-03 03:04:00 --> Language Class Initialized
INFO - 2023-01-03 03:04:00 --> Loader Class Initialized
INFO - 2023-01-03 03:04:00 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:01 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:01 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:01 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:01 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:01 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:01 --> Total execution time: 0.5264
INFO - 2023-01-03 03:04:01 --> Config Class Initialized
INFO - 2023-01-03 03:04:01 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:01 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:01 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:01 --> URI Class Initialized
INFO - 2023-01-03 03:04:01 --> Router Class Initialized
INFO - 2023-01-03 03:04:01 --> Output Class Initialized
INFO - 2023-01-03 03:04:01 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:01 --> Input Class Initialized
INFO - 2023-01-03 03:04:01 --> Language Class Initialized
INFO - 2023-01-03 03:04:01 --> Loader Class Initialized
INFO - 2023-01-03 03:04:01 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:01 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:01 --> Total execution time: 0.2642
INFO - 2023-01-03 03:04:01 --> Config Class Initialized
INFO - 2023-01-03 03:04:01 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:01 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:01 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:01 --> URI Class Initialized
INFO - 2023-01-03 03:04:01 --> Router Class Initialized
INFO - 2023-01-03 03:04:01 --> Output Class Initialized
INFO - 2023-01-03 03:04:01 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:01 --> Input Class Initialized
INFO - 2023-01-03 03:04:01 --> Language Class Initialized
INFO - 2023-01-03 03:04:01 --> Loader Class Initialized
INFO - 2023-01-03 03:04:01 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:01 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:01 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:01 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:01 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:01 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:01 --> Total execution time: 0.3560
INFO - 2023-01-03 03:04:07 --> Config Class Initialized
INFO - 2023-01-03 03:04:07 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:07 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:07 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:07 --> URI Class Initialized
INFO - 2023-01-03 03:04:07 --> Router Class Initialized
INFO - 2023-01-03 03:04:07 --> Output Class Initialized
INFO - 2023-01-03 03:04:07 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:07 --> Input Class Initialized
INFO - 2023-01-03 03:04:07 --> Language Class Initialized
INFO - 2023-01-03 03:04:07 --> Loader Class Initialized
INFO - 2023-01-03 03:04:07 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:07 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:07 --> Total execution time: 0.1282
INFO - 2023-01-03 03:04:07 --> Config Class Initialized
INFO - 2023-01-03 03:04:07 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:07 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:07 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:07 --> URI Class Initialized
INFO - 2023-01-03 03:04:07 --> Router Class Initialized
INFO - 2023-01-03 03:04:07 --> Output Class Initialized
INFO - 2023-01-03 03:04:07 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:07 --> Input Class Initialized
INFO - 2023-01-03 03:04:07 --> Language Class Initialized
INFO - 2023-01-03 03:04:07 --> Loader Class Initialized
INFO - 2023-01-03 03:04:07 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:07 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:07 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:07 --> Model "PGsql_model" initialized
INFO - 2023-01-03 03:04:08 --> Model "Grafana_model" initialized
INFO - 2023-01-03 03:04:08 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:08 --> Total execution time: 0.1945
INFO - 2023-01-03 03:04:14 --> Config Class Initialized
INFO - 2023-01-03 03:04:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:14 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:14 --> URI Class Initialized
INFO - 2023-01-03 03:04:14 --> Router Class Initialized
INFO - 2023-01-03 03:04:14 --> Output Class Initialized
INFO - 2023-01-03 03:04:14 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:14 --> Input Class Initialized
INFO - 2023-01-03 03:04:14 --> Language Class Initialized
INFO - 2023-01-03 03:04:14 --> Loader Class Initialized
INFO - 2023-01-03 03:04:14 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:14 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:14 --> Total execution time: 0.0955
INFO - 2023-01-03 03:04:14 --> Config Class Initialized
INFO - 2023-01-03 03:04:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:14 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:14 --> URI Class Initialized
INFO - 2023-01-03 03:04:14 --> Router Class Initialized
INFO - 2023-01-03 03:04:14 --> Output Class Initialized
INFO - 2023-01-03 03:04:14 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:14 --> Input Class Initialized
INFO - 2023-01-03 03:04:14 --> Language Class Initialized
INFO - 2023-01-03 03:04:14 --> Loader Class Initialized
INFO - 2023-01-03 03:04:14 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:14 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:14 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:14 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:14 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:14 --> Total execution time: 0.1733
INFO - 2023-01-03 03:04:17 --> Config Class Initialized
INFO - 2023-01-03 03:04:17 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:17 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:17 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:17 --> URI Class Initialized
INFO - 2023-01-03 03:04:17 --> Router Class Initialized
INFO - 2023-01-03 03:04:17 --> Output Class Initialized
INFO - 2023-01-03 03:04:17 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:18 --> Input Class Initialized
INFO - 2023-01-03 03:04:18 --> Language Class Initialized
INFO - 2023-01-03 03:04:18 --> Loader Class Initialized
INFO - 2023-01-03 03:04:18 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:18 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:18 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:18 --> Total execution time: 0.3309
INFO - 2023-01-03 03:04:18 --> Config Class Initialized
INFO - 2023-01-03 03:04:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:18 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:18 --> URI Class Initialized
INFO - 2023-01-03 03:04:18 --> Router Class Initialized
INFO - 2023-01-03 03:04:18 --> Output Class Initialized
INFO - 2023-01-03 03:04:18 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:18 --> Input Class Initialized
INFO - 2023-01-03 03:04:18 --> Language Class Initialized
INFO - 2023-01-03 03:04:18 --> Loader Class Initialized
INFO - 2023-01-03 03:04:18 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:18 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:18 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:18 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:18 --> Total execution time: 0.1841
INFO - 2023-01-03 03:04:22 --> Config Class Initialized
INFO - 2023-01-03 03:04:22 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:22 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:22 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:22 --> URI Class Initialized
INFO - 2023-01-03 03:04:22 --> Router Class Initialized
INFO - 2023-01-03 03:04:22 --> Output Class Initialized
INFO - 2023-01-03 03:04:22 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:22 --> Input Class Initialized
INFO - 2023-01-03 03:04:22 --> Language Class Initialized
INFO - 2023-01-03 03:04:22 --> Loader Class Initialized
INFO - 2023-01-03 03:04:22 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:22 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:22 --> Total execution time: 0.1216
INFO - 2023-01-03 03:04:23 --> Config Class Initialized
INFO - 2023-01-03 03:04:23 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:23 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:23 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:23 --> URI Class Initialized
INFO - 2023-01-03 03:04:23 --> Router Class Initialized
INFO - 2023-01-03 03:04:23 --> Output Class Initialized
INFO - 2023-01-03 03:04:23 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:23 --> Input Class Initialized
INFO - 2023-01-03 03:04:23 --> Language Class Initialized
INFO - 2023-01-03 03:04:23 --> Loader Class Initialized
INFO - 2023-01-03 03:04:23 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:23 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:23 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:23 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:23 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:23 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:23 --> Total execution time: 0.2521
INFO - 2023-01-03 03:04:23 --> Config Class Initialized
INFO - 2023-01-03 03:04:23 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:23 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:23 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:23 --> URI Class Initialized
INFO - 2023-01-03 03:04:23 --> Router Class Initialized
INFO - 2023-01-03 03:04:23 --> Output Class Initialized
INFO - 2023-01-03 03:04:23 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:23 --> Input Class Initialized
INFO - 2023-01-03 03:04:23 --> Language Class Initialized
INFO - 2023-01-03 03:04:23 --> Loader Class Initialized
INFO - 2023-01-03 03:04:23 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:23 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:23 --> Total execution time: 0.1123
INFO - 2023-01-03 03:04:23 --> Config Class Initialized
INFO - 2023-01-03 03:04:23 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:23 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:23 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:23 --> URI Class Initialized
INFO - 2023-01-03 03:04:23 --> Router Class Initialized
INFO - 2023-01-03 03:04:23 --> Output Class Initialized
INFO - 2023-01-03 03:04:23 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:23 --> Input Class Initialized
INFO - 2023-01-03 03:04:23 --> Language Class Initialized
INFO - 2023-01-03 03:04:23 --> Loader Class Initialized
INFO - 2023-01-03 03:04:23 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:23 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:23 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:23 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:23 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:23 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:23 --> Total execution time: 0.1882
INFO - 2023-01-03 03:04:25 --> Config Class Initialized
INFO - 2023-01-03 03:04:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:25 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:25 --> URI Class Initialized
INFO - 2023-01-03 03:04:25 --> Router Class Initialized
INFO - 2023-01-03 03:04:25 --> Output Class Initialized
INFO - 2023-01-03 03:04:25 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:25 --> Input Class Initialized
INFO - 2023-01-03 03:04:25 --> Language Class Initialized
INFO - 2023-01-03 03:04:25 --> Loader Class Initialized
INFO - 2023-01-03 03:04:25 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:25 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:25 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:25 --> Total execution time: 0.1615
INFO - 2023-01-03 03:04:25 --> Config Class Initialized
INFO - 2023-01-03 03:04:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:25 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:25 --> URI Class Initialized
INFO - 2023-01-03 03:04:25 --> Router Class Initialized
INFO - 2023-01-03 03:04:25 --> Output Class Initialized
INFO - 2023-01-03 03:04:25 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:25 --> Input Class Initialized
INFO - 2023-01-03 03:04:25 --> Language Class Initialized
INFO - 2023-01-03 03:04:25 --> Loader Class Initialized
INFO - 2023-01-03 03:04:25 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:25 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:25 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:25 --> Total execution time: 0.1436
INFO - 2023-01-03 03:04:31 --> Config Class Initialized
INFO - 2023-01-03 03:04:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:31 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:31 --> URI Class Initialized
INFO - 2023-01-03 03:04:31 --> Router Class Initialized
INFO - 2023-01-03 03:04:31 --> Output Class Initialized
INFO - 2023-01-03 03:04:31 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:31 --> Input Class Initialized
INFO - 2023-01-03 03:04:31 --> Language Class Initialized
INFO - 2023-01-03 03:04:31 --> Loader Class Initialized
INFO - 2023-01-03 03:04:31 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:31 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:31 --> Total execution time: 0.1161
INFO - 2023-01-03 03:04:31 --> Config Class Initialized
INFO - 2023-01-03 03:04:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:31 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:31 --> URI Class Initialized
INFO - 2023-01-03 03:04:31 --> Router Class Initialized
INFO - 2023-01-03 03:04:31 --> Output Class Initialized
INFO - 2023-01-03 03:04:31 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:31 --> Input Class Initialized
INFO - 2023-01-03 03:04:31 --> Language Class Initialized
INFO - 2023-01-03 03:04:31 --> Loader Class Initialized
INFO - 2023-01-03 03:04:31 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:31 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:31 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:31 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:31 --> Total execution time: 0.1808
INFO - 2023-01-03 03:04:32 --> Config Class Initialized
INFO - 2023-01-03 03:04:32 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:32 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:32 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:32 --> URI Class Initialized
INFO - 2023-01-03 03:04:32 --> Router Class Initialized
INFO - 2023-01-03 03:04:32 --> Output Class Initialized
INFO - 2023-01-03 03:04:32 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:32 --> Input Class Initialized
INFO - 2023-01-03 03:04:32 --> Language Class Initialized
INFO - 2023-01-03 03:04:32 --> Loader Class Initialized
INFO - 2023-01-03 03:04:32 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:32 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:32 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:33 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:33 --> Total execution time: 0.2178
INFO - 2023-01-03 03:04:33 --> Config Class Initialized
INFO - 2023-01-03 03:04:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:33 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:33 --> URI Class Initialized
INFO - 2023-01-03 03:04:33 --> Router Class Initialized
INFO - 2023-01-03 03:04:33 --> Output Class Initialized
INFO - 2023-01-03 03:04:33 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:33 --> Input Class Initialized
INFO - 2023-01-03 03:04:33 --> Language Class Initialized
INFO - 2023-01-03 03:04:33 --> Loader Class Initialized
INFO - 2023-01-03 03:04:33 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:33 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:33 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:33 --> Total execution time: 0.2203
INFO - 2023-01-03 03:04:34 --> Config Class Initialized
INFO - 2023-01-03 03:04:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:34 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:34 --> URI Class Initialized
INFO - 2023-01-03 03:04:34 --> Router Class Initialized
INFO - 2023-01-03 03:04:34 --> Output Class Initialized
INFO - 2023-01-03 03:04:34 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:34 --> Input Class Initialized
INFO - 2023-01-03 03:04:34 --> Language Class Initialized
INFO - 2023-01-03 03:04:34 --> Loader Class Initialized
INFO - 2023-01-03 03:04:34 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:34 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:34 --> Total execution time: 0.1353
INFO - 2023-01-03 03:04:34 --> Config Class Initialized
INFO - 2023-01-03 03:04:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:34 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:34 --> URI Class Initialized
INFO - 2023-01-03 03:04:34 --> Router Class Initialized
INFO - 2023-01-03 03:04:34 --> Output Class Initialized
INFO - 2023-01-03 03:04:34 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:34 --> Input Class Initialized
INFO - 2023-01-03 03:04:34 --> Language Class Initialized
INFO - 2023-01-03 03:04:34 --> Loader Class Initialized
INFO - 2023-01-03 03:04:34 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:34 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:34 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:34 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:34 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:34 --> Total execution time: 0.2269
INFO - 2023-01-03 03:04:34 --> Config Class Initialized
INFO - 2023-01-03 03:04:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:34 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:35 --> URI Class Initialized
INFO - 2023-01-03 03:04:35 --> Router Class Initialized
INFO - 2023-01-03 03:04:35 --> Output Class Initialized
INFO - 2023-01-03 03:04:35 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:35 --> Input Class Initialized
INFO - 2023-01-03 03:04:35 --> Language Class Initialized
INFO - 2023-01-03 03:04:35 --> Loader Class Initialized
INFO - 2023-01-03 03:04:35 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:35 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:35 --> Total execution time: 0.1377
INFO - 2023-01-03 03:04:35 --> Config Class Initialized
INFO - 2023-01-03 03:04:35 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:35 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:35 --> URI Class Initialized
INFO - 2023-01-03 03:04:35 --> Router Class Initialized
INFO - 2023-01-03 03:04:35 --> Output Class Initialized
INFO - 2023-01-03 03:04:35 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:35 --> Input Class Initialized
INFO - 2023-01-03 03:04:35 --> Language Class Initialized
INFO - 2023-01-03 03:04:35 --> Loader Class Initialized
INFO - 2023-01-03 03:04:35 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:35 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:35 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:35 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:35 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:35 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:35 --> Total execution time: 0.2159
INFO - 2023-01-03 03:04:38 --> Config Class Initialized
INFO - 2023-01-03 03:04:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:38 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:38 --> URI Class Initialized
INFO - 2023-01-03 03:04:38 --> Router Class Initialized
INFO - 2023-01-03 03:04:38 --> Output Class Initialized
INFO - 2023-01-03 03:04:38 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:38 --> Input Class Initialized
INFO - 2023-01-03 03:04:38 --> Language Class Initialized
INFO - 2023-01-03 03:04:38 --> Loader Class Initialized
INFO - 2023-01-03 03:04:38 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:38 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:38 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:38 --> Total execution time: 0.3000
INFO - 2023-01-03 03:04:38 --> Config Class Initialized
INFO - 2023-01-03 03:04:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:04:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:04:38 --> Utf8 Class Initialized
INFO - 2023-01-03 03:04:38 --> URI Class Initialized
INFO - 2023-01-03 03:04:38 --> Router Class Initialized
INFO - 2023-01-03 03:04:38 --> Output Class Initialized
INFO - 2023-01-03 03:04:38 --> Security Class Initialized
DEBUG - 2023-01-03 03:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:04:38 --> Input Class Initialized
INFO - 2023-01-03 03:04:38 --> Language Class Initialized
INFO - 2023-01-03 03:04:38 --> Loader Class Initialized
INFO - 2023-01-03 03:04:38 --> Controller Class Initialized
DEBUG - 2023-01-03 03:04:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:04:38 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:39 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:04:39 --> Database Driver Class Initialized
INFO - 2023-01-03 03:04:39 --> Model "Login_model" initialized
INFO - 2023-01-03 03:04:39 --> Final output sent to browser
DEBUG - 2023-01-03 03:04:39 --> Total execution time: 0.2914
INFO - 2023-01-03 03:43:30 --> Config Class Initialized
INFO - 2023-01-03 03:43:30 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:43:30 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:43:30 --> Utf8 Class Initialized
INFO - 2023-01-03 03:43:30 --> URI Class Initialized
INFO - 2023-01-03 03:43:30 --> Router Class Initialized
INFO - 2023-01-03 03:43:30 --> Output Class Initialized
INFO - 2023-01-03 03:43:30 --> Security Class Initialized
DEBUG - 2023-01-03 03:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:43:30 --> Input Class Initialized
INFO - 2023-01-03 03:43:30 --> Language Class Initialized
INFO - 2023-01-03 03:43:30 --> Loader Class Initialized
INFO - 2023-01-03 03:43:30 --> Controller Class Initialized
DEBUG - 2023-01-03 03:43:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:43:30 --> Database Driver Class Initialized
INFO - 2023-01-03 03:43:30 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:43:30 --> Final output sent to browser
DEBUG - 2023-01-03 03:43:30 --> Total execution time: 0.4032
INFO - 2023-01-03 03:43:30 --> Config Class Initialized
INFO - 2023-01-03 03:43:30 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:43:30 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:43:30 --> Utf8 Class Initialized
INFO - 2023-01-03 03:43:30 --> URI Class Initialized
INFO - 2023-01-03 03:43:30 --> Router Class Initialized
INFO - 2023-01-03 03:43:30 --> Output Class Initialized
INFO - 2023-01-03 03:43:30 --> Security Class Initialized
DEBUG - 2023-01-03 03:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:43:30 --> Input Class Initialized
INFO - 2023-01-03 03:43:30 --> Language Class Initialized
INFO - 2023-01-03 03:43:30 --> Loader Class Initialized
INFO - 2023-01-03 03:43:30 --> Controller Class Initialized
DEBUG - 2023-01-03 03:43:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:43:30 --> Database Driver Class Initialized
INFO - 2023-01-03 03:43:30 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:43:30 --> Final output sent to browser
DEBUG - 2023-01-03 03:43:30 --> Total execution time: 0.1965
INFO - 2023-01-03 03:43:35 --> Config Class Initialized
INFO - 2023-01-03 03:43:35 --> Hooks Class Initialized
INFO - 2023-01-03 03:43:35 --> Config Class Initialized
INFO - 2023-01-03 03:43:35 --> Hooks Class Initialized
DEBUG - 2023-01-03 03:43:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:43:35 --> Utf8 Class Initialized
DEBUG - 2023-01-03 03:43:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:43:35 --> Utf8 Class Initialized
INFO - 2023-01-03 03:43:35 --> URI Class Initialized
INFO - 2023-01-03 03:43:35 --> URI Class Initialized
INFO - 2023-01-03 03:43:35 --> Router Class Initialized
INFO - 2023-01-03 03:43:35 --> Router Class Initialized
INFO - 2023-01-03 03:43:35 --> Output Class Initialized
INFO - 2023-01-03 03:43:35 --> Security Class Initialized
INFO - 2023-01-03 03:43:35 --> Output Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:43:35 --> Security Class Initialized
INFO - 2023-01-03 03:43:35 --> Input Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:43:35 --> Language Class Initialized
INFO - 2023-01-03 03:43:35 --> Input Class Initialized
INFO - 2023-01-03 03:43:35 --> Language Class Initialized
INFO - 2023-01-03 03:43:35 --> Loader Class Initialized
INFO - 2023-01-03 03:43:35 --> Controller Class Initialized
INFO - 2023-01-03 03:43:35 --> Loader Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:43:35 --> Final output sent to browser
DEBUG - 2023-01-03 03:43:35 --> Total execution time: 0.2528
INFO - 2023-01-03 03:43:35 --> Controller Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:43:35 --> Database Driver Class Initialized
INFO - 2023-01-03 03:43:35 --> Config Class Initialized
INFO - 2023-01-03 03:43:35 --> Hooks Class Initialized
INFO - 2023-01-03 03:43:35 --> Model "Cluster_model" initialized
DEBUG - 2023-01-03 03:43:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:43:35 --> Final output sent to browser
INFO - 2023-01-03 03:43:35 --> Utf8 Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Total execution time: 0.3492
INFO - 2023-01-03 03:43:35 --> URI Class Initialized
INFO - 2023-01-03 03:43:35 --> Router Class Initialized
INFO - 2023-01-03 03:43:35 --> Output Class Initialized
INFO - 2023-01-03 03:43:35 --> Config Class Initialized
INFO - 2023-01-03 03:43:35 --> Hooks Class Initialized
INFO - 2023-01-03 03:43:35 --> Security Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 03:43:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 03:43:35 --> Input Class Initialized
INFO - 2023-01-03 03:43:35 --> Utf8 Class Initialized
INFO - 2023-01-03 03:43:35 --> Language Class Initialized
INFO - 2023-01-03 03:43:35 --> URI Class Initialized
INFO - 2023-01-03 03:43:35 --> Loader Class Initialized
INFO - 2023-01-03 03:43:35 --> Router Class Initialized
INFO - 2023-01-03 03:43:35 --> Controller Class Initialized
INFO - 2023-01-03 03:43:35 --> Output Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:43:35 --> Security Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 03:43:35 --> Input Class Initialized
INFO - 2023-01-03 03:43:35 --> Database Driver Class Initialized
INFO - 2023-01-03 03:43:35 --> Language Class Initialized
INFO - 2023-01-03 03:43:35 --> Model "Login_model" initialized
INFO - 2023-01-03 03:43:35 --> Loader Class Initialized
INFO - 2023-01-03 03:43:35 --> Database Driver Class Initialized
INFO - 2023-01-03 03:43:35 --> Controller Class Initialized
DEBUG - 2023-01-03 03:43:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 03:43:35 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:43:35 --> Final output sent to browser
DEBUG - 2023-01-03 03:43:35 --> Total execution time: 0.3635
INFO - 2023-01-03 03:43:35 --> Database Driver Class Initialized
INFO - 2023-01-03 03:43:36 --> Model "Cluster_model" initialized
INFO - 2023-01-03 03:43:36 --> Final output sent to browser
DEBUG - 2023-01-03 03:43:36 --> Total execution time: 0.3235
INFO - 2023-01-03 04:42:26 --> Config Class Initialized
INFO - 2023-01-03 04:42:26 --> Hooks Class Initialized
DEBUG - 2023-01-03 04:42:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 04:42:26 --> Utf8 Class Initialized
INFO - 2023-01-03 04:42:26 --> URI Class Initialized
INFO - 2023-01-03 04:42:26 --> Router Class Initialized
INFO - 2023-01-03 04:42:26 --> Output Class Initialized
INFO - 2023-01-03 04:42:26 --> Security Class Initialized
DEBUG - 2023-01-03 04:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 04:42:26 --> Input Class Initialized
INFO - 2023-01-03 04:42:26 --> Language Class Initialized
INFO - 2023-01-03 04:42:26 --> Loader Class Initialized
INFO - 2023-01-03 04:42:26 --> Controller Class Initialized
DEBUG - 2023-01-03 04:42:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 04:42:26 --> Database Driver Class Initialized
INFO - 2023-01-03 04:42:27 --> Model "Cluster_model" initialized
INFO - 2023-01-03 04:42:27 --> Database Driver Class Initialized
INFO - 2023-01-03 04:42:27 --> Model "Login_model" initialized
INFO - 2023-01-03 04:42:27 --> Final output sent to browser
DEBUG - 2023-01-03 04:42:27 --> Total execution time: 1.2815
INFO - 2023-01-03 04:42:27 --> Config Class Initialized
INFO - 2023-01-03 04:42:27 --> Hooks Class Initialized
DEBUG - 2023-01-03 04:42:27 --> UTF-8 Support Enabled
INFO - 2023-01-03 04:42:27 --> Utf8 Class Initialized
INFO - 2023-01-03 04:42:27 --> URI Class Initialized
INFO - 2023-01-03 04:42:27 --> Router Class Initialized
INFO - 2023-01-03 04:42:27 --> Output Class Initialized
INFO - 2023-01-03 04:42:27 --> Security Class Initialized
DEBUG - 2023-01-03 04:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 04:42:27 --> Input Class Initialized
INFO - 2023-01-03 04:42:27 --> Language Class Initialized
INFO - 2023-01-03 04:42:27 --> Loader Class Initialized
INFO - 2023-01-03 04:42:27 --> Controller Class Initialized
DEBUG - 2023-01-03 04:42:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 04:42:27 --> Database Driver Class Initialized
INFO - 2023-01-03 04:42:27 --> Model "Cluster_model" initialized
INFO - 2023-01-03 04:42:27 --> Database Driver Class Initialized
INFO - 2023-01-03 04:42:27 --> Model "Login_model" initialized
INFO - 2023-01-03 04:42:27 --> Final output sent to browser
DEBUG - 2023-01-03 04:42:27 --> Total execution time: 0.2306
INFO - 2023-01-03 07:44:29 --> Config Class Initialized
INFO - 2023-01-03 07:44:29 --> Hooks Class Initialized
DEBUG - 2023-01-03 07:44:29 --> UTF-8 Support Enabled
INFO - 2023-01-03 07:44:29 --> Utf8 Class Initialized
INFO - 2023-01-03 07:44:29 --> URI Class Initialized
INFO - 2023-01-03 07:44:29 --> Router Class Initialized
INFO - 2023-01-03 07:44:29 --> Output Class Initialized
INFO - 2023-01-03 07:44:29 --> Security Class Initialized
DEBUG - 2023-01-03 07:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 07:44:29 --> Input Class Initialized
INFO - 2023-01-03 07:44:29 --> Language Class Initialized
INFO - 2023-01-03 07:44:29 --> Loader Class Initialized
INFO - 2023-01-03 07:44:29 --> Controller Class Initialized
DEBUG - 2023-01-03 07:44:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 07:44:29 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:29 --> Model "Cluster_model" initialized
INFO - 2023-01-03 07:44:29 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:29 --> Model "Login_model" initialized
INFO - 2023-01-03 07:44:29 --> Final output sent to browser
DEBUG - 2023-01-03 07:44:29 --> Total execution time: 0.3631
INFO - 2023-01-03 07:44:29 --> Config Class Initialized
INFO - 2023-01-03 07:44:29 --> Hooks Class Initialized
DEBUG - 2023-01-03 07:44:29 --> UTF-8 Support Enabled
INFO - 2023-01-03 07:44:29 --> Utf8 Class Initialized
INFO - 2023-01-03 07:44:29 --> URI Class Initialized
INFO - 2023-01-03 07:44:29 --> Router Class Initialized
INFO - 2023-01-03 07:44:29 --> Output Class Initialized
INFO - 2023-01-03 07:44:30 --> Security Class Initialized
DEBUG - 2023-01-03 07:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 07:44:30 --> Input Class Initialized
INFO - 2023-01-03 07:44:30 --> Language Class Initialized
INFO - 2023-01-03 07:44:30 --> Loader Class Initialized
INFO - 2023-01-03 07:44:30 --> Controller Class Initialized
DEBUG - 2023-01-03 07:44:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 07:44:30 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:30 --> Model "Cluster_model" initialized
INFO - 2023-01-03 07:44:30 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:30 --> Model "Login_model" initialized
INFO - 2023-01-03 07:44:30 --> Final output sent to browser
DEBUG - 2023-01-03 07:44:30 --> Total execution time: 0.2819
INFO - 2023-01-03 07:44:32 --> Config Class Initialized
INFO - 2023-01-03 07:44:32 --> Config Class Initialized
INFO - 2023-01-03 07:44:32 --> Hooks Class Initialized
INFO - 2023-01-03 07:44:32 --> Hooks Class Initialized
DEBUG - 2023-01-03 07:44:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 07:44:32 --> UTF-8 Support Enabled
INFO - 2023-01-03 07:44:32 --> Utf8 Class Initialized
INFO - 2023-01-03 07:44:32 --> Utf8 Class Initialized
INFO - 2023-01-03 07:44:32 --> URI Class Initialized
INFO - 2023-01-03 07:44:32 --> URI Class Initialized
INFO - 2023-01-03 07:44:32 --> Router Class Initialized
INFO - 2023-01-03 07:44:32 --> Router Class Initialized
INFO - 2023-01-03 07:44:32 --> Output Class Initialized
INFO - 2023-01-03 07:44:32 --> Output Class Initialized
INFO - 2023-01-03 07:44:32 --> Security Class Initialized
INFO - 2023-01-03 07:44:32 --> Security Class Initialized
DEBUG - 2023-01-03 07:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 07:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 07:44:32 --> Input Class Initialized
INFO - 2023-01-03 07:44:32 --> Input Class Initialized
INFO - 2023-01-03 07:44:32 --> Language Class Initialized
INFO - 2023-01-03 07:44:32 --> Language Class Initialized
INFO - 2023-01-03 07:44:32 --> Loader Class Initialized
INFO - 2023-01-03 07:44:32 --> Loader Class Initialized
INFO - 2023-01-03 07:44:32 --> Controller Class Initialized
INFO - 2023-01-03 07:44:32 --> Controller Class Initialized
DEBUG - 2023-01-03 07:44:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-03 07:44:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 07:44:33 --> Final output sent to browser
DEBUG - 2023-01-03 07:44:33 --> Total execution time: 0.2398
INFO - 2023-01-03 07:44:33 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 07:44:33 --> Final output sent to browser
INFO - 2023-01-03 07:44:33 --> Config Class Initialized
INFO - 2023-01-03 07:44:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 07:44:33 --> Total execution time: 0.3075
DEBUG - 2023-01-03 07:44:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 07:44:33 --> Utf8 Class Initialized
INFO - 2023-01-03 07:44:33 --> URI Class Initialized
INFO - 2023-01-03 07:44:33 --> Config Class Initialized
INFO - 2023-01-03 07:44:33 --> Hooks Class Initialized
INFO - 2023-01-03 07:44:33 --> Router Class Initialized
DEBUG - 2023-01-03 07:44:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 07:44:33 --> Output Class Initialized
INFO - 2023-01-03 07:44:33 --> Utf8 Class Initialized
INFO - 2023-01-03 07:44:33 --> Security Class Initialized
INFO - 2023-01-03 07:44:33 --> URI Class Initialized
DEBUG - 2023-01-03 07:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 07:44:33 --> Input Class Initialized
INFO - 2023-01-03 07:44:33 --> Router Class Initialized
INFO - 2023-01-03 07:44:33 --> Language Class Initialized
INFO - 2023-01-03 07:44:33 --> Output Class Initialized
INFO - 2023-01-03 07:44:33 --> Security Class Initialized
INFO - 2023-01-03 07:44:33 --> Loader Class Initialized
DEBUG - 2023-01-03 07:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 07:44:33 --> Input Class Initialized
INFO - 2023-01-03 07:44:33 --> Controller Class Initialized
DEBUG - 2023-01-03 07:44:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 07:44:33 --> Language Class Initialized
INFO - 2023-01-03 07:44:33 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:33 --> Loader Class Initialized
INFO - 2023-01-03 07:44:33 --> Model "Login_model" initialized
INFO - 2023-01-03 07:44:33 --> Controller Class Initialized
DEBUG - 2023-01-03 07:44:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 07:44:33 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 07:44:33 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:33 --> Final output sent to browser
DEBUG - 2023-01-03 07:44:33 --> Total execution time: 0.4400
INFO - 2023-01-03 07:44:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 07:44:33 --> Final output sent to browser
DEBUG - 2023-01-03 07:44:33 --> Total execution time: 0.4180
INFO - 2023-01-03 07:44:56 --> Config Class Initialized
INFO - 2023-01-03 07:44:56 --> Hooks Class Initialized
DEBUG - 2023-01-03 07:44:56 --> UTF-8 Support Enabled
INFO - 2023-01-03 07:44:56 --> Utf8 Class Initialized
INFO - 2023-01-03 07:44:56 --> URI Class Initialized
INFO - 2023-01-03 07:44:56 --> Router Class Initialized
INFO - 2023-01-03 07:44:56 --> Output Class Initialized
INFO - 2023-01-03 07:44:56 --> Security Class Initialized
DEBUG - 2023-01-03 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 07:44:56 --> Input Class Initialized
INFO - 2023-01-03 07:44:56 --> Language Class Initialized
INFO - 2023-01-03 07:44:56 --> Loader Class Initialized
INFO - 2023-01-03 07:44:56 --> Controller Class Initialized
DEBUG - 2023-01-03 07:44:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 07:44:56 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:56 --> Model "Cluster_model" initialized
INFO - 2023-01-03 07:44:56 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:56 --> Model "Login_model" initialized
INFO - 2023-01-03 07:44:56 --> Final output sent to browser
DEBUG - 2023-01-03 07:44:56 --> Total execution time: 0.2041
INFO - 2023-01-03 07:44:56 --> Config Class Initialized
INFO - 2023-01-03 07:44:56 --> Hooks Class Initialized
DEBUG - 2023-01-03 07:44:56 --> UTF-8 Support Enabled
INFO - 2023-01-03 07:44:56 --> Utf8 Class Initialized
INFO - 2023-01-03 07:44:56 --> URI Class Initialized
INFO - 2023-01-03 07:44:56 --> Router Class Initialized
INFO - 2023-01-03 07:44:56 --> Output Class Initialized
INFO - 2023-01-03 07:44:56 --> Security Class Initialized
DEBUG - 2023-01-03 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 07:44:56 --> Input Class Initialized
INFO - 2023-01-03 07:44:56 --> Language Class Initialized
INFO - 2023-01-03 07:44:56 --> Loader Class Initialized
INFO - 2023-01-03 07:44:56 --> Controller Class Initialized
DEBUG - 2023-01-03 07:44:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 07:44:57 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:57 --> Model "Cluster_model" initialized
INFO - 2023-01-03 07:44:57 --> Database Driver Class Initialized
INFO - 2023-01-03 07:44:57 --> Model "Login_model" initialized
INFO - 2023-01-03 07:44:57 --> Final output sent to browser
DEBUG - 2023-01-03 07:44:57 --> Total execution time: 0.1894
INFO - 2023-01-03 10:04:21 --> Config Class Initialized
INFO - 2023-01-03 10:04:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:04:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:04:21 --> Utf8 Class Initialized
INFO - 2023-01-03 10:04:21 --> URI Class Initialized
INFO - 2023-01-03 10:04:21 --> Router Class Initialized
INFO - 2023-01-03 10:04:21 --> Output Class Initialized
INFO - 2023-01-03 10:04:21 --> Security Class Initialized
DEBUG - 2023-01-03 10:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:04:21 --> Input Class Initialized
INFO - 2023-01-03 10:04:21 --> Language Class Initialized
INFO - 2023-01-03 10:04:21 --> Loader Class Initialized
INFO - 2023-01-03 10:04:21 --> Controller Class Initialized
INFO - 2023-01-03 10:04:21 --> Helper loaded: form_helper
INFO - 2023-01-03 10:04:21 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:04:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:04:21 --> Model "Change_model" initialized
INFO - 2023-01-03 10:04:21 --> Model "Grafana_model" initialized
INFO - 2023-01-03 10:04:21 --> Final output sent to browser
DEBUG - 2023-01-03 10:04:21 --> Total execution time: 0.2263
INFO - 2023-01-03 10:04:21 --> Config Class Initialized
INFO - 2023-01-03 10:04:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:04:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:04:21 --> Utf8 Class Initialized
INFO - 2023-01-03 10:04:21 --> URI Class Initialized
INFO - 2023-01-03 10:04:21 --> Router Class Initialized
INFO - 2023-01-03 10:04:21 --> Output Class Initialized
INFO - 2023-01-03 10:04:21 --> Security Class Initialized
DEBUG - 2023-01-03 10:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:04:21 --> Input Class Initialized
INFO - 2023-01-03 10:04:21 --> Language Class Initialized
INFO - 2023-01-03 10:04:21 --> Loader Class Initialized
INFO - 2023-01-03 10:04:21 --> Controller Class Initialized
INFO - 2023-01-03 10:04:21 --> Helper loaded: form_helper
INFO - 2023-01-03 10:04:21 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:04:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:04:21 --> Final output sent to browser
DEBUG - 2023-01-03 10:04:21 --> Total execution time: 0.1020
INFO - 2023-01-03 10:04:21 --> Config Class Initialized
INFO - 2023-01-03 10:04:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:04:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:04:21 --> Utf8 Class Initialized
INFO - 2023-01-03 10:04:21 --> URI Class Initialized
INFO - 2023-01-03 10:04:21 --> Router Class Initialized
INFO - 2023-01-03 10:04:21 --> Output Class Initialized
INFO - 2023-01-03 10:04:21 --> Security Class Initialized
DEBUG - 2023-01-03 10:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:04:21 --> Input Class Initialized
INFO - 2023-01-03 10:04:21 --> Language Class Initialized
INFO - 2023-01-03 10:04:21 --> Loader Class Initialized
INFO - 2023-01-03 10:04:21 --> Controller Class Initialized
INFO - 2023-01-03 10:04:21 --> Helper loaded: form_helper
INFO - 2023-01-03 10:04:21 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:04:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:04:21 --> Database Driver Class Initialized
INFO - 2023-01-03 10:04:21 --> Model "Login_model" initialized
INFO - 2023-01-03 10:04:21 --> Final output sent to browser
DEBUG - 2023-01-03 10:04:21 --> Total execution time: 0.1526
INFO - 2023-01-03 10:04:25 --> Config Class Initialized
INFO - 2023-01-03 10:04:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:04:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:04:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:04:25 --> URI Class Initialized
INFO - 2023-01-03 10:04:25 --> Router Class Initialized
INFO - 2023-01-03 10:04:25 --> Output Class Initialized
INFO - 2023-01-03 10:04:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:04:25 --> Input Class Initialized
INFO - 2023-01-03 10:04:25 --> Language Class Initialized
INFO - 2023-01-03 10:04:25 --> Loader Class Initialized
INFO - 2023-01-03 10:04:25 --> Controller Class Initialized
INFO - 2023-01-03 10:04:25 --> Helper loaded: form_helper
INFO - 2023-01-03 10:04:25 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:04:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:04:25 --> Model "Change_model" initialized
INFO - 2023-01-03 10:04:25 --> Model "Grafana_model" initialized
INFO - 2023-01-03 10:04:25 --> Final output sent to browser
DEBUG - 2023-01-03 10:04:25 --> Total execution time: 0.1560
INFO - 2023-01-03 10:04:25 --> Config Class Initialized
INFO - 2023-01-03 10:04:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:04:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:04:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:04:25 --> URI Class Initialized
INFO - 2023-01-03 10:04:25 --> Router Class Initialized
INFO - 2023-01-03 10:04:25 --> Output Class Initialized
INFO - 2023-01-03 10:04:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:04:25 --> Input Class Initialized
INFO - 2023-01-03 10:04:25 --> Language Class Initialized
INFO - 2023-01-03 10:04:25 --> Loader Class Initialized
INFO - 2023-01-03 10:04:25 --> Controller Class Initialized
INFO - 2023-01-03 10:04:25 --> Helper loaded: form_helper
INFO - 2023-01-03 10:04:25 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:04:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:04:26 --> Database Driver Class Initialized
INFO - 2023-01-03 10:04:26 --> Model "Login_model" initialized
INFO - 2023-01-03 10:04:26 --> Final output sent to browser
DEBUG - 2023-01-03 10:04:26 --> Total execution time: 0.1369
INFO - 2023-01-03 10:04:52 --> Config Class Initialized
INFO - 2023-01-03 10:04:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:04:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:04:52 --> Utf8 Class Initialized
INFO - 2023-01-03 10:04:52 --> URI Class Initialized
INFO - 2023-01-03 10:04:52 --> Router Class Initialized
INFO - 2023-01-03 10:04:52 --> Output Class Initialized
INFO - 2023-01-03 10:04:52 --> Security Class Initialized
DEBUG - 2023-01-03 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:04:52 --> Input Class Initialized
INFO - 2023-01-03 10:04:52 --> Language Class Initialized
INFO - 2023-01-03 10:04:52 --> Loader Class Initialized
INFO - 2023-01-03 10:04:52 --> Controller Class Initialized
INFO - 2023-01-03 10:04:52 --> Helper loaded: form_helper
INFO - 2023-01-03 10:04:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:04:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:04:52 --> Model "Change_model" initialized
INFO - 2023-01-03 10:04:52 --> Model "Grafana_model" initialized
INFO - 2023-01-03 10:04:52 --> Final output sent to browser
DEBUG - 2023-01-03 10:04:52 --> Total execution time: 0.1734
INFO - 2023-01-03 10:04:52 --> Config Class Initialized
INFO - 2023-01-03 10:04:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:04:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:04:52 --> Utf8 Class Initialized
INFO - 2023-01-03 10:04:52 --> URI Class Initialized
INFO - 2023-01-03 10:04:52 --> Router Class Initialized
INFO - 2023-01-03 10:04:52 --> Output Class Initialized
INFO - 2023-01-03 10:04:52 --> Security Class Initialized
DEBUG - 2023-01-03 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:04:52 --> Input Class Initialized
INFO - 2023-01-03 10:04:52 --> Language Class Initialized
INFO - 2023-01-03 10:04:52 --> Loader Class Initialized
INFO - 2023-01-03 10:04:52 --> Controller Class Initialized
INFO - 2023-01-03 10:04:52 --> Helper loaded: form_helper
INFO - 2023-01-03 10:04:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:04:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:04:52 --> Final output sent to browser
DEBUG - 2023-01-03 10:04:52 --> Total execution time: 0.1079
INFO - 2023-01-03 10:04:52 --> Config Class Initialized
INFO - 2023-01-03 10:04:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:04:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:04:52 --> Utf8 Class Initialized
INFO - 2023-01-03 10:04:52 --> URI Class Initialized
INFO - 2023-01-03 10:04:52 --> Router Class Initialized
INFO - 2023-01-03 10:04:52 --> Output Class Initialized
INFO - 2023-01-03 10:04:52 --> Security Class Initialized
DEBUG - 2023-01-03 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:04:52 --> Input Class Initialized
INFO - 2023-01-03 10:04:52 --> Language Class Initialized
INFO - 2023-01-03 10:04:52 --> Loader Class Initialized
INFO - 2023-01-03 10:04:52 --> Controller Class Initialized
INFO - 2023-01-03 10:04:52 --> Helper loaded: form_helper
INFO - 2023-01-03 10:04:52 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:04:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:04:52 --> Database Driver Class Initialized
INFO - 2023-01-03 10:04:52 --> Model "Login_model" initialized
INFO - 2023-01-03 10:04:52 --> Final output sent to browser
DEBUG - 2023-01-03 10:04:52 --> Total execution time: 0.1410
INFO - 2023-01-03 10:05:06 --> Config Class Initialized
INFO - 2023-01-03 10:05:06 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:06 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:06 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:06 --> URI Class Initialized
INFO - 2023-01-03 10:05:06 --> Router Class Initialized
INFO - 2023-01-03 10:05:06 --> Output Class Initialized
INFO - 2023-01-03 10:05:06 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:06 --> Input Class Initialized
INFO - 2023-01-03 10:05:06 --> Language Class Initialized
INFO - 2023-01-03 10:05:06 --> Loader Class Initialized
INFO - 2023-01-03 10:05:06 --> Controller Class Initialized
INFO - 2023-01-03 10:05:06 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:06 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:06 --> Model "Change_model" initialized
INFO - 2023-01-03 10:05:06 --> Model "Grafana_model" initialized
INFO - 2023-01-03 10:05:06 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:06 --> Total execution time: 0.1403
INFO - 2023-01-03 10:05:06 --> Config Class Initialized
INFO - 2023-01-03 10:05:06 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:06 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:06 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:06 --> URI Class Initialized
INFO - 2023-01-03 10:05:06 --> Router Class Initialized
INFO - 2023-01-03 10:05:06 --> Output Class Initialized
INFO - 2023-01-03 10:05:06 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:06 --> Input Class Initialized
INFO - 2023-01-03 10:05:06 --> Language Class Initialized
INFO - 2023-01-03 10:05:06 --> Loader Class Initialized
INFO - 2023-01-03 10:05:06 --> Controller Class Initialized
INFO - 2023-01-03 10:05:06 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:06 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:06 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:06 --> Total execution time: 0.1248
INFO - 2023-01-03 10:05:06 --> Config Class Initialized
INFO - 2023-01-03 10:05:06 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:07 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:07 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:07 --> URI Class Initialized
INFO - 2023-01-03 10:05:07 --> Router Class Initialized
INFO - 2023-01-03 10:05:07 --> Output Class Initialized
INFO - 2023-01-03 10:05:07 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:07 --> Input Class Initialized
INFO - 2023-01-03 10:05:07 --> Language Class Initialized
INFO - 2023-01-03 10:05:07 --> Loader Class Initialized
INFO - 2023-01-03 10:05:07 --> Controller Class Initialized
INFO - 2023-01-03 10:05:07 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:07 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:07 --> Database Driver Class Initialized
INFO - 2023-01-03 10:05:07 --> Model "Login_model" initialized
INFO - 2023-01-03 10:05:07 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:07 --> Total execution time: 0.1509
INFO - 2023-01-03 10:05:12 --> Config Class Initialized
INFO - 2023-01-03 10:05:12 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:12 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:12 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:12 --> URI Class Initialized
INFO - 2023-01-03 10:05:12 --> Router Class Initialized
INFO - 2023-01-03 10:05:12 --> Output Class Initialized
INFO - 2023-01-03 10:05:12 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:12 --> Input Class Initialized
INFO - 2023-01-03 10:05:12 --> Language Class Initialized
INFO - 2023-01-03 10:05:12 --> Loader Class Initialized
INFO - 2023-01-03 10:05:12 --> Controller Class Initialized
INFO - 2023-01-03 10:05:12 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:12 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:12 --> Model "Change_model" initialized
INFO - 2023-01-03 10:05:12 --> Model "Grafana_model" initialized
INFO - 2023-01-03 10:05:12 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:12 --> Total execution time: 0.1446
INFO - 2023-01-03 10:05:12 --> Config Class Initialized
INFO - 2023-01-03 10:05:12 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:12 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:12 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:12 --> URI Class Initialized
INFO - 2023-01-03 10:05:12 --> Router Class Initialized
INFO - 2023-01-03 10:05:12 --> Output Class Initialized
INFO - 2023-01-03 10:05:12 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:12 --> Input Class Initialized
INFO - 2023-01-03 10:05:12 --> Language Class Initialized
INFO - 2023-01-03 10:05:12 --> Loader Class Initialized
INFO - 2023-01-03 10:05:12 --> Controller Class Initialized
INFO - 2023-01-03 10:05:12 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:12 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:12 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:12 --> Total execution time: 0.1029
INFO - 2023-01-03 10:05:13 --> Config Class Initialized
INFO - 2023-01-03 10:05:13 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:13 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:13 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:13 --> URI Class Initialized
INFO - 2023-01-03 10:05:13 --> Router Class Initialized
INFO - 2023-01-03 10:05:13 --> Output Class Initialized
INFO - 2023-01-03 10:05:13 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:13 --> Input Class Initialized
INFO - 2023-01-03 10:05:13 --> Language Class Initialized
INFO - 2023-01-03 10:05:13 --> Loader Class Initialized
INFO - 2023-01-03 10:05:13 --> Controller Class Initialized
INFO - 2023-01-03 10:05:13 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:13 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:13 --> Database Driver Class Initialized
INFO - 2023-01-03 10:05:13 --> Model "Login_model" initialized
INFO - 2023-01-03 10:05:13 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:13 --> Total execution time: 0.1423
INFO - 2023-01-03 10:05:49 --> Config Class Initialized
INFO - 2023-01-03 10:05:49 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:49 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:49 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:49 --> URI Class Initialized
INFO - 2023-01-03 10:05:49 --> Router Class Initialized
INFO - 2023-01-03 10:05:49 --> Output Class Initialized
INFO - 2023-01-03 10:05:49 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:49 --> Input Class Initialized
INFO - 2023-01-03 10:05:49 --> Language Class Initialized
INFO - 2023-01-03 10:05:49 --> Loader Class Initialized
INFO - 2023-01-03 10:05:49 --> Controller Class Initialized
INFO - 2023-01-03 10:05:49 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:49 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:49 --> Model "Change_model" initialized
INFO - 2023-01-03 10:05:49 --> Model "Grafana_model" initialized
INFO - 2023-01-03 10:05:49 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:49 --> Total execution time: 0.1559
INFO - 2023-01-03 10:05:49 --> Config Class Initialized
INFO - 2023-01-03 10:05:49 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:49 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:49 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:49 --> URI Class Initialized
INFO - 2023-01-03 10:05:49 --> Router Class Initialized
INFO - 2023-01-03 10:05:49 --> Output Class Initialized
INFO - 2023-01-03 10:05:49 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:49 --> Input Class Initialized
INFO - 2023-01-03 10:05:49 --> Language Class Initialized
INFO - 2023-01-03 10:05:49 --> Loader Class Initialized
INFO - 2023-01-03 10:05:49 --> Controller Class Initialized
INFO - 2023-01-03 10:05:49 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:49 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:49 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:49 --> Total execution time: 0.1067
INFO - 2023-01-03 10:05:49 --> Config Class Initialized
INFO - 2023-01-03 10:05:49 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:05:49 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:05:49 --> Utf8 Class Initialized
INFO - 2023-01-03 10:05:49 --> URI Class Initialized
INFO - 2023-01-03 10:05:49 --> Router Class Initialized
INFO - 2023-01-03 10:05:49 --> Output Class Initialized
INFO - 2023-01-03 10:05:49 --> Security Class Initialized
DEBUG - 2023-01-03 10:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:05:49 --> Input Class Initialized
INFO - 2023-01-03 10:05:49 --> Language Class Initialized
INFO - 2023-01-03 10:05:49 --> Loader Class Initialized
INFO - 2023-01-03 10:05:49 --> Controller Class Initialized
INFO - 2023-01-03 10:05:49 --> Helper loaded: form_helper
INFO - 2023-01-03 10:05:49 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:05:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:05:49 --> Database Driver Class Initialized
INFO - 2023-01-03 10:05:49 --> Model "Login_model" initialized
INFO - 2023-01-03 10:05:49 --> Final output sent to browser
DEBUG - 2023-01-03 10:05:49 --> Total execution time: 0.1451
INFO - 2023-01-03 10:06:16 --> Config Class Initialized
INFO - 2023-01-03 10:06:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:16 --> URI Class Initialized
INFO - 2023-01-03 10:06:16 --> Router Class Initialized
INFO - 2023-01-03 10:06:16 --> Output Class Initialized
INFO - 2023-01-03 10:06:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:16 --> Input Class Initialized
INFO - 2023-01-03 10:06:16 --> Language Class Initialized
INFO - 2023-01-03 10:06:16 --> Loader Class Initialized
INFO - 2023-01-03 10:06:16 --> Controller Class Initialized
INFO - 2023-01-03 10:06:16 --> Helper loaded: form_helper
INFO - 2023-01-03 10:06:16 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:06:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:16 --> Model "Change_model" initialized
INFO - 2023-01-03 10:06:16 --> Model "Grafana_model" initialized
INFO - 2023-01-03 10:06:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:16 --> Total execution time: 0.3017
INFO - 2023-01-03 10:06:16 --> Config Class Initialized
INFO - 2023-01-03 10:06:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:16 --> URI Class Initialized
INFO - 2023-01-03 10:06:16 --> Router Class Initialized
INFO - 2023-01-03 10:06:16 --> Output Class Initialized
INFO - 2023-01-03 10:06:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:16 --> Input Class Initialized
INFO - 2023-01-03 10:06:16 --> Language Class Initialized
INFO - 2023-01-03 10:06:16 --> Loader Class Initialized
INFO - 2023-01-03 10:06:16 --> Controller Class Initialized
INFO - 2023-01-03 10:06:16 --> Helper loaded: form_helper
INFO - 2023-01-03 10:06:16 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:06:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:16 --> Total execution time: 0.1054
INFO - 2023-01-03 10:06:16 --> Config Class Initialized
INFO - 2023-01-03 10:06:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:16 --> URI Class Initialized
INFO - 2023-01-03 10:06:16 --> Router Class Initialized
INFO - 2023-01-03 10:06:16 --> Output Class Initialized
INFO - 2023-01-03 10:06:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:16 --> Input Class Initialized
INFO - 2023-01-03 10:06:16 --> Language Class Initialized
INFO - 2023-01-03 10:06:16 --> Loader Class Initialized
INFO - 2023-01-03 10:06:16 --> Controller Class Initialized
INFO - 2023-01-03 10:06:16 --> Helper loaded: form_helper
INFO - 2023-01-03 10:06:16 --> Helper loaded: url_helper
DEBUG - 2023-01-03 10:06:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:16 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:16 --> Model "Login_model" initialized
INFO - 2023-01-03 10:06:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:16 --> Total execution time: 0.1332
INFO - 2023-01-03 10:06:16 --> Config Class Initialized
INFO - 2023-01-03 10:06:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:16 --> URI Class Initialized
INFO - 2023-01-03 10:06:16 --> Router Class Initialized
INFO - 2023-01-03 10:06:16 --> Output Class Initialized
INFO - 2023-01-03 10:06:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:16 --> Input Class Initialized
INFO - 2023-01-03 10:06:16 --> Language Class Initialized
INFO - 2023-01-03 10:06:16 --> Loader Class Initialized
INFO - 2023-01-03 10:06:16 --> Controller Class Initialized
DEBUG - 2023-01-03 10:06:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:16 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:16 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:16 --> Total execution time: 0.1401
INFO - 2023-01-03 10:06:17 --> Config Class Initialized
INFO - 2023-01-03 10:06:17 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:17 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:17 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:17 --> URI Class Initialized
INFO - 2023-01-03 10:06:17 --> Router Class Initialized
INFO - 2023-01-03 10:06:17 --> Output Class Initialized
INFO - 2023-01-03 10:06:17 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:17 --> Input Class Initialized
INFO - 2023-01-03 10:06:17 --> Language Class Initialized
INFO - 2023-01-03 10:06:17 --> Loader Class Initialized
INFO - 2023-01-03 10:06:17 --> Controller Class Initialized
DEBUG - 2023-01-03 10:06:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:17 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:17 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:17 --> Total execution time: 0.1223
INFO - 2023-01-03 10:06:17 --> Config Class Initialized
INFO - 2023-01-03 10:06:17 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:17 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:17 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:17 --> URI Class Initialized
INFO - 2023-01-03 10:06:17 --> Router Class Initialized
INFO - 2023-01-03 10:06:17 --> Output Class Initialized
INFO - 2023-01-03 10:06:17 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:17 --> Input Class Initialized
INFO - 2023-01-03 10:06:17 --> Language Class Initialized
INFO - 2023-01-03 10:06:17 --> Loader Class Initialized
INFO - 2023-01-03 10:06:17 --> Controller Class Initialized
DEBUG - 2023-01-03 10:06:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:17 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:17 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:17 --> Model "Login_model" initialized
INFO - 2023-01-03 10:06:17 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:17 --> Total execution time: 0.2177
INFO - 2023-01-03 10:06:17 --> Config Class Initialized
INFO - 2023-01-03 10:06:17 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:17 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:17 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:17 --> URI Class Initialized
INFO - 2023-01-03 10:06:17 --> Router Class Initialized
INFO - 2023-01-03 10:06:17 --> Output Class Initialized
INFO - 2023-01-03 10:06:17 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:17 --> Input Class Initialized
INFO - 2023-01-03 10:06:17 --> Language Class Initialized
INFO - 2023-01-03 10:06:17 --> Loader Class Initialized
INFO - 2023-01-03 10:06:17 --> Controller Class Initialized
DEBUG - 2023-01-03 10:06:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:17 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:18 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:18 --> Model "Login_model" initialized
INFO - 2023-01-03 10:06:18 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:18 --> Total execution time: 0.1903
INFO - 2023-01-03 10:06:25 --> Config Class Initialized
INFO - 2023-01-03 10:06:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:25 --> URI Class Initialized
INFO - 2023-01-03 10:06:25 --> Router Class Initialized
INFO - 2023-01-03 10:06:25 --> Output Class Initialized
INFO - 2023-01-03 10:06:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:25 --> Input Class Initialized
INFO - 2023-01-03 10:06:25 --> Language Class Initialized
INFO - 2023-01-03 10:06:25 --> Loader Class Initialized
INFO - 2023-01-03 10:06:25 --> Controller Class Initialized
DEBUG - 2023-01-03 10:06:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:25 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:25 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:25 --> Total execution time: 0.1616
INFO - 2023-01-03 10:06:25 --> Config Class Initialized
INFO - 2023-01-03 10:06:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:25 --> URI Class Initialized
INFO - 2023-01-03 10:06:25 --> Router Class Initialized
INFO - 2023-01-03 10:06:25 --> Output Class Initialized
INFO - 2023-01-03 10:06:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:25 --> Input Class Initialized
INFO - 2023-01-03 10:06:25 --> Language Class Initialized
INFO - 2023-01-03 10:06:25 --> Loader Class Initialized
INFO - 2023-01-03 10:06:25 --> Controller Class Initialized
DEBUG - 2023-01-03 10:06:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:25 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:25 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:25 --> Total execution time: 0.1543
INFO - 2023-01-03 10:06:29 --> Config Class Initialized
INFO - 2023-01-03 10:06:29 --> Hooks Class Initialized
INFO - 2023-01-03 10:06:29 --> Config Class Initialized
INFO - 2023-01-03 10:06:29 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:29 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:29 --> Utf8 Class Initialized
DEBUG - 2023-01-03 10:06:29 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:29 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:29 --> URI Class Initialized
INFO - 2023-01-03 10:06:29 --> URI Class Initialized
INFO - 2023-01-03 10:06:29 --> Router Class Initialized
INFO - 2023-01-03 10:06:29 --> Router Class Initialized
INFO - 2023-01-03 10:06:29 --> Output Class Initialized
INFO - 2023-01-03 10:06:29 --> Output Class Initialized
INFO - 2023-01-03 10:06:29 --> Security Class Initialized
INFO - 2023-01-03 10:06:29 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:29 --> Input Class Initialized
DEBUG - 2023-01-03 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:29 --> Input Class Initialized
INFO - 2023-01-03 10:06:29 --> Language Class Initialized
INFO - 2023-01-03 10:06:29 --> Language Class Initialized
INFO - 2023-01-03 10:06:29 --> Loader Class Initialized
INFO - 2023-01-03 10:06:29 --> Loader Class Initialized
INFO - 2023-01-03 10:06:29 --> Controller Class Initialized
DEBUG - 2023-01-03 10:06:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:29 --> Controller Class Initialized
INFO - 2023-01-03 10:06:29 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:29 --> Total execution time: 0.1834
DEBUG - 2023-01-03 10:06:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:29 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:29 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:29 --> Config Class Initialized
INFO - 2023-01-03 10:06:29 --> Hooks Class Initialized
INFO - 2023-01-03 10:06:29 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:29 --> Total execution time: 0.2453
DEBUG - 2023-01-03 10:06:29 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:29 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:29 --> URI Class Initialized
INFO - 2023-01-03 10:06:29 --> Config Class Initialized
INFO - 2023-01-03 10:06:29 --> Router Class Initialized
INFO - 2023-01-03 10:06:29 --> Config Class Initialized
INFO - 2023-01-03 10:06:29 --> Hooks Class Initialized
INFO - 2023-01-03 10:06:29 --> Hooks Class Initialized
INFO - 2023-01-03 10:06:29 --> Output Class Initialized
DEBUG - 2023-01-03 10:06:29 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:29 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:29 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:29 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:29 --> Utf8 Class Initialized
DEBUG - 2023-01-03 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:29 --> URI Class Initialized
INFO - 2023-01-03 10:06:29 --> Input Class Initialized
INFO - 2023-01-03 10:06:29 --> URI Class Initialized
INFO - 2023-01-03 10:06:29 --> Language Class Initialized
INFO - 2023-01-03 10:06:29 --> Router Class Initialized
INFO - 2023-01-03 10:06:29 --> Router Class Initialized
INFO - 2023-01-03 10:06:29 --> Loader Class Initialized
INFO - 2023-01-03 10:06:29 --> Output Class Initialized
INFO - 2023-01-03 10:06:29 --> Output Class Initialized
INFO - 2023-01-03 10:06:29 --> Controller Class Initialized
INFO - 2023-01-03 10:06:29 --> Security Class Initialized
INFO - 2023-01-03 10:06:29 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-03 10:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:29 --> Input Class Initialized
INFO - 2023-01-03 10:06:29 --> Input Class Initialized
INFO - 2023-01-03 10:06:29 --> Language Class Initialized
INFO - 2023-01-03 10:06:29 --> Language Class Initialized
INFO - 2023-01-03 10:06:29 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:29 --> Model "Login_model" initialized
INFO - 2023-01-03 10:06:29 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:29 --> Loader Class Initialized
INFO - 2023-01-03 10:06:29 --> Loader Class Initialized
INFO - 2023-01-03 10:06:29 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:29 --> Controller Class Initialized
INFO - 2023-01-03 10:06:29 --> Controller Class Initialized
INFO - 2023-01-03 10:06:29 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-03 10:06:29 --> Total execution time: 0.3606
DEBUG - 2023-01-03 10:06:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:29 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:29 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:29 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:29 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:29 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:29 --> Total execution time: 0.3530
INFO - 2023-01-03 10:06:29 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:29 --> Model "Login_model" initialized
INFO - 2023-01-03 10:06:29 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:29 --> Total execution time: 0.3767
INFO - 2023-01-03 10:06:29 --> Config Class Initialized
INFO - 2023-01-03 10:06:29 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:06:29 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:06:29 --> Utf8 Class Initialized
INFO - 2023-01-03 10:06:29 --> URI Class Initialized
INFO - 2023-01-03 10:06:29 --> Router Class Initialized
INFO - 2023-01-03 10:06:29 --> Output Class Initialized
INFO - 2023-01-03 10:06:29 --> Security Class Initialized
DEBUG - 2023-01-03 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:06:29 --> Input Class Initialized
INFO - 2023-01-03 10:06:29 --> Language Class Initialized
INFO - 2023-01-03 10:06:29 --> Loader Class Initialized
INFO - 2023-01-03 10:06:29 --> Controller Class Initialized
DEBUG - 2023-01-03 10:06:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:06:30 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:30 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:06:30 --> Database Driver Class Initialized
INFO - 2023-01-03 10:06:30 --> Model "Login_model" initialized
INFO - 2023-01-03 10:06:30 --> Final output sent to browser
DEBUG - 2023-01-03 10:06:30 --> Total execution time: 0.2107
INFO - 2023-01-03 10:08:27 --> Config Class Initialized
INFO - 2023-01-03 10:08:27 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:08:27 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:08:27 --> Utf8 Class Initialized
INFO - 2023-01-03 10:08:27 --> URI Class Initialized
INFO - 2023-01-03 10:08:27 --> Router Class Initialized
INFO - 2023-01-03 10:08:27 --> Output Class Initialized
INFO - 2023-01-03 10:08:27 --> Security Class Initialized
DEBUG - 2023-01-03 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:08:27 --> Input Class Initialized
INFO - 2023-01-03 10:08:27 --> Language Class Initialized
INFO - 2023-01-03 10:08:27 --> Loader Class Initialized
INFO - 2023-01-03 10:08:27 --> Controller Class Initialized
DEBUG - 2023-01-03 10:08:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:08:27 --> Database Driver Class Initialized
INFO - 2023-01-03 10:08:27 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:08:27 --> Database Driver Class Initialized
INFO - 2023-01-03 10:08:27 --> Model "Login_model" initialized
INFO - 2023-01-03 10:08:27 --> Final output sent to browser
DEBUG - 2023-01-03 10:08:27 --> Total execution time: 0.3545
INFO - 2023-01-03 10:12:14 --> Config Class Initialized
INFO - 2023-01-03 10:12:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:12:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:12:14 --> Utf8 Class Initialized
INFO - 2023-01-03 10:12:14 --> URI Class Initialized
INFO - 2023-01-03 10:12:14 --> Router Class Initialized
INFO - 2023-01-03 10:12:14 --> Output Class Initialized
INFO - 2023-01-03 10:12:14 --> Security Class Initialized
DEBUG - 2023-01-03 10:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:12:14 --> Input Class Initialized
INFO - 2023-01-03 10:12:14 --> Language Class Initialized
INFO - 2023-01-03 10:12:14 --> Loader Class Initialized
INFO - 2023-01-03 10:12:14 --> Controller Class Initialized
DEBUG - 2023-01-03 10:12:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:12:14 --> Database Driver Class Initialized
INFO - 2023-01-03 10:12:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:12:14 --> Final output sent to browser
DEBUG - 2023-01-03 10:12:14 --> Total execution time: 0.1629
INFO - 2023-01-03 10:12:14 --> Config Class Initialized
INFO - 2023-01-03 10:12:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:12:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:12:14 --> Utf8 Class Initialized
INFO - 2023-01-03 10:12:14 --> URI Class Initialized
INFO - 2023-01-03 10:12:14 --> Router Class Initialized
INFO - 2023-01-03 10:12:14 --> Output Class Initialized
INFO - 2023-01-03 10:12:14 --> Security Class Initialized
DEBUG - 2023-01-03 10:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:12:14 --> Input Class Initialized
INFO - 2023-01-03 10:12:14 --> Language Class Initialized
INFO - 2023-01-03 10:12:14 --> Loader Class Initialized
INFO - 2023-01-03 10:12:14 --> Controller Class Initialized
DEBUG - 2023-01-03 10:12:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:12:14 --> Database Driver Class Initialized
INFO - 2023-01-03 10:12:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:12:14 --> Final output sent to browser
DEBUG - 2023-01-03 10:12:14 --> Total execution time: 0.1667
INFO - 2023-01-03 10:13:24 --> Config Class Initialized
INFO - 2023-01-03 10:13:24 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:24 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:24 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:24 --> URI Class Initialized
INFO - 2023-01-03 10:13:24 --> Router Class Initialized
INFO - 2023-01-03 10:13:24 --> Output Class Initialized
INFO - 2023-01-03 10:13:24 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:24 --> Input Class Initialized
INFO - 2023-01-03 10:13:24 --> Language Class Initialized
INFO - 2023-01-03 10:13:24 --> Loader Class Initialized
INFO - 2023-01-03 10:13:24 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:24 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:24 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:24 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:24 --> Total execution time: 0.2094
INFO - 2023-01-03 10:13:24 --> Config Class Initialized
INFO - 2023-01-03 10:13:24 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:24 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:24 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:24 --> URI Class Initialized
INFO - 2023-01-03 10:13:24 --> Router Class Initialized
INFO - 2023-01-03 10:13:24 --> Output Class Initialized
INFO - 2023-01-03 10:13:24 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:24 --> Input Class Initialized
INFO - 2023-01-03 10:13:24 --> Language Class Initialized
INFO - 2023-01-03 10:13:24 --> Loader Class Initialized
INFO - 2023-01-03 10:13:24 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:24 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:24 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:24 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:24 --> Total execution time: 0.2506
INFO - 2023-01-03 10:13:35 --> Config Class Initialized
INFO - 2023-01-03 10:13:35 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:35 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:35 --> URI Class Initialized
INFO - 2023-01-03 10:13:35 --> Router Class Initialized
INFO - 2023-01-03 10:13:35 --> Output Class Initialized
INFO - 2023-01-03 10:13:35 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:35 --> Input Class Initialized
INFO - 2023-01-03 10:13:35 --> Language Class Initialized
INFO - 2023-01-03 10:13:35 --> Loader Class Initialized
INFO - 2023-01-03 10:13:35 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:35 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:35 --> Total execution time: 0.1130
INFO - 2023-01-03 10:13:35 --> Config Class Initialized
INFO - 2023-01-03 10:13:35 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:35 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:35 --> URI Class Initialized
INFO - 2023-01-03 10:13:35 --> Router Class Initialized
INFO - 2023-01-03 10:13:35 --> Output Class Initialized
INFO - 2023-01-03 10:13:35 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:35 --> Input Class Initialized
INFO - 2023-01-03 10:13:35 --> Language Class Initialized
INFO - 2023-01-03 10:13:35 --> Loader Class Initialized
INFO - 2023-01-03 10:13:35 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:35 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:35 --> Model "Login_model" initialized
INFO - 2023-01-03 10:13:35 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:35 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:35 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:35 --> Total execution time: 0.1894
INFO - 2023-01-03 10:13:36 --> Config Class Initialized
INFO - 2023-01-03 10:13:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:36 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:36 --> URI Class Initialized
INFO - 2023-01-03 10:13:36 --> Router Class Initialized
INFO - 2023-01-03 10:13:36 --> Output Class Initialized
INFO - 2023-01-03 10:13:36 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:36 --> Input Class Initialized
INFO - 2023-01-03 10:13:36 --> Language Class Initialized
INFO - 2023-01-03 10:13:36 --> Loader Class Initialized
INFO - 2023-01-03 10:13:36 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:36 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:36 --> Total execution time: 0.1088
INFO - 2023-01-03 10:13:36 --> Config Class Initialized
INFO - 2023-01-03 10:13:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:36 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:36 --> URI Class Initialized
INFO - 2023-01-03 10:13:36 --> Router Class Initialized
INFO - 2023-01-03 10:13:36 --> Output Class Initialized
INFO - 2023-01-03 10:13:36 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:36 --> Input Class Initialized
INFO - 2023-01-03 10:13:36 --> Language Class Initialized
INFO - 2023-01-03 10:13:36 --> Loader Class Initialized
INFO - 2023-01-03 10:13:36 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:36 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:36 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:36 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:36 --> Total execution time: 0.1652
INFO - 2023-01-03 10:13:37 --> Config Class Initialized
INFO - 2023-01-03 10:13:37 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:37 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:37 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:37 --> URI Class Initialized
INFO - 2023-01-03 10:13:37 --> Router Class Initialized
INFO - 2023-01-03 10:13:37 --> Output Class Initialized
INFO - 2023-01-03 10:13:37 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:37 --> Input Class Initialized
INFO - 2023-01-03 10:13:37 --> Language Class Initialized
INFO - 2023-01-03 10:13:37 --> Loader Class Initialized
INFO - 2023-01-03 10:13:37 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:37 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:37 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:37 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:37 --> Total execution time: 0.1473
INFO - 2023-01-03 10:13:38 --> Config Class Initialized
INFO - 2023-01-03 10:13:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:38 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:38 --> URI Class Initialized
INFO - 2023-01-03 10:13:38 --> Router Class Initialized
INFO - 2023-01-03 10:13:38 --> Output Class Initialized
INFO - 2023-01-03 10:13:38 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:38 --> Input Class Initialized
INFO - 2023-01-03 10:13:38 --> Language Class Initialized
INFO - 2023-01-03 10:13:38 --> Loader Class Initialized
INFO - 2023-01-03 10:13:38 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:38 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:38 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:38 --> Total execution time: 0.1512
INFO - 2023-01-03 10:13:39 --> Config Class Initialized
INFO - 2023-01-03 10:13:39 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:39 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:39 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:39 --> URI Class Initialized
INFO - 2023-01-03 10:13:39 --> Router Class Initialized
INFO - 2023-01-03 10:13:39 --> Output Class Initialized
INFO - 2023-01-03 10:13:39 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:39 --> Input Class Initialized
INFO - 2023-01-03 10:13:39 --> Language Class Initialized
INFO - 2023-01-03 10:13:39 --> Loader Class Initialized
INFO - 2023-01-03 10:13:39 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:39 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:39 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:39 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:39 --> Total execution time: 0.1567
INFO - 2023-01-03 10:13:40 --> Config Class Initialized
INFO - 2023-01-03 10:13:40 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:40 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:40 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:40 --> URI Class Initialized
INFO - 2023-01-03 10:13:40 --> Router Class Initialized
INFO - 2023-01-03 10:13:40 --> Output Class Initialized
INFO - 2023-01-03 10:13:40 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:40 --> Input Class Initialized
INFO - 2023-01-03 10:13:40 --> Language Class Initialized
INFO - 2023-01-03 10:13:40 --> Loader Class Initialized
INFO - 2023-01-03 10:13:40 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:40 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:40 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:40 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:40 --> Total execution time: 0.1598
INFO - 2023-01-03 10:13:41 --> Config Class Initialized
INFO - 2023-01-03 10:13:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:41 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:41 --> URI Class Initialized
INFO - 2023-01-03 10:13:41 --> Router Class Initialized
INFO - 2023-01-03 10:13:41 --> Output Class Initialized
INFO - 2023-01-03 10:13:41 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:41 --> Input Class Initialized
INFO - 2023-01-03 10:13:41 --> Language Class Initialized
INFO - 2023-01-03 10:13:41 --> Loader Class Initialized
INFO - 2023-01-03 10:13:41 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:41 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:41 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:41 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:41 --> Total execution time: 0.1627
INFO - 2023-01-03 10:13:42 --> Config Class Initialized
INFO - 2023-01-03 10:13:42 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:42 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:42 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:42 --> URI Class Initialized
INFO - 2023-01-03 10:13:42 --> Router Class Initialized
INFO - 2023-01-03 10:13:42 --> Output Class Initialized
INFO - 2023-01-03 10:13:42 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:42 --> Input Class Initialized
INFO - 2023-01-03 10:13:42 --> Language Class Initialized
INFO - 2023-01-03 10:13:42 --> Loader Class Initialized
INFO - 2023-01-03 10:13:42 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:42 --> Total execution time: 0.1272
INFO - 2023-01-03 10:13:42 --> Config Class Initialized
INFO - 2023-01-03 10:13:42 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:42 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:42 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:42 --> URI Class Initialized
INFO - 2023-01-03 10:13:42 --> Router Class Initialized
INFO - 2023-01-03 10:13:42 --> Output Class Initialized
INFO - 2023-01-03 10:13:42 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:42 --> Input Class Initialized
INFO - 2023-01-03 10:13:42 --> Language Class Initialized
INFO - 2023-01-03 10:13:42 --> Loader Class Initialized
INFO - 2023-01-03 10:13:42 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:42 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:42 --> Total execution time: 0.1522
INFO - 2023-01-03 10:13:44 --> Config Class Initialized
INFO - 2023-01-03 10:13:44 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:44 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:44 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:44 --> URI Class Initialized
INFO - 2023-01-03 10:13:44 --> Router Class Initialized
INFO - 2023-01-03 10:13:44 --> Output Class Initialized
INFO - 2023-01-03 10:13:44 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:44 --> Input Class Initialized
INFO - 2023-01-03 10:13:44 --> Language Class Initialized
INFO - 2023-01-03 10:13:44 --> Loader Class Initialized
INFO - 2023-01-03 10:13:44 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:44 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:44 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:44 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:44 --> Model "Login_model" initialized
INFO - 2023-01-03 10:13:44 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:44 --> Total execution time: 0.3273
INFO - 2023-01-03 10:13:44 --> Config Class Initialized
INFO - 2023-01-03 10:13:44 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:13:44 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:13:44 --> Utf8 Class Initialized
INFO - 2023-01-03 10:13:44 --> URI Class Initialized
INFO - 2023-01-03 10:13:44 --> Router Class Initialized
INFO - 2023-01-03 10:13:44 --> Output Class Initialized
INFO - 2023-01-03 10:13:44 --> Security Class Initialized
DEBUG - 2023-01-03 10:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:13:45 --> Input Class Initialized
INFO - 2023-01-03 10:13:45 --> Language Class Initialized
INFO - 2023-01-03 10:13:45 --> Loader Class Initialized
INFO - 2023-01-03 10:13:45 --> Controller Class Initialized
DEBUG - 2023-01-03 10:13:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:13:45 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:45 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:13:45 --> Database Driver Class Initialized
INFO - 2023-01-03 10:13:45 --> Model "Login_model" initialized
INFO - 2023-01-03 10:13:45 --> Final output sent to browser
DEBUG - 2023-01-03 10:13:45 --> Total execution time: 0.2866
INFO - 2023-01-03 10:15:18 --> Config Class Initialized
INFO - 2023-01-03 10:15:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:15:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:15:18 --> Utf8 Class Initialized
INFO - 2023-01-03 10:15:18 --> URI Class Initialized
INFO - 2023-01-03 10:15:18 --> Router Class Initialized
INFO - 2023-01-03 10:15:18 --> Output Class Initialized
INFO - 2023-01-03 10:15:18 --> Security Class Initialized
DEBUG - 2023-01-03 10:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:15:18 --> Input Class Initialized
INFO - 2023-01-03 10:15:18 --> Language Class Initialized
INFO - 2023-01-03 10:15:18 --> Loader Class Initialized
INFO - 2023-01-03 10:15:18 --> Controller Class Initialized
DEBUG - 2023-01-03 10:15:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:15:18 --> Database Driver Class Initialized
INFO - 2023-01-03 10:15:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:15:18 --> Final output sent to browser
DEBUG - 2023-01-03 10:15:18 --> Total execution time: 0.1638
INFO - 2023-01-03 10:15:18 --> Config Class Initialized
INFO - 2023-01-03 10:15:18 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:15:18 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:15:18 --> Utf8 Class Initialized
INFO - 2023-01-03 10:15:18 --> URI Class Initialized
INFO - 2023-01-03 10:15:18 --> Router Class Initialized
INFO - 2023-01-03 10:15:18 --> Output Class Initialized
INFO - 2023-01-03 10:15:18 --> Security Class Initialized
DEBUG - 2023-01-03 10:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:15:18 --> Input Class Initialized
INFO - 2023-01-03 10:15:18 --> Language Class Initialized
INFO - 2023-01-03 10:15:18 --> Loader Class Initialized
INFO - 2023-01-03 10:15:18 --> Controller Class Initialized
DEBUG - 2023-01-03 10:15:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:15:18 --> Database Driver Class Initialized
INFO - 2023-01-03 10:15:18 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:15:18 --> Final output sent to browser
DEBUG - 2023-01-03 10:15:18 --> Total execution time: 0.1576
INFO - 2023-01-03 10:15:21 --> Config Class Initialized
INFO - 2023-01-03 10:15:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:15:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:15:21 --> Utf8 Class Initialized
INFO - 2023-01-03 10:15:21 --> URI Class Initialized
INFO - 2023-01-03 10:15:21 --> Router Class Initialized
INFO - 2023-01-03 10:15:21 --> Output Class Initialized
INFO - 2023-01-03 10:15:21 --> Security Class Initialized
DEBUG - 2023-01-03 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:15:21 --> Input Class Initialized
INFO - 2023-01-03 10:15:21 --> Language Class Initialized
INFO - 2023-01-03 10:15:21 --> Loader Class Initialized
INFO - 2023-01-03 10:15:21 --> Controller Class Initialized
DEBUG - 2023-01-03 10:15:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:15:21 --> Database Driver Class Initialized
INFO - 2023-01-03 10:15:21 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:15:21 --> Final output sent to browser
DEBUG - 2023-01-03 10:15:21 --> Total execution time: 0.1659
INFO - 2023-01-03 10:15:21 --> Config Class Initialized
INFO - 2023-01-03 10:15:21 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:15:21 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:15:21 --> Utf8 Class Initialized
INFO - 2023-01-03 10:15:21 --> URI Class Initialized
INFO - 2023-01-03 10:15:21 --> Router Class Initialized
INFO - 2023-01-03 10:15:21 --> Output Class Initialized
INFO - 2023-01-03 10:15:21 --> Security Class Initialized
DEBUG - 2023-01-03 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:15:21 --> Input Class Initialized
INFO - 2023-01-03 10:15:21 --> Language Class Initialized
INFO - 2023-01-03 10:15:21 --> Loader Class Initialized
INFO - 2023-01-03 10:15:22 --> Controller Class Initialized
DEBUG - 2023-01-03 10:15:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:15:22 --> Database Driver Class Initialized
INFO - 2023-01-03 10:15:22 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:15:22 --> Final output sent to browser
DEBUG - 2023-01-03 10:15:22 --> Total execution time: 0.1566
INFO - 2023-01-03 10:15:25 --> Config Class Initialized
INFO - 2023-01-03 10:15:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:15:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:15:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:15:25 --> URI Class Initialized
INFO - 2023-01-03 10:15:25 --> Router Class Initialized
INFO - 2023-01-03 10:15:25 --> Output Class Initialized
INFO - 2023-01-03 10:15:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:15:25 --> Input Class Initialized
INFO - 2023-01-03 10:15:25 --> Language Class Initialized
INFO - 2023-01-03 10:15:25 --> Loader Class Initialized
INFO - 2023-01-03 10:15:25 --> Controller Class Initialized
DEBUG - 2023-01-03 10:15:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:15:25 --> Database Driver Class Initialized
INFO - 2023-01-03 10:15:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:15:25 --> Final output sent to browser
DEBUG - 2023-01-03 10:15:25 --> Total execution time: 0.1739
INFO - 2023-01-03 10:15:25 --> Config Class Initialized
INFO - 2023-01-03 10:15:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:15:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:15:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:15:25 --> URI Class Initialized
INFO - 2023-01-03 10:15:25 --> Router Class Initialized
INFO - 2023-01-03 10:15:25 --> Output Class Initialized
INFO - 2023-01-03 10:15:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:15:25 --> Input Class Initialized
INFO - 2023-01-03 10:15:25 --> Language Class Initialized
INFO - 2023-01-03 10:15:25 --> Loader Class Initialized
INFO - 2023-01-03 10:15:25 --> Controller Class Initialized
DEBUG - 2023-01-03 10:15:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:15:25 --> Database Driver Class Initialized
INFO - 2023-01-03 10:15:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:15:25 --> Final output sent to browser
DEBUG - 2023-01-03 10:15:25 --> Total execution time: 0.1555
INFO - 2023-01-03 10:15:28 --> Config Class Initialized
INFO - 2023-01-03 10:15:28 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:15:28 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:15:28 --> Utf8 Class Initialized
INFO - 2023-01-03 10:15:28 --> URI Class Initialized
INFO - 2023-01-03 10:15:28 --> Router Class Initialized
INFO - 2023-01-03 10:15:28 --> Output Class Initialized
INFO - 2023-01-03 10:15:28 --> Security Class Initialized
DEBUG - 2023-01-03 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:15:28 --> Input Class Initialized
INFO - 2023-01-03 10:15:28 --> Language Class Initialized
INFO - 2023-01-03 10:15:28 --> Loader Class Initialized
INFO - 2023-01-03 10:15:28 --> Controller Class Initialized
DEBUG - 2023-01-03 10:15:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:15:28 --> Final output sent to browser
DEBUG - 2023-01-03 10:15:28 --> Total execution time: 0.1354
INFO - 2023-01-03 10:15:28 --> Config Class Initialized
INFO - 2023-01-03 10:15:28 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:15:28 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:15:28 --> Utf8 Class Initialized
INFO - 2023-01-03 10:15:28 --> URI Class Initialized
INFO - 2023-01-03 10:15:28 --> Router Class Initialized
INFO - 2023-01-03 10:15:28 --> Output Class Initialized
INFO - 2023-01-03 10:15:28 --> Security Class Initialized
DEBUG - 2023-01-03 10:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:15:28 --> Input Class Initialized
INFO - 2023-01-03 10:15:28 --> Language Class Initialized
INFO - 2023-01-03 10:15:28 --> Loader Class Initialized
INFO - 2023-01-03 10:15:28 --> Controller Class Initialized
DEBUG - 2023-01-03 10:15:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:15:28 --> Database Driver Class Initialized
INFO - 2023-01-03 10:15:28 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:15:28 --> Final output sent to browser
DEBUG - 2023-01-03 10:15:28 --> Total execution time: 0.1366
INFO - 2023-01-03 10:17:41 --> Config Class Initialized
INFO - 2023-01-03 10:17:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:17:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:17:41 --> Utf8 Class Initialized
INFO - 2023-01-03 10:17:41 --> URI Class Initialized
INFO - 2023-01-03 10:17:41 --> Router Class Initialized
INFO - 2023-01-03 10:17:41 --> Output Class Initialized
INFO - 2023-01-03 10:17:41 --> Security Class Initialized
DEBUG - 2023-01-03 10:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:17:41 --> Input Class Initialized
INFO - 2023-01-03 10:17:41 --> Language Class Initialized
INFO - 2023-01-03 10:17:42 --> Loader Class Initialized
INFO - 2023-01-03 10:17:42 --> Controller Class Initialized
DEBUG - 2023-01-03 10:17:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:17:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:17:42 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:17:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:17:42 --> Total execution time: 1.6205
INFO - 2023-01-03 10:17:43 --> Config Class Initialized
INFO - 2023-01-03 10:17:43 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:17:43 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:17:43 --> Utf8 Class Initialized
INFO - 2023-01-03 10:17:43 --> URI Class Initialized
INFO - 2023-01-03 10:17:43 --> Router Class Initialized
INFO - 2023-01-03 10:17:43 --> Output Class Initialized
INFO - 2023-01-03 10:17:43 --> Security Class Initialized
DEBUG - 2023-01-03 10:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:17:43 --> Input Class Initialized
INFO - 2023-01-03 10:17:44 --> Language Class Initialized
INFO - 2023-01-03 10:17:44 --> Loader Class Initialized
INFO - 2023-01-03 10:17:44 --> Controller Class Initialized
DEBUG - 2023-01-03 10:17:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:17:44 --> Database Driver Class Initialized
INFO - 2023-01-03 10:17:44 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:17:44 --> Final output sent to browser
DEBUG - 2023-01-03 10:17:44 --> Total execution time: 1.5005
INFO - 2023-01-03 10:19:22 --> Config Class Initialized
INFO - 2023-01-03 10:19:22 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:19:22 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:19:22 --> Utf8 Class Initialized
INFO - 2023-01-03 10:19:22 --> URI Class Initialized
INFO - 2023-01-03 10:19:22 --> Router Class Initialized
INFO - 2023-01-03 10:19:22 --> Output Class Initialized
INFO - 2023-01-03 10:19:22 --> Security Class Initialized
DEBUG - 2023-01-03 10:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:19:22 --> Input Class Initialized
INFO - 2023-01-03 10:19:22 --> Language Class Initialized
INFO - 2023-01-03 10:19:22 --> Loader Class Initialized
INFO - 2023-01-03 10:19:22 --> Controller Class Initialized
DEBUG - 2023-01-03 10:19:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:19:23 --> Database Driver Class Initialized
INFO - 2023-01-03 10:19:23 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:19:23 --> Final output sent to browser
DEBUG - 2023-01-03 10:19:23 --> Total execution time: 0.9004
INFO - 2023-01-03 10:19:23 --> Config Class Initialized
INFO - 2023-01-03 10:19:23 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:19:23 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:19:23 --> Utf8 Class Initialized
INFO - 2023-01-03 10:19:23 --> URI Class Initialized
INFO - 2023-01-03 10:19:23 --> Router Class Initialized
INFO - 2023-01-03 10:19:23 --> Output Class Initialized
INFO - 2023-01-03 10:19:23 --> Security Class Initialized
DEBUG - 2023-01-03 10:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:19:23 --> Input Class Initialized
INFO - 2023-01-03 10:19:23 --> Language Class Initialized
INFO - 2023-01-03 10:19:24 --> Loader Class Initialized
INFO - 2023-01-03 10:19:24 --> Controller Class Initialized
DEBUG - 2023-01-03 10:19:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:19:24 --> Database Driver Class Initialized
INFO - 2023-01-03 10:19:24 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:19:24 --> Final output sent to browser
DEBUG - 2023-01-03 10:19:24 --> Total execution time: 1.1210
INFO - 2023-01-03 10:20:53 --> Config Class Initialized
INFO - 2023-01-03 10:20:53 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:20:53 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:20:53 --> Utf8 Class Initialized
INFO - 2023-01-03 10:20:53 --> URI Class Initialized
INFO - 2023-01-03 10:20:53 --> Router Class Initialized
INFO - 2023-01-03 10:20:53 --> Output Class Initialized
INFO - 2023-01-03 10:20:53 --> Security Class Initialized
DEBUG - 2023-01-03 10:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:20:53 --> Input Class Initialized
INFO - 2023-01-03 10:20:53 --> Language Class Initialized
INFO - 2023-01-03 10:20:53 --> Loader Class Initialized
INFO - 2023-01-03 10:20:53 --> Controller Class Initialized
DEBUG - 2023-01-03 10:20:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:20:53 --> Database Driver Class Initialized
INFO - 2023-01-03 10:20:53 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:20:53 --> Final output sent to browser
DEBUG - 2023-01-03 10:20:53 --> Total execution time: 0.7406
INFO - 2023-01-03 10:20:54 --> Config Class Initialized
INFO - 2023-01-03 10:20:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:20:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:20:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:20:54 --> URI Class Initialized
INFO - 2023-01-03 10:20:54 --> Router Class Initialized
INFO - 2023-01-03 10:20:54 --> Output Class Initialized
INFO - 2023-01-03 10:20:54 --> Security Class Initialized
DEBUG - 2023-01-03 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:20:54 --> Input Class Initialized
INFO - 2023-01-03 10:20:54 --> Language Class Initialized
INFO - 2023-01-03 10:20:54 --> Loader Class Initialized
INFO - 2023-01-03 10:20:54 --> Controller Class Initialized
DEBUG - 2023-01-03 10:20:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:20:54 --> Database Driver Class Initialized
INFO - 2023-01-03 10:20:54 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:20:54 --> Final output sent to browser
DEBUG - 2023-01-03 10:20:54 --> Total execution time: 0.7061
INFO - 2023-01-03 10:22:01 --> Config Class Initialized
INFO - 2023-01-03 10:22:01 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:22:01 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:22:01 --> Utf8 Class Initialized
INFO - 2023-01-03 10:22:01 --> URI Class Initialized
INFO - 2023-01-03 10:22:01 --> Router Class Initialized
INFO - 2023-01-03 10:22:01 --> Output Class Initialized
INFO - 2023-01-03 10:22:01 --> Security Class Initialized
DEBUG - 2023-01-03 10:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:22:01 --> Input Class Initialized
INFO - 2023-01-03 10:22:01 --> Language Class Initialized
INFO - 2023-01-03 10:22:02 --> Loader Class Initialized
INFO - 2023-01-03 10:22:02 --> Controller Class Initialized
DEBUG - 2023-01-03 10:22:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:22:02 --> Database Driver Class Initialized
INFO - 2023-01-03 10:22:02 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:22:02 --> Final output sent to browser
DEBUG - 2023-01-03 10:22:02 --> Total execution time: 0.9891
INFO - 2023-01-03 10:22:02 --> Config Class Initialized
INFO - 2023-01-03 10:22:02 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:22:02 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:22:02 --> Utf8 Class Initialized
INFO - 2023-01-03 10:22:02 --> URI Class Initialized
INFO - 2023-01-03 10:22:02 --> Router Class Initialized
INFO - 2023-01-03 10:22:02 --> Output Class Initialized
INFO - 2023-01-03 10:22:02 --> Security Class Initialized
DEBUG - 2023-01-03 10:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:22:03 --> Input Class Initialized
INFO - 2023-01-03 10:22:03 --> Language Class Initialized
INFO - 2023-01-03 10:22:03 --> Loader Class Initialized
INFO - 2023-01-03 10:22:03 --> Controller Class Initialized
DEBUG - 2023-01-03 10:22:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:22:03 --> Database Driver Class Initialized
INFO - 2023-01-03 10:22:03 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:22:03 --> Final output sent to browser
DEBUG - 2023-01-03 10:22:03 --> Total execution time: 1.1398
INFO - 2023-01-03 10:23:41 --> Config Class Initialized
INFO - 2023-01-03 10:23:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:23:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:23:41 --> Utf8 Class Initialized
INFO - 2023-01-03 10:23:41 --> URI Class Initialized
INFO - 2023-01-03 10:23:41 --> Router Class Initialized
INFO - 2023-01-03 10:23:41 --> Output Class Initialized
INFO - 2023-01-03 10:23:41 --> Security Class Initialized
DEBUG - 2023-01-03 10:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:23:41 --> Input Class Initialized
INFO - 2023-01-03 10:23:41 --> Language Class Initialized
INFO - 2023-01-03 10:23:41 --> Loader Class Initialized
INFO - 2023-01-03 10:23:41 --> Controller Class Initialized
DEBUG - 2023-01-03 10:23:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:23:41 --> Database Driver Class Initialized
INFO - 2023-01-03 10:23:41 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:23:41 --> Final output sent to browser
DEBUG - 2023-01-03 10:23:41 --> Total execution time: 0.4347
INFO - 2023-01-03 10:23:41 --> Config Class Initialized
INFO - 2023-01-03 10:23:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:23:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:23:41 --> Utf8 Class Initialized
INFO - 2023-01-03 10:23:41 --> URI Class Initialized
INFO - 2023-01-03 10:23:41 --> Router Class Initialized
INFO - 2023-01-03 10:23:42 --> Output Class Initialized
INFO - 2023-01-03 10:23:42 --> Security Class Initialized
DEBUG - 2023-01-03 10:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:23:42 --> Input Class Initialized
INFO - 2023-01-03 10:23:42 --> Language Class Initialized
INFO - 2023-01-03 10:23:42 --> Loader Class Initialized
INFO - 2023-01-03 10:23:42 --> Controller Class Initialized
DEBUG - 2023-01-03 10:23:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:23:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:23:42 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:23:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:23:42 --> Total execution time: 0.7892
INFO - 2023-01-03 10:25:02 --> Config Class Initialized
INFO - 2023-01-03 10:25:02 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:25:02 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:25:02 --> Utf8 Class Initialized
INFO - 2023-01-03 10:25:02 --> URI Class Initialized
INFO - 2023-01-03 10:25:02 --> Router Class Initialized
INFO - 2023-01-03 10:25:02 --> Output Class Initialized
INFO - 2023-01-03 10:25:02 --> Security Class Initialized
DEBUG - 2023-01-03 10:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:25:02 --> Input Class Initialized
INFO - 2023-01-03 10:25:02 --> Language Class Initialized
INFO - 2023-01-03 10:25:02 --> Loader Class Initialized
INFO - 2023-01-03 10:25:02 --> Controller Class Initialized
DEBUG - 2023-01-03 10:25:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:25:02 --> Final output sent to browser
DEBUG - 2023-01-03 10:25:02 --> Total execution time: 0.3402
INFO - 2023-01-03 10:25:02 --> Config Class Initialized
INFO - 2023-01-03 10:25:02 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:25:02 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:25:02 --> Utf8 Class Initialized
INFO - 2023-01-03 10:25:02 --> URI Class Initialized
INFO - 2023-01-03 10:25:02 --> Router Class Initialized
INFO - 2023-01-03 10:25:02 --> Output Class Initialized
INFO - 2023-01-03 10:25:02 --> Security Class Initialized
DEBUG - 2023-01-03 10:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:25:02 --> Input Class Initialized
INFO - 2023-01-03 10:25:02 --> Language Class Initialized
INFO - 2023-01-03 10:25:02 --> Loader Class Initialized
INFO - 2023-01-03 10:25:02 --> Controller Class Initialized
DEBUG - 2023-01-03 10:25:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:25:02 --> Database Driver Class Initialized
INFO - 2023-01-03 10:25:02 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:25:02 --> Final output sent to browser
DEBUG - 2023-01-03 10:25:02 --> Total execution time: 0.2746
INFO - 2023-01-03 10:25:04 --> Config Class Initialized
INFO - 2023-01-03 10:25:04 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:25:04 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:25:04 --> Utf8 Class Initialized
INFO - 2023-01-03 10:25:04 --> URI Class Initialized
INFO - 2023-01-03 10:25:04 --> Router Class Initialized
INFO - 2023-01-03 10:25:04 --> Output Class Initialized
INFO - 2023-01-03 10:25:04 --> Security Class Initialized
DEBUG - 2023-01-03 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:25:04 --> Input Class Initialized
INFO - 2023-01-03 10:25:04 --> Language Class Initialized
INFO - 2023-01-03 10:25:04 --> Loader Class Initialized
INFO - 2023-01-03 10:25:04 --> Controller Class Initialized
DEBUG - 2023-01-03 10:25:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:25:04 --> Database Driver Class Initialized
INFO - 2023-01-03 10:25:04 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:25:04 --> Final output sent to browser
DEBUG - 2023-01-03 10:25:04 --> Total execution time: 0.3019
INFO - 2023-01-03 10:25:04 --> Config Class Initialized
INFO - 2023-01-03 10:25:04 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:25:04 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:25:04 --> Utf8 Class Initialized
INFO - 2023-01-03 10:25:04 --> URI Class Initialized
INFO - 2023-01-03 10:25:04 --> Router Class Initialized
INFO - 2023-01-03 10:25:04 --> Output Class Initialized
INFO - 2023-01-03 10:25:04 --> Security Class Initialized
DEBUG - 2023-01-03 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:25:04 --> Input Class Initialized
INFO - 2023-01-03 10:25:04 --> Language Class Initialized
INFO - 2023-01-03 10:25:04 --> Loader Class Initialized
INFO - 2023-01-03 10:25:04 --> Controller Class Initialized
DEBUG - 2023-01-03 10:25:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:25:04 --> Database Driver Class Initialized
INFO - 2023-01-03 10:25:04 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:25:04 --> Final output sent to browser
DEBUG - 2023-01-03 10:25:04 --> Total execution time: 0.3017
INFO - 2023-01-03 10:31:46 --> Config Class Initialized
INFO - 2023-01-03 10:31:46 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:31:46 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:31:46 --> Utf8 Class Initialized
INFO - 2023-01-03 10:31:46 --> URI Class Initialized
INFO - 2023-01-03 10:31:46 --> Router Class Initialized
INFO - 2023-01-03 10:31:46 --> Output Class Initialized
INFO - 2023-01-03 10:31:46 --> Security Class Initialized
DEBUG - 2023-01-03 10:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:31:46 --> Input Class Initialized
INFO - 2023-01-03 10:31:46 --> Language Class Initialized
INFO - 2023-01-03 10:31:46 --> Loader Class Initialized
INFO - 2023-01-03 10:31:46 --> Controller Class Initialized
DEBUG - 2023-01-03 10:31:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:31:46 --> Database Driver Class Initialized
INFO - 2023-01-03 10:31:46 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:31:46 --> Final output sent to browser
DEBUG - 2023-01-03 10:31:46 --> Total execution time: 0.1720
INFO - 2023-01-03 10:31:46 --> Config Class Initialized
INFO - 2023-01-03 10:31:46 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:31:46 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:31:46 --> Utf8 Class Initialized
INFO - 2023-01-03 10:31:46 --> URI Class Initialized
INFO - 2023-01-03 10:31:46 --> Router Class Initialized
INFO - 2023-01-03 10:31:46 --> Output Class Initialized
INFO - 2023-01-03 10:31:46 --> Security Class Initialized
DEBUG - 2023-01-03 10:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:31:46 --> Input Class Initialized
INFO - 2023-01-03 10:31:46 --> Language Class Initialized
INFO - 2023-01-03 10:31:46 --> Loader Class Initialized
INFO - 2023-01-03 10:31:46 --> Controller Class Initialized
DEBUG - 2023-01-03 10:31:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:31:46 --> Database Driver Class Initialized
INFO - 2023-01-03 10:31:46 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:31:46 --> Final output sent to browser
DEBUG - 2023-01-03 10:31:46 --> Total execution time: 0.1847
INFO - 2023-01-03 10:32:09 --> Config Class Initialized
INFO - 2023-01-03 10:32:09 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:09 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:09 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:09 --> URI Class Initialized
INFO - 2023-01-03 10:32:09 --> Router Class Initialized
INFO - 2023-01-03 10:32:09 --> Output Class Initialized
INFO - 2023-01-03 10:32:09 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:09 --> Input Class Initialized
INFO - 2023-01-03 10:32:09 --> Language Class Initialized
INFO - 2023-01-03 10:32:09 --> Loader Class Initialized
INFO - 2023-01-03 10:32:09 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:09 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:09 --> Total execution time: 0.1069
INFO - 2023-01-03 10:32:09 --> Config Class Initialized
INFO - 2023-01-03 10:32:09 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:09 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:09 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:09 --> URI Class Initialized
INFO - 2023-01-03 10:32:09 --> Router Class Initialized
INFO - 2023-01-03 10:32:09 --> Output Class Initialized
INFO - 2023-01-03 10:32:09 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:09 --> Input Class Initialized
INFO - 2023-01-03 10:32:09 --> Language Class Initialized
INFO - 2023-01-03 10:32:09 --> Loader Class Initialized
INFO - 2023-01-03 10:32:09 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:09 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:09 --> Model "Login_model" initialized
INFO - 2023-01-03 10:32:09 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:09 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:09 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:09 --> Total execution time: 0.1845
INFO - 2023-01-03 10:32:10 --> Config Class Initialized
INFO - 2023-01-03 10:32:10 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:10 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:10 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:10 --> URI Class Initialized
INFO - 2023-01-03 10:32:10 --> Router Class Initialized
INFO - 2023-01-03 10:32:10 --> Output Class Initialized
INFO - 2023-01-03 10:32:10 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:10 --> Input Class Initialized
INFO - 2023-01-03 10:32:10 --> Language Class Initialized
INFO - 2023-01-03 10:32:10 --> Loader Class Initialized
INFO - 2023-01-03 10:32:10 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:10 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:10 --> Total execution time: 0.1268
INFO - 2023-01-03 10:32:10 --> Config Class Initialized
INFO - 2023-01-03 10:32:10 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:10 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:10 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:10 --> URI Class Initialized
INFO - 2023-01-03 10:32:10 --> Router Class Initialized
INFO - 2023-01-03 10:32:11 --> Output Class Initialized
INFO - 2023-01-03 10:32:11 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:11 --> Input Class Initialized
INFO - 2023-01-03 10:32:11 --> Language Class Initialized
INFO - 2023-01-03 10:32:11 --> Loader Class Initialized
INFO - 2023-01-03 10:32:11 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:11 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:11 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:11 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:11 --> Total execution time: 0.1624
INFO - 2023-01-03 10:32:11 --> Config Class Initialized
INFO - 2023-01-03 10:32:11 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:11 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:11 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:11 --> URI Class Initialized
INFO - 2023-01-03 10:32:11 --> Router Class Initialized
INFO - 2023-01-03 10:32:11 --> Output Class Initialized
INFO - 2023-01-03 10:32:11 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:11 --> Input Class Initialized
INFO - 2023-01-03 10:32:11 --> Language Class Initialized
INFO - 2023-01-03 10:32:11 --> Loader Class Initialized
INFO - 2023-01-03 10:32:11 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:11 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:11 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:11 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:11 --> Total execution time: 0.1417
INFO - 2023-01-03 10:32:12 --> Config Class Initialized
INFO - 2023-01-03 10:32:12 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:12 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:12 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:12 --> URI Class Initialized
INFO - 2023-01-03 10:32:12 --> Router Class Initialized
INFO - 2023-01-03 10:32:12 --> Output Class Initialized
INFO - 2023-01-03 10:32:12 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:12 --> Input Class Initialized
INFO - 2023-01-03 10:32:12 --> Language Class Initialized
INFO - 2023-01-03 10:32:12 --> Loader Class Initialized
INFO - 2023-01-03 10:32:12 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:12 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:12 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:12 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:12 --> Total execution time: 0.1437
INFO - 2023-01-03 10:32:13 --> Config Class Initialized
INFO - 2023-01-03 10:32:13 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:13 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:13 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:13 --> URI Class Initialized
INFO - 2023-01-03 10:32:13 --> Router Class Initialized
INFO - 2023-01-03 10:32:13 --> Output Class Initialized
INFO - 2023-01-03 10:32:13 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:13 --> Input Class Initialized
INFO - 2023-01-03 10:32:13 --> Language Class Initialized
INFO - 2023-01-03 10:32:13 --> Loader Class Initialized
INFO - 2023-01-03 10:32:13 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:13 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:13 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:13 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:13 --> Total execution time: 0.1454
INFO - 2023-01-03 10:32:14 --> Config Class Initialized
INFO - 2023-01-03 10:32:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:14 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:14 --> URI Class Initialized
INFO - 2023-01-03 10:32:14 --> Router Class Initialized
INFO - 2023-01-03 10:32:14 --> Output Class Initialized
INFO - 2023-01-03 10:32:14 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:14 --> Input Class Initialized
INFO - 2023-01-03 10:32:14 --> Language Class Initialized
INFO - 2023-01-03 10:32:14 --> Loader Class Initialized
INFO - 2023-01-03 10:32:14 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:14 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:14 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:14 --> Total execution time: 0.1330
INFO - 2023-01-03 10:32:15 --> Config Class Initialized
INFO - 2023-01-03 10:32:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:15 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:15 --> URI Class Initialized
INFO - 2023-01-03 10:32:15 --> Router Class Initialized
INFO - 2023-01-03 10:32:15 --> Output Class Initialized
INFO - 2023-01-03 10:32:15 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:15 --> Input Class Initialized
INFO - 2023-01-03 10:32:15 --> Language Class Initialized
INFO - 2023-01-03 10:32:15 --> Loader Class Initialized
INFO - 2023-01-03 10:32:15 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:15 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:15 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:15 --> Total execution time: 0.1343
INFO - 2023-01-03 10:32:16 --> Config Class Initialized
INFO - 2023-01-03 10:32:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:16 --> URI Class Initialized
INFO - 2023-01-03 10:32:16 --> Router Class Initialized
INFO - 2023-01-03 10:32:16 --> Output Class Initialized
INFO - 2023-01-03 10:32:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:16 --> Input Class Initialized
INFO - 2023-01-03 10:32:16 --> Language Class Initialized
INFO - 2023-01-03 10:32:16 --> Loader Class Initialized
INFO - 2023-01-03 10:32:16 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:16 --> Total execution time: 0.1058
INFO - 2023-01-03 10:32:16 --> Config Class Initialized
INFO - 2023-01-03 10:32:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:16 --> URI Class Initialized
INFO - 2023-01-03 10:32:16 --> Router Class Initialized
INFO - 2023-01-03 10:32:16 --> Output Class Initialized
INFO - 2023-01-03 10:32:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:16 --> Input Class Initialized
INFO - 2023-01-03 10:32:16 --> Language Class Initialized
INFO - 2023-01-03 10:32:17 --> Loader Class Initialized
INFO - 2023-01-03 10:32:17 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:17 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:17 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:17 --> Total execution time: 0.1287
INFO - 2023-01-03 10:32:30 --> Config Class Initialized
INFO - 2023-01-03 10:32:30 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:30 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:30 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:30 --> URI Class Initialized
INFO - 2023-01-03 10:32:30 --> Router Class Initialized
INFO - 2023-01-03 10:32:30 --> Output Class Initialized
INFO - 2023-01-03 10:32:30 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:30 --> Input Class Initialized
INFO - 2023-01-03 10:32:30 --> Language Class Initialized
INFO - 2023-01-03 10:32:30 --> Loader Class Initialized
INFO - 2023-01-03 10:32:30 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:30 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:30 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:30 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:30 --> Total execution time: 0.1691
INFO - 2023-01-03 10:32:31 --> Config Class Initialized
INFO - 2023-01-03 10:32:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:31 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:31 --> URI Class Initialized
INFO - 2023-01-03 10:32:31 --> Router Class Initialized
INFO - 2023-01-03 10:32:31 --> Output Class Initialized
INFO - 2023-01-03 10:32:31 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:31 --> Input Class Initialized
INFO - 2023-01-03 10:32:31 --> Language Class Initialized
INFO - 2023-01-03 10:32:31 --> Loader Class Initialized
INFO - 2023-01-03 10:32:31 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:31 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:31 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:31 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:31 --> Total execution time: 0.1609
INFO - 2023-01-03 10:32:33 --> Config Class Initialized
INFO - 2023-01-03 10:32:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:33 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:33 --> URI Class Initialized
INFO - 2023-01-03 10:32:33 --> Router Class Initialized
INFO - 2023-01-03 10:32:33 --> Output Class Initialized
INFO - 2023-01-03 10:32:33 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:33 --> Input Class Initialized
INFO - 2023-01-03 10:32:33 --> Language Class Initialized
INFO - 2023-01-03 10:32:33 --> Loader Class Initialized
INFO - 2023-01-03 10:32:33 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:33 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:33 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:33 --> Total execution time: 0.1494
INFO - 2023-01-03 10:32:33 --> Config Class Initialized
INFO - 2023-01-03 10:32:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:32:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:32:33 --> Utf8 Class Initialized
INFO - 2023-01-03 10:32:33 --> URI Class Initialized
INFO - 2023-01-03 10:32:33 --> Router Class Initialized
INFO - 2023-01-03 10:32:33 --> Output Class Initialized
INFO - 2023-01-03 10:32:33 --> Security Class Initialized
DEBUG - 2023-01-03 10:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:32:33 --> Input Class Initialized
INFO - 2023-01-03 10:32:33 --> Language Class Initialized
INFO - 2023-01-03 10:32:33 --> Loader Class Initialized
INFO - 2023-01-03 10:32:33 --> Controller Class Initialized
DEBUG - 2023-01-03 10:32:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:32:33 --> Database Driver Class Initialized
INFO - 2023-01-03 10:32:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:32:33 --> Final output sent to browser
DEBUG - 2023-01-03 10:32:33 --> Total execution time: 0.1621
INFO - 2023-01-03 10:33:15 --> Config Class Initialized
INFO - 2023-01-03 10:33:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:33:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:33:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:33:16 --> URI Class Initialized
INFO - 2023-01-03 10:33:16 --> Router Class Initialized
INFO - 2023-01-03 10:33:16 --> Output Class Initialized
INFO - 2023-01-03 10:33:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:33:16 --> Input Class Initialized
INFO - 2023-01-03 10:33:16 --> Language Class Initialized
INFO - 2023-01-03 10:33:16 --> Loader Class Initialized
INFO - 2023-01-03 10:33:16 --> Controller Class Initialized
DEBUG - 2023-01-03 10:33:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:33:16 --> Database Driver Class Initialized
INFO - 2023-01-03 10:33:16 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:33:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:33:16 --> Total execution time: 0.3990
INFO - 2023-01-03 10:33:16 --> Config Class Initialized
INFO - 2023-01-03 10:33:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:33:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:33:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:33:16 --> URI Class Initialized
INFO - 2023-01-03 10:33:16 --> Router Class Initialized
INFO - 2023-01-03 10:33:16 --> Output Class Initialized
INFO - 2023-01-03 10:33:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:33:16 --> Input Class Initialized
INFO - 2023-01-03 10:33:16 --> Language Class Initialized
INFO - 2023-01-03 10:33:16 --> Loader Class Initialized
INFO - 2023-01-03 10:33:16 --> Controller Class Initialized
DEBUG - 2023-01-03 10:33:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:33:16 --> Database Driver Class Initialized
INFO - 2023-01-03 10:33:16 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:33:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:33:16 --> Total execution time: 0.3598
INFO - 2023-01-03 10:34:36 --> Config Class Initialized
INFO - 2023-01-03 10:34:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:36 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:36 --> URI Class Initialized
INFO - 2023-01-03 10:34:36 --> Router Class Initialized
INFO - 2023-01-03 10:34:36 --> Output Class Initialized
INFO - 2023-01-03 10:34:36 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:36 --> Input Class Initialized
INFO - 2023-01-03 10:34:36 --> Language Class Initialized
INFO - 2023-01-03 10:34:36 --> Loader Class Initialized
INFO - 2023-01-03 10:34:36 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:36 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:36 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:36 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:36 --> Total execution time: 0.1817
INFO - 2023-01-03 10:34:36 --> Config Class Initialized
INFO - 2023-01-03 10:34:36 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:36 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:36 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:36 --> URI Class Initialized
INFO - 2023-01-03 10:34:36 --> Router Class Initialized
INFO - 2023-01-03 10:34:36 --> Output Class Initialized
INFO - 2023-01-03 10:34:36 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:36 --> Input Class Initialized
INFO - 2023-01-03 10:34:36 --> Language Class Initialized
INFO - 2023-01-03 10:34:36 --> Loader Class Initialized
INFO - 2023-01-03 10:34:36 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:36 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:36 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:36 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:36 --> Total execution time: 0.1596
INFO - 2023-01-03 10:34:47 --> Config Class Initialized
INFO - 2023-01-03 10:34:47 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:47 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:47 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:47 --> URI Class Initialized
INFO - 2023-01-03 10:34:47 --> Router Class Initialized
INFO - 2023-01-03 10:34:47 --> Output Class Initialized
INFO - 2023-01-03 10:34:47 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:47 --> Input Class Initialized
INFO - 2023-01-03 10:34:47 --> Language Class Initialized
INFO - 2023-01-03 10:34:47 --> Loader Class Initialized
INFO - 2023-01-03 10:34:47 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:47 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:47 --> Total execution time: 0.1541
INFO - 2023-01-03 10:34:47 --> Config Class Initialized
INFO - 2023-01-03 10:34:47 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:47 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:47 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:47 --> URI Class Initialized
INFO - 2023-01-03 10:34:47 --> Router Class Initialized
INFO - 2023-01-03 10:34:47 --> Output Class Initialized
INFO - 2023-01-03 10:34:47 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:47 --> Input Class Initialized
INFO - 2023-01-03 10:34:47 --> Language Class Initialized
INFO - 2023-01-03 10:34:47 --> Loader Class Initialized
INFO - 2023-01-03 10:34:47 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:47 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:47 --> Model "Login_model" initialized
INFO - 2023-01-03 10:34:47 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:47 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:47 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:47 --> Total execution time: 0.2283
INFO - 2023-01-03 10:34:48 --> Config Class Initialized
INFO - 2023-01-03 10:34:48 --> Config Class Initialized
INFO - 2023-01-03 10:34:48 --> Hooks Class Initialized
INFO - 2023-01-03 10:34:48 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 10:34:48 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:48 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:48 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:48 --> URI Class Initialized
INFO - 2023-01-03 10:34:48 --> URI Class Initialized
INFO - 2023-01-03 10:34:48 --> Router Class Initialized
INFO - 2023-01-03 10:34:48 --> Router Class Initialized
INFO - 2023-01-03 10:34:48 --> Output Class Initialized
INFO - 2023-01-03 10:34:48 --> Output Class Initialized
INFO - 2023-01-03 10:34:48 --> Security Class Initialized
INFO - 2023-01-03 10:34:48 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:48 --> Input Class Initialized
INFO - 2023-01-03 10:34:48 --> Input Class Initialized
INFO - 2023-01-03 10:34:48 --> Language Class Initialized
INFO - 2023-01-03 10:34:48 --> Language Class Initialized
INFO - 2023-01-03 10:34:48 --> Loader Class Initialized
INFO - 2023-01-03 10:34:48 --> Loader Class Initialized
INFO - 2023-01-03 10:34:48 --> Controller Class Initialized
INFO - 2023-01-03 10:34:48 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-03 10:34:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:48 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:48 --> Total execution time: 0.2916
INFO - 2023-01-03 10:34:48 --> Config Class Initialized
INFO - 2023-01-03 10:34:48 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:48 --> Hooks Class Initialized
INFO - 2023-01-03 10:34:48 --> Model "Cluster_model" initialized
DEBUG - 2023-01-03 10:34:48 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:48 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:48 --> Final output sent to browser
INFO - 2023-01-03 10:34:48 --> URI Class Initialized
DEBUG - 2023-01-03 10:34:49 --> Total execution time: 0.4035
INFO - 2023-01-03 10:34:49 --> Router Class Initialized
INFO - 2023-01-03 10:34:49 --> Output Class Initialized
INFO - 2023-01-03 10:34:49 --> Config Class Initialized
INFO - 2023-01-03 10:34:49 --> Security Class Initialized
INFO - 2023-01-03 10:34:49 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:49 --> Input Class Initialized
DEBUG - 2023-01-03 10:34:49 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:49 --> Language Class Initialized
INFO - 2023-01-03 10:34:49 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:49 --> URI Class Initialized
INFO - 2023-01-03 10:34:49 --> Router Class Initialized
INFO - 2023-01-03 10:34:49 --> Output Class Initialized
INFO - 2023-01-03 10:34:49 --> Security Class Initialized
INFO - 2023-01-03 10:34:49 --> Loader Class Initialized
DEBUG - 2023-01-03 10:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:49 --> Controller Class Initialized
INFO - 2023-01-03 10:34:49 --> Input Class Initialized
DEBUG - 2023-01-03 10:34:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:49 --> Language Class Initialized
INFO - 2023-01-03 10:34:49 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:49 --> Loader Class Initialized
INFO - 2023-01-03 10:34:49 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:49 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:49 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:49 --> Total execution time: 0.3685
INFO - 2023-01-03 10:34:49 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:49 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:49 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:49 --> Total execution time: 0.3100
INFO - 2023-01-03 10:34:49 --> Config Class Initialized
INFO - 2023-01-03 10:34:49 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:49 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:49 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:49 --> URI Class Initialized
INFO - 2023-01-03 10:34:49 --> Router Class Initialized
INFO - 2023-01-03 10:34:49 --> Output Class Initialized
INFO - 2023-01-03 10:34:49 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:49 --> Input Class Initialized
INFO - 2023-01-03 10:34:49 --> Language Class Initialized
INFO - 2023-01-03 10:34:49 --> Loader Class Initialized
INFO - 2023-01-03 10:34:49 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:49 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:49 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:49 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:49 --> Total execution time: 0.2032
INFO - 2023-01-03 10:34:50 --> Config Class Initialized
INFO - 2023-01-03 10:34:50 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:50 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:50 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:50 --> URI Class Initialized
INFO - 2023-01-03 10:34:50 --> Router Class Initialized
INFO - 2023-01-03 10:34:50 --> Output Class Initialized
INFO - 2023-01-03 10:34:50 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:50 --> Input Class Initialized
INFO - 2023-01-03 10:34:50 --> Language Class Initialized
INFO - 2023-01-03 10:34:50 --> Loader Class Initialized
INFO - 2023-01-03 10:34:50 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:50 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:50 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:50 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:50 --> Total execution time: 0.2132
INFO - 2023-01-03 10:34:51 --> Config Class Initialized
INFO - 2023-01-03 10:34:51 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:51 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:51 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:51 --> URI Class Initialized
INFO - 2023-01-03 10:34:51 --> Router Class Initialized
INFO - 2023-01-03 10:34:51 --> Output Class Initialized
INFO - 2023-01-03 10:34:51 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:51 --> Input Class Initialized
INFO - 2023-01-03 10:34:51 --> Language Class Initialized
INFO - 2023-01-03 10:34:51 --> Loader Class Initialized
INFO - 2023-01-03 10:34:51 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:51 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:51 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:51 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:51 --> Total execution time: 0.2181
INFO - 2023-01-03 10:34:52 --> Config Class Initialized
INFO - 2023-01-03 10:34:52 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:52 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:52 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:52 --> URI Class Initialized
INFO - 2023-01-03 10:34:52 --> Router Class Initialized
INFO - 2023-01-03 10:34:52 --> Output Class Initialized
INFO - 2023-01-03 10:34:52 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:52 --> Input Class Initialized
INFO - 2023-01-03 10:34:52 --> Language Class Initialized
INFO - 2023-01-03 10:34:52 --> Loader Class Initialized
INFO - 2023-01-03 10:34:52 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:52 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:52 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:52 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:52 --> Total execution time: 0.1983
INFO - 2023-01-03 10:34:53 --> Config Class Initialized
INFO - 2023-01-03 10:34:53 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:53 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:53 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:53 --> URI Class Initialized
INFO - 2023-01-03 10:34:53 --> Router Class Initialized
INFO - 2023-01-03 10:34:53 --> Output Class Initialized
INFO - 2023-01-03 10:34:53 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:53 --> Input Class Initialized
INFO - 2023-01-03 10:34:53 --> Language Class Initialized
INFO - 2023-01-03 10:34:53 --> Loader Class Initialized
INFO - 2023-01-03 10:34:53 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:53 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:53 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:53 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:53 --> Total execution time: 0.3169
INFO - 2023-01-03 10:34:54 --> Config Class Initialized
INFO - 2023-01-03 10:34:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:54 --> URI Class Initialized
INFO - 2023-01-03 10:34:54 --> Router Class Initialized
INFO - 2023-01-03 10:34:54 --> Output Class Initialized
INFO - 2023-01-03 10:34:54 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:54 --> Input Class Initialized
INFO - 2023-01-03 10:34:54 --> Language Class Initialized
INFO - 2023-01-03 10:34:54 --> Loader Class Initialized
INFO - 2023-01-03 10:34:54 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:54 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:54 --> Total execution time: 0.2473
INFO - 2023-01-03 10:34:54 --> Config Class Initialized
INFO - 2023-01-03 10:34:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:34:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:34:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:34:54 --> URI Class Initialized
INFO - 2023-01-03 10:34:54 --> Router Class Initialized
INFO - 2023-01-03 10:34:54 --> Output Class Initialized
INFO - 2023-01-03 10:34:54 --> Security Class Initialized
DEBUG - 2023-01-03 10:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:34:54 --> Input Class Initialized
INFO - 2023-01-03 10:34:54 --> Language Class Initialized
INFO - 2023-01-03 10:34:55 --> Loader Class Initialized
INFO - 2023-01-03 10:34:55 --> Controller Class Initialized
DEBUG - 2023-01-03 10:34:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:34:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:34:55 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:34:55 --> Final output sent to browser
DEBUG - 2023-01-03 10:34:55 --> Total execution time: 0.2355
INFO - 2023-01-03 10:35:49 --> Config Class Initialized
INFO - 2023-01-03 10:35:49 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:35:49 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:35:49 --> Utf8 Class Initialized
INFO - 2023-01-03 10:35:49 --> URI Class Initialized
INFO - 2023-01-03 10:35:50 --> Router Class Initialized
INFO - 2023-01-03 10:35:50 --> Output Class Initialized
INFO - 2023-01-03 10:35:50 --> Security Class Initialized
DEBUG - 2023-01-03 10:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:35:50 --> Input Class Initialized
INFO - 2023-01-03 10:35:50 --> Language Class Initialized
INFO - 2023-01-03 10:35:50 --> Loader Class Initialized
INFO - 2023-01-03 10:35:50 --> Controller Class Initialized
DEBUG - 2023-01-03 10:35:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:35:50 --> Database Driver Class Initialized
INFO - 2023-01-03 10:35:50 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:35:50 --> Final output sent to browser
DEBUG - 2023-01-03 10:35:50 --> Total execution time: 1.0430
INFO - 2023-01-03 10:35:51 --> Config Class Initialized
INFO - 2023-01-03 10:35:51 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:35:51 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:35:51 --> Utf8 Class Initialized
INFO - 2023-01-03 10:35:51 --> URI Class Initialized
INFO - 2023-01-03 10:35:51 --> Router Class Initialized
INFO - 2023-01-03 10:35:51 --> Output Class Initialized
INFO - 2023-01-03 10:35:51 --> Security Class Initialized
DEBUG - 2023-01-03 10:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:35:51 --> Input Class Initialized
INFO - 2023-01-03 10:35:51 --> Language Class Initialized
INFO - 2023-01-03 10:35:51 --> Loader Class Initialized
INFO - 2023-01-03 10:35:51 --> Controller Class Initialized
DEBUG - 2023-01-03 10:35:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:35:52 --> Database Driver Class Initialized
INFO - 2023-01-03 10:35:52 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:35:52 --> Final output sent to browser
DEBUG - 2023-01-03 10:35:52 --> Total execution time: 1.1299
INFO - 2023-01-03 10:36:03 --> Config Class Initialized
INFO - 2023-01-03 10:36:03 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:03 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:03 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:03 --> URI Class Initialized
INFO - 2023-01-03 10:36:03 --> Router Class Initialized
INFO - 2023-01-03 10:36:03 --> Output Class Initialized
INFO - 2023-01-03 10:36:03 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:03 --> Input Class Initialized
INFO - 2023-01-03 10:36:03 --> Language Class Initialized
INFO - 2023-01-03 10:36:04 --> Loader Class Initialized
INFO - 2023-01-03 10:36:04 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:04 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:04 --> Total execution time: 0.6629
INFO - 2023-01-03 10:36:04 --> Config Class Initialized
INFO - 2023-01-03 10:36:04 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:04 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:04 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:04 --> URI Class Initialized
INFO - 2023-01-03 10:36:04 --> Router Class Initialized
INFO - 2023-01-03 10:36:04 --> Output Class Initialized
INFO - 2023-01-03 10:36:04 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:04 --> Input Class Initialized
INFO - 2023-01-03 10:36:04 --> Language Class Initialized
INFO - 2023-01-03 10:36:04 --> Loader Class Initialized
INFO - 2023-01-03 10:36:04 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:04 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:04 --> Model "Login_model" initialized
INFO - 2023-01-03 10:36:04 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:04 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:04 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:04 --> Total execution time: 0.4740
INFO - 2023-01-03 10:36:05 --> Config Class Initialized
INFO - 2023-01-03 10:36:05 --> Hooks Class Initialized
INFO - 2023-01-03 10:36:05 --> Config Class Initialized
INFO - 2023-01-03 10:36:05 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:06 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:06 --> Utf8 Class Initialized
DEBUG - 2023-01-03 10:36:06 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:06 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:06 --> URI Class Initialized
INFO - 2023-01-03 10:36:06 --> URI Class Initialized
INFO - 2023-01-03 10:36:06 --> Router Class Initialized
INFO - 2023-01-03 10:36:06 --> Router Class Initialized
INFO - 2023-01-03 10:36:06 --> Output Class Initialized
INFO - 2023-01-03 10:36:06 --> Output Class Initialized
INFO - 2023-01-03 10:36:06 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:06 --> Security Class Initialized
INFO - 2023-01-03 10:36:06 --> Input Class Initialized
DEBUG - 2023-01-03 10:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:06 --> Language Class Initialized
INFO - 2023-01-03 10:36:06 --> Input Class Initialized
INFO - 2023-01-03 10:36:06 --> Language Class Initialized
INFO - 2023-01-03 10:36:06 --> Loader Class Initialized
INFO - 2023-01-03 10:36:06 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:06 --> Loader Class Initialized
INFO - 2023-01-03 10:36:06 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:06 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:06 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:06 --> Total execution time: 0.6826
INFO - 2023-01-03 10:36:06 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:06 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:06 --> Total execution time: 0.8680
INFO - 2023-01-03 10:36:06 --> Config Class Initialized
INFO - 2023-01-03 10:36:06 --> Hooks Class Initialized
INFO - 2023-01-03 10:36:06 --> Config Class Initialized
INFO - 2023-01-03 10:36:06 --> Hooks Class Initialized
INFO - 2023-01-03 10:36:06 --> Config Class Initialized
DEBUG - 2023-01-03 10:36:07 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:07 --> Hooks Class Initialized
INFO - 2023-01-03 10:36:07 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:07 --> URI Class Initialized
DEBUG - 2023-01-03 10:36:07 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:07 --> Utf8 Class Initialized
DEBUG - 2023-01-03 10:36:07 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:07 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:07 --> URI Class Initialized
INFO - 2023-01-03 10:36:07 --> Router Class Initialized
INFO - 2023-01-03 10:36:07 --> URI Class Initialized
INFO - 2023-01-03 10:36:07 --> Router Class Initialized
INFO - 2023-01-03 10:36:07 --> Output Class Initialized
INFO - 2023-01-03 10:36:07 --> Router Class Initialized
INFO - 2023-01-03 10:36:07 --> Security Class Initialized
INFO - 2023-01-03 10:36:07 --> Output Class Initialized
INFO - 2023-01-03 10:36:07 --> Output Class Initialized
DEBUG - 2023-01-03 10:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:07 --> Security Class Initialized
INFO - 2023-01-03 10:36:07 --> Input Class Initialized
INFO - 2023-01-03 10:36:07 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:07 --> Language Class Initialized
INFO - 2023-01-03 10:36:07 --> Input Class Initialized
DEBUG - 2023-01-03 10:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:07 --> Input Class Initialized
INFO - 2023-01-03 10:36:07 --> Language Class Initialized
INFO - 2023-01-03 10:36:07 --> Language Class Initialized
INFO - 2023-01-03 10:36:07 --> Loader Class Initialized
INFO - 2023-01-03 10:36:07 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:07 --> Loader Class Initialized
INFO - 2023-01-03 10:36:07 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:07 --> Loader Class Initialized
INFO - 2023-01-03 10:36:07 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:08 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:08 --> Controller Class Initialized
INFO - 2023-01-03 10:36:08 --> Database Driver Class Initialized
DEBUG - 2023-01-03 10:36:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:08 --> Final output sent to browser
INFO - 2023-01-03 10:36:08 --> Model "Cluster_model" initialized
DEBUG - 2023-01-03 10:36:08 --> Total execution time: 1.2767
INFO - 2023-01-03 10:36:08 --> Config Class Initialized
INFO - 2023-01-03 10:36:08 --> Final output sent to browser
INFO - 2023-01-03 10:36:08 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:08 --> Total execution time: 1.3206
INFO - 2023-01-03 10:36:08 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:08 --> Model "Cluster_model" initialized
DEBUG - 2023-01-03 10:36:08 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:08 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:08 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:08 --> Total execution time: 1.4888
INFO - 2023-01-03 10:36:08 --> URI Class Initialized
INFO - 2023-01-03 10:36:08 --> Router Class Initialized
INFO - 2023-01-03 10:36:08 --> Output Class Initialized
INFO - 2023-01-03 10:36:08 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:08 --> Input Class Initialized
INFO - 2023-01-03 10:36:08 --> Language Class Initialized
INFO - 2023-01-03 10:36:08 --> Config Class Initialized
INFO - 2023-01-03 10:36:08 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:08 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:08 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:08 --> Loader Class Initialized
INFO - 2023-01-03 10:36:08 --> URI Class Initialized
INFO - 2023-01-03 10:36:08 --> Controller Class Initialized
INFO - 2023-01-03 10:36:09 --> Router Class Initialized
DEBUG - 2023-01-03 10:36:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:09 --> Output Class Initialized
INFO - 2023-01-03 10:36:09 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:09 --> Security Class Initialized
INFO - 2023-01-03 10:36:09 --> Model "Cluster_model" initialized
DEBUG - 2023-01-03 10:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:09 --> Final output sent to browser
INFO - 2023-01-03 10:36:09 --> Input Class Initialized
DEBUG - 2023-01-03 10:36:09 --> Total execution time: 1.1481
INFO - 2023-01-03 10:36:09 --> Language Class Initialized
INFO - 2023-01-03 10:36:09 --> Loader Class Initialized
INFO - 2023-01-03 10:36:09 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:09 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:09 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:09 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:09 --> Total execution time: 0.6936
INFO - 2023-01-03 10:36:09 --> Config Class Initialized
INFO - 2023-01-03 10:36:09 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:09 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:09 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:09 --> URI Class Initialized
INFO - 2023-01-03 10:36:09 --> Router Class Initialized
INFO - 2023-01-03 10:36:09 --> Output Class Initialized
INFO - 2023-01-03 10:36:09 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:09 --> Input Class Initialized
INFO - 2023-01-03 10:36:09 --> Language Class Initialized
INFO - 2023-01-03 10:36:10 --> Loader Class Initialized
INFO - 2023-01-03 10:36:10 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:10 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:10 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:10 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:10 --> Total execution time: 0.4043
INFO - 2023-01-03 10:36:10 --> Config Class Initialized
INFO - 2023-01-03 10:36:10 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:10 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:10 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:10 --> URI Class Initialized
INFO - 2023-01-03 10:36:10 --> Router Class Initialized
INFO - 2023-01-03 10:36:10 --> Output Class Initialized
INFO - 2023-01-03 10:36:10 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:10 --> Input Class Initialized
INFO - 2023-01-03 10:36:10 --> Language Class Initialized
INFO - 2023-01-03 10:36:10 --> Loader Class Initialized
INFO - 2023-01-03 10:36:10 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:11 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:11 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:11 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:11 --> Total execution time: 0.3280
INFO - 2023-01-03 10:36:11 --> Config Class Initialized
INFO - 2023-01-03 10:36:11 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:11 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:11 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:11 --> URI Class Initialized
INFO - 2023-01-03 10:36:12 --> Router Class Initialized
INFO - 2023-01-03 10:36:12 --> Output Class Initialized
INFO - 2023-01-03 10:36:12 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:12 --> Input Class Initialized
INFO - 2023-01-03 10:36:12 --> Language Class Initialized
INFO - 2023-01-03 10:36:12 --> Loader Class Initialized
INFO - 2023-01-03 10:36:12 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:12 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:12 --> Total execution time: 0.3395
INFO - 2023-01-03 10:36:12 --> Config Class Initialized
INFO - 2023-01-03 10:36:12 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:12 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:12 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:12 --> URI Class Initialized
INFO - 2023-01-03 10:36:12 --> Router Class Initialized
INFO - 2023-01-03 10:36:12 --> Output Class Initialized
INFO - 2023-01-03 10:36:12 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:12 --> Input Class Initialized
INFO - 2023-01-03 10:36:12 --> Language Class Initialized
INFO - 2023-01-03 10:36:12 --> Loader Class Initialized
INFO - 2023-01-03 10:36:12 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:12 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:12 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:12 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:12 --> Total execution time: 0.4086
INFO - 2023-01-03 10:36:13 --> Config Class Initialized
INFO - 2023-01-03 10:36:13 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:13 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:13 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:13 --> URI Class Initialized
INFO - 2023-01-03 10:36:13 --> Router Class Initialized
INFO - 2023-01-03 10:36:13 --> Output Class Initialized
INFO - 2023-01-03 10:36:13 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:13 --> Input Class Initialized
INFO - 2023-01-03 10:36:13 --> Language Class Initialized
INFO - 2023-01-03 10:36:13 --> Loader Class Initialized
INFO - 2023-01-03 10:36:13 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:14 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:14 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:14 --> Total execution time: 0.5309
INFO - 2023-01-03 10:36:14 --> Config Class Initialized
INFO - 2023-01-03 10:36:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:14 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:14 --> URI Class Initialized
INFO - 2023-01-03 10:36:14 --> Router Class Initialized
INFO - 2023-01-03 10:36:14 --> Output Class Initialized
INFO - 2023-01-03 10:36:14 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:14 --> Input Class Initialized
INFO - 2023-01-03 10:36:14 --> Language Class Initialized
INFO - 2023-01-03 10:36:14 --> Loader Class Initialized
INFO - 2023-01-03 10:36:14 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:14 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:14 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:14 --> Total execution time: 0.4430
INFO - 2023-01-03 10:36:25 --> Config Class Initialized
INFO - 2023-01-03 10:36:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:25 --> URI Class Initialized
INFO - 2023-01-03 10:36:25 --> Router Class Initialized
INFO - 2023-01-03 10:36:25 --> Output Class Initialized
INFO - 2023-01-03 10:36:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:25 --> Input Class Initialized
INFO - 2023-01-03 10:36:25 --> Language Class Initialized
INFO - 2023-01-03 10:36:25 --> Loader Class Initialized
INFO - 2023-01-03 10:36:25 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:25 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:25 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:25 --> Total execution time: 0.3438
INFO - 2023-01-03 10:36:25 --> Config Class Initialized
INFO - 2023-01-03 10:36:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:25 --> URI Class Initialized
INFO - 2023-01-03 10:36:25 --> Router Class Initialized
INFO - 2023-01-03 10:36:25 --> Output Class Initialized
INFO - 2023-01-03 10:36:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:25 --> Input Class Initialized
INFO - 2023-01-03 10:36:25 --> Language Class Initialized
INFO - 2023-01-03 10:36:25 --> Loader Class Initialized
INFO - 2023-01-03 10:36:25 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:25 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:25 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:25 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:25 --> Total execution time: 0.3193
INFO - 2023-01-03 10:36:34 --> Config Class Initialized
INFO - 2023-01-03 10:36:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:34 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:34 --> URI Class Initialized
INFO - 2023-01-03 10:36:34 --> Router Class Initialized
INFO - 2023-01-03 10:36:34 --> Output Class Initialized
INFO - 2023-01-03 10:36:34 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:34 --> Input Class Initialized
INFO - 2023-01-03 10:36:34 --> Language Class Initialized
INFO - 2023-01-03 10:36:34 --> Loader Class Initialized
INFO - 2023-01-03 10:36:34 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:34 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:35 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:35 --> Model "Login_model" initialized
INFO - 2023-01-03 10:36:35 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:35 --> Total execution time: 0.3051
INFO - 2023-01-03 10:36:35 --> Config Class Initialized
INFO - 2023-01-03 10:36:35 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:36:35 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:36:35 --> Utf8 Class Initialized
INFO - 2023-01-03 10:36:35 --> URI Class Initialized
INFO - 2023-01-03 10:36:35 --> Router Class Initialized
INFO - 2023-01-03 10:36:35 --> Output Class Initialized
INFO - 2023-01-03 10:36:35 --> Security Class Initialized
DEBUG - 2023-01-03 10:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:36:35 --> Input Class Initialized
INFO - 2023-01-03 10:36:35 --> Language Class Initialized
INFO - 2023-01-03 10:36:35 --> Loader Class Initialized
INFO - 2023-01-03 10:36:35 --> Controller Class Initialized
DEBUG - 2023-01-03 10:36:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:36:35 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:35 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:36:35 --> Database Driver Class Initialized
INFO - 2023-01-03 10:36:35 --> Model "Login_model" initialized
INFO - 2023-01-03 10:36:35 --> Final output sent to browser
DEBUG - 2023-01-03 10:36:35 --> Total execution time: 0.3222
INFO - 2023-01-03 10:39:38 --> Config Class Initialized
INFO - 2023-01-03 10:39:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:39:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:39:38 --> Utf8 Class Initialized
INFO - 2023-01-03 10:39:38 --> URI Class Initialized
INFO - 2023-01-03 10:39:38 --> Router Class Initialized
INFO - 2023-01-03 10:39:38 --> Output Class Initialized
INFO - 2023-01-03 10:39:38 --> Security Class Initialized
DEBUG - 2023-01-03 10:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:39:38 --> Input Class Initialized
INFO - 2023-01-03 10:39:38 --> Language Class Initialized
INFO - 2023-01-03 10:39:38 --> Loader Class Initialized
INFO - 2023-01-03 10:39:38 --> Controller Class Initialized
DEBUG - 2023-01-03 10:39:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:39:38 --> Final output sent to browser
DEBUG - 2023-01-03 10:39:38 --> Total execution time: 0.4913
INFO - 2023-01-03 10:39:38 --> Config Class Initialized
INFO - 2023-01-03 10:39:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:39:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:39:38 --> Utf8 Class Initialized
INFO - 2023-01-03 10:39:38 --> URI Class Initialized
INFO - 2023-01-03 10:39:38 --> Router Class Initialized
INFO - 2023-01-03 10:39:38 --> Output Class Initialized
INFO - 2023-01-03 10:39:38 --> Security Class Initialized
DEBUG - 2023-01-03 10:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:39:38 --> Input Class Initialized
INFO - 2023-01-03 10:39:38 --> Language Class Initialized
INFO - 2023-01-03 10:39:38 --> Loader Class Initialized
INFO - 2023-01-03 10:39:38 --> Controller Class Initialized
DEBUG - 2023-01-03 10:39:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:39:39 --> Database Driver Class Initialized
INFO - 2023-01-03 10:39:39 --> Model "Login_model" initialized
INFO - 2023-01-03 10:39:39 --> Database Driver Class Initialized
INFO - 2023-01-03 10:39:39 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:39:39 --> Final output sent to browser
DEBUG - 2023-01-03 10:39:39 --> Total execution time: 0.4491
INFO - 2023-01-03 10:39:39 --> Config Class Initialized
INFO - 2023-01-03 10:39:39 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:39:39 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:39:39 --> Utf8 Class Initialized
INFO - 2023-01-03 10:39:39 --> URI Class Initialized
INFO - 2023-01-03 10:39:39 --> Router Class Initialized
INFO - 2023-01-03 10:39:39 --> Output Class Initialized
INFO - 2023-01-03 10:39:39 --> Security Class Initialized
DEBUG - 2023-01-03 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:39:39 --> Input Class Initialized
INFO - 2023-01-03 10:39:39 --> Language Class Initialized
INFO - 2023-01-03 10:39:39 --> Loader Class Initialized
INFO - 2023-01-03 10:39:39 --> Controller Class Initialized
DEBUG - 2023-01-03 10:39:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:39:39 --> Final output sent to browser
DEBUG - 2023-01-03 10:39:39 --> Total execution time: 0.2977
INFO - 2023-01-03 10:39:39 --> Config Class Initialized
INFO - 2023-01-03 10:39:39 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:39:39 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:39:39 --> Utf8 Class Initialized
INFO - 2023-01-03 10:39:39 --> URI Class Initialized
INFO - 2023-01-03 10:39:39 --> Router Class Initialized
INFO - 2023-01-03 10:39:39 --> Output Class Initialized
INFO - 2023-01-03 10:39:39 --> Security Class Initialized
DEBUG - 2023-01-03 10:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:39:39 --> Input Class Initialized
INFO - 2023-01-03 10:39:39 --> Language Class Initialized
INFO - 2023-01-03 10:39:39 --> Loader Class Initialized
INFO - 2023-01-03 10:39:39 --> Controller Class Initialized
DEBUG - 2023-01-03 10:39:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:39:39 --> Database Driver Class Initialized
INFO - 2023-01-03 10:39:39 --> Model "Login_model" initialized
INFO - 2023-01-03 10:39:39 --> Database Driver Class Initialized
INFO - 2023-01-03 10:39:40 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:39:40 --> Final output sent to browser
DEBUG - 2023-01-03 10:39:40 --> Total execution time: 0.4389
INFO - 2023-01-03 10:39:41 --> Config Class Initialized
INFO - 2023-01-03 10:39:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:39:42 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:39:42 --> Utf8 Class Initialized
INFO - 2023-01-03 10:39:42 --> URI Class Initialized
INFO - 2023-01-03 10:39:42 --> Router Class Initialized
INFO - 2023-01-03 10:39:42 --> Output Class Initialized
INFO - 2023-01-03 10:39:42 --> Security Class Initialized
DEBUG - 2023-01-03 10:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:39:42 --> Input Class Initialized
INFO - 2023-01-03 10:39:42 --> Language Class Initialized
INFO - 2023-01-03 10:39:42 --> Loader Class Initialized
INFO - 2023-01-03 10:39:42 --> Controller Class Initialized
DEBUG - 2023-01-03 10:39:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:39:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:39:42 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:39:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:39:42 --> Model "Login_model" initialized
INFO - 2023-01-03 10:39:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:39:42 --> Total execution time: 0.6365
INFO - 2023-01-03 10:39:42 --> Config Class Initialized
INFO - 2023-01-03 10:39:42 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:39:42 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:39:42 --> Utf8 Class Initialized
INFO - 2023-01-03 10:39:42 --> URI Class Initialized
INFO - 2023-01-03 10:39:42 --> Router Class Initialized
INFO - 2023-01-03 10:39:42 --> Output Class Initialized
INFO - 2023-01-03 10:39:42 --> Security Class Initialized
DEBUG - 2023-01-03 10:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:39:42 --> Input Class Initialized
INFO - 2023-01-03 10:39:42 --> Language Class Initialized
INFO - 2023-01-03 10:39:43 --> Loader Class Initialized
INFO - 2023-01-03 10:39:43 --> Controller Class Initialized
DEBUG - 2023-01-03 10:39:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:39:43 --> Database Driver Class Initialized
INFO - 2023-01-03 10:39:43 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:39:43 --> Database Driver Class Initialized
INFO - 2023-01-03 10:39:43 --> Model "Login_model" initialized
INFO - 2023-01-03 10:39:43 --> Final output sent to browser
DEBUG - 2023-01-03 10:39:43 --> Total execution time: 0.7478
INFO - 2023-01-03 10:40:39 --> Config Class Initialized
INFO - 2023-01-03 10:40:39 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:40:39 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:40:39 --> Utf8 Class Initialized
INFO - 2023-01-03 10:40:39 --> URI Class Initialized
INFO - 2023-01-03 10:40:39 --> Router Class Initialized
INFO - 2023-01-03 10:40:39 --> Output Class Initialized
INFO - 2023-01-03 10:40:39 --> Security Class Initialized
DEBUG - 2023-01-03 10:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:40:39 --> Input Class Initialized
INFO - 2023-01-03 10:40:39 --> Language Class Initialized
INFO - 2023-01-03 10:40:40 --> Loader Class Initialized
INFO - 2023-01-03 10:40:40 --> Controller Class Initialized
DEBUG - 2023-01-03 10:40:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:40:40 --> Database Driver Class Initialized
INFO - 2023-01-03 10:40:40 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:40:40 --> Database Driver Class Initialized
INFO - 2023-01-03 10:40:40 --> Model "Login_model" initialized
INFO - 2023-01-03 10:40:40 --> Final output sent to browser
DEBUG - 2023-01-03 10:40:40 --> Total execution time: 1.5090
INFO - 2023-01-03 10:40:41 --> Config Class Initialized
INFO - 2023-01-03 10:40:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:40:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:40:41 --> Utf8 Class Initialized
INFO - 2023-01-03 10:40:41 --> URI Class Initialized
INFO - 2023-01-03 10:40:41 --> Router Class Initialized
INFO - 2023-01-03 10:40:41 --> Output Class Initialized
INFO - 2023-01-03 10:40:41 --> Security Class Initialized
DEBUG - 2023-01-03 10:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:40:41 --> Input Class Initialized
INFO - 2023-01-03 10:40:41 --> Language Class Initialized
INFO - 2023-01-03 10:40:41 --> Loader Class Initialized
INFO - 2023-01-03 10:40:41 --> Controller Class Initialized
DEBUG - 2023-01-03 10:40:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:40:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:40:42 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:40:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:40:42 --> Model "Login_model" initialized
INFO - 2023-01-03 10:40:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:40:42 --> Total execution time: 1.2476
INFO - 2023-01-03 10:41:31 --> Config Class Initialized
INFO - 2023-01-03 10:41:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:41:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:41:31 --> Utf8 Class Initialized
INFO - 2023-01-03 10:41:31 --> URI Class Initialized
INFO - 2023-01-03 10:41:31 --> Router Class Initialized
INFO - 2023-01-03 10:41:31 --> Output Class Initialized
INFO - 2023-01-03 10:41:31 --> Security Class Initialized
DEBUG - 2023-01-03 10:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:41:31 --> Input Class Initialized
INFO - 2023-01-03 10:41:31 --> Language Class Initialized
INFO - 2023-01-03 10:41:31 --> Loader Class Initialized
INFO - 2023-01-03 10:41:31 --> Controller Class Initialized
DEBUG - 2023-01-03 10:41:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:41:32 --> Database Driver Class Initialized
INFO - 2023-01-03 10:41:33 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:41:33 --> Database Driver Class Initialized
INFO - 2023-01-03 10:41:33 --> Model "Login_model" initialized
INFO - 2023-01-03 10:41:33 --> Final output sent to browser
DEBUG - 2023-01-03 10:41:33 --> Total execution time: 1.8709
INFO - 2023-01-03 10:41:33 --> Config Class Initialized
INFO - 2023-01-03 10:41:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:41:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:41:33 --> Utf8 Class Initialized
INFO - 2023-01-03 10:41:33 --> URI Class Initialized
INFO - 2023-01-03 10:41:33 --> Router Class Initialized
INFO - 2023-01-03 10:41:33 --> Output Class Initialized
INFO - 2023-01-03 10:41:33 --> Security Class Initialized
DEBUG - 2023-01-03 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:41:33 --> Input Class Initialized
INFO - 2023-01-03 10:41:33 --> Language Class Initialized
INFO - 2023-01-03 10:41:33 --> Loader Class Initialized
INFO - 2023-01-03 10:41:33 --> Controller Class Initialized
DEBUG - 2023-01-03 10:41:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:41:34 --> Database Driver Class Initialized
INFO - 2023-01-03 10:41:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:41:34 --> Database Driver Class Initialized
INFO - 2023-01-03 10:41:34 --> Model "Login_model" initialized
INFO - 2023-01-03 10:41:34 --> Final output sent to browser
DEBUG - 2023-01-03 10:41:34 --> Total execution time: 0.7081
INFO - 2023-01-03 10:42:22 --> Config Class Initialized
INFO - 2023-01-03 10:42:22 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:42:22 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:42:22 --> Utf8 Class Initialized
INFO - 2023-01-03 10:42:22 --> URI Class Initialized
INFO - 2023-01-03 10:42:22 --> Router Class Initialized
INFO - 2023-01-03 10:42:22 --> Output Class Initialized
INFO - 2023-01-03 10:42:22 --> Security Class Initialized
DEBUG - 2023-01-03 10:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:42:22 --> Input Class Initialized
INFO - 2023-01-03 10:42:22 --> Language Class Initialized
INFO - 2023-01-03 10:42:23 --> Loader Class Initialized
INFO - 2023-01-03 10:42:23 --> Controller Class Initialized
DEBUG - 2023-01-03 10:42:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:42:23 --> Database Driver Class Initialized
INFO - 2023-01-03 10:42:23 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:42:23 --> Database Driver Class Initialized
INFO - 2023-01-03 10:42:23 --> Model "Login_model" initialized
INFO - 2023-01-03 10:42:23 --> Final output sent to browser
DEBUG - 2023-01-03 10:42:23 --> Total execution time: 1.3553
INFO - 2023-01-03 10:42:23 --> Config Class Initialized
INFO - 2023-01-03 10:42:23 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:42:23 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:42:23 --> Utf8 Class Initialized
INFO - 2023-01-03 10:42:23 --> URI Class Initialized
INFO - 2023-01-03 10:42:23 --> Router Class Initialized
INFO - 2023-01-03 10:42:23 --> Output Class Initialized
INFO - 2023-01-03 10:42:23 --> Security Class Initialized
DEBUG - 2023-01-03 10:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:42:23 --> Input Class Initialized
INFO - 2023-01-03 10:42:24 --> Language Class Initialized
INFO - 2023-01-03 10:42:24 --> Loader Class Initialized
INFO - 2023-01-03 10:42:24 --> Controller Class Initialized
DEBUG - 2023-01-03 10:42:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:42:24 --> Database Driver Class Initialized
INFO - 2023-01-03 10:42:24 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:42:24 --> Database Driver Class Initialized
INFO - 2023-01-03 10:42:24 --> Model "Login_model" initialized
INFO - 2023-01-03 10:42:24 --> Final output sent to browser
DEBUG - 2023-01-03 10:42:24 --> Total execution time: 0.8924
INFO - 2023-01-03 10:43:07 --> Config Class Initialized
INFO - 2023-01-03 10:43:07 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:43:07 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:43:07 --> Utf8 Class Initialized
INFO - 2023-01-03 10:43:07 --> URI Class Initialized
INFO - 2023-01-03 10:43:07 --> Router Class Initialized
INFO - 2023-01-03 10:43:07 --> Output Class Initialized
INFO - 2023-01-03 10:43:07 --> Security Class Initialized
DEBUG - 2023-01-03 10:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:43:07 --> Input Class Initialized
INFO - 2023-01-03 10:43:07 --> Language Class Initialized
INFO - 2023-01-03 10:43:08 --> Loader Class Initialized
INFO - 2023-01-03 10:43:08 --> Controller Class Initialized
DEBUG - 2023-01-03 10:43:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:43:08 --> Database Driver Class Initialized
INFO - 2023-01-03 10:43:08 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:43:08 --> Database Driver Class Initialized
INFO - 2023-01-03 10:43:08 --> Model "Login_model" initialized
INFO - 2023-01-03 10:43:08 --> Final output sent to browser
DEBUG - 2023-01-03 10:43:08 --> Total execution time: 1.6058
INFO - 2023-01-03 10:43:09 --> Config Class Initialized
INFO - 2023-01-03 10:43:09 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:43:09 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:43:09 --> Utf8 Class Initialized
INFO - 2023-01-03 10:43:09 --> URI Class Initialized
INFO - 2023-01-03 10:43:09 --> Router Class Initialized
INFO - 2023-01-03 10:43:09 --> Output Class Initialized
INFO - 2023-01-03 10:43:09 --> Security Class Initialized
DEBUG - 2023-01-03 10:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:43:09 --> Input Class Initialized
INFO - 2023-01-03 10:43:09 --> Language Class Initialized
INFO - 2023-01-03 10:43:09 --> Loader Class Initialized
INFO - 2023-01-03 10:43:09 --> Controller Class Initialized
DEBUG - 2023-01-03 10:43:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:43:09 --> Database Driver Class Initialized
INFO - 2023-01-03 10:43:10 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:43:10 --> Database Driver Class Initialized
INFO - 2023-01-03 10:43:10 --> Model "Login_model" initialized
INFO - 2023-01-03 10:43:10 --> Final output sent to browser
DEBUG - 2023-01-03 10:43:10 --> Total execution time: 1.1451
INFO - 2023-01-03 10:44:00 --> Config Class Initialized
INFO - 2023-01-03 10:44:00 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:44:01 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:44:01 --> Utf8 Class Initialized
INFO - 2023-01-03 10:44:01 --> URI Class Initialized
INFO - 2023-01-03 10:44:01 --> Router Class Initialized
INFO - 2023-01-03 10:44:01 --> Output Class Initialized
INFO - 2023-01-03 10:44:01 --> Security Class Initialized
DEBUG - 2023-01-03 10:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:44:01 --> Input Class Initialized
INFO - 2023-01-03 10:44:01 --> Language Class Initialized
INFO - 2023-01-03 10:44:01 --> Loader Class Initialized
INFO - 2023-01-03 10:44:01 --> Controller Class Initialized
DEBUG - 2023-01-03 10:44:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:44:01 --> Database Driver Class Initialized
INFO - 2023-01-03 10:44:01 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:44:01 --> Database Driver Class Initialized
INFO - 2023-01-03 10:44:02 --> Model "Login_model" initialized
INFO - 2023-01-03 10:44:02 --> Final output sent to browser
DEBUG - 2023-01-03 10:44:02 --> Total execution time: 1.2858
INFO - 2023-01-03 10:44:02 --> Config Class Initialized
INFO - 2023-01-03 10:44:02 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:44:02 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:44:02 --> Utf8 Class Initialized
INFO - 2023-01-03 10:44:02 --> URI Class Initialized
INFO - 2023-01-03 10:44:02 --> Router Class Initialized
INFO - 2023-01-03 10:44:02 --> Output Class Initialized
INFO - 2023-01-03 10:44:02 --> Security Class Initialized
DEBUG - 2023-01-03 10:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:44:02 --> Input Class Initialized
INFO - 2023-01-03 10:44:02 --> Language Class Initialized
INFO - 2023-01-03 10:44:03 --> Loader Class Initialized
INFO - 2023-01-03 10:44:03 --> Controller Class Initialized
DEBUG - 2023-01-03 10:44:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:44:03 --> Database Driver Class Initialized
INFO - 2023-01-03 10:44:03 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:44:03 --> Database Driver Class Initialized
INFO - 2023-01-03 10:44:03 --> Model "Login_model" initialized
INFO - 2023-01-03 10:44:03 --> Final output sent to browser
DEBUG - 2023-01-03 10:44:03 --> Total execution time: 1.3593
INFO - 2023-01-03 10:44:57 --> Config Class Initialized
INFO - 2023-01-03 10:44:57 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:44:57 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:44:57 --> Utf8 Class Initialized
INFO - 2023-01-03 10:44:57 --> URI Class Initialized
INFO - 2023-01-03 10:44:57 --> Router Class Initialized
INFO - 2023-01-03 10:44:57 --> Output Class Initialized
INFO - 2023-01-03 10:44:57 --> Security Class Initialized
DEBUG - 2023-01-03 10:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:44:57 --> Input Class Initialized
INFO - 2023-01-03 10:44:57 --> Language Class Initialized
INFO - 2023-01-03 10:44:57 --> Loader Class Initialized
INFO - 2023-01-03 10:44:57 --> Controller Class Initialized
DEBUG - 2023-01-03 10:44:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:44:57 --> Database Driver Class Initialized
INFO - 2023-01-03 10:44:58 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:44:58 --> Database Driver Class Initialized
INFO - 2023-01-03 10:44:58 --> Model "Login_model" initialized
INFO - 2023-01-03 10:44:58 --> Final output sent to browser
DEBUG - 2023-01-03 10:44:58 --> Total execution time: 0.9971
INFO - 2023-01-03 10:44:58 --> Config Class Initialized
INFO - 2023-01-03 10:44:58 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:44:58 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:44:58 --> Utf8 Class Initialized
INFO - 2023-01-03 10:44:58 --> URI Class Initialized
INFO - 2023-01-03 10:44:58 --> Router Class Initialized
INFO - 2023-01-03 10:44:58 --> Output Class Initialized
INFO - 2023-01-03 10:44:58 --> Security Class Initialized
DEBUG - 2023-01-03 10:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:44:58 --> Input Class Initialized
INFO - 2023-01-03 10:44:59 --> Language Class Initialized
INFO - 2023-01-03 10:44:59 --> Loader Class Initialized
INFO - 2023-01-03 10:44:59 --> Controller Class Initialized
DEBUG - 2023-01-03 10:44:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:44:59 --> Database Driver Class Initialized
INFO - 2023-01-03 10:44:59 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:44:59 --> Database Driver Class Initialized
INFO - 2023-01-03 10:44:59 --> Model "Login_model" initialized
INFO - 2023-01-03 10:44:59 --> Final output sent to browser
DEBUG - 2023-01-03 10:44:59 --> Total execution time: 1.3372
INFO - 2023-01-03 10:46:16 --> Config Class Initialized
INFO - 2023-01-03 10:46:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:46:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:46:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:46:16 --> URI Class Initialized
INFO - 2023-01-03 10:46:16 --> Router Class Initialized
INFO - 2023-01-03 10:46:16 --> Output Class Initialized
INFO - 2023-01-03 10:46:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:46:16 --> Input Class Initialized
INFO - 2023-01-03 10:46:16 --> Language Class Initialized
INFO - 2023-01-03 10:46:16 --> Loader Class Initialized
INFO - 2023-01-03 10:46:16 --> Controller Class Initialized
DEBUG - 2023-01-03 10:46:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:46:16 --> Database Driver Class Initialized
INFO - 2023-01-03 10:46:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:46:17 --> Database Driver Class Initialized
INFO - 2023-01-03 10:46:17 --> Model "Login_model" initialized
INFO - 2023-01-03 10:46:17 --> Final output sent to browser
DEBUG - 2023-01-03 10:46:17 --> Total execution time: 1.0931
INFO - 2023-01-03 10:46:17 --> Config Class Initialized
INFO - 2023-01-03 10:46:17 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:46:17 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:46:17 --> Utf8 Class Initialized
INFO - 2023-01-03 10:46:17 --> URI Class Initialized
INFO - 2023-01-03 10:46:17 --> Router Class Initialized
INFO - 2023-01-03 10:46:17 --> Output Class Initialized
INFO - 2023-01-03 10:46:17 --> Security Class Initialized
DEBUG - 2023-01-03 10:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:46:17 --> Input Class Initialized
INFO - 2023-01-03 10:46:17 --> Language Class Initialized
INFO - 2023-01-03 10:46:17 --> Loader Class Initialized
INFO - 2023-01-03 10:46:17 --> Controller Class Initialized
DEBUG - 2023-01-03 10:46:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:46:17 --> Database Driver Class Initialized
INFO - 2023-01-03 10:46:17 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:46:18 --> Database Driver Class Initialized
INFO - 2023-01-03 10:46:18 --> Model "Login_model" initialized
INFO - 2023-01-03 10:46:18 --> Final output sent to browser
DEBUG - 2023-01-03 10:46:18 --> Total execution time: 0.6971
INFO - 2023-01-03 10:46:38 --> Config Class Initialized
INFO - 2023-01-03 10:46:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:46:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:46:38 --> Utf8 Class Initialized
INFO - 2023-01-03 10:46:38 --> URI Class Initialized
INFO - 2023-01-03 10:46:38 --> Router Class Initialized
INFO - 2023-01-03 10:46:38 --> Output Class Initialized
INFO - 2023-01-03 10:46:38 --> Security Class Initialized
DEBUG - 2023-01-03 10:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:46:38 --> Input Class Initialized
INFO - 2023-01-03 10:46:38 --> Language Class Initialized
INFO - 2023-01-03 10:46:39 --> Loader Class Initialized
INFO - 2023-01-03 10:46:39 --> Controller Class Initialized
DEBUG - 2023-01-03 10:46:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:46:39 --> Database Driver Class Initialized
INFO - 2023-01-03 10:46:39 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:46:39 --> Database Driver Class Initialized
INFO - 2023-01-03 10:46:39 --> Model "Login_model" initialized
INFO - 2023-01-03 10:46:39 --> Final output sent to browser
DEBUG - 2023-01-03 10:46:39 --> Total execution time: 1.1441
INFO - 2023-01-03 10:46:39 --> Config Class Initialized
INFO - 2023-01-03 10:46:39 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:46:39 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:46:39 --> Utf8 Class Initialized
INFO - 2023-01-03 10:46:39 --> URI Class Initialized
INFO - 2023-01-03 10:46:39 --> Router Class Initialized
INFO - 2023-01-03 10:46:39 --> Output Class Initialized
INFO - 2023-01-03 10:46:39 --> Security Class Initialized
DEBUG - 2023-01-03 10:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:46:39 --> Input Class Initialized
INFO - 2023-01-03 10:46:39 --> Language Class Initialized
INFO - 2023-01-03 10:46:39 --> Loader Class Initialized
INFO - 2023-01-03 10:46:40 --> Controller Class Initialized
DEBUG - 2023-01-03 10:46:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:46:40 --> Database Driver Class Initialized
INFO - 2023-01-03 10:46:40 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:46:40 --> Database Driver Class Initialized
INFO - 2023-01-03 10:46:40 --> Model "Login_model" initialized
INFO - 2023-01-03 10:46:40 --> Final output sent to browser
DEBUG - 2023-01-03 10:46:40 --> Total execution time: 0.6749
INFO - 2023-01-03 10:47:46 --> Config Class Initialized
INFO - 2023-01-03 10:47:46 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:47:46 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:47:46 --> Utf8 Class Initialized
INFO - 2023-01-03 10:47:46 --> URI Class Initialized
INFO - 2023-01-03 10:47:46 --> Router Class Initialized
INFO - 2023-01-03 10:47:46 --> Output Class Initialized
INFO - 2023-01-03 10:47:46 --> Security Class Initialized
DEBUG - 2023-01-03 10:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:47:46 --> Input Class Initialized
INFO - 2023-01-03 10:47:46 --> Language Class Initialized
INFO - 2023-01-03 10:47:46 --> Loader Class Initialized
INFO - 2023-01-03 10:47:46 --> Controller Class Initialized
DEBUG - 2023-01-03 10:47:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:47:46 --> Database Driver Class Initialized
INFO - 2023-01-03 10:47:46 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:47:46 --> Database Driver Class Initialized
INFO - 2023-01-03 10:47:46 --> Model "Login_model" initialized
INFO - 2023-01-03 10:47:46 --> Final output sent to browser
DEBUG - 2023-01-03 10:47:46 --> Total execution time: 0.6472
INFO - 2023-01-03 10:47:47 --> Config Class Initialized
INFO - 2023-01-03 10:47:47 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:47:47 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:47:47 --> Utf8 Class Initialized
INFO - 2023-01-03 10:47:47 --> URI Class Initialized
INFO - 2023-01-03 10:47:47 --> Router Class Initialized
INFO - 2023-01-03 10:47:47 --> Output Class Initialized
INFO - 2023-01-03 10:47:47 --> Security Class Initialized
DEBUG - 2023-01-03 10:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:47:47 --> Input Class Initialized
INFO - 2023-01-03 10:47:47 --> Language Class Initialized
INFO - 2023-01-03 10:47:47 --> Loader Class Initialized
INFO - 2023-01-03 10:47:47 --> Controller Class Initialized
DEBUG - 2023-01-03 10:47:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:47:47 --> Database Driver Class Initialized
INFO - 2023-01-03 10:47:47 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:47:47 --> Database Driver Class Initialized
INFO - 2023-01-03 10:47:47 --> Model "Login_model" initialized
INFO - 2023-01-03 10:47:47 --> Final output sent to browser
DEBUG - 2023-01-03 10:47:47 --> Total execution time: 0.5958
INFO - 2023-01-03 10:48:38 --> Config Class Initialized
INFO - 2023-01-03 10:48:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:48:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:48:38 --> Utf8 Class Initialized
INFO - 2023-01-03 10:48:38 --> URI Class Initialized
INFO - 2023-01-03 10:48:38 --> Router Class Initialized
INFO - 2023-01-03 10:48:38 --> Output Class Initialized
INFO - 2023-01-03 10:48:38 --> Security Class Initialized
DEBUG - 2023-01-03 10:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:48:38 --> Input Class Initialized
INFO - 2023-01-03 10:48:38 --> Language Class Initialized
INFO - 2023-01-03 10:48:39 --> Loader Class Initialized
INFO - 2023-01-03 10:48:39 --> Controller Class Initialized
DEBUG - 2023-01-03 10:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:48:39 --> Final output sent to browser
DEBUG - 2023-01-03 10:48:39 --> Total execution time: 1.0551
INFO - 2023-01-03 10:48:39 --> Config Class Initialized
INFO - 2023-01-03 10:48:39 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:48:39 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:48:39 --> Utf8 Class Initialized
INFO - 2023-01-03 10:48:39 --> URI Class Initialized
INFO - 2023-01-03 10:48:39 --> Router Class Initialized
INFO - 2023-01-03 10:48:39 --> Output Class Initialized
INFO - 2023-01-03 10:48:39 --> Security Class Initialized
DEBUG - 2023-01-03 10:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:48:39 --> Input Class Initialized
INFO - 2023-01-03 10:48:39 --> Language Class Initialized
INFO - 2023-01-03 10:48:39 --> Loader Class Initialized
INFO - 2023-01-03 10:48:40 --> Controller Class Initialized
DEBUG - 2023-01-03 10:48:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:48:40 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:40 --> Model "Login_model" initialized
INFO - 2023-01-03 10:48:40 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:40 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:48:40 --> Final output sent to browser
DEBUG - 2023-01-03 10:48:40 --> Total execution time: 0.9626
INFO - 2023-01-03 10:48:40 --> Config Class Initialized
INFO - 2023-01-03 10:48:40 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:48:40 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:48:40 --> Utf8 Class Initialized
INFO - 2023-01-03 10:48:40 --> URI Class Initialized
INFO - 2023-01-03 10:48:40 --> Router Class Initialized
INFO - 2023-01-03 10:48:40 --> Output Class Initialized
INFO - 2023-01-03 10:48:40 --> Security Class Initialized
DEBUG - 2023-01-03 10:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:48:40 --> Input Class Initialized
INFO - 2023-01-03 10:48:41 --> Language Class Initialized
INFO - 2023-01-03 10:48:41 --> Loader Class Initialized
INFO - 2023-01-03 10:48:41 --> Controller Class Initialized
DEBUG - 2023-01-03 10:48:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:48:41 --> Final output sent to browser
DEBUG - 2023-01-03 10:48:41 --> Total execution time: 0.7145
INFO - 2023-01-03 10:48:41 --> Config Class Initialized
INFO - 2023-01-03 10:48:41 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:48:41 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:48:41 --> Utf8 Class Initialized
INFO - 2023-01-03 10:48:41 --> URI Class Initialized
INFO - 2023-01-03 10:48:41 --> Router Class Initialized
INFO - 2023-01-03 10:48:41 --> Output Class Initialized
INFO - 2023-01-03 10:48:41 --> Security Class Initialized
DEBUG - 2023-01-03 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:48:41 --> Input Class Initialized
INFO - 2023-01-03 10:48:41 --> Language Class Initialized
INFO - 2023-01-03 10:48:41 --> Loader Class Initialized
INFO - 2023-01-03 10:48:41 --> Controller Class Initialized
DEBUG - 2023-01-03 10:48:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:48:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:42 --> Model "Login_model" initialized
INFO - 2023-01-03 10:48:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:42 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:48:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:48:42 --> Total execution time: 0.8813
INFO - 2023-01-03 10:48:44 --> Config Class Initialized
INFO - 2023-01-03 10:48:44 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:48:44 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:48:44 --> Utf8 Class Initialized
INFO - 2023-01-03 10:48:44 --> URI Class Initialized
INFO - 2023-01-03 10:48:44 --> Router Class Initialized
INFO - 2023-01-03 10:48:44 --> Output Class Initialized
INFO - 2023-01-03 10:48:45 --> Security Class Initialized
DEBUG - 2023-01-03 10:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:48:45 --> Input Class Initialized
INFO - 2023-01-03 10:48:45 --> Language Class Initialized
INFO - 2023-01-03 10:48:45 --> Loader Class Initialized
INFO - 2023-01-03 10:48:45 --> Controller Class Initialized
DEBUG - 2023-01-03 10:48:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:48:45 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:45 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:48:45 --> Final output sent to browser
DEBUG - 2023-01-03 10:48:45 --> Total execution time: 0.9341
INFO - 2023-01-03 10:48:45 --> Config Class Initialized
INFO - 2023-01-03 10:48:45 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:48:45 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:48:45 --> Utf8 Class Initialized
INFO - 2023-01-03 10:48:45 --> URI Class Initialized
INFO - 2023-01-03 10:48:45 --> Router Class Initialized
INFO - 2023-01-03 10:48:45 --> Output Class Initialized
INFO - 2023-01-03 10:48:45 --> Security Class Initialized
DEBUG - 2023-01-03 10:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:48:45 --> Input Class Initialized
INFO - 2023-01-03 10:48:45 --> Language Class Initialized
INFO - 2023-01-03 10:48:46 --> Loader Class Initialized
INFO - 2023-01-03 10:48:46 --> Controller Class Initialized
DEBUG - 2023-01-03 10:48:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:48:46 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:46 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:48:46 --> Final output sent to browser
DEBUG - 2023-01-03 10:48:46 --> Total execution time: 0.6477
INFO - 2023-01-03 10:48:47 --> Config Class Initialized
INFO - 2023-01-03 10:48:47 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:48:47 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:48:47 --> Utf8 Class Initialized
INFO - 2023-01-03 10:48:47 --> URI Class Initialized
INFO - 2023-01-03 10:48:47 --> Router Class Initialized
INFO - 2023-01-03 10:48:48 --> Output Class Initialized
INFO - 2023-01-03 10:48:48 --> Security Class Initialized
DEBUG - 2023-01-03 10:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:48:48 --> Input Class Initialized
INFO - 2023-01-03 10:48:48 --> Language Class Initialized
INFO - 2023-01-03 10:48:48 --> Loader Class Initialized
INFO - 2023-01-03 10:48:48 --> Controller Class Initialized
DEBUG - 2023-01-03 10:48:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:48:48 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:48 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:48:48 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:48 --> Model "Login_model" initialized
INFO - 2023-01-03 10:48:48 --> Final output sent to browser
DEBUG - 2023-01-03 10:48:48 --> Total execution time: 0.8758
INFO - 2023-01-03 10:48:48 --> Config Class Initialized
INFO - 2023-01-03 10:48:48 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:48:48 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:48:49 --> Utf8 Class Initialized
INFO - 2023-01-03 10:48:49 --> URI Class Initialized
INFO - 2023-01-03 10:48:49 --> Router Class Initialized
INFO - 2023-01-03 10:48:49 --> Output Class Initialized
INFO - 2023-01-03 10:48:49 --> Security Class Initialized
DEBUG - 2023-01-03 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:48:49 --> Input Class Initialized
INFO - 2023-01-03 10:48:49 --> Language Class Initialized
INFO - 2023-01-03 10:48:49 --> Loader Class Initialized
INFO - 2023-01-03 10:48:49 --> Controller Class Initialized
DEBUG - 2023-01-03 10:48:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:48:49 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:49 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:48:49 --> Database Driver Class Initialized
INFO - 2023-01-03 10:48:49 --> Model "Login_model" initialized
INFO - 2023-01-03 10:48:49 --> Final output sent to browser
DEBUG - 2023-01-03 10:48:49 --> Total execution time: 0.8234
INFO - 2023-01-03 10:50:15 --> Config Class Initialized
INFO - 2023-01-03 10:50:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:15 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:15 --> URI Class Initialized
INFO - 2023-01-03 10:50:15 --> Router Class Initialized
INFO - 2023-01-03 10:50:15 --> Output Class Initialized
INFO - 2023-01-03 10:50:15 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:15 --> Input Class Initialized
INFO - 2023-01-03 10:50:15 --> Language Class Initialized
INFO - 2023-01-03 10:50:15 --> Loader Class Initialized
INFO - 2023-01-03 10:50:15 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:15 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:15 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:15 --> Model "Login_model" initialized
INFO - 2023-01-03 10:50:15 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:15 --> Total execution time: 0.9199
INFO - 2023-01-03 10:50:16 --> Config Class Initialized
INFO - 2023-01-03 10:50:16 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:16 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:16 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:16 --> URI Class Initialized
INFO - 2023-01-03 10:50:16 --> Router Class Initialized
INFO - 2023-01-03 10:50:16 --> Output Class Initialized
INFO - 2023-01-03 10:50:16 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:16 --> Input Class Initialized
INFO - 2023-01-03 10:50:16 --> Language Class Initialized
INFO - 2023-01-03 10:50:16 --> Loader Class Initialized
INFO - 2023-01-03 10:50:16 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:16 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:16 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:16 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:16 --> Model "Login_model" initialized
INFO - 2023-01-03 10:50:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:16 --> Total execution time: 0.7451
INFO - 2023-01-03 10:50:31 --> Config Class Initialized
INFO - 2023-01-03 10:50:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:31 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:31 --> URI Class Initialized
INFO - 2023-01-03 10:50:31 --> Router Class Initialized
INFO - 2023-01-03 10:50:31 --> Output Class Initialized
INFO - 2023-01-03 10:50:31 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:31 --> Input Class Initialized
INFO - 2023-01-03 10:50:31 --> Language Class Initialized
INFO - 2023-01-03 10:50:31 --> Loader Class Initialized
INFO - 2023-01-03 10:50:31 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:31 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:31 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:31 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:31 --> Total execution time: 0.3498
INFO - 2023-01-03 10:50:31 --> Config Class Initialized
INFO - 2023-01-03 10:50:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:31 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:31 --> URI Class Initialized
INFO - 2023-01-03 10:50:31 --> Router Class Initialized
INFO - 2023-01-03 10:50:31 --> Output Class Initialized
INFO - 2023-01-03 10:50:31 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:31 --> Input Class Initialized
INFO - 2023-01-03 10:50:31 --> Language Class Initialized
INFO - 2023-01-03 10:50:31 --> Loader Class Initialized
INFO - 2023-01-03 10:50:31 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:31 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:31 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:31 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:31 --> Total execution time: 0.2973
INFO - 2023-01-03 10:50:33 --> Config Class Initialized
INFO - 2023-01-03 10:50:33 --> Config Class Initialized
INFO - 2023-01-03 10:50:33 --> Hooks Class Initialized
INFO - 2023-01-03 10:50:33 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 10:50:33 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:34 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:34 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:34 --> URI Class Initialized
INFO - 2023-01-03 10:50:34 --> URI Class Initialized
INFO - 2023-01-03 10:50:34 --> Router Class Initialized
INFO - 2023-01-03 10:50:34 --> Router Class Initialized
INFO - 2023-01-03 10:50:34 --> Output Class Initialized
INFO - 2023-01-03 10:50:34 --> Output Class Initialized
INFO - 2023-01-03 10:50:34 --> Security Class Initialized
INFO - 2023-01-03 10:50:34 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 10:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:34 --> Input Class Initialized
INFO - 2023-01-03 10:50:34 --> Input Class Initialized
INFO - 2023-01-03 10:50:34 --> Language Class Initialized
INFO - 2023-01-03 10:50:34 --> Language Class Initialized
INFO - 2023-01-03 10:50:34 --> Loader Class Initialized
INFO - 2023-01-03 10:50:34 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:34 --> Loader Class Initialized
INFO - 2023-01-03 10:50:34 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:34 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:34 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:34 --> Total execution time: 0.4678
INFO - 2023-01-03 10:50:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:34 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:34 --> Total execution time: 0.5062
INFO - 2023-01-03 10:50:34 --> Config Class Initialized
INFO - 2023-01-03 10:50:34 --> Hooks Class Initialized
INFO - 2023-01-03 10:50:34 --> Config Class Initialized
INFO - 2023-01-03 10:50:34 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:34 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:34 --> URI Class Initialized
DEBUG - 2023-01-03 10:50:34 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:34 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:34 --> Router Class Initialized
INFO - 2023-01-03 10:50:34 --> URI Class Initialized
INFO - 2023-01-03 10:50:34 --> Output Class Initialized
INFO - 2023-01-03 10:50:34 --> Router Class Initialized
INFO - 2023-01-03 10:50:34 --> Security Class Initialized
INFO - 2023-01-03 10:50:34 --> Output Class Initialized
DEBUG - 2023-01-03 10:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:34 --> Input Class Initialized
INFO - 2023-01-03 10:50:34 --> Security Class Initialized
INFO - 2023-01-03 10:50:34 --> Language Class Initialized
DEBUG - 2023-01-03 10:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:34 --> Input Class Initialized
INFO - 2023-01-03 10:50:34 --> Language Class Initialized
INFO - 2023-01-03 10:50:34 --> Loader Class Initialized
INFO - 2023-01-03 10:50:34 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:34 --> Loader Class Initialized
INFO - 2023-01-03 10:50:34 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:34 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:34 --> Final output sent to browser
INFO - 2023-01-03 10:50:34 --> Database Driver Class Initialized
DEBUG - 2023-01-03 10:50:34 --> Total execution time: 0.4365
INFO - 2023-01-03 10:50:34 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:34 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:34 --> Total execution time: 0.4398
INFO - 2023-01-03 10:50:37 --> Config Class Initialized
INFO - 2023-01-03 10:50:37 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:37 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:37 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:37 --> URI Class Initialized
INFO - 2023-01-03 10:50:37 --> Router Class Initialized
INFO - 2023-01-03 10:50:37 --> Output Class Initialized
INFO - 2023-01-03 10:50:37 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:37 --> Input Class Initialized
INFO - 2023-01-03 10:50:37 --> Language Class Initialized
INFO - 2023-01-03 10:50:38 --> Loader Class Initialized
INFO - 2023-01-03 10:50:38 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:38 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:38 --> Total execution time: 0.1832
INFO - 2023-01-03 10:50:38 --> Config Class Initialized
INFO - 2023-01-03 10:50:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:38 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:38 --> URI Class Initialized
INFO - 2023-01-03 10:50:38 --> Router Class Initialized
INFO - 2023-01-03 10:50:38 --> Output Class Initialized
INFO - 2023-01-03 10:50:38 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:38 --> Input Class Initialized
INFO - 2023-01-03 10:50:38 --> Language Class Initialized
INFO - 2023-01-03 10:50:38 --> Loader Class Initialized
INFO - 2023-01-03 10:50:38 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:38 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:38 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:38 --> Total execution time: 0.2717
INFO - 2023-01-03 10:50:42 --> Config Class Initialized
INFO - 2023-01-03 10:50:42 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:42 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:42 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:42 --> URI Class Initialized
INFO - 2023-01-03 10:50:42 --> Router Class Initialized
INFO - 2023-01-03 10:50:42 --> Output Class Initialized
INFO - 2023-01-03 10:50:42 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:42 --> Input Class Initialized
INFO - 2023-01-03 10:50:42 --> Language Class Initialized
INFO - 2023-01-03 10:50:42 --> Loader Class Initialized
INFO - 2023-01-03 10:50:42 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:42 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:42 --> Total execution time: 0.2383
INFO - 2023-01-03 10:50:42 --> Config Class Initialized
INFO - 2023-01-03 10:50:42 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:42 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:42 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:42 --> URI Class Initialized
INFO - 2023-01-03 10:50:42 --> Router Class Initialized
INFO - 2023-01-03 10:50:42 --> Output Class Initialized
INFO - 2023-01-03 10:50:42 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:42 --> Input Class Initialized
INFO - 2023-01-03 10:50:42 --> Language Class Initialized
INFO - 2023-01-03 10:50:42 --> Loader Class Initialized
INFO - 2023-01-03 10:50:42 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:42 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:42 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:42 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:42 --> Total execution time: 0.2293
INFO - 2023-01-03 10:50:55 --> Config Class Initialized
INFO - 2023-01-03 10:50:55 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:55 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:55 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:55 --> URI Class Initialized
INFO - 2023-01-03 10:50:55 --> Router Class Initialized
INFO - 2023-01-03 10:50:55 --> Output Class Initialized
INFO - 2023-01-03 10:50:55 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:55 --> Input Class Initialized
INFO - 2023-01-03 10:50:55 --> Language Class Initialized
INFO - 2023-01-03 10:50:55 --> Loader Class Initialized
INFO - 2023-01-03 10:50:55 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:55 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:55 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:55 --> Total execution time: 0.1773
INFO - 2023-01-03 10:50:55 --> Config Class Initialized
INFO - 2023-01-03 10:50:55 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:55 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:55 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:55 --> URI Class Initialized
INFO - 2023-01-03 10:50:55 --> Router Class Initialized
INFO - 2023-01-03 10:50:55 --> Output Class Initialized
INFO - 2023-01-03 10:50:55 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:55 --> Input Class Initialized
INFO - 2023-01-03 10:50:55 --> Language Class Initialized
INFO - 2023-01-03 10:50:55 --> Loader Class Initialized
INFO - 2023-01-03 10:50:55 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:55 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:55 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:55 --> Total execution time: 0.1751
INFO - 2023-01-03 10:50:59 --> Config Class Initialized
INFO - 2023-01-03 10:50:59 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:59 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:59 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:59 --> URI Class Initialized
INFO - 2023-01-03 10:50:59 --> Router Class Initialized
INFO - 2023-01-03 10:50:59 --> Output Class Initialized
INFO - 2023-01-03 10:50:59 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:59 --> Input Class Initialized
INFO - 2023-01-03 10:50:59 --> Language Class Initialized
INFO - 2023-01-03 10:50:59 --> Loader Class Initialized
INFO - 2023-01-03 10:50:59 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:59 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:59 --> Total execution time: 0.1197
INFO - 2023-01-03 10:50:59 --> Config Class Initialized
INFO - 2023-01-03 10:50:59 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:50:59 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:50:59 --> Utf8 Class Initialized
INFO - 2023-01-03 10:50:59 --> URI Class Initialized
INFO - 2023-01-03 10:50:59 --> Router Class Initialized
INFO - 2023-01-03 10:50:59 --> Output Class Initialized
INFO - 2023-01-03 10:50:59 --> Security Class Initialized
DEBUG - 2023-01-03 10:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:50:59 --> Input Class Initialized
INFO - 2023-01-03 10:50:59 --> Language Class Initialized
INFO - 2023-01-03 10:50:59 --> Loader Class Initialized
INFO - 2023-01-03 10:50:59 --> Controller Class Initialized
DEBUG - 2023-01-03 10:50:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:50:59 --> Database Driver Class Initialized
INFO - 2023-01-03 10:50:59 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:50:59 --> Final output sent to browser
DEBUG - 2023-01-03 10:50:59 --> Total execution time: 0.1704
INFO - 2023-01-03 10:51:03 --> Config Class Initialized
INFO - 2023-01-03 10:51:03 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:03 --> URI Class Initialized
INFO - 2023-01-03 10:51:03 --> Router Class Initialized
INFO - 2023-01-03 10:51:03 --> Output Class Initialized
INFO - 2023-01-03 10:51:03 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:03 --> Input Class Initialized
INFO - 2023-01-03 10:51:03 --> Language Class Initialized
INFO - 2023-01-03 10:51:03 --> Loader Class Initialized
INFO - 2023-01-03 10:51:03 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:03 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:03 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:03 --> Total execution time: 0.2079
INFO - 2023-01-03 10:51:03 --> Config Class Initialized
INFO - 2023-01-03 10:51:03 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:03 --> URI Class Initialized
INFO - 2023-01-03 10:51:03 --> Router Class Initialized
INFO - 2023-01-03 10:51:03 --> Output Class Initialized
INFO - 2023-01-03 10:51:03 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:03 --> Input Class Initialized
INFO - 2023-01-03 10:51:03 --> Language Class Initialized
INFO - 2023-01-03 10:51:03 --> Loader Class Initialized
INFO - 2023-01-03 10:51:03 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:03 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:03 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:03 --> Total execution time: 0.2528
INFO - 2023-01-03 10:51:15 --> Config Class Initialized
INFO - 2023-01-03 10:51:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:15 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:15 --> URI Class Initialized
INFO - 2023-01-03 10:51:15 --> Router Class Initialized
INFO - 2023-01-03 10:51:15 --> Output Class Initialized
INFO - 2023-01-03 10:51:15 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:15 --> Input Class Initialized
INFO - 2023-01-03 10:51:15 --> Language Class Initialized
INFO - 2023-01-03 10:51:15 --> Loader Class Initialized
INFO - 2023-01-03 10:51:15 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:15 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:15 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:15 --> Total execution time: 0.3093
INFO - 2023-01-03 10:51:15 --> Config Class Initialized
INFO - 2023-01-03 10:51:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:15 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:15 --> URI Class Initialized
INFO - 2023-01-03 10:51:15 --> Router Class Initialized
INFO - 2023-01-03 10:51:15 --> Output Class Initialized
INFO - 2023-01-03 10:51:15 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:15 --> Input Class Initialized
INFO - 2023-01-03 10:51:15 --> Language Class Initialized
INFO - 2023-01-03 10:51:15 --> Loader Class Initialized
INFO - 2023-01-03 10:51:16 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:16 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:16 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:16 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:16 --> Total execution time: 0.2962
INFO - 2023-01-03 10:51:28 --> Config Class Initialized
INFO - 2023-01-03 10:51:28 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:28 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:28 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:28 --> URI Class Initialized
INFO - 2023-01-03 10:51:28 --> Router Class Initialized
INFO - 2023-01-03 10:51:28 --> Output Class Initialized
INFO - 2023-01-03 10:51:28 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:28 --> Input Class Initialized
INFO - 2023-01-03 10:51:28 --> Language Class Initialized
INFO - 2023-01-03 10:51:28 --> Loader Class Initialized
INFO - 2023-01-03 10:51:28 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:28 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:28 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:28 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:28 --> Total execution time: 0.2382
INFO - 2023-01-03 10:51:28 --> Config Class Initialized
INFO - 2023-01-03 10:51:28 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:28 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:28 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:28 --> URI Class Initialized
INFO - 2023-01-03 10:51:28 --> Router Class Initialized
INFO - 2023-01-03 10:51:28 --> Output Class Initialized
INFO - 2023-01-03 10:51:28 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:28 --> Input Class Initialized
INFO - 2023-01-03 10:51:28 --> Language Class Initialized
INFO - 2023-01-03 10:51:28 --> Loader Class Initialized
INFO - 2023-01-03 10:51:28 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:28 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:28 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:28 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:28 --> Total execution time: 0.2040
INFO - 2023-01-03 10:51:37 --> Config Class Initialized
INFO - 2023-01-03 10:51:37 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:37 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:37 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:37 --> URI Class Initialized
INFO - 2023-01-03 10:51:37 --> Router Class Initialized
INFO - 2023-01-03 10:51:37 --> Output Class Initialized
INFO - 2023-01-03 10:51:37 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:37 --> Input Class Initialized
INFO - 2023-01-03 10:51:37 --> Language Class Initialized
INFO - 2023-01-03 10:51:37 --> Loader Class Initialized
INFO - 2023-01-03 10:51:37 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:37 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:37 --> Total execution time: 0.0994
INFO - 2023-01-03 10:51:37 --> Config Class Initialized
INFO - 2023-01-03 10:51:37 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:37 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:37 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:37 --> URI Class Initialized
INFO - 2023-01-03 10:51:37 --> Router Class Initialized
INFO - 2023-01-03 10:51:37 --> Output Class Initialized
INFO - 2023-01-03 10:51:37 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:37 --> Input Class Initialized
INFO - 2023-01-03 10:51:37 --> Language Class Initialized
INFO - 2023-01-03 10:51:37 --> Loader Class Initialized
INFO - 2023-01-03 10:51:37 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:37 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:37 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:37 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:37 --> Total execution time: 0.1386
INFO - 2023-01-03 10:51:38 --> Config Class Initialized
INFO - 2023-01-03 10:51:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:38 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:38 --> URI Class Initialized
INFO - 2023-01-03 10:51:38 --> Router Class Initialized
INFO - 2023-01-03 10:51:38 --> Output Class Initialized
INFO - 2023-01-03 10:51:38 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:38 --> Input Class Initialized
INFO - 2023-01-03 10:51:38 --> Language Class Initialized
INFO - 2023-01-03 10:51:38 --> Loader Class Initialized
INFO - 2023-01-03 10:51:38 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:38 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:38 --> Total execution time: 0.1082
INFO - 2023-01-03 10:51:38 --> Config Class Initialized
INFO - 2023-01-03 10:51:38 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:38 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:38 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:38 --> URI Class Initialized
INFO - 2023-01-03 10:51:38 --> Router Class Initialized
INFO - 2023-01-03 10:51:38 --> Output Class Initialized
INFO - 2023-01-03 10:51:38 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:38 --> Input Class Initialized
INFO - 2023-01-03 10:51:38 --> Language Class Initialized
INFO - 2023-01-03 10:51:38 --> Loader Class Initialized
INFO - 2023-01-03 10:51:38 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:38 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:38 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:38 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:38 --> Total execution time: 0.1796
INFO - 2023-01-03 10:51:50 --> Config Class Initialized
INFO - 2023-01-03 10:51:50 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:50 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:50 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:50 --> URI Class Initialized
INFO - 2023-01-03 10:51:50 --> Router Class Initialized
INFO - 2023-01-03 10:51:50 --> Output Class Initialized
INFO - 2023-01-03 10:51:50 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:50 --> Input Class Initialized
INFO - 2023-01-03 10:51:50 --> Language Class Initialized
INFO - 2023-01-03 10:51:50 --> Loader Class Initialized
INFO - 2023-01-03 10:51:50 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:50 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:50 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:50 --> Model "Login_model" initialized
INFO - 2023-01-03 10:51:50 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:50 --> Total execution time: 0.1836
INFO - 2023-01-03 10:51:50 --> Config Class Initialized
INFO - 2023-01-03 10:51:50 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:50 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:50 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:50 --> URI Class Initialized
INFO - 2023-01-03 10:51:50 --> Router Class Initialized
INFO - 2023-01-03 10:51:50 --> Output Class Initialized
INFO - 2023-01-03 10:51:50 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:50 --> Input Class Initialized
INFO - 2023-01-03 10:51:50 --> Language Class Initialized
INFO - 2023-01-03 10:51:50 --> Loader Class Initialized
INFO - 2023-01-03 10:51:50 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:50 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:50 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:50 --> Model "Login_model" initialized
INFO - 2023-01-03 10:51:50 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:50 --> Total execution time: 0.1591
INFO - 2023-01-03 10:51:54 --> Config Class Initialized
INFO - 2023-01-03 10:51:54 --> Hooks Class Initialized
INFO - 2023-01-03 10:51:54 --> Config Class Initialized
INFO - 2023-01-03 10:51:54 --> Hooks Class Initialized
INFO - 2023-01-03 10:51:54 --> Config Class Initialized
INFO - 2023-01-03 10:51:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:54 --> Utf8 Class Initialized
DEBUG - 2023-01-03 10:51:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:54 --> URI Class Initialized
DEBUG - 2023-01-03 10:51:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:54 --> URI Class Initialized
INFO - 2023-01-03 10:51:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:54 --> Router Class Initialized
INFO - 2023-01-03 10:51:54 --> URI Class Initialized
INFO - 2023-01-03 10:51:54 --> Router Class Initialized
INFO - 2023-01-03 10:51:54 --> Output Class Initialized
INFO - 2023-01-03 10:51:54 --> Router Class Initialized
INFO - 2023-01-03 10:51:54 --> Security Class Initialized
INFO - 2023-01-03 10:51:54 --> Output Class Initialized
DEBUG - 2023-01-03 10:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:54 --> Input Class Initialized
INFO - 2023-01-03 10:51:54 --> Output Class Initialized
INFO - 2023-01-03 10:51:54 --> Security Class Initialized
INFO - 2023-01-03 10:51:54 --> Language Class Initialized
INFO - 2023-01-03 10:51:54 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:54 --> Input Class Initialized
DEBUG - 2023-01-03 10:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:54 --> Loader Class Initialized
INFO - 2023-01-03 10:51:54 --> Input Class Initialized
INFO - 2023-01-03 10:51:54 --> Language Class Initialized
INFO - 2023-01-03 10:51:54 --> Controller Class Initialized
INFO - 2023-01-03 10:51:54 --> Language Class Initialized
DEBUG - 2023-01-03 10:51:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:54 --> Loader Class Initialized
INFO - 2023-01-03 10:51:54 --> Loader Class Initialized
INFO - 2023-01-03 10:51:54 --> Controller Class Initialized
INFO - 2023-01-03 10:51:54 --> Database Driver Class Initialized
DEBUG - 2023-01-03 10:51:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:54 --> Controller Class Initialized
INFO - 2023-01-03 10:51:54 --> Final output sent to browser
INFO - 2023-01-03 10:51:54 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-03 10:51:54 --> Total execution time: 0.2845
DEBUG - 2023-01-03 10:51:54 --> Total execution time: 0.2903
INFO - 2023-01-03 10:51:54 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:54 --> Config Class Initialized
INFO - 2023-01-03 10:51:54 --> Model "Login_model" initialized
INFO - 2023-01-03 10:51:54 --> Config Class Initialized
INFO - 2023-01-03 10:51:54 --> Hooks Class Initialized
INFO - 2023-01-03 10:51:54 --> Hooks Class Initialized
INFO - 2023-01-03 10:51:54 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:54 --> Total execution time: 0.3773
DEBUG - 2023-01-03 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 10:51:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:54 --> Config Class Initialized
INFO - 2023-01-03 10:51:54 --> URI Class Initialized
INFO - 2023-01-03 10:51:54 --> URI Class Initialized
INFO - 2023-01-03 10:51:54 --> Hooks Class Initialized
INFO - 2023-01-03 10:51:54 --> Router Class Initialized
INFO - 2023-01-03 10:51:54 --> Router Class Initialized
INFO - 2023-01-03 10:51:54 --> Config Class Initialized
INFO - 2023-01-03 10:51:54 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:54 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:54 --> Output Class Initialized
INFO - 2023-01-03 10:51:54 --> Output Class Initialized
INFO - 2023-01-03 10:51:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:54 --> Security Class Initialized
INFO - 2023-01-03 10:51:54 --> Security Class Initialized
INFO - 2023-01-03 10:51:54 --> URI Class Initialized
DEBUG - 2023-01-03 10:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 10:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:54 --> Input Class Initialized
INFO - 2023-01-03 10:51:54 --> Input Class Initialized
INFO - 2023-01-03 10:51:54 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:54 --> Router Class Initialized
INFO - 2023-01-03 10:51:54 --> Language Class Initialized
INFO - 2023-01-03 10:51:54 --> Language Class Initialized
INFO - 2023-01-03 10:51:54 --> URI Class Initialized
INFO - 2023-01-03 10:51:55 --> Output Class Initialized
INFO - 2023-01-03 10:51:55 --> Loader Class Initialized
INFO - 2023-01-03 10:51:55 --> Loader Class Initialized
INFO - 2023-01-03 10:51:55 --> Router Class Initialized
INFO - 2023-01-03 10:51:55 --> Security Class Initialized
INFO - 2023-01-03 10:51:55 --> Controller Class Initialized
INFO - 2023-01-03 10:51:55 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:55 --> Output Class Initialized
DEBUG - 2023-01-03 10:51:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-03 10:51:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:55 --> Input Class Initialized
INFO - 2023-01-03 10:51:55 --> Security Class Initialized
INFO - 2023-01-03 10:51:55 --> Language Class Initialized
DEBUG - 2023-01-03 10:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:55 --> Input Class Initialized
INFO - 2023-01-03 10:51:55 --> Language Class Initialized
INFO - 2023-01-03 10:51:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:55 --> Final output sent to browser
INFO - 2023-01-03 10:51:55 --> Loader Class Initialized
INFO - 2023-01-03 10:51:55 --> Database Driver Class Initialized
DEBUG - 2023-01-03 10:51:55 --> Total execution time: 0.3978
INFO - 2023-01-03 10:51:55 --> Loader Class Initialized
INFO - 2023-01-03 10:51:55 --> Controller Class Initialized
INFO - 2023-01-03 10:51:55 --> Model "Login_model" initialized
INFO - 2023-01-03 10:51:55 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-03 10:51:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:55 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:51:55 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:55 --> Total execution time: 0.5004
INFO - 2023-01-03 10:51:55 --> Config Class Initialized
INFO - 2023-01-03 10:51:55 --> Hooks Class Initialized
INFO - 2023-01-03 10:51:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:55 --> Database Driver Class Initialized
DEBUG - 2023-01-03 10:51:55 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:55 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:55 --> Model "Login_model" initialized
INFO - 2023-01-03 10:51:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:55 --> URI Class Initialized
INFO - 2023-01-03 10:51:55 --> Final output sent to browser
INFO - 2023-01-03 10:51:55 --> Model "Login_model" initialized
INFO - 2023-01-03 10:51:55 --> Router Class Initialized
DEBUG - 2023-01-03 10:51:55 --> Total execution time: 0.4776
INFO - 2023-01-03 10:51:55 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:55 --> Total execution time: 0.5506
INFO - 2023-01-03 10:51:55 --> Output Class Initialized
INFO - 2023-01-03 10:51:55 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:55 --> Input Class Initialized
INFO - 2023-01-03 10:51:55 --> Language Class Initialized
INFO - 2023-01-03 10:51:55 --> Loader Class Initialized
INFO - 2023-01-03 10:51:55 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:51:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:55 --> Database Driver Class Initialized
INFO - 2023-01-03 10:51:55 --> Model "Login_model" initialized
INFO - 2023-01-03 10:51:55 --> Final output sent to browser
DEBUG - 2023-01-03 10:51:55 --> Total execution time: 0.2758
INFO - 2023-01-03 10:51:59 --> Config Class Initialized
INFO - 2023-01-03 10:51:59 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:51:59 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:51:59 --> Utf8 Class Initialized
INFO - 2023-01-03 10:51:59 --> URI Class Initialized
INFO - 2023-01-03 10:51:59 --> Router Class Initialized
INFO - 2023-01-03 10:51:59 --> Output Class Initialized
INFO - 2023-01-03 10:51:59 --> Security Class Initialized
DEBUG - 2023-01-03 10:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:51:59 --> Input Class Initialized
INFO - 2023-01-03 10:51:59 --> Language Class Initialized
INFO - 2023-01-03 10:51:59 --> Loader Class Initialized
INFO - 2023-01-03 10:51:59 --> Controller Class Initialized
DEBUG - 2023-01-03 10:51:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:00 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:00 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:00 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:00 --> Model "Login_model" initialized
INFO - 2023-01-03 10:52:00 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:00 --> Total execution time: 0.2600
INFO - 2023-01-03 10:52:00 --> Config Class Initialized
INFO - 2023-01-03 10:52:00 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:00 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:00 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:00 --> URI Class Initialized
INFO - 2023-01-03 10:52:00 --> Router Class Initialized
INFO - 2023-01-03 10:52:00 --> Output Class Initialized
INFO - 2023-01-03 10:52:00 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:00 --> Input Class Initialized
INFO - 2023-01-03 10:52:00 --> Language Class Initialized
INFO - 2023-01-03 10:52:00 --> Loader Class Initialized
INFO - 2023-01-03 10:52:00 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:00 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:00 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:00 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:00 --> Model "Login_model" initialized
INFO - 2023-01-03 10:52:00 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:00 --> Total execution time: 0.2563
INFO - 2023-01-03 10:52:14 --> Config Class Initialized
INFO - 2023-01-03 10:52:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:14 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:14 --> URI Class Initialized
INFO - 2023-01-03 10:52:14 --> Router Class Initialized
INFO - 2023-01-03 10:52:14 --> Output Class Initialized
INFO - 2023-01-03 10:52:14 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:14 --> Input Class Initialized
INFO - 2023-01-03 10:52:14 --> Language Class Initialized
INFO - 2023-01-03 10:52:14 --> Loader Class Initialized
INFO - 2023-01-03 10:52:14 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:14 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:14 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:14 --> Total execution time: 0.1846
INFO - 2023-01-03 10:52:14 --> Config Class Initialized
INFO - 2023-01-03 10:52:14 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:14 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:14 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:14 --> URI Class Initialized
INFO - 2023-01-03 10:52:14 --> Router Class Initialized
INFO - 2023-01-03 10:52:14 --> Output Class Initialized
INFO - 2023-01-03 10:52:14 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:14 --> Input Class Initialized
INFO - 2023-01-03 10:52:14 --> Language Class Initialized
INFO - 2023-01-03 10:52:14 --> Loader Class Initialized
INFO - 2023-01-03 10:52:14 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:14 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:14 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:14 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:14 --> Total execution time: 0.1891
INFO - 2023-01-03 10:52:15 --> Config Class Initialized
INFO - 2023-01-03 10:52:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:15 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:15 --> URI Class Initialized
INFO - 2023-01-03 10:52:15 --> Router Class Initialized
INFO - 2023-01-03 10:52:15 --> Output Class Initialized
INFO - 2023-01-03 10:52:15 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:15 --> Input Class Initialized
INFO - 2023-01-03 10:52:15 --> Language Class Initialized
INFO - 2023-01-03 10:52:15 --> Loader Class Initialized
INFO - 2023-01-03 10:52:15 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:15 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:15 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:15 --> Total execution time: 0.1934
INFO - 2023-01-03 10:52:15 --> Config Class Initialized
INFO - 2023-01-03 10:52:15 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:15 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:15 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:15 --> URI Class Initialized
INFO - 2023-01-03 10:52:15 --> Router Class Initialized
INFO - 2023-01-03 10:52:15 --> Output Class Initialized
INFO - 2023-01-03 10:52:15 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:15 --> Input Class Initialized
INFO - 2023-01-03 10:52:15 --> Language Class Initialized
INFO - 2023-01-03 10:52:15 --> Loader Class Initialized
INFO - 2023-01-03 10:52:15 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:15 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:15 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:15 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:15 --> Total execution time: 0.2054
INFO - 2023-01-03 10:52:25 --> Config Class Initialized
INFO - 2023-01-03 10:52:25 --> Hooks Class Initialized
INFO - 2023-01-03 10:52:25 --> Config Class Initialized
INFO - 2023-01-03 10:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:25 --> Utf8 Class Initialized
DEBUG - 2023-01-03 10:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:25 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:25 --> URI Class Initialized
INFO - 2023-01-03 10:52:25 --> URI Class Initialized
INFO - 2023-01-03 10:52:25 --> Router Class Initialized
INFO - 2023-01-03 10:52:25 --> Router Class Initialized
INFO - 2023-01-03 10:52:25 --> Output Class Initialized
INFO - 2023-01-03 10:52:25 --> Output Class Initialized
INFO - 2023-01-03 10:52:25 --> Security Class Initialized
INFO - 2023-01-03 10:52:25 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:26 --> Input Class Initialized
DEBUG - 2023-01-03 10:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:26 --> Language Class Initialized
INFO - 2023-01-03 10:52:26 --> Input Class Initialized
INFO - 2023-01-03 10:52:26 --> Language Class Initialized
INFO - 2023-01-03 10:52:26 --> Loader Class Initialized
INFO - 2023-01-03 10:52:26 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:26 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:26 --> Total execution time: 0.2365
INFO - 2023-01-03 10:52:26 --> Loader Class Initialized
INFO - 2023-01-03 10:52:26 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:26 --> Final output sent to browser
INFO - 2023-01-03 10:52:26 --> Config Class Initialized
DEBUG - 2023-01-03 10:52:26 --> Total execution time: 0.2814
INFO - 2023-01-03 10:52:26 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:26 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:26 --> Config Class Initialized
INFO - 2023-01-03 10:52:26 --> URI Class Initialized
INFO - 2023-01-03 10:52:26 --> Hooks Class Initialized
INFO - 2023-01-03 10:52:26 --> Router Class Initialized
DEBUG - 2023-01-03 10:52:26 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:26 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:26 --> Output Class Initialized
INFO - 2023-01-03 10:52:26 --> URI Class Initialized
INFO - 2023-01-03 10:52:26 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:26 --> Router Class Initialized
INFO - 2023-01-03 10:52:26 --> Input Class Initialized
INFO - 2023-01-03 10:52:26 --> Language Class Initialized
INFO - 2023-01-03 10:52:26 --> Output Class Initialized
INFO - 2023-01-03 10:52:26 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:26 --> Loader Class Initialized
INFO - 2023-01-03 10:52:26 --> Input Class Initialized
INFO - 2023-01-03 10:52:26 --> Language Class Initialized
INFO - 2023-01-03 10:52:26 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:26 --> Loader Class Initialized
INFO - 2023-01-03 10:52:26 --> Controller Class Initialized
INFO - 2023-01-03 10:52:26 --> Database Driver Class Initialized
DEBUG - 2023-01-03 10:52:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:26 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:26 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:26 --> Total execution time: 0.3069
INFO - 2023-01-03 10:52:26 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:26 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:26 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:26 --> Total execution time: 0.2965
INFO - 2023-01-03 10:52:31 --> Config Class Initialized
INFO - 2023-01-03 10:52:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:31 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:31 --> URI Class Initialized
INFO - 2023-01-03 10:52:31 --> Router Class Initialized
INFO - 2023-01-03 10:52:31 --> Output Class Initialized
INFO - 2023-01-03 10:52:31 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:31 --> Input Class Initialized
INFO - 2023-01-03 10:52:31 --> Language Class Initialized
INFO - 2023-01-03 10:52:31 --> Loader Class Initialized
INFO - 2023-01-03 10:52:31 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:31 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:31 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:31 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:31 --> Total execution time: 0.2052
INFO - 2023-01-03 10:52:31 --> Config Class Initialized
INFO - 2023-01-03 10:52:31 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:31 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:31 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:31 --> URI Class Initialized
INFO - 2023-01-03 10:52:31 --> Router Class Initialized
INFO - 2023-01-03 10:52:31 --> Output Class Initialized
INFO - 2023-01-03 10:52:31 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:31 --> Input Class Initialized
INFO - 2023-01-03 10:52:31 --> Language Class Initialized
INFO - 2023-01-03 10:52:31 --> Loader Class Initialized
INFO - 2023-01-03 10:52:31 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:31 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:31 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:31 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:31 --> Total execution time: 0.2244
INFO - 2023-01-03 10:52:48 --> Config Class Initialized
INFO - 2023-01-03 10:52:48 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:48 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:48 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:48 --> URI Class Initialized
INFO - 2023-01-03 10:52:48 --> Router Class Initialized
INFO - 2023-01-03 10:52:48 --> Output Class Initialized
INFO - 2023-01-03 10:52:48 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:48 --> Input Class Initialized
INFO - 2023-01-03 10:52:48 --> Language Class Initialized
INFO - 2023-01-03 10:52:48 --> Loader Class Initialized
INFO - 2023-01-03 10:52:48 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:48 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:48 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:48 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:48 --> Total execution time: 0.1840
INFO - 2023-01-03 10:52:48 --> Config Class Initialized
INFO - 2023-01-03 10:52:48 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:48 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:48 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:48 --> URI Class Initialized
INFO - 2023-01-03 10:52:48 --> Router Class Initialized
INFO - 2023-01-03 10:52:48 --> Output Class Initialized
INFO - 2023-01-03 10:52:48 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:48 --> Input Class Initialized
INFO - 2023-01-03 10:52:48 --> Language Class Initialized
INFO - 2023-01-03 10:52:48 --> Loader Class Initialized
INFO - 2023-01-03 10:52:48 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:48 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:48 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:48 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:48 --> Total execution time: 0.1536
INFO - 2023-01-03 10:52:50 --> Config Class Initialized
INFO - 2023-01-03 10:52:50 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:50 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:50 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:50 --> URI Class Initialized
INFO - 2023-01-03 10:52:50 --> Router Class Initialized
INFO - 2023-01-03 10:52:50 --> Output Class Initialized
INFO - 2023-01-03 10:52:50 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:50 --> Input Class Initialized
INFO - 2023-01-03 10:52:50 --> Language Class Initialized
INFO - 2023-01-03 10:52:50 --> Loader Class Initialized
INFO - 2023-01-03 10:52:50 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:50 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:50 --> Total execution time: 0.1041
INFO - 2023-01-03 10:52:50 --> Config Class Initialized
INFO - 2023-01-03 10:52:50 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:50 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:50 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:50 --> URI Class Initialized
INFO - 2023-01-03 10:52:50 --> Router Class Initialized
INFO - 2023-01-03 10:52:50 --> Output Class Initialized
INFO - 2023-01-03 10:52:50 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:51 --> Input Class Initialized
INFO - 2023-01-03 10:52:51 --> Language Class Initialized
INFO - 2023-01-03 10:52:51 --> Loader Class Initialized
INFO - 2023-01-03 10:52:51 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:51 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:51 --> Model "Login_model" initialized
INFO - 2023-01-03 10:52:51 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:51 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:51 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:51 --> Total execution time: 0.1751
INFO - 2023-01-03 10:52:51 --> Config Class Initialized
INFO - 2023-01-03 10:52:51 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:51 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:51 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:51 --> URI Class Initialized
INFO - 2023-01-03 10:52:51 --> Router Class Initialized
INFO - 2023-01-03 10:52:51 --> Output Class Initialized
INFO - 2023-01-03 10:52:51 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:51 --> Input Class Initialized
INFO - 2023-01-03 10:52:51 --> Language Class Initialized
INFO - 2023-01-03 10:52:51 --> Loader Class Initialized
INFO - 2023-01-03 10:52:51 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:51 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:51 --> Total execution time: 0.1062
INFO - 2023-01-03 10:52:51 --> Config Class Initialized
INFO - 2023-01-03 10:52:51 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:51 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:51 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:51 --> URI Class Initialized
INFO - 2023-01-03 10:52:51 --> Router Class Initialized
INFO - 2023-01-03 10:52:51 --> Output Class Initialized
INFO - 2023-01-03 10:52:51 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:51 --> Input Class Initialized
INFO - 2023-01-03 10:52:51 --> Language Class Initialized
INFO - 2023-01-03 10:52:51 --> Loader Class Initialized
INFO - 2023-01-03 10:52:51 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:51 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:51 --> Model "Login_model" initialized
INFO - 2023-01-03 10:52:51 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:51 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:51 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:51 --> Total execution time: 0.1662
INFO - 2023-01-03 10:52:53 --> Config Class Initialized
INFO - 2023-01-03 10:52:53 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:53 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:53 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:53 --> URI Class Initialized
INFO - 2023-01-03 10:52:53 --> Router Class Initialized
INFO - 2023-01-03 10:52:53 --> Output Class Initialized
INFO - 2023-01-03 10:52:53 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:53 --> Input Class Initialized
INFO - 2023-01-03 10:52:53 --> Language Class Initialized
INFO - 2023-01-03 10:52:53 --> Loader Class Initialized
INFO - 2023-01-03 10:52:53 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:53 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:53 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:53 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:53 --> Model "Login_model" initialized
INFO - 2023-01-03 10:52:53 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:53 --> Total execution time: 0.2834
INFO - 2023-01-03 10:52:53 --> Config Class Initialized
INFO - 2023-01-03 10:52:53 --> Hooks Class Initialized
DEBUG - 2023-01-03 10:52:53 --> UTF-8 Support Enabled
INFO - 2023-01-03 10:52:53 --> Utf8 Class Initialized
INFO - 2023-01-03 10:52:53 --> URI Class Initialized
INFO - 2023-01-03 10:52:53 --> Router Class Initialized
INFO - 2023-01-03 10:52:53 --> Output Class Initialized
INFO - 2023-01-03 10:52:53 --> Security Class Initialized
DEBUG - 2023-01-03 10:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-03 10:52:53 --> Input Class Initialized
INFO - 2023-01-03 10:52:53 --> Language Class Initialized
INFO - 2023-01-03 10:52:53 --> Loader Class Initialized
INFO - 2023-01-03 10:52:53 --> Controller Class Initialized
DEBUG - 2023-01-03 10:52:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-03 10:52:53 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:53 --> Model "Cluster_model" initialized
INFO - 2023-01-03 10:52:53 --> Database Driver Class Initialized
INFO - 2023-01-03 10:52:53 --> Model "Login_model" initialized
INFO - 2023-01-03 10:52:53 --> Final output sent to browser
DEBUG - 2023-01-03 10:52:53 --> Total execution time: 0.2556
