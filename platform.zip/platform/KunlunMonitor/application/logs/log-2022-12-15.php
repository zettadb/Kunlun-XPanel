<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-15 03:26:49 --> Config Class Initialized
INFO - 2022-12-15 03:26:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:49 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:49 --> URI Class Initialized
INFO - 2022-12-15 03:26:49 --> Router Class Initialized
INFO - 2022-12-15 03:26:49 --> Output Class Initialized
INFO - 2022-12-15 03:26:49 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:49 --> Input Class Initialized
INFO - 2022-12-15 03:26:49 --> Language Class Initialized
INFO - 2022-12-15 03:26:49 --> Loader Class Initialized
INFO - 2022-12-15 03:26:49 --> Controller Class Initialized
INFO - 2022-12-15 03:26:49 --> Helper loaded: form_helper
INFO - 2022-12-15 03:26:49 --> Helper loaded: url_helper
DEBUG - 2022-12-15 03:26:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:49 --> Model "Change_model" initialized
INFO - 2022-12-15 03:26:49 --> Model "Grafana_model" initialized
INFO - 2022-12-15 03:26:49 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:49 --> Total execution time: 0.0947
INFO - 2022-12-15 03:26:49 --> Config Class Initialized
INFO - 2022-12-15 03:26:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:49 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:49 --> URI Class Initialized
INFO - 2022-12-15 03:26:49 --> Router Class Initialized
INFO - 2022-12-15 03:26:49 --> Output Class Initialized
INFO - 2022-12-15 03:26:49 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:49 --> Input Class Initialized
INFO - 2022-12-15 03:26:49 --> Language Class Initialized
INFO - 2022-12-15 03:26:49 --> Loader Class Initialized
INFO - 2022-12-15 03:26:49 --> Controller Class Initialized
INFO - 2022-12-15 03:26:49 --> Helper loaded: form_helper
INFO - 2022-12-15 03:26:49 --> Helper loaded: url_helper
DEBUG - 2022-12-15 03:26:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:49 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:49 --> Total execution time: 0.0219
INFO - 2022-12-15 03:26:49 --> Config Class Initialized
INFO - 2022-12-15 03:26:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:49 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:49 --> URI Class Initialized
INFO - 2022-12-15 03:26:49 --> Router Class Initialized
INFO - 2022-12-15 03:26:49 --> Output Class Initialized
INFO - 2022-12-15 03:26:49 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:49 --> Input Class Initialized
INFO - 2022-12-15 03:26:49 --> Language Class Initialized
INFO - 2022-12-15 03:26:49 --> Loader Class Initialized
INFO - 2022-12-15 03:26:49 --> Controller Class Initialized
INFO - 2022-12-15 03:26:49 --> Helper loaded: form_helper
INFO - 2022-12-15 03:26:49 --> Helper loaded: url_helper
DEBUG - 2022-12-15 03:26:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:49 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:49 --> Model "Login_model" initialized
INFO - 2022-12-15 03:26:49 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:49 --> Total execution time: 0.1636
INFO - 2022-12-15 03:26:49 --> Config Class Initialized
INFO - 2022-12-15 03:26:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:49 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:49 --> URI Class Initialized
INFO - 2022-12-15 03:26:49 --> Router Class Initialized
INFO - 2022-12-15 03:26:49 --> Output Class Initialized
INFO - 2022-12-15 03:26:49 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:49 --> Input Class Initialized
INFO - 2022-12-15 03:26:49 --> Language Class Initialized
INFO - 2022-12-15 03:26:49 --> Loader Class Initialized
INFO - 2022-12-15 03:26:49 --> Controller Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:49 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:49 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:26:49 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:49 --> Total execution time: 0.0584
INFO - 2022-12-15 03:26:49 --> Config Class Initialized
INFO - 2022-12-15 03:26:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:49 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:49 --> URI Class Initialized
INFO - 2022-12-15 03:26:49 --> Router Class Initialized
INFO - 2022-12-15 03:26:49 --> Output Class Initialized
INFO - 2022-12-15 03:26:49 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:49 --> Input Class Initialized
INFO - 2022-12-15 03:26:49 --> Language Class Initialized
INFO - 2022-12-15 03:26:49 --> Loader Class Initialized
INFO - 2022-12-15 03:26:49 --> Controller Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:49 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:49 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:26:49 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:49 --> Total execution time: 0.0692
INFO - 2022-12-15 03:26:49 --> Config Class Initialized
INFO - 2022-12-15 03:26:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:49 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:49 --> URI Class Initialized
INFO - 2022-12-15 03:26:49 --> Router Class Initialized
INFO - 2022-12-15 03:26:49 --> Output Class Initialized
INFO - 2022-12-15 03:26:49 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:49 --> Input Class Initialized
INFO - 2022-12-15 03:26:49 --> Language Class Initialized
INFO - 2022-12-15 03:26:49 --> Loader Class Initialized
INFO - 2022-12-15 03:26:49 --> Controller Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:49 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:49 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:26:49 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:49 --> Model "Login_model" initialized
INFO - 2022-12-15 03:26:49 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:49 --> Total execution time: 0.1974
INFO - 2022-12-15 03:26:49 --> Config Class Initialized
INFO - 2022-12-15 03:26:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:49 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:49 --> URI Class Initialized
INFO - 2022-12-15 03:26:49 --> Router Class Initialized
INFO - 2022-12-15 03:26:49 --> Output Class Initialized
INFO - 2022-12-15 03:26:49 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:49 --> Input Class Initialized
INFO - 2022-12-15 03:26:49 --> Language Class Initialized
INFO - 2022-12-15 03:26:49 --> Loader Class Initialized
INFO - 2022-12-15 03:26:50 --> Controller Class Initialized
DEBUG - 2022-12-15 03:26:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:50 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:50 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:26:50 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:50 --> Model "Login_model" initialized
INFO - 2022-12-15 03:26:50 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:50 --> Total execution time: 0.1309
INFO - 2022-12-15 03:26:55 --> Config Class Initialized
INFO - 2022-12-15 03:26:55 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:55 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:55 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:55 --> URI Class Initialized
INFO - 2022-12-15 03:26:55 --> Router Class Initialized
INFO - 2022-12-15 03:26:55 --> Output Class Initialized
INFO - 2022-12-15 03:26:55 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:55 --> Input Class Initialized
INFO - 2022-12-15 03:26:55 --> Language Class Initialized
INFO - 2022-12-15 03:26:55 --> Loader Class Initialized
INFO - 2022-12-15 03:26:55 --> Controller Class Initialized
DEBUG - 2022-12-15 03:26:55 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:55 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:55 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:26:55 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:55 --> Total execution time: 0.0628
INFO - 2022-12-15 03:26:55 --> Config Class Initialized
INFO - 2022-12-15 03:26:55 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:26:55 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:26:55 --> Utf8 Class Initialized
INFO - 2022-12-15 03:26:55 --> URI Class Initialized
INFO - 2022-12-15 03:26:55 --> Router Class Initialized
INFO - 2022-12-15 03:26:55 --> Output Class Initialized
INFO - 2022-12-15 03:26:55 --> Security Class Initialized
DEBUG - 2022-12-15 03:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:26:55 --> Input Class Initialized
INFO - 2022-12-15 03:26:55 --> Language Class Initialized
INFO - 2022-12-15 03:26:55 --> Loader Class Initialized
INFO - 2022-12-15 03:26:55 --> Controller Class Initialized
DEBUG - 2022-12-15 03:26:55 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:26:55 --> Database Driver Class Initialized
INFO - 2022-12-15 03:26:55 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:26:55 --> Final output sent to browser
DEBUG - 2022-12-15 03:26:55 --> Total execution time: 0.0386
INFO - 2022-12-15 03:29:14 --> Config Class Initialized
INFO - 2022-12-15 03:29:14 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:29:14 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:29:14 --> Utf8 Class Initialized
INFO - 2022-12-15 03:29:14 --> URI Class Initialized
INFO - 2022-12-15 03:29:14 --> Router Class Initialized
INFO - 2022-12-15 03:29:14 --> Output Class Initialized
INFO - 2022-12-15 03:29:14 --> Security Class Initialized
DEBUG - 2022-12-15 03:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:29:14 --> Input Class Initialized
INFO - 2022-12-15 03:29:14 --> Language Class Initialized
INFO - 2022-12-15 03:29:14 --> Loader Class Initialized
INFO - 2022-12-15 03:29:14 --> Controller Class Initialized
DEBUG - 2022-12-15 03:29:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:29:14 --> Database Driver Class Initialized
INFO - 2022-12-15 03:29:14 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:29:14 --> Final output sent to browser
DEBUG - 2022-12-15 03:29:14 --> Total execution time: 0.0551
INFO - 2022-12-15 03:29:14 --> Config Class Initialized
INFO - 2022-12-15 03:29:14 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:29:14 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:29:14 --> Utf8 Class Initialized
INFO - 2022-12-15 03:29:14 --> URI Class Initialized
INFO - 2022-12-15 03:29:14 --> Router Class Initialized
INFO - 2022-12-15 03:29:14 --> Output Class Initialized
INFO - 2022-12-15 03:29:14 --> Security Class Initialized
DEBUG - 2022-12-15 03:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:29:14 --> Input Class Initialized
INFO - 2022-12-15 03:29:14 --> Language Class Initialized
INFO - 2022-12-15 03:29:14 --> Loader Class Initialized
INFO - 2022-12-15 03:29:14 --> Controller Class Initialized
DEBUG - 2022-12-15 03:29:14 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:29:14 --> Database Driver Class Initialized
INFO - 2022-12-15 03:29:14 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:29:14 --> Final output sent to browser
DEBUG - 2022-12-15 03:29:14 --> Total execution time: 0.0585
INFO - 2022-12-15 03:29:17 --> Config Class Initialized
INFO - 2022-12-15 03:29:17 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:29:17 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:29:17 --> Utf8 Class Initialized
INFO - 2022-12-15 03:29:17 --> URI Class Initialized
INFO - 2022-12-15 03:29:17 --> Router Class Initialized
INFO - 2022-12-15 03:29:17 --> Output Class Initialized
INFO - 2022-12-15 03:29:17 --> Security Class Initialized
DEBUG - 2022-12-15 03:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:29:17 --> Input Class Initialized
INFO - 2022-12-15 03:29:17 --> Language Class Initialized
INFO - 2022-12-15 03:29:17 --> Loader Class Initialized
INFO - 2022-12-15 03:29:17 --> Controller Class Initialized
DEBUG - 2022-12-15 03:29:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:29:17 --> Database Driver Class Initialized
INFO - 2022-12-15 03:29:17 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:29:17 --> Final output sent to browser
DEBUG - 2022-12-15 03:29:17 --> Total execution time: 0.0587
INFO - 2022-12-15 03:29:17 --> Config Class Initialized
INFO - 2022-12-15 03:29:17 --> Hooks Class Initialized
DEBUG - 2022-12-15 03:29:17 --> UTF-8 Support Enabled
INFO - 2022-12-15 03:29:17 --> Utf8 Class Initialized
INFO - 2022-12-15 03:29:17 --> URI Class Initialized
INFO - 2022-12-15 03:29:17 --> Router Class Initialized
INFO - 2022-12-15 03:29:17 --> Output Class Initialized
INFO - 2022-12-15 03:29:17 --> Security Class Initialized
DEBUG - 2022-12-15 03:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 03:29:17 --> Input Class Initialized
INFO - 2022-12-15 03:29:17 --> Language Class Initialized
INFO - 2022-12-15 03:29:17 --> Loader Class Initialized
INFO - 2022-12-15 03:29:17 --> Controller Class Initialized
DEBUG - 2022-12-15 03:29:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 03:29:17 --> Database Driver Class Initialized
INFO - 2022-12-15 03:29:17 --> Model "Cluster_model" initialized
INFO - 2022-12-15 03:29:17 --> Final output sent to browser
DEBUG - 2022-12-15 03:29:17 --> Total execution time: 0.0531
INFO - 2022-12-15 04:19:28 --> Config Class Initialized
INFO - 2022-12-15 04:19:28 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:28 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:28 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:28 --> URI Class Initialized
INFO - 2022-12-15 04:19:28 --> Router Class Initialized
INFO - 2022-12-15 04:19:28 --> Output Class Initialized
INFO - 2022-12-15 04:19:28 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:28 --> Input Class Initialized
INFO - 2022-12-15 04:19:28 --> Language Class Initialized
INFO - 2022-12-15 04:19:28 --> Loader Class Initialized
INFO - 2022-12-15 04:19:28 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:28 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:28 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:28 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:28 --> Model "Login_model" initialized
INFO - 2022-12-15 04:19:28 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:28 --> Total execution time: 0.4131
INFO - 2022-12-15 04:19:28 --> Config Class Initialized
INFO - 2022-12-15 04:19:28 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:28 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:28 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:28 --> URI Class Initialized
INFO - 2022-12-15 04:19:28 --> Router Class Initialized
INFO - 2022-12-15 04:19:28 --> Output Class Initialized
INFO - 2022-12-15 04:19:28 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:28 --> Input Class Initialized
INFO - 2022-12-15 04:19:28 --> Language Class Initialized
INFO - 2022-12-15 04:19:28 --> Loader Class Initialized
INFO - 2022-12-15 04:19:28 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:28 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:28 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:28 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:28 --> Model "Login_model" initialized
INFO - 2022-12-15 04:19:28 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:28 --> Total execution time: 0.0888
INFO - 2022-12-15 04:19:35 --> Config Class Initialized
INFO - 2022-12-15 04:19:35 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:35 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:35 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:35 --> URI Class Initialized
INFO - 2022-12-15 04:19:35 --> Router Class Initialized
INFO - 2022-12-15 04:19:35 --> Output Class Initialized
INFO - 2022-12-15 04:19:35 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:35 --> Input Class Initialized
INFO - 2022-12-15 04:19:35 --> Language Class Initialized
INFO - 2022-12-15 04:19:35 --> Loader Class Initialized
INFO - 2022-12-15 04:19:35 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:35 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:35 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:35 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:35 --> Total execution time: 0.0507
INFO - 2022-12-15 04:19:35 --> Config Class Initialized
INFO - 2022-12-15 04:19:35 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:35 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:35 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:35 --> URI Class Initialized
INFO - 2022-12-15 04:19:35 --> Router Class Initialized
INFO - 2022-12-15 04:19:35 --> Output Class Initialized
INFO - 2022-12-15 04:19:35 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:35 --> Input Class Initialized
INFO - 2022-12-15 04:19:35 --> Language Class Initialized
INFO - 2022-12-15 04:19:35 --> Loader Class Initialized
INFO - 2022-12-15 04:19:35 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:35 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:35 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:35 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:35 --> Total execution time: 0.0567
INFO - 2022-12-15 04:19:37 --> Config Class Initialized
INFO - 2022-12-15 04:19:37 --> Hooks Class Initialized
INFO - 2022-12-15 04:19:37 --> Config Class Initialized
INFO - 2022-12-15 04:19:37 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:37 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:37 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:37 --> URI Class Initialized
DEBUG - 2022-12-15 04:19:37 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:37 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:37 --> Router Class Initialized
INFO - 2022-12-15 04:19:37 --> URI Class Initialized
INFO - 2022-12-15 04:19:37 --> Output Class Initialized
INFO - 2022-12-15 04:19:37 --> Router Class Initialized
INFO - 2022-12-15 04:19:37 --> Security Class Initialized
INFO - 2022-12-15 04:19:37 --> Output Class Initialized
DEBUG - 2022-12-15 04:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:37 --> Input Class Initialized
INFO - 2022-12-15 04:19:37 --> Language Class Initialized
INFO - 2022-12-15 04:19:37 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:37 --> Input Class Initialized
INFO - 2022-12-15 04:19:37 --> Language Class Initialized
INFO - 2022-12-15 04:19:37 --> Loader Class Initialized
INFO - 2022-12-15 04:19:37 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:37 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:37 --> Total execution time: 0.0237
INFO - 2022-12-15 04:19:37 --> Loader Class Initialized
INFO - 2022-12-15 04:19:37 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:37 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:37 --> Config Class Initialized
INFO - 2022-12-15 04:19:37 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:37 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:37 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:37 --> URI Class Initialized
INFO - 2022-12-15 04:19:37 --> Router Class Initialized
INFO - 2022-12-15 04:19:37 --> Output Class Initialized
INFO - 2022-12-15 04:19:37 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:37 --> Input Class Initialized
INFO - 2022-12-15 04:19:37 --> Language Class Initialized
INFO - 2022-12-15 04:19:37 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:37 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:37 --> Total execution time: 0.0466
INFO - 2022-12-15 04:19:37 --> Loader Class Initialized
INFO - 2022-12-15 04:19:37 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:37 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:37 --> Config Class Initialized
INFO - 2022-12-15 04:19:37 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:37 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:37 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:37 --> URI Class Initialized
INFO - 2022-12-15 04:19:37 --> Router Class Initialized
INFO - 2022-12-15 04:19:37 --> Output Class Initialized
INFO - 2022-12-15 04:19:37 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:37 --> Input Class Initialized
INFO - 2022-12-15 04:19:37 --> Language Class Initialized
INFO - 2022-12-15 04:19:37 --> Loader Class Initialized
INFO - 2022-12-15 04:19:37 --> Controller Class Initialized
INFO - 2022-12-15 04:19:37 --> Model "Cluster_model" initialized
DEBUG - 2022-12-15 04:19:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:37 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:37 --> Total execution time: 0.0489
INFO - 2022-12-15 04:19:37 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:37 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:37 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:37 --> Total execution time: 0.0347
INFO - 2022-12-15 04:19:38 --> Config Class Initialized
INFO - 2022-12-15 04:19:38 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:38 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:38 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:38 --> URI Class Initialized
INFO - 2022-12-15 04:19:38 --> Router Class Initialized
INFO - 2022-12-15 04:19:38 --> Output Class Initialized
INFO - 2022-12-15 04:19:38 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:38 --> Input Class Initialized
INFO - 2022-12-15 04:19:38 --> Language Class Initialized
INFO - 2022-12-15 04:19:38 --> Loader Class Initialized
INFO - 2022-12-15 04:19:38 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:38 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:38 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:38 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:38 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:38 --> Total execution time: 0.0462
INFO - 2022-12-15 04:19:39 --> Config Class Initialized
INFO - 2022-12-15 04:19:39 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:39 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:39 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:39 --> URI Class Initialized
INFO - 2022-12-15 04:19:39 --> Router Class Initialized
INFO - 2022-12-15 04:19:39 --> Output Class Initialized
INFO - 2022-12-15 04:19:39 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:39 --> Input Class Initialized
INFO - 2022-12-15 04:19:39 --> Language Class Initialized
INFO - 2022-12-15 04:19:39 --> Loader Class Initialized
INFO - 2022-12-15 04:19:39 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:39 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:39 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:39 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:39 --> Total execution time: 0.0439
INFO - 2022-12-15 04:19:39 --> Config Class Initialized
INFO - 2022-12-15 04:19:39 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:39 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:39 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:39 --> URI Class Initialized
INFO - 2022-12-15 04:19:39 --> Router Class Initialized
INFO - 2022-12-15 04:19:39 --> Output Class Initialized
INFO - 2022-12-15 04:19:39 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:39 --> Input Class Initialized
INFO - 2022-12-15 04:19:39 --> Language Class Initialized
INFO - 2022-12-15 04:19:39 --> Loader Class Initialized
INFO - 2022-12-15 04:19:39 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:39 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:39 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:39 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:39 --> Total execution time: 0.0557
INFO - 2022-12-15 04:19:39 --> Config Class Initialized
INFO - 2022-12-15 04:19:39 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:39 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:39 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:39 --> URI Class Initialized
INFO - 2022-12-15 04:19:39 --> Router Class Initialized
INFO - 2022-12-15 04:19:39 --> Output Class Initialized
INFO - 2022-12-15 04:19:39 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:39 --> Input Class Initialized
INFO - 2022-12-15 04:19:39 --> Language Class Initialized
INFO - 2022-12-15 04:19:39 --> Loader Class Initialized
INFO - 2022-12-15 04:19:39 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:39 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:40 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:40 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:40 --> Total execution time: 0.0444
INFO - 2022-12-15 04:19:40 --> Config Class Initialized
INFO - 2022-12-15 04:19:40 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:40 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:40 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:40 --> URI Class Initialized
INFO - 2022-12-15 04:19:40 --> Router Class Initialized
INFO - 2022-12-15 04:19:40 --> Output Class Initialized
INFO - 2022-12-15 04:19:40 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:40 --> Input Class Initialized
INFO - 2022-12-15 04:19:40 --> Language Class Initialized
INFO - 2022-12-15 04:19:40 --> Loader Class Initialized
INFO - 2022-12-15 04:19:40 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:40 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:40 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:40 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:40 --> Total execution time: 0.0562
INFO - 2022-12-15 04:19:41 --> Config Class Initialized
INFO - 2022-12-15 04:19:41 --> Hooks Class Initialized
INFO - 2022-12-15 04:19:41 --> Config Class Initialized
INFO - 2022-12-15 04:19:41 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:41 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:41 --> Utf8 Class Initialized
DEBUG - 2022-12-15 04:19:41 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:41 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:41 --> URI Class Initialized
INFO - 2022-12-15 04:19:41 --> URI Class Initialized
INFO - 2022-12-15 04:19:41 --> Router Class Initialized
INFO - 2022-12-15 04:19:41 --> Router Class Initialized
INFO - 2022-12-15 04:19:41 --> Output Class Initialized
INFO - 2022-12-15 04:19:41 --> Output Class Initialized
INFO - 2022-12-15 04:19:41 --> Security Class Initialized
INFO - 2022-12-15 04:19:41 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:41 --> Input Class Initialized
DEBUG - 2022-12-15 04:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:41 --> Input Class Initialized
INFO - 2022-12-15 04:19:41 --> Language Class Initialized
INFO - 2022-12-15 04:19:41 --> Language Class Initialized
INFO - 2022-12-15 04:19:41 --> Loader Class Initialized
INFO - 2022-12-15 04:19:41 --> Controller Class Initialized
INFO - 2022-12-15 04:19:41 --> Loader Class Initialized
DEBUG - 2022-12-15 04:19:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:41 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:41 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:41 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:41 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:41 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:41 --> Final output sent to browser
INFO - 2022-12-15 04:19:41 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:41 --> Total execution time: 0.0539
DEBUG - 2022-12-15 04:19:41 --> Total execution time: 0.0541
INFO - 2022-12-15 04:19:42 --> Config Class Initialized
INFO - 2022-12-15 04:19:42 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:42 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:42 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:42 --> URI Class Initialized
INFO - 2022-12-15 04:19:42 --> Router Class Initialized
INFO - 2022-12-15 04:19:42 --> Output Class Initialized
INFO - 2022-12-15 04:19:42 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:42 --> Input Class Initialized
INFO - 2022-12-15 04:19:42 --> Language Class Initialized
INFO - 2022-12-15 04:19:42 --> Loader Class Initialized
INFO - 2022-12-15 04:19:42 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:42 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:42 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:42 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:42 --> Total execution time: 0.0712
INFO - 2022-12-15 04:19:42 --> Config Class Initialized
INFO - 2022-12-15 04:19:42 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:42 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:42 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:42 --> URI Class Initialized
INFO - 2022-12-15 04:19:42 --> Router Class Initialized
INFO - 2022-12-15 04:19:42 --> Output Class Initialized
INFO - 2022-12-15 04:19:42 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:42 --> Input Class Initialized
INFO - 2022-12-15 04:19:42 --> Language Class Initialized
INFO - 2022-12-15 04:19:42 --> Loader Class Initialized
INFO - 2022-12-15 04:19:42 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:42 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:42 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:42 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:42 --> Total execution time: 0.0584
INFO - 2022-12-15 04:19:44 --> Config Class Initialized
INFO - 2022-12-15 04:19:44 --> Config Class Initialized
INFO - 2022-12-15 04:19:44 --> Hooks Class Initialized
INFO - 2022-12-15 04:19:44 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-15 04:19:44 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:44 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:44 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:44 --> URI Class Initialized
INFO - 2022-12-15 04:19:44 --> URI Class Initialized
INFO - 2022-12-15 04:19:44 --> Router Class Initialized
INFO - 2022-12-15 04:19:44 --> Router Class Initialized
INFO - 2022-12-15 04:19:44 --> Output Class Initialized
INFO - 2022-12-15 04:19:44 --> Output Class Initialized
INFO - 2022-12-15 04:19:44 --> Security Class Initialized
INFO - 2022-12-15 04:19:44 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:44 --> Input Class Initialized
DEBUG - 2022-12-15 04:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:44 --> Input Class Initialized
INFO - 2022-12-15 04:19:44 --> Language Class Initialized
INFO - 2022-12-15 04:19:44 --> Language Class Initialized
INFO - 2022-12-15 04:19:44 --> Loader Class Initialized
INFO - 2022-12-15 04:19:44 --> Loader Class Initialized
INFO - 2022-12-15 04:19:44 --> Controller Class Initialized
INFO - 2022-12-15 04:19:44 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-15 04:19:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:44 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:44 --> Total execution time: 0.0247
INFO - 2022-12-15 04:19:44 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:44 --> Config Class Initialized
INFO - 2022-12-15 04:19:44 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:44 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:44 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:44 --> URI Class Initialized
INFO - 2022-12-15 04:19:44 --> Router Class Initialized
INFO - 2022-12-15 04:19:44 --> Output Class Initialized
INFO - 2022-12-15 04:19:44 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:44 --> Input Class Initialized
INFO - 2022-12-15 04:19:44 --> Language Class Initialized
INFO - 2022-12-15 04:19:44 --> Loader Class Initialized
INFO - 2022-12-15 04:19:44 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:44 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:44 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:44 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:44 --> Total execution time: 0.0617
INFO - 2022-12-15 04:19:44 --> Config Class Initialized
INFO - 2022-12-15 04:19:44 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:44 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:44 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:44 --> URI Class Initialized
INFO - 2022-12-15 04:19:44 --> Router Class Initialized
INFO - 2022-12-15 04:19:44 --> Output Class Initialized
INFO - 2022-12-15 04:19:44 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:44 --> Input Class Initialized
INFO - 2022-12-15 04:19:44 --> Language Class Initialized
INFO - 2022-12-15 04:19:44 --> Loader Class Initialized
INFO - 2022-12-15 04:19:44 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:44 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:44 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:44 --> Total execution time: 0.0583
INFO - 2022-12-15 04:19:44 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:44 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:44 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:44 --> Total execution time: 0.2069
INFO - 2022-12-15 04:19:45 --> Config Class Initialized
INFO - 2022-12-15 04:19:45 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:45 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:45 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:45 --> URI Class Initialized
INFO - 2022-12-15 04:19:45 --> Router Class Initialized
INFO - 2022-12-15 04:19:45 --> Output Class Initialized
INFO - 2022-12-15 04:19:45 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:45 --> Input Class Initialized
INFO - 2022-12-15 04:19:45 --> Language Class Initialized
INFO - 2022-12-15 04:19:45 --> Loader Class Initialized
INFO - 2022-12-15 04:19:45 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:45 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:45 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:46 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:46 --> Total execution time: 0.2589
INFO - 2022-12-15 04:19:50 --> Config Class Initialized
INFO - 2022-12-15 04:19:50 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:50 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:50 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:50 --> URI Class Initialized
INFO - 2022-12-15 04:19:50 --> Router Class Initialized
INFO - 2022-12-15 04:19:50 --> Output Class Initialized
INFO - 2022-12-15 04:19:50 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:50 --> Input Class Initialized
INFO - 2022-12-15 04:19:50 --> Language Class Initialized
INFO - 2022-12-15 04:19:50 --> Loader Class Initialized
INFO - 2022-12-15 04:19:50 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:50 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:50 --> Total execution time: 0.0199
INFO - 2022-12-15 04:19:50 --> Config Class Initialized
INFO - 2022-12-15 04:19:50 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:50 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:50 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:50 --> URI Class Initialized
INFO - 2022-12-15 04:19:50 --> Router Class Initialized
INFO - 2022-12-15 04:19:50 --> Output Class Initialized
INFO - 2022-12-15 04:19:50 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:50 --> Input Class Initialized
INFO - 2022-12-15 04:19:50 --> Language Class Initialized
INFO - 2022-12-15 04:19:50 --> Loader Class Initialized
INFO - 2022-12-15 04:19:50 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:50 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:50 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:50 --> Model "Mysql_model" initialized
INFO - 2022-12-15 04:19:50 --> Model "Grafana_model" initialized
ERROR - 2022-12-15 04:19:50 --> Exception of type 'TypeError' occurred with Message: count(): Argument #1 ($value) must be of type Countable|array, null given in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Grafana.php at Line 51
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Grafana->mysqlDashboard()
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#2 {main}
INFO - 2022-12-15 04:19:54 --> Config Class Initialized
INFO - 2022-12-15 04:19:54 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:54 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:54 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:54 --> URI Class Initialized
INFO - 2022-12-15 04:19:54 --> Router Class Initialized
INFO - 2022-12-15 04:19:54 --> Output Class Initialized
INFO - 2022-12-15 04:19:54 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:54 --> Input Class Initialized
INFO - 2022-12-15 04:19:54 --> Language Class Initialized
INFO - 2022-12-15 04:19:54 --> Loader Class Initialized
INFO - 2022-12-15 04:19:54 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:54 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:54 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:54 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:54 --> Total execution time: 0.0469
INFO - 2022-12-15 04:19:54 --> Config Class Initialized
INFO - 2022-12-15 04:19:54 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:19:54 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:19:54 --> Utf8 Class Initialized
INFO - 2022-12-15 04:19:54 --> URI Class Initialized
INFO - 2022-12-15 04:19:54 --> Router Class Initialized
INFO - 2022-12-15 04:19:54 --> Output Class Initialized
INFO - 2022-12-15 04:19:54 --> Security Class Initialized
DEBUG - 2022-12-15 04:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:19:54 --> Input Class Initialized
INFO - 2022-12-15 04:19:54 --> Language Class Initialized
INFO - 2022-12-15 04:19:54 --> Loader Class Initialized
INFO - 2022-12-15 04:19:54 --> Controller Class Initialized
DEBUG - 2022-12-15 04:19:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:19:54 --> Database Driver Class Initialized
INFO - 2022-12-15 04:19:54 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:19:54 --> Final output sent to browser
DEBUG - 2022-12-15 04:19:54 --> Total execution time: 0.0386
INFO - 2022-12-15 04:20:04 --> Config Class Initialized
INFO - 2022-12-15 04:20:04 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:04 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:04 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:04 --> URI Class Initialized
INFO - 2022-12-15 04:20:04 --> Router Class Initialized
INFO - 2022-12-15 04:20:04 --> Output Class Initialized
INFO - 2022-12-15 04:20:04 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:04 --> Input Class Initialized
INFO - 2022-12-15 04:20:04 --> Language Class Initialized
INFO - 2022-12-15 04:20:04 --> Loader Class Initialized
INFO - 2022-12-15 04:20:04 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:04 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:04 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:04 --> Total execution time: 0.0185
INFO - 2022-12-15 04:20:04 --> Config Class Initialized
INFO - 2022-12-15 04:20:04 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:04 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:04 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:04 --> URI Class Initialized
INFO - 2022-12-15 04:20:04 --> Router Class Initialized
INFO - 2022-12-15 04:20:04 --> Output Class Initialized
INFO - 2022-12-15 04:20:04 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:04 --> Input Class Initialized
INFO - 2022-12-15 04:20:04 --> Language Class Initialized
INFO - 2022-12-15 04:20:04 --> Loader Class Initialized
INFO - 2022-12-15 04:20:04 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:04 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:04 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:04 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:04 --> Model "PGsql_model" initialized
INFO - 2022-12-15 04:20:04 --> Model "Grafana_model" initialized
ERROR - 2022-12-15 04:20:04 --> Exception of type 'TypeError' occurred with Message: count(): Argument #1 ($value) must be of type Countable|array, null given in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Grafana.php at Line 181
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Grafana->pgsqlDashboard()
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#2 {main}
INFO - 2022-12-15 04:20:19 --> Config Class Initialized
INFO - 2022-12-15 04:20:19 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:19 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:19 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:19 --> URI Class Initialized
INFO - 2022-12-15 04:20:19 --> Router Class Initialized
INFO - 2022-12-15 04:20:19 --> Output Class Initialized
INFO - 2022-12-15 04:20:19 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:19 --> Input Class Initialized
INFO - 2022-12-15 04:20:19 --> Language Class Initialized
INFO - 2022-12-15 04:20:19 --> Loader Class Initialized
INFO - 2022-12-15 04:20:19 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:19 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:19 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:20 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:20 --> Total execution time: 0.2416
INFO - 2022-12-15 04:20:20 --> Config Class Initialized
INFO - 2022-12-15 04:20:20 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:20 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:20 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:20 --> URI Class Initialized
INFO - 2022-12-15 04:20:20 --> Router Class Initialized
INFO - 2022-12-15 04:20:20 --> Output Class Initialized
INFO - 2022-12-15 04:20:20 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:20 --> Input Class Initialized
INFO - 2022-12-15 04:20:20 --> Language Class Initialized
INFO - 2022-12-15 04:20:20 --> Loader Class Initialized
INFO - 2022-12-15 04:20:20 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:20 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:20 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:20 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:20 --> Total execution time: 0.0360
INFO - 2022-12-15 04:20:26 --> Config Class Initialized
INFO - 2022-12-15 04:20:26 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:26 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:26 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:26 --> URI Class Initialized
INFO - 2022-12-15 04:20:26 --> Router Class Initialized
INFO - 2022-12-15 04:20:26 --> Output Class Initialized
INFO - 2022-12-15 04:20:26 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:26 --> Input Class Initialized
INFO - 2022-12-15 04:20:26 --> Language Class Initialized
INFO - 2022-12-15 04:20:26 --> Loader Class Initialized
INFO - 2022-12-15 04:20:26 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:26 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:26 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:26 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:26 --> Total execution time: 0.0637
INFO - 2022-12-15 04:20:26 --> Config Class Initialized
INFO - 2022-12-15 04:20:26 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:26 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:26 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:26 --> URI Class Initialized
INFO - 2022-12-15 04:20:26 --> Router Class Initialized
INFO - 2022-12-15 04:20:26 --> Output Class Initialized
INFO - 2022-12-15 04:20:26 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:26 --> Input Class Initialized
INFO - 2022-12-15 04:20:26 --> Language Class Initialized
INFO - 2022-12-15 04:20:26 --> Loader Class Initialized
INFO - 2022-12-15 04:20:26 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:26 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:26 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:26 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:26 --> Total execution time: 0.0474
INFO - 2022-12-15 04:20:28 --> Config Class Initialized
INFO - 2022-12-15 04:20:28 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:28 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:28 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:28 --> URI Class Initialized
INFO - 2022-12-15 04:20:28 --> Router Class Initialized
INFO - 2022-12-15 04:20:28 --> Output Class Initialized
INFO - 2022-12-15 04:20:28 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:28 --> Input Class Initialized
INFO - 2022-12-15 04:20:28 --> Language Class Initialized
INFO - 2022-12-15 04:20:28 --> Loader Class Initialized
INFO - 2022-12-15 04:20:28 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:28 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:28 --> Total execution time: 0.0204
INFO - 2022-12-15 04:20:28 --> Config Class Initialized
INFO - 2022-12-15 04:20:28 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:28 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:28 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:28 --> URI Class Initialized
INFO - 2022-12-15 04:20:28 --> Router Class Initialized
INFO - 2022-12-15 04:20:28 --> Output Class Initialized
INFO - 2022-12-15 04:20:28 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:28 --> Input Class Initialized
INFO - 2022-12-15 04:20:28 --> Language Class Initialized
INFO - 2022-12-15 04:20:28 --> Loader Class Initialized
INFO - 2022-12-15 04:20:28 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:28 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:28 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:28 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:28 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:28 --> Total execution time: 0.0361
INFO - 2022-12-15 04:20:32 --> Config Class Initialized
INFO - 2022-12-15 04:20:32 --> Config Class Initialized
INFO - 2022-12-15 04:20:32 --> Hooks Class Initialized
INFO - 2022-12-15 04:20:32 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-15 04:20:32 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:32 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:32 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:32 --> URI Class Initialized
INFO - 2022-12-15 04:20:32 --> URI Class Initialized
INFO - 2022-12-15 04:20:32 --> Router Class Initialized
INFO - 2022-12-15 04:20:32 --> Router Class Initialized
INFO - 2022-12-15 04:20:32 --> Output Class Initialized
INFO - 2022-12-15 04:20:32 --> Output Class Initialized
INFO - 2022-12-15 04:20:32 --> Security Class Initialized
INFO - 2022-12-15 04:20:32 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-15 04:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:32 --> Input Class Initialized
INFO - 2022-12-15 04:20:32 --> Input Class Initialized
INFO - 2022-12-15 04:20:32 --> Language Class Initialized
INFO - 2022-12-15 04:20:32 --> Language Class Initialized
INFO - 2022-12-15 04:20:32 --> Loader Class Initialized
INFO - 2022-12-15 04:20:32 --> Loader Class Initialized
INFO - 2022-12-15 04:20:32 --> Controller Class Initialized
INFO - 2022-12-15 04:20:32 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-15 04:20:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:32 --> Final output sent to browser
INFO - 2022-12-15 04:20:32 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:32 --> Total execution time: 0.0244
DEBUG - 2022-12-15 04:20:32 --> Total execution time: 0.0243
INFO - 2022-12-15 04:20:32 --> Config Class Initialized
INFO - 2022-12-15 04:20:32 --> Config Class Initialized
INFO - 2022-12-15 04:20:32 --> Hooks Class Initialized
INFO - 2022-12-15 04:20:32 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-15 04:20:32 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:32 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:32 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:32 --> URI Class Initialized
INFO - 2022-12-15 04:20:32 --> URI Class Initialized
INFO - 2022-12-15 04:20:32 --> Router Class Initialized
INFO - 2022-12-15 04:20:32 --> Router Class Initialized
INFO - 2022-12-15 04:20:32 --> Output Class Initialized
INFO - 2022-12-15 04:20:32 --> Output Class Initialized
INFO - 2022-12-15 04:20:32 --> Security Class Initialized
INFO - 2022-12-15 04:20:32 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-15 04:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:32 --> Input Class Initialized
INFO - 2022-12-15 04:20:32 --> Input Class Initialized
INFO - 2022-12-15 04:20:32 --> Language Class Initialized
INFO - 2022-12-15 04:20:32 --> Language Class Initialized
INFO - 2022-12-15 04:20:32 --> Loader Class Initialized
INFO - 2022-12-15 04:20:32 --> Loader Class Initialized
INFO - 2022-12-15 04:20:32 --> Controller Class Initialized
INFO - 2022-12-15 04:20:32 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-15 04:20:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:32 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:32 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:32 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:32 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:32 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:32 --> Total execution time: 0.0577
INFO - 2022-12-15 04:20:32 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:32 --> Total execution time: 0.0586
INFO - 2022-12-15 04:20:37 --> Config Class Initialized
INFO - 2022-12-15 04:20:37 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:37 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:37 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:37 --> URI Class Initialized
INFO - 2022-12-15 04:20:37 --> Router Class Initialized
INFO - 2022-12-15 04:20:37 --> Output Class Initialized
INFO - 2022-12-15 04:20:37 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:37 --> Input Class Initialized
INFO - 2022-12-15 04:20:37 --> Language Class Initialized
INFO - 2022-12-15 04:20:37 --> Loader Class Initialized
INFO - 2022-12-15 04:20:37 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:37 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:37 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:37 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:37 --> Total execution time: 0.0567
INFO - 2022-12-15 04:20:37 --> Config Class Initialized
INFO - 2022-12-15 04:20:37 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:37 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:37 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:37 --> URI Class Initialized
INFO - 2022-12-15 04:20:37 --> Router Class Initialized
INFO - 2022-12-15 04:20:37 --> Output Class Initialized
INFO - 2022-12-15 04:20:37 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:37 --> Input Class Initialized
INFO - 2022-12-15 04:20:37 --> Language Class Initialized
INFO - 2022-12-15 04:20:37 --> Loader Class Initialized
INFO - 2022-12-15 04:20:37 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:37 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:37 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:37 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:37 --> Total execution time: 0.0521
INFO - 2022-12-15 04:20:39 --> Config Class Initialized
INFO - 2022-12-15 04:20:39 --> Config Class Initialized
INFO - 2022-12-15 04:20:39 --> Hooks Class Initialized
INFO - 2022-12-15 04:20:39 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-15 04:20:39 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:39 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:39 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:39 --> URI Class Initialized
INFO - 2022-12-15 04:20:39 --> URI Class Initialized
INFO - 2022-12-15 04:20:39 --> Router Class Initialized
INFO - 2022-12-15 04:20:39 --> Router Class Initialized
INFO - 2022-12-15 04:20:39 --> Output Class Initialized
INFO - 2022-12-15 04:20:39 --> Output Class Initialized
INFO - 2022-12-15 04:20:39 --> Security Class Initialized
INFO - 2022-12-15 04:20:39 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-15 04:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:39 --> Input Class Initialized
INFO - 2022-12-15 04:20:39 --> Input Class Initialized
INFO - 2022-12-15 04:20:39 --> Language Class Initialized
INFO - 2022-12-15 04:20:39 --> Language Class Initialized
INFO - 2022-12-15 04:20:39 --> Loader Class Initialized
INFO - 2022-12-15 04:20:39 --> Loader Class Initialized
INFO - 2022-12-15 04:20:39 --> Controller Class Initialized
INFO - 2022-12-15 04:20:39 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-15 04:20:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:39 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:39 --> Total execution time: 0.0250
INFO - 2022-12-15 04:20:39 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:39 --> Config Class Initialized
INFO - 2022-12-15 04:20:39 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:39 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:39 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:39 --> URI Class Initialized
INFO - 2022-12-15 04:20:39 --> Router Class Initialized
INFO - 2022-12-15 04:20:39 --> Output Class Initialized
INFO - 2022-12-15 04:20:39 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:39 --> Input Class Initialized
INFO - 2022-12-15 04:20:39 --> Language Class Initialized
INFO - 2022-12-15 04:20:39 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:39 --> Final output sent to browser
INFO - 2022-12-15 04:20:39 --> Loader Class Initialized
DEBUG - 2022-12-15 04:20:39 --> Total execution time: 0.0535
INFO - 2022-12-15 04:20:39 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:39 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:39 --> Config Class Initialized
INFO - 2022-12-15 04:20:39 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:20:39 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:20:39 --> Utf8 Class Initialized
INFO - 2022-12-15 04:20:39 --> URI Class Initialized
INFO - 2022-12-15 04:20:39 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:39 --> Router Class Initialized
INFO - 2022-12-15 04:20:39 --> Final output sent to browser
INFO - 2022-12-15 04:20:39 --> Output Class Initialized
DEBUG - 2022-12-15 04:20:39 --> Total execution time: 0.0366
INFO - 2022-12-15 04:20:39 --> Security Class Initialized
DEBUG - 2022-12-15 04:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:20:39 --> Input Class Initialized
INFO - 2022-12-15 04:20:39 --> Language Class Initialized
INFO - 2022-12-15 04:20:39 --> Loader Class Initialized
INFO - 2022-12-15 04:20:39 --> Controller Class Initialized
DEBUG - 2022-12-15 04:20:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:20:39 --> Database Driver Class Initialized
INFO - 2022-12-15 04:20:39 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:20:39 --> Final output sent to browser
DEBUG - 2022-12-15 04:20:39 --> Total execution time: 0.0573
INFO - 2022-12-15 04:28:53 --> Config Class Initialized
INFO - 2022-12-15 04:28:53 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:28:53 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:28:53 --> Utf8 Class Initialized
INFO - 2022-12-15 04:28:53 --> URI Class Initialized
INFO - 2022-12-15 04:28:53 --> Router Class Initialized
INFO - 2022-12-15 04:28:53 --> Output Class Initialized
INFO - 2022-12-15 04:28:53 --> Security Class Initialized
DEBUG - 2022-12-15 04:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:28:53 --> Input Class Initialized
INFO - 2022-12-15 04:28:53 --> Language Class Initialized
INFO - 2022-12-15 04:28:53 --> Loader Class Initialized
INFO - 2022-12-15 04:28:53 --> Controller Class Initialized
DEBUG - 2022-12-15 04:28:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:28:53 --> Database Driver Class Initialized
INFO - 2022-12-15 04:28:53 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:28:53 --> Final output sent to browser
DEBUG - 2022-12-15 04:28:53 --> Total execution time: 0.5020
INFO - 2022-12-15 04:28:53 --> Config Class Initialized
INFO - 2022-12-15 04:28:53 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:28:53 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:28:53 --> Utf8 Class Initialized
INFO - 2022-12-15 04:28:53 --> URI Class Initialized
INFO - 2022-12-15 04:28:53 --> Router Class Initialized
INFO - 2022-12-15 04:28:53 --> Output Class Initialized
INFO - 2022-12-15 04:28:53 --> Security Class Initialized
DEBUG - 2022-12-15 04:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:28:53 --> Input Class Initialized
INFO - 2022-12-15 04:28:53 --> Language Class Initialized
INFO - 2022-12-15 04:28:53 --> Loader Class Initialized
INFO - 2022-12-15 04:28:53 --> Controller Class Initialized
DEBUG - 2022-12-15 04:28:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:28:54 --> Database Driver Class Initialized
INFO - 2022-12-15 04:28:55 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:28:55 --> Final output sent to browser
DEBUG - 2022-12-15 04:28:55 --> Total execution time: 1.0969
INFO - 2022-12-15 04:29:04 --> Config Class Initialized
INFO - 2022-12-15 04:29:04 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:04 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:04 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:04 --> URI Class Initialized
INFO - 2022-12-15 04:29:04 --> Router Class Initialized
INFO - 2022-12-15 04:29:04 --> Output Class Initialized
INFO - 2022-12-15 04:29:04 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:04 --> Input Class Initialized
INFO - 2022-12-15 04:29:04 --> Language Class Initialized
INFO - 2022-12-15 04:29:04 --> Loader Class Initialized
INFO - 2022-12-15 04:29:04 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:04 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:04 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:04 --> Total execution time: 0.0293
INFO - 2022-12-15 04:29:04 --> Config Class Initialized
INFO - 2022-12-15 04:29:04 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:04 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:04 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:04 --> URI Class Initialized
INFO - 2022-12-15 04:29:04 --> Router Class Initialized
INFO - 2022-12-15 04:29:04 --> Output Class Initialized
INFO - 2022-12-15 04:29:04 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:04 --> Input Class Initialized
INFO - 2022-12-15 04:29:04 --> Language Class Initialized
INFO - 2022-12-15 04:29:04 --> Loader Class Initialized
INFO - 2022-12-15 04:29:04 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:04 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:04 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:04 --> Model "Login_model" initialized
INFO - 2022-12-15 04:29:04 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:05 --> Model "Cluster_model" initialized
ERROR - 2022-12-15 04:29:05 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-15 04:29:05 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-15 04:29:05 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-15 04:29:05 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-15 04:29:06 --> Config Class Initialized
INFO - 2022-12-15 04:29:06 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:06 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:06 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:06 --> URI Class Initialized
INFO - 2022-12-15 04:29:06 --> Router Class Initialized
INFO - 2022-12-15 04:29:06 --> Output Class Initialized
INFO - 2022-12-15 04:29:06 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:06 --> Input Class Initialized
INFO - 2022-12-15 04:29:06 --> Language Class Initialized
INFO - 2022-12-15 04:29:06 --> Loader Class Initialized
INFO - 2022-12-15 04:29:06 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:06 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:06 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:29:06 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:06 --> Total execution time: 0.0495
INFO - 2022-12-15 04:29:06 --> Config Class Initialized
INFO - 2022-12-15 04:29:06 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:06 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:06 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:06 --> URI Class Initialized
INFO - 2022-12-15 04:29:06 --> Router Class Initialized
INFO - 2022-12-15 04:29:06 --> Output Class Initialized
INFO - 2022-12-15 04:29:06 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:06 --> Input Class Initialized
INFO - 2022-12-15 04:29:06 --> Language Class Initialized
INFO - 2022-12-15 04:29:06 --> Loader Class Initialized
INFO - 2022-12-15 04:29:06 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:06 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:06 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:29:06 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:06 --> Total execution time: 0.0557
INFO - 2022-12-15 04:29:07 --> Config Class Initialized
INFO - 2022-12-15 04:29:07 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:07 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:07 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:07 --> URI Class Initialized
INFO - 2022-12-15 04:29:07 --> Router Class Initialized
INFO - 2022-12-15 04:29:07 --> Output Class Initialized
INFO - 2022-12-15 04:29:07 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:07 --> Input Class Initialized
INFO - 2022-12-15 04:29:07 --> Language Class Initialized
INFO - 2022-12-15 04:29:07 --> Loader Class Initialized
INFO - 2022-12-15 04:29:07 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:07 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:07 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:29:07 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:07 --> Model "Login_model" initialized
INFO - 2022-12-15 04:29:07 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:07 --> Total execution time: 0.1592
INFO - 2022-12-15 04:29:07 --> Config Class Initialized
INFO - 2022-12-15 04:29:07 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:07 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:07 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:07 --> URI Class Initialized
INFO - 2022-12-15 04:29:07 --> Router Class Initialized
INFO - 2022-12-15 04:29:07 --> Output Class Initialized
INFO - 2022-12-15 04:29:07 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:07 --> Input Class Initialized
INFO - 2022-12-15 04:29:07 --> Language Class Initialized
INFO - 2022-12-15 04:29:07 --> Loader Class Initialized
INFO - 2022-12-15 04:29:07 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:07 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:07 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:29:07 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:07 --> Model "Login_model" initialized
INFO - 2022-12-15 04:29:07 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:07 --> Total execution time: 0.2779
INFO - 2022-12-15 04:29:08 --> Config Class Initialized
INFO - 2022-12-15 04:29:08 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:08 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:08 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:08 --> URI Class Initialized
INFO - 2022-12-15 04:29:08 --> Router Class Initialized
INFO - 2022-12-15 04:29:08 --> Output Class Initialized
INFO - 2022-12-15 04:29:08 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:08 --> Input Class Initialized
INFO - 2022-12-15 04:29:08 --> Language Class Initialized
INFO - 2022-12-15 04:29:08 --> Loader Class Initialized
INFO - 2022-12-15 04:29:08 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:08 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:08 --> Model "Login_model" initialized
INFO - 2022-12-15 04:29:08 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:08 --> Model "Cluster_model" initialized
ERROR - 2022-12-15 04:29:08 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-15 04:29:08 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-15 04:29:08 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-15 04:29:08 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-15 04:29:09 --> Config Class Initialized
INFO - 2022-12-15 04:29:09 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:09 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:09 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:09 --> URI Class Initialized
INFO - 2022-12-15 04:29:09 --> Router Class Initialized
INFO - 2022-12-15 04:29:09 --> Output Class Initialized
INFO - 2022-12-15 04:29:09 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:09 --> Input Class Initialized
INFO - 2022-12-15 04:29:09 --> Language Class Initialized
INFO - 2022-12-15 04:29:09 --> Loader Class Initialized
INFO - 2022-12-15 04:29:09 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:09 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:09 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:09 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:29:09 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:09 --> Total execution time: 0.0336
INFO - 2022-12-15 04:29:10 --> Config Class Initialized
INFO - 2022-12-15 04:29:10 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:10 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:10 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:10 --> URI Class Initialized
INFO - 2022-12-15 04:29:10 --> Router Class Initialized
INFO - 2022-12-15 04:29:10 --> Output Class Initialized
INFO - 2022-12-15 04:29:10 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:10 --> Input Class Initialized
INFO - 2022-12-15 04:29:10 --> Language Class Initialized
INFO - 2022-12-15 04:29:10 --> Loader Class Initialized
INFO - 2022-12-15 04:29:10 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:10 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:10 --> Total execution time: 0.0201
INFO - 2022-12-15 04:29:10 --> Config Class Initialized
INFO - 2022-12-15 04:29:10 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:10 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:10 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:10 --> URI Class Initialized
INFO - 2022-12-15 04:29:10 --> Router Class Initialized
INFO - 2022-12-15 04:29:10 --> Output Class Initialized
INFO - 2022-12-15 04:29:10 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:10 --> Input Class Initialized
INFO - 2022-12-15 04:29:10 --> Language Class Initialized
INFO - 2022-12-15 04:29:10 --> Loader Class Initialized
INFO - 2022-12-15 04:29:10 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:10 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:10 --> Model "Login_model" initialized
INFO - 2022-12-15 04:29:10 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:10 --> Model "Cluster_model" initialized
ERROR - 2022-12-15 04:29:10 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-15 04:29:10 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-15 04:29:10 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-15 04:29:10 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-15 04:29:10 --> Config Class Initialized
INFO - 2022-12-15 04:29:10 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:10 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:10 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:10 --> URI Class Initialized
INFO - 2022-12-15 04:29:10 --> Router Class Initialized
INFO - 2022-12-15 04:29:10 --> Output Class Initialized
INFO - 2022-12-15 04:29:10 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:10 --> Input Class Initialized
INFO - 2022-12-15 04:29:10 --> Language Class Initialized
INFO - 2022-12-15 04:29:10 --> Loader Class Initialized
INFO - 2022-12-15 04:29:10 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:10 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:10 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:29:10 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:10 --> Model "Login_model" initialized
INFO - 2022-12-15 04:29:10 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:10 --> Total execution time: 0.2231
INFO - 2022-12-15 04:29:11 --> Config Class Initialized
INFO - 2022-12-15 04:29:11 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:11 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:11 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:11 --> URI Class Initialized
INFO - 2022-12-15 04:29:11 --> Router Class Initialized
INFO - 2022-12-15 04:29:11 --> Output Class Initialized
INFO - 2022-12-15 04:29:11 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:11 --> Input Class Initialized
INFO - 2022-12-15 04:29:11 --> Language Class Initialized
INFO - 2022-12-15 04:29:11 --> Loader Class Initialized
INFO - 2022-12-15 04:29:11 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:11 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:12 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:29:12 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:12 --> Total execution time: 0.0821
INFO - 2022-12-15 04:29:12 --> Config Class Initialized
INFO - 2022-12-15 04:29:12 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:29:12 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:29:12 --> Utf8 Class Initialized
INFO - 2022-12-15 04:29:12 --> URI Class Initialized
INFO - 2022-12-15 04:29:12 --> Router Class Initialized
INFO - 2022-12-15 04:29:12 --> Output Class Initialized
INFO - 2022-12-15 04:29:12 --> Security Class Initialized
DEBUG - 2022-12-15 04:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:29:12 --> Input Class Initialized
INFO - 2022-12-15 04:29:12 --> Language Class Initialized
INFO - 2022-12-15 04:29:12 --> Loader Class Initialized
INFO - 2022-12-15 04:29:12 --> Controller Class Initialized
DEBUG - 2022-12-15 04:29:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:29:12 --> Database Driver Class Initialized
INFO - 2022-12-15 04:29:12 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:29:12 --> Final output sent to browser
DEBUG - 2022-12-15 04:29:12 --> Total execution time: 0.0737
INFO - 2022-12-15 04:38:15 --> Config Class Initialized
INFO - 2022-12-15 04:38:15 --> Config Class Initialized
INFO - 2022-12-15 04:38:15 --> Hooks Class Initialized
INFO - 2022-12-15 04:38:15 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-15 04:38:15 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:15 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:15 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:15 --> URI Class Initialized
INFO - 2022-12-15 04:38:15 --> URI Class Initialized
INFO - 2022-12-15 04:38:15 --> Router Class Initialized
INFO - 2022-12-15 04:38:15 --> Router Class Initialized
INFO - 2022-12-15 04:38:15 --> Output Class Initialized
INFO - 2022-12-15 04:38:15 --> Output Class Initialized
INFO - 2022-12-15 04:38:15 --> Security Class Initialized
INFO - 2022-12-15 04:38:15 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-15 04:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:15 --> Input Class Initialized
INFO - 2022-12-15 04:38:15 --> Input Class Initialized
INFO - 2022-12-15 04:38:15 --> Language Class Initialized
INFO - 2022-12-15 04:38:15 --> Language Class Initialized
INFO - 2022-12-15 04:38:15 --> Loader Class Initialized
INFO - 2022-12-15 04:38:15 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:15 --> Loader Class Initialized
INFO - 2022-12-15 04:38:15 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:15 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:15 --> Total execution time: 0.0502
INFO - 2022-12-15 04:38:15 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:15 --> Config Class Initialized
INFO - 2022-12-15 04:38:15 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:15 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:15 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:15 --> URI Class Initialized
INFO - 2022-12-15 04:38:15 --> Router Class Initialized
INFO - 2022-12-15 04:38:15 --> Output Class Initialized
INFO - 2022-12-15 04:38:15 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:15 --> Input Class Initialized
INFO - 2022-12-15 04:38:15 --> Language Class Initialized
INFO - 2022-12-15 04:38:15 --> Loader Class Initialized
INFO - 2022-12-15 04:38:15 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:15 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:15 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:15 --> Model "Login_model" initialized
INFO - 2022-12-15 04:38:15 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:15 --> Total execution time: 0.1203
INFO - 2022-12-15 04:38:15 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:15 --> Config Class Initialized
INFO - 2022-12-15 04:38:15 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:15 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:15 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:15 --> URI Class Initialized
INFO - 2022-12-15 04:38:15 --> Router Class Initialized
INFO - 2022-12-15 04:38:15 --> Output Class Initialized
INFO - 2022-12-15 04:38:15 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:15 --> Input Class Initialized
INFO - 2022-12-15 04:38:15 --> Language Class Initialized
INFO - 2022-12-15 04:38:15 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:15 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:15 --> Total execution time: 0.0997
INFO - 2022-12-15 04:38:15 --> Loader Class Initialized
INFO - 2022-12-15 04:38:15 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:15 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:15 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:15 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:15 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:15 --> Total execution time: 0.0760
INFO - 2022-12-15 04:38:16 --> Config Class Initialized
INFO - 2022-12-15 04:38:16 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:16 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:16 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:16 --> URI Class Initialized
INFO - 2022-12-15 04:38:16 --> Router Class Initialized
INFO - 2022-12-15 04:38:16 --> Output Class Initialized
INFO - 2022-12-15 04:38:16 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:16 --> Input Class Initialized
INFO - 2022-12-15 04:38:16 --> Language Class Initialized
INFO - 2022-12-15 04:38:16 --> Loader Class Initialized
INFO - 2022-12-15 04:38:16 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:16 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:16 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:16 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:16 --> Model "Login_model" initialized
INFO - 2022-12-15 04:38:16 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:16 --> Total execution time: 0.2931
INFO - 2022-12-15 04:38:16 --> Config Class Initialized
INFO - 2022-12-15 04:38:16 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:16 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:16 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:16 --> URI Class Initialized
INFO - 2022-12-15 04:38:16 --> Router Class Initialized
INFO - 2022-12-15 04:38:16 --> Output Class Initialized
INFO - 2022-12-15 04:38:16 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:16 --> Input Class Initialized
INFO - 2022-12-15 04:38:16 --> Language Class Initialized
INFO - 2022-12-15 04:38:16 --> Loader Class Initialized
INFO - 2022-12-15 04:38:16 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:16 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:17 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:17 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:17 --> Model "Login_model" initialized
INFO - 2022-12-15 04:38:18 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:18 --> Total execution time: 1.3277
INFO - 2022-12-15 04:38:21 --> Config Class Initialized
INFO - 2022-12-15 04:38:21 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:21 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:21 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:21 --> URI Class Initialized
INFO - 2022-12-15 04:38:21 --> Router Class Initialized
INFO - 2022-12-15 04:38:21 --> Output Class Initialized
INFO - 2022-12-15 04:38:21 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:21 --> Input Class Initialized
INFO - 2022-12-15 04:38:21 --> Language Class Initialized
INFO - 2022-12-15 04:38:21 --> Loader Class Initialized
INFO - 2022-12-15 04:38:21 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:21 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:21 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:21 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:21 --> Total execution time: 0.0718
INFO - 2022-12-15 04:38:21 --> Config Class Initialized
INFO - 2022-12-15 04:38:21 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:21 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:21 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:21 --> URI Class Initialized
INFO - 2022-12-15 04:38:21 --> Router Class Initialized
INFO - 2022-12-15 04:38:21 --> Output Class Initialized
INFO - 2022-12-15 04:38:21 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:21 --> Input Class Initialized
INFO - 2022-12-15 04:38:21 --> Language Class Initialized
INFO - 2022-12-15 04:38:21 --> Loader Class Initialized
INFO - 2022-12-15 04:38:21 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:22 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:22 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:22 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:22 --> Total execution time: 0.2560
INFO - 2022-12-15 04:38:24 --> Config Class Initialized
INFO - 2022-12-15 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:24 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:24 --> URI Class Initialized
INFO - 2022-12-15 04:38:24 --> Router Class Initialized
INFO - 2022-12-15 04:38:24 --> Output Class Initialized
INFO - 2022-12-15 04:38:24 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:24 --> Input Class Initialized
INFO - 2022-12-15 04:38:24 --> Language Class Initialized
INFO - 2022-12-15 04:38:24 --> Loader Class Initialized
INFO - 2022-12-15 04:38:24 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:24 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:24 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:24 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:24 --> Total execution time: 0.0424
INFO - 2022-12-15 04:38:24 --> Config Class Initialized
INFO - 2022-12-15 04:38:24 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:24 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:24 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:24 --> URI Class Initialized
INFO - 2022-12-15 04:38:24 --> Router Class Initialized
INFO - 2022-12-15 04:38:24 --> Output Class Initialized
INFO - 2022-12-15 04:38:24 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:24 --> Input Class Initialized
INFO - 2022-12-15 04:38:24 --> Language Class Initialized
INFO - 2022-12-15 04:38:24 --> Loader Class Initialized
INFO - 2022-12-15 04:38:24 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:24 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:24 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:24 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:24 --> Total execution time: 0.0562
INFO - 2022-12-15 04:38:25 --> Config Class Initialized
INFO - 2022-12-15 04:38:25 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:25 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:25 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:25 --> URI Class Initialized
INFO - 2022-12-15 04:38:25 --> Router Class Initialized
INFO - 2022-12-15 04:38:25 --> Output Class Initialized
INFO - 2022-12-15 04:38:25 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:25 --> Input Class Initialized
INFO - 2022-12-15 04:38:25 --> Language Class Initialized
INFO - 2022-12-15 04:38:25 --> Loader Class Initialized
INFO - 2022-12-15 04:38:25 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:25 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:25 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:25 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:25 --> Total execution time: 0.0343
INFO - 2022-12-15 04:38:25 --> Config Class Initialized
INFO - 2022-12-15 04:38:25 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:25 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:25 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:25 --> URI Class Initialized
INFO - 2022-12-15 04:38:25 --> Router Class Initialized
INFO - 2022-12-15 04:38:25 --> Output Class Initialized
INFO - 2022-12-15 04:38:25 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:25 --> Input Class Initialized
INFO - 2022-12-15 04:38:25 --> Language Class Initialized
INFO - 2022-12-15 04:38:25 --> Loader Class Initialized
INFO - 2022-12-15 04:38:25 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:25 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:25 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:25 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:25 --> Total execution time: 0.0547
INFO - 2022-12-15 04:38:26 --> Config Class Initialized
INFO - 2022-12-15 04:38:26 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:26 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:26 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:26 --> URI Class Initialized
INFO - 2022-12-15 04:38:26 --> Router Class Initialized
INFO - 2022-12-15 04:38:26 --> Output Class Initialized
INFO - 2022-12-15 04:38:26 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:26 --> Input Class Initialized
INFO - 2022-12-15 04:38:26 --> Language Class Initialized
INFO - 2022-12-15 04:38:26 --> Loader Class Initialized
INFO - 2022-12-15 04:38:26 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:26 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:26 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:26 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:26 --> Total execution time: 0.0366
INFO - 2022-12-15 04:38:26 --> Config Class Initialized
INFO - 2022-12-15 04:38:26 --> Hooks Class Initialized
DEBUG - 2022-12-15 04:38:26 --> UTF-8 Support Enabled
INFO - 2022-12-15 04:38:26 --> Utf8 Class Initialized
INFO - 2022-12-15 04:38:26 --> URI Class Initialized
INFO - 2022-12-15 04:38:26 --> Router Class Initialized
INFO - 2022-12-15 04:38:26 --> Output Class Initialized
INFO - 2022-12-15 04:38:26 --> Security Class Initialized
DEBUG - 2022-12-15 04:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 04:38:26 --> Input Class Initialized
INFO - 2022-12-15 04:38:26 --> Language Class Initialized
INFO - 2022-12-15 04:38:26 --> Loader Class Initialized
INFO - 2022-12-15 04:38:26 --> Controller Class Initialized
DEBUG - 2022-12-15 04:38:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 04:38:26 --> Database Driver Class Initialized
INFO - 2022-12-15 04:38:26 --> Model "Cluster_model" initialized
INFO - 2022-12-15 04:38:26 --> Final output sent to browser
DEBUG - 2022-12-15 04:38:26 --> Total execution time: 0.0383
INFO - 2022-12-15 06:43:23 --> Config Class Initialized
INFO - 2022-12-15 06:43:23 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:43:23 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:43:23 --> Utf8 Class Initialized
INFO - 2022-12-15 06:43:23 --> URI Class Initialized
INFO - 2022-12-15 06:43:23 --> Router Class Initialized
INFO - 2022-12-15 06:43:23 --> Output Class Initialized
INFO - 2022-12-15 06:43:23 --> Security Class Initialized
DEBUG - 2022-12-15 06:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:43:23 --> Input Class Initialized
INFO - 2022-12-15 06:43:23 --> Language Class Initialized
INFO - 2022-12-15 06:43:23 --> Loader Class Initialized
INFO - 2022-12-15 06:43:23 --> Controller Class Initialized
DEBUG - 2022-12-15 06:43:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:43:23 --> Final output sent to browser
DEBUG - 2022-12-15 06:43:23 --> Total execution time: 0.0241
INFO - 2022-12-15 06:43:23 --> Config Class Initialized
INFO - 2022-12-15 06:43:23 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:43:23 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:43:23 --> Utf8 Class Initialized
INFO - 2022-12-15 06:43:23 --> URI Class Initialized
INFO - 2022-12-15 06:43:23 --> Router Class Initialized
INFO - 2022-12-15 06:43:23 --> Output Class Initialized
INFO - 2022-12-15 06:43:23 --> Security Class Initialized
DEBUG - 2022-12-15 06:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:43:23 --> Input Class Initialized
INFO - 2022-12-15 06:43:23 --> Language Class Initialized
INFO - 2022-12-15 06:43:23 --> Loader Class Initialized
INFO - 2022-12-15 06:43:23 --> Controller Class Initialized
DEBUG - 2022-12-15 06:43:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:43:23 --> Database Driver Class Initialized
INFO - 2022-12-15 06:43:23 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:43:23 --> Final output sent to browser
DEBUG - 2022-12-15 06:43:23 --> Total execution time: 0.0352
INFO - 2022-12-15 06:43:25 --> Config Class Initialized
INFO - 2022-12-15 06:43:25 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:43:25 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:43:25 --> Utf8 Class Initialized
INFO - 2022-12-15 06:43:25 --> URI Class Initialized
INFO - 2022-12-15 06:43:25 --> Router Class Initialized
INFO - 2022-12-15 06:43:25 --> Output Class Initialized
INFO - 2022-12-15 06:43:25 --> Security Class Initialized
DEBUG - 2022-12-15 06:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:43:25 --> Input Class Initialized
INFO - 2022-12-15 06:43:25 --> Language Class Initialized
INFO - 2022-12-15 06:43:25 --> Loader Class Initialized
INFO - 2022-12-15 06:43:25 --> Controller Class Initialized
DEBUG - 2022-12-15 06:43:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:43:25 --> Database Driver Class Initialized
INFO - 2022-12-15 06:43:25 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:43:25 --> Final output sent to browser
DEBUG - 2022-12-15 06:43:25 --> Total execution time: 0.0497
INFO - 2022-12-15 06:43:25 --> Config Class Initialized
INFO - 2022-12-15 06:43:25 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:43:25 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:43:25 --> Utf8 Class Initialized
INFO - 2022-12-15 06:43:25 --> URI Class Initialized
INFO - 2022-12-15 06:43:25 --> Router Class Initialized
INFO - 2022-12-15 06:43:25 --> Output Class Initialized
INFO - 2022-12-15 06:43:25 --> Security Class Initialized
DEBUG - 2022-12-15 06:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:43:25 --> Input Class Initialized
INFO - 2022-12-15 06:43:25 --> Language Class Initialized
INFO - 2022-12-15 06:43:25 --> Loader Class Initialized
INFO - 2022-12-15 06:43:25 --> Controller Class Initialized
DEBUG - 2022-12-15 06:43:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:43:25 --> Database Driver Class Initialized
INFO - 2022-12-15 06:43:25 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:43:25 --> Final output sent to browser
DEBUG - 2022-12-15 06:43:25 --> Total execution time: 0.0544
INFO - 2022-12-15 06:43:31 --> Config Class Initialized
INFO - 2022-12-15 06:43:31 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:43:31 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:43:31 --> Utf8 Class Initialized
INFO - 2022-12-15 06:43:31 --> URI Class Initialized
INFO - 2022-12-15 06:43:31 --> Router Class Initialized
INFO - 2022-12-15 06:43:31 --> Output Class Initialized
INFO - 2022-12-15 06:43:31 --> Security Class Initialized
DEBUG - 2022-12-15 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:43:31 --> Input Class Initialized
INFO - 2022-12-15 06:43:31 --> Language Class Initialized
INFO - 2022-12-15 06:43:31 --> Loader Class Initialized
INFO - 2022-12-15 06:43:31 --> Controller Class Initialized
DEBUG - 2022-12-15 06:43:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:43:31 --> Database Driver Class Initialized
INFO - 2022-12-15 06:43:31 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:43:31 --> Final output sent to browser
DEBUG - 2022-12-15 06:43:31 --> Total execution time: 0.2753
INFO - 2022-12-15 06:43:31 --> Config Class Initialized
INFO - 2022-12-15 06:43:31 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:43:31 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:43:31 --> Utf8 Class Initialized
INFO - 2022-12-15 06:43:31 --> URI Class Initialized
INFO - 2022-12-15 06:43:31 --> Router Class Initialized
INFO - 2022-12-15 06:43:31 --> Output Class Initialized
INFO - 2022-12-15 06:43:31 --> Security Class Initialized
DEBUG - 2022-12-15 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:43:31 --> Input Class Initialized
INFO - 2022-12-15 06:43:31 --> Language Class Initialized
INFO - 2022-12-15 06:43:31 --> Loader Class Initialized
INFO - 2022-12-15 06:43:31 --> Controller Class Initialized
DEBUG - 2022-12-15 06:43:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:43:31 --> Database Driver Class Initialized
INFO - 2022-12-15 06:43:31 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:43:32 --> Final output sent to browser
DEBUG - 2022-12-15 06:43:32 --> Total execution time: 0.2092
INFO - 2022-12-15 06:47:34 --> Config Class Initialized
INFO - 2022-12-15 06:47:34 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:34 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:34 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:34 --> URI Class Initialized
INFO - 2022-12-15 06:47:34 --> Router Class Initialized
INFO - 2022-12-15 06:47:34 --> Output Class Initialized
INFO - 2022-12-15 06:47:34 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:34 --> Input Class Initialized
INFO - 2022-12-15 06:47:34 --> Language Class Initialized
INFO - 2022-12-15 06:47:34 --> Loader Class Initialized
INFO - 2022-12-15 06:47:34 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:34 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:34 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:34 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:34 --> Total execution time: 0.0523
INFO - 2022-12-15 06:47:34 --> Config Class Initialized
INFO - 2022-12-15 06:47:34 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:34 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:34 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:34 --> URI Class Initialized
INFO - 2022-12-15 06:47:34 --> Router Class Initialized
INFO - 2022-12-15 06:47:34 --> Output Class Initialized
INFO - 2022-12-15 06:47:34 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:34 --> Input Class Initialized
INFO - 2022-12-15 06:47:34 --> Language Class Initialized
INFO - 2022-12-15 06:47:34 --> Loader Class Initialized
INFO - 2022-12-15 06:47:34 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:34 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:34 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:34 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:34 --> Total execution time: 0.0537
INFO - 2022-12-15 06:47:36 --> Config Class Initialized
INFO - 2022-12-15 06:47:36 --> Hooks Class Initialized
INFO - 2022-12-15 06:47:36 --> Config Class Initialized
INFO - 2022-12-15 06:47:36 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-15 06:47:36 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:36 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:36 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:36 --> URI Class Initialized
INFO - 2022-12-15 06:47:36 --> URI Class Initialized
INFO - 2022-12-15 06:47:36 --> Router Class Initialized
INFO - 2022-12-15 06:47:36 --> Router Class Initialized
INFO - 2022-12-15 06:47:36 --> Output Class Initialized
INFO - 2022-12-15 06:47:36 --> Output Class Initialized
INFO - 2022-12-15 06:47:36 --> Security Class Initialized
INFO - 2022-12-15 06:47:36 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-15 06:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:36 --> Input Class Initialized
INFO - 2022-12-15 06:47:36 --> Input Class Initialized
INFO - 2022-12-15 06:47:36 --> Language Class Initialized
INFO - 2022-12-15 06:47:36 --> Language Class Initialized
INFO - 2022-12-15 06:47:36 --> Loader Class Initialized
INFO - 2022-12-15 06:47:36 --> Loader Class Initialized
INFO - 2022-12-15 06:47:36 --> Controller Class Initialized
INFO - 2022-12-15 06:47:36 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-15 06:47:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:36 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:36 --> Total execution time: 0.0271
INFO - 2022-12-15 06:47:36 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:36 --> Config Class Initialized
INFO - 2022-12-15 06:47:36 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:36 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:36 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:36 --> URI Class Initialized
INFO - 2022-12-15 06:47:36 --> Router Class Initialized
INFO - 2022-12-15 06:47:36 --> Output Class Initialized
INFO - 2022-12-15 06:47:36 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:36 --> Input Class Initialized
INFO - 2022-12-15 06:47:36 --> Language Class Initialized
INFO - 2022-12-15 06:47:36 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:36 --> Loader Class Initialized
INFO - 2022-12-15 06:47:36 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:36 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:36 --> Total execution time: 0.0532
INFO - 2022-12-15 06:47:36 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:36 --> Config Class Initialized
INFO - 2022-12-15 06:47:36 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:36 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:36 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:36 --> URI Class Initialized
INFO - 2022-12-15 06:47:36 --> Router Class Initialized
INFO - 2022-12-15 06:47:36 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:36 --> Output Class Initialized
INFO - 2022-12-15 06:47:36 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:36 --> Final output sent to browser
INFO - 2022-12-15 06:47:36 --> Input Class Initialized
DEBUG - 2022-12-15 06:47:36 --> Total execution time: 0.0508
INFO - 2022-12-15 06:47:36 --> Language Class Initialized
INFO - 2022-12-15 06:47:36 --> Loader Class Initialized
INFO - 2022-12-15 06:47:36 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:36 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:36 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:36 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:36 --> Total execution time: 0.0605
INFO - 2022-12-15 06:47:52 --> Config Class Initialized
INFO - 2022-12-15 06:47:52 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:52 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:52 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:52 --> URI Class Initialized
INFO - 2022-12-15 06:47:52 --> Router Class Initialized
INFO - 2022-12-15 06:47:52 --> Output Class Initialized
INFO - 2022-12-15 06:47:52 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:52 --> Input Class Initialized
INFO - 2022-12-15 06:47:52 --> Language Class Initialized
INFO - 2022-12-15 06:47:52 --> Loader Class Initialized
INFO - 2022-12-15 06:47:52 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:52 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:52 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:52 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:52 --> Total execution time: 0.0623
INFO - 2022-12-15 06:47:52 --> Config Class Initialized
INFO - 2022-12-15 06:47:52 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:52 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:52 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:52 --> URI Class Initialized
INFO - 2022-12-15 06:47:52 --> Router Class Initialized
INFO - 2022-12-15 06:47:52 --> Output Class Initialized
INFO - 2022-12-15 06:47:52 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:52 --> Input Class Initialized
INFO - 2022-12-15 06:47:52 --> Language Class Initialized
INFO - 2022-12-15 06:47:52 --> Loader Class Initialized
INFO - 2022-12-15 06:47:52 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:52 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:52 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:52 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:52 --> Total execution time: 0.0410
INFO - 2022-12-15 06:47:53 --> Config Class Initialized
INFO - 2022-12-15 06:47:53 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:53 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:53 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:53 --> URI Class Initialized
INFO - 2022-12-15 06:47:53 --> Router Class Initialized
INFO - 2022-12-15 06:47:53 --> Output Class Initialized
INFO - 2022-12-15 06:47:53 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:53 --> Input Class Initialized
INFO - 2022-12-15 06:47:53 --> Language Class Initialized
INFO - 2022-12-15 06:47:53 --> Loader Class Initialized
INFO - 2022-12-15 06:47:53 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:53 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:53 --> Total execution time: 0.0205
INFO - 2022-12-15 06:47:53 --> Config Class Initialized
INFO - 2022-12-15 06:47:53 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:53 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:53 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:53 --> URI Class Initialized
INFO - 2022-12-15 06:47:53 --> Router Class Initialized
INFO - 2022-12-15 06:47:53 --> Output Class Initialized
INFO - 2022-12-15 06:47:53 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:53 --> Input Class Initialized
INFO - 2022-12-15 06:47:53 --> Language Class Initialized
INFO - 2022-12-15 06:47:53 --> Loader Class Initialized
INFO - 2022-12-15 06:47:53 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:53 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:54 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:54 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:54 --> Total execution time: 0.0513
INFO - 2022-12-15 06:47:58 --> Config Class Initialized
INFO - 2022-12-15 06:47:58 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:58 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:58 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:58 --> URI Class Initialized
INFO - 2022-12-15 06:47:58 --> Router Class Initialized
INFO - 2022-12-15 06:47:58 --> Output Class Initialized
INFO - 2022-12-15 06:47:58 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:58 --> Input Class Initialized
INFO - 2022-12-15 06:47:58 --> Language Class Initialized
INFO - 2022-12-15 06:47:58 --> Loader Class Initialized
INFO - 2022-12-15 06:47:58 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:58 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:58 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:58 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:58 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:58 --> Total execution time: 0.0585
INFO - 2022-12-15 06:47:58 --> Config Class Initialized
INFO - 2022-12-15 06:47:58 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:47:58 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:47:58 --> Utf8 Class Initialized
INFO - 2022-12-15 06:47:58 --> URI Class Initialized
INFO - 2022-12-15 06:47:58 --> Router Class Initialized
INFO - 2022-12-15 06:47:58 --> Output Class Initialized
INFO - 2022-12-15 06:47:58 --> Security Class Initialized
DEBUG - 2022-12-15 06:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:47:58 --> Input Class Initialized
INFO - 2022-12-15 06:47:58 --> Language Class Initialized
INFO - 2022-12-15 06:47:58 --> Loader Class Initialized
INFO - 2022-12-15 06:47:58 --> Controller Class Initialized
DEBUG - 2022-12-15 06:47:58 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:47:58 --> Database Driver Class Initialized
INFO - 2022-12-15 06:47:58 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:47:58 --> Final output sent to browser
DEBUG - 2022-12-15 06:47:58 --> Total execution time: 0.0576
INFO - 2022-12-15 06:48:00 --> Config Class Initialized
INFO - 2022-12-15 06:48:00 --> Hooks Class Initialized
INFO - 2022-12-15 06:48:00 --> Config Class Initialized
INFO - 2022-12-15 06:48:00 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:48:00 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:48:00 --> Utf8 Class Initialized
DEBUG - 2022-12-15 06:48:00 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:48:00 --> Utf8 Class Initialized
INFO - 2022-12-15 06:48:00 --> URI Class Initialized
INFO - 2022-12-15 06:48:00 --> URI Class Initialized
INFO - 2022-12-15 06:48:00 --> Router Class Initialized
INFO - 2022-12-15 06:48:00 --> Router Class Initialized
INFO - 2022-12-15 06:48:00 --> Output Class Initialized
INFO - 2022-12-15 06:48:00 --> Output Class Initialized
INFO - 2022-12-15 06:48:00 --> Security Class Initialized
INFO - 2022-12-15 06:48:00 --> Security Class Initialized
DEBUG - 2022-12-15 06:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:48:00 --> Input Class Initialized
DEBUG - 2022-12-15 06:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:48:00 --> Language Class Initialized
INFO - 2022-12-15 06:48:00 --> Input Class Initialized
INFO - 2022-12-15 06:48:00 --> Language Class Initialized
INFO - 2022-12-15 06:48:00 --> Loader Class Initialized
INFO - 2022-12-15 06:48:00 --> Loader Class Initialized
INFO - 2022-12-15 06:48:00 --> Controller Class Initialized
DEBUG - 2022-12-15 06:48:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:48:00 --> Final output sent to browser
INFO - 2022-12-15 06:48:00 --> Controller Class Initialized
DEBUG - 2022-12-15 06:48:00 --> Total execution time: 0.0246
DEBUG - 2022-12-15 06:48:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:48:00 --> Database Driver Class Initialized
INFO - 2022-12-15 06:48:00 --> Config Class Initialized
INFO - 2022-12-15 06:48:00 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:48:00 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:48:00 --> Utf8 Class Initialized
INFO - 2022-12-15 06:48:00 --> URI Class Initialized
INFO - 2022-12-15 06:48:00 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:48:00 --> Router Class Initialized
INFO - 2022-12-15 06:48:00 --> Output Class Initialized
INFO - 2022-12-15 06:48:00 --> Final output sent to browser
DEBUG - 2022-12-15 06:48:00 --> Total execution time: 0.0419
INFO - 2022-12-15 06:48:00 --> Security Class Initialized
DEBUG - 2022-12-15 06:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:48:00 --> Input Class Initialized
INFO - 2022-12-15 06:48:00 --> Language Class Initialized
INFO - 2022-12-15 06:48:01 --> Loader Class Initialized
INFO - 2022-12-15 06:48:01 --> Config Class Initialized
INFO - 2022-12-15 06:48:01 --> Hooks Class Initialized
INFO - 2022-12-15 06:48:01 --> Controller Class Initialized
DEBUG - 2022-12-15 06:48:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-15 06:48:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:48:01 --> Utf8 Class Initialized
INFO - 2022-12-15 06:48:01 --> URI Class Initialized
INFO - 2022-12-15 06:48:01 --> Router Class Initialized
INFO - 2022-12-15 06:48:01 --> Database Driver Class Initialized
INFO - 2022-12-15 06:48:01 --> Output Class Initialized
INFO - 2022-12-15 06:48:01 --> Security Class Initialized
DEBUG - 2022-12-15 06:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:48:01 --> Input Class Initialized
INFO - 2022-12-15 06:48:01 --> Language Class Initialized
INFO - 2022-12-15 06:48:01 --> Loader Class Initialized
INFO - 2022-12-15 06:48:01 --> Controller Class Initialized
DEBUG - 2022-12-15 06:48:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:48:01 --> Database Driver Class Initialized
INFO - 2022-12-15 06:48:01 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:48:01 --> Final output sent to browser
DEBUG - 2022-12-15 06:48:01 --> Total execution time: 0.0546
INFO - 2022-12-15 06:48:01 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:48:01 --> Final output sent to browser
DEBUG - 2022-12-15 06:48:01 --> Total execution time: 0.0600
INFO - 2022-12-15 06:48:02 --> Config Class Initialized
INFO - 2022-12-15 06:48:02 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:48:02 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:48:02 --> Utf8 Class Initialized
INFO - 2022-12-15 06:48:02 --> URI Class Initialized
INFO - 2022-12-15 06:48:02 --> Router Class Initialized
INFO - 2022-12-15 06:48:02 --> Output Class Initialized
INFO - 2022-12-15 06:48:02 --> Security Class Initialized
DEBUG - 2022-12-15 06:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:48:02 --> Input Class Initialized
INFO - 2022-12-15 06:48:02 --> Language Class Initialized
INFO - 2022-12-15 06:48:02 --> Loader Class Initialized
INFO - 2022-12-15 06:48:02 --> Controller Class Initialized
DEBUG - 2022-12-15 06:48:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:48:02 --> Database Driver Class Initialized
INFO - 2022-12-15 06:48:02 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:48:02 --> Final output sent to browser
DEBUG - 2022-12-15 06:48:02 --> Total execution time: 0.0572
INFO - 2022-12-15 06:48:02 --> Config Class Initialized
INFO - 2022-12-15 06:48:02 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:48:02 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:48:02 --> Utf8 Class Initialized
INFO - 2022-12-15 06:48:02 --> URI Class Initialized
INFO - 2022-12-15 06:48:02 --> Router Class Initialized
INFO - 2022-12-15 06:48:02 --> Output Class Initialized
INFO - 2022-12-15 06:48:02 --> Security Class Initialized
DEBUG - 2022-12-15 06:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:48:02 --> Input Class Initialized
INFO - 2022-12-15 06:48:02 --> Language Class Initialized
INFO - 2022-12-15 06:48:02 --> Loader Class Initialized
INFO - 2022-12-15 06:48:02 --> Controller Class Initialized
DEBUG - 2022-12-15 06:48:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:48:02 --> Database Driver Class Initialized
INFO - 2022-12-15 06:48:02 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:48:02 --> Final output sent to browser
DEBUG - 2022-12-15 06:48:02 --> Total execution time: 0.0684
INFO - 2022-12-15 06:49:51 --> Config Class Initialized
INFO - 2022-12-15 06:49:51 --> Config Class Initialized
INFO - 2022-12-15 06:49:51 --> Hooks Class Initialized
INFO - 2022-12-15 06:49:51 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:49:51 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:49:51 --> Utf8 Class Initialized
DEBUG - 2022-12-15 06:49:51 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:49:51 --> Utf8 Class Initialized
INFO - 2022-12-15 06:49:51 --> URI Class Initialized
INFO - 2022-12-15 06:49:51 --> URI Class Initialized
INFO - 2022-12-15 06:49:51 --> Router Class Initialized
INFO - 2022-12-15 06:49:51 --> Router Class Initialized
INFO - 2022-12-15 06:49:51 --> Output Class Initialized
INFO - 2022-12-15 06:49:51 --> Output Class Initialized
INFO - 2022-12-15 06:49:51 --> Security Class Initialized
INFO - 2022-12-15 06:49:51 --> Security Class Initialized
DEBUG - 2022-12-15 06:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:49:51 --> Input Class Initialized
DEBUG - 2022-12-15 06:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:49:51 --> Input Class Initialized
INFO - 2022-12-15 06:49:51 --> Language Class Initialized
INFO - 2022-12-15 06:49:51 --> Language Class Initialized
INFO - 2022-12-15 06:49:51 --> Loader Class Initialized
INFO - 2022-12-15 06:49:51 --> Controller Class Initialized
DEBUG - 2022-12-15 06:49:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:49:51 --> Database Driver Class Initialized
INFO - 2022-12-15 06:49:51 --> Loader Class Initialized
INFO - 2022-12-15 06:49:51 --> Controller Class Initialized
DEBUG - 2022-12-15 06:49:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:49:51 --> Final output sent to browser
DEBUG - 2022-12-15 06:49:51 --> Total execution time: 0.0311
INFO - 2022-12-15 06:49:51 --> Config Class Initialized
INFO - 2022-12-15 06:49:51 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:49:51 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:49:51 --> Utf8 Class Initialized
INFO - 2022-12-15 06:49:51 --> URI Class Initialized
INFO - 2022-12-15 06:49:51 --> Router Class Initialized
INFO - 2022-12-15 06:49:51 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:49:51 --> Output Class Initialized
INFO - 2022-12-15 06:49:51 --> Security Class Initialized
DEBUG - 2022-12-15 06:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:49:51 --> Input Class Initialized
INFO - 2022-12-15 06:49:51 --> Language Class Initialized
INFO - 2022-12-15 06:49:51 --> Loader Class Initialized
INFO - 2022-12-15 06:49:51 --> Controller Class Initialized
DEBUG - 2022-12-15 06:49:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:49:51 --> Final output sent to browser
DEBUG - 2022-12-15 06:49:51 --> Total execution time: 0.0568
INFO - 2022-12-15 06:49:51 --> Database Driver Class Initialized
INFO - 2022-12-15 06:49:51 --> Config Class Initialized
INFO - 2022-12-15 06:49:51 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:49:51 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:49:51 --> Utf8 Class Initialized
INFO - 2022-12-15 06:49:51 --> URI Class Initialized
INFO - 2022-12-15 06:49:51 --> Router Class Initialized
INFO - 2022-12-15 06:49:51 --> Output Class Initialized
INFO - 2022-12-15 06:49:51 --> Security Class Initialized
DEBUG - 2022-12-15 06:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:49:51 --> Input Class Initialized
INFO - 2022-12-15 06:49:51 --> Language Class Initialized
INFO - 2022-12-15 06:49:51 --> Loader Class Initialized
INFO - 2022-12-15 06:49:51 --> Controller Class Initialized
DEBUG - 2022-12-15 06:49:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:49:51 --> Model "Login_model" initialized
INFO - 2022-12-15 06:49:51 --> Database Driver Class Initialized
INFO - 2022-12-15 06:49:51 --> Database Driver Class Initialized
INFO - 2022-12-15 06:49:51 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:49:51 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:49:51 --> Final output sent to browser
DEBUG - 2022-12-15 06:49:51 --> Total execution time: 0.0860
INFO - 2022-12-15 06:49:51 --> Final output sent to browser
DEBUG - 2022-12-15 06:49:51 --> Total execution time: 0.0699
INFO - 2022-12-15 06:49:53 --> Config Class Initialized
INFO - 2022-12-15 06:49:53 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:49:53 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:49:53 --> Utf8 Class Initialized
INFO - 2022-12-15 06:49:53 --> URI Class Initialized
INFO - 2022-12-15 06:49:53 --> Router Class Initialized
INFO - 2022-12-15 06:49:53 --> Output Class Initialized
INFO - 2022-12-15 06:49:53 --> Security Class Initialized
DEBUG - 2022-12-15 06:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:49:53 --> Input Class Initialized
INFO - 2022-12-15 06:49:53 --> Language Class Initialized
INFO - 2022-12-15 06:49:53 --> Loader Class Initialized
INFO - 2022-12-15 06:49:53 --> Controller Class Initialized
DEBUG - 2022-12-15 06:49:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:49:53 --> Database Driver Class Initialized
INFO - 2022-12-15 06:49:53 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:49:53 --> Database Driver Class Initialized
INFO - 2022-12-15 06:49:53 --> Model "Login_model" initialized
INFO - 2022-12-15 06:49:54 --> Final output sent to browser
DEBUG - 2022-12-15 06:49:54 --> Total execution time: 0.5778
INFO - 2022-12-15 06:49:54 --> Config Class Initialized
INFO - 2022-12-15 06:49:54 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:49:54 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:49:54 --> Utf8 Class Initialized
INFO - 2022-12-15 06:49:54 --> URI Class Initialized
INFO - 2022-12-15 06:49:54 --> Router Class Initialized
INFO - 2022-12-15 06:49:54 --> Output Class Initialized
INFO - 2022-12-15 06:49:54 --> Security Class Initialized
DEBUG - 2022-12-15 06:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:49:54 --> Input Class Initialized
INFO - 2022-12-15 06:49:54 --> Language Class Initialized
INFO - 2022-12-15 06:49:54 --> Loader Class Initialized
INFO - 2022-12-15 06:49:54 --> Controller Class Initialized
DEBUG - 2022-12-15 06:49:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:49:54 --> Database Driver Class Initialized
INFO - 2022-12-15 06:49:54 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:49:54 --> Database Driver Class Initialized
INFO - 2022-12-15 06:49:54 --> Model "Login_model" initialized
INFO - 2022-12-15 06:49:54 --> Final output sent to browser
DEBUG - 2022-12-15 06:49:54 --> Total execution time: 0.1477
INFO - 2022-12-15 06:50:02 --> Config Class Initialized
INFO - 2022-12-15 06:50:02 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:50:02 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:50:02 --> Utf8 Class Initialized
INFO - 2022-12-15 06:50:02 --> URI Class Initialized
INFO - 2022-12-15 06:50:02 --> Router Class Initialized
INFO - 2022-12-15 06:50:02 --> Output Class Initialized
INFO - 2022-12-15 06:50:02 --> Security Class Initialized
DEBUG - 2022-12-15 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:50:02 --> Input Class Initialized
INFO - 2022-12-15 06:50:02 --> Language Class Initialized
INFO - 2022-12-15 06:50:02 --> Loader Class Initialized
INFO - 2022-12-15 06:50:02 --> Controller Class Initialized
DEBUG - 2022-12-15 06:50:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:50:02 --> Database Driver Class Initialized
INFO - 2022-12-15 06:50:02 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:50:02 --> Final output sent to browser
DEBUG - 2022-12-15 06:50:02 --> Total execution time: 0.0622
INFO - 2022-12-15 06:50:02 --> Config Class Initialized
INFO - 2022-12-15 06:50:02 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:50:02 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:50:02 --> Utf8 Class Initialized
INFO - 2022-12-15 06:50:02 --> URI Class Initialized
INFO - 2022-12-15 06:50:02 --> Router Class Initialized
INFO - 2022-12-15 06:50:02 --> Output Class Initialized
INFO - 2022-12-15 06:50:02 --> Security Class Initialized
DEBUG - 2022-12-15 06:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:50:02 --> Input Class Initialized
INFO - 2022-12-15 06:50:02 --> Language Class Initialized
INFO - 2022-12-15 06:50:02 --> Loader Class Initialized
INFO - 2022-12-15 06:50:02 --> Controller Class Initialized
DEBUG - 2022-12-15 06:50:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:50:02 --> Database Driver Class Initialized
INFO - 2022-12-15 06:50:02 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:50:02 --> Final output sent to browser
DEBUG - 2022-12-15 06:50:02 --> Total execution time: 0.0500
INFO - 2022-12-15 06:50:03 --> Config Class Initialized
INFO - 2022-12-15 06:50:03 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:50:03 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:50:03 --> Utf8 Class Initialized
INFO - 2022-12-15 06:50:03 --> URI Class Initialized
INFO - 2022-12-15 06:50:03 --> Router Class Initialized
INFO - 2022-12-15 06:50:03 --> Output Class Initialized
INFO - 2022-12-15 06:50:03 --> Security Class Initialized
DEBUG - 2022-12-15 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:50:03 --> Input Class Initialized
INFO - 2022-12-15 06:50:03 --> Language Class Initialized
INFO - 2022-12-15 06:50:03 --> Loader Class Initialized
INFO - 2022-12-15 06:50:03 --> Controller Class Initialized
DEBUG - 2022-12-15 06:50:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:50:03 --> Final output sent to browser
DEBUG - 2022-12-15 06:50:03 --> Total execution time: 0.0199
INFO - 2022-12-15 06:50:03 --> Config Class Initialized
INFO - 2022-12-15 06:50:03 --> Hooks Class Initialized
DEBUG - 2022-12-15 06:50:03 --> UTF-8 Support Enabled
INFO - 2022-12-15 06:50:03 --> Utf8 Class Initialized
INFO - 2022-12-15 06:50:03 --> URI Class Initialized
INFO - 2022-12-15 06:50:03 --> Router Class Initialized
INFO - 2022-12-15 06:50:03 --> Output Class Initialized
INFO - 2022-12-15 06:50:03 --> Security Class Initialized
DEBUG - 2022-12-15 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 06:50:03 --> Input Class Initialized
INFO - 2022-12-15 06:50:03 --> Language Class Initialized
INFO - 2022-12-15 06:50:03 --> Loader Class Initialized
INFO - 2022-12-15 06:50:03 --> Controller Class Initialized
DEBUG - 2022-12-15 06:50:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 06:50:03 --> Database Driver Class Initialized
INFO - 2022-12-15 06:50:03 --> Model "Cluster_model" initialized
INFO - 2022-12-15 06:50:03 --> Final output sent to browser
DEBUG - 2022-12-15 06:50:03 --> Total execution time: 0.0512
INFO - 2022-12-15 07:05:40 --> Config Class Initialized
INFO - 2022-12-15 07:05:40 --> Hooks Class Initialized
DEBUG - 2022-12-15 07:05:40 --> UTF-8 Support Enabled
INFO - 2022-12-15 07:05:40 --> Utf8 Class Initialized
INFO - 2022-12-15 07:05:40 --> URI Class Initialized
INFO - 2022-12-15 07:05:40 --> Router Class Initialized
INFO - 2022-12-15 07:05:40 --> Output Class Initialized
INFO - 2022-12-15 07:05:40 --> Security Class Initialized
DEBUG - 2022-12-15 07:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 07:05:40 --> Input Class Initialized
INFO - 2022-12-15 07:05:40 --> Language Class Initialized
INFO - 2022-12-15 07:05:40 --> Loader Class Initialized
INFO - 2022-12-15 07:05:40 --> Controller Class Initialized
DEBUG - 2022-12-15 07:05:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 07:05:40 --> Database Driver Class Initialized
INFO - 2022-12-15 07:05:40 --> Model "Cluster_model" initialized
INFO - 2022-12-15 07:05:40 --> Final output sent to browser
DEBUG - 2022-12-15 07:05:40 --> Total execution time: 0.0510
INFO - 2022-12-15 07:05:40 --> Config Class Initialized
INFO - 2022-12-15 07:05:40 --> Hooks Class Initialized
DEBUG - 2022-12-15 07:05:40 --> UTF-8 Support Enabled
INFO - 2022-12-15 07:05:40 --> Utf8 Class Initialized
INFO - 2022-12-15 07:05:40 --> URI Class Initialized
INFO - 2022-12-15 07:05:40 --> Router Class Initialized
INFO - 2022-12-15 07:05:40 --> Output Class Initialized
INFO - 2022-12-15 07:05:40 --> Security Class Initialized
DEBUG - 2022-12-15 07:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 07:05:40 --> Input Class Initialized
INFO - 2022-12-15 07:05:40 --> Language Class Initialized
INFO - 2022-12-15 07:05:40 --> Loader Class Initialized
INFO - 2022-12-15 07:05:40 --> Controller Class Initialized
DEBUG - 2022-12-15 07:05:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 07:05:40 --> Database Driver Class Initialized
INFO - 2022-12-15 07:05:40 --> Model "Cluster_model" initialized
INFO - 2022-12-15 07:05:40 --> Final output sent to browser
DEBUG - 2022-12-15 07:05:40 --> Total execution time: 0.0569
INFO - 2022-12-15 07:05:42 --> Config Class Initialized
INFO - 2022-12-15 07:05:42 --> Hooks Class Initialized
INFO - 2022-12-15 07:05:42 --> Config Class Initialized
INFO - 2022-12-15 07:05:42 --> Hooks Class Initialized
DEBUG - 2022-12-15 07:05:42 --> UTF-8 Support Enabled
INFO - 2022-12-15 07:05:42 --> Utf8 Class Initialized
DEBUG - 2022-12-15 07:05:42 --> UTF-8 Support Enabled
INFO - 2022-12-15 07:05:42 --> Utf8 Class Initialized
INFO - 2022-12-15 07:05:42 --> URI Class Initialized
INFO - 2022-12-15 07:05:42 --> URI Class Initialized
INFO - 2022-12-15 07:05:42 --> Router Class Initialized
INFO - 2022-12-15 07:05:42 --> Router Class Initialized
INFO - 2022-12-15 07:05:42 --> Output Class Initialized
INFO - 2022-12-15 07:05:42 --> Output Class Initialized
INFO - 2022-12-15 07:05:42 --> Security Class Initialized
INFO - 2022-12-15 07:05:42 --> Security Class Initialized
DEBUG - 2022-12-15 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 07:05:42 --> Input Class Initialized
DEBUG - 2022-12-15 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 07:05:42 --> Input Class Initialized
INFO - 2022-12-15 07:05:42 --> Language Class Initialized
INFO - 2022-12-15 07:05:42 --> Language Class Initialized
INFO - 2022-12-15 07:05:42 --> Loader Class Initialized
INFO - 2022-12-15 07:05:42 --> Controller Class Initialized
DEBUG - 2022-12-15 07:05:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 07:05:42 --> Database Driver Class Initialized
INFO - 2022-12-15 07:05:42 --> Loader Class Initialized
INFO - 2022-12-15 07:05:42 --> Controller Class Initialized
DEBUG - 2022-12-15 07:05:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 07:05:42 --> Final output sent to browser
DEBUG - 2022-12-15 07:05:42 --> Total execution time: 0.0293
INFO - 2022-12-15 07:05:42 --> Model "Cluster_model" initialized
INFO - 2022-12-15 07:05:42 --> Config Class Initialized
INFO - 2022-12-15 07:05:42 --> Hooks Class Initialized
DEBUG - 2022-12-15 07:05:42 --> UTF-8 Support Enabled
INFO - 2022-12-15 07:05:42 --> Utf8 Class Initialized
INFO - 2022-12-15 07:05:42 --> URI Class Initialized
INFO - 2022-12-15 07:05:42 --> Router Class Initialized
INFO - 2022-12-15 07:05:42 --> Output Class Initialized
INFO - 2022-12-15 07:05:42 --> Security Class Initialized
DEBUG - 2022-12-15 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 07:05:42 --> Input Class Initialized
INFO - 2022-12-15 07:05:42 --> Language Class Initialized
INFO - 2022-12-15 07:05:42 --> Loader Class Initialized
INFO - 2022-12-15 07:05:42 --> Controller Class Initialized
DEBUG - 2022-12-15 07:05:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 07:05:42 --> Database Driver Class Initialized
INFO - 2022-12-15 07:05:42 --> Final output sent to browser
DEBUG - 2022-12-15 07:05:42 --> Total execution time: 0.0623
INFO - 2022-12-15 07:05:42 --> Config Class Initialized
INFO - 2022-12-15 07:05:42 --> Hooks Class Initialized
DEBUG - 2022-12-15 07:05:42 --> UTF-8 Support Enabled
INFO - 2022-12-15 07:05:42 --> Utf8 Class Initialized
INFO - 2022-12-15 07:05:42 --> URI Class Initialized
INFO - 2022-12-15 07:05:42 --> Router Class Initialized
INFO - 2022-12-15 07:05:42 --> Output Class Initialized
INFO - 2022-12-15 07:05:42 --> Model "Login_model" initialized
INFO - 2022-12-15 07:05:42 --> Security Class Initialized
DEBUG - 2022-12-15 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 07:05:42 --> Input Class Initialized
INFO - 2022-12-15 07:05:42 --> Language Class Initialized
INFO - 2022-12-15 07:05:42 --> Database Driver Class Initialized
INFO - 2022-12-15 07:05:42 --> Loader Class Initialized
INFO - 2022-12-15 07:05:42 --> Controller Class Initialized
DEBUG - 2022-12-15 07:05:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 07:05:42 --> Database Driver Class Initialized
INFO - 2022-12-15 07:05:42 --> Model "Cluster_model" initialized
INFO - 2022-12-15 07:05:42 --> Final output sent to browser
DEBUG - 2022-12-15 07:05:42 --> Total execution time: 0.0755
INFO - 2022-12-15 07:05:42 --> Model "Cluster_model" initialized
INFO - 2022-12-15 07:05:42 --> Final output sent to browser
DEBUG - 2022-12-15 07:05:42 --> Total execution time: 0.0609
INFO - 2022-12-15 08:52:31 --> Config Class Initialized
INFO - 2022-12-15 08:52:31 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:52:31 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:52:31 --> Utf8 Class Initialized
INFO - 2022-12-15 08:52:31 --> URI Class Initialized
INFO - 2022-12-15 08:52:31 --> Router Class Initialized
INFO - 2022-12-15 08:52:31 --> Output Class Initialized
INFO - 2022-12-15 08:52:31 --> Security Class Initialized
DEBUG - 2022-12-15 08:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:52:31 --> Input Class Initialized
INFO - 2022-12-15 08:52:31 --> Language Class Initialized
INFO - 2022-12-15 08:52:31 --> Loader Class Initialized
INFO - 2022-12-15 08:52:31 --> Controller Class Initialized
DEBUG - 2022-12-15 08:52:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 08:52:31 --> Database Driver Class Initialized
INFO - 2022-12-15 08:52:31 --> Model "Cluster_model" initialized
INFO - 2022-12-15 08:52:31 --> Database Driver Class Initialized
INFO - 2022-12-15 08:52:31 --> Model "Login_model" initialized
INFO - 2022-12-15 08:52:31 --> Final output sent to browser
DEBUG - 2022-12-15 08:52:31 --> Total execution time: 0.1263
INFO - 2022-12-15 08:52:31 --> Config Class Initialized
INFO - 2022-12-15 08:52:31 --> Hooks Class Initialized
DEBUG - 2022-12-15 08:52:31 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:52:31 --> Utf8 Class Initialized
INFO - 2022-12-15 08:52:31 --> URI Class Initialized
INFO - 2022-12-15 08:52:31 --> Router Class Initialized
INFO - 2022-12-15 08:52:31 --> Output Class Initialized
INFO - 2022-12-15 08:52:31 --> Security Class Initialized
DEBUG - 2022-12-15 08:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:52:31 --> Input Class Initialized
INFO - 2022-12-15 08:52:31 --> Language Class Initialized
INFO - 2022-12-15 08:52:31 --> Loader Class Initialized
INFO - 2022-12-15 08:52:31 --> Controller Class Initialized
DEBUG - 2022-12-15 08:52:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 08:52:31 --> Database Driver Class Initialized
INFO - 2022-12-15 08:52:32 --> Model "Cluster_model" initialized
INFO - 2022-12-15 08:52:32 --> Database Driver Class Initialized
INFO - 2022-12-15 08:52:32 --> Model "Login_model" initialized
INFO - 2022-12-15 08:52:32 --> Final output sent to browser
DEBUG - 2022-12-15 08:52:32 --> Total execution time: 0.6484
INFO - 2022-12-15 08:52:35 --> Config Class Initialized
INFO - 2022-12-15 08:52:35 --> Hooks Class Initialized
INFO - 2022-12-15 08:52:35 --> Config Class Initialized
DEBUG - 2022-12-15 08:52:35 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:52:35 --> Hooks Class Initialized
INFO - 2022-12-15 08:52:35 --> Utf8 Class Initialized
INFO - 2022-12-15 08:52:35 --> URI Class Initialized
DEBUG - 2022-12-15 08:52:35 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:52:35 --> Router Class Initialized
INFO - 2022-12-15 08:52:35 --> Utf8 Class Initialized
INFO - 2022-12-15 08:52:35 --> URI Class Initialized
INFO - 2022-12-15 08:52:35 --> Output Class Initialized
INFO - 2022-12-15 08:52:35 --> Security Class Initialized
INFO - 2022-12-15 08:52:35 --> Router Class Initialized
DEBUG - 2022-12-15 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:52:35 --> Input Class Initialized
INFO - 2022-12-15 08:52:35 --> Output Class Initialized
INFO - 2022-12-15 08:52:35 --> Language Class Initialized
INFO - 2022-12-15 08:52:35 --> Security Class Initialized
DEBUG - 2022-12-15 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:52:35 --> Input Class Initialized
INFO - 2022-12-15 08:52:35 --> Language Class Initialized
INFO - 2022-12-15 08:52:35 --> Loader Class Initialized
INFO - 2022-12-15 08:52:35 --> Controller Class Initialized
DEBUG - 2022-12-15 08:52:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 08:52:35 --> Final output sent to browser
DEBUG - 2022-12-15 08:52:35 --> Total execution time: 0.0243
INFO - 2022-12-15 08:52:35 --> Loader Class Initialized
INFO - 2022-12-15 08:52:35 --> Controller Class Initialized
DEBUG - 2022-12-15 08:52:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 08:52:35 --> Config Class Initialized
INFO - 2022-12-15 08:52:35 --> Hooks Class Initialized
INFO - 2022-12-15 08:52:35 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:52:35 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:52:35 --> Utf8 Class Initialized
INFO - 2022-12-15 08:52:35 --> URI Class Initialized
INFO - 2022-12-15 08:52:35 --> Router Class Initialized
INFO - 2022-12-15 08:52:35 --> Output Class Initialized
INFO - 2022-12-15 08:52:35 --> Security Class Initialized
INFO - 2022-12-15 08:52:35 --> Model "Cluster_model" initialized
DEBUG - 2022-12-15 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:52:35 --> Input Class Initialized
INFO - 2022-12-15 08:52:35 --> Language Class Initialized
INFO - 2022-12-15 08:52:35 --> Final output sent to browser
DEBUG - 2022-12-15 08:52:35 --> Total execution time: 0.0470
INFO - 2022-12-15 08:52:35 --> Loader Class Initialized
INFO - 2022-12-15 08:52:35 --> Controller Class Initialized
DEBUG - 2022-12-15 08:52:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 08:52:35 --> Config Class Initialized
INFO - 2022-12-15 08:52:35 --> Hooks Class Initialized
INFO - 2022-12-15 08:52:35 --> Database Driver Class Initialized
DEBUG - 2022-12-15 08:52:35 --> UTF-8 Support Enabled
INFO - 2022-12-15 08:52:35 --> Utf8 Class Initialized
INFO - 2022-12-15 08:52:35 --> URI Class Initialized
INFO - 2022-12-15 08:52:35 --> Router Class Initialized
INFO - 2022-12-15 08:52:35 --> Output Class Initialized
INFO - 2022-12-15 08:52:35 --> Security Class Initialized
DEBUG - 2022-12-15 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 08:52:35 --> Input Class Initialized
INFO - 2022-12-15 08:52:35 --> Language Class Initialized
INFO - 2022-12-15 08:52:35 --> Loader Class Initialized
INFO - 2022-12-15 08:52:35 --> Controller Class Initialized
DEBUG - 2022-12-15 08:52:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 08:52:35 --> Model "Cluster_model" initialized
INFO - 2022-12-15 08:52:35 --> Final output sent to browser
DEBUG - 2022-12-15 08:52:35 --> Total execution time: 0.0535
INFO - 2022-12-15 08:52:35 --> Database Driver Class Initialized
INFO - 2022-12-15 08:52:35 --> Model "Cluster_model" initialized
INFO - 2022-12-15 08:52:35 --> Final output sent to browser
DEBUG - 2022-12-15 08:52:35 --> Total execution time: 0.0590
INFO - 2022-12-15 09:26:03 --> Config Class Initialized
INFO - 2022-12-15 09:26:03 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:26:03 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:26:03 --> Utf8 Class Initialized
INFO - 2022-12-15 09:26:03 --> URI Class Initialized
INFO - 2022-12-15 09:26:03 --> Router Class Initialized
INFO - 2022-12-15 09:26:03 --> Output Class Initialized
INFO - 2022-12-15 09:26:03 --> Security Class Initialized
DEBUG - 2022-12-15 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:26:03 --> Input Class Initialized
INFO - 2022-12-15 09:26:03 --> Language Class Initialized
INFO - 2022-12-15 09:26:03 --> Loader Class Initialized
INFO - 2022-12-15 09:26:03 --> Controller Class Initialized
DEBUG - 2022-12-15 09:26:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:26:03 --> Database Driver Class Initialized
INFO - 2022-12-15 09:26:03 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:26:03 --> Final output sent to browser
DEBUG - 2022-12-15 09:26:03 --> Total execution time: 0.1455
INFO - 2022-12-15 09:26:03 --> Config Class Initialized
INFO - 2022-12-15 09:26:03 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:26:03 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:26:03 --> Utf8 Class Initialized
INFO - 2022-12-15 09:26:03 --> URI Class Initialized
INFO - 2022-12-15 09:26:03 --> Router Class Initialized
INFO - 2022-12-15 09:26:03 --> Output Class Initialized
INFO - 2022-12-15 09:26:03 --> Security Class Initialized
DEBUG - 2022-12-15 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:26:03 --> Input Class Initialized
INFO - 2022-12-15 09:26:03 --> Language Class Initialized
INFO - 2022-12-15 09:26:03 --> Loader Class Initialized
INFO - 2022-12-15 09:26:03 --> Controller Class Initialized
DEBUG - 2022-12-15 09:26:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:26:03 --> Database Driver Class Initialized
INFO - 2022-12-15 09:26:03 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:26:03 --> Final output sent to browser
DEBUG - 2022-12-15 09:26:03 --> Total execution time: 0.1225
INFO - 2022-12-15 09:37:06 --> Config Class Initialized
INFO - 2022-12-15 09:37:06 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:37:06 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:37:06 --> Utf8 Class Initialized
INFO - 2022-12-15 09:37:06 --> URI Class Initialized
INFO - 2022-12-15 09:37:06 --> Router Class Initialized
INFO - 2022-12-15 09:37:06 --> Output Class Initialized
INFO - 2022-12-15 09:37:06 --> Security Class Initialized
DEBUG - 2022-12-15 09:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:37:06 --> Input Class Initialized
INFO - 2022-12-15 09:37:06 --> Language Class Initialized
INFO - 2022-12-15 09:37:06 --> Loader Class Initialized
INFO - 2022-12-15 09:37:06 --> Controller Class Initialized
DEBUG - 2022-12-15 09:37:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:37:06 --> Final output sent to browser
DEBUG - 2022-12-15 09:37:06 --> Total execution time: 0.0300
INFO - 2022-12-15 09:37:06 --> Config Class Initialized
INFO - 2022-12-15 09:37:06 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:37:06 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:37:06 --> Utf8 Class Initialized
INFO - 2022-12-15 09:37:06 --> URI Class Initialized
INFO - 2022-12-15 09:37:06 --> Router Class Initialized
INFO - 2022-12-15 09:37:06 --> Output Class Initialized
INFO - 2022-12-15 09:37:06 --> Security Class Initialized
DEBUG - 2022-12-15 09:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:37:06 --> Input Class Initialized
INFO - 2022-12-15 09:37:06 --> Language Class Initialized
INFO - 2022-12-15 09:37:06 --> Loader Class Initialized
INFO - 2022-12-15 09:37:06 --> Controller Class Initialized
DEBUG - 2022-12-15 09:37:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:37:06 --> Database Driver Class Initialized
INFO - 2022-12-15 09:37:06 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:37:06 --> Final output sent to browser
DEBUG - 2022-12-15 09:37:06 --> Total execution time: 0.0751
INFO - 2022-12-15 09:37:07 --> Config Class Initialized
INFO - 2022-12-15 09:37:07 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:37:07 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:37:07 --> Utf8 Class Initialized
INFO - 2022-12-15 09:37:07 --> URI Class Initialized
INFO - 2022-12-15 09:37:07 --> Router Class Initialized
INFO - 2022-12-15 09:37:07 --> Output Class Initialized
INFO - 2022-12-15 09:37:07 --> Security Class Initialized
DEBUG - 2022-12-15 09:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:37:07 --> Input Class Initialized
INFO - 2022-12-15 09:37:07 --> Language Class Initialized
INFO - 2022-12-15 09:37:07 --> Loader Class Initialized
INFO - 2022-12-15 09:37:07 --> Controller Class Initialized
DEBUG - 2022-12-15 09:37:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:37:07 --> Database Driver Class Initialized
INFO - 2022-12-15 09:37:07 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:37:07 --> Final output sent to browser
DEBUG - 2022-12-15 09:37:07 --> Total execution time: 0.0511
INFO - 2022-12-15 09:37:07 --> Config Class Initialized
INFO - 2022-12-15 09:37:07 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:37:07 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:37:07 --> Utf8 Class Initialized
INFO - 2022-12-15 09:37:07 --> URI Class Initialized
INFO - 2022-12-15 09:37:07 --> Router Class Initialized
INFO - 2022-12-15 09:37:07 --> Output Class Initialized
INFO - 2022-12-15 09:37:07 --> Security Class Initialized
DEBUG - 2022-12-15 09:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:37:07 --> Input Class Initialized
INFO - 2022-12-15 09:37:07 --> Language Class Initialized
INFO - 2022-12-15 09:37:07 --> Loader Class Initialized
INFO - 2022-12-15 09:37:07 --> Controller Class Initialized
DEBUG - 2022-12-15 09:37:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:37:07 --> Database Driver Class Initialized
INFO - 2022-12-15 09:37:07 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:37:07 --> Final output sent to browser
DEBUG - 2022-12-15 09:37:07 --> Total execution time: 0.0497
INFO - 2022-12-15 09:37:09 --> Config Class Initialized
INFO - 2022-12-15 09:37:09 --> Hooks Class Initialized
INFO - 2022-12-15 09:37:09 --> Config Class Initialized
INFO - 2022-12-15 09:37:09 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:37:09 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:37:09 --> Utf8 Class Initialized
INFO - 2022-12-15 09:37:09 --> URI Class Initialized
DEBUG - 2022-12-15 09:37:09 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:37:09 --> Utf8 Class Initialized
INFO - 2022-12-15 09:37:09 --> URI Class Initialized
INFO - 2022-12-15 09:37:09 --> Router Class Initialized
INFO - 2022-12-15 09:37:09 --> Router Class Initialized
INFO - 2022-12-15 09:37:09 --> Output Class Initialized
INFO - 2022-12-15 09:37:09 --> Security Class Initialized
INFO - 2022-12-15 09:37:09 --> Output Class Initialized
DEBUG - 2022-12-15 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:37:09 --> Input Class Initialized
INFO - 2022-12-15 09:37:09 --> Security Class Initialized
INFO - 2022-12-15 09:37:09 --> Language Class Initialized
DEBUG - 2022-12-15 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:37:09 --> Input Class Initialized
INFO - 2022-12-15 09:37:09 --> Language Class Initialized
INFO - 2022-12-15 09:37:09 --> Loader Class Initialized
INFO - 2022-12-15 09:37:09 --> Controller Class Initialized
DEBUG - 2022-12-15 09:37:09 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:37:09 --> Loader Class Initialized
INFO - 2022-12-15 09:37:09 --> Controller Class Initialized
DEBUG - 2022-12-15 09:37:09 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:37:09 --> Database Driver Class Initialized
INFO - 2022-12-15 09:37:09 --> Database Driver Class Initialized
INFO - 2022-12-15 09:37:09 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:37:09 --> Final output sent to browser
DEBUG - 2022-12-15 09:37:09 --> Total execution time: 0.0486
INFO - 2022-12-15 09:37:09 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:37:09 --> Final output sent to browser
DEBUG - 2022-12-15 09:37:09 --> Total execution time: 0.0541
INFO - 2022-12-15 09:37:09 --> Config Class Initialized
INFO - 2022-12-15 09:37:09 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:37:09 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:37:09 --> Utf8 Class Initialized
INFO - 2022-12-15 09:37:09 --> URI Class Initialized
INFO - 2022-12-15 09:37:09 --> Router Class Initialized
INFO - 2022-12-15 09:37:09 --> Output Class Initialized
INFO - 2022-12-15 09:37:09 --> Security Class Initialized
DEBUG - 2022-12-15 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:37:09 --> Input Class Initialized
INFO - 2022-12-15 09:37:09 --> Language Class Initialized
INFO - 2022-12-15 09:37:09 --> Loader Class Initialized
INFO - 2022-12-15 09:37:09 --> Controller Class Initialized
DEBUG - 2022-12-15 09:37:09 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:37:09 --> Database Driver Class Initialized
INFO - 2022-12-15 09:37:09 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:37:09 --> Final output sent to browser
DEBUG - 2022-12-15 09:37:09 --> Total execution time: 0.0340
INFO - 2022-12-15 09:41:16 --> Config Class Initialized
INFO - 2022-12-15 09:41:16 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:16 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:16 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:16 --> URI Class Initialized
INFO - 2022-12-15 09:41:16 --> Router Class Initialized
INFO - 2022-12-15 09:41:16 --> Output Class Initialized
INFO - 2022-12-15 09:41:16 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:16 --> Input Class Initialized
INFO - 2022-12-15 09:41:16 --> Language Class Initialized
INFO - 2022-12-15 09:41:16 --> Loader Class Initialized
INFO - 2022-12-15 09:41:16 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:16 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:16 --> Total execution time: 0.0209
INFO - 2022-12-15 09:41:16 --> Config Class Initialized
INFO - 2022-12-15 09:41:16 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:16 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:16 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:16 --> URI Class Initialized
INFO - 2022-12-15 09:41:16 --> Router Class Initialized
INFO - 2022-12-15 09:41:16 --> Output Class Initialized
INFO - 2022-12-15 09:41:16 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:16 --> Input Class Initialized
INFO - 2022-12-15 09:41:16 --> Language Class Initialized
INFO - 2022-12-15 09:41:16 --> Loader Class Initialized
INFO - 2022-12-15 09:41:16 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:16 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:16 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:17 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:17 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:17 --> Total execution time: 0.0612
INFO - 2022-12-15 09:41:17 --> Config Class Initialized
INFO - 2022-12-15 09:41:17 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:17 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:17 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:17 --> URI Class Initialized
INFO - 2022-12-15 09:41:17 --> Router Class Initialized
INFO - 2022-12-15 09:41:17 --> Output Class Initialized
INFO - 2022-12-15 09:41:17 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:17 --> Input Class Initialized
INFO - 2022-12-15 09:41:17 --> Language Class Initialized
INFO - 2022-12-15 09:41:17 --> Loader Class Initialized
INFO - 2022-12-15 09:41:17 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:17 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:17 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:17 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:17 --> Total execution time: 0.0543
INFO - 2022-12-15 09:41:17 --> Config Class Initialized
INFO - 2022-12-15 09:41:17 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:17 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:17 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:17 --> URI Class Initialized
INFO - 2022-12-15 09:41:17 --> Router Class Initialized
INFO - 2022-12-15 09:41:17 --> Output Class Initialized
INFO - 2022-12-15 09:41:17 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:17 --> Input Class Initialized
INFO - 2022-12-15 09:41:17 --> Language Class Initialized
INFO - 2022-12-15 09:41:17 --> Loader Class Initialized
INFO - 2022-12-15 09:41:17 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:17 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:17 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:17 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:17 --> Total execution time: 0.0529
INFO - 2022-12-15 09:41:18 --> Config Class Initialized
INFO - 2022-12-15 09:41:18 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:18 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:18 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:18 --> URI Class Initialized
INFO - 2022-12-15 09:41:18 --> Router Class Initialized
INFO - 2022-12-15 09:41:18 --> Output Class Initialized
INFO - 2022-12-15 09:41:18 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:18 --> Input Class Initialized
INFO - 2022-12-15 09:41:18 --> Language Class Initialized
INFO - 2022-12-15 09:41:18 --> Loader Class Initialized
INFO - 2022-12-15 09:41:18 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:18 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:18 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:18 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:18 --> Total execution time: 0.0338
INFO - 2022-12-15 09:41:18 --> Config Class Initialized
INFO - 2022-12-15 09:41:18 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:18 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:18 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:18 --> URI Class Initialized
INFO - 2022-12-15 09:41:18 --> Router Class Initialized
INFO - 2022-12-15 09:41:18 --> Output Class Initialized
INFO - 2022-12-15 09:41:18 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:18 --> Input Class Initialized
INFO - 2022-12-15 09:41:18 --> Language Class Initialized
INFO - 2022-12-15 09:41:18 --> Loader Class Initialized
INFO - 2022-12-15 09:41:18 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:18 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:18 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:18 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:18 --> Total execution time: 0.0527
INFO - 2022-12-15 09:41:19 --> Config Class Initialized
INFO - 2022-12-15 09:41:19 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:19 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:19 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:19 --> URI Class Initialized
INFO - 2022-12-15 09:41:19 --> Router Class Initialized
INFO - 2022-12-15 09:41:19 --> Output Class Initialized
INFO - 2022-12-15 09:41:19 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:19 --> Input Class Initialized
INFO - 2022-12-15 09:41:19 --> Language Class Initialized
INFO - 2022-12-15 09:41:19 --> Loader Class Initialized
INFO - 2022-12-15 09:41:19 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:19 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:19 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:19 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:19 --> Total execution time: 0.0415
INFO - 2022-12-15 09:41:19 --> Config Class Initialized
INFO - 2022-12-15 09:41:19 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:19 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:19 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:19 --> URI Class Initialized
INFO - 2022-12-15 09:41:19 --> Router Class Initialized
INFO - 2022-12-15 09:41:19 --> Output Class Initialized
INFO - 2022-12-15 09:41:19 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:19 --> Input Class Initialized
INFO - 2022-12-15 09:41:19 --> Language Class Initialized
INFO - 2022-12-15 09:41:19 --> Loader Class Initialized
INFO - 2022-12-15 09:41:19 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:19 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:19 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:19 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:19 --> Total execution time: 0.0390
INFO - 2022-12-15 09:41:23 --> Config Class Initialized
INFO - 2022-12-15 09:41:23 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:23 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:23 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:23 --> URI Class Initialized
INFO - 2022-12-15 09:41:23 --> Router Class Initialized
INFO - 2022-12-15 09:41:23 --> Output Class Initialized
INFO - 2022-12-15 09:41:23 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:23 --> Input Class Initialized
INFO - 2022-12-15 09:41:23 --> Language Class Initialized
INFO - 2022-12-15 09:41:23 --> Loader Class Initialized
INFO - 2022-12-15 09:41:23 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:23 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:23 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:23 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:24 --> Total execution time: 0.0601
INFO - 2022-12-15 09:41:24 --> Config Class Initialized
INFO - 2022-12-15 09:41:24 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:24 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:24 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:24 --> URI Class Initialized
INFO - 2022-12-15 09:41:24 --> Router Class Initialized
INFO - 2022-12-15 09:41:24 --> Output Class Initialized
INFO - 2022-12-15 09:41:24 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:24 --> Input Class Initialized
INFO - 2022-12-15 09:41:24 --> Language Class Initialized
INFO - 2022-12-15 09:41:24 --> Loader Class Initialized
INFO - 2022-12-15 09:41:24 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:24 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:24 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:24 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:24 --> Total execution time: 0.0584
INFO - 2022-12-15 09:41:25 --> Config Class Initialized
INFO - 2022-12-15 09:41:25 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:25 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:25 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:25 --> URI Class Initialized
INFO - 2022-12-15 09:41:25 --> Router Class Initialized
INFO - 2022-12-15 09:41:25 --> Output Class Initialized
INFO - 2022-12-15 09:41:25 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:25 --> Input Class Initialized
INFO - 2022-12-15 09:41:25 --> Language Class Initialized
INFO - 2022-12-15 09:41:25 --> Loader Class Initialized
INFO - 2022-12-15 09:41:25 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:25 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:25 --> Total execution time: 0.0198
INFO - 2022-12-15 09:41:25 --> Config Class Initialized
INFO - 2022-12-15 09:41:25 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:25 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:25 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:25 --> URI Class Initialized
INFO - 2022-12-15 09:41:25 --> Router Class Initialized
INFO - 2022-12-15 09:41:25 --> Output Class Initialized
INFO - 2022-12-15 09:41:25 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:25 --> Input Class Initialized
INFO - 2022-12-15 09:41:25 --> Language Class Initialized
INFO - 2022-12-15 09:41:25 --> Loader Class Initialized
INFO - 2022-12-15 09:41:25 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:25 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:25 --> Model "Login_model" initialized
INFO - 2022-12-15 09:41:25 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:25 --> Model "Cluster_model" initialized
ERROR - 2022-12-15 09:41:25 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-15 09:41:25 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-15 09:41:25 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-15 09:41:25 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-15 09:41:26 --> Config Class Initialized
INFO - 2022-12-15 09:41:26 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:26 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:26 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:26 --> URI Class Initialized
INFO - 2022-12-15 09:41:26 --> Router Class Initialized
INFO - 2022-12-15 09:41:26 --> Output Class Initialized
INFO - 2022-12-15 09:41:26 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:26 --> Input Class Initialized
INFO - 2022-12-15 09:41:26 --> Language Class Initialized
INFO - 2022-12-15 09:41:26 --> Loader Class Initialized
INFO - 2022-12-15 09:41:26 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:26 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:26 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:26 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:26 --> Model "Login_model" initialized
INFO - 2022-12-15 09:41:26 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:26 --> Total execution time: 0.0899
INFO - 2022-12-15 09:41:26 --> Config Class Initialized
INFO - 2022-12-15 09:41:26 --> Hooks Class Initialized
DEBUG - 2022-12-15 09:41:26 --> UTF-8 Support Enabled
INFO - 2022-12-15 09:41:26 --> Utf8 Class Initialized
INFO - 2022-12-15 09:41:26 --> URI Class Initialized
INFO - 2022-12-15 09:41:26 --> Router Class Initialized
INFO - 2022-12-15 09:41:26 --> Output Class Initialized
INFO - 2022-12-15 09:41:26 --> Security Class Initialized
DEBUG - 2022-12-15 09:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 09:41:26 --> Input Class Initialized
INFO - 2022-12-15 09:41:26 --> Language Class Initialized
INFO - 2022-12-15 09:41:26 --> Loader Class Initialized
INFO - 2022-12-15 09:41:26 --> Controller Class Initialized
DEBUG - 2022-12-15 09:41:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 09:41:26 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:26 --> Model "Cluster_model" initialized
INFO - 2022-12-15 09:41:26 --> Database Driver Class Initialized
INFO - 2022-12-15 09:41:26 --> Model "Login_model" initialized
INFO - 2022-12-15 09:41:26 --> Final output sent to browser
DEBUG - 2022-12-15 09:41:26 --> Total execution time: 0.1110
INFO - 2022-12-15 10:15:57 --> Config Class Initialized
INFO - 2022-12-15 10:15:57 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:15:57 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:15:57 --> Utf8 Class Initialized
INFO - 2022-12-15 10:15:57 --> URI Class Initialized
INFO - 2022-12-15 10:15:57 --> Router Class Initialized
INFO - 2022-12-15 10:15:57 --> Output Class Initialized
INFO - 2022-12-15 10:15:57 --> Security Class Initialized
DEBUG - 2022-12-15 10:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:15:57 --> Input Class Initialized
INFO - 2022-12-15 10:15:57 --> Language Class Initialized
INFO - 2022-12-15 10:15:57 --> Loader Class Initialized
INFO - 2022-12-15 10:15:57 --> Controller Class Initialized
DEBUG - 2022-12-15 10:15:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:15:57 --> Database Driver Class Initialized
INFO - 2022-12-15 10:15:57 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:15:57 --> Final output sent to browser
DEBUG - 2022-12-15 10:15:57 --> Total execution time: 0.0681
INFO - 2022-12-15 10:15:57 --> Config Class Initialized
INFO - 2022-12-15 10:15:57 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:15:57 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:15:57 --> Utf8 Class Initialized
INFO - 2022-12-15 10:15:57 --> URI Class Initialized
INFO - 2022-12-15 10:15:57 --> Router Class Initialized
INFO - 2022-12-15 10:15:57 --> Output Class Initialized
INFO - 2022-12-15 10:15:57 --> Security Class Initialized
DEBUG - 2022-12-15 10:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:15:57 --> Input Class Initialized
INFO - 2022-12-15 10:15:57 --> Language Class Initialized
INFO - 2022-12-15 10:15:57 --> Loader Class Initialized
INFO - 2022-12-15 10:15:57 --> Controller Class Initialized
DEBUG - 2022-12-15 10:15:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:15:57 --> Database Driver Class Initialized
INFO - 2022-12-15 10:15:57 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:15:57 --> Final output sent to browser
DEBUG - 2022-12-15 10:15:57 --> Total execution time: 0.0795
INFO - 2022-12-15 10:16:00 --> Config Class Initialized
INFO - 2022-12-15 10:16:00 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:16:00 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:00 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:00 --> URI Class Initialized
INFO - 2022-12-15 10:16:00 --> Router Class Initialized
INFO - 2022-12-15 10:16:00 --> Output Class Initialized
INFO - 2022-12-15 10:16:00 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:00 --> Input Class Initialized
INFO - 2022-12-15 10:16:00 --> Language Class Initialized
INFO - 2022-12-15 10:16:00 --> Loader Class Initialized
INFO - 2022-12-15 10:16:00 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:00 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:00 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:00 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:00 --> Total execution time: 0.0845
INFO - 2022-12-15 10:16:00 --> Config Class Initialized
INFO - 2022-12-15 10:16:00 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:16:00 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:00 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:00 --> URI Class Initialized
INFO - 2022-12-15 10:16:00 --> Router Class Initialized
INFO - 2022-12-15 10:16:00 --> Output Class Initialized
INFO - 2022-12-15 10:16:00 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:00 --> Input Class Initialized
INFO - 2022-12-15 10:16:00 --> Language Class Initialized
INFO - 2022-12-15 10:16:00 --> Loader Class Initialized
INFO - 2022-12-15 10:16:00 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:00 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:00 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:00 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:00 --> Total execution time: 0.0447
INFO - 2022-12-15 10:16:01 --> Config Class Initialized
INFO - 2022-12-15 10:16:01 --> Hooks Class Initialized
INFO - 2022-12-15 10:16:01 --> Config Class Initialized
INFO - 2022-12-15 10:16:01 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:16:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:01 --> Utf8 Class Initialized
DEBUG - 2022-12-15 10:16:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:01 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:01 --> URI Class Initialized
INFO - 2022-12-15 10:16:01 --> URI Class Initialized
INFO - 2022-12-15 10:16:01 --> Router Class Initialized
INFO - 2022-12-15 10:16:01 --> Router Class Initialized
INFO - 2022-12-15 10:16:01 --> Output Class Initialized
INFO - 2022-12-15 10:16:01 --> Output Class Initialized
INFO - 2022-12-15 10:16:01 --> Security Class Initialized
INFO - 2022-12-15 10:16:01 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:01 --> Input Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:01 --> Input Class Initialized
INFO - 2022-12-15 10:16:01 --> Language Class Initialized
INFO - 2022-12-15 10:16:01 --> Language Class Initialized
INFO - 2022-12-15 10:16:01 --> Loader Class Initialized
INFO - 2022-12-15 10:16:01 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:01 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:01 --> Loader Class Initialized
INFO - 2022-12-15 10:16:01 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:01 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:01 --> Total execution time: 0.0305
INFO - 2022-12-15 10:16:01 --> Config Class Initialized
INFO - 2022-12-15 10:16:01 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:16:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:01 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:01 --> URI Class Initialized
INFO - 2022-12-15 10:16:01 --> Router Class Initialized
INFO - 2022-12-15 10:16:01 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:01 --> Output Class Initialized
INFO - 2022-12-15 10:16:01 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:01 --> Final output sent to browser
INFO - 2022-12-15 10:16:01 --> Input Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Total execution time: 0.0513
INFO - 2022-12-15 10:16:01 --> Language Class Initialized
INFO - 2022-12-15 10:16:01 --> Loader Class Initialized
INFO - 2022-12-15 10:16:01 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:01 --> Config Class Initialized
INFO - 2022-12-15 10:16:01 --> Hooks Class Initialized
INFO - 2022-12-15 10:16:01 --> Database Driver Class Initialized
DEBUG - 2022-12-15 10:16:01 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:01 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:01 --> URI Class Initialized
INFO - 2022-12-15 10:16:01 --> Router Class Initialized
INFO - 2022-12-15 10:16:01 --> Output Class Initialized
INFO - 2022-12-15 10:16:01 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:01 --> Input Class Initialized
INFO - 2022-12-15 10:16:01 --> Language Class Initialized
INFO - 2022-12-15 10:16:01 --> Loader Class Initialized
INFO - 2022-12-15 10:16:01 --> Model "Login_model" initialized
INFO - 2022-12-15 10:16:01 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:01 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:01 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:01 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:01 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:01 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:01 --> Total execution time: 0.0741
INFO - 2022-12-15 10:16:01 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:01 --> Total execution time: 0.0550
INFO - 2022-12-15 10:16:03 --> Config Class Initialized
INFO - 2022-12-15 10:16:03 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:16:03 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:03 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:03 --> URI Class Initialized
INFO - 2022-12-15 10:16:03 --> Router Class Initialized
INFO - 2022-12-15 10:16:03 --> Output Class Initialized
INFO - 2022-12-15 10:16:03 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:03 --> Input Class Initialized
INFO - 2022-12-15 10:16:03 --> Language Class Initialized
INFO - 2022-12-15 10:16:03 --> Loader Class Initialized
INFO - 2022-12-15 10:16:03 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:03 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:04 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:04 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:04 --> Model "Login_model" initialized
INFO - 2022-12-15 10:16:04 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:04 --> Total execution time: 0.1310
INFO - 2022-12-15 10:16:04 --> Config Class Initialized
INFO - 2022-12-15 10:16:04 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:16:04 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:04 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:04 --> URI Class Initialized
INFO - 2022-12-15 10:16:04 --> Router Class Initialized
INFO - 2022-12-15 10:16:04 --> Output Class Initialized
INFO - 2022-12-15 10:16:04 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:04 --> Input Class Initialized
INFO - 2022-12-15 10:16:04 --> Language Class Initialized
INFO - 2022-12-15 10:16:04 --> Loader Class Initialized
INFO - 2022-12-15 10:16:04 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:04 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:04 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:04 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:04 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:04 --> Model "Login_model" initialized
INFO - 2022-12-15 10:16:04 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:04 --> Total execution time: 0.1100
INFO - 2022-12-15 10:16:23 --> Config Class Initialized
INFO - 2022-12-15 10:16:23 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:16:23 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:23 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:23 --> URI Class Initialized
INFO - 2022-12-15 10:16:23 --> Router Class Initialized
INFO - 2022-12-15 10:16:23 --> Output Class Initialized
INFO - 2022-12-15 10:16:23 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:23 --> Input Class Initialized
INFO - 2022-12-15 10:16:23 --> Language Class Initialized
INFO - 2022-12-15 10:16:23 --> Loader Class Initialized
INFO - 2022-12-15 10:16:23 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:23 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:23 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:23 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:23 --> Total execution time: 0.0550
INFO - 2022-12-15 10:16:23 --> Config Class Initialized
INFO - 2022-12-15 10:16:23 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:16:23 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:16:23 --> Utf8 Class Initialized
INFO - 2022-12-15 10:16:23 --> URI Class Initialized
INFO - 2022-12-15 10:16:23 --> Router Class Initialized
INFO - 2022-12-15 10:16:23 --> Output Class Initialized
INFO - 2022-12-15 10:16:23 --> Security Class Initialized
DEBUG - 2022-12-15 10:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:16:23 --> Input Class Initialized
INFO - 2022-12-15 10:16:23 --> Language Class Initialized
INFO - 2022-12-15 10:16:23 --> Loader Class Initialized
INFO - 2022-12-15 10:16:23 --> Controller Class Initialized
DEBUG - 2022-12-15 10:16:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:16:23 --> Database Driver Class Initialized
INFO - 2022-12-15 10:16:23 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:16:23 --> Final output sent to browser
DEBUG - 2022-12-15 10:16:23 --> Total execution time: 0.0782
INFO - 2022-12-15 10:32:54 --> Config Class Initialized
INFO - 2022-12-15 10:32:54 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:32:54 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:32:54 --> Utf8 Class Initialized
INFO - 2022-12-15 10:32:54 --> URI Class Initialized
INFO - 2022-12-15 10:32:54 --> Router Class Initialized
INFO - 2022-12-15 10:32:54 --> Output Class Initialized
INFO - 2022-12-15 10:32:54 --> Security Class Initialized
DEBUG - 2022-12-15 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:32:54 --> Input Class Initialized
INFO - 2022-12-15 10:32:54 --> Language Class Initialized
INFO - 2022-12-15 10:32:54 --> Loader Class Initialized
INFO - 2022-12-15 10:32:54 --> Controller Class Initialized
DEBUG - 2022-12-15 10:32:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:32:54 --> Database Driver Class Initialized
INFO - 2022-12-15 10:32:54 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:32:54 --> Final output sent to browser
DEBUG - 2022-12-15 10:32:54 --> Total execution time: 0.0469
INFO - 2022-12-15 10:32:54 --> Config Class Initialized
INFO - 2022-12-15 10:32:54 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:32:54 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:32:54 --> Utf8 Class Initialized
INFO - 2022-12-15 10:32:54 --> URI Class Initialized
INFO - 2022-12-15 10:32:54 --> Router Class Initialized
INFO - 2022-12-15 10:32:54 --> Output Class Initialized
INFO - 2022-12-15 10:32:54 --> Security Class Initialized
DEBUG - 2022-12-15 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:32:54 --> Input Class Initialized
INFO - 2022-12-15 10:32:54 --> Language Class Initialized
INFO - 2022-12-15 10:32:54 --> Loader Class Initialized
INFO - 2022-12-15 10:32:54 --> Controller Class Initialized
DEBUG - 2022-12-15 10:32:54 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:32:54 --> Database Driver Class Initialized
INFO - 2022-12-15 10:32:54 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:32:54 --> Final output sent to browser
DEBUG - 2022-12-15 10:32:54 --> Total execution time: 0.0546
INFO - 2022-12-15 10:32:56 --> Config Class Initialized
INFO - 2022-12-15 10:32:56 --> Hooks Class Initialized
INFO - 2022-12-15 10:32:56 --> Config Class Initialized
INFO - 2022-12-15 10:32:56 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:32:56 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:32:56 --> Utf8 Class Initialized
DEBUG - 2022-12-15 10:32:56 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:32:56 --> Utf8 Class Initialized
INFO - 2022-12-15 10:32:56 --> URI Class Initialized
INFO - 2022-12-15 10:32:56 --> URI Class Initialized
INFO - 2022-12-15 10:32:56 --> Router Class Initialized
INFO - 2022-12-15 10:32:56 --> Router Class Initialized
INFO - 2022-12-15 10:32:56 --> Output Class Initialized
INFO - 2022-12-15 10:32:56 --> Output Class Initialized
INFO - 2022-12-15 10:32:56 --> Security Class Initialized
INFO - 2022-12-15 10:32:56 --> Security Class Initialized
DEBUG - 2022-12-15 10:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:32:56 --> Input Class Initialized
DEBUG - 2022-12-15 10:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:32:56 --> Input Class Initialized
INFO - 2022-12-15 10:32:56 --> Language Class Initialized
INFO - 2022-12-15 10:32:56 --> Language Class Initialized
INFO - 2022-12-15 10:32:56 --> Loader Class Initialized
INFO - 2022-12-15 10:32:56 --> Loader Class Initialized
INFO - 2022-12-15 10:32:56 --> Controller Class Initialized
DEBUG - 2022-12-15 10:32:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:32:56 --> Controller Class Initialized
INFO - 2022-12-15 10:32:56 --> Final output sent to browser
DEBUG - 2022-12-15 10:32:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-15 10:32:56 --> Total execution time: 0.0277
INFO - 2022-12-15 10:32:56 --> Database Driver Class Initialized
INFO - 2022-12-15 10:32:56 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:32:56 --> Config Class Initialized
INFO - 2022-12-15 10:32:56 --> Hooks Class Initialized
INFO - 2022-12-15 10:32:56 --> Final output sent to browser
DEBUG - 2022-12-15 10:32:56 --> Total execution time: 0.0396
DEBUG - 2022-12-15 10:32:56 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:32:56 --> Utf8 Class Initialized
INFO - 2022-12-15 10:32:56 --> URI Class Initialized
INFO - 2022-12-15 10:32:56 --> Router Class Initialized
INFO - 2022-12-15 10:32:56 --> Output Class Initialized
INFO - 2022-12-15 10:32:56 --> Security Class Initialized
DEBUG - 2022-12-15 10:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:32:56 --> Input Class Initialized
INFO - 2022-12-15 10:32:56 --> Language Class Initialized
INFO - 2022-12-15 10:32:56 --> Config Class Initialized
INFO - 2022-12-15 10:32:56 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:32:56 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:32:56 --> Utf8 Class Initialized
INFO - 2022-12-15 10:32:56 --> URI Class Initialized
INFO - 2022-12-15 10:32:56 --> Loader Class Initialized
INFO - 2022-12-15 10:32:56 --> Router Class Initialized
INFO - 2022-12-15 10:32:56 --> Controller Class Initialized
DEBUG - 2022-12-15 10:32:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:32:56 --> Output Class Initialized
INFO - 2022-12-15 10:32:56 --> Security Class Initialized
DEBUG - 2022-12-15 10:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:32:56 --> Input Class Initialized
INFO - 2022-12-15 10:32:56 --> Language Class Initialized
INFO - 2022-12-15 10:32:56 --> Database Driver Class Initialized
INFO - 2022-12-15 10:32:56 --> Loader Class Initialized
INFO - 2022-12-15 10:32:56 --> Controller Class Initialized
DEBUG - 2022-12-15 10:32:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:32:56 --> Database Driver Class Initialized
INFO - 2022-12-15 10:32:56 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:32:56 --> Final output sent to browser
DEBUG - 2022-12-15 10:32:56 --> Total execution time: 0.0568
INFO - 2022-12-15 10:32:56 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:32:56 --> Final output sent to browser
DEBUG - 2022-12-15 10:32:56 --> Total execution time: 0.0552
INFO - 2022-12-15 10:32:59 --> Config Class Initialized
INFO - 2022-12-15 10:32:59 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:32:59 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:32:59 --> Utf8 Class Initialized
INFO - 2022-12-15 10:32:59 --> URI Class Initialized
INFO - 2022-12-15 10:32:59 --> Router Class Initialized
INFO - 2022-12-15 10:32:59 --> Output Class Initialized
INFO - 2022-12-15 10:32:59 --> Security Class Initialized
DEBUG - 2022-12-15 10:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:32:59 --> Input Class Initialized
INFO - 2022-12-15 10:32:59 --> Language Class Initialized
INFO - 2022-12-15 10:32:59 --> Loader Class Initialized
INFO - 2022-12-15 10:32:59 --> Controller Class Initialized
DEBUG - 2022-12-15 10:32:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:32:59 --> Database Driver Class Initialized
INFO - 2022-12-15 10:32:59 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:32:59 --> Final output sent to browser
DEBUG - 2022-12-15 10:32:59 --> Total execution time: 0.0452
INFO - 2022-12-15 10:32:59 --> Config Class Initialized
INFO - 2022-12-15 10:32:59 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:32:59 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:32:59 --> Utf8 Class Initialized
INFO - 2022-12-15 10:32:59 --> URI Class Initialized
INFO - 2022-12-15 10:32:59 --> Router Class Initialized
INFO - 2022-12-15 10:32:59 --> Output Class Initialized
INFO - 2022-12-15 10:32:59 --> Security Class Initialized
DEBUG - 2022-12-15 10:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:32:59 --> Input Class Initialized
INFO - 2022-12-15 10:32:59 --> Language Class Initialized
INFO - 2022-12-15 10:32:59 --> Loader Class Initialized
INFO - 2022-12-15 10:32:59 --> Controller Class Initialized
DEBUG - 2022-12-15 10:32:59 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:32:59 --> Database Driver Class Initialized
INFO - 2022-12-15 10:32:59 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:32:59 --> Final output sent to browser
DEBUG - 2022-12-15 10:32:59 --> Total execution time: 0.0553
INFO - 2022-12-15 10:33:08 --> Config Class Initialized
INFO - 2022-12-15 10:33:08 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:33:08 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:33:08 --> Utf8 Class Initialized
INFO - 2022-12-15 10:33:08 --> URI Class Initialized
INFO - 2022-12-15 10:33:08 --> Router Class Initialized
INFO - 2022-12-15 10:33:08 --> Output Class Initialized
INFO - 2022-12-15 10:33:08 --> Security Class Initialized
DEBUG - 2022-12-15 10:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:33:08 --> Input Class Initialized
INFO - 2022-12-15 10:33:08 --> Language Class Initialized
INFO - 2022-12-15 10:33:08 --> Loader Class Initialized
INFO - 2022-12-15 10:33:08 --> Controller Class Initialized
DEBUG - 2022-12-15 10:33:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:33:08 --> Database Driver Class Initialized
INFO - 2022-12-15 10:33:08 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:33:08 --> Final output sent to browser
DEBUG - 2022-12-15 10:33:08 --> Total execution time: 0.0535
INFO - 2022-12-15 10:33:08 --> Config Class Initialized
INFO - 2022-12-15 10:33:08 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:33:08 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:33:08 --> Utf8 Class Initialized
INFO - 2022-12-15 10:33:08 --> URI Class Initialized
INFO - 2022-12-15 10:33:08 --> Router Class Initialized
INFO - 2022-12-15 10:33:08 --> Output Class Initialized
INFO - 2022-12-15 10:33:08 --> Security Class Initialized
DEBUG - 2022-12-15 10:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:33:08 --> Input Class Initialized
INFO - 2022-12-15 10:33:08 --> Language Class Initialized
INFO - 2022-12-15 10:33:08 --> Loader Class Initialized
INFO - 2022-12-15 10:33:08 --> Controller Class Initialized
DEBUG - 2022-12-15 10:33:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:33:08 --> Database Driver Class Initialized
INFO - 2022-12-15 10:33:08 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:33:08 --> Final output sent to browser
DEBUG - 2022-12-15 10:33:08 --> Total execution time: 0.0507
INFO - 2022-12-15 10:33:08 --> Config Class Initialized
INFO - 2022-12-15 10:33:08 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:33:08 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:33:08 --> Utf8 Class Initialized
INFO - 2022-12-15 10:33:08 --> URI Class Initialized
INFO - 2022-12-15 10:33:08 --> Router Class Initialized
INFO - 2022-12-15 10:33:08 --> Output Class Initialized
INFO - 2022-12-15 10:33:08 --> Security Class Initialized
DEBUG - 2022-12-15 10:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:33:08 --> Input Class Initialized
INFO - 2022-12-15 10:33:08 --> Language Class Initialized
INFO - 2022-12-15 10:33:08 --> Loader Class Initialized
INFO - 2022-12-15 10:33:08 --> Controller Class Initialized
DEBUG - 2022-12-15 10:33:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:33:08 --> Database Driver Class Initialized
INFO - 2022-12-15 10:33:08 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:33:08 --> Final output sent to browser
DEBUG - 2022-12-15 10:33:08 --> Total execution time: 0.0550
INFO - 2022-12-15 10:33:08 --> Config Class Initialized
INFO - 2022-12-15 10:33:08 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:33:08 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:33:08 --> Utf8 Class Initialized
INFO - 2022-12-15 10:33:08 --> URI Class Initialized
INFO - 2022-12-15 10:33:08 --> Router Class Initialized
INFO - 2022-12-15 10:33:08 --> Output Class Initialized
INFO - 2022-12-15 10:33:08 --> Security Class Initialized
DEBUG - 2022-12-15 10:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:33:08 --> Input Class Initialized
INFO - 2022-12-15 10:33:08 --> Language Class Initialized
INFO - 2022-12-15 10:33:08 --> Loader Class Initialized
INFO - 2022-12-15 10:33:08 --> Controller Class Initialized
DEBUG - 2022-12-15 10:33:08 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:33:08 --> Database Driver Class Initialized
INFO - 2022-12-15 10:33:08 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:33:08 --> Final output sent to browser
DEBUG - 2022-12-15 10:33:08 --> Total execution time: 0.0538
INFO - 2022-12-15 10:39:47 --> Config Class Initialized
INFO - 2022-12-15 10:39:47 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:39:47 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:39:47 --> Utf8 Class Initialized
INFO - 2022-12-15 10:39:47 --> URI Class Initialized
INFO - 2022-12-15 10:39:47 --> Router Class Initialized
INFO - 2022-12-15 10:39:47 --> Output Class Initialized
INFO - 2022-12-15 10:39:47 --> Security Class Initialized
DEBUG - 2022-12-15 10:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:39:47 --> Input Class Initialized
INFO - 2022-12-15 10:39:47 --> Language Class Initialized
INFO - 2022-12-15 10:39:47 --> Loader Class Initialized
INFO - 2022-12-15 10:39:47 --> Controller Class Initialized
DEBUG - 2022-12-15 10:39:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:39:47 --> Database Driver Class Initialized
INFO - 2022-12-15 10:39:47 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:39:47 --> Final output sent to browser
DEBUG - 2022-12-15 10:39:47 --> Total execution time: 0.0705
INFO - 2022-12-15 10:39:47 --> Config Class Initialized
INFO - 2022-12-15 10:39:47 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:39:47 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:39:47 --> Utf8 Class Initialized
INFO - 2022-12-15 10:39:47 --> URI Class Initialized
INFO - 2022-12-15 10:39:47 --> Router Class Initialized
INFO - 2022-12-15 10:39:47 --> Output Class Initialized
INFO - 2022-12-15 10:39:47 --> Security Class Initialized
DEBUG - 2022-12-15 10:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:39:47 --> Input Class Initialized
INFO - 2022-12-15 10:39:47 --> Language Class Initialized
INFO - 2022-12-15 10:39:47 --> Loader Class Initialized
INFO - 2022-12-15 10:39:47 --> Controller Class Initialized
DEBUG - 2022-12-15 10:39:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:39:47 --> Database Driver Class Initialized
INFO - 2022-12-15 10:39:47 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:39:47 --> Final output sent to browser
DEBUG - 2022-12-15 10:39:47 --> Total execution time: 0.0560
INFO - 2022-12-15 10:39:49 --> Config Class Initialized
INFO - 2022-12-15 10:39:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:39:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:39:49 --> Utf8 Class Initialized
INFO - 2022-12-15 10:39:49 --> URI Class Initialized
INFO - 2022-12-15 10:39:49 --> Router Class Initialized
INFO - 2022-12-15 10:39:49 --> Output Class Initialized
INFO - 2022-12-15 10:39:49 --> Security Class Initialized
DEBUG - 2022-12-15 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:39:49 --> Input Class Initialized
INFO - 2022-12-15 10:39:49 --> Language Class Initialized
INFO - 2022-12-15 10:39:49 --> Loader Class Initialized
INFO - 2022-12-15 10:39:49 --> Controller Class Initialized
DEBUG - 2022-12-15 10:39:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:39:49 --> Final output sent to browser
DEBUG - 2022-12-15 10:39:49 --> Total execution time: 0.0214
INFO - 2022-12-15 10:39:49 --> Config Class Initialized
INFO - 2022-12-15 10:39:49 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:39:49 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:39:49 --> Utf8 Class Initialized
INFO - 2022-12-15 10:39:49 --> URI Class Initialized
INFO - 2022-12-15 10:39:49 --> Router Class Initialized
INFO - 2022-12-15 10:39:49 --> Output Class Initialized
INFO - 2022-12-15 10:39:49 --> Security Class Initialized
DEBUG - 2022-12-15 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:39:49 --> Input Class Initialized
INFO - 2022-12-15 10:39:49 --> Language Class Initialized
INFO - 2022-12-15 10:39:49 --> Loader Class Initialized
INFO - 2022-12-15 10:39:49 --> Controller Class Initialized
DEBUG - 2022-12-15 10:39:49 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:39:49 --> Database Driver Class Initialized
INFO - 2022-12-15 10:39:49 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:39:49 --> Final output sent to browser
DEBUG - 2022-12-15 10:39:49 --> Total execution time: 0.0340
INFO - 2022-12-15 10:39:50 --> Config Class Initialized
INFO - 2022-12-15 10:39:50 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:39:50 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:39:50 --> Utf8 Class Initialized
INFO - 2022-12-15 10:39:50 --> URI Class Initialized
INFO - 2022-12-15 10:39:50 --> Router Class Initialized
INFO - 2022-12-15 10:39:50 --> Output Class Initialized
INFO - 2022-12-15 10:39:50 --> Security Class Initialized
DEBUG - 2022-12-15 10:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:39:50 --> Input Class Initialized
INFO - 2022-12-15 10:39:50 --> Language Class Initialized
INFO - 2022-12-15 10:39:50 --> Loader Class Initialized
INFO - 2022-12-15 10:39:50 --> Controller Class Initialized
DEBUG - 2022-12-15 10:39:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:39:50 --> Database Driver Class Initialized
INFO - 2022-12-15 10:39:50 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:39:50 --> Final output sent to browser
DEBUG - 2022-12-15 10:39:50 --> Total execution time: 0.0535
INFO - 2022-12-15 10:39:50 --> Config Class Initialized
INFO - 2022-12-15 10:39:50 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:39:50 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:39:50 --> Utf8 Class Initialized
INFO - 2022-12-15 10:39:50 --> URI Class Initialized
INFO - 2022-12-15 10:39:50 --> Router Class Initialized
INFO - 2022-12-15 10:39:50 --> Output Class Initialized
INFO - 2022-12-15 10:39:50 --> Security Class Initialized
DEBUG - 2022-12-15 10:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:39:50 --> Input Class Initialized
INFO - 2022-12-15 10:39:50 --> Language Class Initialized
INFO - 2022-12-15 10:39:50 --> Loader Class Initialized
INFO - 2022-12-15 10:39:50 --> Controller Class Initialized
DEBUG - 2022-12-15 10:39:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:39:50 --> Database Driver Class Initialized
INFO - 2022-12-15 10:39:50 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:39:50 --> Final output sent to browser
DEBUG - 2022-12-15 10:39:50 --> Total execution time: 0.0545
INFO - 2022-12-15 10:42:52 --> Config Class Initialized
INFO - 2022-12-15 10:42:52 --> Config Class Initialized
INFO - 2022-12-15 10:42:52 --> Hooks Class Initialized
INFO - 2022-12-15 10:42:52 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-15 10:42:52 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:42:52 --> Utf8 Class Initialized
INFO - 2022-12-15 10:42:52 --> Utf8 Class Initialized
INFO - 2022-12-15 10:42:52 --> URI Class Initialized
INFO - 2022-12-15 10:42:52 --> URI Class Initialized
INFO - 2022-12-15 10:42:52 --> Router Class Initialized
INFO - 2022-12-15 10:42:52 --> Router Class Initialized
INFO - 2022-12-15 10:42:52 --> Output Class Initialized
INFO - 2022-12-15 10:42:52 --> Output Class Initialized
INFO - 2022-12-15 10:42:52 --> Security Class Initialized
INFO - 2022-12-15 10:42:52 --> Security Class Initialized
DEBUG - 2022-12-15 10:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-15 10:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:42:52 --> Input Class Initialized
INFO - 2022-12-15 10:42:52 --> Input Class Initialized
INFO - 2022-12-15 10:42:52 --> Language Class Initialized
INFO - 2022-12-15 10:42:52 --> Language Class Initialized
INFO - 2022-12-15 10:42:52 --> Loader Class Initialized
INFO - 2022-12-15 10:42:52 --> Loader Class Initialized
INFO - 2022-12-15 10:42:52 --> Controller Class Initialized
INFO - 2022-12-15 10:42:52 --> Controller Class Initialized
DEBUG - 2022-12-15 10:42:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
DEBUG - 2022-12-15 10:42:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:42:52 --> Final output sent to browser
DEBUG - 2022-12-15 10:42:52 --> Total execution time: 0.0264
INFO - 2022-12-15 10:42:52 --> Database Driver Class Initialized
INFO - 2022-12-15 10:42:52 --> Config Class Initialized
INFO - 2022-12-15 10:42:52 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:42:52 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:42:52 --> Utf8 Class Initialized
INFO - 2022-12-15 10:42:52 --> URI Class Initialized
INFO - 2022-12-15 10:42:52 --> Router Class Initialized
INFO - 2022-12-15 10:42:52 --> Output Class Initialized
INFO - 2022-12-15 10:42:52 --> Security Class Initialized
DEBUG - 2022-12-15 10:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:42:52 --> Input Class Initialized
INFO - 2022-12-15 10:42:52 --> Language Class Initialized
INFO - 2022-12-15 10:42:52 --> Loader Class Initialized
INFO - 2022-12-15 10:42:52 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:42:52 --> Controller Class Initialized
DEBUG - 2022-12-15 10:42:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:42:52 --> Final output sent to browser
DEBUG - 2022-12-15 10:42:52 --> Total execution time: 0.0571
INFO - 2022-12-15 10:42:52 --> Database Driver Class Initialized
INFO - 2022-12-15 10:42:52 --> Config Class Initialized
INFO - 2022-12-15 10:42:52 --> Hooks Class Initialized
DEBUG - 2022-12-15 10:42:52 --> UTF-8 Support Enabled
INFO - 2022-12-15 10:42:52 --> Utf8 Class Initialized
INFO - 2022-12-15 10:42:52 --> URI Class Initialized
INFO - 2022-12-15 10:42:52 --> Router Class Initialized
INFO - 2022-12-15 10:42:52 --> Output Class Initialized
INFO - 2022-12-15 10:42:52 --> Security Class Initialized
DEBUG - 2022-12-15 10:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-15 10:42:52 --> Input Class Initialized
INFO - 2022-12-15 10:42:52 --> Language Class Initialized
INFO - 2022-12-15 10:42:52 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:42:52 --> Loader Class Initialized
INFO - 2022-12-15 10:42:52 --> Controller Class Initialized
DEBUG - 2022-12-15 10:42:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-15 10:42:52 --> Final output sent to browser
DEBUG - 2022-12-15 10:42:52 --> Total execution time: 0.0542
INFO - 2022-12-15 10:42:52 --> Database Driver Class Initialized
INFO - 2022-12-15 10:42:53 --> Model "Cluster_model" initialized
INFO - 2022-12-15 10:42:53 --> Final output sent to browser
DEBUG - 2022-12-15 10:42:53 --> Total execution time: 0.0524
