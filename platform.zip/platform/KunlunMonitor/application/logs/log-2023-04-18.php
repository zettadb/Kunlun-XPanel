<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-18 01:53:30 --> Config Class Initialized
INFO - 2023-04-18 01:53:30 --> Hooks Class Initialized
DEBUG - 2023-04-18 01:53:30 --> UTF-8 Support Enabled
INFO - 2023-04-18 01:53:30 --> Utf8 Class Initialized
INFO - 2023-04-18 01:53:30 --> URI Class Initialized
INFO - 2023-04-18 01:53:30 --> Router Class Initialized
INFO - 2023-04-18 01:53:30 --> Output Class Initialized
INFO - 2023-04-18 01:53:30 --> Security Class Initialized
DEBUG - 2023-04-18 01:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 01:53:30 --> Input Class Initialized
INFO - 2023-04-18 01:53:30 --> Language Class Initialized
INFO - 2023-04-18 01:53:30 --> Loader Class Initialized
INFO - 2023-04-18 01:53:30 --> Controller Class Initialized
DEBUG - 2023-04-18 01:53:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 01:53:30 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:30 --> Model "Cluster_model" initialized
INFO - 2023-04-18 01:53:30 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:30 --> Model "Login_model" initialized
INFO - 2023-04-18 01:53:30 --> Final output sent to browser
DEBUG - 2023-04-18 01:53:30 --> Total execution time: 0.1571
INFO - 2023-04-18 01:53:30 --> Config Class Initialized
INFO - 2023-04-18 01:53:30 --> Hooks Class Initialized
DEBUG - 2023-04-18 01:53:30 --> UTF-8 Support Enabled
INFO - 2023-04-18 01:53:30 --> Utf8 Class Initialized
INFO - 2023-04-18 01:53:30 --> URI Class Initialized
INFO - 2023-04-18 01:53:30 --> Router Class Initialized
INFO - 2023-04-18 01:53:30 --> Output Class Initialized
INFO - 2023-04-18 01:53:30 --> Security Class Initialized
DEBUG - 2023-04-18 01:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 01:53:30 --> Input Class Initialized
INFO - 2023-04-18 01:53:30 --> Language Class Initialized
INFO - 2023-04-18 01:53:30 --> Loader Class Initialized
INFO - 2023-04-18 01:53:30 --> Controller Class Initialized
DEBUG - 2023-04-18 01:53:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 01:53:30 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:30 --> Model "Cluster_model" initialized
INFO - 2023-04-18 01:53:30 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:30 --> Model "Login_model" initialized
INFO - 2023-04-18 01:53:30 --> Final output sent to browser
DEBUG - 2023-04-18 01:53:30 --> Total execution time: 0.1019
INFO - 2023-04-18 01:53:47 --> Config Class Initialized
INFO - 2023-04-18 01:53:47 --> Config Class Initialized
INFO - 2023-04-18 01:53:47 --> Hooks Class Initialized
INFO - 2023-04-18 01:53:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 01:53:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 01:53:47 --> Utf8 Class Initialized
DEBUG - 2023-04-18 01:53:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 01:53:47 --> URI Class Initialized
INFO - 2023-04-18 01:53:47 --> Utf8 Class Initialized
INFO - 2023-04-18 01:53:47 --> Router Class Initialized
INFO - 2023-04-18 01:53:47 --> URI Class Initialized
INFO - 2023-04-18 01:53:47 --> Output Class Initialized
INFO - 2023-04-18 01:53:47 --> Router Class Initialized
INFO - 2023-04-18 01:53:47 --> Security Class Initialized
INFO - 2023-04-18 01:53:47 --> Output Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 01:53:47 --> Security Class Initialized
INFO - 2023-04-18 01:53:47 --> Input Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 01:53:47 --> Language Class Initialized
INFO - 2023-04-18 01:53:47 --> Input Class Initialized
INFO - 2023-04-18 01:53:47 --> Loader Class Initialized
INFO - 2023-04-18 01:53:47 --> Language Class Initialized
INFO - 2023-04-18 01:53:47 --> Controller Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 01:53:47 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:47 --> Loader Class Initialized
INFO - 2023-04-18 01:53:47 --> Controller Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 01:53:47 --> Final output sent to browser
DEBUG - 2023-04-18 01:53:47 --> Total execution time: 0.0475
INFO - 2023-04-18 01:53:47 --> Config Class Initialized
INFO - 2023-04-18 01:53:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 01:53:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 01:53:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 01:53:47 --> Utf8 Class Initialized
INFO - 2023-04-18 01:53:47 --> URI Class Initialized
INFO - 2023-04-18 01:53:47 --> Router Class Initialized
INFO - 2023-04-18 01:53:47 --> Output Class Initialized
INFO - 2023-04-18 01:53:47 --> Security Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 01:53:47 --> Input Class Initialized
INFO - 2023-04-18 01:53:47 --> Language Class Initialized
INFO - 2023-04-18 01:53:47 --> Loader Class Initialized
INFO - 2023-04-18 01:53:47 --> Controller Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 01:53:47 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:47 --> Model "Login_model" initialized
INFO - 2023-04-18 01:53:47 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:47 --> Final output sent to browser
DEBUG - 2023-04-18 01:53:47 --> Total execution time: 0.1110
INFO - 2023-04-18 01:53:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 01:53:47 --> Config Class Initialized
INFO - 2023-04-18 01:53:47 --> Final output sent to browser
INFO - 2023-04-18 01:53:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Total execution time: 0.0637
DEBUG - 2023-04-18 01:53:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 01:53:47 --> Utf8 Class Initialized
INFO - 2023-04-18 01:53:47 --> URI Class Initialized
INFO - 2023-04-18 01:53:47 --> Router Class Initialized
INFO - 2023-04-18 01:53:47 --> Output Class Initialized
INFO - 2023-04-18 01:53:47 --> Security Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 01:53:47 --> Input Class Initialized
INFO - 2023-04-18 01:53:47 --> Language Class Initialized
INFO - 2023-04-18 01:53:47 --> Loader Class Initialized
INFO - 2023-04-18 01:53:47 --> Controller Class Initialized
DEBUG - 2023-04-18 01:53:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 01:53:47 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 01:53:47 --> Final output sent to browser
DEBUG - 2023-04-18 01:53:47 --> Total execution time: 0.0776
INFO - 2023-04-18 01:53:49 --> Config Class Initialized
INFO - 2023-04-18 01:53:49 --> Hooks Class Initialized
DEBUG - 2023-04-18 01:53:49 --> UTF-8 Support Enabled
INFO - 2023-04-18 01:53:49 --> Utf8 Class Initialized
INFO - 2023-04-18 01:53:49 --> URI Class Initialized
INFO - 2023-04-18 01:53:49 --> Router Class Initialized
INFO - 2023-04-18 01:53:49 --> Output Class Initialized
INFO - 2023-04-18 01:53:49 --> Security Class Initialized
DEBUG - 2023-04-18 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 01:53:49 --> Input Class Initialized
INFO - 2023-04-18 01:53:49 --> Language Class Initialized
INFO - 2023-04-18 01:53:49 --> Loader Class Initialized
INFO - 2023-04-18 01:53:49 --> Controller Class Initialized
DEBUG - 2023-04-18 01:53:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 01:53:49 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:49 --> Model "Cluster_model" initialized
INFO - 2023-04-18 01:53:49 --> Final output sent to browser
DEBUG - 2023-04-18 01:53:49 --> Total execution time: 0.0778
INFO - 2023-04-18 01:53:49 --> Config Class Initialized
INFO - 2023-04-18 01:53:49 --> Hooks Class Initialized
DEBUG - 2023-04-18 01:53:49 --> UTF-8 Support Enabled
INFO - 2023-04-18 01:53:49 --> Utf8 Class Initialized
INFO - 2023-04-18 01:53:49 --> URI Class Initialized
INFO - 2023-04-18 01:53:49 --> Router Class Initialized
INFO - 2023-04-18 01:53:49 --> Output Class Initialized
INFO - 2023-04-18 01:53:49 --> Security Class Initialized
DEBUG - 2023-04-18 01:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 01:53:49 --> Input Class Initialized
INFO - 2023-04-18 01:53:49 --> Language Class Initialized
INFO - 2023-04-18 01:53:49 --> Loader Class Initialized
INFO - 2023-04-18 01:53:49 --> Controller Class Initialized
DEBUG - 2023-04-18 01:53:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 01:53:49 --> Database Driver Class Initialized
INFO - 2023-04-18 01:53:49 --> Model "Cluster_model" initialized
INFO - 2023-04-18 01:53:49 --> Final output sent to browser
DEBUG - 2023-04-18 01:53:49 --> Total execution time: 0.0595
INFO - 2023-04-18 02:02:47 --> Config Class Initialized
INFO - 2023-04-18 02:02:47 --> Config Class Initialized
INFO - 2023-04-18 02:02:47 --> Hooks Class Initialized
INFO - 2023-04-18 02:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:02:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 02:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:02:47 --> Utf8 Class Initialized
INFO - 2023-04-18 02:02:47 --> Utf8 Class Initialized
INFO - 2023-04-18 02:02:47 --> URI Class Initialized
INFO - 2023-04-18 02:02:47 --> URI Class Initialized
INFO - 2023-04-18 02:02:47 --> Router Class Initialized
INFO - 2023-04-18 02:02:47 --> Router Class Initialized
INFO - 2023-04-18 02:02:47 --> Output Class Initialized
INFO - 2023-04-18 02:02:47 --> Output Class Initialized
INFO - 2023-04-18 02:02:47 --> Security Class Initialized
INFO - 2023-04-18 02:02:47 --> Security Class Initialized
DEBUG - 2023-04-18 02:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:02:47 --> Input Class Initialized
DEBUG - 2023-04-18 02:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:02:47 --> Language Class Initialized
INFO - 2023-04-18 02:02:47 --> Input Class Initialized
INFO - 2023-04-18 02:02:47 --> Language Class Initialized
INFO - 2023-04-18 02:02:47 --> Loader Class Initialized
INFO - 2023-04-18 02:02:47 --> Loader Class Initialized
INFO - 2023-04-18 02:02:47 --> Controller Class Initialized
INFO - 2023-04-18 02:02:47 --> Controller Class Initialized
DEBUG - 2023-04-18 02:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 02:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:02:47 --> Final output sent to browser
INFO - 2023-04-18 02:02:47 --> Database Driver Class Initialized
DEBUG - 2023-04-18 02:02:47 --> Total execution time: 0.0030
INFO - 2023-04-18 02:02:47 --> Config Class Initialized
INFO - 2023-04-18 02:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:02:47 --> Utf8 Class Initialized
INFO - 2023-04-18 02:02:47 --> URI Class Initialized
INFO - 2023-04-18 02:02:47 --> Router Class Initialized
INFO - 2023-04-18 02:02:47 --> Output Class Initialized
INFO - 2023-04-18 02:02:47 --> Security Class Initialized
DEBUG - 2023-04-18 02:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:02:47 --> Input Class Initialized
INFO - 2023-04-18 02:02:47 --> Language Class Initialized
INFO - 2023-04-18 02:02:47 --> Loader Class Initialized
INFO - 2023-04-18 02:02:47 --> Controller Class Initialized
DEBUG - 2023-04-18 02:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:02:47 --> Database Driver Class Initialized
INFO - 2023-04-18 02:02:47 --> Final output sent to browser
DEBUG - 2023-04-18 02:02:47 --> Total execution time: 0.0607
INFO - 2023-04-18 02:02:47 --> Config Class Initialized
INFO - 2023-04-18 02:02:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:02:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:02:47 --> Utf8 Class Initialized
INFO - 2023-04-18 02:02:47 --> URI Class Initialized
INFO - 2023-04-18 02:02:47 --> Router Class Initialized
INFO - 2023-04-18 02:02:47 --> Output Class Initialized
INFO - 2023-04-18 02:02:47 --> Model "Login_model" initialized
INFO - 2023-04-18 02:02:47 --> Security Class Initialized
DEBUG - 2023-04-18 02:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:02:47 --> Input Class Initialized
INFO - 2023-04-18 02:02:47 --> Language Class Initialized
INFO - 2023-04-18 02:02:47 --> Loader Class Initialized
INFO - 2023-04-18 02:02:47 --> Controller Class Initialized
DEBUG - 2023-04-18 02:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:02:47 --> Database Driver Class Initialized
INFO - 2023-04-18 02:02:47 --> Database Driver Class Initialized
INFO - 2023-04-18 02:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:02:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:02:47 --> Final output sent to browser
DEBUG - 2023-04-18 02:02:47 --> Total execution time: 0.0712
INFO - 2023-04-18 02:02:47 --> Final output sent to browser
DEBUG - 2023-04-18 02:02:47 --> Total execution time: 0.0173
INFO - 2023-04-18 02:02:50 --> Config Class Initialized
INFO - 2023-04-18 02:02:50 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:02:50 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:02:50 --> Utf8 Class Initialized
INFO - 2023-04-18 02:02:50 --> URI Class Initialized
INFO - 2023-04-18 02:02:50 --> Router Class Initialized
INFO - 2023-04-18 02:02:50 --> Output Class Initialized
INFO - 2023-04-18 02:02:50 --> Security Class Initialized
DEBUG - 2023-04-18 02:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:02:50 --> Input Class Initialized
INFO - 2023-04-18 02:02:50 --> Language Class Initialized
INFO - 2023-04-18 02:02:50 --> Loader Class Initialized
INFO - 2023-04-18 02:02:50 --> Controller Class Initialized
DEBUG - 2023-04-18 02:02:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:02:50 --> Database Driver Class Initialized
INFO - 2023-04-18 02:02:50 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:02:50 --> Final output sent to browser
DEBUG - 2023-04-18 02:02:50 --> Total execution time: 0.0946
INFO - 2023-04-18 02:02:50 --> Config Class Initialized
INFO - 2023-04-18 02:02:50 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:02:50 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:02:50 --> Utf8 Class Initialized
INFO - 2023-04-18 02:02:50 --> URI Class Initialized
INFO - 2023-04-18 02:02:50 --> Router Class Initialized
INFO - 2023-04-18 02:02:50 --> Output Class Initialized
INFO - 2023-04-18 02:02:50 --> Security Class Initialized
DEBUG - 2023-04-18 02:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:02:50 --> Input Class Initialized
INFO - 2023-04-18 02:02:50 --> Language Class Initialized
INFO - 2023-04-18 02:02:50 --> Loader Class Initialized
INFO - 2023-04-18 02:02:50 --> Controller Class Initialized
DEBUG - 2023-04-18 02:02:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:02:50 --> Database Driver Class Initialized
INFO - 2023-04-18 02:02:50 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:02:50 --> Final output sent to browser
DEBUG - 2023-04-18 02:02:50 --> Total execution time: 0.1606
INFO - 2023-04-18 02:02:51 --> Config Class Initialized
INFO - 2023-04-18 02:02:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:02:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:02:51 --> Utf8 Class Initialized
INFO - 2023-04-18 02:02:51 --> URI Class Initialized
INFO - 2023-04-18 02:02:51 --> Router Class Initialized
INFO - 2023-04-18 02:02:51 --> Output Class Initialized
INFO - 2023-04-18 02:02:51 --> Security Class Initialized
DEBUG - 2023-04-18 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:02:51 --> Input Class Initialized
INFO - 2023-04-18 02:02:51 --> Language Class Initialized
INFO - 2023-04-18 02:02:51 --> Loader Class Initialized
INFO - 2023-04-18 02:02:51 --> Controller Class Initialized
DEBUG - 2023-04-18 02:02:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:02:51 --> Database Driver Class Initialized
INFO - 2023-04-18 02:02:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:02:51 --> Final output sent to browser
DEBUG - 2023-04-18 02:02:51 --> Total execution time: 0.0603
INFO - 2023-04-18 02:02:51 --> Config Class Initialized
INFO - 2023-04-18 02:02:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:02:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:02:51 --> Utf8 Class Initialized
INFO - 2023-04-18 02:02:51 --> URI Class Initialized
INFO - 2023-04-18 02:02:51 --> Router Class Initialized
INFO - 2023-04-18 02:02:51 --> Output Class Initialized
INFO - 2023-04-18 02:02:51 --> Security Class Initialized
DEBUG - 2023-04-18 02:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:02:51 --> Input Class Initialized
INFO - 2023-04-18 02:02:51 --> Language Class Initialized
INFO - 2023-04-18 02:02:51 --> Loader Class Initialized
INFO - 2023-04-18 02:02:51 --> Controller Class Initialized
DEBUG - 2023-04-18 02:02:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:02:51 --> Database Driver Class Initialized
INFO - 2023-04-18 02:02:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:02:51 --> Final output sent to browser
DEBUG - 2023-04-18 02:02:51 --> Total execution time: 0.0552
INFO - 2023-04-18 02:04:51 --> Config Class Initialized
INFO - 2023-04-18 02:04:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:04:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:04:51 --> Utf8 Class Initialized
INFO - 2023-04-18 02:04:51 --> URI Class Initialized
INFO - 2023-04-18 02:04:51 --> Router Class Initialized
INFO - 2023-04-18 02:04:51 --> Output Class Initialized
INFO - 2023-04-18 02:04:51 --> Security Class Initialized
DEBUG - 2023-04-18 02:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:04:51 --> Input Class Initialized
INFO - 2023-04-18 02:04:51 --> Language Class Initialized
INFO - 2023-04-18 02:04:51 --> Loader Class Initialized
INFO - 2023-04-18 02:04:51 --> Controller Class Initialized
DEBUG - 2023-04-18 02:04:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:04:51 --> Database Driver Class Initialized
INFO - 2023-04-18 02:04:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:04:51 --> Final output sent to browser
DEBUG - 2023-04-18 02:04:51 --> Total execution time: 0.0595
INFO - 2023-04-18 02:04:51 --> Config Class Initialized
INFO - 2023-04-18 02:04:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:04:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:04:51 --> Utf8 Class Initialized
INFO - 2023-04-18 02:04:51 --> URI Class Initialized
INFO - 2023-04-18 02:04:51 --> Router Class Initialized
INFO - 2023-04-18 02:04:51 --> Output Class Initialized
INFO - 2023-04-18 02:04:51 --> Security Class Initialized
DEBUG - 2023-04-18 02:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:04:51 --> Input Class Initialized
INFO - 2023-04-18 02:04:51 --> Language Class Initialized
INFO - 2023-04-18 02:04:51 --> Loader Class Initialized
INFO - 2023-04-18 02:04:51 --> Controller Class Initialized
DEBUG - 2023-04-18 02:04:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:04:51 --> Database Driver Class Initialized
INFO - 2023-04-18 02:04:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:04:51 --> Final output sent to browser
DEBUG - 2023-04-18 02:04:51 --> Total execution time: 0.0540
INFO - 2023-04-18 02:04:53 --> Config Class Initialized
INFO - 2023-04-18 02:04:53 --> Config Class Initialized
INFO - 2023-04-18 02:04:53 --> Hooks Class Initialized
INFO - 2023-04-18 02:04:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 02:04:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:04:53 --> Utf8 Class Initialized
INFO - 2023-04-18 02:04:53 --> Utf8 Class Initialized
INFO - 2023-04-18 02:04:53 --> URI Class Initialized
INFO - 2023-04-18 02:04:53 --> URI Class Initialized
INFO - 2023-04-18 02:04:53 --> Router Class Initialized
INFO - 2023-04-18 02:04:53 --> Router Class Initialized
INFO - 2023-04-18 02:04:53 --> Output Class Initialized
INFO - 2023-04-18 02:04:53 --> Output Class Initialized
INFO - 2023-04-18 02:04:53 --> Security Class Initialized
INFO - 2023-04-18 02:04:53 --> Security Class Initialized
DEBUG - 2023-04-18 02:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:04:53 --> Input Class Initialized
DEBUG - 2023-04-18 02:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:04:53 --> Language Class Initialized
INFO - 2023-04-18 02:04:53 --> Input Class Initialized
INFO - 2023-04-18 02:04:53 --> Language Class Initialized
INFO - 2023-04-18 02:04:53 --> Loader Class Initialized
INFO - 2023-04-18 02:04:53 --> Loader Class Initialized
INFO - 2023-04-18 02:04:53 --> Controller Class Initialized
INFO - 2023-04-18 02:04:53 --> Controller Class Initialized
DEBUG - 2023-04-18 02:04:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 02:04:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:04:53 --> Database Driver Class Initialized
INFO - 2023-04-18 02:04:53 --> Final output sent to browser
DEBUG - 2023-04-18 02:04:53 --> Total execution time: 0.0045
INFO - 2023-04-18 02:04:53 --> Config Class Initialized
INFO - 2023-04-18 02:04:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:04:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:04:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:04:53 --> Utf8 Class Initialized
INFO - 2023-04-18 02:04:53 --> URI Class Initialized
INFO - 2023-04-18 02:04:53 --> Router Class Initialized
INFO - 2023-04-18 02:04:53 --> Output Class Initialized
INFO - 2023-04-18 02:04:53 --> Security Class Initialized
DEBUG - 2023-04-18 02:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:04:53 --> Input Class Initialized
INFO - 2023-04-18 02:04:53 --> Language Class Initialized
INFO - 2023-04-18 02:04:53 --> Loader Class Initialized
INFO - 2023-04-18 02:04:53 --> Controller Class Initialized
DEBUG - 2023-04-18 02:04:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:04:53 --> Database Driver Class Initialized
INFO - 2023-04-18 02:04:53 --> Final output sent to browser
DEBUG - 2023-04-18 02:04:53 --> Total execution time: 0.0504
INFO - 2023-04-18 02:04:53 --> Config Class Initialized
INFO - 2023-04-18 02:04:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:04:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:04:53 --> Utf8 Class Initialized
INFO - 2023-04-18 02:04:53 --> URI Class Initialized
INFO - 2023-04-18 02:04:53 --> Router Class Initialized
INFO - 2023-04-18 02:04:53 --> Output Class Initialized
INFO - 2023-04-18 02:04:53 --> Security Class Initialized
DEBUG - 2023-04-18 02:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:04:53 --> Input Class Initialized
INFO - 2023-04-18 02:04:53 --> Language Class Initialized
INFO - 2023-04-18 02:04:53 --> Loader Class Initialized
INFO - 2023-04-18 02:04:53 --> Controller Class Initialized
DEBUG - 2023-04-18 02:04:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:04:53 --> Database Driver Class Initialized
INFO - 2023-04-18 02:04:53 --> Model "Login_model" initialized
INFO - 2023-04-18 02:04:53 --> Database Driver Class Initialized
INFO - 2023-04-18 02:04:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:04:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:04:53 --> Final output sent to browser
DEBUG - 2023-04-18 02:04:53 --> Total execution time: 0.0630
INFO - 2023-04-18 02:04:53 --> Final output sent to browser
DEBUG - 2023-04-18 02:04:53 --> Total execution time: 0.0228
INFO - 2023-04-18 02:04:56 --> Config Class Initialized
INFO - 2023-04-18 02:04:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:04:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:04:56 --> Utf8 Class Initialized
INFO - 2023-04-18 02:04:56 --> URI Class Initialized
INFO - 2023-04-18 02:04:56 --> Router Class Initialized
INFO - 2023-04-18 02:04:56 --> Output Class Initialized
INFO - 2023-04-18 02:04:56 --> Security Class Initialized
DEBUG - 2023-04-18 02:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:04:56 --> Input Class Initialized
INFO - 2023-04-18 02:04:56 --> Language Class Initialized
INFO - 2023-04-18 02:04:56 --> Loader Class Initialized
INFO - 2023-04-18 02:04:56 --> Controller Class Initialized
DEBUG - 2023-04-18 02:04:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:04:56 --> Database Driver Class Initialized
INFO - 2023-04-18 02:04:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:04:56 --> Final output sent to browser
DEBUG - 2023-04-18 02:04:56 --> Total execution time: 0.0488
INFO - 2023-04-18 02:04:56 --> Config Class Initialized
INFO - 2023-04-18 02:04:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:04:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:04:56 --> Utf8 Class Initialized
INFO - 2023-04-18 02:04:56 --> URI Class Initialized
INFO - 2023-04-18 02:04:56 --> Router Class Initialized
INFO - 2023-04-18 02:04:56 --> Output Class Initialized
INFO - 2023-04-18 02:04:56 --> Security Class Initialized
DEBUG - 2023-04-18 02:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:04:56 --> Input Class Initialized
INFO - 2023-04-18 02:04:56 --> Language Class Initialized
INFO - 2023-04-18 02:04:56 --> Loader Class Initialized
INFO - 2023-04-18 02:04:56 --> Controller Class Initialized
DEBUG - 2023-04-18 02:04:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:04:56 --> Database Driver Class Initialized
INFO - 2023-04-18 02:04:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:04:56 --> Final output sent to browser
DEBUG - 2023-04-18 02:04:56 --> Total execution time: 0.0850
INFO - 2023-04-18 02:05:01 --> Config Class Initialized
INFO - 2023-04-18 02:05:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:05:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:05:01 --> Utf8 Class Initialized
INFO - 2023-04-18 02:05:01 --> URI Class Initialized
INFO - 2023-04-18 02:05:01 --> Router Class Initialized
INFO - 2023-04-18 02:05:01 --> Output Class Initialized
INFO - 2023-04-18 02:05:01 --> Security Class Initialized
DEBUG - 2023-04-18 02:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:05:01 --> Input Class Initialized
INFO - 2023-04-18 02:05:01 --> Language Class Initialized
INFO - 2023-04-18 02:05:01 --> Loader Class Initialized
INFO - 2023-04-18 02:05:01 --> Controller Class Initialized
DEBUG - 2023-04-18 02:05:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:05:01 --> Database Driver Class Initialized
INFO - 2023-04-18 02:05:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:05:01 --> Database Driver Class Initialized
INFO - 2023-04-18 02:05:01 --> Model "Login_model" initialized
INFO - 2023-04-18 02:05:01 --> Final output sent to browser
DEBUG - 2023-04-18 02:05:01 --> Total execution time: 0.0776
INFO - 2023-04-18 02:05:01 --> Config Class Initialized
INFO - 2023-04-18 02:05:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:05:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:05:01 --> Utf8 Class Initialized
INFO - 2023-04-18 02:05:01 --> URI Class Initialized
INFO - 2023-04-18 02:05:01 --> Router Class Initialized
INFO - 2023-04-18 02:05:01 --> Output Class Initialized
INFO - 2023-04-18 02:05:01 --> Security Class Initialized
DEBUG - 2023-04-18 02:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:05:01 --> Input Class Initialized
INFO - 2023-04-18 02:05:01 --> Language Class Initialized
INFO - 2023-04-18 02:05:01 --> Loader Class Initialized
INFO - 2023-04-18 02:05:01 --> Controller Class Initialized
DEBUG - 2023-04-18 02:05:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:05:01 --> Database Driver Class Initialized
INFO - 2023-04-18 02:05:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:05:01 --> Database Driver Class Initialized
INFO - 2023-04-18 02:05:01 --> Model "Login_model" initialized
INFO - 2023-04-18 02:05:01 --> Final output sent to browser
DEBUG - 2023-04-18 02:05:01 --> Total execution time: 0.1564
INFO - 2023-04-18 02:10:01 --> Config Class Initialized
INFO - 2023-04-18 02:10:01 --> Config Class Initialized
INFO - 2023-04-18 02:10:01 --> Hooks Class Initialized
INFO - 2023-04-18 02:10:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:10:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 02:10:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:10:01 --> Utf8 Class Initialized
INFO - 2023-04-18 02:10:01 --> Utf8 Class Initialized
INFO - 2023-04-18 02:10:01 --> URI Class Initialized
INFO - 2023-04-18 02:10:01 --> URI Class Initialized
INFO - 2023-04-18 02:10:01 --> Router Class Initialized
INFO - 2023-04-18 02:10:01 --> Router Class Initialized
INFO - 2023-04-18 02:10:01 --> Output Class Initialized
INFO - 2023-04-18 02:10:01 --> Output Class Initialized
INFO - 2023-04-18 02:10:01 --> Security Class Initialized
INFO - 2023-04-18 02:10:01 --> Security Class Initialized
DEBUG - 2023-04-18 02:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 02:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:10:01 --> Input Class Initialized
INFO - 2023-04-18 02:10:01 --> Input Class Initialized
INFO - 2023-04-18 02:10:01 --> Language Class Initialized
INFO - 2023-04-18 02:10:01 --> Language Class Initialized
INFO - 2023-04-18 02:10:01 --> Loader Class Initialized
INFO - 2023-04-18 02:10:01 --> Loader Class Initialized
INFO - 2023-04-18 02:10:01 --> Controller Class Initialized
INFO - 2023-04-18 02:10:01 --> Controller Class Initialized
DEBUG - 2023-04-18 02:10:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 02:10:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:10:01 --> Final output sent to browser
DEBUG - 2023-04-18 02:10:01 --> Total execution time: 0.0031
INFO - 2023-04-18 02:10:01 --> Database Driver Class Initialized
INFO - 2023-04-18 02:10:01 --> Config Class Initialized
INFO - 2023-04-18 02:10:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:10:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:10:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:10:01 --> Utf8 Class Initialized
INFO - 2023-04-18 02:10:01 --> URI Class Initialized
INFO - 2023-04-18 02:10:01 --> Router Class Initialized
INFO - 2023-04-18 02:10:01 --> Output Class Initialized
INFO - 2023-04-18 02:10:01 --> Security Class Initialized
DEBUG - 2023-04-18 02:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:10:01 --> Input Class Initialized
INFO - 2023-04-18 02:10:01 --> Language Class Initialized
INFO - 2023-04-18 02:10:01 --> Loader Class Initialized
INFO - 2023-04-18 02:10:01 --> Controller Class Initialized
DEBUG - 2023-04-18 02:10:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:10:01 --> Database Driver Class Initialized
INFO - 2023-04-18 02:10:01 --> Final output sent to browser
DEBUG - 2023-04-18 02:10:01 --> Total execution time: 0.0361
INFO - 2023-04-18 02:10:01 --> Config Class Initialized
INFO - 2023-04-18 02:10:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:10:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:10:01 --> Utf8 Class Initialized
INFO - 2023-04-18 02:10:01 --> URI Class Initialized
INFO - 2023-04-18 02:10:01 --> Router Class Initialized
INFO - 2023-04-18 02:10:01 --> Output Class Initialized
INFO - 2023-04-18 02:10:01 --> Security Class Initialized
DEBUG - 2023-04-18 02:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:10:01 --> Input Class Initialized
INFO - 2023-04-18 02:10:01 --> Language Class Initialized
INFO - 2023-04-18 02:10:01 --> Loader Class Initialized
INFO - 2023-04-18 02:10:01 --> Controller Class Initialized
DEBUG - 2023-04-18 02:10:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:10:01 --> Database Driver Class Initialized
INFO - 2023-04-18 02:10:01 --> Model "Login_model" initialized
INFO - 2023-04-18 02:10:01 --> Database Driver Class Initialized
INFO - 2023-04-18 02:10:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:10:01 --> Final output sent to browser
DEBUG - 2023-04-18 02:10:01 --> Total execution time: 0.0141
INFO - 2023-04-18 02:10:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:10:01 --> Final output sent to browser
DEBUG - 2023-04-18 02:10:01 --> Total execution time: 0.0908
INFO - 2023-04-18 02:13:48 --> Config Class Initialized
INFO - 2023-04-18 02:13:48 --> Config Class Initialized
INFO - 2023-04-18 02:13:48 --> Hooks Class Initialized
INFO - 2023-04-18 02:13:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 02:13:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:48 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:48 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:48 --> URI Class Initialized
INFO - 2023-04-18 02:13:48 --> URI Class Initialized
INFO - 2023-04-18 02:13:48 --> Router Class Initialized
INFO - 2023-04-18 02:13:48 --> Router Class Initialized
INFO - 2023-04-18 02:13:48 --> Output Class Initialized
INFO - 2023-04-18 02:13:48 --> Output Class Initialized
INFO - 2023-04-18 02:13:48 --> Security Class Initialized
INFO - 2023-04-18 02:13:48 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 02:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:48 --> Input Class Initialized
INFO - 2023-04-18 02:13:48 --> Input Class Initialized
INFO - 2023-04-18 02:13:48 --> Language Class Initialized
INFO - 2023-04-18 02:13:48 --> Language Class Initialized
INFO - 2023-04-18 02:13:48 --> Loader Class Initialized
INFO - 2023-04-18 02:13:48 --> Loader Class Initialized
INFO - 2023-04-18 02:13:48 --> Controller Class Initialized
INFO - 2023-04-18 02:13:48 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 02:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:48 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:48 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:48 --> Total execution time: 0.0867
INFO - 2023-04-18 02:13:48 --> Config Class Initialized
INFO - 2023-04-18 02:13:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:48 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:48 --> URI Class Initialized
INFO - 2023-04-18 02:13:48 --> Router Class Initialized
INFO - 2023-04-18 02:13:48 --> Output Class Initialized
INFO - 2023-04-18 02:13:48 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:48 --> Input Class Initialized
INFO - 2023-04-18 02:13:48 --> Language Class Initialized
INFO - 2023-04-18 02:13:48 --> Loader Class Initialized
INFO - 2023-04-18 02:13:48 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:48 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:48 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:48 --> Total execution time: 0.1325
INFO - 2023-04-18 02:13:48 --> Config Class Initialized
INFO - 2023-04-18 02:13:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:48 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:48 --> URI Class Initialized
INFO - 2023-04-18 02:13:48 --> Router Class Initialized
INFO - 2023-04-18 02:13:48 --> Output Class Initialized
INFO - 2023-04-18 02:13:48 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:48 --> Input Class Initialized
INFO - 2023-04-18 02:13:48 --> Language Class Initialized
INFO - 2023-04-18 02:13:48 --> Loader Class Initialized
INFO - 2023-04-18 02:13:48 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:48 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:48 --> Model "Login_model" initialized
INFO - 2023-04-18 02:13:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:48 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:48 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:48 --> Total execution time: 0.0179
INFO - 2023-04-18 02:13:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:48 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:48 --> Total execution time: 0.1116
INFO - 2023-04-18 02:13:50 --> Config Class Initialized
INFO - 2023-04-18 02:13:50 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:50 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:50 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:50 --> URI Class Initialized
INFO - 2023-04-18 02:13:50 --> Router Class Initialized
INFO - 2023-04-18 02:13:50 --> Output Class Initialized
INFO - 2023-04-18 02:13:50 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:50 --> Input Class Initialized
INFO - 2023-04-18 02:13:50 --> Language Class Initialized
INFO - 2023-04-18 02:13:50 --> Loader Class Initialized
INFO - 2023-04-18 02:13:50 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:50 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:50 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:50 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:50 --> Total execution time: 0.0429
INFO - 2023-04-18 02:13:50 --> Config Class Initialized
INFO - 2023-04-18 02:13:50 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:50 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:50 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:50 --> URI Class Initialized
INFO - 2023-04-18 02:13:50 --> Router Class Initialized
INFO - 2023-04-18 02:13:50 --> Output Class Initialized
INFO - 2023-04-18 02:13:50 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:50 --> Input Class Initialized
INFO - 2023-04-18 02:13:50 --> Language Class Initialized
INFO - 2023-04-18 02:13:50 --> Loader Class Initialized
INFO - 2023-04-18 02:13:50 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:50 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:50 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:51 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:51 --> Total execution time: 0.1262
INFO - 2023-04-18 02:13:54 --> Config Class Initialized
INFO - 2023-04-18 02:13:54 --> Config Class Initialized
INFO - 2023-04-18 02:13:54 --> Hooks Class Initialized
INFO - 2023-04-18 02:13:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 02:13:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:54 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:54 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:54 --> URI Class Initialized
INFO - 2023-04-18 02:13:54 --> URI Class Initialized
INFO - 2023-04-18 02:13:54 --> Router Class Initialized
INFO - 2023-04-18 02:13:54 --> Router Class Initialized
INFO - 2023-04-18 02:13:54 --> Output Class Initialized
INFO - 2023-04-18 02:13:54 --> Output Class Initialized
INFO - 2023-04-18 02:13:54 --> Security Class Initialized
INFO - 2023-04-18 02:13:54 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 02:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:54 --> Input Class Initialized
INFO - 2023-04-18 02:13:54 --> Input Class Initialized
INFO - 2023-04-18 02:13:54 --> Language Class Initialized
INFO - 2023-04-18 02:13:54 --> Language Class Initialized
INFO - 2023-04-18 02:13:54 --> Loader Class Initialized
INFO - 2023-04-18 02:13:54 --> Loader Class Initialized
INFO - 2023-04-18 02:13:54 --> Controller Class Initialized
INFO - 2023-04-18 02:13:54 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 02:13:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:54 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:54 --> Total execution time: 0.0050
INFO - 2023-04-18 02:13:54 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:54 --> Config Class Initialized
INFO - 2023-04-18 02:13:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:54 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:54 --> URI Class Initialized
INFO - 2023-04-18 02:13:54 --> Router Class Initialized
INFO - 2023-04-18 02:13:54 --> Output Class Initialized
INFO - 2023-04-18 02:13:54 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:54 --> Input Class Initialized
INFO - 2023-04-18 02:13:54 --> Language Class Initialized
INFO - 2023-04-18 02:13:54 --> Loader Class Initialized
INFO - 2023-04-18 02:13:54 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:54 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:54 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:54 --> Total execution time: 0.0510
INFO - 2023-04-18 02:13:54 --> Config Class Initialized
INFO - 2023-04-18 02:13:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:54 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:54 --> URI Class Initialized
INFO - 2023-04-18 02:13:54 --> Router Class Initialized
INFO - 2023-04-18 02:13:54 --> Output Class Initialized
INFO - 2023-04-18 02:13:54 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:54 --> Input Class Initialized
INFO - 2023-04-18 02:13:54 --> Language Class Initialized
INFO - 2023-04-18 02:13:54 --> Loader Class Initialized
INFO - 2023-04-18 02:13:54 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:54 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:54 --> Model "Login_model" initialized
INFO - 2023-04-18 02:13:54 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:54 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:54 --> Total execution time: 0.0149
INFO - 2023-04-18 02:13:54 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:54 --> Total execution time: 0.0627
INFO - 2023-04-18 02:13:55 --> Config Class Initialized
INFO - 2023-04-18 02:13:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:55 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:55 --> URI Class Initialized
INFO - 2023-04-18 02:13:55 --> Router Class Initialized
INFO - 2023-04-18 02:13:55 --> Output Class Initialized
INFO - 2023-04-18 02:13:55 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:55 --> Input Class Initialized
INFO - 2023-04-18 02:13:55 --> Language Class Initialized
INFO - 2023-04-18 02:13:55 --> Loader Class Initialized
INFO - 2023-04-18 02:13:55 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:55 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:55 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:55 --> Model "Login_model" initialized
INFO - 2023-04-18 02:13:55 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:55 --> Total execution time: 0.1303
INFO - 2023-04-18 02:13:55 --> Config Class Initialized
INFO - 2023-04-18 02:13:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:55 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:55 --> URI Class Initialized
INFO - 2023-04-18 02:13:55 --> Router Class Initialized
INFO - 2023-04-18 02:13:55 --> Output Class Initialized
INFO - 2023-04-18 02:13:55 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:55 --> Input Class Initialized
INFO - 2023-04-18 02:13:55 --> Language Class Initialized
INFO - 2023-04-18 02:13:55 --> Loader Class Initialized
INFO - 2023-04-18 02:13:55 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:55 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:55 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:55 --> Model "Login_model" initialized
INFO - 2023-04-18 02:13:55 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:55 --> Total execution time: 0.0958
INFO - 2023-04-18 02:13:58 --> Config Class Initialized
INFO - 2023-04-18 02:13:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:58 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:58 --> URI Class Initialized
INFO - 2023-04-18 02:13:58 --> Router Class Initialized
INFO - 2023-04-18 02:13:58 --> Output Class Initialized
INFO - 2023-04-18 02:13:58 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:58 --> Input Class Initialized
INFO - 2023-04-18 02:13:58 --> Language Class Initialized
INFO - 2023-04-18 02:13:58 --> Loader Class Initialized
INFO - 2023-04-18 02:13:58 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:58 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:59 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:59 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:59 --> Total execution time: 0.0553
INFO - 2023-04-18 02:13:59 --> Config Class Initialized
INFO - 2023-04-18 02:13:59 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:13:59 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:13:59 --> Utf8 Class Initialized
INFO - 2023-04-18 02:13:59 --> URI Class Initialized
INFO - 2023-04-18 02:13:59 --> Router Class Initialized
INFO - 2023-04-18 02:13:59 --> Output Class Initialized
INFO - 2023-04-18 02:13:59 --> Security Class Initialized
DEBUG - 2023-04-18 02:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:13:59 --> Input Class Initialized
INFO - 2023-04-18 02:13:59 --> Language Class Initialized
INFO - 2023-04-18 02:13:59 --> Loader Class Initialized
INFO - 2023-04-18 02:13:59 --> Controller Class Initialized
DEBUG - 2023-04-18 02:13:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:13:59 --> Database Driver Class Initialized
INFO - 2023-04-18 02:13:59 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:13:59 --> Final output sent to browser
DEBUG - 2023-04-18 02:13:59 --> Total execution time: 0.0568
INFO - 2023-04-18 02:30:47 --> Config Class Initialized
INFO - 2023-04-18 02:30:47 --> Config Class Initialized
INFO - 2023-04-18 02:30:47 --> Hooks Class Initialized
INFO - 2023-04-18 02:30:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 02:30:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:30:47 --> Utf8 Class Initialized
INFO - 2023-04-18 02:30:47 --> Utf8 Class Initialized
INFO - 2023-04-18 02:30:47 --> URI Class Initialized
INFO - 2023-04-18 02:30:47 --> URI Class Initialized
INFO - 2023-04-18 02:30:47 --> Router Class Initialized
INFO - 2023-04-18 02:30:47 --> Router Class Initialized
INFO - 2023-04-18 02:30:47 --> Output Class Initialized
INFO - 2023-04-18 02:30:47 --> Output Class Initialized
INFO - 2023-04-18 02:30:47 --> Security Class Initialized
INFO - 2023-04-18 02:30:47 --> Security Class Initialized
DEBUG - 2023-04-18 02:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 02:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:30:47 --> Input Class Initialized
INFO - 2023-04-18 02:30:47 --> Input Class Initialized
INFO - 2023-04-18 02:30:47 --> Language Class Initialized
INFO - 2023-04-18 02:30:47 --> Language Class Initialized
INFO - 2023-04-18 02:30:47 --> Loader Class Initialized
INFO - 2023-04-18 02:30:47 --> Loader Class Initialized
INFO - 2023-04-18 02:30:47 --> Controller Class Initialized
INFO - 2023-04-18 02:30:47 --> Controller Class Initialized
DEBUG - 2023-04-18 02:30:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 02:30:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:30:47 --> Final output sent to browser
DEBUG - 2023-04-18 02:30:47 --> Total execution time: 0.0043
INFO - 2023-04-18 02:30:47 --> Database Driver Class Initialized
INFO - 2023-04-18 02:30:47 --> Config Class Initialized
INFO - 2023-04-18 02:30:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:30:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:30:47 --> Utf8 Class Initialized
INFO - 2023-04-18 02:30:47 --> URI Class Initialized
INFO - 2023-04-18 02:30:47 --> Router Class Initialized
INFO - 2023-04-18 02:30:47 --> Output Class Initialized
INFO - 2023-04-18 02:30:47 --> Security Class Initialized
DEBUG - 2023-04-18 02:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:30:47 --> Input Class Initialized
INFO - 2023-04-18 02:30:47 --> Language Class Initialized
INFO - 2023-04-18 02:30:47 --> Loader Class Initialized
INFO - 2023-04-18 02:30:47 --> Controller Class Initialized
DEBUG - 2023-04-18 02:30:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:30:47 --> Database Driver Class Initialized
INFO - 2023-04-18 02:30:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:30:47 --> Model "Login_model" initialized
INFO - 2023-04-18 02:30:47 --> Final output sent to browser
DEBUG - 2023-04-18 02:30:47 --> Total execution time: 0.0698
INFO - 2023-04-18 02:30:47 --> Database Driver Class Initialized
INFO - 2023-04-18 02:30:47 --> Config Class Initialized
INFO - 2023-04-18 02:30:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:30:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:30:47 --> Utf8 Class Initialized
INFO - 2023-04-18 02:30:47 --> URI Class Initialized
INFO - 2023-04-18 02:30:47 --> Router Class Initialized
INFO - 2023-04-18 02:30:47 --> Output Class Initialized
INFO - 2023-04-18 02:30:47 --> Security Class Initialized
DEBUG - 2023-04-18 02:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:30:47 --> Input Class Initialized
INFO - 2023-04-18 02:30:47 --> Language Class Initialized
INFO - 2023-04-18 02:30:47 --> Loader Class Initialized
INFO - 2023-04-18 02:30:47 --> Controller Class Initialized
DEBUG - 2023-04-18 02:30:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:30:47 --> Database Driver Class Initialized
INFO - 2023-04-18 02:30:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:30:47 --> Final output sent to browser
INFO - 2023-04-18 02:30:47 --> Model "Cluster_model" initialized
DEBUG - 2023-04-18 02:30:47 --> Total execution time: 0.0775
INFO - 2023-04-18 02:30:47 --> Final output sent to browser
DEBUG - 2023-04-18 02:30:47 --> Total execution time: 0.0153
INFO - 2023-04-18 02:30:48 --> Config Class Initialized
INFO - 2023-04-18 02:30:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:30:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:30:48 --> Utf8 Class Initialized
INFO - 2023-04-18 02:30:48 --> URI Class Initialized
INFO - 2023-04-18 02:30:48 --> Router Class Initialized
INFO - 2023-04-18 02:30:48 --> Output Class Initialized
INFO - 2023-04-18 02:30:48 --> Security Class Initialized
DEBUG - 2023-04-18 02:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:30:48 --> Input Class Initialized
INFO - 2023-04-18 02:30:48 --> Language Class Initialized
INFO - 2023-04-18 02:30:48 --> Loader Class Initialized
INFO - 2023-04-18 02:30:48 --> Controller Class Initialized
DEBUG - 2023-04-18 02:30:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:30:48 --> Database Driver Class Initialized
INFO - 2023-04-18 02:30:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:30:48 --> Database Driver Class Initialized
INFO - 2023-04-18 02:30:48 --> Model "Login_model" initialized
INFO - 2023-04-18 02:30:48 --> Final output sent to browser
DEBUG - 2023-04-18 02:30:48 --> Total execution time: 0.0657
INFO - 2023-04-18 02:30:48 --> Config Class Initialized
INFO - 2023-04-18 02:30:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:30:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:30:48 --> Utf8 Class Initialized
INFO - 2023-04-18 02:30:48 --> URI Class Initialized
INFO - 2023-04-18 02:30:48 --> Router Class Initialized
INFO - 2023-04-18 02:30:48 --> Output Class Initialized
INFO - 2023-04-18 02:30:48 --> Security Class Initialized
DEBUG - 2023-04-18 02:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:30:48 --> Input Class Initialized
INFO - 2023-04-18 02:30:48 --> Language Class Initialized
INFO - 2023-04-18 02:30:48 --> Loader Class Initialized
INFO - 2023-04-18 02:30:48 --> Controller Class Initialized
DEBUG - 2023-04-18 02:30:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:30:48 --> Database Driver Class Initialized
INFO - 2023-04-18 02:30:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:30:48 --> Database Driver Class Initialized
INFO - 2023-04-18 02:30:48 --> Model "Login_model" initialized
INFO - 2023-04-18 02:30:48 --> Final output sent to browser
DEBUG - 2023-04-18 02:30:48 --> Total execution time: 0.0969
INFO - 2023-04-18 02:39:32 --> Config Class Initialized
INFO - 2023-04-18 02:39:32 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:39:32 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:39:32 --> Utf8 Class Initialized
INFO - 2023-04-18 02:39:32 --> URI Class Initialized
INFO - 2023-04-18 02:39:32 --> Router Class Initialized
INFO - 2023-04-18 02:39:32 --> Output Class Initialized
INFO - 2023-04-18 02:39:32 --> Security Class Initialized
DEBUG - 2023-04-18 02:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:39:32 --> Input Class Initialized
INFO - 2023-04-18 02:39:32 --> Language Class Initialized
INFO - 2023-04-18 02:39:32 --> Loader Class Initialized
INFO - 2023-04-18 02:39:32 --> Controller Class Initialized
DEBUG - 2023-04-18 02:39:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:39:32 --> Database Driver Class Initialized
INFO - 2023-04-18 02:39:32 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:39:32 --> Final output sent to browser
DEBUG - 2023-04-18 02:39:32 --> Total execution time: 0.0397
INFO - 2023-04-18 02:39:32 --> Config Class Initialized
INFO - 2023-04-18 02:39:32 --> Hooks Class Initialized
DEBUG - 2023-04-18 02:39:32 --> UTF-8 Support Enabled
INFO - 2023-04-18 02:39:32 --> Utf8 Class Initialized
INFO - 2023-04-18 02:39:32 --> URI Class Initialized
INFO - 2023-04-18 02:39:32 --> Router Class Initialized
INFO - 2023-04-18 02:39:32 --> Output Class Initialized
INFO - 2023-04-18 02:39:32 --> Security Class Initialized
DEBUG - 2023-04-18 02:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 02:39:32 --> Input Class Initialized
INFO - 2023-04-18 02:39:32 --> Language Class Initialized
INFO - 2023-04-18 02:39:32 --> Loader Class Initialized
INFO - 2023-04-18 02:39:32 --> Controller Class Initialized
DEBUG - 2023-04-18 02:39:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 02:39:32 --> Database Driver Class Initialized
INFO - 2023-04-18 02:39:32 --> Model "Cluster_model" initialized
INFO - 2023-04-18 02:39:32 --> Final output sent to browser
DEBUG - 2023-04-18 02:39:32 --> Total execution time: 0.0394
INFO - 2023-04-18 03:10:14 --> Config Class Initialized
INFO - 2023-04-18 03:10:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:10:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:10:14 --> Utf8 Class Initialized
INFO - 2023-04-18 03:10:14 --> URI Class Initialized
INFO - 2023-04-18 03:10:14 --> Router Class Initialized
INFO - 2023-04-18 03:10:14 --> Output Class Initialized
INFO - 2023-04-18 03:10:14 --> Security Class Initialized
DEBUG - 2023-04-18 03:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:10:14 --> Input Class Initialized
INFO - 2023-04-18 03:10:14 --> Language Class Initialized
INFO - 2023-04-18 03:10:14 --> Loader Class Initialized
INFO - 2023-04-18 03:10:14 --> Controller Class Initialized
DEBUG - 2023-04-18 03:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:10:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:10:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:10:14 --> Final output sent to browser
DEBUG - 2023-04-18 03:10:14 --> Total execution time: 0.1734
INFO - 2023-04-18 03:10:14 --> Config Class Initialized
INFO - 2023-04-18 03:10:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:10:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:10:14 --> Utf8 Class Initialized
INFO - 2023-04-18 03:10:14 --> URI Class Initialized
INFO - 2023-04-18 03:10:14 --> Router Class Initialized
INFO - 2023-04-18 03:10:14 --> Output Class Initialized
INFO - 2023-04-18 03:10:14 --> Security Class Initialized
DEBUG - 2023-04-18 03:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:10:14 --> Input Class Initialized
INFO - 2023-04-18 03:10:14 --> Language Class Initialized
INFO - 2023-04-18 03:10:14 --> Loader Class Initialized
INFO - 2023-04-18 03:10:14 --> Controller Class Initialized
DEBUG - 2023-04-18 03:10:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:10:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:10:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:10:14 --> Final output sent to browser
DEBUG - 2023-04-18 03:10:14 --> Total execution time: 0.0390
INFO - 2023-04-18 03:20:24 --> Config Class Initialized
INFO - 2023-04-18 03:20:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:20:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:20:24 --> Utf8 Class Initialized
INFO - 2023-04-18 03:20:24 --> URI Class Initialized
INFO - 2023-04-18 03:20:24 --> Router Class Initialized
INFO - 2023-04-18 03:20:24 --> Output Class Initialized
INFO - 2023-04-18 03:20:24 --> Security Class Initialized
DEBUG - 2023-04-18 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:20:24 --> Input Class Initialized
INFO - 2023-04-18 03:20:24 --> Language Class Initialized
INFO - 2023-04-18 03:20:24 --> Loader Class Initialized
INFO - 2023-04-18 03:20:24 --> Controller Class Initialized
DEBUG - 2023-04-18 03:20:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:20:24 --> Database Driver Class Initialized
INFO - 2023-04-18 03:20:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:20:24 --> Database Driver Class Initialized
INFO - 2023-04-18 03:20:24 --> Model "Login_model" initialized
INFO - 2023-04-18 03:20:24 --> Final output sent to browser
DEBUG - 2023-04-18 03:20:24 --> Total execution time: 0.1101
INFO - 2023-04-18 03:20:24 --> Config Class Initialized
INFO - 2023-04-18 03:20:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:20:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:20:24 --> Utf8 Class Initialized
INFO - 2023-04-18 03:20:24 --> URI Class Initialized
INFO - 2023-04-18 03:20:24 --> Router Class Initialized
INFO - 2023-04-18 03:20:24 --> Output Class Initialized
INFO - 2023-04-18 03:20:24 --> Security Class Initialized
DEBUG - 2023-04-18 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:20:24 --> Input Class Initialized
INFO - 2023-04-18 03:20:24 --> Language Class Initialized
INFO - 2023-04-18 03:20:24 --> Loader Class Initialized
INFO - 2023-04-18 03:20:24 --> Controller Class Initialized
DEBUG - 2023-04-18 03:20:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:20:24 --> Database Driver Class Initialized
INFO - 2023-04-18 03:20:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:20:24 --> Database Driver Class Initialized
INFO - 2023-04-18 03:20:24 --> Model "Login_model" initialized
INFO - 2023-04-18 03:20:24 --> Final output sent to browser
DEBUG - 2023-04-18 03:20:24 --> Total execution time: 0.1099
INFO - 2023-04-18 03:20:28 --> Config Class Initialized
INFO - 2023-04-18 03:20:28 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:20:29 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:20:29 --> Utf8 Class Initialized
INFO - 2023-04-18 03:20:29 --> URI Class Initialized
INFO - 2023-04-18 03:20:29 --> Router Class Initialized
INFO - 2023-04-18 03:20:29 --> Output Class Initialized
INFO - 2023-04-18 03:20:29 --> Security Class Initialized
DEBUG - 2023-04-18 03:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:20:29 --> Input Class Initialized
INFO - 2023-04-18 03:20:29 --> Language Class Initialized
INFO - 2023-04-18 03:20:29 --> Loader Class Initialized
INFO - 2023-04-18 03:20:29 --> Controller Class Initialized
INFO - 2023-04-18 03:20:29 --> Helper loaded: form_helper
INFO - 2023-04-18 03:20:29 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:20:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:20:29 --> Model "Change_model" initialized
INFO - 2023-04-18 03:20:29 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:20:29 --> Final output sent to browser
DEBUG - 2023-04-18 03:20:29 --> Total execution time: 0.0423
INFO - 2023-04-18 03:20:39 --> Config Class Initialized
INFO - 2023-04-18 03:20:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:20:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:20:39 --> Utf8 Class Initialized
INFO - 2023-04-18 03:20:39 --> URI Class Initialized
INFO - 2023-04-18 03:20:39 --> Router Class Initialized
INFO - 2023-04-18 03:20:39 --> Output Class Initialized
INFO - 2023-04-18 03:20:39 --> Security Class Initialized
DEBUG - 2023-04-18 03:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:20:39 --> Input Class Initialized
INFO - 2023-04-18 03:20:39 --> Language Class Initialized
INFO - 2023-04-18 03:20:39 --> Loader Class Initialized
INFO - 2023-04-18 03:20:39 --> Controller Class Initialized
INFO - 2023-04-18 03:20:39 --> Helper loaded: form_helper
INFO - 2023-04-18 03:20:39 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:20:39 --> Model "Change_model" initialized
INFO - 2023-04-18 03:20:39 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:20:39 --> Final output sent to browser
DEBUG - 2023-04-18 03:20:39 --> Total execution time: 0.0280
INFO - 2023-04-18 03:21:04 --> Config Class Initialized
INFO - 2023-04-18 03:21:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:21:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:21:04 --> Utf8 Class Initialized
INFO - 2023-04-18 03:21:04 --> URI Class Initialized
INFO - 2023-04-18 03:21:04 --> Router Class Initialized
INFO - 2023-04-18 03:21:04 --> Output Class Initialized
INFO - 2023-04-18 03:21:04 --> Security Class Initialized
DEBUG - 2023-04-18 03:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:21:04 --> Input Class Initialized
INFO - 2023-04-18 03:21:04 --> Language Class Initialized
INFO - 2023-04-18 03:21:04 --> Loader Class Initialized
INFO - 2023-04-18 03:21:04 --> Controller Class Initialized
INFO - 2023-04-18 03:21:04 --> Helper loaded: form_helper
INFO - 2023-04-18 03:21:04 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:21:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:21:04 --> Model "Change_model" initialized
INFO - 2023-04-18 03:21:04 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:21:04 --> Final output sent to browser
DEBUG - 2023-04-18 03:21:04 --> Total execution time: 0.0243
INFO - 2023-04-18 03:22:11 --> Config Class Initialized
INFO - 2023-04-18 03:22:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:22:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:22:11 --> Utf8 Class Initialized
INFO - 2023-04-18 03:22:11 --> URI Class Initialized
INFO - 2023-04-18 03:22:11 --> Router Class Initialized
INFO - 2023-04-18 03:22:11 --> Output Class Initialized
INFO - 2023-04-18 03:22:11 --> Security Class Initialized
DEBUG - 2023-04-18 03:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:22:11 --> Input Class Initialized
INFO - 2023-04-18 03:22:11 --> Language Class Initialized
INFO - 2023-04-18 03:22:11 --> Loader Class Initialized
INFO - 2023-04-18 03:22:11 --> Controller Class Initialized
INFO - 2023-04-18 03:22:11 --> Helper loaded: form_helper
INFO - 2023-04-18 03:22:11 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:22:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:22:11 --> Model "Change_model" initialized
INFO - 2023-04-18 03:22:11 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:22:11 --> Final output sent to browser
DEBUG - 2023-04-18 03:22:11 --> Total execution time: 0.2536
INFO - 2023-04-18 03:22:36 --> Config Class Initialized
INFO - 2023-04-18 03:22:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:22:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:22:36 --> Utf8 Class Initialized
INFO - 2023-04-18 03:22:36 --> URI Class Initialized
INFO - 2023-04-18 03:22:36 --> Router Class Initialized
INFO - 2023-04-18 03:22:36 --> Output Class Initialized
INFO - 2023-04-18 03:22:36 --> Security Class Initialized
DEBUG - 2023-04-18 03:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:22:36 --> Input Class Initialized
INFO - 2023-04-18 03:22:36 --> Language Class Initialized
INFO - 2023-04-18 03:22:36 --> Loader Class Initialized
INFO - 2023-04-18 03:22:36 --> Controller Class Initialized
INFO - 2023-04-18 03:22:36 --> Helper loaded: form_helper
INFO - 2023-04-18 03:22:36 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:22:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:22:36 --> Model "Change_model" initialized
INFO - 2023-04-18 03:22:36 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:22:36 --> Final output sent to browser
DEBUG - 2023-04-18 03:22:36 --> Total execution time: 0.2604
INFO - 2023-04-18 03:24:03 --> Config Class Initialized
INFO - 2023-04-18 03:24:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:03 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:03 --> URI Class Initialized
INFO - 2023-04-18 03:24:03 --> Router Class Initialized
INFO - 2023-04-18 03:24:03 --> Output Class Initialized
INFO - 2023-04-18 03:24:03 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:03 --> Input Class Initialized
INFO - 2023-04-18 03:24:03 --> Language Class Initialized
INFO - 2023-04-18 03:24:03 --> Loader Class Initialized
INFO - 2023-04-18 03:24:03 --> Controller Class Initialized
INFO - 2023-04-18 03:24:03 --> Helper loaded: form_helper
INFO - 2023-04-18 03:24:03 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:24:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:03 --> Model "Change_model" initialized
INFO - 2023-04-18 03:24:03 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:24:03 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:03 --> Total execution time: 0.1025
INFO - 2023-04-18 03:24:03 --> Config Class Initialized
INFO - 2023-04-18 03:24:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:04 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:04 --> URI Class Initialized
INFO - 2023-04-18 03:24:04 --> Router Class Initialized
INFO - 2023-04-18 03:24:04 --> Output Class Initialized
INFO - 2023-04-18 03:24:04 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:04 --> Input Class Initialized
INFO - 2023-04-18 03:24:04 --> Language Class Initialized
ERROR - 2023-04-18 03:24:04 --> 404 Page Not Found: Faviconico/index
INFO - 2023-04-18 03:24:11 --> Config Class Initialized
INFO - 2023-04-18 03:24:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:11 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:11 --> URI Class Initialized
INFO - 2023-04-18 03:24:11 --> Router Class Initialized
INFO - 2023-04-18 03:24:12 --> Output Class Initialized
INFO - 2023-04-18 03:24:12 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:12 --> Input Class Initialized
INFO - 2023-04-18 03:24:12 --> Language Class Initialized
INFO - 2023-04-18 03:24:12 --> Loader Class Initialized
INFO - 2023-04-18 03:24:12 --> Controller Class Initialized
INFO - 2023-04-18 03:24:12 --> Helper loaded: form_helper
INFO - 2023-04-18 03:24:12 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:24:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:12 --> Model "Change_model" initialized
INFO - 2023-04-18 03:24:12 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:24:12 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:12 --> Total execution time: 1.0212
INFO - 2023-04-18 03:24:12 --> Config Class Initialized
INFO - 2023-04-18 03:24:12 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:12 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:12 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:13 --> URI Class Initialized
INFO - 2023-04-18 03:24:13 --> Router Class Initialized
INFO - 2023-04-18 03:24:13 --> Output Class Initialized
INFO - 2023-04-18 03:24:13 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:13 --> Input Class Initialized
INFO - 2023-04-18 03:24:13 --> Language Class Initialized
INFO - 2023-04-18 03:24:13 --> Loader Class Initialized
INFO - 2023-04-18 03:24:13 --> Controller Class Initialized
INFO - 2023-04-18 03:24:13 --> Helper loaded: form_helper
INFO - 2023-04-18 03:24:13 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:24:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:13 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:13 --> Total execution time: 0.6898
INFO - 2023-04-18 03:24:13 --> Config Class Initialized
INFO - 2023-04-18 03:24:13 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:13 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:13 --> URI Class Initialized
INFO - 2023-04-18 03:24:13 --> Router Class Initialized
INFO - 2023-04-18 03:24:13 --> Output Class Initialized
INFO - 2023-04-18 03:24:13 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:13 --> Input Class Initialized
INFO - 2023-04-18 03:24:13 --> Language Class Initialized
INFO - 2023-04-18 03:24:13 --> Loader Class Initialized
INFO - 2023-04-18 03:24:13 --> Controller Class Initialized
INFO - 2023-04-18 03:24:13 --> Helper loaded: form_helper
INFO - 2023-04-18 03:24:13 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:24:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:13 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:13 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:13 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:13 --> Total execution time: 0.2585
INFO - 2023-04-18 03:24:13 --> Config Class Initialized
INFO - 2023-04-18 03:24:13 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:13 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:13 --> URI Class Initialized
INFO - 2023-04-18 03:24:13 --> Router Class Initialized
INFO - 2023-04-18 03:24:13 --> Output Class Initialized
INFO - 2023-04-18 03:24:13 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:13 --> Input Class Initialized
INFO - 2023-04-18 03:24:13 --> Language Class Initialized
INFO - 2023-04-18 03:24:13 --> Loader Class Initialized
INFO - 2023-04-18 03:24:13 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:13 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:14 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:14 --> Total execution time: 0.0943
INFO - 2023-04-18 03:24:14 --> Config Class Initialized
INFO - 2023-04-18 03:24:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:14 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:14 --> URI Class Initialized
INFO - 2023-04-18 03:24:14 --> Router Class Initialized
INFO - 2023-04-18 03:24:14 --> Output Class Initialized
INFO - 2023-04-18 03:24:14 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:14 --> Input Class Initialized
INFO - 2023-04-18 03:24:14 --> Language Class Initialized
INFO - 2023-04-18 03:24:14 --> Loader Class Initialized
INFO - 2023-04-18 03:24:14 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:14 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:14 --> Total execution time: 0.0110
INFO - 2023-04-18 03:24:14 --> Config Class Initialized
INFO - 2023-04-18 03:24:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:14 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:14 --> URI Class Initialized
INFO - 2023-04-18 03:24:14 --> Router Class Initialized
INFO - 2023-04-18 03:24:14 --> Output Class Initialized
INFO - 2023-04-18 03:24:14 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:14 --> Input Class Initialized
INFO - 2023-04-18 03:24:14 --> Language Class Initialized
INFO - 2023-04-18 03:24:14 --> Loader Class Initialized
INFO - 2023-04-18 03:24:14 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:14 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:14 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:14 --> Total execution time: 0.2322
INFO - 2023-04-18 03:24:14 --> Config Class Initialized
INFO - 2023-04-18 03:24:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:14 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:14 --> URI Class Initialized
INFO - 2023-04-18 03:24:14 --> Router Class Initialized
INFO - 2023-04-18 03:24:14 --> Output Class Initialized
INFO - 2023-04-18 03:24:14 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:14 --> Input Class Initialized
INFO - 2023-04-18 03:24:14 --> Language Class Initialized
INFO - 2023-04-18 03:24:14 --> Loader Class Initialized
INFO - 2023-04-18 03:24:14 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:14 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:14 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:14 --> Total execution time: 0.3899
INFO - 2023-04-18 03:24:23 --> Config Class Initialized
INFO - 2023-04-18 03:24:23 --> Config Class Initialized
INFO - 2023-04-18 03:24:23 --> Hooks Class Initialized
INFO - 2023-04-18 03:24:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 03:24:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:23 --> URI Class Initialized
INFO - 2023-04-18 03:24:23 --> URI Class Initialized
INFO - 2023-04-18 03:24:23 --> Router Class Initialized
INFO - 2023-04-18 03:24:23 --> Router Class Initialized
INFO - 2023-04-18 03:24:23 --> Output Class Initialized
INFO - 2023-04-18 03:24:23 --> Output Class Initialized
INFO - 2023-04-18 03:24:23 --> Security Class Initialized
INFO - 2023-04-18 03:24:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 03:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:23 --> Input Class Initialized
INFO - 2023-04-18 03:24:23 --> Input Class Initialized
INFO - 2023-04-18 03:24:23 --> Language Class Initialized
INFO - 2023-04-18 03:24:23 --> Language Class Initialized
INFO - 2023-04-18 03:24:23 --> Loader Class Initialized
INFO - 2023-04-18 03:24:23 --> Loader Class Initialized
INFO - 2023-04-18 03:24:23 --> Controller Class Initialized
INFO - 2023-04-18 03:24:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 03:24:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:23 --> Final output sent to browser
INFO - 2023-04-18 03:24:23 --> Database Driver Class Initialized
DEBUG - 2023-04-18 03:24:23 --> Total execution time: 0.0063
INFO - 2023-04-18 03:24:23 --> Config Class Initialized
INFO - 2023-04-18 03:24:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:23 --> URI Class Initialized
INFO - 2023-04-18 03:24:23 --> Router Class Initialized
INFO - 2023-04-18 03:24:23 --> Output Class Initialized
INFO - 2023-04-18 03:24:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:23 --> Input Class Initialized
INFO - 2023-04-18 03:24:23 --> Language Class Initialized
INFO - 2023-04-18 03:24:23 --> Loader Class Initialized
INFO - 2023-04-18 03:24:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:23 --> Total execution time: 0.0565
INFO - 2023-04-18 03:24:23 --> Config Class Initialized
INFO - 2023-04-18 03:24:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:23 --> URI Class Initialized
INFO - 2023-04-18 03:24:23 --> Router Class Initialized
INFO - 2023-04-18 03:24:23 --> Output Class Initialized
INFO - 2023-04-18 03:24:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:23 --> Input Class Initialized
INFO - 2023-04-18 03:24:23 --> Language Class Initialized
INFO - 2023-04-18 03:24:23 --> Loader Class Initialized
INFO - 2023-04-18 03:24:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:23 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:23 --> Total execution time: 0.0128
INFO - 2023-04-18 03:24:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:23 --> Total execution time: 0.1070
INFO - 2023-04-18 03:24:26 --> Config Class Initialized
INFO - 2023-04-18 03:24:26 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:26 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:26 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:26 --> URI Class Initialized
INFO - 2023-04-18 03:24:26 --> Router Class Initialized
INFO - 2023-04-18 03:24:26 --> Output Class Initialized
INFO - 2023-04-18 03:24:26 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:26 --> Input Class Initialized
INFO - 2023-04-18 03:24:26 --> Language Class Initialized
INFO - 2023-04-18 03:24:26 --> Loader Class Initialized
INFO - 2023-04-18 03:24:26 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:26 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:26 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:26 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:26 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:26 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:26 --> Total execution time: 0.0622
INFO - 2023-04-18 03:24:26 --> Config Class Initialized
INFO - 2023-04-18 03:24:26 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:26 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:26 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:26 --> URI Class Initialized
INFO - 2023-04-18 03:24:26 --> Router Class Initialized
INFO - 2023-04-18 03:24:26 --> Output Class Initialized
INFO - 2023-04-18 03:24:26 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:26 --> Input Class Initialized
INFO - 2023-04-18 03:24:26 --> Language Class Initialized
INFO - 2023-04-18 03:24:26 --> Loader Class Initialized
INFO - 2023-04-18 03:24:26 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:26 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:26 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:26 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:26 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:26 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:26 --> Total execution time: 0.0625
INFO - 2023-04-18 03:24:39 --> Config Class Initialized
INFO - 2023-04-18 03:24:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:39 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:39 --> URI Class Initialized
INFO - 2023-04-18 03:24:39 --> Router Class Initialized
INFO - 2023-04-18 03:24:39 --> Output Class Initialized
INFO - 2023-04-18 03:24:39 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:39 --> Input Class Initialized
INFO - 2023-04-18 03:24:39 --> Language Class Initialized
INFO - 2023-04-18 03:24:39 --> Loader Class Initialized
INFO - 2023-04-18 03:24:39 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:39 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:39 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:39 --> Total execution time: 0.0125
INFO - 2023-04-18 03:24:39 --> Config Class Initialized
INFO - 2023-04-18 03:24:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:39 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:39 --> URI Class Initialized
INFO - 2023-04-18 03:24:39 --> Router Class Initialized
INFO - 2023-04-18 03:24:39 --> Output Class Initialized
INFO - 2023-04-18 03:24:39 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:39 --> Input Class Initialized
INFO - 2023-04-18 03:24:39 --> Language Class Initialized
INFO - 2023-04-18 03:24:39 --> Loader Class Initialized
INFO - 2023-04-18 03:24:39 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:39 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:39 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:39 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:39 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:39 --> Total execution time: 0.0188
INFO - 2023-04-18 03:24:39 --> Config Class Initialized
INFO - 2023-04-18 03:24:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:39 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:39 --> URI Class Initialized
INFO - 2023-04-18 03:24:39 --> Router Class Initialized
INFO - 2023-04-18 03:24:39 --> Output Class Initialized
INFO - 2023-04-18 03:24:39 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:39 --> Input Class Initialized
INFO - 2023-04-18 03:24:39 --> Language Class Initialized
INFO - 2023-04-18 03:24:39 --> Loader Class Initialized
INFO - 2023-04-18 03:24:39 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:39 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:39 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:39 --> Total execution time: 0.0491
INFO - 2023-04-18 03:24:39 --> Config Class Initialized
INFO - 2023-04-18 03:24:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:39 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:39 --> URI Class Initialized
INFO - 2023-04-18 03:24:39 --> Router Class Initialized
INFO - 2023-04-18 03:24:39 --> Output Class Initialized
INFO - 2023-04-18 03:24:39 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:39 --> Input Class Initialized
INFO - 2023-04-18 03:24:39 --> Language Class Initialized
INFO - 2023-04-18 03:24:39 --> Loader Class Initialized
INFO - 2023-04-18 03:24:39 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:39 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:39 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:39 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:39 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:39 --> Total execution time: 0.0218
INFO - 2023-04-18 03:24:40 --> Config Class Initialized
INFO - 2023-04-18 03:24:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:40 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:40 --> URI Class Initialized
INFO - 2023-04-18 03:24:40 --> Router Class Initialized
INFO - 2023-04-18 03:24:40 --> Output Class Initialized
INFO - 2023-04-18 03:24:40 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:40 --> Input Class Initialized
INFO - 2023-04-18 03:24:40 --> Language Class Initialized
INFO - 2023-04-18 03:24:40 --> Loader Class Initialized
INFO - 2023-04-18 03:24:40 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:40 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:40 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:40 --> Total execution time: 0.0166
INFO - 2023-04-18 03:24:40 --> Config Class Initialized
INFO - 2023-04-18 03:24:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:40 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:40 --> URI Class Initialized
INFO - 2023-04-18 03:24:40 --> Router Class Initialized
INFO - 2023-04-18 03:24:40 --> Output Class Initialized
INFO - 2023-04-18 03:24:40 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:40 --> Input Class Initialized
INFO - 2023-04-18 03:24:40 --> Language Class Initialized
INFO - 2023-04-18 03:24:40 --> Loader Class Initialized
INFO - 2023-04-18 03:24:40 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:40 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:40 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:40 --> Total execution time: 0.0573
INFO - 2023-04-18 03:24:41 --> Config Class Initialized
INFO - 2023-04-18 03:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:41 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:41 --> URI Class Initialized
INFO - 2023-04-18 03:24:41 --> Router Class Initialized
INFO - 2023-04-18 03:24:41 --> Output Class Initialized
INFO - 2023-04-18 03:24:41 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:41 --> Input Class Initialized
INFO - 2023-04-18 03:24:41 --> Language Class Initialized
INFO - 2023-04-18 03:24:41 --> Loader Class Initialized
INFO - 2023-04-18 03:24:41 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:41 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:41 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:41 --> Total execution time: 0.0114
INFO - 2023-04-18 03:24:41 --> Config Class Initialized
INFO - 2023-04-18 03:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:41 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:41 --> URI Class Initialized
INFO - 2023-04-18 03:24:41 --> Router Class Initialized
INFO - 2023-04-18 03:24:41 --> Output Class Initialized
INFO - 2023-04-18 03:24:41 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:41 --> Input Class Initialized
INFO - 2023-04-18 03:24:41 --> Language Class Initialized
INFO - 2023-04-18 03:24:41 --> Loader Class Initialized
INFO - 2023-04-18 03:24:41 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:41 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:41 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:41 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:41 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:41 --> Total execution time: 0.0200
INFO - 2023-04-18 03:24:41 --> Config Class Initialized
INFO - 2023-04-18 03:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:41 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:41 --> URI Class Initialized
INFO - 2023-04-18 03:24:41 --> Router Class Initialized
INFO - 2023-04-18 03:24:41 --> Output Class Initialized
INFO - 2023-04-18 03:24:41 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:41 --> Input Class Initialized
INFO - 2023-04-18 03:24:41 --> Language Class Initialized
INFO - 2023-04-18 03:24:41 --> Loader Class Initialized
INFO - 2023-04-18 03:24:41 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:41 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:41 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:41 --> Total execution time: 0.0136
INFO - 2023-04-18 03:24:41 --> Config Class Initialized
INFO - 2023-04-18 03:24:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:41 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:41 --> URI Class Initialized
INFO - 2023-04-18 03:24:41 --> Router Class Initialized
INFO - 2023-04-18 03:24:41 --> Output Class Initialized
INFO - 2023-04-18 03:24:41 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:41 --> Input Class Initialized
INFO - 2023-04-18 03:24:41 --> Language Class Initialized
INFO - 2023-04-18 03:24:41 --> Loader Class Initialized
INFO - 2023-04-18 03:24:41 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:41 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:41 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:41 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:41 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:41 --> Total execution time: 0.0229
INFO - 2023-04-18 03:24:42 --> Config Class Initialized
INFO - 2023-04-18 03:24:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:42 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:42 --> URI Class Initialized
INFO - 2023-04-18 03:24:42 --> Router Class Initialized
INFO - 2023-04-18 03:24:42 --> Output Class Initialized
INFO - 2023-04-18 03:24:42 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:42 --> Input Class Initialized
INFO - 2023-04-18 03:24:42 --> Language Class Initialized
INFO - 2023-04-18 03:24:42 --> Loader Class Initialized
INFO - 2023-04-18 03:24:42 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:42 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:42 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:42 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:42 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:42 --> Total execution time: 0.1117
INFO - 2023-04-18 03:24:42 --> Config Class Initialized
INFO - 2023-04-18 03:24:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:42 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:42 --> URI Class Initialized
INFO - 2023-04-18 03:24:42 --> Router Class Initialized
INFO - 2023-04-18 03:24:42 --> Output Class Initialized
INFO - 2023-04-18 03:24:42 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:42 --> Input Class Initialized
INFO - 2023-04-18 03:24:42 --> Language Class Initialized
INFO - 2023-04-18 03:24:42 --> Loader Class Initialized
INFO - 2023-04-18 03:24:42 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:42 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:42 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:42 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:42 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:42 --> Total execution time: 0.0649
INFO - 2023-04-18 03:24:44 --> Config Class Initialized
INFO - 2023-04-18 03:24:44 --> Config Class Initialized
INFO - 2023-04-18 03:24:44 --> Hooks Class Initialized
INFO - 2023-04-18 03:24:44 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 03:24:44 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:44 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:44 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:44 --> URI Class Initialized
INFO - 2023-04-18 03:24:44 --> URI Class Initialized
INFO - 2023-04-18 03:24:44 --> Router Class Initialized
INFO - 2023-04-18 03:24:44 --> Router Class Initialized
INFO - 2023-04-18 03:24:44 --> Output Class Initialized
INFO - 2023-04-18 03:24:44 --> Output Class Initialized
INFO - 2023-04-18 03:24:44 --> Security Class Initialized
INFO - 2023-04-18 03:24:44 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:44 --> Input Class Initialized
INFO - 2023-04-18 03:24:44 --> Input Class Initialized
INFO - 2023-04-18 03:24:44 --> Language Class Initialized
INFO - 2023-04-18 03:24:44 --> Language Class Initialized
INFO - 2023-04-18 03:24:44 --> Loader Class Initialized
INFO - 2023-04-18 03:24:44 --> Loader Class Initialized
INFO - 2023-04-18 03:24:44 --> Controller Class Initialized
INFO - 2023-04-18 03:24:44 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 03:24:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:44 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:44 --> Total execution time: 0.0046
INFO - 2023-04-18 03:24:44 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:44 --> Config Class Initialized
INFO - 2023-04-18 03:24:44 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:44 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:44 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:44 --> URI Class Initialized
INFO - 2023-04-18 03:24:44 --> Router Class Initialized
INFO - 2023-04-18 03:24:44 --> Output Class Initialized
INFO - 2023-04-18 03:24:44 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:44 --> Input Class Initialized
INFO - 2023-04-18 03:24:44 --> Language Class Initialized
INFO - 2023-04-18 03:24:44 --> Loader Class Initialized
INFO - 2023-04-18 03:24:44 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:44 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:44 --> Model "Login_model" initialized
INFO - 2023-04-18 03:24:44 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:44 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:44 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:44 --> Total execution time: 0.1034
INFO - 2023-04-18 03:24:44 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:44 --> Config Class Initialized
INFO - 2023-04-18 03:24:44 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:44 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:44 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:44 --> URI Class Initialized
INFO - 2023-04-18 03:24:44 --> Router Class Initialized
INFO - 2023-04-18 03:24:44 --> Output Class Initialized
INFO - 2023-04-18 03:24:44 --> Security Class Initialized
INFO - 2023-04-18 03:24:44 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 03:24:44 --> Total execution time: 0.1024
INFO - 2023-04-18 03:24:44 --> Input Class Initialized
INFO - 2023-04-18 03:24:44 --> Language Class Initialized
INFO - 2023-04-18 03:24:44 --> Loader Class Initialized
INFO - 2023-04-18 03:24:44 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:44 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:44 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:44 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:44 --> Total execution time: 0.0541
INFO - 2023-04-18 03:24:47 --> Config Class Initialized
INFO - 2023-04-18 03:24:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:47 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:47 --> URI Class Initialized
INFO - 2023-04-18 03:24:47 --> Router Class Initialized
INFO - 2023-04-18 03:24:47 --> Output Class Initialized
INFO - 2023-04-18 03:24:47 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:47 --> Input Class Initialized
INFO - 2023-04-18 03:24:47 --> Language Class Initialized
INFO - 2023-04-18 03:24:47 --> Loader Class Initialized
INFO - 2023-04-18 03:24:47 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:47 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:47 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:47 --> Total execution time: 0.0735
INFO - 2023-04-18 03:24:47 --> Config Class Initialized
INFO - 2023-04-18 03:24:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:48 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:48 --> URI Class Initialized
INFO - 2023-04-18 03:24:48 --> Router Class Initialized
INFO - 2023-04-18 03:24:48 --> Output Class Initialized
INFO - 2023-04-18 03:24:48 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:48 --> Input Class Initialized
INFO - 2023-04-18 03:24:48 --> Language Class Initialized
INFO - 2023-04-18 03:24:48 --> Loader Class Initialized
INFO - 2023-04-18 03:24:48 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:48 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:48 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:48 --> Total execution time: 0.0812
INFO - 2023-04-18 03:24:49 --> Config Class Initialized
INFO - 2023-04-18 03:24:49 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:49 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:49 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:49 --> URI Class Initialized
INFO - 2023-04-18 03:24:49 --> Router Class Initialized
INFO - 2023-04-18 03:24:49 --> Output Class Initialized
INFO - 2023-04-18 03:24:49 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:49 --> Input Class Initialized
INFO - 2023-04-18 03:24:49 --> Language Class Initialized
INFO - 2023-04-18 03:24:49 --> Loader Class Initialized
INFO - 2023-04-18 03:24:49 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:49 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:49 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:49 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:49 --> Total execution time: 0.0162
INFO - 2023-04-18 03:24:49 --> Config Class Initialized
INFO - 2023-04-18 03:24:49 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:24:49 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:24:49 --> Utf8 Class Initialized
INFO - 2023-04-18 03:24:49 --> URI Class Initialized
INFO - 2023-04-18 03:24:49 --> Router Class Initialized
INFO - 2023-04-18 03:24:49 --> Output Class Initialized
INFO - 2023-04-18 03:24:49 --> Security Class Initialized
DEBUG - 2023-04-18 03:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:24:49 --> Input Class Initialized
INFO - 2023-04-18 03:24:49 --> Language Class Initialized
INFO - 2023-04-18 03:24:49 --> Loader Class Initialized
INFO - 2023-04-18 03:24:49 --> Controller Class Initialized
DEBUG - 2023-04-18 03:24:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:24:49 --> Database Driver Class Initialized
INFO - 2023-04-18 03:24:49 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:24:49 --> Final output sent to browser
DEBUG - 2023-04-18 03:24:49 --> Total execution time: 0.0530
INFO - 2023-04-18 03:32:00 --> Config Class Initialized
INFO - 2023-04-18 03:32:00 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:32:00 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:32:00 --> Utf8 Class Initialized
INFO - 2023-04-18 03:32:00 --> URI Class Initialized
INFO - 2023-04-18 03:32:00 --> Router Class Initialized
INFO - 2023-04-18 03:32:00 --> Output Class Initialized
INFO - 2023-04-18 03:32:00 --> Security Class Initialized
DEBUG - 2023-04-18 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:32:00 --> Input Class Initialized
INFO - 2023-04-18 03:32:00 --> Language Class Initialized
INFO - 2023-04-18 03:32:00 --> Loader Class Initialized
INFO - 2023-04-18 03:32:00 --> Controller Class Initialized
DEBUG - 2023-04-18 03:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:32:00 --> Database Driver Class Initialized
INFO - 2023-04-18 03:32:00 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:32:00 --> Final output sent to browser
DEBUG - 2023-04-18 03:32:00 --> Total execution time: 0.1308
INFO - 2023-04-18 03:32:00 --> Config Class Initialized
INFO - 2023-04-18 03:32:00 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:32:00 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:32:01 --> Utf8 Class Initialized
INFO - 2023-04-18 03:32:01 --> URI Class Initialized
INFO - 2023-04-18 03:32:01 --> Router Class Initialized
INFO - 2023-04-18 03:32:01 --> Output Class Initialized
INFO - 2023-04-18 03:32:01 --> Security Class Initialized
DEBUG - 2023-04-18 03:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:32:01 --> Input Class Initialized
INFO - 2023-04-18 03:32:01 --> Language Class Initialized
INFO - 2023-04-18 03:32:01 --> Loader Class Initialized
INFO - 2023-04-18 03:32:01 --> Controller Class Initialized
DEBUG - 2023-04-18 03:32:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:32:01 --> Database Driver Class Initialized
INFO - 2023-04-18 03:32:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:32:01 --> Final output sent to browser
DEBUG - 2023-04-18 03:32:01 --> Total execution time: 0.1368
INFO - 2023-04-18 03:43:14 --> Config Class Initialized
INFO - 2023-04-18 03:43:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:14 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:14 --> URI Class Initialized
INFO - 2023-04-18 03:43:14 --> Router Class Initialized
INFO - 2023-04-18 03:43:14 --> Output Class Initialized
INFO - 2023-04-18 03:43:14 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:14 --> Input Class Initialized
INFO - 2023-04-18 03:43:14 --> Language Class Initialized
INFO - 2023-04-18 03:43:14 --> Loader Class Initialized
INFO - 2023-04-18 03:43:14 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:14 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:14 --> Total execution time: 0.1006
INFO - 2023-04-18 03:43:14 --> Config Class Initialized
INFO - 2023-04-18 03:43:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:14 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:14 --> URI Class Initialized
INFO - 2023-04-18 03:43:14 --> Router Class Initialized
INFO - 2023-04-18 03:43:14 --> Output Class Initialized
INFO - 2023-04-18 03:43:14 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:14 --> Input Class Initialized
INFO - 2023-04-18 03:43:14 --> Language Class Initialized
INFO - 2023-04-18 03:43:14 --> Loader Class Initialized
INFO - 2023-04-18 03:43:14 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:14 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:15 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:15 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:15 --> Total execution time: 0.0133
INFO - 2023-04-18 03:43:17 --> Config Class Initialized
INFO - 2023-04-18 03:43:17 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:17 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:17 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:17 --> URI Class Initialized
INFO - 2023-04-18 03:43:17 --> Router Class Initialized
INFO - 2023-04-18 03:43:17 --> Output Class Initialized
INFO - 2023-04-18 03:43:17 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:17 --> Input Class Initialized
INFO - 2023-04-18 03:43:17 --> Language Class Initialized
INFO - 2023-04-18 03:43:17 --> Loader Class Initialized
INFO - 2023-04-18 03:43:17 --> Controller Class Initialized
INFO - 2023-04-18 03:43:17 --> Helper loaded: form_helper
INFO - 2023-04-18 03:43:17 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:43:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:17 --> Model "Change_model" initialized
INFO - 2023-04-18 03:43:17 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:43:18 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:18 --> Total execution time: 0.0389
INFO - 2023-04-18 03:43:18 --> Config Class Initialized
INFO - 2023-04-18 03:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:18 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:18 --> URI Class Initialized
INFO - 2023-04-18 03:43:18 --> Router Class Initialized
INFO - 2023-04-18 03:43:18 --> Output Class Initialized
INFO - 2023-04-18 03:43:18 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:18 --> Input Class Initialized
INFO - 2023-04-18 03:43:18 --> Language Class Initialized
INFO - 2023-04-18 03:43:18 --> Loader Class Initialized
INFO - 2023-04-18 03:43:18 --> Controller Class Initialized
INFO - 2023-04-18 03:43:18 --> Helper loaded: form_helper
INFO - 2023-04-18 03:43:18 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:18 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:18 --> Total execution time: 0.0030
INFO - 2023-04-18 03:43:18 --> Config Class Initialized
INFO - 2023-04-18 03:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:18 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:18 --> URI Class Initialized
INFO - 2023-04-18 03:43:18 --> Router Class Initialized
INFO - 2023-04-18 03:43:18 --> Output Class Initialized
INFO - 2023-04-18 03:43:18 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:18 --> Input Class Initialized
INFO - 2023-04-18 03:43:18 --> Language Class Initialized
INFO - 2023-04-18 03:43:18 --> Loader Class Initialized
INFO - 2023-04-18 03:43:18 --> Controller Class Initialized
INFO - 2023-04-18 03:43:18 --> Helper loaded: form_helper
INFO - 2023-04-18 03:43:18 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:18 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:18 --> Model "Login_model" initialized
INFO - 2023-04-18 03:43:18 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:18 --> Total execution time: 0.0214
INFO - 2023-04-18 03:43:18 --> Config Class Initialized
INFO - 2023-04-18 03:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:18 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:18 --> URI Class Initialized
INFO - 2023-04-18 03:43:18 --> Router Class Initialized
INFO - 2023-04-18 03:43:18 --> Output Class Initialized
INFO - 2023-04-18 03:43:18 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:18 --> Input Class Initialized
INFO - 2023-04-18 03:43:18 --> Language Class Initialized
INFO - 2023-04-18 03:43:18 --> Loader Class Initialized
INFO - 2023-04-18 03:43:18 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:18 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:18 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:18 --> Total execution time: 0.0303
INFO - 2023-04-18 03:43:18 --> Config Class Initialized
INFO - 2023-04-18 03:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:18 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:18 --> URI Class Initialized
INFO - 2023-04-18 03:43:18 --> Router Class Initialized
INFO - 2023-04-18 03:43:18 --> Output Class Initialized
INFO - 2023-04-18 03:43:18 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:18 --> Input Class Initialized
INFO - 2023-04-18 03:43:18 --> Language Class Initialized
INFO - 2023-04-18 03:43:18 --> Loader Class Initialized
INFO - 2023-04-18 03:43:18 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:18 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:18 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:18 --> Total execution time: 0.0215
INFO - 2023-04-18 03:43:18 --> Config Class Initialized
INFO - 2023-04-18 03:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:18 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:18 --> URI Class Initialized
INFO - 2023-04-18 03:43:18 --> Router Class Initialized
INFO - 2023-04-18 03:43:18 --> Output Class Initialized
INFO - 2023-04-18 03:43:18 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:18 --> Input Class Initialized
INFO - 2023-04-18 03:43:18 --> Language Class Initialized
INFO - 2023-04-18 03:43:18 --> Loader Class Initialized
INFO - 2023-04-18 03:43:18 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:18 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:18 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:18 --> Model "Login_model" initialized
INFO - 2023-04-18 03:43:18 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:18 --> Total execution time: 0.1004
INFO - 2023-04-18 03:43:18 --> Config Class Initialized
INFO - 2023-04-18 03:43:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:18 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:18 --> URI Class Initialized
INFO - 2023-04-18 03:43:18 --> Router Class Initialized
INFO - 2023-04-18 03:43:18 --> Output Class Initialized
INFO - 2023-04-18 03:43:18 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:18 --> Input Class Initialized
INFO - 2023-04-18 03:43:18 --> Language Class Initialized
INFO - 2023-04-18 03:43:18 --> Loader Class Initialized
INFO - 2023-04-18 03:43:18 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:18 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:18 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:18 --> Model "Login_model" initialized
INFO - 2023-04-18 03:43:18 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:18 --> Total execution time: 0.1065
INFO - 2023-04-18 03:43:23 --> Config Class Initialized
INFO - 2023-04-18 03:43:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:23 --> URI Class Initialized
INFO - 2023-04-18 03:43:23 --> Router Class Initialized
INFO - 2023-04-18 03:43:23 --> Output Class Initialized
INFO - 2023-04-18 03:43:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:23 --> Input Class Initialized
INFO - 2023-04-18 03:43:23 --> Language Class Initialized
INFO - 2023-04-18 03:43:23 --> Loader Class Initialized
INFO - 2023-04-18 03:43:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:23 --> Total execution time: 0.0291
INFO - 2023-04-18 03:43:23 --> Config Class Initialized
INFO - 2023-04-18 03:43:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:23 --> URI Class Initialized
INFO - 2023-04-18 03:43:23 --> Router Class Initialized
INFO - 2023-04-18 03:43:23 --> Output Class Initialized
INFO - 2023-04-18 03:43:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:23 --> Input Class Initialized
INFO - 2023-04-18 03:43:23 --> Language Class Initialized
INFO - 2023-04-18 03:43:23 --> Loader Class Initialized
INFO - 2023-04-18 03:43:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:23 --> Total execution time: 0.0650
INFO - 2023-04-18 03:43:27 --> Config Class Initialized
INFO - 2023-04-18 03:43:27 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:27 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:27 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:27 --> URI Class Initialized
INFO - 2023-04-18 03:43:27 --> Router Class Initialized
INFO - 2023-04-18 03:43:27 --> Output Class Initialized
INFO - 2023-04-18 03:43:27 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:27 --> Input Class Initialized
INFO - 2023-04-18 03:43:27 --> Language Class Initialized
INFO - 2023-04-18 03:43:27 --> Loader Class Initialized
INFO - 2023-04-18 03:43:27 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:27 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:27 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:27 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:27 --> Total execution time: 0.0198
INFO - 2023-04-18 03:43:27 --> Config Class Initialized
INFO - 2023-04-18 03:43:27 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:43:27 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:43:27 --> Utf8 Class Initialized
INFO - 2023-04-18 03:43:27 --> URI Class Initialized
INFO - 2023-04-18 03:43:27 --> Router Class Initialized
INFO - 2023-04-18 03:43:27 --> Output Class Initialized
INFO - 2023-04-18 03:43:27 --> Security Class Initialized
DEBUG - 2023-04-18 03:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:43:27 --> Input Class Initialized
INFO - 2023-04-18 03:43:27 --> Language Class Initialized
INFO - 2023-04-18 03:43:27 --> Loader Class Initialized
INFO - 2023-04-18 03:43:27 --> Controller Class Initialized
DEBUG - 2023-04-18 03:43:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:43:27 --> Database Driver Class Initialized
INFO - 2023-04-18 03:43:27 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:43:27 --> Final output sent to browser
DEBUG - 2023-04-18 03:43:27 --> Total execution time: 0.0143
INFO - 2023-04-18 03:55:13 --> Config Class Initialized
INFO - 2023-04-18 03:55:13 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:13 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:13 --> URI Class Initialized
INFO - 2023-04-18 03:55:13 --> Router Class Initialized
INFO - 2023-04-18 03:55:13 --> Output Class Initialized
INFO - 2023-04-18 03:55:13 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:13 --> Input Class Initialized
INFO - 2023-04-18 03:55:13 --> Language Class Initialized
INFO - 2023-04-18 03:55:13 --> Loader Class Initialized
INFO - 2023-04-18 03:55:13 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:13 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:13 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:13 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:13 --> Model "Login_model" initialized
INFO - 2023-04-18 03:55:13 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:13 --> Total execution time: 0.1479
INFO - 2023-04-18 03:55:13 --> Config Class Initialized
INFO - 2023-04-18 03:55:13 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:13 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:13 --> URI Class Initialized
INFO - 2023-04-18 03:55:13 --> Router Class Initialized
INFO - 2023-04-18 03:55:13 --> Output Class Initialized
INFO - 2023-04-18 03:55:13 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:13 --> Input Class Initialized
INFO - 2023-04-18 03:55:13 --> Language Class Initialized
INFO - 2023-04-18 03:55:13 --> Loader Class Initialized
INFO - 2023-04-18 03:55:13 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:13 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:13 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:13 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:13 --> Model "Login_model" initialized
INFO - 2023-04-18 03:55:14 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:14 --> Total execution time: 0.0913
INFO - 2023-04-18 03:55:21 --> Config Class Initialized
INFO - 2023-04-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:21 --> URI Class Initialized
INFO - 2023-04-18 03:55:21 --> Router Class Initialized
INFO - 2023-04-18 03:55:21 --> Output Class Initialized
INFO - 2023-04-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:21 --> Input Class Initialized
INFO - 2023-04-18 03:55:21 --> Language Class Initialized
INFO - 2023-04-18 03:55:21 --> Loader Class Initialized
INFO - 2023-04-18 03:55:21 --> Controller Class Initialized
INFO - 2023-04-18 03:55:21 --> Helper loaded: form_helper
INFO - 2023-04-18 03:55:21 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:21 --> Model "Change_model" initialized
INFO - 2023-04-18 03:55:21 --> Model "Grafana_model" initialized
INFO - 2023-04-18 03:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:21 --> Total execution time: 0.0319
INFO - 2023-04-18 03:55:21 --> Config Class Initialized
INFO - 2023-04-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:21 --> URI Class Initialized
INFO - 2023-04-18 03:55:21 --> Router Class Initialized
INFO - 2023-04-18 03:55:21 --> Output Class Initialized
INFO - 2023-04-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:21 --> Input Class Initialized
INFO - 2023-04-18 03:55:21 --> Language Class Initialized
INFO - 2023-04-18 03:55:21 --> Loader Class Initialized
INFO - 2023-04-18 03:55:21 --> Controller Class Initialized
INFO - 2023-04-18 03:55:21 --> Helper loaded: form_helper
INFO - 2023-04-18 03:55:21 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:21 --> Total execution time: 0.0027
INFO - 2023-04-18 03:55:21 --> Config Class Initialized
INFO - 2023-04-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:21 --> URI Class Initialized
INFO - 2023-04-18 03:55:21 --> Router Class Initialized
INFO - 2023-04-18 03:55:21 --> Output Class Initialized
INFO - 2023-04-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:21 --> Input Class Initialized
INFO - 2023-04-18 03:55:21 --> Language Class Initialized
INFO - 2023-04-18 03:55:21 --> Loader Class Initialized
INFO - 2023-04-18 03:55:21 --> Controller Class Initialized
INFO - 2023-04-18 03:55:21 --> Helper loaded: form_helper
INFO - 2023-04-18 03:55:21 --> Helper loaded: url_helper
DEBUG - 2023-04-18 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:21 --> Model "Login_model" initialized
INFO - 2023-04-18 03:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:21 --> Total execution time: 0.0151
INFO - 2023-04-18 03:55:21 --> Config Class Initialized
INFO - 2023-04-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:21 --> URI Class Initialized
INFO - 2023-04-18 03:55:21 --> Router Class Initialized
INFO - 2023-04-18 03:55:21 --> Output Class Initialized
INFO - 2023-04-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:21 --> Input Class Initialized
INFO - 2023-04-18 03:55:21 --> Language Class Initialized
INFO - 2023-04-18 03:55:21 --> Loader Class Initialized
INFO - 2023-04-18 03:55:21 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:21 --> Total execution time: 0.0126
INFO - 2023-04-18 03:55:21 --> Config Class Initialized
INFO - 2023-04-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:21 --> URI Class Initialized
INFO - 2023-04-18 03:55:21 --> Router Class Initialized
INFO - 2023-04-18 03:55:21 --> Output Class Initialized
INFO - 2023-04-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:21 --> Input Class Initialized
INFO - 2023-04-18 03:55:21 --> Language Class Initialized
INFO - 2023-04-18 03:55:21 --> Loader Class Initialized
INFO - 2023-04-18 03:55:21 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:21 --> Total execution time: 0.0217
INFO - 2023-04-18 03:55:21 --> Config Class Initialized
INFO - 2023-04-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:21 --> URI Class Initialized
INFO - 2023-04-18 03:55:21 --> Router Class Initialized
INFO - 2023-04-18 03:55:21 --> Output Class Initialized
INFO - 2023-04-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:21 --> Input Class Initialized
INFO - 2023-04-18 03:55:21 --> Language Class Initialized
INFO - 2023-04-18 03:55:21 --> Loader Class Initialized
INFO - 2023-04-18 03:55:21 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:21 --> Model "Login_model" initialized
INFO - 2023-04-18 03:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:21 --> Total execution time: 0.0939
INFO - 2023-04-18 03:55:21 --> Config Class Initialized
INFO - 2023-04-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:21 --> URI Class Initialized
INFO - 2023-04-18 03:55:21 --> Router Class Initialized
INFO - 2023-04-18 03:55:21 --> Output Class Initialized
INFO - 2023-04-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:21 --> Input Class Initialized
INFO - 2023-04-18 03:55:21 --> Language Class Initialized
INFO - 2023-04-18 03:55:21 --> Loader Class Initialized
INFO - 2023-04-18 03:55:21 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:21 --> Model "Login_model" initialized
INFO - 2023-04-18 03:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:21 --> Total execution time: 0.0727
INFO - 2023-04-18 03:55:23 --> Config Class Initialized
INFO - 2023-04-18 03:55:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:23 --> URI Class Initialized
INFO - 2023-04-18 03:55:23 --> Router Class Initialized
INFO - 2023-04-18 03:55:23 --> Output Class Initialized
INFO - 2023-04-18 03:55:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:23 --> Input Class Initialized
INFO - 2023-04-18 03:55:23 --> Language Class Initialized
INFO - 2023-04-18 03:55:23 --> Loader Class Initialized
INFO - 2023-04-18 03:55:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:23 --> Total execution time: 0.0676
INFO - 2023-04-18 03:55:23 --> Config Class Initialized
INFO - 2023-04-18 03:55:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:23 --> URI Class Initialized
INFO - 2023-04-18 03:55:23 --> Router Class Initialized
INFO - 2023-04-18 03:55:23 --> Output Class Initialized
INFO - 2023-04-18 03:55:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:23 --> Input Class Initialized
INFO - 2023-04-18 03:55:23 --> Language Class Initialized
INFO - 2023-04-18 03:55:23 --> Loader Class Initialized
INFO - 2023-04-18 03:55:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:23 --> Total execution time: 0.0732
INFO - 2023-04-18 03:55:23 --> Config Class Initialized
INFO - 2023-04-18 03:55:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:23 --> URI Class Initialized
INFO - 2023-04-18 03:55:23 --> Router Class Initialized
INFO - 2023-04-18 03:55:23 --> Output Class Initialized
INFO - 2023-04-18 03:55:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:23 --> Input Class Initialized
INFO - 2023-04-18 03:55:23 --> Language Class Initialized
INFO - 2023-04-18 03:55:23 --> Loader Class Initialized
INFO - 2023-04-18 03:55:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:23 --> Total execution time: 0.0203
INFO - 2023-04-18 03:55:23 --> Config Class Initialized
INFO - 2023-04-18 03:55:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:23 --> URI Class Initialized
INFO - 2023-04-18 03:55:23 --> Router Class Initialized
INFO - 2023-04-18 03:55:23 --> Output Class Initialized
INFO - 2023-04-18 03:55:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:23 --> Input Class Initialized
INFO - 2023-04-18 03:55:23 --> Language Class Initialized
INFO - 2023-04-18 03:55:23 --> Loader Class Initialized
INFO - 2023-04-18 03:55:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:24 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:24 --> Total execution time: 0.0138
INFO - 2023-04-18 03:55:27 --> Config Class Initialized
INFO - 2023-04-18 03:55:27 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:27 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:27 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:27 --> URI Class Initialized
INFO - 2023-04-18 03:55:27 --> Router Class Initialized
INFO - 2023-04-18 03:55:27 --> Output Class Initialized
INFO - 2023-04-18 03:55:27 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:27 --> Input Class Initialized
INFO - 2023-04-18 03:55:27 --> Language Class Initialized
INFO - 2023-04-18 03:55:27 --> Loader Class Initialized
INFO - 2023-04-18 03:55:27 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:27 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:27 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:27 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:27 --> Model "Login_model" initialized
INFO - 2023-04-18 03:55:27 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:27 --> Total execution time: 0.1786
INFO - 2023-04-18 03:55:27 --> Config Class Initialized
INFO - 2023-04-18 03:55:27 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:55:27 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:55:27 --> Utf8 Class Initialized
INFO - 2023-04-18 03:55:27 --> URI Class Initialized
INFO - 2023-04-18 03:55:27 --> Router Class Initialized
INFO - 2023-04-18 03:55:27 --> Output Class Initialized
INFO - 2023-04-18 03:55:27 --> Security Class Initialized
DEBUG - 2023-04-18 03:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:55:27 --> Input Class Initialized
INFO - 2023-04-18 03:55:27 --> Language Class Initialized
INFO - 2023-04-18 03:55:27 --> Loader Class Initialized
INFO - 2023-04-18 03:55:27 --> Controller Class Initialized
DEBUG - 2023-04-18 03:55:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:55:27 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:27 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:55:27 --> Database Driver Class Initialized
INFO - 2023-04-18 03:55:27 --> Model "Login_model" initialized
INFO - 2023-04-18 03:55:27 --> Final output sent to browser
DEBUG - 2023-04-18 03:55:27 --> Total execution time: 0.0652
INFO - 2023-04-18 03:58:23 --> Config Class Initialized
INFO - 2023-04-18 03:58:23 --> Config Class Initialized
INFO - 2023-04-18 03:58:23 --> Hooks Class Initialized
INFO - 2023-04-18 03:58:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:58:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:58:23 --> Utf8 Class Initialized
DEBUG - 2023-04-18 03:58:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:58:23 --> URI Class Initialized
INFO - 2023-04-18 03:58:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:58:23 --> URI Class Initialized
INFO - 2023-04-18 03:58:23 --> Router Class Initialized
INFO - 2023-04-18 03:58:23 --> Router Class Initialized
INFO - 2023-04-18 03:58:23 --> Output Class Initialized
INFO - 2023-04-18 03:58:23 --> Output Class Initialized
INFO - 2023-04-18 03:58:23 --> Security Class Initialized
INFO - 2023-04-18 03:58:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 03:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:58:23 --> Input Class Initialized
INFO - 2023-04-18 03:58:23 --> Input Class Initialized
INFO - 2023-04-18 03:58:23 --> Language Class Initialized
INFO - 2023-04-18 03:58:23 --> Language Class Initialized
INFO - 2023-04-18 03:58:23 --> Loader Class Initialized
INFO - 2023-04-18 03:58:23 --> Loader Class Initialized
INFO - 2023-04-18 03:58:23 --> Controller Class Initialized
INFO - 2023-04-18 03:58:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:58:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 03:58:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:58:23 --> Final output sent to browser
INFO - 2023-04-18 03:58:23 --> Database Driver Class Initialized
DEBUG - 2023-04-18 03:58:23 --> Total execution time: 0.0050
INFO - 2023-04-18 03:58:23 --> Config Class Initialized
INFO - 2023-04-18 03:58:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:58:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:58:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:58:23 --> URI Class Initialized
INFO - 2023-04-18 03:58:23 --> Router Class Initialized
INFO - 2023-04-18 03:58:23 --> Output Class Initialized
INFO - 2023-04-18 03:58:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:58:23 --> Input Class Initialized
INFO - 2023-04-18 03:58:23 --> Language Class Initialized
INFO - 2023-04-18 03:58:23 --> Loader Class Initialized
INFO - 2023-04-18 03:58:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:58:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:58:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:58:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:58:23 --> Model "Login_model" initialized
INFO - 2023-04-18 03:58:23 --> Final output sent to browser
INFO - 2023-04-18 03:58:23 --> Database Driver Class Initialized
DEBUG - 2023-04-18 03:58:23 --> Total execution time: 0.0225
INFO - 2023-04-18 03:58:23 --> Config Class Initialized
INFO - 2023-04-18 03:58:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 03:58:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 03:58:23 --> Utf8 Class Initialized
INFO - 2023-04-18 03:58:23 --> URI Class Initialized
INFO - 2023-04-18 03:58:23 --> Router Class Initialized
INFO - 2023-04-18 03:58:23 --> Output Class Initialized
INFO - 2023-04-18 03:58:23 --> Security Class Initialized
DEBUG - 2023-04-18 03:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 03:58:23 --> Input Class Initialized
INFO - 2023-04-18 03:58:23 --> Language Class Initialized
INFO - 2023-04-18 03:58:23 --> Loader Class Initialized
INFO - 2023-04-18 03:58:23 --> Controller Class Initialized
DEBUG - 2023-04-18 03:58:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 03:58:23 --> Database Driver Class Initialized
INFO - 2023-04-18 03:58:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:58:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:58:23 --> Total execution time: 0.0225
INFO - 2023-04-18 03:58:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 03:58:23 --> Final output sent to browser
DEBUG - 2023-04-18 03:58:23 --> Total execution time: 0.0535
INFO - 2023-04-18 05:44:18 --> Config Class Initialized
INFO - 2023-04-18 05:44:18 --> Config Class Initialized
INFO - 2023-04-18 05:44:18 --> Hooks Class Initialized
INFO - 2023-04-18 05:44:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 05:44:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 05:44:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 05:44:18 --> Utf8 Class Initialized
INFO - 2023-04-18 05:44:18 --> Utf8 Class Initialized
INFO - 2023-04-18 05:44:18 --> URI Class Initialized
INFO - 2023-04-18 05:44:18 --> URI Class Initialized
INFO - 2023-04-18 05:44:18 --> Router Class Initialized
INFO - 2023-04-18 05:44:18 --> Router Class Initialized
INFO - 2023-04-18 05:44:18 --> Output Class Initialized
INFO - 2023-04-18 05:44:18 --> Output Class Initialized
INFO - 2023-04-18 05:44:18 --> Security Class Initialized
INFO - 2023-04-18 05:44:18 --> Security Class Initialized
DEBUG - 2023-04-18 05:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 05:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 05:44:18 --> Input Class Initialized
INFO - 2023-04-18 05:44:18 --> Input Class Initialized
INFO - 2023-04-18 05:44:18 --> Language Class Initialized
INFO - 2023-04-18 05:44:18 --> Language Class Initialized
INFO - 2023-04-18 05:44:18 --> Loader Class Initialized
INFO - 2023-04-18 05:44:18 --> Controller Class Initialized
DEBUG - 2023-04-18 05:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:44:18 --> Final output sent to browser
DEBUG - 2023-04-18 05:44:18 --> Total execution time: 0.0863
INFO - 2023-04-18 05:44:18 --> Config Class Initialized
INFO - 2023-04-18 05:44:18 --> Loader Class Initialized
INFO - 2023-04-18 05:44:18 --> Hooks Class Initialized
INFO - 2023-04-18 05:44:18 --> Controller Class Initialized
DEBUG - 2023-04-18 05:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 05:44:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 05:44:18 --> Utf8 Class Initialized
INFO - 2023-04-18 05:44:18 --> Database Driver Class Initialized
INFO - 2023-04-18 05:44:18 --> URI Class Initialized
INFO - 2023-04-18 05:44:18 --> Router Class Initialized
INFO - 2023-04-18 05:44:18 --> Output Class Initialized
INFO - 2023-04-18 05:44:18 --> Security Class Initialized
DEBUG - 2023-04-18 05:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 05:44:18 --> Input Class Initialized
INFO - 2023-04-18 05:44:18 --> Language Class Initialized
INFO - 2023-04-18 05:44:18 --> Loader Class Initialized
INFO - 2023-04-18 05:44:18 --> Controller Class Initialized
DEBUG - 2023-04-18 05:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:44:18 --> Database Driver Class Initialized
INFO - 2023-04-18 05:44:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 05:44:18 --> Model "Login_model" initialized
INFO - 2023-04-18 05:44:18 --> Database Driver Class Initialized
INFO - 2023-04-18 05:44:18 --> Final output sent to browser
DEBUG - 2023-04-18 05:44:18 --> Total execution time: 0.1494
INFO - 2023-04-18 05:44:18 --> Config Class Initialized
INFO - 2023-04-18 05:44:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 05:44:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 05:44:18 --> Utf8 Class Initialized
INFO - 2023-04-18 05:44:18 --> URI Class Initialized
INFO - 2023-04-18 05:44:18 --> Router Class Initialized
INFO - 2023-04-18 05:44:18 --> Output Class Initialized
INFO - 2023-04-18 05:44:18 --> Security Class Initialized
DEBUG - 2023-04-18 05:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 05:44:18 --> Input Class Initialized
INFO - 2023-04-18 05:44:18 --> Language Class Initialized
INFO - 2023-04-18 05:44:18 --> Loader Class Initialized
INFO - 2023-04-18 05:44:18 --> Controller Class Initialized
DEBUG - 2023-04-18 05:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:44:18 --> Database Driver Class Initialized
INFO - 2023-04-18 05:44:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 05:44:18 --> Final output sent to browser
DEBUG - 2023-04-18 05:44:18 --> Total execution time: 0.0681
INFO - 2023-04-18 05:44:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 05:44:18 --> Final output sent to browser
DEBUG - 2023-04-18 05:44:18 --> Total execution time: 0.0572
INFO - 2023-04-18 05:52:40 --> Config Class Initialized
INFO - 2023-04-18 05:52:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 05:52:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 05:52:40 --> Utf8 Class Initialized
INFO - 2023-04-18 05:52:40 --> URI Class Initialized
INFO - 2023-04-18 05:52:40 --> Router Class Initialized
INFO - 2023-04-18 05:52:40 --> Output Class Initialized
INFO - 2023-04-18 05:52:40 --> Security Class Initialized
DEBUG - 2023-04-18 05:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 05:52:40 --> Input Class Initialized
INFO - 2023-04-18 05:52:40 --> Language Class Initialized
INFO - 2023-04-18 05:52:40 --> Loader Class Initialized
INFO - 2023-04-18 05:52:40 --> Controller Class Initialized
DEBUG - 2023-04-18 05:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:52:40 --> Database Driver Class Initialized
INFO - 2023-04-18 05:52:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 05:52:40 --> Final output sent to browser
DEBUG - 2023-04-18 05:52:40 --> Total execution time: 0.0346
INFO - 2023-04-18 05:52:40 --> Config Class Initialized
INFO - 2023-04-18 05:52:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 05:52:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 05:52:40 --> Utf8 Class Initialized
INFO - 2023-04-18 05:52:40 --> URI Class Initialized
INFO - 2023-04-18 05:52:40 --> Router Class Initialized
INFO - 2023-04-18 05:52:40 --> Output Class Initialized
INFO - 2023-04-18 05:52:40 --> Security Class Initialized
DEBUG - 2023-04-18 05:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 05:52:40 --> Input Class Initialized
INFO - 2023-04-18 05:52:40 --> Language Class Initialized
INFO - 2023-04-18 05:52:40 --> Loader Class Initialized
INFO - 2023-04-18 05:52:40 --> Controller Class Initialized
DEBUG - 2023-04-18 05:52:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:52:40 --> Database Driver Class Initialized
INFO - 2023-04-18 05:52:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 05:52:40 --> Final output sent to browser
DEBUG - 2023-04-18 05:52:40 --> Total execution time: 0.0400
INFO - 2023-04-18 05:52:42 --> Config Class Initialized
INFO - 2023-04-18 05:52:42 --> Config Class Initialized
INFO - 2023-04-18 05:52:42 --> Hooks Class Initialized
INFO - 2023-04-18 05:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 05:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 05:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 05:52:42 --> Utf8 Class Initialized
INFO - 2023-04-18 05:52:42 --> Utf8 Class Initialized
INFO - 2023-04-18 05:52:42 --> URI Class Initialized
INFO - 2023-04-18 05:52:42 --> URI Class Initialized
INFO - 2023-04-18 05:52:42 --> Router Class Initialized
INFO - 2023-04-18 05:52:42 --> Router Class Initialized
INFO - 2023-04-18 05:52:42 --> Output Class Initialized
INFO - 2023-04-18 05:52:42 --> Output Class Initialized
INFO - 2023-04-18 05:52:42 --> Security Class Initialized
INFO - 2023-04-18 05:52:42 --> Security Class Initialized
DEBUG - 2023-04-18 05:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 05:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 05:52:42 --> Input Class Initialized
INFO - 2023-04-18 05:52:42 --> Language Class Initialized
INFO - 2023-04-18 05:52:42 --> Input Class Initialized
INFO - 2023-04-18 05:52:42 --> Loader Class Initialized
INFO - 2023-04-18 05:52:42 --> Language Class Initialized
INFO - 2023-04-18 05:52:42 --> Controller Class Initialized
DEBUG - 2023-04-18 05:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:52:42 --> Loader Class Initialized
INFO - 2023-04-18 05:52:42 --> Final output sent to browser
INFO - 2023-04-18 05:52:42 --> Controller Class Initialized
DEBUG - 2023-04-18 05:52:42 --> Total execution time: 0.0057
DEBUG - 2023-04-18 05:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:52:42 --> Database Driver Class Initialized
INFO - 2023-04-18 05:52:42 --> Config Class Initialized
INFO - 2023-04-18 05:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 05:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 05:52:42 --> Utf8 Class Initialized
INFO - 2023-04-18 05:52:42 --> URI Class Initialized
INFO - 2023-04-18 05:52:42 --> Router Class Initialized
INFO - 2023-04-18 05:52:42 --> Output Class Initialized
INFO - 2023-04-18 05:52:42 --> Security Class Initialized
DEBUG - 2023-04-18 05:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 05:52:42 --> Input Class Initialized
INFO - 2023-04-18 05:52:42 --> Language Class Initialized
INFO - 2023-04-18 05:52:42 --> Loader Class Initialized
INFO - 2023-04-18 05:52:42 --> Controller Class Initialized
DEBUG - 2023-04-18 05:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:52:42 --> Database Driver Class Initialized
INFO - 2023-04-18 05:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 05:52:43 --> Final output sent to browser
DEBUG - 2023-04-18 05:52:43 --> Total execution time: 0.0241
INFO - 2023-04-18 05:52:43 --> Model "Login_model" initialized
INFO - 2023-04-18 05:52:43 --> Config Class Initialized
INFO - 2023-04-18 05:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-18 05:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-18 05:52:43 --> Utf8 Class Initialized
INFO - 2023-04-18 05:52:43 --> Database Driver Class Initialized
INFO - 2023-04-18 05:52:43 --> URI Class Initialized
INFO - 2023-04-18 05:52:43 --> Router Class Initialized
INFO - 2023-04-18 05:52:43 --> Output Class Initialized
INFO - 2023-04-18 05:52:43 --> Security Class Initialized
DEBUG - 2023-04-18 05:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 05:52:43 --> Input Class Initialized
INFO - 2023-04-18 05:52:43 --> Language Class Initialized
INFO - 2023-04-18 05:52:43 --> Loader Class Initialized
INFO - 2023-04-18 05:52:43 --> Controller Class Initialized
DEBUG - 2023-04-18 05:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 05:52:43 --> Database Driver Class Initialized
INFO - 2023-04-18 05:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-18 05:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-18 05:52:43 --> Final output sent to browser
DEBUG - 2023-04-18 05:52:43 --> Total execution time: 0.0283
INFO - 2023-04-18 05:52:43 --> Final output sent to browser
DEBUG - 2023-04-18 05:52:43 --> Total execution time: 0.0165
INFO - 2023-04-18 06:22:51 --> Config Class Initialized
INFO - 2023-04-18 06:22:51 --> Config Class Initialized
INFO - 2023-04-18 06:22:51 --> Hooks Class Initialized
INFO - 2023-04-18 06:22:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 06:22:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:22:51 --> Utf8 Class Initialized
INFO - 2023-04-18 06:22:51 --> URI Class Initialized
INFO - 2023-04-18 06:22:51 --> Utf8 Class Initialized
INFO - 2023-04-18 06:22:51 --> Router Class Initialized
INFO - 2023-04-18 06:22:51 --> URI Class Initialized
INFO - 2023-04-18 06:22:51 --> Output Class Initialized
INFO - 2023-04-18 06:22:51 --> Router Class Initialized
INFO - 2023-04-18 06:22:51 --> Security Class Initialized
INFO - 2023-04-18 06:22:51 --> Output Class Initialized
DEBUG - 2023-04-18 06:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:22:51 --> Security Class Initialized
INFO - 2023-04-18 06:22:51 --> Input Class Initialized
DEBUG - 2023-04-18 06:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:22:51 --> Language Class Initialized
INFO - 2023-04-18 06:22:51 --> Input Class Initialized
INFO - 2023-04-18 06:22:51 --> Language Class Initialized
INFO - 2023-04-18 06:22:51 --> Loader Class Initialized
INFO - 2023-04-18 06:22:51 --> Controller Class Initialized
DEBUG - 2023-04-18 06:22:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:22:51 --> Final output sent to browser
DEBUG - 2023-04-18 06:22:51 --> Total execution time: 0.0838
INFO - 2023-04-18 06:22:51 --> Config Class Initialized
INFO - 2023-04-18 06:22:51 --> Loader Class Initialized
INFO - 2023-04-18 06:22:51 --> Hooks Class Initialized
INFO - 2023-04-18 06:22:51 --> Controller Class Initialized
DEBUG - 2023-04-18 06:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 06:22:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:22:51 --> Utf8 Class Initialized
INFO - 2023-04-18 06:22:51 --> URI Class Initialized
INFO - 2023-04-18 06:22:51 --> Router Class Initialized
INFO - 2023-04-18 06:22:51 --> Output Class Initialized
INFO - 2023-04-18 06:22:51 --> Security Class Initialized
DEBUG - 2023-04-18 06:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:22:51 --> Input Class Initialized
INFO - 2023-04-18 06:22:51 --> Language Class Initialized
INFO - 2023-04-18 06:22:51 --> Loader Class Initialized
INFO - 2023-04-18 06:22:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:22:51 --> Controller Class Initialized
DEBUG - 2023-04-18 06:22:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:22:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:22:51 --> Model "Login_model" initialized
INFO - 2023-04-18 06:22:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:22:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:22:51 --> Final output sent to browser
DEBUG - 2023-04-18 06:22:51 --> Total execution time: 0.1477
INFO - 2023-04-18 06:22:51 --> Config Class Initialized
INFO - 2023-04-18 06:22:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:22:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:22:51 --> Utf8 Class Initialized
INFO - 2023-04-18 06:22:51 --> URI Class Initialized
INFO - 2023-04-18 06:22:51 --> Router Class Initialized
INFO - 2023-04-18 06:22:51 --> Output Class Initialized
INFO - 2023-04-18 06:22:51 --> Security Class Initialized
DEBUG - 2023-04-18 06:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:22:51 --> Input Class Initialized
INFO - 2023-04-18 06:22:51 --> Language Class Initialized
INFO - 2023-04-18 06:22:51 --> Loader Class Initialized
INFO - 2023-04-18 06:22:51 --> Controller Class Initialized
DEBUG - 2023-04-18 06:22:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:22:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:22:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:22:51 --> Final output sent to browser
DEBUG - 2023-04-18 06:22:51 --> Total execution time: 0.0683
INFO - 2023-04-18 06:22:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:22:51 --> Final output sent to browser
DEBUG - 2023-04-18 06:22:51 --> Total execution time: 0.0547
INFO - 2023-04-18 06:22:52 --> Config Class Initialized
INFO - 2023-04-18 06:22:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:22:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:22:52 --> Utf8 Class Initialized
INFO - 2023-04-18 06:22:52 --> URI Class Initialized
INFO - 2023-04-18 06:22:52 --> Router Class Initialized
INFO - 2023-04-18 06:22:52 --> Output Class Initialized
INFO - 2023-04-18 06:22:52 --> Security Class Initialized
DEBUG - 2023-04-18 06:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:22:52 --> Input Class Initialized
INFO - 2023-04-18 06:22:52 --> Language Class Initialized
INFO - 2023-04-18 06:22:52 --> Loader Class Initialized
INFO - 2023-04-18 06:22:52 --> Controller Class Initialized
DEBUG - 2023-04-18 06:22:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:22:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:22:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:22:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:22:52 --> Model "Login_model" initialized
INFO - 2023-04-18 06:22:52 --> Final output sent to browser
DEBUG - 2023-04-18 06:22:52 --> Total execution time: 0.0689
INFO - 2023-04-18 06:22:52 --> Config Class Initialized
INFO - 2023-04-18 06:22:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:22:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:22:52 --> Utf8 Class Initialized
INFO - 2023-04-18 06:22:52 --> URI Class Initialized
INFO - 2023-04-18 06:22:52 --> Router Class Initialized
INFO - 2023-04-18 06:22:52 --> Output Class Initialized
INFO - 2023-04-18 06:22:52 --> Security Class Initialized
DEBUG - 2023-04-18 06:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:22:52 --> Input Class Initialized
INFO - 2023-04-18 06:22:52 --> Language Class Initialized
INFO - 2023-04-18 06:22:52 --> Loader Class Initialized
INFO - 2023-04-18 06:22:52 --> Controller Class Initialized
DEBUG - 2023-04-18 06:22:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:22:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:22:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:22:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:22:52 --> Model "Login_model" initialized
INFO - 2023-04-18 06:22:53 --> Final output sent to browser
DEBUG - 2023-04-18 06:22:53 --> Total execution time: 0.1114
INFO - 2023-04-18 06:26:35 --> Config Class Initialized
INFO - 2023-04-18 06:26:35 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:35 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:35 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:35 --> URI Class Initialized
INFO - 2023-04-18 06:26:35 --> Router Class Initialized
INFO - 2023-04-18 06:26:35 --> Output Class Initialized
INFO - 2023-04-18 06:26:35 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:35 --> Input Class Initialized
INFO - 2023-04-18 06:26:35 --> Language Class Initialized
INFO - 2023-04-18 06:26:35 --> Loader Class Initialized
INFO - 2023-04-18 06:26:35 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:35 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:35 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:35 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:35 --> Total execution time: 0.0250
INFO - 2023-04-18 06:26:35 --> Config Class Initialized
INFO - 2023-04-18 06:26:35 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:35 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:35 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:35 --> URI Class Initialized
INFO - 2023-04-18 06:26:35 --> Router Class Initialized
INFO - 2023-04-18 06:26:35 --> Output Class Initialized
INFO - 2023-04-18 06:26:35 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:35 --> Input Class Initialized
INFO - 2023-04-18 06:26:35 --> Language Class Initialized
INFO - 2023-04-18 06:26:35 --> Loader Class Initialized
INFO - 2023-04-18 06:26:35 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:35 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:35 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:35 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:35 --> Total execution time: 0.0579
INFO - 2023-04-18 06:26:36 --> Config Class Initialized
INFO - 2023-04-18 06:26:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:36 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:36 --> URI Class Initialized
INFO - 2023-04-18 06:26:36 --> Router Class Initialized
INFO - 2023-04-18 06:26:36 --> Output Class Initialized
INFO - 2023-04-18 06:26:36 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:36 --> Input Class Initialized
INFO - 2023-04-18 06:26:36 --> Language Class Initialized
INFO - 2023-04-18 06:26:36 --> Loader Class Initialized
INFO - 2023-04-18 06:26:36 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:36 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:36 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:36 --> Total execution time: 0.0148
INFO - 2023-04-18 06:26:36 --> Config Class Initialized
INFO - 2023-04-18 06:26:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:36 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:36 --> URI Class Initialized
INFO - 2023-04-18 06:26:36 --> Router Class Initialized
INFO - 2023-04-18 06:26:36 --> Output Class Initialized
INFO - 2023-04-18 06:26:36 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:36 --> Input Class Initialized
INFO - 2023-04-18 06:26:36 --> Language Class Initialized
INFO - 2023-04-18 06:26:36 --> Loader Class Initialized
INFO - 2023-04-18 06:26:36 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:36 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:36 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:36 --> Model "Login_model" initialized
INFO - 2023-04-18 06:26:36 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:36 --> Total execution time: 0.0206
INFO - 2023-04-18 06:26:36 --> Config Class Initialized
INFO - 2023-04-18 06:26:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:36 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:36 --> URI Class Initialized
INFO - 2023-04-18 06:26:36 --> Router Class Initialized
INFO - 2023-04-18 06:26:36 --> Output Class Initialized
INFO - 2023-04-18 06:26:36 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:36 --> Input Class Initialized
INFO - 2023-04-18 06:26:36 --> Language Class Initialized
INFO - 2023-04-18 06:26:36 --> Loader Class Initialized
INFO - 2023-04-18 06:26:36 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:36 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:36 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:36 --> Total execution time: 0.0909
INFO - 2023-04-18 06:26:36 --> Config Class Initialized
INFO - 2023-04-18 06:26:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:36 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:36 --> URI Class Initialized
INFO - 2023-04-18 06:26:36 --> Router Class Initialized
INFO - 2023-04-18 06:26:36 --> Output Class Initialized
INFO - 2023-04-18 06:26:36 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:36 --> Input Class Initialized
INFO - 2023-04-18 06:26:36 --> Language Class Initialized
INFO - 2023-04-18 06:26:36 --> Loader Class Initialized
INFO - 2023-04-18 06:26:36 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:36 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:36 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:36 --> Model "Login_model" initialized
INFO - 2023-04-18 06:26:36 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:36 --> Total execution time: 0.0203
INFO - 2023-04-18 06:26:40 --> Config Class Initialized
INFO - 2023-04-18 06:26:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:40 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:40 --> URI Class Initialized
INFO - 2023-04-18 06:26:40 --> Router Class Initialized
INFO - 2023-04-18 06:26:40 --> Output Class Initialized
INFO - 2023-04-18 06:26:40 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:40 --> Input Class Initialized
INFO - 2023-04-18 06:26:40 --> Language Class Initialized
INFO - 2023-04-18 06:26:40 --> Loader Class Initialized
INFO - 2023-04-18 06:26:40 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:40 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:40 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:40 --> Model "Login_model" initialized
INFO - 2023-04-18 06:26:40 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:40 --> Total execution time: 0.0911
INFO - 2023-04-18 06:26:40 --> Config Class Initialized
INFO - 2023-04-18 06:26:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:40 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:40 --> URI Class Initialized
INFO - 2023-04-18 06:26:40 --> Router Class Initialized
INFO - 2023-04-18 06:26:40 --> Output Class Initialized
INFO - 2023-04-18 06:26:40 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:40 --> Input Class Initialized
INFO - 2023-04-18 06:26:40 --> Language Class Initialized
INFO - 2023-04-18 06:26:40 --> Loader Class Initialized
INFO - 2023-04-18 06:26:40 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:40 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:40 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:40 --> Model "Login_model" initialized
INFO - 2023-04-18 06:26:40 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:40 --> Total execution time: 0.0635
INFO - 2023-04-18 06:26:43 --> Config Class Initialized
INFO - 2023-04-18 06:26:43 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:43 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:43 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:43 --> URI Class Initialized
INFO - 2023-04-18 06:26:43 --> Router Class Initialized
INFO - 2023-04-18 06:26:43 --> Output Class Initialized
INFO - 2023-04-18 06:26:43 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:43 --> Input Class Initialized
INFO - 2023-04-18 06:26:43 --> Language Class Initialized
INFO - 2023-04-18 06:26:43 --> Loader Class Initialized
INFO - 2023-04-18 06:26:43 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:43 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:43 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:43 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:43 --> Total execution time: 0.0167
INFO - 2023-04-18 06:26:43 --> Config Class Initialized
INFO - 2023-04-18 06:26:43 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:26:43 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:26:43 --> Utf8 Class Initialized
INFO - 2023-04-18 06:26:43 --> URI Class Initialized
INFO - 2023-04-18 06:26:43 --> Router Class Initialized
INFO - 2023-04-18 06:26:43 --> Output Class Initialized
INFO - 2023-04-18 06:26:43 --> Security Class Initialized
DEBUG - 2023-04-18 06:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:26:43 --> Input Class Initialized
INFO - 2023-04-18 06:26:43 --> Language Class Initialized
INFO - 2023-04-18 06:26:43 --> Loader Class Initialized
INFO - 2023-04-18 06:26:43 --> Controller Class Initialized
DEBUG - 2023-04-18 06:26:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:26:43 --> Database Driver Class Initialized
INFO - 2023-04-18 06:26:43 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:26:43 --> Final output sent to browser
DEBUG - 2023-04-18 06:26:43 --> Total execution time: 0.0531
INFO - 2023-04-18 06:27:07 --> Config Class Initialized
INFO - 2023-04-18 06:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:27:07 --> Utf8 Class Initialized
INFO - 2023-04-18 06:27:07 --> URI Class Initialized
INFO - 2023-04-18 06:27:07 --> Router Class Initialized
INFO - 2023-04-18 06:27:07 --> Output Class Initialized
INFO - 2023-04-18 06:27:07 --> Security Class Initialized
DEBUG - 2023-04-18 06:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:27:07 --> Input Class Initialized
INFO - 2023-04-18 06:27:07 --> Language Class Initialized
INFO - 2023-04-18 06:27:07 --> Loader Class Initialized
INFO - 2023-04-18 06:27:07 --> Controller Class Initialized
DEBUG - 2023-04-18 06:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:27:07 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:27:07 --> Final output sent to browser
DEBUG - 2023-04-18 06:27:07 --> Total execution time: 0.0762
INFO - 2023-04-18 06:27:07 --> Config Class Initialized
INFO - 2023-04-18 06:27:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:27:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:27:07 --> Utf8 Class Initialized
INFO - 2023-04-18 06:27:07 --> URI Class Initialized
INFO - 2023-04-18 06:27:07 --> Router Class Initialized
INFO - 2023-04-18 06:27:07 --> Output Class Initialized
INFO - 2023-04-18 06:27:07 --> Security Class Initialized
DEBUG - 2023-04-18 06:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:27:07 --> Input Class Initialized
INFO - 2023-04-18 06:27:07 --> Language Class Initialized
INFO - 2023-04-18 06:27:07 --> Loader Class Initialized
INFO - 2023-04-18 06:27:07 --> Controller Class Initialized
DEBUG - 2023-04-18 06:27:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:27:07 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:27:07 --> Final output sent to browser
DEBUG - 2023-04-18 06:27:07 --> Total execution time: 0.0762
INFO - 2023-04-18 06:27:10 --> Config Class Initialized
INFO - 2023-04-18 06:27:10 --> Config Class Initialized
INFO - 2023-04-18 06:27:10 --> Hooks Class Initialized
INFO - 2023-04-18 06:27:10 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:27:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 06:27:10 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:27:10 --> Utf8 Class Initialized
INFO - 2023-04-18 06:27:10 --> Utf8 Class Initialized
INFO - 2023-04-18 06:27:10 --> URI Class Initialized
INFO - 2023-04-18 06:27:10 --> URI Class Initialized
INFO - 2023-04-18 06:27:10 --> Router Class Initialized
INFO - 2023-04-18 06:27:10 --> Router Class Initialized
INFO - 2023-04-18 06:27:10 --> Output Class Initialized
INFO - 2023-04-18 06:27:10 --> Output Class Initialized
INFO - 2023-04-18 06:27:10 --> Security Class Initialized
INFO - 2023-04-18 06:27:10 --> Security Class Initialized
DEBUG - 2023-04-18 06:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 06:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:27:10 --> Input Class Initialized
INFO - 2023-04-18 06:27:10 --> Input Class Initialized
INFO - 2023-04-18 06:27:10 --> Language Class Initialized
INFO - 2023-04-18 06:27:10 --> Language Class Initialized
INFO - 2023-04-18 06:27:10 --> Loader Class Initialized
INFO - 2023-04-18 06:27:10 --> Loader Class Initialized
INFO - 2023-04-18 06:27:10 --> Controller Class Initialized
INFO - 2023-04-18 06:27:10 --> Controller Class Initialized
DEBUG - 2023-04-18 06:27:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 06:27:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:27:10 --> Final output sent to browser
DEBUG - 2023-04-18 06:27:10 --> Total execution time: 0.0048
INFO - 2023-04-18 06:27:10 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:10 --> Config Class Initialized
INFO - 2023-04-18 06:27:10 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:27:10 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:27:10 --> Utf8 Class Initialized
INFO - 2023-04-18 06:27:10 --> URI Class Initialized
INFO - 2023-04-18 06:27:10 --> Router Class Initialized
INFO - 2023-04-18 06:27:10 --> Output Class Initialized
INFO - 2023-04-18 06:27:10 --> Security Class Initialized
DEBUG - 2023-04-18 06:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:27:10 --> Input Class Initialized
INFO - 2023-04-18 06:27:10 --> Language Class Initialized
INFO - 2023-04-18 06:27:10 --> Loader Class Initialized
INFO - 2023-04-18 06:27:10 --> Controller Class Initialized
DEBUG - 2023-04-18 06:27:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:27:10 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:10 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:27:10 --> Final output sent to browser
DEBUG - 2023-04-18 06:27:10 --> Total execution time: 0.0191
INFO - 2023-04-18 06:27:10 --> Model "Login_model" initialized
INFO - 2023-04-18 06:27:10 --> Config Class Initialized
INFO - 2023-04-18 06:27:10 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:27:10 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:27:10 --> Utf8 Class Initialized
INFO - 2023-04-18 06:27:10 --> URI Class Initialized
INFO - 2023-04-18 06:27:10 --> Router Class Initialized
INFO - 2023-04-18 06:27:10 --> Output Class Initialized
INFO - 2023-04-18 06:27:10 --> Security Class Initialized
DEBUG - 2023-04-18 06:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:27:10 --> Input Class Initialized
INFO - 2023-04-18 06:27:10 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:10 --> Language Class Initialized
INFO - 2023-04-18 06:27:10 --> Loader Class Initialized
INFO - 2023-04-18 06:27:10 --> Controller Class Initialized
DEBUG - 2023-04-18 06:27:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:27:10 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:10 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:27:10 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:27:10 --> Final output sent to browser
DEBUG - 2023-04-18 06:27:10 --> Total execution time: 0.0227
INFO - 2023-04-18 06:27:10 --> Final output sent to browser
DEBUG - 2023-04-18 06:27:10 --> Total execution time: 0.0137
INFO - 2023-04-18 06:27:11 --> Config Class Initialized
INFO - 2023-04-18 06:27:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:27:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:27:11 --> Utf8 Class Initialized
INFO - 2023-04-18 06:27:11 --> URI Class Initialized
INFO - 2023-04-18 06:27:11 --> Router Class Initialized
INFO - 2023-04-18 06:27:11 --> Output Class Initialized
INFO - 2023-04-18 06:27:11 --> Security Class Initialized
DEBUG - 2023-04-18 06:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:27:11 --> Input Class Initialized
INFO - 2023-04-18 06:27:11 --> Language Class Initialized
INFO - 2023-04-18 06:27:11 --> Loader Class Initialized
INFO - 2023-04-18 06:27:11 --> Controller Class Initialized
DEBUG - 2023-04-18 06:27:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:27:11 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:27:11 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:11 --> Model "Login_model" initialized
INFO - 2023-04-18 06:27:11 --> Final output sent to browser
DEBUG - 2023-04-18 06:27:11 --> Total execution time: 0.0628
INFO - 2023-04-18 06:27:11 --> Config Class Initialized
INFO - 2023-04-18 06:27:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:27:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:27:11 --> Utf8 Class Initialized
INFO - 2023-04-18 06:27:11 --> URI Class Initialized
INFO - 2023-04-18 06:27:11 --> Router Class Initialized
INFO - 2023-04-18 06:27:11 --> Output Class Initialized
INFO - 2023-04-18 06:27:11 --> Security Class Initialized
DEBUG - 2023-04-18 06:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:27:11 --> Input Class Initialized
INFO - 2023-04-18 06:27:11 --> Language Class Initialized
INFO - 2023-04-18 06:27:11 --> Loader Class Initialized
INFO - 2023-04-18 06:27:11 --> Controller Class Initialized
DEBUG - 2023-04-18 06:27:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:27:11 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:27:11 --> Database Driver Class Initialized
INFO - 2023-04-18 06:27:11 --> Model "Login_model" initialized
INFO - 2023-04-18 06:27:11 --> Final output sent to browser
DEBUG - 2023-04-18 06:27:11 --> Total execution time: 0.0569
INFO - 2023-04-18 06:28:57 --> Config Class Initialized
INFO - 2023-04-18 06:28:57 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:28:57 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:28:57 --> Utf8 Class Initialized
INFO - 2023-04-18 06:28:57 --> URI Class Initialized
INFO - 2023-04-18 06:28:57 --> Router Class Initialized
INFO - 2023-04-18 06:28:57 --> Output Class Initialized
INFO - 2023-04-18 06:28:57 --> Security Class Initialized
DEBUG - 2023-04-18 06:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:28:57 --> Input Class Initialized
INFO - 2023-04-18 06:28:57 --> Language Class Initialized
INFO - 2023-04-18 06:28:57 --> Loader Class Initialized
INFO - 2023-04-18 06:28:57 --> Controller Class Initialized
DEBUG - 2023-04-18 06:28:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:28:57 --> Database Driver Class Initialized
INFO - 2023-04-18 06:28:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:28:58 --> Database Driver Class Initialized
INFO - 2023-04-18 06:28:58 --> Model "Login_model" initialized
INFO - 2023-04-18 06:28:58 --> Final output sent to browser
DEBUG - 2023-04-18 06:28:58 --> Total execution time: 0.1994
INFO - 2023-04-18 06:28:58 --> Config Class Initialized
INFO - 2023-04-18 06:28:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:28:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:28:58 --> Utf8 Class Initialized
INFO - 2023-04-18 06:28:58 --> URI Class Initialized
INFO - 2023-04-18 06:28:58 --> Router Class Initialized
INFO - 2023-04-18 06:28:58 --> Output Class Initialized
INFO - 2023-04-18 06:28:58 --> Security Class Initialized
DEBUG - 2023-04-18 06:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:28:58 --> Input Class Initialized
INFO - 2023-04-18 06:28:58 --> Language Class Initialized
INFO - 2023-04-18 06:28:58 --> Loader Class Initialized
INFO - 2023-04-18 06:28:58 --> Controller Class Initialized
DEBUG - 2023-04-18 06:28:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:28:58 --> Database Driver Class Initialized
INFO - 2023-04-18 06:28:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:28:58 --> Database Driver Class Initialized
INFO - 2023-04-18 06:28:58 --> Model "Login_model" initialized
INFO - 2023-04-18 06:28:58 --> Final output sent to browser
DEBUG - 2023-04-18 06:28:58 --> Total execution time: 0.0623
INFO - 2023-04-18 06:31:20 --> Config Class Initialized
INFO - 2023-04-18 06:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:31:20 --> Utf8 Class Initialized
INFO - 2023-04-18 06:31:20 --> URI Class Initialized
INFO - 2023-04-18 06:31:20 --> Router Class Initialized
INFO - 2023-04-18 06:31:20 --> Output Class Initialized
INFO - 2023-04-18 06:31:20 --> Security Class Initialized
DEBUG - 2023-04-18 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:31:20 --> Input Class Initialized
INFO - 2023-04-18 06:31:20 --> Language Class Initialized
INFO - 2023-04-18 06:31:20 --> Loader Class Initialized
INFO - 2023-04-18 06:31:20 --> Controller Class Initialized
DEBUG - 2023-04-18 06:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:31:20 --> Database Driver Class Initialized
INFO - 2023-04-18 06:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:31:20 --> Database Driver Class Initialized
INFO - 2023-04-18 06:31:20 --> Model "Login_model" initialized
INFO - 2023-04-18 06:31:20 --> Final output sent to browser
DEBUG - 2023-04-18 06:31:20 --> Total execution time: 0.2089
INFO - 2023-04-18 06:31:20 --> Config Class Initialized
INFO - 2023-04-18 06:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:31:20 --> Utf8 Class Initialized
INFO - 2023-04-18 06:31:20 --> URI Class Initialized
INFO - 2023-04-18 06:31:20 --> Router Class Initialized
INFO - 2023-04-18 06:31:20 --> Output Class Initialized
INFO - 2023-04-18 06:31:20 --> Security Class Initialized
DEBUG - 2023-04-18 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:31:20 --> Input Class Initialized
INFO - 2023-04-18 06:31:20 --> Language Class Initialized
INFO - 2023-04-18 06:31:20 --> Loader Class Initialized
INFO - 2023-04-18 06:31:20 --> Controller Class Initialized
DEBUG - 2023-04-18 06:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:31:20 --> Database Driver Class Initialized
INFO - 2023-04-18 06:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:31:20 --> Database Driver Class Initialized
INFO - 2023-04-18 06:31:20 --> Model "Login_model" initialized
INFO - 2023-04-18 06:31:20 --> Final output sent to browser
DEBUG - 2023-04-18 06:31:20 --> Total execution time: 0.0805
INFO - 2023-04-18 06:32:44 --> Config Class Initialized
INFO - 2023-04-18 06:32:44 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:32:44 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:32:44 --> Utf8 Class Initialized
INFO - 2023-04-18 06:32:44 --> URI Class Initialized
INFO - 2023-04-18 06:32:44 --> Router Class Initialized
INFO - 2023-04-18 06:32:44 --> Output Class Initialized
INFO - 2023-04-18 06:32:44 --> Security Class Initialized
DEBUG - 2023-04-18 06:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:32:44 --> Input Class Initialized
INFO - 2023-04-18 06:32:44 --> Language Class Initialized
INFO - 2023-04-18 06:32:44 --> Loader Class Initialized
INFO - 2023-04-18 06:32:44 --> Controller Class Initialized
DEBUG - 2023-04-18 06:32:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:32:44 --> Database Driver Class Initialized
INFO - 2023-04-18 06:32:44 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:32:44 --> Database Driver Class Initialized
INFO - 2023-04-18 06:32:44 --> Model "Login_model" initialized
INFO - 2023-04-18 06:32:44 --> Final output sent to browser
DEBUG - 2023-04-18 06:32:44 --> Total execution time: 0.1430
INFO - 2023-04-18 06:32:44 --> Config Class Initialized
INFO - 2023-04-18 06:32:44 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:32:44 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:32:44 --> Utf8 Class Initialized
INFO - 2023-04-18 06:32:44 --> URI Class Initialized
INFO - 2023-04-18 06:32:44 --> Router Class Initialized
INFO - 2023-04-18 06:32:44 --> Output Class Initialized
INFO - 2023-04-18 06:32:44 --> Security Class Initialized
DEBUG - 2023-04-18 06:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:32:44 --> Input Class Initialized
INFO - 2023-04-18 06:32:44 --> Language Class Initialized
INFO - 2023-04-18 06:32:44 --> Loader Class Initialized
INFO - 2023-04-18 06:32:44 --> Controller Class Initialized
DEBUG - 2023-04-18 06:32:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:32:44 --> Database Driver Class Initialized
INFO - 2023-04-18 06:32:44 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:32:44 --> Database Driver Class Initialized
INFO - 2023-04-18 06:32:44 --> Model "Login_model" initialized
INFO - 2023-04-18 06:32:44 --> Final output sent to browser
DEBUG - 2023-04-18 06:32:44 --> Total execution time: 0.0714
INFO - 2023-04-18 06:33:51 --> Config Class Initialized
INFO - 2023-04-18 06:33:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:33:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:33:51 --> Utf8 Class Initialized
INFO - 2023-04-18 06:33:51 --> URI Class Initialized
INFO - 2023-04-18 06:33:51 --> Router Class Initialized
INFO - 2023-04-18 06:33:51 --> Output Class Initialized
INFO - 2023-04-18 06:33:51 --> Security Class Initialized
DEBUG - 2023-04-18 06:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:33:51 --> Input Class Initialized
INFO - 2023-04-18 06:33:51 --> Language Class Initialized
INFO - 2023-04-18 06:33:51 --> Loader Class Initialized
INFO - 2023-04-18 06:33:51 --> Controller Class Initialized
DEBUG - 2023-04-18 06:33:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:33:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:33:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:33:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:33:51 --> Model "Login_model" initialized
INFO - 2023-04-18 06:33:51 --> Final output sent to browser
DEBUG - 2023-04-18 06:33:51 --> Total execution time: 0.1011
INFO - 2023-04-18 06:33:51 --> Config Class Initialized
INFO - 2023-04-18 06:33:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:33:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:33:51 --> Utf8 Class Initialized
INFO - 2023-04-18 06:33:51 --> URI Class Initialized
INFO - 2023-04-18 06:33:51 --> Router Class Initialized
INFO - 2023-04-18 06:33:51 --> Output Class Initialized
INFO - 2023-04-18 06:33:51 --> Security Class Initialized
DEBUG - 2023-04-18 06:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:33:51 --> Input Class Initialized
INFO - 2023-04-18 06:33:51 --> Language Class Initialized
INFO - 2023-04-18 06:33:51 --> Loader Class Initialized
INFO - 2023-04-18 06:33:51 --> Controller Class Initialized
DEBUG - 2023-04-18 06:33:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:33:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:33:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:33:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:33:51 --> Model "Login_model" initialized
INFO - 2023-04-18 06:33:51 --> Final output sent to browser
DEBUG - 2023-04-18 06:33:51 --> Total execution time: 0.0580
INFO - 2023-04-18 06:34:52 --> Config Class Initialized
INFO - 2023-04-18 06:34:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:34:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:34:52 --> Utf8 Class Initialized
INFO - 2023-04-18 06:34:52 --> URI Class Initialized
INFO - 2023-04-18 06:34:52 --> Router Class Initialized
INFO - 2023-04-18 06:34:52 --> Output Class Initialized
INFO - 2023-04-18 06:34:52 --> Security Class Initialized
DEBUG - 2023-04-18 06:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:34:52 --> Input Class Initialized
INFO - 2023-04-18 06:34:52 --> Language Class Initialized
INFO - 2023-04-18 06:34:52 --> Loader Class Initialized
INFO - 2023-04-18 06:34:52 --> Controller Class Initialized
DEBUG - 2023-04-18 06:34:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:34:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:34:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:34:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:34:52 --> Model "Login_model" initialized
INFO - 2023-04-18 06:34:52 --> Final output sent to browser
DEBUG - 2023-04-18 06:34:52 --> Total execution time: 0.1542
INFO - 2023-04-18 06:34:52 --> Config Class Initialized
INFO - 2023-04-18 06:34:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:34:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:34:52 --> Utf8 Class Initialized
INFO - 2023-04-18 06:34:52 --> URI Class Initialized
INFO - 2023-04-18 06:34:52 --> Router Class Initialized
INFO - 2023-04-18 06:34:52 --> Output Class Initialized
INFO - 2023-04-18 06:34:52 --> Security Class Initialized
DEBUG - 2023-04-18 06:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:34:52 --> Input Class Initialized
INFO - 2023-04-18 06:34:52 --> Language Class Initialized
INFO - 2023-04-18 06:34:52 --> Loader Class Initialized
INFO - 2023-04-18 06:34:52 --> Controller Class Initialized
DEBUG - 2023-04-18 06:34:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:34:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:34:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:34:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:34:52 --> Model "Login_model" initialized
INFO - 2023-04-18 06:34:52 --> Final output sent to browser
DEBUG - 2023-04-18 06:34:52 --> Total execution time: 0.1304
INFO - 2023-04-18 06:35:53 --> Config Class Initialized
INFO - 2023-04-18 06:35:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:35:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:35:53 --> Utf8 Class Initialized
INFO - 2023-04-18 06:35:53 --> URI Class Initialized
INFO - 2023-04-18 06:35:53 --> Router Class Initialized
INFO - 2023-04-18 06:35:53 --> Output Class Initialized
INFO - 2023-04-18 06:35:53 --> Security Class Initialized
DEBUG - 2023-04-18 06:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:35:53 --> Input Class Initialized
INFO - 2023-04-18 06:35:53 --> Language Class Initialized
INFO - 2023-04-18 06:35:53 --> Loader Class Initialized
INFO - 2023-04-18 06:35:53 --> Controller Class Initialized
DEBUG - 2023-04-18 06:35:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:35:53 --> Database Driver Class Initialized
INFO - 2023-04-18 06:35:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:35:53 --> Database Driver Class Initialized
INFO - 2023-04-18 06:35:53 --> Model "Login_model" initialized
INFO - 2023-04-18 06:35:53 --> Final output sent to browser
DEBUG - 2023-04-18 06:35:53 --> Total execution time: 0.3811
INFO - 2023-04-18 06:35:54 --> Config Class Initialized
INFO - 2023-04-18 06:35:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:35:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:35:54 --> Utf8 Class Initialized
INFO - 2023-04-18 06:35:54 --> URI Class Initialized
INFO - 2023-04-18 06:35:54 --> Router Class Initialized
INFO - 2023-04-18 06:35:54 --> Output Class Initialized
INFO - 2023-04-18 06:35:54 --> Security Class Initialized
DEBUG - 2023-04-18 06:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:35:54 --> Input Class Initialized
INFO - 2023-04-18 06:35:54 --> Language Class Initialized
INFO - 2023-04-18 06:35:54 --> Loader Class Initialized
INFO - 2023-04-18 06:35:54 --> Controller Class Initialized
DEBUG - 2023-04-18 06:35:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:35:54 --> Database Driver Class Initialized
INFO - 2023-04-18 06:35:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:35:54 --> Database Driver Class Initialized
INFO - 2023-04-18 06:35:54 --> Model "Login_model" initialized
INFO - 2023-04-18 06:35:54 --> Final output sent to browser
DEBUG - 2023-04-18 06:35:54 --> Total execution time: 0.0690
INFO - 2023-04-18 06:36:15 --> Config Class Initialized
INFO - 2023-04-18 06:36:15 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:36:15 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:36:15 --> Utf8 Class Initialized
INFO - 2023-04-18 06:36:15 --> URI Class Initialized
INFO - 2023-04-18 06:36:15 --> Router Class Initialized
INFO - 2023-04-18 06:36:15 --> Output Class Initialized
INFO - 2023-04-18 06:36:15 --> Security Class Initialized
DEBUG - 2023-04-18 06:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:36:15 --> Input Class Initialized
INFO - 2023-04-18 06:36:15 --> Language Class Initialized
INFO - 2023-04-18 06:36:15 --> Loader Class Initialized
INFO - 2023-04-18 06:36:15 --> Controller Class Initialized
DEBUG - 2023-04-18 06:36:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:36:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:36:15 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:36:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:36:15 --> Model "Login_model" initialized
INFO - 2023-04-18 06:36:15 --> Final output sent to browser
DEBUG - 2023-04-18 06:36:15 --> Total execution time: 0.1481
INFO - 2023-04-18 06:36:15 --> Config Class Initialized
INFO - 2023-04-18 06:36:15 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:36:15 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:36:15 --> Utf8 Class Initialized
INFO - 2023-04-18 06:36:15 --> URI Class Initialized
INFO - 2023-04-18 06:36:15 --> Router Class Initialized
INFO - 2023-04-18 06:36:15 --> Output Class Initialized
INFO - 2023-04-18 06:36:15 --> Security Class Initialized
DEBUG - 2023-04-18 06:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:36:15 --> Input Class Initialized
INFO - 2023-04-18 06:36:15 --> Language Class Initialized
INFO - 2023-04-18 06:36:15 --> Loader Class Initialized
INFO - 2023-04-18 06:36:15 --> Controller Class Initialized
DEBUG - 2023-04-18 06:36:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:36:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:36:15 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:36:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:36:15 --> Model "Login_model" initialized
INFO - 2023-04-18 06:36:15 --> Final output sent to browser
DEBUG - 2023-04-18 06:36:15 --> Total execution time: 0.0588
INFO - 2023-04-18 06:36:39 --> Config Class Initialized
INFO - 2023-04-18 06:36:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:36:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:36:39 --> Utf8 Class Initialized
INFO - 2023-04-18 06:36:39 --> URI Class Initialized
INFO - 2023-04-18 06:36:39 --> Router Class Initialized
INFO - 2023-04-18 06:36:39 --> Output Class Initialized
INFO - 2023-04-18 06:36:39 --> Security Class Initialized
DEBUG - 2023-04-18 06:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:36:39 --> Input Class Initialized
INFO - 2023-04-18 06:36:39 --> Language Class Initialized
INFO - 2023-04-18 06:36:39 --> Loader Class Initialized
INFO - 2023-04-18 06:36:39 --> Controller Class Initialized
DEBUG - 2023-04-18 06:36:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:36:39 --> Database Driver Class Initialized
INFO - 2023-04-18 06:36:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:36:39 --> Database Driver Class Initialized
INFO - 2023-04-18 06:36:39 --> Model "Login_model" initialized
INFO - 2023-04-18 06:36:39 --> Final output sent to browser
DEBUG - 2023-04-18 06:36:39 --> Total execution time: 0.1473
INFO - 2023-04-18 06:36:39 --> Config Class Initialized
INFO - 2023-04-18 06:36:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:36:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:36:39 --> Utf8 Class Initialized
INFO - 2023-04-18 06:36:39 --> URI Class Initialized
INFO - 2023-04-18 06:36:39 --> Router Class Initialized
INFO - 2023-04-18 06:36:39 --> Output Class Initialized
INFO - 2023-04-18 06:36:39 --> Security Class Initialized
DEBUG - 2023-04-18 06:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:36:39 --> Input Class Initialized
INFO - 2023-04-18 06:36:39 --> Language Class Initialized
INFO - 2023-04-18 06:36:39 --> Loader Class Initialized
INFO - 2023-04-18 06:36:39 --> Controller Class Initialized
DEBUG - 2023-04-18 06:36:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:36:39 --> Database Driver Class Initialized
INFO - 2023-04-18 06:36:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:36:39 --> Database Driver Class Initialized
INFO - 2023-04-18 06:36:39 --> Model "Login_model" initialized
INFO - 2023-04-18 06:36:39 --> Final output sent to browser
DEBUG - 2023-04-18 06:36:39 --> Total execution time: 0.0619
INFO - 2023-04-18 06:37:17 --> Config Class Initialized
INFO - 2023-04-18 06:37:17 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:37:17 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:37:17 --> Utf8 Class Initialized
INFO - 2023-04-18 06:37:17 --> URI Class Initialized
INFO - 2023-04-18 06:37:17 --> Router Class Initialized
INFO - 2023-04-18 06:37:17 --> Output Class Initialized
INFO - 2023-04-18 06:37:17 --> Security Class Initialized
DEBUG - 2023-04-18 06:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:37:17 --> Input Class Initialized
INFO - 2023-04-18 06:37:17 --> Language Class Initialized
INFO - 2023-04-18 06:37:17 --> Loader Class Initialized
INFO - 2023-04-18 06:37:17 --> Controller Class Initialized
DEBUG - 2023-04-18 06:37:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:37:17 --> Database Driver Class Initialized
INFO - 2023-04-18 06:37:17 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:37:17 --> Database Driver Class Initialized
INFO - 2023-04-18 06:37:17 --> Model "Login_model" initialized
INFO - 2023-04-18 06:37:17 --> Final output sent to browser
DEBUG - 2023-04-18 06:37:17 --> Total execution time: 0.1750
INFO - 2023-04-18 06:37:17 --> Config Class Initialized
INFO - 2023-04-18 06:37:17 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:37:17 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:37:17 --> Utf8 Class Initialized
INFO - 2023-04-18 06:37:17 --> URI Class Initialized
INFO - 2023-04-18 06:37:17 --> Router Class Initialized
INFO - 2023-04-18 06:37:17 --> Output Class Initialized
INFO - 2023-04-18 06:37:17 --> Security Class Initialized
DEBUG - 2023-04-18 06:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:37:17 --> Input Class Initialized
INFO - 2023-04-18 06:37:17 --> Language Class Initialized
INFO - 2023-04-18 06:37:17 --> Loader Class Initialized
INFO - 2023-04-18 06:37:17 --> Controller Class Initialized
DEBUG - 2023-04-18 06:37:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:37:17 --> Database Driver Class Initialized
INFO - 2023-04-18 06:37:17 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:37:17 --> Database Driver Class Initialized
INFO - 2023-04-18 06:37:17 --> Model "Login_model" initialized
INFO - 2023-04-18 06:37:17 --> Final output sent to browser
DEBUG - 2023-04-18 06:37:17 --> Total execution time: 0.0652
INFO - 2023-04-18 06:38:42 --> Config Class Initialized
INFO - 2023-04-18 06:38:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:38:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:38:42 --> Utf8 Class Initialized
INFO - 2023-04-18 06:38:42 --> URI Class Initialized
INFO - 2023-04-18 06:38:42 --> Router Class Initialized
INFO - 2023-04-18 06:38:42 --> Output Class Initialized
INFO - 2023-04-18 06:38:42 --> Security Class Initialized
DEBUG - 2023-04-18 06:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:38:42 --> Input Class Initialized
INFO - 2023-04-18 06:38:42 --> Language Class Initialized
INFO - 2023-04-18 06:38:42 --> Loader Class Initialized
INFO - 2023-04-18 06:38:42 --> Controller Class Initialized
DEBUG - 2023-04-18 06:38:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:38:42 --> Database Driver Class Initialized
INFO - 2023-04-18 06:38:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:38:42 --> Database Driver Class Initialized
INFO - 2023-04-18 06:38:42 --> Model "Login_model" initialized
INFO - 2023-04-18 06:38:42 --> Final output sent to browser
DEBUG - 2023-04-18 06:38:42 --> Total execution time: 0.1860
INFO - 2023-04-18 06:38:42 --> Config Class Initialized
INFO - 2023-04-18 06:38:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:38:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:38:42 --> Utf8 Class Initialized
INFO - 2023-04-18 06:38:42 --> URI Class Initialized
INFO - 2023-04-18 06:38:42 --> Router Class Initialized
INFO - 2023-04-18 06:38:42 --> Output Class Initialized
INFO - 2023-04-18 06:38:42 --> Security Class Initialized
DEBUG - 2023-04-18 06:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:38:42 --> Input Class Initialized
INFO - 2023-04-18 06:38:42 --> Language Class Initialized
INFO - 2023-04-18 06:38:42 --> Loader Class Initialized
INFO - 2023-04-18 06:38:42 --> Controller Class Initialized
DEBUG - 2023-04-18 06:38:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:38:42 --> Database Driver Class Initialized
INFO - 2023-04-18 06:38:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:38:42 --> Database Driver Class Initialized
INFO - 2023-04-18 06:38:42 --> Model "Login_model" initialized
INFO - 2023-04-18 06:38:42 --> Final output sent to browser
DEBUG - 2023-04-18 06:38:42 --> Total execution time: 0.1328
INFO - 2023-04-18 06:40:29 --> Config Class Initialized
INFO - 2023-04-18 06:40:29 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:40:29 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:40:29 --> Utf8 Class Initialized
INFO - 2023-04-18 06:40:29 --> URI Class Initialized
INFO - 2023-04-18 06:40:29 --> Router Class Initialized
INFO - 2023-04-18 06:40:29 --> Output Class Initialized
INFO - 2023-04-18 06:40:29 --> Security Class Initialized
DEBUG - 2023-04-18 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:40:29 --> Input Class Initialized
INFO - 2023-04-18 06:40:29 --> Language Class Initialized
INFO - 2023-04-18 06:40:29 --> Loader Class Initialized
INFO - 2023-04-18 06:40:29 --> Controller Class Initialized
DEBUG - 2023-04-18 06:40:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:40:29 --> Database Driver Class Initialized
INFO - 2023-04-18 06:40:29 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:40:29 --> Database Driver Class Initialized
INFO - 2023-04-18 06:40:29 --> Model "Login_model" initialized
INFO - 2023-04-18 06:40:29 --> Final output sent to browser
DEBUG - 2023-04-18 06:40:29 --> Total execution time: 0.2091
INFO - 2023-04-18 06:40:29 --> Config Class Initialized
INFO - 2023-04-18 06:40:29 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:40:29 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:40:29 --> Utf8 Class Initialized
INFO - 2023-04-18 06:40:29 --> URI Class Initialized
INFO - 2023-04-18 06:40:29 --> Router Class Initialized
INFO - 2023-04-18 06:40:29 --> Output Class Initialized
INFO - 2023-04-18 06:40:29 --> Security Class Initialized
DEBUG - 2023-04-18 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:40:29 --> Input Class Initialized
INFO - 2023-04-18 06:40:29 --> Language Class Initialized
INFO - 2023-04-18 06:40:29 --> Loader Class Initialized
INFO - 2023-04-18 06:40:29 --> Controller Class Initialized
DEBUG - 2023-04-18 06:40:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:40:29 --> Database Driver Class Initialized
INFO - 2023-04-18 06:40:29 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:40:29 --> Database Driver Class Initialized
INFO - 2023-04-18 06:40:29 --> Model "Login_model" initialized
INFO - 2023-04-18 06:40:29 --> Final output sent to browser
DEBUG - 2023-04-18 06:40:29 --> Total execution time: 0.1042
INFO - 2023-04-18 06:41:24 --> Config Class Initialized
INFO - 2023-04-18 06:41:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:41:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:41:24 --> Utf8 Class Initialized
INFO - 2023-04-18 06:41:24 --> URI Class Initialized
INFO - 2023-04-18 06:41:24 --> Router Class Initialized
INFO - 2023-04-18 06:41:24 --> Output Class Initialized
INFO - 2023-04-18 06:41:24 --> Security Class Initialized
DEBUG - 2023-04-18 06:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:41:24 --> Input Class Initialized
INFO - 2023-04-18 06:41:24 --> Language Class Initialized
INFO - 2023-04-18 06:41:24 --> Loader Class Initialized
INFO - 2023-04-18 06:41:24 --> Controller Class Initialized
DEBUG - 2023-04-18 06:41:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:41:24 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:41:24 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:24 --> Model "Login_model" initialized
INFO - 2023-04-18 06:41:24 --> Final output sent to browser
DEBUG - 2023-04-18 06:41:24 --> Total execution time: 0.1080
INFO - 2023-04-18 06:41:24 --> Config Class Initialized
INFO - 2023-04-18 06:41:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:41:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:41:24 --> Utf8 Class Initialized
INFO - 2023-04-18 06:41:24 --> URI Class Initialized
INFO - 2023-04-18 06:41:24 --> Router Class Initialized
INFO - 2023-04-18 06:41:24 --> Output Class Initialized
INFO - 2023-04-18 06:41:24 --> Security Class Initialized
DEBUG - 2023-04-18 06:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:41:24 --> Input Class Initialized
INFO - 2023-04-18 06:41:24 --> Language Class Initialized
INFO - 2023-04-18 06:41:24 --> Loader Class Initialized
INFO - 2023-04-18 06:41:24 --> Controller Class Initialized
DEBUG - 2023-04-18 06:41:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:41:24 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:41:24 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:24 --> Model "Login_model" initialized
INFO - 2023-04-18 06:41:24 --> Final output sent to browser
DEBUG - 2023-04-18 06:41:24 --> Total execution time: 0.1134
INFO - 2023-04-18 06:41:31 --> Config Class Initialized
INFO - 2023-04-18 06:41:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:41:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:41:31 --> Utf8 Class Initialized
INFO - 2023-04-18 06:41:31 --> URI Class Initialized
INFO - 2023-04-18 06:41:31 --> Router Class Initialized
INFO - 2023-04-18 06:41:31 --> Output Class Initialized
INFO - 2023-04-18 06:41:31 --> Security Class Initialized
DEBUG - 2023-04-18 06:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:41:31 --> Input Class Initialized
INFO - 2023-04-18 06:41:31 --> Language Class Initialized
INFO - 2023-04-18 06:41:31 --> Loader Class Initialized
INFO - 2023-04-18 06:41:31 --> Controller Class Initialized
DEBUG - 2023-04-18 06:41:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:41:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:41:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:31 --> Model "Login_model" initialized
INFO - 2023-04-18 06:41:32 --> Final output sent to browser
DEBUG - 2023-04-18 06:41:32 --> Total execution time: 0.1721
INFO - 2023-04-18 06:41:32 --> Config Class Initialized
INFO - 2023-04-18 06:41:32 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:41:32 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:41:32 --> Utf8 Class Initialized
INFO - 2023-04-18 06:41:32 --> URI Class Initialized
INFO - 2023-04-18 06:41:32 --> Router Class Initialized
INFO - 2023-04-18 06:41:32 --> Output Class Initialized
INFO - 2023-04-18 06:41:32 --> Security Class Initialized
DEBUG - 2023-04-18 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:41:32 --> Input Class Initialized
INFO - 2023-04-18 06:41:32 --> Language Class Initialized
INFO - 2023-04-18 06:41:32 --> Loader Class Initialized
INFO - 2023-04-18 06:41:32 --> Controller Class Initialized
DEBUG - 2023-04-18 06:41:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:41:32 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:32 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:41:32 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:32 --> Model "Login_model" initialized
INFO - 2023-04-18 06:41:32 --> Final output sent to browser
DEBUG - 2023-04-18 06:41:32 --> Total execution time: 0.0606
INFO - 2023-04-18 06:41:45 --> Config Class Initialized
INFO - 2023-04-18 06:41:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:41:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:41:45 --> Utf8 Class Initialized
INFO - 2023-04-18 06:41:45 --> URI Class Initialized
INFO - 2023-04-18 06:41:45 --> Router Class Initialized
INFO - 2023-04-18 06:41:45 --> Output Class Initialized
INFO - 2023-04-18 06:41:45 --> Security Class Initialized
DEBUG - 2023-04-18 06:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:41:45 --> Input Class Initialized
INFO - 2023-04-18 06:41:45 --> Language Class Initialized
INFO - 2023-04-18 06:41:45 --> Loader Class Initialized
INFO - 2023-04-18 06:41:45 --> Controller Class Initialized
DEBUG - 2023-04-18 06:41:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:41:45 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:41:45 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:45 --> Model "Login_model" initialized
INFO - 2023-04-18 06:41:45 --> Final output sent to browser
DEBUG - 2023-04-18 06:41:45 --> Total execution time: 0.1926
INFO - 2023-04-18 06:41:45 --> Config Class Initialized
INFO - 2023-04-18 06:41:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:41:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:41:45 --> Utf8 Class Initialized
INFO - 2023-04-18 06:41:45 --> URI Class Initialized
INFO - 2023-04-18 06:41:45 --> Router Class Initialized
INFO - 2023-04-18 06:41:45 --> Output Class Initialized
INFO - 2023-04-18 06:41:45 --> Security Class Initialized
DEBUG - 2023-04-18 06:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:41:45 --> Input Class Initialized
INFO - 2023-04-18 06:41:45 --> Language Class Initialized
INFO - 2023-04-18 06:41:45 --> Loader Class Initialized
INFO - 2023-04-18 06:41:45 --> Controller Class Initialized
DEBUG - 2023-04-18 06:41:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:41:45 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:41:45 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:45 --> Model "Login_model" initialized
INFO - 2023-04-18 06:41:45 --> Final output sent to browser
DEBUG - 2023-04-18 06:41:45 --> Total execution time: 0.0607
INFO - 2023-04-18 06:41:53 --> Config Class Initialized
INFO - 2023-04-18 06:41:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:41:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:41:53 --> Utf8 Class Initialized
INFO - 2023-04-18 06:41:53 --> URI Class Initialized
INFO - 2023-04-18 06:41:53 --> Router Class Initialized
INFO - 2023-04-18 06:41:53 --> Output Class Initialized
INFO - 2023-04-18 06:41:53 --> Security Class Initialized
DEBUG - 2023-04-18 06:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:41:53 --> Input Class Initialized
INFO - 2023-04-18 06:41:53 --> Language Class Initialized
INFO - 2023-04-18 06:41:53 --> Loader Class Initialized
INFO - 2023-04-18 06:41:53 --> Controller Class Initialized
DEBUG - 2023-04-18 06:41:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:41:53 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:41:53 --> Final output sent to browser
DEBUG - 2023-04-18 06:41:53 --> Total execution time: 0.0206
INFO - 2023-04-18 06:41:53 --> Config Class Initialized
INFO - 2023-04-18 06:41:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:41:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:41:53 --> Utf8 Class Initialized
INFO - 2023-04-18 06:41:53 --> URI Class Initialized
INFO - 2023-04-18 06:41:53 --> Router Class Initialized
INFO - 2023-04-18 06:41:53 --> Output Class Initialized
INFO - 2023-04-18 06:41:53 --> Security Class Initialized
DEBUG - 2023-04-18 06:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:41:53 --> Input Class Initialized
INFO - 2023-04-18 06:41:53 --> Language Class Initialized
INFO - 2023-04-18 06:41:53 --> Loader Class Initialized
INFO - 2023-04-18 06:41:53 --> Controller Class Initialized
DEBUG - 2023-04-18 06:41:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:41:53 --> Database Driver Class Initialized
INFO - 2023-04-18 06:41:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:41:53 --> Final output sent to browser
DEBUG - 2023-04-18 06:41:53 --> Total execution time: 0.0604
INFO - 2023-04-18 06:42:02 --> Config Class Initialized
INFO - 2023-04-18 06:42:02 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:02 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:02 --> URI Class Initialized
INFO - 2023-04-18 06:42:02 --> Router Class Initialized
INFO - 2023-04-18 06:42:02 --> Output Class Initialized
INFO - 2023-04-18 06:42:02 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:02 --> Input Class Initialized
INFO - 2023-04-18 06:42:02 --> Language Class Initialized
INFO - 2023-04-18 06:42:02 --> Loader Class Initialized
INFO - 2023-04-18 06:42:02 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:02 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:02 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:02 --> Model "Login_model" initialized
INFO - 2023-04-18 06:42:02 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:02 --> Total execution time: 0.1869
INFO - 2023-04-18 06:42:02 --> Config Class Initialized
INFO - 2023-04-18 06:42:02 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:02 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:02 --> URI Class Initialized
INFO - 2023-04-18 06:42:02 --> Router Class Initialized
INFO - 2023-04-18 06:42:02 --> Output Class Initialized
INFO - 2023-04-18 06:42:02 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:02 --> Input Class Initialized
INFO - 2023-04-18 06:42:02 --> Language Class Initialized
INFO - 2023-04-18 06:42:02 --> Loader Class Initialized
INFO - 2023-04-18 06:42:02 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:02 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:02 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:02 --> Model "Login_model" initialized
INFO - 2023-04-18 06:42:02 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:02 --> Total execution time: 0.0595
INFO - 2023-04-18 06:42:09 --> Config Class Initialized
INFO - 2023-04-18 06:42:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:09 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:09 --> URI Class Initialized
INFO - 2023-04-18 06:42:09 --> Router Class Initialized
INFO - 2023-04-18 06:42:09 --> Output Class Initialized
INFO - 2023-04-18 06:42:09 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:09 --> Input Class Initialized
INFO - 2023-04-18 06:42:09 --> Language Class Initialized
INFO - 2023-04-18 06:42:09 --> Loader Class Initialized
INFO - 2023-04-18 06:42:09 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:09 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:09 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:09 --> Total execution time: 0.0215
INFO - 2023-04-18 06:42:09 --> Config Class Initialized
INFO - 2023-04-18 06:42:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:09 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:09 --> URI Class Initialized
INFO - 2023-04-18 06:42:09 --> Router Class Initialized
INFO - 2023-04-18 06:42:09 --> Output Class Initialized
INFO - 2023-04-18 06:42:09 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:09 --> Input Class Initialized
INFO - 2023-04-18 06:42:09 --> Language Class Initialized
INFO - 2023-04-18 06:42:09 --> Loader Class Initialized
INFO - 2023-04-18 06:42:09 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:09 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:09 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:09 --> Total execution time: 0.0202
INFO - 2023-04-18 06:42:46 --> Config Class Initialized
INFO - 2023-04-18 06:42:46 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:46 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:46 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:46 --> URI Class Initialized
INFO - 2023-04-18 06:42:46 --> Router Class Initialized
INFO - 2023-04-18 06:42:46 --> Output Class Initialized
INFO - 2023-04-18 06:42:46 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:46 --> Input Class Initialized
INFO - 2023-04-18 06:42:46 --> Language Class Initialized
INFO - 2023-04-18 06:42:46 --> Loader Class Initialized
INFO - 2023-04-18 06:42:46 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:46 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:46 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:46 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:46 --> Total execution time: 0.0128
INFO - 2023-04-18 06:42:46 --> Config Class Initialized
INFO - 2023-04-18 06:42:46 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:46 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:46 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:46 --> URI Class Initialized
INFO - 2023-04-18 06:42:46 --> Router Class Initialized
INFO - 2023-04-18 06:42:46 --> Output Class Initialized
INFO - 2023-04-18 06:42:46 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:46 --> Input Class Initialized
INFO - 2023-04-18 06:42:46 --> Language Class Initialized
INFO - 2023-04-18 06:42:46 --> Loader Class Initialized
INFO - 2023-04-18 06:42:46 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:46 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:46 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:46 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:46 --> Total execution time: 0.0559
INFO - 2023-04-18 06:42:49 --> Config Class Initialized
INFO - 2023-04-18 06:42:49 --> Config Class Initialized
INFO - 2023-04-18 06:42:49 --> Hooks Class Initialized
INFO - 2023-04-18 06:42:49 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:49 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:49 --> Utf8 Class Initialized
DEBUG - 2023-04-18 06:42:49 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:49 --> URI Class Initialized
INFO - 2023-04-18 06:42:49 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:49 --> Router Class Initialized
INFO - 2023-04-18 06:42:49 --> URI Class Initialized
INFO - 2023-04-18 06:42:49 --> Output Class Initialized
INFO - 2023-04-18 06:42:49 --> Security Class Initialized
INFO - 2023-04-18 06:42:49 --> Router Class Initialized
DEBUG - 2023-04-18 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:49 --> Output Class Initialized
INFO - 2023-04-18 06:42:49 --> Input Class Initialized
INFO - 2023-04-18 06:42:49 --> Security Class Initialized
INFO - 2023-04-18 06:42:49 --> Language Class Initialized
DEBUG - 2023-04-18 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:49 --> Input Class Initialized
INFO - 2023-04-18 06:42:49 --> Loader Class Initialized
INFO - 2023-04-18 06:42:49 --> Language Class Initialized
INFO - 2023-04-18 06:42:49 --> Controller Class Initialized
INFO - 2023-04-18 06:42:49 --> Loader Class Initialized
DEBUG - 2023-04-18 06:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:49 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:49 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:49 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:49 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:49 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:49 --> Final output sent to browser
INFO - 2023-04-18 06:42:49 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:49 --> Total execution time: 0.0153
DEBUG - 2023-04-18 06:42:49 --> Total execution time: 0.0154
INFO - 2023-04-18 06:42:49 --> Config Class Initialized
INFO - 2023-04-18 06:42:49 --> Config Class Initialized
INFO - 2023-04-18 06:42:49 --> Hooks Class Initialized
INFO - 2023-04-18 06:42:49 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:49 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:49 --> Utf8 Class Initialized
DEBUG - 2023-04-18 06:42:49 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:49 --> URI Class Initialized
INFO - 2023-04-18 06:42:49 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:49 --> Router Class Initialized
INFO - 2023-04-18 06:42:49 --> URI Class Initialized
INFO - 2023-04-18 06:42:49 --> Output Class Initialized
INFO - 2023-04-18 06:42:49 --> Router Class Initialized
INFO - 2023-04-18 06:42:49 --> Security Class Initialized
INFO - 2023-04-18 06:42:49 --> Output Class Initialized
DEBUG - 2023-04-18 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:49 --> Security Class Initialized
INFO - 2023-04-18 06:42:49 --> Input Class Initialized
DEBUG - 2023-04-18 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:49 --> Language Class Initialized
INFO - 2023-04-18 06:42:49 --> Input Class Initialized
INFO - 2023-04-18 06:42:49 --> Loader Class Initialized
INFO - 2023-04-18 06:42:49 --> Language Class Initialized
INFO - 2023-04-18 06:42:49 --> Controller Class Initialized
INFO - 2023-04-18 06:42:49 --> Loader Class Initialized
DEBUG - 2023-04-18 06:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:49 --> Controller Class Initialized
INFO - 2023-04-18 06:42:49 --> Database Driver Class Initialized
DEBUG - 2023-04-18 06:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:49 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:49 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:49 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:49 --> Final output sent to browser
INFO - 2023-04-18 06:42:49 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:49 --> Total execution time: 0.0134
DEBUG - 2023-04-18 06:42:49 --> Total execution time: 0.0134
INFO - 2023-04-18 06:42:52 --> Config Class Initialized
INFO - 2023-04-18 06:42:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:52 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:52 --> URI Class Initialized
INFO - 2023-04-18 06:42:52 --> Router Class Initialized
INFO - 2023-04-18 06:42:52 --> Output Class Initialized
INFO - 2023-04-18 06:42:52 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:52 --> Input Class Initialized
INFO - 2023-04-18 06:42:52 --> Language Class Initialized
INFO - 2023-04-18 06:42:52 --> Loader Class Initialized
INFO - 2023-04-18 06:42:52 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:52 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:52 --> Total execution time: 0.0166
INFO - 2023-04-18 06:42:52 --> Config Class Initialized
INFO - 2023-04-18 06:42:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:52 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:52 --> URI Class Initialized
INFO - 2023-04-18 06:42:52 --> Router Class Initialized
INFO - 2023-04-18 06:42:52 --> Output Class Initialized
INFO - 2023-04-18 06:42:52 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:52 --> Input Class Initialized
INFO - 2023-04-18 06:42:52 --> Language Class Initialized
INFO - 2023-04-18 06:42:52 --> Loader Class Initialized
INFO - 2023-04-18 06:42:52 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:52 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:52 --> Total execution time: 0.0534
INFO - 2023-04-18 06:42:59 --> Config Class Initialized
INFO - 2023-04-18 06:42:59 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:59 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:59 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:59 --> URI Class Initialized
INFO - 2023-04-18 06:42:59 --> Router Class Initialized
INFO - 2023-04-18 06:42:59 --> Output Class Initialized
INFO - 2023-04-18 06:42:59 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:59 --> Input Class Initialized
INFO - 2023-04-18 06:42:59 --> Language Class Initialized
INFO - 2023-04-18 06:42:59 --> Loader Class Initialized
INFO - 2023-04-18 06:42:59 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:59 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:59 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:59 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:59 --> Total execution time: 0.0228
INFO - 2023-04-18 06:42:59 --> Config Class Initialized
INFO - 2023-04-18 06:42:59 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:42:59 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:42:59 --> Utf8 Class Initialized
INFO - 2023-04-18 06:42:59 --> URI Class Initialized
INFO - 2023-04-18 06:42:59 --> Router Class Initialized
INFO - 2023-04-18 06:42:59 --> Output Class Initialized
INFO - 2023-04-18 06:42:59 --> Security Class Initialized
DEBUG - 2023-04-18 06:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:42:59 --> Input Class Initialized
INFO - 2023-04-18 06:42:59 --> Language Class Initialized
INFO - 2023-04-18 06:42:59 --> Loader Class Initialized
INFO - 2023-04-18 06:42:59 --> Controller Class Initialized
DEBUG - 2023-04-18 06:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:42:59 --> Database Driver Class Initialized
INFO - 2023-04-18 06:42:59 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:42:59 --> Final output sent to browser
DEBUG - 2023-04-18 06:42:59 --> Total execution time: 0.0207
INFO - 2023-04-18 06:43:03 --> Config Class Initialized
INFO - 2023-04-18 06:43:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:03 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:03 --> URI Class Initialized
INFO - 2023-04-18 06:43:03 --> Router Class Initialized
INFO - 2023-04-18 06:43:03 --> Output Class Initialized
INFO - 2023-04-18 06:43:03 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:03 --> Input Class Initialized
INFO - 2023-04-18 06:43:03 --> Language Class Initialized
INFO - 2023-04-18 06:43:03 --> Loader Class Initialized
INFO - 2023-04-18 06:43:03 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:03 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:03 --> Total execution time: 0.0058
INFO - 2023-04-18 06:43:03 --> Config Class Initialized
INFO - 2023-04-18 06:43:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:03 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:03 --> URI Class Initialized
INFO - 2023-04-18 06:43:03 --> Router Class Initialized
INFO - 2023-04-18 06:43:03 --> Output Class Initialized
INFO - 2023-04-18 06:43:03 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:03 --> Input Class Initialized
INFO - 2023-04-18 06:43:03 --> Language Class Initialized
INFO - 2023-04-18 06:43:03 --> Loader Class Initialized
INFO - 2023-04-18 06:43:03 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:03 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:03 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:43:03 --> Model "Mysql_model" initialized
INFO - 2023-04-18 06:43:03 --> Model "Grafana_model" initialized
INFO - 2023-04-18 06:43:03 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:03 --> Total execution time: 0.0171
INFO - 2023-04-18 06:43:04 --> Config Class Initialized
INFO - 2023-04-18 06:43:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:04 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:04 --> URI Class Initialized
INFO - 2023-04-18 06:43:04 --> Router Class Initialized
INFO - 2023-04-18 06:43:04 --> Output Class Initialized
INFO - 2023-04-18 06:43:04 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:04 --> Input Class Initialized
INFO - 2023-04-18 06:43:04 --> Language Class Initialized
INFO - 2023-04-18 06:43:04 --> Loader Class Initialized
INFO - 2023-04-18 06:43:04 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:04 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:04 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:43:04 --> Model "Mysql_model" initialized
INFO - 2023-04-18 06:43:04 --> Model "Grafana_model" initialized
INFO - 2023-04-18 06:43:04 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:04 --> Total execution time: 0.0195
INFO - 2023-04-18 06:43:07 --> Config Class Initialized
INFO - 2023-04-18 06:43:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:07 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:07 --> URI Class Initialized
INFO - 2023-04-18 06:43:07 --> Router Class Initialized
INFO - 2023-04-18 06:43:07 --> Output Class Initialized
INFO - 2023-04-18 06:43:07 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:07 --> Input Class Initialized
INFO - 2023-04-18 06:43:07 --> Language Class Initialized
INFO - 2023-04-18 06:43:07 --> Loader Class Initialized
INFO - 2023-04-18 06:43:07 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:07 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:43:07 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:07 --> Total execution time: 0.0150
INFO - 2023-04-18 06:43:07 --> Config Class Initialized
INFO - 2023-04-18 06:43:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:07 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:07 --> URI Class Initialized
INFO - 2023-04-18 06:43:07 --> Router Class Initialized
INFO - 2023-04-18 06:43:07 --> Output Class Initialized
INFO - 2023-04-18 06:43:07 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:07 --> Input Class Initialized
INFO - 2023-04-18 06:43:07 --> Language Class Initialized
INFO - 2023-04-18 06:43:07 --> Loader Class Initialized
INFO - 2023-04-18 06:43:07 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:07 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:43:07 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:07 --> Total execution time: 0.0559
INFO - 2023-04-18 06:43:09 --> Config Class Initialized
INFO - 2023-04-18 06:43:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:09 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:09 --> URI Class Initialized
INFO - 2023-04-18 06:43:09 --> Router Class Initialized
INFO - 2023-04-18 06:43:09 --> Output Class Initialized
INFO - 2023-04-18 06:43:09 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:09 --> Input Class Initialized
INFO - 2023-04-18 06:43:09 --> Language Class Initialized
INFO - 2023-04-18 06:43:09 --> Loader Class Initialized
INFO - 2023-04-18 06:43:09 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:09 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:43:09 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:09 --> Total execution time: 0.0483
INFO - 2023-04-18 06:43:09 --> Config Class Initialized
INFO - 2023-04-18 06:43:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:09 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:09 --> URI Class Initialized
INFO - 2023-04-18 06:43:09 --> Router Class Initialized
INFO - 2023-04-18 06:43:09 --> Output Class Initialized
INFO - 2023-04-18 06:43:09 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:09 --> Input Class Initialized
INFO - 2023-04-18 06:43:09 --> Language Class Initialized
INFO - 2023-04-18 06:43:09 --> Loader Class Initialized
INFO - 2023-04-18 06:43:09 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:09 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:43:09 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:09 --> Total execution time: 0.0834
INFO - 2023-04-18 06:43:15 --> Config Class Initialized
INFO - 2023-04-18 06:43:15 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:15 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:15 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:15 --> URI Class Initialized
INFO - 2023-04-18 06:43:15 --> Router Class Initialized
INFO - 2023-04-18 06:43:15 --> Output Class Initialized
INFO - 2023-04-18 06:43:15 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:15 --> Input Class Initialized
INFO - 2023-04-18 06:43:15 --> Language Class Initialized
INFO - 2023-04-18 06:43:15 --> Loader Class Initialized
INFO - 2023-04-18 06:43:15 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:15 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:43:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:15 --> Model "Login_model" initialized
INFO - 2023-04-18 06:43:15 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:15 --> Total execution time: 0.0952
INFO - 2023-04-18 06:43:15 --> Config Class Initialized
INFO - 2023-04-18 06:43:15 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:43:15 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:43:15 --> Utf8 Class Initialized
INFO - 2023-04-18 06:43:15 --> URI Class Initialized
INFO - 2023-04-18 06:43:15 --> Router Class Initialized
INFO - 2023-04-18 06:43:15 --> Output Class Initialized
INFO - 2023-04-18 06:43:15 --> Security Class Initialized
DEBUG - 2023-04-18 06:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:43:15 --> Input Class Initialized
INFO - 2023-04-18 06:43:15 --> Language Class Initialized
INFO - 2023-04-18 06:43:15 --> Loader Class Initialized
INFO - 2023-04-18 06:43:15 --> Controller Class Initialized
DEBUG - 2023-04-18 06:43:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:43:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:15 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:43:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:43:15 --> Model "Login_model" initialized
INFO - 2023-04-18 06:43:15 --> Final output sent to browser
DEBUG - 2023-04-18 06:43:15 --> Total execution time: 0.0603
INFO - 2023-04-18 06:44:21 --> Config Class Initialized
INFO - 2023-04-18 06:44:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:21 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:21 --> URI Class Initialized
INFO - 2023-04-18 06:44:21 --> Router Class Initialized
INFO - 2023-04-18 06:44:21 --> Output Class Initialized
INFO - 2023-04-18 06:44:21 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:21 --> Input Class Initialized
INFO - 2023-04-18 06:44:21 --> Language Class Initialized
INFO - 2023-04-18 06:44:21 --> Loader Class Initialized
INFO - 2023-04-18 06:44:21 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:21 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:21 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:21 --> Total execution time: 0.0154
INFO - 2023-04-18 06:44:21 --> Config Class Initialized
INFO - 2023-04-18 06:44:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:21 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:21 --> URI Class Initialized
INFO - 2023-04-18 06:44:21 --> Router Class Initialized
INFO - 2023-04-18 06:44:21 --> Output Class Initialized
INFO - 2023-04-18 06:44:21 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:21 --> Input Class Initialized
INFO - 2023-04-18 06:44:21 --> Language Class Initialized
INFO - 2023-04-18 06:44:21 --> Loader Class Initialized
INFO - 2023-04-18 06:44:21 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:21 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:21 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:21 --> Total execution time: 0.0121
INFO - 2023-04-18 06:44:24 --> Config Class Initialized
INFO - 2023-04-18 06:44:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:24 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:24 --> URI Class Initialized
INFO - 2023-04-18 06:44:24 --> Router Class Initialized
INFO - 2023-04-18 06:44:24 --> Output Class Initialized
INFO - 2023-04-18 06:44:24 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:24 --> Input Class Initialized
INFO - 2023-04-18 06:44:24 --> Language Class Initialized
INFO - 2023-04-18 06:44:24 --> Loader Class Initialized
INFO - 2023-04-18 06:44:24 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:24 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:24 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:24 --> Total execution time: 0.0611
INFO - 2023-04-18 06:44:24 --> Config Class Initialized
INFO - 2023-04-18 06:44:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:24 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:24 --> URI Class Initialized
INFO - 2023-04-18 06:44:24 --> Router Class Initialized
INFO - 2023-04-18 06:44:24 --> Output Class Initialized
INFO - 2023-04-18 06:44:24 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:24 --> Input Class Initialized
INFO - 2023-04-18 06:44:24 --> Language Class Initialized
INFO - 2023-04-18 06:44:24 --> Loader Class Initialized
INFO - 2023-04-18 06:44:24 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:24 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:24 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:24 --> Total execution time: 0.0414
INFO - 2023-04-18 06:44:31 --> Config Class Initialized
INFO - 2023-04-18 06:44:31 --> Config Class Initialized
INFO - 2023-04-18 06:44:31 --> Hooks Class Initialized
INFO - 2023-04-18 06:44:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:31 --> Utf8 Class Initialized
DEBUG - 2023-04-18 06:44:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:31 --> URI Class Initialized
INFO - 2023-04-18 06:44:31 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:31 --> Router Class Initialized
INFO - 2023-04-18 06:44:31 --> URI Class Initialized
INFO - 2023-04-18 06:44:31 --> Output Class Initialized
INFO - 2023-04-18 06:44:31 --> Router Class Initialized
INFO - 2023-04-18 06:44:31 --> Security Class Initialized
INFO - 2023-04-18 06:44:31 --> Output Class Initialized
DEBUG - 2023-04-18 06:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:31 --> Security Class Initialized
INFO - 2023-04-18 06:44:31 --> Input Class Initialized
DEBUG - 2023-04-18 06:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:31 --> Language Class Initialized
INFO - 2023-04-18 06:44:31 --> Input Class Initialized
INFO - 2023-04-18 06:44:31 --> Language Class Initialized
INFO - 2023-04-18 06:44:31 --> Loader Class Initialized
INFO - 2023-04-18 06:44:31 --> Loader Class Initialized
INFO - 2023-04-18 06:44:31 --> Controller Class Initialized
INFO - 2023-04-18 06:44:31 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 06:44:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:31 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:31 --> Total execution time: 0.0043
INFO - 2023-04-18 06:44:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:31 --> Config Class Initialized
INFO - 2023-04-18 06:44:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:31 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:31 --> URI Class Initialized
INFO - 2023-04-18 06:44:31 --> Router Class Initialized
INFO - 2023-04-18 06:44:31 --> Output Class Initialized
INFO - 2023-04-18 06:44:31 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:31 --> Input Class Initialized
INFO - 2023-04-18 06:44:31 --> Language Class Initialized
INFO - 2023-04-18 06:44:31 --> Loader Class Initialized
INFO - 2023-04-18 06:44:31 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:31 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:31 --> Total execution time: 0.0495
INFO - 2023-04-18 06:44:31 --> Config Class Initialized
INFO - 2023-04-18 06:44:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:31 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:31 --> URI Class Initialized
INFO - 2023-04-18 06:44:31 --> Router Class Initialized
INFO - 2023-04-18 06:44:31 --> Output Class Initialized
INFO - 2023-04-18 06:44:31 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:31 --> Input Class Initialized
INFO - 2023-04-18 06:44:31 --> Language Class Initialized
INFO - 2023-04-18 06:44:31 --> Loader Class Initialized
INFO - 2023-04-18 06:44:31 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:31 --> Model "Login_model" initialized
INFO - 2023-04-18 06:44:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:31 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:31 --> Total execution time: 0.0148
INFO - 2023-04-18 06:44:31 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:31 --> Total execution time: 0.0621
INFO - 2023-04-18 06:44:32 --> Config Class Initialized
INFO - 2023-04-18 06:44:32 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:32 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:32 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:32 --> URI Class Initialized
INFO - 2023-04-18 06:44:32 --> Router Class Initialized
INFO - 2023-04-18 06:44:32 --> Output Class Initialized
INFO - 2023-04-18 06:44:32 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:32 --> Input Class Initialized
INFO - 2023-04-18 06:44:32 --> Language Class Initialized
INFO - 2023-04-18 06:44:32 --> Loader Class Initialized
INFO - 2023-04-18 06:44:32 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:32 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:32 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:32 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:32 --> Model "Login_model" initialized
INFO - 2023-04-18 06:44:32 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:32 --> Total execution time: 0.0806
INFO - 2023-04-18 06:44:32 --> Config Class Initialized
INFO - 2023-04-18 06:44:32 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:32 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:32 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:32 --> URI Class Initialized
INFO - 2023-04-18 06:44:32 --> Router Class Initialized
INFO - 2023-04-18 06:44:32 --> Output Class Initialized
INFO - 2023-04-18 06:44:32 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:32 --> Input Class Initialized
INFO - 2023-04-18 06:44:32 --> Language Class Initialized
INFO - 2023-04-18 06:44:32 --> Loader Class Initialized
INFO - 2023-04-18 06:44:32 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:32 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:32 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:32 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:32 --> Model "Login_model" initialized
INFO - 2023-04-18 06:44:32 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:32 --> Total execution time: 0.0643
INFO - 2023-04-18 06:44:52 --> Config Class Initialized
INFO - 2023-04-18 06:44:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:52 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:52 --> URI Class Initialized
INFO - 2023-04-18 06:44:52 --> Router Class Initialized
INFO - 2023-04-18 06:44:52 --> Output Class Initialized
INFO - 2023-04-18 06:44:52 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:52 --> Input Class Initialized
INFO - 2023-04-18 06:44:52 --> Language Class Initialized
INFO - 2023-04-18 06:44:52 --> Loader Class Initialized
INFO - 2023-04-18 06:44:52 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:52 --> Model "Login_model" initialized
INFO - 2023-04-18 06:44:52 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:52 --> Total execution time: 0.0679
INFO - 2023-04-18 06:44:52 --> Config Class Initialized
INFO - 2023-04-18 06:44:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:44:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:44:52 --> Utf8 Class Initialized
INFO - 2023-04-18 06:44:52 --> URI Class Initialized
INFO - 2023-04-18 06:44:52 --> Router Class Initialized
INFO - 2023-04-18 06:44:52 --> Output Class Initialized
INFO - 2023-04-18 06:44:52 --> Security Class Initialized
DEBUG - 2023-04-18 06:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:44:52 --> Input Class Initialized
INFO - 2023-04-18 06:44:52 --> Language Class Initialized
INFO - 2023-04-18 06:44:52 --> Loader Class Initialized
INFO - 2023-04-18 06:44:52 --> Controller Class Initialized
DEBUG - 2023-04-18 06:44:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:44:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:44:52 --> Database Driver Class Initialized
INFO - 2023-04-18 06:44:52 --> Model "Login_model" initialized
INFO - 2023-04-18 06:44:52 --> Final output sent to browser
DEBUG - 2023-04-18 06:44:52 --> Total execution time: 0.1136
INFO - 2023-04-18 06:46:08 --> Config Class Initialized
INFO - 2023-04-18 06:46:08 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:08 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:08 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:08 --> URI Class Initialized
INFO - 2023-04-18 06:46:08 --> Router Class Initialized
INFO - 2023-04-18 06:46:08 --> Output Class Initialized
INFO - 2023-04-18 06:46:08 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:08 --> Input Class Initialized
INFO - 2023-04-18 06:46:08 --> Language Class Initialized
INFO - 2023-04-18 06:46:08 --> Loader Class Initialized
INFO - 2023-04-18 06:46:08 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:08 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:08 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:08 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:08 --> Total execution time: 0.0206
INFO - 2023-04-18 06:46:08 --> Config Class Initialized
INFO - 2023-04-18 06:46:08 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:08 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:08 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:08 --> URI Class Initialized
INFO - 2023-04-18 06:46:08 --> Router Class Initialized
INFO - 2023-04-18 06:46:08 --> Output Class Initialized
INFO - 2023-04-18 06:46:08 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:08 --> Input Class Initialized
INFO - 2023-04-18 06:46:08 --> Language Class Initialized
INFO - 2023-04-18 06:46:08 --> Loader Class Initialized
INFO - 2023-04-18 06:46:08 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:08 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:08 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:08 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:08 --> Total execution time: 0.0513
INFO - 2023-04-18 06:46:12 --> Config Class Initialized
INFO - 2023-04-18 06:46:12 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:12 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:12 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:12 --> URI Class Initialized
INFO - 2023-04-18 06:46:12 --> Router Class Initialized
INFO - 2023-04-18 06:46:12 --> Output Class Initialized
INFO - 2023-04-18 06:46:12 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:12 --> Input Class Initialized
INFO - 2023-04-18 06:46:12 --> Language Class Initialized
INFO - 2023-04-18 06:46:12 --> Loader Class Initialized
INFO - 2023-04-18 06:46:12 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:12 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:12 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:12 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:12 --> Total execution time: 0.0438
INFO - 2023-04-18 06:46:12 --> Config Class Initialized
INFO - 2023-04-18 06:46:12 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:12 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:12 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:12 --> URI Class Initialized
INFO - 2023-04-18 06:46:12 --> Router Class Initialized
INFO - 2023-04-18 06:46:12 --> Output Class Initialized
INFO - 2023-04-18 06:46:12 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:12 --> Input Class Initialized
INFO - 2023-04-18 06:46:12 --> Language Class Initialized
INFO - 2023-04-18 06:46:12 --> Loader Class Initialized
INFO - 2023-04-18 06:46:12 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:12 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:12 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:12 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:12 --> Total execution time: 0.0393
INFO - 2023-04-18 06:46:13 --> Config Class Initialized
INFO - 2023-04-18 06:46:13 --> Hooks Class Initialized
INFO - 2023-04-18 06:46:13 --> Config Class Initialized
DEBUG - 2023-04-18 06:46:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:13 --> Hooks Class Initialized
INFO - 2023-04-18 06:46:13 --> Utf8 Class Initialized
DEBUG - 2023-04-18 06:46:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:13 --> URI Class Initialized
INFO - 2023-04-18 06:46:13 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:13 --> Router Class Initialized
INFO - 2023-04-18 06:46:13 --> URI Class Initialized
INFO - 2023-04-18 06:46:13 --> Output Class Initialized
INFO - 2023-04-18 06:46:13 --> Security Class Initialized
INFO - 2023-04-18 06:46:13 --> Router Class Initialized
DEBUG - 2023-04-18 06:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:13 --> Output Class Initialized
INFO - 2023-04-18 06:46:13 --> Input Class Initialized
INFO - 2023-04-18 06:46:13 --> Security Class Initialized
INFO - 2023-04-18 06:46:13 --> Language Class Initialized
DEBUG - 2023-04-18 06:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:13 --> Loader Class Initialized
INFO - 2023-04-18 06:46:13 --> Input Class Initialized
INFO - 2023-04-18 06:46:13 --> Controller Class Initialized
INFO - 2023-04-18 06:46:13 --> Language Class Initialized
DEBUG - 2023-04-18 06:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:13 --> Loader Class Initialized
INFO - 2023-04-18 06:46:13 --> Controller Class Initialized
INFO - 2023-04-18 06:46:13 --> Database Driver Class Initialized
DEBUG - 2023-04-18 06:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:13 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:13 --> Total execution time: 0.0044
INFO - 2023-04-18 06:46:13 --> Config Class Initialized
INFO - 2023-04-18 06:46:13 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:13 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:13 --> URI Class Initialized
INFO - 2023-04-18 06:46:13 --> Router Class Initialized
INFO - 2023-04-18 06:46:13 --> Output Class Initialized
INFO - 2023-04-18 06:46:13 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:13 --> Input Class Initialized
INFO - 2023-04-18 06:46:13 --> Language Class Initialized
INFO - 2023-04-18 06:46:13 --> Loader Class Initialized
INFO - 2023-04-18 06:46:13 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:13 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:13 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:13 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:13 --> Total execution time: 0.0152
INFO - 2023-04-18 06:46:13 --> Model "Login_model" initialized
INFO - 2023-04-18 06:46:13 --> Config Class Initialized
INFO - 2023-04-18 06:46:13 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:13 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:13 --> URI Class Initialized
INFO - 2023-04-18 06:46:13 --> Router Class Initialized
INFO - 2023-04-18 06:46:13 --> Output Class Initialized
INFO - 2023-04-18 06:46:13 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:13 --> Input Class Initialized
INFO - 2023-04-18 06:46:13 --> Language Class Initialized
INFO - 2023-04-18 06:46:13 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:13 --> Loader Class Initialized
INFO - 2023-04-18 06:46:13 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:13 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:13 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:13 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:13 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:13 --> Total execution time: 0.0204
INFO - 2023-04-18 06:46:13 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:13 --> Total execution time: 0.0126
INFO - 2023-04-18 06:46:15 --> Config Class Initialized
INFO - 2023-04-18 06:46:15 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:15 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:15 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:15 --> URI Class Initialized
INFO - 2023-04-18 06:46:15 --> Router Class Initialized
INFO - 2023-04-18 06:46:15 --> Output Class Initialized
INFO - 2023-04-18 06:46:15 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:15 --> Input Class Initialized
INFO - 2023-04-18 06:46:15 --> Language Class Initialized
INFO - 2023-04-18 06:46:15 --> Loader Class Initialized
INFO - 2023-04-18 06:46:15 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:15 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:15 --> Model "Login_model" initialized
INFO - 2023-04-18 06:46:15 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:15 --> Total execution time: 0.0825
INFO - 2023-04-18 06:46:15 --> Config Class Initialized
INFO - 2023-04-18 06:46:15 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:15 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:15 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:15 --> URI Class Initialized
INFO - 2023-04-18 06:46:15 --> Router Class Initialized
INFO - 2023-04-18 06:46:15 --> Output Class Initialized
INFO - 2023-04-18 06:46:15 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:15 --> Input Class Initialized
INFO - 2023-04-18 06:46:15 --> Language Class Initialized
INFO - 2023-04-18 06:46:15 --> Loader Class Initialized
INFO - 2023-04-18 06:46:15 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:15 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:15 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:15 --> Model "Login_model" initialized
INFO - 2023-04-18 06:46:15 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:15 --> Total execution time: 0.0654
INFO - 2023-04-18 06:46:45 --> Config Class Initialized
INFO - 2023-04-18 06:46:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:45 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:45 --> URI Class Initialized
INFO - 2023-04-18 06:46:45 --> Router Class Initialized
INFO - 2023-04-18 06:46:45 --> Output Class Initialized
INFO - 2023-04-18 06:46:45 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:45 --> Input Class Initialized
INFO - 2023-04-18 06:46:45 --> Language Class Initialized
INFO - 2023-04-18 06:46:45 --> Loader Class Initialized
INFO - 2023-04-18 06:46:45 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:45 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:45 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:45 --> Total execution time: 0.0246
INFO - 2023-04-18 06:46:45 --> Config Class Initialized
INFO - 2023-04-18 06:46:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:45 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:45 --> URI Class Initialized
INFO - 2023-04-18 06:46:45 --> Router Class Initialized
INFO - 2023-04-18 06:46:45 --> Output Class Initialized
INFO - 2023-04-18 06:46:45 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:45 --> Input Class Initialized
INFO - 2023-04-18 06:46:45 --> Language Class Initialized
INFO - 2023-04-18 06:46:45 --> Loader Class Initialized
INFO - 2023-04-18 06:46:45 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:45 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:45 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:45 --> Total execution time: 0.0180
INFO - 2023-04-18 06:46:56 --> Config Class Initialized
INFO - 2023-04-18 06:46:56 --> Config Class Initialized
INFO - 2023-04-18 06:46:56 --> Hooks Class Initialized
INFO - 2023-04-18 06:46:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:56 --> Utf8 Class Initialized
DEBUG - 2023-04-18 06:46:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:56 --> URI Class Initialized
INFO - 2023-04-18 06:46:56 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:56 --> Router Class Initialized
INFO - 2023-04-18 06:46:56 --> URI Class Initialized
INFO - 2023-04-18 06:46:56 --> Output Class Initialized
INFO - 2023-04-18 06:46:56 --> Router Class Initialized
INFO - 2023-04-18 06:46:56 --> Security Class Initialized
INFO - 2023-04-18 06:46:56 --> Output Class Initialized
DEBUG - 2023-04-18 06:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:56 --> Security Class Initialized
INFO - 2023-04-18 06:46:56 --> Input Class Initialized
DEBUG - 2023-04-18 06:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:56 --> Language Class Initialized
INFO - 2023-04-18 06:46:56 --> Input Class Initialized
INFO - 2023-04-18 06:46:56 --> Language Class Initialized
INFO - 2023-04-18 06:46:56 --> Loader Class Initialized
INFO - 2023-04-18 06:46:56 --> Loader Class Initialized
INFO - 2023-04-18 06:46:56 --> Controller Class Initialized
INFO - 2023-04-18 06:46:56 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 06:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:56 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:56 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:56 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:56 --> Total execution time: 0.0172
INFO - 2023-04-18 06:46:56 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:56 --> Total execution time: 0.0175
INFO - 2023-04-18 06:46:56 --> Config Class Initialized
INFO - 2023-04-18 06:46:56 --> Config Class Initialized
INFO - 2023-04-18 06:46:56 --> Hooks Class Initialized
INFO - 2023-04-18 06:46:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 06:46:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:46:56 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:56 --> Utf8 Class Initialized
INFO - 2023-04-18 06:46:56 --> URI Class Initialized
INFO - 2023-04-18 06:46:56 --> URI Class Initialized
INFO - 2023-04-18 06:46:56 --> Router Class Initialized
INFO - 2023-04-18 06:46:56 --> Router Class Initialized
INFO - 2023-04-18 06:46:56 --> Output Class Initialized
INFO - 2023-04-18 06:46:56 --> Output Class Initialized
INFO - 2023-04-18 06:46:56 --> Security Class Initialized
DEBUG - 2023-04-18 06:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:56 --> Security Class Initialized
INFO - 2023-04-18 06:46:56 --> Input Class Initialized
DEBUG - 2023-04-18 06:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:46:56 --> Language Class Initialized
INFO - 2023-04-18 06:46:56 --> Input Class Initialized
INFO - 2023-04-18 06:46:56 --> Language Class Initialized
INFO - 2023-04-18 06:46:56 --> Loader Class Initialized
INFO - 2023-04-18 06:46:56 --> Loader Class Initialized
INFO - 2023-04-18 06:46:56 --> Controller Class Initialized
INFO - 2023-04-18 06:46:56 --> Controller Class Initialized
DEBUG - 2023-04-18 06:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 06:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:46:56 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:56 --> Database Driver Class Initialized
INFO - 2023-04-18 06:46:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:46:56 --> Final output sent to browser
INFO - 2023-04-18 06:46:56 --> Final output sent to browser
DEBUG - 2023-04-18 06:46:56 --> Total execution time: 0.0135
DEBUG - 2023-04-18 06:46:56 --> Total execution time: 0.0135
INFO - 2023-04-18 06:47:05 --> Config Class Initialized
INFO - 2023-04-18 06:47:05 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:05 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:05 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:05 --> URI Class Initialized
INFO - 2023-04-18 06:47:05 --> Router Class Initialized
INFO - 2023-04-18 06:47:05 --> Output Class Initialized
INFO - 2023-04-18 06:47:05 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:05 --> Input Class Initialized
INFO - 2023-04-18 06:47:05 --> Language Class Initialized
INFO - 2023-04-18 06:47:05 --> Loader Class Initialized
INFO - 2023-04-18 06:47:05 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:05 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:05 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:05 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:05 --> Total execution time: 0.0212
INFO - 2023-04-18 06:47:05 --> Config Class Initialized
INFO - 2023-04-18 06:47:05 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:05 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:05 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:05 --> URI Class Initialized
INFO - 2023-04-18 06:47:05 --> Router Class Initialized
INFO - 2023-04-18 06:47:05 --> Output Class Initialized
INFO - 2023-04-18 06:47:05 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:05 --> Input Class Initialized
INFO - 2023-04-18 06:47:05 --> Language Class Initialized
INFO - 2023-04-18 06:47:05 --> Loader Class Initialized
INFO - 2023-04-18 06:47:05 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:05 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:05 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:05 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:05 --> Total execution time: 0.0143
INFO - 2023-04-18 06:47:11 --> Config Class Initialized
INFO - 2023-04-18 06:47:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:11 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:11 --> URI Class Initialized
INFO - 2023-04-18 06:47:11 --> Router Class Initialized
INFO - 2023-04-18 06:47:11 --> Output Class Initialized
INFO - 2023-04-18 06:47:11 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:11 --> Input Class Initialized
INFO - 2023-04-18 06:47:11 --> Language Class Initialized
INFO - 2023-04-18 06:47:11 --> Loader Class Initialized
INFO - 2023-04-18 06:47:11 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:11 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:11 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:11 --> Total execution time: 0.0112
INFO - 2023-04-18 06:47:11 --> Config Class Initialized
INFO - 2023-04-18 06:47:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:11 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:11 --> URI Class Initialized
INFO - 2023-04-18 06:47:11 --> Router Class Initialized
INFO - 2023-04-18 06:47:11 --> Output Class Initialized
INFO - 2023-04-18 06:47:11 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:11 --> Input Class Initialized
INFO - 2023-04-18 06:47:11 --> Language Class Initialized
INFO - 2023-04-18 06:47:11 --> Loader Class Initialized
INFO - 2023-04-18 06:47:11 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:11 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:11 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:11 --> Total execution time: 0.0143
INFO - 2023-04-18 06:47:14 --> Config Class Initialized
INFO - 2023-04-18 06:47:14 --> Config Class Initialized
INFO - 2023-04-18 06:47:14 --> Hooks Class Initialized
INFO - 2023-04-18 06:47:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:14 --> Utf8 Class Initialized
DEBUG - 2023-04-18 06:47:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:14 --> URI Class Initialized
INFO - 2023-04-18 06:47:14 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:14 --> URI Class Initialized
INFO - 2023-04-18 06:47:14 --> Router Class Initialized
INFO - 2023-04-18 06:47:14 --> Router Class Initialized
INFO - 2023-04-18 06:47:14 --> Output Class Initialized
INFO - 2023-04-18 06:47:14 --> Output Class Initialized
INFO - 2023-04-18 06:47:14 --> Security Class Initialized
INFO - 2023-04-18 06:47:14 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 06:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:14 --> Input Class Initialized
INFO - 2023-04-18 06:47:14 --> Input Class Initialized
INFO - 2023-04-18 06:47:14 --> Language Class Initialized
INFO - 2023-04-18 06:47:14 --> Language Class Initialized
INFO - 2023-04-18 06:47:14 --> Loader Class Initialized
INFO - 2023-04-18 06:47:14 --> Loader Class Initialized
INFO - 2023-04-18 06:47:14 --> Controller Class Initialized
INFO - 2023-04-18 06:47:14 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 06:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:14 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:14 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:14 --> Final output sent to browser
INFO - 2023-04-18 06:47:14 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:14 --> Total execution time: 0.0166
DEBUG - 2023-04-18 06:47:14 --> Total execution time: 0.0166
INFO - 2023-04-18 06:47:14 --> Config Class Initialized
INFO - 2023-04-18 06:47:14 --> Config Class Initialized
INFO - 2023-04-18 06:47:14 --> Hooks Class Initialized
INFO - 2023-04-18 06:47:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:14 --> Utf8 Class Initialized
DEBUG - 2023-04-18 06:47:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:14 --> URI Class Initialized
INFO - 2023-04-18 06:47:14 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:14 --> Router Class Initialized
INFO - 2023-04-18 06:47:14 --> URI Class Initialized
INFO - 2023-04-18 06:47:14 --> Output Class Initialized
INFO - 2023-04-18 06:47:14 --> Security Class Initialized
INFO - 2023-04-18 06:47:14 --> Router Class Initialized
DEBUG - 2023-04-18 06:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:14 --> Output Class Initialized
INFO - 2023-04-18 06:47:14 --> Input Class Initialized
INFO - 2023-04-18 06:47:14 --> Security Class Initialized
INFO - 2023-04-18 06:47:14 --> Language Class Initialized
DEBUG - 2023-04-18 06:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:14 --> Input Class Initialized
INFO - 2023-04-18 06:47:14 --> Loader Class Initialized
INFO - 2023-04-18 06:47:14 --> Language Class Initialized
INFO - 2023-04-18 06:47:14 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:14 --> Loader Class Initialized
INFO - 2023-04-18 06:47:14 --> Controller Class Initialized
INFO - 2023-04-18 06:47:14 --> Database Driver Class Initialized
DEBUG - 2023-04-18 06:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:14 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:14 --> Final output sent to browser
INFO - 2023-04-18 06:47:14 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:14 --> Total execution time: 0.0643
DEBUG - 2023-04-18 06:47:14 --> Total execution time: 0.0651
INFO - 2023-04-18 06:47:19 --> Config Class Initialized
INFO - 2023-04-18 06:47:19 --> Config Class Initialized
INFO - 2023-04-18 06:47:19 --> Hooks Class Initialized
INFO - 2023-04-18 06:47:19 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:19 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:19 --> Utf8 Class Initialized
DEBUG - 2023-04-18 06:47:19 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:19 --> URI Class Initialized
INFO - 2023-04-18 06:47:19 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:19 --> Router Class Initialized
INFO - 2023-04-18 06:47:19 --> URI Class Initialized
INFO - 2023-04-18 06:47:19 --> Output Class Initialized
INFO - 2023-04-18 06:47:19 --> Router Class Initialized
INFO - 2023-04-18 06:47:19 --> Security Class Initialized
INFO - 2023-04-18 06:47:19 --> Output Class Initialized
DEBUG - 2023-04-18 06:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:19 --> Security Class Initialized
INFO - 2023-04-18 06:47:19 --> Input Class Initialized
DEBUG - 2023-04-18 06:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:19 --> Language Class Initialized
INFO - 2023-04-18 06:47:19 --> Input Class Initialized
INFO - 2023-04-18 06:47:19 --> Language Class Initialized
INFO - 2023-04-18 06:47:19 --> Loader Class Initialized
INFO - 2023-04-18 06:47:19 --> Loader Class Initialized
INFO - 2023-04-18 06:47:19 --> Controller Class Initialized
INFO - 2023-04-18 06:47:19 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 06:47:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:19 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:19 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:19 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:19 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:19 --> Final output sent to browser
INFO - 2023-04-18 06:47:19 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:19 --> Total execution time: 0.0585
DEBUG - 2023-04-18 06:47:19 --> Total execution time: 0.0585
INFO - 2023-04-18 06:47:19 --> Config Class Initialized
INFO - 2023-04-18 06:47:19 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:19 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:19 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:19 --> URI Class Initialized
INFO - 2023-04-18 06:47:19 --> Router Class Initialized
INFO - 2023-04-18 06:47:19 --> Output Class Initialized
INFO - 2023-04-18 06:47:19 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:19 --> Input Class Initialized
INFO - 2023-04-18 06:47:19 --> Language Class Initialized
INFO - 2023-04-18 06:47:19 --> Loader Class Initialized
INFO - 2023-04-18 06:47:19 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:19 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:19 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:19 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:19 --> Total execution time: 0.0542
INFO - 2023-04-18 06:47:31 --> Config Class Initialized
INFO - 2023-04-18 06:47:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:31 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:31 --> URI Class Initialized
INFO - 2023-04-18 06:47:31 --> Router Class Initialized
INFO - 2023-04-18 06:47:31 --> Output Class Initialized
INFO - 2023-04-18 06:47:31 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:31 --> Input Class Initialized
INFO - 2023-04-18 06:47:31 --> Language Class Initialized
INFO - 2023-04-18 06:47:31 --> Loader Class Initialized
INFO - 2023-04-18 06:47:31 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:31 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:31 --> Total execution time: 0.1645
INFO - 2023-04-18 06:47:31 --> Config Class Initialized
INFO - 2023-04-18 06:47:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:31 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:31 --> URI Class Initialized
INFO - 2023-04-18 06:47:31 --> Router Class Initialized
INFO - 2023-04-18 06:47:31 --> Output Class Initialized
INFO - 2023-04-18 06:47:31 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:31 --> Input Class Initialized
INFO - 2023-04-18 06:47:31 --> Language Class Initialized
INFO - 2023-04-18 06:47:31 --> Loader Class Initialized
INFO - 2023-04-18 06:47:31 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:31 --> Model "Login_model" initialized
INFO - 2023-04-18 06:47:31 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:31 --> Total execution time: 0.0322
INFO - 2023-04-18 06:47:31 --> Config Class Initialized
INFO - 2023-04-18 06:47:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:31 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:31 --> URI Class Initialized
INFO - 2023-04-18 06:47:31 --> Router Class Initialized
INFO - 2023-04-18 06:47:31 --> Output Class Initialized
INFO - 2023-04-18 06:47:31 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:31 --> Input Class Initialized
INFO - 2023-04-18 06:47:31 --> Language Class Initialized
INFO - 2023-04-18 06:47:31 --> Loader Class Initialized
INFO - 2023-04-18 06:47:31 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:31 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:31 --> Total execution time: 0.0576
INFO - 2023-04-18 06:47:31 --> Config Class Initialized
INFO - 2023-04-18 06:47:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:31 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:31 --> URI Class Initialized
INFO - 2023-04-18 06:47:31 --> Router Class Initialized
INFO - 2023-04-18 06:47:31 --> Output Class Initialized
INFO - 2023-04-18 06:47:31 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:31 --> Input Class Initialized
INFO - 2023-04-18 06:47:31 --> Language Class Initialized
INFO - 2023-04-18 06:47:31 --> Loader Class Initialized
INFO - 2023-04-18 06:47:31 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:31 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:31 --> Model "Login_model" initialized
INFO - 2023-04-18 06:47:31 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:31 --> Total execution time: 0.0302
INFO - 2023-04-18 06:47:34 --> Config Class Initialized
INFO - 2023-04-18 06:47:34 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:34 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:34 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:34 --> URI Class Initialized
INFO - 2023-04-18 06:47:34 --> Router Class Initialized
INFO - 2023-04-18 06:47:34 --> Output Class Initialized
INFO - 2023-04-18 06:47:34 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:34 --> Input Class Initialized
INFO - 2023-04-18 06:47:34 --> Language Class Initialized
INFO - 2023-04-18 06:47:34 --> Loader Class Initialized
INFO - 2023-04-18 06:47:34 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:34 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:34 --> Total execution time: 0.0042
INFO - 2023-04-18 06:47:34 --> Config Class Initialized
INFO - 2023-04-18 06:47:34 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:34 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:34 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:34 --> URI Class Initialized
INFO - 2023-04-18 06:47:34 --> Router Class Initialized
INFO - 2023-04-18 06:47:34 --> Output Class Initialized
INFO - 2023-04-18 06:47:34 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:34 --> Input Class Initialized
INFO - 2023-04-18 06:47:34 --> Language Class Initialized
INFO - 2023-04-18 06:47:34 --> Loader Class Initialized
INFO - 2023-04-18 06:47:34 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:34 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:34 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:34 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:34 --> Total execution time: 0.0566
INFO - 2023-04-18 06:47:36 --> Config Class Initialized
INFO - 2023-04-18 06:47:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:36 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:36 --> URI Class Initialized
INFO - 2023-04-18 06:47:36 --> Router Class Initialized
INFO - 2023-04-18 06:47:36 --> Output Class Initialized
INFO - 2023-04-18 06:47:36 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:36 --> Input Class Initialized
INFO - 2023-04-18 06:47:36 --> Language Class Initialized
INFO - 2023-04-18 06:47:36 --> Loader Class Initialized
INFO - 2023-04-18 06:47:36 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:36 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:36 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:36 --> Total execution time: 0.0171
INFO - 2023-04-18 06:47:36 --> Config Class Initialized
INFO - 2023-04-18 06:47:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:36 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:36 --> URI Class Initialized
INFO - 2023-04-18 06:47:36 --> Router Class Initialized
INFO - 2023-04-18 06:47:36 --> Output Class Initialized
INFO - 2023-04-18 06:47:36 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:36 --> Input Class Initialized
INFO - 2023-04-18 06:47:36 --> Language Class Initialized
INFO - 2023-04-18 06:47:36 --> Loader Class Initialized
INFO - 2023-04-18 06:47:36 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:36 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:36 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:36 --> Total execution time: 0.0133
INFO - 2023-04-18 06:47:38 --> Config Class Initialized
INFO - 2023-04-18 06:47:38 --> Config Class Initialized
INFO - 2023-04-18 06:47:38 --> Hooks Class Initialized
INFO - 2023-04-18 06:47:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 06:47:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:38 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:38 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:38 --> URI Class Initialized
INFO - 2023-04-18 06:47:38 --> URI Class Initialized
INFO - 2023-04-18 06:47:38 --> Router Class Initialized
INFO - 2023-04-18 06:47:38 --> Router Class Initialized
INFO - 2023-04-18 06:47:38 --> Output Class Initialized
INFO - 2023-04-18 06:47:38 --> Output Class Initialized
INFO - 2023-04-18 06:47:38 --> Security Class Initialized
INFO - 2023-04-18 06:47:38 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 06:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:38 --> Input Class Initialized
INFO - 2023-04-18 06:47:38 --> Input Class Initialized
INFO - 2023-04-18 06:47:38 --> Language Class Initialized
INFO - 2023-04-18 06:47:38 --> Language Class Initialized
INFO - 2023-04-18 06:47:38 --> Loader Class Initialized
INFO - 2023-04-18 06:47:38 --> Loader Class Initialized
INFO - 2023-04-18 06:47:38 --> Controller Class Initialized
INFO - 2023-04-18 06:47:38 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 06:47:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:38 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:38 --> Total execution time: 0.0042
INFO - 2023-04-18 06:47:38 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:38 --> Config Class Initialized
INFO - 2023-04-18 06:47:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:38 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:38 --> URI Class Initialized
INFO - 2023-04-18 06:47:38 --> Router Class Initialized
INFO - 2023-04-18 06:47:38 --> Output Class Initialized
INFO - 2023-04-18 06:47:38 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:38 --> Input Class Initialized
INFO - 2023-04-18 06:47:38 --> Language Class Initialized
INFO - 2023-04-18 06:47:38 --> Loader Class Initialized
INFO - 2023-04-18 06:47:38 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:38 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:38 --> Model "Login_model" initialized
INFO - 2023-04-18 06:47:38 --> Final output sent to browser
INFO - 2023-04-18 06:47:38 --> Database Driver Class Initialized
DEBUG - 2023-04-18 06:47:38 --> Total execution time: 0.0265
INFO - 2023-04-18 06:47:38 --> Config Class Initialized
INFO - 2023-04-18 06:47:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:38 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:38 --> URI Class Initialized
INFO - 2023-04-18 06:47:38 --> Router Class Initialized
INFO - 2023-04-18 06:47:38 --> Output Class Initialized
INFO - 2023-04-18 06:47:38 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:38 --> Input Class Initialized
INFO - 2023-04-18 06:47:38 --> Language Class Initialized
INFO - 2023-04-18 06:47:38 --> Loader Class Initialized
INFO - 2023-04-18 06:47:38 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:38 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:38 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:38 --> Total execution time: 0.0289
INFO - 2023-04-18 06:47:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:38 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:38 --> Total execution time: 0.0533
INFO - 2023-04-18 06:47:41 --> Config Class Initialized
INFO - 2023-04-18 06:47:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:41 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:41 --> URI Class Initialized
INFO - 2023-04-18 06:47:41 --> Router Class Initialized
INFO - 2023-04-18 06:47:41 --> Output Class Initialized
INFO - 2023-04-18 06:47:41 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:41 --> Input Class Initialized
INFO - 2023-04-18 06:47:41 --> Language Class Initialized
INFO - 2023-04-18 06:47:41 --> Loader Class Initialized
INFO - 2023-04-18 06:47:41 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:41 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:41 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:41 --> Model "Login_model" initialized
INFO - 2023-04-18 06:47:41 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:41 --> Total execution time: 0.0617
INFO - 2023-04-18 06:47:41 --> Config Class Initialized
INFO - 2023-04-18 06:47:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:47:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:47:41 --> Utf8 Class Initialized
INFO - 2023-04-18 06:47:41 --> URI Class Initialized
INFO - 2023-04-18 06:47:41 --> Router Class Initialized
INFO - 2023-04-18 06:47:41 --> Output Class Initialized
INFO - 2023-04-18 06:47:41 --> Security Class Initialized
DEBUG - 2023-04-18 06:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:47:41 --> Input Class Initialized
INFO - 2023-04-18 06:47:41 --> Language Class Initialized
INFO - 2023-04-18 06:47:41 --> Loader Class Initialized
INFO - 2023-04-18 06:47:41 --> Controller Class Initialized
DEBUG - 2023-04-18 06:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:47:41 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:47:41 --> Database Driver Class Initialized
INFO - 2023-04-18 06:47:41 --> Model "Login_model" initialized
INFO - 2023-04-18 06:47:41 --> Final output sent to browser
DEBUG - 2023-04-18 06:47:41 --> Total execution time: 0.0604
INFO - 2023-04-18 06:49:25 --> Config Class Initialized
INFO - 2023-04-18 06:49:25 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:49:25 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:49:25 --> Utf8 Class Initialized
INFO - 2023-04-18 06:49:25 --> URI Class Initialized
INFO - 2023-04-18 06:49:25 --> Router Class Initialized
INFO - 2023-04-18 06:49:25 --> Output Class Initialized
INFO - 2023-04-18 06:49:25 --> Security Class Initialized
DEBUG - 2023-04-18 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:49:25 --> Input Class Initialized
INFO - 2023-04-18 06:49:25 --> Language Class Initialized
INFO - 2023-04-18 06:49:25 --> Loader Class Initialized
INFO - 2023-04-18 06:49:25 --> Controller Class Initialized
DEBUG - 2023-04-18 06:49:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:49:25 --> Database Driver Class Initialized
INFO - 2023-04-18 06:49:25 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:49:25 --> Database Driver Class Initialized
INFO - 2023-04-18 06:49:25 --> Model "Login_model" initialized
INFO - 2023-04-18 06:49:25 --> Final output sent to browser
DEBUG - 2023-04-18 06:49:25 --> Total execution time: 0.1879
INFO - 2023-04-18 06:49:25 --> Config Class Initialized
INFO - 2023-04-18 06:49:26 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:49:26 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:49:26 --> Utf8 Class Initialized
INFO - 2023-04-18 06:49:26 --> URI Class Initialized
INFO - 2023-04-18 06:49:26 --> Router Class Initialized
INFO - 2023-04-18 06:49:26 --> Output Class Initialized
INFO - 2023-04-18 06:49:26 --> Security Class Initialized
DEBUG - 2023-04-18 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:49:26 --> Input Class Initialized
INFO - 2023-04-18 06:49:26 --> Language Class Initialized
INFO - 2023-04-18 06:49:26 --> Loader Class Initialized
INFO - 2023-04-18 06:49:26 --> Controller Class Initialized
DEBUG - 2023-04-18 06:49:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:49:26 --> Database Driver Class Initialized
INFO - 2023-04-18 06:49:26 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:49:26 --> Database Driver Class Initialized
INFO - 2023-04-18 06:49:26 --> Model "Login_model" initialized
INFO - 2023-04-18 06:49:26 --> Final output sent to browser
DEBUG - 2023-04-18 06:49:26 --> Total execution time: 0.1011
INFO - 2023-04-18 06:49:37 --> Config Class Initialized
INFO - 2023-04-18 06:49:37 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:49:37 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:49:37 --> Utf8 Class Initialized
INFO - 2023-04-18 06:49:37 --> URI Class Initialized
INFO - 2023-04-18 06:49:37 --> Router Class Initialized
INFO - 2023-04-18 06:49:37 --> Output Class Initialized
INFO - 2023-04-18 06:49:37 --> Security Class Initialized
DEBUG - 2023-04-18 06:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:49:37 --> Input Class Initialized
INFO - 2023-04-18 06:49:37 --> Language Class Initialized
INFO - 2023-04-18 06:49:37 --> Loader Class Initialized
INFO - 2023-04-18 06:49:37 --> Controller Class Initialized
DEBUG - 2023-04-18 06:49:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:49:37 --> Database Driver Class Initialized
INFO - 2023-04-18 06:49:37 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:49:37 --> Final output sent to browser
DEBUG - 2023-04-18 06:49:37 --> Total execution time: 0.0337
INFO - 2023-04-18 06:49:37 --> Config Class Initialized
INFO - 2023-04-18 06:49:37 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:49:37 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:49:37 --> Utf8 Class Initialized
INFO - 2023-04-18 06:49:37 --> URI Class Initialized
INFO - 2023-04-18 06:49:37 --> Router Class Initialized
INFO - 2023-04-18 06:49:37 --> Output Class Initialized
INFO - 2023-04-18 06:49:37 --> Security Class Initialized
DEBUG - 2023-04-18 06:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:49:37 --> Input Class Initialized
INFO - 2023-04-18 06:49:37 --> Language Class Initialized
INFO - 2023-04-18 06:49:37 --> Loader Class Initialized
INFO - 2023-04-18 06:49:37 --> Controller Class Initialized
DEBUG - 2023-04-18 06:49:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:49:37 --> Database Driver Class Initialized
INFO - 2023-04-18 06:49:37 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:49:37 --> Final output sent to browser
DEBUG - 2023-04-18 06:49:37 --> Total execution time: 0.0638
INFO - 2023-04-18 06:49:51 --> Config Class Initialized
INFO - 2023-04-18 06:49:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:49:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:49:51 --> Utf8 Class Initialized
INFO - 2023-04-18 06:49:51 --> URI Class Initialized
INFO - 2023-04-18 06:49:51 --> Router Class Initialized
INFO - 2023-04-18 06:49:51 --> Output Class Initialized
INFO - 2023-04-18 06:49:51 --> Security Class Initialized
DEBUG - 2023-04-18 06:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:49:51 --> Input Class Initialized
INFO - 2023-04-18 06:49:51 --> Language Class Initialized
INFO - 2023-04-18 06:49:51 --> Loader Class Initialized
INFO - 2023-04-18 06:49:51 --> Controller Class Initialized
DEBUG - 2023-04-18 06:49:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:49:51 --> Database Driver Class Initialized
INFO - 2023-04-18 06:49:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:49:51 --> Final output sent to browser
DEBUG - 2023-04-18 06:49:51 --> Total execution time: 0.1453
INFO - 2023-04-18 06:56:37 --> Config Class Initialized
INFO - 2023-04-18 06:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:56:37 --> Utf8 Class Initialized
INFO - 2023-04-18 06:56:37 --> URI Class Initialized
INFO - 2023-04-18 06:56:37 --> Router Class Initialized
INFO - 2023-04-18 06:56:37 --> Output Class Initialized
INFO - 2023-04-18 06:56:37 --> Security Class Initialized
DEBUG - 2023-04-18 06:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:56:37 --> Input Class Initialized
INFO - 2023-04-18 06:56:37 --> Language Class Initialized
INFO - 2023-04-18 06:56:37 --> Loader Class Initialized
INFO - 2023-04-18 06:56:37 --> Controller Class Initialized
DEBUG - 2023-04-18 06:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:56:37 --> Database Driver Class Initialized
INFO - 2023-04-18 06:56:37 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:56:37 --> Database Driver Class Initialized
INFO - 2023-04-18 06:56:37 --> Model "Login_model" initialized
INFO - 2023-04-18 06:56:37 --> Final output sent to browser
DEBUG - 2023-04-18 06:56:37 --> Total execution time: 0.1874
INFO - 2023-04-18 06:56:37 --> Config Class Initialized
INFO - 2023-04-18 06:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-18 06:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-18 06:56:37 --> Utf8 Class Initialized
INFO - 2023-04-18 06:56:37 --> URI Class Initialized
INFO - 2023-04-18 06:56:37 --> Router Class Initialized
INFO - 2023-04-18 06:56:37 --> Output Class Initialized
INFO - 2023-04-18 06:56:37 --> Security Class Initialized
DEBUG - 2023-04-18 06:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 06:56:37 --> Input Class Initialized
INFO - 2023-04-18 06:56:37 --> Language Class Initialized
INFO - 2023-04-18 06:56:37 --> Loader Class Initialized
INFO - 2023-04-18 06:56:37 --> Controller Class Initialized
DEBUG - 2023-04-18 06:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 06:56:37 --> Database Driver Class Initialized
INFO - 2023-04-18 06:56:37 --> Model "Cluster_model" initialized
INFO - 2023-04-18 06:56:37 --> Database Driver Class Initialized
INFO - 2023-04-18 06:56:37 --> Model "Login_model" initialized
INFO - 2023-04-18 06:56:37 --> Final output sent to browser
DEBUG - 2023-04-18 06:56:37 --> Total execution time: 0.1012
INFO - 2023-04-18 07:00:38 --> Config Class Initialized
INFO - 2023-04-18 07:00:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:00:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:00:38 --> Utf8 Class Initialized
INFO - 2023-04-18 07:00:38 --> URI Class Initialized
INFO - 2023-04-18 07:00:38 --> Router Class Initialized
INFO - 2023-04-18 07:00:38 --> Output Class Initialized
INFO - 2023-04-18 07:00:38 --> Security Class Initialized
DEBUG - 2023-04-18 07:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:00:38 --> Input Class Initialized
INFO - 2023-04-18 07:00:38 --> Language Class Initialized
INFO - 2023-04-18 07:00:38 --> Loader Class Initialized
INFO - 2023-04-18 07:00:38 --> Controller Class Initialized
DEBUG - 2023-04-18 07:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:00:38 --> Database Driver Class Initialized
INFO - 2023-04-18 07:00:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:00:38 --> Final output sent to browser
DEBUG - 2023-04-18 07:00:38 --> Total execution time: 0.0516
INFO - 2023-04-18 07:00:38 --> Config Class Initialized
INFO - 2023-04-18 07:00:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:00:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:00:38 --> Utf8 Class Initialized
INFO - 2023-04-18 07:00:38 --> URI Class Initialized
INFO - 2023-04-18 07:00:38 --> Router Class Initialized
INFO - 2023-04-18 07:00:38 --> Output Class Initialized
INFO - 2023-04-18 07:00:38 --> Security Class Initialized
DEBUG - 2023-04-18 07:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:00:38 --> Input Class Initialized
INFO - 2023-04-18 07:00:38 --> Language Class Initialized
INFO - 2023-04-18 07:00:38 --> Loader Class Initialized
INFO - 2023-04-18 07:00:38 --> Controller Class Initialized
DEBUG - 2023-04-18 07:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:00:38 --> Database Driver Class Initialized
INFO - 2023-04-18 07:00:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:00:38 --> Final output sent to browser
DEBUG - 2023-04-18 07:00:38 --> Total execution time: 0.0684
INFO - 2023-04-18 07:06:06 --> Config Class Initialized
INFO - 2023-04-18 07:06:06 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:06:06 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:06:06 --> Utf8 Class Initialized
INFO - 2023-04-18 07:06:06 --> URI Class Initialized
INFO - 2023-04-18 07:06:06 --> Router Class Initialized
INFO - 2023-04-18 07:06:06 --> Output Class Initialized
INFO - 2023-04-18 07:06:06 --> Security Class Initialized
DEBUG - 2023-04-18 07:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:06:06 --> Input Class Initialized
INFO - 2023-04-18 07:06:06 --> Language Class Initialized
INFO - 2023-04-18 07:06:06 --> Loader Class Initialized
INFO - 2023-04-18 07:06:06 --> Controller Class Initialized
DEBUG - 2023-04-18 07:06:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:06:06 --> Database Driver Class Initialized
INFO - 2023-04-18 07:06:06 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:06:06 --> Final output sent to browser
DEBUG - 2023-04-18 07:06:06 --> Total execution time: 0.0894
INFO - 2023-04-18 07:06:25 --> Config Class Initialized
INFO - 2023-04-18 07:06:25 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:06:25 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:06:25 --> Utf8 Class Initialized
INFO - 2023-04-18 07:06:25 --> URI Class Initialized
INFO - 2023-04-18 07:06:25 --> Router Class Initialized
INFO - 2023-04-18 07:06:25 --> Output Class Initialized
INFO - 2023-04-18 07:06:25 --> Security Class Initialized
DEBUG - 2023-04-18 07:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:06:25 --> Input Class Initialized
INFO - 2023-04-18 07:06:25 --> Language Class Initialized
INFO - 2023-04-18 07:06:25 --> Loader Class Initialized
INFO - 2023-04-18 07:06:25 --> Controller Class Initialized
DEBUG - 2023-04-18 07:06:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:06:25 --> Database Driver Class Initialized
INFO - 2023-04-18 07:06:25 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:06:25 --> Final output sent to browser
DEBUG - 2023-04-18 07:06:25 --> Total execution time: 0.0277
INFO - 2023-04-18 07:13:44 --> Config Class Initialized
INFO - 2023-04-18 07:13:44 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:13:44 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:13:44 --> Utf8 Class Initialized
INFO - 2023-04-18 07:13:44 --> URI Class Initialized
INFO - 2023-04-18 07:13:44 --> Router Class Initialized
INFO - 2023-04-18 07:13:44 --> Output Class Initialized
INFO - 2023-04-18 07:13:44 --> Security Class Initialized
DEBUG - 2023-04-18 07:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:13:44 --> Input Class Initialized
INFO - 2023-04-18 07:13:44 --> Language Class Initialized
INFO - 2023-04-18 07:13:44 --> Loader Class Initialized
INFO - 2023-04-18 07:13:44 --> Controller Class Initialized
DEBUG - 2023-04-18 07:13:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:13:44 --> Database Driver Class Initialized
INFO - 2023-04-18 07:13:44 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:13:44 --> Final output sent to browser
DEBUG - 2023-04-18 07:13:44 --> Total execution time: 0.0744
INFO - 2023-04-18 07:13:55 --> Config Class Initialized
INFO - 2023-04-18 07:13:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:13:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:13:55 --> Utf8 Class Initialized
INFO - 2023-04-18 07:13:55 --> URI Class Initialized
INFO - 2023-04-18 07:13:55 --> Router Class Initialized
INFO - 2023-04-18 07:13:55 --> Output Class Initialized
INFO - 2023-04-18 07:13:55 --> Security Class Initialized
DEBUG - 2023-04-18 07:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:13:55 --> Input Class Initialized
INFO - 2023-04-18 07:13:55 --> Language Class Initialized
INFO - 2023-04-18 07:13:55 --> Loader Class Initialized
INFO - 2023-04-18 07:13:55 --> Controller Class Initialized
DEBUG - 2023-04-18 07:13:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:13:55 --> Database Driver Class Initialized
INFO - 2023-04-18 07:13:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:13:55 --> Final output sent to browser
DEBUG - 2023-04-18 07:13:55 --> Total execution time: 0.0764
INFO - 2023-04-18 07:15:18 --> Config Class Initialized
INFO - 2023-04-18 07:15:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:15:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:15:18 --> Utf8 Class Initialized
INFO - 2023-04-18 07:15:18 --> URI Class Initialized
INFO - 2023-04-18 07:15:18 --> Router Class Initialized
INFO - 2023-04-18 07:15:18 --> Output Class Initialized
INFO - 2023-04-18 07:15:18 --> Security Class Initialized
DEBUG - 2023-04-18 07:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:15:18 --> Input Class Initialized
INFO - 2023-04-18 07:15:18 --> Language Class Initialized
INFO - 2023-04-18 07:15:18 --> Loader Class Initialized
INFO - 2023-04-18 07:15:18 --> Controller Class Initialized
DEBUG - 2023-04-18 07:15:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:15:18 --> Database Driver Class Initialized
INFO - 2023-04-18 07:15:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:15:18 --> Final output sent to browser
DEBUG - 2023-04-18 07:15:18 --> Total execution time: 0.0761
INFO - 2023-04-18 07:15:19 --> Config Class Initialized
INFO - 2023-04-18 07:15:19 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:15:19 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:15:19 --> Utf8 Class Initialized
INFO - 2023-04-18 07:15:19 --> URI Class Initialized
INFO - 2023-04-18 07:15:19 --> Router Class Initialized
INFO - 2023-04-18 07:15:19 --> Output Class Initialized
INFO - 2023-04-18 07:15:19 --> Security Class Initialized
DEBUG - 2023-04-18 07:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:15:19 --> Input Class Initialized
INFO - 2023-04-18 07:15:19 --> Language Class Initialized
INFO - 2023-04-18 07:15:19 --> Loader Class Initialized
INFO - 2023-04-18 07:15:19 --> Controller Class Initialized
DEBUG - 2023-04-18 07:15:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:15:19 --> Database Driver Class Initialized
INFO - 2023-04-18 07:15:19 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:15:19 --> Final output sent to browser
DEBUG - 2023-04-18 07:15:19 --> Total execution time: 0.0659
INFO - 2023-04-18 07:15:28 --> Config Class Initialized
INFO - 2023-04-18 07:15:28 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:15:28 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:15:28 --> Utf8 Class Initialized
INFO - 2023-04-18 07:15:28 --> URI Class Initialized
INFO - 2023-04-18 07:15:28 --> Router Class Initialized
INFO - 2023-04-18 07:15:28 --> Output Class Initialized
INFO - 2023-04-18 07:15:28 --> Security Class Initialized
DEBUG - 2023-04-18 07:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:15:28 --> Input Class Initialized
INFO - 2023-04-18 07:15:28 --> Language Class Initialized
INFO - 2023-04-18 07:15:28 --> Loader Class Initialized
INFO - 2023-04-18 07:15:28 --> Controller Class Initialized
DEBUG - 2023-04-18 07:15:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:15:28 --> Database Driver Class Initialized
INFO - 2023-04-18 07:15:28 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:15:28 --> Final output sent to browser
DEBUG - 2023-04-18 07:15:28 --> Total execution time: 0.1072
INFO - 2023-04-18 07:18:25 --> Config Class Initialized
INFO - 2023-04-18 07:18:25 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:18:25 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:18:25 --> Utf8 Class Initialized
INFO - 2023-04-18 07:18:25 --> URI Class Initialized
INFO - 2023-04-18 07:18:25 --> Router Class Initialized
INFO - 2023-04-18 07:18:25 --> Output Class Initialized
INFO - 2023-04-18 07:18:25 --> Security Class Initialized
DEBUG - 2023-04-18 07:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:18:25 --> Input Class Initialized
INFO - 2023-04-18 07:18:25 --> Language Class Initialized
INFO - 2023-04-18 07:18:25 --> Loader Class Initialized
INFO - 2023-04-18 07:18:25 --> Controller Class Initialized
DEBUG - 2023-04-18 07:18:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:18:25 --> Database Driver Class Initialized
INFO - 2023-04-18 07:18:25 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:18:25 --> Final output sent to browser
DEBUG - 2023-04-18 07:18:25 --> Total execution time: 0.0743
INFO - 2023-04-18 07:18:35 --> Config Class Initialized
INFO - 2023-04-18 07:18:35 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:18:35 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:18:35 --> Utf8 Class Initialized
INFO - 2023-04-18 07:18:35 --> URI Class Initialized
INFO - 2023-04-18 07:18:35 --> Router Class Initialized
INFO - 2023-04-18 07:18:35 --> Output Class Initialized
INFO - 2023-04-18 07:18:35 --> Security Class Initialized
DEBUG - 2023-04-18 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:18:35 --> Input Class Initialized
INFO - 2023-04-18 07:18:35 --> Language Class Initialized
INFO - 2023-04-18 07:18:35 --> Loader Class Initialized
INFO - 2023-04-18 07:18:35 --> Controller Class Initialized
DEBUG - 2023-04-18 07:18:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:18:35 --> Database Driver Class Initialized
INFO - 2023-04-18 07:18:35 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:18:35 --> Final output sent to browser
DEBUG - 2023-04-18 07:18:35 --> Total execution time: 0.0712
INFO - 2023-04-18 07:51:48 --> Config Class Initialized
INFO - 2023-04-18 07:51:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:51:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:51:48 --> Utf8 Class Initialized
INFO - 2023-04-18 07:51:48 --> URI Class Initialized
INFO - 2023-04-18 07:51:48 --> Router Class Initialized
INFO - 2023-04-18 07:51:48 --> Output Class Initialized
INFO - 2023-04-18 07:51:48 --> Security Class Initialized
DEBUG - 2023-04-18 07:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:51:48 --> Input Class Initialized
INFO - 2023-04-18 07:51:48 --> Language Class Initialized
INFO - 2023-04-18 07:51:48 --> Loader Class Initialized
INFO - 2023-04-18 07:51:48 --> Controller Class Initialized
DEBUG - 2023-04-18 07:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:51:48 --> Database Driver Class Initialized
INFO - 2023-04-18 07:51:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:51:48 --> Database Driver Class Initialized
INFO - 2023-04-18 07:51:48 --> Model "Login_model" initialized
INFO - 2023-04-18 07:51:48 --> Final output sent to browser
DEBUG - 2023-04-18 07:51:48 --> Total execution time: 0.1765
INFO - 2023-04-18 07:51:48 --> Config Class Initialized
INFO - 2023-04-18 07:51:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:51:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:51:48 --> Utf8 Class Initialized
INFO - 2023-04-18 07:51:48 --> URI Class Initialized
INFO - 2023-04-18 07:51:48 --> Router Class Initialized
INFO - 2023-04-18 07:51:48 --> Output Class Initialized
INFO - 2023-04-18 07:51:48 --> Security Class Initialized
DEBUG - 2023-04-18 07:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:51:48 --> Input Class Initialized
INFO - 2023-04-18 07:51:48 --> Language Class Initialized
INFO - 2023-04-18 07:51:48 --> Loader Class Initialized
INFO - 2023-04-18 07:51:48 --> Controller Class Initialized
DEBUG - 2023-04-18 07:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:51:48 --> Database Driver Class Initialized
INFO - 2023-04-18 07:51:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:51:48 --> Database Driver Class Initialized
INFO - 2023-04-18 07:51:48 --> Model "Login_model" initialized
INFO - 2023-04-18 07:51:48 --> Final output sent to browser
DEBUG - 2023-04-18 07:51:48 --> Total execution time: 0.0888
INFO - 2023-04-18 07:51:52 --> Config Class Initialized
INFO - 2023-04-18 07:51:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:51:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:51:52 --> Utf8 Class Initialized
INFO - 2023-04-18 07:51:52 --> URI Class Initialized
INFO - 2023-04-18 07:51:52 --> Router Class Initialized
INFO - 2023-04-18 07:51:52 --> Output Class Initialized
INFO - 2023-04-18 07:51:52 --> Security Class Initialized
DEBUG - 2023-04-18 07:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:51:52 --> Input Class Initialized
INFO - 2023-04-18 07:51:52 --> Language Class Initialized
INFO - 2023-04-18 07:51:52 --> Loader Class Initialized
INFO - 2023-04-18 07:51:52 --> Controller Class Initialized
DEBUG - 2023-04-18 07:51:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:51:52 --> Database Driver Class Initialized
INFO - 2023-04-18 07:51:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:51:52 --> Final output sent to browser
DEBUG - 2023-04-18 07:51:52 --> Total execution time: 0.1326
INFO - 2023-04-18 07:51:52 --> Config Class Initialized
INFO - 2023-04-18 07:51:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:51:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:51:52 --> Utf8 Class Initialized
INFO - 2023-04-18 07:51:52 --> URI Class Initialized
INFO - 2023-04-18 07:51:52 --> Router Class Initialized
INFO - 2023-04-18 07:51:52 --> Output Class Initialized
INFO - 2023-04-18 07:51:52 --> Security Class Initialized
DEBUG - 2023-04-18 07:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:51:52 --> Input Class Initialized
INFO - 2023-04-18 07:51:52 --> Language Class Initialized
INFO - 2023-04-18 07:51:52 --> Loader Class Initialized
INFO - 2023-04-18 07:51:52 --> Controller Class Initialized
DEBUG - 2023-04-18 07:51:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:51:52 --> Database Driver Class Initialized
INFO - 2023-04-18 07:51:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:51:52 --> Final output sent to browser
DEBUG - 2023-04-18 07:51:52 --> Total execution time: 0.0902
INFO - 2023-04-18 07:52:02 --> Config Class Initialized
INFO - 2023-04-18 07:52:02 --> Config Class Initialized
INFO - 2023-04-18 07:52:02 --> Hooks Class Initialized
INFO - 2023-04-18 07:52:02 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:02 --> Utf8 Class Initialized
DEBUG - 2023-04-18 07:52:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:02 --> URI Class Initialized
INFO - 2023-04-18 07:52:02 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:02 --> Router Class Initialized
INFO - 2023-04-18 07:52:02 --> URI Class Initialized
INFO - 2023-04-18 07:52:02 --> Output Class Initialized
INFO - 2023-04-18 07:52:02 --> Router Class Initialized
INFO - 2023-04-18 07:52:02 --> Security Class Initialized
INFO - 2023-04-18 07:52:02 --> Output Class Initialized
DEBUG - 2023-04-18 07:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:02 --> Input Class Initialized
INFO - 2023-04-18 07:52:02 --> Security Class Initialized
INFO - 2023-04-18 07:52:02 --> Language Class Initialized
DEBUG - 2023-04-18 07:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:02 --> Input Class Initialized
INFO - 2023-04-18 07:52:02 --> Loader Class Initialized
INFO - 2023-04-18 07:52:02 --> Controller Class Initialized
INFO - 2023-04-18 07:52:02 --> Language Class Initialized
DEBUG - 2023-04-18 07:52:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:02 --> Loader Class Initialized
INFO - 2023-04-18 07:52:02 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:02 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:02 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:02 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:02 --> Total execution time: 0.0276
INFO - 2023-04-18 07:52:02 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:02 --> Total execution time: 0.0295
INFO - 2023-04-18 07:52:02 --> Config Class Initialized
INFO - 2023-04-18 07:52:02 --> Config Class Initialized
INFO - 2023-04-18 07:52:02 --> Hooks Class Initialized
INFO - 2023-04-18 07:52:02 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:02 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 07:52:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:02 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:02 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:02 --> URI Class Initialized
INFO - 2023-04-18 07:52:02 --> URI Class Initialized
INFO - 2023-04-18 07:52:02 --> Router Class Initialized
INFO - 2023-04-18 07:52:02 --> Router Class Initialized
INFO - 2023-04-18 07:52:02 --> Output Class Initialized
INFO - 2023-04-18 07:52:02 --> Output Class Initialized
INFO - 2023-04-18 07:52:02 --> Security Class Initialized
INFO - 2023-04-18 07:52:02 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 07:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:02 --> Input Class Initialized
INFO - 2023-04-18 07:52:02 --> Input Class Initialized
INFO - 2023-04-18 07:52:02 --> Language Class Initialized
INFO - 2023-04-18 07:52:02 --> Language Class Initialized
INFO - 2023-04-18 07:52:02 --> Loader Class Initialized
INFO - 2023-04-18 07:52:02 --> Loader Class Initialized
INFO - 2023-04-18 07:52:02 --> Controller Class Initialized
INFO - 2023-04-18 07:52:02 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 07:52:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:02 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:02 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:02 --> Final output sent to browser
INFO - 2023-04-18 07:52:02 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:02 --> Total execution time: 0.0496
DEBUG - 2023-04-18 07:52:02 --> Total execution time: 0.0516
INFO - 2023-04-18 07:52:03 --> Config Class Initialized
INFO - 2023-04-18 07:52:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:03 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:03 --> URI Class Initialized
INFO - 2023-04-18 07:52:03 --> Router Class Initialized
INFO - 2023-04-18 07:52:03 --> Output Class Initialized
INFO - 2023-04-18 07:52:03 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:03 --> Input Class Initialized
INFO - 2023-04-18 07:52:03 --> Language Class Initialized
INFO - 2023-04-18 07:52:03 --> Loader Class Initialized
INFO - 2023-04-18 07:52:03 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:03 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:03 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:03 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:03 --> Total execution time: 0.0232
INFO - 2023-04-18 07:52:03 --> Config Class Initialized
INFO - 2023-04-18 07:52:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:03 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:03 --> URI Class Initialized
INFO - 2023-04-18 07:52:03 --> Router Class Initialized
INFO - 2023-04-18 07:52:03 --> Output Class Initialized
INFO - 2023-04-18 07:52:03 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:03 --> Input Class Initialized
INFO - 2023-04-18 07:52:03 --> Language Class Initialized
INFO - 2023-04-18 07:52:03 --> Loader Class Initialized
INFO - 2023-04-18 07:52:03 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:03 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:03 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:03 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:03 --> Total execution time: 0.0665
INFO - 2023-04-18 07:52:05 --> Config Class Initialized
INFO - 2023-04-18 07:52:05 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:05 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:05 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:05 --> URI Class Initialized
INFO - 2023-04-18 07:52:05 --> Router Class Initialized
INFO - 2023-04-18 07:52:05 --> Output Class Initialized
INFO - 2023-04-18 07:52:05 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:05 --> Input Class Initialized
INFO - 2023-04-18 07:52:05 --> Language Class Initialized
INFO - 2023-04-18 07:52:05 --> Loader Class Initialized
INFO - 2023-04-18 07:52:05 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:05 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:05 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:05 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:05 --> Total execution time: 0.0484
INFO - 2023-04-18 07:52:05 --> Config Class Initialized
INFO - 2023-04-18 07:52:05 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:05 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:05 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:05 --> URI Class Initialized
INFO - 2023-04-18 07:52:05 --> Router Class Initialized
INFO - 2023-04-18 07:52:05 --> Output Class Initialized
INFO - 2023-04-18 07:52:05 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:05 --> Input Class Initialized
INFO - 2023-04-18 07:52:05 --> Language Class Initialized
INFO - 2023-04-18 07:52:05 --> Loader Class Initialized
INFO - 2023-04-18 07:52:05 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:05 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:05 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:05 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:05 --> Total execution time: 0.0654
INFO - 2023-04-18 07:52:07 --> Config Class Initialized
INFO - 2023-04-18 07:52:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:07 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:07 --> URI Class Initialized
INFO - 2023-04-18 07:52:07 --> Router Class Initialized
INFO - 2023-04-18 07:52:07 --> Output Class Initialized
INFO - 2023-04-18 07:52:07 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:07 --> Input Class Initialized
INFO - 2023-04-18 07:52:07 --> Language Class Initialized
INFO - 2023-04-18 07:52:07 --> Loader Class Initialized
INFO - 2023-04-18 07:52:07 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:07 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:07 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:07 --> Total execution time: 0.0171
INFO - 2023-04-18 07:52:07 --> Config Class Initialized
INFO - 2023-04-18 07:52:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:07 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:07 --> URI Class Initialized
INFO - 2023-04-18 07:52:07 --> Router Class Initialized
INFO - 2023-04-18 07:52:07 --> Output Class Initialized
INFO - 2023-04-18 07:52:07 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:07 --> Input Class Initialized
INFO - 2023-04-18 07:52:07 --> Language Class Initialized
INFO - 2023-04-18 07:52:07 --> Loader Class Initialized
INFO - 2023-04-18 07:52:07 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:07 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:07 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:07 --> Total execution time: 0.0143
INFO - 2023-04-18 07:52:09 --> Config Class Initialized
INFO - 2023-04-18 07:52:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:09 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:09 --> URI Class Initialized
INFO - 2023-04-18 07:52:09 --> Router Class Initialized
INFO - 2023-04-18 07:52:09 --> Output Class Initialized
INFO - 2023-04-18 07:52:09 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:09 --> Input Class Initialized
INFO - 2023-04-18 07:52:09 --> Language Class Initialized
INFO - 2023-04-18 07:52:09 --> Loader Class Initialized
INFO - 2023-04-18 07:52:09 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:09 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:09 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:09 --> Total execution time: 0.0515
INFO - 2023-04-18 07:52:09 --> Config Class Initialized
INFO - 2023-04-18 07:52:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:09 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:09 --> URI Class Initialized
INFO - 2023-04-18 07:52:09 --> Router Class Initialized
INFO - 2023-04-18 07:52:09 --> Output Class Initialized
INFO - 2023-04-18 07:52:09 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:09 --> Input Class Initialized
INFO - 2023-04-18 07:52:09 --> Language Class Initialized
INFO - 2023-04-18 07:52:09 --> Loader Class Initialized
INFO - 2023-04-18 07:52:09 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:09 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:09 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:09 --> Total execution time: 0.0736
INFO - 2023-04-18 07:52:11 --> Config Class Initialized
INFO - 2023-04-18 07:52:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:11 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:11 --> URI Class Initialized
INFO - 2023-04-18 07:52:11 --> Router Class Initialized
INFO - 2023-04-18 07:52:11 --> Output Class Initialized
INFO - 2023-04-18 07:52:11 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:11 --> Input Class Initialized
INFO - 2023-04-18 07:52:11 --> Language Class Initialized
INFO - 2023-04-18 07:52:11 --> Loader Class Initialized
INFO - 2023-04-18 07:52:11 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:11 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:11 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:11 --> Total execution time: 0.0147
INFO - 2023-04-18 07:52:11 --> Config Class Initialized
INFO - 2023-04-18 07:52:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:11 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:11 --> URI Class Initialized
INFO - 2023-04-18 07:52:11 --> Router Class Initialized
INFO - 2023-04-18 07:52:11 --> Output Class Initialized
INFO - 2023-04-18 07:52:11 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:11 --> Input Class Initialized
INFO - 2023-04-18 07:52:11 --> Language Class Initialized
INFO - 2023-04-18 07:52:11 --> Loader Class Initialized
INFO - 2023-04-18 07:52:11 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:11 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:11 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:11 --> Total execution time: 0.0535
INFO - 2023-04-18 07:52:11 --> Config Class Initialized
INFO - 2023-04-18 07:52:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:11 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:11 --> URI Class Initialized
INFO - 2023-04-18 07:52:11 --> Router Class Initialized
INFO - 2023-04-18 07:52:11 --> Output Class Initialized
INFO - 2023-04-18 07:52:11 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:11 --> Input Class Initialized
INFO - 2023-04-18 07:52:11 --> Language Class Initialized
INFO - 2023-04-18 07:52:11 --> Loader Class Initialized
INFO - 2023-04-18 07:52:11 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:11 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:11 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:11 --> Total execution time: 0.0154
INFO - 2023-04-18 07:52:11 --> Config Class Initialized
INFO - 2023-04-18 07:52:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:11 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:11 --> URI Class Initialized
INFO - 2023-04-18 07:52:11 --> Router Class Initialized
INFO - 2023-04-18 07:52:11 --> Output Class Initialized
INFO - 2023-04-18 07:52:11 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:11 --> Input Class Initialized
INFO - 2023-04-18 07:52:11 --> Language Class Initialized
INFO - 2023-04-18 07:52:11 --> Loader Class Initialized
INFO - 2023-04-18 07:52:11 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:11 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:11 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:11 --> Total execution time: 0.0506
INFO - 2023-04-18 07:52:12 --> Config Class Initialized
INFO - 2023-04-18 07:52:12 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:12 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:12 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:12 --> URI Class Initialized
INFO - 2023-04-18 07:52:12 --> Router Class Initialized
INFO - 2023-04-18 07:52:12 --> Output Class Initialized
INFO - 2023-04-18 07:52:12 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:12 --> Input Class Initialized
INFO - 2023-04-18 07:52:12 --> Language Class Initialized
INFO - 2023-04-18 07:52:12 --> Loader Class Initialized
INFO - 2023-04-18 07:52:12 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:12 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:12 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:12 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:12 --> Total execution time: 0.0307
INFO - 2023-04-18 07:52:12 --> Config Class Initialized
INFO - 2023-04-18 07:52:12 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:52:12 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:52:12 --> Utf8 Class Initialized
INFO - 2023-04-18 07:52:12 --> URI Class Initialized
INFO - 2023-04-18 07:52:12 --> Router Class Initialized
INFO - 2023-04-18 07:52:12 --> Output Class Initialized
INFO - 2023-04-18 07:52:12 --> Security Class Initialized
DEBUG - 2023-04-18 07:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:52:12 --> Input Class Initialized
INFO - 2023-04-18 07:52:12 --> Language Class Initialized
INFO - 2023-04-18 07:52:12 --> Loader Class Initialized
INFO - 2023-04-18 07:52:12 --> Controller Class Initialized
DEBUG - 2023-04-18 07:52:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:52:12 --> Database Driver Class Initialized
INFO - 2023-04-18 07:52:12 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:52:12 --> Final output sent to browser
DEBUG - 2023-04-18 07:52:12 --> Total execution time: 0.0737
INFO - 2023-04-18 07:53:07 --> Config Class Initialized
INFO - 2023-04-18 07:53:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:53:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:53:07 --> Utf8 Class Initialized
INFO - 2023-04-18 07:53:07 --> URI Class Initialized
INFO - 2023-04-18 07:53:07 --> Router Class Initialized
INFO - 2023-04-18 07:53:07 --> Output Class Initialized
INFO - 2023-04-18 07:53:07 --> Security Class Initialized
DEBUG - 2023-04-18 07:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:53:07 --> Input Class Initialized
INFO - 2023-04-18 07:53:07 --> Language Class Initialized
INFO - 2023-04-18 07:53:07 --> Loader Class Initialized
INFO - 2023-04-18 07:53:07 --> Controller Class Initialized
DEBUG - 2023-04-18 07:53:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:53:07 --> Database Driver Class Initialized
INFO - 2023-04-18 07:53:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:53:07 --> Final output sent to browser
DEBUG - 2023-04-18 07:53:07 --> Total execution time: 0.0143
INFO - 2023-04-18 07:53:07 --> Config Class Initialized
INFO - 2023-04-18 07:53:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:53:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:53:07 --> Utf8 Class Initialized
INFO - 2023-04-18 07:53:07 --> URI Class Initialized
INFO - 2023-04-18 07:53:07 --> Router Class Initialized
INFO - 2023-04-18 07:53:07 --> Output Class Initialized
INFO - 2023-04-18 07:53:07 --> Security Class Initialized
DEBUG - 2023-04-18 07:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:53:07 --> Input Class Initialized
INFO - 2023-04-18 07:53:07 --> Language Class Initialized
INFO - 2023-04-18 07:53:07 --> Loader Class Initialized
INFO - 2023-04-18 07:53:07 --> Controller Class Initialized
DEBUG - 2023-04-18 07:53:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:53:07 --> Database Driver Class Initialized
INFO - 2023-04-18 07:53:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:53:07 --> Final output sent to browser
DEBUG - 2023-04-18 07:53:07 --> Total execution time: 0.0092
INFO - 2023-04-18 07:53:09 --> Config Class Initialized
INFO - 2023-04-18 07:53:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:53:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:53:09 --> Utf8 Class Initialized
INFO - 2023-04-18 07:53:09 --> URI Class Initialized
INFO - 2023-04-18 07:53:09 --> Router Class Initialized
INFO - 2023-04-18 07:53:09 --> Output Class Initialized
INFO - 2023-04-18 07:53:09 --> Security Class Initialized
DEBUG - 2023-04-18 07:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:53:09 --> Input Class Initialized
INFO - 2023-04-18 07:53:09 --> Language Class Initialized
INFO - 2023-04-18 07:53:09 --> Loader Class Initialized
INFO - 2023-04-18 07:53:09 --> Controller Class Initialized
DEBUG - 2023-04-18 07:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:53:09 --> Database Driver Class Initialized
INFO - 2023-04-18 07:53:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:53:09 --> Final output sent to browser
DEBUG - 2023-04-18 07:53:09 --> Total execution time: 0.0128
INFO - 2023-04-18 07:53:09 --> Config Class Initialized
INFO - 2023-04-18 07:53:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:53:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:53:09 --> Utf8 Class Initialized
INFO - 2023-04-18 07:53:09 --> URI Class Initialized
INFO - 2023-04-18 07:53:09 --> Router Class Initialized
INFO - 2023-04-18 07:53:09 --> Output Class Initialized
INFO - 2023-04-18 07:53:09 --> Security Class Initialized
DEBUG - 2023-04-18 07:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:53:09 --> Input Class Initialized
INFO - 2023-04-18 07:53:09 --> Language Class Initialized
INFO - 2023-04-18 07:53:09 --> Loader Class Initialized
INFO - 2023-04-18 07:53:09 --> Controller Class Initialized
DEBUG - 2023-04-18 07:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:53:09 --> Database Driver Class Initialized
INFO - 2023-04-18 07:53:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:53:09 --> Final output sent to browser
DEBUG - 2023-04-18 07:53:09 --> Total execution time: 0.0100
INFO - 2023-04-18 07:53:09 --> Config Class Initialized
INFO - 2023-04-18 07:53:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:53:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:53:09 --> Utf8 Class Initialized
INFO - 2023-04-18 07:53:09 --> URI Class Initialized
INFO - 2023-04-18 07:53:09 --> Router Class Initialized
INFO - 2023-04-18 07:53:09 --> Output Class Initialized
INFO - 2023-04-18 07:53:09 --> Security Class Initialized
DEBUG - 2023-04-18 07:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:53:09 --> Input Class Initialized
INFO - 2023-04-18 07:53:09 --> Language Class Initialized
INFO - 2023-04-18 07:53:09 --> Loader Class Initialized
INFO - 2023-04-18 07:53:09 --> Controller Class Initialized
DEBUG - 2023-04-18 07:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:53:09 --> Database Driver Class Initialized
INFO - 2023-04-18 07:53:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:53:09 --> Final output sent to browser
DEBUG - 2023-04-18 07:53:09 --> Total execution time: 0.0212
INFO - 2023-04-18 07:53:09 --> Config Class Initialized
INFO - 2023-04-18 07:53:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:53:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:53:09 --> Utf8 Class Initialized
INFO - 2023-04-18 07:53:09 --> URI Class Initialized
INFO - 2023-04-18 07:53:09 --> Router Class Initialized
INFO - 2023-04-18 07:53:09 --> Output Class Initialized
INFO - 2023-04-18 07:53:09 --> Security Class Initialized
DEBUG - 2023-04-18 07:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:53:09 --> Input Class Initialized
INFO - 2023-04-18 07:53:09 --> Language Class Initialized
INFO - 2023-04-18 07:53:09 --> Loader Class Initialized
INFO - 2023-04-18 07:53:09 --> Controller Class Initialized
DEBUG - 2023-04-18 07:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:53:09 --> Database Driver Class Initialized
INFO - 2023-04-18 07:53:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:53:09 --> Final output sent to browser
DEBUG - 2023-04-18 07:53:09 --> Total execution time: 0.0407
INFO - 2023-04-18 07:53:11 --> Config Class Initialized
INFO - 2023-04-18 07:53:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:53:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:53:11 --> Utf8 Class Initialized
INFO - 2023-04-18 07:53:11 --> URI Class Initialized
INFO - 2023-04-18 07:53:11 --> Router Class Initialized
INFO - 2023-04-18 07:53:11 --> Output Class Initialized
INFO - 2023-04-18 07:53:11 --> Security Class Initialized
DEBUG - 2023-04-18 07:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:53:11 --> Input Class Initialized
INFO - 2023-04-18 07:53:11 --> Language Class Initialized
INFO - 2023-04-18 07:53:11 --> Loader Class Initialized
INFO - 2023-04-18 07:53:11 --> Controller Class Initialized
DEBUG - 2023-04-18 07:53:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:53:11 --> Database Driver Class Initialized
INFO - 2023-04-18 07:53:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:53:11 --> Final output sent to browser
DEBUG - 2023-04-18 07:53:11 --> Total execution time: 0.0326
INFO - 2023-04-18 07:53:11 --> Config Class Initialized
INFO - 2023-04-18 07:53:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:53:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:53:11 --> Utf8 Class Initialized
INFO - 2023-04-18 07:53:11 --> URI Class Initialized
INFO - 2023-04-18 07:53:11 --> Router Class Initialized
INFO - 2023-04-18 07:53:11 --> Output Class Initialized
INFO - 2023-04-18 07:53:11 --> Security Class Initialized
DEBUG - 2023-04-18 07:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:53:11 --> Input Class Initialized
INFO - 2023-04-18 07:53:11 --> Language Class Initialized
INFO - 2023-04-18 07:53:11 --> Loader Class Initialized
INFO - 2023-04-18 07:53:11 --> Controller Class Initialized
DEBUG - 2023-04-18 07:53:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:53:11 --> Database Driver Class Initialized
INFO - 2023-04-18 07:53:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:53:11 --> Final output sent to browser
DEBUG - 2023-04-18 07:53:11 --> Total execution time: 0.0522
INFO - 2023-04-18 07:55:21 --> Config Class Initialized
INFO - 2023-04-18 07:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 07:55:21 --> URI Class Initialized
INFO - 2023-04-18 07:55:21 --> Router Class Initialized
INFO - 2023-04-18 07:55:21 --> Output Class Initialized
INFO - 2023-04-18 07:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 07:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:55:21 --> Input Class Initialized
INFO - 2023-04-18 07:55:21 --> Language Class Initialized
INFO - 2023-04-18 07:55:21 --> Loader Class Initialized
INFO - 2023-04-18 07:55:21 --> Controller Class Initialized
DEBUG - 2023-04-18 07:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 07:55:21 --> Total execution time: 0.0179
INFO - 2023-04-18 07:55:21 --> Config Class Initialized
INFO - 2023-04-18 07:55:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:55:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:55:21 --> Utf8 Class Initialized
INFO - 2023-04-18 07:55:21 --> URI Class Initialized
INFO - 2023-04-18 07:55:21 --> Router Class Initialized
INFO - 2023-04-18 07:55:21 --> Output Class Initialized
INFO - 2023-04-18 07:55:21 --> Security Class Initialized
DEBUG - 2023-04-18 07:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:55:21 --> Input Class Initialized
INFO - 2023-04-18 07:55:21 --> Language Class Initialized
INFO - 2023-04-18 07:55:21 --> Loader Class Initialized
INFO - 2023-04-18 07:55:21 --> Controller Class Initialized
DEBUG - 2023-04-18 07:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:55:21 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:55:21 --> Final output sent to browser
DEBUG - 2023-04-18 07:55:21 --> Total execution time: 0.0549
INFO - 2023-04-18 07:55:23 --> Config Class Initialized
INFO - 2023-04-18 07:55:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:55:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:55:23 --> Utf8 Class Initialized
INFO - 2023-04-18 07:55:23 --> URI Class Initialized
INFO - 2023-04-18 07:55:23 --> Router Class Initialized
INFO - 2023-04-18 07:55:23 --> Output Class Initialized
INFO - 2023-04-18 07:55:23 --> Security Class Initialized
DEBUG - 2023-04-18 07:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:55:23 --> Input Class Initialized
INFO - 2023-04-18 07:55:23 --> Language Class Initialized
INFO - 2023-04-18 07:55:23 --> Loader Class Initialized
INFO - 2023-04-18 07:55:23 --> Controller Class Initialized
DEBUG - 2023-04-18 07:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:55:23 --> Final output sent to browser
DEBUG - 2023-04-18 07:55:23 --> Total execution time: 0.0121
INFO - 2023-04-18 07:55:23 --> Config Class Initialized
INFO - 2023-04-18 07:55:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:55:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:55:23 --> Utf8 Class Initialized
INFO - 2023-04-18 07:55:23 --> URI Class Initialized
INFO - 2023-04-18 07:55:23 --> Router Class Initialized
INFO - 2023-04-18 07:55:23 --> Output Class Initialized
INFO - 2023-04-18 07:55:23 --> Security Class Initialized
DEBUG - 2023-04-18 07:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:55:23 --> Input Class Initialized
INFO - 2023-04-18 07:55:23 --> Language Class Initialized
INFO - 2023-04-18 07:55:23 --> Loader Class Initialized
INFO - 2023-04-18 07:55:23 --> Controller Class Initialized
DEBUG - 2023-04-18 07:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:23 --> Model "Login_model" initialized
INFO - 2023-04-18 07:55:23 --> Final output sent to browser
DEBUG - 2023-04-18 07:55:23 --> Total execution time: 0.0246
INFO - 2023-04-18 07:55:23 --> Config Class Initialized
INFO - 2023-04-18 07:55:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:55:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:55:23 --> Utf8 Class Initialized
INFO - 2023-04-18 07:55:23 --> URI Class Initialized
INFO - 2023-04-18 07:55:23 --> Router Class Initialized
INFO - 2023-04-18 07:55:23 --> Output Class Initialized
INFO - 2023-04-18 07:55:23 --> Security Class Initialized
DEBUG - 2023-04-18 07:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:55:23 --> Input Class Initialized
INFO - 2023-04-18 07:55:23 --> Language Class Initialized
INFO - 2023-04-18 07:55:23 --> Loader Class Initialized
INFO - 2023-04-18 07:55:23 --> Controller Class Initialized
DEBUG - 2023-04-18 07:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:55:23 --> Final output sent to browser
DEBUG - 2023-04-18 07:55:23 --> Total execution time: 0.0499
INFO - 2023-04-18 07:55:23 --> Config Class Initialized
INFO - 2023-04-18 07:55:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:55:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:55:23 --> Utf8 Class Initialized
INFO - 2023-04-18 07:55:23 --> URI Class Initialized
INFO - 2023-04-18 07:55:23 --> Router Class Initialized
INFO - 2023-04-18 07:55:23 --> Output Class Initialized
INFO - 2023-04-18 07:55:23 --> Security Class Initialized
DEBUG - 2023-04-18 07:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:55:23 --> Input Class Initialized
INFO - 2023-04-18 07:55:23 --> Language Class Initialized
INFO - 2023-04-18 07:55:23 --> Loader Class Initialized
INFO - 2023-04-18 07:55:23 --> Controller Class Initialized
DEBUG - 2023-04-18 07:55:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:55:23 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:23 --> Model "Login_model" initialized
INFO - 2023-04-18 07:55:23 --> Final output sent to browser
DEBUG - 2023-04-18 07:55:23 --> Total execution time: 0.0195
INFO - 2023-04-18 07:55:27 --> Config Class Initialized
INFO - 2023-04-18 07:55:27 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:55:27 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:55:27 --> Utf8 Class Initialized
INFO - 2023-04-18 07:55:27 --> URI Class Initialized
INFO - 2023-04-18 07:55:27 --> Router Class Initialized
INFO - 2023-04-18 07:55:27 --> Output Class Initialized
INFO - 2023-04-18 07:55:27 --> Security Class Initialized
DEBUG - 2023-04-18 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:55:27 --> Input Class Initialized
INFO - 2023-04-18 07:55:27 --> Language Class Initialized
INFO - 2023-04-18 07:55:27 --> Loader Class Initialized
INFO - 2023-04-18 07:55:27 --> Controller Class Initialized
DEBUG - 2023-04-18 07:55:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:55:27 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:27 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:55:27 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:27 --> Model "Login_model" initialized
INFO - 2023-04-18 07:55:27 --> Final output sent to browser
DEBUG - 2023-04-18 07:55:27 --> Total execution time: 0.0912
INFO - 2023-04-18 07:55:27 --> Config Class Initialized
INFO - 2023-04-18 07:55:27 --> Hooks Class Initialized
DEBUG - 2023-04-18 07:55:27 --> UTF-8 Support Enabled
INFO - 2023-04-18 07:55:27 --> Utf8 Class Initialized
INFO - 2023-04-18 07:55:27 --> URI Class Initialized
INFO - 2023-04-18 07:55:27 --> Router Class Initialized
INFO - 2023-04-18 07:55:27 --> Output Class Initialized
INFO - 2023-04-18 07:55:27 --> Security Class Initialized
DEBUG - 2023-04-18 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 07:55:27 --> Input Class Initialized
INFO - 2023-04-18 07:55:27 --> Language Class Initialized
INFO - 2023-04-18 07:55:27 --> Loader Class Initialized
INFO - 2023-04-18 07:55:27 --> Controller Class Initialized
DEBUG - 2023-04-18 07:55:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 07:55:27 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:27 --> Model "Cluster_model" initialized
INFO - 2023-04-18 07:55:27 --> Database Driver Class Initialized
INFO - 2023-04-18 07:55:27 --> Model "Login_model" initialized
INFO - 2023-04-18 07:55:27 --> Final output sent to browser
DEBUG - 2023-04-18 07:55:27 --> Total execution time: 0.0622
INFO - 2023-04-18 08:12:40 --> Config Class Initialized
INFO - 2023-04-18 08:12:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:12:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:12:40 --> Utf8 Class Initialized
INFO - 2023-04-18 08:12:40 --> URI Class Initialized
INFO - 2023-04-18 08:12:40 --> Router Class Initialized
INFO - 2023-04-18 08:12:40 --> Output Class Initialized
INFO - 2023-04-18 08:12:40 --> Security Class Initialized
DEBUG - 2023-04-18 08:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:12:40 --> Input Class Initialized
INFO - 2023-04-18 08:12:40 --> Language Class Initialized
INFO - 2023-04-18 08:12:40 --> Loader Class Initialized
INFO - 2023-04-18 08:12:40 --> Controller Class Initialized
DEBUG - 2023-04-18 08:12:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:12:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:12:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:12:40 --> Final output sent to browser
DEBUG - 2023-04-18 08:12:40 --> Total execution time: 0.0816
INFO - 2023-04-18 08:14:09 --> Config Class Initialized
INFO - 2023-04-18 08:14:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:14:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:14:09 --> Utf8 Class Initialized
INFO - 2023-04-18 08:14:09 --> URI Class Initialized
INFO - 2023-04-18 08:14:09 --> Router Class Initialized
INFO - 2023-04-18 08:14:09 --> Output Class Initialized
INFO - 2023-04-18 08:14:09 --> Security Class Initialized
DEBUG - 2023-04-18 08:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:14:09 --> Input Class Initialized
INFO - 2023-04-18 08:14:09 --> Language Class Initialized
INFO - 2023-04-18 08:14:09 --> Loader Class Initialized
INFO - 2023-04-18 08:14:09 --> Controller Class Initialized
DEBUG - 2023-04-18 08:14:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:14:09 --> Database Driver Class Initialized
INFO - 2023-04-18 08:14:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:14:09 --> Final output sent to browser
DEBUG - 2023-04-18 08:14:09 --> Total execution time: 0.0779
INFO - 2023-04-18 08:14:11 --> Config Class Initialized
INFO - 2023-04-18 08:14:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:14:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:14:11 --> Utf8 Class Initialized
INFO - 2023-04-18 08:14:11 --> URI Class Initialized
INFO - 2023-04-18 08:14:11 --> Router Class Initialized
INFO - 2023-04-18 08:14:11 --> Output Class Initialized
INFO - 2023-04-18 08:14:11 --> Security Class Initialized
DEBUG - 2023-04-18 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:14:11 --> Input Class Initialized
INFO - 2023-04-18 08:14:11 --> Language Class Initialized
INFO - 2023-04-18 08:14:11 --> Loader Class Initialized
INFO - 2023-04-18 08:14:11 --> Controller Class Initialized
DEBUG - 2023-04-18 08:14:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:14:11 --> Database Driver Class Initialized
INFO - 2023-04-18 08:14:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:14:12 --> Final output sent to browser
DEBUG - 2023-04-18 08:14:12 --> Total execution time: 0.0793
INFO - 2023-04-18 08:15:04 --> Config Class Initialized
INFO - 2023-04-18 08:15:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:15:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:15:04 --> Utf8 Class Initialized
INFO - 2023-04-18 08:15:04 --> URI Class Initialized
INFO - 2023-04-18 08:15:04 --> Router Class Initialized
INFO - 2023-04-18 08:15:04 --> Output Class Initialized
INFO - 2023-04-18 08:15:04 --> Security Class Initialized
DEBUG - 2023-04-18 08:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:15:04 --> Input Class Initialized
INFO - 2023-04-18 08:15:04 --> Language Class Initialized
INFO - 2023-04-18 08:15:04 --> Loader Class Initialized
INFO - 2023-04-18 08:15:04 --> Controller Class Initialized
DEBUG - 2023-04-18 08:15:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:15:04 --> Database Driver Class Initialized
INFO - 2023-04-18 08:15:04 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:15:04 --> Final output sent to browser
DEBUG - 2023-04-18 08:15:04 --> Total execution time: 0.0721
INFO - 2023-04-18 08:15:20 --> Config Class Initialized
INFO - 2023-04-18 08:15:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:15:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:15:20 --> Utf8 Class Initialized
INFO - 2023-04-18 08:15:20 --> URI Class Initialized
INFO - 2023-04-18 08:15:20 --> Router Class Initialized
INFO - 2023-04-18 08:15:20 --> Output Class Initialized
INFO - 2023-04-18 08:15:20 --> Security Class Initialized
DEBUG - 2023-04-18 08:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:15:20 --> Input Class Initialized
INFO - 2023-04-18 08:15:20 --> Language Class Initialized
INFO - 2023-04-18 08:15:20 --> Loader Class Initialized
INFO - 2023-04-18 08:15:20 --> Controller Class Initialized
DEBUG - 2023-04-18 08:15:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:15:20 --> Database Driver Class Initialized
INFO - 2023-04-18 08:15:20 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:15:20 --> Final output sent to browser
DEBUG - 2023-04-18 08:15:20 --> Total execution time: 0.0770
INFO - 2023-04-18 08:15:32 --> Config Class Initialized
INFO - 2023-04-18 08:15:32 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:15:32 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:15:32 --> Utf8 Class Initialized
INFO - 2023-04-18 08:15:32 --> URI Class Initialized
INFO - 2023-04-18 08:15:32 --> Router Class Initialized
INFO - 2023-04-18 08:15:32 --> Output Class Initialized
INFO - 2023-04-18 08:15:32 --> Security Class Initialized
DEBUG - 2023-04-18 08:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:15:32 --> Input Class Initialized
INFO - 2023-04-18 08:15:32 --> Language Class Initialized
INFO - 2023-04-18 08:15:32 --> Loader Class Initialized
INFO - 2023-04-18 08:15:32 --> Controller Class Initialized
DEBUG - 2023-04-18 08:15:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:15:32 --> Database Driver Class Initialized
INFO - 2023-04-18 08:15:32 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:15:32 --> Final output sent to browser
DEBUG - 2023-04-18 08:15:32 --> Total execution time: 0.1130
INFO - 2023-04-18 08:15:52 --> Config Class Initialized
INFO - 2023-04-18 08:15:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:15:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:15:52 --> Utf8 Class Initialized
INFO - 2023-04-18 08:15:52 --> URI Class Initialized
INFO - 2023-04-18 08:15:52 --> Router Class Initialized
INFO - 2023-04-18 08:15:52 --> Output Class Initialized
INFO - 2023-04-18 08:15:52 --> Security Class Initialized
DEBUG - 2023-04-18 08:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:15:52 --> Input Class Initialized
INFO - 2023-04-18 08:15:52 --> Language Class Initialized
INFO - 2023-04-18 08:15:52 --> Loader Class Initialized
INFO - 2023-04-18 08:15:52 --> Controller Class Initialized
DEBUG - 2023-04-18 08:15:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:15:52 --> Database Driver Class Initialized
INFO - 2023-04-18 08:15:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:15:52 --> Final output sent to browser
DEBUG - 2023-04-18 08:15:52 --> Total execution time: 0.0779
INFO - 2023-04-18 08:15:54 --> Config Class Initialized
INFO - 2023-04-18 08:15:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:15:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:15:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:15:54 --> URI Class Initialized
INFO - 2023-04-18 08:15:54 --> Router Class Initialized
INFO - 2023-04-18 08:15:54 --> Output Class Initialized
INFO - 2023-04-18 08:15:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:15:54 --> Input Class Initialized
INFO - 2023-04-18 08:15:54 --> Language Class Initialized
INFO - 2023-04-18 08:15:54 --> Loader Class Initialized
INFO - 2023-04-18 08:15:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:15:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:15:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:15:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:15:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:15:54 --> Total execution time: 0.0623
INFO - 2023-04-18 08:15:56 --> Config Class Initialized
INFO - 2023-04-18 08:15:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:15:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:15:56 --> Utf8 Class Initialized
INFO - 2023-04-18 08:15:56 --> URI Class Initialized
INFO - 2023-04-18 08:15:56 --> Router Class Initialized
INFO - 2023-04-18 08:15:56 --> Output Class Initialized
INFO - 2023-04-18 08:15:56 --> Security Class Initialized
DEBUG - 2023-04-18 08:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:15:56 --> Input Class Initialized
INFO - 2023-04-18 08:15:56 --> Language Class Initialized
INFO - 2023-04-18 08:15:56 --> Loader Class Initialized
INFO - 2023-04-18 08:15:56 --> Controller Class Initialized
DEBUG - 2023-04-18 08:15:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:15:56 --> Database Driver Class Initialized
INFO - 2023-04-18 08:15:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:15:56 --> Final output sent to browser
DEBUG - 2023-04-18 08:15:56 --> Total execution time: 0.0788
INFO - 2023-04-18 08:16:34 --> Config Class Initialized
INFO - 2023-04-18 08:16:34 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:16:34 --> Utf8 Class Initialized
INFO - 2023-04-18 08:16:34 --> URI Class Initialized
INFO - 2023-04-18 08:16:34 --> Router Class Initialized
INFO - 2023-04-18 08:16:34 --> Output Class Initialized
INFO - 2023-04-18 08:16:34 --> Security Class Initialized
DEBUG - 2023-04-18 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:16:34 --> Input Class Initialized
INFO - 2023-04-18 08:16:34 --> Language Class Initialized
INFO - 2023-04-18 08:16:34 --> Loader Class Initialized
INFO - 2023-04-18 08:16:34 --> Controller Class Initialized
DEBUG - 2023-04-18 08:16:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:16:34 --> Database Driver Class Initialized
INFO - 2023-04-18 08:16:34 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:16:34 --> Final output sent to browser
DEBUG - 2023-04-18 08:16:34 --> Total execution time: 0.0715
INFO - 2023-04-18 08:17:21 --> Config Class Initialized
INFO - 2023-04-18 08:17:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:17:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:17:21 --> Utf8 Class Initialized
INFO - 2023-04-18 08:17:21 --> URI Class Initialized
INFO - 2023-04-18 08:17:21 --> Router Class Initialized
INFO - 2023-04-18 08:17:21 --> Output Class Initialized
INFO - 2023-04-18 08:17:21 --> Security Class Initialized
DEBUG - 2023-04-18 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:17:21 --> Input Class Initialized
INFO - 2023-04-18 08:17:21 --> Language Class Initialized
INFO - 2023-04-18 08:17:21 --> Loader Class Initialized
INFO - 2023-04-18 08:17:21 --> Controller Class Initialized
DEBUG - 2023-04-18 08:17:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:17:21 --> Database Driver Class Initialized
INFO - 2023-04-18 08:17:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:17:21 --> Final output sent to browser
DEBUG - 2023-04-18 08:17:21 --> Total execution time: 0.0722
INFO - 2023-04-18 08:17:38 --> Config Class Initialized
INFO - 2023-04-18 08:17:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:17:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:17:38 --> Utf8 Class Initialized
INFO - 2023-04-18 08:17:38 --> URI Class Initialized
INFO - 2023-04-18 08:17:38 --> Router Class Initialized
INFO - 2023-04-18 08:17:38 --> Output Class Initialized
INFO - 2023-04-18 08:17:38 --> Security Class Initialized
DEBUG - 2023-04-18 08:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:17:38 --> Input Class Initialized
INFO - 2023-04-18 08:17:38 --> Language Class Initialized
INFO - 2023-04-18 08:17:38 --> Loader Class Initialized
INFO - 2023-04-18 08:17:38 --> Controller Class Initialized
DEBUG - 2023-04-18 08:17:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:17:38 --> Database Driver Class Initialized
INFO - 2023-04-18 08:17:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:17:38 --> Final output sent to browser
DEBUG - 2023-04-18 08:17:38 --> Total execution time: 0.1013
INFO - 2023-04-18 08:17:59 --> Config Class Initialized
INFO - 2023-04-18 08:17:59 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:17:59 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:17:59 --> Utf8 Class Initialized
INFO - 2023-04-18 08:17:59 --> URI Class Initialized
INFO - 2023-04-18 08:17:59 --> Router Class Initialized
INFO - 2023-04-18 08:17:59 --> Output Class Initialized
INFO - 2023-04-18 08:17:59 --> Security Class Initialized
DEBUG - 2023-04-18 08:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:17:59 --> Input Class Initialized
INFO - 2023-04-18 08:17:59 --> Language Class Initialized
INFO - 2023-04-18 08:17:59 --> Loader Class Initialized
INFO - 2023-04-18 08:17:59 --> Controller Class Initialized
DEBUG - 2023-04-18 08:17:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:17:59 --> Database Driver Class Initialized
INFO - 2023-04-18 08:17:59 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:17:59 --> Database Driver Class Initialized
INFO - 2023-04-18 08:17:59 --> Model "Login_model" initialized
INFO - 2023-04-18 08:17:59 --> Final output sent to browser
DEBUG - 2023-04-18 08:17:59 --> Total execution time: 0.1862
INFO - 2023-04-18 08:17:59 --> Config Class Initialized
INFO - 2023-04-18 08:17:59 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:17:59 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:17:59 --> Utf8 Class Initialized
INFO - 2023-04-18 08:17:59 --> URI Class Initialized
INFO - 2023-04-18 08:17:59 --> Router Class Initialized
INFO - 2023-04-18 08:17:59 --> Output Class Initialized
INFO - 2023-04-18 08:17:59 --> Security Class Initialized
DEBUG - 2023-04-18 08:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:17:59 --> Input Class Initialized
INFO - 2023-04-18 08:17:59 --> Language Class Initialized
INFO - 2023-04-18 08:17:59 --> Loader Class Initialized
INFO - 2023-04-18 08:17:59 --> Controller Class Initialized
DEBUG - 2023-04-18 08:17:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:17:59 --> Database Driver Class Initialized
INFO - 2023-04-18 08:17:59 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:17:59 --> Database Driver Class Initialized
INFO - 2023-04-18 08:17:59 --> Model "Login_model" initialized
INFO - 2023-04-18 08:17:59 --> Final output sent to browser
DEBUG - 2023-04-18 08:17:59 --> Total execution time: 0.1508
INFO - 2023-04-18 08:19:52 --> Config Class Initialized
INFO - 2023-04-18 08:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:52 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:52 --> URI Class Initialized
INFO - 2023-04-18 08:19:52 --> Router Class Initialized
INFO - 2023-04-18 08:19:52 --> Output Class Initialized
INFO - 2023-04-18 08:19:52 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:52 --> Input Class Initialized
INFO - 2023-04-18 08:19:52 --> Language Class Initialized
INFO - 2023-04-18 08:19:52 --> Loader Class Initialized
INFO - 2023-04-18 08:19:52 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:52 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:52 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:52 --> Total execution time: 0.0152
INFO - 2023-04-18 08:19:52 --> Config Class Initialized
INFO - 2023-04-18 08:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:52 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:52 --> URI Class Initialized
INFO - 2023-04-18 08:19:52 --> Router Class Initialized
INFO - 2023-04-18 08:19:52 --> Output Class Initialized
INFO - 2023-04-18 08:19:52 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:52 --> Input Class Initialized
INFO - 2023-04-18 08:19:52 --> Language Class Initialized
INFO - 2023-04-18 08:19:52 --> Loader Class Initialized
INFO - 2023-04-18 08:19:52 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:52 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:52 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:52 --> Total execution time: 0.0573
INFO - 2023-04-18 08:19:52 --> Config Class Initialized
INFO - 2023-04-18 08:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:52 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:52 --> URI Class Initialized
INFO - 2023-04-18 08:19:52 --> Router Class Initialized
INFO - 2023-04-18 08:19:52 --> Output Class Initialized
INFO - 2023-04-18 08:19:52 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:52 --> Input Class Initialized
INFO - 2023-04-18 08:19:52 --> Language Class Initialized
INFO - 2023-04-18 08:19:52 --> Loader Class Initialized
INFO - 2023-04-18 08:19:52 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:52 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:52 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:52 --> Total execution time: 0.0131
INFO - 2023-04-18 08:19:52 --> Config Class Initialized
INFO - 2023-04-18 08:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:52 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:52 --> URI Class Initialized
INFO - 2023-04-18 08:19:52 --> Router Class Initialized
INFO - 2023-04-18 08:19:52 --> Output Class Initialized
INFO - 2023-04-18 08:19:52 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:52 --> Input Class Initialized
INFO - 2023-04-18 08:19:52 --> Language Class Initialized
INFO - 2023-04-18 08:19:52 --> Loader Class Initialized
INFO - 2023-04-18 08:19:52 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:52 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:52 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:52 --> Total execution time: 0.0138
INFO - 2023-04-18 08:19:53 --> Config Class Initialized
INFO - 2023-04-18 08:19:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:53 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:53 --> URI Class Initialized
INFO - 2023-04-18 08:19:53 --> Router Class Initialized
INFO - 2023-04-18 08:19:53 --> Output Class Initialized
INFO - 2023-04-18 08:19:53 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:53 --> Input Class Initialized
INFO - 2023-04-18 08:19:53 --> Language Class Initialized
INFO - 2023-04-18 08:19:53 --> Loader Class Initialized
INFO - 2023-04-18 08:19:53 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:53 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:53 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:53 --> Total execution time: 0.0489
INFO - 2023-04-18 08:19:53 --> Config Class Initialized
INFO - 2023-04-18 08:19:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:53 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:53 --> URI Class Initialized
INFO - 2023-04-18 08:19:53 --> Router Class Initialized
INFO - 2023-04-18 08:19:53 --> Output Class Initialized
INFO - 2023-04-18 08:19:53 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:53 --> Input Class Initialized
INFO - 2023-04-18 08:19:53 --> Language Class Initialized
INFO - 2023-04-18 08:19:53 --> Loader Class Initialized
INFO - 2023-04-18 08:19:53 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:53 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:53 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:53 --> Total execution time: 0.0823
INFO - 2023-04-18 08:19:55 --> Config Class Initialized
INFO - 2023-04-18 08:19:55 --> Config Class Initialized
INFO - 2023-04-18 08:19:55 --> Hooks Class Initialized
INFO - 2023-04-18 08:19:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:55 --> Utf8 Class Initialized
DEBUG - 2023-04-18 08:19:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:55 --> URI Class Initialized
INFO - 2023-04-18 08:19:55 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:55 --> Router Class Initialized
INFO - 2023-04-18 08:19:55 --> URI Class Initialized
INFO - 2023-04-18 08:19:55 --> Output Class Initialized
INFO - 2023-04-18 08:19:55 --> Router Class Initialized
INFO - 2023-04-18 08:19:55 --> Security Class Initialized
INFO - 2023-04-18 08:19:55 --> Output Class Initialized
DEBUG - 2023-04-18 08:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:55 --> Security Class Initialized
INFO - 2023-04-18 08:19:55 --> Input Class Initialized
DEBUG - 2023-04-18 08:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:55 --> Language Class Initialized
INFO - 2023-04-18 08:19:55 --> Input Class Initialized
INFO - 2023-04-18 08:19:55 --> Language Class Initialized
INFO - 2023-04-18 08:19:55 --> Loader Class Initialized
INFO - 2023-04-18 08:19:55 --> Controller Class Initialized
INFO - 2023-04-18 08:19:55 --> Loader Class Initialized
DEBUG - 2023-04-18 08:19:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:55 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:55 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:55 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:55 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:55 --> Total execution time: 0.0159
INFO - 2023-04-18 08:19:55 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:55 --> Total execution time: 0.0180
INFO - 2023-04-18 08:19:55 --> Config Class Initialized
INFO - 2023-04-18 08:19:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:55 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:55 --> URI Class Initialized
INFO - 2023-04-18 08:19:55 --> Router Class Initialized
INFO - 2023-04-18 08:19:55 --> Output Class Initialized
INFO - 2023-04-18 08:19:55 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:55 --> Input Class Initialized
INFO - 2023-04-18 08:19:55 --> Language Class Initialized
INFO - 2023-04-18 08:19:55 --> Config Class Initialized
INFO - 2023-04-18 08:19:55 --> Hooks Class Initialized
INFO - 2023-04-18 08:19:55 --> Loader Class Initialized
DEBUG - 2023-04-18 08:19:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:55 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:55 --> Controller Class Initialized
INFO - 2023-04-18 08:19:55 --> URI Class Initialized
DEBUG - 2023-04-18 08:19:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:55 --> Router Class Initialized
INFO - 2023-04-18 08:19:55 --> Output Class Initialized
INFO - 2023-04-18 08:19:55 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:55 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:55 --> Input Class Initialized
INFO - 2023-04-18 08:19:55 --> Language Class Initialized
INFO - 2023-04-18 08:19:55 --> Loader Class Initialized
INFO - 2023-04-18 08:19:55 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:55 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:55 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:55 --> Total execution time: 0.0161
INFO - 2023-04-18 08:19:55 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:55 --> Total execution time: 0.0167
INFO - 2023-04-18 08:19:56 --> Config Class Initialized
INFO - 2023-04-18 08:19:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:56 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:56 --> URI Class Initialized
INFO - 2023-04-18 08:19:56 --> Router Class Initialized
INFO - 2023-04-18 08:19:56 --> Output Class Initialized
INFO - 2023-04-18 08:19:56 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:56 --> Input Class Initialized
INFO - 2023-04-18 08:19:56 --> Language Class Initialized
INFO - 2023-04-18 08:19:56 --> Loader Class Initialized
INFO - 2023-04-18 08:19:56 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:56 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:56 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:56 --> Total execution time: 0.0236
INFO - 2023-04-18 08:19:56 --> Config Class Initialized
INFO - 2023-04-18 08:19:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:19:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:19:56 --> Utf8 Class Initialized
INFO - 2023-04-18 08:19:56 --> URI Class Initialized
INFO - 2023-04-18 08:19:56 --> Router Class Initialized
INFO - 2023-04-18 08:19:56 --> Output Class Initialized
INFO - 2023-04-18 08:19:56 --> Security Class Initialized
DEBUG - 2023-04-18 08:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:19:56 --> Input Class Initialized
INFO - 2023-04-18 08:19:56 --> Language Class Initialized
INFO - 2023-04-18 08:19:56 --> Loader Class Initialized
INFO - 2023-04-18 08:19:56 --> Controller Class Initialized
DEBUG - 2023-04-18 08:19:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:19:56 --> Database Driver Class Initialized
INFO - 2023-04-18 08:19:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:19:56 --> Final output sent to browser
DEBUG - 2023-04-18 08:19:56 --> Total execution time: 0.0178
INFO - 2023-04-18 08:20:00 --> Config Class Initialized
INFO - 2023-04-18 08:20:00 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:20:00 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:20:00 --> Utf8 Class Initialized
INFO - 2023-04-18 08:20:00 --> URI Class Initialized
INFO - 2023-04-18 08:20:00 --> Router Class Initialized
INFO - 2023-04-18 08:20:00 --> Output Class Initialized
INFO - 2023-04-18 08:20:00 --> Security Class Initialized
DEBUG - 2023-04-18 08:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:20:00 --> Input Class Initialized
INFO - 2023-04-18 08:20:00 --> Language Class Initialized
INFO - 2023-04-18 08:20:00 --> Loader Class Initialized
INFO - 2023-04-18 08:20:00 --> Controller Class Initialized
DEBUG - 2023-04-18 08:20:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:20:00 --> Database Driver Class Initialized
INFO - 2023-04-18 08:20:00 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:20:00 --> Final output sent to browser
DEBUG - 2023-04-18 08:20:00 --> Total execution time: 0.0372
INFO - 2023-04-18 08:20:00 --> Config Class Initialized
INFO - 2023-04-18 08:20:00 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:20:00 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:20:00 --> Utf8 Class Initialized
INFO - 2023-04-18 08:20:00 --> URI Class Initialized
INFO - 2023-04-18 08:20:00 --> Router Class Initialized
INFO - 2023-04-18 08:20:00 --> Output Class Initialized
INFO - 2023-04-18 08:20:00 --> Security Class Initialized
DEBUG - 2023-04-18 08:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:20:00 --> Input Class Initialized
INFO - 2023-04-18 08:20:00 --> Language Class Initialized
INFO - 2023-04-18 08:20:00 --> Loader Class Initialized
INFO - 2023-04-18 08:20:00 --> Controller Class Initialized
DEBUG - 2023-04-18 08:20:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:20:00 --> Database Driver Class Initialized
INFO - 2023-04-18 08:20:00 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:20:00 --> Final output sent to browser
DEBUG - 2023-04-18 08:20:00 --> Total execution time: 0.0136
INFO - 2023-04-18 08:20:01 --> Config Class Initialized
INFO - 2023-04-18 08:20:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:20:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:20:01 --> Utf8 Class Initialized
INFO - 2023-04-18 08:20:01 --> URI Class Initialized
INFO - 2023-04-18 08:20:01 --> Router Class Initialized
INFO - 2023-04-18 08:20:01 --> Output Class Initialized
INFO - 2023-04-18 08:20:01 --> Security Class Initialized
DEBUG - 2023-04-18 08:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:20:01 --> Input Class Initialized
INFO - 2023-04-18 08:20:01 --> Language Class Initialized
INFO - 2023-04-18 08:20:01 --> Loader Class Initialized
INFO - 2023-04-18 08:20:01 --> Controller Class Initialized
DEBUG - 2023-04-18 08:20:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:20:01 --> Database Driver Class Initialized
INFO - 2023-04-18 08:20:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:20:01 --> Final output sent to browser
DEBUG - 2023-04-18 08:20:01 --> Total execution time: 0.0188
INFO - 2023-04-18 08:20:01 --> Config Class Initialized
INFO - 2023-04-18 08:20:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:20:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:20:01 --> Utf8 Class Initialized
INFO - 2023-04-18 08:20:01 --> URI Class Initialized
INFO - 2023-04-18 08:20:01 --> Router Class Initialized
INFO - 2023-04-18 08:20:01 --> Output Class Initialized
INFO - 2023-04-18 08:20:01 --> Security Class Initialized
DEBUG - 2023-04-18 08:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:20:01 --> Input Class Initialized
INFO - 2023-04-18 08:20:01 --> Language Class Initialized
INFO - 2023-04-18 08:20:01 --> Loader Class Initialized
INFO - 2023-04-18 08:20:01 --> Controller Class Initialized
DEBUG - 2023-04-18 08:20:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:20:01 --> Database Driver Class Initialized
INFO - 2023-04-18 08:20:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:20:01 --> Final output sent to browser
DEBUG - 2023-04-18 08:20:01 --> Total execution time: 0.0136
INFO - 2023-04-18 08:20:04 --> Config Class Initialized
INFO - 2023-04-18 08:20:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:20:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:20:04 --> Utf8 Class Initialized
INFO - 2023-04-18 08:20:04 --> URI Class Initialized
INFO - 2023-04-18 08:20:04 --> Router Class Initialized
INFO - 2023-04-18 08:20:04 --> Output Class Initialized
INFO - 2023-04-18 08:20:04 --> Security Class Initialized
DEBUG - 2023-04-18 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:20:04 --> Input Class Initialized
INFO - 2023-04-18 08:20:04 --> Language Class Initialized
INFO - 2023-04-18 08:20:04 --> Loader Class Initialized
INFO - 2023-04-18 08:20:04 --> Controller Class Initialized
DEBUG - 2023-04-18 08:20:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:20:04 --> Database Driver Class Initialized
INFO - 2023-04-18 08:20:04 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:20:04 --> Final output sent to browser
DEBUG - 2023-04-18 08:20:04 --> Total execution time: 0.0293
INFO - 2023-04-18 08:20:04 --> Config Class Initialized
INFO - 2023-04-18 08:20:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:20:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:20:04 --> Utf8 Class Initialized
INFO - 2023-04-18 08:20:04 --> URI Class Initialized
INFO - 2023-04-18 08:20:04 --> Router Class Initialized
INFO - 2023-04-18 08:20:04 --> Output Class Initialized
INFO - 2023-04-18 08:20:04 --> Security Class Initialized
DEBUG - 2023-04-18 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:20:04 --> Input Class Initialized
INFO - 2023-04-18 08:20:04 --> Language Class Initialized
INFO - 2023-04-18 08:20:04 --> Loader Class Initialized
INFO - 2023-04-18 08:20:04 --> Controller Class Initialized
DEBUG - 2023-04-18 08:20:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:20:04 --> Database Driver Class Initialized
INFO - 2023-04-18 08:20:04 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:20:04 --> Final output sent to browser
DEBUG - 2023-04-18 08:20:04 --> Total execution time: 0.0188
INFO - 2023-04-18 08:21:41 --> Config Class Initialized
INFO - 2023-04-18 08:21:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:21:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:21:41 --> Utf8 Class Initialized
INFO - 2023-04-18 08:21:41 --> URI Class Initialized
INFO - 2023-04-18 08:21:41 --> Router Class Initialized
INFO - 2023-04-18 08:21:41 --> Output Class Initialized
INFO - 2023-04-18 08:21:41 --> Security Class Initialized
DEBUG - 2023-04-18 08:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:21:41 --> Input Class Initialized
INFO - 2023-04-18 08:21:41 --> Language Class Initialized
INFO - 2023-04-18 08:21:41 --> Loader Class Initialized
INFO - 2023-04-18 08:21:41 --> Controller Class Initialized
DEBUG - 2023-04-18 08:21:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:21:41 --> Database Driver Class Initialized
INFO - 2023-04-18 08:21:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:21:41 --> Final output sent to browser
DEBUG - 2023-04-18 08:21:41 --> Total execution time: 0.0242
INFO - 2023-04-18 08:21:41 --> Config Class Initialized
INFO - 2023-04-18 08:21:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:21:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:21:41 --> Utf8 Class Initialized
INFO - 2023-04-18 08:21:41 --> URI Class Initialized
INFO - 2023-04-18 08:21:41 --> Router Class Initialized
INFO - 2023-04-18 08:21:41 --> Output Class Initialized
INFO - 2023-04-18 08:21:41 --> Security Class Initialized
DEBUG - 2023-04-18 08:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:21:41 --> Input Class Initialized
INFO - 2023-04-18 08:21:41 --> Language Class Initialized
INFO - 2023-04-18 08:21:41 --> Loader Class Initialized
INFO - 2023-04-18 08:21:41 --> Controller Class Initialized
DEBUG - 2023-04-18 08:21:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:21:41 --> Database Driver Class Initialized
INFO - 2023-04-18 08:21:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:21:41 --> Final output sent to browser
DEBUG - 2023-04-18 08:21:41 --> Total execution time: 0.0226
INFO - 2023-04-18 08:23:38 --> Config Class Initialized
INFO - 2023-04-18 08:23:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:23:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:23:38 --> Utf8 Class Initialized
INFO - 2023-04-18 08:23:38 --> URI Class Initialized
INFO - 2023-04-18 08:23:38 --> Router Class Initialized
INFO - 2023-04-18 08:23:38 --> Output Class Initialized
INFO - 2023-04-18 08:23:38 --> Security Class Initialized
DEBUG - 2023-04-18 08:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:23:38 --> Input Class Initialized
INFO - 2023-04-18 08:23:38 --> Language Class Initialized
INFO - 2023-04-18 08:23:38 --> Loader Class Initialized
INFO - 2023-04-18 08:23:38 --> Controller Class Initialized
DEBUG - 2023-04-18 08:23:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:23:38 --> Database Driver Class Initialized
INFO - 2023-04-18 08:23:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:23:38 --> Database Driver Class Initialized
INFO - 2023-04-18 08:23:38 --> Model "Login_model" initialized
INFO - 2023-04-18 08:23:38 --> Final output sent to browser
DEBUG - 2023-04-18 08:23:38 --> Total execution time: 0.1757
INFO - 2023-04-18 08:23:38 --> Config Class Initialized
INFO - 2023-04-18 08:23:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:23:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:23:38 --> Utf8 Class Initialized
INFO - 2023-04-18 08:23:38 --> URI Class Initialized
INFO - 2023-04-18 08:23:38 --> Router Class Initialized
INFO - 2023-04-18 08:23:38 --> Output Class Initialized
INFO - 2023-04-18 08:23:38 --> Security Class Initialized
DEBUG - 2023-04-18 08:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:23:38 --> Input Class Initialized
INFO - 2023-04-18 08:23:38 --> Language Class Initialized
INFO - 2023-04-18 08:23:38 --> Loader Class Initialized
INFO - 2023-04-18 08:23:38 --> Controller Class Initialized
DEBUG - 2023-04-18 08:23:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:23:38 --> Database Driver Class Initialized
INFO - 2023-04-18 08:23:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:23:38 --> Database Driver Class Initialized
INFO - 2023-04-18 08:23:38 --> Model "Login_model" initialized
INFO - 2023-04-18 08:23:38 --> Final output sent to browser
DEBUG - 2023-04-18 08:23:38 --> Total execution time: 0.1695
INFO - 2023-04-18 08:23:43 --> Config Class Initialized
INFO - 2023-04-18 08:23:43 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:23:43 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:23:43 --> Utf8 Class Initialized
INFO - 2023-04-18 08:23:43 --> URI Class Initialized
INFO - 2023-04-18 08:23:43 --> Router Class Initialized
INFO - 2023-04-18 08:23:43 --> Output Class Initialized
INFO - 2023-04-18 08:23:43 --> Security Class Initialized
DEBUG - 2023-04-18 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:23:43 --> Input Class Initialized
INFO - 2023-04-18 08:23:43 --> Language Class Initialized
INFO - 2023-04-18 08:23:43 --> Loader Class Initialized
INFO - 2023-04-18 08:23:43 --> Controller Class Initialized
DEBUG - 2023-04-18 08:23:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:23:43 --> Database Driver Class Initialized
INFO - 2023-04-18 08:23:43 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:23:43 --> Final output sent to browser
DEBUG - 2023-04-18 08:23:43 --> Total execution time: 0.0318
INFO - 2023-04-18 08:23:43 --> Config Class Initialized
INFO - 2023-04-18 08:23:43 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:23:43 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:23:43 --> Utf8 Class Initialized
INFO - 2023-04-18 08:23:43 --> URI Class Initialized
INFO - 2023-04-18 08:23:43 --> Router Class Initialized
INFO - 2023-04-18 08:23:43 --> Output Class Initialized
INFO - 2023-04-18 08:23:43 --> Security Class Initialized
DEBUG - 2023-04-18 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:23:43 --> Input Class Initialized
INFO - 2023-04-18 08:23:43 --> Language Class Initialized
INFO - 2023-04-18 08:23:43 --> Loader Class Initialized
INFO - 2023-04-18 08:23:43 --> Controller Class Initialized
DEBUG - 2023-04-18 08:23:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:23:43 --> Database Driver Class Initialized
INFO - 2023-04-18 08:23:43 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:23:43 --> Final output sent to browser
DEBUG - 2023-04-18 08:23:43 --> Total execution time: 0.0193
INFO - 2023-04-18 08:25:04 --> Config Class Initialized
INFO - 2023-04-18 08:25:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:04 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:04 --> URI Class Initialized
INFO - 2023-04-18 08:25:04 --> Router Class Initialized
INFO - 2023-04-18 08:25:04 --> Output Class Initialized
INFO - 2023-04-18 08:25:04 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:04 --> Input Class Initialized
INFO - 2023-04-18 08:25:04 --> Language Class Initialized
INFO - 2023-04-18 08:25:04 --> Loader Class Initialized
INFO - 2023-04-18 08:25:04 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:04 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:04 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:04 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:04 --> Model "Login_model" initialized
INFO - 2023-04-18 08:25:04 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:04 --> Total execution time: 0.1837
INFO - 2023-04-18 08:25:04 --> Config Class Initialized
INFO - 2023-04-18 08:25:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:04 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:04 --> URI Class Initialized
INFO - 2023-04-18 08:25:04 --> Router Class Initialized
INFO - 2023-04-18 08:25:04 --> Output Class Initialized
INFO - 2023-04-18 08:25:04 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:04 --> Input Class Initialized
INFO - 2023-04-18 08:25:04 --> Language Class Initialized
INFO - 2023-04-18 08:25:04 --> Loader Class Initialized
INFO - 2023-04-18 08:25:04 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:04 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:04 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:04 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:04 --> Model "Login_model" initialized
INFO - 2023-04-18 08:25:04 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:04 --> Total execution time: 0.0669
INFO - 2023-04-18 08:25:08 --> Config Class Initialized
INFO - 2023-04-18 08:25:08 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:08 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:08 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:08 --> URI Class Initialized
INFO - 2023-04-18 08:25:08 --> Router Class Initialized
INFO - 2023-04-18 08:25:08 --> Output Class Initialized
INFO - 2023-04-18 08:25:08 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:08 --> Input Class Initialized
INFO - 2023-04-18 08:25:08 --> Language Class Initialized
INFO - 2023-04-18 08:25:08 --> Loader Class Initialized
INFO - 2023-04-18 08:25:08 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:08 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:08 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:08 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:08 --> Total execution time: 0.0496
INFO - 2023-04-18 08:25:08 --> Config Class Initialized
INFO - 2023-04-18 08:25:08 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:08 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:08 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:08 --> URI Class Initialized
INFO - 2023-04-18 08:25:08 --> Router Class Initialized
INFO - 2023-04-18 08:25:08 --> Output Class Initialized
INFO - 2023-04-18 08:25:08 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:08 --> Input Class Initialized
INFO - 2023-04-18 08:25:08 --> Language Class Initialized
INFO - 2023-04-18 08:25:08 --> Loader Class Initialized
INFO - 2023-04-18 08:25:08 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:08 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:08 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:08 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:08 --> Total execution time: 0.0446
INFO - 2023-04-18 08:25:09 --> Config Class Initialized
INFO - 2023-04-18 08:25:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:09 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:09 --> URI Class Initialized
INFO - 2023-04-18 08:25:09 --> Router Class Initialized
INFO - 2023-04-18 08:25:09 --> Output Class Initialized
INFO - 2023-04-18 08:25:09 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:09 --> Input Class Initialized
INFO - 2023-04-18 08:25:09 --> Language Class Initialized
INFO - 2023-04-18 08:25:09 --> Loader Class Initialized
INFO - 2023-04-18 08:25:09 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:09 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:09 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:09 --> Total execution time: 0.0227
INFO - 2023-04-18 08:25:09 --> Config Class Initialized
INFO - 2023-04-18 08:25:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:09 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:09 --> URI Class Initialized
INFO - 2023-04-18 08:25:09 --> Router Class Initialized
INFO - 2023-04-18 08:25:09 --> Output Class Initialized
INFO - 2023-04-18 08:25:09 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:09 --> Input Class Initialized
INFO - 2023-04-18 08:25:09 --> Language Class Initialized
INFO - 2023-04-18 08:25:09 --> Loader Class Initialized
INFO - 2023-04-18 08:25:09 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:09 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:09 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:09 --> Total execution time: 0.0213
INFO - 2023-04-18 08:25:29 --> Config Class Initialized
INFO - 2023-04-18 08:25:29 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:29 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:29 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:29 --> URI Class Initialized
INFO - 2023-04-18 08:25:29 --> Router Class Initialized
INFO - 2023-04-18 08:25:29 --> Output Class Initialized
INFO - 2023-04-18 08:25:29 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:29 --> Input Class Initialized
INFO - 2023-04-18 08:25:29 --> Language Class Initialized
INFO - 2023-04-18 08:25:29 --> Loader Class Initialized
INFO - 2023-04-18 08:25:29 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:29 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:29 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:29 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:29 --> Model "Login_model" initialized
INFO - 2023-04-18 08:25:29 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:29 --> Total execution time: 0.1124
INFO - 2023-04-18 08:25:29 --> Config Class Initialized
INFO - 2023-04-18 08:25:29 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:29 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:29 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:29 --> URI Class Initialized
INFO - 2023-04-18 08:25:29 --> Router Class Initialized
INFO - 2023-04-18 08:25:29 --> Output Class Initialized
INFO - 2023-04-18 08:25:29 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:29 --> Input Class Initialized
INFO - 2023-04-18 08:25:29 --> Language Class Initialized
INFO - 2023-04-18 08:25:29 --> Loader Class Initialized
INFO - 2023-04-18 08:25:29 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:29 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:29 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:29 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:29 --> Model "Login_model" initialized
INFO - 2023-04-18 08:25:29 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:29 --> Total execution time: 0.1444
INFO - 2023-04-18 08:25:33 --> Config Class Initialized
INFO - 2023-04-18 08:25:33 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:33 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:33 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:33 --> URI Class Initialized
INFO - 2023-04-18 08:25:33 --> Router Class Initialized
INFO - 2023-04-18 08:25:33 --> Output Class Initialized
INFO - 2023-04-18 08:25:33 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:33 --> Input Class Initialized
INFO - 2023-04-18 08:25:33 --> Language Class Initialized
INFO - 2023-04-18 08:25:33 --> Loader Class Initialized
INFO - 2023-04-18 08:25:33 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:33 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:33 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:33 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:33 --> Total execution time: 0.0265
INFO - 2023-04-18 08:25:33 --> Config Class Initialized
INFO - 2023-04-18 08:25:33 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:33 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:33 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:33 --> URI Class Initialized
INFO - 2023-04-18 08:25:33 --> Router Class Initialized
INFO - 2023-04-18 08:25:33 --> Output Class Initialized
INFO - 2023-04-18 08:25:33 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:33 --> Input Class Initialized
INFO - 2023-04-18 08:25:33 --> Language Class Initialized
INFO - 2023-04-18 08:25:33 --> Loader Class Initialized
INFO - 2023-04-18 08:25:33 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:33 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:33 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:33 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:33 --> Total execution time: 0.0188
INFO - 2023-04-18 08:25:45 --> Config Class Initialized
INFO - 2023-04-18 08:25:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:45 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:45 --> URI Class Initialized
INFO - 2023-04-18 08:25:45 --> Router Class Initialized
INFO - 2023-04-18 08:25:45 --> Output Class Initialized
INFO - 2023-04-18 08:25:45 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:45 --> Input Class Initialized
INFO - 2023-04-18 08:25:45 --> Language Class Initialized
INFO - 2023-04-18 08:25:45 --> Loader Class Initialized
INFO - 2023-04-18 08:25:45 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:45 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:45 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:45 --> Total execution time: 0.0437
INFO - 2023-04-18 08:25:45 --> Config Class Initialized
INFO - 2023-04-18 08:25:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:45 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:45 --> URI Class Initialized
INFO - 2023-04-18 08:25:45 --> Router Class Initialized
INFO - 2023-04-18 08:25:45 --> Output Class Initialized
INFO - 2023-04-18 08:25:45 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:45 --> Input Class Initialized
INFO - 2023-04-18 08:25:45 --> Language Class Initialized
INFO - 2023-04-18 08:25:45 --> Loader Class Initialized
INFO - 2023-04-18 08:25:45 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:45 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:45 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:45 --> Total execution time: 0.0351
INFO - 2023-04-18 08:25:47 --> Config Class Initialized
INFO - 2023-04-18 08:25:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:47 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:47 --> URI Class Initialized
INFO - 2023-04-18 08:25:47 --> Router Class Initialized
INFO - 2023-04-18 08:25:47 --> Output Class Initialized
INFO - 2023-04-18 08:25:47 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:47 --> Input Class Initialized
INFO - 2023-04-18 08:25:47 --> Language Class Initialized
INFO - 2023-04-18 08:25:47 --> Loader Class Initialized
INFO - 2023-04-18 08:25:47 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:47 --> Model "Login_model" initialized
INFO - 2023-04-18 08:25:47 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:47 --> Total execution time: 0.0835
INFO - 2023-04-18 08:25:47 --> Config Class Initialized
INFO - 2023-04-18 08:25:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:47 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:47 --> URI Class Initialized
INFO - 2023-04-18 08:25:47 --> Router Class Initialized
INFO - 2023-04-18 08:25:47 --> Output Class Initialized
INFO - 2023-04-18 08:25:47 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:47 --> Input Class Initialized
INFO - 2023-04-18 08:25:47 --> Language Class Initialized
INFO - 2023-04-18 08:25:47 --> Loader Class Initialized
INFO - 2023-04-18 08:25:47 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:47 --> Model "Login_model" initialized
INFO - 2023-04-18 08:25:47 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:47 --> Total execution time: 0.0589
INFO - 2023-04-18 08:25:51 --> Config Class Initialized
INFO - 2023-04-18 08:25:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:51 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:51 --> URI Class Initialized
INFO - 2023-04-18 08:25:51 --> Router Class Initialized
INFO - 2023-04-18 08:25:51 --> Output Class Initialized
INFO - 2023-04-18 08:25:51 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:51 --> Input Class Initialized
INFO - 2023-04-18 08:25:51 --> Language Class Initialized
INFO - 2023-04-18 08:25:51 --> Loader Class Initialized
INFO - 2023-04-18 08:25:51 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:51 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:51 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:51 --> Total execution time: 0.0225
INFO - 2023-04-18 08:25:51 --> Config Class Initialized
INFO - 2023-04-18 08:25:51 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:25:51 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:25:51 --> Utf8 Class Initialized
INFO - 2023-04-18 08:25:51 --> URI Class Initialized
INFO - 2023-04-18 08:25:51 --> Router Class Initialized
INFO - 2023-04-18 08:25:51 --> Output Class Initialized
INFO - 2023-04-18 08:25:51 --> Security Class Initialized
DEBUG - 2023-04-18 08:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:25:51 --> Input Class Initialized
INFO - 2023-04-18 08:25:51 --> Language Class Initialized
INFO - 2023-04-18 08:25:51 --> Loader Class Initialized
INFO - 2023-04-18 08:25:51 --> Controller Class Initialized
DEBUG - 2023-04-18 08:25:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:25:51 --> Database Driver Class Initialized
INFO - 2023-04-18 08:25:51 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:25:51 --> Final output sent to browser
DEBUG - 2023-04-18 08:25:51 --> Total execution time: 0.0207
INFO - 2023-04-18 08:26:23 --> Config Class Initialized
INFO - 2023-04-18 08:26:23 --> Config Class Initialized
INFO - 2023-04-18 08:26:23 --> Hooks Class Initialized
INFO - 2023-04-18 08:26:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:26:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 08:26:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:23 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:23 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:23 --> URI Class Initialized
INFO - 2023-04-18 08:26:23 --> URI Class Initialized
INFO - 2023-04-18 08:26:23 --> Router Class Initialized
INFO - 2023-04-18 08:26:23 --> Router Class Initialized
INFO - 2023-04-18 08:26:23 --> Output Class Initialized
INFO - 2023-04-18 08:26:23 --> Output Class Initialized
INFO - 2023-04-18 08:26:23 --> Security Class Initialized
INFO - 2023-04-18 08:26:23 --> Security Class Initialized
DEBUG - 2023-04-18 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:23 --> Input Class Initialized
DEBUG - 2023-04-18 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:23 --> Language Class Initialized
INFO - 2023-04-18 08:26:23 --> Input Class Initialized
INFO - 2023-04-18 08:26:23 --> Language Class Initialized
INFO - 2023-04-18 08:26:23 --> Loader Class Initialized
INFO - 2023-04-18 08:26:23 --> Loader Class Initialized
INFO - 2023-04-18 08:26:23 --> Controller Class Initialized
INFO - 2023-04-18 08:26:23 --> Controller Class Initialized
DEBUG - 2023-04-18 08:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:23 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:23 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:23 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:23 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:23 --> Total execution time: 0.0137
INFO - 2023-04-18 08:26:23 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:23 --> Total execution time: 0.0152
INFO - 2023-04-18 08:26:23 --> Config Class Initialized
INFO - 2023-04-18 08:26:23 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:26:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:23 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:23 --> URI Class Initialized
INFO - 2023-04-18 08:26:23 --> Router Class Initialized
INFO - 2023-04-18 08:26:23 --> Output Class Initialized
INFO - 2023-04-18 08:26:23 --> Security Class Initialized
INFO - 2023-04-18 08:26:23 --> Config Class Initialized
DEBUG - 2023-04-18 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:23 --> Hooks Class Initialized
INFO - 2023-04-18 08:26:23 --> Input Class Initialized
INFO - 2023-04-18 08:26:23 --> Language Class Initialized
DEBUG - 2023-04-18 08:26:23 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:23 --> Loader Class Initialized
INFO - 2023-04-18 08:26:23 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:23 --> Controller Class Initialized
INFO - 2023-04-18 08:26:23 --> URI Class Initialized
DEBUG - 2023-04-18 08:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:23 --> Router Class Initialized
INFO - 2023-04-18 08:26:23 --> Output Class Initialized
INFO - 2023-04-18 08:26:23 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:23 --> Security Class Initialized
DEBUG - 2023-04-18 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:23 --> Input Class Initialized
INFO - 2023-04-18 08:26:23 --> Language Class Initialized
INFO - 2023-04-18 08:26:23 --> Loader Class Initialized
INFO - 2023-04-18 08:26:23 --> Controller Class Initialized
DEBUG - 2023-04-18 08:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:23 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:24 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:24 --> Total execution time: 0.0123
INFO - 2023-04-18 08:26:24 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:24 --> Total execution time: 0.0122
INFO - 2023-04-18 08:26:24 --> Config Class Initialized
INFO - 2023-04-18 08:26:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:26:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:24 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:24 --> URI Class Initialized
INFO - 2023-04-18 08:26:24 --> Router Class Initialized
INFO - 2023-04-18 08:26:24 --> Output Class Initialized
INFO - 2023-04-18 08:26:24 --> Security Class Initialized
DEBUG - 2023-04-18 08:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:24 --> Input Class Initialized
INFO - 2023-04-18 08:26:24 --> Language Class Initialized
INFO - 2023-04-18 08:26:24 --> Loader Class Initialized
INFO - 2023-04-18 08:26:24 --> Controller Class Initialized
DEBUG - 2023-04-18 08:26:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:24 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:24 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:24 --> Total execution time: 0.0248
INFO - 2023-04-18 08:26:24 --> Config Class Initialized
INFO - 2023-04-18 08:26:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:26:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:24 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:24 --> URI Class Initialized
INFO - 2023-04-18 08:26:24 --> Router Class Initialized
INFO - 2023-04-18 08:26:24 --> Output Class Initialized
INFO - 2023-04-18 08:26:24 --> Security Class Initialized
DEBUG - 2023-04-18 08:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:24 --> Input Class Initialized
INFO - 2023-04-18 08:26:24 --> Language Class Initialized
INFO - 2023-04-18 08:26:24 --> Loader Class Initialized
INFO - 2023-04-18 08:26:24 --> Controller Class Initialized
DEBUG - 2023-04-18 08:26:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:24 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:24 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:24 --> Total execution time: 0.0193
INFO - 2023-04-18 08:26:47 --> Config Class Initialized
INFO - 2023-04-18 08:26:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:26:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:47 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:47 --> URI Class Initialized
INFO - 2023-04-18 08:26:47 --> Router Class Initialized
INFO - 2023-04-18 08:26:47 --> Output Class Initialized
INFO - 2023-04-18 08:26:47 --> Security Class Initialized
DEBUG - 2023-04-18 08:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:47 --> Input Class Initialized
INFO - 2023-04-18 08:26:47 --> Language Class Initialized
INFO - 2023-04-18 08:26:47 --> Loader Class Initialized
INFO - 2023-04-18 08:26:47 --> Controller Class Initialized
DEBUG - 2023-04-18 08:26:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:47 --> Model "Login_model" initialized
INFO - 2023-04-18 08:26:47 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:47 --> Total execution time: 0.1453
INFO - 2023-04-18 08:26:47 --> Config Class Initialized
INFO - 2023-04-18 08:26:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:26:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:47 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:47 --> URI Class Initialized
INFO - 2023-04-18 08:26:47 --> Router Class Initialized
INFO - 2023-04-18 08:26:47 --> Output Class Initialized
INFO - 2023-04-18 08:26:47 --> Security Class Initialized
DEBUG - 2023-04-18 08:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:47 --> Input Class Initialized
INFO - 2023-04-18 08:26:47 --> Language Class Initialized
INFO - 2023-04-18 08:26:47 --> Loader Class Initialized
INFO - 2023-04-18 08:26:47 --> Controller Class Initialized
DEBUG - 2023-04-18 08:26:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:47 --> Model "Login_model" initialized
INFO - 2023-04-18 08:26:47 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:47 --> Total execution time: 0.0600
INFO - 2023-04-18 08:26:55 --> Config Class Initialized
INFO - 2023-04-18 08:26:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:26:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:55 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:55 --> URI Class Initialized
INFO - 2023-04-18 08:26:55 --> Router Class Initialized
INFO - 2023-04-18 08:26:55 --> Output Class Initialized
INFO - 2023-04-18 08:26:55 --> Security Class Initialized
DEBUG - 2023-04-18 08:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:55 --> Input Class Initialized
INFO - 2023-04-18 08:26:55 --> Language Class Initialized
INFO - 2023-04-18 08:26:55 --> Loader Class Initialized
INFO - 2023-04-18 08:26:55 --> Controller Class Initialized
DEBUG - 2023-04-18 08:26:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:55 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:55 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:55 --> Total execution time: 0.0281
INFO - 2023-04-18 08:26:55 --> Config Class Initialized
INFO - 2023-04-18 08:26:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:26:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:26:55 --> Utf8 Class Initialized
INFO - 2023-04-18 08:26:55 --> URI Class Initialized
INFO - 2023-04-18 08:26:55 --> Router Class Initialized
INFO - 2023-04-18 08:26:55 --> Output Class Initialized
INFO - 2023-04-18 08:26:55 --> Security Class Initialized
DEBUG - 2023-04-18 08:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:26:55 --> Input Class Initialized
INFO - 2023-04-18 08:26:55 --> Language Class Initialized
INFO - 2023-04-18 08:26:55 --> Loader Class Initialized
INFO - 2023-04-18 08:26:55 --> Controller Class Initialized
DEBUG - 2023-04-18 08:26:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:26:55 --> Database Driver Class Initialized
INFO - 2023-04-18 08:26:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:26:55 --> Final output sent to browser
DEBUG - 2023-04-18 08:26:55 --> Total execution time: 0.0219
INFO - 2023-04-18 08:27:40 --> Config Class Initialized
INFO - 2023-04-18 08:27:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:27:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:27:40 --> Utf8 Class Initialized
INFO - 2023-04-18 08:27:40 --> URI Class Initialized
INFO - 2023-04-18 08:27:40 --> Router Class Initialized
INFO - 2023-04-18 08:27:40 --> Output Class Initialized
INFO - 2023-04-18 08:27:40 --> Security Class Initialized
DEBUG - 2023-04-18 08:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:27:40 --> Input Class Initialized
INFO - 2023-04-18 08:27:40 --> Language Class Initialized
INFO - 2023-04-18 08:27:40 --> Loader Class Initialized
INFO - 2023-04-18 08:27:40 --> Controller Class Initialized
DEBUG - 2023-04-18 08:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:27:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:27:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:27:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:27:40 --> Model "Login_model" initialized
INFO - 2023-04-18 08:27:40 --> Final output sent to browser
DEBUG - 2023-04-18 08:27:40 --> Total execution time: 0.1434
INFO - 2023-04-18 08:27:40 --> Config Class Initialized
INFO - 2023-04-18 08:27:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:27:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:27:40 --> Utf8 Class Initialized
INFO - 2023-04-18 08:27:40 --> URI Class Initialized
INFO - 2023-04-18 08:27:40 --> Router Class Initialized
INFO - 2023-04-18 08:27:40 --> Output Class Initialized
INFO - 2023-04-18 08:27:40 --> Security Class Initialized
DEBUG - 2023-04-18 08:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:27:40 --> Input Class Initialized
INFO - 2023-04-18 08:27:40 --> Language Class Initialized
INFO - 2023-04-18 08:27:40 --> Loader Class Initialized
INFO - 2023-04-18 08:27:40 --> Controller Class Initialized
DEBUG - 2023-04-18 08:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:27:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:27:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:27:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:27:40 --> Model "Login_model" initialized
INFO - 2023-04-18 08:27:40 --> Final output sent to browser
DEBUG - 2023-04-18 08:27:40 --> Total execution time: 0.0534
INFO - 2023-04-18 08:27:46 --> Config Class Initialized
INFO - 2023-04-18 08:27:46 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:27:46 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:27:46 --> Utf8 Class Initialized
INFO - 2023-04-18 08:27:46 --> URI Class Initialized
INFO - 2023-04-18 08:27:46 --> Router Class Initialized
INFO - 2023-04-18 08:27:46 --> Output Class Initialized
INFO - 2023-04-18 08:27:46 --> Security Class Initialized
DEBUG - 2023-04-18 08:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:27:46 --> Input Class Initialized
INFO - 2023-04-18 08:27:46 --> Language Class Initialized
INFO - 2023-04-18 08:27:46 --> Loader Class Initialized
INFO - 2023-04-18 08:27:46 --> Controller Class Initialized
DEBUG - 2023-04-18 08:27:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:27:46 --> Database Driver Class Initialized
INFO - 2023-04-18 08:27:46 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:27:46 --> Final output sent to browser
DEBUG - 2023-04-18 08:27:46 --> Total execution time: 0.0232
INFO - 2023-04-18 08:27:46 --> Config Class Initialized
INFO - 2023-04-18 08:27:46 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:27:46 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:27:46 --> Utf8 Class Initialized
INFO - 2023-04-18 08:27:46 --> URI Class Initialized
INFO - 2023-04-18 08:27:46 --> Router Class Initialized
INFO - 2023-04-18 08:27:46 --> Output Class Initialized
INFO - 2023-04-18 08:27:46 --> Security Class Initialized
DEBUG - 2023-04-18 08:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:27:46 --> Input Class Initialized
INFO - 2023-04-18 08:27:46 --> Language Class Initialized
INFO - 2023-04-18 08:27:46 --> Loader Class Initialized
INFO - 2023-04-18 08:27:46 --> Controller Class Initialized
DEBUG - 2023-04-18 08:27:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:27:46 --> Database Driver Class Initialized
INFO - 2023-04-18 08:27:46 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:27:46 --> Final output sent to browser
DEBUG - 2023-04-18 08:27:46 --> Total execution time: 0.0187
INFO - 2023-04-18 08:29:58 --> Config Class Initialized
INFO - 2023-04-18 08:29:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:29:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:29:58 --> Utf8 Class Initialized
INFO - 2023-04-18 08:29:58 --> URI Class Initialized
INFO - 2023-04-18 08:29:58 --> Router Class Initialized
INFO - 2023-04-18 08:29:58 --> Output Class Initialized
INFO - 2023-04-18 08:29:58 --> Security Class Initialized
DEBUG - 2023-04-18 08:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:29:58 --> Input Class Initialized
INFO - 2023-04-18 08:29:58 --> Language Class Initialized
INFO - 2023-04-18 08:29:58 --> Loader Class Initialized
INFO - 2023-04-18 08:29:58 --> Controller Class Initialized
DEBUG - 2023-04-18 08:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:29:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:29:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:29:58 --> Final output sent to browser
DEBUG - 2023-04-18 08:29:58 --> Total execution time: 0.0633
INFO - 2023-04-18 08:29:58 --> Config Class Initialized
INFO - 2023-04-18 08:29:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:29:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:29:58 --> Utf8 Class Initialized
INFO - 2023-04-18 08:29:58 --> URI Class Initialized
INFO - 2023-04-18 08:29:58 --> Router Class Initialized
INFO - 2023-04-18 08:29:58 --> Output Class Initialized
INFO - 2023-04-18 08:29:58 --> Security Class Initialized
DEBUG - 2023-04-18 08:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:29:58 --> Input Class Initialized
INFO - 2023-04-18 08:29:58 --> Language Class Initialized
INFO - 2023-04-18 08:29:58 --> Loader Class Initialized
INFO - 2023-04-18 08:29:58 --> Controller Class Initialized
DEBUG - 2023-04-18 08:29:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:29:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:29:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:29:58 --> Final output sent to browser
DEBUG - 2023-04-18 08:29:58 --> Total execution time: 0.0589
INFO - 2023-04-18 08:30:02 --> Config Class Initialized
INFO - 2023-04-18 08:30:02 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:02 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:02 --> URI Class Initialized
INFO - 2023-04-18 08:30:02 --> Router Class Initialized
INFO - 2023-04-18 08:30:02 --> Output Class Initialized
INFO - 2023-04-18 08:30:02 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:02 --> Input Class Initialized
INFO - 2023-04-18 08:30:02 --> Language Class Initialized
INFO - 2023-04-18 08:30:02 --> Loader Class Initialized
INFO - 2023-04-18 08:30:02 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:02 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:02 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:02 --> Model "Login_model" initialized
INFO - 2023-04-18 08:30:02 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:02 --> Total execution time: 0.1857
INFO - 2023-04-18 08:30:02 --> Config Class Initialized
INFO - 2023-04-18 08:30:02 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:02 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:02 --> URI Class Initialized
INFO - 2023-04-18 08:30:02 --> Router Class Initialized
INFO - 2023-04-18 08:30:02 --> Output Class Initialized
INFO - 2023-04-18 08:30:02 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:02 --> Input Class Initialized
INFO - 2023-04-18 08:30:02 --> Language Class Initialized
INFO - 2023-04-18 08:30:02 --> Loader Class Initialized
INFO - 2023-04-18 08:30:02 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:02 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:02 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:02 --> Model "Login_model" initialized
INFO - 2023-04-18 08:30:02 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:02 --> Total execution time: 0.1039
INFO - 2023-04-18 08:30:07 --> Config Class Initialized
INFO - 2023-04-18 08:30:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:07 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:07 --> URI Class Initialized
INFO - 2023-04-18 08:30:07 --> Router Class Initialized
INFO - 2023-04-18 08:30:07 --> Output Class Initialized
INFO - 2023-04-18 08:30:07 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:07 --> Input Class Initialized
INFO - 2023-04-18 08:30:07 --> Language Class Initialized
INFO - 2023-04-18 08:30:07 --> Loader Class Initialized
INFO - 2023-04-18 08:30:07 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:07 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:07 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:07 --> Total execution time: 0.0291
INFO - 2023-04-18 08:30:07 --> Config Class Initialized
INFO - 2023-04-18 08:30:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:07 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:07 --> URI Class Initialized
INFO - 2023-04-18 08:30:07 --> Router Class Initialized
INFO - 2023-04-18 08:30:07 --> Output Class Initialized
INFO - 2023-04-18 08:30:07 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:07 --> Input Class Initialized
INFO - 2023-04-18 08:30:07 --> Language Class Initialized
INFO - 2023-04-18 08:30:07 --> Loader Class Initialized
INFO - 2023-04-18 08:30:07 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:07 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:07 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:07 --> Total execution time: 0.0231
INFO - 2023-04-18 08:30:16 --> Config Class Initialized
INFO - 2023-04-18 08:30:16 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:16 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:16 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:16 --> URI Class Initialized
INFO - 2023-04-18 08:30:16 --> Router Class Initialized
INFO - 2023-04-18 08:30:16 --> Output Class Initialized
INFO - 2023-04-18 08:30:16 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:16 --> Input Class Initialized
INFO - 2023-04-18 08:30:16 --> Language Class Initialized
INFO - 2023-04-18 08:30:16 --> Loader Class Initialized
INFO - 2023-04-18 08:30:16 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:16 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:16 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:17 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:17 --> Total execution time: 0.0237
INFO - 2023-04-18 08:30:17 --> Config Class Initialized
INFO - 2023-04-18 08:30:17 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:17 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:17 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:17 --> URI Class Initialized
INFO - 2023-04-18 08:30:17 --> Router Class Initialized
INFO - 2023-04-18 08:30:17 --> Output Class Initialized
INFO - 2023-04-18 08:30:17 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:17 --> Input Class Initialized
INFO - 2023-04-18 08:30:17 --> Language Class Initialized
INFO - 2023-04-18 08:30:17 --> Loader Class Initialized
INFO - 2023-04-18 08:30:17 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:17 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:17 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:17 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:17 --> Total execution time: 0.0183
INFO - 2023-04-18 08:30:20 --> Config Class Initialized
INFO - 2023-04-18 08:30:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:20 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:20 --> URI Class Initialized
INFO - 2023-04-18 08:30:20 --> Router Class Initialized
INFO - 2023-04-18 08:30:20 --> Output Class Initialized
INFO - 2023-04-18 08:30:20 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:20 --> Input Class Initialized
INFO - 2023-04-18 08:30:20 --> Language Class Initialized
INFO - 2023-04-18 08:30:20 --> Loader Class Initialized
INFO - 2023-04-18 08:30:20 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:20 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:20 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:20 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:20 --> Model "Login_model" initialized
INFO - 2023-04-18 08:30:20 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:20 --> Total execution time: 0.0561
INFO - 2023-04-18 08:30:20 --> Config Class Initialized
INFO - 2023-04-18 08:30:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:20 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:20 --> URI Class Initialized
INFO - 2023-04-18 08:30:20 --> Router Class Initialized
INFO - 2023-04-18 08:30:20 --> Output Class Initialized
INFO - 2023-04-18 08:30:20 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:20 --> Input Class Initialized
INFO - 2023-04-18 08:30:20 --> Language Class Initialized
INFO - 2023-04-18 08:30:20 --> Loader Class Initialized
INFO - 2023-04-18 08:30:20 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:20 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:20 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:20 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:20 --> Model "Login_model" initialized
INFO - 2023-04-18 08:30:20 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:20 --> Total execution time: 0.1455
INFO - 2023-04-18 08:30:24 --> Config Class Initialized
INFO - 2023-04-18 08:30:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:24 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:24 --> URI Class Initialized
INFO - 2023-04-18 08:30:24 --> Router Class Initialized
INFO - 2023-04-18 08:30:24 --> Output Class Initialized
INFO - 2023-04-18 08:30:24 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:24 --> Input Class Initialized
INFO - 2023-04-18 08:30:24 --> Language Class Initialized
INFO - 2023-04-18 08:30:24 --> Loader Class Initialized
INFO - 2023-04-18 08:30:24 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:24 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:24 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:24 --> Total execution time: 0.0225
INFO - 2023-04-18 08:30:24 --> Config Class Initialized
INFO - 2023-04-18 08:30:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:24 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:24 --> URI Class Initialized
INFO - 2023-04-18 08:30:24 --> Router Class Initialized
INFO - 2023-04-18 08:30:24 --> Output Class Initialized
INFO - 2023-04-18 08:30:24 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:24 --> Input Class Initialized
INFO - 2023-04-18 08:30:24 --> Language Class Initialized
INFO - 2023-04-18 08:30:24 --> Loader Class Initialized
INFO - 2023-04-18 08:30:24 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:24 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:24 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:24 --> Total execution time: 0.0174
INFO - 2023-04-18 08:30:39 --> Config Class Initialized
INFO - 2023-04-18 08:30:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:39 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:39 --> URI Class Initialized
INFO - 2023-04-18 08:30:39 --> Router Class Initialized
INFO - 2023-04-18 08:30:39 --> Output Class Initialized
INFO - 2023-04-18 08:30:39 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:39 --> Input Class Initialized
INFO - 2023-04-18 08:30:39 --> Language Class Initialized
INFO - 2023-04-18 08:30:39 --> Loader Class Initialized
INFO - 2023-04-18 08:30:39 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:39 --> Model "Login_model" initialized
INFO - 2023-04-18 08:30:39 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:39 --> Total execution time: 0.1154
INFO - 2023-04-18 08:30:39 --> Config Class Initialized
INFO - 2023-04-18 08:30:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:39 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:39 --> URI Class Initialized
INFO - 2023-04-18 08:30:39 --> Router Class Initialized
INFO - 2023-04-18 08:30:39 --> Output Class Initialized
INFO - 2023-04-18 08:30:39 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:39 --> Input Class Initialized
INFO - 2023-04-18 08:30:39 --> Language Class Initialized
INFO - 2023-04-18 08:30:39 --> Loader Class Initialized
INFO - 2023-04-18 08:30:39 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:39 --> Model "Login_model" initialized
INFO - 2023-04-18 08:30:39 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:39 --> Total execution time: 0.1168
INFO - 2023-04-18 08:30:42 --> Config Class Initialized
INFO - 2023-04-18 08:30:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:42 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:42 --> URI Class Initialized
INFO - 2023-04-18 08:30:42 --> Router Class Initialized
INFO - 2023-04-18 08:30:42 --> Output Class Initialized
INFO - 2023-04-18 08:30:42 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:42 --> Input Class Initialized
INFO - 2023-04-18 08:30:42 --> Language Class Initialized
INFO - 2023-04-18 08:30:42 --> Loader Class Initialized
INFO - 2023-04-18 08:30:42 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:42 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:42 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:42 --> Total execution time: 0.0220
INFO - 2023-04-18 08:30:42 --> Config Class Initialized
INFO - 2023-04-18 08:30:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:42 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:42 --> URI Class Initialized
INFO - 2023-04-18 08:30:42 --> Router Class Initialized
INFO - 2023-04-18 08:30:42 --> Output Class Initialized
INFO - 2023-04-18 08:30:42 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:42 --> Input Class Initialized
INFO - 2023-04-18 08:30:42 --> Language Class Initialized
INFO - 2023-04-18 08:30:42 --> Loader Class Initialized
INFO - 2023-04-18 08:30:42 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:42 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:42 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:42 --> Total execution time: 0.0211
INFO - 2023-04-18 08:30:50 --> Config Class Initialized
INFO - 2023-04-18 08:30:50 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:50 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:50 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:50 --> URI Class Initialized
INFO - 2023-04-18 08:30:50 --> Router Class Initialized
INFO - 2023-04-18 08:30:50 --> Output Class Initialized
INFO - 2023-04-18 08:30:50 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:50 --> Input Class Initialized
INFO - 2023-04-18 08:30:50 --> Language Class Initialized
INFO - 2023-04-18 08:30:50 --> Loader Class Initialized
INFO - 2023-04-18 08:30:50 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:50 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:50 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:50 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:50 --> Model "Login_model" initialized
INFO - 2023-04-18 08:30:50 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:50 --> Total execution time: 0.0618
INFO - 2023-04-18 08:30:50 --> Config Class Initialized
INFO - 2023-04-18 08:30:50 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:30:50 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:30:50 --> Utf8 Class Initialized
INFO - 2023-04-18 08:30:50 --> URI Class Initialized
INFO - 2023-04-18 08:30:50 --> Router Class Initialized
INFO - 2023-04-18 08:30:50 --> Output Class Initialized
INFO - 2023-04-18 08:30:50 --> Security Class Initialized
DEBUG - 2023-04-18 08:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:30:50 --> Input Class Initialized
INFO - 2023-04-18 08:30:50 --> Language Class Initialized
INFO - 2023-04-18 08:30:50 --> Loader Class Initialized
INFO - 2023-04-18 08:30:50 --> Controller Class Initialized
DEBUG - 2023-04-18 08:30:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:30:50 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:50 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:30:50 --> Database Driver Class Initialized
INFO - 2023-04-18 08:30:50 --> Model "Login_model" initialized
INFO - 2023-04-18 08:30:50 --> Final output sent to browser
DEBUG - 2023-04-18 08:30:50 --> Total execution time: 0.1025
INFO - 2023-04-18 08:31:17 --> Config Class Initialized
INFO - 2023-04-18 08:31:17 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:17 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:17 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:17 --> URI Class Initialized
INFO - 2023-04-18 08:31:17 --> Router Class Initialized
INFO - 2023-04-18 08:31:17 --> Output Class Initialized
INFO - 2023-04-18 08:31:17 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:17 --> Input Class Initialized
INFO - 2023-04-18 08:31:17 --> Language Class Initialized
INFO - 2023-04-18 08:31:17 --> Loader Class Initialized
INFO - 2023-04-18 08:31:17 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:17 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:17 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:17 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:17 --> Model "Login_model" initialized
INFO - 2023-04-18 08:31:17 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:17 --> Total execution time: 0.1583
INFO - 2023-04-18 08:31:17 --> Config Class Initialized
INFO - 2023-04-18 08:31:17 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:17 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:17 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:17 --> URI Class Initialized
INFO - 2023-04-18 08:31:17 --> Router Class Initialized
INFO - 2023-04-18 08:31:17 --> Output Class Initialized
INFO - 2023-04-18 08:31:17 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:17 --> Input Class Initialized
INFO - 2023-04-18 08:31:17 --> Language Class Initialized
INFO - 2023-04-18 08:31:17 --> Loader Class Initialized
INFO - 2023-04-18 08:31:17 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:17 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:17 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:17 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:17 --> Model "Login_model" initialized
INFO - 2023-04-18 08:31:17 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:17 --> Total execution time: 0.0706
INFO - 2023-04-18 08:31:20 --> Config Class Initialized
INFO - 2023-04-18 08:31:20 --> Config Class Initialized
INFO - 2023-04-18 08:31:20 --> Hooks Class Initialized
INFO - 2023-04-18 08:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 08:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:20 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:20 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:20 --> URI Class Initialized
INFO - 2023-04-18 08:31:20 --> URI Class Initialized
INFO - 2023-04-18 08:31:20 --> Router Class Initialized
INFO - 2023-04-18 08:31:20 --> Router Class Initialized
INFO - 2023-04-18 08:31:20 --> Output Class Initialized
INFO - 2023-04-18 08:31:20 --> Output Class Initialized
INFO - 2023-04-18 08:31:20 --> Security Class Initialized
INFO - 2023-04-18 08:31:20 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:20 --> Input Class Initialized
INFO - 2023-04-18 08:31:20 --> Input Class Initialized
INFO - 2023-04-18 08:31:20 --> Language Class Initialized
INFO - 2023-04-18 08:31:20 --> Language Class Initialized
INFO - 2023-04-18 08:31:20 --> Loader Class Initialized
INFO - 2023-04-18 08:31:20 --> Loader Class Initialized
INFO - 2023-04-18 08:31:20 --> Controller Class Initialized
INFO - 2023-04-18 08:31:20 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:20 --> Final output sent to browser
INFO - 2023-04-18 08:31:20 --> Database Driver Class Initialized
DEBUG - 2023-04-18 08:31:20 --> Total execution time: 0.0051
INFO - 2023-04-18 08:31:20 --> Config Class Initialized
INFO - 2023-04-18 08:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:20 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:20 --> URI Class Initialized
INFO - 2023-04-18 08:31:20 --> Router Class Initialized
INFO - 2023-04-18 08:31:20 --> Output Class Initialized
INFO - 2023-04-18 08:31:20 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:20 --> Input Class Initialized
INFO - 2023-04-18 08:31:20 --> Language Class Initialized
INFO - 2023-04-18 08:31:20 --> Loader Class Initialized
INFO - 2023-04-18 08:31:20 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:20 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:20 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:20 --> Total execution time: 0.0516
INFO - 2023-04-18 08:31:20 --> Config Class Initialized
INFO - 2023-04-18 08:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:20 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:20 --> URI Class Initialized
INFO - 2023-04-18 08:31:20 --> Router Class Initialized
INFO - 2023-04-18 08:31:20 --> Output Class Initialized
INFO - 2023-04-18 08:31:20 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:20 --> Input Class Initialized
INFO - 2023-04-18 08:31:20 --> Language Class Initialized
INFO - 2023-04-18 08:31:20 --> Loader Class Initialized
INFO - 2023-04-18 08:31:20 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:20 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:20 --> Model "Login_model" initialized
INFO - 2023-04-18 08:31:20 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:20 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:20 --> Total execution time: 0.0169
INFO - 2023-04-18 08:31:20 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:20 --> Total execution time: 0.0644
INFO - 2023-04-18 08:31:22 --> Config Class Initialized
INFO - 2023-04-18 08:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:22 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:22 --> URI Class Initialized
INFO - 2023-04-18 08:31:22 --> Router Class Initialized
INFO - 2023-04-18 08:31:22 --> Output Class Initialized
INFO - 2023-04-18 08:31:22 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:22 --> Input Class Initialized
INFO - 2023-04-18 08:31:22 --> Language Class Initialized
INFO - 2023-04-18 08:31:22 --> Loader Class Initialized
INFO - 2023-04-18 08:31:22 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:22 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:22 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:22 --> Total execution time: 0.1098
INFO - 2023-04-18 08:31:22 --> Config Class Initialized
INFO - 2023-04-18 08:31:22 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:22 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:22 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:22 --> URI Class Initialized
INFO - 2023-04-18 08:31:22 --> Router Class Initialized
INFO - 2023-04-18 08:31:22 --> Output Class Initialized
INFO - 2023-04-18 08:31:22 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:22 --> Input Class Initialized
INFO - 2023-04-18 08:31:22 --> Language Class Initialized
INFO - 2023-04-18 08:31:22 --> Loader Class Initialized
INFO - 2023-04-18 08:31:22 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:22 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:22 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:22 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:22 --> Total execution time: 0.1357
INFO - 2023-04-18 08:31:24 --> Config Class Initialized
INFO - 2023-04-18 08:31:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:24 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:24 --> URI Class Initialized
INFO - 2023-04-18 08:31:24 --> Router Class Initialized
INFO - 2023-04-18 08:31:24 --> Output Class Initialized
INFO - 2023-04-18 08:31:24 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:24 --> Input Class Initialized
INFO - 2023-04-18 08:31:24 --> Language Class Initialized
INFO - 2023-04-18 08:31:24 --> Loader Class Initialized
INFO - 2023-04-18 08:31:24 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:24 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:24 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:24 --> Total execution time: 0.0182
INFO - 2023-04-18 08:31:24 --> Config Class Initialized
INFO - 2023-04-18 08:31:24 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:24 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:24 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:24 --> URI Class Initialized
INFO - 2023-04-18 08:31:24 --> Router Class Initialized
INFO - 2023-04-18 08:31:24 --> Output Class Initialized
INFO - 2023-04-18 08:31:24 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:24 --> Input Class Initialized
INFO - 2023-04-18 08:31:24 --> Language Class Initialized
INFO - 2023-04-18 08:31:24 --> Loader Class Initialized
INFO - 2023-04-18 08:31:24 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:24 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:24 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:24 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:24 --> Total execution time: 0.0118
INFO - 2023-04-18 08:31:28 --> Config Class Initialized
INFO - 2023-04-18 08:31:28 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:28 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:28 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:28 --> URI Class Initialized
INFO - 2023-04-18 08:31:28 --> Router Class Initialized
INFO - 2023-04-18 08:31:28 --> Output Class Initialized
INFO - 2023-04-18 08:31:28 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:28 --> Input Class Initialized
INFO - 2023-04-18 08:31:28 --> Language Class Initialized
INFO - 2023-04-18 08:31:28 --> Loader Class Initialized
INFO - 2023-04-18 08:31:28 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:28 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:28 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:28 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:28 --> Model "Login_model" initialized
INFO - 2023-04-18 08:31:28 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:28 --> Total execution time: 0.0713
INFO - 2023-04-18 08:31:28 --> Config Class Initialized
INFO - 2023-04-18 08:31:28 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:28 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:28 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:28 --> URI Class Initialized
INFO - 2023-04-18 08:31:28 --> Router Class Initialized
INFO - 2023-04-18 08:31:28 --> Output Class Initialized
INFO - 2023-04-18 08:31:28 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:28 --> Input Class Initialized
INFO - 2023-04-18 08:31:28 --> Language Class Initialized
INFO - 2023-04-18 08:31:28 --> Loader Class Initialized
INFO - 2023-04-18 08:31:28 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:28 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:28 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:28 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:28 --> Model "Login_model" initialized
INFO - 2023-04-18 08:31:28 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:28 --> Total execution time: 0.0617
INFO - 2023-04-18 08:31:33 --> Config Class Initialized
INFO - 2023-04-18 08:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:33 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:33 --> URI Class Initialized
INFO - 2023-04-18 08:31:33 --> Router Class Initialized
INFO - 2023-04-18 08:31:33 --> Output Class Initialized
INFO - 2023-04-18 08:31:33 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:33 --> Input Class Initialized
INFO - 2023-04-18 08:31:33 --> Language Class Initialized
INFO - 2023-04-18 08:31:33 --> Loader Class Initialized
INFO - 2023-04-18 08:31:33 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:33 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:33 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:33 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:33 --> Total execution time: 0.0233
INFO - 2023-04-18 08:31:33 --> Config Class Initialized
INFO - 2023-04-18 08:31:33 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:33 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:33 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:33 --> URI Class Initialized
INFO - 2023-04-18 08:31:33 --> Router Class Initialized
INFO - 2023-04-18 08:31:33 --> Output Class Initialized
INFO - 2023-04-18 08:31:33 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:33 --> Input Class Initialized
INFO - 2023-04-18 08:31:33 --> Language Class Initialized
INFO - 2023-04-18 08:31:33 --> Loader Class Initialized
INFO - 2023-04-18 08:31:33 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:33 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:33 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:33 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:33 --> Total execution time: 0.0235
INFO - 2023-04-18 08:31:53 --> Config Class Initialized
INFO - 2023-04-18 08:31:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:53 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:53 --> URI Class Initialized
INFO - 2023-04-18 08:31:53 --> Router Class Initialized
INFO - 2023-04-18 08:31:53 --> Output Class Initialized
INFO - 2023-04-18 08:31:53 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:53 --> Input Class Initialized
INFO - 2023-04-18 08:31:53 --> Language Class Initialized
INFO - 2023-04-18 08:31:53 --> Loader Class Initialized
INFO - 2023-04-18 08:31:53 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:53 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:53 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:53 --> Total execution time: 0.0792
INFO - 2023-04-18 08:31:53 --> Config Class Initialized
INFO - 2023-04-18 08:31:53 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:53 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:53 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:53 --> URI Class Initialized
INFO - 2023-04-18 08:31:53 --> Router Class Initialized
INFO - 2023-04-18 08:31:53 --> Output Class Initialized
INFO - 2023-04-18 08:31:53 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:53 --> Input Class Initialized
INFO - 2023-04-18 08:31:53 --> Language Class Initialized
INFO - 2023-04-18 08:31:53 --> Loader Class Initialized
INFO - 2023-04-18 08:31:53 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:53 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:53 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:53 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:53 --> Total execution time: 0.1196
INFO - 2023-04-18 08:31:56 --> Config Class Initialized
INFO - 2023-04-18 08:31:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:56 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:56 --> URI Class Initialized
INFO - 2023-04-18 08:31:56 --> Router Class Initialized
INFO - 2023-04-18 08:31:56 --> Output Class Initialized
INFO - 2023-04-18 08:31:56 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:56 --> Input Class Initialized
INFO - 2023-04-18 08:31:56 --> Language Class Initialized
INFO - 2023-04-18 08:31:56 --> Loader Class Initialized
INFO - 2023-04-18 08:31:56 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:56 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:56 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:56 --> Total execution time: 0.0270
INFO - 2023-04-18 08:31:56 --> Config Class Initialized
INFO - 2023-04-18 08:31:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:31:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:31:56 --> Utf8 Class Initialized
INFO - 2023-04-18 08:31:56 --> URI Class Initialized
INFO - 2023-04-18 08:31:56 --> Router Class Initialized
INFO - 2023-04-18 08:31:56 --> Output Class Initialized
INFO - 2023-04-18 08:31:56 --> Security Class Initialized
DEBUG - 2023-04-18 08:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:31:56 --> Input Class Initialized
INFO - 2023-04-18 08:31:56 --> Language Class Initialized
INFO - 2023-04-18 08:31:56 --> Loader Class Initialized
INFO - 2023-04-18 08:31:56 --> Controller Class Initialized
DEBUG - 2023-04-18 08:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:31:56 --> Database Driver Class Initialized
INFO - 2023-04-18 08:31:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:31:56 --> Final output sent to browser
DEBUG - 2023-04-18 08:31:56 --> Total execution time: 0.0241
INFO - 2023-04-18 08:32:07 --> Config Class Initialized
INFO - 2023-04-18 08:32:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:32:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:32:07 --> Utf8 Class Initialized
INFO - 2023-04-18 08:32:07 --> URI Class Initialized
INFO - 2023-04-18 08:32:07 --> Router Class Initialized
INFO - 2023-04-18 08:32:07 --> Output Class Initialized
INFO - 2023-04-18 08:32:07 --> Security Class Initialized
DEBUG - 2023-04-18 08:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:32:07 --> Input Class Initialized
INFO - 2023-04-18 08:32:07 --> Language Class Initialized
INFO - 2023-04-18 08:32:07 --> Loader Class Initialized
INFO - 2023-04-18 08:32:07 --> Controller Class Initialized
DEBUG - 2023-04-18 08:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:32:07 --> Final output sent to browser
DEBUG - 2023-04-18 08:32:07 --> Total execution time: 0.0038
INFO - 2023-04-18 08:32:07 --> Config Class Initialized
INFO - 2023-04-18 08:32:07 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:32:07 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:32:07 --> Utf8 Class Initialized
INFO - 2023-04-18 08:32:07 --> URI Class Initialized
INFO - 2023-04-18 08:32:07 --> Router Class Initialized
INFO - 2023-04-18 08:32:07 --> Output Class Initialized
INFO - 2023-04-18 08:32:07 --> Security Class Initialized
DEBUG - 2023-04-18 08:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:32:07 --> Input Class Initialized
INFO - 2023-04-18 08:32:07 --> Language Class Initialized
INFO - 2023-04-18 08:32:07 --> Loader Class Initialized
INFO - 2023-04-18 08:32:07 --> Controller Class Initialized
DEBUG - 2023-04-18 08:32:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:32:07 --> Database Driver Class Initialized
INFO - 2023-04-18 08:32:07 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:32:07 --> Model "Mysql_model" initialized
INFO - 2023-04-18 08:32:07 --> Model "Grafana_model" initialized
INFO - 2023-04-18 08:32:07 --> Final output sent to browser
DEBUG - 2023-04-18 08:32:07 --> Total execution time: 0.0124
INFO - 2023-04-18 08:32:09 --> Config Class Initialized
INFO - 2023-04-18 08:32:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:32:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:32:09 --> Utf8 Class Initialized
INFO - 2023-04-18 08:32:09 --> URI Class Initialized
INFO - 2023-04-18 08:32:09 --> Router Class Initialized
INFO - 2023-04-18 08:32:09 --> Output Class Initialized
INFO - 2023-04-18 08:32:09 --> Security Class Initialized
DEBUG - 2023-04-18 08:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:32:09 --> Input Class Initialized
INFO - 2023-04-18 08:32:09 --> Language Class Initialized
INFO - 2023-04-18 08:32:09 --> Loader Class Initialized
INFO - 2023-04-18 08:32:09 --> Controller Class Initialized
DEBUG - 2023-04-18 08:32:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:32:09 --> Database Driver Class Initialized
INFO - 2023-04-18 08:32:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:32:09 --> Model "Mysql_model" initialized
INFO - 2023-04-18 08:32:09 --> Model "Grafana_model" initialized
INFO - 2023-04-18 08:32:09 --> Final output sent to browser
DEBUG - 2023-04-18 08:32:09 --> Total execution time: 0.0166
INFO - 2023-04-18 08:34:57 --> Config Class Initialized
INFO - 2023-04-18 08:34:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:34:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:34:58 --> Utf8 Class Initialized
INFO - 2023-04-18 08:34:58 --> URI Class Initialized
INFO - 2023-04-18 08:34:58 --> Router Class Initialized
INFO - 2023-04-18 08:34:58 --> Output Class Initialized
INFO - 2023-04-18 08:34:58 --> Security Class Initialized
DEBUG - 2023-04-18 08:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:34:58 --> Input Class Initialized
INFO - 2023-04-18 08:34:58 --> Language Class Initialized
INFO - 2023-04-18 08:34:58 --> Loader Class Initialized
INFO - 2023-04-18 08:34:58 --> Controller Class Initialized
DEBUG - 2023-04-18 08:34:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:34:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:34:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:34:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:34:58 --> Model "Login_model" initialized
INFO - 2023-04-18 08:34:58 --> Final output sent to browser
DEBUG - 2023-04-18 08:34:58 --> Total execution time: 0.1427
INFO - 2023-04-18 08:34:58 --> Config Class Initialized
INFO - 2023-04-18 08:34:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:34:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:34:58 --> Utf8 Class Initialized
INFO - 2023-04-18 08:34:58 --> URI Class Initialized
INFO - 2023-04-18 08:34:58 --> Router Class Initialized
INFO - 2023-04-18 08:34:58 --> Output Class Initialized
INFO - 2023-04-18 08:34:58 --> Security Class Initialized
DEBUG - 2023-04-18 08:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:34:58 --> Input Class Initialized
INFO - 2023-04-18 08:34:58 --> Language Class Initialized
INFO - 2023-04-18 08:34:58 --> Loader Class Initialized
INFO - 2023-04-18 08:34:58 --> Controller Class Initialized
DEBUG - 2023-04-18 08:34:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:34:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:34:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:34:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:34:58 --> Model "Login_model" initialized
INFO - 2023-04-18 08:34:58 --> Final output sent to browser
DEBUG - 2023-04-18 08:34:58 --> Total execution time: 0.0605
INFO - 2023-04-18 08:35:02 --> Config Class Initialized
INFO - 2023-04-18 08:35:02 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:35:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:35:02 --> Utf8 Class Initialized
INFO - 2023-04-18 08:35:02 --> URI Class Initialized
INFO - 2023-04-18 08:35:02 --> Router Class Initialized
INFO - 2023-04-18 08:35:02 --> Output Class Initialized
INFO - 2023-04-18 08:35:02 --> Security Class Initialized
DEBUG - 2023-04-18 08:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:35:02 --> Input Class Initialized
INFO - 2023-04-18 08:35:02 --> Language Class Initialized
INFO - 2023-04-18 08:35:02 --> Loader Class Initialized
INFO - 2023-04-18 08:35:02 --> Controller Class Initialized
DEBUG - 2023-04-18 08:35:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:35:02 --> Database Driver Class Initialized
INFO - 2023-04-18 08:35:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:35:02 --> Final output sent to browser
DEBUG - 2023-04-18 08:35:02 --> Total execution time: 0.0272
INFO - 2023-04-18 08:35:02 --> Config Class Initialized
INFO - 2023-04-18 08:35:02 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:35:02 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:35:02 --> Utf8 Class Initialized
INFO - 2023-04-18 08:35:02 --> URI Class Initialized
INFO - 2023-04-18 08:35:02 --> Router Class Initialized
INFO - 2023-04-18 08:35:02 --> Output Class Initialized
INFO - 2023-04-18 08:35:02 --> Security Class Initialized
DEBUG - 2023-04-18 08:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:35:02 --> Input Class Initialized
INFO - 2023-04-18 08:35:02 --> Language Class Initialized
INFO - 2023-04-18 08:35:02 --> Loader Class Initialized
INFO - 2023-04-18 08:35:02 --> Controller Class Initialized
DEBUG - 2023-04-18 08:35:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:35:02 --> Database Driver Class Initialized
INFO - 2023-04-18 08:35:02 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:35:02 --> Final output sent to browser
DEBUG - 2023-04-18 08:35:02 --> Total execution time: 0.0203
INFO - 2023-04-18 08:35:16 --> Config Class Initialized
INFO - 2023-04-18 08:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:35:16 --> Utf8 Class Initialized
INFO - 2023-04-18 08:35:16 --> URI Class Initialized
INFO - 2023-04-18 08:35:16 --> Router Class Initialized
INFO - 2023-04-18 08:35:16 --> Output Class Initialized
INFO - 2023-04-18 08:35:16 --> Security Class Initialized
DEBUG - 2023-04-18 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:35:16 --> Input Class Initialized
INFO - 2023-04-18 08:35:16 --> Language Class Initialized
INFO - 2023-04-18 08:35:16 --> Loader Class Initialized
INFO - 2023-04-18 08:35:16 --> Controller Class Initialized
DEBUG - 2023-04-18 08:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:35:16 --> Database Driver Class Initialized
INFO - 2023-04-18 08:35:16 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:35:16 --> Final output sent to browser
DEBUG - 2023-04-18 08:35:16 --> Total execution time: 0.0231
INFO - 2023-04-18 08:35:16 --> Config Class Initialized
INFO - 2023-04-18 08:35:16 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:35:16 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:35:16 --> Utf8 Class Initialized
INFO - 2023-04-18 08:35:16 --> URI Class Initialized
INFO - 2023-04-18 08:35:16 --> Router Class Initialized
INFO - 2023-04-18 08:35:16 --> Output Class Initialized
INFO - 2023-04-18 08:35:16 --> Security Class Initialized
DEBUG - 2023-04-18 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:35:16 --> Input Class Initialized
INFO - 2023-04-18 08:35:16 --> Language Class Initialized
INFO - 2023-04-18 08:35:16 --> Loader Class Initialized
INFO - 2023-04-18 08:35:16 --> Controller Class Initialized
DEBUG - 2023-04-18 08:35:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:35:16 --> Database Driver Class Initialized
INFO - 2023-04-18 08:35:16 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:35:16 --> Final output sent to browser
DEBUG - 2023-04-18 08:35:16 --> Total execution time: 0.0195
INFO - 2023-04-18 08:36:01 --> Config Class Initialized
INFO - 2023-04-18 08:36:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:36:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:36:01 --> Utf8 Class Initialized
INFO - 2023-04-18 08:36:01 --> URI Class Initialized
INFO - 2023-04-18 08:36:01 --> Router Class Initialized
INFO - 2023-04-18 08:36:01 --> Output Class Initialized
INFO - 2023-04-18 08:36:01 --> Security Class Initialized
DEBUG - 2023-04-18 08:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:36:01 --> Input Class Initialized
INFO - 2023-04-18 08:36:01 --> Language Class Initialized
INFO - 2023-04-18 08:36:01 --> Loader Class Initialized
INFO - 2023-04-18 08:36:01 --> Controller Class Initialized
DEBUG - 2023-04-18 08:36:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:36:01 --> Database Driver Class Initialized
INFO - 2023-04-18 08:36:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:36:01 --> Database Driver Class Initialized
INFO - 2023-04-18 08:36:01 --> Model "Login_model" initialized
INFO - 2023-04-18 08:36:01 --> Final output sent to browser
DEBUG - 2023-04-18 08:36:01 --> Total execution time: 0.1597
INFO - 2023-04-18 08:36:01 --> Config Class Initialized
INFO - 2023-04-18 08:36:01 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:36:01 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:36:01 --> Utf8 Class Initialized
INFO - 2023-04-18 08:36:01 --> URI Class Initialized
INFO - 2023-04-18 08:36:01 --> Router Class Initialized
INFO - 2023-04-18 08:36:01 --> Output Class Initialized
INFO - 2023-04-18 08:36:01 --> Security Class Initialized
DEBUG - 2023-04-18 08:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:36:01 --> Input Class Initialized
INFO - 2023-04-18 08:36:01 --> Language Class Initialized
INFO - 2023-04-18 08:36:01 --> Loader Class Initialized
INFO - 2023-04-18 08:36:01 --> Controller Class Initialized
DEBUG - 2023-04-18 08:36:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:36:01 --> Database Driver Class Initialized
INFO - 2023-04-18 08:36:01 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:36:01 --> Database Driver Class Initialized
INFO - 2023-04-18 08:36:01 --> Model "Login_model" initialized
INFO - 2023-04-18 08:36:01 --> Final output sent to browser
DEBUG - 2023-04-18 08:36:01 --> Total execution time: 0.1418
INFO - 2023-04-18 08:36:08 --> Config Class Initialized
INFO - 2023-04-18 08:36:08 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:36:08 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:36:08 --> Utf8 Class Initialized
INFO - 2023-04-18 08:36:08 --> URI Class Initialized
INFO - 2023-04-18 08:36:08 --> Router Class Initialized
INFO - 2023-04-18 08:36:08 --> Output Class Initialized
INFO - 2023-04-18 08:36:08 --> Security Class Initialized
DEBUG - 2023-04-18 08:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:36:08 --> Input Class Initialized
INFO - 2023-04-18 08:36:08 --> Language Class Initialized
INFO - 2023-04-18 08:36:08 --> Loader Class Initialized
INFO - 2023-04-18 08:36:08 --> Controller Class Initialized
DEBUG - 2023-04-18 08:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:36:08 --> Database Driver Class Initialized
INFO - 2023-04-18 08:36:08 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:36:08 --> Final output sent to browser
DEBUG - 2023-04-18 08:36:08 --> Total execution time: 0.0267
INFO - 2023-04-18 08:36:08 --> Config Class Initialized
INFO - 2023-04-18 08:36:08 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:36:08 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:36:08 --> Utf8 Class Initialized
INFO - 2023-04-18 08:36:08 --> URI Class Initialized
INFO - 2023-04-18 08:36:08 --> Router Class Initialized
INFO - 2023-04-18 08:36:08 --> Output Class Initialized
INFO - 2023-04-18 08:36:08 --> Security Class Initialized
DEBUG - 2023-04-18 08:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:36:08 --> Input Class Initialized
INFO - 2023-04-18 08:36:08 --> Language Class Initialized
INFO - 2023-04-18 08:36:08 --> Loader Class Initialized
INFO - 2023-04-18 08:36:08 --> Controller Class Initialized
DEBUG - 2023-04-18 08:36:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:36:08 --> Database Driver Class Initialized
INFO - 2023-04-18 08:36:08 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:36:08 --> Final output sent to browser
DEBUG - 2023-04-18 08:36:08 --> Total execution time: 0.0713
INFO - 2023-04-18 08:36:31 --> Config Class Initialized
INFO - 2023-04-18 08:36:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:36:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:36:31 --> Utf8 Class Initialized
INFO - 2023-04-18 08:36:31 --> URI Class Initialized
INFO - 2023-04-18 08:36:31 --> Router Class Initialized
INFO - 2023-04-18 08:36:31 --> Output Class Initialized
INFO - 2023-04-18 08:36:31 --> Security Class Initialized
DEBUG - 2023-04-18 08:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:36:31 --> Input Class Initialized
INFO - 2023-04-18 08:36:31 --> Language Class Initialized
INFO - 2023-04-18 08:36:31 --> Loader Class Initialized
INFO - 2023-04-18 08:36:31 --> Controller Class Initialized
DEBUG - 2023-04-18 08:36:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:36:31 --> Database Driver Class Initialized
INFO - 2023-04-18 08:36:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:36:31 --> Final output sent to browser
DEBUG - 2023-04-18 08:36:31 --> Total execution time: 0.0631
INFO - 2023-04-18 08:36:31 --> Config Class Initialized
INFO - 2023-04-18 08:36:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:36:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:36:31 --> Utf8 Class Initialized
INFO - 2023-04-18 08:36:31 --> URI Class Initialized
INFO - 2023-04-18 08:36:31 --> Router Class Initialized
INFO - 2023-04-18 08:36:31 --> Output Class Initialized
INFO - 2023-04-18 08:36:31 --> Security Class Initialized
DEBUG - 2023-04-18 08:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:36:31 --> Input Class Initialized
INFO - 2023-04-18 08:36:31 --> Language Class Initialized
INFO - 2023-04-18 08:36:31 --> Loader Class Initialized
INFO - 2023-04-18 08:36:31 --> Controller Class Initialized
DEBUG - 2023-04-18 08:36:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:36:31 --> Database Driver Class Initialized
INFO - 2023-04-18 08:36:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:36:31 --> Final output sent to browser
DEBUG - 2023-04-18 08:36:31 --> Total execution time: 0.0202
INFO - 2023-04-18 08:37:03 --> Config Class Initialized
INFO - 2023-04-18 08:37:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:03 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:03 --> URI Class Initialized
INFO - 2023-04-18 08:37:03 --> Router Class Initialized
INFO - 2023-04-18 08:37:03 --> Output Class Initialized
INFO - 2023-04-18 08:37:03 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:03 --> Input Class Initialized
INFO - 2023-04-18 08:37:03 --> Language Class Initialized
INFO - 2023-04-18 08:37:03 --> Loader Class Initialized
INFO - 2023-04-18 08:37:03 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:03 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:03 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:03 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:03 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:03 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:03 --> Total execution time: 0.1418
INFO - 2023-04-18 08:37:03 --> Config Class Initialized
INFO - 2023-04-18 08:37:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:03 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:03 --> URI Class Initialized
INFO - 2023-04-18 08:37:03 --> Router Class Initialized
INFO - 2023-04-18 08:37:03 --> Output Class Initialized
INFO - 2023-04-18 08:37:03 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:03 --> Input Class Initialized
INFO - 2023-04-18 08:37:03 --> Language Class Initialized
INFO - 2023-04-18 08:37:03 --> Loader Class Initialized
INFO - 2023-04-18 08:37:03 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:03 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:03 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:03 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:03 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:03 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:03 --> Total execution time: 0.0584
INFO - 2023-04-18 08:37:09 --> Config Class Initialized
INFO - 2023-04-18 08:37:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:09 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:09 --> URI Class Initialized
INFO - 2023-04-18 08:37:09 --> Router Class Initialized
INFO - 2023-04-18 08:37:09 --> Output Class Initialized
INFO - 2023-04-18 08:37:09 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:09 --> Input Class Initialized
INFO - 2023-04-18 08:37:09 --> Language Class Initialized
INFO - 2023-04-18 08:37:09 --> Loader Class Initialized
INFO - 2023-04-18 08:37:09 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:09 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:09 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:09 --> Total execution time: 0.0236
INFO - 2023-04-18 08:37:09 --> Config Class Initialized
INFO - 2023-04-18 08:37:09 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:09 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:09 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:09 --> URI Class Initialized
INFO - 2023-04-18 08:37:09 --> Router Class Initialized
INFO - 2023-04-18 08:37:09 --> Output Class Initialized
INFO - 2023-04-18 08:37:09 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:09 --> Input Class Initialized
INFO - 2023-04-18 08:37:09 --> Language Class Initialized
INFO - 2023-04-18 08:37:09 --> Loader Class Initialized
INFO - 2023-04-18 08:37:09 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:09 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:09 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:09 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:09 --> Total execution time: 0.0249
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:18 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:18 --> Total execution time: 0.0336
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
INFO - 2023-04-18 08:37:18 --> Final output sent to browser
INFO - 2023-04-18 08:37:18 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:18 --> Total execution time: 0.0390
DEBUG - 2023-04-18 08:37:18 --> Total execution time: 0.0429
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:18 --> Final output sent to browser
INFO - 2023-04-18 08:37:18 --> Final output sent to browser
INFO - 2023-04-18 08:37:18 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:18 --> Total execution time: 0.0677
DEBUG - 2023-04-18 08:37:18 --> Total execution time: 0.1084
DEBUG - 2023-04-18 08:37:18 --> Total execution time: 0.0653
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:18 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:18 --> Total execution time: 0.0715
INFO - 2023-04-18 08:37:18 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:18 --> Total execution time: 0.0781
INFO - 2023-04-18 08:37:18 --> Config Class Initialized
INFO - 2023-04-18 08:37:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:18 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:18 --> URI Class Initialized
INFO - 2023-04-18 08:37:18 --> Router Class Initialized
INFO - 2023-04-18 08:37:18 --> Output Class Initialized
INFO - 2023-04-18 08:37:18 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:18 --> Input Class Initialized
INFO - 2023-04-18 08:37:18 --> Language Class Initialized
INFO - 2023-04-18 08:37:18 --> Loader Class Initialized
INFO - 2023-04-18 08:37:18 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:18 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:18 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:19 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:19 --> Total execution time: 0.0144
INFO - 2023-04-18 08:37:19 --> Config Class Initialized
INFO - 2023-04-18 08:37:19 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:19 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:19 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:19 --> URI Class Initialized
INFO - 2023-04-18 08:37:19 --> Router Class Initialized
INFO - 2023-04-18 08:37:19 --> Output Class Initialized
INFO - 2023-04-18 08:37:19 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:19 --> Input Class Initialized
INFO - 2023-04-18 08:37:19 --> Language Class Initialized
INFO - 2023-04-18 08:37:19 --> Loader Class Initialized
INFO - 2023-04-18 08:37:19 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:19 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:19 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:19 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:19 --> Total execution time: 0.0131
INFO - 2023-04-18 08:37:21 --> Config Class Initialized
INFO - 2023-04-18 08:37:21 --> Hooks Class Initialized
INFO - 2023-04-18 08:37:21 --> Config Class Initialized
INFO - 2023-04-18 08:37:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:21 --> Utf8 Class Initialized
DEBUG - 2023-04-18 08:37:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:21 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:21 --> URI Class Initialized
INFO - 2023-04-18 08:37:21 --> URI Class Initialized
INFO - 2023-04-18 08:37:21 --> Router Class Initialized
INFO - 2023-04-18 08:37:21 --> Router Class Initialized
INFO - 2023-04-18 08:37:21 --> Output Class Initialized
INFO - 2023-04-18 08:37:21 --> Output Class Initialized
INFO - 2023-04-18 08:37:21 --> Security Class Initialized
INFO - 2023-04-18 08:37:21 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:21 --> Input Class Initialized
INFO - 2023-04-18 08:37:21 --> Input Class Initialized
INFO - 2023-04-18 08:37:21 --> Language Class Initialized
INFO - 2023-04-18 08:37:21 --> Language Class Initialized
INFO - 2023-04-18 08:37:21 --> Loader Class Initialized
INFO - 2023-04-18 08:37:21 --> Loader Class Initialized
INFO - 2023-04-18 08:37:21 --> Controller Class Initialized
INFO - 2023-04-18 08:37:21 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:37:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:21 --> Final output sent to browser
INFO - 2023-04-18 08:37:21 --> Database Driver Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Total execution time: 0.0478
INFO - 2023-04-18 08:37:21 --> Config Class Initialized
INFO - 2023-04-18 08:37:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:21 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:21 --> URI Class Initialized
INFO - 2023-04-18 08:37:21 --> Router Class Initialized
INFO - 2023-04-18 08:37:21 --> Output Class Initialized
INFO - 2023-04-18 08:37:21 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:21 --> Input Class Initialized
INFO - 2023-04-18 08:37:21 --> Language Class Initialized
INFO - 2023-04-18 08:37:21 --> Loader Class Initialized
INFO - 2023-04-18 08:37:21 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:21 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:21 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:21 --> Total execution time: 0.1495
INFO - 2023-04-18 08:37:21 --> Config Class Initialized
INFO - 2023-04-18 08:37:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:21 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:21 --> URI Class Initialized
INFO - 2023-04-18 08:37:21 --> Router Class Initialized
INFO - 2023-04-18 08:37:21 --> Output Class Initialized
INFO - 2023-04-18 08:37:21 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:21 --> Input Class Initialized
INFO - 2023-04-18 08:37:21 --> Language Class Initialized
INFO - 2023-04-18 08:37:21 --> Loader Class Initialized
INFO - 2023-04-18 08:37:21 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:21 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:21 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:21 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:21 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:21 --> Total execution time: 0.0128
INFO - 2023-04-18 08:37:21 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:21 --> Total execution time: 0.1139
INFO - 2023-04-18 08:37:21 --> Config Class Initialized
INFO - 2023-04-18 08:37:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:21 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:21 --> URI Class Initialized
INFO - 2023-04-18 08:37:21 --> Router Class Initialized
INFO - 2023-04-18 08:37:21 --> Output Class Initialized
INFO - 2023-04-18 08:37:21 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:21 --> Input Class Initialized
INFO - 2023-04-18 08:37:21 --> Language Class Initialized
INFO - 2023-04-18 08:37:21 --> Loader Class Initialized
INFO - 2023-04-18 08:37:21 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:21 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:21 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:21 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:21 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:21 --> Total execution time: 0.1106
INFO - 2023-04-18 08:37:21 --> Config Class Initialized
INFO - 2023-04-18 08:37:21 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:21 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:21 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:21 --> URI Class Initialized
INFO - 2023-04-18 08:37:21 --> Router Class Initialized
INFO - 2023-04-18 08:37:21 --> Output Class Initialized
INFO - 2023-04-18 08:37:21 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:21 --> Input Class Initialized
INFO - 2023-04-18 08:37:21 --> Language Class Initialized
INFO - 2023-04-18 08:37:21 --> Loader Class Initialized
INFO - 2023-04-18 08:37:21 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:21 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:21 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:21 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:21 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:21 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:21 --> Total execution time: 0.0632
INFO - 2023-04-18 08:37:53 --> Config Class Initialized
INFO - 2023-04-18 08:37:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:54 --> URI Class Initialized
INFO - 2023-04-18 08:37:54 --> Router Class Initialized
INFO - 2023-04-18 08:37:54 --> Output Class Initialized
INFO - 2023-04-18 08:37:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:54 --> Input Class Initialized
INFO - 2023-04-18 08:37:54 --> Language Class Initialized
INFO - 2023-04-18 08:37:54 --> Loader Class Initialized
INFO - 2023-04-18 08:37:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:54 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:54 --> Total execution time: 0.1451
INFO - 2023-04-18 08:37:54 --> Config Class Initialized
INFO - 2023-04-18 08:37:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:37:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:37:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:37:54 --> URI Class Initialized
INFO - 2023-04-18 08:37:54 --> Router Class Initialized
INFO - 2023-04-18 08:37:54 --> Output Class Initialized
INFO - 2023-04-18 08:37:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:37:54 --> Input Class Initialized
INFO - 2023-04-18 08:37:54 --> Language Class Initialized
INFO - 2023-04-18 08:37:54 --> Loader Class Initialized
INFO - 2023-04-18 08:37:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:37:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:37:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:37:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:37:54 --> Model "Login_model" initialized
INFO - 2023-04-18 08:37:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:37:54 --> Total execution time: 0.0596
INFO - 2023-04-18 08:38:10 --> Config Class Initialized
INFO - 2023-04-18 08:38:10 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:38:10 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:38:10 --> Utf8 Class Initialized
INFO - 2023-04-18 08:38:10 --> URI Class Initialized
INFO - 2023-04-18 08:38:10 --> Router Class Initialized
INFO - 2023-04-18 08:38:10 --> Output Class Initialized
INFO - 2023-04-18 08:38:10 --> Security Class Initialized
DEBUG - 2023-04-18 08:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:38:10 --> Input Class Initialized
INFO - 2023-04-18 08:38:10 --> Language Class Initialized
INFO - 2023-04-18 08:38:10 --> Loader Class Initialized
INFO - 2023-04-18 08:38:10 --> Controller Class Initialized
DEBUG - 2023-04-18 08:38:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:38:10 --> Database Driver Class Initialized
INFO - 2023-04-18 08:38:10 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:38:10 --> Final output sent to browser
DEBUG - 2023-04-18 08:38:10 --> Total execution time: 0.0237
INFO - 2023-04-18 08:38:10 --> Config Class Initialized
INFO - 2023-04-18 08:38:10 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:38:10 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:38:10 --> Utf8 Class Initialized
INFO - 2023-04-18 08:38:10 --> URI Class Initialized
INFO - 2023-04-18 08:38:10 --> Router Class Initialized
INFO - 2023-04-18 08:38:10 --> Output Class Initialized
INFO - 2023-04-18 08:38:10 --> Security Class Initialized
DEBUG - 2023-04-18 08:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:38:10 --> Input Class Initialized
INFO - 2023-04-18 08:38:10 --> Language Class Initialized
INFO - 2023-04-18 08:38:10 --> Loader Class Initialized
INFO - 2023-04-18 08:38:10 --> Controller Class Initialized
DEBUG - 2023-04-18 08:38:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:38:10 --> Database Driver Class Initialized
INFO - 2023-04-18 08:38:10 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:38:10 --> Final output sent to browser
DEBUG - 2023-04-18 08:38:10 --> Total execution time: 0.0598
INFO - 2023-04-18 08:38:32 --> Config Class Initialized
INFO - 2023-04-18 08:38:32 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:38:32 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:38:32 --> Utf8 Class Initialized
INFO - 2023-04-18 08:38:32 --> URI Class Initialized
INFO - 2023-04-18 08:38:32 --> Router Class Initialized
INFO - 2023-04-18 08:38:32 --> Output Class Initialized
INFO - 2023-04-18 08:38:32 --> Security Class Initialized
DEBUG - 2023-04-18 08:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:38:32 --> Input Class Initialized
INFO - 2023-04-18 08:38:32 --> Language Class Initialized
INFO - 2023-04-18 08:38:32 --> Loader Class Initialized
INFO - 2023-04-18 08:38:32 --> Controller Class Initialized
DEBUG - 2023-04-18 08:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:38:32 --> Database Driver Class Initialized
INFO - 2023-04-18 08:38:32 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:38:32 --> Final output sent to browser
DEBUG - 2023-04-18 08:38:32 --> Total execution time: 0.0634
INFO - 2023-04-18 08:38:32 --> Config Class Initialized
INFO - 2023-04-18 08:38:32 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:38:32 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:38:32 --> Utf8 Class Initialized
INFO - 2023-04-18 08:38:32 --> URI Class Initialized
INFO - 2023-04-18 08:38:32 --> Router Class Initialized
INFO - 2023-04-18 08:38:32 --> Output Class Initialized
INFO - 2023-04-18 08:38:32 --> Security Class Initialized
DEBUG - 2023-04-18 08:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:38:32 --> Input Class Initialized
INFO - 2023-04-18 08:38:32 --> Language Class Initialized
INFO - 2023-04-18 08:38:32 --> Loader Class Initialized
INFO - 2023-04-18 08:38:32 --> Controller Class Initialized
DEBUG - 2023-04-18 08:38:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:38:32 --> Database Driver Class Initialized
INFO - 2023-04-18 08:38:32 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:38:32 --> Final output sent to browser
DEBUG - 2023-04-18 08:38:32 --> Total execution time: 0.0204
INFO - 2023-04-18 08:38:44 --> Config Class Initialized
INFO - 2023-04-18 08:38:44 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:38:44 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:38:44 --> Utf8 Class Initialized
INFO - 2023-04-18 08:38:44 --> URI Class Initialized
INFO - 2023-04-18 08:38:44 --> Router Class Initialized
INFO - 2023-04-18 08:38:44 --> Output Class Initialized
INFO - 2023-04-18 08:38:44 --> Security Class Initialized
DEBUG - 2023-04-18 08:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:38:44 --> Input Class Initialized
INFO - 2023-04-18 08:38:44 --> Language Class Initialized
INFO - 2023-04-18 08:38:44 --> Loader Class Initialized
INFO - 2023-04-18 08:38:44 --> Controller Class Initialized
DEBUG - 2023-04-18 08:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:38:44 --> Database Driver Class Initialized
INFO - 2023-04-18 08:38:44 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:38:44 --> Final output sent to browser
DEBUG - 2023-04-18 08:38:44 --> Total execution time: 0.0224
INFO - 2023-04-18 08:38:45 --> Config Class Initialized
INFO - 2023-04-18 08:38:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:38:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:38:45 --> Utf8 Class Initialized
INFO - 2023-04-18 08:38:45 --> URI Class Initialized
INFO - 2023-04-18 08:38:45 --> Router Class Initialized
INFO - 2023-04-18 08:38:45 --> Output Class Initialized
INFO - 2023-04-18 08:38:45 --> Security Class Initialized
DEBUG - 2023-04-18 08:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:38:45 --> Input Class Initialized
INFO - 2023-04-18 08:38:45 --> Language Class Initialized
INFO - 2023-04-18 08:38:45 --> Loader Class Initialized
INFO - 2023-04-18 08:38:45 --> Controller Class Initialized
DEBUG - 2023-04-18 08:38:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:38:45 --> Database Driver Class Initialized
INFO - 2023-04-18 08:38:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:38:45 --> Final output sent to browser
DEBUG - 2023-04-18 08:38:45 --> Total execution time: 0.0196
INFO - 2023-04-18 08:39:34 --> Config Class Initialized
INFO - 2023-04-18 08:39:34 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:39:34 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:39:34 --> Utf8 Class Initialized
INFO - 2023-04-18 08:39:34 --> URI Class Initialized
INFO - 2023-04-18 08:39:34 --> Router Class Initialized
INFO - 2023-04-18 08:39:34 --> Output Class Initialized
INFO - 2023-04-18 08:39:34 --> Security Class Initialized
DEBUG - 2023-04-18 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:39:34 --> Input Class Initialized
INFO - 2023-04-18 08:39:34 --> Language Class Initialized
INFO - 2023-04-18 08:39:34 --> Loader Class Initialized
INFO - 2023-04-18 08:39:34 --> Controller Class Initialized
DEBUG - 2023-04-18 08:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:39:34 --> Database Driver Class Initialized
INFO - 2023-04-18 08:39:34 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:39:34 --> Database Driver Class Initialized
INFO - 2023-04-18 08:39:34 --> Model "Login_model" initialized
INFO - 2023-04-18 08:39:34 --> Final output sent to browser
DEBUG - 2023-04-18 08:39:34 --> Total execution time: 0.1700
INFO - 2023-04-18 08:39:34 --> Config Class Initialized
INFO - 2023-04-18 08:39:34 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:39:34 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:39:34 --> Utf8 Class Initialized
INFO - 2023-04-18 08:39:34 --> URI Class Initialized
INFO - 2023-04-18 08:39:34 --> Router Class Initialized
INFO - 2023-04-18 08:39:34 --> Output Class Initialized
INFO - 2023-04-18 08:39:34 --> Security Class Initialized
DEBUG - 2023-04-18 08:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:39:34 --> Input Class Initialized
INFO - 2023-04-18 08:39:34 --> Language Class Initialized
INFO - 2023-04-18 08:39:34 --> Loader Class Initialized
INFO - 2023-04-18 08:39:34 --> Controller Class Initialized
DEBUG - 2023-04-18 08:39:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:39:34 --> Database Driver Class Initialized
INFO - 2023-04-18 08:39:34 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:39:34 --> Database Driver Class Initialized
INFO - 2023-04-18 08:39:34 --> Model "Login_model" initialized
INFO - 2023-04-18 08:39:34 --> Final output sent to browser
DEBUG - 2023-04-18 08:39:34 --> Total execution time: 0.0600
INFO - 2023-04-18 08:39:39 --> Config Class Initialized
INFO - 2023-04-18 08:39:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:39:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:39:39 --> Utf8 Class Initialized
INFO - 2023-04-18 08:39:39 --> URI Class Initialized
INFO - 2023-04-18 08:39:39 --> Router Class Initialized
INFO - 2023-04-18 08:39:39 --> Output Class Initialized
INFO - 2023-04-18 08:39:39 --> Security Class Initialized
DEBUG - 2023-04-18 08:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:39:39 --> Input Class Initialized
INFO - 2023-04-18 08:39:39 --> Language Class Initialized
INFO - 2023-04-18 08:39:39 --> Loader Class Initialized
INFO - 2023-04-18 08:39:39 --> Controller Class Initialized
DEBUG - 2023-04-18 08:39:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:39:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:39:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:39:39 --> Final output sent to browser
DEBUG - 2023-04-18 08:39:39 --> Total execution time: 0.0242
INFO - 2023-04-18 08:39:39 --> Config Class Initialized
INFO - 2023-04-18 08:39:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:39:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:39:39 --> Utf8 Class Initialized
INFO - 2023-04-18 08:39:39 --> URI Class Initialized
INFO - 2023-04-18 08:39:39 --> Router Class Initialized
INFO - 2023-04-18 08:39:39 --> Output Class Initialized
INFO - 2023-04-18 08:39:39 --> Security Class Initialized
DEBUG - 2023-04-18 08:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:39:39 --> Input Class Initialized
INFO - 2023-04-18 08:39:39 --> Language Class Initialized
INFO - 2023-04-18 08:39:39 --> Loader Class Initialized
INFO - 2023-04-18 08:39:39 --> Controller Class Initialized
DEBUG - 2023-04-18 08:39:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:39:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:39:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:39:39 --> Final output sent to browser
DEBUG - 2023-04-18 08:39:39 --> Total execution time: 0.0203
INFO - 2023-04-18 08:40:03 --> Config Class Initialized
INFO - 2023-04-18 08:40:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:40:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:40:03 --> Utf8 Class Initialized
INFO - 2023-04-18 08:40:03 --> URI Class Initialized
INFO - 2023-04-18 08:40:03 --> Router Class Initialized
INFO - 2023-04-18 08:40:03 --> Output Class Initialized
INFO - 2023-04-18 08:40:03 --> Security Class Initialized
DEBUG - 2023-04-18 08:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:40:03 --> Input Class Initialized
INFO - 2023-04-18 08:40:03 --> Language Class Initialized
INFO - 2023-04-18 08:40:03 --> Loader Class Initialized
INFO - 2023-04-18 08:40:03 --> Controller Class Initialized
DEBUG - 2023-04-18 08:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:40:03 --> Database Driver Class Initialized
INFO - 2023-04-18 08:40:03 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:40:03 --> Database Driver Class Initialized
INFO - 2023-04-18 08:40:03 --> Model "Login_model" initialized
INFO - 2023-04-18 08:40:03 --> Final output sent to browser
DEBUG - 2023-04-18 08:40:03 --> Total execution time: 0.1387
INFO - 2023-04-18 08:40:03 --> Config Class Initialized
INFO - 2023-04-18 08:40:03 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:40:03 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:40:03 --> Utf8 Class Initialized
INFO - 2023-04-18 08:40:03 --> URI Class Initialized
INFO - 2023-04-18 08:40:03 --> Router Class Initialized
INFO - 2023-04-18 08:40:03 --> Output Class Initialized
INFO - 2023-04-18 08:40:03 --> Security Class Initialized
DEBUG - 2023-04-18 08:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:40:03 --> Input Class Initialized
INFO - 2023-04-18 08:40:03 --> Language Class Initialized
INFO - 2023-04-18 08:40:03 --> Loader Class Initialized
INFO - 2023-04-18 08:40:03 --> Controller Class Initialized
DEBUG - 2023-04-18 08:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:40:03 --> Database Driver Class Initialized
INFO - 2023-04-18 08:40:03 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:40:03 --> Database Driver Class Initialized
INFO - 2023-04-18 08:40:03 --> Model "Login_model" initialized
INFO - 2023-04-18 08:40:03 --> Final output sent to browser
DEBUG - 2023-04-18 08:40:03 --> Total execution time: 0.0856
INFO - 2023-04-18 08:40:05 --> Config Class Initialized
INFO - 2023-04-18 08:40:05 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:40:05 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:40:05 --> Utf8 Class Initialized
INFO - 2023-04-18 08:40:05 --> URI Class Initialized
INFO - 2023-04-18 08:40:05 --> Router Class Initialized
INFO - 2023-04-18 08:40:05 --> Output Class Initialized
INFO - 2023-04-18 08:40:05 --> Security Class Initialized
DEBUG - 2023-04-18 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:40:05 --> Input Class Initialized
INFO - 2023-04-18 08:40:05 --> Language Class Initialized
INFO - 2023-04-18 08:40:05 --> Loader Class Initialized
INFO - 2023-04-18 08:40:05 --> Controller Class Initialized
DEBUG - 2023-04-18 08:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:40:05 --> Database Driver Class Initialized
INFO - 2023-04-18 08:40:05 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:40:05 --> Final output sent to browser
DEBUG - 2023-04-18 08:40:05 --> Total execution time: 0.0224
INFO - 2023-04-18 08:40:05 --> Config Class Initialized
INFO - 2023-04-18 08:40:05 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:40:05 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:40:05 --> Utf8 Class Initialized
INFO - 2023-04-18 08:40:05 --> URI Class Initialized
INFO - 2023-04-18 08:40:05 --> Router Class Initialized
INFO - 2023-04-18 08:40:05 --> Output Class Initialized
INFO - 2023-04-18 08:40:05 --> Security Class Initialized
DEBUG - 2023-04-18 08:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:40:05 --> Input Class Initialized
INFO - 2023-04-18 08:40:05 --> Language Class Initialized
INFO - 2023-04-18 08:40:05 --> Loader Class Initialized
INFO - 2023-04-18 08:40:05 --> Controller Class Initialized
DEBUG - 2023-04-18 08:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:40:05 --> Database Driver Class Initialized
INFO - 2023-04-18 08:40:05 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:40:06 --> Final output sent to browser
DEBUG - 2023-04-18 08:40:06 --> Total execution time: 0.0195
INFO - 2023-04-18 08:41:10 --> Config Class Initialized
INFO - 2023-04-18 08:41:10 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:10 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:10 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:10 --> URI Class Initialized
INFO - 2023-04-18 08:41:10 --> Router Class Initialized
INFO - 2023-04-18 08:41:10 --> Output Class Initialized
INFO - 2023-04-18 08:41:10 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:10 --> Input Class Initialized
INFO - 2023-04-18 08:41:10 --> Language Class Initialized
INFO - 2023-04-18 08:41:10 --> Loader Class Initialized
INFO - 2023-04-18 08:41:10 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:10 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:10 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:10 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:11 --> Total execution time: 0.0623
INFO - 2023-04-18 08:41:11 --> Config Class Initialized
INFO - 2023-04-18 08:41:11 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:11 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:11 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:11 --> URI Class Initialized
INFO - 2023-04-18 08:41:11 --> Router Class Initialized
INFO - 2023-04-18 08:41:11 --> Output Class Initialized
INFO - 2023-04-18 08:41:11 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:11 --> Input Class Initialized
INFO - 2023-04-18 08:41:11 --> Language Class Initialized
INFO - 2023-04-18 08:41:11 --> Loader Class Initialized
INFO - 2023-04-18 08:41:11 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:11 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:11 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:11 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:11 --> Total execution time: 0.0189
INFO - 2023-04-18 08:41:37 --> Config Class Initialized
INFO - 2023-04-18 08:41:37 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:37 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:37 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:37 --> URI Class Initialized
INFO - 2023-04-18 08:41:37 --> Router Class Initialized
INFO - 2023-04-18 08:41:37 --> Output Class Initialized
INFO - 2023-04-18 08:41:37 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:37 --> Input Class Initialized
INFO - 2023-04-18 08:41:37 --> Language Class Initialized
INFO - 2023-04-18 08:41:37 --> Loader Class Initialized
INFO - 2023-04-18 08:41:37 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:37 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:37 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:37 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:37 --> Total execution time: 0.0543
INFO - 2023-04-18 08:41:37 --> Config Class Initialized
INFO - 2023-04-18 08:41:37 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:37 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:37 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:37 --> URI Class Initialized
INFO - 2023-04-18 08:41:37 --> Router Class Initialized
INFO - 2023-04-18 08:41:37 --> Output Class Initialized
INFO - 2023-04-18 08:41:37 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:37 --> Input Class Initialized
INFO - 2023-04-18 08:41:37 --> Language Class Initialized
INFO - 2023-04-18 08:41:37 --> Loader Class Initialized
INFO - 2023-04-18 08:41:37 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:37 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:37 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:37 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:37 --> Total execution time: 0.0546
INFO - 2023-04-18 08:41:38 --> Config Class Initialized
INFO - 2023-04-18 08:41:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:38 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:38 --> URI Class Initialized
INFO - 2023-04-18 08:41:38 --> Router Class Initialized
INFO - 2023-04-18 08:41:38 --> Output Class Initialized
INFO - 2023-04-18 08:41:38 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:38 --> Input Class Initialized
INFO - 2023-04-18 08:41:38 --> Language Class Initialized
INFO - 2023-04-18 08:41:38 --> Loader Class Initialized
INFO - 2023-04-18 08:41:38 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:38 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:38 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:38 --> Total execution time: 0.0142
INFO - 2023-04-18 08:41:38 --> Config Class Initialized
INFO - 2023-04-18 08:41:38 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:38 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:38 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:38 --> URI Class Initialized
INFO - 2023-04-18 08:41:38 --> Router Class Initialized
INFO - 2023-04-18 08:41:38 --> Output Class Initialized
INFO - 2023-04-18 08:41:38 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:38 --> Input Class Initialized
INFO - 2023-04-18 08:41:38 --> Language Class Initialized
INFO - 2023-04-18 08:41:38 --> Loader Class Initialized
INFO - 2023-04-18 08:41:38 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:38 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:38 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:38 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:38 --> Total execution time: 0.0586
INFO - 2023-04-18 08:41:39 --> Config Class Initialized
INFO - 2023-04-18 08:41:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:39 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:39 --> URI Class Initialized
INFO - 2023-04-18 08:41:39 --> Router Class Initialized
INFO - 2023-04-18 08:41:39 --> Output Class Initialized
INFO - 2023-04-18 08:41:39 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:39 --> Input Class Initialized
INFO - 2023-04-18 08:41:39 --> Language Class Initialized
INFO - 2023-04-18 08:41:39 --> Loader Class Initialized
INFO - 2023-04-18 08:41:39 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:39 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:39 --> Total execution time: 0.0131
INFO - 2023-04-18 08:41:39 --> Config Class Initialized
INFO - 2023-04-18 08:41:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:39 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:39 --> URI Class Initialized
INFO - 2023-04-18 08:41:39 --> Router Class Initialized
INFO - 2023-04-18 08:41:39 --> Output Class Initialized
INFO - 2023-04-18 08:41:39 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:39 --> Input Class Initialized
INFO - 2023-04-18 08:41:39 --> Language Class Initialized
INFO - 2023-04-18 08:41:39 --> Loader Class Initialized
INFO - 2023-04-18 08:41:39 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:39 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:39 --> Total execution time: 0.0118
INFO - 2023-04-18 08:41:45 --> Config Class Initialized
INFO - 2023-04-18 08:41:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:45 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:45 --> URI Class Initialized
INFO - 2023-04-18 08:41:45 --> Router Class Initialized
INFO - 2023-04-18 08:41:45 --> Output Class Initialized
INFO - 2023-04-18 08:41:45 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:45 --> Input Class Initialized
INFO - 2023-04-18 08:41:45 --> Language Class Initialized
INFO - 2023-04-18 08:41:45 --> Loader Class Initialized
INFO - 2023-04-18 08:41:45 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:45 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:45 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:45 --> Total execution time: 0.0160
INFO - 2023-04-18 08:41:45 --> Config Class Initialized
INFO - 2023-04-18 08:41:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:45 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:45 --> URI Class Initialized
INFO - 2023-04-18 08:41:45 --> Router Class Initialized
INFO - 2023-04-18 08:41:45 --> Output Class Initialized
INFO - 2023-04-18 08:41:45 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:45 --> Input Class Initialized
INFO - 2023-04-18 08:41:45 --> Language Class Initialized
INFO - 2023-04-18 08:41:45 --> Loader Class Initialized
INFO - 2023-04-18 08:41:45 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:45 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:45 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:45 --> Total execution time: 0.0115
INFO - 2023-04-18 08:41:48 --> Config Class Initialized
INFO - 2023-04-18 08:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:48 --> URI Class Initialized
INFO - 2023-04-18 08:41:48 --> Router Class Initialized
INFO - 2023-04-18 08:41:48 --> Output Class Initialized
INFO - 2023-04-18 08:41:48 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:48 --> Input Class Initialized
INFO - 2023-04-18 08:41:48 --> Language Class Initialized
INFO - 2023-04-18 08:41:48 --> Loader Class Initialized
INFO - 2023-04-18 08:41:48 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:48 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:48 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:48 --> Total execution time: 0.0368
INFO - 2023-04-18 08:41:48 --> Config Class Initialized
INFO - 2023-04-18 08:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:48 --> URI Class Initialized
INFO - 2023-04-18 08:41:48 --> Router Class Initialized
INFO - 2023-04-18 08:41:48 --> Output Class Initialized
INFO - 2023-04-18 08:41:48 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:48 --> Input Class Initialized
INFO - 2023-04-18 08:41:48 --> Language Class Initialized
INFO - 2023-04-18 08:41:48 --> Loader Class Initialized
INFO - 2023-04-18 08:41:48 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:48 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:49 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:49 --> Total execution time: 0.0771
INFO - 2023-04-18 08:41:54 --> Config Class Initialized
INFO - 2023-04-18 08:41:54 --> Config Class Initialized
INFO - 2023-04-18 08:41:54 --> Hooks Class Initialized
INFO - 2023-04-18 08:41:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 08:41:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:54 --> URI Class Initialized
INFO - 2023-04-18 08:41:54 --> URI Class Initialized
INFO - 2023-04-18 08:41:54 --> Router Class Initialized
INFO - 2023-04-18 08:41:54 --> Router Class Initialized
INFO - 2023-04-18 08:41:54 --> Output Class Initialized
INFO - 2023-04-18 08:41:54 --> Output Class Initialized
INFO - 2023-04-18 08:41:54 --> Security Class Initialized
INFO - 2023-04-18 08:41:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 08:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:54 --> Input Class Initialized
INFO - 2023-04-18 08:41:54 --> Input Class Initialized
INFO - 2023-04-18 08:41:54 --> Language Class Initialized
INFO - 2023-04-18 08:41:54 --> Language Class Initialized
INFO - 2023-04-18 08:41:54 --> Loader Class Initialized
INFO - 2023-04-18 08:41:54 --> Loader Class Initialized
INFO - 2023-04-18 08:41:54 --> Controller Class Initialized
INFO - 2023-04-18 08:41:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:54 --> Final output sent to browser
INFO - 2023-04-18 08:41:54 --> Database Driver Class Initialized
DEBUG - 2023-04-18 08:41:54 --> Total execution time: 0.0059
INFO - 2023-04-18 08:41:54 --> Config Class Initialized
INFO - 2023-04-18 08:41:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:54 --> URI Class Initialized
INFO - 2023-04-18 08:41:54 --> Router Class Initialized
INFO - 2023-04-18 08:41:54 --> Output Class Initialized
INFO - 2023-04-18 08:41:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:54 --> Input Class Initialized
INFO - 2023-04-18 08:41:54 --> Language Class Initialized
INFO - 2023-04-18 08:41:54 --> Loader Class Initialized
INFO - 2023-04-18 08:41:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:54 --> Model "Login_model" initialized
INFO - 2023-04-18 08:41:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:54 --> Total execution time: 0.0202
INFO - 2023-04-18 08:41:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:54 --> Config Class Initialized
INFO - 2023-04-18 08:41:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:54 --> URI Class Initialized
INFO - 2023-04-18 08:41:54 --> Router Class Initialized
INFO - 2023-04-18 08:41:54 --> Output Class Initialized
INFO - 2023-04-18 08:41:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:54 --> Input Class Initialized
INFO - 2023-04-18 08:41:54 --> Language Class Initialized
INFO - 2023-04-18 08:41:54 --> Loader Class Initialized
INFO - 2023-04-18 08:41:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:54 --> Total execution time: 0.0249
INFO - 2023-04-18 08:41:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:54 --> Total execution time: 0.0141
INFO - 2023-04-18 08:41:57 --> Config Class Initialized
INFO - 2023-04-18 08:41:57 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:57 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:57 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:57 --> URI Class Initialized
INFO - 2023-04-18 08:41:57 --> Router Class Initialized
INFO - 2023-04-18 08:41:57 --> Output Class Initialized
INFO - 2023-04-18 08:41:57 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:57 --> Input Class Initialized
INFO - 2023-04-18 08:41:57 --> Language Class Initialized
INFO - 2023-04-18 08:41:57 --> Loader Class Initialized
INFO - 2023-04-18 08:41:57 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:57 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:57 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:57 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:57 --> Model "Login_model" initialized
INFO - 2023-04-18 08:41:57 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:57 --> Total execution time: 0.0787
INFO - 2023-04-18 08:41:57 --> Config Class Initialized
INFO - 2023-04-18 08:41:57 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:41:57 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:41:57 --> Utf8 Class Initialized
INFO - 2023-04-18 08:41:57 --> URI Class Initialized
INFO - 2023-04-18 08:41:57 --> Router Class Initialized
INFO - 2023-04-18 08:41:57 --> Output Class Initialized
INFO - 2023-04-18 08:41:57 --> Security Class Initialized
DEBUG - 2023-04-18 08:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:41:57 --> Input Class Initialized
INFO - 2023-04-18 08:41:57 --> Language Class Initialized
INFO - 2023-04-18 08:41:57 --> Loader Class Initialized
INFO - 2023-04-18 08:41:57 --> Controller Class Initialized
DEBUG - 2023-04-18 08:41:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:41:57 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:57 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:41:57 --> Database Driver Class Initialized
INFO - 2023-04-18 08:41:57 --> Model "Login_model" initialized
INFO - 2023-04-18 08:41:57 --> Final output sent to browser
DEBUG - 2023-04-18 08:41:57 --> Total execution time: 0.0853
INFO - 2023-04-18 08:42:31 --> Config Class Initialized
INFO - 2023-04-18 08:42:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:31 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:31 --> URI Class Initialized
INFO - 2023-04-18 08:42:31 --> Router Class Initialized
INFO - 2023-04-18 08:42:31 --> Output Class Initialized
INFO - 2023-04-18 08:42:31 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:31 --> Input Class Initialized
INFO - 2023-04-18 08:42:31 --> Language Class Initialized
INFO - 2023-04-18 08:42:31 --> Loader Class Initialized
INFO - 2023-04-18 08:42:31 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:31 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:31 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:31 --> Model "Login_model" initialized
INFO - 2023-04-18 08:42:31 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:31 --> Total execution time: 0.1459
INFO - 2023-04-18 08:42:31 --> Config Class Initialized
INFO - 2023-04-18 08:42:31 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:31 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:31 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:31 --> URI Class Initialized
INFO - 2023-04-18 08:42:31 --> Router Class Initialized
INFO - 2023-04-18 08:42:31 --> Output Class Initialized
INFO - 2023-04-18 08:42:31 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:31 --> Input Class Initialized
INFO - 2023-04-18 08:42:31 --> Language Class Initialized
INFO - 2023-04-18 08:42:31 --> Loader Class Initialized
INFO - 2023-04-18 08:42:31 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:31 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:31 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:31 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:31 --> Model "Login_model" initialized
INFO - 2023-04-18 08:42:31 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:31 --> Total execution time: 0.0618
INFO - 2023-04-18 08:42:47 --> Config Class Initialized
INFO - 2023-04-18 08:42:47 --> Config Class Initialized
INFO - 2023-04-18 08:42:47 --> Hooks Class Initialized
INFO - 2023-04-18 08:42:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:47 --> Utf8 Class Initialized
DEBUG - 2023-04-18 08:42:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:47 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:47 --> URI Class Initialized
INFO - 2023-04-18 08:42:47 --> URI Class Initialized
INFO - 2023-04-18 08:42:47 --> Router Class Initialized
INFO - 2023-04-18 08:42:47 --> Router Class Initialized
INFO - 2023-04-18 08:42:47 --> Output Class Initialized
INFO - 2023-04-18 08:42:47 --> Output Class Initialized
INFO - 2023-04-18 08:42:47 --> Security Class Initialized
INFO - 2023-04-18 08:42:47 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:47 --> Input Class Initialized
INFO - 2023-04-18 08:42:47 --> Input Class Initialized
INFO - 2023-04-18 08:42:47 --> Language Class Initialized
INFO - 2023-04-18 08:42:47 --> Language Class Initialized
INFO - 2023-04-18 08:42:47 --> Loader Class Initialized
INFO - 2023-04-18 08:42:47 --> Loader Class Initialized
INFO - 2023-04-18 08:42:47 --> Controller Class Initialized
INFO - 2023-04-18 08:42:47 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:47 --> Final output sent to browser
INFO - 2023-04-18 08:42:47 --> Database Driver Class Initialized
DEBUG - 2023-04-18 08:42:47 --> Total execution time: 0.0048
INFO - 2023-04-18 08:42:47 --> Config Class Initialized
INFO - 2023-04-18 08:42:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:47 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:47 --> URI Class Initialized
INFO - 2023-04-18 08:42:47 --> Router Class Initialized
INFO - 2023-04-18 08:42:47 --> Output Class Initialized
INFO - 2023-04-18 08:42:47 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:47 --> Input Class Initialized
INFO - 2023-04-18 08:42:47 --> Language Class Initialized
INFO - 2023-04-18 08:42:47 --> Loader Class Initialized
INFO - 2023-04-18 08:42:47 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:47 --> Model "Login_model" initialized
INFO - 2023-04-18 08:42:47 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:47 --> Total execution time: 0.0180
INFO - 2023-04-18 08:42:47 --> Config Class Initialized
INFO - 2023-04-18 08:42:47 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:47 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:47 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:47 --> URI Class Initialized
INFO - 2023-04-18 08:42:47 --> Router Class Initialized
INFO - 2023-04-18 08:42:47 --> Output Class Initialized
INFO - 2023-04-18 08:42:47 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:47 --> Input Class Initialized
INFO - 2023-04-18 08:42:47 --> Language Class Initialized
INFO - 2023-04-18 08:42:47 --> Loader Class Initialized
INFO - 2023-04-18 08:42:47 --> Controller Class Initialized
INFO - 2023-04-18 08:42:47 --> Database Driver Class Initialized
DEBUG - 2023-04-18 08:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:47 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:47 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:47 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:47 --> Total execution time: 0.0297
INFO - 2023-04-18 08:42:47 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:47 --> Total execution time: 0.0187
INFO - 2023-04-18 08:42:48 --> Config Class Initialized
INFO - 2023-04-18 08:42:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:48 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:48 --> URI Class Initialized
INFO - 2023-04-18 08:42:48 --> Router Class Initialized
INFO - 2023-04-18 08:42:48 --> Output Class Initialized
INFO - 2023-04-18 08:42:48 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:48 --> Input Class Initialized
INFO - 2023-04-18 08:42:48 --> Language Class Initialized
INFO - 2023-04-18 08:42:48 --> Loader Class Initialized
INFO - 2023-04-18 08:42:48 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:48 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:48 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:48 --> Total execution time: 0.0385
INFO - 2023-04-18 08:42:48 --> Config Class Initialized
INFO - 2023-04-18 08:42:48 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:48 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:48 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:48 --> URI Class Initialized
INFO - 2023-04-18 08:42:48 --> Router Class Initialized
INFO - 2023-04-18 08:42:48 --> Output Class Initialized
INFO - 2023-04-18 08:42:48 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:48 --> Input Class Initialized
INFO - 2023-04-18 08:42:48 --> Language Class Initialized
INFO - 2023-04-18 08:42:48 --> Loader Class Initialized
INFO - 2023-04-18 08:42:48 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:48 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:48 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:48 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:48 --> Total execution time: 0.0768
INFO - 2023-04-18 08:42:52 --> Config Class Initialized
INFO - 2023-04-18 08:42:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:52 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:52 --> URI Class Initialized
INFO - 2023-04-18 08:42:52 --> Router Class Initialized
INFO - 2023-04-18 08:42:52 --> Output Class Initialized
INFO - 2023-04-18 08:42:52 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:52 --> Input Class Initialized
INFO - 2023-04-18 08:42:52 --> Language Class Initialized
INFO - 2023-04-18 08:42:52 --> Loader Class Initialized
INFO - 2023-04-18 08:42:52 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:52 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:52 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:52 --> Total execution time: 0.0182
INFO - 2023-04-18 08:42:52 --> Config Class Initialized
INFO - 2023-04-18 08:42:52 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:52 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:52 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:52 --> URI Class Initialized
INFO - 2023-04-18 08:42:52 --> Router Class Initialized
INFO - 2023-04-18 08:42:52 --> Output Class Initialized
INFO - 2023-04-18 08:42:52 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:52 --> Input Class Initialized
INFO - 2023-04-18 08:42:52 --> Language Class Initialized
INFO - 2023-04-18 08:42:52 --> Loader Class Initialized
INFO - 2023-04-18 08:42:52 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:52 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:52 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:52 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:52 --> Total execution time: 0.0159
INFO - 2023-04-18 08:42:54 --> Config Class Initialized
INFO - 2023-04-18 08:42:54 --> Config Class Initialized
INFO - 2023-04-18 08:42:54 --> Config Class Initialized
INFO - 2023-04-18 08:42:54 --> Hooks Class Initialized
INFO - 2023-04-18 08:42:54 --> Hooks Class Initialized
INFO - 2023-04-18 08:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 08:42:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 08:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:54 --> URI Class Initialized
INFO - 2023-04-18 08:42:54 --> URI Class Initialized
INFO - 2023-04-18 08:42:54 --> URI Class Initialized
INFO - 2023-04-18 08:42:54 --> Router Class Initialized
INFO - 2023-04-18 08:42:54 --> Router Class Initialized
INFO - 2023-04-18 08:42:54 --> Router Class Initialized
INFO - 2023-04-18 08:42:54 --> Output Class Initialized
INFO - 2023-04-18 08:42:54 --> Output Class Initialized
INFO - 2023-04-18 08:42:54 --> Output Class Initialized
INFO - 2023-04-18 08:42:54 --> Security Class Initialized
INFO - 2023-04-18 08:42:54 --> Security Class Initialized
INFO - 2023-04-18 08:42:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 08:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:54 --> Input Class Initialized
INFO - 2023-04-18 08:42:54 --> Input Class Initialized
INFO - 2023-04-18 08:42:54 --> Input Class Initialized
INFO - 2023-04-18 08:42:54 --> Language Class Initialized
INFO - 2023-04-18 08:42:54 --> Language Class Initialized
INFO - 2023-04-18 08:42:54 --> Language Class Initialized
INFO - 2023-04-18 08:42:54 --> Loader Class Initialized
INFO - 2023-04-18 08:42:54 --> Loader Class Initialized
INFO - 2023-04-18 08:42:54 --> Loader Class Initialized
INFO - 2023-04-18 08:42:54 --> Controller Class Initialized
INFO - 2023-04-18 08:42:54 --> Controller Class Initialized
INFO - 2023-04-18 08:42:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Model "Login_model" initialized
INFO - 2023-04-18 08:42:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:54 --> Total execution time: 0.0321
INFO - 2023-04-18 08:42:54 --> Config Class Initialized
INFO - 2023-04-18 08:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:54 --> URI Class Initialized
INFO - 2023-04-18 08:42:54 --> Router Class Initialized
INFO - 2023-04-18 08:42:54 --> Output Class Initialized
INFO - 2023-04-18 08:42:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:54 --> Input Class Initialized
INFO - 2023-04-18 08:42:54 --> Language Class Initialized
INFO - 2023-04-18 08:42:54 --> Loader Class Initialized
INFO - 2023-04-18 08:42:54 --> Controller Class Initialized
INFO - 2023-04-18 08:42:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:42:54 --> Total execution time: 0.0355
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Config Class Initialized
INFO - 2023-04-18 08:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:54 --> URI Class Initialized
INFO - 2023-04-18 08:42:54 --> Router Class Initialized
INFO - 2023-04-18 08:42:54 --> Output Class Initialized
INFO - 2023-04-18 08:42:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:54 --> Input Class Initialized
INFO - 2023-04-18 08:42:54 --> Language Class Initialized
INFO - 2023-04-18 08:42:54 --> Loader Class Initialized
INFO - 2023-04-18 08:42:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:54 --> Total execution time: 0.0391
INFO - 2023-04-18 08:42:54 --> Config Class Initialized
INFO - 2023-04-18 08:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:54 --> URI Class Initialized
INFO - 2023-04-18 08:42:54 --> Router Class Initialized
INFO - 2023-04-18 08:42:54 --> Output Class Initialized
INFO - 2023-04-18 08:42:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:54 --> Input Class Initialized
INFO - 2023-04-18 08:42:54 --> Language Class Initialized
INFO - 2023-04-18 08:42:54 --> Loader Class Initialized
INFO - 2023-04-18 08:42:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:54 --> Model "Login_model" initialized
INFO - 2023-04-18 08:42:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:54 --> Total execution time: 0.0264
INFO - 2023-04-18 08:42:54 --> Config Class Initialized
INFO - 2023-04-18 08:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:54 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:54 --> URI Class Initialized
INFO - 2023-04-18 08:42:54 --> Router Class Initialized
INFO - 2023-04-18 08:42:54 --> Output Class Initialized
INFO - 2023-04-18 08:42:54 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:54 --> Input Class Initialized
INFO - 2023-04-18 08:42:54 --> Language Class Initialized
INFO - 2023-04-18 08:42:54 --> Loader Class Initialized
INFO - 2023-04-18 08:42:54 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:54 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:54 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:54 --> Total execution time: 0.0268
INFO - 2023-04-18 08:42:54 --> Config Class Initialized
INFO - 2023-04-18 08:42:54 --> Final output sent to browser
INFO - 2023-04-18 08:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:55 --> Total execution time: 0.0292
DEBUG - 2023-04-18 08:42:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:55 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:55 --> URI Class Initialized
INFO - 2023-04-18 08:42:55 --> Router Class Initialized
INFO - 2023-04-18 08:42:55 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:55 --> Total execution time: 0.0624
INFO - 2023-04-18 08:42:55 --> Output Class Initialized
INFO - 2023-04-18 08:42:55 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:55 --> Input Class Initialized
INFO - 2023-04-18 08:42:55 --> Language Class Initialized
INFO - 2023-04-18 08:42:55 --> Loader Class Initialized
INFO - 2023-04-18 08:42:55 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:55 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:55 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:55 --> Total execution time: 0.1446
INFO - 2023-04-18 08:42:58 --> Config Class Initialized
INFO - 2023-04-18 08:42:58 --> Config Class Initialized
INFO - 2023-04-18 08:42:58 --> Hooks Class Initialized
INFO - 2023-04-18 08:42:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:58 --> Utf8 Class Initialized
DEBUG - 2023-04-18 08:42:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:58 --> URI Class Initialized
INFO - 2023-04-18 08:42:58 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:58 --> Router Class Initialized
INFO - 2023-04-18 08:42:58 --> URI Class Initialized
INFO - 2023-04-18 08:42:58 --> Output Class Initialized
INFO - 2023-04-18 08:42:58 --> Router Class Initialized
INFO - 2023-04-18 08:42:58 --> Output Class Initialized
INFO - 2023-04-18 08:42:58 --> Security Class Initialized
INFO - 2023-04-18 08:42:58 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 08:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:58 --> Input Class Initialized
INFO - 2023-04-18 08:42:58 --> Input Class Initialized
INFO - 2023-04-18 08:42:58 --> Language Class Initialized
INFO - 2023-04-18 08:42:58 --> Language Class Initialized
INFO - 2023-04-18 08:42:58 --> Loader Class Initialized
INFO - 2023-04-18 08:42:58 --> Loader Class Initialized
INFO - 2023-04-18 08:42:58 --> Controller Class Initialized
INFO - 2023-04-18 08:42:58 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 08:42:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:58 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:58 --> Total execution time: 0.0197
INFO - 2023-04-18 08:42:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:58 --> Config Class Initialized
INFO - 2023-04-18 08:42:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:58 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:58 --> URI Class Initialized
INFO - 2023-04-18 08:42:58 --> Router Class Initialized
INFO - 2023-04-18 08:42:58 --> Output Class Initialized
INFO - 2023-04-18 08:42:58 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:58 --> Input Class Initialized
INFO - 2023-04-18 08:42:58 --> Language Class Initialized
INFO - 2023-04-18 08:42:58 --> Loader Class Initialized
INFO - 2023-04-18 08:42:58 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:58 --> Model "Login_model" initialized
INFO - 2023-04-18 08:42:58 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:58 --> Total execution time: 0.0354
INFO - 2023-04-18 08:42:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:58 --> Config Class Initialized
INFO - 2023-04-18 08:42:58 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:58 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:58 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:58 --> URI Class Initialized
INFO - 2023-04-18 08:42:58 --> Router Class Initialized
INFO - 2023-04-18 08:42:58 --> Output Class Initialized
INFO - 2023-04-18 08:42:58 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:58 --> Input Class Initialized
INFO - 2023-04-18 08:42:58 --> Language Class Initialized
INFO - 2023-04-18 08:42:58 --> Loader Class Initialized
INFO - 2023-04-18 08:42:58 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:58 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:58 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:58 --> Total execution time: 0.0243
INFO - 2023-04-18 08:42:58 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:58 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:58 --> Total execution time: 0.0558
INFO - 2023-04-18 08:42:59 --> Config Class Initialized
INFO - 2023-04-18 08:42:59 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:59 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:59 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:59 --> URI Class Initialized
INFO - 2023-04-18 08:42:59 --> Router Class Initialized
INFO - 2023-04-18 08:42:59 --> Output Class Initialized
INFO - 2023-04-18 08:42:59 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:59 --> Input Class Initialized
INFO - 2023-04-18 08:42:59 --> Language Class Initialized
INFO - 2023-04-18 08:42:59 --> Loader Class Initialized
INFO - 2023-04-18 08:42:59 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:59 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:59 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:59 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:59 --> Model "Login_model" initialized
INFO - 2023-04-18 08:42:59 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:59 --> Total execution time: 0.0632
INFO - 2023-04-18 08:42:59 --> Config Class Initialized
INFO - 2023-04-18 08:42:59 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:42:59 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:42:59 --> Utf8 Class Initialized
INFO - 2023-04-18 08:42:59 --> URI Class Initialized
INFO - 2023-04-18 08:42:59 --> Router Class Initialized
INFO - 2023-04-18 08:42:59 --> Output Class Initialized
INFO - 2023-04-18 08:42:59 --> Security Class Initialized
DEBUG - 2023-04-18 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:42:59 --> Input Class Initialized
INFO - 2023-04-18 08:42:59 --> Language Class Initialized
INFO - 2023-04-18 08:42:59 --> Loader Class Initialized
INFO - 2023-04-18 08:42:59 --> Controller Class Initialized
DEBUG - 2023-04-18 08:42:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:42:59 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:59 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:42:59 --> Database Driver Class Initialized
INFO - 2023-04-18 08:42:59 --> Model "Login_model" initialized
INFO - 2023-04-18 08:42:59 --> Final output sent to browser
DEBUG - 2023-04-18 08:42:59 --> Total execution time: 0.0608
INFO - 2023-04-18 08:44:16 --> Config Class Initialized
INFO - 2023-04-18 08:44:16 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:16 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:16 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:16 --> URI Class Initialized
INFO - 2023-04-18 08:44:16 --> Router Class Initialized
INFO - 2023-04-18 08:44:16 --> Output Class Initialized
INFO - 2023-04-18 08:44:16 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:16 --> Input Class Initialized
INFO - 2023-04-18 08:44:16 --> Language Class Initialized
INFO - 2023-04-18 08:44:16 --> Loader Class Initialized
INFO - 2023-04-18 08:44:16 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:16 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:16 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:16 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:16 --> Model "Login_model" initialized
INFO - 2023-04-18 08:44:17 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:17 --> Total execution time: 0.0638
INFO - 2023-04-18 08:44:17 --> Config Class Initialized
INFO - 2023-04-18 08:44:17 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:17 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:17 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:17 --> URI Class Initialized
INFO - 2023-04-18 08:44:17 --> Router Class Initialized
INFO - 2023-04-18 08:44:17 --> Output Class Initialized
INFO - 2023-04-18 08:44:17 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:17 --> Input Class Initialized
INFO - 2023-04-18 08:44:17 --> Language Class Initialized
INFO - 2023-04-18 08:44:17 --> Loader Class Initialized
INFO - 2023-04-18 08:44:17 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:17 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:17 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:17 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:17 --> Model "Login_model" initialized
INFO - 2023-04-18 08:44:17 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:17 --> Total execution time: 0.1874
INFO - 2023-04-18 08:44:36 --> Config Class Initialized
INFO - 2023-04-18 08:44:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:36 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:36 --> URI Class Initialized
INFO - 2023-04-18 08:44:36 --> Router Class Initialized
INFO - 2023-04-18 08:44:36 --> Output Class Initialized
INFO - 2023-04-18 08:44:36 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:36 --> Input Class Initialized
INFO - 2023-04-18 08:44:36 --> Language Class Initialized
INFO - 2023-04-18 08:44:36 --> Loader Class Initialized
INFO - 2023-04-18 08:44:36 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:36 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:36 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:36 --> Total execution time: 0.0250
INFO - 2023-04-18 08:44:36 --> Config Class Initialized
INFO - 2023-04-18 08:44:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:36 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:36 --> URI Class Initialized
INFO - 2023-04-18 08:44:36 --> Router Class Initialized
INFO - 2023-04-18 08:44:36 --> Output Class Initialized
INFO - 2023-04-18 08:44:36 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:36 --> Input Class Initialized
INFO - 2023-04-18 08:44:36 --> Language Class Initialized
INFO - 2023-04-18 08:44:36 --> Loader Class Initialized
INFO - 2023-04-18 08:44:36 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:36 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:36 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:36 --> Model "Login_model" initialized
INFO - 2023-04-18 08:44:36 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:36 --> Total execution time: 0.0197
INFO - 2023-04-18 08:44:36 --> Config Class Initialized
INFO - 2023-04-18 08:44:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:36 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:36 --> URI Class Initialized
INFO - 2023-04-18 08:44:36 --> Router Class Initialized
INFO - 2023-04-18 08:44:36 --> Output Class Initialized
INFO - 2023-04-18 08:44:36 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:36 --> Input Class Initialized
INFO - 2023-04-18 08:44:36 --> Language Class Initialized
INFO - 2023-04-18 08:44:36 --> Loader Class Initialized
INFO - 2023-04-18 08:44:36 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:36 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:36 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:36 --> Total execution time: 0.0565
INFO - 2023-04-18 08:44:36 --> Config Class Initialized
INFO - 2023-04-18 08:44:36 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:36 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:36 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:36 --> URI Class Initialized
INFO - 2023-04-18 08:44:36 --> Router Class Initialized
INFO - 2023-04-18 08:44:36 --> Output Class Initialized
INFO - 2023-04-18 08:44:36 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:36 --> Input Class Initialized
INFO - 2023-04-18 08:44:36 --> Language Class Initialized
INFO - 2023-04-18 08:44:36 --> Loader Class Initialized
INFO - 2023-04-18 08:44:36 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:36 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:36 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:36 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:36 --> Model "Login_model" initialized
INFO - 2023-04-18 08:44:36 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:36 --> Total execution time: 0.0205
INFO - 2023-04-18 08:44:39 --> Config Class Initialized
INFO - 2023-04-18 08:44:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:39 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:39 --> URI Class Initialized
INFO - 2023-04-18 08:44:39 --> Router Class Initialized
INFO - 2023-04-18 08:44:39 --> Output Class Initialized
INFO - 2023-04-18 08:44:39 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:39 --> Input Class Initialized
INFO - 2023-04-18 08:44:39 --> Language Class Initialized
INFO - 2023-04-18 08:44:39 --> Loader Class Initialized
INFO - 2023-04-18 08:44:39 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:39 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:39 --> Total execution time: 0.0182
INFO - 2023-04-18 08:44:39 --> Config Class Initialized
INFO - 2023-04-18 08:44:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:39 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:39 --> URI Class Initialized
INFO - 2023-04-18 08:44:39 --> Router Class Initialized
INFO - 2023-04-18 08:44:39 --> Output Class Initialized
INFO - 2023-04-18 08:44:39 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:39 --> Input Class Initialized
INFO - 2023-04-18 08:44:39 --> Language Class Initialized
INFO - 2023-04-18 08:44:39 --> Loader Class Initialized
INFO - 2023-04-18 08:44:39 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:39 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:39 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:39 --> Total execution time: 0.0573
INFO - 2023-04-18 08:44:40 --> Config Class Initialized
INFO - 2023-04-18 08:44:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:40 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:40 --> URI Class Initialized
INFO - 2023-04-18 08:44:40 --> Router Class Initialized
INFO - 2023-04-18 08:44:40 --> Output Class Initialized
INFO - 2023-04-18 08:44:40 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:40 --> Input Class Initialized
INFO - 2023-04-18 08:44:40 --> Language Class Initialized
INFO - 2023-04-18 08:44:40 --> Loader Class Initialized
INFO - 2023-04-18 08:44:40 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:40 --> Model "Login_model" initialized
INFO - 2023-04-18 08:44:40 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:40 --> Total execution time: 0.0242
INFO - 2023-04-18 08:44:40 --> Config Class Initialized
INFO - 2023-04-18 08:44:40 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:40 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:40 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:40 --> URI Class Initialized
INFO - 2023-04-18 08:44:40 --> Router Class Initialized
INFO - 2023-04-18 08:44:40 --> Output Class Initialized
INFO - 2023-04-18 08:44:40 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:40 --> Input Class Initialized
INFO - 2023-04-18 08:44:40 --> Language Class Initialized
INFO - 2023-04-18 08:44:40 --> Loader Class Initialized
INFO - 2023-04-18 08:44:40 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:40 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:40 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:40 --> Model "Login_model" initialized
INFO - 2023-04-18 08:44:40 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:40 --> Total execution time: 0.0204
INFO - 2023-04-18 08:44:41 --> Config Class Initialized
INFO - 2023-04-18 08:44:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:41 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:41 --> URI Class Initialized
INFO - 2023-04-18 08:44:41 --> Router Class Initialized
INFO - 2023-04-18 08:44:41 --> Output Class Initialized
INFO - 2023-04-18 08:44:41 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:41 --> Input Class Initialized
INFO - 2023-04-18 08:44:41 --> Language Class Initialized
INFO - 2023-04-18 08:44:41 --> Loader Class Initialized
INFO - 2023-04-18 08:44:41 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:41 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:41 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:41 --> Model "Login_model" initialized
INFO - 2023-04-18 08:44:41 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:41 --> Total execution time: 0.0878
INFO - 2023-04-18 08:44:41 --> Config Class Initialized
INFO - 2023-04-18 08:44:41 --> Hooks Class Initialized
DEBUG - 2023-04-18 08:44:41 --> UTF-8 Support Enabled
INFO - 2023-04-18 08:44:41 --> Utf8 Class Initialized
INFO - 2023-04-18 08:44:41 --> URI Class Initialized
INFO - 2023-04-18 08:44:41 --> Router Class Initialized
INFO - 2023-04-18 08:44:41 --> Output Class Initialized
INFO - 2023-04-18 08:44:41 --> Security Class Initialized
DEBUG - 2023-04-18 08:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 08:44:41 --> Input Class Initialized
INFO - 2023-04-18 08:44:41 --> Language Class Initialized
INFO - 2023-04-18 08:44:41 --> Loader Class Initialized
INFO - 2023-04-18 08:44:41 --> Controller Class Initialized
DEBUG - 2023-04-18 08:44:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 08:44:41 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:41 --> Model "Cluster_model" initialized
INFO - 2023-04-18 08:44:41 --> Database Driver Class Initialized
INFO - 2023-04-18 08:44:41 --> Model "Login_model" initialized
INFO - 2023-04-18 08:44:41 --> Final output sent to browser
DEBUG - 2023-04-18 08:44:41 --> Total execution time: 0.0647
INFO - 2023-04-18 09:21:37 --> Config Class Initialized
INFO - 2023-04-18 09:21:37 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:21:37 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:21:37 --> Utf8 Class Initialized
INFO - 2023-04-18 09:21:37 --> URI Class Initialized
INFO - 2023-04-18 09:21:37 --> Router Class Initialized
INFO - 2023-04-18 09:21:37 --> Output Class Initialized
INFO - 2023-04-18 09:21:37 --> Security Class Initialized
DEBUG - 2023-04-18 09:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:21:37 --> Input Class Initialized
INFO - 2023-04-18 09:21:37 --> Language Class Initialized
INFO - 2023-04-18 09:21:37 --> Loader Class Initialized
INFO - 2023-04-18 09:21:37 --> Controller Class Initialized
DEBUG - 2023-04-18 09:21:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:21:37 --> Database Driver Class Initialized
INFO - 2023-04-18 09:21:37 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:21:37 --> Final output sent to browser
DEBUG - 2023-04-18 09:21:37 --> Total execution time: 0.0571
INFO - 2023-04-18 09:21:37 --> Config Class Initialized
INFO - 2023-04-18 09:21:37 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:21:37 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:21:37 --> Utf8 Class Initialized
INFO - 2023-04-18 09:21:37 --> URI Class Initialized
INFO - 2023-04-18 09:21:37 --> Router Class Initialized
INFO - 2023-04-18 09:21:37 --> Output Class Initialized
INFO - 2023-04-18 09:21:37 --> Security Class Initialized
DEBUG - 2023-04-18 09:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:21:37 --> Input Class Initialized
INFO - 2023-04-18 09:21:37 --> Language Class Initialized
INFO - 2023-04-18 09:21:37 --> Loader Class Initialized
INFO - 2023-04-18 09:21:37 --> Controller Class Initialized
DEBUG - 2023-04-18 09:21:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:21:37 --> Database Driver Class Initialized
INFO - 2023-04-18 09:21:37 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:21:37 --> Final output sent to browser
DEBUG - 2023-04-18 09:21:37 --> Total execution time: 0.1160
INFO - 2023-04-18 09:28:04 --> Config Class Initialized
INFO - 2023-04-18 09:28:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:28:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:28:04 --> Utf8 Class Initialized
INFO - 2023-04-18 09:28:04 --> URI Class Initialized
INFO - 2023-04-18 09:28:04 --> Router Class Initialized
INFO - 2023-04-18 09:28:04 --> Output Class Initialized
INFO - 2023-04-18 09:28:04 --> Security Class Initialized
DEBUG - 2023-04-18 09:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:28:04 --> Input Class Initialized
INFO - 2023-04-18 09:28:04 --> Language Class Initialized
INFO - 2023-04-18 09:28:04 --> Loader Class Initialized
INFO - 2023-04-18 09:28:04 --> Controller Class Initialized
DEBUG - 2023-04-18 09:28:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:28:04 --> Database Driver Class Initialized
INFO - 2023-04-18 09:28:04 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:28:04 --> Final output sent to browser
DEBUG - 2023-04-18 09:28:04 --> Total execution time: 0.0174
INFO - 2023-04-18 09:28:04 --> Config Class Initialized
INFO - 2023-04-18 09:28:04 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:28:04 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:28:04 --> Utf8 Class Initialized
INFO - 2023-04-18 09:28:04 --> URI Class Initialized
INFO - 2023-04-18 09:28:04 --> Router Class Initialized
INFO - 2023-04-18 09:28:04 --> Output Class Initialized
INFO - 2023-04-18 09:28:04 --> Security Class Initialized
DEBUG - 2023-04-18 09:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:28:04 --> Input Class Initialized
INFO - 2023-04-18 09:28:04 --> Language Class Initialized
INFO - 2023-04-18 09:28:04 --> Loader Class Initialized
INFO - 2023-04-18 09:28:04 --> Controller Class Initialized
DEBUG - 2023-04-18 09:28:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:28:04 --> Database Driver Class Initialized
INFO - 2023-04-18 09:28:04 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:28:04 --> Final output sent to browser
DEBUG - 2023-04-18 09:28:04 --> Total execution time: 0.0166
INFO - 2023-04-18 09:32:12 --> Config Class Initialized
INFO - 2023-04-18 09:32:12 --> Config Class Initialized
INFO - 2023-04-18 09:32:12 --> Hooks Class Initialized
INFO - 2023-04-18 09:32:12 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 09:32:12 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:32:12 --> Utf8 Class Initialized
INFO - 2023-04-18 09:32:12 --> Utf8 Class Initialized
INFO - 2023-04-18 09:32:12 --> URI Class Initialized
INFO - 2023-04-18 09:32:12 --> URI Class Initialized
INFO - 2023-04-18 09:32:12 --> Router Class Initialized
INFO - 2023-04-18 09:32:12 --> Router Class Initialized
INFO - 2023-04-18 09:32:12 --> Output Class Initialized
INFO - 2023-04-18 09:32:12 --> Security Class Initialized
INFO - 2023-04-18 09:32:12 --> Output Class Initialized
DEBUG - 2023-04-18 09:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:32:12 --> Security Class Initialized
INFO - 2023-04-18 09:32:12 --> Input Class Initialized
DEBUG - 2023-04-18 09:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:32:12 --> Language Class Initialized
INFO - 2023-04-18 09:32:12 --> Input Class Initialized
INFO - 2023-04-18 09:32:12 --> Language Class Initialized
INFO - 2023-04-18 09:32:12 --> Loader Class Initialized
INFO - 2023-04-18 09:32:12 --> Loader Class Initialized
INFO - 2023-04-18 09:32:12 --> Controller Class Initialized
INFO - 2023-04-18 09:32:12 --> Controller Class Initialized
DEBUG - 2023-04-18 09:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 09:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:32:12 --> Final output sent to browser
DEBUG - 2023-04-18 09:32:12 --> Total execution time: 0.0047
INFO - 2023-04-18 09:32:12 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:12 --> Config Class Initialized
INFO - 2023-04-18 09:32:12 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:32:12 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:32:12 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:32:12 --> Utf8 Class Initialized
INFO - 2023-04-18 09:32:12 --> URI Class Initialized
INFO - 2023-04-18 09:32:12 --> Router Class Initialized
INFO - 2023-04-18 09:32:12 --> Output Class Initialized
INFO - 2023-04-18 09:32:12 --> Security Class Initialized
DEBUG - 2023-04-18 09:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:32:12 --> Input Class Initialized
INFO - 2023-04-18 09:32:12 --> Language Class Initialized
INFO - 2023-04-18 09:32:12 --> Loader Class Initialized
INFO - 2023-04-18 09:32:12 --> Controller Class Initialized
DEBUG - 2023-04-18 09:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:32:12 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:12 --> Final output sent to browser
DEBUG - 2023-04-18 09:32:12 --> Total execution time: 0.0506
INFO - 2023-04-18 09:32:12 --> Config Class Initialized
INFO - 2023-04-18 09:32:12 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:32:12 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:32:12 --> Utf8 Class Initialized
INFO - 2023-04-18 09:32:12 --> URI Class Initialized
INFO - 2023-04-18 09:32:12 --> Router Class Initialized
INFO - 2023-04-18 09:32:12 --> Output Class Initialized
INFO - 2023-04-18 09:32:12 --> Security Class Initialized
DEBUG - 2023-04-18 09:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:32:12 --> Input Class Initialized
INFO - 2023-04-18 09:32:12 --> Language Class Initialized
INFO - 2023-04-18 09:32:12 --> Loader Class Initialized
INFO - 2023-04-18 09:32:12 --> Controller Class Initialized
DEBUG - 2023-04-18 09:32:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:32:12 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:12 --> Model "Login_model" initialized
INFO - 2023-04-18 09:32:12 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:12 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:32:12 --> Final output sent to browser
DEBUG - 2023-04-18 09:32:12 --> Total execution time: 0.0159
INFO - 2023-04-18 09:32:12 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:32:12 --> Final output sent to browser
DEBUG - 2023-04-18 09:32:12 --> Total execution time: 0.1041
INFO - 2023-04-18 09:32:13 --> Config Class Initialized
INFO - 2023-04-18 09:32:13 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:32:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:32:13 --> Utf8 Class Initialized
INFO - 2023-04-18 09:32:13 --> URI Class Initialized
INFO - 2023-04-18 09:32:13 --> Router Class Initialized
INFO - 2023-04-18 09:32:13 --> Output Class Initialized
INFO - 2023-04-18 09:32:13 --> Security Class Initialized
DEBUG - 2023-04-18 09:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:32:13 --> Input Class Initialized
INFO - 2023-04-18 09:32:13 --> Language Class Initialized
INFO - 2023-04-18 09:32:13 --> Loader Class Initialized
INFO - 2023-04-18 09:32:13 --> Controller Class Initialized
DEBUG - 2023-04-18 09:32:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:32:13 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:13 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:32:13 --> Final output sent to browser
DEBUG - 2023-04-18 09:32:13 --> Total execution time: 0.0395
INFO - 2023-04-18 09:32:13 --> Config Class Initialized
INFO - 2023-04-18 09:32:13 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:32:13 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:32:13 --> Utf8 Class Initialized
INFO - 2023-04-18 09:32:13 --> URI Class Initialized
INFO - 2023-04-18 09:32:13 --> Router Class Initialized
INFO - 2023-04-18 09:32:13 --> Output Class Initialized
INFO - 2023-04-18 09:32:13 --> Security Class Initialized
DEBUG - 2023-04-18 09:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:32:13 --> Input Class Initialized
INFO - 2023-04-18 09:32:13 --> Language Class Initialized
INFO - 2023-04-18 09:32:13 --> Loader Class Initialized
INFO - 2023-04-18 09:32:13 --> Controller Class Initialized
DEBUG - 2023-04-18 09:32:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:32:13 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:13 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:32:13 --> Final output sent to browser
DEBUG - 2023-04-18 09:32:13 --> Total execution time: 0.0784
INFO - 2023-04-18 09:32:14 --> Config Class Initialized
INFO - 2023-04-18 09:32:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:32:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:32:14 --> Utf8 Class Initialized
INFO - 2023-04-18 09:32:14 --> URI Class Initialized
INFO - 2023-04-18 09:32:14 --> Router Class Initialized
INFO - 2023-04-18 09:32:14 --> Output Class Initialized
INFO - 2023-04-18 09:32:14 --> Security Class Initialized
DEBUG - 2023-04-18 09:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:32:14 --> Input Class Initialized
INFO - 2023-04-18 09:32:14 --> Language Class Initialized
INFO - 2023-04-18 09:32:14 --> Loader Class Initialized
INFO - 2023-04-18 09:32:14 --> Controller Class Initialized
DEBUG - 2023-04-18 09:32:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:32:14 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:32:14 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:14 --> Model "Login_model" initialized
INFO - 2023-04-18 09:32:14 --> Final output sent to browser
DEBUG - 2023-04-18 09:32:14 --> Total execution time: 0.0859
INFO - 2023-04-18 09:32:14 --> Config Class Initialized
INFO - 2023-04-18 09:32:14 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:32:14 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:32:14 --> Utf8 Class Initialized
INFO - 2023-04-18 09:32:14 --> URI Class Initialized
INFO - 2023-04-18 09:32:14 --> Router Class Initialized
INFO - 2023-04-18 09:32:14 --> Output Class Initialized
INFO - 2023-04-18 09:32:14 --> Security Class Initialized
DEBUG - 2023-04-18 09:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:32:14 --> Input Class Initialized
INFO - 2023-04-18 09:32:14 --> Language Class Initialized
INFO - 2023-04-18 09:32:14 --> Loader Class Initialized
INFO - 2023-04-18 09:32:14 --> Controller Class Initialized
DEBUG - 2023-04-18 09:32:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:32:14 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:14 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:32:14 --> Database Driver Class Initialized
INFO - 2023-04-18 09:32:14 --> Model "Login_model" initialized
INFO - 2023-04-18 09:32:14 --> Final output sent to browser
DEBUG - 2023-04-18 09:32:14 --> Total execution time: 0.1024
INFO - 2023-04-18 09:44:42 --> Config Class Initialized
INFO - 2023-04-18 09:44:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:44:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:44:42 --> Utf8 Class Initialized
INFO - 2023-04-18 09:44:42 --> URI Class Initialized
INFO - 2023-04-18 09:44:42 --> Router Class Initialized
INFO - 2023-04-18 09:44:42 --> Output Class Initialized
INFO - 2023-04-18 09:44:42 --> Security Class Initialized
DEBUG - 2023-04-18 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:44:42 --> Input Class Initialized
INFO - 2023-04-18 09:44:42 --> Language Class Initialized
INFO - 2023-04-18 09:44:42 --> Loader Class Initialized
INFO - 2023-04-18 09:44:42 --> Controller Class Initialized
DEBUG - 2023-04-18 09:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:44:42 --> Database Driver Class Initialized
INFO - 2023-04-18 09:44:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:44:42 --> Final output sent to browser
DEBUG - 2023-04-18 09:44:42 --> Total execution time: 0.0378
INFO - 2023-04-18 09:44:42 --> Config Class Initialized
INFO - 2023-04-18 09:44:42 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:44:42 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:44:42 --> Utf8 Class Initialized
INFO - 2023-04-18 09:44:42 --> URI Class Initialized
INFO - 2023-04-18 09:44:42 --> Router Class Initialized
INFO - 2023-04-18 09:44:42 --> Output Class Initialized
INFO - 2023-04-18 09:44:42 --> Security Class Initialized
DEBUG - 2023-04-18 09:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:44:42 --> Input Class Initialized
INFO - 2023-04-18 09:44:42 --> Language Class Initialized
INFO - 2023-04-18 09:44:42 --> Loader Class Initialized
INFO - 2023-04-18 09:44:42 --> Controller Class Initialized
DEBUG - 2023-04-18 09:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:44:42 --> Database Driver Class Initialized
INFO - 2023-04-18 09:44:42 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:44:42 --> Final output sent to browser
DEBUG - 2023-04-18 09:44:42 --> Total execution time: 0.0307
INFO - 2023-04-18 09:44:45 --> Config Class Initialized
INFO - 2023-04-18 09:44:45 --> Config Class Initialized
INFO - 2023-04-18 09:44:45 --> Hooks Class Initialized
INFO - 2023-04-18 09:44:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:44:45 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 09:44:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:44:45 --> Utf8 Class Initialized
INFO - 2023-04-18 09:44:45 --> Utf8 Class Initialized
INFO - 2023-04-18 09:44:45 --> URI Class Initialized
INFO - 2023-04-18 09:44:45 --> URI Class Initialized
INFO - 2023-04-18 09:44:45 --> Router Class Initialized
INFO - 2023-04-18 09:44:45 --> Router Class Initialized
INFO - 2023-04-18 09:44:45 --> Output Class Initialized
INFO - 2023-04-18 09:44:45 --> Output Class Initialized
INFO - 2023-04-18 09:44:45 --> Security Class Initialized
INFO - 2023-04-18 09:44:45 --> Security Class Initialized
DEBUG - 2023-04-18 09:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:44:45 --> Input Class Initialized
INFO - 2023-04-18 09:44:45 --> Input Class Initialized
INFO - 2023-04-18 09:44:45 --> Language Class Initialized
INFO - 2023-04-18 09:44:45 --> Language Class Initialized
INFO - 2023-04-18 09:44:45 --> Loader Class Initialized
INFO - 2023-04-18 09:44:45 --> Loader Class Initialized
INFO - 2023-04-18 09:44:45 --> Controller Class Initialized
INFO - 2023-04-18 09:44:45 --> Controller Class Initialized
DEBUG - 2023-04-18 09:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 09:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:44:45 --> Final output sent to browser
DEBUG - 2023-04-18 09:44:45 --> Total execution time: 0.0044
INFO - 2023-04-18 09:44:45 --> Database Driver Class Initialized
INFO - 2023-04-18 09:44:45 --> Config Class Initialized
INFO - 2023-04-18 09:44:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:44:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:44:45 --> Utf8 Class Initialized
INFO - 2023-04-18 09:44:45 --> URI Class Initialized
INFO - 2023-04-18 09:44:45 --> Router Class Initialized
INFO - 2023-04-18 09:44:45 --> Output Class Initialized
INFO - 2023-04-18 09:44:45 --> Security Class Initialized
DEBUG - 2023-04-18 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:44:45 --> Input Class Initialized
INFO - 2023-04-18 09:44:45 --> Language Class Initialized
INFO - 2023-04-18 09:44:45 --> Loader Class Initialized
INFO - 2023-04-18 09:44:45 --> Controller Class Initialized
DEBUG - 2023-04-18 09:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:44:45 --> Database Driver Class Initialized
INFO - 2023-04-18 09:44:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:44:45 --> Model "Login_model" initialized
INFO - 2023-04-18 09:44:45 --> Final output sent to browser
DEBUG - 2023-04-18 09:44:45 --> Total execution time: 0.0171
INFO - 2023-04-18 09:44:45 --> Database Driver Class Initialized
INFO - 2023-04-18 09:44:45 --> Config Class Initialized
INFO - 2023-04-18 09:44:45 --> Hooks Class Initialized
DEBUG - 2023-04-18 09:44:45 --> UTF-8 Support Enabled
INFO - 2023-04-18 09:44:45 --> Utf8 Class Initialized
INFO - 2023-04-18 09:44:45 --> URI Class Initialized
INFO - 2023-04-18 09:44:45 --> Router Class Initialized
INFO - 2023-04-18 09:44:45 --> Output Class Initialized
INFO - 2023-04-18 09:44:45 --> Security Class Initialized
DEBUG - 2023-04-18 09:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 09:44:45 --> Input Class Initialized
INFO - 2023-04-18 09:44:45 --> Language Class Initialized
INFO - 2023-04-18 09:44:45 --> Loader Class Initialized
INFO - 2023-04-18 09:44:45 --> Controller Class Initialized
DEBUG - 2023-04-18 09:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 09:44:45 --> Database Driver Class Initialized
INFO - 2023-04-18 09:44:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:44:45 --> Final output sent to browser
DEBUG - 2023-04-18 09:44:45 --> Total execution time: 0.0201
INFO - 2023-04-18 09:44:45 --> Model "Cluster_model" initialized
INFO - 2023-04-18 09:44:45 --> Final output sent to browser
DEBUG - 2023-04-18 09:44:45 --> Total execution time: 0.0524
INFO - 2023-04-18 10:05:55 --> Config Class Initialized
INFO - 2023-04-18 10:05:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 10:05:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 10:05:55 --> Utf8 Class Initialized
INFO - 2023-04-18 10:05:55 --> URI Class Initialized
INFO - 2023-04-18 10:05:55 --> Router Class Initialized
INFO - 2023-04-18 10:05:55 --> Output Class Initialized
INFO - 2023-04-18 10:05:55 --> Security Class Initialized
DEBUG - 2023-04-18 10:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 10:05:55 --> Input Class Initialized
INFO - 2023-04-18 10:05:55 --> Language Class Initialized
INFO - 2023-04-18 10:05:55 --> Loader Class Initialized
INFO - 2023-04-18 10:05:55 --> Controller Class Initialized
DEBUG - 2023-04-18 10:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 10:05:55 --> Database Driver Class Initialized
INFO - 2023-04-18 10:05:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 10:05:55 --> Final output sent to browser
DEBUG - 2023-04-18 10:05:55 --> Total execution time: 0.0441
INFO - 2023-04-18 10:05:55 --> Config Class Initialized
INFO - 2023-04-18 10:05:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 10:05:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 10:05:55 --> Utf8 Class Initialized
INFO - 2023-04-18 10:05:55 --> URI Class Initialized
INFO - 2023-04-18 10:05:55 --> Router Class Initialized
INFO - 2023-04-18 10:05:55 --> Output Class Initialized
INFO - 2023-04-18 10:05:55 --> Security Class Initialized
DEBUG - 2023-04-18 10:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 10:05:55 --> Input Class Initialized
INFO - 2023-04-18 10:05:55 --> Language Class Initialized
INFO - 2023-04-18 10:05:55 --> Loader Class Initialized
INFO - 2023-04-18 10:05:55 --> Controller Class Initialized
DEBUG - 2023-04-18 10:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 10:05:55 --> Database Driver Class Initialized
INFO - 2023-04-18 10:05:55 --> Model "Cluster_model" initialized
INFO - 2023-04-18 10:05:55 --> Final output sent to browser
DEBUG - 2023-04-18 10:05:55 --> Total execution time: 0.0411
INFO - 2023-04-18 10:05:55 --> Config Class Initialized
INFO - 2023-04-18 10:05:55 --> Hooks Class Initialized
DEBUG - 2023-04-18 10:05:55 --> UTF-8 Support Enabled
INFO - 2023-04-18 10:05:55 --> Utf8 Class Initialized
INFO - 2023-04-18 10:05:55 --> URI Class Initialized
INFO - 2023-04-18 10:05:55 --> Router Class Initialized
INFO - 2023-04-18 10:05:55 --> Output Class Initialized
INFO - 2023-04-18 10:05:55 --> Security Class Initialized
DEBUG - 2023-04-18 10:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 10:05:55 --> Input Class Initialized
INFO - 2023-04-18 10:05:55 --> Language Class Initialized
INFO - 2023-04-18 10:05:55 --> Loader Class Initialized
INFO - 2023-04-18 10:05:55 --> Controller Class Initialized
DEBUG - 2023-04-18 10:05:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 10:05:55 --> Database Driver Class Initialized
INFO - 2023-04-18 10:05:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 10:05:56 --> Database Driver Class Initialized
INFO - 2023-04-18 10:05:56 --> Model "Login_model" initialized
INFO - 2023-04-18 10:05:56 --> Final output sent to browser
DEBUG - 2023-04-18 10:05:56 --> Total execution time: 0.0717
INFO - 2023-04-18 10:05:56 --> Config Class Initialized
INFO - 2023-04-18 10:05:56 --> Hooks Class Initialized
DEBUG - 2023-04-18 10:05:56 --> UTF-8 Support Enabled
INFO - 2023-04-18 10:05:56 --> Utf8 Class Initialized
INFO - 2023-04-18 10:05:56 --> URI Class Initialized
INFO - 2023-04-18 10:05:56 --> Router Class Initialized
INFO - 2023-04-18 10:05:56 --> Output Class Initialized
INFO - 2023-04-18 10:05:56 --> Security Class Initialized
DEBUG - 2023-04-18 10:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 10:05:56 --> Input Class Initialized
INFO - 2023-04-18 10:05:56 --> Language Class Initialized
INFO - 2023-04-18 10:05:56 --> Loader Class Initialized
INFO - 2023-04-18 10:05:56 --> Controller Class Initialized
DEBUG - 2023-04-18 10:05:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 10:05:56 --> Database Driver Class Initialized
INFO - 2023-04-18 10:05:56 --> Model "Cluster_model" initialized
INFO - 2023-04-18 10:05:56 --> Database Driver Class Initialized
INFO - 2023-04-18 10:05:56 --> Model "Login_model" initialized
INFO - 2023-04-18 10:05:56 --> Final output sent to browser
DEBUG - 2023-04-18 10:05:56 --> Total execution time: 0.1080
INFO - 2023-04-18 10:06:39 --> Config Class Initialized
INFO - 2023-04-18 10:06:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 10:06:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 10:06:39 --> Utf8 Class Initialized
INFO - 2023-04-18 10:06:39 --> URI Class Initialized
INFO - 2023-04-18 10:06:39 --> Router Class Initialized
INFO - 2023-04-18 10:06:39 --> Output Class Initialized
INFO - 2023-04-18 10:06:39 --> Security Class Initialized
DEBUG - 2023-04-18 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 10:06:39 --> Input Class Initialized
INFO - 2023-04-18 10:06:39 --> Language Class Initialized
INFO - 2023-04-18 10:06:39 --> Loader Class Initialized
INFO - 2023-04-18 10:06:39 --> Controller Class Initialized
DEBUG - 2023-04-18 10:06:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 10:06:39 --> Database Driver Class Initialized
INFO - 2023-04-18 10:06:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 10:06:39 --> Final output sent to browser
DEBUG - 2023-04-18 10:06:39 --> Total execution time: 0.0118
INFO - 2023-04-18 10:06:39 --> Config Class Initialized
INFO - 2023-04-18 10:06:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 10:06:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 10:06:39 --> Utf8 Class Initialized
INFO - 2023-04-18 10:06:39 --> URI Class Initialized
INFO - 2023-04-18 10:06:39 --> Router Class Initialized
INFO - 2023-04-18 10:06:39 --> Output Class Initialized
INFO - 2023-04-18 10:06:39 --> Security Class Initialized
DEBUG - 2023-04-18 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 10:06:39 --> Input Class Initialized
INFO - 2023-04-18 10:06:39 --> Language Class Initialized
INFO - 2023-04-18 10:06:39 --> Loader Class Initialized
INFO - 2023-04-18 10:06:39 --> Controller Class Initialized
DEBUG - 2023-04-18 10:06:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 10:06:39 --> Database Driver Class Initialized
INFO - 2023-04-18 10:06:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 10:06:39 --> Final output sent to browser
DEBUG - 2023-04-18 10:06:39 --> Total execution time: 0.0494
INFO - 2023-04-18 10:06:39 --> Config Class Initialized
INFO - 2023-04-18 10:06:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 10:06:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 10:06:39 --> Utf8 Class Initialized
INFO - 2023-04-18 10:06:39 --> URI Class Initialized
INFO - 2023-04-18 10:06:39 --> Router Class Initialized
INFO - 2023-04-18 10:06:39 --> Output Class Initialized
INFO - 2023-04-18 10:06:39 --> Security Class Initialized
DEBUG - 2023-04-18 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 10:06:39 --> Input Class Initialized
INFO - 2023-04-18 10:06:39 --> Language Class Initialized
INFO - 2023-04-18 10:06:39 --> Loader Class Initialized
INFO - 2023-04-18 10:06:39 --> Controller Class Initialized
DEBUG - 2023-04-18 10:06:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 10:06:39 --> Database Driver Class Initialized
INFO - 2023-04-18 10:06:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 10:06:39 --> Final output sent to browser
DEBUG - 2023-04-18 10:06:39 --> Total execution time: 0.0524
INFO - 2023-04-18 10:06:39 --> Config Class Initialized
INFO - 2023-04-18 10:06:39 --> Hooks Class Initialized
DEBUG - 2023-04-18 10:06:39 --> UTF-8 Support Enabled
INFO - 2023-04-18 10:06:39 --> Utf8 Class Initialized
INFO - 2023-04-18 10:06:39 --> URI Class Initialized
INFO - 2023-04-18 10:06:39 --> Router Class Initialized
INFO - 2023-04-18 10:06:39 --> Output Class Initialized
INFO - 2023-04-18 10:06:39 --> Security Class Initialized
DEBUG - 2023-04-18 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 10:06:39 --> Input Class Initialized
INFO - 2023-04-18 10:06:39 --> Language Class Initialized
INFO - 2023-04-18 10:06:39 --> Loader Class Initialized
INFO - 2023-04-18 10:06:39 --> Controller Class Initialized
DEBUG - 2023-04-18 10:06:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 10:06:39 --> Database Driver Class Initialized
INFO - 2023-04-18 10:06:39 --> Model "Cluster_model" initialized
INFO - 2023-04-18 10:06:39 --> Final output sent to browser
DEBUG - 2023-04-18 10:06:39 --> Total execution time: 0.0555
INFO - 2023-04-18 13:04:18 --> Config Class Initialized
INFO - 2023-04-18 13:04:18 --> Hooks Class Initialized
DEBUG - 2023-04-18 13:04:18 --> UTF-8 Support Enabled
INFO - 2023-04-18 13:04:18 --> Utf8 Class Initialized
INFO - 2023-04-18 13:04:18 --> URI Class Initialized
INFO - 2023-04-18 13:04:18 --> Router Class Initialized
INFO - 2023-04-18 13:04:18 --> Output Class Initialized
INFO - 2023-04-18 13:04:18 --> Security Class Initialized
DEBUG - 2023-04-18 13:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 13:04:18 --> Input Class Initialized
INFO - 2023-04-18 13:04:18 --> Language Class Initialized
INFO - 2023-04-18 13:04:18 --> Loader Class Initialized
INFO - 2023-04-18 13:04:18 --> Controller Class Initialized
DEBUG - 2023-04-18 13:04:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 13:04:18 --> Database Driver Class Initialized
INFO - 2023-04-18 13:04:20 --> Config Class Initialized
INFO - 2023-04-18 13:04:20 --> Config Class Initialized
INFO - 2023-04-18 13:04:20 --> Hooks Class Initialized
INFO - 2023-04-18 13:04:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 13:04:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-18 13:04:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 13:04:20 --> Utf8 Class Initialized
INFO - 2023-04-18 13:04:20 --> Utf8 Class Initialized
INFO - 2023-04-18 13:04:20 --> URI Class Initialized
INFO - 2023-04-18 13:04:20 --> URI Class Initialized
INFO - 2023-04-18 13:04:20 --> Router Class Initialized
INFO - 2023-04-18 13:04:20 --> Router Class Initialized
INFO - 2023-04-18 13:04:20 --> Output Class Initialized
INFO - 2023-04-18 13:04:20 --> Output Class Initialized
INFO - 2023-04-18 13:04:20 --> Security Class Initialized
INFO - 2023-04-18 13:04:20 --> Security Class Initialized
DEBUG - 2023-04-18 13:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-18 13:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 13:04:20 --> Input Class Initialized
INFO - 2023-04-18 13:04:20 --> Input Class Initialized
INFO - 2023-04-18 13:04:20 --> Language Class Initialized
INFO - 2023-04-18 13:04:20 --> Language Class Initialized
INFO - 2023-04-18 13:04:20 --> Loader Class Initialized
INFO - 2023-04-18 13:04:20 --> Loader Class Initialized
INFO - 2023-04-18 13:04:20 --> Controller Class Initialized
INFO - 2023-04-18 13:04:20 --> Controller Class Initialized
DEBUG - 2023-04-18 13:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-18 13:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 13:04:20 --> Final output sent to browser
DEBUG - 2023-04-18 13:04:20 --> Total execution time: 0.0043
INFO - 2023-04-18 13:04:20 --> Database Driver Class Initialized
INFO - 2023-04-18 13:04:20 --> Config Class Initialized
INFO - 2023-04-18 13:04:20 --> Hooks Class Initialized
DEBUG - 2023-04-18 13:04:20 --> UTF-8 Support Enabled
INFO - 2023-04-18 13:04:20 --> Utf8 Class Initialized
INFO - 2023-04-18 13:04:20 --> URI Class Initialized
INFO - 2023-04-18 13:04:20 --> Router Class Initialized
INFO - 2023-04-18 13:04:20 --> Output Class Initialized
INFO - 2023-04-18 13:04:20 --> Security Class Initialized
DEBUG - 2023-04-18 13:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-18 13:04:20 --> Input Class Initialized
INFO - 2023-04-18 13:04:20 --> Language Class Initialized
INFO - 2023-04-18 13:04:20 --> Loader Class Initialized
INFO - 2023-04-18 13:04:20 --> Controller Class Initialized
DEBUG - 2023-04-18 13:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-18 13:04:20 --> Database Driver Class Initialized
ERROR - 2023-04-18 13:04:28 --> Unable to connect to the database
INFO - 2023-04-18 13:04:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-18 13:04:30 --> Unable to connect to the database
INFO - 2023-04-18 13:04:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-18 13:04:30 --> Unable to connect to the database
INFO - 2023-04-18 13:04:30 --> Model "Login_model" initialized
ERROR - 2023-04-18 13:04:30 --> Unable to connect to the database
ERROR - 2023-04-18 13:04:30 --> Query error: Host is down - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' group by id;
INFO - 2023-04-18 13:04:30 --> Final output sent to browser
DEBUG - 2023-04-18 13:04:30 --> Total execution time: 10.0294
