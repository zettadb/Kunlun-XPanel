<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-22 03:05:13 --> Config Class Initialized
INFO - 2023-05-22 03:05:13 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:13 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:13 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:13 --> URI Class Initialized
INFO - 2023-05-22 03:05:13 --> Router Class Initialized
INFO - 2023-05-22 03:05:13 --> Output Class Initialized
INFO - 2023-05-22 03:05:13 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:13 --> Input Class Initialized
INFO - 2023-05-22 03:05:13 --> Language Class Initialized
INFO - 2023-05-22 03:05:13 --> Loader Class Initialized
INFO - 2023-05-22 03:05:13 --> Controller Class Initialized
INFO - 2023-05-22 03:05:13 --> Helper loaded: form_helper
INFO - 2023-05-22 03:05:13 --> Helper loaded: url_helper
DEBUG - 2023-05-22 03:05:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:13 --> Model "Change_model" initialized
INFO - 2023-05-22 03:05:13 --> Model "Grafana_model" initialized
INFO - 2023-05-22 03:05:14 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:14 --> Total execution time: 0.8320
INFO - 2023-05-22 03:05:14 --> Config Class Initialized
INFO - 2023-05-22 03:05:14 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:14 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:14 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:14 --> URI Class Initialized
INFO - 2023-05-22 03:05:14 --> Router Class Initialized
INFO - 2023-05-22 03:05:14 --> Output Class Initialized
INFO - 2023-05-22 03:05:14 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:14 --> Input Class Initialized
INFO - 2023-05-22 03:05:14 --> Language Class Initialized
INFO - 2023-05-22 03:05:14 --> Loader Class Initialized
INFO - 2023-05-22 03:05:14 --> Controller Class Initialized
INFO - 2023-05-22 03:05:14 --> Helper loaded: form_helper
INFO - 2023-05-22 03:05:14 --> Helper loaded: url_helper
DEBUG - 2023-05-22 03:05:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:14 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:14 --> Model "Login_model" initialized
INFO - 2023-05-22 03:05:14 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:14 --> Total execution time: 0.4765
INFO - 2023-05-22 03:05:14 --> Config Class Initialized
INFO - 2023-05-22 03:05:14 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:14 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:14 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:14 --> URI Class Initialized
INFO - 2023-05-22 03:05:14 --> Router Class Initialized
INFO - 2023-05-22 03:05:14 --> Output Class Initialized
INFO - 2023-05-22 03:05:14 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:14 --> Input Class Initialized
INFO - 2023-05-22 03:05:14 --> Language Class Initialized
INFO - 2023-05-22 03:05:14 --> Loader Class Initialized
INFO - 2023-05-22 03:05:14 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:14 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:14 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:14 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:14 --> Total execution time: 0.2879
INFO - 2023-05-22 03:05:15 --> Config Class Initialized
INFO - 2023-05-22 03:05:15 --> Config Class Initialized
INFO - 2023-05-22 03:05:15 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:15 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:05:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:15 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:15 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:15 --> URI Class Initialized
INFO - 2023-05-22 03:05:15 --> URI Class Initialized
INFO - 2023-05-22 03:05:15 --> Router Class Initialized
INFO - 2023-05-22 03:05:15 --> Router Class Initialized
INFO - 2023-05-22 03:05:15 --> Output Class Initialized
INFO - 2023-05-22 03:05:15 --> Output Class Initialized
INFO - 2023-05-22 03:05:15 --> Security Class Initialized
INFO - 2023-05-22 03:05:15 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:15 --> Input Class Initialized
INFO - 2023-05-22 03:05:15 --> Input Class Initialized
INFO - 2023-05-22 03:05:15 --> Language Class Initialized
INFO - 2023-05-22 03:05:15 --> Language Class Initialized
INFO - 2023-05-22 03:05:15 --> Loader Class Initialized
INFO - 2023-05-22 03:05:15 --> Loader Class Initialized
INFO - 2023-05-22 03:05:15 --> Controller Class Initialized
INFO - 2023-05-22 03:05:15 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:05:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:15 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:15 --> Total execution time: 0.3677
INFO - 2023-05-22 03:05:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:15 --> Model "Login_model" initialized
INFO - 2023-05-22 03:05:16 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:16 --> Total execution time: 0.7212
INFO - 2023-05-22 03:05:33 --> Config Class Initialized
INFO - 2023-05-22 03:05:33 --> Config Class Initialized
INFO - 2023-05-22 03:05:33 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:33 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:33 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:05:33 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:33 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:33 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:33 --> URI Class Initialized
INFO - 2023-05-22 03:05:33 --> URI Class Initialized
INFO - 2023-05-22 03:05:33 --> Router Class Initialized
INFO - 2023-05-22 03:05:33 --> Router Class Initialized
INFO - 2023-05-22 03:05:33 --> Output Class Initialized
INFO - 2023-05-22 03:05:33 --> Output Class Initialized
INFO - 2023-05-22 03:05:33 --> Security Class Initialized
INFO - 2023-05-22 03:05:33 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:33 --> Input Class Initialized
INFO - 2023-05-22 03:05:33 --> Input Class Initialized
INFO - 2023-05-22 03:05:33 --> Language Class Initialized
INFO - 2023-05-22 03:05:33 --> Language Class Initialized
INFO - 2023-05-22 03:05:33 --> Loader Class Initialized
INFO - 2023-05-22 03:05:33 --> Loader Class Initialized
INFO - 2023-05-22 03:05:33 --> Controller Class Initialized
INFO - 2023-05-22 03:05:33 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:05:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:33 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:33 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:33 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:33 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:33 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:33 --> Total execution time: 0.2785
INFO - 2023-05-22 03:05:33 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:33 --> Total execution time: 0.3268
INFO - 2023-05-22 03:05:37 --> Config Class Initialized
INFO - 2023-05-22 03:05:37 --> Config Class Initialized
INFO - 2023-05-22 03:05:37 --> Config Class Initialized
INFO - 2023-05-22 03:05:37 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:37 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:37 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:37 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:05:37 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:05:37 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:37 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:37 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:37 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:37 --> URI Class Initialized
INFO - 2023-05-22 03:05:37 --> URI Class Initialized
INFO - 2023-05-22 03:05:37 --> Config Class Initialized
INFO - 2023-05-22 03:05:37 --> URI Class Initialized
INFO - 2023-05-22 03:05:37 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:37 --> Router Class Initialized
INFO - 2023-05-22 03:05:37 --> Router Class Initialized
INFO - 2023-05-22 03:05:37 --> Router Class Initialized
INFO - 2023-05-22 03:05:37 --> Output Class Initialized
INFO - 2023-05-22 03:05:37 --> Output Class Initialized
INFO - 2023-05-22 03:05:37 --> Output Class Initialized
INFO - 2023-05-22 03:05:37 --> Security Class Initialized
INFO - 2023-05-22 03:05:37 --> Security Class Initialized
INFO - 2023-05-22 03:05:37 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:05:37 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:37 --> Input Class Initialized
INFO - 2023-05-22 03:05:37 --> Input Class Initialized
INFO - 2023-05-22 03:05:37 --> Input Class Initialized
INFO - 2023-05-22 03:05:37 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:37 --> Language Class Initialized
INFO - 2023-05-22 03:05:37 --> Language Class Initialized
INFO - 2023-05-22 03:05:37 --> Language Class Initialized
INFO - 2023-05-22 03:05:37 --> URI Class Initialized
INFO - 2023-05-22 03:05:37 --> Router Class Initialized
INFO - 2023-05-22 03:05:37 --> Loader Class Initialized
INFO - 2023-05-22 03:05:37 --> Output Class Initialized
INFO - 2023-05-22 03:05:37 --> Loader Class Initialized
INFO - 2023-05-22 03:05:37 --> Controller Class Initialized
INFO - 2023-05-22 03:05:37 --> Controller Class Initialized
INFO - 2023-05-22 03:05:37 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:37 --> Loader Class Initialized
DEBUG - 2023-05-22 03:05:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:37 --> Input Class Initialized
INFO - 2023-05-22 03:05:37 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:37 --> Language Class Initialized
INFO - 2023-05-22 03:05:37 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:37 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:37 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:37 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:37 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:37 --> Loader Class Initialized
INFO - 2023-05-22 03:05:37 --> Final output sent to browser
INFO - 2023-05-22 03:05:37 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:37 --> Total execution time: 0.3557
INFO - 2023-05-22 03:05:37 --> Database Driver Class Initialized
DEBUG - 2023-05-22 03:05:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:37 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:37 --> Total execution time: 0.3721
INFO - 2023-05-22 03:05:37 --> Model "Login_model" initialized
INFO - 2023-05-22 03:05:37 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:37 --> Total execution time: 0.4114
INFO - 2023-05-22 03:05:37 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:37 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:37 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:37 --> Total execution time: 0.4933
INFO - 2023-05-22 03:05:39 --> Config Class Initialized
INFO - 2023-05-22 03:05:39 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:39 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:39 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:39 --> URI Class Initialized
INFO - 2023-05-22 03:05:39 --> Router Class Initialized
INFO - 2023-05-22 03:05:39 --> Output Class Initialized
INFO - 2023-05-22 03:05:39 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:39 --> Input Class Initialized
INFO - 2023-05-22 03:05:39 --> Language Class Initialized
INFO - 2023-05-22 03:05:39 --> Loader Class Initialized
INFO - 2023-05-22 03:05:39 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:39 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:39 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:39 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:39 --> Total execution time: 0.2788
INFO - 2023-05-22 03:05:42 --> Config Class Initialized
INFO - 2023-05-22 03:05:42 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:42 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:42 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:42 --> URI Class Initialized
INFO - 2023-05-22 03:05:42 --> Router Class Initialized
INFO - 2023-05-22 03:05:42 --> Output Class Initialized
INFO - 2023-05-22 03:05:42 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:42 --> Input Class Initialized
INFO - 2023-05-22 03:05:42 --> Language Class Initialized
INFO - 2023-05-22 03:05:42 --> Loader Class Initialized
INFO - 2023-05-22 03:05:42 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:43 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:43 --> Total execution time: 0.3788
INFO - 2023-05-22 03:05:43 --> Config Class Initialized
INFO - 2023-05-22 03:05:43 --> Config Class Initialized
INFO - 2023-05-22 03:05:43 --> Config Class Initialized
INFO - 2023-05-22 03:05:43 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:43 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:43 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:05:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:05:43 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:43 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:43 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:43 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:43 --> URI Class Initialized
INFO - 2023-05-22 03:05:43 --> URI Class Initialized
INFO - 2023-05-22 03:05:43 --> URI Class Initialized
INFO - 2023-05-22 03:05:43 --> Router Class Initialized
INFO - 2023-05-22 03:05:43 --> Router Class Initialized
INFO - 2023-05-22 03:05:43 --> Router Class Initialized
INFO - 2023-05-22 03:05:43 --> Output Class Initialized
INFO - 2023-05-22 03:05:43 --> Output Class Initialized
INFO - 2023-05-22 03:05:43 --> Output Class Initialized
INFO - 2023-05-22 03:05:43 --> Security Class Initialized
INFO - 2023-05-22 03:05:43 --> Security Class Initialized
INFO - 2023-05-22 03:05:43 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:43 --> Input Class Initialized
INFO - 2023-05-22 03:05:43 --> Input Class Initialized
INFO - 2023-05-22 03:05:43 --> Input Class Initialized
INFO - 2023-05-22 03:05:43 --> Language Class Initialized
INFO - 2023-05-22 03:05:43 --> Language Class Initialized
INFO - 2023-05-22 03:05:43 --> Language Class Initialized
INFO - 2023-05-22 03:05:43 --> Loader Class Initialized
INFO - 2023-05-22 03:05:43 --> Loader Class Initialized
INFO - 2023-05-22 03:05:43 --> Controller Class Initialized
INFO - 2023-05-22 03:05:43 --> Controller Class Initialized
INFO - 2023-05-22 03:05:43 --> Loader Class Initialized
DEBUG - 2023-05-22 03:05:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:05:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:43 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:43 --> Final output sent to browser
INFO - 2023-05-22 03:05:43 --> Final output sent to browser
INFO - 2023-05-22 03:05:43 --> Model "Cluster_model" initialized
DEBUG - 2023-05-22 03:05:43 --> Total execution time: 0.2536
DEBUG - 2023-05-22 03:05:43 --> Total execution time: 0.2523
INFO - 2023-05-22 03:05:43 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:43 --> Total execution time: 0.2797
INFO - 2023-05-22 03:05:43 --> Config Class Initialized
INFO - 2023-05-22 03:05:43 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:43 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:43 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:43 --> URI Class Initialized
INFO - 2023-05-22 03:05:43 --> Router Class Initialized
INFO - 2023-05-22 03:05:43 --> Output Class Initialized
INFO - 2023-05-22 03:05:43 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:43 --> Input Class Initialized
INFO - 2023-05-22 03:05:43 --> Language Class Initialized
INFO - 2023-05-22 03:05:43 --> Loader Class Initialized
INFO - 2023-05-22 03:05:43 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:46 --> Config Class Initialized
INFO - 2023-05-22 03:05:46 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:46 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:46 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:46 --> URI Class Initialized
INFO - 2023-05-22 03:05:46 --> Router Class Initialized
INFO - 2023-05-22 03:05:46 --> Output Class Initialized
INFO - 2023-05-22 03:05:46 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:46 --> Input Class Initialized
INFO - 2023-05-22 03:05:46 --> Language Class Initialized
INFO - 2023-05-22 03:05:46 --> Loader Class Initialized
INFO - 2023-05-22 03:05:46 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:46 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:46 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:46 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:46 --> Total execution time: 0.2094
INFO - 2023-05-22 03:05:51 --> Config Class Initialized
INFO - 2023-05-22 03:05:51 --> Config Class Initialized
INFO - 2023-05-22 03:05:51 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:51 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:51 --> Config Class Initialized
DEBUG - 2023-05-22 03:05:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:05:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:51 --> Hooks Class Initialized
INFO - 2023-05-22 03:05:51 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:51 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:51 --> URI Class Initialized
INFO - 2023-05-22 03:05:51 --> URI Class Initialized
INFO - 2023-05-22 03:05:51 --> Router Class Initialized
INFO - 2023-05-22 03:05:51 --> Router Class Initialized
DEBUG - 2023-05-22 03:05:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:51 --> Output Class Initialized
INFO - 2023-05-22 03:05:51 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:51 --> Output Class Initialized
INFO - 2023-05-22 03:05:51 --> URI Class Initialized
INFO - 2023-05-22 03:05:51 --> Security Class Initialized
INFO - 2023-05-22 03:05:51 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:51 --> Input Class Initialized
INFO - 2023-05-22 03:05:51 --> Input Class Initialized
INFO - 2023-05-22 03:05:51 --> Router Class Initialized
INFO - 2023-05-22 03:05:51 --> Language Class Initialized
INFO - 2023-05-22 03:05:51 --> Language Class Initialized
INFO - 2023-05-22 03:05:51 --> Output Class Initialized
INFO - 2023-05-22 03:05:51 --> Loader Class Initialized
INFO - 2023-05-22 03:05:51 --> Security Class Initialized
INFO - 2023-05-22 03:05:51 --> Loader Class Initialized
DEBUG - 2023-05-22 03:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:51 --> Controller Class Initialized
INFO - 2023-05-22 03:05:51 --> Input Class Initialized
DEBUG - 2023-05-22 03:05:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:51 --> Language Class Initialized
INFO - 2023-05-22 03:05:51 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:51 --> Loader Class Initialized
INFO - 2023-05-22 03:05:51 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:51 --> Controller Class Initialized
INFO - 2023-05-22 03:05:51 --> Database Driver Class Initialized
DEBUG - 2023-05-22 03:05:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:51 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:51 --> Total execution time: 0.2263
INFO - 2023-05-22 03:05:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:51 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:51 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:51 --> Total execution time: 0.2820
INFO - 2023-05-22 03:05:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:05:51 --> Final output sent to browser
DEBUG - 2023-05-22 03:05:51 --> Total execution time: 0.2893
INFO - 2023-05-22 03:05:51 --> Config Class Initialized
INFO - 2023-05-22 03:05:51 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:05:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:05:51 --> Utf8 Class Initialized
INFO - 2023-05-22 03:05:51 --> URI Class Initialized
INFO - 2023-05-22 03:05:51 --> Router Class Initialized
INFO - 2023-05-22 03:05:51 --> Output Class Initialized
INFO - 2023-05-22 03:05:51 --> Security Class Initialized
DEBUG - 2023-05-22 03:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:05:51 --> Input Class Initialized
INFO - 2023-05-22 03:05:51 --> Language Class Initialized
INFO - 2023-05-22 03:05:51 --> Loader Class Initialized
INFO - 2023-05-22 03:05:51 --> Controller Class Initialized
DEBUG - 2023-05-22 03:05:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:05:51 --> Database Driver Class Initialized
INFO - 2023-05-22 03:05:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:13 --> Config Class Initialized
INFO - 2023-05-22 03:06:13 --> Config Class Initialized
INFO - 2023-05-22 03:06:13 --> Hooks Class Initialized
INFO - 2023-05-22 03:06:13 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:06:13 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:13 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:13 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:13 --> URI Class Initialized
INFO - 2023-05-22 03:06:13 --> URI Class Initialized
INFO - 2023-05-22 03:06:13 --> Router Class Initialized
INFO - 2023-05-22 03:06:13 --> Router Class Initialized
INFO - 2023-05-22 03:06:13 --> Output Class Initialized
INFO - 2023-05-22 03:06:13 --> Output Class Initialized
INFO - 2023-05-22 03:06:13 --> Security Class Initialized
INFO - 2023-05-22 03:06:13 --> Security Class Initialized
DEBUG - 2023-05-22 03:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:13 --> Input Class Initialized
INFO - 2023-05-22 03:06:13 --> Input Class Initialized
INFO - 2023-05-22 03:06:13 --> Language Class Initialized
INFO - 2023-05-22 03:06:13 --> Language Class Initialized
INFO - 2023-05-22 03:06:13 --> Loader Class Initialized
INFO - 2023-05-22 03:06:13 --> Loader Class Initialized
INFO - 2023-05-22 03:06:13 --> Controller Class Initialized
INFO - 2023-05-22 03:06:13 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:06:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:13 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:13 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:13 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:13 --> Model "Login_model" initialized
INFO - 2023-05-22 03:06:13 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:13 --> Total execution time: 0.2100
INFO - 2023-05-22 03:06:13 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:13 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:13 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:13 --> Total execution time: 0.2651
INFO - 2023-05-22 03:06:15 --> Config Class Initialized
INFO - 2023-05-22 03:06:15 --> Config Class Initialized
INFO - 2023-05-22 03:06:15 --> Hooks Class Initialized
INFO - 2023-05-22 03:06:15 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:06:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:15 --> Utf8 Class Initialized
DEBUG - 2023-05-22 03:06:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:15 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:15 --> URI Class Initialized
INFO - 2023-05-22 03:06:15 --> URI Class Initialized
INFO - 2023-05-22 03:06:15 --> Router Class Initialized
INFO - 2023-05-22 03:06:15 --> Router Class Initialized
INFO - 2023-05-22 03:06:15 --> Output Class Initialized
INFO - 2023-05-22 03:06:15 --> Output Class Initialized
INFO - 2023-05-22 03:06:15 --> Security Class Initialized
INFO - 2023-05-22 03:06:15 --> Security Class Initialized
DEBUG - 2023-05-22 03:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:15 --> Input Class Initialized
INFO - 2023-05-22 03:06:15 --> Language Class Initialized
DEBUG - 2023-05-22 03:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:15 --> Input Class Initialized
INFO - 2023-05-22 03:06:15 --> Language Class Initialized
INFO - 2023-05-22 03:06:15 --> Loader Class Initialized
INFO - 2023-05-22 03:06:15 --> Loader Class Initialized
INFO - 2023-05-22 03:06:15 --> Controller Class Initialized
INFO - 2023-05-22 03:06:15 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:06:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:15 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:15 --> Total execution time: 0.3449
INFO - 2023-05-22 03:06:15 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:15 --> Total execution time: 0.4238
INFO - 2023-05-22 03:06:21 --> Config Class Initialized
INFO - 2023-05-22 03:06:21 --> Hooks Class Initialized
INFO - 2023-05-22 03:06:21 --> Config Class Initialized
INFO - 2023-05-22 03:06:21 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:06:21 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:21 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:21 --> URI Class Initialized
DEBUG - 2023-05-22 03:06:21 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:21 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:21 --> URI Class Initialized
INFO - 2023-05-22 03:06:21 --> Router Class Initialized
INFO - 2023-05-22 03:06:21 --> Router Class Initialized
INFO - 2023-05-22 03:06:21 --> Output Class Initialized
INFO - 2023-05-22 03:06:21 --> Security Class Initialized
INFO - 2023-05-22 03:06:21 --> Output Class Initialized
DEBUG - 2023-05-22 03:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:21 --> Security Class Initialized
INFO - 2023-05-22 03:06:21 --> Input Class Initialized
DEBUG - 2023-05-22 03:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:21 --> Language Class Initialized
INFO - 2023-05-22 03:06:21 --> Input Class Initialized
INFO - 2023-05-22 03:06:21 --> Language Class Initialized
INFO - 2023-05-22 03:06:21 --> Loader Class Initialized
INFO - 2023-05-22 03:06:21 --> Controller Class Initialized
INFO - 2023-05-22 03:06:21 --> Loader Class Initialized
DEBUG - 2023-05-22 03:06:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:21 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:21 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:21 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:21 --> Model "Login_model" initialized
INFO - 2023-05-22 03:06:21 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:21 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:21 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:21 --> Total execution time: 0.2531
INFO - 2023-05-22 03:06:22 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:22 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:22 --> Total execution time: 0.3178
INFO - 2023-05-22 03:06:24 --> Config Class Initialized
INFO - 2023-05-22 03:06:24 --> Config Class Initialized
INFO - 2023-05-22 03:06:24 --> Hooks Class Initialized
INFO - 2023-05-22 03:06:24 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:06:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:06:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:24 --> URI Class Initialized
INFO - 2023-05-22 03:06:24 --> URI Class Initialized
INFO - 2023-05-22 03:06:24 --> Router Class Initialized
INFO - 2023-05-22 03:06:24 --> Router Class Initialized
INFO - 2023-05-22 03:06:24 --> Output Class Initialized
INFO - 2023-05-22 03:06:24 --> Output Class Initialized
INFO - 2023-05-22 03:06:24 --> Security Class Initialized
INFO - 2023-05-22 03:06:24 --> Security Class Initialized
DEBUG - 2023-05-22 03:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:24 --> Input Class Initialized
INFO - 2023-05-22 03:06:24 --> Input Class Initialized
INFO - 2023-05-22 03:06:24 --> Language Class Initialized
INFO - 2023-05-22 03:06:24 --> Language Class Initialized
INFO - 2023-05-22 03:06:24 --> Loader Class Initialized
INFO - 2023-05-22 03:06:24 --> Loader Class Initialized
INFO - 2023-05-22 03:06:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:24 --> Total execution time: 0.2062
INFO - 2023-05-22 03:06:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:24 --> Model "Login_model" initialized
INFO - 2023-05-22 03:06:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:24 --> Total execution time: 0.8257
INFO - 2023-05-22 03:06:55 --> Config Class Initialized
INFO - 2023-05-22 03:06:55 --> Config Class Initialized
INFO - 2023-05-22 03:06:55 --> Config Class Initialized
INFO - 2023-05-22 03:06:55 --> Hooks Class Initialized
INFO - 2023-05-22 03:06:55 --> Hooks Class Initialized
INFO - 2023-05-22 03:06:55 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:06:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:06:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:06:55 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:55 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:55 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:55 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:55 --> URI Class Initialized
INFO - 2023-05-22 03:06:55 --> URI Class Initialized
INFO - 2023-05-22 03:06:55 --> URI Class Initialized
INFO - 2023-05-22 03:06:55 --> Router Class Initialized
INFO - 2023-05-22 03:06:55 --> Router Class Initialized
INFO - 2023-05-22 03:06:55 --> Router Class Initialized
INFO - 2023-05-22 03:06:55 --> Output Class Initialized
INFO - 2023-05-22 03:06:55 --> Output Class Initialized
INFO - 2023-05-22 03:06:55 --> Output Class Initialized
INFO - 2023-05-22 03:06:55 --> Security Class Initialized
INFO - 2023-05-22 03:06:55 --> Security Class Initialized
INFO - 2023-05-22 03:06:55 --> Security Class Initialized
DEBUG - 2023-05-22 03:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:55 --> Input Class Initialized
INFO - 2023-05-22 03:06:55 --> Input Class Initialized
INFO - 2023-05-22 03:06:55 --> Input Class Initialized
INFO - 2023-05-22 03:06:55 --> Language Class Initialized
INFO - 2023-05-22 03:06:55 --> Language Class Initialized
INFO - 2023-05-22 03:06:55 --> Language Class Initialized
INFO - 2023-05-22 03:06:55 --> Loader Class Initialized
INFO - 2023-05-22 03:06:55 --> Loader Class Initialized
INFO - 2023-05-22 03:06:55 --> Controller Class Initialized
INFO - 2023-05-22 03:06:55 --> Controller Class Initialized
INFO - 2023-05-22 03:06:55 --> Loader Class Initialized
DEBUG - 2023-05-22 03:06:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:06:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:55 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:55 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:55 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:55 --> Final output sent to browser
INFO - 2023-05-22 03:06:55 --> Final output sent to browser
INFO - 2023-05-22 03:06:55 --> Database Driver Class Initialized
DEBUG - 2023-05-22 03:06:55 --> Total execution time: 0.2069
DEBUG - 2023-05-22 03:06:55 --> Total execution time: 0.2065
INFO - 2023-05-22 03:06:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:55 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:55 --> Total execution time: 0.2675
INFO - 2023-05-22 03:06:55 --> Config Class Initialized
INFO - 2023-05-22 03:06:55 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:06:55 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:55 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:55 --> URI Class Initialized
INFO - 2023-05-22 03:06:55 --> Router Class Initialized
INFO - 2023-05-22 03:06:55 --> Output Class Initialized
INFO - 2023-05-22 03:06:55 --> Security Class Initialized
DEBUG - 2023-05-22 03:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:55 --> Input Class Initialized
INFO - 2023-05-22 03:06:55 --> Language Class Initialized
INFO - 2023-05-22 03:06:55 --> Loader Class Initialized
INFO - 2023-05-22 03:06:55 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:55 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:57 --> Config Class Initialized
INFO - 2023-05-22 03:06:57 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:06:57 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:57 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:57 --> URI Class Initialized
INFO - 2023-05-22 03:06:57 --> Router Class Initialized
INFO - 2023-05-22 03:06:57 --> Output Class Initialized
INFO - 2023-05-22 03:06:57 --> Security Class Initialized
DEBUG - 2023-05-22 03:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:57 --> Input Class Initialized
INFO - 2023-05-22 03:06:57 --> Language Class Initialized
INFO - 2023-05-22 03:06:57 --> Loader Class Initialized
INFO - 2023-05-22 03:06:57 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:57 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:57 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:57 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:57 --> Total execution time: 0.2836
INFO - 2023-05-22 03:06:59 --> Config Class Initialized
INFO - 2023-05-22 03:06:59 --> Hooks Class Initialized
INFO - 2023-05-22 03:06:59 --> Config Class Initialized
INFO - 2023-05-22 03:06:59 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:06:59 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:59 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:59 --> URI Class Initialized
DEBUG - 2023-05-22 03:06:59 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:06:59 --> Utf8 Class Initialized
INFO - 2023-05-22 03:06:59 --> URI Class Initialized
INFO - 2023-05-22 03:06:59 --> Router Class Initialized
INFO - 2023-05-22 03:06:59 --> Output Class Initialized
INFO - 2023-05-22 03:06:59 --> Router Class Initialized
INFO - 2023-05-22 03:06:59 --> Security Class Initialized
INFO - 2023-05-22 03:06:59 --> Output Class Initialized
DEBUG - 2023-05-22 03:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:59 --> Input Class Initialized
INFO - 2023-05-22 03:06:59 --> Security Class Initialized
DEBUG - 2023-05-22 03:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:06:59 --> Language Class Initialized
INFO - 2023-05-22 03:06:59 --> Input Class Initialized
INFO - 2023-05-22 03:06:59 --> Language Class Initialized
INFO - 2023-05-22 03:06:59 --> Loader Class Initialized
INFO - 2023-05-22 03:06:59 --> Loader Class Initialized
INFO - 2023-05-22 03:06:59 --> Controller Class Initialized
INFO - 2023-05-22 03:06:59 --> Controller Class Initialized
DEBUG - 2023-05-22 03:06:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:06:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:06:59 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:59 --> Database Driver Class Initialized
INFO - 2023-05-22 03:06:59 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:59 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:06:59 --> Final output sent to browser
DEBUG - 2023-05-22 03:06:59 --> Total execution time: 0.2573
INFO - 2023-05-22 03:07:00 --> Final output sent to browser
DEBUG - 2023-05-22 03:07:00 --> Total execution time: 0.3072
INFO - 2023-05-22 03:07:00 --> Config Class Initialized
INFO - 2023-05-22 03:07:00 --> Config Class Initialized
INFO - 2023-05-22 03:07:00 --> Hooks Class Initialized
INFO - 2023-05-22 03:07:00 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:07:00 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:07:00 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:07:00 --> Utf8 Class Initialized
INFO - 2023-05-22 03:07:00 --> Utf8 Class Initialized
INFO - 2023-05-22 03:07:00 --> URI Class Initialized
INFO - 2023-05-22 03:07:00 --> URI Class Initialized
INFO - 2023-05-22 03:07:00 --> Router Class Initialized
INFO - 2023-05-22 03:07:00 --> Router Class Initialized
INFO - 2023-05-22 03:07:00 --> Output Class Initialized
INFO - 2023-05-22 03:07:00 --> Output Class Initialized
INFO - 2023-05-22 03:07:00 --> Security Class Initialized
INFO - 2023-05-22 03:07:00 --> Security Class Initialized
DEBUG - 2023-05-22 03:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:07:00 --> Input Class Initialized
INFO - 2023-05-22 03:07:00 --> Input Class Initialized
INFO - 2023-05-22 03:07:00 --> Language Class Initialized
INFO - 2023-05-22 03:07:00 --> Language Class Initialized
INFO - 2023-05-22 03:07:00 --> Loader Class Initialized
INFO - 2023-05-22 03:07:00 --> Loader Class Initialized
INFO - 2023-05-22 03:07:00 --> Controller Class Initialized
INFO - 2023-05-22 03:07:00 --> Controller Class Initialized
DEBUG - 2023-05-22 03:07:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:07:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:07:00 --> Database Driver Class Initialized
INFO - 2023-05-22 03:07:00 --> Database Driver Class Initialized
INFO - 2023-05-22 03:07:00 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:07:00 --> Model "Login_model" initialized
INFO - 2023-05-22 03:07:00 --> Final output sent to browser
DEBUG - 2023-05-22 03:07:00 --> Total execution time: 0.2349
INFO - 2023-05-22 03:07:00 --> Database Driver Class Initialized
INFO - 2023-05-22 03:07:00 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:07:00 --> Final output sent to browser
DEBUG - 2023-05-22 03:07:00 --> Total execution time: 0.2713
INFO - 2023-05-22 03:07:06 --> Config Class Initialized
INFO - 2023-05-22 03:07:06 --> Config Class Initialized
INFO - 2023-05-22 03:07:06 --> Hooks Class Initialized
INFO - 2023-05-22 03:07:06 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:07:06 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:07:06 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:07:06 --> Utf8 Class Initialized
INFO - 2023-05-22 03:07:06 --> Utf8 Class Initialized
INFO - 2023-05-22 03:07:06 --> URI Class Initialized
INFO - 2023-05-22 03:07:06 --> URI Class Initialized
INFO - 2023-05-22 03:07:06 --> Router Class Initialized
INFO - 2023-05-22 03:07:06 --> Router Class Initialized
INFO - 2023-05-22 03:07:06 --> Output Class Initialized
INFO - 2023-05-22 03:07:06 --> Output Class Initialized
INFO - 2023-05-22 03:07:06 --> Security Class Initialized
INFO - 2023-05-22 03:07:06 --> Security Class Initialized
DEBUG - 2023-05-22 03:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:07:06 --> Input Class Initialized
INFO - 2023-05-22 03:07:06 --> Input Class Initialized
INFO - 2023-05-22 03:07:06 --> Language Class Initialized
INFO - 2023-05-22 03:07:06 --> Language Class Initialized
INFO - 2023-05-22 03:07:06 --> Loader Class Initialized
INFO - 2023-05-22 03:07:06 --> Loader Class Initialized
INFO - 2023-05-22 03:07:06 --> Controller Class Initialized
DEBUG - 2023-05-22 03:07:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:07:06 --> Controller Class Initialized
DEBUG - 2023-05-22 03:07:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:07:06 --> Database Driver Class Initialized
INFO - 2023-05-22 03:07:06 --> Database Driver Class Initialized
INFO - 2023-05-22 03:07:06 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:07:06 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:07:06 --> Final output sent to browser
DEBUG - 2023-05-22 03:07:06 --> Total execution time: 0.1993
INFO - 2023-05-22 03:07:06 --> Database Driver Class Initialized
INFO - 2023-05-22 03:07:06 --> Model "Login_model" initialized
INFO - 2023-05-22 03:07:06 --> Final output sent to browser
DEBUG - 2023-05-22 03:07:07 --> Total execution time: 0.6461
INFO - 2023-05-22 03:08:48 --> Config Class Initialized
INFO - 2023-05-22 03:08:48 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:08:49 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:08:49 --> Utf8 Class Initialized
INFO - 2023-05-22 03:08:49 --> URI Class Initialized
INFO - 2023-05-22 03:08:49 --> Router Class Initialized
INFO - 2023-05-22 03:08:49 --> Output Class Initialized
INFO - 2023-05-22 03:08:49 --> Security Class Initialized
DEBUG - 2023-05-22 03:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:08:49 --> Input Class Initialized
INFO - 2023-05-22 03:08:49 --> Language Class Initialized
INFO - 2023-05-22 03:08:49 --> Loader Class Initialized
INFO - 2023-05-22 03:08:49 --> Controller Class Initialized
DEBUG - 2023-05-22 03:08:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:08:49 --> Database Driver Class Initialized
INFO - 2023-05-22 03:08:49 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:08:49 --> Final output sent to browser
DEBUG - 2023-05-22 03:08:49 --> Total execution time: 0.7578
INFO - 2023-05-22 03:08:52 --> Config Class Initialized
INFO - 2023-05-22 03:08:52 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:08:52 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:08:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:08:52 --> URI Class Initialized
INFO - 2023-05-22 03:08:52 --> Config Class Initialized
INFO - 2023-05-22 03:08:52 --> Router Class Initialized
INFO - 2023-05-22 03:08:52 --> Config Class Initialized
INFO - 2023-05-22 03:08:52 --> Hooks Class Initialized
INFO - 2023-05-22 03:08:52 --> Hooks Class Initialized
INFO - 2023-05-22 03:08:52 --> Output Class Initialized
DEBUG - 2023-05-22 03:08:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:08:52 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:08:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:08:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:08:52 --> URI Class Initialized
INFO - 2023-05-22 03:08:52 --> URI Class Initialized
INFO - 2023-05-22 03:08:52 --> Security Class Initialized
DEBUG - 2023-05-22 03:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:08:52 --> Input Class Initialized
INFO - 2023-05-22 03:08:52 --> Router Class Initialized
INFO - 2023-05-22 03:08:52 --> Router Class Initialized
INFO - 2023-05-22 03:08:52 --> Language Class Initialized
INFO - 2023-05-22 03:08:52 --> Output Class Initialized
INFO - 2023-05-22 03:08:52 --> Output Class Initialized
INFO - 2023-05-22 03:08:52 --> Security Class Initialized
INFO - 2023-05-22 03:08:52 --> Security Class Initialized
DEBUG - 2023-05-22 03:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:08:52 --> Input Class Initialized
INFO - 2023-05-22 03:08:52 --> Input Class Initialized
INFO - 2023-05-22 03:08:52 --> Language Class Initialized
INFO - 2023-05-22 03:08:52 --> Language Class Initialized
INFO - 2023-05-22 03:08:52 --> Loader Class Initialized
INFO - 2023-05-22 03:08:52 --> Loader Class Initialized
INFO - 2023-05-22 03:08:52 --> Loader Class Initialized
INFO - 2023-05-22 03:08:52 --> Controller Class Initialized
DEBUG - 2023-05-22 03:08:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:08:52 --> Controller Class Initialized
INFO - 2023-05-22 03:08:52 --> Controller Class Initialized
DEBUG - 2023-05-22 03:08:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:08:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:08:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:08:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:08:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:08:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:08:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:08:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:08:52 --> Final output sent to browser
INFO - 2023-05-22 03:08:52 --> Final output sent to browser
INFO - 2023-05-22 03:08:52 --> Final output sent to browser
DEBUG - 2023-05-22 03:08:52 --> Total execution time: 0.2224
DEBUG - 2023-05-22 03:08:52 --> Total execution time: 0.2252
DEBUG - 2023-05-22 03:08:52 --> Total execution time: 0.3014
INFO - 2023-05-22 03:08:52 --> Config Class Initialized
INFO - 2023-05-22 03:08:52 --> Config Class Initialized
INFO - 2023-05-22 03:08:52 --> Hooks Class Initialized
INFO - 2023-05-22 03:08:52 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:08:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:08:52 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:08:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:08:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:08:52 --> URI Class Initialized
INFO - 2023-05-22 03:08:52 --> URI Class Initialized
INFO - 2023-05-22 03:08:52 --> Router Class Initialized
INFO - 2023-05-22 03:08:52 --> Router Class Initialized
INFO - 2023-05-22 03:08:52 --> Output Class Initialized
INFO - 2023-05-22 03:08:52 --> Output Class Initialized
INFO - 2023-05-22 03:08:52 --> Security Class Initialized
INFO - 2023-05-22 03:08:52 --> Security Class Initialized
DEBUG - 2023-05-22 03:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:08:52 --> Input Class Initialized
INFO - 2023-05-22 03:08:52 --> Input Class Initialized
INFO - 2023-05-22 03:08:52 --> Language Class Initialized
INFO - 2023-05-22 03:08:53 --> Language Class Initialized
INFO - 2023-05-22 03:08:53 --> Loader Class Initialized
INFO - 2023-05-22 03:08:53 --> Loader Class Initialized
INFO - 2023-05-22 03:08:53 --> Controller Class Initialized
INFO - 2023-05-22 03:08:53 --> Controller Class Initialized
DEBUG - 2023-05-22 03:08:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:08:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:08:53 --> Database Driver Class Initialized
INFO - 2023-05-22 03:08:53 --> Database Driver Class Initialized
INFO - 2023-05-22 03:08:53 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:08:53 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:08:53 --> Final output sent to browser
DEBUG - 2023-05-22 03:08:53 --> Total execution time: 0.2057
INFO - 2023-05-22 03:09:30 --> Config Class Initialized
INFO - 2023-05-22 03:09:30 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:09:30 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:09:30 --> Utf8 Class Initialized
INFO - 2023-05-22 03:09:30 --> URI Class Initialized
INFO - 2023-05-22 03:09:30 --> Router Class Initialized
INFO - 2023-05-22 03:09:30 --> Output Class Initialized
INFO - 2023-05-22 03:09:30 --> Security Class Initialized
DEBUG - 2023-05-22 03:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:09:30 --> Input Class Initialized
INFO - 2023-05-22 03:09:30 --> Language Class Initialized
INFO - 2023-05-22 03:09:30 --> Loader Class Initialized
INFO - 2023-05-22 03:09:30 --> Controller Class Initialized
DEBUG - 2023-05-22 03:09:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:09:30 --> Database Driver Class Initialized
INFO - 2023-05-22 03:09:31 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:09:35 --> Config Class Initialized
INFO - 2023-05-22 03:09:35 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:09:35 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:09:35 --> Utf8 Class Initialized
INFO - 2023-05-22 03:09:35 --> URI Class Initialized
INFO - 2023-05-22 03:09:35 --> Router Class Initialized
INFO - 2023-05-22 03:09:35 --> Output Class Initialized
INFO - 2023-05-22 03:09:35 --> Security Class Initialized
DEBUG - 2023-05-22 03:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:09:35 --> Input Class Initialized
INFO - 2023-05-22 03:09:35 --> Language Class Initialized
INFO - 2023-05-22 03:09:35 --> Loader Class Initialized
INFO - 2023-05-22 03:09:35 --> Controller Class Initialized
DEBUG - 2023-05-22 03:09:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:09:35 --> Database Driver Class Initialized
INFO - 2023-05-22 03:09:35 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:28:41 --> Config Class Initialized
INFO - 2023-05-22 03:28:41 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:28:41 --> Utf8 Class Initialized
INFO - 2023-05-22 03:28:41 --> URI Class Initialized
INFO - 2023-05-22 03:28:41 --> Router Class Initialized
INFO - 2023-05-22 03:28:41 --> Output Class Initialized
INFO - 2023-05-22 03:28:41 --> Security Class Initialized
DEBUG - 2023-05-22 03:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:28:41 --> Input Class Initialized
INFO - 2023-05-22 03:28:41 --> Language Class Initialized
INFO - 2023-05-22 03:28:41 --> Loader Class Initialized
INFO - 2023-05-22 03:28:41 --> Controller Class Initialized
INFO - 2023-05-22 03:28:41 --> Helper loaded: form_helper
INFO - 2023-05-22 03:28:41 --> Helper loaded: url_helper
DEBUG - 2023-05-22 03:28:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:28:41 --> Model "Change_model" initialized
INFO - 2023-05-22 03:28:41 --> Model "Grafana_model" initialized
INFO - 2023-05-22 03:28:42 --> Final output sent to browser
DEBUG - 2023-05-22 03:28:42 --> Total execution time: 0.7728
INFO - 2023-05-22 03:28:42 --> Config Class Initialized
INFO - 2023-05-22 03:28:42 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:28:42 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:28:42 --> Utf8 Class Initialized
INFO - 2023-05-22 03:28:42 --> URI Class Initialized
INFO - 2023-05-22 03:28:42 --> Router Class Initialized
INFO - 2023-05-22 03:28:42 --> Output Class Initialized
INFO - 2023-05-22 03:28:42 --> Security Class Initialized
DEBUG - 2023-05-22 03:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:28:42 --> Input Class Initialized
INFO - 2023-05-22 03:28:42 --> Language Class Initialized
INFO - 2023-05-22 03:28:42 --> Loader Class Initialized
INFO - 2023-05-22 03:28:42 --> Controller Class Initialized
INFO - 2023-05-22 03:28:42 --> Helper loaded: form_helper
INFO - 2023-05-22 03:28:42 --> Helper loaded: url_helper
DEBUG - 2023-05-22 03:28:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:28:42 --> Database Driver Class Initialized
INFO - 2023-05-22 03:28:42 --> Model "Login_model" initialized
INFO - 2023-05-22 03:28:42 --> Final output sent to browser
DEBUG - 2023-05-22 03:28:42 --> Total execution time: 0.4322
INFO - 2023-05-22 03:28:42 --> Config Class Initialized
INFO - 2023-05-22 03:28:42 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:28:42 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:28:42 --> Utf8 Class Initialized
INFO - 2023-05-22 03:28:42 --> URI Class Initialized
INFO - 2023-05-22 03:28:42 --> Router Class Initialized
INFO - 2023-05-22 03:28:42 --> Output Class Initialized
INFO - 2023-05-22 03:28:42 --> Security Class Initialized
DEBUG - 2023-05-22 03:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:28:42 --> Input Class Initialized
INFO - 2023-05-22 03:28:42 --> Language Class Initialized
INFO - 2023-05-22 03:28:42 --> Loader Class Initialized
INFO - 2023-05-22 03:28:42 --> Controller Class Initialized
DEBUG - 2023-05-22 03:28:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:28:42 --> Database Driver Class Initialized
INFO - 2023-05-22 03:28:42 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:28:42 --> Final output sent to browser
DEBUG - 2023-05-22 03:28:42 --> Total execution time: 0.3337
INFO - 2023-05-22 03:28:43 --> Config Class Initialized
INFO - 2023-05-22 03:28:43 --> Config Class Initialized
INFO - 2023-05-22 03:28:43 --> Hooks Class Initialized
INFO - 2023-05-22 03:28:43 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:28:43 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:28:43 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:28:43 --> Utf8 Class Initialized
INFO - 2023-05-22 03:28:43 --> Utf8 Class Initialized
INFO - 2023-05-22 03:28:43 --> URI Class Initialized
INFO - 2023-05-22 03:28:43 --> URI Class Initialized
INFO - 2023-05-22 03:28:43 --> Router Class Initialized
INFO - 2023-05-22 03:28:43 --> Router Class Initialized
INFO - 2023-05-22 03:28:43 --> Output Class Initialized
INFO - 2023-05-22 03:28:43 --> Output Class Initialized
INFO - 2023-05-22 03:28:43 --> Security Class Initialized
INFO - 2023-05-22 03:28:43 --> Security Class Initialized
DEBUG - 2023-05-22 03:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:28:43 --> Input Class Initialized
INFO - 2023-05-22 03:28:43 --> Input Class Initialized
INFO - 2023-05-22 03:28:43 --> Language Class Initialized
INFO - 2023-05-22 03:28:43 --> Language Class Initialized
INFO - 2023-05-22 03:28:43 --> Loader Class Initialized
INFO - 2023-05-22 03:28:43 --> Loader Class Initialized
INFO - 2023-05-22 03:28:43 --> Controller Class Initialized
INFO - 2023-05-22 03:28:43 --> Controller Class Initialized
DEBUG - 2023-05-22 03:28:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:28:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:28:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:28:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:28:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:28:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:28:43 --> Final output sent to browser
DEBUG - 2023-05-22 03:28:43 --> Total execution time: 0.2198
INFO - 2023-05-22 03:28:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:28:43 --> Model "Login_model" initialized
INFO - 2023-05-22 03:28:43 --> Final output sent to browser
DEBUG - 2023-05-22 03:28:43 --> Total execution time: 0.6846
INFO - 2023-05-22 03:29:50 --> Config Class Initialized
INFO - 2023-05-22 03:29:50 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:50 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:50 --> URI Class Initialized
INFO - 2023-05-22 03:29:50 --> Router Class Initialized
INFO - 2023-05-22 03:29:50 --> Output Class Initialized
INFO - 2023-05-22 03:29:50 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:50 --> Input Class Initialized
INFO - 2023-05-22 03:29:50 --> Language Class Initialized
INFO - 2023-05-22 03:29:50 --> Loader Class Initialized
INFO - 2023-05-22 03:29:50 --> Controller Class Initialized
INFO - 2023-05-22 03:29:50 --> Helper loaded: form_helper
INFO - 2023-05-22 03:29:50 --> Helper loaded: url_helper
DEBUG - 2023-05-22 03:29:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:50 --> Model "Change_model" initialized
INFO - 2023-05-22 03:29:50 --> Model "Grafana_model" initialized
INFO - 2023-05-22 03:29:50 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:50 --> Total execution time: 0.2270
INFO - 2023-05-22 03:29:50 --> Config Class Initialized
INFO - 2023-05-22 03:29:50 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:50 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:50 --> URI Class Initialized
INFO - 2023-05-22 03:29:50 --> Router Class Initialized
INFO - 2023-05-22 03:29:50 --> Output Class Initialized
INFO - 2023-05-22 03:29:50 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:50 --> Input Class Initialized
INFO - 2023-05-22 03:29:50 --> Language Class Initialized
INFO - 2023-05-22 03:29:50 --> Loader Class Initialized
INFO - 2023-05-22 03:29:50 --> Controller Class Initialized
INFO - 2023-05-22 03:29:50 --> Helper loaded: form_helper
INFO - 2023-05-22 03:29:50 --> Helper loaded: url_helper
DEBUG - 2023-05-22 03:29:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:50 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:50 --> Total execution time: 0.1522
INFO - 2023-05-22 03:29:50 --> Config Class Initialized
INFO - 2023-05-22 03:29:50 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:50 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:50 --> URI Class Initialized
INFO - 2023-05-22 03:29:50 --> Router Class Initialized
INFO - 2023-05-22 03:29:50 --> Output Class Initialized
INFO - 2023-05-22 03:29:50 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:51 --> Input Class Initialized
INFO - 2023-05-22 03:29:51 --> Language Class Initialized
INFO - 2023-05-22 03:29:51 --> Loader Class Initialized
INFO - 2023-05-22 03:29:51 --> Controller Class Initialized
INFO - 2023-05-22 03:29:51 --> Helper loaded: form_helper
INFO - 2023-05-22 03:29:51 --> Helper loaded: url_helper
DEBUG - 2023-05-22 03:29:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:51 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:51 --> Model "Login_model" initialized
INFO - 2023-05-22 03:29:51 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:51 --> Total execution time: 0.2525
INFO - 2023-05-22 03:29:51 --> Config Class Initialized
INFO - 2023-05-22 03:29:51 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:51 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:51 --> URI Class Initialized
INFO - 2023-05-22 03:29:51 --> Router Class Initialized
INFO - 2023-05-22 03:29:51 --> Output Class Initialized
INFO - 2023-05-22 03:29:51 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:51 --> Input Class Initialized
INFO - 2023-05-22 03:29:51 --> Language Class Initialized
INFO - 2023-05-22 03:29:51 --> Loader Class Initialized
INFO - 2023-05-22 03:29:51 --> Controller Class Initialized
DEBUG - 2023-05-22 03:29:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:51 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:29:51 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:51 --> Total execution time: 0.1950
INFO - 2023-05-22 03:29:51 --> Config Class Initialized
INFO - 2023-05-22 03:29:51 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:51 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:51 --> URI Class Initialized
INFO - 2023-05-22 03:29:51 --> Router Class Initialized
INFO - 2023-05-22 03:29:51 --> Output Class Initialized
INFO - 2023-05-22 03:29:51 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:51 --> Input Class Initialized
INFO - 2023-05-22 03:29:51 --> Language Class Initialized
INFO - 2023-05-22 03:29:51 --> Loader Class Initialized
INFO - 2023-05-22 03:29:51 --> Controller Class Initialized
DEBUG - 2023-05-22 03:29:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:51 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:29:51 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:51 --> Total execution time: 0.1943
INFO - 2023-05-22 03:29:51 --> Config Class Initialized
INFO - 2023-05-22 03:29:51 --> Config Class Initialized
INFO - 2023-05-22 03:29:51 --> Hooks Class Initialized
INFO - 2023-05-22 03:29:51 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:52 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:29:52 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:52 --> URI Class Initialized
INFO - 2023-05-22 03:29:52 --> URI Class Initialized
INFO - 2023-05-22 03:29:52 --> Router Class Initialized
INFO - 2023-05-22 03:29:52 --> Router Class Initialized
INFO - 2023-05-22 03:29:52 --> Output Class Initialized
INFO - 2023-05-22 03:29:52 --> Output Class Initialized
INFO - 2023-05-22 03:29:52 --> Security Class Initialized
INFO - 2023-05-22 03:29:52 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:52 --> Input Class Initialized
INFO - 2023-05-22 03:29:52 --> Input Class Initialized
INFO - 2023-05-22 03:29:52 --> Language Class Initialized
INFO - 2023-05-22 03:29:52 --> Language Class Initialized
INFO - 2023-05-22 03:29:52 --> Loader Class Initialized
INFO - 2023-05-22 03:29:52 --> Loader Class Initialized
INFO - 2023-05-22 03:29:52 --> Controller Class Initialized
DEBUG - 2023-05-22 03:29:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:52 --> Controller Class Initialized
DEBUG - 2023-05-22 03:29:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:29:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:29:52 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:52 --> Total execution time: 0.2602
INFO - 2023-05-22 03:29:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:52 --> Model "Login_model" initialized
INFO - 2023-05-22 03:29:52 --> Config Class Initialized
INFO - 2023-05-22 03:29:52 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:52 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:52 --> URI Class Initialized
INFO - 2023-05-22 03:29:52 --> Router Class Initialized
INFO - 2023-05-22 03:29:52 --> Output Class Initialized
INFO - 2023-05-22 03:29:52 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:52 --> Input Class Initialized
INFO - 2023-05-22 03:29:52 --> Language Class Initialized
INFO - 2023-05-22 03:29:52 --> Loader Class Initialized
INFO - 2023-05-22 03:29:52 --> Controller Class Initialized
DEBUG - 2023-05-22 03:29:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:29:52 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:52 --> Total execution time: 0.5328
INFO - 2023-05-22 03:29:52 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:52 --> Total execution time: 0.2387
INFO - 2023-05-22 03:29:52 --> Config Class Initialized
INFO - 2023-05-22 03:29:52 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:52 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:52 --> URI Class Initialized
INFO - 2023-05-22 03:29:52 --> Router Class Initialized
INFO - 2023-05-22 03:29:52 --> Output Class Initialized
INFO - 2023-05-22 03:29:52 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:52 --> Input Class Initialized
INFO - 2023-05-22 03:29:52 --> Language Class Initialized
INFO - 2023-05-22 03:29:52 --> Loader Class Initialized
INFO - 2023-05-22 03:29:52 --> Controller Class Initialized
DEBUG - 2023-05-22 03:29:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:29:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:52 --> Model "Login_model" initialized
INFO - 2023-05-22 03:29:53 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:53 --> Total execution time: 0.5275
INFO - 2023-05-22 03:29:57 --> Config Class Initialized
INFO - 2023-05-22 03:29:57 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:57 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:57 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:58 --> URI Class Initialized
INFO - 2023-05-22 03:29:58 --> Router Class Initialized
INFO - 2023-05-22 03:29:58 --> Output Class Initialized
INFO - 2023-05-22 03:29:58 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:58 --> Input Class Initialized
INFO - 2023-05-22 03:29:58 --> Language Class Initialized
INFO - 2023-05-22 03:29:58 --> Loader Class Initialized
INFO - 2023-05-22 03:29:58 --> Controller Class Initialized
DEBUG - 2023-05-22 03:29:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:58 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:58 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:29:58 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:58 --> Total execution time: 0.2862
INFO - 2023-05-22 03:29:58 --> Config Class Initialized
INFO - 2023-05-22 03:29:58 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:29:58 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:29:58 --> Utf8 Class Initialized
INFO - 2023-05-22 03:29:58 --> URI Class Initialized
INFO - 2023-05-22 03:29:58 --> Router Class Initialized
INFO - 2023-05-22 03:29:58 --> Output Class Initialized
INFO - 2023-05-22 03:29:58 --> Security Class Initialized
DEBUG - 2023-05-22 03:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:29:58 --> Input Class Initialized
INFO - 2023-05-22 03:29:58 --> Language Class Initialized
INFO - 2023-05-22 03:29:58 --> Loader Class Initialized
INFO - 2023-05-22 03:29:58 --> Controller Class Initialized
DEBUG - 2023-05-22 03:29:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:29:58 --> Database Driver Class Initialized
INFO - 2023-05-22 03:29:58 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:29:58 --> Final output sent to browser
DEBUG - 2023-05-22 03:29:58 --> Total execution time: 0.2789
INFO - 2023-05-22 03:30:24 --> Config Class Initialized
INFO - 2023-05-22 03:30:24 --> Config Class Initialized
INFO - 2023-05-22 03:30:24 --> Hooks Class Initialized
INFO - 2023-05-22 03:30:24 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:30:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:24 --> URI Class Initialized
INFO - 2023-05-22 03:30:24 --> URI Class Initialized
INFO - 2023-05-22 03:30:24 --> Router Class Initialized
INFO - 2023-05-22 03:30:24 --> Router Class Initialized
INFO - 2023-05-22 03:30:24 --> Output Class Initialized
INFO - 2023-05-22 03:30:24 --> Output Class Initialized
INFO - 2023-05-22 03:30:24 --> Security Class Initialized
INFO - 2023-05-22 03:30:24 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:24 --> Input Class Initialized
INFO - 2023-05-22 03:30:24 --> Input Class Initialized
INFO - 2023-05-22 03:30:24 --> Language Class Initialized
INFO - 2023-05-22 03:30:24 --> Language Class Initialized
INFO - 2023-05-22 03:30:24 --> Loader Class Initialized
INFO - 2023-05-22 03:30:24 --> Loader Class Initialized
INFO - 2023-05-22 03:30:24 --> Controller Class Initialized
INFO - 2023-05-22 03:30:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:30:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:24 --> Total execution time: 0.4247
INFO - 2023-05-22 03:30:24 --> Config Class Initialized
INFO - 2023-05-22 03:30:24 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:24 --> URI Class Initialized
INFO - 2023-05-22 03:30:24 --> Router Class Initialized
INFO - 2023-05-22 03:30:24 --> Output Class Initialized
INFO - 2023-05-22 03:30:24 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:24 --> Input Class Initialized
INFO - 2023-05-22 03:30:24 --> Language Class Initialized
INFO - 2023-05-22 03:30:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:24 --> Total execution time: 0.5685
INFO - 2023-05-22 03:30:24 --> Loader Class Initialized
INFO - 2023-05-22 03:30:24 --> Controller Class Initialized
INFO - 2023-05-22 03:30:24 --> Config Class Initialized
INFO - 2023-05-22 03:30:24 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:24 --> Database Driver Class Initialized
DEBUG - 2023-05-22 03:30:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:24 --> URI Class Initialized
INFO - 2023-05-22 03:30:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:24 --> Router Class Initialized
INFO - 2023-05-22 03:30:24 --> Output Class Initialized
INFO - 2023-05-22 03:30:24 --> Security Class Initialized
INFO - 2023-05-22 03:30:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:30:24 --> Total execution time: 0.2742
INFO - 2023-05-22 03:30:24 --> Input Class Initialized
INFO - 2023-05-22 03:30:24 --> Language Class Initialized
INFO - 2023-05-22 03:30:24 --> Loader Class Initialized
INFO - 2023-05-22 03:30:25 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:25 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:25 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:25 --> Total execution time: 0.4382
INFO - 2023-05-22 03:30:27 --> Config Class Initialized
INFO - 2023-05-22 03:30:27 --> Config Class Initialized
INFO - 2023-05-22 03:30:27 --> Hooks Class Initialized
INFO - 2023-05-22 03:30:27 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:30:27 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:27 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:27 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:27 --> URI Class Initialized
INFO - 2023-05-22 03:30:27 --> URI Class Initialized
INFO - 2023-05-22 03:30:27 --> Router Class Initialized
INFO - 2023-05-22 03:30:27 --> Router Class Initialized
INFO - 2023-05-22 03:30:27 --> Output Class Initialized
INFO - 2023-05-22 03:30:27 --> Output Class Initialized
INFO - 2023-05-22 03:30:27 --> Security Class Initialized
INFO - 2023-05-22 03:30:27 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:27 --> Input Class Initialized
INFO - 2023-05-22 03:30:27 --> Input Class Initialized
INFO - 2023-05-22 03:30:27 --> Language Class Initialized
INFO - 2023-05-22 03:30:27 --> Language Class Initialized
INFO - 2023-05-22 03:30:27 --> Loader Class Initialized
INFO - 2023-05-22 03:30:28 --> Loader Class Initialized
INFO - 2023-05-22 03:30:28 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:28 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:28 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:28 --> Total execution time: 0.1700
INFO - 2023-05-22 03:30:28 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:28 --> Config Class Initialized
INFO - 2023-05-22 03:30:28 --> Hooks Class Initialized
INFO - 2023-05-22 03:30:28 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:28 --> Total execution time: 0.2826
DEBUG - 2023-05-22 03:30:28 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:28 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:28 --> URI Class Initialized
INFO - 2023-05-22 03:30:28 --> Router Class Initialized
INFO - 2023-05-22 03:30:28 --> Config Class Initialized
INFO - 2023-05-22 03:30:28 --> Output Class Initialized
INFO - 2023-05-22 03:30:28 --> Hooks Class Initialized
INFO - 2023-05-22 03:30:28 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:30:28 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:28 --> Input Class Initialized
INFO - 2023-05-22 03:30:28 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:28 --> Language Class Initialized
INFO - 2023-05-22 03:30:28 --> URI Class Initialized
INFO - 2023-05-22 03:30:28 --> Router Class Initialized
INFO - 2023-05-22 03:30:28 --> Loader Class Initialized
INFO - 2023-05-22 03:30:28 --> Output Class Initialized
INFO - 2023-05-22 03:30:28 --> Security Class Initialized
INFO - 2023-05-22 03:30:28 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:28 --> Input Class Initialized
INFO - 2023-05-22 03:30:28 --> Language Class Initialized
INFO - 2023-05-22 03:30:28 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:28 --> Loader Class Initialized
INFO - 2023-05-22 03:30:28 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:28 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:28 --> Model "Login_model" initialized
INFO - 2023-05-22 03:30:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:28 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:28 --> Total execution time: 0.2774
INFO - 2023-05-22 03:30:28 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:28 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:28 --> Total execution time: 0.4639
INFO - 2023-05-22 03:30:33 --> Config Class Initialized
INFO - 2023-05-22 03:30:33 --> Config Class Initialized
INFO - 2023-05-22 03:30:33 --> Hooks Class Initialized
INFO - 2023-05-22 03:30:33 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:33 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:30:33 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:33 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:33 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:33 --> URI Class Initialized
INFO - 2023-05-22 03:30:33 --> URI Class Initialized
INFO - 2023-05-22 03:30:33 --> Router Class Initialized
INFO - 2023-05-22 03:30:33 --> Router Class Initialized
INFO - 2023-05-22 03:30:33 --> Output Class Initialized
INFO - 2023-05-22 03:30:33 --> Output Class Initialized
INFO - 2023-05-22 03:30:33 --> Security Class Initialized
INFO - 2023-05-22 03:30:33 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:33 --> Input Class Initialized
INFO - 2023-05-22 03:30:33 --> Input Class Initialized
INFO - 2023-05-22 03:30:33 --> Language Class Initialized
INFO - 2023-05-22 03:30:33 --> Language Class Initialized
INFO - 2023-05-22 03:30:33 --> Loader Class Initialized
INFO - 2023-05-22 03:30:33 --> Loader Class Initialized
INFO - 2023-05-22 03:30:33 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:33 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:33 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:33 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:33 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:33 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:33 --> Total execution time: 0.1671
INFO - 2023-05-22 03:30:33 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:33 --> Config Class Initialized
INFO - 2023-05-22 03:30:33 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:33 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:33 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:33 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:33 --> URI Class Initialized
INFO - 2023-05-22 03:30:33 --> Router Class Initialized
INFO - 2023-05-22 03:30:33 --> Output Class Initialized
INFO - 2023-05-22 03:30:33 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:33 --> Input Class Initialized
INFO - 2023-05-22 03:30:33 --> Language Class Initialized
INFO - 2023-05-22 03:30:33 --> Loader Class Initialized
INFO - 2023-05-22 03:30:33 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:33 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:33 --> Model "Login_model" initialized
INFO - 2023-05-22 03:30:33 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:33 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:33 --> Total execution time: 0.2192
INFO - 2023-05-22 03:30:34 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:34 --> Total execution time: 0.8326
INFO - 2023-05-22 03:30:34 --> Config Class Initialized
INFO - 2023-05-22 03:30:34 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:34 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:34 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:34 --> URI Class Initialized
INFO - 2023-05-22 03:30:34 --> Router Class Initialized
INFO - 2023-05-22 03:30:34 --> Output Class Initialized
INFO - 2023-05-22 03:30:34 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:34 --> Input Class Initialized
INFO - 2023-05-22 03:30:34 --> Language Class Initialized
INFO - 2023-05-22 03:30:34 --> Loader Class Initialized
INFO - 2023-05-22 03:30:34 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:34 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:34 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:34 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:34 --> Model "Login_model" initialized
INFO - 2023-05-22 03:30:34 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:34 --> Total execution time: 0.7401
INFO - 2023-05-22 03:30:43 --> Config Class Initialized
INFO - 2023-05-22 03:30:43 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:43 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:43 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:43 --> URI Class Initialized
INFO - 2023-05-22 03:30:43 --> Router Class Initialized
INFO - 2023-05-22 03:30:43 --> Output Class Initialized
INFO - 2023-05-22 03:30:43 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:43 --> Input Class Initialized
INFO - 2023-05-22 03:30:43 --> Language Class Initialized
INFO - 2023-05-22 03:30:43 --> Loader Class Initialized
INFO - 2023-05-22 03:30:43 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:43 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:43 --> Total execution time: 0.2344
INFO - 2023-05-22 03:30:43 --> Config Class Initialized
INFO - 2023-05-22 03:30:43 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:30:43 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:30:43 --> Utf8 Class Initialized
INFO - 2023-05-22 03:30:43 --> URI Class Initialized
INFO - 2023-05-22 03:30:43 --> Router Class Initialized
INFO - 2023-05-22 03:30:43 --> Output Class Initialized
INFO - 2023-05-22 03:30:43 --> Security Class Initialized
DEBUG - 2023-05-22 03:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:30:43 --> Input Class Initialized
INFO - 2023-05-22 03:30:43 --> Language Class Initialized
INFO - 2023-05-22 03:30:43 --> Loader Class Initialized
INFO - 2023-05-22 03:30:43 --> Controller Class Initialized
DEBUG - 2023-05-22 03:30:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:30:44 --> Database Driver Class Initialized
INFO - 2023-05-22 03:30:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:30:44 --> Final output sent to browser
DEBUG - 2023-05-22 03:30:44 --> Total execution time: 0.2695
INFO - 2023-05-22 03:31:18 --> Config Class Initialized
INFO - 2023-05-22 03:31:18 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:31:18 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:31:18 --> Utf8 Class Initialized
INFO - 2023-05-22 03:31:18 --> URI Class Initialized
INFO - 2023-05-22 03:31:18 --> Router Class Initialized
INFO - 2023-05-22 03:31:18 --> Output Class Initialized
INFO - 2023-05-22 03:31:18 --> Security Class Initialized
DEBUG - 2023-05-22 03:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:31:18 --> Input Class Initialized
INFO - 2023-05-22 03:31:18 --> Language Class Initialized
INFO - 2023-05-22 03:31:18 --> Loader Class Initialized
INFO - 2023-05-22 03:31:18 --> Controller Class Initialized
DEBUG - 2023-05-22 03:31:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:31:18 --> Database Driver Class Initialized
INFO - 2023-05-22 03:31:18 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:31:18 --> Final output sent to browser
DEBUG - 2023-05-22 03:31:18 --> Total execution time: 0.2187
INFO - 2023-05-22 03:31:19 --> Config Class Initialized
INFO - 2023-05-22 03:31:19 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:31:19 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:31:19 --> Utf8 Class Initialized
INFO - 2023-05-22 03:31:19 --> URI Class Initialized
INFO - 2023-05-22 03:31:19 --> Router Class Initialized
INFO - 2023-05-22 03:31:19 --> Output Class Initialized
INFO - 2023-05-22 03:31:19 --> Security Class Initialized
DEBUG - 2023-05-22 03:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:31:19 --> Input Class Initialized
INFO - 2023-05-22 03:31:19 --> Language Class Initialized
INFO - 2023-05-22 03:31:19 --> Loader Class Initialized
INFO - 2023-05-22 03:31:19 --> Controller Class Initialized
DEBUG - 2023-05-22 03:31:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:31:19 --> Database Driver Class Initialized
INFO - 2023-05-22 03:31:19 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:31:19 --> Final output sent to browser
DEBUG - 2023-05-22 03:31:19 --> Total execution time: 0.2191
INFO - 2023-05-22 03:31:34 --> Config Class Initialized
INFO - 2023-05-22 03:31:34 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:31:34 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:31:34 --> Utf8 Class Initialized
INFO - 2023-05-22 03:31:34 --> URI Class Initialized
INFO - 2023-05-22 03:31:34 --> Router Class Initialized
INFO - 2023-05-22 03:31:34 --> Output Class Initialized
INFO - 2023-05-22 03:31:34 --> Security Class Initialized
DEBUG - 2023-05-22 03:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:31:34 --> Input Class Initialized
INFO - 2023-05-22 03:31:34 --> Language Class Initialized
INFO - 2023-05-22 03:31:34 --> Loader Class Initialized
INFO - 2023-05-22 03:31:34 --> Controller Class Initialized
DEBUG - 2023-05-22 03:31:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:31:34 --> Database Driver Class Initialized
INFO - 2023-05-22 03:31:35 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:31:35 --> Final output sent to browser
DEBUG - 2023-05-22 03:31:35 --> Total execution time: 0.2224
INFO - 2023-05-22 03:31:35 --> Config Class Initialized
INFO - 2023-05-22 03:31:35 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:31:35 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:31:35 --> Utf8 Class Initialized
INFO - 2023-05-22 03:31:35 --> URI Class Initialized
INFO - 2023-05-22 03:31:35 --> Router Class Initialized
INFO - 2023-05-22 03:31:35 --> Output Class Initialized
INFO - 2023-05-22 03:31:35 --> Security Class Initialized
DEBUG - 2023-05-22 03:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:31:35 --> Input Class Initialized
INFO - 2023-05-22 03:31:35 --> Language Class Initialized
INFO - 2023-05-22 03:31:35 --> Loader Class Initialized
INFO - 2023-05-22 03:31:35 --> Controller Class Initialized
DEBUG - 2023-05-22 03:31:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:31:35 --> Database Driver Class Initialized
INFO - 2023-05-22 03:31:35 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:31:35 --> Final output sent to browser
DEBUG - 2023-05-22 03:31:35 --> Total execution time: 0.1934
INFO - 2023-05-22 03:40:10 --> Config Class Initialized
INFO - 2023-05-22 03:40:10 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:10 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:10 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:10 --> URI Class Initialized
INFO - 2023-05-22 03:40:10 --> Router Class Initialized
INFO - 2023-05-22 03:40:10 --> Output Class Initialized
INFO - 2023-05-22 03:40:10 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:10 --> Input Class Initialized
INFO - 2023-05-22 03:40:10 --> Language Class Initialized
INFO - 2023-05-22 03:40:10 --> Loader Class Initialized
INFO - 2023-05-22 03:40:10 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:10 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:10 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:10 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:10 --> Total execution time: 0.4266
INFO - 2023-05-22 03:40:11 --> Config Class Initialized
INFO - 2023-05-22 03:40:11 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:11 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:11 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:11 --> URI Class Initialized
INFO - 2023-05-22 03:40:11 --> Router Class Initialized
INFO - 2023-05-22 03:40:11 --> Output Class Initialized
INFO - 2023-05-22 03:40:11 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:11 --> Input Class Initialized
INFO - 2023-05-22 03:40:11 --> Language Class Initialized
INFO - 2023-05-22 03:40:11 --> Loader Class Initialized
INFO - 2023-05-22 03:40:11 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:11 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:11 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:11 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:11 --> Total execution time: 0.3116
INFO - 2023-05-22 03:40:15 --> Config Class Initialized
INFO - 2023-05-22 03:40:15 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:15 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:15 --> URI Class Initialized
INFO - 2023-05-22 03:40:15 --> Router Class Initialized
INFO - 2023-05-22 03:40:15 --> Output Class Initialized
INFO - 2023-05-22 03:40:15 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:15 --> Input Class Initialized
INFO - 2023-05-22 03:40:15 --> Language Class Initialized
INFO - 2023-05-22 03:40:15 --> Loader Class Initialized
INFO - 2023-05-22 03:40:15 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:15 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:15 --> Model "Cluster_model" initialized
ERROR - 2023-05-22 03:40:15 --> Exception of type 'Error' occurred with Message: Call to undefined method Login_model::getUserId() in File /var/www/html/KunlunMonitor/application/controllers/user/RCR.php at Line 26
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): RCR->getRCRList()
#1 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#2 {main}
INFO - 2023-05-22 03:40:15 --> Config Class Initialized
INFO - 2023-05-22 03:40:15 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:15 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:15 --> URI Class Initialized
INFO - 2023-05-22 03:40:15 --> Router Class Initialized
INFO - 2023-05-22 03:40:15 --> Output Class Initialized
INFO - 2023-05-22 03:40:15 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:15 --> Input Class Initialized
INFO - 2023-05-22 03:40:15 --> Language Class Initialized
INFO - 2023-05-22 03:40:15 --> Loader Class Initialized
INFO - 2023-05-22 03:40:15 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:15 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:15 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:15 --> Model "Cluster_model" initialized
ERROR - 2023-05-22 03:40:15 --> Exception of type 'Error' occurred with Message: Call to undefined method Login_model::getUserId() in File /var/www/html/KunlunMonitor/application/controllers/user/RCR.php at Line 26
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): RCR->getRCRList()
#1 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#2 {main}
INFO - 2023-05-22 03:40:15 --> Config Class Initialized
INFO - 2023-05-22 03:40:15 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:15 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:15 --> URI Class Initialized
INFO - 2023-05-22 03:40:15 --> Router Class Initialized
INFO - 2023-05-22 03:40:15 --> Output Class Initialized
INFO - 2023-05-22 03:40:16 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:16 --> Input Class Initialized
INFO - 2023-05-22 03:40:16 --> Language Class Initialized
INFO - 2023-05-22 03:40:16 --> Loader Class Initialized
INFO - 2023-05-22 03:40:16 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:16 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:16 --> Total execution time: 0.1914
INFO - 2023-05-22 03:40:16 --> Config Class Initialized
INFO - 2023-05-22 03:40:16 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:16 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:16 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:16 --> URI Class Initialized
INFO - 2023-05-22 03:40:16 --> Router Class Initialized
INFO - 2023-05-22 03:40:16 --> Output Class Initialized
INFO - 2023-05-22 03:40:16 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:16 --> Input Class Initialized
INFO - 2023-05-22 03:40:16 --> Language Class Initialized
INFO - 2023-05-22 03:40:16 --> Loader Class Initialized
INFO - 2023-05-22 03:40:16 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:16 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:16 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:16 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:16 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:16 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:16 --> Total execution time: 0.3743
INFO - 2023-05-22 03:40:22 --> Config Class Initialized
INFO - 2023-05-22 03:40:22 --> Config Class Initialized
INFO - 2023-05-22 03:40:22 --> Hooks Class Initialized
INFO - 2023-05-22 03:40:22 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:22 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:40:22 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:22 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:22 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:22 --> URI Class Initialized
INFO - 2023-05-22 03:40:22 --> URI Class Initialized
INFO - 2023-05-22 03:40:22 --> Router Class Initialized
INFO - 2023-05-22 03:40:22 --> Router Class Initialized
INFO - 2023-05-22 03:40:22 --> Output Class Initialized
INFO - 2023-05-22 03:40:22 --> Output Class Initialized
INFO - 2023-05-22 03:40:22 --> Security Class Initialized
INFO - 2023-05-22 03:40:22 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:22 --> Input Class Initialized
INFO - 2023-05-22 03:40:22 --> Input Class Initialized
INFO - 2023-05-22 03:40:22 --> Language Class Initialized
INFO - 2023-05-22 03:40:22 --> Language Class Initialized
INFO - 2023-05-22 03:40:22 --> Loader Class Initialized
INFO - 2023-05-22 03:40:22 --> Controller Class Initialized
INFO - 2023-05-22 03:40:22 --> Loader Class Initialized
DEBUG - 2023-05-22 03:40:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:22 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:22 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:22 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:22 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:22 --> Total execution time: 0.1957
INFO - 2023-05-22 03:40:22 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:22 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:22 --> Config Class Initialized
INFO - 2023-05-22 03:40:22 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:22 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:22 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:22 --> URI Class Initialized
INFO - 2023-05-22 03:40:22 --> Router Class Initialized
INFO - 2023-05-22 03:40:22 --> Output Class Initialized
INFO - 2023-05-22 03:40:22 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:22 --> Input Class Initialized
INFO - 2023-05-22 03:40:22 --> Language Class Initialized
INFO - 2023-05-22 03:40:22 --> Loader Class Initialized
INFO - 2023-05-22 03:40:22 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:22 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:22 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:22 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:22 --> Total execution time: 0.2367
INFO - 2023-05-22 03:40:23 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:23 --> Total execution time: 0.7185
INFO - 2023-05-22 03:40:23 --> Config Class Initialized
INFO - 2023-05-22 03:40:23 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:23 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:23 --> URI Class Initialized
INFO - 2023-05-22 03:40:23 --> Router Class Initialized
INFO - 2023-05-22 03:40:23 --> Output Class Initialized
INFO - 2023-05-22 03:40:23 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:23 --> Input Class Initialized
INFO - 2023-05-22 03:40:23 --> Language Class Initialized
INFO - 2023-05-22 03:40:23 --> Loader Class Initialized
INFO - 2023-05-22 03:40:23 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:23 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:23 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:23 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:23 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:23 --> Total execution time: 0.4256
INFO - 2023-05-22 03:40:25 --> Config Class Initialized
INFO - 2023-05-22 03:40:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:25 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:25 --> URI Class Initialized
INFO - 2023-05-22 03:40:25 --> Router Class Initialized
INFO - 2023-05-22 03:40:25 --> Output Class Initialized
INFO - 2023-05-22 03:40:25 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:25 --> Input Class Initialized
INFO - 2023-05-22 03:40:25 --> Language Class Initialized
INFO - 2023-05-22 03:40:25 --> Loader Class Initialized
INFO - 2023-05-22 03:40:25 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:25 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:25 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:25 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:25 --> Model "Cluster_model" initialized
ERROR - 2023-05-22 03:40:25 --> Exception of type 'Error' occurred with Message: Call to undefined method Login_model::getUserId() in File /var/www/html/KunlunMonitor/application/controllers/user/RCR.php at Line 26
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): RCR->getRCRList()
#1 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#2 {main}
INFO - 2023-05-22 03:40:25 --> Config Class Initialized
INFO - 2023-05-22 03:40:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:25 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:25 --> URI Class Initialized
INFO - 2023-05-22 03:40:25 --> Router Class Initialized
INFO - 2023-05-22 03:40:25 --> Output Class Initialized
INFO - 2023-05-22 03:40:25 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:25 --> Input Class Initialized
INFO - 2023-05-22 03:40:25 --> Language Class Initialized
INFO - 2023-05-22 03:40:25 --> Loader Class Initialized
INFO - 2023-05-22 03:40:25 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:25 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:25 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:25 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:25 --> Model "Cluster_model" initialized
ERROR - 2023-05-22 03:40:25 --> Exception of type 'Error' occurred with Message: Call to undefined method Login_model::getUserId() in File /var/www/html/KunlunMonitor/application/controllers/user/RCR.php at Line 26
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): RCR->getRCRList()
#1 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#2 {main}
INFO - 2023-05-22 03:40:25 --> Config Class Initialized
INFO - 2023-05-22 03:40:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:25 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:25 --> URI Class Initialized
INFO - 2023-05-22 03:40:25 --> Router Class Initialized
INFO - 2023-05-22 03:40:25 --> Output Class Initialized
INFO - 2023-05-22 03:40:25 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:25 --> Input Class Initialized
INFO - 2023-05-22 03:40:25 --> Language Class Initialized
INFO - 2023-05-22 03:40:25 --> Loader Class Initialized
INFO - 2023-05-22 03:40:25 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:25 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:25 --> Total execution time: 0.1530
INFO - 2023-05-22 03:40:25 --> Config Class Initialized
INFO - 2023-05-22 03:40:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:25 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:25 --> URI Class Initialized
INFO - 2023-05-22 03:40:25 --> Router Class Initialized
INFO - 2023-05-22 03:40:25 --> Output Class Initialized
INFO - 2023-05-22 03:40:25 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:25 --> Input Class Initialized
INFO - 2023-05-22 03:40:25 --> Language Class Initialized
INFO - 2023-05-22 03:40:25 --> Loader Class Initialized
INFO - 2023-05-22 03:40:25 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:26 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:26 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:26 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:26 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:26 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:26 --> Total execution time: 0.2657
INFO - 2023-05-22 03:40:38 --> Config Class Initialized
INFO - 2023-05-22 03:40:38 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:38 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:38 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:38 --> URI Class Initialized
INFO - 2023-05-22 03:40:38 --> Router Class Initialized
INFO - 2023-05-22 03:40:38 --> Output Class Initialized
INFO - 2023-05-22 03:40:38 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:38 --> Input Class Initialized
INFO - 2023-05-22 03:40:38 --> Language Class Initialized
INFO - 2023-05-22 03:40:38 --> Loader Class Initialized
INFO - 2023-05-22 03:40:38 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:38 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:38 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:38 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:38 --> Total execution time: 0.2142
INFO - 2023-05-22 03:40:38 --> Config Class Initialized
INFO - 2023-05-22 03:40:38 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:38 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:38 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:38 --> URI Class Initialized
INFO - 2023-05-22 03:40:38 --> Router Class Initialized
INFO - 2023-05-22 03:40:39 --> Output Class Initialized
INFO - 2023-05-22 03:40:39 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:39 --> Input Class Initialized
INFO - 2023-05-22 03:40:39 --> Language Class Initialized
INFO - 2023-05-22 03:40:39 --> Loader Class Initialized
INFO - 2023-05-22 03:40:39 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:39 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:39 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:39 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:39 --> Total execution time: 0.2364
INFO - 2023-05-22 03:40:40 --> Config Class Initialized
INFO - 2023-05-22 03:40:40 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:40 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:40 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:40 --> URI Class Initialized
INFO - 2023-05-22 03:40:40 --> Router Class Initialized
INFO - 2023-05-22 03:40:40 --> Output Class Initialized
INFO - 2023-05-22 03:40:40 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:40 --> Input Class Initialized
INFO - 2023-05-22 03:40:40 --> Language Class Initialized
INFO - 2023-05-22 03:40:40 --> Loader Class Initialized
INFO - 2023-05-22 03:40:40 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:40 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:40 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:40 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:40 --> Model "Cluster_model" initialized
ERROR - 2023-05-22 03:40:40 --> Exception of type 'Error' occurred with Message: Call to undefined method Login_model::getUserId() in File /var/www/html/KunlunMonitor/application/controllers/user/RCR.php at Line 26
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): RCR->getRCRList()
#1 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#2 {main}
INFO - 2023-05-22 03:40:40 --> Config Class Initialized
INFO - 2023-05-22 03:40:40 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:40 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:40 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:40 --> URI Class Initialized
INFO - 2023-05-22 03:40:40 --> Router Class Initialized
INFO - 2023-05-22 03:40:40 --> Output Class Initialized
INFO - 2023-05-22 03:40:41 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:41 --> Input Class Initialized
INFO - 2023-05-22 03:40:41 --> Language Class Initialized
INFO - 2023-05-22 03:40:41 --> Loader Class Initialized
INFO - 2023-05-22 03:40:41 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:41 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:41 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:41 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:41 --> Model "Cluster_model" initialized
ERROR - 2023-05-22 03:40:41 --> Exception of type 'Error' occurred with Message: Call to undefined method Login_model::getUserId() in File /var/www/html/KunlunMonitor/application/controllers/user/RCR.php at Line 26
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): RCR->getRCRList()
#1 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#2 {main}
INFO - 2023-05-22 03:40:41 --> Config Class Initialized
INFO - 2023-05-22 03:40:41 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:41 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:41 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:41 --> URI Class Initialized
INFO - 2023-05-22 03:40:41 --> Router Class Initialized
INFO - 2023-05-22 03:40:41 --> Output Class Initialized
INFO - 2023-05-22 03:40:41 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:41 --> Input Class Initialized
INFO - 2023-05-22 03:40:41 --> Language Class Initialized
INFO - 2023-05-22 03:40:41 --> Loader Class Initialized
INFO - 2023-05-22 03:40:41 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:41 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:41 --> Total execution time: 0.1706
INFO - 2023-05-22 03:40:41 --> Config Class Initialized
INFO - 2023-05-22 03:40:41 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:41 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:41 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:41 --> URI Class Initialized
INFO - 2023-05-22 03:40:41 --> Router Class Initialized
INFO - 2023-05-22 03:40:41 --> Output Class Initialized
INFO - 2023-05-22 03:40:41 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:41 --> Input Class Initialized
INFO - 2023-05-22 03:40:41 --> Language Class Initialized
INFO - 2023-05-22 03:40:41 --> Loader Class Initialized
INFO - 2023-05-22 03:40:41 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:41 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:41 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:41 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:41 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:41 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:41 --> Total execution time: 0.3106
INFO - 2023-05-22 03:40:45 --> Config Class Initialized
INFO - 2023-05-22 03:40:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:45 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:45 --> URI Class Initialized
INFO - 2023-05-22 03:40:45 --> Router Class Initialized
INFO - 2023-05-22 03:40:45 --> Output Class Initialized
INFO - 2023-05-22 03:40:45 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:45 --> Input Class Initialized
INFO - 2023-05-22 03:40:45 --> Language Class Initialized
INFO - 2023-05-22 03:40:45 --> Loader Class Initialized
INFO - 2023-05-22 03:40:45 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:45 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:45 --> Model "Login_model" initialized
ERROR - 2023-05-22 03:40:45 --> Exception of type 'Error' occurred with Message: Call to undefined method Login_model::getUserId() in File /var/www/html/KunlunMonitor/application/controllers/user/RCR.php at Line 285
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): RCR->getMetaList()
#1 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#2 {main}
INFO - 2023-05-22 03:40:45 --> Config Class Initialized
INFO - 2023-05-22 03:40:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:45 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:45 --> URI Class Initialized
INFO - 2023-05-22 03:40:45 --> Router Class Initialized
INFO - 2023-05-22 03:40:45 --> Output Class Initialized
INFO - 2023-05-22 03:40:45 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:45 --> Input Class Initialized
INFO - 2023-05-22 03:40:45 --> Language Class Initialized
INFO - 2023-05-22 03:40:45 --> Loader Class Initialized
INFO - 2023-05-22 03:40:45 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:45 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:45 --> Model "Login_model" initialized
ERROR - 2023-05-22 03:40:45 --> Exception of type 'Error' occurred with Message: Call to undefined method Login_model::getUserId() in File /var/www/html/KunlunMonitor/application/controllers/user/RCR.php at Line 285
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): RCR->getMetaList()
#1 /var/www/html/KunlunMonitor/index.php(305): require_once('/var/www/html/K...')
#2 {main}
INFO - 2023-05-22 03:40:49 --> Config Class Initialized
INFO - 2023-05-22 03:40:49 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:49 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:49 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:49 --> URI Class Initialized
INFO - 2023-05-22 03:40:49 --> Router Class Initialized
INFO - 2023-05-22 03:40:49 --> Output Class Initialized
INFO - 2023-05-22 03:40:49 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:49 --> Input Class Initialized
INFO - 2023-05-22 03:40:49 --> Language Class Initialized
INFO - 2023-05-22 03:40:49 --> Loader Class Initialized
INFO - 2023-05-22 03:40:49 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:49 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:49 --> Total execution time: 0.1202
INFO - 2023-05-22 03:40:49 --> Config Class Initialized
INFO - 2023-05-22 03:40:49 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:49 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:49 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:49 --> URI Class Initialized
INFO - 2023-05-22 03:40:49 --> Router Class Initialized
INFO - 2023-05-22 03:40:49 --> Output Class Initialized
INFO - 2023-05-22 03:40:49 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:49 --> Input Class Initialized
INFO - 2023-05-22 03:40:49 --> Language Class Initialized
INFO - 2023-05-22 03:40:49 --> Loader Class Initialized
INFO - 2023-05-22 03:40:49 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:49 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:49 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:49 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:49 --> Total execution time: 0.2106
INFO - 2023-05-22 03:40:52 --> Config Class Initialized
INFO - 2023-05-22 03:40:52 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:52 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:52 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:52 --> URI Class Initialized
INFO - 2023-05-22 03:40:52 --> Router Class Initialized
INFO - 2023-05-22 03:40:52 --> Output Class Initialized
INFO - 2023-05-22 03:40:52 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:52 --> Input Class Initialized
INFO - 2023-05-22 03:40:52 --> Language Class Initialized
INFO - 2023-05-22 03:40:52 --> Loader Class Initialized
INFO - 2023-05-22 03:40:52 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:52 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:52 --> Model "Login_model" initialized
INFO - 2023-05-22 03:40:52 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:52 --> Total execution time: 0.1722
INFO - 2023-05-22 03:40:58 --> Config Class Initialized
INFO - 2023-05-22 03:40:58 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:58 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:58 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:58 --> URI Class Initialized
INFO - 2023-05-22 03:40:58 --> Router Class Initialized
INFO - 2023-05-22 03:40:58 --> Output Class Initialized
INFO - 2023-05-22 03:40:58 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:58 --> Input Class Initialized
INFO - 2023-05-22 03:40:58 --> Language Class Initialized
INFO - 2023-05-22 03:40:58 --> Loader Class Initialized
INFO - 2023-05-22 03:40:58 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:58 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:58 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:58 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:58 --> Total execution time: 0.1963
INFO - 2023-05-22 03:40:58 --> Config Class Initialized
INFO - 2023-05-22 03:40:58 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:40:58 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:40:58 --> Utf8 Class Initialized
INFO - 2023-05-22 03:40:58 --> URI Class Initialized
INFO - 2023-05-22 03:40:58 --> Router Class Initialized
INFO - 2023-05-22 03:40:58 --> Output Class Initialized
INFO - 2023-05-22 03:40:58 --> Security Class Initialized
DEBUG - 2023-05-22 03:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:40:58 --> Input Class Initialized
INFO - 2023-05-22 03:40:58 --> Language Class Initialized
INFO - 2023-05-22 03:40:58 --> Loader Class Initialized
INFO - 2023-05-22 03:40:58 --> Controller Class Initialized
DEBUG - 2023-05-22 03:40:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:40:59 --> Database Driver Class Initialized
INFO - 2023-05-22 03:40:59 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:40:59 --> Final output sent to browser
DEBUG - 2023-05-22 03:40:59 --> Total execution time: 0.2367
INFO - 2023-05-22 03:41:01 --> Config Class Initialized
INFO - 2023-05-22 03:41:01 --> Config Class Initialized
INFO - 2023-05-22 03:41:01 --> Config Class Initialized
INFO - 2023-05-22 03:41:01 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:01 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:01 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:01 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:01 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:01 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:01 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:01 --> URI Class Initialized
INFO - 2023-05-22 03:41:01 --> URI Class Initialized
INFO - 2023-05-22 03:41:01 --> URI Class Initialized
INFO - 2023-05-22 03:41:01 --> Router Class Initialized
INFO - 2023-05-22 03:41:01 --> Router Class Initialized
INFO - 2023-05-22 03:41:01 --> Router Class Initialized
INFO - 2023-05-22 03:41:01 --> Output Class Initialized
INFO - 2023-05-22 03:41:01 --> Output Class Initialized
INFO - 2023-05-22 03:41:01 --> Output Class Initialized
INFO - 2023-05-22 03:41:01 --> Security Class Initialized
INFO - 2023-05-22 03:41:01 --> Security Class Initialized
INFO - 2023-05-22 03:41:01 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:01 --> Input Class Initialized
INFO - 2023-05-22 03:41:01 --> Input Class Initialized
INFO - 2023-05-22 03:41:01 --> Input Class Initialized
INFO - 2023-05-22 03:41:01 --> Language Class Initialized
INFO - 2023-05-22 03:41:01 --> Language Class Initialized
INFO - 2023-05-22 03:41:01 --> Language Class Initialized
INFO - 2023-05-22 03:41:01 --> Loader Class Initialized
INFO - 2023-05-22 03:41:01 --> Loader Class Initialized
INFO - 2023-05-22 03:41:01 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:01 --> Controller Class Initialized
INFO - 2023-05-22 03:41:01 --> Loader Class Initialized
DEBUG - 2023-05-22 03:41:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:01 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:01 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:01 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:01 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:01 --> Final output sent to browser
INFO - 2023-05-22 03:41:01 --> Final output sent to browser
INFO - 2023-05-22 03:41:01 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:01 --> Total execution time: 0.2688
DEBUG - 2023-05-22 03:41:01 --> Total execution time: 0.2682
DEBUG - 2023-05-22 03:41:01 --> Total execution time: 0.2682
INFO - 2023-05-22 03:41:01 --> Config Class Initialized
INFO - 2023-05-22 03:41:01 --> Config Class Initialized
INFO - 2023-05-22 03:41:01 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:01 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:01 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:01 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:01 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:01 --> URI Class Initialized
INFO - 2023-05-22 03:41:01 --> URI Class Initialized
INFO - 2023-05-22 03:41:01 --> Router Class Initialized
INFO - 2023-05-22 03:41:01 --> Router Class Initialized
INFO - 2023-05-22 03:41:01 --> Output Class Initialized
INFO - 2023-05-22 03:41:01 --> Output Class Initialized
INFO - 2023-05-22 03:41:01 --> Security Class Initialized
INFO - 2023-05-22 03:41:01 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:01 --> Input Class Initialized
INFO - 2023-05-22 03:41:01 --> Input Class Initialized
INFO - 2023-05-22 03:41:01 --> Language Class Initialized
INFO - 2023-05-22 03:41:01 --> Language Class Initialized
INFO - 2023-05-22 03:41:01 --> Loader Class Initialized
INFO - 2023-05-22 03:41:01 --> Loader Class Initialized
INFO - 2023-05-22 03:41:01 --> Controller Class Initialized
INFO - 2023-05-22 03:41:01 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:41:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:01 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:01 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:01 --> Final output sent to browser
INFO - 2023-05-22 03:41:01 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:01 --> Total execution time: 0.2089
DEBUG - 2023-05-22 03:41:01 --> Total execution time: 0.2098
INFO - 2023-05-22 03:41:01 --> Config Class Initialized
INFO - 2023-05-22 03:41:01 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:01 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:01 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:01 --> URI Class Initialized
INFO - 2023-05-22 03:41:01 --> Router Class Initialized
INFO - 2023-05-22 03:41:01 --> Output Class Initialized
INFO - 2023-05-22 03:41:01 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:02 --> Input Class Initialized
INFO - 2023-05-22 03:41:02 --> Language Class Initialized
INFO - 2023-05-22 03:41:02 --> Loader Class Initialized
INFO - 2023-05-22 03:41:02 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:02 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:02 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:02 --> Config Class Initialized
INFO - 2023-05-22 03:41:02 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:02 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:02 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:02 --> URI Class Initialized
INFO - 2023-05-22 03:41:02 --> Router Class Initialized
INFO - 2023-05-22 03:41:02 --> Output Class Initialized
INFO - 2023-05-22 03:41:02 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:02 --> Input Class Initialized
INFO - 2023-05-22 03:41:02 --> Language Class Initialized
INFO - 2023-05-22 03:41:02 --> Loader Class Initialized
INFO - 2023-05-22 03:41:02 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:02 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:02 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:23 --> Config Class Initialized
INFO - 2023-05-22 03:41:23 --> Config Class Initialized
INFO - 2023-05-22 03:41:23 --> Config Class Initialized
INFO - 2023-05-22 03:41:23 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:23 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:23 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:23 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:23 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:23 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:23 --> URI Class Initialized
INFO - 2023-05-22 03:41:23 --> URI Class Initialized
INFO - 2023-05-22 03:41:23 --> URI Class Initialized
INFO - 2023-05-22 03:41:23 --> Router Class Initialized
INFO - 2023-05-22 03:41:23 --> Router Class Initialized
INFO - 2023-05-22 03:41:23 --> Router Class Initialized
INFO - 2023-05-22 03:41:23 --> Output Class Initialized
INFO - 2023-05-22 03:41:23 --> Output Class Initialized
INFO - 2023-05-22 03:41:23 --> Output Class Initialized
INFO - 2023-05-22 03:41:23 --> Security Class Initialized
INFO - 2023-05-22 03:41:23 --> Security Class Initialized
INFO - 2023-05-22 03:41:23 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:23 --> Input Class Initialized
INFO - 2023-05-22 03:41:23 --> Input Class Initialized
INFO - 2023-05-22 03:41:23 --> Input Class Initialized
INFO - 2023-05-22 03:41:23 --> Language Class Initialized
INFO - 2023-05-22 03:41:23 --> Language Class Initialized
INFO - 2023-05-22 03:41:23 --> Language Class Initialized
INFO - 2023-05-22 03:41:23 --> Loader Class Initialized
INFO - 2023-05-22 03:41:23 --> Loader Class Initialized
INFO - 2023-05-22 03:41:23 --> Controller Class Initialized
INFO - 2023-05-22 03:41:23 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:41:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:23 --> Loader Class Initialized
INFO - 2023-05-22 03:41:23 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:23 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:23 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:23 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:23 --> Final output sent to browser
INFO - 2023-05-22 03:41:23 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:23 --> Total execution time: 0.3164
DEBUG - 2023-05-22 03:41:23 --> Total execution time: 0.3157
INFO - 2023-05-22 03:41:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:23 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:23 --> Total execution time: 0.3508
INFO - 2023-05-22 03:41:23 --> Config Class Initialized
INFO - 2023-05-22 03:41:23 --> Config Class Initialized
INFO - 2023-05-22 03:41:23 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:23 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:23 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:23 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:23 --> URI Class Initialized
INFO - 2023-05-22 03:41:23 --> URI Class Initialized
INFO - 2023-05-22 03:41:23 --> Config Class Initialized
INFO - 2023-05-22 03:41:23 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:23 --> Router Class Initialized
INFO - 2023-05-22 03:41:23 --> Router Class Initialized
INFO - 2023-05-22 03:41:23 --> Output Class Initialized
INFO - 2023-05-22 03:41:23 --> Output Class Initialized
INFO - 2023-05-22 03:41:23 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:23 --> Security Class Initialized
INFO - 2023-05-22 03:41:23 --> Utf8 Class Initialized
DEBUG - 2023-05-22 03:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:23 --> URI Class Initialized
INFO - 2023-05-22 03:41:23 --> Input Class Initialized
INFO - 2023-05-22 03:41:23 --> Input Class Initialized
INFO - 2023-05-22 03:41:23 --> Language Class Initialized
INFO - 2023-05-22 03:41:23 --> Language Class Initialized
INFO - 2023-05-22 03:41:23 --> Router Class Initialized
INFO - 2023-05-22 03:41:24 --> Loader Class Initialized
INFO - 2023-05-22 03:41:24 --> Loader Class Initialized
INFO - 2023-05-22 03:41:24 --> Output Class Initialized
INFO - 2023-05-22 03:41:24 --> Controller Class Initialized
INFO - 2023-05-22 03:41:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:24 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:24 --> Input Class Initialized
INFO - 2023-05-22 03:41:24 --> Language Class Initialized
INFO - 2023-05-22 03:41:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:24 --> Loader Class Initialized
INFO - 2023-05-22 03:41:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:24 --> Final output sent to browser
INFO - 2023-05-22 03:41:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:24 --> Total execution time: 0.3130
DEBUG - 2023-05-22 03:41:24 --> Total execution time: 0.3124
INFO - 2023-05-22 03:41:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:24 --> Config Class Initialized
INFO - 2023-05-22 03:41:24 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:24 --> Total execution time: 0.3647
DEBUG - 2023-05-22 03:41:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:24 --> URI Class Initialized
INFO - 2023-05-22 03:41:24 --> Router Class Initialized
INFO - 2023-05-22 03:41:24 --> Output Class Initialized
INFO - 2023-05-22 03:41:24 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:24 --> Input Class Initialized
INFO - 2023-05-22 03:41:24 --> Language Class Initialized
INFO - 2023-05-22 03:41:24 --> Loader Class Initialized
INFO - 2023-05-22 03:41:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:24 --> Config Class Initialized
INFO - 2023-05-22 03:41:24 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:24 --> URI Class Initialized
INFO - 2023-05-22 03:41:24 --> Router Class Initialized
INFO - 2023-05-22 03:41:24 --> Output Class Initialized
INFO - 2023-05-22 03:41:24 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:24 --> Input Class Initialized
INFO - 2023-05-22 03:41:24 --> Language Class Initialized
INFO - 2023-05-22 03:41:24 --> Loader Class Initialized
INFO - 2023-05-22 03:41:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:33 --> Config Class Initialized
INFO - 2023-05-22 03:41:33 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:33 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:33 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:33 --> URI Class Initialized
INFO - 2023-05-22 03:41:33 --> Router Class Initialized
INFO - 2023-05-22 03:41:33 --> Output Class Initialized
INFO - 2023-05-22 03:41:33 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:33 --> Input Class Initialized
INFO - 2023-05-22 03:41:33 --> Language Class Initialized
INFO - 2023-05-22 03:41:33 --> Loader Class Initialized
INFO - 2023-05-22 03:41:33 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:33 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:33 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:33 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:33 --> Total execution time: 0.1904
INFO - 2023-05-22 03:41:34 --> Config Class Initialized
INFO - 2023-05-22 03:41:34 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:34 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:34 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:34 --> URI Class Initialized
INFO - 2023-05-22 03:41:34 --> Router Class Initialized
INFO - 2023-05-22 03:41:34 --> Output Class Initialized
INFO - 2023-05-22 03:41:34 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:34 --> Input Class Initialized
INFO - 2023-05-22 03:41:34 --> Language Class Initialized
INFO - 2023-05-22 03:41:34 --> Loader Class Initialized
INFO - 2023-05-22 03:41:34 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:34 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:34 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:34 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:34 --> Total execution time: 0.2142
INFO - 2023-05-22 03:41:42 --> Config Class Initialized
INFO - 2023-05-22 03:41:42 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:42 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:42 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:42 --> URI Class Initialized
INFO - 2023-05-22 03:41:42 --> Router Class Initialized
INFO - 2023-05-22 03:41:42 --> Output Class Initialized
INFO - 2023-05-22 03:41:42 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:42 --> Input Class Initialized
INFO - 2023-05-22 03:41:42 --> Language Class Initialized
INFO - 2023-05-22 03:41:42 --> Loader Class Initialized
INFO - 2023-05-22 03:41:42 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:42 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:42 --> Total execution time: 0.1579
INFO - 2023-05-22 03:41:42 --> Config Class Initialized
INFO - 2023-05-22 03:41:42 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:42 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:42 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:42 --> URI Class Initialized
INFO - 2023-05-22 03:41:42 --> Router Class Initialized
INFO - 2023-05-22 03:41:42 --> Output Class Initialized
INFO - 2023-05-22 03:41:42 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:42 --> Input Class Initialized
INFO - 2023-05-22 03:41:43 --> Language Class Initialized
INFO - 2023-05-22 03:41:43 --> Loader Class Initialized
INFO - 2023-05-22 03:41:43 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:43 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:43 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:43 --> Total execution time: 0.2220
INFO - 2023-05-22 03:41:47 --> Config Class Initialized
INFO - 2023-05-22 03:41:47 --> Config Class Initialized
INFO - 2023-05-22 03:41:47 --> Config Class Initialized
INFO - 2023-05-22 03:41:47 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:47 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:47 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:47 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:47 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:47 --> URI Class Initialized
INFO - 2023-05-22 03:41:47 --> URI Class Initialized
INFO - 2023-05-22 03:41:47 --> URI Class Initialized
INFO - 2023-05-22 03:41:47 --> Router Class Initialized
INFO - 2023-05-22 03:41:47 --> Router Class Initialized
INFO - 2023-05-22 03:41:47 --> Router Class Initialized
INFO - 2023-05-22 03:41:47 --> Output Class Initialized
INFO - 2023-05-22 03:41:47 --> Output Class Initialized
INFO - 2023-05-22 03:41:47 --> Output Class Initialized
INFO - 2023-05-22 03:41:47 --> Security Class Initialized
INFO - 2023-05-22 03:41:47 --> Security Class Initialized
INFO - 2023-05-22 03:41:47 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:47 --> Input Class Initialized
INFO - 2023-05-22 03:41:47 --> Input Class Initialized
INFO - 2023-05-22 03:41:47 --> Input Class Initialized
INFO - 2023-05-22 03:41:47 --> Language Class Initialized
INFO - 2023-05-22 03:41:47 --> Language Class Initialized
INFO - 2023-05-22 03:41:47 --> Language Class Initialized
INFO - 2023-05-22 03:41:47 --> Loader Class Initialized
INFO - 2023-05-22 03:41:47 --> Loader Class Initialized
INFO - 2023-05-22 03:41:47 --> Controller Class Initialized
INFO - 2023-05-22 03:41:47 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:41:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:47 --> Loader Class Initialized
INFO - 2023-05-22 03:41:47 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:47 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:47 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:47 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:47 --> Final output sent to browser
INFO - 2023-05-22 03:41:47 --> Final output sent to browser
INFO - 2023-05-22 03:41:47 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:47 --> Total execution time: 0.1748
DEBUG - 2023-05-22 03:41:47 --> Total execution time: 0.1756
DEBUG - 2023-05-22 03:41:47 --> Total execution time: 0.1756
INFO - 2023-05-22 03:41:47 --> Config Class Initialized
INFO - 2023-05-22 03:41:47 --> Config Class Initialized
INFO - 2023-05-22 03:41:47 --> Config Class Initialized
INFO - 2023-05-22 03:41:47 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:47 --> Hooks Class Initialized
INFO - 2023-05-22 03:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:47 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:47 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:47 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:47 --> URI Class Initialized
INFO - 2023-05-22 03:41:47 --> URI Class Initialized
INFO - 2023-05-22 03:41:47 --> URI Class Initialized
INFO - 2023-05-22 03:41:47 --> Router Class Initialized
INFO - 2023-05-22 03:41:47 --> Router Class Initialized
INFO - 2023-05-22 03:41:47 --> Router Class Initialized
INFO - 2023-05-22 03:41:47 --> Output Class Initialized
INFO - 2023-05-22 03:41:47 --> Output Class Initialized
INFO - 2023-05-22 03:41:47 --> Output Class Initialized
INFO - 2023-05-22 03:41:47 --> Security Class Initialized
INFO - 2023-05-22 03:41:47 --> Security Class Initialized
INFO - 2023-05-22 03:41:47 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:47 --> Input Class Initialized
INFO - 2023-05-22 03:41:47 --> Input Class Initialized
INFO - 2023-05-22 03:41:47 --> Input Class Initialized
INFO - 2023-05-22 03:41:47 --> Language Class Initialized
INFO - 2023-05-22 03:41:47 --> Language Class Initialized
INFO - 2023-05-22 03:41:47 --> Language Class Initialized
INFO - 2023-05-22 03:41:47 --> Loader Class Initialized
INFO - 2023-05-22 03:41:47 --> Loader Class Initialized
INFO - 2023-05-22 03:41:47 --> Controller Class Initialized
INFO - 2023-05-22 03:41:47 --> Controller Class Initialized
INFO - 2023-05-22 03:41:47 --> Loader Class Initialized
DEBUG - 2023-05-22 03:41:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:41:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:47 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:47 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:47 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:47 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:47 --> Final output sent to browser
INFO - 2023-05-22 03:41:47 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:47 --> Total execution time: 0.1992
DEBUG - 2023-05-22 03:41:47 --> Total execution time: 0.2041
INFO - 2023-05-22 03:41:47 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:47 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:47 --> Total execution time: 0.2744
INFO - 2023-05-22 03:41:47 --> Config Class Initialized
INFO - 2023-05-22 03:41:47 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:47 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:47 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:47 --> URI Class Initialized
INFO - 2023-05-22 03:41:47 --> Router Class Initialized
INFO - 2023-05-22 03:41:47 --> Output Class Initialized
INFO - 2023-05-22 03:41:47 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:47 --> Input Class Initialized
INFO - 2023-05-22 03:41:47 --> Language Class Initialized
INFO - 2023-05-22 03:41:47 --> Loader Class Initialized
INFO - 2023-05-22 03:41:47 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:47 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:48 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:48 --> Config Class Initialized
INFO - 2023-05-22 03:41:48 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:48 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:48 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:48 --> URI Class Initialized
INFO - 2023-05-22 03:41:48 --> Router Class Initialized
INFO - 2023-05-22 03:41:48 --> Output Class Initialized
INFO - 2023-05-22 03:41:48 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:48 --> Input Class Initialized
INFO - 2023-05-22 03:41:48 --> Language Class Initialized
INFO - 2023-05-22 03:41:48 --> Loader Class Initialized
INFO - 2023-05-22 03:41:48 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:48 --> Config Class Initialized
INFO - 2023-05-22 03:41:48 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:48 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:48 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:48 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:48 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:48 --> URI Class Initialized
INFO - 2023-05-22 03:41:48 --> Router Class Initialized
INFO - 2023-05-22 03:41:48 --> Output Class Initialized
INFO - 2023-05-22 03:41:48 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:48 --> Input Class Initialized
INFO - 2023-05-22 03:41:48 --> Language Class Initialized
INFO - 2023-05-22 03:41:48 --> Loader Class Initialized
INFO - 2023-05-22 03:41:48 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:48 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:48 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:48 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:48 --> Total execution time: 0.3293
INFO - 2023-05-22 03:41:50 --> Config Class Initialized
INFO - 2023-05-22 03:41:50 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:41:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:41:50 --> Utf8 Class Initialized
INFO - 2023-05-22 03:41:50 --> URI Class Initialized
INFO - 2023-05-22 03:41:50 --> Router Class Initialized
INFO - 2023-05-22 03:41:51 --> Output Class Initialized
INFO - 2023-05-22 03:41:51 --> Security Class Initialized
DEBUG - 2023-05-22 03:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:41:51 --> Input Class Initialized
INFO - 2023-05-22 03:41:51 --> Language Class Initialized
INFO - 2023-05-22 03:41:51 --> Loader Class Initialized
INFO - 2023-05-22 03:41:51 --> Controller Class Initialized
DEBUG - 2023-05-22 03:41:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:41:51 --> Database Driver Class Initialized
INFO - 2023-05-22 03:41:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:41:51 --> Final output sent to browser
DEBUG - 2023-05-22 03:41:51 --> Total execution time: 0.2477
INFO - 2023-05-22 03:42:02 --> Config Class Initialized
INFO - 2023-05-22 03:42:02 --> Config Class Initialized
INFO - 2023-05-22 03:42:02 --> Config Class Initialized
INFO - 2023-05-22 03:42:02 --> Hooks Class Initialized
INFO - 2023-05-22 03:42:02 --> Hooks Class Initialized
INFO - 2023-05-22 03:42:02 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:42:02 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:42:02 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:02 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:02 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:02 --> URI Class Initialized
INFO - 2023-05-22 03:42:02 --> URI Class Initialized
INFO - 2023-05-22 03:42:02 --> URI Class Initialized
INFO - 2023-05-22 03:42:02 --> Router Class Initialized
INFO - 2023-05-22 03:42:02 --> Router Class Initialized
INFO - 2023-05-22 03:42:02 --> Router Class Initialized
INFO - 2023-05-22 03:42:02 --> Output Class Initialized
INFO - 2023-05-22 03:42:02 --> Output Class Initialized
INFO - 2023-05-22 03:42:02 --> Output Class Initialized
INFO - 2023-05-22 03:42:02 --> Security Class Initialized
INFO - 2023-05-22 03:42:02 --> Security Class Initialized
INFO - 2023-05-22 03:42:02 --> Security Class Initialized
DEBUG - 2023-05-22 03:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:42:02 --> Input Class Initialized
INFO - 2023-05-22 03:42:02 --> Input Class Initialized
INFO - 2023-05-22 03:42:02 --> Input Class Initialized
INFO - 2023-05-22 03:42:02 --> Language Class Initialized
INFO - 2023-05-22 03:42:02 --> Language Class Initialized
INFO - 2023-05-22 03:42:02 --> Language Class Initialized
INFO - 2023-05-22 03:42:02 --> Loader Class Initialized
INFO - 2023-05-22 03:42:02 --> Loader Class Initialized
INFO - 2023-05-22 03:42:02 --> Controller Class Initialized
INFO - 2023-05-22 03:42:02 --> Controller Class Initialized
DEBUG - 2023-05-22 03:42:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:42:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:42:02 --> Loader Class Initialized
INFO - 2023-05-22 03:42:02 --> Controller Class Initialized
DEBUG - 2023-05-22 03:42:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:42:02 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:02 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:02 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:02 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:02 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:02 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:02 --> Final output sent to browser
INFO - 2023-05-22 03:42:02 --> Final output sent to browser
INFO - 2023-05-22 03:42:02 --> Final output sent to browser
DEBUG - 2023-05-22 03:42:02 --> Total execution time: 0.1808
DEBUG - 2023-05-22 03:42:02 --> Total execution time: 0.1810
DEBUG - 2023-05-22 03:42:02 --> Total execution time: 0.1816
INFO - 2023-05-22 03:42:02 --> Config Class Initialized
INFO - 2023-05-22 03:42:02 --> Config Class Initialized
INFO - 2023-05-22 03:42:02 --> Config Class Initialized
INFO - 2023-05-22 03:42:02 --> Hooks Class Initialized
INFO - 2023-05-22 03:42:02 --> Hooks Class Initialized
INFO - 2023-05-22 03:42:02 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 03:42:02 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:42:02 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:02 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:02 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:02 --> URI Class Initialized
INFO - 2023-05-22 03:42:02 --> URI Class Initialized
INFO - 2023-05-22 03:42:02 --> URI Class Initialized
INFO - 2023-05-22 03:42:02 --> Router Class Initialized
INFO - 2023-05-22 03:42:02 --> Router Class Initialized
INFO - 2023-05-22 03:42:02 --> Router Class Initialized
INFO - 2023-05-22 03:42:02 --> Output Class Initialized
INFO - 2023-05-22 03:42:02 --> Output Class Initialized
INFO - 2023-05-22 03:42:02 --> Output Class Initialized
INFO - 2023-05-22 03:42:02 --> Security Class Initialized
INFO - 2023-05-22 03:42:02 --> Security Class Initialized
INFO - 2023-05-22 03:42:02 --> Security Class Initialized
DEBUG - 2023-05-22 03:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 03:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:42:02 --> Input Class Initialized
INFO - 2023-05-22 03:42:02 --> Input Class Initialized
INFO - 2023-05-22 03:42:02 --> Input Class Initialized
INFO - 2023-05-22 03:42:02 --> Language Class Initialized
INFO - 2023-05-22 03:42:02 --> Language Class Initialized
INFO - 2023-05-22 03:42:02 --> Language Class Initialized
INFO - 2023-05-22 03:42:02 --> Loader Class Initialized
INFO - 2023-05-22 03:42:02 --> Loader Class Initialized
INFO - 2023-05-22 03:42:02 --> Controller Class Initialized
INFO - 2023-05-22 03:42:02 --> Controller Class Initialized
INFO - 2023-05-22 03:42:02 --> Loader Class Initialized
DEBUG - 2023-05-22 03:42:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 03:42:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:42:02 --> Controller Class Initialized
DEBUG - 2023-05-22 03:42:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:42:02 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:02 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:02 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:02 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:02 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:02 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:02 --> Final output sent to browser
INFO - 2023-05-22 03:42:02 --> Final output sent to browser
DEBUG - 2023-05-22 03:42:02 --> Total execution time: 0.2376
DEBUG - 2023-05-22 03:42:02 --> Total execution time: 0.2388
INFO - 2023-05-22 03:42:02 --> Final output sent to browser
DEBUG - 2023-05-22 03:42:02 --> Total execution time: 0.2711
INFO - 2023-05-22 03:42:02 --> Config Class Initialized
INFO - 2023-05-22 03:42:02 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:42:02 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:42:02 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:02 --> URI Class Initialized
INFO - 2023-05-22 03:42:02 --> Router Class Initialized
INFO - 2023-05-22 03:42:02 --> Output Class Initialized
INFO - 2023-05-22 03:42:02 --> Security Class Initialized
DEBUG - 2023-05-22 03:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:42:03 --> Input Class Initialized
INFO - 2023-05-22 03:42:03 --> Language Class Initialized
INFO - 2023-05-22 03:42:03 --> Loader Class Initialized
INFO - 2023-05-22 03:42:03 --> Controller Class Initialized
DEBUG - 2023-05-22 03:42:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:42:03 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:03 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:04 --> Config Class Initialized
INFO - 2023-05-22 03:42:04 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:42:04 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:42:04 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:04 --> URI Class Initialized
INFO - 2023-05-22 03:42:04 --> Router Class Initialized
INFO - 2023-05-22 03:42:04 --> Output Class Initialized
INFO - 2023-05-22 03:42:04 --> Security Class Initialized
DEBUG - 2023-05-22 03:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:42:04 --> Input Class Initialized
INFO - 2023-05-22 03:42:04 --> Language Class Initialized
INFO - 2023-05-22 03:42:04 --> Loader Class Initialized
INFO - 2023-05-22 03:42:04 --> Controller Class Initialized
DEBUG - 2023-05-22 03:42:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:42:04 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:04 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:12 --> Config Class Initialized
INFO - 2023-05-22 03:42:12 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:42:12 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:42:12 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:12 --> URI Class Initialized
INFO - 2023-05-22 03:42:12 --> Router Class Initialized
INFO - 2023-05-22 03:42:12 --> Output Class Initialized
INFO - 2023-05-22 03:42:13 --> Security Class Initialized
DEBUG - 2023-05-22 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:42:13 --> Input Class Initialized
INFO - 2023-05-22 03:42:13 --> Language Class Initialized
INFO - 2023-05-22 03:42:13 --> Loader Class Initialized
INFO - 2023-05-22 03:42:13 --> Controller Class Initialized
DEBUG - 2023-05-22 03:42:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:42:13 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:13 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:42:13 --> Config Class Initialized
INFO - 2023-05-22 03:42:13 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:42:13 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:42:13 --> Utf8 Class Initialized
INFO - 2023-05-22 03:42:13 --> URI Class Initialized
INFO - 2023-05-22 03:42:13 --> Router Class Initialized
INFO - 2023-05-22 03:42:13 --> Output Class Initialized
INFO - 2023-05-22 03:42:13 --> Security Class Initialized
DEBUG - 2023-05-22 03:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:42:13 --> Input Class Initialized
INFO - 2023-05-22 03:42:13 --> Language Class Initialized
INFO - 2023-05-22 03:42:13 --> Loader Class Initialized
INFO - 2023-05-22 03:42:13 --> Controller Class Initialized
DEBUG - 2023-05-22 03:42:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:42:13 --> Database Driver Class Initialized
INFO - 2023-05-22 03:42:13 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:13 --> Config Class Initialized
INFO - 2023-05-22 03:43:13 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:13 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:13 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:13 --> URI Class Initialized
INFO - 2023-05-22 03:43:13 --> Router Class Initialized
INFO - 2023-05-22 03:43:13 --> Output Class Initialized
INFO - 2023-05-22 03:43:13 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:13 --> Input Class Initialized
INFO - 2023-05-22 03:43:13 --> Language Class Initialized
INFO - 2023-05-22 03:43:13 --> Loader Class Initialized
INFO - 2023-05-22 03:43:13 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:13 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:13 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:13 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:13 --> Total execution time: 0.1750
INFO - 2023-05-22 03:43:13 --> Config Class Initialized
INFO - 2023-05-22 03:43:13 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:13 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:13 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:13 --> URI Class Initialized
INFO - 2023-05-22 03:43:13 --> Router Class Initialized
INFO - 2023-05-22 03:43:13 --> Output Class Initialized
INFO - 2023-05-22 03:43:13 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:13 --> Input Class Initialized
INFO - 2023-05-22 03:43:13 --> Language Class Initialized
INFO - 2023-05-22 03:43:13 --> Loader Class Initialized
INFO - 2023-05-22 03:43:13 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:13 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:13 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:13 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:13 --> Total execution time: 0.2287
INFO - 2023-05-22 03:43:23 --> Config Class Initialized
INFO - 2023-05-22 03:43:23 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:23 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:23 --> URI Class Initialized
INFO - 2023-05-22 03:43:23 --> Router Class Initialized
INFO - 2023-05-22 03:43:23 --> Output Class Initialized
INFO - 2023-05-22 03:43:23 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:23 --> Input Class Initialized
INFO - 2023-05-22 03:43:23 --> Language Class Initialized
INFO - 2023-05-22 03:43:23 --> Loader Class Initialized
INFO - 2023-05-22 03:43:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:24 --> Total execution time: 0.1703
INFO - 2023-05-22 03:43:24 --> Config Class Initialized
INFO - 2023-05-22 03:43:24 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:24 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:24 --> URI Class Initialized
INFO - 2023-05-22 03:43:24 --> Router Class Initialized
INFO - 2023-05-22 03:43:24 --> Output Class Initialized
INFO - 2023-05-22 03:43:24 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:24 --> Input Class Initialized
INFO - 2023-05-22 03:43:24 --> Language Class Initialized
INFO - 2023-05-22 03:43:24 --> Loader Class Initialized
INFO - 2023-05-22 03:43:24 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:24 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:24 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:24 --> Total execution time: 0.2195
INFO - 2023-05-22 03:43:25 --> Config Class Initialized
INFO - 2023-05-22 03:43:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:25 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:25 --> URI Class Initialized
INFO - 2023-05-22 03:43:25 --> Router Class Initialized
INFO - 2023-05-22 03:43:25 --> Output Class Initialized
INFO - 2023-05-22 03:43:25 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:25 --> Input Class Initialized
INFO - 2023-05-22 03:43:25 --> Language Class Initialized
INFO - 2023-05-22 03:43:25 --> Loader Class Initialized
INFO - 2023-05-22 03:43:25 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:25 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:25 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:25 --> Total execution time: 0.1474
INFO - 2023-05-22 03:43:25 --> Config Class Initialized
INFO - 2023-05-22 03:43:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:25 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:25 --> URI Class Initialized
INFO - 2023-05-22 03:43:25 --> Router Class Initialized
INFO - 2023-05-22 03:43:25 --> Output Class Initialized
INFO - 2023-05-22 03:43:25 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:25 --> Input Class Initialized
INFO - 2023-05-22 03:43:25 --> Language Class Initialized
INFO - 2023-05-22 03:43:25 --> Loader Class Initialized
INFO - 2023-05-22 03:43:25 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:25 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:26 --> Config Class Initialized
INFO - 2023-05-22 03:43:26 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:26 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:26 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:26 --> URI Class Initialized
INFO - 2023-05-22 03:43:26 --> Router Class Initialized
INFO - 2023-05-22 03:43:26 --> Output Class Initialized
INFO - 2023-05-22 03:43:26 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:26 --> Input Class Initialized
INFO - 2023-05-22 03:43:26 --> Language Class Initialized
INFO - 2023-05-22 03:43:26 --> Loader Class Initialized
INFO - 2023-05-22 03:43:26 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:26 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:26 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:27 --> Config Class Initialized
INFO - 2023-05-22 03:43:27 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:27 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:27 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:27 --> URI Class Initialized
INFO - 2023-05-22 03:43:27 --> Router Class Initialized
INFO - 2023-05-22 03:43:27 --> Output Class Initialized
INFO - 2023-05-22 03:43:27 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:27 --> Input Class Initialized
INFO - 2023-05-22 03:43:27 --> Language Class Initialized
INFO - 2023-05-22 03:43:27 --> Loader Class Initialized
INFO - 2023-05-22 03:43:27 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:27 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:27 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:27 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:27 --> Total execution time: 2.2649
INFO - 2023-05-22 03:43:28 --> Config Class Initialized
INFO - 2023-05-22 03:43:28 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:28 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:28 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:28 --> URI Class Initialized
INFO - 2023-05-22 03:43:28 --> Router Class Initialized
INFO - 2023-05-22 03:43:28 --> Output Class Initialized
INFO - 2023-05-22 03:43:28 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:28 --> Input Class Initialized
INFO - 2023-05-22 03:43:28 --> Language Class Initialized
INFO - 2023-05-22 03:43:28 --> Loader Class Initialized
INFO - 2023-05-22 03:43:28 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:28 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:28 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:28 --> Total execution time: 2.2597
INFO - 2023-05-22 03:43:29 --> Config Class Initialized
INFO - 2023-05-22 03:43:29 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:29 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:29 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:29 --> URI Class Initialized
INFO - 2023-05-22 03:43:29 --> Router Class Initialized
INFO - 2023-05-22 03:43:29 --> Output Class Initialized
INFO - 2023-05-22 03:43:29 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:29 --> Input Class Initialized
INFO - 2023-05-22 03:43:29 --> Language Class Initialized
INFO - 2023-05-22 03:43:29 --> Loader Class Initialized
INFO - 2023-05-22 03:43:29 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:29 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:29 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:29 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:29 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:29 --> Total execution time: 2.2094
INFO - 2023-05-22 03:43:30 --> Config Class Initialized
INFO - 2023-05-22 03:43:30 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:30 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:30 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:30 --> URI Class Initialized
INFO - 2023-05-22 03:43:30 --> Router Class Initialized
INFO - 2023-05-22 03:43:30 --> Output Class Initialized
INFO - 2023-05-22 03:43:30 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:30 --> Input Class Initialized
INFO - 2023-05-22 03:43:30 --> Language Class Initialized
INFO - 2023-05-22 03:43:30 --> Loader Class Initialized
INFO - 2023-05-22 03:43:30 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:30 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:30 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:30 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:30 --> Total execution time: 2.2487
INFO - 2023-05-22 03:43:31 --> Config Class Initialized
INFO - 2023-05-22 03:43:31 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:31 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:31 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:31 --> URI Class Initialized
INFO - 2023-05-22 03:43:31 --> Router Class Initialized
INFO - 2023-05-22 03:43:31 --> Output Class Initialized
INFO - 2023-05-22 03:43:31 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:31 --> Input Class Initialized
INFO - 2023-05-22 03:43:31 --> Language Class Initialized
INFO - 2023-05-22 03:43:31 --> Loader Class Initialized
INFO - 2023-05-22 03:43:31 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:31 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:31 --> Total execution time: 2.2004
INFO - 2023-05-22 03:43:31 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:31 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:31 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:31 --> Total execution time: 0.2640
INFO - 2023-05-22 03:43:31 --> Config Class Initialized
INFO - 2023-05-22 03:43:31 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:31 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:31 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:31 --> URI Class Initialized
INFO - 2023-05-22 03:43:31 --> Router Class Initialized
INFO - 2023-05-22 03:43:31 --> Output Class Initialized
INFO - 2023-05-22 03:43:31 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:31 --> Input Class Initialized
INFO - 2023-05-22 03:43:31 --> Language Class Initialized
INFO - 2023-05-22 03:43:31 --> Loader Class Initialized
INFO - 2023-05-22 03:43:31 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:31 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:31 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:32 --> Config Class Initialized
INFO - 2023-05-22 03:43:32 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:32 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:32 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:32 --> URI Class Initialized
INFO - 2023-05-22 03:43:32 --> Router Class Initialized
INFO - 2023-05-22 03:43:32 --> Output Class Initialized
INFO - 2023-05-22 03:43:32 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:32 --> Input Class Initialized
INFO - 2023-05-22 03:43:32 --> Language Class Initialized
INFO - 2023-05-22 03:43:32 --> Loader Class Initialized
INFO - 2023-05-22 03:43:32 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:32 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:32 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:32 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:32 --> Total execution time: 2.2944
INFO - 2023-05-22 03:43:33 --> Config Class Initialized
INFO - 2023-05-22 03:43:33 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:43:33 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:43:33 --> Utf8 Class Initialized
INFO - 2023-05-22 03:43:33 --> URI Class Initialized
INFO - 2023-05-22 03:43:33 --> Router Class Initialized
INFO - 2023-05-22 03:43:33 --> Output Class Initialized
INFO - 2023-05-22 03:43:33 --> Security Class Initialized
DEBUG - 2023-05-22 03:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:43:33 --> Input Class Initialized
INFO - 2023-05-22 03:43:33 --> Language Class Initialized
INFO - 2023-05-22 03:43:33 --> Loader Class Initialized
INFO - 2023-05-22 03:43:33 --> Controller Class Initialized
DEBUG - 2023-05-22 03:43:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:43:33 --> Database Driver Class Initialized
INFO - 2023-05-22 03:43:33 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:43:33 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:33 --> Total execution time: 0.1823
INFO - 2023-05-22 03:43:34 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:34 --> Total execution time: 2.3656
INFO - 2023-05-22 03:43:34 --> Final output sent to browser
DEBUG - 2023-05-22 03:43:34 --> Total execution time: 2.2476
INFO - 2023-05-22 03:46:53 --> Config Class Initialized
INFO - 2023-05-22 03:46:53 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:46:53 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:46:53 --> Utf8 Class Initialized
INFO - 2023-05-22 03:46:53 --> URI Class Initialized
INFO - 2023-05-22 03:46:53 --> Router Class Initialized
INFO - 2023-05-22 03:46:53 --> Output Class Initialized
INFO - 2023-05-22 03:46:53 --> Security Class Initialized
DEBUG - 2023-05-22 03:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:46:53 --> Input Class Initialized
INFO - 2023-05-22 03:46:53 --> Language Class Initialized
INFO - 2023-05-22 03:46:53 --> Loader Class Initialized
INFO - 2023-05-22 03:46:53 --> Controller Class Initialized
DEBUG - 2023-05-22 03:46:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:46:53 --> Database Driver Class Initialized
INFO - 2023-05-22 03:46:54 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:46:54 --> Final output sent to browser
DEBUG - 2023-05-22 03:46:54 --> Total execution time: 0.4332
INFO - 2023-05-22 03:46:54 --> Config Class Initialized
INFO - 2023-05-22 03:46:54 --> Hooks Class Initialized
DEBUG - 2023-05-22 03:46:54 --> UTF-8 Support Enabled
INFO - 2023-05-22 03:46:54 --> Utf8 Class Initialized
INFO - 2023-05-22 03:46:54 --> URI Class Initialized
INFO - 2023-05-22 03:46:54 --> Router Class Initialized
INFO - 2023-05-22 03:46:54 --> Output Class Initialized
INFO - 2023-05-22 03:46:54 --> Security Class Initialized
DEBUG - 2023-05-22 03:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 03:46:54 --> Input Class Initialized
INFO - 2023-05-22 03:46:54 --> Language Class Initialized
INFO - 2023-05-22 03:46:54 --> Loader Class Initialized
INFO - 2023-05-22 03:46:54 --> Controller Class Initialized
DEBUG - 2023-05-22 03:46:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 03:46:54 --> Database Driver Class Initialized
INFO - 2023-05-22 03:46:54 --> Model "Cluster_model" initialized
INFO - 2023-05-22 03:46:54 --> Final output sent to browser
DEBUG - 2023-05-22 03:46:54 --> Total execution time: 0.3147
INFO - 2023-05-22 05:33:22 --> Config Class Initialized
INFO - 2023-05-22 05:33:22 --> Hooks Class Initialized
DEBUG - 2023-05-22 05:33:22 --> UTF-8 Support Enabled
INFO - 2023-05-22 05:33:22 --> Utf8 Class Initialized
INFO - 2023-05-22 05:33:22 --> URI Class Initialized
INFO - 2023-05-22 05:33:22 --> Router Class Initialized
INFO - 2023-05-22 05:33:22 --> Output Class Initialized
INFO - 2023-05-22 05:33:22 --> Security Class Initialized
DEBUG - 2023-05-22 05:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 05:33:22 --> Input Class Initialized
INFO - 2023-05-22 05:33:22 --> Language Class Initialized
INFO - 2023-05-22 05:33:22 --> Loader Class Initialized
INFO - 2023-05-22 05:33:22 --> Controller Class Initialized
DEBUG - 2023-05-22 05:33:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 05:33:22 --> Database Driver Class Initialized
INFO - 2023-05-22 05:33:22 --> Model "Cluster_model" initialized
INFO - 2023-05-22 05:33:22 --> Final output sent to browser
DEBUG - 2023-05-22 05:33:22 --> Total execution time: 0.3421
INFO - 2023-05-22 05:33:23 --> Config Class Initialized
INFO - 2023-05-22 05:33:23 --> Hooks Class Initialized
DEBUG - 2023-05-22 05:33:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 05:33:23 --> Utf8 Class Initialized
INFO - 2023-05-22 05:33:23 --> URI Class Initialized
INFO - 2023-05-22 05:33:23 --> Router Class Initialized
INFO - 2023-05-22 05:33:23 --> Output Class Initialized
INFO - 2023-05-22 05:33:23 --> Security Class Initialized
DEBUG - 2023-05-22 05:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 05:33:23 --> Input Class Initialized
INFO - 2023-05-22 05:33:23 --> Language Class Initialized
INFO - 2023-05-22 05:33:23 --> Loader Class Initialized
INFO - 2023-05-22 05:33:23 --> Controller Class Initialized
DEBUG - 2023-05-22 05:33:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 05:33:23 --> Database Driver Class Initialized
INFO - 2023-05-22 05:33:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 05:33:23 --> Final output sent to browser
DEBUG - 2023-05-22 05:33:23 --> Total execution time: 0.2854
INFO - 2023-05-22 06:05:44 --> Config Class Initialized
INFO - 2023-05-22 06:05:44 --> Config Class Initialized
INFO - 2023-05-22 06:05:44 --> Config Class Initialized
INFO - 2023-05-22 06:05:44 --> Hooks Class Initialized
INFO - 2023-05-22 06:05:44 --> Hooks Class Initialized
INFO - 2023-05-22 06:05:44 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:05:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:05:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:05:44 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:05:44 --> Utf8 Class Initialized
INFO - 2023-05-22 06:05:44 --> Utf8 Class Initialized
INFO - 2023-05-22 06:05:44 --> Utf8 Class Initialized
INFO - 2023-05-22 06:05:44 --> URI Class Initialized
INFO - 2023-05-22 06:05:44 --> URI Class Initialized
INFO - 2023-05-22 06:05:44 --> URI Class Initialized
INFO - 2023-05-22 06:05:44 --> Router Class Initialized
INFO - 2023-05-22 06:05:44 --> Router Class Initialized
INFO - 2023-05-22 06:05:44 --> Router Class Initialized
INFO - 2023-05-22 06:05:44 --> Output Class Initialized
INFO - 2023-05-22 06:05:44 --> Output Class Initialized
INFO - 2023-05-22 06:05:44 --> Output Class Initialized
INFO - 2023-05-22 06:05:44 --> Security Class Initialized
INFO - 2023-05-22 06:05:44 --> Security Class Initialized
INFO - 2023-05-22 06:05:44 --> Security Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:05:44 --> Input Class Initialized
INFO - 2023-05-22 06:05:44 --> Input Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:05:44 --> Input Class Initialized
INFO - 2023-05-22 06:05:44 --> Config Class Initialized
INFO - 2023-05-22 06:05:44 --> Hooks Class Initialized
INFO - 2023-05-22 06:05:44 --> Language Class Initialized
INFO - 2023-05-22 06:05:44 --> Language Class Initialized
INFO - 2023-05-22 06:05:44 --> Language Class Initialized
DEBUG - 2023-05-22 06:05:44 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:05:44 --> Utf8 Class Initialized
INFO - 2023-05-22 06:05:44 --> Loader Class Initialized
INFO - 2023-05-22 06:05:44 --> Loader Class Initialized
INFO - 2023-05-22 06:05:44 --> URI Class Initialized
INFO - 2023-05-22 06:05:44 --> Controller Class Initialized
INFO - 2023-05-22 06:05:44 --> Controller Class Initialized
INFO - 2023-05-22 06:05:44 --> Loader Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:05:44 --> Router Class Initialized
INFO - 2023-05-22 06:05:44 --> Controller Class Initialized
INFO - 2023-05-22 06:05:44 --> Output Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:05:44 --> Security Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:44 --> Input Class Initialized
INFO - 2023-05-22 06:05:44 --> Language Class Initialized
INFO - 2023-05-22 06:05:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:05:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:44 --> Loader Class Initialized
INFO - 2023-05-22 06:05:44 --> Model "Login_model" initialized
INFO - 2023-05-22 06:05:44 --> Final output sent to browser
DEBUG - 2023-05-22 06:05:44 --> Total execution time: 0.3493
INFO - 2023-05-22 06:05:44 --> Controller Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:05:44 --> Final output sent to browser
INFO - 2023-05-22 06:05:44 --> Final output sent to browser
DEBUG - 2023-05-22 06:05:44 --> Total execution time: 0.3695
DEBUG - 2023-05-22 06:05:44 --> Total execution time: 0.3693
INFO - 2023-05-22 06:05:44 --> Config Class Initialized
INFO - 2023-05-22 06:05:44 --> Config Class Initialized
INFO - 2023-05-22 06:05:44 --> Config Class Initialized
INFO - 2023-05-22 06:05:44 --> Hooks Class Initialized
INFO - 2023-05-22 06:05:44 --> Hooks Class Initialized
INFO - 2023-05-22 06:05:44 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:05:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:05:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:05:44 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:44 --> Utf8 Class Initialized
INFO - 2023-05-22 06:05:44 --> Utf8 Class Initialized
INFO - 2023-05-22 06:05:44 --> Utf8 Class Initialized
INFO - 2023-05-22 06:05:44 --> URI Class Initialized
INFO - 2023-05-22 06:05:44 --> URI Class Initialized
INFO - 2023-05-22 06:05:44 --> URI Class Initialized
INFO - 2023-05-22 06:05:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:05:44 --> Router Class Initialized
INFO - 2023-05-22 06:05:44 --> Router Class Initialized
INFO - 2023-05-22 06:05:44 --> Router Class Initialized
INFO - 2023-05-22 06:05:44 --> Output Class Initialized
INFO - 2023-05-22 06:05:44 --> Output Class Initialized
INFO - 2023-05-22 06:05:44 --> Output Class Initialized
INFO - 2023-05-22 06:05:44 --> Security Class Initialized
INFO - 2023-05-22 06:05:44 --> Security Class Initialized
INFO - 2023-05-22 06:05:44 --> Security Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:05:44 --> Final output sent to browser
DEBUG - 2023-05-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:05:44 --> Input Class Initialized
INFO - 2023-05-22 06:05:44 --> Input Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Total execution time: 0.4171
INFO - 2023-05-22 06:05:44 --> Input Class Initialized
INFO - 2023-05-22 06:05:44 --> Language Class Initialized
INFO - 2023-05-22 06:05:44 --> Language Class Initialized
INFO - 2023-05-22 06:05:44 --> Language Class Initialized
INFO - 2023-05-22 06:05:44 --> Loader Class Initialized
INFO - 2023-05-22 06:05:44 --> Loader Class Initialized
INFO - 2023-05-22 06:05:44 --> Loader Class Initialized
INFO - 2023-05-22 06:05:44 --> Controller Class Initialized
INFO - 2023-05-22 06:05:44 --> Controller Class Initialized
INFO - 2023-05-22 06:05:44 --> Controller Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:05:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:05:44 --> Config Class Initialized
INFO - 2023-05-22 06:05:44 --> Hooks Class Initialized
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
DEBUG - 2023-05-22 06:05:44 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:05:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:05:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:05:44 --> Utf8 Class Initialized
INFO - 2023-05-22 06:05:44 --> URI Class Initialized
INFO - 2023-05-22 06:05:44 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:44 --> Router Class Initialized
INFO - 2023-05-22 06:05:44 --> Model "Login_model" initialized
INFO - 2023-05-22 06:05:44 --> Final output sent to browser
INFO - 2023-05-22 06:05:44 --> Output Class Initialized
INFO - 2023-05-22 06:05:44 --> Final output sent to browser
DEBUG - 2023-05-22 06:05:44 --> Total execution time: 0.2901
DEBUG - 2023-05-22 06:05:44 --> Total execution time: 0.2811
INFO - 2023-05-22 06:05:44 --> Security Class Initialized
DEBUG - 2023-05-22 06:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:05:44 --> Input Class Initialized
INFO - 2023-05-22 06:05:44 --> Final output sent to browser
DEBUG - 2023-05-22 06:05:44 --> Total execution time: 0.3130
INFO - 2023-05-22 06:05:44 --> Language Class Initialized
INFO - 2023-05-22 06:05:44 --> Loader Class Initialized
INFO - 2023-05-22 06:05:44 --> Controller Class Initialized
DEBUG - 2023-05-22 06:05:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:05:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:05:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:05:45 --> Final output sent to browser
DEBUG - 2023-05-22 06:05:45 --> Total execution time: 0.3006
INFO - 2023-05-22 06:06:45 --> Config Class Initialized
INFO - 2023-05-22 06:06:45 --> Config Class Initialized
INFO - 2023-05-22 06:06:45 --> Hooks Class Initialized
INFO - 2023-05-22 06:06:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:06:45 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:06:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:06:45 --> Utf8 Class Initialized
INFO - 2023-05-22 06:06:45 --> Utf8 Class Initialized
INFO - 2023-05-22 06:06:45 --> URI Class Initialized
INFO - 2023-05-22 06:06:45 --> URI Class Initialized
INFO - 2023-05-22 06:06:45 --> Router Class Initialized
INFO - 2023-05-22 06:06:45 --> Router Class Initialized
INFO - 2023-05-22 06:06:45 --> Output Class Initialized
INFO - 2023-05-22 06:06:45 --> Output Class Initialized
INFO - 2023-05-22 06:06:45 --> Security Class Initialized
INFO - 2023-05-22 06:06:45 --> Security Class Initialized
DEBUG - 2023-05-22 06:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:06:45 --> Input Class Initialized
INFO - 2023-05-22 06:06:45 --> Input Class Initialized
INFO - 2023-05-22 06:06:45 --> Language Class Initialized
INFO - 2023-05-22 06:06:45 --> Language Class Initialized
INFO - 2023-05-22 06:06:45 --> Loader Class Initialized
INFO - 2023-05-22 06:06:45 --> Controller Class Initialized
INFO - 2023-05-22 06:06:45 --> Loader Class Initialized
DEBUG - 2023-05-22 06:06:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:06:45 --> Controller Class Initialized
DEBUG - 2023-05-22 06:06:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:06:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:06:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:06:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:06:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:06:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:06:45 --> Final output sent to browser
INFO - 2023-05-22 06:06:45 --> Model "Login_model" initialized
DEBUG - 2023-05-22 06:06:45 --> Total execution time: 0.1902
INFO - 2023-05-22 06:06:45 --> Config Class Initialized
INFO - 2023-05-22 06:06:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:06:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:06:45 --> Utf8 Class Initialized
INFO - 2023-05-22 06:06:45 --> URI Class Initialized
INFO - 2023-05-22 06:06:45 --> Router Class Initialized
INFO - 2023-05-22 06:06:45 --> Output Class Initialized
INFO - 2023-05-22 06:06:45 --> Security Class Initialized
DEBUG - 2023-05-22 06:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:06:45 --> Input Class Initialized
INFO - 2023-05-22 06:06:45 --> Language Class Initialized
INFO - 2023-05-22 06:06:45 --> Loader Class Initialized
INFO - 2023-05-22 06:06:45 --> Controller Class Initialized
DEBUG - 2023-05-22 06:06:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:06:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:06:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:06:45 --> Final output sent to browser
DEBUG - 2023-05-22 06:06:45 --> Total execution time: 0.3618
INFO - 2023-05-22 06:06:52 --> Final output sent to browser
DEBUG - 2023-05-22 06:06:52 --> Total execution time: 7.0076
INFO - 2023-05-22 06:06:52 --> Config Class Initialized
INFO - 2023-05-22 06:06:52 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:06:52 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:06:52 --> Utf8 Class Initialized
INFO - 2023-05-22 06:06:52 --> URI Class Initialized
INFO - 2023-05-22 06:06:52 --> Router Class Initialized
INFO - 2023-05-22 06:06:52 --> Output Class Initialized
INFO - 2023-05-22 06:06:52 --> Security Class Initialized
DEBUG - 2023-05-22 06:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:06:52 --> Input Class Initialized
INFO - 2023-05-22 06:06:52 --> Language Class Initialized
INFO - 2023-05-22 06:06:52 --> Loader Class Initialized
INFO - 2023-05-22 06:06:52 --> Controller Class Initialized
DEBUG - 2023-05-22 06:06:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:06:52 --> Database Driver Class Initialized
INFO - 2023-05-22 06:06:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:06:52 --> Database Driver Class Initialized
INFO - 2023-05-22 06:06:52 --> Model "Login_model" initialized
INFO - 2023-05-22 06:06:59 --> Final output sent to browser
DEBUG - 2023-05-22 06:06:59 --> Total execution time: 7.2540
INFO - 2023-05-22 06:07:45 --> Config Class Initialized
INFO - 2023-05-22 06:07:45 --> Config Class Initialized
INFO - 2023-05-22 06:07:45 --> Hooks Class Initialized
INFO - 2023-05-22 06:07:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:07:45 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:07:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:07:45 --> Utf8 Class Initialized
INFO - 2023-05-22 06:07:45 --> Utf8 Class Initialized
INFO - 2023-05-22 06:07:45 --> URI Class Initialized
INFO - 2023-05-22 06:07:45 --> URI Class Initialized
INFO - 2023-05-22 06:07:45 --> Router Class Initialized
INFO - 2023-05-22 06:07:45 --> Router Class Initialized
INFO - 2023-05-22 06:07:45 --> Output Class Initialized
INFO - 2023-05-22 06:07:45 --> Output Class Initialized
INFO - 2023-05-22 06:07:45 --> Security Class Initialized
INFO - 2023-05-22 06:07:45 --> Security Class Initialized
DEBUG - 2023-05-22 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:07:45 --> Input Class Initialized
DEBUG - 2023-05-22 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:07:45 --> Language Class Initialized
INFO - 2023-05-22 06:07:45 --> Input Class Initialized
INFO - 2023-05-22 06:07:45 --> Language Class Initialized
INFO - 2023-05-22 06:07:45 --> Loader Class Initialized
INFO - 2023-05-22 06:07:45 --> Controller Class Initialized
INFO - 2023-05-22 06:07:45 --> Loader Class Initialized
DEBUG - 2023-05-22 06:07:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:07:45 --> Controller Class Initialized
DEBUG - 2023-05-22 06:07:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:07:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:07:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:07:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:07:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:07:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:07:45 --> Final output sent to browser
DEBUG - 2023-05-22 06:07:45 --> Total execution time: 0.3129
INFO - 2023-05-22 06:07:45 --> Model "Login_model" initialized
INFO - 2023-05-22 06:07:45 --> Config Class Initialized
INFO - 2023-05-22 06:07:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:07:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:07:45 --> Utf8 Class Initialized
INFO - 2023-05-22 06:07:45 --> URI Class Initialized
INFO - 2023-05-22 06:07:45 --> Router Class Initialized
INFO - 2023-05-22 06:07:45 --> Output Class Initialized
INFO - 2023-05-22 06:07:45 --> Security Class Initialized
DEBUG - 2023-05-22 06:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:07:45 --> Input Class Initialized
INFO - 2023-05-22 06:07:45 --> Language Class Initialized
INFO - 2023-05-22 06:07:45 --> Loader Class Initialized
INFO - 2023-05-22 06:07:45 --> Controller Class Initialized
DEBUG - 2023-05-22 06:07:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:07:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:07:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:07:45 --> Final output sent to browser
DEBUG - 2023-05-22 06:07:45 --> Total execution time: 0.4120
INFO - 2023-05-22 06:07:51 --> Final output sent to browser
DEBUG - 2023-05-22 06:07:51 --> Total execution time: 6.4277
INFO - 2023-05-22 06:07:51 --> Config Class Initialized
INFO - 2023-05-22 06:07:51 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:07:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:07:51 --> Utf8 Class Initialized
INFO - 2023-05-22 06:07:51 --> URI Class Initialized
INFO - 2023-05-22 06:07:51 --> Router Class Initialized
INFO - 2023-05-22 06:07:51 --> Output Class Initialized
INFO - 2023-05-22 06:07:51 --> Security Class Initialized
DEBUG - 2023-05-22 06:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:07:51 --> Input Class Initialized
INFO - 2023-05-22 06:07:51 --> Language Class Initialized
INFO - 2023-05-22 06:07:51 --> Loader Class Initialized
INFO - 2023-05-22 06:07:51 --> Controller Class Initialized
DEBUG - 2023-05-22 06:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:07:51 --> Database Driver Class Initialized
INFO - 2023-05-22 06:07:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:07:51 --> Database Driver Class Initialized
INFO - 2023-05-22 06:07:51 --> Model "Login_model" initialized
INFO - 2023-05-22 06:07:58 --> Final output sent to browser
DEBUG - 2023-05-22 06:07:58 --> Total execution time: 6.6741
INFO - 2023-05-22 06:08:45 --> Config Class Initialized
INFO - 2023-05-22 06:08:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:08:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:08:45 --> Utf8 Class Initialized
INFO - 2023-05-22 06:08:45 --> URI Class Initialized
INFO - 2023-05-22 06:08:45 --> Router Class Initialized
INFO - 2023-05-22 06:08:45 --> Output Class Initialized
INFO - 2023-05-22 06:08:45 --> Security Class Initialized
DEBUG - 2023-05-22 06:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:08:45 --> Input Class Initialized
INFO - 2023-05-22 06:08:45 --> Language Class Initialized
INFO - 2023-05-22 06:08:45 --> Loader Class Initialized
INFO - 2023-05-22 06:08:45 --> Controller Class Initialized
DEBUG - 2023-05-22 06:08:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:08:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:08:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:08:45 --> Final output sent to browser
DEBUG - 2023-05-22 06:08:45 --> Total execution time: 0.4746
INFO - 2023-05-22 06:08:45 --> Config Class Initialized
INFO - 2023-05-22 06:08:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:08:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:08:45 --> Utf8 Class Initialized
INFO - 2023-05-22 06:08:45 --> URI Class Initialized
INFO - 2023-05-22 06:08:45 --> Router Class Initialized
INFO - 2023-05-22 06:08:45 --> Output Class Initialized
INFO - 2023-05-22 06:08:45 --> Security Class Initialized
DEBUG - 2023-05-22 06:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:08:45 --> Input Class Initialized
INFO - 2023-05-22 06:08:45 --> Language Class Initialized
INFO - 2023-05-22 06:08:45 --> Loader Class Initialized
INFO - 2023-05-22 06:08:45 --> Controller Class Initialized
DEBUG - 2023-05-22 06:08:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:08:45 --> Database Driver Class Initialized
INFO - 2023-05-22 06:08:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:08:45 --> Final output sent to browser
DEBUG - 2023-05-22 06:08:45 --> Total execution time: 0.2892
INFO - 2023-05-22 06:09:03 --> Config Class Initialized
INFO - 2023-05-22 06:09:03 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:03 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:03 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:03 --> URI Class Initialized
INFO - 2023-05-22 06:09:03 --> Router Class Initialized
INFO - 2023-05-22 06:09:03 --> Output Class Initialized
INFO - 2023-05-22 06:09:03 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:03 --> Input Class Initialized
INFO - 2023-05-22 06:09:03 --> Language Class Initialized
INFO - 2023-05-22 06:09:03 --> Loader Class Initialized
INFO - 2023-05-22 06:09:03 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:03 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:03 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:03 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:03 --> Model "Login_model" initialized
INFO - 2023-05-22 06:09:09 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:09 --> Total execution time: 6.7406
INFO - 2023-05-22 06:09:09 --> Config Class Initialized
INFO - 2023-05-22 06:09:09 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:09 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:09 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:09 --> URI Class Initialized
INFO - 2023-05-22 06:09:09 --> Router Class Initialized
INFO - 2023-05-22 06:09:09 --> Output Class Initialized
INFO - 2023-05-22 06:09:09 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:10 --> Input Class Initialized
INFO - 2023-05-22 06:09:10 --> Language Class Initialized
INFO - 2023-05-22 06:09:10 --> Loader Class Initialized
INFO - 2023-05-22 06:09:10 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:10 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:10 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:10 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:10 --> Model "Login_model" initialized
INFO - 2023-05-22 06:09:16 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:16 --> Total execution time: 6.8200
INFO - 2023-05-22 06:09:46 --> Config Class Initialized
INFO - 2023-05-22 06:09:46 --> Config Class Initialized
INFO - 2023-05-22 06:09:46 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:46 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:46 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:46 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:46 --> URI Class Initialized
DEBUG - 2023-05-22 06:09:46 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:46 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:46 --> Router Class Initialized
INFO - 2023-05-22 06:09:46 --> URI Class Initialized
INFO - 2023-05-22 06:09:46 --> Output Class Initialized
INFO - 2023-05-22 06:09:46 --> Router Class Initialized
INFO - 2023-05-22 06:09:46 --> Security Class Initialized
INFO - 2023-05-22 06:09:46 --> Output Class Initialized
DEBUG - 2023-05-22 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:46 --> Input Class Initialized
INFO - 2023-05-22 06:09:46 --> Language Class Initialized
INFO - 2023-05-22 06:09:46 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:46 --> Input Class Initialized
INFO - 2023-05-22 06:09:46 --> Language Class Initialized
INFO - 2023-05-22 06:09:46 --> Loader Class Initialized
INFO - 2023-05-22 06:09:46 --> Controller Class Initialized
INFO - 2023-05-22 06:09:46 --> Loader Class Initialized
DEBUG - 2023-05-22 06:09:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:46 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:46 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:46 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:46 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:46 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:46 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:46 --> Model "Login_model" initialized
INFO - 2023-05-22 06:09:46 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:46 --> Total execution time: 0.2812
INFO - 2023-05-22 06:09:47 --> Config Class Initialized
INFO - 2023-05-22 06:09:47 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:47 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:47 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:47 --> URI Class Initialized
INFO - 2023-05-22 06:09:47 --> Router Class Initialized
INFO - 2023-05-22 06:09:47 --> Output Class Initialized
INFO - 2023-05-22 06:09:47 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:47 --> Input Class Initialized
INFO - 2023-05-22 06:09:47 --> Language Class Initialized
INFO - 2023-05-22 06:09:47 --> Loader Class Initialized
INFO - 2023-05-22 06:09:47 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:47 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:47 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:47 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:47 --> Total execution time: 0.3725
INFO - 2023-05-22 06:09:49 --> Config Class Initialized
INFO - 2023-05-22 06:09:49 --> Config Class Initialized
INFO - 2023-05-22 06:09:49 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:49 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:49 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:09:49 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:49 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:49 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:49 --> URI Class Initialized
INFO - 2023-05-22 06:09:49 --> URI Class Initialized
INFO - 2023-05-22 06:09:49 --> Router Class Initialized
INFO - 2023-05-22 06:09:49 --> Router Class Initialized
INFO - 2023-05-22 06:09:49 --> Output Class Initialized
INFO - 2023-05-22 06:09:49 --> Output Class Initialized
INFO - 2023-05-22 06:09:49 --> Security Class Initialized
INFO - 2023-05-22 06:09:49 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:49 --> Input Class Initialized
INFO - 2023-05-22 06:09:49 --> Input Class Initialized
INFO - 2023-05-22 06:09:49 --> Language Class Initialized
INFO - 2023-05-22 06:09:49 --> Language Class Initialized
INFO - 2023-05-22 06:09:49 --> Loader Class Initialized
INFO - 2023-05-22 06:09:49 --> Loader Class Initialized
INFO - 2023-05-22 06:09:49 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:49 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:49 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:49 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:49 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:49 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:49 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:49 --> Total execution time: 0.4004
INFO - 2023-05-22 06:09:49 --> Config Class Initialized
INFO - 2023-05-22 06:09:49 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:49 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:49 --> Total execution time: 0.4605
DEBUG - 2023-05-22 06:09:49 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:49 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:49 --> URI Class Initialized
INFO - 2023-05-22 06:09:49 --> Router Class Initialized
INFO - 2023-05-22 06:09:49 --> Config Class Initialized
INFO - 2023-05-22 06:09:49 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:49 --> Output Class Initialized
INFO - 2023-05-22 06:09:49 --> Config Class Initialized
INFO - 2023-05-22 06:09:49 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:49 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:49 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:49 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:49 --> Input Class Initialized
INFO - 2023-05-22 06:09:49 --> URI Class Initialized
INFO - 2023-05-22 06:09:49 --> Language Class Initialized
DEBUG - 2023-05-22 06:09:49 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:49 --> Router Class Initialized
INFO - 2023-05-22 06:09:49 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:49 --> URI Class Initialized
INFO - 2023-05-22 06:09:49 --> Loader Class Initialized
INFO - 2023-05-22 06:09:49 --> Output Class Initialized
INFO - 2023-05-22 06:09:49 --> Security Class Initialized
INFO - 2023-05-22 06:09:49 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:49 --> Router Class Initialized
DEBUG - 2023-05-22 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:49 --> Input Class Initialized
INFO - 2023-05-22 06:09:49 --> Language Class Initialized
INFO - 2023-05-22 06:09:49 --> Output Class Initialized
INFO - 2023-05-22 06:09:49 --> Security Class Initialized
INFO - 2023-05-22 06:09:49 --> Database Driver Class Initialized
DEBUG - 2023-05-22 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:49 --> Loader Class Initialized
INFO - 2023-05-22 06:09:49 --> Input Class Initialized
INFO - 2023-05-22 06:09:49 --> Language Class Initialized
INFO - 2023-05-22 06:09:49 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:49 --> Loader Class Initialized
INFO - 2023-05-22 06:09:49 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:49 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:49 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:49 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:49 --> Final output sent to browser
INFO - 2023-05-22 06:09:49 --> Model "Cluster_model" initialized
DEBUG - 2023-05-22 06:09:49 --> Total execution time: 0.5197
INFO - 2023-05-22 06:09:50 --> Config Class Initialized
INFO - 2023-05-22 06:09:50 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:50 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:50 --> URI Class Initialized
INFO - 2023-05-22 06:09:50 --> Router Class Initialized
INFO - 2023-05-22 06:09:50 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:50 --> Total execution time: 0.5624
INFO - 2023-05-22 06:09:50 --> Output Class Initialized
INFO - 2023-05-22 06:09:50 --> Security Class Initialized
INFO - 2023-05-22 06:09:50 --> Model "Cluster_model" initialized
DEBUG - 2023-05-22 06:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:50 --> Input Class Initialized
INFO - 2023-05-22 06:09:50 --> Language Class Initialized
INFO - 2023-05-22 06:09:50 --> Loader Class Initialized
INFO - 2023-05-22 06:09:50 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:50 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:50 --> Total execution time: 0.6467
INFO - 2023-05-22 06:09:50 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:50 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:50 --> Config Class Initialized
INFO - 2023-05-22 06:09:50 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:50 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:50 --> Total execution time: 0.2686
DEBUG - 2023-05-22 06:09:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:50 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:50 --> URI Class Initialized
INFO - 2023-05-22 06:09:50 --> Router Class Initialized
INFO - 2023-05-22 06:09:50 --> Output Class Initialized
INFO - 2023-05-22 06:09:50 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:50 --> Input Class Initialized
INFO - 2023-05-22 06:09:50 --> Language Class Initialized
INFO - 2023-05-22 06:09:50 --> Loader Class Initialized
INFO - 2023-05-22 06:09:50 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:50 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:50 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:50 --> Config Class Initialized
INFO - 2023-05-22 06:09:50 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:50 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:50 --> URI Class Initialized
INFO - 2023-05-22 06:09:50 --> Router Class Initialized
INFO - 2023-05-22 06:09:50 --> Output Class Initialized
INFO - 2023-05-22 06:09:50 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:50 --> Input Class Initialized
INFO - 2023-05-22 06:09:50 --> Language Class Initialized
INFO - 2023-05-22 06:09:50 --> Loader Class Initialized
INFO - 2023-05-22 06:09:50 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:50 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:50 --> Config Class Initialized
INFO - 2023-05-22 06:09:50 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:50 --> Model "Cluster_model" initialized
DEBUG - 2023-05-22 06:09:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:50 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:50 --> URI Class Initialized
INFO - 2023-05-22 06:09:50 --> Router Class Initialized
INFO - 2023-05-22 06:09:51 --> Output Class Initialized
INFO - 2023-05-22 06:09:51 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:51 --> Input Class Initialized
INFO - 2023-05-22 06:09:51 --> Language Class Initialized
INFO - 2023-05-22 06:09:51 --> Loader Class Initialized
INFO - 2023-05-22 06:09:51 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:51 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:51 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:51 --> Total execution time: 0.3032
INFO - 2023-05-22 06:09:51 --> Config Class Initialized
INFO - 2023-05-22 06:09:51 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:51 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:51 --> URI Class Initialized
INFO - 2023-05-22 06:09:51 --> Router Class Initialized
INFO - 2023-05-22 06:09:51 --> Output Class Initialized
INFO - 2023-05-22 06:09:51 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:51 --> Input Class Initialized
INFO - 2023-05-22 06:09:51 --> Language Class Initialized
INFO - 2023-05-22 06:09:51 --> Loader Class Initialized
INFO - 2023-05-22 06:09:51 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:51 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:51 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:51 --> Total execution time: 0.3175
INFO - 2023-05-22 06:09:53 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:53 --> Total execution time: 7.0814
INFO - 2023-05-22 06:09:53 --> Config Class Initialized
INFO - 2023-05-22 06:09:53 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:53 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:53 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:53 --> URI Class Initialized
INFO - 2023-05-22 06:09:53 --> Router Class Initialized
INFO - 2023-05-22 06:09:53 --> Output Class Initialized
INFO - 2023-05-22 06:09:53 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:53 --> Input Class Initialized
INFO - 2023-05-22 06:09:53 --> Language Class Initialized
INFO - 2023-05-22 06:09:53 --> Loader Class Initialized
INFO - 2023-05-22 06:09:53 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:53 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:53 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:53 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:54 --> Model "Login_model" initialized
INFO - 2023-05-22 06:09:55 --> Config Class Initialized
INFO - 2023-05-22 06:09:55 --> Config Class Initialized
INFO - 2023-05-22 06:09:55 --> Config Class Initialized
INFO - 2023-05-22 06:09:55 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:55 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:55 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:09:55 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:55 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:55 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:55 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:55 --> URI Class Initialized
INFO - 2023-05-22 06:09:55 --> URI Class Initialized
INFO - 2023-05-22 06:09:55 --> URI Class Initialized
INFO - 2023-05-22 06:09:55 --> Router Class Initialized
INFO - 2023-05-22 06:09:55 --> Router Class Initialized
INFO - 2023-05-22 06:09:55 --> Router Class Initialized
INFO - 2023-05-22 06:09:55 --> Output Class Initialized
INFO - 2023-05-22 06:09:55 --> Output Class Initialized
INFO - 2023-05-22 06:09:55 --> Output Class Initialized
INFO - 2023-05-22 06:09:55 --> Security Class Initialized
INFO - 2023-05-22 06:09:55 --> Security Class Initialized
INFO - 2023-05-22 06:09:55 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:55 --> Input Class Initialized
INFO - 2023-05-22 06:09:55 --> Input Class Initialized
INFO - 2023-05-22 06:09:55 --> Input Class Initialized
INFO - 2023-05-22 06:09:55 --> Language Class Initialized
INFO - 2023-05-22 06:09:55 --> Language Class Initialized
INFO - 2023-05-22 06:09:55 --> Language Class Initialized
INFO - 2023-05-22 06:09:55 --> Loader Class Initialized
INFO - 2023-05-22 06:09:55 --> Loader Class Initialized
INFO - 2023-05-22 06:09:55 --> Controller Class Initialized
INFO - 2023-05-22 06:09:55 --> Controller Class Initialized
INFO - 2023-05-22 06:09:55 --> Loader Class Initialized
DEBUG - 2023-05-22 06:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:55 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:55 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:55 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:55 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:55 --> Final output sent to browser
INFO - 2023-05-22 06:09:55 --> Model "Cluster_model" initialized
DEBUG - 2023-05-22 06:09:55 --> Total execution time: 0.2453
INFO - 2023-05-22 06:09:55 --> Final output sent to browser
INFO - 2023-05-22 06:09:55 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:55 --> Total execution time: 0.2637
DEBUG - 2023-05-22 06:09:55 --> Total execution time: 0.2631
INFO - 2023-05-22 06:09:55 --> Config Class Initialized
INFO - 2023-05-22 06:09:55 --> Config Class Initialized
INFO - 2023-05-22 06:09:55 --> Config Class Initialized
INFO - 2023-05-22 06:09:55 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:55 --> Hooks Class Initialized
INFO - 2023-05-22 06:09:55 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:09:55 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:55 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:55 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:55 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:55 --> URI Class Initialized
INFO - 2023-05-22 06:09:55 --> URI Class Initialized
INFO - 2023-05-22 06:09:55 --> URI Class Initialized
INFO - 2023-05-22 06:09:55 --> Router Class Initialized
INFO - 2023-05-22 06:09:55 --> Router Class Initialized
INFO - 2023-05-22 06:09:55 --> Router Class Initialized
INFO - 2023-05-22 06:09:55 --> Output Class Initialized
INFO - 2023-05-22 06:09:55 --> Output Class Initialized
INFO - 2023-05-22 06:09:55 --> Output Class Initialized
INFO - 2023-05-22 06:09:55 --> Security Class Initialized
INFO - 2023-05-22 06:09:55 --> Security Class Initialized
INFO - 2023-05-22 06:09:55 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:55 --> Input Class Initialized
INFO - 2023-05-22 06:09:55 --> Input Class Initialized
INFO - 2023-05-22 06:09:55 --> Input Class Initialized
INFO - 2023-05-22 06:09:55 --> Language Class Initialized
INFO - 2023-05-22 06:09:55 --> Language Class Initialized
INFO - 2023-05-22 06:09:55 --> Language Class Initialized
INFO - 2023-05-22 06:09:55 --> Loader Class Initialized
INFO - 2023-05-22 06:09:55 --> Loader Class Initialized
INFO - 2023-05-22 06:09:55 --> Controller Class Initialized
INFO - 2023-05-22 06:09:55 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:55 --> Loader Class Initialized
INFO - 2023-05-22 06:09:55 --> Controller Class Initialized
INFO - 2023-05-22 06:09:55 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:55 --> Database Driver Class Initialized
DEBUG - 2023-05-22 06:09:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:55 --> Final output sent to browser
INFO - 2023-05-22 06:09:55 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:55 --> Total execution time: 0.2415
DEBUG - 2023-05-22 06:09:55 --> Total execution time: 0.2405
INFO - 2023-05-22 06:09:55 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:55 --> Config Class Initialized
INFO - 2023-05-22 06:09:55 --> Final output sent to browser
INFO - 2023-05-22 06:09:55 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:55 --> Total execution time: 0.3151
DEBUG - 2023-05-22 06:09:55 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:55 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:55 --> URI Class Initialized
INFO - 2023-05-22 06:09:55 --> Router Class Initialized
INFO - 2023-05-22 06:09:55 --> Output Class Initialized
INFO - 2023-05-22 06:09:55 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:55 --> Input Class Initialized
INFO - 2023-05-22 06:09:56 --> Language Class Initialized
INFO - 2023-05-22 06:09:56 --> Loader Class Initialized
INFO - 2023-05-22 06:09:56 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:56 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:56 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:56 --> Config Class Initialized
INFO - 2023-05-22 06:09:56 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:09:56 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:09:56 --> Utf8 Class Initialized
INFO - 2023-05-22 06:09:56 --> URI Class Initialized
INFO - 2023-05-22 06:09:56 --> Router Class Initialized
INFO - 2023-05-22 06:09:56 --> Output Class Initialized
INFO - 2023-05-22 06:09:56 --> Security Class Initialized
DEBUG - 2023-05-22 06:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:09:56 --> Input Class Initialized
INFO - 2023-05-22 06:09:56 --> Language Class Initialized
INFO - 2023-05-22 06:09:56 --> Loader Class Initialized
INFO - 2023-05-22 06:09:56 --> Controller Class Initialized
DEBUG - 2023-05-22 06:09:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:09:56 --> Database Driver Class Initialized
INFO - 2023-05-22 06:09:56 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:09:58 --> Final output sent to browser
DEBUG - 2023-05-22 06:09:58 --> Total execution time: 4.4393
INFO - 2023-05-22 06:18:27 --> Config Class Initialized
INFO - 2023-05-22 06:18:27 --> Config Class Initialized
INFO - 2023-05-22 06:18:27 --> Hooks Class Initialized
INFO - 2023-05-22 06:18:27 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:18:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:18:27 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:18:27 --> Config Class Initialized
INFO - 2023-05-22 06:18:27 --> Utf8 Class Initialized
INFO - 2023-05-22 06:18:27 --> Utf8 Class Initialized
INFO - 2023-05-22 06:18:27 --> Hooks Class Initialized
INFO - 2023-05-22 06:18:27 --> URI Class Initialized
INFO - 2023-05-22 06:18:27 --> URI Class Initialized
INFO - 2023-05-22 06:18:27 --> Router Class Initialized
INFO - 2023-05-22 06:18:27 --> Router Class Initialized
INFO - 2023-05-22 06:18:27 --> Output Class Initialized
INFO - 2023-05-22 06:18:27 --> Output Class Initialized
INFO - 2023-05-22 06:18:27 --> Security Class Initialized
DEBUG - 2023-05-22 06:18:27 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:18:27 --> Security Class Initialized
INFO - 2023-05-22 06:18:27 --> Utf8 Class Initialized
DEBUG - 2023-05-22 06:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:18:27 --> URI Class Initialized
INFO - 2023-05-22 06:18:27 --> Input Class Initialized
INFO - 2023-05-22 06:18:27 --> Input Class Initialized
INFO - 2023-05-22 06:18:27 --> Language Class Initialized
INFO - 2023-05-22 06:18:27 --> Language Class Initialized
INFO - 2023-05-22 06:18:27 --> Router Class Initialized
INFO - 2023-05-22 06:18:27 --> Loader Class Initialized
INFO - 2023-05-22 06:18:27 --> Loader Class Initialized
INFO - 2023-05-22 06:18:27 --> Output Class Initialized
INFO - 2023-05-22 06:18:27 --> Controller Class Initialized
INFO - 2023-05-22 06:18:27 --> Controller Class Initialized
DEBUG - 2023-05-22 06:18:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:18:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:18:27 --> Security Class Initialized
DEBUG - 2023-05-22 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:18:27 --> Input Class Initialized
INFO - 2023-05-22 06:18:27 --> Language Class Initialized
INFO - 2023-05-22 06:18:27 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:27 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:27 --> Loader Class Initialized
INFO - 2023-05-22 06:18:27 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:18:27 --> Controller Class Initialized
DEBUG - 2023-05-22 06:18:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:18:27 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:27 --> Model "Login_model" initialized
INFO - 2023-05-22 06:18:27 --> Final output sent to browser
INFO - 2023-05-22 06:18:27 --> Final output sent to browser
DEBUG - 2023-05-22 06:18:27 --> Total execution time: 0.2745
DEBUG - 2023-05-22 06:18:27 --> Total execution time: 0.2776
INFO - 2023-05-22 06:18:27 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:27 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:18:27 --> Config Class Initialized
INFO - 2023-05-22 06:18:27 --> Config Class Initialized
INFO - 2023-05-22 06:18:27 --> Hooks Class Initialized
INFO - 2023-05-22 06:18:27 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:18:27 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:18:27 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:18:27 --> Utf8 Class Initialized
INFO - 2023-05-22 06:18:27 --> Utf8 Class Initialized
INFO - 2023-05-22 06:18:27 --> URI Class Initialized
INFO - 2023-05-22 06:18:27 --> URI Class Initialized
INFO - 2023-05-22 06:18:27 --> Router Class Initialized
INFO - 2023-05-22 06:18:27 --> Router Class Initialized
INFO - 2023-05-22 06:18:27 --> Final output sent to browser
INFO - 2023-05-22 06:18:27 --> Output Class Initialized
INFO - 2023-05-22 06:18:27 --> Output Class Initialized
DEBUG - 2023-05-22 06:18:27 --> Total execution time: 0.3713
INFO - 2023-05-22 06:18:27 --> Security Class Initialized
INFO - 2023-05-22 06:18:27 --> Security Class Initialized
DEBUG - 2023-05-22 06:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:18:27 --> Input Class Initialized
INFO - 2023-05-22 06:18:27 --> Input Class Initialized
INFO - 2023-05-22 06:18:27 --> Language Class Initialized
INFO - 2023-05-22 06:18:27 --> Language Class Initialized
INFO - 2023-05-22 06:18:27 --> Loader Class Initialized
INFO - 2023-05-22 06:18:27 --> Loader Class Initialized
INFO - 2023-05-22 06:18:28 --> Controller Class Initialized
INFO - 2023-05-22 06:18:28 --> Controller Class Initialized
INFO - 2023-05-22 06:18:28 --> Config Class Initialized
INFO - 2023-05-22 06:18:28 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:18:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:18:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:18:28 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:18:28 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:28 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:28 --> Utf8 Class Initialized
INFO - 2023-05-22 06:18:28 --> URI Class Initialized
INFO - 2023-05-22 06:18:28 --> Router Class Initialized
INFO - 2023-05-22 06:18:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:18:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:18:28 --> Output Class Initialized
INFO - 2023-05-22 06:18:28 --> Security Class Initialized
INFO - 2023-05-22 06:18:28 --> Final output sent to browser
DEBUG - 2023-05-22 06:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:18:28 --> Total execution time: 0.2571
INFO - 2023-05-22 06:18:28 --> Input Class Initialized
INFO - 2023-05-22 06:18:28 --> Final output sent to browser
INFO - 2023-05-22 06:18:28 --> Language Class Initialized
DEBUG - 2023-05-22 06:18:28 --> Total execution time: 0.2682
INFO - 2023-05-22 06:18:28 --> Config Class Initialized
INFO - 2023-05-22 06:18:28 --> Hooks Class Initialized
INFO - 2023-05-22 06:18:28 --> Loader Class Initialized
DEBUG - 2023-05-22 06:18:28 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:18:28 --> Controller Class Initialized
INFO - 2023-05-22 06:18:28 --> Utf8 Class Initialized
INFO - 2023-05-22 06:18:28 --> Config Class Initialized
INFO - 2023-05-22 06:18:28 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:18:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:18:28 --> URI Class Initialized
DEBUG - 2023-05-22 06:18:28 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:18:28 --> Router Class Initialized
INFO - 2023-05-22 06:18:28 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:28 --> Utf8 Class Initialized
INFO - 2023-05-22 06:18:28 --> URI Class Initialized
INFO - 2023-05-22 06:18:28 --> Output Class Initialized
INFO - 2023-05-22 06:18:28 --> Router Class Initialized
INFO - 2023-05-22 06:18:28 --> Security Class Initialized
DEBUG - 2023-05-22 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:18:28 --> Output Class Initialized
INFO - 2023-05-22 06:18:28 --> Input Class Initialized
INFO - 2023-05-22 06:18:28 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:28 --> Language Class Initialized
INFO - 2023-05-22 06:18:28 --> Security Class Initialized
INFO - 2023-05-22 06:18:28 --> Model "Login_model" initialized
DEBUG - 2023-05-22 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:18:28 --> Input Class Initialized
INFO - 2023-05-22 06:18:28 --> Language Class Initialized
INFO - 2023-05-22 06:18:28 --> Final output sent to browser
DEBUG - 2023-05-22 06:18:28 --> Total execution time: 0.3437
INFO - 2023-05-22 06:18:28 --> Loader Class Initialized
INFO - 2023-05-22 06:18:28 --> Loader Class Initialized
INFO - 2023-05-22 06:18:28 --> Controller Class Initialized
DEBUG - 2023-05-22 06:18:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:18:28 --> Controller Class Initialized
DEBUG - 2023-05-22 06:18:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:18:28 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:28 --> Database Driver Class Initialized
INFO - 2023-05-22 06:18:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:18:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:18:28 --> Final output sent to browser
INFO - 2023-05-22 06:18:28 --> Final output sent to browser
DEBUG - 2023-05-22 06:18:28 --> Total execution time: 0.2721
DEBUG - 2023-05-22 06:18:28 --> Total execution time: 0.3389
INFO - 2023-05-22 06:19:20 --> Config Class Initialized
INFO - 2023-05-22 06:19:20 --> Config Class Initialized
INFO - 2023-05-22 06:19:20 --> Config Class Initialized
INFO - 2023-05-22 06:19:20 --> Hooks Class Initialized
INFO - 2023-05-22 06:19:20 --> Hooks Class Initialized
INFO - 2023-05-22 06:19:20 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:19:20 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:19:20 --> Utf8 Class Initialized
INFO - 2023-05-22 06:19:20 --> Utf8 Class Initialized
INFO - 2023-05-22 06:19:20 --> Utf8 Class Initialized
INFO - 2023-05-22 06:19:20 --> URI Class Initialized
INFO - 2023-05-22 06:19:20 --> URI Class Initialized
INFO - 2023-05-22 06:19:20 --> URI Class Initialized
INFO - 2023-05-22 06:19:20 --> Router Class Initialized
INFO - 2023-05-22 06:19:20 --> Router Class Initialized
INFO - 2023-05-22 06:19:20 --> Router Class Initialized
INFO - 2023-05-22 06:19:20 --> Output Class Initialized
INFO - 2023-05-22 06:19:20 --> Output Class Initialized
INFO - 2023-05-22 06:19:20 --> Output Class Initialized
INFO - 2023-05-22 06:19:20 --> Security Class Initialized
INFO - 2023-05-22 06:19:20 --> Security Class Initialized
INFO - 2023-05-22 06:19:20 --> Security Class Initialized
DEBUG - 2023-05-22 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:19:20 --> Input Class Initialized
INFO - 2023-05-22 06:19:20 --> Input Class Initialized
INFO - 2023-05-22 06:19:20 --> Input Class Initialized
INFO - 2023-05-22 06:19:20 --> Language Class Initialized
INFO - 2023-05-22 06:19:20 --> Language Class Initialized
INFO - 2023-05-22 06:19:20 --> Language Class Initialized
INFO - 2023-05-22 06:19:20 --> Loader Class Initialized
INFO - 2023-05-22 06:19:20 --> Loader Class Initialized
INFO - 2023-05-22 06:19:20 --> Controller Class Initialized
INFO - 2023-05-22 06:19:20 --> Controller Class Initialized
INFO - 2023-05-22 06:19:20 --> Loader Class Initialized
DEBUG - 2023-05-22 06:19:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:19:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:19:20 --> Controller Class Initialized
DEBUG - 2023-05-22 06:19:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:19:20 --> Database Driver Class Initialized
INFO - 2023-05-22 06:19:20 --> Database Driver Class Initialized
INFO - 2023-05-22 06:19:20 --> Database Driver Class Initialized
INFO - 2023-05-22 06:19:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:19:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:19:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:19:20 --> Final output sent to browser
INFO - 2023-05-22 06:19:20 --> Final output sent to browser
INFO - 2023-05-22 06:19:20 --> Final output sent to browser
DEBUG - 2023-05-22 06:19:20 --> Total execution time: 0.2157
DEBUG - 2023-05-22 06:19:20 --> Total execution time: 0.2131
DEBUG - 2023-05-22 06:19:20 --> Total execution time: 0.2166
INFO - 2023-05-22 06:19:20 --> Config Class Initialized
INFO - 2023-05-22 06:19:20 --> Config Class Initialized
INFO - 2023-05-22 06:19:20 --> Config Class Initialized
INFO - 2023-05-22 06:19:20 --> Hooks Class Initialized
INFO - 2023-05-22 06:19:20 --> Hooks Class Initialized
INFO - 2023-05-22 06:19:20 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 06:19:20 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:19:20 --> Utf8 Class Initialized
INFO - 2023-05-22 06:19:20 --> Utf8 Class Initialized
INFO - 2023-05-22 06:19:20 --> Utf8 Class Initialized
INFO - 2023-05-22 06:19:20 --> URI Class Initialized
INFO - 2023-05-22 06:19:20 --> URI Class Initialized
INFO - 2023-05-22 06:19:20 --> URI Class Initialized
INFO - 2023-05-22 06:19:20 --> Router Class Initialized
INFO - 2023-05-22 06:19:20 --> Router Class Initialized
INFO - 2023-05-22 06:19:20 --> Router Class Initialized
INFO - 2023-05-22 06:19:20 --> Output Class Initialized
INFO - 2023-05-22 06:19:20 --> Output Class Initialized
INFO - 2023-05-22 06:19:20 --> Output Class Initialized
INFO - 2023-05-22 06:19:20 --> Security Class Initialized
INFO - 2023-05-22 06:19:20 --> Security Class Initialized
INFO - 2023-05-22 06:19:20 --> Security Class Initialized
DEBUG - 2023-05-22 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 06:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:19:20 --> Input Class Initialized
INFO - 2023-05-22 06:19:20 --> Input Class Initialized
INFO - 2023-05-22 06:19:20 --> Input Class Initialized
INFO - 2023-05-22 06:19:20 --> Language Class Initialized
INFO - 2023-05-22 06:19:20 --> Language Class Initialized
INFO - 2023-05-22 06:19:20 --> Language Class Initialized
INFO - 2023-05-22 06:19:20 --> Loader Class Initialized
INFO - 2023-05-22 06:19:20 --> Loader Class Initialized
INFO - 2023-05-22 06:19:20 --> Controller Class Initialized
INFO - 2023-05-22 06:19:20 --> Controller Class Initialized
DEBUG - 2023-05-22 06:19:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 06:19:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:19:20 --> Loader Class Initialized
INFO - 2023-05-22 06:19:20 --> Controller Class Initialized
DEBUG - 2023-05-22 06:19:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:19:20 --> Database Driver Class Initialized
INFO - 2023-05-22 06:19:20 --> Database Driver Class Initialized
INFO - 2023-05-22 06:19:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:19:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:19:20 --> Database Driver Class Initialized
INFO - 2023-05-22 06:19:20 --> Final output sent to browser
INFO - 2023-05-22 06:19:20 --> Final output sent to browser
DEBUG - 2023-05-22 06:19:20 --> Total execution time: 0.2342
DEBUG - 2023-05-22 06:19:20 --> Total execution time: 0.2356
INFO - 2023-05-22 06:19:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:19:20 --> Final output sent to browser
DEBUG - 2023-05-22 06:19:20 --> Total execution time: 0.2736
INFO - 2023-05-22 06:19:20 --> Config Class Initialized
INFO - 2023-05-22 06:19:20 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:19:20 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:19:20 --> Utf8 Class Initialized
INFO - 2023-05-22 06:19:20 --> URI Class Initialized
INFO - 2023-05-22 06:19:20 --> Router Class Initialized
INFO - 2023-05-22 06:19:20 --> Output Class Initialized
INFO - 2023-05-22 06:19:20 --> Security Class Initialized
DEBUG - 2023-05-22 06:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:19:20 --> Input Class Initialized
INFO - 2023-05-22 06:19:20 --> Language Class Initialized
INFO - 2023-05-22 06:19:20 --> Loader Class Initialized
INFO - 2023-05-22 06:19:20 --> Controller Class Initialized
DEBUG - 2023-05-22 06:19:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:19:20 --> Database Driver Class Initialized
INFO - 2023-05-22 06:19:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 06:19:21 --> Config Class Initialized
INFO - 2023-05-22 06:19:21 --> Hooks Class Initialized
DEBUG - 2023-05-22 06:19:21 --> UTF-8 Support Enabled
INFO - 2023-05-22 06:19:21 --> Utf8 Class Initialized
INFO - 2023-05-22 06:19:21 --> URI Class Initialized
INFO - 2023-05-22 06:19:21 --> Router Class Initialized
INFO - 2023-05-22 06:19:21 --> Output Class Initialized
INFO - 2023-05-22 06:19:21 --> Security Class Initialized
DEBUG - 2023-05-22 06:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 06:19:21 --> Input Class Initialized
INFO - 2023-05-22 06:19:21 --> Language Class Initialized
INFO - 2023-05-22 06:19:21 --> Loader Class Initialized
INFO - 2023-05-22 06:19:21 --> Controller Class Initialized
DEBUG - 2023-05-22 06:19:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 06:19:21 --> Database Driver Class Initialized
INFO - 2023-05-22 06:19:21 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:11:08 --> Config Class Initialized
INFO - 2023-05-22 08:11:08 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:11:08 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:11:08 --> Utf8 Class Initialized
INFO - 2023-05-22 08:11:08 --> URI Class Initialized
INFO - 2023-05-22 08:11:08 --> Router Class Initialized
INFO - 2023-05-22 08:11:08 --> Output Class Initialized
INFO - 2023-05-22 08:11:08 --> Security Class Initialized
DEBUG - 2023-05-22 08:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:11:08 --> Input Class Initialized
INFO - 2023-05-22 08:11:08 --> Language Class Initialized
INFO - 2023-05-22 08:11:08 --> Loader Class Initialized
INFO - 2023-05-22 08:11:08 --> Controller Class Initialized
DEBUG - 2023-05-22 08:11:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:11:08 --> Database Driver Class Initialized
INFO - 2023-05-22 08:11:08 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:11:08 --> Final output sent to browser
DEBUG - 2023-05-22 08:11:08 --> Total execution time: 0.3415
INFO - 2023-05-22 08:11:09 --> Config Class Initialized
INFO - 2023-05-22 08:11:09 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:11:09 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:11:09 --> Utf8 Class Initialized
INFO - 2023-05-22 08:11:09 --> URI Class Initialized
INFO - 2023-05-22 08:11:09 --> Router Class Initialized
INFO - 2023-05-22 08:11:09 --> Output Class Initialized
INFO - 2023-05-22 08:11:09 --> Security Class Initialized
DEBUG - 2023-05-22 08:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:11:09 --> Input Class Initialized
INFO - 2023-05-22 08:11:09 --> Language Class Initialized
INFO - 2023-05-22 08:11:09 --> Loader Class Initialized
INFO - 2023-05-22 08:11:09 --> Controller Class Initialized
DEBUG - 2023-05-22 08:11:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:11:09 --> Database Driver Class Initialized
INFO - 2023-05-22 08:11:09 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:11:09 --> Final output sent to browser
DEBUG - 2023-05-22 08:11:09 --> Total execution time: 0.3011
INFO - 2023-05-22 08:16:34 --> Config Class Initialized
INFO - 2023-05-22 08:16:34 --> Config Class Initialized
INFO - 2023-05-22 08:16:34 --> Config Class Initialized
INFO - 2023-05-22 08:16:34 --> Hooks Class Initialized
INFO - 2023-05-22 08:16:34 --> Hooks Class Initialized
INFO - 2023-05-22 08:16:34 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:16:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 08:16:34 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:16:34 --> Utf8 Class Initialized
INFO - 2023-05-22 08:16:34 --> Utf8 Class Initialized
INFO - 2023-05-22 08:16:34 --> Utf8 Class Initialized
INFO - 2023-05-22 08:16:34 --> URI Class Initialized
INFO - 2023-05-22 08:16:34 --> URI Class Initialized
INFO - 2023-05-22 08:16:34 --> URI Class Initialized
INFO - 2023-05-22 08:16:34 --> Router Class Initialized
INFO - 2023-05-22 08:16:34 --> Router Class Initialized
INFO - 2023-05-22 08:16:34 --> Router Class Initialized
INFO - 2023-05-22 08:16:34 --> Output Class Initialized
INFO - 2023-05-22 08:16:34 --> Output Class Initialized
INFO - 2023-05-22 08:16:34 --> Output Class Initialized
INFO - 2023-05-22 08:16:34 --> Security Class Initialized
INFO - 2023-05-22 08:16:34 --> Security Class Initialized
INFO - 2023-05-22 08:16:34 --> Security Class Initialized
DEBUG - 2023-05-22 08:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:16:34 --> Input Class Initialized
INFO - 2023-05-22 08:16:34 --> Input Class Initialized
INFO - 2023-05-22 08:16:34 --> Input Class Initialized
INFO - 2023-05-22 08:16:34 --> Language Class Initialized
INFO - 2023-05-22 08:16:34 --> Language Class Initialized
INFO - 2023-05-22 08:16:34 --> Language Class Initialized
INFO - 2023-05-22 08:16:34 --> Loader Class Initialized
INFO - 2023-05-22 08:16:34 --> Loader Class Initialized
INFO - 2023-05-22 08:16:34 --> Controller Class Initialized
INFO - 2023-05-22 08:16:34 --> Controller Class Initialized
INFO - 2023-05-22 08:16:34 --> Loader Class Initialized
DEBUG - 2023-05-22 08:16:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 08:16:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:16:34 --> Controller Class Initialized
DEBUG - 2023-05-22 08:16:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:16:34 --> Database Driver Class Initialized
INFO - 2023-05-22 08:16:34 --> Database Driver Class Initialized
INFO - 2023-05-22 08:16:34 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:16:34 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:16:34 --> Final output sent to browser
INFO - 2023-05-22 08:16:34 --> Final output sent to browser
DEBUG - 2023-05-22 08:16:34 --> Total execution time: 0.2526
DEBUG - 2023-05-22 08:16:34 --> Total execution time: 0.2525
INFO - 2023-05-22 08:16:34 --> Database Driver Class Initialized
INFO - 2023-05-22 08:16:34 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:16:34 --> Final output sent to browser
DEBUG - 2023-05-22 08:16:34 --> Total execution time: 0.2951
INFO - 2023-05-22 08:16:34 --> Config Class Initialized
INFO - 2023-05-22 08:16:34 --> Hooks Class Initialized
INFO - 2023-05-22 08:16:34 --> Config Class Initialized
INFO - 2023-05-22 08:16:34 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:16:34 --> Utf8 Class Initialized
INFO - 2023-05-22 08:16:34 --> Config Class Initialized
INFO - 2023-05-22 08:16:34 --> Hooks Class Initialized
INFO - 2023-05-22 08:16:34 --> URI Class Initialized
DEBUG - 2023-05-22 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:16:34 --> Utf8 Class Initialized
DEBUG - 2023-05-22 08:16:34 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:16:34 --> Router Class Initialized
INFO - 2023-05-22 08:16:34 --> Utf8 Class Initialized
INFO - 2023-05-22 08:16:34 --> URI Class Initialized
INFO - 2023-05-22 08:16:34 --> URI Class Initialized
INFO - 2023-05-22 08:16:34 --> Output Class Initialized
INFO - 2023-05-22 08:16:34 --> Router Class Initialized
INFO - 2023-05-22 08:16:34 --> Router Class Initialized
INFO - 2023-05-22 08:16:34 --> Security Class Initialized
INFO - 2023-05-22 08:16:34 --> Output Class Initialized
INFO - 2023-05-22 08:16:34 --> Output Class Initialized
DEBUG - 2023-05-22 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:16:34 --> Security Class Initialized
INFO - 2023-05-22 08:16:34 --> Input Class Initialized
INFO - 2023-05-22 08:16:34 --> Security Class Initialized
DEBUG - 2023-05-22 08:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:16:34 --> Language Class Initialized
INFO - 2023-05-22 08:16:34 --> Input Class Initialized
INFO - 2023-05-22 08:16:34 --> Input Class Initialized
INFO - 2023-05-22 08:16:34 --> Language Class Initialized
INFO - 2023-05-22 08:16:34 --> Language Class Initialized
INFO - 2023-05-22 08:16:34 --> Loader Class Initialized
INFO - 2023-05-22 08:16:34 --> Loader Class Initialized
INFO - 2023-05-22 08:16:34 --> Controller Class Initialized
DEBUG - 2023-05-22 08:16:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:16:34 --> Loader Class Initialized
INFO - 2023-05-22 08:16:34 --> Controller Class Initialized
INFO - 2023-05-22 08:16:34 --> Controller Class Initialized
DEBUG - 2023-05-22 08:16:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 08:16:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:16:34 --> Database Driver Class Initialized
INFO - 2023-05-22 08:16:34 --> Database Driver Class Initialized
INFO - 2023-05-22 08:16:34 --> Database Driver Class Initialized
INFO - 2023-05-22 08:16:34 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:16:34 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:16:34 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:16:34 --> Final output sent to browser
DEBUG - 2023-05-22 08:16:34 --> Total execution time: 0.3029
INFO - 2023-05-22 08:16:34 --> Final output sent to browser
INFO - 2023-05-22 08:16:34 --> Final output sent to browser
DEBUG - 2023-05-22 08:16:34 --> Total execution time: 0.3049
DEBUG - 2023-05-22 08:16:34 --> Total execution time: 0.2675
INFO - 2023-05-22 08:16:34 --> Config Class Initialized
INFO - 2023-05-22 08:16:34 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:16:35 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:16:35 --> Utf8 Class Initialized
INFO - 2023-05-22 08:16:35 --> URI Class Initialized
INFO - 2023-05-22 08:16:35 --> Router Class Initialized
INFO - 2023-05-22 08:16:35 --> Output Class Initialized
INFO - 2023-05-22 08:16:35 --> Security Class Initialized
DEBUG - 2023-05-22 08:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:16:35 --> Input Class Initialized
INFO - 2023-05-22 08:16:35 --> Language Class Initialized
INFO - 2023-05-22 08:16:35 --> Loader Class Initialized
INFO - 2023-05-22 08:16:35 --> Controller Class Initialized
DEBUG - 2023-05-22 08:16:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:16:35 --> Database Driver Class Initialized
INFO - 2023-05-22 08:16:36 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:16:36 --> Config Class Initialized
INFO - 2023-05-22 08:16:36 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:16:36 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:16:36 --> Utf8 Class Initialized
INFO - 2023-05-22 08:16:36 --> URI Class Initialized
INFO - 2023-05-22 08:16:36 --> Router Class Initialized
INFO - 2023-05-22 08:16:36 --> Output Class Initialized
INFO - 2023-05-22 08:16:36 --> Security Class Initialized
DEBUG - 2023-05-22 08:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:16:36 --> Input Class Initialized
INFO - 2023-05-22 08:16:36 --> Language Class Initialized
INFO - 2023-05-22 08:16:36 --> Loader Class Initialized
INFO - 2023-05-22 08:16:36 --> Controller Class Initialized
DEBUG - 2023-05-22 08:16:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:16:36 --> Database Driver Class Initialized
INFO - 2023-05-22 08:16:36 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:18:18 --> Config Class Initialized
INFO - 2023-05-22 08:18:18 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:18:18 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:18:18 --> Utf8 Class Initialized
INFO - 2023-05-22 08:18:18 --> URI Class Initialized
INFO - 2023-05-22 08:18:18 --> Router Class Initialized
INFO - 2023-05-22 08:18:18 --> Output Class Initialized
INFO - 2023-05-22 08:18:18 --> Security Class Initialized
DEBUG - 2023-05-22 08:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:18:18 --> Input Class Initialized
INFO - 2023-05-22 08:18:18 --> Language Class Initialized
INFO - 2023-05-22 08:18:18 --> Loader Class Initialized
INFO - 2023-05-22 08:18:18 --> Controller Class Initialized
DEBUG - 2023-05-22 08:18:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:18:19 --> Database Driver Class Initialized
INFO - 2023-05-22 08:18:19 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:18:19 --> Final output sent to browser
DEBUG - 2023-05-22 08:18:19 --> Total execution time: 0.2641
INFO - 2023-05-22 08:18:19 --> Config Class Initialized
INFO - 2023-05-22 08:18:19 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:18:19 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:18:19 --> Utf8 Class Initialized
INFO - 2023-05-22 08:18:19 --> URI Class Initialized
INFO - 2023-05-22 08:18:19 --> Router Class Initialized
INFO - 2023-05-22 08:18:19 --> Output Class Initialized
INFO - 2023-05-22 08:18:19 --> Security Class Initialized
DEBUG - 2023-05-22 08:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:18:19 --> Input Class Initialized
INFO - 2023-05-22 08:18:19 --> Language Class Initialized
INFO - 2023-05-22 08:18:19 --> Loader Class Initialized
INFO - 2023-05-22 08:18:19 --> Controller Class Initialized
DEBUG - 2023-05-22 08:18:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:18:19 --> Database Driver Class Initialized
INFO - 2023-05-22 08:18:19 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:18:19 --> Final output sent to browser
DEBUG - 2023-05-22 08:18:19 --> Total execution time: 0.2732
INFO - 2023-05-22 08:25:25 --> Config Class Initialized
INFO - 2023-05-22 08:25:25 --> Config Class Initialized
INFO - 2023-05-22 08:25:25 --> Config Class Initialized
INFO - 2023-05-22 08:25:25 --> Hooks Class Initialized
INFO - 2023-05-22 08:25:25 --> Hooks Class Initialized
INFO - 2023-05-22 08:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 08:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:25:25 --> Utf8 Class Initialized
INFO - 2023-05-22 08:25:25 --> Utf8 Class Initialized
INFO - 2023-05-22 08:25:25 --> Utf8 Class Initialized
INFO - 2023-05-22 08:25:25 --> URI Class Initialized
INFO - 2023-05-22 08:25:25 --> URI Class Initialized
INFO - 2023-05-22 08:25:25 --> URI Class Initialized
INFO - 2023-05-22 08:25:25 --> Router Class Initialized
INFO - 2023-05-22 08:25:25 --> Router Class Initialized
INFO - 2023-05-22 08:25:25 --> Router Class Initialized
INFO - 2023-05-22 08:25:25 --> Output Class Initialized
INFO - 2023-05-22 08:25:25 --> Output Class Initialized
INFO - 2023-05-22 08:25:25 --> Output Class Initialized
INFO - 2023-05-22 08:25:25 --> Security Class Initialized
INFO - 2023-05-22 08:25:25 --> Security Class Initialized
INFO - 2023-05-22 08:25:25 --> Security Class Initialized
DEBUG - 2023-05-22 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:25:25 --> Input Class Initialized
INFO - 2023-05-22 08:25:25 --> Input Class Initialized
INFO - 2023-05-22 08:25:25 --> Input Class Initialized
INFO - 2023-05-22 08:25:25 --> Language Class Initialized
INFO - 2023-05-22 08:25:25 --> Language Class Initialized
INFO - 2023-05-22 08:25:25 --> Language Class Initialized
INFO - 2023-05-22 08:25:25 --> Loader Class Initialized
INFO - 2023-05-22 08:25:25 --> Loader Class Initialized
INFO - 2023-05-22 08:25:25 --> Controller Class Initialized
INFO - 2023-05-22 08:25:25 --> Controller Class Initialized
INFO - 2023-05-22 08:25:25 --> Loader Class Initialized
DEBUG - 2023-05-22 08:25:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 08:25:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:25:25 --> Controller Class Initialized
DEBUG - 2023-05-22 08:25:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:25:25 --> Database Driver Class Initialized
INFO - 2023-05-22 08:25:25 --> Database Driver Class Initialized
INFO - 2023-05-22 08:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:25:25 --> Final output sent to browser
INFO - 2023-05-22 08:25:25 --> Final output sent to browser
INFO - 2023-05-22 08:25:25 --> Database Driver Class Initialized
DEBUG - 2023-05-22 08:25:25 --> Total execution time: 0.2092
DEBUG - 2023-05-22 08:25:25 --> Total execution time: 0.2093
INFO - 2023-05-22 08:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:25:25 --> Final output sent to browser
DEBUG - 2023-05-22 08:25:25 --> Total execution time: 0.2300
INFO - 2023-05-22 08:25:25 --> Config Class Initialized
INFO - 2023-05-22 08:25:25 --> Config Class Initialized
INFO - 2023-05-22 08:25:25 --> Hooks Class Initialized
INFO - 2023-05-22 08:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 08:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:25:25 --> Utf8 Class Initialized
INFO - 2023-05-22 08:25:25 --> Utf8 Class Initialized
INFO - 2023-05-22 08:25:25 --> Config Class Initialized
INFO - 2023-05-22 08:25:25 --> URI Class Initialized
INFO - 2023-05-22 08:25:25 --> URI Class Initialized
INFO - 2023-05-22 08:25:25 --> Hooks Class Initialized
INFO - 2023-05-22 08:25:25 --> Router Class Initialized
INFO - 2023-05-22 08:25:25 --> Router Class Initialized
INFO - 2023-05-22 08:25:25 --> Output Class Initialized
INFO - 2023-05-22 08:25:25 --> Output Class Initialized
DEBUG - 2023-05-22 08:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:25:25 --> Security Class Initialized
INFO - 2023-05-22 08:25:25 --> Utf8 Class Initialized
INFO - 2023-05-22 08:25:25 --> Security Class Initialized
INFO - 2023-05-22 08:25:25 --> URI Class Initialized
DEBUG - 2023-05-22 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:25:25 --> Input Class Initialized
INFO - 2023-05-22 08:25:25 --> Input Class Initialized
INFO - 2023-05-22 08:25:25 --> Language Class Initialized
INFO - 2023-05-22 08:25:25 --> Language Class Initialized
INFO - 2023-05-22 08:25:25 --> Router Class Initialized
INFO - 2023-05-22 08:25:25 --> Loader Class Initialized
INFO - 2023-05-22 08:25:25 --> Loader Class Initialized
INFO - 2023-05-22 08:25:25 --> Output Class Initialized
INFO - 2023-05-22 08:25:25 --> Controller Class Initialized
INFO - 2023-05-22 08:25:25 --> Controller Class Initialized
DEBUG - 2023-05-22 08:25:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 08:25:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:25:25 --> Security Class Initialized
DEBUG - 2023-05-22 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:25:25 --> Input Class Initialized
INFO - 2023-05-22 08:25:25 --> Language Class Initialized
INFO - 2023-05-22 08:25:25 --> Database Driver Class Initialized
INFO - 2023-05-22 08:25:25 --> Database Driver Class Initialized
INFO - 2023-05-22 08:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:25:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:25:25 --> Final output sent to browser
INFO - 2023-05-22 08:25:25 --> Loader Class Initialized
INFO - 2023-05-22 08:25:25 --> Final output sent to browser
DEBUG - 2023-05-22 08:25:25 --> Total execution time: 0.2077
DEBUG - 2023-05-22 08:25:25 --> Total execution time: 0.2084
INFO - 2023-05-22 08:25:25 --> Controller Class Initialized
DEBUG - 2023-05-22 08:25:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:25:25 --> Database Driver Class Initialized
INFO - 2023-05-22 08:25:25 --> Config Class Initialized
INFO - 2023-05-22 08:25:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:25:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:25:25 --> Utf8 Class Initialized
INFO - 2023-05-22 08:25:25 --> URI Class Initialized
INFO - 2023-05-22 08:25:25 --> Router Class Initialized
INFO - 2023-05-22 08:25:25 --> Output Class Initialized
INFO - 2023-05-22 08:25:26 --> Security Class Initialized
DEBUG - 2023-05-22 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:25:26 --> Input Class Initialized
INFO - 2023-05-22 08:25:26 --> Language Class Initialized
INFO - 2023-05-22 08:25:26 --> Loader Class Initialized
INFO - 2023-05-22 08:25:26 --> Controller Class Initialized
DEBUG - 2023-05-22 08:25:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:25:26 --> Database Driver Class Initialized
INFO - 2023-05-22 08:25:26 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:25:26 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:25:26 --> Final output sent to browser
DEBUG - 2023-05-22 08:25:26 --> Total execution time: 0.4851
INFO - 2023-05-22 08:25:26 --> Config Class Initialized
INFO - 2023-05-22 08:25:26 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:25:26 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:25:26 --> Utf8 Class Initialized
INFO - 2023-05-22 08:25:26 --> URI Class Initialized
INFO - 2023-05-22 08:25:26 --> Router Class Initialized
INFO - 2023-05-22 08:25:26 --> Output Class Initialized
INFO - 2023-05-22 08:25:26 --> Security Class Initialized
DEBUG - 2023-05-22 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:25:26 --> Input Class Initialized
INFO - 2023-05-22 08:25:26 --> Language Class Initialized
INFO - 2023-05-22 08:25:26 --> Loader Class Initialized
INFO - 2023-05-22 08:25:26 --> Controller Class Initialized
DEBUG - 2023-05-22 08:25:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:25:26 --> Database Driver Class Initialized
INFO - 2023-05-22 08:25:26 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:28:09 --> Config Class Initialized
INFO - 2023-05-22 08:28:09 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:28:09 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:28:09 --> Utf8 Class Initialized
INFO - 2023-05-22 08:28:09 --> URI Class Initialized
INFO - 2023-05-22 08:28:10 --> Router Class Initialized
INFO - 2023-05-22 08:28:10 --> Output Class Initialized
INFO - 2023-05-22 08:28:10 --> Security Class Initialized
DEBUG - 2023-05-22 08:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:28:10 --> Input Class Initialized
INFO - 2023-05-22 08:28:10 --> Language Class Initialized
INFO - 2023-05-22 08:28:10 --> Loader Class Initialized
INFO - 2023-05-22 08:28:10 --> Controller Class Initialized
DEBUG - 2023-05-22 08:28:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:28:10 --> Database Driver Class Initialized
INFO - 2023-05-22 08:28:10 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:28:10 --> Final output sent to browser
DEBUG - 2023-05-22 08:28:10 --> Total execution time: 0.7201
INFO - 2023-05-22 08:28:10 --> Config Class Initialized
INFO - 2023-05-22 08:28:10 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:28:11 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:28:11 --> Utf8 Class Initialized
INFO - 2023-05-22 08:28:11 --> URI Class Initialized
INFO - 2023-05-22 08:28:11 --> Router Class Initialized
INFO - 2023-05-22 08:28:11 --> Output Class Initialized
INFO - 2023-05-22 08:28:11 --> Security Class Initialized
DEBUG - 2023-05-22 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:28:11 --> Input Class Initialized
INFO - 2023-05-22 08:28:11 --> Language Class Initialized
INFO - 2023-05-22 08:28:11 --> Loader Class Initialized
INFO - 2023-05-22 08:28:11 --> Controller Class Initialized
DEBUG - 2023-05-22 08:28:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:28:11 --> Database Driver Class Initialized
INFO - 2023-05-22 08:28:11 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:28:11 --> Final output sent to browser
DEBUG - 2023-05-22 08:28:11 --> Total execution time: 0.9403
INFO - 2023-05-22 08:30:09 --> Config Class Initialized
INFO - 2023-05-22 08:30:09 --> Config Class Initialized
INFO - 2023-05-22 08:30:09 --> Config Class Initialized
INFO - 2023-05-22 08:30:09 --> Hooks Class Initialized
INFO - 2023-05-22 08:30:09 --> Hooks Class Initialized
INFO - 2023-05-22 08:30:09 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 08:30:09 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:30:09 --> Utf8 Class Initialized
INFO - 2023-05-22 08:30:09 --> Utf8 Class Initialized
INFO - 2023-05-22 08:30:09 --> Utf8 Class Initialized
INFO - 2023-05-22 08:30:09 --> URI Class Initialized
INFO - 2023-05-22 08:30:09 --> URI Class Initialized
INFO - 2023-05-22 08:30:09 --> URI Class Initialized
INFO - 2023-05-22 08:30:09 --> Router Class Initialized
INFO - 2023-05-22 08:30:09 --> Router Class Initialized
INFO - 2023-05-22 08:30:09 --> Router Class Initialized
INFO - 2023-05-22 08:30:09 --> Output Class Initialized
INFO - 2023-05-22 08:30:09 --> Output Class Initialized
INFO - 2023-05-22 08:30:09 --> Output Class Initialized
INFO - 2023-05-22 08:30:09 --> Security Class Initialized
INFO - 2023-05-22 08:30:09 --> Security Class Initialized
INFO - 2023-05-22 08:30:09 --> Security Class Initialized
DEBUG - 2023-05-22 08:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:30:09 --> Input Class Initialized
INFO - 2023-05-22 08:30:09 --> Input Class Initialized
INFO - 2023-05-22 08:30:09 --> Input Class Initialized
INFO - 2023-05-22 08:30:09 --> Language Class Initialized
INFO - 2023-05-22 08:30:09 --> Language Class Initialized
INFO - 2023-05-22 08:30:09 --> Language Class Initialized
INFO - 2023-05-22 08:30:09 --> Loader Class Initialized
INFO - 2023-05-22 08:30:09 --> Loader Class Initialized
INFO - 2023-05-22 08:30:09 --> Controller Class Initialized
INFO - 2023-05-22 08:30:09 --> Controller Class Initialized
DEBUG - 2023-05-22 08:30:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 08:30:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:30:09 --> Loader Class Initialized
INFO - 2023-05-22 08:30:09 --> Controller Class Initialized
INFO - 2023-05-22 08:30:09 --> Database Driver Class Initialized
DEBUG - 2023-05-22 08:30:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:30:09 --> Database Driver Class Initialized
INFO - 2023-05-22 08:30:09 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:30:09 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:30:09 --> Final output sent to browser
INFO - 2023-05-22 08:30:09 --> Final output sent to browser
DEBUG - 2023-05-22 08:30:09 --> Total execution time: 0.4028
DEBUG - 2023-05-22 08:30:09 --> Total execution time: 0.3998
INFO - 2023-05-22 08:30:09 --> Database Driver Class Initialized
INFO - 2023-05-22 08:30:09 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:30:09 --> Final output sent to browser
INFO - 2023-05-22 08:30:09 --> Config Class Initialized
INFO - 2023-05-22 08:30:09 --> Config Class Initialized
DEBUG - 2023-05-22 08:30:09 --> Total execution time: 0.4798
INFO - 2023-05-22 08:30:09 --> Hooks Class Initialized
INFO - 2023-05-22 08:30:09 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 08:30:09 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:30:09 --> Utf8 Class Initialized
INFO - 2023-05-22 08:30:09 --> Utf8 Class Initialized
INFO - 2023-05-22 08:30:09 --> URI Class Initialized
INFO - 2023-05-22 08:30:09 --> URI Class Initialized
INFO - 2023-05-22 08:30:09 --> Router Class Initialized
INFO - 2023-05-22 08:30:09 --> Router Class Initialized
INFO - 2023-05-22 08:30:09 --> Output Class Initialized
INFO - 2023-05-22 08:30:09 --> Output Class Initialized
INFO - 2023-05-22 08:30:09 --> Config Class Initialized
INFO - 2023-05-22 08:30:09 --> Hooks Class Initialized
INFO - 2023-05-22 08:30:09 --> Security Class Initialized
INFO - 2023-05-22 08:30:09 --> Security Class Initialized
DEBUG - 2023-05-22 08:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 08:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:30:09 --> Input Class Initialized
INFO - 2023-05-22 08:30:09 --> Input Class Initialized
INFO - 2023-05-22 08:30:09 --> Language Class Initialized
INFO - 2023-05-22 08:30:09 --> Language Class Initialized
DEBUG - 2023-05-22 08:30:09 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:30:09 --> Utf8 Class Initialized
INFO - 2023-05-22 08:30:09 --> Loader Class Initialized
INFO - 2023-05-22 08:30:09 --> Loader Class Initialized
INFO - 2023-05-22 08:30:09 --> URI Class Initialized
INFO - 2023-05-22 08:30:09 --> Controller Class Initialized
INFO - 2023-05-22 08:30:09 --> Controller Class Initialized
DEBUG - 2023-05-22 08:30:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 08:30:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:30:09 --> Router Class Initialized
INFO - 2023-05-22 08:30:09 --> Output Class Initialized
INFO - 2023-05-22 08:30:10 --> Database Driver Class Initialized
INFO - 2023-05-22 08:30:10 --> Database Driver Class Initialized
INFO - 2023-05-22 08:30:10 --> Security Class Initialized
DEBUG - 2023-05-22 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:30:10 --> Input Class Initialized
INFO - 2023-05-22 08:30:10 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:30:10 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:30:10 --> Language Class Initialized
INFO - 2023-05-22 08:30:10 --> Final output sent to browser
DEBUG - 2023-05-22 08:30:10 --> Total execution time: 0.3955
INFO - 2023-05-22 08:30:10 --> Final output sent to browser
DEBUG - 2023-05-22 08:30:10 --> Total execution time: 0.4116
INFO - 2023-05-22 08:30:10 --> Loader Class Initialized
INFO - 2023-05-22 08:30:10 --> Controller Class Initialized
DEBUG - 2023-05-22 08:30:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:30:10 --> Config Class Initialized
INFO - 2023-05-22 08:30:10 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:30:10 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:30:10 --> Database Driver Class Initialized
INFO - 2023-05-22 08:30:10 --> Utf8 Class Initialized
INFO - 2023-05-22 08:30:10 --> URI Class Initialized
INFO - 2023-05-22 08:30:10 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:30:10 --> Router Class Initialized
INFO - 2023-05-22 08:30:10 --> Final output sent to browser
INFO - 2023-05-22 08:30:10 --> Output Class Initialized
DEBUG - 2023-05-22 08:30:10 --> Total execution time: 0.5542
INFO - 2023-05-22 08:30:10 --> Security Class Initialized
DEBUG - 2023-05-22 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:30:10 --> Input Class Initialized
INFO - 2023-05-22 08:30:10 --> Language Class Initialized
INFO - 2023-05-22 08:30:10 --> Loader Class Initialized
INFO - 2023-05-22 08:30:10 --> Controller Class Initialized
DEBUG - 2023-05-22 08:30:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:30:10 --> Database Driver Class Initialized
INFO - 2023-05-22 08:30:10 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:30:10 --> Config Class Initialized
INFO - 2023-05-22 08:30:10 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:30:10 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:30:10 --> Utf8 Class Initialized
INFO - 2023-05-22 08:30:10 --> URI Class Initialized
INFO - 2023-05-22 08:30:10 --> Router Class Initialized
INFO - 2023-05-22 08:30:10 --> Output Class Initialized
INFO - 2023-05-22 08:30:10 --> Security Class Initialized
DEBUG - 2023-05-22 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:30:10 --> Input Class Initialized
INFO - 2023-05-22 08:30:11 --> Language Class Initialized
INFO - 2023-05-22 08:30:11 --> Loader Class Initialized
INFO - 2023-05-22 08:30:11 --> Controller Class Initialized
DEBUG - 2023-05-22 08:30:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:30:11 --> Database Driver Class Initialized
INFO - 2023-05-22 08:30:11 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:31:07 --> Config Class Initialized
INFO - 2023-05-22 08:31:07 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:31:07 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:31:07 --> Utf8 Class Initialized
INFO - 2023-05-22 08:31:07 --> URI Class Initialized
INFO - 2023-05-22 08:31:08 --> Router Class Initialized
INFO - 2023-05-22 08:31:08 --> Output Class Initialized
INFO - 2023-05-22 08:31:08 --> Security Class Initialized
DEBUG - 2023-05-22 08:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:31:08 --> Input Class Initialized
INFO - 2023-05-22 08:31:08 --> Language Class Initialized
INFO - 2023-05-22 08:31:08 --> Loader Class Initialized
INFO - 2023-05-22 08:31:08 --> Controller Class Initialized
DEBUG - 2023-05-22 08:31:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:31:08 --> Database Driver Class Initialized
INFO - 2023-05-22 08:31:08 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:31:08 --> Final output sent to browser
DEBUG - 2023-05-22 08:31:08 --> Total execution time: 0.5166
INFO - 2023-05-22 08:31:08 --> Config Class Initialized
INFO - 2023-05-22 08:31:08 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:31:08 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:31:08 --> Utf8 Class Initialized
INFO - 2023-05-22 08:31:08 --> URI Class Initialized
INFO - 2023-05-22 08:31:08 --> Router Class Initialized
INFO - 2023-05-22 08:31:08 --> Output Class Initialized
INFO - 2023-05-22 08:31:08 --> Security Class Initialized
DEBUG - 2023-05-22 08:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:31:08 --> Input Class Initialized
INFO - 2023-05-22 08:31:08 --> Language Class Initialized
INFO - 2023-05-22 08:31:08 --> Loader Class Initialized
INFO - 2023-05-22 08:31:08 --> Controller Class Initialized
DEBUG - 2023-05-22 08:31:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:31:08 --> Database Driver Class Initialized
INFO - 2023-05-22 08:31:08 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:31:08 --> Final output sent to browser
DEBUG - 2023-05-22 08:31:08 --> Total execution time: 0.4344
INFO - 2023-05-22 08:31:11 --> Config Class Initialized
INFO - 2023-05-22 08:31:11 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:31:11 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:31:11 --> Utf8 Class Initialized
INFO - 2023-05-22 08:31:11 --> URI Class Initialized
INFO - 2023-05-22 08:31:11 --> Router Class Initialized
INFO - 2023-05-22 08:31:11 --> Output Class Initialized
INFO - 2023-05-22 08:31:11 --> Security Class Initialized
DEBUG - 2023-05-22 08:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:31:11 --> Input Class Initialized
INFO - 2023-05-22 08:31:11 --> Language Class Initialized
INFO - 2023-05-22 08:31:11 --> Loader Class Initialized
INFO - 2023-05-22 08:31:11 --> Controller Class Initialized
DEBUG - 2023-05-22 08:31:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:31:11 --> Final output sent to browser
DEBUG - 2023-05-22 08:31:11 --> Total execution time: 0.2372
INFO - 2023-05-22 08:31:11 --> Config Class Initialized
INFO - 2023-05-22 08:31:11 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:31:11 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:31:12 --> Utf8 Class Initialized
INFO - 2023-05-22 08:31:12 --> URI Class Initialized
INFO - 2023-05-22 08:31:12 --> Router Class Initialized
INFO - 2023-05-22 08:31:12 --> Output Class Initialized
INFO - 2023-05-22 08:31:12 --> Security Class Initialized
DEBUG - 2023-05-22 08:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:31:12 --> Input Class Initialized
INFO - 2023-05-22 08:31:12 --> Language Class Initialized
INFO - 2023-05-22 08:31:12 --> Loader Class Initialized
INFO - 2023-05-22 08:31:12 --> Controller Class Initialized
DEBUG - 2023-05-22 08:31:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:31:12 --> Database Driver Class Initialized
INFO - 2023-05-22 08:31:12 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:31:12 --> Final output sent to browser
DEBUG - 2023-05-22 08:31:12 --> Total execution time: 0.3330
INFO - 2023-05-22 08:31:19 --> Config Class Initialized
INFO - 2023-05-22 08:31:19 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:31:19 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:31:19 --> Utf8 Class Initialized
INFO - 2023-05-22 08:31:19 --> URI Class Initialized
INFO - 2023-05-22 08:31:19 --> Router Class Initialized
INFO - 2023-05-22 08:31:19 --> Output Class Initialized
INFO - 2023-05-22 08:31:19 --> Security Class Initialized
DEBUG - 2023-05-22 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:31:19 --> Input Class Initialized
INFO - 2023-05-22 08:31:19 --> Language Class Initialized
INFO - 2023-05-22 08:31:19 --> Loader Class Initialized
INFO - 2023-05-22 08:31:19 --> Controller Class Initialized
DEBUG - 2023-05-22 08:31:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:31:19 --> Database Driver Class Initialized
INFO - 2023-05-22 08:31:19 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:31:19 --> Final output sent to browser
DEBUG - 2023-05-22 08:31:19 --> Total execution time: 0.2561
INFO - 2023-05-22 08:31:19 --> Config Class Initialized
INFO - 2023-05-22 08:31:19 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:31:20 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:31:20 --> Utf8 Class Initialized
INFO - 2023-05-22 08:31:20 --> URI Class Initialized
INFO - 2023-05-22 08:31:20 --> Router Class Initialized
INFO - 2023-05-22 08:31:20 --> Output Class Initialized
INFO - 2023-05-22 08:31:20 --> Security Class Initialized
DEBUG - 2023-05-22 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:31:20 --> Input Class Initialized
INFO - 2023-05-22 08:31:20 --> Language Class Initialized
INFO - 2023-05-22 08:31:20 --> Loader Class Initialized
INFO - 2023-05-22 08:31:20 --> Controller Class Initialized
DEBUG - 2023-05-22 08:31:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:31:20 --> Database Driver Class Initialized
INFO - 2023-05-22 08:31:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:31:20 --> Final output sent to browser
DEBUG - 2023-05-22 08:31:20 --> Total execution time: 0.3697
INFO - 2023-05-22 08:32:30 --> Config Class Initialized
INFO - 2023-05-22 08:32:30 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:32:30 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:32:30 --> Utf8 Class Initialized
INFO - 2023-05-22 08:32:30 --> URI Class Initialized
INFO - 2023-05-22 08:32:30 --> Router Class Initialized
INFO - 2023-05-22 08:32:30 --> Output Class Initialized
INFO - 2023-05-22 08:32:30 --> Security Class Initialized
DEBUG - 2023-05-22 08:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:32:30 --> Input Class Initialized
INFO - 2023-05-22 08:32:30 --> Language Class Initialized
INFO - 2023-05-22 08:32:30 --> Loader Class Initialized
INFO - 2023-05-22 08:32:30 --> Controller Class Initialized
DEBUG - 2023-05-22 08:32:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:32:30 --> Final output sent to browser
DEBUG - 2023-05-22 08:32:30 --> Total execution time: 0.1757
INFO - 2023-05-22 08:32:31 --> Config Class Initialized
INFO - 2023-05-22 08:32:31 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:32:31 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:32:31 --> Utf8 Class Initialized
INFO - 2023-05-22 08:32:31 --> URI Class Initialized
INFO - 2023-05-22 08:32:31 --> Router Class Initialized
INFO - 2023-05-22 08:32:31 --> Output Class Initialized
INFO - 2023-05-22 08:32:31 --> Security Class Initialized
DEBUG - 2023-05-22 08:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:32:31 --> Input Class Initialized
INFO - 2023-05-22 08:32:31 --> Language Class Initialized
INFO - 2023-05-22 08:32:31 --> Loader Class Initialized
INFO - 2023-05-22 08:32:31 --> Controller Class Initialized
DEBUG - 2023-05-22 08:32:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:32:31 --> Database Driver Class Initialized
INFO - 2023-05-22 08:32:31 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:32:31 --> Final output sent to browser
DEBUG - 2023-05-22 08:32:31 --> Total execution time: 0.3224
INFO - 2023-05-22 08:40:55 --> Config Class Initialized
INFO - 2023-05-22 08:40:55 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:40:55 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:40:55 --> Utf8 Class Initialized
INFO - 2023-05-22 08:40:55 --> URI Class Initialized
INFO - 2023-05-22 08:40:55 --> Router Class Initialized
INFO - 2023-05-22 08:40:55 --> Output Class Initialized
INFO - 2023-05-22 08:40:55 --> Security Class Initialized
DEBUG - 2023-05-22 08:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:40:55 --> Input Class Initialized
INFO - 2023-05-22 08:40:56 --> Language Class Initialized
INFO - 2023-05-22 08:40:56 --> Loader Class Initialized
INFO - 2023-05-22 08:40:56 --> Controller Class Initialized
DEBUG - 2023-05-22 08:40:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:40:56 --> Database Driver Class Initialized
INFO - 2023-05-22 08:40:56 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:40:56 --> Final output sent to browser
DEBUG - 2023-05-22 08:40:56 --> Total execution time: 0.4412
INFO - 2023-05-22 08:40:56 --> Config Class Initialized
INFO - 2023-05-22 08:40:56 --> Hooks Class Initialized
DEBUG - 2023-05-22 08:40:56 --> UTF-8 Support Enabled
INFO - 2023-05-22 08:40:56 --> Utf8 Class Initialized
INFO - 2023-05-22 08:40:56 --> URI Class Initialized
INFO - 2023-05-22 08:40:56 --> Router Class Initialized
INFO - 2023-05-22 08:40:56 --> Output Class Initialized
INFO - 2023-05-22 08:40:56 --> Security Class Initialized
DEBUG - 2023-05-22 08:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 08:40:56 --> Input Class Initialized
INFO - 2023-05-22 08:40:56 --> Language Class Initialized
INFO - 2023-05-22 08:40:56 --> Loader Class Initialized
INFO - 2023-05-22 08:40:56 --> Controller Class Initialized
DEBUG - 2023-05-22 08:40:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 08:40:56 --> Database Driver Class Initialized
INFO - 2023-05-22 08:40:56 --> Model "Cluster_model" initialized
INFO - 2023-05-22 08:40:56 --> Final output sent to browser
DEBUG - 2023-05-22 08:40:56 --> Total execution time: 0.2796
INFO - 2023-05-22 09:27:14 --> Config Class Initialized
INFO - 2023-05-22 09:27:14 --> Config Class Initialized
INFO - 2023-05-22 09:27:14 --> Config Class Initialized
INFO - 2023-05-22 09:27:14 --> Hooks Class Initialized
INFO - 2023-05-22 09:27:14 --> Hooks Class Initialized
INFO - 2023-05-22 09:27:14 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:27:14 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:27:14 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:27:14 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:27:14 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:14 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:14 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:14 --> URI Class Initialized
INFO - 2023-05-22 09:27:14 --> URI Class Initialized
INFO - 2023-05-22 09:27:14 --> URI Class Initialized
INFO - 2023-05-22 09:27:14 --> Router Class Initialized
INFO - 2023-05-22 09:27:14 --> Router Class Initialized
INFO - 2023-05-22 09:27:14 --> Router Class Initialized
INFO - 2023-05-22 09:27:14 --> Output Class Initialized
INFO - 2023-05-22 09:27:14 --> Output Class Initialized
INFO - 2023-05-22 09:27:14 --> Output Class Initialized
INFO - 2023-05-22 09:27:14 --> Security Class Initialized
INFO - 2023-05-22 09:27:14 --> Security Class Initialized
INFO - 2023-05-22 09:27:14 --> Security Class Initialized
DEBUG - 2023-05-22 09:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:14 --> Input Class Initialized
INFO - 2023-05-22 09:27:14 --> Input Class Initialized
INFO - 2023-05-22 09:27:14 --> Input Class Initialized
INFO - 2023-05-22 09:27:14 --> Language Class Initialized
INFO - 2023-05-22 09:27:14 --> Language Class Initialized
INFO - 2023-05-22 09:27:14 --> Language Class Initialized
INFO - 2023-05-22 09:27:14 --> Loader Class Initialized
INFO - 2023-05-22 09:27:14 --> Loader Class Initialized
INFO - 2023-05-22 09:27:14 --> Controller Class Initialized
INFO - 2023-05-22 09:27:14 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:14 --> Loader Class Initialized
DEBUG - 2023-05-22 09:27:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:14 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:14 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:14 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:14 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:15 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:15 --> Total execution time: 0.3942
INFO - 2023-05-22 09:27:15 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:15 --> Total execution time: 0.3980
INFO - 2023-05-22 09:27:15 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:15 --> Total execution time: 0.4235
INFO - 2023-05-22 09:27:15 --> Config Class Initialized
INFO - 2023-05-22 09:27:15 --> Config Class Initialized
INFO - 2023-05-22 09:27:15 --> Hooks Class Initialized
INFO - 2023-05-22 09:27:15 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:27:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:27:15 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:15 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:15 --> URI Class Initialized
INFO - 2023-05-22 09:27:15 --> URI Class Initialized
INFO - 2023-05-22 09:27:15 --> Config Class Initialized
INFO - 2023-05-22 09:27:15 --> Router Class Initialized
INFO - 2023-05-22 09:27:15 --> Router Class Initialized
INFO - 2023-05-22 09:27:15 --> Hooks Class Initialized
INFO - 2023-05-22 09:27:15 --> Output Class Initialized
INFO - 2023-05-22 09:27:15 --> Output Class Initialized
INFO - 2023-05-22 09:27:15 --> Security Class Initialized
INFO - 2023-05-22 09:27:15 --> Security Class Initialized
DEBUG - 2023-05-22 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:15 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:15 --> Input Class Initialized
INFO - 2023-05-22 09:27:15 --> Input Class Initialized
INFO - 2023-05-22 09:27:15 --> Language Class Initialized
INFO - 2023-05-22 09:27:15 --> URI Class Initialized
INFO - 2023-05-22 09:27:15 --> Language Class Initialized
INFO - 2023-05-22 09:27:15 --> Router Class Initialized
INFO - 2023-05-22 09:27:15 --> Loader Class Initialized
INFO - 2023-05-22 09:27:15 --> Output Class Initialized
INFO - 2023-05-22 09:27:15 --> Controller Class Initialized
INFO - 2023-05-22 09:27:15 --> Security Class Initialized
INFO - 2023-05-22 09:27:15 --> Loader Class Initialized
DEBUG - 2023-05-22 09:27:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:15 --> Input Class Initialized
INFO - 2023-05-22 09:27:15 --> Controller Class Initialized
INFO - 2023-05-22 09:27:15 --> Language Class Initialized
DEBUG - 2023-05-22 09:27:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:15 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:15 --> Loader Class Initialized
INFO - 2023-05-22 09:27:15 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:15 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:15 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:15 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:15 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:15 --> Total execution time: 0.4312
INFO - 2023-05-22 09:27:15 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:15 --> Total execution time: 0.4870
INFO - 2023-05-22 09:27:15 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:15 --> Total execution time: 0.4927
INFO - 2023-05-22 09:27:15 --> Config Class Initialized
INFO - 2023-05-22 09:27:15 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:27:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:27:15 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:15 --> URI Class Initialized
INFO - 2023-05-22 09:27:15 --> Router Class Initialized
INFO - 2023-05-22 09:27:15 --> Output Class Initialized
INFO - 2023-05-22 09:27:15 --> Security Class Initialized
DEBUG - 2023-05-22 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:15 --> Input Class Initialized
INFO - 2023-05-22 09:27:15 --> Language Class Initialized
INFO - 2023-05-22 09:27:15 --> Loader Class Initialized
INFO - 2023-05-22 09:27:15 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:15 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:16 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:16 --> Config Class Initialized
INFO - 2023-05-22 09:27:16 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:27:16 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:27:16 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:16 --> URI Class Initialized
INFO - 2023-05-22 09:27:16 --> Router Class Initialized
INFO - 2023-05-22 09:27:16 --> Output Class Initialized
INFO - 2023-05-22 09:27:16 --> Security Class Initialized
DEBUG - 2023-05-22 09:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:16 --> Input Class Initialized
INFO - 2023-05-22 09:27:16 --> Language Class Initialized
INFO - 2023-05-22 09:27:16 --> Loader Class Initialized
INFO - 2023-05-22 09:27:16 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:16 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:16 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:17 --> Config Class Initialized
INFO - 2023-05-22 09:27:17 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:27:17 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:27:17 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:17 --> URI Class Initialized
INFO - 2023-05-22 09:27:17 --> Router Class Initialized
INFO - 2023-05-22 09:27:17 --> Output Class Initialized
INFO - 2023-05-22 09:27:17 --> Security Class Initialized
DEBUG - 2023-05-22 09:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:18 --> Input Class Initialized
INFO - 2023-05-22 09:27:18 --> Language Class Initialized
INFO - 2023-05-22 09:27:18 --> Loader Class Initialized
INFO - 2023-05-22 09:27:18 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:18 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:18 --> Total execution time: 0.1788
INFO - 2023-05-22 09:27:18 --> Config Class Initialized
INFO - 2023-05-22 09:27:18 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:27:18 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:27:18 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:18 --> URI Class Initialized
INFO - 2023-05-22 09:27:18 --> Router Class Initialized
INFO - 2023-05-22 09:27:18 --> Output Class Initialized
INFO - 2023-05-22 09:27:18 --> Security Class Initialized
DEBUG - 2023-05-22 09:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:18 --> Input Class Initialized
INFO - 2023-05-22 09:27:18 --> Language Class Initialized
INFO - 2023-05-22 09:27:18 --> Loader Class Initialized
INFO - 2023-05-22 09:27:18 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:18 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:18 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:18 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:18 --> Total execution time: 0.4121
INFO - 2023-05-22 09:27:21 --> Config Class Initialized
INFO - 2023-05-22 09:27:21 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:27:21 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:27:21 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:21 --> URI Class Initialized
INFO - 2023-05-22 09:27:21 --> Router Class Initialized
INFO - 2023-05-22 09:27:21 --> Output Class Initialized
INFO - 2023-05-22 09:27:21 --> Security Class Initialized
DEBUG - 2023-05-22 09:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:21 --> Input Class Initialized
INFO - 2023-05-22 09:27:21 --> Language Class Initialized
INFO - 2023-05-22 09:27:21 --> Loader Class Initialized
INFO - 2023-05-22 09:27:21 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:21 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:21 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:21 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:21 --> Total execution time: 0.2550
INFO - 2023-05-22 09:27:21 --> Config Class Initialized
INFO - 2023-05-22 09:27:21 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:27:21 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:27:21 --> Utf8 Class Initialized
INFO - 2023-05-22 09:27:21 --> URI Class Initialized
INFO - 2023-05-22 09:27:21 --> Router Class Initialized
INFO - 2023-05-22 09:27:21 --> Output Class Initialized
INFO - 2023-05-22 09:27:21 --> Security Class Initialized
DEBUG - 2023-05-22 09:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:27:21 --> Input Class Initialized
INFO - 2023-05-22 09:27:21 --> Language Class Initialized
INFO - 2023-05-22 09:27:21 --> Loader Class Initialized
INFO - 2023-05-22 09:27:21 --> Controller Class Initialized
DEBUG - 2023-05-22 09:27:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:27:21 --> Database Driver Class Initialized
INFO - 2023-05-22 09:27:22 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:27:22 --> Final output sent to browser
DEBUG - 2023-05-22 09:27:22 --> Total execution time: 0.5023
INFO - 2023-05-22 09:31:00 --> Config Class Initialized
INFO - 2023-05-22 09:31:00 --> Config Class Initialized
INFO - 2023-05-22 09:31:00 --> Config Class Initialized
INFO - 2023-05-22 09:31:00 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:00 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:00 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:00 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:00 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:00 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:00 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:00 --> URI Class Initialized
INFO - 2023-05-22 09:31:00 --> URI Class Initialized
INFO - 2023-05-22 09:31:00 --> URI Class Initialized
INFO - 2023-05-22 09:31:00 --> Router Class Initialized
INFO - 2023-05-22 09:31:00 --> Router Class Initialized
INFO - 2023-05-22 09:31:00 --> Router Class Initialized
INFO - 2023-05-22 09:31:00 --> Output Class Initialized
INFO - 2023-05-22 09:31:00 --> Output Class Initialized
INFO - 2023-05-22 09:31:00 --> Output Class Initialized
INFO - 2023-05-22 09:31:00 --> Security Class Initialized
INFO - 2023-05-22 09:31:00 --> Security Class Initialized
INFO - 2023-05-22 09:31:00 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:00 --> Input Class Initialized
INFO - 2023-05-22 09:31:00 --> Input Class Initialized
INFO - 2023-05-22 09:31:00 --> Input Class Initialized
INFO - 2023-05-22 09:31:00 --> Language Class Initialized
INFO - 2023-05-22 09:31:00 --> Language Class Initialized
INFO - 2023-05-22 09:31:00 --> Language Class Initialized
INFO - 2023-05-22 09:31:00 --> Loader Class Initialized
INFO - 2023-05-22 09:31:00 --> Loader Class Initialized
INFO - 2023-05-22 09:31:00 --> Controller Class Initialized
INFO - 2023-05-22 09:31:00 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 09:31:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:00 --> Loader Class Initialized
INFO - 2023-05-22 09:31:00 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:00 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:00 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:00 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:00 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:00 --> Final output sent to browser
INFO - 2023-05-22 09:31:00 --> Database Driver Class Initialized
DEBUG - 2023-05-22 09:31:00 --> Total execution time: 0.2417
INFO - 2023-05-22 09:31:00 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:00 --> Total execution time: 0.2596
INFO - 2023-05-22 09:31:00 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:00 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:00 --> Total execution time: 0.2706
INFO - 2023-05-22 09:31:00 --> Config Class Initialized
INFO - 2023-05-22 09:31:00 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:00 --> Config Class Initialized
INFO - 2023-05-22 09:31:00 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:00 --> Config Class Initialized
INFO - 2023-05-22 09:31:00 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:00 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:00 --> Utf8 Class Initialized
DEBUG - 2023-05-22 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:00 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:00 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:00 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:00 --> URI Class Initialized
INFO - 2023-05-22 09:31:00 --> URI Class Initialized
INFO - 2023-05-22 09:31:00 --> URI Class Initialized
INFO - 2023-05-22 09:31:00 --> Router Class Initialized
INFO - 2023-05-22 09:31:00 --> Router Class Initialized
INFO - 2023-05-22 09:31:00 --> Router Class Initialized
INFO - 2023-05-22 09:31:01 --> Output Class Initialized
INFO - 2023-05-22 09:31:01 --> Output Class Initialized
INFO - 2023-05-22 09:31:01 --> Output Class Initialized
INFO - 2023-05-22 09:31:01 --> Security Class Initialized
INFO - 2023-05-22 09:31:01 --> Security Class Initialized
INFO - 2023-05-22 09:31:01 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:01 --> Input Class Initialized
INFO - 2023-05-22 09:31:01 --> Input Class Initialized
INFO - 2023-05-22 09:31:01 --> Input Class Initialized
INFO - 2023-05-22 09:31:01 --> Language Class Initialized
INFO - 2023-05-22 09:31:01 --> Language Class Initialized
INFO - 2023-05-22 09:31:01 --> Language Class Initialized
INFO - 2023-05-22 09:31:01 --> Loader Class Initialized
INFO - 2023-05-22 09:31:01 --> Loader Class Initialized
INFO - 2023-05-22 09:31:01 --> Controller Class Initialized
INFO - 2023-05-22 09:31:01 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:01 --> Loader Class Initialized
DEBUG - 2023-05-22 09:31:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:01 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:01 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:01 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:01 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:01 --> Final output sent to browser
INFO - 2023-05-22 09:31:01 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:01 --> Total execution time: 0.2387
DEBUG - 2023-05-22 09:31:01 --> Total execution time: 0.2572
INFO - 2023-05-22 09:31:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:01 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:01 --> Total execution time: 0.2720
INFO - 2023-05-22 09:31:01 --> Config Class Initialized
INFO - 2023-05-22 09:31:01 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:01 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:01 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:01 --> URI Class Initialized
INFO - 2023-05-22 09:31:01 --> Router Class Initialized
INFO - 2023-05-22 09:31:01 --> Output Class Initialized
INFO - 2023-05-22 09:31:01 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:01 --> Input Class Initialized
INFO - 2023-05-22 09:31:01 --> Language Class Initialized
INFO - 2023-05-22 09:31:01 --> Loader Class Initialized
INFO - 2023-05-22 09:31:01 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:01 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:01 --> Config Class Initialized
INFO - 2023-05-22 09:31:01 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:01 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:01 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:01 --> URI Class Initialized
INFO - 2023-05-22 09:31:01 --> Router Class Initialized
INFO - 2023-05-22 09:31:01 --> Output Class Initialized
INFO - 2023-05-22 09:31:01 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:01 --> Input Class Initialized
INFO - 2023-05-22 09:31:01 --> Language Class Initialized
INFO - 2023-05-22 09:31:01 --> Loader Class Initialized
INFO - 2023-05-22 09:31:01 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:01 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:03 --> Config Class Initialized
INFO - 2023-05-22 09:31:03 --> Config Class Initialized
INFO - 2023-05-22 09:31:03 --> Config Class Initialized
INFO - 2023-05-22 09:31:03 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:03 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:03 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:03 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:03 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:03 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:03 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:03 --> URI Class Initialized
INFO - 2023-05-22 09:31:03 --> URI Class Initialized
INFO - 2023-05-22 09:31:03 --> URI Class Initialized
INFO - 2023-05-22 09:31:03 --> Router Class Initialized
INFO - 2023-05-22 09:31:03 --> Router Class Initialized
INFO - 2023-05-22 09:31:03 --> Router Class Initialized
INFO - 2023-05-22 09:31:03 --> Output Class Initialized
INFO - 2023-05-22 09:31:03 --> Output Class Initialized
INFO - 2023-05-22 09:31:03 --> Output Class Initialized
INFO - 2023-05-22 09:31:03 --> Security Class Initialized
INFO - 2023-05-22 09:31:03 --> Security Class Initialized
INFO - 2023-05-22 09:31:03 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:03 --> Input Class Initialized
INFO - 2023-05-22 09:31:03 --> Input Class Initialized
INFO - 2023-05-22 09:31:03 --> Input Class Initialized
INFO - 2023-05-22 09:31:03 --> Language Class Initialized
INFO - 2023-05-22 09:31:03 --> Language Class Initialized
INFO - 2023-05-22 09:31:03 --> Language Class Initialized
INFO - 2023-05-22 09:31:03 --> Loader Class Initialized
INFO - 2023-05-22 09:31:03 --> Loader Class Initialized
INFO - 2023-05-22 09:31:03 --> Controller Class Initialized
INFO - 2023-05-22 09:31:03 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 09:31:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:03 --> Loader Class Initialized
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:03 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:03 --> Config Class Initialized
INFO - 2023-05-22 09:31:03 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:03 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:03 --> Model "Cluster_model" initialized
DEBUG - 2023-05-22 09:31:03 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:03 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:03 --> URI Class Initialized
INFO - 2023-05-22 09:31:03 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:03 --> Total execution time: 0.2763
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:03 --> Final output sent to browser
INFO - 2023-05-22 09:31:03 --> Router Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Total execution time: 0.2953
INFO - 2023-05-22 09:31:03 --> Output Class Initialized
INFO - 2023-05-22 09:31:03 --> Model "Login_model" initialized
INFO - 2023-05-22 09:31:03 --> Security Class Initialized
INFO - 2023-05-22 09:31:03 --> Config Class Initialized
INFO - 2023-05-22 09:31:03 --> Final output sent to browser
INFO - 2023-05-22 09:31:03 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Total execution time: 0.3519
DEBUG - 2023-05-22 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:03 --> Input Class Initialized
INFO - 2023-05-22 09:31:03 --> Config Class Initialized
INFO - 2023-05-22 09:31:03 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:03 --> Language Class Initialized
DEBUG - 2023-05-22 09:31:03 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:03 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:03 --> URI Class Initialized
DEBUG - 2023-05-22 09:31:03 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:03 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:03 --> Loader Class Initialized
INFO - 2023-05-22 09:31:03 --> Config Class Initialized
INFO - 2023-05-22 09:31:03 --> URI Class Initialized
INFO - 2023-05-22 09:31:03 --> Router Class Initialized
INFO - 2023-05-22 09:31:03 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:03 --> Controller Class Initialized
INFO - 2023-05-22 09:31:03 --> Output Class Initialized
INFO - 2023-05-22 09:31:03 --> Router Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:03 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:03 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:03 --> Output Class Initialized
INFO - 2023-05-22 09:31:03 --> Utf8 Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:03 --> URI Class Initialized
INFO - 2023-05-22 09:31:03 --> Input Class Initialized
INFO - 2023-05-22 09:31:03 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:03 --> Language Class Initialized
INFO - 2023-05-22 09:31:03 --> Input Class Initialized
INFO - 2023-05-22 09:31:03 --> Router Class Initialized
INFO - 2023-05-22 09:31:03 --> Language Class Initialized
INFO - 2023-05-22 09:31:03 --> Loader Class Initialized
INFO - 2023-05-22 09:31:03 --> Output Class Initialized
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:03 --> Security Class Initialized
INFO - 2023-05-22 09:31:03 --> Loader Class Initialized
INFO - 2023-05-22 09:31:03 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:03 --> Controller Class Initialized
INFO - 2023-05-22 09:31:03 --> Input Class Initialized
INFO - 2023-05-22 09:31:03 --> Model "Cluster_model" initialized
DEBUG - 2023-05-22 09:31:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:03 --> Language Class Initialized
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:03 --> Loader Class Initialized
INFO - 2023-05-22 09:31:03 --> Final output sent to browser
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Total execution time: 0.4027
INFO - 2023-05-22 09:31:03 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:03 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:03 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:03 --> Config Class Initialized
INFO - 2023-05-22 09:31:03 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:03 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:03 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:03 --> Total execution time: 0.3632
INFO - 2023-05-22 09:31:03 --> Model "Login_model" initialized
INFO - 2023-05-22 09:31:03 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:03 --> URI Class Initialized
INFO - 2023-05-22 09:31:03 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:03 --> Total execution time: 0.3634
INFO - 2023-05-22 09:31:03 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:03 --> Total execution time: 0.3164
INFO - 2023-05-22 09:31:03 --> Router Class Initialized
INFO - 2023-05-22 09:31:03 --> Output Class Initialized
INFO - 2023-05-22 09:31:03 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:03 --> Input Class Initialized
INFO - 2023-05-22 09:31:03 --> Language Class Initialized
INFO - 2023-05-22 09:31:04 --> Loader Class Initialized
INFO - 2023-05-22 09:31:04 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:04 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:04 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:04 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:04 --> Total execution time: 0.3230
INFO - 2023-05-22 09:31:23 --> Config Class Initialized
INFO - 2023-05-22 09:31:23 --> Config Class Initialized
INFO - 2023-05-22 09:31:23 --> Config Class Initialized
INFO - 2023-05-22 09:31:23 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:23 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:23 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:23 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:23 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:23 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:23 --> URI Class Initialized
INFO - 2023-05-22 09:31:23 --> URI Class Initialized
INFO - 2023-05-22 09:31:23 --> URI Class Initialized
INFO - 2023-05-22 09:31:23 --> Router Class Initialized
INFO - 2023-05-22 09:31:23 --> Router Class Initialized
INFO - 2023-05-22 09:31:23 --> Router Class Initialized
INFO - 2023-05-22 09:31:23 --> Output Class Initialized
INFO - 2023-05-22 09:31:23 --> Output Class Initialized
INFO - 2023-05-22 09:31:23 --> Output Class Initialized
INFO - 2023-05-22 09:31:23 --> Security Class Initialized
INFO - 2023-05-22 09:31:23 --> Security Class Initialized
INFO - 2023-05-22 09:31:23 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:23 --> Input Class Initialized
INFO - 2023-05-22 09:31:23 --> Input Class Initialized
INFO - 2023-05-22 09:31:23 --> Input Class Initialized
INFO - 2023-05-22 09:31:23 --> Language Class Initialized
INFO - 2023-05-22 09:31:23 --> Language Class Initialized
INFO - 2023-05-22 09:31:23 --> Language Class Initialized
INFO - 2023-05-22 09:31:23 --> Loader Class Initialized
INFO - 2023-05-22 09:31:23 --> Loader Class Initialized
INFO - 2023-05-22 09:31:23 --> Controller Class Initialized
INFO - 2023-05-22 09:31:23 --> Controller Class Initialized
INFO - 2023-05-22 09:31:23 --> Loader Class Initialized
DEBUG - 2023-05-22 09:31:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 09:31:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:23 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:23 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:23 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:23 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:23 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:23 --> Total execution time: 0.2607
INFO - 2023-05-22 09:31:23 --> Final output sent to browser
INFO - 2023-05-22 09:31:23 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:23 --> Total execution time: 0.2724
DEBUG - 2023-05-22 09:31:23 --> Total execution time: 0.2711
INFO - 2023-05-22 09:31:23 --> Config Class Initialized
INFO - 2023-05-22 09:31:23 --> Config Class Initialized
INFO - 2023-05-22 09:31:23 --> Config Class Initialized
INFO - 2023-05-22 09:31:23 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:23 --> Hooks Class Initialized
INFO - 2023-05-22 09:31:23 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:23 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:31:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:23 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:23 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:23 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:23 --> URI Class Initialized
INFO - 2023-05-22 09:31:23 --> URI Class Initialized
INFO - 2023-05-22 09:31:23 --> URI Class Initialized
INFO - 2023-05-22 09:31:23 --> Router Class Initialized
INFO - 2023-05-22 09:31:23 --> Router Class Initialized
INFO - 2023-05-22 09:31:23 --> Router Class Initialized
INFO - 2023-05-22 09:31:23 --> Output Class Initialized
INFO - 2023-05-22 09:31:23 --> Output Class Initialized
INFO - 2023-05-22 09:31:23 --> Output Class Initialized
INFO - 2023-05-22 09:31:23 --> Security Class Initialized
INFO - 2023-05-22 09:31:23 --> Security Class Initialized
INFO - 2023-05-22 09:31:23 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:23 --> Input Class Initialized
INFO - 2023-05-22 09:31:23 --> Input Class Initialized
INFO - 2023-05-22 09:31:23 --> Input Class Initialized
INFO - 2023-05-22 09:31:23 --> Language Class Initialized
INFO - 2023-05-22 09:31:23 --> Language Class Initialized
INFO - 2023-05-22 09:31:23 --> Language Class Initialized
INFO - 2023-05-22 09:31:23 --> Loader Class Initialized
INFO - 2023-05-22 09:31:23 --> Loader Class Initialized
INFO - 2023-05-22 09:31:23 --> Controller Class Initialized
INFO - 2023-05-22 09:31:23 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 09:31:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:23 --> Loader Class Initialized
INFO - 2023-05-22 09:31:23 --> Controller Class Initialized
INFO - 2023-05-22 09:31:23 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:23 --> Database Driver Class Initialized
DEBUG - 2023-05-22 09:31:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:23 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:23 --> Final output sent to browser
INFO - 2023-05-22 09:31:23 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:23 --> Total execution time: 0.2585
DEBUG - 2023-05-22 09:31:23 --> Total execution time: 0.2595
INFO - 2023-05-22 09:31:23 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:23 --> Final output sent to browser
DEBUG - 2023-05-22 09:31:23 --> Total execution time: 0.2897
INFO - 2023-05-22 09:31:23 --> Config Class Initialized
INFO - 2023-05-22 09:31:23 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:23 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:23 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:23 --> URI Class Initialized
INFO - 2023-05-22 09:31:23 --> Router Class Initialized
INFO - 2023-05-22 09:31:23 --> Output Class Initialized
INFO - 2023-05-22 09:31:23 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:23 --> Input Class Initialized
INFO - 2023-05-22 09:31:23 --> Language Class Initialized
INFO - 2023-05-22 09:31:23 --> Loader Class Initialized
INFO - 2023-05-22 09:31:23 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:23 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:23 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:31:24 --> Config Class Initialized
INFO - 2023-05-22 09:31:24 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:31:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:31:24 --> Utf8 Class Initialized
INFO - 2023-05-22 09:31:24 --> URI Class Initialized
INFO - 2023-05-22 09:31:24 --> Router Class Initialized
INFO - 2023-05-22 09:31:24 --> Output Class Initialized
INFO - 2023-05-22 09:31:24 --> Security Class Initialized
DEBUG - 2023-05-22 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:31:24 --> Input Class Initialized
INFO - 2023-05-22 09:31:24 --> Language Class Initialized
INFO - 2023-05-22 09:31:24 --> Loader Class Initialized
INFO - 2023-05-22 09:31:24 --> Controller Class Initialized
DEBUG - 2023-05-22 09:31:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:31:24 --> Database Driver Class Initialized
INFO - 2023-05-22 09:31:24 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:32:53 --> Config Class Initialized
INFO - 2023-05-22 09:32:53 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:32:53 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:32:53 --> Utf8 Class Initialized
INFO - 2023-05-22 09:32:53 --> URI Class Initialized
INFO - 2023-05-22 09:32:53 --> Router Class Initialized
INFO - 2023-05-22 09:32:53 --> Output Class Initialized
INFO - 2023-05-22 09:32:53 --> Security Class Initialized
DEBUG - 2023-05-22 09:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:32:53 --> Input Class Initialized
INFO - 2023-05-22 09:32:53 --> Language Class Initialized
INFO - 2023-05-22 09:32:53 --> Loader Class Initialized
INFO - 2023-05-22 09:32:53 --> Controller Class Initialized
DEBUG - 2023-05-22 09:32:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:32:53 --> Database Driver Class Initialized
INFO - 2023-05-22 09:32:53 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:32:53 --> Final output sent to browser
DEBUG - 2023-05-22 09:32:53 --> Total execution time: 0.1845
INFO - 2023-05-22 09:32:53 --> Config Class Initialized
INFO - 2023-05-22 09:32:53 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:32:53 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:32:53 --> Utf8 Class Initialized
INFO - 2023-05-22 09:32:53 --> URI Class Initialized
INFO - 2023-05-22 09:32:53 --> Router Class Initialized
INFO - 2023-05-22 09:32:53 --> Output Class Initialized
INFO - 2023-05-22 09:32:53 --> Security Class Initialized
DEBUG - 2023-05-22 09:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:32:53 --> Input Class Initialized
INFO - 2023-05-22 09:32:53 --> Language Class Initialized
INFO - 2023-05-22 09:32:53 --> Loader Class Initialized
INFO - 2023-05-22 09:32:53 --> Controller Class Initialized
DEBUG - 2023-05-22 09:32:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:32:53 --> Database Driver Class Initialized
INFO - 2023-05-22 09:32:53 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:32:53 --> Final output sent to browser
DEBUG - 2023-05-22 09:32:53 --> Total execution time: 0.2086
INFO - 2023-05-22 09:45:24 --> Config Class Initialized
INFO - 2023-05-22 09:45:24 --> Config Class Initialized
INFO - 2023-05-22 09:45:24 --> Config Class Initialized
INFO - 2023-05-22 09:45:24 --> Hooks Class Initialized
INFO - 2023-05-22 09:45:24 --> Hooks Class Initialized
INFO - 2023-05-22 09:45:24 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:45:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:45:24 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 09:45:24 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:45:24 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:24 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:24 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:24 --> URI Class Initialized
INFO - 2023-05-22 09:45:24 --> URI Class Initialized
INFO - 2023-05-22 09:45:24 --> URI Class Initialized
INFO - 2023-05-22 09:45:24 --> Router Class Initialized
INFO - 2023-05-22 09:45:24 --> Router Class Initialized
INFO - 2023-05-22 09:45:24 --> Router Class Initialized
INFO - 2023-05-22 09:45:24 --> Output Class Initialized
INFO - 2023-05-22 09:45:24 --> Output Class Initialized
INFO - 2023-05-22 09:45:25 --> Security Class Initialized
INFO - 2023-05-22 09:45:25 --> Security Class Initialized
INFO - 2023-05-22 09:45:25 --> Output Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:45:25 --> Input Class Initialized
INFO - 2023-05-22 09:45:25 --> Input Class Initialized
INFO - 2023-05-22 09:45:25 --> Language Class Initialized
INFO - 2023-05-22 09:45:25 --> Security Class Initialized
INFO - 2023-05-22 09:45:25 --> Language Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:45:25 --> Input Class Initialized
INFO - 2023-05-22 09:45:25 --> Language Class Initialized
INFO - 2023-05-22 09:45:25 --> Loader Class Initialized
INFO - 2023-05-22 09:45:25 --> Controller Class Initialized
INFO - 2023-05-22 09:45:25 --> Loader Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:45:25 --> Loader Class Initialized
INFO - 2023-05-22 09:45:25 --> Controller Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:45:25 --> Controller Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:45:25 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:25 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:25 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:25 --> Final output sent to browser
DEBUG - 2023-05-22 09:45:25 --> Total execution time: 0.3091
INFO - 2023-05-22 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:25 --> Final output sent to browser
DEBUG - 2023-05-22 09:45:25 --> Total execution time: 0.3300
INFO - 2023-05-22 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:25 --> Final output sent to browser
DEBUG - 2023-05-22 09:45:25 --> Total execution time: 0.3688
INFO - 2023-05-22 09:45:25 --> Config Class Initialized
INFO - 2023-05-22 09:45:25 --> Hooks Class Initialized
INFO - 2023-05-22 09:45:25 --> Config Class Initialized
INFO - 2023-05-22 09:45:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:45:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:45:25 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:25 --> URI Class Initialized
DEBUG - 2023-05-22 09:45:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:45:25 --> Config Class Initialized
INFO - 2023-05-22 09:45:25 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:25 --> Hooks Class Initialized
INFO - 2023-05-22 09:45:25 --> URI Class Initialized
INFO - 2023-05-22 09:45:25 --> Router Class Initialized
INFO - 2023-05-22 09:45:25 --> Router Class Initialized
INFO - 2023-05-22 09:45:25 --> Output Class Initialized
INFO - 2023-05-22 09:45:25 --> Security Class Initialized
DEBUG - 2023-05-22 09:45:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:45:25 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:25 --> Output Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:45:25 --> URI Class Initialized
INFO - 2023-05-22 09:45:25 --> Input Class Initialized
INFO - 2023-05-22 09:45:25 --> Security Class Initialized
INFO - 2023-05-22 09:45:25 --> Language Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:45:25 --> Router Class Initialized
INFO - 2023-05-22 09:45:25 --> Input Class Initialized
INFO - 2023-05-22 09:45:25 --> Language Class Initialized
INFO - 2023-05-22 09:45:25 --> Loader Class Initialized
INFO - 2023-05-22 09:45:25 --> Output Class Initialized
INFO - 2023-05-22 09:45:25 --> Controller Class Initialized
INFO - 2023-05-22 09:45:25 --> Security Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:45:25 --> Input Class Initialized
INFO - 2023-05-22 09:45:25 --> Loader Class Initialized
INFO - 2023-05-22 09:45:25 --> Language Class Initialized
INFO - 2023-05-22 09:45:25 --> Controller Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:45:25 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:25 --> Loader Class Initialized
INFO - 2023-05-22 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:25 --> Final output sent to browser
INFO - 2023-05-22 09:45:25 --> Controller Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Total execution time: 0.2924
DEBUG - 2023-05-22 09:45:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:45:25 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:25 --> Final output sent to browser
DEBUG - 2023-05-22 09:45:25 --> Total execution time: 0.3274
INFO - 2023-05-22 09:45:25 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:25 --> Final output sent to browser
DEBUG - 2023-05-22 09:45:25 --> Total execution time: 0.3568
INFO - 2023-05-22 09:45:25 --> Config Class Initialized
INFO - 2023-05-22 09:45:25 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:45:25 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:45:25 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:25 --> URI Class Initialized
INFO - 2023-05-22 09:45:25 --> Router Class Initialized
INFO - 2023-05-22 09:45:25 --> Output Class Initialized
INFO - 2023-05-22 09:45:25 --> Security Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:45:25 --> Input Class Initialized
INFO - 2023-05-22 09:45:25 --> Language Class Initialized
INFO - 2023-05-22 09:45:25 --> Loader Class Initialized
INFO - 2023-05-22 09:45:25 --> Controller Class Initialized
DEBUG - 2023-05-22 09:45:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:45:25 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:25 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:26 --> Config Class Initialized
INFO - 2023-05-22 09:45:26 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:45:26 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:45:26 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:26 --> URI Class Initialized
INFO - 2023-05-22 09:45:26 --> Router Class Initialized
INFO - 2023-05-22 09:45:26 --> Output Class Initialized
INFO - 2023-05-22 09:45:26 --> Security Class Initialized
DEBUG - 2023-05-22 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:45:26 --> Input Class Initialized
INFO - 2023-05-22 09:45:26 --> Language Class Initialized
INFO - 2023-05-22 09:45:26 --> Loader Class Initialized
INFO - 2023-05-22 09:45:26 --> Controller Class Initialized
DEBUG - 2023-05-22 09:45:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:45:26 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:26 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:27 --> Config Class Initialized
INFO - 2023-05-22 09:45:27 --> Hooks Class Initialized
DEBUG - 2023-05-22 09:45:27 --> UTF-8 Support Enabled
INFO - 2023-05-22 09:45:27 --> Utf8 Class Initialized
INFO - 2023-05-22 09:45:27 --> URI Class Initialized
INFO - 2023-05-22 09:45:27 --> Router Class Initialized
INFO - 2023-05-22 09:45:27 --> Output Class Initialized
INFO - 2023-05-22 09:45:27 --> Security Class Initialized
DEBUG - 2023-05-22 09:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 09:45:28 --> Input Class Initialized
INFO - 2023-05-22 09:45:28 --> Language Class Initialized
INFO - 2023-05-22 09:45:28 --> Loader Class Initialized
INFO - 2023-05-22 09:45:28 --> Controller Class Initialized
DEBUG - 2023-05-22 09:45:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 09:45:28 --> Database Driver Class Initialized
INFO - 2023-05-22 09:45:28 --> Model "Cluster_model" initialized
INFO - 2023-05-22 09:45:28 --> Final output sent to browser
DEBUG - 2023-05-22 09:45:28 --> Total execution time: 0.4176
INFO - 2023-05-22 10:04:42 --> Config Class Initialized
INFO - 2023-05-22 10:04:42 --> Config Class Initialized
INFO - 2023-05-22 10:04:42 --> Config Class Initialized
INFO - 2023-05-22 10:04:42 --> Hooks Class Initialized
INFO - 2023-05-22 10:04:42 --> Hooks Class Initialized
INFO - 2023-05-22 10:04:42 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:04:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 10:04:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 10:04:42 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:04:42 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:42 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:42 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:42 --> URI Class Initialized
INFO - 2023-05-22 10:04:42 --> URI Class Initialized
INFO - 2023-05-22 10:04:42 --> URI Class Initialized
INFO - 2023-05-22 10:04:42 --> Router Class Initialized
INFO - 2023-05-22 10:04:42 --> Router Class Initialized
INFO - 2023-05-22 10:04:42 --> Router Class Initialized
INFO - 2023-05-22 10:04:42 --> Output Class Initialized
INFO - 2023-05-22 10:04:42 --> Output Class Initialized
INFO - 2023-05-22 10:04:42 --> Output Class Initialized
INFO - 2023-05-22 10:04:42 --> Security Class Initialized
INFO - 2023-05-22 10:04:42 --> Security Class Initialized
INFO - 2023-05-22 10:04:42 --> Security Class Initialized
DEBUG - 2023-05-22 10:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 10:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 10:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:04:42 --> Input Class Initialized
INFO - 2023-05-22 10:04:42 --> Input Class Initialized
INFO - 2023-05-22 10:04:42 --> Input Class Initialized
INFO - 2023-05-22 10:04:42 --> Language Class Initialized
INFO - 2023-05-22 10:04:42 --> Language Class Initialized
INFO - 2023-05-22 10:04:42 --> Language Class Initialized
INFO - 2023-05-22 10:04:42 --> Loader Class Initialized
INFO - 2023-05-22 10:04:42 --> Loader Class Initialized
INFO - 2023-05-22 10:04:42 --> Controller Class Initialized
INFO - 2023-05-22 10:04:42 --> Controller Class Initialized
DEBUG - 2023-05-22 10:04:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 10:04:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:04:42 --> Loader Class Initialized
INFO - 2023-05-22 10:04:42 --> Database Driver Class Initialized
INFO - 2023-05-22 10:04:42 --> Database Driver Class Initialized
INFO - 2023-05-22 10:04:42 --> Controller Class Initialized
INFO - 2023-05-22 10:04:42 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:04:42 --> Model "Cluster_model" initialized
DEBUG - 2023-05-22 10:04:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:04:42 --> Final output sent to browser
INFO - 2023-05-22 10:04:42 --> Final output sent to browser
DEBUG - 2023-05-22 10:04:42 --> Total execution time: 0.4947
DEBUG - 2023-05-22 10:04:42 --> Total execution time: 0.4932
INFO - 2023-05-22 10:04:42 --> Config Class Initialized
INFO - 2023-05-22 10:04:42 --> Config Class Initialized
INFO - 2023-05-22 10:04:42 --> Hooks Class Initialized
INFO - 2023-05-22 10:04:42 --> Hooks Class Initialized
INFO - 2023-05-22 10:04:42 --> Database Driver Class Initialized
DEBUG - 2023-05-22 10:04:42 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 10:04:42 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:04:42 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:04:42 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:42 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:42 --> Final output sent to browser
DEBUG - 2023-05-22 10:04:42 --> Total execution time: 0.6266
INFO - 2023-05-22 10:04:42 --> URI Class Initialized
INFO - 2023-05-22 10:04:42 --> URI Class Initialized
INFO - 2023-05-22 10:04:42 --> Router Class Initialized
INFO - 2023-05-22 10:04:42 --> Router Class Initialized
INFO - 2023-05-22 10:04:42 --> Output Class Initialized
INFO - 2023-05-22 10:04:42 --> Output Class Initialized
INFO - 2023-05-22 10:04:42 --> Security Class Initialized
INFO - 2023-05-22 10:04:42 --> Security Class Initialized
DEBUG - 2023-05-22 10:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 10:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:04:42 --> Input Class Initialized
INFO - 2023-05-22 10:04:42 --> Input Class Initialized
INFO - 2023-05-22 10:04:43 --> Config Class Initialized
INFO - 2023-05-22 10:04:43 --> Language Class Initialized
INFO - 2023-05-22 10:04:43 --> Language Class Initialized
INFO - 2023-05-22 10:04:43 --> Hooks Class Initialized
INFO - 2023-05-22 10:04:43 --> Loader Class Initialized
INFO - 2023-05-22 10:04:43 --> Loader Class Initialized
DEBUG - 2023-05-22 10:04:43 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:04:43 --> Controller Class Initialized
INFO - 2023-05-22 10:04:43 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:43 --> Controller Class Initialized
DEBUG - 2023-05-22 10:04:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 10:04:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:04:43 --> URI Class Initialized
INFO - 2023-05-22 10:04:43 --> Router Class Initialized
INFO - 2023-05-22 10:04:43 --> Database Driver Class Initialized
INFO - 2023-05-22 10:04:43 --> Database Driver Class Initialized
INFO - 2023-05-22 10:04:43 --> Output Class Initialized
INFO - 2023-05-22 10:04:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:04:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:04:43 --> Security Class Initialized
INFO - 2023-05-22 10:04:43 --> Final output sent to browser
INFO - 2023-05-22 10:04:43 --> Final output sent to browser
DEBUG - 2023-05-22 10:04:43 --> Total execution time: 0.3573
DEBUG - 2023-05-22 10:04:43 --> Total execution time: 0.3561
DEBUG - 2023-05-22 10:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:04:43 --> Input Class Initialized
INFO - 2023-05-22 10:04:43 --> Language Class Initialized
INFO - 2023-05-22 10:04:43 --> Loader Class Initialized
INFO - 2023-05-22 10:04:43 --> Config Class Initialized
INFO - 2023-05-22 10:04:43 --> Hooks Class Initialized
INFO - 2023-05-22 10:04:43 --> Controller Class Initialized
DEBUG - 2023-05-22 10:04:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 10:04:43 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:04:43 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:43 --> URI Class Initialized
INFO - 2023-05-22 10:04:43 --> Database Driver Class Initialized
INFO - 2023-05-22 10:04:43 --> Router Class Initialized
INFO - 2023-05-22 10:04:43 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:04:43 --> Output Class Initialized
INFO - 2023-05-22 10:04:43 --> Security Class Initialized
INFO - 2023-05-22 10:04:43 --> Final output sent to browser
DEBUG - 2023-05-22 10:04:43 --> Total execution time: 0.4551
DEBUG - 2023-05-22 10:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:04:43 --> Input Class Initialized
INFO - 2023-05-22 10:04:43 --> Language Class Initialized
INFO - 2023-05-22 10:04:43 --> Loader Class Initialized
INFO - 2023-05-22 10:04:43 --> Controller Class Initialized
DEBUG - 2023-05-22 10:04:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:04:43 --> Database Driver Class Initialized
INFO - 2023-05-22 10:04:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:04:44 --> Config Class Initialized
INFO - 2023-05-22 10:04:44 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:04:44 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:04:44 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:44 --> URI Class Initialized
INFO - 2023-05-22 10:04:44 --> Router Class Initialized
INFO - 2023-05-22 10:04:44 --> Output Class Initialized
INFO - 2023-05-22 10:04:44 --> Security Class Initialized
DEBUG - 2023-05-22 10:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:04:44 --> Input Class Initialized
INFO - 2023-05-22 10:04:44 --> Language Class Initialized
INFO - 2023-05-22 10:04:44 --> Loader Class Initialized
INFO - 2023-05-22 10:04:44 --> Controller Class Initialized
DEBUG - 2023-05-22 10:04:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:04:44 --> Database Driver Class Initialized
INFO - 2023-05-22 10:04:44 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:04:45 --> Config Class Initialized
INFO - 2023-05-22 10:04:45 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:04:45 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:04:45 --> Utf8 Class Initialized
INFO - 2023-05-22 10:04:45 --> URI Class Initialized
INFO - 2023-05-22 10:04:45 --> Router Class Initialized
INFO - 2023-05-22 10:04:45 --> Output Class Initialized
INFO - 2023-05-22 10:04:45 --> Security Class Initialized
DEBUG - 2023-05-22 10:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:04:45 --> Input Class Initialized
INFO - 2023-05-22 10:04:45 --> Language Class Initialized
INFO - 2023-05-22 10:04:45 --> Loader Class Initialized
INFO - 2023-05-22 10:04:45 --> Controller Class Initialized
DEBUG - 2023-05-22 10:04:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:04:45 --> Database Driver Class Initialized
INFO - 2023-05-22 10:04:45 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:04:45 --> Final output sent to browser
DEBUG - 2023-05-22 10:04:45 --> Total execution time: 0.2676
INFO - 2023-05-22 10:15:31 --> Config Class Initialized
INFO - 2023-05-22 10:15:31 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:31 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:31 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:31 --> URI Class Initialized
INFO - 2023-05-22 10:15:31 --> Router Class Initialized
INFO - 2023-05-22 10:15:31 --> Output Class Initialized
INFO - 2023-05-22 10:15:31 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:31 --> Input Class Initialized
INFO - 2023-05-22 10:15:31 --> Language Class Initialized
INFO - 2023-05-22 10:15:31 --> Loader Class Initialized
INFO - 2023-05-22 10:15:31 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:32 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:32 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:32 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:32 --> Total execution time: 1.0330
INFO - 2023-05-22 10:15:32 --> Config Class Initialized
INFO - 2023-05-22 10:15:32 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:32 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:32 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:32 --> URI Class Initialized
INFO - 2023-05-22 10:15:32 --> Router Class Initialized
INFO - 2023-05-22 10:15:32 --> Output Class Initialized
INFO - 2023-05-22 10:15:32 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:32 --> Input Class Initialized
INFO - 2023-05-22 10:15:32 --> Language Class Initialized
INFO - 2023-05-22 10:15:32 --> Loader Class Initialized
INFO - 2023-05-22 10:15:33 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:33 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:33 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:33 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:33 --> Total execution time: 1.2261
INFO - 2023-05-22 10:15:34 --> Config Class Initialized
INFO - 2023-05-22 10:15:34 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:34 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:34 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:34 --> URI Class Initialized
INFO - 2023-05-22 10:15:34 --> Router Class Initialized
INFO - 2023-05-22 10:15:34 --> Output Class Initialized
INFO - 2023-05-22 10:15:34 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:34 --> Input Class Initialized
INFO - 2023-05-22 10:15:34 --> Language Class Initialized
INFO - 2023-05-22 10:15:34 --> Loader Class Initialized
INFO - 2023-05-22 10:15:34 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:34 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:35 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:35 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:35 --> Total execution time: 0.3296
INFO - 2023-05-22 10:15:35 --> Config Class Initialized
INFO - 2023-05-22 10:15:35 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:35 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:35 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:35 --> URI Class Initialized
INFO - 2023-05-22 10:15:35 --> Router Class Initialized
INFO - 2023-05-22 10:15:35 --> Output Class Initialized
INFO - 2023-05-22 10:15:35 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:35 --> Input Class Initialized
INFO - 2023-05-22 10:15:35 --> Language Class Initialized
INFO - 2023-05-22 10:15:35 --> Loader Class Initialized
INFO - 2023-05-22 10:15:35 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:35 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:35 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:35 --> Config Class Initialized
INFO - 2023-05-22 10:15:35 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:35 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:35 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:35 --> URI Class Initialized
INFO - 2023-05-22 10:15:35 --> Router Class Initialized
INFO - 2023-05-22 10:15:35 --> Output Class Initialized
INFO - 2023-05-22 10:15:35 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:35 --> Input Class Initialized
INFO - 2023-05-22 10:15:35 --> Language Class Initialized
INFO - 2023-05-22 10:15:35 --> Loader Class Initialized
INFO - 2023-05-22 10:15:35 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:35 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:35 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:36 --> Config Class Initialized
INFO - 2023-05-22 10:15:36 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:36 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:36 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:36 --> URI Class Initialized
INFO - 2023-05-22 10:15:36 --> Router Class Initialized
INFO - 2023-05-22 10:15:36 --> Output Class Initialized
INFO - 2023-05-22 10:15:36 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:36 --> Input Class Initialized
INFO - 2023-05-22 10:15:36 --> Language Class Initialized
INFO - 2023-05-22 10:15:36 --> Loader Class Initialized
INFO - 2023-05-22 10:15:36 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:37 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:37 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:37 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:37 --> Total execution time: 2.8839
INFO - 2023-05-22 10:15:37 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:38 --> Total execution time: 2.4171
INFO - 2023-05-22 10:15:38 --> Config Class Initialized
INFO - 2023-05-22 10:15:38 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:38 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:38 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:38 --> URI Class Initialized
INFO - 2023-05-22 10:15:38 --> Router Class Initialized
INFO - 2023-05-22 10:15:38 --> Config Class Initialized
INFO - 2023-05-22 10:15:38 --> Hooks Class Initialized
INFO - 2023-05-22 10:15:38 --> Output Class Initialized
DEBUG - 2023-05-22 10:15:38 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:38 --> Security Class Initialized
INFO - 2023-05-22 10:15:38 --> Utf8 Class Initialized
DEBUG - 2023-05-22 10:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:38 --> URI Class Initialized
INFO - 2023-05-22 10:15:38 --> Input Class Initialized
INFO - 2023-05-22 10:15:38 --> Language Class Initialized
INFO - 2023-05-22 10:15:38 --> Router Class Initialized
INFO - 2023-05-22 10:15:38 --> Output Class Initialized
INFO - 2023-05-22 10:15:38 --> Security Class Initialized
INFO - 2023-05-22 10:15:38 --> Loader Class Initialized
DEBUG - 2023-05-22 10:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:38 --> Input Class Initialized
INFO - 2023-05-22 10:15:38 --> Language Class Initialized
INFO - 2023-05-22 10:15:39 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:39 --> Loader Class Initialized
INFO - 2023-05-22 10:15:39 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:39 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:39 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:39 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:39 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:39 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:39 --> Total execution time: 2.8512
INFO - 2023-05-22 10:15:39 --> Config Class Initialized
INFO - 2023-05-22 10:15:39 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:39 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:39 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:39 --> URI Class Initialized
INFO - 2023-05-22 10:15:39 --> Router Class Initialized
INFO - 2023-05-22 10:15:39 --> Output Class Initialized
INFO - 2023-05-22 10:15:39 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:39 --> Input Class Initialized
INFO - 2023-05-22 10:15:39 --> Language Class Initialized
INFO - 2023-05-22 10:15:39 --> Loader Class Initialized
INFO - 2023-05-22 10:15:39 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:39 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:40 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:40 --> Config Class Initialized
INFO - 2023-05-22 10:15:40 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:40 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:40 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:40 --> URI Class Initialized
INFO - 2023-05-22 10:15:40 --> Router Class Initialized
INFO - 2023-05-22 10:15:40 --> Output Class Initialized
INFO - 2023-05-22 10:15:40 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:40 --> Input Class Initialized
INFO - 2023-05-22 10:15:40 --> Language Class Initialized
INFO - 2023-05-22 10:15:40 --> Loader Class Initialized
INFO - 2023-05-22 10:15:40 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:40 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:40 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:40 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:40 --> Total execution time: 0.2842
INFO - 2023-05-22 10:15:40 --> Config Class Initialized
INFO - 2023-05-22 10:15:40 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:40 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:40 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:41 --> URI Class Initialized
INFO - 2023-05-22 10:15:41 --> Router Class Initialized
INFO - 2023-05-22 10:15:41 --> Output Class Initialized
INFO - 2023-05-22 10:15:41 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:41 --> Input Class Initialized
INFO - 2023-05-22 10:15:41 --> Language Class Initialized
INFO - 2023-05-22 10:15:41 --> Loader Class Initialized
INFO - 2023-05-22 10:15:41 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:41 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:41 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:41 --> Final output sent to browser
INFO - 2023-05-22 10:15:41 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:41 --> Total execution time: 3.5119
DEBUG - 2023-05-22 10:15:41 --> Total execution time: 2.7932
INFO - 2023-05-22 10:15:41 --> Config Class Initialized
INFO - 2023-05-22 10:15:41 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:15:41 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:15:41 --> Utf8 Class Initialized
INFO - 2023-05-22 10:15:41 --> URI Class Initialized
INFO - 2023-05-22 10:15:41 --> Router Class Initialized
INFO - 2023-05-22 10:15:41 --> Output Class Initialized
INFO - 2023-05-22 10:15:41 --> Security Class Initialized
DEBUG - 2023-05-22 10:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:15:41 --> Input Class Initialized
INFO - 2023-05-22 10:15:41 --> Language Class Initialized
INFO - 2023-05-22 10:15:41 --> Loader Class Initialized
INFO - 2023-05-22 10:15:41 --> Controller Class Initialized
DEBUG - 2023-05-22 10:15:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:15:41 --> Database Driver Class Initialized
INFO - 2023-05-22 10:15:41 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:15:41 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:41 --> Total execution time: 0.3500
INFO - 2023-05-22 10:15:42 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:42 --> Total execution time: 2.6514
INFO - 2023-05-22 10:15:43 --> Final output sent to browser
DEBUG - 2023-05-22 10:15:43 --> Total execution time: 2.6619
INFO - 2023-05-22 10:16:15 --> Config Class Initialized
INFO - 2023-05-22 10:16:15 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:15 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:15 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:15 --> URI Class Initialized
INFO - 2023-05-22 10:16:15 --> Router Class Initialized
INFO - 2023-05-22 10:16:15 --> Output Class Initialized
INFO - 2023-05-22 10:16:15 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:15 --> Input Class Initialized
INFO - 2023-05-22 10:16:15 --> Language Class Initialized
INFO - 2023-05-22 10:16:15 --> Loader Class Initialized
INFO - 2023-05-22 10:16:15 --> Controller Class Initialized
INFO - 2023-05-22 10:16:16 --> Helper loaded: form_helper
INFO - 2023-05-22 10:16:16 --> Helper loaded: url_helper
DEBUG - 2023-05-22 10:16:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:16 --> Model "Change_model" initialized
INFO - 2023-05-22 10:16:16 --> Model "Grafana_model" initialized
INFO - 2023-05-22 10:16:16 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:16 --> Total execution time: 0.3015
INFO - 2023-05-22 10:16:16 --> Config Class Initialized
INFO - 2023-05-22 10:16:16 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:16 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:16 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:16 --> URI Class Initialized
INFO - 2023-05-22 10:16:16 --> Router Class Initialized
INFO - 2023-05-22 10:16:16 --> Output Class Initialized
INFO - 2023-05-22 10:16:16 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:16 --> Input Class Initialized
INFO - 2023-05-22 10:16:16 --> Language Class Initialized
INFO - 2023-05-22 10:16:16 --> Loader Class Initialized
INFO - 2023-05-22 10:16:16 --> Controller Class Initialized
INFO - 2023-05-22 10:16:16 --> Helper loaded: form_helper
INFO - 2023-05-22 10:16:16 --> Helper loaded: url_helper
DEBUG - 2023-05-22 10:16:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:16 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:16 --> Total execution time: 0.2054
INFO - 2023-05-22 10:16:16 --> Config Class Initialized
INFO - 2023-05-22 10:16:16 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:16 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:16 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:16 --> URI Class Initialized
INFO - 2023-05-22 10:16:16 --> Router Class Initialized
INFO - 2023-05-22 10:16:16 --> Output Class Initialized
INFO - 2023-05-22 10:16:16 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:16 --> Input Class Initialized
INFO - 2023-05-22 10:16:16 --> Language Class Initialized
INFO - 2023-05-22 10:16:16 --> Loader Class Initialized
INFO - 2023-05-22 10:16:16 --> Controller Class Initialized
INFO - 2023-05-22 10:16:16 --> Helper loaded: form_helper
INFO - 2023-05-22 10:16:16 --> Helper loaded: url_helper
DEBUG - 2023-05-22 10:16:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:16 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:16 --> Model "Login_model" initialized
INFO - 2023-05-22 10:16:16 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:16 --> Total execution time: 0.2849
INFO - 2023-05-22 10:16:16 --> Config Class Initialized
INFO - 2023-05-22 10:16:16 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:16 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:16 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:16 --> URI Class Initialized
INFO - 2023-05-22 10:16:16 --> Router Class Initialized
INFO - 2023-05-22 10:16:16 --> Output Class Initialized
INFO - 2023-05-22 10:16:16 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:16 --> Input Class Initialized
INFO - 2023-05-22 10:16:16 --> Language Class Initialized
INFO - 2023-05-22 10:16:16 --> Loader Class Initialized
INFO - 2023-05-22 10:16:16 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:16 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:16 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:16 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:16 --> Total execution time: 0.2240
INFO - 2023-05-22 10:16:17 --> Config Class Initialized
INFO - 2023-05-22 10:16:17 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:17 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:17 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:17 --> URI Class Initialized
INFO - 2023-05-22 10:16:17 --> Router Class Initialized
INFO - 2023-05-22 10:16:17 --> Output Class Initialized
INFO - 2023-05-22 10:16:17 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:17 --> Input Class Initialized
INFO - 2023-05-22 10:16:17 --> Language Class Initialized
INFO - 2023-05-22 10:16:17 --> Loader Class Initialized
INFO - 2023-05-22 10:16:17 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:17 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:17 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:17 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:17 --> Total execution time: 0.2231
INFO - 2023-05-22 10:16:17 --> Config Class Initialized
INFO - 2023-05-22 10:16:17 --> Config Class Initialized
INFO - 2023-05-22 10:16:17 --> Hooks Class Initialized
INFO - 2023-05-22 10:16:17 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:17 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 10:16:17 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:17 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:17 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:17 --> URI Class Initialized
INFO - 2023-05-22 10:16:17 --> URI Class Initialized
INFO - 2023-05-22 10:16:17 --> Router Class Initialized
INFO - 2023-05-22 10:16:17 --> Router Class Initialized
INFO - 2023-05-22 10:16:17 --> Output Class Initialized
INFO - 2023-05-22 10:16:17 --> Output Class Initialized
INFO - 2023-05-22 10:16:17 --> Security Class Initialized
INFO - 2023-05-22 10:16:17 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 10:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:17 --> Input Class Initialized
INFO - 2023-05-22 10:16:17 --> Input Class Initialized
INFO - 2023-05-22 10:16:17 --> Language Class Initialized
INFO - 2023-05-22 10:16:17 --> Language Class Initialized
INFO - 2023-05-22 10:16:17 --> Loader Class Initialized
INFO - 2023-05-22 10:16:17 --> Loader Class Initialized
INFO - 2023-05-22 10:16:17 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:17 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:17 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:17 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:17 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:17 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:17 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:17 --> Total execution time: 0.2229
INFO - 2023-05-22 10:16:17 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:17 --> Model "Login_model" initialized
INFO - 2023-05-22 10:16:17 --> Config Class Initialized
INFO - 2023-05-22 10:16:17 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:17 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:17 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:17 --> URI Class Initialized
INFO - 2023-05-22 10:16:17 --> Router Class Initialized
INFO - 2023-05-22 10:16:17 --> Output Class Initialized
INFO - 2023-05-22 10:16:17 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:17 --> Input Class Initialized
INFO - 2023-05-22 10:16:17 --> Language Class Initialized
INFO - 2023-05-22 10:16:17 --> Loader Class Initialized
INFO - 2023-05-22 10:16:17 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:17 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:17 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:17 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:17 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:17 --> Total execution time: 0.5222
INFO - 2023-05-22 10:16:17 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:17 --> Total execution time: 0.2724
INFO - 2023-05-22 10:16:17 --> Config Class Initialized
INFO - 2023-05-22 10:16:17 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:18 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:18 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:18 --> URI Class Initialized
INFO - 2023-05-22 10:16:18 --> Router Class Initialized
INFO - 2023-05-22 10:16:18 --> Output Class Initialized
INFO - 2023-05-22 10:16:18 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:18 --> Input Class Initialized
INFO - 2023-05-22 10:16:18 --> Language Class Initialized
INFO - 2023-05-22 10:16:18 --> Loader Class Initialized
INFO - 2023-05-22 10:16:18 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:18 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:18 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:18 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:18 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:18 --> Model "Login_model" initialized
INFO - 2023-05-22 10:16:18 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:18 --> Total execution time: 0.9670
INFO - 2023-05-22 10:16:26 --> Config Class Initialized
INFO - 2023-05-22 10:16:26 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:26 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:26 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:26 --> URI Class Initialized
INFO - 2023-05-22 10:16:26 --> Router Class Initialized
INFO - 2023-05-22 10:16:26 --> Output Class Initialized
INFO - 2023-05-22 10:16:26 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:26 --> Input Class Initialized
INFO - 2023-05-22 10:16:26 --> Language Class Initialized
INFO - 2023-05-22 10:16:26 --> Loader Class Initialized
INFO - 2023-05-22 10:16:26 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:26 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:26 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:26 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:26 --> Total execution time: 0.3210
INFO - 2023-05-22 10:16:26 --> Config Class Initialized
INFO - 2023-05-22 10:16:26 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:26 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:26 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:26 --> URI Class Initialized
INFO - 2023-05-22 10:16:26 --> Router Class Initialized
INFO - 2023-05-22 10:16:26 --> Output Class Initialized
INFO - 2023-05-22 10:16:26 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:26 --> Input Class Initialized
INFO - 2023-05-22 10:16:26 --> Language Class Initialized
INFO - 2023-05-22 10:16:26 --> Loader Class Initialized
INFO - 2023-05-22 10:16:26 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:26 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:26 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:27 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:27 --> Total execution time: 0.3677
INFO - 2023-05-22 10:16:32 --> Config Class Initialized
INFO - 2023-05-22 10:16:32 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:32 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:32 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:32 --> URI Class Initialized
INFO - 2023-05-22 10:16:32 --> Router Class Initialized
INFO - 2023-05-22 10:16:32 --> Output Class Initialized
INFO - 2023-05-22 10:16:32 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:32 --> Input Class Initialized
INFO - 2023-05-22 10:16:32 --> Language Class Initialized
INFO - 2023-05-22 10:16:32 --> Loader Class Initialized
INFO - 2023-05-22 10:16:32 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:32 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:32 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:32 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:32 --> Total execution time: 0.3498
INFO - 2023-05-22 10:16:32 --> Config Class Initialized
INFO - 2023-05-22 10:16:32 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:16:32 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:16:32 --> Utf8 Class Initialized
INFO - 2023-05-22 10:16:32 --> URI Class Initialized
INFO - 2023-05-22 10:16:32 --> Router Class Initialized
INFO - 2023-05-22 10:16:32 --> Output Class Initialized
INFO - 2023-05-22 10:16:32 --> Security Class Initialized
DEBUG - 2023-05-22 10:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:16:32 --> Input Class Initialized
INFO - 2023-05-22 10:16:32 --> Language Class Initialized
INFO - 2023-05-22 10:16:32 --> Loader Class Initialized
INFO - 2023-05-22 10:16:32 --> Controller Class Initialized
DEBUG - 2023-05-22 10:16:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:16:32 --> Database Driver Class Initialized
INFO - 2023-05-22 10:16:32 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:16:32 --> Final output sent to browser
DEBUG - 2023-05-22 10:16:32 --> Total execution time: 0.2538
INFO - 2023-05-22 10:24:20 --> Config Class Initialized
INFO - 2023-05-22 10:24:20 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:20 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:20 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:20 --> URI Class Initialized
INFO - 2023-05-22 10:24:20 --> Router Class Initialized
INFO - 2023-05-22 10:24:20 --> Output Class Initialized
INFO - 2023-05-22 10:24:20 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:20 --> Input Class Initialized
INFO - 2023-05-22 10:24:20 --> Language Class Initialized
INFO - 2023-05-22 10:24:20 --> Loader Class Initialized
INFO - 2023-05-22 10:24:20 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:20 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:20 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:20 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:20 --> Total execution time: 0.4037
INFO - 2023-05-22 10:24:20 --> Config Class Initialized
INFO - 2023-05-22 10:24:20 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:20 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:20 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:20 --> URI Class Initialized
INFO - 2023-05-22 10:24:20 --> Router Class Initialized
INFO - 2023-05-22 10:24:20 --> Output Class Initialized
INFO - 2023-05-22 10:24:20 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:20 --> Input Class Initialized
INFO - 2023-05-22 10:24:20 --> Language Class Initialized
INFO - 2023-05-22 10:24:20 --> Loader Class Initialized
INFO - 2023-05-22 10:24:20 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:20 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:20 --> Model "Cluster_model" initialized
ERROR - 2023-05-22 10:24:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '* from cluster_cdc_server where id=' at line 1 - Invalid query: delete * from cluster_cdc_server where id=
INFO - 2023-05-22 10:24:20 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-22 10:24:39 --> Config Class Initialized
INFO - 2023-05-22 10:24:39 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:39 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:39 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:39 --> URI Class Initialized
INFO - 2023-05-22 10:24:39 --> Router Class Initialized
INFO - 2023-05-22 10:24:39 --> Output Class Initialized
INFO - 2023-05-22 10:24:39 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:39 --> Input Class Initialized
INFO - 2023-05-22 10:24:39 --> Language Class Initialized
INFO - 2023-05-22 10:24:39 --> Loader Class Initialized
INFO - 2023-05-22 10:24:39 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:39 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:39 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:39 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:39 --> Total execution time: 0.5739
INFO - 2023-05-22 10:24:39 --> Config Class Initialized
INFO - 2023-05-22 10:24:39 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:39 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:39 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:39 --> URI Class Initialized
INFO - 2023-05-22 10:24:39 --> Router Class Initialized
INFO - 2023-05-22 10:24:39 --> Output Class Initialized
INFO - 2023-05-22 10:24:39 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:39 --> Input Class Initialized
INFO - 2023-05-22 10:24:39 --> Language Class Initialized
INFO - 2023-05-22 10:24:39 --> Loader Class Initialized
INFO - 2023-05-22 10:24:39 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:40 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:40 --> Model "Cluster_model" initialized
ERROR - 2023-05-22 10:24:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '* from cluster_cdc_server where id=' at line 1 - Invalid query: delete * from cluster_cdc_server where id=
INFO - 2023-05-22 10:24:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-22 10:24:50 --> Config Class Initialized
INFO - 2023-05-22 10:24:50 --> Config Class Initialized
INFO - 2023-05-22 10:24:50 --> Config Class Initialized
INFO - 2023-05-22 10:24:50 --> Hooks Class Initialized
INFO - 2023-05-22 10:24:50 --> Hooks Class Initialized
INFO - 2023-05-22 10:24:50 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 10:24:50 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:50 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:50 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:50 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:50 --> URI Class Initialized
INFO - 2023-05-22 10:24:50 --> URI Class Initialized
INFO - 2023-05-22 10:24:50 --> URI Class Initialized
INFO - 2023-05-22 10:24:50 --> Router Class Initialized
INFO - 2023-05-22 10:24:50 --> Router Class Initialized
INFO - 2023-05-22 10:24:50 --> Router Class Initialized
INFO - 2023-05-22 10:24:50 --> Output Class Initialized
INFO - 2023-05-22 10:24:50 --> Output Class Initialized
INFO - 2023-05-22 10:24:50 --> Output Class Initialized
INFO - 2023-05-22 10:24:50 --> Security Class Initialized
INFO - 2023-05-22 10:24:50 --> Security Class Initialized
INFO - 2023-05-22 10:24:50 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 10:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:51 --> Input Class Initialized
INFO - 2023-05-22 10:24:51 --> Input Class Initialized
INFO - 2023-05-22 10:24:51 --> Input Class Initialized
INFO - 2023-05-22 10:24:51 --> Language Class Initialized
INFO - 2023-05-22 10:24:51 --> Language Class Initialized
INFO - 2023-05-22 10:24:51 --> Language Class Initialized
INFO - 2023-05-22 10:24:51 --> Loader Class Initialized
INFO - 2023-05-22 10:24:51 --> Loader Class Initialized
INFO - 2023-05-22 10:24:51 --> Controller Class Initialized
INFO - 2023-05-22 10:24:51 --> Controller Class Initialized
INFO - 2023-05-22 10:24:51 --> Loader Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 10:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:51 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:51 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:51 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:51 --> Final output sent to browser
INFO - 2023-05-22 10:24:51 --> Final output sent to browser
INFO - 2023-05-22 10:24:51 --> Database Driver Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Total execution time: 0.1899
DEBUG - 2023-05-22 10:24:51 --> Total execution time: 0.1892
INFO - 2023-05-22 10:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:51 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:51 --> Total execution time: 0.2132
INFO - 2023-05-22 10:24:51 --> Config Class Initialized
INFO - 2023-05-22 10:24:51 --> Config Class Initialized
INFO - 2023-05-22 10:24:51 --> Hooks Class Initialized
INFO - 2023-05-22 10:24:51 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:51 --> UTF-8 Support Enabled
DEBUG - 2023-05-22 10:24:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:51 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:51 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:51 --> URI Class Initialized
INFO - 2023-05-22 10:24:51 --> URI Class Initialized
INFO - 2023-05-22 10:24:51 --> Config Class Initialized
INFO - 2023-05-22 10:24:51 --> Hooks Class Initialized
INFO - 2023-05-22 10:24:51 --> Router Class Initialized
INFO - 2023-05-22 10:24:51 --> Router Class Initialized
INFO - 2023-05-22 10:24:51 --> Output Class Initialized
INFO - 2023-05-22 10:24:51 --> Output Class Initialized
INFO - 2023-05-22 10:24:51 --> Security Class Initialized
INFO - 2023-05-22 10:24:51 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:51 --> Utf8 Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-22 10:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:51 --> Input Class Initialized
INFO - 2023-05-22 10:24:51 --> Input Class Initialized
INFO - 2023-05-22 10:24:51 --> Language Class Initialized
INFO - 2023-05-22 10:24:51 --> URI Class Initialized
INFO - 2023-05-22 10:24:51 --> Language Class Initialized
INFO - 2023-05-22 10:24:51 --> Router Class Initialized
INFO - 2023-05-22 10:24:51 --> Loader Class Initialized
INFO - 2023-05-22 10:24:51 --> Output Class Initialized
INFO - 2023-05-22 10:24:51 --> Controller Class Initialized
INFO - 2023-05-22 10:24:51 --> Security Class Initialized
INFO - 2023-05-22 10:24:51 --> Loader Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-22 10:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:51 --> Input Class Initialized
INFO - 2023-05-22 10:24:51 --> Controller Class Initialized
INFO - 2023-05-22 10:24:51 --> Language Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:51 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:51 --> Loader Class Initialized
INFO - 2023-05-22 10:24:51 --> Final output sent to browser
INFO - 2023-05-22 10:24:51 --> Controller Class Initialized
INFO - 2023-05-22 10:24:51 --> Database Driver Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Total execution time: 0.2315
DEBUG - 2023-05-22 10:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:51 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:51 --> Config Class Initialized
INFO - 2023-05-22 10:24:51 --> Hooks Class Initialized
INFO - 2023-05-22 10:24:51 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:51 --> Total execution time: 0.3148
INFO - 2023-05-22 10:24:51 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:51 --> Total execution time: 0.2976
DEBUG - 2023-05-22 10:24:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:51 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:51 --> URI Class Initialized
INFO - 2023-05-22 10:24:51 --> Router Class Initialized
INFO - 2023-05-22 10:24:51 --> Output Class Initialized
INFO - 2023-05-22 10:24:51 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:51 --> Input Class Initialized
INFO - 2023-05-22 10:24:51 --> Language Class Initialized
INFO - 2023-05-22 10:24:51 --> Loader Class Initialized
INFO - 2023-05-22 10:24:51 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:51 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:51 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:51 --> Config Class Initialized
INFO - 2023-05-22 10:24:51 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:51 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:51 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:51 --> URI Class Initialized
INFO - 2023-05-22 10:24:52 --> Router Class Initialized
INFO - 2023-05-22 10:24:52 --> Output Class Initialized
INFO - 2023-05-22 10:24:52 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:52 --> Input Class Initialized
INFO - 2023-05-22 10:24:52 --> Language Class Initialized
INFO - 2023-05-22 10:24:52 --> Loader Class Initialized
INFO - 2023-05-22 10:24:52 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:52 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:52 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:55 --> Config Class Initialized
INFO - 2023-05-22 10:24:55 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:55 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:55 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:55 --> URI Class Initialized
INFO - 2023-05-22 10:24:55 --> Router Class Initialized
INFO - 2023-05-22 10:24:55 --> Output Class Initialized
INFO - 2023-05-22 10:24:55 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:55 --> Input Class Initialized
INFO - 2023-05-22 10:24:55 --> Language Class Initialized
INFO - 2023-05-22 10:24:55 --> Loader Class Initialized
INFO - 2023-05-22 10:24:55 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:55 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:55 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:55 --> Total execution time: 0.1861
INFO - 2023-05-22 10:24:55 --> Config Class Initialized
INFO - 2023-05-22 10:24:55 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:55 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:55 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:55 --> URI Class Initialized
INFO - 2023-05-22 10:24:55 --> Router Class Initialized
INFO - 2023-05-22 10:24:55 --> Output Class Initialized
INFO - 2023-05-22 10:24:55 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:55 --> Input Class Initialized
INFO - 2023-05-22 10:24:55 --> Language Class Initialized
INFO - 2023-05-22 10:24:55 --> Loader Class Initialized
INFO - 2023-05-22 10:24:55 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:55 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:55 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:55 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:55 --> Total execution time: 0.2254
INFO - 2023-05-22 10:24:56 --> Config Class Initialized
INFO - 2023-05-22 10:24:56 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:56 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:56 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:56 --> URI Class Initialized
INFO - 2023-05-22 10:24:56 --> Router Class Initialized
INFO - 2023-05-22 10:24:56 --> Output Class Initialized
INFO - 2023-05-22 10:24:56 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:56 --> Input Class Initialized
INFO - 2023-05-22 10:24:56 --> Language Class Initialized
INFO - 2023-05-22 10:24:56 --> Loader Class Initialized
INFO - 2023-05-22 10:24:56 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:56 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:57 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:57 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:57 --> Total execution time: 0.1643
INFO - 2023-05-22 10:24:57 --> Config Class Initialized
INFO - 2023-05-22 10:24:57 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:57 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:57 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:57 --> URI Class Initialized
INFO - 2023-05-22 10:24:57 --> Router Class Initialized
INFO - 2023-05-22 10:24:57 --> Output Class Initialized
INFO - 2023-05-22 10:24:57 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:57 --> Input Class Initialized
INFO - 2023-05-22 10:24:57 --> Language Class Initialized
INFO - 2023-05-22 10:24:57 --> Loader Class Initialized
INFO - 2023-05-22 10:24:57 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:57 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:57 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:57 --> Config Class Initialized
INFO - 2023-05-22 10:24:57 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:57 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:57 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:57 --> URI Class Initialized
INFO - 2023-05-22 10:24:57 --> Router Class Initialized
INFO - 2023-05-22 10:24:57 --> Output Class Initialized
INFO - 2023-05-22 10:24:57 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:57 --> Input Class Initialized
INFO - 2023-05-22 10:24:57 --> Language Class Initialized
INFO - 2023-05-22 10:24:57 --> Loader Class Initialized
INFO - 2023-05-22 10:24:57 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:58 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:58 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:58 --> Config Class Initialized
INFO - 2023-05-22 10:24:58 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:58 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:58 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:58 --> URI Class Initialized
INFO - 2023-05-22 10:24:58 --> Router Class Initialized
INFO - 2023-05-22 10:24:58 --> Output Class Initialized
INFO - 2023-05-22 10:24:58 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:58 --> Input Class Initialized
INFO - 2023-05-22 10:24:58 --> Language Class Initialized
INFO - 2023-05-22 10:24:58 --> Loader Class Initialized
INFO - 2023-05-22 10:24:58 --> Controller Class Initialized
DEBUG - 2023-05-22 10:24:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:24:58 --> Database Driver Class Initialized
INFO - 2023-05-22 10:24:59 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:24:59 --> Final output sent to browser
DEBUG - 2023-05-22 10:24:59 --> Total execution time: 2.2463
INFO - 2023-05-22 10:24:59 --> Config Class Initialized
INFO - 2023-05-22 10:24:59 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:24:59 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:24:59 --> Utf8 Class Initialized
INFO - 2023-05-22 10:24:59 --> URI Class Initialized
INFO - 2023-05-22 10:24:59 --> Router Class Initialized
INFO - 2023-05-22 10:24:59 --> Output Class Initialized
INFO - 2023-05-22 10:24:59 --> Security Class Initialized
DEBUG - 2023-05-22 10:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:24:59 --> Input Class Initialized
INFO - 2023-05-22 10:25:00 --> Language Class Initialized
INFO - 2023-05-22 10:25:00 --> Loader Class Initialized
INFO - 2023-05-22 10:25:00 --> Controller Class Initialized
DEBUG - 2023-05-22 10:25:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:25:00 --> Database Driver Class Initialized
INFO - 2023-05-22 10:25:00 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:25:00 --> Final output sent to browser
DEBUG - 2023-05-22 10:25:00 --> Total execution time: 2.3054
INFO - 2023-05-22 10:25:00 --> Config Class Initialized
INFO - 2023-05-22 10:25:00 --> Hooks Class Initialized
DEBUG - 2023-05-22 10:25:00 --> UTF-8 Support Enabled
INFO - 2023-05-22 10:25:00 --> Utf8 Class Initialized
INFO - 2023-05-22 10:25:00 --> URI Class Initialized
INFO - 2023-05-22 10:25:00 --> Router Class Initialized
INFO - 2023-05-22 10:25:00 --> Output Class Initialized
INFO - 2023-05-22 10:25:00 --> Security Class Initialized
DEBUG - 2023-05-22 10:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-22 10:25:00 --> Input Class Initialized
INFO - 2023-05-22 10:25:00 --> Language Class Initialized
INFO - 2023-05-22 10:25:00 --> Loader Class Initialized
INFO - 2023-05-22 10:25:00 --> Controller Class Initialized
DEBUG - 2023-05-22 10:25:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-22 10:25:01 --> Database Driver Class Initialized
INFO - 2023-05-22 10:25:01 --> Model "Cluster_model" initialized
INFO - 2023-05-22 10:25:01 --> Final output sent to browser
DEBUG - 2023-05-22 10:25:01 --> Total execution time: 2.2605
INFO - 2023-05-22 10:25:02 --> Final output sent to browser
DEBUG - 2023-05-22 10:25:02 --> Total execution time: 2.3465
INFO - 2023-05-22 10:25:03 --> Final output sent to browser
DEBUG - 2023-05-22 10:25:03 --> Total execution time: 2.3515
