<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-16 05:40:29 --> Config Class Initialized
INFO - 2023-03-16 05:40:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:29 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:29 --> URI Class Initialized
INFO - 2023-03-16 05:40:29 --> Router Class Initialized
INFO - 2023-03-16 05:40:29 --> Output Class Initialized
INFO - 2023-03-16 05:40:29 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:29 --> Input Class Initialized
INFO - 2023-03-16 05:40:29 --> Language Class Initialized
INFO - 2023-03-16 05:40:29 --> Loader Class Initialized
INFO - 2023-03-16 05:40:29 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:29 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:30 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:30 --> Total execution time: 0.2821
INFO - 2023-03-16 05:40:30 --> Config Class Initialized
INFO - 2023-03-16 05:40:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:30 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:30 --> URI Class Initialized
INFO - 2023-03-16 05:40:30 --> Router Class Initialized
INFO - 2023-03-16 05:40:30 --> Output Class Initialized
INFO - 2023-03-16 05:40:30 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:30 --> Input Class Initialized
INFO - 2023-03-16 05:40:30 --> Language Class Initialized
INFO - 2023-03-16 05:40:30 --> Loader Class Initialized
INFO - 2023-03-16 05:40:30 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:30 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:30 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:30 --> Total execution time: 0.0520
INFO - 2023-03-16 05:40:33 --> Config Class Initialized
INFO - 2023-03-16 05:40:33 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:33 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:33 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:33 --> URI Class Initialized
INFO - 2023-03-16 05:40:33 --> Router Class Initialized
INFO - 2023-03-16 05:40:33 --> Output Class Initialized
INFO - 2023-03-16 05:40:33 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:33 --> Input Class Initialized
INFO - 2023-03-16 05:40:33 --> Language Class Initialized
INFO - 2023-03-16 05:40:33 --> Loader Class Initialized
INFO - 2023-03-16 05:40:33 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:33 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:33 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:33 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:33 --> Model "Login_model" initialized
INFO - 2023-03-16 05:40:33 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:33 --> Total execution time: 0.0846
INFO - 2023-03-16 05:40:33 --> Config Class Initialized
INFO - 2023-03-16 05:40:33 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:33 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:33 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:33 --> URI Class Initialized
INFO - 2023-03-16 05:40:33 --> Router Class Initialized
INFO - 2023-03-16 05:40:33 --> Output Class Initialized
INFO - 2023-03-16 05:40:33 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:33 --> Input Class Initialized
INFO - 2023-03-16 05:40:33 --> Language Class Initialized
INFO - 2023-03-16 05:40:33 --> Loader Class Initialized
INFO - 2023-03-16 05:40:33 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:33 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:33 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:33 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:33 --> Model "Login_model" initialized
INFO - 2023-03-16 05:40:33 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:33 --> Total execution time: 0.0632
INFO - 2023-03-16 05:40:39 --> Config Class Initialized
INFO - 2023-03-16 05:40:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:39 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:39 --> URI Class Initialized
INFO - 2023-03-16 05:40:39 --> Router Class Initialized
INFO - 2023-03-16 05:40:39 --> Output Class Initialized
INFO - 2023-03-16 05:40:39 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:39 --> Input Class Initialized
INFO - 2023-03-16 05:40:39 --> Language Class Initialized
INFO - 2023-03-16 05:40:39 --> Loader Class Initialized
INFO - 2023-03-16 05:40:39 --> Controller Class Initialized
INFO - 2023-03-16 05:40:39 --> Helper loaded: form_helper
INFO - 2023-03-16 05:40:39 --> Helper loaded: url_helper
DEBUG - 2023-03-16 05:40:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:39 --> Model "Change_model" initialized
INFO - 2023-03-16 05:40:39 --> Model "Grafana_model" initialized
INFO - 2023-03-16 05:40:39 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:39 --> Total execution time: 0.0368
INFO - 2023-03-16 05:40:39 --> Config Class Initialized
INFO - 2023-03-16 05:40:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:39 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:39 --> URI Class Initialized
INFO - 2023-03-16 05:40:39 --> Router Class Initialized
INFO - 2023-03-16 05:40:39 --> Output Class Initialized
INFO - 2023-03-16 05:40:39 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:39 --> Input Class Initialized
INFO - 2023-03-16 05:40:39 --> Language Class Initialized
INFO - 2023-03-16 05:40:39 --> Loader Class Initialized
INFO - 2023-03-16 05:40:39 --> Controller Class Initialized
INFO - 2023-03-16 05:40:39 --> Helper loaded: form_helper
INFO - 2023-03-16 05:40:39 --> Helper loaded: url_helper
DEBUG - 2023-03-16 05:40:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:39 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:39 --> Total execution time: 0.0031
INFO - 2023-03-16 05:40:39 --> Config Class Initialized
INFO - 2023-03-16 05:40:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:39 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:39 --> URI Class Initialized
INFO - 2023-03-16 05:40:39 --> Router Class Initialized
INFO - 2023-03-16 05:40:39 --> Output Class Initialized
INFO - 2023-03-16 05:40:39 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:39 --> Input Class Initialized
INFO - 2023-03-16 05:40:39 --> Language Class Initialized
INFO - 2023-03-16 05:40:39 --> Loader Class Initialized
INFO - 2023-03-16 05:40:39 --> Controller Class Initialized
INFO - 2023-03-16 05:40:39 --> Helper loaded: form_helper
INFO - 2023-03-16 05:40:39 --> Helper loaded: url_helper
DEBUG - 2023-03-16 05:40:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:39 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:39 --> Model "Login_model" initialized
INFO - 2023-03-16 05:40:39 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:39 --> Total execution time: 0.0177
INFO - 2023-03-16 05:40:39 --> Config Class Initialized
INFO - 2023-03-16 05:40:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:39 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:39 --> URI Class Initialized
INFO - 2023-03-16 05:40:39 --> Router Class Initialized
INFO - 2023-03-16 05:40:39 --> Output Class Initialized
INFO - 2023-03-16 05:40:39 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:39 --> Input Class Initialized
INFO - 2023-03-16 05:40:39 --> Language Class Initialized
INFO - 2023-03-16 05:40:39 --> Loader Class Initialized
INFO - 2023-03-16 05:40:39 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:39 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:39 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:39 --> Total execution time: 0.0138
INFO - 2023-03-16 05:40:39 --> Config Class Initialized
INFO - 2023-03-16 05:40:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:39 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:39 --> URI Class Initialized
INFO - 2023-03-16 05:40:39 --> Router Class Initialized
INFO - 2023-03-16 05:40:39 --> Output Class Initialized
INFO - 2023-03-16 05:40:39 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:39 --> Input Class Initialized
INFO - 2023-03-16 05:40:39 --> Language Class Initialized
INFO - 2023-03-16 05:40:39 --> Loader Class Initialized
INFO - 2023-03-16 05:40:39 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:39 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:39 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:39 --> Total execution time: 0.0141
INFO - 2023-03-16 05:40:40 --> Config Class Initialized
INFO - 2023-03-16 05:40:40 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:40 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:40 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:40 --> URI Class Initialized
INFO - 2023-03-16 05:40:40 --> Router Class Initialized
INFO - 2023-03-16 05:40:40 --> Output Class Initialized
INFO - 2023-03-16 05:40:40 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:40 --> Input Class Initialized
INFO - 2023-03-16 05:40:40 --> Language Class Initialized
INFO - 2023-03-16 05:40:40 --> Loader Class Initialized
INFO - 2023-03-16 05:40:40 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:40 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:40 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:40 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:40 --> Model "Login_model" initialized
INFO - 2023-03-16 05:40:40 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:40 --> Total execution time: 0.1199
INFO - 2023-03-16 05:40:40 --> Config Class Initialized
INFO - 2023-03-16 05:40:40 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:40 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:40 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:40 --> URI Class Initialized
INFO - 2023-03-16 05:40:40 --> Router Class Initialized
INFO - 2023-03-16 05:40:40 --> Output Class Initialized
INFO - 2023-03-16 05:40:40 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:40 --> Input Class Initialized
INFO - 2023-03-16 05:40:40 --> Language Class Initialized
INFO - 2023-03-16 05:40:40 --> Loader Class Initialized
INFO - 2023-03-16 05:40:40 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:40 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:40 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:40 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:40 --> Model "Login_model" initialized
INFO - 2023-03-16 05:40:40 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:40 --> Total execution time: 0.0782
INFO - 2023-03-16 05:40:44 --> Config Class Initialized
INFO - 2023-03-16 05:40:44 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:44 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:44 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:44 --> URI Class Initialized
INFO - 2023-03-16 05:40:44 --> Router Class Initialized
INFO - 2023-03-16 05:40:44 --> Output Class Initialized
INFO - 2023-03-16 05:40:44 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:44 --> Input Class Initialized
INFO - 2023-03-16 05:40:44 --> Language Class Initialized
INFO - 2023-03-16 05:40:44 --> Loader Class Initialized
INFO - 2023-03-16 05:40:44 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:44 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:44 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:44 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:44 --> Total execution time: 0.0415
INFO - 2023-03-16 05:40:44 --> Config Class Initialized
INFO - 2023-03-16 05:40:45 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:45 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:45 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:45 --> URI Class Initialized
INFO - 2023-03-16 05:40:45 --> Router Class Initialized
INFO - 2023-03-16 05:40:45 --> Output Class Initialized
INFO - 2023-03-16 05:40:45 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:45 --> Input Class Initialized
INFO - 2023-03-16 05:40:45 --> Language Class Initialized
INFO - 2023-03-16 05:40:45 --> Loader Class Initialized
INFO - 2023-03-16 05:40:45 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:45 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:45 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:45 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:45 --> Total execution time: 0.0556
INFO - 2023-03-16 05:40:45 --> Config Class Initialized
INFO - 2023-03-16 05:40:45 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:45 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:45 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:45 --> URI Class Initialized
INFO - 2023-03-16 05:40:45 --> Router Class Initialized
INFO - 2023-03-16 05:40:45 --> Output Class Initialized
INFO - 2023-03-16 05:40:45 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:45 --> Input Class Initialized
INFO - 2023-03-16 05:40:45 --> Language Class Initialized
INFO - 2023-03-16 05:40:45 --> Loader Class Initialized
INFO - 2023-03-16 05:40:45 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:45 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:45 --> Total execution time: 0.0028
INFO - 2023-03-16 05:40:45 --> Config Class Initialized
INFO - 2023-03-16 05:40:45 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:45 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:45 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:45 --> URI Class Initialized
INFO - 2023-03-16 05:40:45 --> Router Class Initialized
INFO - 2023-03-16 05:40:45 --> Output Class Initialized
INFO - 2023-03-16 05:40:45 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:45 --> Input Class Initialized
INFO - 2023-03-16 05:40:45 --> Language Class Initialized
INFO - 2023-03-16 05:40:45 --> Loader Class Initialized
INFO - 2023-03-16 05:40:45 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:45 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:45 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:45 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:45 --> Total execution time: 0.0141
INFO - 2023-03-16 05:40:47 --> Config Class Initialized
INFO - 2023-03-16 05:40:47 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:47 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:47 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:47 --> URI Class Initialized
INFO - 2023-03-16 05:40:47 --> Router Class Initialized
INFO - 2023-03-16 05:40:47 --> Output Class Initialized
INFO - 2023-03-16 05:40:47 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:47 --> Input Class Initialized
INFO - 2023-03-16 05:40:47 --> Language Class Initialized
INFO - 2023-03-16 05:40:47 --> Loader Class Initialized
INFO - 2023-03-16 05:40:47 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:47 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:47 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:47 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:47 --> Total execution time: 0.0132
INFO - 2023-03-16 05:40:48 --> Config Class Initialized
INFO - 2023-03-16 05:40:48 --> Config Class Initialized
INFO - 2023-03-16 05:40:48 --> Hooks Class Initialized
INFO - 2023-03-16 05:40:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:48 --> Utf8 Class Initialized
DEBUG - 2023-03-16 05:40:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:48 --> URI Class Initialized
INFO - 2023-03-16 05:40:48 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:48 --> Router Class Initialized
INFO - 2023-03-16 05:40:48 --> URI Class Initialized
INFO - 2023-03-16 05:40:48 --> Output Class Initialized
INFO - 2023-03-16 05:40:48 --> Router Class Initialized
INFO - 2023-03-16 05:40:48 --> Security Class Initialized
INFO - 2023-03-16 05:40:48 --> Output Class Initialized
INFO - 2023-03-16 05:40:48 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 05:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:48 --> Input Class Initialized
INFO - 2023-03-16 05:40:48 --> Input Class Initialized
INFO - 2023-03-16 05:40:48 --> Language Class Initialized
INFO - 2023-03-16 05:40:48 --> Language Class Initialized
INFO - 2023-03-16 05:40:48 --> Loader Class Initialized
INFO - 2023-03-16 05:40:48 --> Loader Class Initialized
INFO - 2023-03-16 05:40:48 --> Controller Class Initialized
INFO - 2023-03-16 05:40:48 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 05:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:48 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:48 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:48 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:48 --> Total execution time: 0.0187
INFO - 2023-03-16 05:40:48 --> Config Class Initialized
INFO - 2023-03-16 05:40:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:48 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:48 --> URI Class Initialized
INFO - 2023-03-16 05:40:48 --> Router Class Initialized
INFO - 2023-03-16 05:40:48 --> Output Class Initialized
INFO - 2023-03-16 05:40:48 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:48 --> Input Class Initialized
INFO - 2023-03-16 05:40:48 --> Language Class Initialized
INFO - 2023-03-16 05:40:48 --> Loader Class Initialized
INFO - 2023-03-16 05:40:48 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:48 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:48 --> Final output sent to browser
DEBUG - 2023-03-16 05:40:48 --> Total execution time: 0.0915
INFO - 2023-03-16 05:40:48 --> Config Class Initialized
INFO - 2023-03-16 05:40:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:48 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:48 --> URI Class Initialized
INFO - 2023-03-16 05:40:48 --> Router Class Initialized
INFO - 2023-03-16 05:40:48 --> Output Class Initialized
INFO - 2023-03-16 05:40:48 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:48 --> Input Class Initialized
INFO - 2023-03-16 05:40:48 --> Language Class Initialized
INFO - 2023-03-16 05:40:48 --> Loader Class Initialized
INFO - 2023-03-16 05:40:48 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:48 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:50 --> Config Class Initialized
INFO - 2023-03-16 05:40:50 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:50 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:50 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:50 --> URI Class Initialized
INFO - 2023-03-16 05:40:50 --> Router Class Initialized
INFO - 2023-03-16 05:40:50 --> Output Class Initialized
INFO - 2023-03-16 05:40:50 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:50 --> Input Class Initialized
INFO - 2023-03-16 05:40:50 --> Language Class Initialized
INFO - 2023-03-16 05:40:50 --> Loader Class Initialized
INFO - 2023-03-16 05:40:50 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:50 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:50 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:40:50 --> Config Class Initialized
INFO - 2023-03-16 05:40:50 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:40:50 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:40:50 --> Utf8 Class Initialized
INFO - 2023-03-16 05:40:50 --> URI Class Initialized
INFO - 2023-03-16 05:40:50 --> Router Class Initialized
INFO - 2023-03-16 05:40:50 --> Output Class Initialized
INFO - 2023-03-16 05:40:50 --> Security Class Initialized
DEBUG - 2023-03-16 05:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:40:50 --> Input Class Initialized
INFO - 2023-03-16 05:40:50 --> Language Class Initialized
INFO - 2023-03-16 05:40:50 --> Loader Class Initialized
INFO - 2023-03-16 05:40:50 --> Controller Class Initialized
DEBUG - 2023-03-16 05:40:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:40:50 --> Database Driver Class Initialized
INFO - 2023-03-16 05:40:50 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:42:52 --> Config Class Initialized
INFO - 2023-03-16 05:42:52 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:42:52 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:42:52 --> Utf8 Class Initialized
INFO - 2023-03-16 05:42:52 --> URI Class Initialized
INFO - 2023-03-16 05:42:52 --> Router Class Initialized
INFO - 2023-03-16 05:42:52 --> Output Class Initialized
INFO - 2023-03-16 05:42:52 --> Security Class Initialized
DEBUG - 2023-03-16 05:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:42:52 --> Input Class Initialized
INFO - 2023-03-16 05:42:52 --> Language Class Initialized
INFO - 2023-03-16 05:42:52 --> Loader Class Initialized
INFO - 2023-03-16 05:42:53 --> Controller Class Initialized
DEBUG - 2023-03-16 05:42:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:42:53 --> Database Driver Class Initialized
INFO - 2023-03-16 05:42:53 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:42:53 --> Database Driver Class Initialized
INFO - 2023-03-16 05:42:53 --> Model "Login_model" initialized
INFO - 2023-03-16 05:42:53 --> Final output sent to browser
DEBUG - 2023-03-16 05:42:53 --> Total execution time: 0.6288
INFO - 2023-03-16 05:42:53 --> Config Class Initialized
INFO - 2023-03-16 05:42:53 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:42:53 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:42:53 --> Utf8 Class Initialized
INFO - 2023-03-16 05:42:53 --> URI Class Initialized
INFO - 2023-03-16 05:42:53 --> Router Class Initialized
INFO - 2023-03-16 05:42:53 --> Output Class Initialized
INFO - 2023-03-16 05:42:53 --> Security Class Initialized
DEBUG - 2023-03-16 05:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:42:53 --> Input Class Initialized
INFO - 2023-03-16 05:42:53 --> Language Class Initialized
INFO - 2023-03-16 05:42:53 --> Loader Class Initialized
INFO - 2023-03-16 05:42:53 --> Controller Class Initialized
DEBUG - 2023-03-16 05:42:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:42:53 --> Database Driver Class Initialized
INFO - 2023-03-16 05:42:53 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:42:53 --> Database Driver Class Initialized
INFO - 2023-03-16 05:42:53 --> Model "Login_model" initialized
INFO - 2023-03-16 05:42:53 --> Final output sent to browser
DEBUG - 2023-03-16 05:42:53 --> Total execution time: 0.0388
INFO - 2023-03-16 05:43:17 --> Config Class Initialized
INFO - 2023-03-16 05:43:17 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:17 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:17 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:17 --> URI Class Initialized
INFO - 2023-03-16 05:43:17 --> Router Class Initialized
INFO - 2023-03-16 05:43:17 --> Output Class Initialized
INFO - 2023-03-16 05:43:17 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:17 --> Input Class Initialized
INFO - 2023-03-16 05:43:17 --> Language Class Initialized
INFO - 2023-03-16 05:43:17 --> Loader Class Initialized
INFO - 2023-03-16 05:43:17 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:17 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:17 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:17 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:17 --> Model "Login_model" initialized
INFO - 2023-03-16 05:43:17 --> Final output sent to browser
DEBUG - 2023-03-16 05:43:17 --> Total execution time: 0.1862
INFO - 2023-03-16 05:43:17 --> Config Class Initialized
INFO - 2023-03-16 05:43:17 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:17 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:17 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:17 --> URI Class Initialized
INFO - 2023-03-16 05:43:17 --> Router Class Initialized
INFO - 2023-03-16 05:43:17 --> Output Class Initialized
INFO - 2023-03-16 05:43:17 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:17 --> Input Class Initialized
INFO - 2023-03-16 05:43:17 --> Language Class Initialized
INFO - 2023-03-16 05:43:17 --> Loader Class Initialized
INFO - 2023-03-16 05:43:17 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:17 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:17 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:17 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:17 --> Model "Login_model" initialized
INFO - 2023-03-16 05:43:17 --> Final output sent to browser
DEBUG - 2023-03-16 05:43:17 --> Total execution time: 0.0447
INFO - 2023-03-16 05:43:42 --> Config Class Initialized
INFO - 2023-03-16 05:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:42 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:42 --> URI Class Initialized
INFO - 2023-03-16 05:43:42 --> Router Class Initialized
INFO - 2023-03-16 05:43:42 --> Output Class Initialized
INFO - 2023-03-16 05:43:42 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:42 --> Input Class Initialized
INFO - 2023-03-16 05:43:42 --> Language Class Initialized
INFO - 2023-03-16 05:43:42 --> Loader Class Initialized
INFO - 2023-03-16 05:43:42 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:42 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:42 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:42 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:42 --> Model "Login_model" initialized
INFO - 2023-03-16 05:43:42 --> Final output sent to browser
DEBUG - 2023-03-16 05:43:42 --> Total execution time: 0.0382
INFO - 2023-03-16 05:43:42 --> Config Class Initialized
INFO - 2023-03-16 05:43:42 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:42 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:42 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:42 --> URI Class Initialized
INFO - 2023-03-16 05:43:42 --> Router Class Initialized
INFO - 2023-03-16 05:43:42 --> Output Class Initialized
INFO - 2023-03-16 05:43:42 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:42 --> Input Class Initialized
INFO - 2023-03-16 05:43:42 --> Language Class Initialized
INFO - 2023-03-16 05:43:42 --> Loader Class Initialized
INFO - 2023-03-16 05:43:42 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:42 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:42 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:42 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:42 --> Model "Login_model" initialized
INFO - 2023-03-16 05:43:42 --> Final output sent to browser
DEBUG - 2023-03-16 05:43:42 --> Total execution time: 0.0399
INFO - 2023-03-16 05:43:47 --> Config Class Initialized
INFO - 2023-03-16 05:43:47 --> Config Class Initialized
INFO - 2023-03-16 05:43:47 --> Hooks Class Initialized
INFO - 2023-03-16 05:43:47 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 05:43:47 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:47 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:47 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:47 --> URI Class Initialized
INFO - 2023-03-16 05:43:47 --> URI Class Initialized
INFO - 2023-03-16 05:43:47 --> Router Class Initialized
INFO - 2023-03-16 05:43:47 --> Router Class Initialized
INFO - 2023-03-16 05:43:47 --> Output Class Initialized
INFO - 2023-03-16 05:43:47 --> Output Class Initialized
INFO - 2023-03-16 05:43:47 --> Security Class Initialized
INFO - 2023-03-16 05:43:47 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 05:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:47 --> Input Class Initialized
INFO - 2023-03-16 05:43:47 --> Input Class Initialized
INFO - 2023-03-16 05:43:47 --> Language Class Initialized
INFO - 2023-03-16 05:43:47 --> Language Class Initialized
INFO - 2023-03-16 05:43:47 --> Loader Class Initialized
INFO - 2023-03-16 05:43:47 --> Loader Class Initialized
INFO - 2023-03-16 05:43:47 --> Controller Class Initialized
INFO - 2023-03-16 05:43:47 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 05:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:47 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:47 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:47 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:47 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:47 --> Final output sent to browser
DEBUG - 2023-03-16 05:43:47 --> Total execution time: 0.0176
INFO - 2023-03-16 05:43:47 --> Config Class Initialized
INFO - 2023-03-16 05:43:47 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:47 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:47 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:47 --> URI Class Initialized
INFO - 2023-03-16 05:43:47 --> Router Class Initialized
INFO - 2023-03-16 05:43:47 --> Output Class Initialized
INFO - 2023-03-16 05:43:47 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:47 --> Input Class Initialized
INFO - 2023-03-16 05:43:47 --> Language Class Initialized
INFO - 2023-03-16 05:43:47 --> Loader Class Initialized
INFO - 2023-03-16 05:43:47 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:47 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:47 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:47 --> Final output sent to browser
DEBUG - 2023-03-16 05:43:47 --> Total execution time: 0.0521
INFO - 2023-03-16 05:43:47 --> Config Class Initialized
INFO - 2023-03-16 05:43:47 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:47 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:47 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:47 --> URI Class Initialized
INFO - 2023-03-16 05:43:47 --> Router Class Initialized
INFO - 2023-03-16 05:43:47 --> Output Class Initialized
INFO - 2023-03-16 05:43:47 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:47 --> Input Class Initialized
INFO - 2023-03-16 05:43:47 --> Language Class Initialized
INFO - 2023-03-16 05:43:47 --> Loader Class Initialized
INFO - 2023-03-16 05:43:47 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:47 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:47 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:48 --> Config Class Initialized
INFO - 2023-03-16 05:43:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:48 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:48 --> URI Class Initialized
INFO - 2023-03-16 05:43:48 --> Router Class Initialized
INFO - 2023-03-16 05:43:48 --> Output Class Initialized
INFO - 2023-03-16 05:43:48 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:48 --> Input Class Initialized
INFO - 2023-03-16 05:43:48 --> Language Class Initialized
INFO - 2023-03-16 05:43:48 --> Loader Class Initialized
INFO - 2023-03-16 05:43:48 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:48 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:43:48 --> Config Class Initialized
INFO - 2023-03-16 05:43:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:43:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:43:48 --> Utf8 Class Initialized
INFO - 2023-03-16 05:43:48 --> URI Class Initialized
INFO - 2023-03-16 05:43:48 --> Router Class Initialized
INFO - 2023-03-16 05:43:48 --> Output Class Initialized
INFO - 2023-03-16 05:43:48 --> Security Class Initialized
DEBUG - 2023-03-16 05:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:43:48 --> Input Class Initialized
INFO - 2023-03-16 05:43:48 --> Language Class Initialized
INFO - 2023-03-16 05:43:48 --> Loader Class Initialized
INFO - 2023-03-16 05:43:48 --> Controller Class Initialized
DEBUG - 2023-03-16 05:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:43:48 --> Database Driver Class Initialized
INFO - 2023-03-16 05:43:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:44:03 --> Config Class Initialized
INFO - 2023-03-16 05:44:03 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:44:03 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:44:03 --> Utf8 Class Initialized
INFO - 2023-03-16 05:44:03 --> URI Class Initialized
INFO - 2023-03-16 05:44:03 --> Router Class Initialized
INFO - 2023-03-16 05:44:03 --> Output Class Initialized
INFO - 2023-03-16 05:44:03 --> Security Class Initialized
DEBUG - 2023-03-16 05:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:44:03 --> Input Class Initialized
INFO - 2023-03-16 05:44:03 --> Language Class Initialized
INFO - 2023-03-16 05:44:03 --> Loader Class Initialized
INFO - 2023-03-16 05:44:03 --> Controller Class Initialized
DEBUG - 2023-03-16 05:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:44:03 --> Database Driver Class Initialized
INFO - 2023-03-16 05:44:03 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:44:03 --> Config Class Initialized
INFO - 2023-03-16 05:44:03 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:44:03 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:44:03 --> Utf8 Class Initialized
INFO - 2023-03-16 05:44:03 --> URI Class Initialized
INFO - 2023-03-16 05:44:03 --> Router Class Initialized
INFO - 2023-03-16 05:44:03 --> Output Class Initialized
INFO - 2023-03-16 05:44:03 --> Security Class Initialized
DEBUG - 2023-03-16 05:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:44:03 --> Input Class Initialized
INFO - 2023-03-16 05:44:03 --> Language Class Initialized
INFO - 2023-03-16 05:44:03 --> Loader Class Initialized
INFO - 2023-03-16 05:44:03 --> Controller Class Initialized
DEBUG - 2023-03-16 05:44:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:44:03 --> Database Driver Class Initialized
INFO - 2023-03-16 05:44:03 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:44:23 --> Config Class Initialized
INFO - 2023-03-16 05:44:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:44:23 --> Utf8 Class Initialized
INFO - 2023-03-16 05:44:23 --> URI Class Initialized
INFO - 2023-03-16 05:44:23 --> Router Class Initialized
INFO - 2023-03-16 05:44:23 --> Output Class Initialized
INFO - 2023-03-16 05:44:23 --> Security Class Initialized
DEBUG - 2023-03-16 05:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:44:23 --> Input Class Initialized
INFO - 2023-03-16 05:44:23 --> Language Class Initialized
INFO - 2023-03-16 05:44:23 --> Loader Class Initialized
INFO - 2023-03-16 05:44:23 --> Controller Class Initialized
DEBUG - 2023-03-16 05:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
ERROR - 2023-03-16 05:44:23 --> Exception of type 'ApiException' occurred with Message: token不能为空 in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/ClusterSetting.php at Line 224
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): ClusterSetting->tableRepartition()
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#2 {main}
INFO - 2023-03-16 05:44:23 --> Config Class Initialized
INFO - 2023-03-16 05:44:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:44:23 --> Utf8 Class Initialized
INFO - 2023-03-16 05:44:23 --> URI Class Initialized
INFO - 2023-03-16 05:44:23 --> Router Class Initialized
INFO - 2023-03-16 05:44:23 --> Output Class Initialized
INFO - 2023-03-16 05:44:23 --> Security Class Initialized
DEBUG - 2023-03-16 05:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:44:23 --> Input Class Initialized
INFO - 2023-03-16 05:44:23 --> Language Class Initialized
INFO - 2023-03-16 05:44:23 --> Loader Class Initialized
INFO - 2023-03-16 05:44:23 --> Controller Class Initialized
DEBUG - 2023-03-16 05:44:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:44:23 --> Database Driver Class Initialized
INFO - 2023-03-16 05:44:23 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:44:23 --> Final output sent to browser
DEBUG - 2023-03-16 05:44:23 --> Total execution time: 0.0160
INFO - 2023-03-16 05:44:24 --> Config Class Initialized
INFO - 2023-03-16 05:44:24 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:44:24 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:44:24 --> Utf8 Class Initialized
INFO - 2023-03-16 05:44:24 --> URI Class Initialized
INFO - 2023-03-16 05:44:24 --> Router Class Initialized
INFO - 2023-03-16 05:44:24 --> Output Class Initialized
INFO - 2023-03-16 05:44:24 --> Security Class Initialized
DEBUG - 2023-03-16 05:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:44:24 --> Input Class Initialized
INFO - 2023-03-16 05:44:24 --> Language Class Initialized
INFO - 2023-03-16 05:44:24 --> Loader Class Initialized
INFO - 2023-03-16 05:44:24 --> Controller Class Initialized
DEBUG - 2023-03-16 05:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:44:24 --> Final output sent to browser
DEBUG - 2023-03-16 05:44:24 --> Total execution time: 0.0040
INFO - 2023-03-16 05:44:24 --> Config Class Initialized
INFO - 2023-03-16 05:44:24 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:44:24 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:44:24 --> Utf8 Class Initialized
INFO - 2023-03-16 05:44:24 --> URI Class Initialized
INFO - 2023-03-16 05:44:24 --> Router Class Initialized
INFO - 2023-03-16 05:44:24 --> Output Class Initialized
INFO - 2023-03-16 05:44:24 --> Security Class Initialized
DEBUG - 2023-03-16 05:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:44:24 --> Input Class Initialized
INFO - 2023-03-16 05:44:24 --> Language Class Initialized
INFO - 2023-03-16 05:44:24 --> Loader Class Initialized
INFO - 2023-03-16 05:44:24 --> Controller Class Initialized
DEBUG - 2023-03-16 05:44:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:44:24 --> Database Driver Class Initialized
INFO - 2023-03-16 05:44:24 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:44:24 --> Final output sent to browser
DEBUG - 2023-03-16 05:44:24 --> Total execution time: 0.0198
INFO - 2023-03-16 05:46:51 --> Config Class Initialized
INFO - 2023-03-16 05:46:51 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:46:51 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:46:51 --> Utf8 Class Initialized
INFO - 2023-03-16 05:46:51 --> URI Class Initialized
INFO - 2023-03-16 05:46:51 --> Router Class Initialized
INFO - 2023-03-16 05:46:51 --> Output Class Initialized
INFO - 2023-03-16 05:46:51 --> Security Class Initialized
DEBUG - 2023-03-16 05:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:46:51 --> Input Class Initialized
INFO - 2023-03-16 05:46:51 --> Language Class Initialized
INFO - 2023-03-16 05:46:51 --> Loader Class Initialized
INFO - 2023-03-16 05:46:51 --> Controller Class Initialized
DEBUG - 2023-03-16 05:46:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:46:51 --> Database Driver Class Initialized
INFO - 2023-03-16 05:46:51 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:46:51 --> Database Driver Class Initialized
INFO - 2023-03-16 05:46:51 --> Model "Login_model" initialized
INFO - 2023-03-16 05:46:51 --> Final output sent to browser
DEBUG - 2023-03-16 05:46:51 --> Total execution time: 0.1665
INFO - 2023-03-16 05:46:51 --> Config Class Initialized
INFO - 2023-03-16 05:46:51 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:46:51 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:46:51 --> Utf8 Class Initialized
INFO - 2023-03-16 05:46:51 --> URI Class Initialized
INFO - 2023-03-16 05:46:51 --> Router Class Initialized
INFO - 2023-03-16 05:46:51 --> Output Class Initialized
INFO - 2023-03-16 05:46:51 --> Security Class Initialized
DEBUG - 2023-03-16 05:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:46:51 --> Input Class Initialized
INFO - 2023-03-16 05:46:51 --> Language Class Initialized
INFO - 2023-03-16 05:46:51 --> Loader Class Initialized
INFO - 2023-03-16 05:46:51 --> Controller Class Initialized
DEBUG - 2023-03-16 05:46:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:46:51 --> Database Driver Class Initialized
INFO - 2023-03-16 05:46:51 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:46:51 --> Database Driver Class Initialized
INFO - 2023-03-16 05:46:51 --> Model "Login_model" initialized
INFO - 2023-03-16 05:46:51 --> Final output sent to browser
DEBUG - 2023-03-16 05:46:51 --> Total execution time: 0.0890
INFO - 2023-03-16 05:47:07 --> Config Class Initialized
INFO - 2023-03-16 05:47:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:07 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:07 --> URI Class Initialized
INFO - 2023-03-16 05:47:07 --> Router Class Initialized
INFO - 2023-03-16 05:47:07 --> Output Class Initialized
INFO - 2023-03-16 05:47:07 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:07 --> Input Class Initialized
INFO - 2023-03-16 05:47:07 --> Language Class Initialized
INFO - 2023-03-16 05:47:07 --> Loader Class Initialized
INFO - 2023-03-16 05:47:07 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:07 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:07 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:07 --> Total execution time: 0.0787
INFO - 2023-03-16 05:47:07 --> Config Class Initialized
INFO - 2023-03-16 05:47:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:07 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:07 --> URI Class Initialized
INFO - 2023-03-16 05:47:07 --> Router Class Initialized
INFO - 2023-03-16 05:47:07 --> Output Class Initialized
INFO - 2023-03-16 05:47:07 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:07 --> Input Class Initialized
INFO - 2023-03-16 05:47:07 --> Language Class Initialized
INFO - 2023-03-16 05:47:07 --> Loader Class Initialized
INFO - 2023-03-16 05:47:07 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:07 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:07 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:07 --> Total execution time: 0.0637
INFO - 2023-03-16 05:47:07 --> Config Class Initialized
INFO - 2023-03-16 05:47:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:07 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:07 --> URI Class Initialized
INFO - 2023-03-16 05:47:07 --> Router Class Initialized
INFO - 2023-03-16 05:47:07 --> Output Class Initialized
INFO - 2023-03-16 05:47:07 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:07 --> Input Class Initialized
INFO - 2023-03-16 05:47:07 --> Language Class Initialized
INFO - 2023-03-16 05:47:07 --> Loader Class Initialized
INFO - 2023-03-16 05:47:07 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:07 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:07 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:07 --> Total execution time: 0.0210
INFO - 2023-03-16 05:47:07 --> Config Class Initialized
INFO - 2023-03-16 05:47:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:07 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:07 --> URI Class Initialized
INFO - 2023-03-16 05:47:07 --> Router Class Initialized
INFO - 2023-03-16 05:47:07 --> Output Class Initialized
INFO - 2023-03-16 05:47:07 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:07 --> Input Class Initialized
INFO - 2023-03-16 05:47:07 --> Language Class Initialized
INFO - 2023-03-16 05:47:07 --> Loader Class Initialized
INFO - 2023-03-16 05:47:07 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:07 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:07 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:07 --> Total execution time: 0.0143
INFO - 2023-03-16 05:47:08 --> Config Class Initialized
INFO - 2023-03-16 05:47:08 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:08 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:08 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:08 --> URI Class Initialized
INFO - 2023-03-16 05:47:08 --> Router Class Initialized
INFO - 2023-03-16 05:47:08 --> Output Class Initialized
INFO - 2023-03-16 05:47:08 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:08 --> Input Class Initialized
INFO - 2023-03-16 05:47:08 --> Language Class Initialized
INFO - 2023-03-16 05:47:08 --> Loader Class Initialized
INFO - 2023-03-16 05:47:08 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:08 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:08 --> Total execution time: 0.0026
INFO - 2023-03-16 05:47:08 --> Config Class Initialized
INFO - 2023-03-16 05:47:08 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:08 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:08 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:08 --> URI Class Initialized
INFO - 2023-03-16 05:47:08 --> Router Class Initialized
INFO - 2023-03-16 05:47:08 --> Output Class Initialized
INFO - 2023-03-16 05:47:08 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:08 --> Input Class Initialized
INFO - 2023-03-16 05:47:08 --> Language Class Initialized
INFO - 2023-03-16 05:47:08 --> Loader Class Initialized
INFO - 2023-03-16 05:47:08 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:08 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:08 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:08 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:08 --> Total execution time: 0.0360
INFO - 2023-03-16 05:47:09 --> Config Class Initialized
INFO - 2023-03-16 05:47:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:09 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:09 --> URI Class Initialized
INFO - 2023-03-16 05:47:09 --> Router Class Initialized
INFO - 2023-03-16 05:47:09 --> Output Class Initialized
INFO - 2023-03-16 05:47:09 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:09 --> Input Class Initialized
INFO - 2023-03-16 05:47:09 --> Language Class Initialized
INFO - 2023-03-16 05:47:09 --> Loader Class Initialized
INFO - 2023-03-16 05:47:09 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:09 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:09 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:09 --> Total execution time: 0.0158
INFO - 2023-03-16 05:47:13 --> Config Class Initialized
INFO - 2023-03-16 05:47:13 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:13 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:13 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:13 --> URI Class Initialized
INFO - 2023-03-16 05:47:13 --> Router Class Initialized
INFO - 2023-03-16 05:47:13 --> Output Class Initialized
INFO - 2023-03-16 05:47:13 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:13 --> Input Class Initialized
INFO - 2023-03-16 05:47:13 --> Language Class Initialized
INFO - 2023-03-16 05:47:13 --> Loader Class Initialized
INFO - 2023-03-16 05:47:13 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:13 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:13 --> Total execution time: 0.0103
INFO - 2023-03-16 05:47:13 --> Config Class Initialized
INFO - 2023-03-16 05:47:13 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:13 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:13 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:13 --> URI Class Initialized
INFO - 2023-03-16 05:47:13 --> Router Class Initialized
INFO - 2023-03-16 05:47:13 --> Output Class Initialized
INFO - 2023-03-16 05:47:13 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:13 --> Input Class Initialized
INFO - 2023-03-16 05:47:13 --> Language Class Initialized
INFO - 2023-03-16 05:47:13 --> Loader Class Initialized
INFO - 2023-03-16 05:47:13 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:13 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:13 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:13 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:13 --> Total execution time: 0.0115
INFO - 2023-03-16 05:47:14 --> Config Class Initialized
INFO - 2023-03-16 05:47:14 --> Config Class Initialized
INFO - 2023-03-16 05:47:14 --> Hooks Class Initialized
INFO - 2023-03-16 05:47:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:14 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 05:47:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:14 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:14 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:14 --> URI Class Initialized
INFO - 2023-03-16 05:47:14 --> URI Class Initialized
INFO - 2023-03-16 05:47:14 --> Router Class Initialized
INFO - 2023-03-16 05:47:14 --> Router Class Initialized
INFO - 2023-03-16 05:47:14 --> Output Class Initialized
INFO - 2023-03-16 05:47:14 --> Output Class Initialized
INFO - 2023-03-16 05:47:14 --> Security Class Initialized
INFO - 2023-03-16 05:47:14 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 05:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:14 --> Input Class Initialized
INFO - 2023-03-16 05:47:14 --> Input Class Initialized
INFO - 2023-03-16 05:47:14 --> Language Class Initialized
INFO - 2023-03-16 05:47:14 --> Language Class Initialized
INFO - 2023-03-16 05:47:14 --> Loader Class Initialized
INFO - 2023-03-16 05:47:14 --> Loader Class Initialized
INFO - 2023-03-16 05:47:14 --> Controller Class Initialized
INFO - 2023-03-16 05:47:14 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 05:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:14 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:14 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:14 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:14 --> Total execution time: 0.0151
INFO - 2023-03-16 05:47:14 --> Config Class Initialized
INFO - 2023-03-16 05:47:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:14 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:14 --> URI Class Initialized
INFO - 2023-03-16 05:47:14 --> Router Class Initialized
INFO - 2023-03-16 05:47:14 --> Output Class Initialized
INFO - 2023-03-16 05:47:14 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:14 --> Input Class Initialized
INFO - 2023-03-16 05:47:14 --> Language Class Initialized
INFO - 2023-03-16 05:47:14 --> Loader Class Initialized
INFO - 2023-03-16 05:47:14 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:14 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:14 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:14 --> Total execution time: 0.0503
INFO - 2023-03-16 05:47:14 --> Config Class Initialized
INFO - 2023-03-16 05:47:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:14 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:14 --> URI Class Initialized
INFO - 2023-03-16 05:47:14 --> Router Class Initialized
INFO - 2023-03-16 05:47:14 --> Output Class Initialized
INFO - 2023-03-16 05:47:14 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:14 --> Input Class Initialized
INFO - 2023-03-16 05:47:14 --> Language Class Initialized
INFO - 2023-03-16 05:47:14 --> Loader Class Initialized
INFO - 2023-03-16 05:47:14 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:14 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:15 --> Config Class Initialized
INFO - 2023-03-16 05:47:15 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:15 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:15 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:15 --> URI Class Initialized
INFO - 2023-03-16 05:47:15 --> Router Class Initialized
INFO - 2023-03-16 05:47:15 --> Output Class Initialized
INFO - 2023-03-16 05:47:15 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:15 --> Input Class Initialized
INFO - 2023-03-16 05:47:15 --> Language Class Initialized
INFO - 2023-03-16 05:47:15 --> Loader Class Initialized
INFO - 2023-03-16 05:47:15 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:15 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:15 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:15 --> Config Class Initialized
INFO - 2023-03-16 05:47:15 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:15 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:15 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:15 --> URI Class Initialized
INFO - 2023-03-16 05:47:15 --> Router Class Initialized
INFO - 2023-03-16 05:47:15 --> Output Class Initialized
INFO - 2023-03-16 05:47:15 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:15 --> Input Class Initialized
INFO - 2023-03-16 05:47:15 --> Language Class Initialized
INFO - 2023-03-16 05:47:15 --> Loader Class Initialized
INFO - 2023-03-16 05:47:15 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:15 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:15 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:16 --> Config Class Initialized
INFO - 2023-03-16 05:47:16 --> Config Class Initialized
INFO - 2023-03-16 05:47:16 --> Hooks Class Initialized
INFO - 2023-03-16 05:47:16 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:47:16 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 05:47:16 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:47:16 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:16 --> Utf8 Class Initialized
INFO - 2023-03-16 05:47:16 --> URI Class Initialized
INFO - 2023-03-16 05:47:16 --> URI Class Initialized
INFO - 2023-03-16 05:47:16 --> Router Class Initialized
INFO - 2023-03-16 05:47:16 --> Router Class Initialized
INFO - 2023-03-16 05:47:16 --> Output Class Initialized
INFO - 2023-03-16 05:47:16 --> Output Class Initialized
INFO - 2023-03-16 05:47:16 --> Security Class Initialized
INFO - 2023-03-16 05:47:16 --> Security Class Initialized
DEBUG - 2023-03-16 05:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:16 --> Input Class Initialized
DEBUG - 2023-03-16 05:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:47:16 --> Language Class Initialized
INFO - 2023-03-16 05:47:16 --> Input Class Initialized
INFO - 2023-03-16 05:47:16 --> Language Class Initialized
INFO - 2023-03-16 05:47:16 --> Loader Class Initialized
INFO - 2023-03-16 05:47:16 --> Loader Class Initialized
INFO - 2023-03-16 05:47:16 --> Controller Class Initialized
INFO - 2023-03-16 05:47:16 --> Controller Class Initialized
DEBUG - 2023-03-16 05:47:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 05:47:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:47:16 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:16 --> Database Driver Class Initialized
INFO - 2023-03-16 05:47:16 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:16 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:47:16 --> Final output sent to browser
DEBUG - 2023-03-16 05:47:16 --> Total execution time: 0.0153
INFO - 2023-03-16 05:48:21 --> Config Class Initialized
INFO - 2023-03-16 05:48:21 --> Config Class Initialized
INFO - 2023-03-16 05:48:21 --> Hooks Class Initialized
INFO - 2023-03-16 05:48:21 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:21 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 05:48:21 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:21 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:21 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:21 --> URI Class Initialized
INFO - 2023-03-16 05:48:21 --> URI Class Initialized
INFO - 2023-03-16 05:48:21 --> Router Class Initialized
INFO - 2023-03-16 05:48:21 --> Router Class Initialized
INFO - 2023-03-16 05:48:21 --> Output Class Initialized
INFO - 2023-03-16 05:48:21 --> Output Class Initialized
INFO - 2023-03-16 05:48:21 --> Security Class Initialized
INFO - 2023-03-16 05:48:21 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 05:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:21 --> Input Class Initialized
INFO - 2023-03-16 05:48:21 --> Input Class Initialized
INFO - 2023-03-16 05:48:21 --> Language Class Initialized
INFO - 2023-03-16 05:48:21 --> Language Class Initialized
INFO - 2023-03-16 05:48:21 --> Loader Class Initialized
INFO - 2023-03-16 05:48:21 --> Loader Class Initialized
INFO - 2023-03-16 05:48:21 --> Controller Class Initialized
INFO - 2023-03-16 05:48:21 --> Controller Class Initialized
DEBUG - 2023-03-16 05:48:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 05:48:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:21 --> Final output sent to browser
INFO - 2023-03-16 05:48:21 --> Database Driver Class Initialized
DEBUG - 2023-03-16 05:48:21 --> Total execution time: 0.0057
INFO - 2023-03-16 05:48:21 --> Config Class Initialized
INFO - 2023-03-16 05:48:21 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:21 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:21 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:21 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:21 --> URI Class Initialized
INFO - 2023-03-16 05:48:21 --> Router Class Initialized
INFO - 2023-03-16 05:48:21 --> Output Class Initialized
INFO - 2023-03-16 05:48:21 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:21 --> Input Class Initialized
INFO - 2023-03-16 05:48:21 --> Language Class Initialized
INFO - 2023-03-16 05:48:21 --> Loader Class Initialized
INFO - 2023-03-16 05:48:21 --> Controller Class Initialized
DEBUG - 2023-03-16 05:48:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:21 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:21 --> Final output sent to browser
DEBUG - 2023-03-16 05:48:21 --> Total execution time: 0.0508
INFO - 2023-03-16 05:48:21 --> Config Class Initialized
INFO - 2023-03-16 05:48:21 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:21 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:21 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:21 --> URI Class Initialized
INFO - 2023-03-16 05:48:21 --> Router Class Initialized
INFO - 2023-03-16 05:48:21 --> Output Class Initialized
INFO - 2023-03-16 05:48:21 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:21 --> Input Class Initialized
INFO - 2023-03-16 05:48:21 --> Language Class Initialized
INFO - 2023-03-16 05:48:21 --> Loader Class Initialized
INFO - 2023-03-16 05:48:21 --> Controller Class Initialized
INFO - 2023-03-16 05:48:21 --> Model "Login_model" initialized
DEBUG - 2023-03-16 05:48:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:21 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:21 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:21 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:21 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:21 --> Final output sent to browser
DEBUG - 2023-03-16 05:48:21 --> Total execution time: 0.0609
INFO - 2023-03-16 05:48:21 --> Final output sent to browser
DEBUG - 2023-03-16 05:48:21 --> Total execution time: 0.0187
INFO - 2023-03-16 05:48:23 --> Config Class Initialized
INFO - 2023-03-16 05:48:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:23 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:23 --> URI Class Initialized
INFO - 2023-03-16 05:48:23 --> Router Class Initialized
INFO - 2023-03-16 05:48:23 --> Output Class Initialized
INFO - 2023-03-16 05:48:23 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:23 --> Input Class Initialized
INFO - 2023-03-16 05:48:23 --> Language Class Initialized
INFO - 2023-03-16 05:48:23 --> Loader Class Initialized
INFO - 2023-03-16 05:48:23 --> Controller Class Initialized
DEBUG - 2023-03-16 05:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:23 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:23 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:23 --> Final output sent to browser
INFO - 2023-03-16 05:48:23 --> Config Class Initialized
INFO - 2023-03-16 05:48:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:23 --> Total execution time: 0.0622
DEBUG - 2023-03-16 05:48:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:23 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:23 --> URI Class Initialized
INFO - 2023-03-16 05:48:23 --> Router Class Initialized
INFO - 2023-03-16 05:48:23 --> Output Class Initialized
INFO - 2023-03-16 05:48:23 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:23 --> Input Class Initialized
INFO - 2023-03-16 05:48:23 --> Language Class Initialized
INFO - 2023-03-16 05:48:23 --> Loader Class Initialized
INFO - 2023-03-16 05:48:23 --> Controller Class Initialized
DEBUG - 2023-03-16 05:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:23 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:23 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:23 --> Final output sent to browser
DEBUG - 2023-03-16 05:48:23 --> Total execution time: 0.0818
INFO - 2023-03-16 05:48:28 --> Config Class Initialized
INFO - 2023-03-16 05:48:28 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:28 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:28 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:28 --> URI Class Initialized
INFO - 2023-03-16 05:48:28 --> Router Class Initialized
INFO - 2023-03-16 05:48:28 --> Output Class Initialized
INFO - 2023-03-16 05:48:28 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:28 --> Input Class Initialized
INFO - 2023-03-16 05:48:28 --> Language Class Initialized
INFO - 2023-03-16 05:48:28 --> Loader Class Initialized
INFO - 2023-03-16 05:48:28 --> Controller Class Initialized
DEBUG - 2023-03-16 05:48:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:28 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:28 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:28 --> Final output sent to browser
DEBUG - 2023-03-16 05:48:28 --> Total execution time: 0.0173
INFO - 2023-03-16 05:48:28 --> Config Class Initialized
INFO - 2023-03-16 05:48:28 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:28 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:28 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:28 --> URI Class Initialized
INFO - 2023-03-16 05:48:28 --> Router Class Initialized
INFO - 2023-03-16 05:48:28 --> Output Class Initialized
INFO - 2023-03-16 05:48:28 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:28 --> Input Class Initialized
INFO - 2023-03-16 05:48:28 --> Language Class Initialized
INFO - 2023-03-16 05:48:28 --> Loader Class Initialized
INFO - 2023-03-16 05:48:28 --> Controller Class Initialized
DEBUG - 2023-03-16 05:48:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:28 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:28 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:28 --> Final output sent to browser
DEBUG - 2023-03-16 05:48:28 --> Total execution time: 0.0542
INFO - 2023-03-16 05:48:34 --> Config Class Initialized
INFO - 2023-03-16 05:48:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:34 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:34 --> URI Class Initialized
INFO - 2023-03-16 05:48:34 --> Router Class Initialized
INFO - 2023-03-16 05:48:34 --> Output Class Initialized
INFO - 2023-03-16 05:48:34 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:34 --> Input Class Initialized
INFO - 2023-03-16 05:48:34 --> Language Class Initialized
INFO - 2023-03-16 05:48:34 --> Loader Class Initialized
INFO - 2023-03-16 05:48:34 --> Controller Class Initialized
DEBUG - 2023-03-16 05:48:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:34 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:34 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:34 --> Model "Login_model" initialized
INFO - 2023-03-16 05:48:34 --> Final output sent to browser
DEBUG - 2023-03-16 05:48:34 --> Total execution time: 0.0470
INFO - 2023-03-16 05:48:34 --> Config Class Initialized
INFO - 2023-03-16 05:48:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 05:48:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 05:48:34 --> Utf8 Class Initialized
INFO - 2023-03-16 05:48:34 --> URI Class Initialized
INFO - 2023-03-16 05:48:34 --> Router Class Initialized
INFO - 2023-03-16 05:48:34 --> Output Class Initialized
INFO - 2023-03-16 05:48:34 --> Security Class Initialized
DEBUG - 2023-03-16 05:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 05:48:34 --> Input Class Initialized
INFO - 2023-03-16 05:48:34 --> Language Class Initialized
INFO - 2023-03-16 05:48:34 --> Loader Class Initialized
INFO - 2023-03-16 05:48:34 --> Controller Class Initialized
DEBUG - 2023-03-16 05:48:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 05:48:34 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 05:48:34 --> Database Driver Class Initialized
INFO - 2023-03-16 05:48:34 --> Model "Login_model" initialized
INFO - 2023-03-16 05:48:34 --> Final output sent to browser
DEBUG - 2023-03-16 05:48:34 --> Total execution time: 0.0415
INFO - 2023-03-16 06:18:35 --> Config Class Initialized
INFO - 2023-03-16 06:18:35 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:18:35 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:18:35 --> Utf8 Class Initialized
INFO - 2023-03-16 06:18:35 --> URI Class Initialized
INFO - 2023-03-16 06:18:35 --> Router Class Initialized
INFO - 2023-03-16 06:18:35 --> Output Class Initialized
INFO - 2023-03-16 06:18:35 --> Security Class Initialized
DEBUG - 2023-03-16 06:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:18:35 --> Input Class Initialized
INFO - 2023-03-16 06:18:35 --> Language Class Initialized
INFO - 2023-03-16 06:18:35 --> Loader Class Initialized
INFO - 2023-03-16 06:18:35 --> Controller Class Initialized
DEBUG - 2023-03-16 06:18:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:18:35 --> Database Driver Class Initialized
INFO - 2023-03-16 06:18:35 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:18:35 --> Final output sent to browser
DEBUG - 2023-03-16 06:18:35 --> Total execution time: 0.0552
INFO - 2023-03-16 06:18:35 --> Config Class Initialized
INFO - 2023-03-16 06:18:35 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:18:35 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:18:35 --> Utf8 Class Initialized
INFO - 2023-03-16 06:18:35 --> URI Class Initialized
INFO - 2023-03-16 06:18:35 --> Router Class Initialized
INFO - 2023-03-16 06:18:35 --> Output Class Initialized
INFO - 2023-03-16 06:18:35 --> Security Class Initialized
DEBUG - 2023-03-16 06:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:18:35 --> Input Class Initialized
INFO - 2023-03-16 06:18:35 --> Language Class Initialized
INFO - 2023-03-16 06:18:35 --> Loader Class Initialized
INFO - 2023-03-16 06:18:35 --> Controller Class Initialized
DEBUG - 2023-03-16 06:18:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:18:35 --> Database Driver Class Initialized
INFO - 2023-03-16 06:18:35 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:18:35 --> Final output sent to browser
DEBUG - 2023-03-16 06:18:35 --> Total execution time: 0.0504
INFO - 2023-03-16 06:39:55 --> Config Class Initialized
INFO - 2023-03-16 06:39:55 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:39:55 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:39:55 --> Utf8 Class Initialized
INFO - 2023-03-16 06:39:55 --> URI Class Initialized
INFO - 2023-03-16 06:39:55 --> Router Class Initialized
INFO - 2023-03-16 06:39:55 --> Output Class Initialized
INFO - 2023-03-16 06:39:55 --> Security Class Initialized
DEBUG - 2023-03-16 06:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:39:55 --> Input Class Initialized
INFO - 2023-03-16 06:39:55 --> Language Class Initialized
INFO - 2023-03-16 06:39:55 --> Loader Class Initialized
INFO - 2023-03-16 06:39:55 --> Controller Class Initialized
DEBUG - 2023-03-16 06:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:39:55 --> Database Driver Class Initialized
INFO - 2023-03-16 06:39:55 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:39:55 --> Database Driver Class Initialized
INFO - 2023-03-16 06:39:55 --> Model "Login_model" initialized
INFO - 2023-03-16 06:39:55 --> Final output sent to browser
DEBUG - 2023-03-16 06:39:55 --> Total execution time: 0.0442
INFO - 2023-03-16 06:39:55 --> Config Class Initialized
INFO - 2023-03-16 06:39:55 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:39:55 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:39:55 --> Utf8 Class Initialized
INFO - 2023-03-16 06:39:55 --> URI Class Initialized
INFO - 2023-03-16 06:39:55 --> Router Class Initialized
INFO - 2023-03-16 06:39:55 --> Output Class Initialized
INFO - 2023-03-16 06:39:55 --> Security Class Initialized
DEBUG - 2023-03-16 06:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:39:55 --> Input Class Initialized
INFO - 2023-03-16 06:39:55 --> Language Class Initialized
INFO - 2023-03-16 06:39:55 --> Loader Class Initialized
INFO - 2023-03-16 06:39:55 --> Controller Class Initialized
DEBUG - 2023-03-16 06:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:39:55 --> Database Driver Class Initialized
INFO - 2023-03-16 06:39:55 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:39:55 --> Database Driver Class Initialized
INFO - 2023-03-16 06:39:55 --> Model "Login_model" initialized
INFO - 2023-03-16 06:39:55 --> Final output sent to browser
DEBUG - 2023-03-16 06:39:55 --> Total execution time: 0.0842
INFO - 2023-03-16 06:39:57 --> Config Class Initialized
INFO - 2023-03-16 06:39:57 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:39:57 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:39:57 --> Utf8 Class Initialized
INFO - 2023-03-16 06:39:57 --> URI Class Initialized
INFO - 2023-03-16 06:39:57 --> Router Class Initialized
INFO - 2023-03-16 06:39:57 --> Output Class Initialized
INFO - 2023-03-16 06:39:57 --> Security Class Initialized
DEBUG - 2023-03-16 06:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:39:57 --> Input Class Initialized
INFO - 2023-03-16 06:39:57 --> Language Class Initialized
INFO - 2023-03-16 06:39:57 --> Loader Class Initialized
INFO - 2023-03-16 06:39:57 --> Controller Class Initialized
DEBUG - 2023-03-16 06:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:39:57 --> Database Driver Class Initialized
INFO - 2023-03-16 06:39:57 --> Database Driver Class Initialized
INFO - 2023-03-16 06:39:57 --> Model "Login_model" initialized
INFO - 2023-03-16 06:39:57 --> Final output sent to browser
DEBUG - 2023-03-16 06:39:57 --> Total execution time: 0.1774
INFO - 2023-03-16 06:39:57 --> Config Class Initialized
INFO - 2023-03-16 06:39:57 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:39:57 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:39:57 --> Utf8 Class Initialized
INFO - 2023-03-16 06:39:57 --> URI Class Initialized
INFO - 2023-03-16 06:39:57 --> Router Class Initialized
INFO - 2023-03-16 06:39:57 --> Output Class Initialized
INFO - 2023-03-16 06:39:57 --> Security Class Initialized
DEBUG - 2023-03-16 06:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:39:57 --> Input Class Initialized
INFO - 2023-03-16 06:39:57 --> Language Class Initialized
INFO - 2023-03-16 06:39:57 --> Loader Class Initialized
INFO - 2023-03-16 06:39:57 --> Controller Class Initialized
DEBUG - 2023-03-16 06:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:39:57 --> Database Driver Class Initialized
INFO - 2023-03-16 06:39:57 --> Database Driver Class Initialized
INFO - 2023-03-16 06:39:57 --> Model "Login_model" initialized
INFO - 2023-03-16 06:39:57 --> Final output sent to browser
DEBUG - 2023-03-16 06:39:57 --> Total execution time: 0.0456
INFO - 2023-03-16 06:40:00 --> Config Class Initialized
INFO - 2023-03-16 06:40:00 --> Hooks Class Initialized
INFO - 2023-03-16 06:40:00 --> Config Class Initialized
INFO - 2023-03-16 06:40:00 --> Config Class Initialized
INFO - 2023-03-16 06:40:00 --> Hooks Class Initialized
INFO - 2023-03-16 06:40:00 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 06:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 06:40:00 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:00 --> URI Class Initialized
INFO - 2023-03-16 06:40:00 --> URI Class Initialized
INFO - 2023-03-16 06:40:00 --> URI Class Initialized
INFO - 2023-03-16 06:40:00 --> Router Class Initialized
INFO - 2023-03-16 06:40:00 --> Router Class Initialized
INFO - 2023-03-16 06:40:00 --> Router Class Initialized
INFO - 2023-03-16 06:40:00 --> Output Class Initialized
INFO - 2023-03-16 06:40:00 --> Output Class Initialized
INFO - 2023-03-16 06:40:00 --> Output Class Initialized
INFO - 2023-03-16 06:40:00 --> Security Class Initialized
INFO - 2023-03-16 06:40:00 --> Security Class Initialized
INFO - 2023-03-16 06:40:00 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 06:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:00 --> Input Class Initialized
INFO - 2023-03-16 06:40:00 --> Input Class Initialized
INFO - 2023-03-16 06:40:00 --> Input Class Initialized
INFO - 2023-03-16 06:40:00 --> Language Class Initialized
INFO - 2023-03-16 06:40:00 --> Language Class Initialized
INFO - 2023-03-16 06:40:00 --> Language Class Initialized
INFO - 2023-03-16 06:40:00 --> Loader Class Initialized
INFO - 2023-03-16 06:40:00 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:00 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:00 --> Loader Class Initialized
INFO - 2023-03-16 06:40:00 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:00 --> Loader Class Initialized
INFO - 2023-03-16 06:40:00 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:00 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:00 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:00 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:00 --> Final output sent to browser
INFO - 2023-03-16 06:40:00 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:00 --> Total execution time: 0.0490
DEBUG - 2023-03-16 06:40:00 --> Total execution time: 0.0494
INFO - 2023-03-16 06:40:00 --> Config Class Initialized
INFO - 2023-03-16 06:40:00 --> Hooks Class Initialized
INFO - 2023-03-16 06:40:00 --> Config Class Initialized
INFO - 2023-03-16 06:40:00 --> Final output sent to browser
INFO - 2023-03-16 06:40:00 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Total execution time: 0.0773
DEBUG - 2023-03-16 06:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 06:40:00 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:00 --> URI Class Initialized
INFO - 2023-03-16 06:40:00 --> URI Class Initialized
INFO - 2023-03-16 06:40:00 --> Router Class Initialized
INFO - 2023-03-16 06:40:00 --> Router Class Initialized
INFO - 2023-03-16 06:40:00 --> Output Class Initialized
INFO - 2023-03-16 06:40:00 --> Config Class Initialized
INFO - 2023-03-16 06:40:00 --> Output Class Initialized
INFO - 2023-03-16 06:40:00 --> Hooks Class Initialized
INFO - 2023-03-16 06:40:00 --> Security Class Initialized
INFO - 2023-03-16 06:40:00 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:00 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:00 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:00 --> Input Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:00 --> URI Class Initialized
INFO - 2023-03-16 06:40:00 --> Input Class Initialized
INFO - 2023-03-16 06:40:00 --> Language Class Initialized
INFO - 2023-03-16 06:40:00 --> Language Class Initialized
INFO - 2023-03-16 06:40:00 --> Router Class Initialized
INFO - 2023-03-16 06:40:00 --> Loader Class Initialized
INFO - 2023-03-16 06:40:00 --> Loader Class Initialized
INFO - 2023-03-16 06:40:00 --> Output Class Initialized
INFO - 2023-03-16 06:40:00 --> Controller Class Initialized
INFO - 2023-03-16 06:40:00 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:00 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:00 --> Database Driver Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:00 --> Final output sent to browser
INFO - 2023-03-16 06:40:00 --> Input Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Total execution time: 0.0441
INFO - 2023-03-16 06:40:00 --> Language Class Initialized
INFO - 2023-03-16 06:40:00 --> Loader Class Initialized
INFO - 2023-03-16 06:40:00 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:00 --> Config Class Initialized
INFO - 2023-03-16 06:40:00 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:00 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:01 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:01 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:01 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:01 --> URI Class Initialized
INFO - 2023-03-16 06:40:01 --> Router Class Initialized
INFO - 2023-03-16 06:40:01 --> Output Class Initialized
INFO - 2023-03-16 06:40:01 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:01 --> Input Class Initialized
INFO - 2023-03-16 06:40:01 --> Language Class Initialized
INFO - 2023-03-16 06:40:01 --> Loader Class Initialized
INFO - 2023-03-16 06:40:01 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:01 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:01 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:01 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:01 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:01 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:01 --> Total execution time: 0.0942
INFO - 2023-03-16 06:40:01 --> Config Class Initialized
INFO - 2023-03-16 06:40:01 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:01 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:01 --> Total execution time: 0.0823
INFO - 2023-03-16 06:40:01 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:01 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:01 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:01 --> URI Class Initialized
INFO - 2023-03-16 06:40:01 --> Final output sent to browser
INFO - 2023-03-16 06:40:01 --> Router Class Initialized
DEBUG - 2023-03-16 06:40:01 --> Total execution time: 0.1412
INFO - 2023-03-16 06:40:01 --> Output Class Initialized
INFO - 2023-03-16 06:40:01 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:01 --> Input Class Initialized
INFO - 2023-03-16 06:40:01 --> Language Class Initialized
INFO - 2023-03-16 06:40:01 --> Loader Class Initialized
INFO - 2023-03-16 06:40:01 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:01 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:01 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:01 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:01 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:40:01 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:01 --> Total execution time: 0.1869
INFO - 2023-03-16 06:40:09 --> Config Class Initialized
INFO - 2023-03-16 06:40:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:09 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:09 --> URI Class Initialized
INFO - 2023-03-16 06:40:09 --> Router Class Initialized
INFO - 2023-03-16 06:40:09 --> Output Class Initialized
INFO - 2023-03-16 06:40:09 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:09 --> Input Class Initialized
INFO - 2023-03-16 06:40:09 --> Language Class Initialized
INFO - 2023-03-16 06:40:09 --> Loader Class Initialized
INFO - 2023-03-16 06:40:09 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:09 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:09 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:09 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:09 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:09 --> Total execution time: 0.0263
INFO - 2023-03-16 06:40:09 --> Config Class Initialized
INFO - 2023-03-16 06:40:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:09 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:09 --> URI Class Initialized
INFO - 2023-03-16 06:40:09 --> Router Class Initialized
INFO - 2023-03-16 06:40:09 --> Output Class Initialized
INFO - 2023-03-16 06:40:09 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:09 --> Input Class Initialized
INFO - 2023-03-16 06:40:09 --> Language Class Initialized
INFO - 2023-03-16 06:40:09 --> Loader Class Initialized
INFO - 2023-03-16 06:40:09 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:09 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:09 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:09 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:09 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:09 --> Total execution time: 0.0199
INFO - 2023-03-16 06:40:14 --> Config Class Initialized
INFO - 2023-03-16 06:40:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:14 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:14 --> URI Class Initialized
INFO - 2023-03-16 06:40:14 --> Router Class Initialized
INFO - 2023-03-16 06:40:14 --> Output Class Initialized
INFO - 2023-03-16 06:40:14 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:14 --> Input Class Initialized
INFO - 2023-03-16 06:40:14 --> Language Class Initialized
INFO - 2023-03-16 06:40:14 --> Loader Class Initialized
INFO - 2023-03-16 06:40:14 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:14 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:14 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:14 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:14 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:14 --> Total execution time: 0.0687
INFO - 2023-03-16 06:40:14 --> Config Class Initialized
INFO - 2023-03-16 06:40:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:14 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:14 --> URI Class Initialized
INFO - 2023-03-16 06:40:14 --> Router Class Initialized
INFO - 2023-03-16 06:40:14 --> Output Class Initialized
INFO - 2023-03-16 06:40:14 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:14 --> Input Class Initialized
INFO - 2023-03-16 06:40:14 --> Language Class Initialized
INFO - 2023-03-16 06:40:14 --> Loader Class Initialized
INFO - 2023-03-16 06:40:14 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:14 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:14 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:14 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:14 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:14 --> Total execution time: 0.0199
INFO - 2023-03-16 06:40:25 --> Config Class Initialized
INFO - 2023-03-16 06:40:25 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:25 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:25 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:25 --> URI Class Initialized
INFO - 2023-03-16 06:40:25 --> Router Class Initialized
INFO - 2023-03-16 06:40:25 --> Output Class Initialized
INFO - 2023-03-16 06:40:25 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:25 --> Input Class Initialized
INFO - 2023-03-16 06:40:25 --> Language Class Initialized
INFO - 2023-03-16 06:40:25 --> Loader Class Initialized
INFO - 2023-03-16 06:40:25 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:25 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:25 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:40:25 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:25 --> Total execution time: 0.0636
INFO - 2023-03-16 06:40:25 --> Config Class Initialized
INFO - 2023-03-16 06:40:25 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:25 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:25 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:25 --> URI Class Initialized
INFO - 2023-03-16 06:40:25 --> Router Class Initialized
INFO - 2023-03-16 06:40:25 --> Output Class Initialized
INFO - 2023-03-16 06:40:25 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:25 --> Input Class Initialized
INFO - 2023-03-16 06:40:25 --> Language Class Initialized
INFO - 2023-03-16 06:40:25 --> Loader Class Initialized
INFO - 2023-03-16 06:40:25 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:25 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:25 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:40:25 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:25 --> Total execution time: 0.0407
INFO - 2023-03-16 06:40:26 --> Config Class Initialized
INFO - 2023-03-16 06:40:26 --> Config Class Initialized
INFO - 2023-03-16 06:40:26 --> Hooks Class Initialized
INFO - 2023-03-16 06:40:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:26 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 06:40:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:26 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:26 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:26 --> URI Class Initialized
INFO - 2023-03-16 06:40:26 --> URI Class Initialized
INFO - 2023-03-16 06:40:26 --> Router Class Initialized
INFO - 2023-03-16 06:40:26 --> Router Class Initialized
INFO - 2023-03-16 06:40:26 --> Output Class Initialized
INFO - 2023-03-16 06:40:26 --> Output Class Initialized
INFO - 2023-03-16 06:40:26 --> Security Class Initialized
INFO - 2023-03-16 06:40:26 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 06:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:26 --> Input Class Initialized
INFO - 2023-03-16 06:40:26 --> Input Class Initialized
INFO - 2023-03-16 06:40:26 --> Language Class Initialized
INFO - 2023-03-16 06:40:26 --> Language Class Initialized
INFO - 2023-03-16 06:40:26 --> Loader Class Initialized
INFO - 2023-03-16 06:40:26 --> Loader Class Initialized
INFO - 2023-03-16 06:40:26 --> Controller Class Initialized
INFO - 2023-03-16 06:40:26 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 06:40:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:26 --> Final output sent to browser
INFO - 2023-03-16 06:40:26 --> Database Driver Class Initialized
DEBUG - 2023-03-16 06:40:26 --> Total execution time: 0.0053
INFO - 2023-03-16 06:40:26 --> Config Class Initialized
INFO - 2023-03-16 06:40:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:26 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:26 --> URI Class Initialized
INFO - 2023-03-16 06:40:26 --> Router Class Initialized
INFO - 2023-03-16 06:40:26 --> Output Class Initialized
INFO - 2023-03-16 06:40:26 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:26 --> Input Class Initialized
INFO - 2023-03-16 06:40:26 --> Language Class Initialized
INFO - 2023-03-16 06:40:26 --> Loader Class Initialized
INFO - 2023-03-16 06:40:26 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:26 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:26 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:40:26 --> Model "Login_model" initialized
INFO - 2023-03-16 06:40:26 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:26 --> Total execution time: 0.0198
INFO - 2023-03-16 06:40:26 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:26 --> Config Class Initialized
INFO - 2023-03-16 06:40:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:40:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:40:26 --> Utf8 Class Initialized
INFO - 2023-03-16 06:40:26 --> URI Class Initialized
INFO - 2023-03-16 06:40:26 --> Router Class Initialized
INFO - 2023-03-16 06:40:26 --> Output Class Initialized
INFO - 2023-03-16 06:40:26 --> Security Class Initialized
DEBUG - 2023-03-16 06:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:40:26 --> Input Class Initialized
INFO - 2023-03-16 06:40:26 --> Language Class Initialized
INFO - 2023-03-16 06:40:26 --> Loader Class Initialized
INFO - 2023-03-16 06:40:26 --> Controller Class Initialized
DEBUG - 2023-03-16 06:40:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:40:26 --> Database Driver Class Initialized
INFO - 2023-03-16 06:40:26 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:40:26 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:26 --> Total execution time: 0.0233
INFO - 2023-03-16 06:40:26 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:40:26 --> Final output sent to browser
DEBUG - 2023-03-16 06:40:26 --> Total execution time: 0.0532
INFO - 2023-03-16 06:46:33 --> Config Class Initialized
INFO - 2023-03-16 06:46:33 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:46:33 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:46:33 --> Utf8 Class Initialized
INFO - 2023-03-16 06:46:33 --> URI Class Initialized
INFO - 2023-03-16 06:46:33 --> Router Class Initialized
INFO - 2023-03-16 06:46:33 --> Output Class Initialized
INFO - 2023-03-16 06:46:33 --> Security Class Initialized
DEBUG - 2023-03-16 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:46:33 --> Input Class Initialized
INFO - 2023-03-16 06:46:33 --> Language Class Initialized
INFO - 2023-03-16 06:46:33 --> Loader Class Initialized
INFO - 2023-03-16 06:46:33 --> Controller Class Initialized
DEBUG - 2023-03-16 06:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:46:33 --> Database Driver Class Initialized
INFO - 2023-03-16 06:46:33 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:46:33 --> Final output sent to browser
DEBUG - 2023-03-16 06:46:33 --> Total execution time: 0.0157
INFO - 2023-03-16 06:46:33 --> Config Class Initialized
INFO - 2023-03-16 06:46:33 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:46:33 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:46:33 --> Utf8 Class Initialized
INFO - 2023-03-16 06:46:33 --> URI Class Initialized
INFO - 2023-03-16 06:46:33 --> Router Class Initialized
INFO - 2023-03-16 06:46:33 --> Output Class Initialized
INFO - 2023-03-16 06:46:33 --> Security Class Initialized
DEBUG - 2023-03-16 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:46:33 --> Input Class Initialized
INFO - 2023-03-16 06:46:33 --> Language Class Initialized
INFO - 2023-03-16 06:46:33 --> Loader Class Initialized
INFO - 2023-03-16 06:46:33 --> Controller Class Initialized
DEBUG - 2023-03-16 06:46:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:46:33 --> Database Driver Class Initialized
INFO - 2023-03-16 06:46:33 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:46:33 --> Final output sent to browser
DEBUG - 2023-03-16 06:46:33 --> Total execution time: 0.0131
INFO - 2023-03-16 06:49:29 --> Config Class Initialized
INFO - 2023-03-16 06:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:29 --> URI Class Initialized
INFO - 2023-03-16 06:49:29 --> Router Class Initialized
INFO - 2023-03-16 06:49:29 --> Output Class Initialized
INFO - 2023-03-16 06:49:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:29 --> Input Class Initialized
INFO - 2023-03-16 06:49:29 --> Language Class Initialized
INFO - 2023-03-16 06:49:29 --> Loader Class Initialized
INFO - 2023-03-16 06:49:29 --> Controller Class Initialized
INFO - 2023-03-16 06:49:29 --> Helper loaded: form_helper
INFO - 2023-03-16 06:49:29 --> Helper loaded: url_helper
DEBUG - 2023-03-16 06:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:29 --> Model "Change_model" initialized
INFO - 2023-03-16 06:49:29 --> Model "Grafana_model" initialized
INFO - 2023-03-16 06:49:29 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:29 --> Total execution time: 0.0341
INFO - 2023-03-16 06:49:29 --> Config Class Initialized
INFO - 2023-03-16 06:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:29 --> URI Class Initialized
INFO - 2023-03-16 06:49:29 --> Router Class Initialized
INFO - 2023-03-16 06:49:29 --> Output Class Initialized
INFO - 2023-03-16 06:49:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:29 --> Input Class Initialized
INFO - 2023-03-16 06:49:29 --> Language Class Initialized
INFO - 2023-03-16 06:49:29 --> Loader Class Initialized
INFO - 2023-03-16 06:49:29 --> Controller Class Initialized
INFO - 2023-03-16 06:49:29 --> Helper loaded: form_helper
INFO - 2023-03-16 06:49:29 --> Helper loaded: url_helper
DEBUG - 2023-03-16 06:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:29 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:29 --> Total execution time: 0.0024
INFO - 2023-03-16 06:49:29 --> Config Class Initialized
INFO - 2023-03-16 06:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:29 --> URI Class Initialized
INFO - 2023-03-16 06:49:29 --> Router Class Initialized
INFO - 2023-03-16 06:49:29 --> Output Class Initialized
INFO - 2023-03-16 06:49:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:29 --> Input Class Initialized
INFO - 2023-03-16 06:49:29 --> Language Class Initialized
INFO - 2023-03-16 06:49:29 --> Loader Class Initialized
INFO - 2023-03-16 06:49:29 --> Controller Class Initialized
INFO - 2023-03-16 06:49:29 --> Helper loaded: form_helper
INFO - 2023-03-16 06:49:29 --> Helper loaded: url_helper
DEBUG - 2023-03-16 06:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:29 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:29 --> Model "Login_model" initialized
INFO - 2023-03-16 06:49:29 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:29 --> Total execution time: 0.0153
INFO - 2023-03-16 06:49:29 --> Config Class Initialized
INFO - 2023-03-16 06:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:29 --> URI Class Initialized
INFO - 2023-03-16 06:49:29 --> Router Class Initialized
INFO - 2023-03-16 06:49:29 --> Output Class Initialized
INFO - 2023-03-16 06:49:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:29 --> Input Class Initialized
INFO - 2023-03-16 06:49:29 --> Language Class Initialized
INFO - 2023-03-16 06:49:29 --> Loader Class Initialized
INFO - 2023-03-16 06:49:29 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:29 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:29 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:29 --> Total execution time: 0.0130
INFO - 2023-03-16 06:49:29 --> Config Class Initialized
INFO - 2023-03-16 06:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:29 --> URI Class Initialized
INFO - 2023-03-16 06:49:29 --> Router Class Initialized
INFO - 2023-03-16 06:49:29 --> Output Class Initialized
INFO - 2023-03-16 06:49:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:29 --> Input Class Initialized
INFO - 2023-03-16 06:49:29 --> Language Class Initialized
INFO - 2023-03-16 06:49:29 --> Loader Class Initialized
INFO - 2023-03-16 06:49:29 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:29 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:29 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:29 --> Total execution time: 0.0145
INFO - 2023-03-16 06:49:29 --> Config Class Initialized
INFO - 2023-03-16 06:49:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:29 --> URI Class Initialized
INFO - 2023-03-16 06:49:29 --> Router Class Initialized
INFO - 2023-03-16 06:49:29 --> Output Class Initialized
INFO - 2023-03-16 06:49:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:29 --> Input Class Initialized
INFO - 2023-03-16 06:49:29 --> Language Class Initialized
INFO - 2023-03-16 06:49:29 --> Loader Class Initialized
INFO - 2023-03-16 06:49:29 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:29 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:30 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:30 --> Model "Login_model" initialized
INFO - 2023-03-16 06:49:30 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:30 --> Total execution time: 0.0877
INFO - 2023-03-16 06:49:30 --> Config Class Initialized
INFO - 2023-03-16 06:49:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:30 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:30 --> URI Class Initialized
INFO - 2023-03-16 06:49:30 --> Router Class Initialized
INFO - 2023-03-16 06:49:30 --> Output Class Initialized
INFO - 2023-03-16 06:49:30 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:30 --> Input Class Initialized
INFO - 2023-03-16 06:49:30 --> Language Class Initialized
INFO - 2023-03-16 06:49:30 --> Loader Class Initialized
INFO - 2023-03-16 06:49:30 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:30 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:30 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:30 --> Model "Login_model" initialized
INFO - 2023-03-16 06:49:30 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:30 --> Total execution time: 0.0907
INFO - 2023-03-16 06:49:31 --> Config Class Initialized
INFO - 2023-03-16 06:49:31 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:31 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:31 --> URI Class Initialized
INFO - 2023-03-16 06:49:31 --> Router Class Initialized
INFO - 2023-03-16 06:49:31 --> Output Class Initialized
INFO - 2023-03-16 06:49:31 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:31 --> Input Class Initialized
INFO - 2023-03-16 06:49:31 --> Language Class Initialized
INFO - 2023-03-16 06:49:31 --> Loader Class Initialized
INFO - 2023-03-16 06:49:31 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:31 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:31 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:31 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:31 --> Total execution time: 0.0435
INFO - 2023-03-16 06:49:31 --> Config Class Initialized
INFO - 2023-03-16 06:49:31 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:31 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:31 --> URI Class Initialized
INFO - 2023-03-16 06:49:31 --> Router Class Initialized
INFO - 2023-03-16 06:49:31 --> Output Class Initialized
INFO - 2023-03-16 06:49:31 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:31 --> Input Class Initialized
INFO - 2023-03-16 06:49:31 --> Language Class Initialized
INFO - 2023-03-16 06:49:31 --> Loader Class Initialized
INFO - 2023-03-16 06:49:31 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:31 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:31 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:31 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:31 --> Total execution time: 0.0391
INFO - 2023-03-16 06:49:32 --> Config Class Initialized
INFO - 2023-03-16 06:49:32 --> Config Class Initialized
INFO - 2023-03-16 06:49:32 --> Hooks Class Initialized
INFO - 2023-03-16 06:49:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:32 --> Utf8 Class Initialized
DEBUG - 2023-03-16 06:49:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:32 --> URI Class Initialized
INFO - 2023-03-16 06:49:32 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:32 --> Router Class Initialized
INFO - 2023-03-16 06:49:32 --> URI Class Initialized
INFO - 2023-03-16 06:49:32 --> Output Class Initialized
INFO - 2023-03-16 06:49:32 --> Router Class Initialized
INFO - 2023-03-16 06:49:32 --> Security Class Initialized
INFO - 2023-03-16 06:49:32 --> Output Class Initialized
DEBUG - 2023-03-16 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:32 --> Security Class Initialized
INFO - 2023-03-16 06:49:32 --> Input Class Initialized
DEBUG - 2023-03-16 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:32 --> Language Class Initialized
INFO - 2023-03-16 06:49:32 --> Input Class Initialized
INFO - 2023-03-16 06:49:32 --> Language Class Initialized
INFO - 2023-03-16 06:49:32 --> Loader Class Initialized
INFO - 2023-03-16 06:49:32 --> Loader Class Initialized
INFO - 2023-03-16 06:49:32 --> Controller Class Initialized
INFO - 2023-03-16 06:49:32 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 06:49:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:32 --> Final output sent to browser
INFO - 2023-03-16 06:49:32 --> Database Driver Class Initialized
DEBUG - 2023-03-16 06:49:32 --> Total execution time: 0.0043
INFO - 2023-03-16 06:49:32 --> Config Class Initialized
INFO - 2023-03-16 06:49:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:32 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:32 --> URI Class Initialized
INFO - 2023-03-16 06:49:32 --> Router Class Initialized
INFO - 2023-03-16 06:49:32 --> Output Class Initialized
INFO - 2023-03-16 06:49:32 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:32 --> Input Class Initialized
INFO - 2023-03-16 06:49:32 --> Language Class Initialized
INFO - 2023-03-16 06:49:32 --> Loader Class Initialized
INFO - 2023-03-16 06:49:32 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:32 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:32 --> Model "Login_model" initialized
INFO - 2023-03-16 06:49:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:32 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:32 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:32 --> Total execution time: 0.0290
INFO - 2023-03-16 06:49:32 --> Config Class Initialized
INFO - 2023-03-16 06:49:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:32 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:32 --> URI Class Initialized
INFO - 2023-03-16 06:49:32 --> Router Class Initialized
INFO - 2023-03-16 06:49:32 --> Output Class Initialized
INFO - 2023-03-16 06:49:32 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:32 --> Input Class Initialized
INFO - 2023-03-16 06:49:32 --> Language Class Initialized
INFO - 2023-03-16 06:49:32 --> Loader Class Initialized
INFO - 2023-03-16 06:49:32 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:32 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:32 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:32 --> Total execution time: 0.0329
INFO - 2023-03-16 06:49:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:32 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:32 --> Total execution time: 0.0582
INFO - 2023-03-16 06:49:56 --> Config Class Initialized
INFO - 2023-03-16 06:49:56 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:56 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:56 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:56 --> URI Class Initialized
INFO - 2023-03-16 06:49:56 --> Router Class Initialized
INFO - 2023-03-16 06:49:56 --> Output Class Initialized
INFO - 2023-03-16 06:49:56 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:56 --> Input Class Initialized
INFO - 2023-03-16 06:49:56 --> Language Class Initialized
INFO - 2023-03-16 06:49:56 --> Loader Class Initialized
INFO - 2023-03-16 06:49:56 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:56 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:56 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:56 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:56 --> Model "Login_model" initialized
INFO - 2023-03-16 06:49:56 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:56 --> Total execution time: 0.0621
INFO - 2023-03-16 06:49:56 --> Config Class Initialized
INFO - 2023-03-16 06:49:56 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:49:56 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:49:56 --> Utf8 Class Initialized
INFO - 2023-03-16 06:49:56 --> URI Class Initialized
INFO - 2023-03-16 06:49:56 --> Router Class Initialized
INFO - 2023-03-16 06:49:56 --> Output Class Initialized
INFO - 2023-03-16 06:49:56 --> Security Class Initialized
DEBUG - 2023-03-16 06:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:49:56 --> Input Class Initialized
INFO - 2023-03-16 06:49:56 --> Language Class Initialized
INFO - 2023-03-16 06:49:56 --> Loader Class Initialized
INFO - 2023-03-16 06:49:56 --> Controller Class Initialized
DEBUG - 2023-03-16 06:49:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:49:56 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:56 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:49:56 --> Database Driver Class Initialized
INFO - 2023-03-16 06:49:56 --> Model "Login_model" initialized
INFO - 2023-03-16 06:49:56 --> Final output sent to browser
DEBUG - 2023-03-16 06:49:56 --> Total execution time: 0.0566
INFO - 2023-03-16 06:51:29 --> Config Class Initialized
INFO - 2023-03-16 06:51:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:29 --> URI Class Initialized
INFO - 2023-03-16 06:51:29 --> Router Class Initialized
INFO - 2023-03-16 06:51:29 --> Output Class Initialized
INFO - 2023-03-16 06:51:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:29 --> Input Class Initialized
INFO - 2023-03-16 06:51:29 --> Language Class Initialized
INFO - 2023-03-16 06:51:29 --> Loader Class Initialized
INFO - 2023-03-16 06:51:29 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:29 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:29 --> Total execution time: 0.0276
INFO - 2023-03-16 06:51:29 --> Config Class Initialized
INFO - 2023-03-16 06:51:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:29 --> URI Class Initialized
INFO - 2023-03-16 06:51:29 --> Router Class Initialized
INFO - 2023-03-16 06:51:29 --> Output Class Initialized
INFO - 2023-03-16 06:51:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:29 --> Input Class Initialized
INFO - 2023-03-16 06:51:29 --> Language Class Initialized
INFO - 2023-03-16 06:51:29 --> Loader Class Initialized
INFO - 2023-03-16 06:51:29 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:29 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:29 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:29 --> Total execution time: 0.0156
INFO - 2023-03-16 06:51:29 --> Config Class Initialized
INFO - 2023-03-16 06:51:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:29 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:29 --> URI Class Initialized
INFO - 2023-03-16 06:51:29 --> Router Class Initialized
INFO - 2023-03-16 06:51:29 --> Output Class Initialized
INFO - 2023-03-16 06:51:29 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:29 --> Input Class Initialized
INFO - 2023-03-16 06:51:29 --> Language Class Initialized
INFO - 2023-03-16 06:51:29 --> Loader Class Initialized
INFO - 2023-03-16 06:51:29 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:29 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:29 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:29 --> Total execution time: 0.0530
INFO - 2023-03-16 06:51:29 --> Config Class Initialized
INFO - 2023-03-16 06:51:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:30 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:30 --> URI Class Initialized
INFO - 2023-03-16 06:51:30 --> Router Class Initialized
INFO - 2023-03-16 06:51:30 --> Output Class Initialized
INFO - 2023-03-16 06:51:30 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:30 --> Input Class Initialized
INFO - 2023-03-16 06:51:30 --> Language Class Initialized
INFO - 2023-03-16 06:51:30 --> Loader Class Initialized
INFO - 2023-03-16 06:51:30 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:30 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:30 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:30 --> Total execution time: 0.0541
INFO - 2023-03-16 06:51:30 --> Config Class Initialized
INFO - 2023-03-16 06:51:30 --> Config Class Initialized
INFO - 2023-03-16 06:51:30 --> Hooks Class Initialized
INFO - 2023-03-16 06:51:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:30 --> Utf8 Class Initialized
DEBUG - 2023-03-16 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:30 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:30 --> URI Class Initialized
INFO - 2023-03-16 06:51:30 --> Router Class Initialized
INFO - 2023-03-16 06:51:30 --> Output Class Initialized
INFO - 2023-03-16 06:51:30 --> URI Class Initialized
INFO - 2023-03-16 06:51:30 --> Security Class Initialized
INFO - 2023-03-16 06:51:30 --> Router Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:30 --> Output Class Initialized
INFO - 2023-03-16 06:51:30 --> Input Class Initialized
INFO - 2023-03-16 06:51:30 --> Security Class Initialized
INFO - 2023-03-16 06:51:30 --> Language Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:30 --> Input Class Initialized
INFO - 2023-03-16 06:51:30 --> Loader Class Initialized
INFO - 2023-03-16 06:51:30 --> Language Class Initialized
INFO - 2023-03-16 06:51:30 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:30 --> Loader Class Initialized
INFO - 2023-03-16 06:51:30 --> Controller Class Initialized
INFO - 2023-03-16 06:51:30 --> Database Driver Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:30 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:30 --> Final output sent to browser
INFO - 2023-03-16 06:51:30 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:30 --> Total execution time: 0.0165
DEBUG - 2023-03-16 06:51:30 --> Total execution time: 0.0165
INFO - 2023-03-16 06:51:30 --> Config Class Initialized
INFO - 2023-03-16 06:51:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:30 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:30 --> URI Class Initialized
INFO - 2023-03-16 06:51:30 --> Router Class Initialized
INFO - 2023-03-16 06:51:30 --> Output Class Initialized
INFO - 2023-03-16 06:51:30 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:30 --> Input Class Initialized
INFO - 2023-03-16 06:51:30 --> Language Class Initialized
INFO - 2023-03-16 06:51:30 --> Loader Class Initialized
INFO - 2023-03-16 06:51:30 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:30 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:30 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:30 --> Total execution time: 0.0501
INFO - 2023-03-16 06:51:30 --> Config Class Initialized
INFO - 2023-03-16 06:51:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:30 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:30 --> URI Class Initialized
INFO - 2023-03-16 06:51:30 --> Router Class Initialized
INFO - 2023-03-16 06:51:30 --> Output Class Initialized
INFO - 2023-03-16 06:51:30 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:30 --> Input Class Initialized
INFO - 2023-03-16 06:51:30 --> Language Class Initialized
INFO - 2023-03-16 06:51:30 --> Loader Class Initialized
INFO - 2023-03-16 06:51:30 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:30 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:30 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:30 --> Total execution time: 0.0217
INFO - 2023-03-16 06:51:30 --> Config Class Initialized
INFO - 2023-03-16 06:51:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:30 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:30 --> URI Class Initialized
INFO - 2023-03-16 06:51:30 --> Router Class Initialized
INFO - 2023-03-16 06:51:30 --> Output Class Initialized
INFO - 2023-03-16 06:51:30 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:30 --> Input Class Initialized
INFO - 2023-03-16 06:51:30 --> Language Class Initialized
INFO - 2023-03-16 06:51:30 --> Loader Class Initialized
INFO - 2023-03-16 06:51:30 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:30 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:30 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:30 --> Total execution time: 0.0584
INFO - 2023-03-16 06:51:32 --> Config Class Initialized
INFO - 2023-03-16 06:51:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:32 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:32 --> URI Class Initialized
INFO - 2023-03-16 06:51:32 --> Router Class Initialized
INFO - 2023-03-16 06:51:32 --> Output Class Initialized
INFO - 2023-03-16 06:51:32 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:32 --> Input Class Initialized
INFO - 2023-03-16 06:51:32 --> Language Class Initialized
INFO - 2023-03-16 06:51:32 --> Loader Class Initialized
INFO - 2023-03-16 06:51:32 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:32 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:32 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:32 --> Total execution time: 0.0211
INFO - 2023-03-16 06:51:32 --> Config Class Initialized
INFO - 2023-03-16 06:51:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:32 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:32 --> URI Class Initialized
INFO - 2023-03-16 06:51:32 --> Router Class Initialized
INFO - 2023-03-16 06:51:32 --> Output Class Initialized
INFO - 2023-03-16 06:51:32 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:32 --> Input Class Initialized
INFO - 2023-03-16 06:51:32 --> Language Class Initialized
INFO - 2023-03-16 06:51:32 --> Loader Class Initialized
INFO - 2023-03-16 06:51:32 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:32 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:32 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:32 --> Total execution time: 0.0569
INFO - 2023-03-16 06:51:37 --> Config Class Initialized
INFO - 2023-03-16 06:51:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:37 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:37 --> URI Class Initialized
INFO - 2023-03-16 06:51:37 --> Router Class Initialized
INFO - 2023-03-16 06:51:37 --> Output Class Initialized
INFO - 2023-03-16 06:51:37 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:37 --> Input Class Initialized
INFO - 2023-03-16 06:51:37 --> Language Class Initialized
INFO - 2023-03-16 06:51:37 --> Loader Class Initialized
INFO - 2023-03-16 06:51:37 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:37 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:37 --> Total execution time: 0.0043
INFO - 2023-03-16 06:51:37 --> Config Class Initialized
INFO - 2023-03-16 06:51:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:37 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:37 --> URI Class Initialized
INFO - 2023-03-16 06:51:37 --> Router Class Initialized
INFO - 2023-03-16 06:51:37 --> Output Class Initialized
INFO - 2023-03-16 06:51:37 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:37 --> Input Class Initialized
INFO - 2023-03-16 06:51:37 --> Language Class Initialized
INFO - 2023-03-16 06:51:37 --> Loader Class Initialized
INFO - 2023-03-16 06:51:37 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:37 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:37 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:37 --> Total execution time: 0.0104
INFO - 2023-03-16 06:51:39 --> Config Class Initialized
INFO - 2023-03-16 06:51:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:39 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:39 --> URI Class Initialized
INFO - 2023-03-16 06:51:39 --> Router Class Initialized
INFO - 2023-03-16 06:51:39 --> Output Class Initialized
INFO - 2023-03-16 06:51:39 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:39 --> Input Class Initialized
INFO - 2023-03-16 06:51:39 --> Language Class Initialized
INFO - 2023-03-16 06:51:39 --> Loader Class Initialized
INFO - 2023-03-16 06:51:39 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:39 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:39 --> Total execution time: 0.0041
INFO - 2023-03-16 06:51:39 --> Config Class Initialized
INFO - 2023-03-16 06:51:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:39 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:39 --> URI Class Initialized
INFO - 2023-03-16 06:51:39 --> Router Class Initialized
INFO - 2023-03-16 06:51:39 --> Output Class Initialized
INFO - 2023-03-16 06:51:39 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:39 --> Input Class Initialized
INFO - 2023-03-16 06:51:39 --> Language Class Initialized
INFO - 2023-03-16 06:51:39 --> Loader Class Initialized
INFO - 2023-03-16 06:51:39 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:39 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:39 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:39 --> Total execution time: 0.0114
INFO - 2023-03-16 06:51:53 --> Config Class Initialized
INFO - 2023-03-16 06:51:53 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:53 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:53 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:53 --> URI Class Initialized
INFO - 2023-03-16 06:51:53 --> Router Class Initialized
INFO - 2023-03-16 06:51:53 --> Output Class Initialized
INFO - 2023-03-16 06:51:53 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:53 --> Input Class Initialized
INFO - 2023-03-16 06:51:53 --> Language Class Initialized
INFO - 2023-03-16 06:51:53 --> Loader Class Initialized
INFO - 2023-03-16 06:51:53 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:53 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:53 --> Total execution time: 0.0039
INFO - 2023-03-16 06:51:53 --> Config Class Initialized
INFO - 2023-03-16 06:51:53 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:51:53 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:51:53 --> Utf8 Class Initialized
INFO - 2023-03-16 06:51:53 --> URI Class Initialized
INFO - 2023-03-16 06:51:53 --> Router Class Initialized
INFO - 2023-03-16 06:51:53 --> Output Class Initialized
INFO - 2023-03-16 06:51:53 --> Security Class Initialized
DEBUG - 2023-03-16 06:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:51:53 --> Input Class Initialized
INFO - 2023-03-16 06:51:53 --> Language Class Initialized
INFO - 2023-03-16 06:51:53 --> Loader Class Initialized
INFO - 2023-03-16 06:51:53 --> Controller Class Initialized
DEBUG - 2023-03-16 06:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:51:53 --> Database Driver Class Initialized
INFO - 2023-03-16 06:51:53 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:51:58 --> Final output sent to browser
DEBUG - 2023-03-16 06:51:58 --> Total execution time: 5.0620
INFO - 2023-03-16 06:52:01 --> Config Class Initialized
INFO - 2023-03-16 06:52:01 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:01 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:01 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:01 --> URI Class Initialized
INFO - 2023-03-16 06:52:01 --> Router Class Initialized
INFO - 2023-03-16 06:52:01 --> Output Class Initialized
INFO - 2023-03-16 06:52:01 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:01 --> Input Class Initialized
INFO - 2023-03-16 06:52:01 --> Language Class Initialized
INFO - 2023-03-16 06:52:01 --> Loader Class Initialized
INFO - 2023-03-16 06:52:01 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:01 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:01 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:01 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:01 --> Total execution time: 0.0174
INFO - 2023-03-16 06:52:01 --> Config Class Initialized
INFO - 2023-03-16 06:52:01 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:01 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:01 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:01 --> URI Class Initialized
INFO - 2023-03-16 06:52:01 --> Router Class Initialized
INFO - 2023-03-16 06:52:01 --> Output Class Initialized
INFO - 2023-03-16 06:52:01 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:01 --> Input Class Initialized
INFO - 2023-03-16 06:52:01 --> Language Class Initialized
INFO - 2023-03-16 06:52:01 --> Loader Class Initialized
INFO - 2023-03-16 06:52:01 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:01 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:01 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:01 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:01 --> Total execution time: 0.0561
INFO - 2023-03-16 06:52:02 --> Config Class Initialized
INFO - 2023-03-16 06:52:02 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:02 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:02 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:02 --> URI Class Initialized
INFO - 2023-03-16 06:52:02 --> Router Class Initialized
INFO - 2023-03-16 06:52:02 --> Output Class Initialized
INFO - 2023-03-16 06:52:02 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:02 --> Input Class Initialized
INFO - 2023-03-16 06:52:02 --> Language Class Initialized
INFO - 2023-03-16 06:52:02 --> Loader Class Initialized
INFO - 2023-03-16 06:52:02 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:02 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:02 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:02 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:02 --> Model "Login_model" initialized
INFO - 2023-03-16 06:52:02 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:02 --> Total execution time: 0.0615
INFO - 2023-03-16 06:52:02 --> Config Class Initialized
INFO - 2023-03-16 06:52:02 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:02 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:02 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:02 --> URI Class Initialized
INFO - 2023-03-16 06:52:02 --> Router Class Initialized
INFO - 2023-03-16 06:52:02 --> Output Class Initialized
INFO - 2023-03-16 06:52:02 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:02 --> Input Class Initialized
INFO - 2023-03-16 06:52:02 --> Language Class Initialized
INFO - 2023-03-16 06:52:02 --> Loader Class Initialized
INFO - 2023-03-16 06:52:02 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:02 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:02 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:02 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:02 --> Model "Login_model" initialized
INFO - 2023-03-16 06:52:02 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:02 --> Total execution time: 0.0389
INFO - 2023-03-16 06:52:07 --> Config Class Initialized
INFO - 2023-03-16 06:52:07 --> Config Class Initialized
INFO - 2023-03-16 06:52:07 --> Hooks Class Initialized
INFO - 2023-03-16 06:52:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:07 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 06:52:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:07 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:07 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:07 --> URI Class Initialized
INFO - 2023-03-16 06:52:07 --> URI Class Initialized
INFO - 2023-03-16 06:52:07 --> Router Class Initialized
INFO - 2023-03-16 06:52:07 --> Router Class Initialized
INFO - 2023-03-16 06:52:07 --> Output Class Initialized
INFO - 2023-03-16 06:52:07 --> Output Class Initialized
INFO - 2023-03-16 06:52:07 --> Security Class Initialized
INFO - 2023-03-16 06:52:07 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:07 --> Input Class Initialized
INFO - 2023-03-16 06:52:07 --> Input Class Initialized
INFO - 2023-03-16 06:52:07 --> Language Class Initialized
INFO - 2023-03-16 06:52:07 --> Language Class Initialized
INFO - 2023-03-16 06:52:07 --> Loader Class Initialized
INFO - 2023-03-16 06:52:07 --> Loader Class Initialized
INFO - 2023-03-16 06:52:07 --> Controller Class Initialized
INFO - 2023-03-16 06:52:07 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 06:52:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:07 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:07 --> Total execution time: 0.0069
INFO - 2023-03-16 06:52:07 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:07 --> Config Class Initialized
INFO - 2023-03-16 06:52:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:07 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:07 --> URI Class Initialized
INFO - 2023-03-16 06:52:07 --> Router Class Initialized
INFO - 2023-03-16 06:52:07 --> Output Class Initialized
INFO - 2023-03-16 06:52:07 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:07 --> Input Class Initialized
INFO - 2023-03-16 06:52:07 --> Language Class Initialized
INFO - 2023-03-16 06:52:07 --> Loader Class Initialized
INFO - 2023-03-16 06:52:07 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:07 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:07 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:07 --> Total execution time: 0.0207
INFO - 2023-03-16 06:52:07 --> Final output sent to browser
INFO - 2023-03-16 06:52:07 --> Config Class Initialized
DEBUG - 2023-03-16 06:52:07 --> Total execution time: 0.0137
INFO - 2023-03-16 06:52:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:07 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:07 --> URI Class Initialized
INFO - 2023-03-16 06:52:07 --> Router Class Initialized
INFO - 2023-03-16 06:52:07 --> Output Class Initialized
INFO - 2023-03-16 06:52:07 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:07 --> Input Class Initialized
INFO - 2023-03-16 06:52:07 --> Language Class Initialized
INFO - 2023-03-16 06:52:07 --> Loader Class Initialized
INFO - 2023-03-16 06:52:07 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:07 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:07 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:07 --> Total execution time: 0.0519
INFO - 2023-03-16 06:52:08 --> Config Class Initialized
INFO - 2023-03-16 06:52:08 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:08 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:08 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:08 --> URI Class Initialized
INFO - 2023-03-16 06:52:08 --> Router Class Initialized
INFO - 2023-03-16 06:52:08 --> Output Class Initialized
INFO - 2023-03-16 06:52:08 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:08 --> Input Class Initialized
INFO - 2023-03-16 06:52:08 --> Language Class Initialized
INFO - 2023-03-16 06:52:08 --> Loader Class Initialized
INFO - 2023-03-16 06:52:08 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:08 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:08 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:08 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:08 --> Total execution time: 0.0470
INFO - 2023-03-16 06:52:08 --> Config Class Initialized
INFO - 2023-03-16 06:52:08 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:08 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:08 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:08 --> URI Class Initialized
INFO - 2023-03-16 06:52:08 --> Router Class Initialized
INFO - 2023-03-16 06:52:08 --> Output Class Initialized
INFO - 2023-03-16 06:52:08 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:08 --> Input Class Initialized
INFO - 2023-03-16 06:52:08 --> Language Class Initialized
INFO - 2023-03-16 06:52:08 --> Loader Class Initialized
INFO - 2023-03-16 06:52:08 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:08 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:08 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:08 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:08 --> Total execution time: 0.0173
INFO - 2023-03-16 06:52:10 --> Config Class Initialized
INFO - 2023-03-16 06:52:10 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:10 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:10 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:10 --> URI Class Initialized
INFO - 2023-03-16 06:52:10 --> Router Class Initialized
INFO - 2023-03-16 06:52:10 --> Output Class Initialized
INFO - 2023-03-16 06:52:10 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:10 --> Input Class Initialized
INFO - 2023-03-16 06:52:10 --> Language Class Initialized
INFO - 2023-03-16 06:52:10 --> Loader Class Initialized
INFO - 2023-03-16 06:52:10 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:10 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:10 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:10 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:10 --> Total execution time: 0.0165
INFO - 2023-03-16 06:52:10 --> Config Class Initialized
INFO - 2023-03-16 06:52:10 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:10 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:10 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:10 --> URI Class Initialized
INFO - 2023-03-16 06:52:10 --> Router Class Initialized
INFO - 2023-03-16 06:52:10 --> Output Class Initialized
INFO - 2023-03-16 06:52:10 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:10 --> Input Class Initialized
INFO - 2023-03-16 06:52:10 --> Language Class Initialized
INFO - 2023-03-16 06:52:10 --> Loader Class Initialized
INFO - 2023-03-16 06:52:10 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:10 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:10 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:10 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:10 --> Total execution time: 0.0138
INFO - 2023-03-16 06:52:12 --> Config Class Initialized
INFO - 2023-03-16 06:52:12 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:12 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:12 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:12 --> URI Class Initialized
INFO - 2023-03-16 06:52:12 --> Router Class Initialized
INFO - 2023-03-16 06:52:12 --> Output Class Initialized
INFO - 2023-03-16 06:52:12 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:12 --> Input Class Initialized
INFO - 2023-03-16 06:52:12 --> Language Class Initialized
INFO - 2023-03-16 06:52:12 --> Loader Class Initialized
INFO - 2023-03-16 06:52:12 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:12 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:12 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:12 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:12 --> Total execution time: 0.0209
INFO - 2023-03-16 06:52:14 --> Config Class Initialized
INFO - 2023-03-16 06:52:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:14 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:14 --> URI Class Initialized
INFO - 2023-03-16 06:52:14 --> Router Class Initialized
INFO - 2023-03-16 06:52:14 --> Output Class Initialized
INFO - 2023-03-16 06:52:14 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:14 --> Input Class Initialized
INFO - 2023-03-16 06:52:14 --> Language Class Initialized
INFO - 2023-03-16 06:52:14 --> Loader Class Initialized
INFO - 2023-03-16 06:52:14 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:14 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:14 --> Total execution time: 0.0413
INFO - 2023-03-16 06:52:14 --> Config Class Initialized
INFO - 2023-03-16 06:52:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:14 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:14 --> URI Class Initialized
INFO - 2023-03-16 06:52:14 --> Router Class Initialized
INFO - 2023-03-16 06:52:14 --> Output Class Initialized
INFO - 2023-03-16 06:52:14 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:14 --> Input Class Initialized
INFO - 2023-03-16 06:52:14 --> Language Class Initialized
INFO - 2023-03-16 06:52:14 --> Loader Class Initialized
INFO - 2023-03-16 06:52:14 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:14 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:14 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:14 --> Total execution time: 0.0116
INFO - 2023-03-16 06:52:19 --> Config Class Initialized
INFO - 2023-03-16 06:52:19 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:19 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:19 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:19 --> URI Class Initialized
INFO - 2023-03-16 06:52:19 --> Router Class Initialized
INFO - 2023-03-16 06:52:19 --> Output Class Initialized
INFO - 2023-03-16 06:52:19 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:19 --> Input Class Initialized
INFO - 2023-03-16 06:52:19 --> Language Class Initialized
INFO - 2023-03-16 06:52:19 --> Loader Class Initialized
INFO - 2023-03-16 06:52:19 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:19 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:19 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:19 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:19 --> Total execution time: 0.0152
INFO - 2023-03-16 06:52:21 --> Config Class Initialized
INFO - 2023-03-16 06:52:21 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:21 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:21 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:21 --> URI Class Initialized
INFO - 2023-03-16 06:52:21 --> Router Class Initialized
INFO - 2023-03-16 06:52:21 --> Output Class Initialized
INFO - 2023-03-16 06:52:21 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:21 --> Input Class Initialized
INFO - 2023-03-16 06:52:21 --> Language Class Initialized
INFO - 2023-03-16 06:52:21 --> Loader Class Initialized
INFO - 2023-03-16 06:52:21 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:21 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:21 --> Total execution time: 0.0210
INFO - 2023-03-16 06:52:21 --> Config Class Initialized
INFO - 2023-03-16 06:52:21 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:21 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:21 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:21 --> URI Class Initialized
INFO - 2023-03-16 06:52:21 --> Router Class Initialized
INFO - 2023-03-16 06:52:21 --> Output Class Initialized
INFO - 2023-03-16 06:52:21 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:21 --> Input Class Initialized
INFO - 2023-03-16 06:52:21 --> Language Class Initialized
INFO - 2023-03-16 06:52:21 --> Loader Class Initialized
INFO - 2023-03-16 06:52:21 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:21 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:21 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:21 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:21 --> Total execution time: 0.0105
INFO - 2023-03-16 06:52:26 --> Config Class Initialized
INFO - 2023-03-16 06:52:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:26 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:26 --> URI Class Initialized
INFO - 2023-03-16 06:52:26 --> Router Class Initialized
INFO - 2023-03-16 06:52:26 --> Output Class Initialized
INFO - 2023-03-16 06:52:26 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:26 --> Input Class Initialized
INFO - 2023-03-16 06:52:26 --> Language Class Initialized
INFO - 2023-03-16 06:52:26 --> Loader Class Initialized
INFO - 2023-03-16 06:52:26 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:26 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:26 --> Total execution time: 0.0057
INFO - 2023-03-16 06:52:26 --> Config Class Initialized
INFO - 2023-03-16 06:52:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:26 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:26 --> URI Class Initialized
INFO - 2023-03-16 06:52:26 --> Router Class Initialized
INFO - 2023-03-16 06:52:26 --> Output Class Initialized
INFO - 2023-03-16 06:52:26 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:26 --> Input Class Initialized
INFO - 2023-03-16 06:52:26 --> Language Class Initialized
INFO - 2023-03-16 06:52:26 --> Loader Class Initialized
INFO - 2023-03-16 06:52:26 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:26 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:26 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:31 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:31 --> Total execution time: 5.0474
INFO - 2023-03-16 06:52:53 --> Config Class Initialized
INFO - 2023-03-16 06:52:53 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:53 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:53 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:53 --> URI Class Initialized
INFO - 2023-03-16 06:52:53 --> Router Class Initialized
INFO - 2023-03-16 06:52:53 --> Output Class Initialized
INFO - 2023-03-16 06:52:53 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:53 --> Input Class Initialized
INFO - 2023-03-16 06:52:53 --> Language Class Initialized
INFO - 2023-03-16 06:52:53 --> Loader Class Initialized
INFO - 2023-03-16 06:52:53 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:53 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:53 --> Total execution time: 0.0036
INFO - 2023-03-16 06:52:53 --> Config Class Initialized
INFO - 2023-03-16 06:52:53 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:52:53 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:52:53 --> Utf8 Class Initialized
INFO - 2023-03-16 06:52:53 --> URI Class Initialized
INFO - 2023-03-16 06:52:53 --> Router Class Initialized
INFO - 2023-03-16 06:52:53 --> Output Class Initialized
INFO - 2023-03-16 06:52:53 --> Security Class Initialized
DEBUG - 2023-03-16 06:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:52:53 --> Input Class Initialized
INFO - 2023-03-16 06:52:53 --> Language Class Initialized
INFO - 2023-03-16 06:52:53 --> Loader Class Initialized
INFO - 2023-03-16 06:52:53 --> Controller Class Initialized
DEBUG - 2023-03-16 06:52:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:52:53 --> Database Driver Class Initialized
INFO - 2023-03-16 06:52:53 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:52:59 --> Final output sent to browser
DEBUG - 2023-03-16 06:52:59 --> Total execution time: 5.0835
INFO - 2023-03-16 06:53:40 --> Config Class Initialized
INFO - 2023-03-16 06:53:40 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:53:40 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:53:40 --> Utf8 Class Initialized
INFO - 2023-03-16 06:53:40 --> URI Class Initialized
INFO - 2023-03-16 06:53:40 --> Router Class Initialized
INFO - 2023-03-16 06:53:40 --> Output Class Initialized
INFO - 2023-03-16 06:53:40 --> Security Class Initialized
DEBUG - 2023-03-16 06:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:53:40 --> Input Class Initialized
INFO - 2023-03-16 06:53:40 --> Language Class Initialized
INFO - 2023-03-16 06:53:40 --> Loader Class Initialized
INFO - 2023-03-16 06:53:40 --> Controller Class Initialized
DEBUG - 2023-03-16 06:53:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:53:40 --> Database Driver Class Initialized
INFO - 2023-03-16 06:53:40 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:53:40 --> Final output sent to browser
DEBUG - 2023-03-16 06:53:40 --> Total execution time: 0.0184
INFO - 2023-03-16 06:53:40 --> Config Class Initialized
INFO - 2023-03-16 06:53:40 --> Hooks Class Initialized
DEBUG - 2023-03-16 06:53:40 --> UTF-8 Support Enabled
INFO - 2023-03-16 06:53:40 --> Utf8 Class Initialized
INFO - 2023-03-16 06:53:40 --> URI Class Initialized
INFO - 2023-03-16 06:53:40 --> Router Class Initialized
INFO - 2023-03-16 06:53:40 --> Output Class Initialized
INFO - 2023-03-16 06:53:40 --> Security Class Initialized
DEBUG - 2023-03-16 06:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 06:53:40 --> Input Class Initialized
INFO - 2023-03-16 06:53:40 --> Language Class Initialized
INFO - 2023-03-16 06:53:40 --> Loader Class Initialized
INFO - 2023-03-16 06:53:40 --> Controller Class Initialized
DEBUG - 2023-03-16 06:53:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 06:53:40 --> Database Driver Class Initialized
INFO - 2023-03-16 06:53:40 --> Model "Cluster_model" initialized
INFO - 2023-03-16 06:53:40 --> Final output sent to browser
DEBUG - 2023-03-16 06:53:40 --> Total execution time: 0.0137
INFO - 2023-03-16 07:00:26 --> Config Class Initialized
INFO - 2023-03-16 07:00:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:26 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:26 --> URI Class Initialized
INFO - 2023-03-16 07:00:26 --> Router Class Initialized
INFO - 2023-03-16 07:00:26 --> Output Class Initialized
INFO - 2023-03-16 07:00:26 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:26 --> Input Class Initialized
INFO - 2023-03-16 07:00:26 --> Language Class Initialized
INFO - 2023-03-16 07:00:26 --> Loader Class Initialized
INFO - 2023-03-16 07:00:26 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:26 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:26 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:26 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:26 --> Model "Login_model" initialized
INFO - 2023-03-16 07:00:26 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:26 --> Total execution time: 0.1275
INFO - 2023-03-16 07:00:26 --> Config Class Initialized
INFO - 2023-03-16 07:00:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:26 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:26 --> URI Class Initialized
INFO - 2023-03-16 07:00:26 --> Router Class Initialized
INFO - 2023-03-16 07:00:26 --> Output Class Initialized
INFO - 2023-03-16 07:00:26 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:26 --> Input Class Initialized
INFO - 2023-03-16 07:00:26 --> Language Class Initialized
INFO - 2023-03-16 07:00:26 --> Loader Class Initialized
INFO - 2023-03-16 07:00:26 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:26 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:26 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:26 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:26 --> Model "Login_model" initialized
INFO - 2023-03-16 07:00:26 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:26 --> Total execution time: 0.0412
INFO - 2023-03-16 07:00:34 --> Config Class Initialized
INFO - 2023-03-16 07:00:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:34 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:34 --> URI Class Initialized
INFO - 2023-03-16 07:00:34 --> Router Class Initialized
INFO - 2023-03-16 07:00:34 --> Output Class Initialized
INFO - 2023-03-16 07:00:34 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:34 --> Input Class Initialized
INFO - 2023-03-16 07:00:34 --> Language Class Initialized
INFO - 2023-03-16 07:00:34 --> Loader Class Initialized
INFO - 2023-03-16 07:00:34 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:34 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:34 --> Total execution time: 0.0571
INFO - 2023-03-16 07:00:34 --> Config Class Initialized
INFO - 2023-03-16 07:00:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:34 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:34 --> URI Class Initialized
INFO - 2023-03-16 07:00:34 --> Router Class Initialized
INFO - 2023-03-16 07:00:34 --> Output Class Initialized
INFO - 2023-03-16 07:00:34 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:34 --> Input Class Initialized
INFO - 2023-03-16 07:00:34 --> Language Class Initialized
INFO - 2023-03-16 07:00:34 --> Loader Class Initialized
INFO - 2023-03-16 07:00:34 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:34 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:34 --> Total execution time: 0.0539
INFO - 2023-03-16 07:00:34 --> Config Class Initialized
INFO - 2023-03-16 07:00:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:34 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:34 --> URI Class Initialized
INFO - 2023-03-16 07:00:34 --> Router Class Initialized
INFO - 2023-03-16 07:00:34 --> Output Class Initialized
INFO - 2023-03-16 07:00:34 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:34 --> Input Class Initialized
INFO - 2023-03-16 07:00:34 --> Language Class Initialized
INFO - 2023-03-16 07:00:34 --> Loader Class Initialized
INFO - 2023-03-16 07:00:34 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:34 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:34 --> Total execution time: 0.0037
INFO - 2023-03-16 07:00:34 --> Config Class Initialized
INFO - 2023-03-16 07:00:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:34 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:34 --> URI Class Initialized
INFO - 2023-03-16 07:00:34 --> Router Class Initialized
INFO - 2023-03-16 07:00:34 --> Output Class Initialized
INFO - 2023-03-16 07:00:34 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:34 --> Input Class Initialized
INFO - 2023-03-16 07:00:34 --> Language Class Initialized
INFO - 2023-03-16 07:00:34 --> Loader Class Initialized
INFO - 2023-03-16 07:00:34 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:34 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:34 --> Total execution time: 0.0109
INFO - 2023-03-16 07:00:36 --> Config Class Initialized
INFO - 2023-03-16 07:00:36 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:36 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:36 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:36 --> URI Class Initialized
INFO - 2023-03-16 07:00:36 --> Router Class Initialized
INFO - 2023-03-16 07:00:36 --> Output Class Initialized
INFO - 2023-03-16 07:00:36 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:36 --> Input Class Initialized
INFO - 2023-03-16 07:00:36 --> Language Class Initialized
INFO - 2023-03-16 07:00:36 --> Loader Class Initialized
INFO - 2023-03-16 07:00:36 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:36 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:36 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:36 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:36 --> Total execution time: 0.0182
INFO - 2023-03-16 07:00:36 --> Config Class Initialized
INFO - 2023-03-16 07:00:36 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:36 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:36 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:36 --> URI Class Initialized
INFO - 2023-03-16 07:00:36 --> Router Class Initialized
INFO - 2023-03-16 07:00:36 --> Output Class Initialized
INFO - 2023-03-16 07:00:36 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:36 --> Input Class Initialized
INFO - 2023-03-16 07:00:36 --> Language Class Initialized
INFO - 2023-03-16 07:00:36 --> Loader Class Initialized
INFO - 2023-03-16 07:00:36 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:36 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:36 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:36 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:36 --> Total execution time: 0.0547
INFO - 2023-03-16 07:00:36 --> Config Class Initialized
INFO - 2023-03-16 07:00:36 --> Config Class Initialized
INFO - 2023-03-16 07:00:36 --> Hooks Class Initialized
INFO - 2023-03-16 07:00:36 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:00:36 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:36 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:36 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:36 --> URI Class Initialized
INFO - 2023-03-16 07:00:36 --> URI Class Initialized
INFO - 2023-03-16 07:00:36 --> Router Class Initialized
INFO - 2023-03-16 07:00:36 --> Router Class Initialized
INFO - 2023-03-16 07:00:36 --> Output Class Initialized
INFO - 2023-03-16 07:00:36 --> Output Class Initialized
INFO - 2023-03-16 07:00:36 --> Security Class Initialized
INFO - 2023-03-16 07:00:36 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:36 --> Input Class Initialized
INFO - 2023-03-16 07:00:36 --> Input Class Initialized
INFO - 2023-03-16 07:00:36 --> Language Class Initialized
INFO - 2023-03-16 07:00:36 --> Language Class Initialized
INFO - 2023-03-16 07:00:36 --> Loader Class Initialized
INFO - 2023-03-16 07:00:36 --> Loader Class Initialized
INFO - 2023-03-16 07:00:36 --> Controller Class Initialized
INFO - 2023-03-16 07:00:36 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:00:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:36 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:36 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:36 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:36 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:36 --> Final output sent to browser
INFO - 2023-03-16 07:00:36 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:36 --> Total execution time: 0.0187
DEBUG - 2023-03-16 07:00:36 --> Total execution time: 0.0187
INFO - 2023-03-16 07:00:36 --> Config Class Initialized
INFO - 2023-03-16 07:00:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:37 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:37 --> URI Class Initialized
INFO - 2023-03-16 07:00:37 --> Router Class Initialized
INFO - 2023-03-16 07:00:37 --> Output Class Initialized
INFO - 2023-03-16 07:00:37 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:37 --> Input Class Initialized
INFO - 2023-03-16 07:00:37 --> Language Class Initialized
INFO - 2023-03-16 07:00:37 --> Loader Class Initialized
INFO - 2023-03-16 07:00:37 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:37 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:37 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:37 --> Total execution time: 0.0524
INFO - 2023-03-16 07:00:38 --> Config Class Initialized
INFO - 2023-03-16 07:00:38 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:38 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:38 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:38 --> URI Class Initialized
INFO - 2023-03-16 07:00:38 --> Router Class Initialized
INFO - 2023-03-16 07:00:38 --> Output Class Initialized
INFO - 2023-03-16 07:00:38 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:38 --> Input Class Initialized
INFO - 2023-03-16 07:00:38 --> Language Class Initialized
INFO - 2023-03-16 07:00:38 --> Loader Class Initialized
INFO - 2023-03-16 07:00:38 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:38 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:38 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:38 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:38 --> Total execution time: 0.0384
INFO - 2023-03-16 07:00:39 --> Config Class Initialized
INFO - 2023-03-16 07:00:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:39 --> URI Class Initialized
INFO - 2023-03-16 07:00:39 --> Router Class Initialized
INFO - 2023-03-16 07:00:39 --> Output Class Initialized
INFO - 2023-03-16 07:00:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:39 --> Input Class Initialized
INFO - 2023-03-16 07:00:39 --> Language Class Initialized
INFO - 2023-03-16 07:00:39 --> Loader Class Initialized
INFO - 2023-03-16 07:00:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:39 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:39 --> Total execution time: 0.0150
INFO - 2023-03-16 07:00:48 --> Config Class Initialized
INFO - 2023-03-16 07:00:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:48 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:48 --> URI Class Initialized
INFO - 2023-03-16 07:00:48 --> Router Class Initialized
INFO - 2023-03-16 07:00:48 --> Output Class Initialized
INFO - 2023-03-16 07:00:48 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:48 --> Input Class Initialized
INFO - 2023-03-16 07:00:48 --> Language Class Initialized
INFO - 2023-03-16 07:00:48 --> Loader Class Initialized
INFO - 2023-03-16 07:00:48 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:48 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:48 --> Total execution time: 0.0446
INFO - 2023-03-16 07:00:48 --> Config Class Initialized
INFO - 2023-03-16 07:00:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:48 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:48 --> URI Class Initialized
INFO - 2023-03-16 07:00:48 --> Router Class Initialized
INFO - 2023-03-16 07:00:48 --> Output Class Initialized
INFO - 2023-03-16 07:00:48 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:48 --> Input Class Initialized
INFO - 2023-03-16 07:00:48 --> Language Class Initialized
INFO - 2023-03-16 07:00:48 --> Loader Class Initialized
INFO - 2023-03-16 07:00:48 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:48 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:00:48 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:48 --> Total execution time: 0.0113
INFO - 2023-03-16 07:00:59 --> Config Class Initialized
INFO - 2023-03-16 07:00:59 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:59 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:59 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:59 --> URI Class Initialized
INFO - 2023-03-16 07:00:59 --> Router Class Initialized
INFO - 2023-03-16 07:00:59 --> Output Class Initialized
INFO - 2023-03-16 07:00:59 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:59 --> Input Class Initialized
INFO - 2023-03-16 07:00:59 --> Language Class Initialized
INFO - 2023-03-16 07:00:59 --> Loader Class Initialized
INFO - 2023-03-16 07:00:59 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:59 --> Final output sent to browser
DEBUG - 2023-03-16 07:00:59 --> Total execution time: 0.0046
INFO - 2023-03-16 07:00:59 --> Config Class Initialized
INFO - 2023-03-16 07:00:59 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:00:59 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:00:59 --> Utf8 Class Initialized
INFO - 2023-03-16 07:00:59 --> URI Class Initialized
INFO - 2023-03-16 07:00:59 --> Router Class Initialized
INFO - 2023-03-16 07:00:59 --> Output Class Initialized
INFO - 2023-03-16 07:00:59 --> Security Class Initialized
DEBUG - 2023-03-16 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:00:59 --> Input Class Initialized
INFO - 2023-03-16 07:00:59 --> Language Class Initialized
INFO - 2023-03-16 07:00:59 --> Loader Class Initialized
INFO - 2023-03-16 07:00:59 --> Controller Class Initialized
DEBUG - 2023-03-16 07:00:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:00:59 --> Database Driver Class Initialized
INFO - 2023-03-16 07:00:59 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:01:04 --> Final output sent to browser
DEBUG - 2023-03-16 07:01:04 --> Total execution time: 5.0152
INFO - 2023-03-16 07:06:09 --> Config Class Initialized
INFO - 2023-03-16 07:06:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:09 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:09 --> URI Class Initialized
INFO - 2023-03-16 07:06:09 --> Router Class Initialized
INFO - 2023-03-16 07:06:09 --> Output Class Initialized
INFO - 2023-03-16 07:06:09 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:09 --> Input Class Initialized
INFO - 2023-03-16 07:06:09 --> Language Class Initialized
INFO - 2023-03-16 07:06:09 --> Loader Class Initialized
INFO - 2023-03-16 07:06:09 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:09 --> Total execution time: 0.0426
INFO - 2023-03-16 07:06:09 --> Config Class Initialized
INFO - 2023-03-16 07:06:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:09 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:09 --> URI Class Initialized
INFO - 2023-03-16 07:06:09 --> Router Class Initialized
INFO - 2023-03-16 07:06:09 --> Output Class Initialized
INFO - 2023-03-16 07:06:09 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:09 --> Input Class Initialized
INFO - 2023-03-16 07:06:09 --> Language Class Initialized
INFO - 2023-03-16 07:06:09 --> Loader Class Initialized
INFO - 2023-03-16 07:06:09 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:09 --> Database Driver Class Initialized
INFO - 2023-03-16 07:06:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:06:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:09 --> Total execution time: 0.0122
INFO - 2023-03-16 07:06:10 --> Config Class Initialized
INFO - 2023-03-16 07:06:10 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:10 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:10 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:10 --> URI Class Initialized
INFO - 2023-03-16 07:06:10 --> Router Class Initialized
INFO - 2023-03-16 07:06:10 --> Output Class Initialized
INFO - 2023-03-16 07:06:10 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:10 --> Input Class Initialized
INFO - 2023-03-16 07:06:10 --> Language Class Initialized
INFO - 2023-03-16 07:06:10 --> Loader Class Initialized
INFO - 2023-03-16 07:06:10 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:10 --> Database Driver Class Initialized
INFO - 2023-03-16 07:06:10 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:06:10 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:10 --> Total execution time: 0.0187
INFO - 2023-03-16 07:06:12 --> Config Class Initialized
INFO - 2023-03-16 07:06:12 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:12 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:12 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:12 --> URI Class Initialized
INFO - 2023-03-16 07:06:12 --> Router Class Initialized
INFO - 2023-03-16 07:06:12 --> Output Class Initialized
INFO - 2023-03-16 07:06:12 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:12 --> Input Class Initialized
INFO - 2023-03-16 07:06:12 --> Language Class Initialized
INFO - 2023-03-16 07:06:12 --> Loader Class Initialized
INFO - 2023-03-16 07:06:12 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:12 --> Database Driver Class Initialized
INFO - 2023-03-16 07:06:12 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:06:12 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:12 --> Total execution time: 0.0150
INFO - 2023-03-16 07:06:12 --> Config Class Initialized
INFO - 2023-03-16 07:06:12 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:12 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:12 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:12 --> URI Class Initialized
INFO - 2023-03-16 07:06:12 --> Router Class Initialized
INFO - 2023-03-16 07:06:12 --> Output Class Initialized
INFO - 2023-03-16 07:06:12 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:12 --> Input Class Initialized
INFO - 2023-03-16 07:06:12 --> Language Class Initialized
INFO - 2023-03-16 07:06:12 --> Loader Class Initialized
INFO - 2023-03-16 07:06:12 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:12 --> Database Driver Class Initialized
INFO - 2023-03-16 07:06:12 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:06:12 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:12 --> Total execution time: 0.0151
INFO - 2023-03-16 07:06:13 --> Config Class Initialized
INFO - 2023-03-16 07:06:13 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:13 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:13 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:13 --> URI Class Initialized
INFO - 2023-03-16 07:06:13 --> Router Class Initialized
INFO - 2023-03-16 07:06:13 --> Output Class Initialized
INFO - 2023-03-16 07:06:13 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:13 --> Input Class Initialized
INFO - 2023-03-16 07:06:13 --> Language Class Initialized
INFO - 2023-03-16 07:06:13 --> Loader Class Initialized
INFO - 2023-03-16 07:06:13 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:13 --> Database Driver Class Initialized
INFO - 2023-03-16 07:06:13 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:06:13 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:13 --> Total execution time: 0.0143
INFO - 2023-03-16 07:06:14 --> Config Class Initialized
INFO - 2023-03-16 07:06:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:14 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:14 --> URI Class Initialized
INFO - 2023-03-16 07:06:14 --> Router Class Initialized
INFO - 2023-03-16 07:06:14 --> Output Class Initialized
INFO - 2023-03-16 07:06:14 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:14 --> Input Class Initialized
INFO - 2023-03-16 07:06:14 --> Language Class Initialized
INFO - 2023-03-16 07:06:14 --> Loader Class Initialized
INFO - 2023-03-16 07:06:14 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:14 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:14 --> Total execution time: 0.0051
INFO - 2023-03-16 07:06:14 --> Config Class Initialized
INFO - 2023-03-16 07:06:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:14 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:14 --> URI Class Initialized
INFO - 2023-03-16 07:06:14 --> Router Class Initialized
INFO - 2023-03-16 07:06:14 --> Output Class Initialized
INFO - 2023-03-16 07:06:14 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:14 --> Input Class Initialized
INFO - 2023-03-16 07:06:14 --> Language Class Initialized
INFO - 2023-03-16 07:06:14 --> Loader Class Initialized
INFO - 2023-03-16 07:06:14 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:14 --> Database Driver Class Initialized
INFO - 2023-03-16 07:06:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:06:14 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:14 --> Total execution time: 0.0132
INFO - 2023-03-16 07:06:15 --> Config Class Initialized
INFO - 2023-03-16 07:06:15 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:15 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:15 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:15 --> URI Class Initialized
INFO - 2023-03-16 07:06:15 --> Router Class Initialized
INFO - 2023-03-16 07:06:15 --> Output Class Initialized
INFO - 2023-03-16 07:06:15 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:15 --> Input Class Initialized
INFO - 2023-03-16 07:06:15 --> Language Class Initialized
INFO - 2023-03-16 07:06:15 --> Loader Class Initialized
INFO - 2023-03-16 07:06:15 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:15 --> Database Driver Class Initialized
INFO - 2023-03-16 07:06:15 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:06:15 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:15 --> Total execution time: 0.0365
INFO - 2023-03-16 07:06:15 --> Config Class Initialized
INFO - 2023-03-16 07:06:15 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:06:15 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:06:15 --> Utf8 Class Initialized
INFO - 2023-03-16 07:06:15 --> URI Class Initialized
INFO - 2023-03-16 07:06:15 --> Router Class Initialized
INFO - 2023-03-16 07:06:15 --> Output Class Initialized
INFO - 2023-03-16 07:06:15 --> Security Class Initialized
DEBUG - 2023-03-16 07:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:06:15 --> Input Class Initialized
INFO - 2023-03-16 07:06:15 --> Language Class Initialized
INFO - 2023-03-16 07:06:15 --> Loader Class Initialized
INFO - 2023-03-16 07:06:15 --> Controller Class Initialized
DEBUG - 2023-03-16 07:06:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:06:15 --> Database Driver Class Initialized
INFO - 2023-03-16 07:06:15 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:06:15 --> Final output sent to browser
DEBUG - 2023-03-16 07:06:15 --> Total execution time: 0.0133
INFO - 2023-03-16 07:08:34 --> Config Class Initialized
INFO - 2023-03-16 07:08:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:34 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:34 --> URI Class Initialized
INFO - 2023-03-16 07:08:34 --> Router Class Initialized
INFO - 2023-03-16 07:08:34 --> Output Class Initialized
INFO - 2023-03-16 07:08:34 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:34 --> Input Class Initialized
INFO - 2023-03-16 07:08:34 --> Language Class Initialized
INFO - 2023-03-16 07:08:34 --> Loader Class Initialized
INFO - 2023-03-16 07:08:34 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:34 --> Config Class Initialized
INFO - 2023-03-16 07:08:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:34 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:34 --> URI Class Initialized
INFO - 2023-03-16 07:08:34 --> Router Class Initialized
INFO - 2023-03-16 07:08:34 --> Output Class Initialized
INFO - 2023-03-16 07:08:34 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:34 --> Input Class Initialized
INFO - 2023-03-16 07:08:34 --> Language Class Initialized
INFO - 2023-03-16 07:08:34 --> Loader Class Initialized
INFO - 2023-03-16 07:08:34 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:35 --> Config Class Initialized
INFO - 2023-03-16 07:08:35 --> Hooks Class Initialized
INFO - 2023-03-16 07:08:35 --> Config Class Initialized
DEBUG - 2023-03-16 07:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:35 --> Hooks Class Initialized
INFO - 2023-03-16 07:08:35 --> Utf8 Class Initialized
DEBUG - 2023-03-16 07:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:35 --> URI Class Initialized
INFO - 2023-03-16 07:08:35 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:35 --> Router Class Initialized
INFO - 2023-03-16 07:08:35 --> Output Class Initialized
INFO - 2023-03-16 07:08:35 --> Security Class Initialized
INFO - 2023-03-16 07:08:35 --> URI Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:35 --> Input Class Initialized
INFO - 2023-03-16 07:08:35 --> Router Class Initialized
INFO - 2023-03-16 07:08:35 --> Language Class Initialized
INFO - 2023-03-16 07:08:35 --> Output Class Initialized
INFO - 2023-03-16 07:08:35 --> Loader Class Initialized
INFO - 2023-03-16 07:08:35 --> Security Class Initialized
INFO - 2023-03-16 07:08:35 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:35 --> Input Class Initialized
INFO - 2023-03-16 07:08:35 --> Language Class Initialized
INFO - 2023-03-16 07:08:35 --> Loader Class Initialized
INFO - 2023-03-16 07:08:35 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:35 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:35 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:35 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:35 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:35 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:35 --> Total execution time: 0.0170
INFO - 2023-03-16 07:08:35 --> Config Class Initialized
INFO - 2023-03-16 07:08:35 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:35 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:35 --> URI Class Initialized
INFO - 2023-03-16 07:08:35 --> Router Class Initialized
INFO - 2023-03-16 07:08:35 --> Output Class Initialized
INFO - 2023-03-16 07:08:35 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:35 --> Input Class Initialized
INFO - 2023-03-16 07:08:35 --> Language Class Initialized
INFO - 2023-03-16 07:08:35 --> Loader Class Initialized
INFO - 2023-03-16 07:08:35 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:35 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:35 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:35 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:35 --> Total execution time: 0.0559
INFO - 2023-03-16 07:08:35 --> Config Class Initialized
INFO - 2023-03-16 07:08:35 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:35 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:35 --> URI Class Initialized
INFO - 2023-03-16 07:08:35 --> Router Class Initialized
INFO - 2023-03-16 07:08:35 --> Output Class Initialized
INFO - 2023-03-16 07:08:35 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:35 --> Input Class Initialized
INFO - 2023-03-16 07:08:35 --> Language Class Initialized
INFO - 2023-03-16 07:08:35 --> Loader Class Initialized
INFO - 2023-03-16 07:08:35 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:35 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:35 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:35 --> Config Class Initialized
INFO - 2023-03-16 07:08:35 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:35 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:35 --> URI Class Initialized
INFO - 2023-03-16 07:08:35 --> Router Class Initialized
INFO - 2023-03-16 07:08:35 --> Output Class Initialized
INFO - 2023-03-16 07:08:35 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:35 --> Input Class Initialized
INFO - 2023-03-16 07:08:35 --> Language Class Initialized
INFO - 2023-03-16 07:08:35 --> Loader Class Initialized
INFO - 2023-03-16 07:08:35 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:35 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:35 --> Total execution time: 0.0026
INFO - 2023-03-16 07:08:35 --> Config Class Initialized
INFO - 2023-03-16 07:08:35 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:35 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:35 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:35 --> URI Class Initialized
INFO - 2023-03-16 07:08:35 --> Router Class Initialized
INFO - 2023-03-16 07:08:35 --> Output Class Initialized
INFO - 2023-03-16 07:08:35 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:35 --> Input Class Initialized
INFO - 2023-03-16 07:08:35 --> Language Class Initialized
INFO - 2023-03-16 07:08:35 --> Loader Class Initialized
INFO - 2023-03-16 07:08:35 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:35 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:35 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:35 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:35 --> Total execution time: 0.0114
INFO - 2023-03-16 07:08:36 --> Config Class Initialized
INFO - 2023-03-16 07:08:36 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:36 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:36 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:36 --> URI Class Initialized
INFO - 2023-03-16 07:08:36 --> Router Class Initialized
INFO - 2023-03-16 07:08:36 --> Output Class Initialized
INFO - 2023-03-16 07:08:36 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:36 --> Input Class Initialized
INFO - 2023-03-16 07:08:36 --> Language Class Initialized
INFO - 2023-03-16 07:08:36 --> Loader Class Initialized
INFO - 2023-03-16 07:08:36 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:36 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:36 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:36 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:36 --> Total execution time: 0.0164
INFO - 2023-03-16 07:08:36 --> Config Class Initialized
INFO - 2023-03-16 07:08:36 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:36 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:36 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:36 --> URI Class Initialized
INFO - 2023-03-16 07:08:36 --> Router Class Initialized
INFO - 2023-03-16 07:08:36 --> Output Class Initialized
INFO - 2023-03-16 07:08:36 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:36 --> Input Class Initialized
INFO - 2023-03-16 07:08:36 --> Language Class Initialized
INFO - 2023-03-16 07:08:36 --> Loader Class Initialized
INFO - 2023-03-16 07:08:36 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:36 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:36 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:36 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:36 --> Total execution time: 0.0556
INFO - 2023-03-16 07:08:38 --> Config Class Initialized
INFO - 2023-03-16 07:08:38 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:38 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:38 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:38 --> URI Class Initialized
INFO - 2023-03-16 07:08:38 --> Router Class Initialized
INFO - 2023-03-16 07:08:38 --> Output Class Initialized
INFO - 2023-03-16 07:08:38 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:38 --> Input Class Initialized
INFO - 2023-03-16 07:08:38 --> Language Class Initialized
INFO - 2023-03-16 07:08:38 --> Loader Class Initialized
INFO - 2023-03-16 07:08:38 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:38 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:38 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:38 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:38 --> Total execution time: 0.0236
INFO - 2023-03-16 07:08:38 --> Config Class Initialized
INFO - 2023-03-16 07:08:38 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:38 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:38 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:38 --> URI Class Initialized
INFO - 2023-03-16 07:08:38 --> Router Class Initialized
INFO - 2023-03-16 07:08:38 --> Output Class Initialized
INFO - 2023-03-16 07:08:38 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:38 --> Input Class Initialized
INFO - 2023-03-16 07:08:38 --> Language Class Initialized
INFO - 2023-03-16 07:08:38 --> Loader Class Initialized
INFO - 2023-03-16 07:08:38 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:38 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:38 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:38 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:38 --> Total execution time: 0.0472
INFO - 2023-03-16 07:08:38 --> Config Class Initialized
INFO - 2023-03-16 07:08:38 --> Config Class Initialized
INFO - 2023-03-16 07:08:38 --> Hooks Class Initialized
INFO - 2023-03-16 07:08:38 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:08:38 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:38 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:38 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:38 --> URI Class Initialized
INFO - 2023-03-16 07:08:38 --> URI Class Initialized
INFO - 2023-03-16 07:08:38 --> Router Class Initialized
INFO - 2023-03-16 07:08:38 --> Router Class Initialized
INFO - 2023-03-16 07:08:38 --> Output Class Initialized
INFO - 2023-03-16 07:08:38 --> Output Class Initialized
INFO - 2023-03-16 07:08:38 --> Security Class Initialized
INFO - 2023-03-16 07:08:38 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:38 --> Input Class Initialized
INFO - 2023-03-16 07:08:38 --> Input Class Initialized
INFO - 2023-03-16 07:08:38 --> Language Class Initialized
INFO - 2023-03-16 07:08:38 --> Language Class Initialized
INFO - 2023-03-16 07:08:38 --> Loader Class Initialized
INFO - 2023-03-16 07:08:38 --> Loader Class Initialized
INFO - 2023-03-16 07:08:38 --> Controller Class Initialized
INFO - 2023-03-16 07:08:38 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:08:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:38 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:38 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:38 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:38 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:38 --> Final output sent to browser
INFO - 2023-03-16 07:08:38 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:38 --> Total execution time: 0.0152
DEBUG - 2023-03-16 07:08:38 --> Total execution time: 0.0152
INFO - 2023-03-16 07:08:38 --> Config Class Initialized
INFO - 2023-03-16 07:08:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:39 --> URI Class Initialized
INFO - 2023-03-16 07:08:39 --> Router Class Initialized
INFO - 2023-03-16 07:08:39 --> Output Class Initialized
INFO - 2023-03-16 07:08:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:39 --> Input Class Initialized
INFO - 2023-03-16 07:08:39 --> Language Class Initialized
INFO - 2023-03-16 07:08:39 --> Loader Class Initialized
INFO - 2023-03-16 07:08:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:39 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:39 --> Total execution time: 0.0535
INFO - 2023-03-16 07:08:39 --> Config Class Initialized
INFO - 2023-03-16 07:08:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:39 --> URI Class Initialized
INFO - 2023-03-16 07:08:39 --> Router Class Initialized
INFO - 2023-03-16 07:08:39 --> Output Class Initialized
INFO - 2023-03-16 07:08:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:39 --> Input Class Initialized
INFO - 2023-03-16 07:08:39 --> Language Class Initialized
INFO - 2023-03-16 07:08:39 --> Loader Class Initialized
INFO - 2023-03-16 07:08:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:39 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:39 --> Total execution time: 0.0175
INFO - 2023-03-16 07:08:39 --> Config Class Initialized
INFO - 2023-03-16 07:08:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:08:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:08:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:08:39 --> URI Class Initialized
INFO - 2023-03-16 07:08:39 --> Router Class Initialized
INFO - 2023-03-16 07:08:39 --> Output Class Initialized
INFO - 2023-03-16 07:08:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:08:39 --> Input Class Initialized
INFO - 2023-03-16 07:08:39 --> Language Class Initialized
INFO - 2023-03-16 07:08:39 --> Loader Class Initialized
INFO - 2023-03-16 07:08:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:08:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:08:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:08:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:08:39 --> Final output sent to browser
DEBUG - 2023-03-16 07:08:39 --> Total execution time: 0.0608
INFO - 2023-03-16 07:11:23 --> Config Class Initialized
INFO - 2023-03-16 07:11:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:23 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:23 --> URI Class Initialized
INFO - 2023-03-16 07:11:23 --> Router Class Initialized
INFO - 2023-03-16 07:11:23 --> Output Class Initialized
INFO - 2023-03-16 07:11:23 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:23 --> Input Class Initialized
INFO - 2023-03-16 07:11:23 --> Language Class Initialized
INFO - 2023-03-16 07:11:23 --> Loader Class Initialized
INFO - 2023-03-16 07:11:23 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:23 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:23 --> Total execution time: 0.0020
INFO - 2023-03-16 07:11:23 --> Config Class Initialized
INFO - 2023-03-16 07:11:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:23 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:23 --> URI Class Initialized
INFO - 2023-03-16 07:11:23 --> Router Class Initialized
INFO - 2023-03-16 07:11:23 --> Output Class Initialized
INFO - 2023-03-16 07:11:23 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:23 --> Input Class Initialized
INFO - 2023-03-16 07:11:23 --> Language Class Initialized
INFO - 2023-03-16 07:11:23 --> Loader Class Initialized
INFO - 2023-03-16 07:11:23 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:23 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:23 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:23 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:23 --> Total execution time: 0.0101
INFO - 2023-03-16 07:11:24 --> Config Class Initialized
INFO - 2023-03-16 07:11:24 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:24 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:24 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:24 --> URI Class Initialized
INFO - 2023-03-16 07:11:24 --> Router Class Initialized
INFO - 2023-03-16 07:11:24 --> Output Class Initialized
INFO - 2023-03-16 07:11:24 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:24 --> Input Class Initialized
INFO - 2023-03-16 07:11:24 --> Language Class Initialized
INFO - 2023-03-16 07:11:24 --> Loader Class Initialized
INFO - 2023-03-16 07:11:24 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:24 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:24 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:24 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:24 --> Total execution time: 0.0119
INFO - 2023-03-16 07:11:24 --> Config Class Initialized
INFO - 2023-03-16 07:11:24 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:24 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:24 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:24 --> URI Class Initialized
INFO - 2023-03-16 07:11:24 --> Router Class Initialized
INFO - 2023-03-16 07:11:24 --> Output Class Initialized
INFO - 2023-03-16 07:11:24 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:24 --> Input Class Initialized
INFO - 2023-03-16 07:11:24 --> Language Class Initialized
INFO - 2023-03-16 07:11:24 --> Loader Class Initialized
INFO - 2023-03-16 07:11:24 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:24 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:24 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:24 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:24 --> Total execution time: 0.0505
INFO - 2023-03-16 07:11:25 --> Config Class Initialized
INFO - 2023-03-16 07:11:25 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:25 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:25 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:25 --> URI Class Initialized
INFO - 2023-03-16 07:11:25 --> Router Class Initialized
INFO - 2023-03-16 07:11:25 --> Output Class Initialized
INFO - 2023-03-16 07:11:25 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:25 --> Input Class Initialized
INFO - 2023-03-16 07:11:25 --> Language Class Initialized
INFO - 2023-03-16 07:11:25 --> Loader Class Initialized
INFO - 2023-03-16 07:11:25 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:25 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:25 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:25 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:25 --> Total execution time: 0.0130
INFO - 2023-03-16 07:11:25 --> Config Class Initialized
INFO - 2023-03-16 07:11:25 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:25 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:25 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:25 --> URI Class Initialized
INFO - 2023-03-16 07:11:25 --> Router Class Initialized
INFO - 2023-03-16 07:11:25 --> Output Class Initialized
INFO - 2023-03-16 07:11:25 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:25 --> Input Class Initialized
INFO - 2023-03-16 07:11:25 --> Language Class Initialized
INFO - 2023-03-16 07:11:25 --> Loader Class Initialized
INFO - 2023-03-16 07:11:25 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:25 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:25 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:25 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:25 --> Total execution time: 0.0499
INFO - 2023-03-16 07:11:26 --> Config Class Initialized
INFO - 2023-03-16 07:11:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:26 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:26 --> URI Class Initialized
INFO - 2023-03-16 07:11:26 --> Router Class Initialized
INFO - 2023-03-16 07:11:26 --> Output Class Initialized
INFO - 2023-03-16 07:11:26 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:26 --> Input Class Initialized
INFO - 2023-03-16 07:11:26 --> Language Class Initialized
INFO - 2023-03-16 07:11:26 --> Loader Class Initialized
INFO - 2023-03-16 07:11:26 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:26 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:26 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:26 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:26 --> Total execution time: 0.0447
INFO - 2023-03-16 07:11:26 --> Config Class Initialized
INFO - 2023-03-16 07:11:26 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:26 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:26 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:26 --> URI Class Initialized
INFO - 2023-03-16 07:11:26 --> Router Class Initialized
INFO - 2023-03-16 07:11:26 --> Output Class Initialized
INFO - 2023-03-16 07:11:26 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:26 --> Input Class Initialized
INFO - 2023-03-16 07:11:26 --> Language Class Initialized
INFO - 2023-03-16 07:11:26 --> Loader Class Initialized
INFO - 2023-03-16 07:11:26 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:26 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:26 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:26 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:26 --> Total execution time: 0.0841
INFO - 2023-03-16 07:11:28 --> Config Class Initialized
INFO - 2023-03-16 07:11:28 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:28 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:29 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:29 --> URI Class Initialized
INFO - 2023-03-16 07:11:29 --> Router Class Initialized
INFO - 2023-03-16 07:11:29 --> Output Class Initialized
INFO - 2023-03-16 07:11:29 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:29 --> Input Class Initialized
INFO - 2023-03-16 07:11:29 --> Language Class Initialized
INFO - 2023-03-16 07:11:29 --> Loader Class Initialized
INFO - 2023-03-16 07:11:29 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:29 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:29 --> Total execution time: 0.2050
INFO - 2023-03-16 07:11:29 --> Config Class Initialized
INFO - 2023-03-16 07:11:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:29 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:29 --> URI Class Initialized
INFO - 2023-03-16 07:11:29 --> Router Class Initialized
INFO - 2023-03-16 07:11:29 --> Output Class Initialized
INFO - 2023-03-16 07:11:29 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:29 --> Input Class Initialized
INFO - 2023-03-16 07:11:29 --> Language Class Initialized
INFO - 2023-03-16 07:11:29 --> Loader Class Initialized
INFO - 2023-03-16 07:11:29 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:29 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:29 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:29 --> Total execution time: 0.0263
INFO - 2023-03-16 07:11:29 --> Config Class Initialized
INFO - 2023-03-16 07:11:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:29 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:29 --> URI Class Initialized
INFO - 2023-03-16 07:11:29 --> Router Class Initialized
INFO - 2023-03-16 07:11:29 --> Output Class Initialized
INFO - 2023-03-16 07:11:29 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:29 --> Input Class Initialized
INFO - 2023-03-16 07:11:29 --> Language Class Initialized
INFO - 2023-03-16 07:11:29 --> Loader Class Initialized
INFO - 2023-03-16 07:11:29 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:29 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:29 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:29 --> Total execution time: 0.0531
INFO - 2023-03-16 07:11:29 --> Config Class Initialized
INFO - 2023-03-16 07:11:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:29 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:29 --> URI Class Initialized
INFO - 2023-03-16 07:11:29 --> Router Class Initialized
INFO - 2023-03-16 07:11:29 --> Output Class Initialized
INFO - 2023-03-16 07:11:29 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:29 --> Input Class Initialized
INFO - 2023-03-16 07:11:29 --> Language Class Initialized
INFO - 2023-03-16 07:11:29 --> Loader Class Initialized
INFO - 2023-03-16 07:11:29 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:29 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:29 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:29 --> Total execution time: 0.0517
INFO - 2023-03-16 07:11:32 --> Config Class Initialized
INFO - 2023-03-16 07:11:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:32 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:32 --> URI Class Initialized
INFO - 2023-03-16 07:11:32 --> Router Class Initialized
INFO - 2023-03-16 07:11:32 --> Output Class Initialized
INFO - 2023-03-16 07:11:32 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:32 --> Input Class Initialized
INFO - 2023-03-16 07:11:32 --> Language Class Initialized
INFO - 2023-03-16 07:11:32 --> Loader Class Initialized
INFO - 2023-03-16 07:11:32 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:32 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:32 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:32 --> Total execution time: 0.0142
INFO - 2023-03-16 07:11:33 --> Config Class Initialized
INFO - 2023-03-16 07:11:33 --> Config Class Initialized
INFO - 2023-03-16 07:11:33 --> Hooks Class Initialized
INFO - 2023-03-16 07:11:33 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:33 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:33 --> Utf8 Class Initialized
DEBUG - 2023-03-16 07:11:33 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:33 --> URI Class Initialized
INFO - 2023-03-16 07:11:33 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:33 --> Router Class Initialized
INFO - 2023-03-16 07:11:33 --> Output Class Initialized
INFO - 2023-03-16 07:11:33 --> URI Class Initialized
INFO - 2023-03-16 07:11:33 --> Security Class Initialized
INFO - 2023-03-16 07:11:33 --> Router Class Initialized
DEBUG - 2023-03-16 07:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:33 --> Output Class Initialized
INFO - 2023-03-16 07:11:33 --> Input Class Initialized
INFO - 2023-03-16 07:11:33 --> Security Class Initialized
INFO - 2023-03-16 07:11:33 --> Language Class Initialized
DEBUG - 2023-03-16 07:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:33 --> Input Class Initialized
INFO - 2023-03-16 07:11:33 --> Loader Class Initialized
INFO - 2023-03-16 07:11:33 --> Language Class Initialized
INFO - 2023-03-16 07:11:33 --> Controller Class Initialized
INFO - 2023-03-16 07:11:33 --> Loader Class Initialized
DEBUG - 2023-03-16 07:11:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:33 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:33 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:33 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:33 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:33 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:33 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:33 --> Total execution time: 0.0187
INFO - 2023-03-16 07:11:33 --> Config Class Initialized
INFO - 2023-03-16 07:11:33 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:33 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:33 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:33 --> URI Class Initialized
INFO - 2023-03-16 07:11:33 --> Router Class Initialized
INFO - 2023-03-16 07:11:33 --> Output Class Initialized
INFO - 2023-03-16 07:11:33 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:33 --> Input Class Initialized
INFO - 2023-03-16 07:11:33 --> Language Class Initialized
INFO - 2023-03-16 07:11:33 --> Loader Class Initialized
INFO - 2023-03-16 07:11:33 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:33 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:33 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:33 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:33 --> Total execution time: 0.0924
INFO - 2023-03-16 07:11:33 --> Config Class Initialized
INFO - 2023-03-16 07:11:33 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:33 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:33 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:33 --> URI Class Initialized
INFO - 2023-03-16 07:11:33 --> Router Class Initialized
INFO - 2023-03-16 07:11:33 --> Output Class Initialized
INFO - 2023-03-16 07:11:33 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:33 --> Input Class Initialized
INFO - 2023-03-16 07:11:33 --> Language Class Initialized
INFO - 2023-03-16 07:11:33 --> Loader Class Initialized
INFO - 2023-03-16 07:11:33 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:33 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:33 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:39 --> Config Class Initialized
INFO - 2023-03-16 07:11:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:39 --> URI Class Initialized
INFO - 2023-03-16 07:11:39 --> Router Class Initialized
INFO - 2023-03-16 07:11:39 --> Output Class Initialized
INFO - 2023-03-16 07:11:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:39 --> Input Class Initialized
INFO - 2023-03-16 07:11:39 --> Language Class Initialized
INFO - 2023-03-16 07:11:39 --> Loader Class Initialized
INFO - 2023-03-16 07:11:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:39 --> Config Class Initialized
INFO - 2023-03-16 07:11:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:39 --> URI Class Initialized
INFO - 2023-03-16 07:11:39 --> Router Class Initialized
INFO - 2023-03-16 07:11:39 --> Output Class Initialized
INFO - 2023-03-16 07:11:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:39 --> Input Class Initialized
INFO - 2023-03-16 07:11:39 --> Language Class Initialized
INFO - 2023-03-16 07:11:39 --> Loader Class Initialized
INFO - 2023-03-16 07:11:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:39 --> Config Class Initialized
INFO - 2023-03-16 07:11:39 --> Config Class Initialized
INFO - 2023-03-16 07:11:39 --> Hooks Class Initialized
INFO - 2023-03-16 07:11:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:11:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:39 --> URI Class Initialized
INFO - 2023-03-16 07:11:39 --> URI Class Initialized
INFO - 2023-03-16 07:11:39 --> Router Class Initialized
INFO - 2023-03-16 07:11:39 --> Router Class Initialized
INFO - 2023-03-16 07:11:39 --> Output Class Initialized
INFO - 2023-03-16 07:11:39 --> Output Class Initialized
INFO - 2023-03-16 07:11:39 --> Security Class Initialized
INFO - 2023-03-16 07:11:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:39 --> Input Class Initialized
INFO - 2023-03-16 07:11:39 --> Input Class Initialized
INFO - 2023-03-16 07:11:39 --> Language Class Initialized
INFO - 2023-03-16 07:11:39 --> Language Class Initialized
INFO - 2023-03-16 07:11:39 --> Loader Class Initialized
INFO - 2023-03-16 07:11:39 --> Controller Class Initialized
INFO - 2023-03-16 07:11:39 --> Loader Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:39 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:39 --> Total execution time: 0.0383
INFO - 2023-03-16 07:11:39 --> Config Class Initialized
INFO - 2023-03-16 07:11:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:39 --> URI Class Initialized
INFO - 2023-03-16 07:11:39 --> Router Class Initialized
INFO - 2023-03-16 07:11:39 --> Output Class Initialized
INFO - 2023-03-16 07:11:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:39 --> Input Class Initialized
INFO - 2023-03-16 07:11:39 --> Language Class Initialized
INFO - 2023-03-16 07:11:39 --> Loader Class Initialized
INFO - 2023-03-16 07:11:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:39 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:39 --> Total execution time: 0.0446
INFO - 2023-03-16 07:11:40 --> Config Class Initialized
INFO - 2023-03-16 07:11:40 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:40 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:40 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:40 --> URI Class Initialized
INFO - 2023-03-16 07:11:40 --> Router Class Initialized
INFO - 2023-03-16 07:11:40 --> Output Class Initialized
INFO - 2023-03-16 07:11:40 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:40 --> Input Class Initialized
INFO - 2023-03-16 07:11:40 --> Language Class Initialized
INFO - 2023-03-16 07:11:40 --> Loader Class Initialized
INFO - 2023-03-16 07:11:40 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:40 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:40 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:40 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:40 --> Total execution time: 0.0141
INFO - 2023-03-16 07:11:40 --> Config Class Initialized
INFO - 2023-03-16 07:11:40 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:11:40 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:11:40 --> Utf8 Class Initialized
INFO - 2023-03-16 07:11:40 --> URI Class Initialized
INFO - 2023-03-16 07:11:40 --> Router Class Initialized
INFO - 2023-03-16 07:11:40 --> Output Class Initialized
INFO - 2023-03-16 07:11:40 --> Security Class Initialized
DEBUG - 2023-03-16 07:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:11:40 --> Input Class Initialized
INFO - 2023-03-16 07:11:40 --> Language Class Initialized
INFO - 2023-03-16 07:11:40 --> Loader Class Initialized
INFO - 2023-03-16 07:11:40 --> Controller Class Initialized
DEBUG - 2023-03-16 07:11:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:11:40 --> Database Driver Class Initialized
INFO - 2023-03-16 07:11:40 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:11:40 --> Final output sent to browser
DEBUG - 2023-03-16 07:11:40 --> Total execution time: 0.0557
INFO - 2023-03-16 07:17:58 --> Config Class Initialized
INFO - 2023-03-16 07:17:58 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:17:58 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:17:58 --> Utf8 Class Initialized
INFO - 2023-03-16 07:17:58 --> URI Class Initialized
INFO - 2023-03-16 07:17:58 --> Router Class Initialized
INFO - 2023-03-16 07:17:58 --> Output Class Initialized
INFO - 2023-03-16 07:17:58 --> Security Class Initialized
DEBUG - 2023-03-16 07:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:17:58 --> Input Class Initialized
INFO - 2023-03-16 07:17:58 --> Language Class Initialized
INFO - 2023-03-16 07:17:58 --> Loader Class Initialized
INFO - 2023-03-16 07:17:58 --> Controller Class Initialized
DEBUG - 2023-03-16 07:17:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:17:58 --> Database Driver Class Initialized
INFO - 2023-03-16 07:17:58 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:17:59 --> Database Driver Class Initialized
INFO - 2023-03-16 07:17:59 --> Model "Login_model" initialized
INFO - 2023-03-16 07:17:59 --> Final output sent to browser
DEBUG - 2023-03-16 07:17:59 --> Total execution time: 0.7087
INFO - 2023-03-16 07:17:59 --> Config Class Initialized
INFO - 2023-03-16 07:17:59 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:17:59 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:17:59 --> Utf8 Class Initialized
INFO - 2023-03-16 07:17:59 --> URI Class Initialized
INFO - 2023-03-16 07:17:59 --> Router Class Initialized
INFO - 2023-03-16 07:17:59 --> Output Class Initialized
INFO - 2023-03-16 07:17:59 --> Security Class Initialized
DEBUG - 2023-03-16 07:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:17:59 --> Input Class Initialized
INFO - 2023-03-16 07:17:59 --> Language Class Initialized
INFO - 2023-03-16 07:17:59 --> Loader Class Initialized
INFO - 2023-03-16 07:17:59 --> Controller Class Initialized
DEBUG - 2023-03-16 07:17:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:17:59 --> Database Driver Class Initialized
INFO - 2023-03-16 07:17:59 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:17:59 --> Database Driver Class Initialized
INFO - 2023-03-16 07:17:59 --> Model "Login_model" initialized
INFO - 2023-03-16 07:17:59 --> Final output sent to browser
DEBUG - 2023-03-16 07:17:59 --> Total execution time: 0.0946
INFO - 2023-03-16 07:18:04 --> Config Class Initialized
INFO - 2023-03-16 07:18:04 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:04 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:04 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:04 --> URI Class Initialized
INFO - 2023-03-16 07:18:04 --> Router Class Initialized
INFO - 2023-03-16 07:18:04 --> Output Class Initialized
INFO - 2023-03-16 07:18:04 --> Security Class Initialized
DEBUG - 2023-03-16 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:04 --> Input Class Initialized
INFO - 2023-03-16 07:18:04 --> Language Class Initialized
INFO - 2023-03-16 07:18:04 --> Loader Class Initialized
INFO - 2023-03-16 07:18:04 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:04 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:04 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:04 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:04 --> Total execution time: 0.0149
INFO - 2023-03-16 07:18:04 --> Config Class Initialized
INFO - 2023-03-16 07:18:04 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:04 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:04 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:04 --> URI Class Initialized
INFO - 2023-03-16 07:18:04 --> Router Class Initialized
INFO - 2023-03-16 07:18:04 --> Output Class Initialized
INFO - 2023-03-16 07:18:04 --> Security Class Initialized
DEBUG - 2023-03-16 07:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:04 --> Input Class Initialized
INFO - 2023-03-16 07:18:04 --> Language Class Initialized
INFO - 2023-03-16 07:18:04 --> Loader Class Initialized
INFO - 2023-03-16 07:18:04 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:04 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:04 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:04 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:04 --> Total execution time: 0.0536
INFO - 2023-03-16 07:18:06 --> Config Class Initialized
INFO - 2023-03-16 07:18:06 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:06 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:06 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:06 --> URI Class Initialized
INFO - 2023-03-16 07:18:06 --> Router Class Initialized
INFO - 2023-03-16 07:18:06 --> Output Class Initialized
INFO - 2023-03-16 07:18:06 --> Security Class Initialized
DEBUG - 2023-03-16 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:06 --> Input Class Initialized
INFO - 2023-03-16 07:18:06 --> Language Class Initialized
INFO - 2023-03-16 07:18:06 --> Loader Class Initialized
INFO - 2023-03-16 07:18:06 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:06 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:06 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:06 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:06 --> Total execution time: 0.0445
INFO - 2023-03-16 07:18:06 --> Config Class Initialized
INFO - 2023-03-16 07:18:06 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:06 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:06 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:06 --> URI Class Initialized
INFO - 2023-03-16 07:18:06 --> Router Class Initialized
INFO - 2023-03-16 07:18:06 --> Output Class Initialized
INFO - 2023-03-16 07:18:06 --> Security Class Initialized
DEBUG - 2023-03-16 07:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:06 --> Input Class Initialized
INFO - 2023-03-16 07:18:06 --> Language Class Initialized
INFO - 2023-03-16 07:18:06 --> Loader Class Initialized
INFO - 2023-03-16 07:18:06 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:06 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:06 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:06 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:06 --> Total execution time: 0.0832
INFO - 2023-03-16 07:18:08 --> Config Class Initialized
INFO - 2023-03-16 07:18:08 --> Config Class Initialized
INFO - 2023-03-16 07:18:08 --> Hooks Class Initialized
INFO - 2023-03-16 07:18:08 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:08 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:08 --> Utf8 Class Initialized
DEBUG - 2023-03-16 07:18:08 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:08 --> URI Class Initialized
INFO - 2023-03-16 07:18:08 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:08 --> Router Class Initialized
INFO - 2023-03-16 07:18:08 --> URI Class Initialized
INFO - 2023-03-16 07:18:08 --> Output Class Initialized
INFO - 2023-03-16 07:18:08 --> Router Class Initialized
INFO - 2023-03-16 07:18:08 --> Security Class Initialized
INFO - 2023-03-16 07:18:08 --> Output Class Initialized
DEBUG - 2023-03-16 07:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:08 --> Security Class Initialized
INFO - 2023-03-16 07:18:08 --> Input Class Initialized
DEBUG - 2023-03-16 07:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:08 --> Language Class Initialized
INFO - 2023-03-16 07:18:08 --> Input Class Initialized
INFO - 2023-03-16 07:18:08 --> Language Class Initialized
INFO - 2023-03-16 07:18:08 --> Loader Class Initialized
INFO - 2023-03-16 07:18:08 --> Loader Class Initialized
INFO - 2023-03-16 07:18:08 --> Controller Class Initialized
INFO - 2023-03-16 07:18:08 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:18:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:08 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:08 --> Total execution time: 0.0044
INFO - 2023-03-16 07:18:08 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:08 --> Config Class Initialized
INFO - 2023-03-16 07:18:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:09 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:09 --> URI Class Initialized
INFO - 2023-03-16 07:18:09 --> Router Class Initialized
INFO - 2023-03-16 07:18:09 --> Output Class Initialized
INFO - 2023-03-16 07:18:09 --> Security Class Initialized
DEBUG - 2023-03-16 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:09 --> Input Class Initialized
INFO - 2023-03-16 07:18:09 --> Language Class Initialized
INFO - 2023-03-16 07:18:09 --> Loader Class Initialized
INFO - 2023-03-16 07:18:09 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:09 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:09 --> Model "Login_model" initialized
INFO - 2023-03-16 07:18:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:09 --> Total execution time: 0.1185
INFO - 2023-03-16 07:18:09 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:09 --> Config Class Initialized
INFO - 2023-03-16 07:18:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:09 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:09 --> URI Class Initialized
INFO - 2023-03-16 07:18:09 --> Router Class Initialized
INFO - 2023-03-16 07:18:09 --> Output Class Initialized
INFO - 2023-03-16 07:18:09 --> Security Class Initialized
DEBUG - 2023-03-16 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:09 --> Input Class Initialized
INFO - 2023-03-16 07:18:09 --> Language Class Initialized
INFO - 2023-03-16 07:18:09 --> Loader Class Initialized
INFO - 2023-03-16 07:18:09 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:09 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:09 --> Total execution time: 0.1294
INFO - 2023-03-16 07:18:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:09 --> Total execution time: 0.1146
INFO - 2023-03-16 07:18:11 --> Config Class Initialized
INFO - 2023-03-16 07:18:11 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:11 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:11 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:11 --> URI Class Initialized
INFO - 2023-03-16 07:18:11 --> Router Class Initialized
INFO - 2023-03-16 07:18:11 --> Output Class Initialized
INFO - 2023-03-16 07:18:11 --> Security Class Initialized
DEBUG - 2023-03-16 07:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:11 --> Input Class Initialized
INFO - 2023-03-16 07:18:11 --> Language Class Initialized
INFO - 2023-03-16 07:18:11 --> Loader Class Initialized
INFO - 2023-03-16 07:18:11 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:11 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:11 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:11 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:11 --> Model "Login_model" initialized
INFO - 2023-03-16 07:18:11 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:11 --> Total execution time: 0.0438
INFO - 2023-03-16 07:18:11 --> Config Class Initialized
INFO - 2023-03-16 07:18:11 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:18:11 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:18:11 --> Utf8 Class Initialized
INFO - 2023-03-16 07:18:11 --> URI Class Initialized
INFO - 2023-03-16 07:18:11 --> Router Class Initialized
INFO - 2023-03-16 07:18:11 --> Output Class Initialized
INFO - 2023-03-16 07:18:11 --> Security Class Initialized
DEBUG - 2023-03-16 07:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:18:11 --> Input Class Initialized
INFO - 2023-03-16 07:18:11 --> Language Class Initialized
INFO - 2023-03-16 07:18:11 --> Loader Class Initialized
INFO - 2023-03-16 07:18:11 --> Controller Class Initialized
DEBUG - 2023-03-16 07:18:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:18:11 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:11 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:18:11 --> Database Driver Class Initialized
INFO - 2023-03-16 07:18:11 --> Model "Login_model" initialized
INFO - 2023-03-16 07:18:11 --> Final output sent to browser
DEBUG - 2023-03-16 07:18:11 --> Total execution time: 0.0694
INFO - 2023-03-16 07:23:04 --> Config Class Initialized
INFO - 2023-03-16 07:23:04 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:04 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:04 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:04 --> URI Class Initialized
INFO - 2023-03-16 07:23:04 --> Router Class Initialized
INFO - 2023-03-16 07:23:04 --> Output Class Initialized
INFO - 2023-03-16 07:23:04 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:04 --> Input Class Initialized
INFO - 2023-03-16 07:23:04 --> Language Class Initialized
INFO - 2023-03-16 07:23:04 --> Loader Class Initialized
INFO - 2023-03-16 07:23:04 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:04 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:04 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:04 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:04 --> Model "Login_model" initialized
INFO - 2023-03-16 07:23:04 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:04 --> Total execution time: 0.0523
INFO - 2023-03-16 07:23:04 --> Config Class Initialized
INFO - 2023-03-16 07:23:04 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:04 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:04 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:04 --> URI Class Initialized
INFO - 2023-03-16 07:23:04 --> Router Class Initialized
INFO - 2023-03-16 07:23:04 --> Output Class Initialized
INFO - 2023-03-16 07:23:04 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:04 --> Input Class Initialized
INFO - 2023-03-16 07:23:04 --> Language Class Initialized
INFO - 2023-03-16 07:23:04 --> Loader Class Initialized
INFO - 2023-03-16 07:23:04 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:04 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:04 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:04 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:04 --> Model "Login_model" initialized
INFO - 2023-03-16 07:23:04 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:04 --> Total execution time: 0.1143
INFO - 2023-03-16 07:23:37 --> Config Class Initialized
INFO - 2023-03-16 07:23:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:37 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:37 --> URI Class Initialized
INFO - 2023-03-16 07:23:37 --> Router Class Initialized
INFO - 2023-03-16 07:23:37 --> Output Class Initialized
INFO - 2023-03-16 07:23:37 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:37 --> Input Class Initialized
INFO - 2023-03-16 07:23:37 --> Language Class Initialized
INFO - 2023-03-16 07:23:37 --> Loader Class Initialized
INFO - 2023-03-16 07:23:37 --> Controller Class Initialized
INFO - 2023-03-16 07:23:37 --> Helper loaded: form_helper
INFO - 2023-03-16 07:23:37 --> Helper loaded: url_helper
DEBUG - 2023-03-16 07:23:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:37 --> Model "Change_model" initialized
INFO - 2023-03-16 07:23:37 --> Model "Grafana_model" initialized
INFO - 2023-03-16 07:23:37 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:37 --> Total execution time: 0.0263
INFO - 2023-03-16 07:23:37 --> Config Class Initialized
INFO - 2023-03-16 07:23:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:37 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:37 --> URI Class Initialized
INFO - 2023-03-16 07:23:37 --> Router Class Initialized
INFO - 2023-03-16 07:23:37 --> Output Class Initialized
INFO - 2023-03-16 07:23:37 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:37 --> Input Class Initialized
INFO - 2023-03-16 07:23:37 --> Language Class Initialized
INFO - 2023-03-16 07:23:37 --> Loader Class Initialized
INFO - 2023-03-16 07:23:37 --> Controller Class Initialized
INFO - 2023-03-16 07:23:37 --> Helper loaded: form_helper
INFO - 2023-03-16 07:23:37 --> Helper loaded: url_helper
DEBUG - 2023-03-16 07:23:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:37 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:37 --> Total execution time: 0.0427
INFO - 2023-03-16 07:23:37 --> Config Class Initialized
INFO - 2023-03-16 07:23:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:37 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:37 --> URI Class Initialized
INFO - 2023-03-16 07:23:37 --> Router Class Initialized
INFO - 2023-03-16 07:23:37 --> Output Class Initialized
INFO - 2023-03-16 07:23:37 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:37 --> Input Class Initialized
INFO - 2023-03-16 07:23:37 --> Language Class Initialized
INFO - 2023-03-16 07:23:37 --> Loader Class Initialized
INFO - 2023-03-16 07:23:37 --> Controller Class Initialized
INFO - 2023-03-16 07:23:37 --> Helper loaded: form_helper
INFO - 2023-03-16 07:23:37 --> Helper loaded: url_helper
DEBUG - 2023-03-16 07:23:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:37 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:37 --> Model "Login_model" initialized
INFO - 2023-03-16 07:23:37 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:37 --> Total execution time: 0.0173
INFO - 2023-03-16 07:23:37 --> Config Class Initialized
INFO - 2023-03-16 07:23:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:37 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:37 --> URI Class Initialized
INFO - 2023-03-16 07:23:37 --> Router Class Initialized
INFO - 2023-03-16 07:23:37 --> Output Class Initialized
INFO - 2023-03-16 07:23:37 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:37 --> Input Class Initialized
INFO - 2023-03-16 07:23:37 --> Language Class Initialized
INFO - 2023-03-16 07:23:37 --> Loader Class Initialized
INFO - 2023-03-16 07:23:37 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:37 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:37 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:37 --> Total execution time: 0.0120
INFO - 2023-03-16 07:23:37 --> Config Class Initialized
INFO - 2023-03-16 07:23:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:37 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:37 --> URI Class Initialized
INFO - 2023-03-16 07:23:37 --> Router Class Initialized
INFO - 2023-03-16 07:23:37 --> Output Class Initialized
INFO - 2023-03-16 07:23:37 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:37 --> Input Class Initialized
INFO - 2023-03-16 07:23:37 --> Language Class Initialized
INFO - 2023-03-16 07:23:37 --> Loader Class Initialized
INFO - 2023-03-16 07:23:37 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:37 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:37 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:37 --> Total execution time: 0.0130
INFO - 2023-03-16 07:23:37 --> Config Class Initialized
INFO - 2023-03-16 07:23:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:37 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:37 --> URI Class Initialized
INFO - 2023-03-16 07:23:37 --> Router Class Initialized
INFO - 2023-03-16 07:23:37 --> Output Class Initialized
INFO - 2023-03-16 07:23:37 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:37 --> Input Class Initialized
INFO - 2023-03-16 07:23:37 --> Language Class Initialized
INFO - 2023-03-16 07:23:37 --> Loader Class Initialized
INFO - 2023-03-16 07:23:37 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:37 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:37 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:37 --> Model "Login_model" initialized
INFO - 2023-03-16 07:23:37 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:37 --> Total execution time: 0.0682
INFO - 2023-03-16 07:23:37 --> Config Class Initialized
INFO - 2023-03-16 07:23:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:37 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:37 --> URI Class Initialized
INFO - 2023-03-16 07:23:37 --> Router Class Initialized
INFO - 2023-03-16 07:23:37 --> Output Class Initialized
INFO - 2023-03-16 07:23:37 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:37 --> Input Class Initialized
INFO - 2023-03-16 07:23:37 --> Language Class Initialized
INFO - 2023-03-16 07:23:37 --> Loader Class Initialized
INFO - 2023-03-16 07:23:37 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:37 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:37 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:37 --> Model "Login_model" initialized
INFO - 2023-03-16 07:23:37 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:37 --> Total execution time: 0.0385
INFO - 2023-03-16 07:23:41 --> Config Class Initialized
INFO - 2023-03-16 07:23:42 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:42 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:42 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:42 --> URI Class Initialized
INFO - 2023-03-16 07:23:42 --> Router Class Initialized
INFO - 2023-03-16 07:23:42 --> Output Class Initialized
INFO - 2023-03-16 07:23:42 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:42 --> Input Class Initialized
INFO - 2023-03-16 07:23:42 --> Language Class Initialized
INFO - 2023-03-16 07:23:42 --> Loader Class Initialized
INFO - 2023-03-16 07:23:42 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:42 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:42 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:42 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:42 --> Total execution time: 0.0549
INFO - 2023-03-16 07:23:42 --> Config Class Initialized
INFO - 2023-03-16 07:23:42 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:42 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:42 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:42 --> URI Class Initialized
INFO - 2023-03-16 07:23:42 --> Router Class Initialized
INFO - 2023-03-16 07:23:42 --> Output Class Initialized
INFO - 2023-03-16 07:23:42 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:42 --> Input Class Initialized
INFO - 2023-03-16 07:23:42 --> Language Class Initialized
INFO - 2023-03-16 07:23:42 --> Loader Class Initialized
INFO - 2023-03-16 07:23:42 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:42 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:42 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:42 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:42 --> Total execution time: 0.0155
INFO - 2023-03-16 07:23:44 --> Config Class Initialized
INFO - 2023-03-16 07:23:44 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:44 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:44 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:44 --> URI Class Initialized
INFO - 2023-03-16 07:23:44 --> Router Class Initialized
INFO - 2023-03-16 07:23:44 --> Output Class Initialized
INFO - 2023-03-16 07:23:44 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:44 --> Input Class Initialized
INFO - 2023-03-16 07:23:44 --> Language Class Initialized
INFO - 2023-03-16 07:23:44 --> Loader Class Initialized
INFO - 2023-03-16 07:23:44 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:44 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:44 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:45 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:45 --> Total execution time: 0.0569
INFO - 2023-03-16 07:23:45 --> Config Class Initialized
INFO - 2023-03-16 07:23:45 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:45 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:45 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:45 --> URI Class Initialized
INFO - 2023-03-16 07:23:45 --> Router Class Initialized
INFO - 2023-03-16 07:23:45 --> Output Class Initialized
INFO - 2023-03-16 07:23:45 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:45 --> Input Class Initialized
INFO - 2023-03-16 07:23:45 --> Language Class Initialized
INFO - 2023-03-16 07:23:45 --> Loader Class Initialized
INFO - 2023-03-16 07:23:45 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:45 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:45 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:45 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:45 --> Total execution time: 0.0515
INFO - 2023-03-16 07:23:48 --> Config Class Initialized
INFO - 2023-03-16 07:23:48 --> Config Class Initialized
INFO - 2023-03-16 07:23:48 --> Hooks Class Initialized
INFO - 2023-03-16 07:23:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:23:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:48 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:48 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:48 --> URI Class Initialized
INFO - 2023-03-16 07:23:48 --> URI Class Initialized
INFO - 2023-03-16 07:23:48 --> Router Class Initialized
INFO - 2023-03-16 07:23:48 --> Router Class Initialized
INFO - 2023-03-16 07:23:48 --> Output Class Initialized
INFO - 2023-03-16 07:23:48 --> Output Class Initialized
INFO - 2023-03-16 07:23:48 --> Security Class Initialized
INFO - 2023-03-16 07:23:48 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:48 --> Input Class Initialized
INFO - 2023-03-16 07:23:48 --> Input Class Initialized
INFO - 2023-03-16 07:23:48 --> Language Class Initialized
INFO - 2023-03-16 07:23:48 --> Language Class Initialized
INFO - 2023-03-16 07:23:48 --> Loader Class Initialized
INFO - 2023-03-16 07:23:48 --> Loader Class Initialized
INFO - 2023-03-16 07:23:48 --> Controller Class Initialized
INFO - 2023-03-16 07:23:48 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:23:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:48 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:48 --> Total execution time: 0.0048
INFO - 2023-03-16 07:23:48 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:48 --> Config Class Initialized
INFO - 2023-03-16 07:23:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:48 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:48 --> URI Class Initialized
INFO - 2023-03-16 07:23:48 --> Router Class Initialized
INFO - 2023-03-16 07:23:48 --> Output Class Initialized
INFO - 2023-03-16 07:23:48 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:48 --> Input Class Initialized
INFO - 2023-03-16 07:23:48 --> Language Class Initialized
INFO - 2023-03-16 07:23:48 --> Loader Class Initialized
INFO - 2023-03-16 07:23:48 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:48 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:48 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:48 --> Total execution time: 0.0151
INFO - 2023-03-16 07:23:48 --> Model "Login_model" initialized
INFO - 2023-03-16 07:23:48 --> Config Class Initialized
INFO - 2023-03-16 07:23:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:48 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:48 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:48 --> URI Class Initialized
INFO - 2023-03-16 07:23:48 --> Router Class Initialized
INFO - 2023-03-16 07:23:48 --> Output Class Initialized
INFO - 2023-03-16 07:23:48 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:48 --> Input Class Initialized
INFO - 2023-03-16 07:23:48 --> Language Class Initialized
INFO - 2023-03-16 07:23:48 --> Loader Class Initialized
INFO - 2023-03-16 07:23:48 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:48 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:48 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:48 --> Total execution time: 0.0204
INFO - 2023-03-16 07:23:48 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:48 --> Total execution time: 0.0131
INFO - 2023-03-16 07:23:51 --> Config Class Initialized
INFO - 2023-03-16 07:23:51 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:51 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:51 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:51 --> URI Class Initialized
INFO - 2023-03-16 07:23:51 --> Router Class Initialized
INFO - 2023-03-16 07:23:51 --> Output Class Initialized
INFO - 2023-03-16 07:23:51 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:51 --> Input Class Initialized
INFO - 2023-03-16 07:23:51 --> Language Class Initialized
INFO - 2023-03-16 07:23:51 --> Loader Class Initialized
INFO - 2023-03-16 07:23:51 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:51 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:51 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:51 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:51 --> Total execution time: 0.0262
INFO - 2023-03-16 07:23:51 --> Config Class Initialized
INFO - 2023-03-16 07:23:51 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:23:51 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:23:51 --> Utf8 Class Initialized
INFO - 2023-03-16 07:23:51 --> URI Class Initialized
INFO - 2023-03-16 07:23:51 --> Router Class Initialized
INFO - 2023-03-16 07:23:51 --> Output Class Initialized
INFO - 2023-03-16 07:23:51 --> Security Class Initialized
DEBUG - 2023-03-16 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:23:51 --> Input Class Initialized
INFO - 2023-03-16 07:23:51 --> Language Class Initialized
INFO - 2023-03-16 07:23:51 --> Loader Class Initialized
INFO - 2023-03-16 07:23:51 --> Controller Class Initialized
DEBUG - 2023-03-16 07:23:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:23:51 --> Database Driver Class Initialized
INFO - 2023-03-16 07:23:51 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:23:51 --> Final output sent to browser
DEBUG - 2023-03-16 07:23:51 --> Total execution time: 0.0212
INFO - 2023-03-16 07:25:38 --> Config Class Initialized
INFO - 2023-03-16 07:25:38 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:25:38 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:25:38 --> Utf8 Class Initialized
INFO - 2023-03-16 07:25:38 --> URI Class Initialized
INFO - 2023-03-16 07:25:38 --> Router Class Initialized
INFO - 2023-03-16 07:25:38 --> Output Class Initialized
INFO - 2023-03-16 07:25:38 --> Security Class Initialized
DEBUG - 2023-03-16 07:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:25:38 --> Input Class Initialized
INFO - 2023-03-16 07:25:38 --> Language Class Initialized
INFO - 2023-03-16 07:25:38 --> Loader Class Initialized
INFO - 2023-03-16 07:25:38 --> Controller Class Initialized
DEBUG - 2023-03-16 07:25:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:25:38 --> Database Driver Class Initialized
INFO - 2023-03-16 07:25:38 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:25:38 --> Final output sent to browser
DEBUG - 2023-03-16 07:25:38 --> Total execution time: 0.1153
INFO - 2023-03-16 07:25:38 --> Config Class Initialized
INFO - 2023-03-16 07:25:38 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:25:38 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:25:38 --> Utf8 Class Initialized
INFO - 2023-03-16 07:25:38 --> URI Class Initialized
INFO - 2023-03-16 07:25:38 --> Router Class Initialized
INFO - 2023-03-16 07:25:38 --> Output Class Initialized
INFO - 2023-03-16 07:25:38 --> Security Class Initialized
DEBUG - 2023-03-16 07:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:25:38 --> Input Class Initialized
INFO - 2023-03-16 07:25:38 --> Language Class Initialized
INFO - 2023-03-16 07:25:38 --> Loader Class Initialized
INFO - 2023-03-16 07:25:38 --> Controller Class Initialized
DEBUG - 2023-03-16 07:25:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:25:38 --> Database Driver Class Initialized
INFO - 2023-03-16 07:25:38 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:25:38 --> Final output sent to browser
DEBUG - 2023-03-16 07:25:38 --> Total execution time: 0.0563
INFO - 2023-03-16 07:25:44 --> Config Class Initialized
INFO - 2023-03-16 07:25:44 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:25:44 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:25:44 --> Utf8 Class Initialized
INFO - 2023-03-16 07:25:44 --> URI Class Initialized
INFO - 2023-03-16 07:25:44 --> Router Class Initialized
INFO - 2023-03-16 07:25:44 --> Output Class Initialized
INFO - 2023-03-16 07:25:44 --> Security Class Initialized
DEBUG - 2023-03-16 07:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:25:44 --> Input Class Initialized
INFO - 2023-03-16 07:25:44 --> Language Class Initialized
INFO - 2023-03-16 07:25:44 --> Loader Class Initialized
INFO - 2023-03-16 07:25:44 --> Controller Class Initialized
DEBUG - 2023-03-16 07:25:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:25:44 --> Database Driver Class Initialized
INFO - 2023-03-16 07:25:44 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:25:44 --> Final output sent to browser
DEBUG - 2023-03-16 07:25:44 --> Total execution time: 0.0226
INFO - 2023-03-16 07:25:44 --> Config Class Initialized
INFO - 2023-03-16 07:25:44 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:25:44 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:25:44 --> Utf8 Class Initialized
INFO - 2023-03-16 07:25:44 --> URI Class Initialized
INFO - 2023-03-16 07:25:44 --> Router Class Initialized
INFO - 2023-03-16 07:25:44 --> Output Class Initialized
INFO - 2023-03-16 07:25:44 --> Security Class Initialized
DEBUG - 2023-03-16 07:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:25:44 --> Input Class Initialized
INFO - 2023-03-16 07:25:44 --> Language Class Initialized
INFO - 2023-03-16 07:25:44 --> Loader Class Initialized
INFO - 2023-03-16 07:25:44 --> Controller Class Initialized
DEBUG - 2023-03-16 07:25:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:25:44 --> Database Driver Class Initialized
INFO - 2023-03-16 07:25:44 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:25:44 --> Final output sent to browser
DEBUG - 2023-03-16 07:25:44 --> Total execution time: 0.0152
INFO - 2023-03-16 07:26:48 --> Config Class Initialized
INFO - 2023-03-16 07:26:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:26:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:26:48 --> Utf8 Class Initialized
INFO - 2023-03-16 07:26:48 --> URI Class Initialized
INFO - 2023-03-16 07:26:48 --> Router Class Initialized
INFO - 2023-03-16 07:26:48 --> Output Class Initialized
INFO - 2023-03-16 07:26:48 --> Security Class Initialized
DEBUG - 2023-03-16 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:26:48 --> Input Class Initialized
INFO - 2023-03-16 07:26:48 --> Language Class Initialized
INFO - 2023-03-16 07:26:48 --> Loader Class Initialized
INFO - 2023-03-16 07:26:48 --> Controller Class Initialized
DEBUG - 2023-03-16 07:26:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:26:48 --> Database Driver Class Initialized
INFO - 2023-03-16 07:26:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:26:48 --> Final output sent to browser
DEBUG - 2023-03-16 07:26:48 --> Total execution time: 0.1484
INFO - 2023-03-16 07:26:48 --> Config Class Initialized
INFO - 2023-03-16 07:26:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:26:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:26:48 --> Utf8 Class Initialized
INFO - 2023-03-16 07:26:48 --> URI Class Initialized
INFO - 2023-03-16 07:26:48 --> Router Class Initialized
INFO - 2023-03-16 07:26:48 --> Output Class Initialized
INFO - 2023-03-16 07:26:48 --> Security Class Initialized
DEBUG - 2023-03-16 07:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:26:48 --> Input Class Initialized
INFO - 2023-03-16 07:26:48 --> Language Class Initialized
INFO - 2023-03-16 07:26:48 --> Loader Class Initialized
INFO - 2023-03-16 07:26:48 --> Controller Class Initialized
DEBUG - 2023-03-16 07:26:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:26:48 --> Database Driver Class Initialized
INFO - 2023-03-16 07:26:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:26:48 --> Final output sent to browser
DEBUG - 2023-03-16 07:26:48 --> Total execution time: 0.0158
INFO - 2023-03-16 07:26:52 --> Config Class Initialized
INFO - 2023-03-16 07:26:52 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:26:52 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:26:52 --> Utf8 Class Initialized
INFO - 2023-03-16 07:26:52 --> URI Class Initialized
INFO - 2023-03-16 07:26:52 --> Router Class Initialized
INFO - 2023-03-16 07:26:52 --> Output Class Initialized
INFO - 2023-03-16 07:26:52 --> Security Class Initialized
DEBUG - 2023-03-16 07:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:26:52 --> Input Class Initialized
INFO - 2023-03-16 07:26:52 --> Language Class Initialized
INFO - 2023-03-16 07:26:52 --> Loader Class Initialized
INFO - 2023-03-16 07:26:52 --> Controller Class Initialized
DEBUG - 2023-03-16 07:26:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:26:52 --> Database Driver Class Initialized
INFO - 2023-03-16 07:26:52 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:26:52 --> Final output sent to browser
DEBUG - 2023-03-16 07:26:52 --> Total execution time: 0.0465
INFO - 2023-03-16 07:26:52 --> Config Class Initialized
INFO - 2023-03-16 07:26:52 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:26:52 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:26:52 --> Utf8 Class Initialized
INFO - 2023-03-16 07:26:52 --> URI Class Initialized
INFO - 2023-03-16 07:26:52 --> Router Class Initialized
INFO - 2023-03-16 07:26:52 --> Output Class Initialized
INFO - 2023-03-16 07:26:52 --> Security Class Initialized
DEBUG - 2023-03-16 07:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:26:52 --> Input Class Initialized
INFO - 2023-03-16 07:26:52 --> Language Class Initialized
INFO - 2023-03-16 07:26:52 --> Loader Class Initialized
INFO - 2023-03-16 07:26:52 --> Controller Class Initialized
DEBUG - 2023-03-16 07:26:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:26:52 --> Database Driver Class Initialized
INFO - 2023-03-16 07:26:52 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:26:52 --> Final output sent to browser
DEBUG - 2023-03-16 07:26:52 --> Total execution time: 0.0805
INFO - 2023-03-16 07:26:57 --> Config Class Initialized
INFO - 2023-03-16 07:26:57 --> Hooks Class Initialized
INFO - 2023-03-16 07:26:57 --> Config Class Initialized
INFO - 2023-03-16 07:26:57 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:26:57 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:26:57 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:26:57 --> Utf8 Class Initialized
INFO - 2023-03-16 07:26:57 --> Utf8 Class Initialized
INFO - 2023-03-16 07:26:57 --> URI Class Initialized
INFO - 2023-03-16 07:26:57 --> URI Class Initialized
INFO - 2023-03-16 07:26:57 --> Router Class Initialized
INFO - 2023-03-16 07:26:57 --> Router Class Initialized
INFO - 2023-03-16 07:26:57 --> Output Class Initialized
INFO - 2023-03-16 07:26:57 --> Output Class Initialized
INFO - 2023-03-16 07:26:57 --> Security Class Initialized
INFO - 2023-03-16 07:26:57 --> Security Class Initialized
DEBUG - 2023-03-16 07:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:26:57 --> Input Class Initialized
INFO - 2023-03-16 07:26:57 --> Input Class Initialized
INFO - 2023-03-16 07:26:57 --> Language Class Initialized
INFO - 2023-03-16 07:26:57 --> Language Class Initialized
INFO - 2023-03-16 07:26:57 --> Loader Class Initialized
INFO - 2023-03-16 07:26:57 --> Loader Class Initialized
INFO - 2023-03-16 07:26:57 --> Controller Class Initialized
INFO - 2023-03-16 07:26:57 --> Controller Class Initialized
DEBUG - 2023-03-16 07:26:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:26:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:26:57 --> Final output sent to browser
DEBUG - 2023-03-16 07:26:57 --> Total execution time: 0.0042
INFO - 2023-03-16 07:26:57 --> Database Driver Class Initialized
INFO - 2023-03-16 07:26:57 --> Config Class Initialized
INFO - 2023-03-16 07:26:57 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:26:57 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:26:57 --> Utf8 Class Initialized
INFO - 2023-03-16 07:26:57 --> URI Class Initialized
INFO - 2023-03-16 07:26:57 --> Router Class Initialized
INFO - 2023-03-16 07:26:57 --> Output Class Initialized
INFO - 2023-03-16 07:26:57 --> Security Class Initialized
DEBUG - 2023-03-16 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:26:57 --> Input Class Initialized
INFO - 2023-03-16 07:26:57 --> Language Class Initialized
INFO - 2023-03-16 07:26:57 --> Loader Class Initialized
INFO - 2023-03-16 07:26:57 --> Controller Class Initialized
DEBUG - 2023-03-16 07:26:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:26:57 --> Database Driver Class Initialized
INFO - 2023-03-16 07:26:57 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:26:57 --> Model "Login_model" initialized
INFO - 2023-03-16 07:26:57 --> Final output sent to browser
DEBUG - 2023-03-16 07:26:57 --> Total execution time: 0.0175
INFO - 2023-03-16 07:26:57 --> Config Class Initialized
INFO - 2023-03-16 07:26:57 --> Hooks Class Initialized
INFO - 2023-03-16 07:26:57 --> Database Driver Class Initialized
DEBUG - 2023-03-16 07:26:57 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:26:57 --> Utf8 Class Initialized
INFO - 2023-03-16 07:26:57 --> URI Class Initialized
INFO - 2023-03-16 07:26:57 --> Router Class Initialized
INFO - 2023-03-16 07:26:57 --> Output Class Initialized
INFO - 2023-03-16 07:26:57 --> Security Class Initialized
DEBUG - 2023-03-16 07:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:26:57 --> Input Class Initialized
INFO - 2023-03-16 07:26:57 --> Language Class Initialized
INFO - 2023-03-16 07:26:57 --> Loader Class Initialized
INFO - 2023-03-16 07:26:57 --> Controller Class Initialized
DEBUG - 2023-03-16 07:26:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:26:57 --> Database Driver Class Initialized
INFO - 2023-03-16 07:26:57 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:26:57 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:26:57 --> Final output sent to browser
DEBUG - 2023-03-16 07:26:57 --> Total execution time: 0.0232
INFO - 2023-03-16 07:26:57 --> Final output sent to browser
DEBUG - 2023-03-16 07:26:58 --> Total execution time: 0.0144
INFO - 2023-03-16 07:27:01 --> Config Class Initialized
INFO - 2023-03-16 07:27:01 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:01 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:01 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:01 --> URI Class Initialized
INFO - 2023-03-16 07:27:01 --> Router Class Initialized
INFO - 2023-03-16 07:27:01 --> Output Class Initialized
INFO - 2023-03-16 07:27:01 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:01 --> Input Class Initialized
INFO - 2023-03-16 07:27:01 --> Language Class Initialized
INFO - 2023-03-16 07:27:01 --> Loader Class Initialized
INFO - 2023-03-16 07:27:01 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:01 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:01 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:01 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:01 --> Model "Login_model" initialized
INFO - 2023-03-16 07:27:01 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:01 --> Total execution time: 0.0461
INFO - 2023-03-16 07:27:01 --> Config Class Initialized
INFO - 2023-03-16 07:27:01 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:01 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:01 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:01 --> URI Class Initialized
INFO - 2023-03-16 07:27:01 --> Router Class Initialized
INFO - 2023-03-16 07:27:01 --> Output Class Initialized
INFO - 2023-03-16 07:27:01 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:01 --> Input Class Initialized
INFO - 2023-03-16 07:27:01 --> Language Class Initialized
INFO - 2023-03-16 07:27:01 --> Loader Class Initialized
INFO - 2023-03-16 07:27:01 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:01 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:01 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:01 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:01 --> Model "Login_model" initialized
INFO - 2023-03-16 07:27:01 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:01 --> Total execution time: 0.0403
INFO - 2023-03-16 07:27:03 --> Config Class Initialized
INFO - 2023-03-16 07:27:03 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:03 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:03 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:03 --> URI Class Initialized
INFO - 2023-03-16 07:27:03 --> Router Class Initialized
INFO - 2023-03-16 07:27:03 --> Output Class Initialized
INFO - 2023-03-16 07:27:03 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:03 --> Input Class Initialized
INFO - 2023-03-16 07:27:03 --> Language Class Initialized
INFO - 2023-03-16 07:27:03 --> Loader Class Initialized
INFO - 2023-03-16 07:27:03 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:03 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:03 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:03 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:03 --> Total execution time: 0.0544
INFO - 2023-03-16 07:27:03 --> Config Class Initialized
INFO - 2023-03-16 07:27:03 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:03 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:03 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:03 --> URI Class Initialized
INFO - 2023-03-16 07:27:03 --> Router Class Initialized
INFO - 2023-03-16 07:27:03 --> Output Class Initialized
INFO - 2023-03-16 07:27:03 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:03 --> Input Class Initialized
INFO - 2023-03-16 07:27:03 --> Language Class Initialized
INFO - 2023-03-16 07:27:03 --> Loader Class Initialized
INFO - 2023-03-16 07:27:03 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:03 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:03 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:03 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:03 --> Total execution time: 0.0525
INFO - 2023-03-16 07:27:09 --> Config Class Initialized
INFO - 2023-03-16 07:27:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:09 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:09 --> URI Class Initialized
INFO - 2023-03-16 07:27:09 --> Router Class Initialized
INFO - 2023-03-16 07:27:09 --> Output Class Initialized
INFO - 2023-03-16 07:27:09 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:09 --> Input Class Initialized
INFO - 2023-03-16 07:27:09 --> Language Class Initialized
INFO - 2023-03-16 07:27:09 --> Loader Class Initialized
INFO - 2023-03-16 07:27:09 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:09 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:09 --> Total execution time: 0.0175
INFO - 2023-03-16 07:27:09 --> Config Class Initialized
INFO - 2023-03-16 07:27:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:09 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:09 --> URI Class Initialized
INFO - 2023-03-16 07:27:09 --> Router Class Initialized
INFO - 2023-03-16 07:27:09 --> Output Class Initialized
INFO - 2023-03-16 07:27:09 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:09 --> Input Class Initialized
INFO - 2023-03-16 07:27:09 --> Language Class Initialized
INFO - 2023-03-16 07:27:09 --> Loader Class Initialized
INFO - 2023-03-16 07:27:09 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:09 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:09 --> Total execution time: 0.0524
INFO - 2023-03-16 07:27:15 --> Config Class Initialized
INFO - 2023-03-16 07:27:15 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:15 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:15 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:15 --> URI Class Initialized
INFO - 2023-03-16 07:27:15 --> Router Class Initialized
INFO - 2023-03-16 07:27:15 --> Output Class Initialized
INFO - 2023-03-16 07:27:15 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:15 --> Input Class Initialized
INFO - 2023-03-16 07:27:15 --> Language Class Initialized
INFO - 2023-03-16 07:27:15 --> Loader Class Initialized
INFO - 2023-03-16 07:27:15 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:15 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:15 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:15 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:15 --> Total execution time: 0.0159
INFO - 2023-03-16 07:27:15 --> Config Class Initialized
INFO - 2023-03-16 07:27:15 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:15 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:15 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:15 --> URI Class Initialized
INFO - 2023-03-16 07:27:15 --> Router Class Initialized
INFO - 2023-03-16 07:27:15 --> Output Class Initialized
INFO - 2023-03-16 07:27:15 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:15 --> Input Class Initialized
INFO - 2023-03-16 07:27:15 --> Language Class Initialized
INFO - 2023-03-16 07:27:15 --> Loader Class Initialized
INFO - 2023-03-16 07:27:15 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:15 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:15 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:15 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:15 --> Total execution time: 0.0120
INFO - 2023-03-16 07:27:17 --> Config Class Initialized
INFO - 2023-03-16 07:27:17 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:17 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:17 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:17 --> URI Class Initialized
INFO - 2023-03-16 07:27:17 --> Router Class Initialized
INFO - 2023-03-16 07:27:17 --> Output Class Initialized
INFO - 2023-03-16 07:27:17 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:17 --> Input Class Initialized
INFO - 2023-03-16 07:27:17 --> Language Class Initialized
INFO - 2023-03-16 07:27:17 --> Loader Class Initialized
INFO - 2023-03-16 07:27:17 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:17 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:17 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:17 --> Final output sent to browser
INFO - 2023-03-16 07:27:17 --> Config Class Initialized
DEBUG - 2023-03-16 07:27:17 --> Total execution time: 0.0473
INFO - 2023-03-16 07:27:17 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:17 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:17 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:17 --> URI Class Initialized
INFO - 2023-03-16 07:27:17 --> Router Class Initialized
INFO - 2023-03-16 07:27:17 --> Output Class Initialized
INFO - 2023-03-16 07:27:17 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:17 --> Input Class Initialized
INFO - 2023-03-16 07:27:17 --> Language Class Initialized
INFO - 2023-03-16 07:27:17 --> Loader Class Initialized
INFO - 2023-03-16 07:27:17 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:17 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:17 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:17 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:17 --> Total execution time: 0.0884
INFO - 2023-03-16 07:27:31 --> Config Class Initialized
INFO - 2023-03-16 07:27:31 --> Config Class Initialized
INFO - 2023-03-16 07:27:31 --> Hooks Class Initialized
INFO - 2023-03-16 07:27:31 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:31 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:27:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:31 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:31 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:31 --> URI Class Initialized
INFO - 2023-03-16 07:27:31 --> URI Class Initialized
INFO - 2023-03-16 07:27:31 --> Router Class Initialized
INFO - 2023-03-16 07:27:31 --> Router Class Initialized
INFO - 2023-03-16 07:27:31 --> Output Class Initialized
INFO - 2023-03-16 07:27:31 --> Output Class Initialized
INFO - 2023-03-16 07:27:31 --> Security Class Initialized
INFO - 2023-03-16 07:27:31 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:31 --> Input Class Initialized
INFO - 2023-03-16 07:27:31 --> Input Class Initialized
INFO - 2023-03-16 07:27:31 --> Language Class Initialized
INFO - 2023-03-16 07:27:31 --> Language Class Initialized
INFO - 2023-03-16 07:27:31 --> Loader Class Initialized
INFO - 2023-03-16 07:27:31 --> Loader Class Initialized
INFO - 2023-03-16 07:27:31 --> Controller Class Initialized
INFO - 2023-03-16 07:27:31 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:27:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:31 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:31 --> Total execution time: 0.0092
INFO - 2023-03-16 07:27:31 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:31 --> Config Class Initialized
INFO - 2023-03-16 07:27:31 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:31 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:31 --> URI Class Initialized
INFO - 2023-03-16 07:27:31 --> Router Class Initialized
INFO - 2023-03-16 07:27:31 --> Output Class Initialized
INFO - 2023-03-16 07:27:31 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:31 --> Input Class Initialized
INFO - 2023-03-16 07:27:31 --> Language Class Initialized
INFO - 2023-03-16 07:27:31 --> Loader Class Initialized
INFO - 2023-03-16 07:27:31 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:31 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:31 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:31 --> Model "Login_model" initialized
INFO - 2023-03-16 07:27:31 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:31 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:31 --> Total execution time: 0.0435
INFO - 2023-03-16 07:27:31 --> Config Class Initialized
INFO - 2023-03-16 07:27:31 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:31 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:31 --> URI Class Initialized
INFO - 2023-03-16 07:27:31 --> Router Class Initialized
INFO - 2023-03-16 07:27:31 --> Output Class Initialized
INFO - 2023-03-16 07:27:31 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:31 --> Input Class Initialized
INFO - 2023-03-16 07:27:31 --> Language Class Initialized
INFO - 2023-03-16 07:27:31 --> Loader Class Initialized
INFO - 2023-03-16 07:27:31 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:31 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:31 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:31 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:31 --> Total execution time: 0.0438
INFO - 2023-03-16 07:27:31 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:31 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:31 --> Total execution time: 0.0554
INFO - 2023-03-16 07:27:33 --> Config Class Initialized
INFO - 2023-03-16 07:27:33 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:34 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:34 --> URI Class Initialized
INFO - 2023-03-16 07:27:34 --> Router Class Initialized
INFO - 2023-03-16 07:27:34 --> Output Class Initialized
INFO - 2023-03-16 07:27:34 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:34 --> Input Class Initialized
INFO - 2023-03-16 07:27:34 --> Language Class Initialized
INFO - 2023-03-16 07:27:34 --> Loader Class Initialized
INFO - 2023-03-16 07:27:34 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:34 --> Model "Login_model" initialized
INFO - 2023-03-16 07:27:34 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:34 --> Total execution time: 0.0687
INFO - 2023-03-16 07:27:34 --> Config Class Initialized
INFO - 2023-03-16 07:27:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:27:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:27:34 --> Utf8 Class Initialized
INFO - 2023-03-16 07:27:34 --> URI Class Initialized
INFO - 2023-03-16 07:27:34 --> Router Class Initialized
INFO - 2023-03-16 07:27:34 --> Output Class Initialized
INFO - 2023-03-16 07:27:34 --> Security Class Initialized
DEBUG - 2023-03-16 07:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:27:34 --> Input Class Initialized
INFO - 2023-03-16 07:27:34 --> Language Class Initialized
INFO - 2023-03-16 07:27:34 --> Loader Class Initialized
INFO - 2023-03-16 07:27:34 --> Controller Class Initialized
DEBUG - 2023-03-16 07:27:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:27:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:27:34 --> Database Driver Class Initialized
INFO - 2023-03-16 07:27:34 --> Model "Login_model" initialized
INFO - 2023-03-16 07:27:34 --> Final output sent to browser
DEBUG - 2023-03-16 07:27:34 --> Total execution time: 0.0394
INFO - 2023-03-16 07:30:22 --> Config Class Initialized
INFO - 2023-03-16 07:30:22 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:30:22 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:30:22 --> Utf8 Class Initialized
INFO - 2023-03-16 07:30:22 --> URI Class Initialized
INFO - 2023-03-16 07:30:22 --> Router Class Initialized
INFO - 2023-03-16 07:30:22 --> Output Class Initialized
INFO - 2023-03-16 07:30:22 --> Security Class Initialized
DEBUG - 2023-03-16 07:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:30:22 --> Input Class Initialized
INFO - 2023-03-16 07:30:22 --> Language Class Initialized
INFO - 2023-03-16 07:30:22 --> Loader Class Initialized
INFO - 2023-03-16 07:30:22 --> Controller Class Initialized
DEBUG - 2023-03-16 07:30:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:30:22 --> Database Driver Class Initialized
INFO - 2023-03-16 07:30:22 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:30:22 --> Final output sent to browser
DEBUG - 2023-03-16 07:30:22 --> Total execution time: 0.0545
INFO - 2023-03-16 07:30:22 --> Config Class Initialized
INFO - 2023-03-16 07:30:22 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:30:22 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:30:22 --> Utf8 Class Initialized
INFO - 2023-03-16 07:30:22 --> URI Class Initialized
INFO - 2023-03-16 07:30:22 --> Router Class Initialized
INFO - 2023-03-16 07:30:22 --> Output Class Initialized
INFO - 2023-03-16 07:30:22 --> Security Class Initialized
DEBUG - 2023-03-16 07:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:30:22 --> Input Class Initialized
INFO - 2023-03-16 07:30:22 --> Language Class Initialized
INFO - 2023-03-16 07:30:22 --> Loader Class Initialized
INFO - 2023-03-16 07:30:22 --> Controller Class Initialized
DEBUG - 2023-03-16 07:30:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:30:22 --> Database Driver Class Initialized
INFO - 2023-03-16 07:30:22 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:30:22 --> Final output sent to browser
DEBUG - 2023-03-16 07:30:22 --> Total execution time: 0.0490
INFO - 2023-03-16 07:31:06 --> Config Class Initialized
INFO - 2023-03-16 07:31:06 --> Config Class Initialized
INFO - 2023-03-16 07:31:06 --> Hooks Class Initialized
INFO - 2023-03-16 07:31:06 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:31:06 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:06 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:06 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:06 --> URI Class Initialized
INFO - 2023-03-16 07:31:06 --> URI Class Initialized
INFO - 2023-03-16 07:31:06 --> Router Class Initialized
INFO - 2023-03-16 07:31:06 --> Router Class Initialized
INFO - 2023-03-16 07:31:06 --> Output Class Initialized
INFO - 2023-03-16 07:31:06 --> Output Class Initialized
INFO - 2023-03-16 07:31:06 --> Security Class Initialized
INFO - 2023-03-16 07:31:06 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:06 --> Input Class Initialized
INFO - 2023-03-16 07:31:06 --> Input Class Initialized
INFO - 2023-03-16 07:31:06 --> Language Class Initialized
INFO - 2023-03-16 07:31:06 --> Language Class Initialized
INFO - 2023-03-16 07:31:06 --> Loader Class Initialized
INFO - 2023-03-16 07:31:06 --> Loader Class Initialized
INFO - 2023-03-16 07:31:06 --> Controller Class Initialized
INFO - 2023-03-16 07:31:06 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:31:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:06 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:06 --> Total execution time: 0.0048
INFO - 2023-03-16 07:31:06 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:06 --> Config Class Initialized
INFO - 2023-03-16 07:31:06 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:06 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:06 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:06 --> URI Class Initialized
INFO - 2023-03-16 07:31:06 --> Router Class Initialized
INFO - 2023-03-16 07:31:06 --> Output Class Initialized
INFO - 2023-03-16 07:31:06 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:06 --> Input Class Initialized
INFO - 2023-03-16 07:31:06 --> Language Class Initialized
INFO - 2023-03-16 07:31:06 --> Loader Class Initialized
INFO - 2023-03-16 07:31:06 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:06 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:06 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:06 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:06 --> Total execution time: 0.0189
INFO - 2023-03-16 07:31:06 --> Model "Login_model" initialized
INFO - 2023-03-16 07:31:06 --> Config Class Initialized
INFO - 2023-03-16 07:31:06 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:06 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:06 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:06 --> URI Class Initialized
INFO - 2023-03-16 07:31:06 --> Router Class Initialized
INFO - 2023-03-16 07:31:06 --> Output Class Initialized
INFO - 2023-03-16 07:31:06 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:06 --> Input Class Initialized
INFO - 2023-03-16 07:31:06 --> Language Class Initialized
INFO - 2023-03-16 07:31:06 --> Loader Class Initialized
INFO - 2023-03-16 07:31:06 --> Controller Class Initialized
INFO - 2023-03-16 07:31:06 --> Database Driver Class Initialized
DEBUG - 2023-03-16 07:31:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:06 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:06 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:06 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:06 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:06 --> Total execution time: 0.0271
INFO - 2023-03-16 07:31:06 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:06 --> Total execution time: 0.0163
INFO - 2023-03-16 07:31:07 --> Config Class Initialized
INFO - 2023-03-16 07:31:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:07 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:07 --> URI Class Initialized
INFO - 2023-03-16 07:31:07 --> Router Class Initialized
INFO - 2023-03-16 07:31:07 --> Output Class Initialized
INFO - 2023-03-16 07:31:07 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:07 --> Input Class Initialized
INFO - 2023-03-16 07:31:07 --> Language Class Initialized
INFO - 2023-03-16 07:31:07 --> Loader Class Initialized
INFO - 2023-03-16 07:31:07 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:07 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:07 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:07 --> Model "Login_model" initialized
INFO - 2023-03-16 07:31:07 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:07 --> Total execution time: 0.0426
INFO - 2023-03-16 07:31:07 --> Config Class Initialized
INFO - 2023-03-16 07:31:07 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:07 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:07 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:07 --> URI Class Initialized
INFO - 2023-03-16 07:31:07 --> Router Class Initialized
INFO - 2023-03-16 07:31:07 --> Output Class Initialized
INFO - 2023-03-16 07:31:07 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:07 --> Input Class Initialized
INFO - 2023-03-16 07:31:07 --> Language Class Initialized
INFO - 2023-03-16 07:31:07 --> Loader Class Initialized
INFO - 2023-03-16 07:31:07 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:07 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:07 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:07 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:07 --> Model "Login_model" initialized
INFO - 2023-03-16 07:31:07 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:07 --> Total execution time: 0.0363
INFO - 2023-03-16 07:31:08 --> Config Class Initialized
INFO - 2023-03-16 07:31:08 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:08 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:08 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:08 --> URI Class Initialized
INFO - 2023-03-16 07:31:08 --> Router Class Initialized
INFO - 2023-03-16 07:31:08 --> Output Class Initialized
INFO - 2023-03-16 07:31:08 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:08 --> Input Class Initialized
INFO - 2023-03-16 07:31:08 --> Language Class Initialized
INFO - 2023-03-16 07:31:08 --> Loader Class Initialized
INFO - 2023-03-16 07:31:08 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:08 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:08 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:08 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:08 --> Total execution time: 0.0436
INFO - 2023-03-16 07:31:08 --> Config Class Initialized
INFO - 2023-03-16 07:31:08 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:08 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:08 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:08 --> URI Class Initialized
INFO - 2023-03-16 07:31:08 --> Router Class Initialized
INFO - 2023-03-16 07:31:08 --> Output Class Initialized
INFO - 2023-03-16 07:31:08 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:08 --> Input Class Initialized
INFO - 2023-03-16 07:31:08 --> Language Class Initialized
INFO - 2023-03-16 07:31:08 --> Loader Class Initialized
INFO - 2023-03-16 07:31:08 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:08 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:08 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:08 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:08 --> Total execution time: 0.0397
INFO - 2023-03-16 07:31:09 --> Config Class Initialized
INFO - 2023-03-16 07:31:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:09 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:09 --> URI Class Initialized
INFO - 2023-03-16 07:31:09 --> Router Class Initialized
INFO - 2023-03-16 07:31:09 --> Output Class Initialized
INFO - 2023-03-16 07:31:09 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:09 --> Input Class Initialized
INFO - 2023-03-16 07:31:09 --> Language Class Initialized
INFO - 2023-03-16 07:31:09 --> Loader Class Initialized
INFO - 2023-03-16 07:31:09 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:09 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:09 --> Total execution time: 0.0161
INFO - 2023-03-16 07:31:09 --> Config Class Initialized
INFO - 2023-03-16 07:31:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:09 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:09 --> URI Class Initialized
INFO - 2023-03-16 07:31:09 --> Router Class Initialized
INFO - 2023-03-16 07:31:09 --> Output Class Initialized
INFO - 2023-03-16 07:31:09 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:09 --> Input Class Initialized
INFO - 2023-03-16 07:31:09 --> Language Class Initialized
INFO - 2023-03-16 07:31:09 --> Loader Class Initialized
INFO - 2023-03-16 07:31:09 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:09 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:09 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:09 --> Total execution time: 0.0131
INFO - 2023-03-16 07:31:11 --> Config Class Initialized
INFO - 2023-03-16 07:31:11 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:11 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:11 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:11 --> URI Class Initialized
INFO - 2023-03-16 07:31:11 --> Router Class Initialized
INFO - 2023-03-16 07:31:11 --> Output Class Initialized
INFO - 2023-03-16 07:31:11 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:11 --> Input Class Initialized
INFO - 2023-03-16 07:31:11 --> Language Class Initialized
INFO - 2023-03-16 07:31:11 --> Loader Class Initialized
INFO - 2023-03-16 07:31:11 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:11 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:11 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:11 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:11 --> Total execution time: 0.0549
INFO - 2023-03-16 07:31:14 --> Config Class Initialized
INFO - 2023-03-16 07:31:14 --> Hooks Class Initialized
INFO - 2023-03-16 07:31:14 --> Config Class Initialized
INFO - 2023-03-16 07:31:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:31:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:14 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:14 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:14 --> URI Class Initialized
INFO - 2023-03-16 07:31:14 --> URI Class Initialized
INFO - 2023-03-16 07:31:14 --> Router Class Initialized
INFO - 2023-03-16 07:31:14 --> Router Class Initialized
INFO - 2023-03-16 07:31:14 --> Output Class Initialized
INFO - 2023-03-16 07:31:14 --> Output Class Initialized
INFO - 2023-03-16 07:31:14 --> Security Class Initialized
INFO - 2023-03-16 07:31:14 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:14 --> Input Class Initialized
INFO - 2023-03-16 07:31:14 --> Input Class Initialized
INFO - 2023-03-16 07:31:14 --> Language Class Initialized
INFO - 2023-03-16 07:31:14 --> Language Class Initialized
INFO - 2023-03-16 07:31:14 --> Loader Class Initialized
INFO - 2023-03-16 07:31:14 --> Loader Class Initialized
INFO - 2023-03-16 07:31:14 --> Controller Class Initialized
INFO - 2023-03-16 07:31:14 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:14 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:14 --> Total execution time: 0.0051
INFO - 2023-03-16 07:31:14 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:14 --> Config Class Initialized
INFO - 2023-03-16 07:31:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:14 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:14 --> URI Class Initialized
INFO - 2023-03-16 07:31:14 --> Router Class Initialized
INFO - 2023-03-16 07:31:14 --> Output Class Initialized
INFO - 2023-03-16 07:31:14 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:14 --> Input Class Initialized
INFO - 2023-03-16 07:31:14 --> Language Class Initialized
INFO - 2023-03-16 07:31:14 --> Loader Class Initialized
INFO - 2023-03-16 07:31:14 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:14 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:14 --> Model "Login_model" initialized
INFO - 2023-03-16 07:31:14 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:14 --> Total execution time: 0.0215
INFO - 2023-03-16 07:31:14 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:14 --> Config Class Initialized
INFO - 2023-03-16 07:31:14 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:14 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:14 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:14 --> URI Class Initialized
INFO - 2023-03-16 07:31:14 --> Router Class Initialized
INFO - 2023-03-16 07:31:14 --> Output Class Initialized
INFO - 2023-03-16 07:31:14 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:14 --> Input Class Initialized
INFO - 2023-03-16 07:31:14 --> Language Class Initialized
INFO - 2023-03-16 07:31:14 --> Loader Class Initialized
INFO - 2023-03-16 07:31:14 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:14 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:14 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:14 --> Total execution time: 0.0244
INFO - 2023-03-16 07:31:14 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:14 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:14 --> Total execution time: 0.0575
INFO - 2023-03-16 07:31:16 --> Config Class Initialized
INFO - 2023-03-16 07:31:16 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:16 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:16 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:16 --> URI Class Initialized
INFO - 2023-03-16 07:31:16 --> Router Class Initialized
INFO - 2023-03-16 07:31:16 --> Output Class Initialized
INFO - 2023-03-16 07:31:16 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:16 --> Input Class Initialized
INFO - 2023-03-16 07:31:16 --> Language Class Initialized
INFO - 2023-03-16 07:31:16 --> Loader Class Initialized
INFO - 2023-03-16 07:31:16 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:16 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:16 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:16 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:16 --> Total execution time: 0.0466
INFO - 2023-03-16 07:31:16 --> Config Class Initialized
INFO - 2023-03-16 07:31:16 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:16 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:16 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:16 --> URI Class Initialized
INFO - 2023-03-16 07:31:16 --> Router Class Initialized
INFO - 2023-03-16 07:31:16 --> Output Class Initialized
INFO - 2023-03-16 07:31:16 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:16 --> Input Class Initialized
INFO - 2023-03-16 07:31:16 --> Language Class Initialized
INFO - 2023-03-16 07:31:16 --> Loader Class Initialized
INFO - 2023-03-16 07:31:16 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:16 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:16 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:16 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:16 --> Total execution time: 0.0391
INFO - 2023-03-16 07:31:17 --> Config Class Initialized
INFO - 2023-03-16 07:31:17 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:17 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:17 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:17 --> URI Class Initialized
INFO - 2023-03-16 07:31:17 --> Router Class Initialized
INFO - 2023-03-16 07:31:17 --> Output Class Initialized
INFO - 2023-03-16 07:31:17 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:17 --> Input Class Initialized
INFO - 2023-03-16 07:31:17 --> Language Class Initialized
INFO - 2023-03-16 07:31:17 --> Loader Class Initialized
INFO - 2023-03-16 07:31:17 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:17 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:17 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:17 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:17 --> Total execution time: 0.0183
INFO - 2023-03-16 07:31:17 --> Config Class Initialized
INFO - 2023-03-16 07:31:17 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:17 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:17 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:17 --> URI Class Initialized
INFO - 2023-03-16 07:31:17 --> Router Class Initialized
INFO - 2023-03-16 07:31:17 --> Output Class Initialized
INFO - 2023-03-16 07:31:17 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:17 --> Input Class Initialized
INFO - 2023-03-16 07:31:17 --> Language Class Initialized
INFO - 2023-03-16 07:31:17 --> Loader Class Initialized
INFO - 2023-03-16 07:31:17 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:17 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:17 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:17 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:17 --> Total execution time: 0.0143
INFO - 2023-03-16 07:31:20 --> Config Class Initialized
INFO - 2023-03-16 07:31:20 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:20 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:20 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:20 --> URI Class Initialized
INFO - 2023-03-16 07:31:20 --> Router Class Initialized
INFO - 2023-03-16 07:31:20 --> Output Class Initialized
INFO - 2023-03-16 07:31:20 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:20 --> Input Class Initialized
INFO - 2023-03-16 07:31:20 --> Language Class Initialized
INFO - 2023-03-16 07:31:20 --> Loader Class Initialized
INFO - 2023-03-16 07:31:20 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:20 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:20 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:20 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:20 --> Total execution time: 0.0189
INFO - 2023-03-16 07:31:20 --> Config Class Initialized
INFO - 2023-03-16 07:31:20 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:20 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:20 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:20 --> URI Class Initialized
INFO - 2023-03-16 07:31:20 --> Router Class Initialized
INFO - 2023-03-16 07:31:20 --> Output Class Initialized
INFO - 2023-03-16 07:31:20 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:20 --> Input Class Initialized
INFO - 2023-03-16 07:31:20 --> Language Class Initialized
INFO - 2023-03-16 07:31:20 --> Loader Class Initialized
INFO - 2023-03-16 07:31:20 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:20 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:20 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:20 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:20 --> Total execution time: 0.0146
INFO - 2023-03-16 07:31:22 --> Config Class Initialized
INFO - 2023-03-16 07:31:22 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:22 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:22 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:22 --> URI Class Initialized
INFO - 2023-03-16 07:31:22 --> Router Class Initialized
INFO - 2023-03-16 07:31:22 --> Output Class Initialized
INFO - 2023-03-16 07:31:22 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:22 --> Input Class Initialized
INFO - 2023-03-16 07:31:22 --> Language Class Initialized
INFO - 2023-03-16 07:31:22 --> Loader Class Initialized
INFO - 2023-03-16 07:31:22 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:22 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:22 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:22 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:22 --> Total execution time: 0.0143
INFO - 2023-03-16 07:31:22 --> Config Class Initialized
INFO - 2023-03-16 07:31:22 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:22 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:22 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:22 --> URI Class Initialized
INFO - 2023-03-16 07:31:22 --> Router Class Initialized
INFO - 2023-03-16 07:31:22 --> Output Class Initialized
INFO - 2023-03-16 07:31:22 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:22 --> Input Class Initialized
INFO - 2023-03-16 07:31:22 --> Language Class Initialized
INFO - 2023-03-16 07:31:22 --> Loader Class Initialized
INFO - 2023-03-16 07:31:22 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:22 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:22 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:22 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:22 --> Total execution time: 0.0498
INFO - 2023-03-16 07:31:23 --> Config Class Initialized
INFO - 2023-03-16 07:31:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:23 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:23 --> URI Class Initialized
INFO - 2023-03-16 07:31:23 --> Router Class Initialized
INFO - 2023-03-16 07:31:23 --> Output Class Initialized
INFO - 2023-03-16 07:31:23 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:23 --> Input Class Initialized
INFO - 2023-03-16 07:31:23 --> Language Class Initialized
INFO - 2023-03-16 07:31:23 --> Loader Class Initialized
INFO - 2023-03-16 07:31:23 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:23 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:23 --> Total execution time: 0.0438
INFO - 2023-03-16 07:31:23 --> Config Class Initialized
INFO - 2023-03-16 07:31:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:23 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:23 --> URI Class Initialized
INFO - 2023-03-16 07:31:23 --> Router Class Initialized
INFO - 2023-03-16 07:31:23 --> Output Class Initialized
INFO - 2023-03-16 07:31:23 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:23 --> Input Class Initialized
INFO - 2023-03-16 07:31:23 --> Language Class Initialized
INFO - 2023-03-16 07:31:23 --> Loader Class Initialized
INFO - 2023-03-16 07:31:23 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:23 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:23 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:23 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:23 --> Total execution time: 0.0148
INFO - 2023-03-16 07:31:25 --> Config Class Initialized
INFO - 2023-03-16 07:31:25 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:25 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:25 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:25 --> URI Class Initialized
INFO - 2023-03-16 07:31:25 --> Router Class Initialized
INFO - 2023-03-16 07:31:25 --> Output Class Initialized
INFO - 2023-03-16 07:31:25 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:25 --> Input Class Initialized
INFO - 2023-03-16 07:31:25 --> Language Class Initialized
INFO - 2023-03-16 07:31:25 --> Loader Class Initialized
INFO - 2023-03-16 07:31:25 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:25 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:25 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:25 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:25 --> Total execution time: 0.0174
INFO - 2023-03-16 07:31:25 --> Config Class Initialized
INFO - 2023-03-16 07:31:25 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:31:25 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:31:25 --> Utf8 Class Initialized
INFO - 2023-03-16 07:31:25 --> URI Class Initialized
INFO - 2023-03-16 07:31:25 --> Router Class Initialized
INFO - 2023-03-16 07:31:25 --> Output Class Initialized
INFO - 2023-03-16 07:31:25 --> Security Class Initialized
DEBUG - 2023-03-16 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:31:25 --> Input Class Initialized
INFO - 2023-03-16 07:31:25 --> Language Class Initialized
INFO - 2023-03-16 07:31:25 --> Loader Class Initialized
INFO - 2023-03-16 07:31:25 --> Controller Class Initialized
DEBUG - 2023-03-16 07:31:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:31:25 --> Database Driver Class Initialized
INFO - 2023-03-16 07:31:25 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:31:25 --> Final output sent to browser
DEBUG - 2023-03-16 07:31:25 --> Total execution time: 0.0582
INFO - 2023-03-16 07:39:28 --> Config Class Initialized
INFO - 2023-03-16 07:39:28 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:39:28 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:39:28 --> Utf8 Class Initialized
INFO - 2023-03-16 07:39:28 --> URI Class Initialized
INFO - 2023-03-16 07:39:28 --> Router Class Initialized
INFO - 2023-03-16 07:39:28 --> Output Class Initialized
INFO - 2023-03-16 07:39:28 --> Security Class Initialized
DEBUG - 2023-03-16 07:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:39:28 --> Input Class Initialized
INFO - 2023-03-16 07:39:28 --> Language Class Initialized
INFO - 2023-03-16 07:39:28 --> Loader Class Initialized
INFO - 2023-03-16 07:39:28 --> Controller Class Initialized
DEBUG - 2023-03-16 07:39:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:39:28 --> Database Driver Class Initialized
INFO - 2023-03-16 07:39:28 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:39:28 --> Final output sent to browser
DEBUG - 2023-03-16 07:39:28 --> Total execution time: 0.0454
INFO - 2023-03-16 07:39:28 --> Config Class Initialized
INFO - 2023-03-16 07:39:28 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:39:28 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:39:28 --> Utf8 Class Initialized
INFO - 2023-03-16 07:39:28 --> URI Class Initialized
INFO - 2023-03-16 07:39:28 --> Router Class Initialized
INFO - 2023-03-16 07:39:28 --> Output Class Initialized
INFO - 2023-03-16 07:39:28 --> Security Class Initialized
DEBUG - 2023-03-16 07:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:39:28 --> Input Class Initialized
INFO - 2023-03-16 07:39:28 --> Language Class Initialized
INFO - 2023-03-16 07:39:28 --> Loader Class Initialized
INFO - 2023-03-16 07:39:28 --> Controller Class Initialized
DEBUG - 2023-03-16 07:39:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:39:28 --> Database Driver Class Initialized
INFO - 2023-03-16 07:39:28 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:39:28 --> Final output sent to browser
DEBUG - 2023-03-16 07:39:28 --> Total execution time: 0.0890
INFO - 2023-03-16 07:39:29 --> Config Class Initialized
INFO - 2023-03-16 07:39:29 --> Config Class Initialized
INFO - 2023-03-16 07:39:29 --> Hooks Class Initialized
INFO - 2023-03-16 07:39:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:39:29 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 07:39:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:39:29 --> Utf8 Class Initialized
INFO - 2023-03-16 07:39:29 --> Utf8 Class Initialized
INFO - 2023-03-16 07:39:29 --> URI Class Initialized
INFO - 2023-03-16 07:39:29 --> URI Class Initialized
INFO - 2023-03-16 07:39:29 --> Router Class Initialized
INFO - 2023-03-16 07:39:29 --> Router Class Initialized
INFO - 2023-03-16 07:39:29 --> Output Class Initialized
INFO - 2023-03-16 07:39:29 --> Output Class Initialized
INFO - 2023-03-16 07:39:29 --> Security Class Initialized
INFO - 2023-03-16 07:39:29 --> Security Class Initialized
DEBUG - 2023-03-16 07:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 07:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:39:29 --> Input Class Initialized
INFO - 2023-03-16 07:39:29 --> Input Class Initialized
INFO - 2023-03-16 07:39:29 --> Language Class Initialized
INFO - 2023-03-16 07:39:29 --> Language Class Initialized
INFO - 2023-03-16 07:39:29 --> Loader Class Initialized
INFO - 2023-03-16 07:39:29 --> Controller Class Initialized
INFO - 2023-03-16 07:39:29 --> Loader Class Initialized
DEBUG - 2023-03-16 07:39:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:39:29 --> Controller Class Initialized
INFO - 2023-03-16 07:39:29 --> Final output sent to browser
DEBUG - 2023-03-16 07:39:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 07:39:29 --> Total execution time: 0.0064
INFO - 2023-03-16 07:39:29 --> Database Driver Class Initialized
INFO - 2023-03-16 07:39:29 --> Config Class Initialized
INFO - 2023-03-16 07:39:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:39:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:39:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:39:29 --> Utf8 Class Initialized
INFO - 2023-03-16 07:39:29 --> URI Class Initialized
INFO - 2023-03-16 07:39:29 --> Router Class Initialized
INFO - 2023-03-16 07:39:29 --> Output Class Initialized
INFO - 2023-03-16 07:39:29 --> Security Class Initialized
DEBUG - 2023-03-16 07:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:39:29 --> Input Class Initialized
INFO - 2023-03-16 07:39:29 --> Language Class Initialized
INFO - 2023-03-16 07:39:29 --> Loader Class Initialized
INFO - 2023-03-16 07:39:29 --> Controller Class Initialized
DEBUG - 2023-03-16 07:39:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:39:29 --> Database Driver Class Initialized
INFO - 2023-03-16 07:39:29 --> Final output sent to browser
DEBUG - 2023-03-16 07:39:29 --> Total execution time: 0.0932
INFO - 2023-03-16 07:39:29 --> Config Class Initialized
INFO - 2023-03-16 07:39:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:39:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:39:29 --> Utf8 Class Initialized
INFO - 2023-03-16 07:39:29 --> URI Class Initialized
INFO - 2023-03-16 07:39:29 --> Router Class Initialized
INFO - 2023-03-16 07:39:29 --> Output Class Initialized
INFO - 2023-03-16 07:39:29 --> Security Class Initialized
DEBUG - 2023-03-16 07:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:39:29 --> Input Class Initialized
INFO - 2023-03-16 07:39:29 --> Language Class Initialized
INFO - 2023-03-16 07:39:29 --> Loader Class Initialized
INFO - 2023-03-16 07:39:29 --> Controller Class Initialized
DEBUG - 2023-03-16 07:39:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:39:29 --> Database Driver Class Initialized
INFO - 2023-03-16 07:39:29 --> Model "Login_model" initialized
INFO - 2023-03-16 07:39:29 --> Database Driver Class Initialized
INFO - 2023-03-16 07:39:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:39:29 --> Final output sent to browser
DEBUG - 2023-03-16 07:39:29 --> Total execution time: 0.0118
INFO - 2023-03-16 07:39:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:39:29 --> Final output sent to browser
DEBUG - 2023-03-16 07:39:29 --> Total execution time: 0.1423
INFO - 2023-03-16 07:51:39 --> Config Class Initialized
INFO - 2023-03-16 07:51:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:51:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:51:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:51:39 --> URI Class Initialized
INFO - 2023-03-16 07:51:39 --> Router Class Initialized
INFO - 2023-03-16 07:51:39 --> Output Class Initialized
INFO - 2023-03-16 07:51:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:51:39 --> Input Class Initialized
INFO - 2023-03-16 07:51:39 --> Language Class Initialized
INFO - 2023-03-16 07:51:39 --> Loader Class Initialized
INFO - 2023-03-16 07:51:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:51:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:51:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:51:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:51:39 --> Final output sent to browser
DEBUG - 2023-03-16 07:51:39 --> Total execution time: 0.0630
INFO - 2023-03-16 07:51:39 --> Config Class Initialized
INFO - 2023-03-16 07:51:39 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:51:39 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:51:39 --> Utf8 Class Initialized
INFO - 2023-03-16 07:51:39 --> URI Class Initialized
INFO - 2023-03-16 07:51:39 --> Router Class Initialized
INFO - 2023-03-16 07:51:39 --> Output Class Initialized
INFO - 2023-03-16 07:51:39 --> Security Class Initialized
DEBUG - 2023-03-16 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:51:39 --> Input Class Initialized
INFO - 2023-03-16 07:51:39 --> Language Class Initialized
INFO - 2023-03-16 07:51:39 --> Loader Class Initialized
INFO - 2023-03-16 07:51:39 --> Controller Class Initialized
DEBUG - 2023-03-16 07:51:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:51:39 --> Database Driver Class Initialized
INFO - 2023-03-16 07:51:39 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:51:39 --> Final output sent to browser
DEBUG - 2023-03-16 07:51:39 --> Total execution time: 0.0416
INFO - 2023-03-16 07:56:30 --> Config Class Initialized
INFO - 2023-03-16 07:56:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:56:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:56:30 --> Utf8 Class Initialized
INFO - 2023-03-16 07:56:30 --> URI Class Initialized
INFO - 2023-03-16 07:56:30 --> Router Class Initialized
INFO - 2023-03-16 07:56:30 --> Output Class Initialized
INFO - 2023-03-16 07:56:30 --> Security Class Initialized
DEBUG - 2023-03-16 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:56:30 --> Input Class Initialized
INFO - 2023-03-16 07:56:30 --> Language Class Initialized
INFO - 2023-03-16 07:56:30 --> Loader Class Initialized
INFO - 2023-03-16 07:56:30 --> Controller Class Initialized
DEBUG - 2023-03-16 07:56:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:56:30 --> Database Driver Class Initialized
INFO - 2023-03-16 07:56:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:56:30 --> Final output sent to browser
DEBUG - 2023-03-16 07:56:30 --> Total execution time: 0.0237
INFO - 2023-03-16 07:56:30 --> Config Class Initialized
INFO - 2023-03-16 07:56:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:56:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:56:30 --> Utf8 Class Initialized
INFO - 2023-03-16 07:56:30 --> URI Class Initialized
INFO - 2023-03-16 07:56:30 --> Router Class Initialized
INFO - 2023-03-16 07:56:30 --> Output Class Initialized
INFO - 2023-03-16 07:56:30 --> Security Class Initialized
DEBUG - 2023-03-16 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:56:30 --> Input Class Initialized
INFO - 2023-03-16 07:56:30 --> Language Class Initialized
INFO - 2023-03-16 07:56:30 --> Loader Class Initialized
INFO - 2023-03-16 07:56:30 --> Controller Class Initialized
DEBUG - 2023-03-16 07:56:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:56:30 --> Database Driver Class Initialized
INFO - 2023-03-16 07:56:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:56:30 --> Final output sent to browser
DEBUG - 2023-03-16 07:56:30 --> Total execution time: 0.0240
INFO - 2023-03-16 07:56:32 --> Config Class Initialized
INFO - 2023-03-16 07:56:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:56:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:56:32 --> Utf8 Class Initialized
INFO - 2023-03-16 07:56:32 --> URI Class Initialized
INFO - 2023-03-16 07:56:32 --> Router Class Initialized
INFO - 2023-03-16 07:56:32 --> Output Class Initialized
INFO - 2023-03-16 07:56:32 --> Security Class Initialized
DEBUG - 2023-03-16 07:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:56:32 --> Input Class Initialized
INFO - 2023-03-16 07:56:32 --> Language Class Initialized
INFO - 2023-03-16 07:56:32 --> Loader Class Initialized
INFO - 2023-03-16 07:56:32 --> Controller Class Initialized
DEBUG - 2023-03-16 07:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:56:32 --> Database Driver Class Initialized
INFO - 2023-03-16 07:56:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:56:32 --> Final output sent to browser
DEBUG - 2023-03-16 07:56:32 --> Total execution time: 0.2322
INFO - 2023-03-16 07:56:32 --> Config Class Initialized
INFO - 2023-03-16 07:56:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:56:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:56:32 --> Utf8 Class Initialized
INFO - 2023-03-16 07:56:32 --> URI Class Initialized
INFO - 2023-03-16 07:56:32 --> Router Class Initialized
INFO - 2023-03-16 07:56:32 --> Output Class Initialized
INFO - 2023-03-16 07:56:32 --> Security Class Initialized
DEBUG - 2023-03-16 07:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:56:32 --> Input Class Initialized
INFO - 2023-03-16 07:56:32 --> Language Class Initialized
INFO - 2023-03-16 07:56:32 --> Loader Class Initialized
INFO - 2023-03-16 07:56:32 --> Controller Class Initialized
DEBUG - 2023-03-16 07:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:56:32 --> Database Driver Class Initialized
INFO - 2023-03-16 07:56:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:56:32 --> Final output sent to browser
DEBUG - 2023-03-16 07:56:32 --> Total execution time: 0.0980
INFO - 2023-03-16 07:58:23 --> Config Class Initialized
INFO - 2023-03-16 07:58:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:58:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:58:23 --> Utf8 Class Initialized
INFO - 2023-03-16 07:58:23 --> URI Class Initialized
INFO - 2023-03-16 07:58:23 --> Router Class Initialized
INFO - 2023-03-16 07:58:23 --> Output Class Initialized
INFO - 2023-03-16 07:58:23 --> Security Class Initialized
DEBUG - 2023-03-16 07:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:58:23 --> Input Class Initialized
INFO - 2023-03-16 07:58:23 --> Language Class Initialized
INFO - 2023-03-16 07:58:23 --> Loader Class Initialized
INFO - 2023-03-16 07:58:23 --> Controller Class Initialized
DEBUG - 2023-03-16 07:58:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:58:23 --> Database Driver Class Initialized
INFO - 2023-03-16 07:58:23 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:58:23 --> Final output sent to browser
DEBUG - 2023-03-16 07:58:23 --> Total execution time: 0.0208
INFO - 2023-03-16 07:58:23 --> Config Class Initialized
INFO - 2023-03-16 07:58:23 --> Hooks Class Initialized
DEBUG - 2023-03-16 07:58:23 --> UTF-8 Support Enabled
INFO - 2023-03-16 07:58:23 --> Utf8 Class Initialized
INFO - 2023-03-16 07:58:23 --> URI Class Initialized
INFO - 2023-03-16 07:58:23 --> Router Class Initialized
INFO - 2023-03-16 07:58:23 --> Output Class Initialized
INFO - 2023-03-16 07:58:23 --> Security Class Initialized
DEBUG - 2023-03-16 07:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 07:58:23 --> Input Class Initialized
INFO - 2023-03-16 07:58:23 --> Language Class Initialized
INFO - 2023-03-16 07:58:23 --> Loader Class Initialized
INFO - 2023-03-16 07:58:23 --> Controller Class Initialized
DEBUG - 2023-03-16 07:58:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 07:58:24 --> Database Driver Class Initialized
INFO - 2023-03-16 07:58:24 --> Model "Cluster_model" initialized
INFO - 2023-03-16 07:58:24 --> Final output sent to browser
DEBUG - 2023-03-16 07:58:24 --> Total execution time: 0.0547
INFO - 2023-03-16 08:22:15 --> Config Class Initialized
INFO - 2023-03-16 08:22:15 --> Hooks Class Initialized
DEBUG - 2023-03-16 08:22:15 --> UTF-8 Support Enabled
INFO - 2023-03-16 08:22:15 --> Utf8 Class Initialized
INFO - 2023-03-16 08:22:15 --> URI Class Initialized
INFO - 2023-03-16 08:22:15 --> Router Class Initialized
INFO - 2023-03-16 08:22:15 --> Output Class Initialized
INFO - 2023-03-16 08:22:15 --> Security Class Initialized
DEBUG - 2023-03-16 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 08:22:15 --> Input Class Initialized
INFO - 2023-03-16 08:22:15 --> Language Class Initialized
INFO - 2023-03-16 08:22:15 --> Loader Class Initialized
INFO - 2023-03-16 08:22:15 --> Controller Class Initialized
DEBUG - 2023-03-16 08:22:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 08:22:15 --> Database Driver Class Initialized
INFO - 2023-03-16 08:22:15 --> Model "Cluster_model" initialized
INFO - 2023-03-16 08:22:15 --> Final output sent to browser
DEBUG - 2023-03-16 08:22:15 --> Total execution time: 0.0434
INFO - 2023-03-16 08:22:15 --> Config Class Initialized
INFO - 2023-03-16 08:22:15 --> Hooks Class Initialized
DEBUG - 2023-03-16 08:22:15 --> UTF-8 Support Enabled
INFO - 2023-03-16 08:22:15 --> Utf8 Class Initialized
INFO - 2023-03-16 08:22:15 --> URI Class Initialized
INFO - 2023-03-16 08:22:15 --> Router Class Initialized
INFO - 2023-03-16 08:22:15 --> Output Class Initialized
INFO - 2023-03-16 08:22:15 --> Security Class Initialized
DEBUG - 2023-03-16 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 08:22:15 --> Input Class Initialized
INFO - 2023-03-16 08:22:15 --> Language Class Initialized
INFO - 2023-03-16 08:22:15 --> Loader Class Initialized
INFO - 2023-03-16 08:22:15 --> Controller Class Initialized
DEBUG - 2023-03-16 08:22:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 08:22:15 --> Database Driver Class Initialized
INFO - 2023-03-16 08:22:15 --> Model "Cluster_model" initialized
INFO - 2023-03-16 08:22:15 --> Final output sent to browser
DEBUG - 2023-03-16 08:22:15 --> Total execution time: 0.0492
INFO - 2023-03-16 08:22:18 --> Config Class Initialized
INFO - 2023-03-16 08:22:18 --> Hooks Class Initialized
INFO - 2023-03-16 08:22:18 --> Config Class Initialized
DEBUG - 2023-03-16 08:22:18 --> UTF-8 Support Enabled
INFO - 2023-03-16 08:22:18 --> Hooks Class Initialized
INFO - 2023-03-16 08:22:18 --> Utf8 Class Initialized
INFO - 2023-03-16 08:22:18 --> URI Class Initialized
DEBUG - 2023-03-16 08:22:18 --> UTF-8 Support Enabled
INFO - 2023-03-16 08:22:18 --> Utf8 Class Initialized
INFO - 2023-03-16 08:22:18 --> Router Class Initialized
INFO - 2023-03-16 08:22:18 --> URI Class Initialized
INFO - 2023-03-16 08:22:18 --> Output Class Initialized
INFO - 2023-03-16 08:22:18 --> Router Class Initialized
INFO - 2023-03-16 08:22:18 --> Security Class Initialized
INFO - 2023-03-16 08:22:18 --> Output Class Initialized
DEBUG - 2023-03-16 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 08:22:18 --> Security Class Initialized
INFO - 2023-03-16 08:22:18 --> Input Class Initialized
DEBUG - 2023-03-16 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 08:22:18 --> Language Class Initialized
INFO - 2023-03-16 08:22:18 --> Input Class Initialized
INFO - 2023-03-16 08:22:18 --> Language Class Initialized
INFO - 2023-03-16 08:22:18 --> Loader Class Initialized
INFO - 2023-03-16 08:22:18 --> Controller Class Initialized
DEBUG - 2023-03-16 08:22:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 08:22:18 --> Loader Class Initialized
INFO - 2023-03-16 08:22:18 --> Final output sent to browser
DEBUG - 2023-03-16 08:22:18 --> Total execution time: 0.0043
INFO - 2023-03-16 08:22:18 --> Controller Class Initialized
DEBUG - 2023-03-16 08:22:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 08:22:18 --> Database Driver Class Initialized
INFO - 2023-03-16 08:22:18 --> Config Class Initialized
INFO - 2023-03-16 08:22:18 --> Hooks Class Initialized
DEBUG - 2023-03-16 08:22:18 --> UTF-8 Support Enabled
INFO - 2023-03-16 08:22:18 --> Utf8 Class Initialized
INFO - 2023-03-16 08:22:18 --> URI Class Initialized
INFO - 2023-03-16 08:22:18 --> Router Class Initialized
INFO - 2023-03-16 08:22:18 --> Output Class Initialized
INFO - 2023-03-16 08:22:18 --> Security Class Initialized
DEBUG - 2023-03-16 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 08:22:18 --> Input Class Initialized
INFO - 2023-03-16 08:22:18 --> Language Class Initialized
INFO - 2023-03-16 08:22:18 --> Loader Class Initialized
INFO - 2023-03-16 08:22:18 --> Controller Class Initialized
DEBUG - 2023-03-16 08:22:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 08:22:18 --> Database Driver Class Initialized
INFO - 2023-03-16 08:22:18 --> Model "Login_model" initialized
INFO - 2023-03-16 08:22:18 --> Model "Cluster_model" initialized
INFO - 2023-03-16 08:22:18 --> Database Driver Class Initialized
INFO - 2023-03-16 08:22:18 --> Final output sent to browser
DEBUG - 2023-03-16 08:22:18 --> Total execution time: 0.0600
INFO - 2023-03-16 08:22:18 --> Config Class Initialized
INFO - 2023-03-16 08:22:18 --> Hooks Class Initialized
DEBUG - 2023-03-16 08:22:18 --> UTF-8 Support Enabled
INFO - 2023-03-16 08:22:18 --> Utf8 Class Initialized
INFO - 2023-03-16 08:22:18 --> URI Class Initialized
INFO - 2023-03-16 08:22:18 --> Router Class Initialized
INFO - 2023-03-16 08:22:18 --> Output Class Initialized
INFO - 2023-03-16 08:22:18 --> Security Class Initialized
DEBUG - 2023-03-16 08:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 08:22:18 --> Input Class Initialized
INFO - 2023-03-16 08:22:18 --> Language Class Initialized
INFO - 2023-03-16 08:22:18 --> Loader Class Initialized
INFO - 2023-03-16 08:22:18 --> Controller Class Initialized
DEBUG - 2023-03-16 08:22:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 08:22:18 --> Database Driver Class Initialized
INFO - 2023-03-16 08:22:18 --> Model "Cluster_model" initialized
INFO - 2023-03-16 08:22:18 --> Final output sent to browser
DEBUG - 2023-03-16 08:22:18 --> Total execution time: 0.0609
INFO - 2023-03-16 08:22:18 --> Model "Cluster_model" initialized
INFO - 2023-03-16 08:22:18 --> Final output sent to browser
DEBUG - 2023-03-16 08:22:18 --> Total execution time: 0.0530
INFO - 2023-03-16 08:41:09 --> Config Class Initialized
INFO - 2023-03-16 08:41:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 08:41:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 08:41:09 --> Utf8 Class Initialized
INFO - 2023-03-16 08:41:09 --> URI Class Initialized
INFO - 2023-03-16 08:41:09 --> Router Class Initialized
INFO - 2023-03-16 08:41:09 --> Output Class Initialized
INFO - 2023-03-16 08:41:09 --> Security Class Initialized
DEBUG - 2023-03-16 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 08:41:09 --> Input Class Initialized
INFO - 2023-03-16 08:41:09 --> Language Class Initialized
INFO - 2023-03-16 08:41:09 --> Loader Class Initialized
INFO - 2023-03-16 08:41:09 --> Controller Class Initialized
DEBUG - 2023-03-16 08:41:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 08:41:09 --> Database Driver Class Initialized
INFO - 2023-03-16 08:41:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 08:41:09 --> Final output sent to browser
DEBUG - 2023-03-16 08:41:09 --> Total execution time: 0.0451
INFO - 2023-03-16 08:41:09 --> Config Class Initialized
INFO - 2023-03-16 08:41:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 08:41:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 08:41:09 --> Utf8 Class Initialized
INFO - 2023-03-16 08:41:09 --> URI Class Initialized
INFO - 2023-03-16 08:41:09 --> Router Class Initialized
INFO - 2023-03-16 08:41:09 --> Output Class Initialized
INFO - 2023-03-16 08:41:09 --> Security Class Initialized
DEBUG - 2023-03-16 08:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 08:41:09 --> Input Class Initialized
INFO - 2023-03-16 08:41:09 --> Language Class Initialized
INFO - 2023-03-16 08:41:09 --> Loader Class Initialized
INFO - 2023-03-16 08:41:09 --> Controller Class Initialized
DEBUG - 2023-03-16 08:41:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 08:41:09 --> Database Driver Class Initialized
INFO - 2023-03-16 08:41:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 08:41:09 --> Final output sent to browser
DEBUG - 2023-03-16 08:41:09 --> Total execution time: 0.2390
INFO - 2023-03-16 09:14:31 --> Config Class Initialized
INFO - 2023-03-16 09:14:31 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:14:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:14:31 --> Utf8 Class Initialized
INFO - 2023-03-16 09:14:31 --> URI Class Initialized
INFO - 2023-03-16 09:14:31 --> Router Class Initialized
INFO - 2023-03-16 09:14:31 --> Output Class Initialized
INFO - 2023-03-16 09:14:31 --> Security Class Initialized
DEBUG - 2023-03-16 09:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:14:31 --> Input Class Initialized
INFO - 2023-03-16 09:14:31 --> Language Class Initialized
INFO - 2023-03-16 09:14:31 --> Loader Class Initialized
INFO - 2023-03-16 09:14:31 --> Controller Class Initialized
DEBUG - 2023-03-16 09:14:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:14:31 --> Database Driver Class Initialized
INFO - 2023-03-16 09:14:31 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:14:31 --> Final output sent to browser
DEBUG - 2023-03-16 09:14:31 --> Total execution time: 0.0265
INFO - 2023-03-16 09:14:31 --> Config Class Initialized
INFO - 2023-03-16 09:14:31 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:14:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:14:31 --> Utf8 Class Initialized
INFO - 2023-03-16 09:14:31 --> URI Class Initialized
INFO - 2023-03-16 09:14:31 --> Router Class Initialized
INFO - 2023-03-16 09:14:31 --> Output Class Initialized
INFO - 2023-03-16 09:14:31 --> Security Class Initialized
DEBUG - 2023-03-16 09:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:14:31 --> Input Class Initialized
INFO - 2023-03-16 09:14:31 --> Language Class Initialized
INFO - 2023-03-16 09:14:31 --> Loader Class Initialized
INFO - 2023-03-16 09:14:31 --> Controller Class Initialized
DEBUG - 2023-03-16 09:14:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:14:31 --> Database Driver Class Initialized
INFO - 2023-03-16 09:14:31 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:14:31 --> Final output sent to browser
DEBUG - 2023-03-16 09:14:31 --> Total execution time: 0.0639
INFO - 2023-03-16 09:14:34 --> Config Class Initialized
INFO - 2023-03-16 09:14:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:14:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:14:34 --> Utf8 Class Initialized
INFO - 2023-03-16 09:14:34 --> URI Class Initialized
INFO - 2023-03-16 09:14:34 --> Router Class Initialized
INFO - 2023-03-16 09:14:34 --> Output Class Initialized
INFO - 2023-03-16 09:14:34 --> Security Class Initialized
DEBUG - 2023-03-16 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:14:34 --> Input Class Initialized
INFO - 2023-03-16 09:14:34 --> Language Class Initialized
INFO - 2023-03-16 09:14:34 --> Loader Class Initialized
INFO - 2023-03-16 09:14:34 --> Controller Class Initialized
DEBUG - 2023-03-16 09:14:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:14:34 --> Database Driver Class Initialized
INFO - 2023-03-16 09:14:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:14:34 --> Final output sent to browser
INFO - 2023-03-16 09:14:34 --> Config Class Initialized
DEBUG - 2023-03-16 09:14:34 --> Total execution time: 0.1976
INFO - 2023-03-16 09:14:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:14:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:14:34 --> Utf8 Class Initialized
INFO - 2023-03-16 09:14:34 --> URI Class Initialized
INFO - 2023-03-16 09:14:34 --> Router Class Initialized
INFO - 2023-03-16 09:14:34 --> Output Class Initialized
INFO - 2023-03-16 09:14:34 --> Security Class Initialized
DEBUG - 2023-03-16 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:14:34 --> Input Class Initialized
INFO - 2023-03-16 09:14:34 --> Language Class Initialized
INFO - 2023-03-16 09:14:34 --> Loader Class Initialized
INFO - 2023-03-16 09:14:34 --> Controller Class Initialized
DEBUG - 2023-03-16 09:14:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:14:34 --> Database Driver Class Initialized
INFO - 2023-03-16 09:14:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:14:34 --> Final output sent to browser
DEBUG - 2023-03-16 09:14:34 --> Total execution time: 0.3107
INFO - 2023-03-16 09:14:37 --> Config Class Initialized
INFO - 2023-03-16 09:14:37 --> Config Class Initialized
INFO - 2023-03-16 09:14:37 --> Hooks Class Initialized
INFO - 2023-03-16 09:14:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2023-03-16 09:14:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:14:37 --> Utf8 Class Initialized
INFO - 2023-03-16 09:14:37 --> Utf8 Class Initialized
INFO - 2023-03-16 09:14:37 --> URI Class Initialized
INFO - 2023-03-16 09:14:37 --> URI Class Initialized
INFO - 2023-03-16 09:14:37 --> Router Class Initialized
INFO - 2023-03-16 09:14:37 --> Router Class Initialized
INFO - 2023-03-16 09:14:37 --> Output Class Initialized
INFO - 2023-03-16 09:14:37 --> Output Class Initialized
INFO - 2023-03-16 09:14:37 --> Security Class Initialized
INFO - 2023-03-16 09:14:37 --> Security Class Initialized
DEBUG - 2023-03-16 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 09:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:14:37 --> Input Class Initialized
INFO - 2023-03-16 09:14:37 --> Input Class Initialized
INFO - 2023-03-16 09:14:37 --> Language Class Initialized
INFO - 2023-03-16 09:14:37 --> Language Class Initialized
INFO - 2023-03-16 09:14:37 --> Loader Class Initialized
INFO - 2023-03-16 09:14:37 --> Loader Class Initialized
INFO - 2023-03-16 09:14:37 --> Controller Class Initialized
INFO - 2023-03-16 09:14:37 --> Controller Class Initialized
DEBUG - 2023-03-16 09:14:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 09:14:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:14:37 --> Database Driver Class Initialized
INFO - 2023-03-16 09:14:37 --> Final output sent to browser
DEBUG - 2023-03-16 09:14:37 --> Total execution time: 0.0052
INFO - 2023-03-16 09:14:37 --> Config Class Initialized
INFO - 2023-03-16 09:14:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:14:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:14:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:14:37 --> Utf8 Class Initialized
INFO - 2023-03-16 09:14:37 --> URI Class Initialized
INFO - 2023-03-16 09:14:37 --> Router Class Initialized
INFO - 2023-03-16 09:14:37 --> Output Class Initialized
INFO - 2023-03-16 09:14:37 --> Security Class Initialized
DEBUG - 2023-03-16 09:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:14:37 --> Input Class Initialized
INFO - 2023-03-16 09:14:37 --> Language Class Initialized
INFO - 2023-03-16 09:14:37 --> Loader Class Initialized
INFO - 2023-03-16 09:14:37 --> Controller Class Initialized
DEBUG - 2023-03-16 09:14:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:14:37 --> Database Driver Class Initialized
INFO - 2023-03-16 09:14:37 --> Final output sent to browser
DEBUG - 2023-03-16 09:14:37 --> Total execution time: 0.0512
INFO - 2023-03-16 09:14:37 --> Config Class Initialized
INFO - 2023-03-16 09:14:37 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:14:37 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:14:37 --> Utf8 Class Initialized
INFO - 2023-03-16 09:14:37 --> URI Class Initialized
INFO - 2023-03-16 09:14:37 --> Router Class Initialized
INFO - 2023-03-16 09:14:37 --> Output Class Initialized
INFO - 2023-03-16 09:14:37 --> Security Class Initialized
DEBUG - 2023-03-16 09:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:14:37 --> Input Class Initialized
INFO - 2023-03-16 09:14:37 --> Language Class Initialized
INFO - 2023-03-16 09:14:37 --> Loader Class Initialized
INFO - 2023-03-16 09:14:37 --> Controller Class Initialized
DEBUG - 2023-03-16 09:14:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:14:37 --> Database Driver Class Initialized
INFO - 2023-03-16 09:14:37 --> Model "Login_model" initialized
INFO - 2023-03-16 09:14:37 --> Database Driver Class Initialized
INFO - 2023-03-16 09:14:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:14:37 --> Final output sent to browser
DEBUG - 2023-03-16 09:14:37 --> Total execution time: 0.0130
INFO - 2023-03-16 09:14:37 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:14:37 --> Final output sent to browser
DEBUG - 2023-03-16 09:14:37 --> Total execution time: 0.0618
INFO - 2023-03-16 09:19:29 --> Config Class Initialized
INFO - 2023-03-16 09:19:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:19:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:19:29 --> Utf8 Class Initialized
INFO - 2023-03-16 09:19:29 --> URI Class Initialized
INFO - 2023-03-16 09:19:29 --> Router Class Initialized
INFO - 2023-03-16 09:19:29 --> Output Class Initialized
INFO - 2023-03-16 09:19:29 --> Security Class Initialized
DEBUG - 2023-03-16 09:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:19:29 --> Input Class Initialized
INFO - 2023-03-16 09:19:29 --> Language Class Initialized
INFO - 2023-03-16 09:19:29 --> Loader Class Initialized
INFO - 2023-03-16 09:19:29 --> Controller Class Initialized
DEBUG - 2023-03-16 09:19:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:19:29 --> Database Driver Class Initialized
INFO - 2023-03-16 09:19:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:19:29 --> Final output sent to browser
DEBUG - 2023-03-16 09:19:29 --> Total execution time: 0.5813
INFO - 2023-03-16 09:19:29 --> Config Class Initialized
INFO - 2023-03-16 09:19:29 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:19:29 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:19:29 --> Utf8 Class Initialized
INFO - 2023-03-16 09:19:29 --> URI Class Initialized
INFO - 2023-03-16 09:19:29 --> Router Class Initialized
INFO - 2023-03-16 09:19:29 --> Output Class Initialized
INFO - 2023-03-16 09:19:29 --> Security Class Initialized
DEBUG - 2023-03-16 09:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:19:29 --> Input Class Initialized
INFO - 2023-03-16 09:19:29 --> Language Class Initialized
INFO - 2023-03-16 09:19:29 --> Loader Class Initialized
INFO - 2023-03-16 09:19:29 --> Controller Class Initialized
DEBUG - 2023-03-16 09:19:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:19:29 --> Database Driver Class Initialized
INFO - 2023-03-16 09:19:29 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:19:29 --> Final output sent to browser
DEBUG - 2023-03-16 09:19:29 --> Total execution time: 0.1380
INFO - 2023-03-16 09:24:09 --> Config Class Initialized
INFO - 2023-03-16 09:24:09 --> Config Class Initialized
INFO - 2023-03-16 09:24:09 --> Hooks Class Initialized
INFO - 2023-03-16 09:24:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:24:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:24:09 --> Utf8 Class Initialized
DEBUG - 2023-03-16 09:24:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:24:09 --> Utf8 Class Initialized
INFO - 2023-03-16 09:24:09 --> URI Class Initialized
INFO - 2023-03-16 09:24:09 --> URI Class Initialized
INFO - 2023-03-16 09:24:09 --> Router Class Initialized
INFO - 2023-03-16 09:24:09 --> Router Class Initialized
INFO - 2023-03-16 09:24:09 --> Output Class Initialized
INFO - 2023-03-16 09:24:09 --> Output Class Initialized
INFO - 2023-03-16 09:24:09 --> Security Class Initialized
INFO - 2023-03-16 09:24:09 --> Security Class Initialized
DEBUG - 2023-03-16 09:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 09:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:24:09 --> Input Class Initialized
INFO - 2023-03-16 09:24:09 --> Input Class Initialized
INFO - 2023-03-16 09:24:09 --> Language Class Initialized
INFO - 2023-03-16 09:24:09 --> Language Class Initialized
INFO - 2023-03-16 09:24:09 --> Loader Class Initialized
INFO - 2023-03-16 09:24:09 --> Loader Class Initialized
INFO - 2023-03-16 09:24:09 --> Controller Class Initialized
INFO - 2023-03-16 09:24:09 --> Controller Class Initialized
DEBUG - 2023-03-16 09:24:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 09:24:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:24:09 --> Final output sent to browser
INFO - 2023-03-16 09:24:09 --> Database Driver Class Initialized
DEBUG - 2023-03-16 09:24:09 --> Total execution time: 0.0071
INFO - 2023-03-16 09:24:09 --> Config Class Initialized
INFO - 2023-03-16 09:24:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:24:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:24:09 --> Utf8 Class Initialized
INFO - 2023-03-16 09:24:09 --> URI Class Initialized
INFO - 2023-03-16 09:24:09 --> Router Class Initialized
INFO - 2023-03-16 09:24:09 --> Output Class Initialized
INFO - 2023-03-16 09:24:09 --> Security Class Initialized
DEBUG - 2023-03-16 09:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:24:09 --> Input Class Initialized
INFO - 2023-03-16 09:24:09 --> Language Class Initialized
INFO - 2023-03-16 09:24:09 --> Loader Class Initialized
INFO - 2023-03-16 09:24:09 --> Controller Class Initialized
DEBUG - 2023-03-16 09:24:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:24:09 --> Database Driver Class Initialized
INFO - 2023-03-16 09:24:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:24:09 --> Final output sent to browser
DEBUG - 2023-03-16 09:24:09 --> Total execution time: 0.0208
INFO - 2023-03-16 09:24:09 --> Model "Login_model" initialized
INFO - 2023-03-16 09:24:09 --> Database Driver Class Initialized
INFO - 2023-03-16 09:24:09 --> Config Class Initialized
INFO - 2023-03-16 09:24:09 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:24:09 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:24:09 --> Utf8 Class Initialized
INFO - 2023-03-16 09:24:09 --> URI Class Initialized
INFO - 2023-03-16 09:24:09 --> Router Class Initialized
INFO - 2023-03-16 09:24:09 --> Output Class Initialized
INFO - 2023-03-16 09:24:09 --> Security Class Initialized
DEBUG - 2023-03-16 09:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:24:09 --> Input Class Initialized
INFO - 2023-03-16 09:24:09 --> Language Class Initialized
INFO - 2023-03-16 09:24:09 --> Loader Class Initialized
INFO - 2023-03-16 09:24:09 --> Controller Class Initialized
DEBUG - 2023-03-16 09:24:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:24:09 --> Database Driver Class Initialized
INFO - 2023-03-16 09:24:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:24:09 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:24:09 --> Final output sent to browser
DEBUG - 2023-03-16 09:24:09 --> Total execution time: 0.0239
INFO - 2023-03-16 09:24:09 --> Final output sent to browser
DEBUG - 2023-03-16 09:24:09 --> Total execution time: 0.0130
INFO - 2023-03-16 09:53:55 --> Config Class Initialized
INFO - 2023-03-16 09:53:55 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:53:55 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:53:55 --> Utf8 Class Initialized
INFO - 2023-03-16 09:53:55 --> URI Class Initialized
INFO - 2023-03-16 09:53:55 --> Router Class Initialized
INFO - 2023-03-16 09:53:55 --> Output Class Initialized
INFO - 2023-03-16 09:53:55 --> Security Class Initialized
DEBUG - 2023-03-16 09:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:53:55 --> Input Class Initialized
INFO - 2023-03-16 09:53:55 --> Language Class Initialized
INFO - 2023-03-16 09:53:55 --> Loader Class Initialized
INFO - 2023-03-16 09:53:55 --> Controller Class Initialized
DEBUG - 2023-03-16 09:53:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:53:55 --> Database Driver Class Initialized
INFO - 2023-03-16 09:53:55 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:53:55 --> Final output sent to browser
DEBUG - 2023-03-16 09:53:55 --> Total execution time: 0.0218
INFO - 2023-03-16 09:53:55 --> Config Class Initialized
INFO - 2023-03-16 09:53:55 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:53:55 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:53:55 --> Utf8 Class Initialized
INFO - 2023-03-16 09:53:55 --> URI Class Initialized
INFO - 2023-03-16 09:53:55 --> Router Class Initialized
INFO - 2023-03-16 09:53:55 --> Output Class Initialized
INFO - 2023-03-16 09:53:55 --> Security Class Initialized
DEBUG - 2023-03-16 09:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:53:55 --> Input Class Initialized
INFO - 2023-03-16 09:53:55 --> Language Class Initialized
INFO - 2023-03-16 09:53:55 --> Loader Class Initialized
INFO - 2023-03-16 09:53:55 --> Controller Class Initialized
DEBUG - 2023-03-16 09:53:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:53:55 --> Database Driver Class Initialized
INFO - 2023-03-16 09:53:55 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:53:55 --> Final output sent to browser
DEBUG - 2023-03-16 09:53:55 --> Total execution time: 0.0594
INFO - 2023-03-16 09:53:57 --> Config Class Initialized
INFO - 2023-03-16 09:53:57 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:53:57 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:53:57 --> Utf8 Class Initialized
INFO - 2023-03-16 09:53:57 --> URI Class Initialized
INFO - 2023-03-16 09:53:57 --> Router Class Initialized
INFO - 2023-03-16 09:53:57 --> Output Class Initialized
INFO - 2023-03-16 09:53:57 --> Security Class Initialized
DEBUG - 2023-03-16 09:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:53:57 --> Input Class Initialized
INFO - 2023-03-16 09:53:57 --> Language Class Initialized
INFO - 2023-03-16 09:53:57 --> Loader Class Initialized
INFO - 2023-03-16 09:53:57 --> Controller Class Initialized
DEBUG - 2023-03-16 09:53:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:53:57 --> Database Driver Class Initialized
INFO - 2023-03-16 09:53:57 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:53:57 --> Final output sent to browser
DEBUG - 2023-03-16 09:53:57 --> Total execution time: 0.0603
INFO - 2023-03-16 09:53:57 --> Config Class Initialized
INFO - 2023-03-16 09:53:57 --> Hooks Class Initialized
DEBUG - 2023-03-16 09:53:57 --> UTF-8 Support Enabled
INFO - 2023-03-16 09:53:57 --> Utf8 Class Initialized
INFO - 2023-03-16 09:53:57 --> URI Class Initialized
INFO - 2023-03-16 09:53:57 --> Router Class Initialized
INFO - 2023-03-16 09:53:57 --> Output Class Initialized
INFO - 2023-03-16 09:53:57 --> Security Class Initialized
DEBUG - 2023-03-16 09:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 09:53:57 --> Input Class Initialized
INFO - 2023-03-16 09:53:57 --> Language Class Initialized
INFO - 2023-03-16 09:53:57 --> Loader Class Initialized
INFO - 2023-03-16 09:53:57 --> Controller Class Initialized
DEBUG - 2023-03-16 09:53:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 09:53:57 --> Database Driver Class Initialized
INFO - 2023-03-16 09:53:57 --> Model "Cluster_model" initialized
INFO - 2023-03-16 09:53:57 --> Final output sent to browser
DEBUG - 2023-03-16 09:53:57 --> Total execution time: 0.0999
INFO - 2023-03-16 10:23:20 --> Config Class Initialized
INFO - 2023-03-16 10:23:20 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:23:20 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:23:20 --> Utf8 Class Initialized
INFO - 2023-03-16 10:23:20 --> URI Class Initialized
INFO - 2023-03-16 10:23:20 --> Router Class Initialized
INFO - 2023-03-16 10:23:20 --> Output Class Initialized
INFO - 2023-03-16 10:23:20 --> Security Class Initialized
DEBUG - 2023-03-16 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:23:20 --> Input Class Initialized
INFO - 2023-03-16 10:23:20 --> Language Class Initialized
INFO - 2023-03-16 10:23:20 --> Loader Class Initialized
INFO - 2023-03-16 10:23:20 --> Controller Class Initialized
DEBUG - 2023-03-16 10:23:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:23:20 --> Database Driver Class Initialized
INFO - 2023-03-16 10:23:20 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:23:20 --> Final output sent to browser
DEBUG - 2023-03-16 10:23:20 --> Total execution time: 0.1014
INFO - 2023-03-16 10:23:20 --> Config Class Initialized
INFO - 2023-03-16 10:23:20 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:23:20 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:23:20 --> Utf8 Class Initialized
INFO - 2023-03-16 10:23:20 --> URI Class Initialized
INFO - 2023-03-16 10:23:20 --> Router Class Initialized
INFO - 2023-03-16 10:23:20 --> Output Class Initialized
INFO - 2023-03-16 10:23:20 --> Security Class Initialized
DEBUG - 2023-03-16 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:23:20 --> Input Class Initialized
INFO - 2023-03-16 10:23:20 --> Language Class Initialized
INFO - 2023-03-16 10:23:20 --> Loader Class Initialized
INFO - 2023-03-16 10:23:20 --> Controller Class Initialized
DEBUG - 2023-03-16 10:23:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:23:20 --> Database Driver Class Initialized
INFO - 2023-03-16 10:23:20 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:23:20 --> Final output sent to browser
DEBUG - 2023-03-16 10:23:20 --> Total execution time: 0.0175
INFO - 2023-03-16 10:34:30 --> Config Class Initialized
INFO - 2023-03-16 10:34:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:34:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:34:30 --> Utf8 Class Initialized
INFO - 2023-03-16 10:34:30 --> URI Class Initialized
INFO - 2023-03-16 10:34:30 --> Router Class Initialized
INFO - 2023-03-16 10:34:30 --> Output Class Initialized
INFO - 2023-03-16 10:34:30 --> Security Class Initialized
DEBUG - 2023-03-16 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:34:30 --> Input Class Initialized
INFO - 2023-03-16 10:34:30 --> Language Class Initialized
INFO - 2023-03-16 10:34:30 --> Loader Class Initialized
INFO - 2023-03-16 10:34:30 --> Controller Class Initialized
DEBUG - 2023-03-16 10:34:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:34:30 --> Database Driver Class Initialized
INFO - 2023-03-16 10:34:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:34:30 --> Final output sent to browser
DEBUG - 2023-03-16 10:34:30 --> Total execution time: 0.0543
INFO - 2023-03-16 10:34:30 --> Config Class Initialized
INFO - 2023-03-16 10:34:30 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:34:30 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:34:30 --> Utf8 Class Initialized
INFO - 2023-03-16 10:34:30 --> URI Class Initialized
INFO - 2023-03-16 10:34:30 --> Router Class Initialized
INFO - 2023-03-16 10:34:30 --> Output Class Initialized
INFO - 2023-03-16 10:34:30 --> Security Class Initialized
DEBUG - 2023-03-16 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:34:30 --> Input Class Initialized
INFO - 2023-03-16 10:34:30 --> Language Class Initialized
INFO - 2023-03-16 10:34:30 --> Loader Class Initialized
INFO - 2023-03-16 10:34:30 --> Controller Class Initialized
DEBUG - 2023-03-16 10:34:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:34:30 --> Database Driver Class Initialized
INFO - 2023-03-16 10:34:30 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:34:30 --> Final output sent to browser
DEBUG - 2023-03-16 10:34:30 --> Total execution time: 0.0416
INFO - 2023-03-16 10:34:31 --> Config Class Initialized
INFO - 2023-03-16 10:34:31 --> Config Class Initialized
INFO - 2023-03-16 10:34:31 --> Hooks Class Initialized
INFO - 2023-03-16 10:34:31 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:34:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:34:31 --> Utf8 Class Initialized
DEBUG - 2023-03-16 10:34:31 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:34:31 --> URI Class Initialized
INFO - 2023-03-16 10:34:31 --> Utf8 Class Initialized
INFO - 2023-03-16 10:34:31 --> URI Class Initialized
INFO - 2023-03-16 10:34:31 --> Router Class Initialized
INFO - 2023-03-16 10:34:31 --> Router Class Initialized
INFO - 2023-03-16 10:34:31 --> Output Class Initialized
INFO - 2023-03-16 10:34:31 --> Output Class Initialized
INFO - 2023-03-16 10:34:31 --> Security Class Initialized
INFO - 2023-03-16 10:34:31 --> Security Class Initialized
DEBUG - 2023-03-16 10:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-16 10:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:34:31 --> Input Class Initialized
INFO - 2023-03-16 10:34:31 --> Input Class Initialized
INFO - 2023-03-16 10:34:31 --> Language Class Initialized
INFO - 2023-03-16 10:34:31 --> Language Class Initialized
INFO - 2023-03-16 10:34:31 --> Loader Class Initialized
INFO - 2023-03-16 10:34:31 --> Loader Class Initialized
INFO - 2023-03-16 10:34:31 --> Controller Class Initialized
INFO - 2023-03-16 10:34:31 --> Controller Class Initialized
DEBUG - 2023-03-16 10:34:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 10:34:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:34:31 --> Final output sent to browser
DEBUG - 2023-03-16 10:34:31 --> Total execution time: 0.0044
INFO - 2023-03-16 10:34:31 --> Database Driver Class Initialized
INFO - 2023-03-16 10:34:31 --> Config Class Initialized
INFO - 2023-03-16 10:34:31 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:34:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:34:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:34:32 --> Utf8 Class Initialized
INFO - 2023-03-16 10:34:32 --> URI Class Initialized
INFO - 2023-03-16 10:34:32 --> Router Class Initialized
INFO - 2023-03-16 10:34:32 --> Output Class Initialized
INFO - 2023-03-16 10:34:32 --> Security Class Initialized
DEBUG - 2023-03-16 10:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:34:32 --> Input Class Initialized
INFO - 2023-03-16 10:34:32 --> Language Class Initialized
INFO - 2023-03-16 10:34:32 --> Loader Class Initialized
INFO - 2023-03-16 10:34:32 --> Controller Class Initialized
DEBUG - 2023-03-16 10:34:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:34:32 --> Database Driver Class Initialized
INFO - 2023-03-16 10:34:32 --> Final output sent to browser
DEBUG - 2023-03-16 10:34:32 --> Total execution time: 0.0506
INFO - 2023-03-16 10:34:32 --> Config Class Initialized
INFO - 2023-03-16 10:34:32 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:34:32 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:34:32 --> Utf8 Class Initialized
INFO - 2023-03-16 10:34:32 --> URI Class Initialized
INFO - 2023-03-16 10:34:32 --> Router Class Initialized
INFO - 2023-03-16 10:34:32 --> Output Class Initialized
INFO - 2023-03-16 10:34:32 --> Security Class Initialized
DEBUG - 2023-03-16 10:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:34:32 --> Input Class Initialized
INFO - 2023-03-16 10:34:32 --> Language Class Initialized
INFO - 2023-03-16 10:34:32 --> Loader Class Initialized
INFO - 2023-03-16 10:34:32 --> Controller Class Initialized
DEBUG - 2023-03-16 10:34:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:34:32 --> Database Driver Class Initialized
INFO - 2023-03-16 10:34:32 --> Model "Login_model" initialized
INFO - 2023-03-16 10:34:32 --> Database Driver Class Initialized
INFO - 2023-03-16 10:34:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:34:32 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:34:32 --> Final output sent to browser
DEBUG - 2023-03-16 10:34:32 --> Total execution time: 0.0147
INFO - 2023-03-16 10:34:32 --> Final output sent to browser
DEBUG - 2023-03-16 10:34:32 --> Total execution time: 0.0624
INFO - 2023-03-16 10:34:34 --> Config Class Initialized
INFO - 2023-03-16 10:34:34 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:34:34 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:34:34 --> Utf8 Class Initialized
INFO - 2023-03-16 10:34:34 --> URI Class Initialized
INFO - 2023-03-16 10:34:34 --> Router Class Initialized
INFO - 2023-03-16 10:34:34 --> Output Class Initialized
INFO - 2023-03-16 10:34:34 --> Security Class Initialized
DEBUG - 2023-03-16 10:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:34:34 --> Input Class Initialized
INFO - 2023-03-16 10:34:34 --> Language Class Initialized
INFO - 2023-03-16 10:34:34 --> Loader Class Initialized
INFO - 2023-03-16 10:34:34 --> Controller Class Initialized
DEBUG - 2023-03-16 10:34:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:34:34 --> Database Driver Class Initialized
INFO - 2023-03-16 10:34:34 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:34:34 --> Final output sent to browser
DEBUG - 2023-03-16 10:34:34 --> Total execution time: 0.0907
INFO - 2023-03-16 10:42:20 --> Config Class Initialized
INFO - 2023-03-16 10:42:20 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:42:20 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:42:20 --> Utf8 Class Initialized
INFO - 2023-03-16 10:42:20 --> URI Class Initialized
INFO - 2023-03-16 10:42:20 --> Router Class Initialized
INFO - 2023-03-16 10:42:20 --> Output Class Initialized
INFO - 2023-03-16 10:42:20 --> Security Class Initialized
DEBUG - 2023-03-16 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:42:20 --> Input Class Initialized
INFO - 2023-03-16 10:42:20 --> Language Class Initialized
INFO - 2023-03-16 10:42:20 --> Loader Class Initialized
INFO - 2023-03-16 10:42:20 --> Controller Class Initialized
DEBUG - 2023-03-16 10:42:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:42:20 --> Database Driver Class Initialized
INFO - 2023-03-16 10:42:20 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:42:20 --> Final output sent to browser
DEBUG - 2023-03-16 10:42:20 --> Total execution time: 0.0190
INFO - 2023-03-16 10:42:20 --> Config Class Initialized
INFO - 2023-03-16 10:42:20 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:42:20 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:42:20 --> Utf8 Class Initialized
INFO - 2023-03-16 10:42:20 --> URI Class Initialized
INFO - 2023-03-16 10:42:20 --> Router Class Initialized
INFO - 2023-03-16 10:42:20 --> Output Class Initialized
INFO - 2023-03-16 10:42:20 --> Security Class Initialized
DEBUG - 2023-03-16 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:42:20 --> Input Class Initialized
INFO - 2023-03-16 10:42:20 --> Language Class Initialized
INFO - 2023-03-16 10:42:20 --> Loader Class Initialized
INFO - 2023-03-16 10:42:20 --> Controller Class Initialized
DEBUG - 2023-03-16 10:42:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:42:20 --> Database Driver Class Initialized
INFO - 2023-03-16 10:42:20 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:42:20 --> Final output sent to browser
DEBUG - 2023-03-16 10:42:20 --> Total execution time: 0.0512
INFO - 2023-03-16 10:44:43 --> Config Class Initialized
INFO - 2023-03-16 10:44:43 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:44:43 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:44:43 --> Utf8 Class Initialized
INFO - 2023-03-16 10:44:43 --> URI Class Initialized
INFO - 2023-03-16 10:44:43 --> Router Class Initialized
INFO - 2023-03-16 10:44:43 --> Output Class Initialized
INFO - 2023-03-16 10:44:43 --> Security Class Initialized
DEBUG - 2023-03-16 10:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:44:43 --> Input Class Initialized
INFO - 2023-03-16 10:44:43 --> Language Class Initialized
INFO - 2023-03-16 10:44:43 --> Loader Class Initialized
INFO - 2023-03-16 10:44:43 --> Controller Class Initialized
DEBUG - 2023-03-16 10:44:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:44:43 --> Database Driver Class Initialized
INFO - 2023-03-16 10:44:43 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:44:43 --> Final output sent to browser
DEBUG - 2023-03-16 10:44:43 --> Total execution time: 0.0926
INFO - 2023-03-16 10:44:43 --> Config Class Initialized
INFO - 2023-03-16 10:44:43 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:44:43 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:44:43 --> Utf8 Class Initialized
INFO - 2023-03-16 10:44:43 --> URI Class Initialized
INFO - 2023-03-16 10:44:43 --> Router Class Initialized
INFO - 2023-03-16 10:44:43 --> Output Class Initialized
INFO - 2023-03-16 10:44:43 --> Security Class Initialized
DEBUG - 2023-03-16 10:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:44:43 --> Input Class Initialized
INFO - 2023-03-16 10:44:43 --> Language Class Initialized
INFO - 2023-03-16 10:44:43 --> Loader Class Initialized
INFO - 2023-03-16 10:44:43 --> Controller Class Initialized
DEBUG - 2023-03-16 10:44:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:44:43 --> Database Driver Class Initialized
INFO - 2023-03-16 10:44:43 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:44:43 --> Final output sent to browser
DEBUG - 2023-03-16 10:44:43 --> Total execution time: 0.0447
INFO - 2023-03-16 10:44:45 --> Config Class Initialized
INFO - 2023-03-16 10:44:45 --> Config Class Initialized
INFO - 2023-03-16 10:44:45 --> Hooks Class Initialized
INFO - 2023-03-16 10:44:45 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:44:45 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:44:45 --> Utf8 Class Initialized
DEBUG - 2023-03-16 10:44:45 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:44:45 --> URI Class Initialized
INFO - 2023-03-16 10:44:45 --> Utf8 Class Initialized
INFO - 2023-03-16 10:44:45 --> Router Class Initialized
INFO - 2023-03-16 10:44:45 --> URI Class Initialized
INFO - 2023-03-16 10:44:45 --> Output Class Initialized
INFO - 2023-03-16 10:44:45 --> Router Class Initialized
INFO - 2023-03-16 10:44:45 --> Security Class Initialized
INFO - 2023-03-16 10:44:45 --> Output Class Initialized
DEBUG - 2023-03-16 10:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:44:45 --> Security Class Initialized
INFO - 2023-03-16 10:44:45 --> Input Class Initialized
DEBUG - 2023-03-16 10:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:44:45 --> Language Class Initialized
INFO - 2023-03-16 10:44:45 --> Input Class Initialized
INFO - 2023-03-16 10:44:45 --> Language Class Initialized
INFO - 2023-03-16 10:44:45 --> Loader Class Initialized
INFO - 2023-03-16 10:44:45 --> Loader Class Initialized
INFO - 2023-03-16 10:44:45 --> Controller Class Initialized
INFO - 2023-03-16 10:44:45 --> Controller Class Initialized
DEBUG - 2023-03-16 10:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-16 10:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:44:45 --> Final output sent to browser
DEBUG - 2023-03-16 10:44:45 --> Total execution time: 0.0054
INFO - 2023-03-16 10:44:45 --> Database Driver Class Initialized
INFO - 2023-03-16 10:44:45 --> Config Class Initialized
INFO - 2023-03-16 10:44:45 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:44:45 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:44:45 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:44:45 --> Utf8 Class Initialized
INFO - 2023-03-16 10:44:45 --> URI Class Initialized
INFO - 2023-03-16 10:44:45 --> Router Class Initialized
INFO - 2023-03-16 10:44:45 --> Output Class Initialized
INFO - 2023-03-16 10:44:45 --> Security Class Initialized
DEBUG - 2023-03-16 10:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:44:45 --> Input Class Initialized
INFO - 2023-03-16 10:44:45 --> Language Class Initialized
INFO - 2023-03-16 10:44:45 --> Loader Class Initialized
INFO - 2023-03-16 10:44:45 --> Controller Class Initialized
DEBUG - 2023-03-16 10:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:44:45 --> Database Driver Class Initialized
INFO - 2023-03-16 10:44:45 --> Final output sent to browser
DEBUG - 2023-03-16 10:44:45 --> Total execution time: 0.0523
INFO - 2023-03-16 10:44:45 --> Config Class Initialized
INFO - 2023-03-16 10:44:45 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:44:45 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:44:45 --> Utf8 Class Initialized
INFO - 2023-03-16 10:44:45 --> URI Class Initialized
INFO - 2023-03-16 10:44:45 --> Router Class Initialized
INFO - 2023-03-16 10:44:45 --> Output Class Initialized
INFO - 2023-03-16 10:44:45 --> Security Class Initialized
DEBUG - 2023-03-16 10:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:44:45 --> Input Class Initialized
INFO - 2023-03-16 10:44:45 --> Language Class Initialized
INFO - 2023-03-16 10:44:45 --> Loader Class Initialized
INFO - 2023-03-16 10:44:45 --> Controller Class Initialized
DEBUG - 2023-03-16 10:44:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:44:45 --> Database Driver Class Initialized
INFO - 2023-03-16 10:44:45 --> Model "Login_model" initialized
INFO - 2023-03-16 10:44:45 --> Database Driver Class Initialized
INFO - 2023-03-16 10:44:45 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:44:45 --> Final output sent to browser
DEBUG - 2023-03-16 10:44:45 --> Total execution time: 0.0151
INFO - 2023-03-16 10:44:45 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:44:45 --> Final output sent to browser
DEBUG - 2023-03-16 10:44:45 --> Total execution time: 0.1044
INFO - 2023-03-16 10:49:48 --> Config Class Initialized
INFO - 2023-03-16 10:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:49:48 --> Utf8 Class Initialized
INFO - 2023-03-16 10:49:48 --> URI Class Initialized
INFO - 2023-03-16 10:49:48 --> Router Class Initialized
INFO - 2023-03-16 10:49:48 --> Output Class Initialized
INFO - 2023-03-16 10:49:48 --> Security Class Initialized
DEBUG - 2023-03-16 10:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:49:48 --> Input Class Initialized
INFO - 2023-03-16 10:49:48 --> Language Class Initialized
INFO - 2023-03-16 10:49:48 --> Loader Class Initialized
INFO - 2023-03-16 10:49:48 --> Controller Class Initialized
DEBUG - 2023-03-16 10:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:49:48 --> Database Driver Class Initialized
INFO - 2023-03-16 10:49:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:49:48 --> Final output sent to browser
DEBUG - 2023-03-16 10:49:48 --> Total execution time: 0.0426
INFO - 2023-03-16 10:49:48 --> Config Class Initialized
INFO - 2023-03-16 10:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-16 10:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-16 10:49:48 --> Utf8 Class Initialized
INFO - 2023-03-16 10:49:48 --> URI Class Initialized
INFO - 2023-03-16 10:49:48 --> Router Class Initialized
INFO - 2023-03-16 10:49:48 --> Output Class Initialized
INFO - 2023-03-16 10:49:48 --> Security Class Initialized
DEBUG - 2023-03-16 10:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-16 10:49:48 --> Input Class Initialized
INFO - 2023-03-16 10:49:48 --> Language Class Initialized
INFO - 2023-03-16 10:49:48 --> Loader Class Initialized
INFO - 2023-03-16 10:49:48 --> Controller Class Initialized
DEBUG - 2023-03-16 10:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-16 10:49:48 --> Database Driver Class Initialized
INFO - 2023-03-16 10:49:48 --> Model "Cluster_model" initialized
INFO - 2023-03-16 10:49:48 --> Final output sent to browser
DEBUG - 2023-03-16 10:49:48 --> Total execution time: 0.0393
