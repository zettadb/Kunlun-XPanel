<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-17 03:01:37 --> Config Class Initialized
INFO - 2023-02-17 03:01:37 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:37 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:37 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:37 --> URI Class Initialized
INFO - 2023-02-17 03:01:37 --> Router Class Initialized
INFO - 2023-02-17 03:01:37 --> Output Class Initialized
INFO - 2023-02-17 03:01:37 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:37 --> Input Class Initialized
INFO - 2023-02-17 03:01:37 --> Language Class Initialized
INFO - 2023-02-17 03:01:37 --> Loader Class Initialized
INFO - 2023-02-17 03:01:37 --> Controller Class Initialized
INFO - 2023-02-17 03:01:37 --> Helper loaded: form_helper
INFO - 2023-02-17 03:01:37 --> Helper loaded: url_helper
DEBUG - 2023-02-17 03:01:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:37 --> Model "Change_model" initialized
INFO - 2023-02-17 03:01:37 --> Model "Grafana_model" initialized
INFO - 2023-02-17 03:01:37 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:37 --> Total execution time: 0.1194
INFO - 2023-02-17 03:01:37 --> Config Class Initialized
INFO - 2023-02-17 03:01:37 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:37 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:37 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:37 --> URI Class Initialized
INFO - 2023-02-17 03:01:37 --> Router Class Initialized
INFO - 2023-02-17 03:01:37 --> Output Class Initialized
INFO - 2023-02-17 03:01:37 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:37 --> Input Class Initialized
INFO - 2023-02-17 03:01:37 --> Language Class Initialized
INFO - 2023-02-17 03:01:37 --> Loader Class Initialized
INFO - 2023-02-17 03:01:37 --> Controller Class Initialized
INFO - 2023-02-17 03:01:37 --> Helper loaded: form_helper
INFO - 2023-02-17 03:01:37 --> Helper loaded: url_helper
DEBUG - 2023-02-17 03:01:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:38 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:38 --> Total execution time: 0.0452
INFO - 2023-02-17 03:01:38 --> Config Class Initialized
INFO - 2023-02-17 03:01:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:38 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:38 --> URI Class Initialized
INFO - 2023-02-17 03:01:38 --> Router Class Initialized
INFO - 2023-02-17 03:01:38 --> Output Class Initialized
INFO - 2023-02-17 03:01:38 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:38 --> Input Class Initialized
INFO - 2023-02-17 03:01:38 --> Language Class Initialized
INFO - 2023-02-17 03:01:38 --> Loader Class Initialized
INFO - 2023-02-17 03:01:38 --> Controller Class Initialized
INFO - 2023-02-17 03:01:38 --> Helper loaded: form_helper
INFO - 2023-02-17 03:01:38 --> Helper loaded: url_helper
DEBUG - 2023-02-17 03:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:38 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:38 --> Model "Login_model" initialized
INFO - 2023-02-17 03:01:38 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:38 --> Total execution time: 0.0270
INFO - 2023-02-17 03:01:38 --> Config Class Initialized
INFO - 2023-02-17 03:01:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:38 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:38 --> URI Class Initialized
INFO - 2023-02-17 03:01:38 --> Router Class Initialized
INFO - 2023-02-17 03:01:38 --> Output Class Initialized
INFO - 2023-02-17 03:01:38 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:38 --> Input Class Initialized
INFO - 2023-02-17 03:01:38 --> Language Class Initialized
INFO - 2023-02-17 03:01:38 --> Loader Class Initialized
INFO - 2023-02-17 03:01:38 --> Controller Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:38 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:01:38 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:38 --> Total execution time: 0.0356
INFO - 2023-02-17 03:01:38 --> Config Class Initialized
INFO - 2023-02-17 03:01:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:38 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:38 --> URI Class Initialized
INFO - 2023-02-17 03:01:38 --> Router Class Initialized
INFO - 2023-02-17 03:01:38 --> Output Class Initialized
INFO - 2023-02-17 03:01:38 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:38 --> Input Class Initialized
INFO - 2023-02-17 03:01:38 --> Language Class Initialized
INFO - 2023-02-17 03:01:38 --> Loader Class Initialized
INFO - 2023-02-17 03:01:38 --> Controller Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:38 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:01:38 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:38 --> Total execution time: 0.0126
INFO - 2023-02-17 03:01:38 --> Config Class Initialized
INFO - 2023-02-17 03:01:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:38 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:38 --> URI Class Initialized
INFO - 2023-02-17 03:01:38 --> Router Class Initialized
INFO - 2023-02-17 03:01:38 --> Output Class Initialized
INFO - 2023-02-17 03:01:38 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:38 --> Input Class Initialized
INFO - 2023-02-17 03:01:38 --> Language Class Initialized
INFO - 2023-02-17 03:01:38 --> Loader Class Initialized
INFO - 2023-02-17 03:01:38 --> Controller Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:38 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:01:38 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:38 --> Model "Login_model" initialized
INFO - 2023-02-17 03:01:38 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:38 --> Total execution time: 0.0559
INFO - 2023-02-17 03:01:38 --> Config Class Initialized
INFO - 2023-02-17 03:01:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:38 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:38 --> URI Class Initialized
INFO - 2023-02-17 03:01:38 --> Router Class Initialized
INFO - 2023-02-17 03:01:38 --> Output Class Initialized
INFO - 2023-02-17 03:01:38 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:38 --> Input Class Initialized
INFO - 2023-02-17 03:01:38 --> Language Class Initialized
INFO - 2023-02-17 03:01:38 --> Loader Class Initialized
INFO - 2023-02-17 03:01:38 --> Controller Class Initialized
DEBUG - 2023-02-17 03:01:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:38 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:01:38 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:38 --> Model "Login_model" initialized
INFO - 2023-02-17 03:01:38 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:38 --> Total execution time: 0.0827
INFO - 2023-02-17 03:01:45 --> Config Class Initialized
INFO - 2023-02-17 03:01:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:45 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:45 --> URI Class Initialized
INFO - 2023-02-17 03:01:45 --> Router Class Initialized
INFO - 2023-02-17 03:01:45 --> Output Class Initialized
INFO - 2023-02-17 03:01:45 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:45 --> Input Class Initialized
INFO - 2023-02-17 03:01:45 --> Language Class Initialized
INFO - 2023-02-17 03:01:45 --> Loader Class Initialized
INFO - 2023-02-17 03:01:45 --> Controller Class Initialized
DEBUG - 2023-02-17 03:01:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:45 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:45 --> Total execution time: 0.0048
INFO - 2023-02-17 03:01:45 --> Config Class Initialized
INFO - 2023-02-17 03:01:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:45 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:45 --> URI Class Initialized
INFO - 2023-02-17 03:01:45 --> Router Class Initialized
INFO - 2023-02-17 03:01:45 --> Output Class Initialized
INFO - 2023-02-17 03:01:45 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:45 --> Input Class Initialized
INFO - 2023-02-17 03:01:45 --> Language Class Initialized
INFO - 2023-02-17 03:01:45 --> Loader Class Initialized
INFO - 2023-02-17 03:01:45 --> Controller Class Initialized
DEBUG - 2023-02-17 03:01:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:45 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:01:45 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:45 --> Total execution time: 0.0136
INFO - 2023-02-17 03:01:50 --> Config Class Initialized
INFO - 2023-02-17 03:01:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:50 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:50 --> URI Class Initialized
INFO - 2023-02-17 03:01:50 --> Router Class Initialized
INFO - 2023-02-17 03:01:50 --> Output Class Initialized
INFO - 2023-02-17 03:01:50 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:50 --> Input Class Initialized
INFO - 2023-02-17 03:01:50 --> Language Class Initialized
INFO - 2023-02-17 03:01:50 --> Loader Class Initialized
INFO - 2023-02-17 03:01:50 --> Controller Class Initialized
DEBUG - 2023-02-17 03:01:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:50 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:50 --> Total execution time: 0.0047
INFO - 2023-02-17 03:01:50 --> Config Class Initialized
INFO - 2023-02-17 03:01:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:01:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:01:50 --> Utf8 Class Initialized
INFO - 2023-02-17 03:01:50 --> URI Class Initialized
INFO - 2023-02-17 03:01:50 --> Router Class Initialized
INFO - 2023-02-17 03:01:50 --> Output Class Initialized
INFO - 2023-02-17 03:01:50 --> Security Class Initialized
DEBUG - 2023-02-17 03:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:01:50 --> Input Class Initialized
INFO - 2023-02-17 03:01:50 --> Language Class Initialized
INFO - 2023-02-17 03:01:50 --> Loader Class Initialized
INFO - 2023-02-17 03:01:50 --> Controller Class Initialized
DEBUG - 2023-02-17 03:01:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:01:50 --> Database Driver Class Initialized
INFO - 2023-02-17 03:01:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:01:50 --> Final output sent to browser
DEBUG - 2023-02-17 03:01:50 --> Total execution time: 0.0117
INFO - 2023-02-17 03:02:13 --> Config Class Initialized
INFO - 2023-02-17 03:02:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:13 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:13 --> URI Class Initialized
INFO - 2023-02-17 03:02:13 --> Router Class Initialized
INFO - 2023-02-17 03:02:13 --> Output Class Initialized
INFO - 2023-02-17 03:02:13 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:13 --> Input Class Initialized
INFO - 2023-02-17 03:02:13 --> Language Class Initialized
INFO - 2023-02-17 03:02:13 --> Loader Class Initialized
INFO - 2023-02-17 03:02:13 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:13 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:13 --> Total execution time: 0.0042
INFO - 2023-02-17 03:02:13 --> Config Class Initialized
INFO - 2023-02-17 03:02:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:13 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:13 --> URI Class Initialized
INFO - 2023-02-17 03:02:13 --> Router Class Initialized
INFO - 2023-02-17 03:02:13 --> Output Class Initialized
INFO - 2023-02-17 03:02:13 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:13 --> Input Class Initialized
INFO - 2023-02-17 03:02:13 --> Language Class Initialized
INFO - 2023-02-17 03:02:13 --> Loader Class Initialized
INFO - 2023-02-17 03:02:13 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:13 --> Database Driver Class Initialized
INFO - 2023-02-17 03:02:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:02:18 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:18 --> Total execution time: 5.0549
INFO - 2023-02-17 03:02:22 --> Config Class Initialized
INFO - 2023-02-17 03:02:22 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:22 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:22 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:22 --> URI Class Initialized
INFO - 2023-02-17 03:02:22 --> Router Class Initialized
INFO - 2023-02-17 03:02:22 --> Output Class Initialized
INFO - 2023-02-17 03:02:22 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:22 --> Input Class Initialized
INFO - 2023-02-17 03:02:22 --> Language Class Initialized
INFO - 2023-02-17 03:02:22 --> Loader Class Initialized
INFO - 2023-02-17 03:02:22 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:22 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:22 --> Total execution time: 0.0052
INFO - 2023-02-17 03:02:22 --> Config Class Initialized
INFO - 2023-02-17 03:02:22 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:22 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:22 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:22 --> URI Class Initialized
INFO - 2023-02-17 03:02:22 --> Router Class Initialized
INFO - 2023-02-17 03:02:22 --> Output Class Initialized
INFO - 2023-02-17 03:02:22 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:22 --> Input Class Initialized
INFO - 2023-02-17 03:02:22 --> Language Class Initialized
INFO - 2023-02-17 03:02:22 --> Loader Class Initialized
INFO - 2023-02-17 03:02:22 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:22 --> Database Driver Class Initialized
INFO - 2023-02-17 03:02:22 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:02:22 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:22 --> Total execution time: 0.0123
INFO - 2023-02-17 03:02:24 --> Config Class Initialized
INFO - 2023-02-17 03:02:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:24 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:24 --> URI Class Initialized
INFO - 2023-02-17 03:02:24 --> Router Class Initialized
INFO - 2023-02-17 03:02:24 --> Output Class Initialized
INFO - 2023-02-17 03:02:24 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:24 --> Input Class Initialized
INFO - 2023-02-17 03:02:24 --> Language Class Initialized
INFO - 2023-02-17 03:02:24 --> Loader Class Initialized
INFO - 2023-02-17 03:02:24 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:24 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:24 --> Total execution time: 0.0040
INFO - 2023-02-17 03:02:24 --> Config Class Initialized
INFO - 2023-02-17 03:02:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:24 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:24 --> URI Class Initialized
INFO - 2023-02-17 03:02:24 --> Router Class Initialized
INFO - 2023-02-17 03:02:24 --> Output Class Initialized
INFO - 2023-02-17 03:02:24 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:24 --> Input Class Initialized
INFO - 2023-02-17 03:02:24 --> Language Class Initialized
INFO - 2023-02-17 03:02:24 --> Loader Class Initialized
INFO - 2023-02-17 03:02:24 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:24 --> Database Driver Class Initialized
INFO - 2023-02-17 03:02:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:02:24 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:24 --> Total execution time: 0.0119
INFO - 2023-02-17 03:02:29 --> Config Class Initialized
INFO - 2023-02-17 03:02:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:29 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:29 --> URI Class Initialized
INFO - 2023-02-17 03:02:29 --> Router Class Initialized
INFO - 2023-02-17 03:02:29 --> Output Class Initialized
INFO - 2023-02-17 03:02:29 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:29 --> Input Class Initialized
INFO - 2023-02-17 03:02:29 --> Language Class Initialized
INFO - 2023-02-17 03:02:29 --> Loader Class Initialized
INFO - 2023-02-17 03:02:29 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:29 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:29 --> Total execution time: 0.0038
INFO - 2023-02-17 03:02:29 --> Config Class Initialized
INFO - 2023-02-17 03:02:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:29 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:29 --> URI Class Initialized
INFO - 2023-02-17 03:02:29 --> Router Class Initialized
INFO - 2023-02-17 03:02:29 --> Output Class Initialized
INFO - 2023-02-17 03:02:29 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:29 --> Input Class Initialized
INFO - 2023-02-17 03:02:29 --> Language Class Initialized
INFO - 2023-02-17 03:02:29 --> Loader Class Initialized
INFO - 2023-02-17 03:02:29 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:29 --> Database Driver Class Initialized
INFO - 2023-02-17 03:02:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:02:34 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:34 --> Total execution time: 5.0966
INFO - 2023-02-17 03:02:44 --> Config Class Initialized
INFO - 2023-02-17 03:02:44 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:44 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:44 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:44 --> URI Class Initialized
INFO - 2023-02-17 03:02:44 --> Router Class Initialized
INFO - 2023-02-17 03:02:44 --> Output Class Initialized
INFO - 2023-02-17 03:02:44 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:44 --> Input Class Initialized
INFO - 2023-02-17 03:02:44 --> Language Class Initialized
INFO - 2023-02-17 03:02:44 --> Loader Class Initialized
INFO - 2023-02-17 03:02:44 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:44 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:44 --> Total execution time: 0.0102
INFO - 2023-02-17 03:02:44 --> Config Class Initialized
INFO - 2023-02-17 03:02:44 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:44 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:44 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:44 --> URI Class Initialized
INFO - 2023-02-17 03:02:44 --> Router Class Initialized
INFO - 2023-02-17 03:02:44 --> Output Class Initialized
INFO - 2023-02-17 03:02:44 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:44 --> Input Class Initialized
INFO - 2023-02-17 03:02:44 --> Language Class Initialized
INFO - 2023-02-17 03:02:44 --> Loader Class Initialized
INFO - 2023-02-17 03:02:44 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:44 --> Database Driver Class Initialized
INFO - 2023-02-17 03:02:44 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:02:49 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:49 --> Total execution time: 5.0501
INFO - 2023-02-17 03:02:51 --> Config Class Initialized
INFO - 2023-02-17 03:02:51 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:51 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:51 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:51 --> URI Class Initialized
INFO - 2023-02-17 03:02:51 --> Router Class Initialized
INFO - 2023-02-17 03:02:51 --> Output Class Initialized
INFO - 2023-02-17 03:02:51 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:51 --> Input Class Initialized
INFO - 2023-02-17 03:02:51 --> Language Class Initialized
INFO - 2023-02-17 03:02:51 --> Loader Class Initialized
INFO - 2023-02-17 03:02:51 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:51 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:51 --> Total execution time: 0.0038
INFO - 2023-02-17 03:02:51 --> Config Class Initialized
INFO - 2023-02-17 03:02:51 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:02:51 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:02:51 --> Utf8 Class Initialized
INFO - 2023-02-17 03:02:51 --> URI Class Initialized
INFO - 2023-02-17 03:02:51 --> Router Class Initialized
INFO - 2023-02-17 03:02:51 --> Output Class Initialized
INFO - 2023-02-17 03:02:51 --> Security Class Initialized
DEBUG - 2023-02-17 03:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:02:51 --> Input Class Initialized
INFO - 2023-02-17 03:02:51 --> Language Class Initialized
INFO - 2023-02-17 03:02:51 --> Loader Class Initialized
INFO - 2023-02-17 03:02:51 --> Controller Class Initialized
DEBUG - 2023-02-17 03:02:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:02:51 --> Database Driver Class Initialized
INFO - 2023-02-17 03:02:51 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:02:56 --> Final output sent to browser
DEBUG - 2023-02-17 03:02:56 --> Total execution time: 5.0152
INFO - 2023-02-17 03:03:09 --> Config Class Initialized
INFO - 2023-02-17 03:03:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:03:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:03:09 --> Utf8 Class Initialized
INFO - 2023-02-17 03:03:09 --> URI Class Initialized
INFO - 2023-02-17 03:03:09 --> Router Class Initialized
INFO - 2023-02-17 03:03:09 --> Output Class Initialized
INFO - 2023-02-17 03:03:09 --> Security Class Initialized
DEBUG - 2023-02-17 03:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:03:09 --> Input Class Initialized
INFO - 2023-02-17 03:03:09 --> Language Class Initialized
INFO - 2023-02-17 03:03:09 --> Loader Class Initialized
INFO - 2023-02-17 03:03:09 --> Controller Class Initialized
DEBUG - 2023-02-17 03:03:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:03:09 --> Final output sent to browser
DEBUG - 2023-02-17 03:03:09 --> Total execution time: 0.0037
INFO - 2023-02-17 03:03:09 --> Config Class Initialized
INFO - 2023-02-17 03:03:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:03:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:03:09 --> Utf8 Class Initialized
INFO - 2023-02-17 03:03:09 --> URI Class Initialized
INFO - 2023-02-17 03:03:09 --> Router Class Initialized
INFO - 2023-02-17 03:03:09 --> Output Class Initialized
INFO - 2023-02-17 03:03:09 --> Security Class Initialized
DEBUG - 2023-02-17 03:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:03:09 --> Input Class Initialized
INFO - 2023-02-17 03:03:09 --> Language Class Initialized
INFO - 2023-02-17 03:03:09 --> Loader Class Initialized
INFO - 2023-02-17 03:03:09 --> Controller Class Initialized
DEBUG - 2023-02-17 03:03:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:03:09 --> Database Driver Class Initialized
INFO - 2023-02-17 03:03:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:03:14 --> Final output sent to browser
DEBUG - 2023-02-17 03:03:14 --> Total execution time: 5.0831
INFO - 2023-02-17 03:06:53 --> Config Class Initialized
INFO - 2023-02-17 03:06:53 --> Config Class Initialized
INFO - 2023-02-17 03:06:53 --> Hooks Class Initialized
INFO - 2023-02-17 03:06:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:53 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 03:06:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:53 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:53 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:53 --> URI Class Initialized
INFO - 2023-02-17 03:06:53 --> URI Class Initialized
INFO - 2023-02-17 03:06:53 --> Router Class Initialized
INFO - 2023-02-17 03:06:53 --> Router Class Initialized
INFO - 2023-02-17 03:06:53 --> Output Class Initialized
INFO - 2023-02-17 03:06:53 --> Output Class Initialized
INFO - 2023-02-17 03:06:53 --> Security Class Initialized
INFO - 2023-02-17 03:06:53 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 03:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:53 --> Input Class Initialized
INFO - 2023-02-17 03:06:53 --> Input Class Initialized
INFO - 2023-02-17 03:06:53 --> Language Class Initialized
INFO - 2023-02-17 03:06:53 --> Language Class Initialized
INFO - 2023-02-17 03:06:53 --> Loader Class Initialized
INFO - 2023-02-17 03:06:53 --> Loader Class Initialized
INFO - 2023-02-17 03:06:53 --> Controller Class Initialized
INFO - 2023-02-17 03:06:53 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 03:06:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:53 --> Database Driver Class Initialized
INFO - 2023-02-17 03:06:53 --> Database Driver Class Initialized
INFO - 2023-02-17 03:06:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:06:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:06:53 --> Final output sent to browser
DEBUG - 2023-02-17 03:06:53 --> Total execution time: 0.0559
INFO - 2023-02-17 03:06:53 --> Config Class Initialized
INFO - 2023-02-17 03:06:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:53 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:53 --> URI Class Initialized
INFO - 2023-02-17 03:06:53 --> Router Class Initialized
INFO - 2023-02-17 03:06:53 --> Output Class Initialized
INFO - 2023-02-17 03:06:53 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:53 --> Input Class Initialized
INFO - 2023-02-17 03:06:53 --> Language Class Initialized
INFO - 2023-02-17 03:06:53 --> Loader Class Initialized
INFO - 2023-02-17 03:06:53 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:53 --> Database Driver Class Initialized
INFO - 2023-02-17 03:06:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:06:53 --> Final output sent to browser
DEBUG - 2023-02-17 03:06:53 --> Total execution time: 0.0492
INFO - 2023-02-17 03:06:53 --> Config Class Initialized
INFO - 2023-02-17 03:06:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:53 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:53 --> URI Class Initialized
INFO - 2023-02-17 03:06:53 --> Router Class Initialized
INFO - 2023-02-17 03:06:53 --> Output Class Initialized
INFO - 2023-02-17 03:06:53 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:53 --> Input Class Initialized
INFO - 2023-02-17 03:06:53 --> Language Class Initialized
INFO - 2023-02-17 03:06:53 --> Loader Class Initialized
INFO - 2023-02-17 03:06:53 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:53 --> Database Driver Class Initialized
INFO - 2023-02-17 03:06:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:06:54 --> Config Class Initialized
INFO - 2023-02-17 03:06:54 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:54 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:54 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:54 --> URI Class Initialized
INFO - 2023-02-17 03:06:54 --> Router Class Initialized
INFO - 2023-02-17 03:06:54 --> Output Class Initialized
INFO - 2023-02-17 03:06:54 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:54 --> Input Class Initialized
INFO - 2023-02-17 03:06:54 --> Language Class Initialized
INFO - 2023-02-17 03:06:54 --> Loader Class Initialized
INFO - 2023-02-17 03:06:54 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:54 --> Final output sent to browser
DEBUG - 2023-02-17 03:06:54 --> Total execution time: 0.0433
INFO - 2023-02-17 03:06:54 --> Config Class Initialized
INFO - 2023-02-17 03:06:54 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:54 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:54 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:54 --> URI Class Initialized
INFO - 2023-02-17 03:06:54 --> Router Class Initialized
INFO - 2023-02-17 03:06:54 --> Output Class Initialized
INFO - 2023-02-17 03:06:54 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:54 --> Input Class Initialized
INFO - 2023-02-17 03:06:54 --> Language Class Initialized
INFO - 2023-02-17 03:06:54 --> Loader Class Initialized
INFO - 2023-02-17 03:06:54 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:54 --> Database Driver Class Initialized
INFO - 2023-02-17 03:06:54 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:06:54 --> Final output sent to browser
DEBUG - 2023-02-17 03:06:54 --> Total execution time: 0.0109
INFO - 2023-02-17 03:06:55 --> Config Class Initialized
INFO - 2023-02-17 03:06:55 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:55 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:55 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:55 --> URI Class Initialized
INFO - 2023-02-17 03:06:55 --> Router Class Initialized
INFO - 2023-02-17 03:06:55 --> Output Class Initialized
INFO - 2023-02-17 03:06:55 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:55 --> Input Class Initialized
INFO - 2023-02-17 03:06:55 --> Language Class Initialized
INFO - 2023-02-17 03:06:55 --> Loader Class Initialized
INFO - 2023-02-17 03:06:55 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:55 --> Final output sent to browser
DEBUG - 2023-02-17 03:06:55 --> Total execution time: 0.0348
INFO - 2023-02-17 03:06:55 --> Config Class Initialized
INFO - 2023-02-17 03:06:55 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:55 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:55 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:55 --> URI Class Initialized
INFO - 2023-02-17 03:06:55 --> Router Class Initialized
INFO - 2023-02-17 03:06:55 --> Output Class Initialized
INFO - 2023-02-17 03:06:55 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:55 --> Input Class Initialized
INFO - 2023-02-17 03:06:55 --> Language Class Initialized
INFO - 2023-02-17 03:06:55 --> Loader Class Initialized
INFO - 2023-02-17 03:06:55 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:55 --> Database Driver Class Initialized
INFO - 2023-02-17 03:06:55 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:06:55 --> Final output sent to browser
DEBUG - 2023-02-17 03:06:55 --> Total execution time: 0.0115
INFO - 2023-02-17 03:06:58 --> Config Class Initialized
INFO - 2023-02-17 03:06:58 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:58 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:58 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:58 --> URI Class Initialized
INFO - 2023-02-17 03:06:58 --> Router Class Initialized
INFO - 2023-02-17 03:06:58 --> Output Class Initialized
INFO - 2023-02-17 03:06:58 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:58 --> Input Class Initialized
INFO - 2023-02-17 03:06:58 --> Language Class Initialized
INFO - 2023-02-17 03:06:58 --> Loader Class Initialized
INFO - 2023-02-17 03:06:58 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:58 --> Database Driver Class Initialized
INFO - 2023-02-17 03:06:58 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:06:58 --> Final output sent to browser
DEBUG - 2023-02-17 03:06:58 --> Total execution time: 0.0285
INFO - 2023-02-17 03:06:58 --> Config Class Initialized
INFO - 2023-02-17 03:06:58 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:06:58 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:06:58 --> Utf8 Class Initialized
INFO - 2023-02-17 03:06:58 --> URI Class Initialized
INFO - 2023-02-17 03:06:58 --> Router Class Initialized
INFO - 2023-02-17 03:06:58 --> Output Class Initialized
INFO - 2023-02-17 03:06:58 --> Security Class Initialized
DEBUG - 2023-02-17 03:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:06:58 --> Input Class Initialized
INFO - 2023-02-17 03:06:58 --> Language Class Initialized
INFO - 2023-02-17 03:06:58 --> Loader Class Initialized
INFO - 2023-02-17 03:06:58 --> Controller Class Initialized
DEBUG - 2023-02-17 03:06:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:06:58 --> Database Driver Class Initialized
INFO - 2023-02-17 03:06:58 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:06:58 --> Final output sent to browser
DEBUG - 2023-02-17 03:06:58 --> Total execution time: 0.0655
INFO - 2023-02-17 03:07:03 --> Config Class Initialized
INFO - 2023-02-17 03:07:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:03 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:03 --> URI Class Initialized
INFO - 2023-02-17 03:07:03 --> Router Class Initialized
INFO - 2023-02-17 03:07:03 --> Output Class Initialized
INFO - 2023-02-17 03:07:03 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:03 --> Input Class Initialized
INFO - 2023-02-17 03:07:03 --> Language Class Initialized
INFO - 2023-02-17 03:07:03 --> Loader Class Initialized
INFO - 2023-02-17 03:07:03 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:03 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:03 --> Total execution time: 0.0481
INFO - 2023-02-17 03:07:03 --> Config Class Initialized
INFO - 2023-02-17 03:07:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:03 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:03 --> URI Class Initialized
INFO - 2023-02-17 03:07:03 --> Router Class Initialized
INFO - 2023-02-17 03:07:03 --> Output Class Initialized
INFO - 2023-02-17 03:07:03 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:03 --> Input Class Initialized
INFO - 2023-02-17 03:07:03 --> Language Class Initialized
INFO - 2023-02-17 03:07:03 --> Loader Class Initialized
INFO - 2023-02-17 03:07:03 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:03 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:03 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:03 --> Total execution time: 0.0129
INFO - 2023-02-17 03:07:17 --> Config Class Initialized
INFO - 2023-02-17 03:07:17 --> Config Class Initialized
INFO - 2023-02-17 03:07:17 --> Hooks Class Initialized
INFO - 2023-02-17 03:07:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:17 --> Utf8 Class Initialized
DEBUG - 2023-02-17 03:07:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:17 --> URI Class Initialized
INFO - 2023-02-17 03:07:17 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:17 --> URI Class Initialized
INFO - 2023-02-17 03:07:17 --> Router Class Initialized
INFO - 2023-02-17 03:07:17 --> Router Class Initialized
INFO - 2023-02-17 03:07:17 --> Output Class Initialized
INFO - 2023-02-17 03:07:17 --> Output Class Initialized
INFO - 2023-02-17 03:07:17 --> Security Class Initialized
INFO - 2023-02-17 03:07:17 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 03:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:17 --> Input Class Initialized
INFO - 2023-02-17 03:07:17 --> Input Class Initialized
INFO - 2023-02-17 03:07:17 --> Language Class Initialized
INFO - 2023-02-17 03:07:17 --> Language Class Initialized
INFO - 2023-02-17 03:07:17 --> Loader Class Initialized
INFO - 2023-02-17 03:07:17 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:17 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:17 --> Loader Class Initialized
INFO - 2023-02-17 03:07:17 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:17 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:17 --> Total execution time: 0.0100
INFO - 2023-02-17 03:07:17 --> Config Class Initialized
INFO - 2023-02-17 03:07:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:17 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:17 --> URI Class Initialized
INFO - 2023-02-17 03:07:17 --> Router Class Initialized
INFO - 2023-02-17 03:07:17 --> Output Class Initialized
INFO - 2023-02-17 03:07:17 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:17 --> Input Class Initialized
INFO - 2023-02-17 03:07:17 --> Language Class Initialized
INFO - 2023-02-17 03:07:17 --> Loader Class Initialized
INFO - 2023-02-17 03:07:17 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:17 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:17 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:17 --> Total execution time: 0.0575
INFO - 2023-02-17 03:07:17 --> Config Class Initialized
INFO - 2023-02-17 03:07:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:17 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:17 --> URI Class Initialized
INFO - 2023-02-17 03:07:17 --> Router Class Initialized
INFO - 2023-02-17 03:07:17 --> Output Class Initialized
INFO - 2023-02-17 03:07:17 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:17 --> Input Class Initialized
INFO - 2023-02-17 03:07:17 --> Language Class Initialized
INFO - 2023-02-17 03:07:17 --> Loader Class Initialized
INFO - 2023-02-17 03:07:17 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:17 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:17 --> Model "Login_model" initialized
INFO - 2023-02-17 03:07:17 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:17 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:17 --> Total execution time: 0.0641
INFO - 2023-02-17 03:07:17 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:17 --> Total execution time: 0.0174
INFO - 2023-02-17 03:07:17 --> Config Class Initialized
INFO - 2023-02-17 03:07:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:17 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:17 --> URI Class Initialized
INFO - 2023-02-17 03:07:17 --> Router Class Initialized
INFO - 2023-02-17 03:07:17 --> Output Class Initialized
INFO - 2023-02-17 03:07:17 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:17 --> Input Class Initialized
INFO - 2023-02-17 03:07:17 --> Language Class Initialized
INFO - 2023-02-17 03:07:17 --> Loader Class Initialized
INFO - 2023-02-17 03:07:17 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:17 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:17 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:17 --> Model "Login_model" initialized
INFO - 2023-02-17 03:07:17 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:17 --> Total execution time: 0.0808
INFO - 2023-02-17 03:07:17 --> Config Class Initialized
INFO - 2023-02-17 03:07:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:17 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:17 --> URI Class Initialized
INFO - 2023-02-17 03:07:17 --> Router Class Initialized
INFO - 2023-02-17 03:07:17 --> Output Class Initialized
INFO - 2023-02-17 03:07:17 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:17 --> Input Class Initialized
INFO - 2023-02-17 03:07:17 --> Language Class Initialized
INFO - 2023-02-17 03:07:17 --> Loader Class Initialized
INFO - 2023-02-17 03:07:17 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:17 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:18 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:18 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:18 --> Model "Login_model" initialized
INFO - 2023-02-17 03:07:18 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:18 --> Total execution time: 0.0381
INFO - 2023-02-17 03:07:24 --> Config Class Initialized
INFO - 2023-02-17 03:07:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:24 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:24 --> URI Class Initialized
INFO - 2023-02-17 03:07:24 --> Router Class Initialized
INFO - 2023-02-17 03:07:24 --> Output Class Initialized
INFO - 2023-02-17 03:07:24 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:24 --> Input Class Initialized
INFO - 2023-02-17 03:07:24 --> Language Class Initialized
INFO - 2023-02-17 03:07:24 --> Loader Class Initialized
INFO - 2023-02-17 03:07:24 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:24 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:24 --> Total execution time: 0.0043
INFO - 2023-02-17 03:07:24 --> Config Class Initialized
INFO - 2023-02-17 03:07:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:24 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:24 --> URI Class Initialized
INFO - 2023-02-17 03:07:24 --> Router Class Initialized
INFO - 2023-02-17 03:07:24 --> Output Class Initialized
INFO - 2023-02-17 03:07:24 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:24 --> Input Class Initialized
INFO - 2023-02-17 03:07:24 --> Language Class Initialized
INFO - 2023-02-17 03:07:24 --> Loader Class Initialized
INFO - 2023-02-17 03:07:24 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:24 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:24 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:24 --> Total execution time: 0.0111
INFO - 2023-02-17 03:07:24 --> Config Class Initialized
INFO - 2023-02-17 03:07:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:24 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:24 --> URI Class Initialized
INFO - 2023-02-17 03:07:24 --> Router Class Initialized
INFO - 2023-02-17 03:07:24 --> Output Class Initialized
INFO - 2023-02-17 03:07:24 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:24 --> Input Class Initialized
INFO - 2023-02-17 03:07:24 --> Language Class Initialized
INFO - 2023-02-17 03:07:24 --> Loader Class Initialized
INFO - 2023-02-17 03:07:24 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:24 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:24 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:24 --> Total execution time: 0.0135
INFO - 2023-02-17 03:07:27 --> Config Class Initialized
INFO - 2023-02-17 03:07:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:27 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:27 --> URI Class Initialized
INFO - 2023-02-17 03:07:27 --> Router Class Initialized
INFO - 2023-02-17 03:07:27 --> Output Class Initialized
INFO - 2023-02-17 03:07:27 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:27 --> Input Class Initialized
INFO - 2023-02-17 03:07:27 --> Language Class Initialized
INFO - 2023-02-17 03:07:27 --> Loader Class Initialized
INFO - 2023-02-17 03:07:27 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:27 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:27 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:27 --> Total execution time: 0.0139
INFO - 2023-02-17 03:07:28 --> Config Class Initialized
INFO - 2023-02-17 03:07:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:28 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:28 --> URI Class Initialized
INFO - 2023-02-17 03:07:28 --> Router Class Initialized
INFO - 2023-02-17 03:07:28 --> Output Class Initialized
INFO - 2023-02-17 03:07:28 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:28 --> Input Class Initialized
INFO - 2023-02-17 03:07:28 --> Language Class Initialized
INFO - 2023-02-17 03:07:28 --> Loader Class Initialized
INFO - 2023-02-17 03:07:28 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:28 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:28 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:28 --> Total execution time: 0.0142
INFO - 2023-02-17 03:07:31 --> Config Class Initialized
INFO - 2023-02-17 03:07:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:31 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:31 --> URI Class Initialized
INFO - 2023-02-17 03:07:31 --> Router Class Initialized
INFO - 2023-02-17 03:07:31 --> Output Class Initialized
INFO - 2023-02-17 03:07:31 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:31 --> Input Class Initialized
INFO - 2023-02-17 03:07:31 --> Language Class Initialized
INFO - 2023-02-17 03:07:31 --> Loader Class Initialized
INFO - 2023-02-17 03:07:31 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:31 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:31 --> Total execution time: 0.0043
INFO - 2023-02-17 03:07:31 --> Config Class Initialized
INFO - 2023-02-17 03:07:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:31 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:31 --> URI Class Initialized
INFO - 2023-02-17 03:07:31 --> Router Class Initialized
INFO - 2023-02-17 03:07:31 --> Output Class Initialized
INFO - 2023-02-17 03:07:31 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:31 --> Input Class Initialized
INFO - 2023-02-17 03:07:31 --> Language Class Initialized
INFO - 2023-02-17 03:07:31 --> Loader Class Initialized
INFO - 2023-02-17 03:07:31 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:31 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:31 --> Model "Login_model" initialized
INFO - 2023-02-17 03:07:31 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:31 --> Total execution time: 0.0141
INFO - 2023-02-17 03:07:33 --> Config Class Initialized
INFO - 2023-02-17 03:07:33 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:33 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:33 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:33 --> URI Class Initialized
INFO - 2023-02-17 03:07:33 --> Router Class Initialized
INFO - 2023-02-17 03:07:33 --> Output Class Initialized
INFO - 2023-02-17 03:07:33 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:33 --> Input Class Initialized
INFO - 2023-02-17 03:07:33 --> Language Class Initialized
INFO - 2023-02-17 03:07:33 --> Loader Class Initialized
INFO - 2023-02-17 03:07:33 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:33 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:33 --> Total execution time: 0.0668
INFO - 2023-02-17 03:07:33 --> Config Class Initialized
INFO - 2023-02-17 03:07:33 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:33 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:33 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:33 --> URI Class Initialized
INFO - 2023-02-17 03:07:33 --> Router Class Initialized
INFO - 2023-02-17 03:07:33 --> Output Class Initialized
INFO - 2023-02-17 03:07:33 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:33 --> Input Class Initialized
INFO - 2023-02-17 03:07:33 --> Language Class Initialized
INFO - 2023-02-17 03:07:33 --> Loader Class Initialized
INFO - 2023-02-17 03:07:33 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:33 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:33 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:33 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:33 --> Total execution time: 0.0459
INFO - 2023-02-17 03:07:34 --> Config Class Initialized
INFO - 2023-02-17 03:07:34 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:34 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:34 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:34 --> URI Class Initialized
INFO - 2023-02-17 03:07:34 --> Router Class Initialized
INFO - 2023-02-17 03:07:34 --> Output Class Initialized
INFO - 2023-02-17 03:07:34 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:34 --> Input Class Initialized
INFO - 2023-02-17 03:07:34 --> Language Class Initialized
INFO - 2023-02-17 03:07:34 --> Loader Class Initialized
INFO - 2023-02-17 03:07:34 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:34 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:34 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:34 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:34 --> Total execution time: 0.0138
INFO - 2023-02-17 03:07:36 --> Config Class Initialized
INFO - 2023-02-17 03:07:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:36 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:36 --> URI Class Initialized
INFO - 2023-02-17 03:07:36 --> Router Class Initialized
INFO - 2023-02-17 03:07:36 --> Output Class Initialized
INFO - 2023-02-17 03:07:36 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:36 --> Input Class Initialized
INFO - 2023-02-17 03:07:36 --> Language Class Initialized
INFO - 2023-02-17 03:07:36 --> Loader Class Initialized
INFO - 2023-02-17 03:07:36 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:36 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:36 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:36 --> Total execution time: 0.0342
INFO - 2023-02-17 03:07:36 --> Config Class Initialized
INFO - 2023-02-17 03:07:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:36 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:36 --> URI Class Initialized
INFO - 2023-02-17 03:07:36 --> Router Class Initialized
INFO - 2023-02-17 03:07:36 --> Output Class Initialized
INFO - 2023-02-17 03:07:36 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:36 --> Input Class Initialized
INFO - 2023-02-17 03:07:36 --> Language Class Initialized
INFO - 2023-02-17 03:07:36 --> Loader Class Initialized
INFO - 2023-02-17 03:07:36 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:36 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:36 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:36 --> Total execution time: 0.0121
INFO - 2023-02-17 03:07:57 --> Config Class Initialized
INFO - 2023-02-17 03:07:57 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:57 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:57 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:57 --> URI Class Initialized
INFO - 2023-02-17 03:07:57 --> Router Class Initialized
INFO - 2023-02-17 03:07:57 --> Output Class Initialized
INFO - 2023-02-17 03:07:57 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:57 --> Input Class Initialized
INFO - 2023-02-17 03:07:57 --> Language Class Initialized
INFO - 2023-02-17 03:07:57 --> Loader Class Initialized
INFO - 2023-02-17 03:07:57 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:57 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:57 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:57 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:57 --> Total execution time: 0.0583
INFO - 2023-02-17 03:07:57 --> Config Class Initialized
INFO - 2023-02-17 03:07:57 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:07:57 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:07:57 --> Utf8 Class Initialized
INFO - 2023-02-17 03:07:57 --> URI Class Initialized
INFO - 2023-02-17 03:07:57 --> Router Class Initialized
INFO - 2023-02-17 03:07:57 --> Output Class Initialized
INFO - 2023-02-17 03:07:57 --> Security Class Initialized
DEBUG - 2023-02-17 03:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:07:57 --> Input Class Initialized
INFO - 2023-02-17 03:07:57 --> Language Class Initialized
INFO - 2023-02-17 03:07:57 --> Loader Class Initialized
INFO - 2023-02-17 03:07:57 --> Controller Class Initialized
DEBUG - 2023-02-17 03:07:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:07:57 --> Database Driver Class Initialized
INFO - 2023-02-17 03:07:57 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:07:57 --> Final output sent to browser
DEBUG - 2023-02-17 03:07:57 --> Total execution time: 0.0208
INFO - 2023-02-17 03:08:03 --> Config Class Initialized
INFO - 2023-02-17 03:08:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:03 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:03 --> URI Class Initialized
INFO - 2023-02-17 03:08:03 --> Router Class Initialized
INFO - 2023-02-17 03:08:03 --> Output Class Initialized
INFO - 2023-02-17 03:08:03 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:03 --> Input Class Initialized
INFO - 2023-02-17 03:08:03 --> Language Class Initialized
INFO - 2023-02-17 03:08:03 --> Loader Class Initialized
INFO - 2023-02-17 03:08:03 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:03 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:03 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:03 --> Total execution time: 0.0154
INFO - 2023-02-17 03:08:03 --> Config Class Initialized
INFO - 2023-02-17 03:08:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:03 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:03 --> URI Class Initialized
INFO - 2023-02-17 03:08:03 --> Router Class Initialized
INFO - 2023-02-17 03:08:03 --> Output Class Initialized
INFO - 2023-02-17 03:08:03 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:03 --> Input Class Initialized
INFO - 2023-02-17 03:08:03 --> Language Class Initialized
INFO - 2023-02-17 03:08:03 --> Loader Class Initialized
INFO - 2023-02-17 03:08:03 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:03 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:03 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:03 --> Total execution time: 0.0119
INFO - 2023-02-17 03:08:05 --> Config Class Initialized
INFO - 2023-02-17 03:08:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:05 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:05 --> URI Class Initialized
INFO - 2023-02-17 03:08:05 --> Router Class Initialized
INFO - 2023-02-17 03:08:05 --> Output Class Initialized
INFO - 2023-02-17 03:08:05 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:05 --> Input Class Initialized
INFO - 2023-02-17 03:08:05 --> Language Class Initialized
INFO - 2023-02-17 03:08:05 --> Loader Class Initialized
INFO - 2023-02-17 03:08:05 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:05 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:05 --> Total execution time: 0.0047
INFO - 2023-02-17 03:08:05 --> Config Class Initialized
INFO - 2023-02-17 03:08:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:05 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:05 --> URI Class Initialized
INFO - 2023-02-17 03:08:05 --> Router Class Initialized
INFO - 2023-02-17 03:08:05 --> Output Class Initialized
INFO - 2023-02-17 03:08:05 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:05 --> Input Class Initialized
INFO - 2023-02-17 03:08:05 --> Language Class Initialized
INFO - 2023-02-17 03:08:05 --> Loader Class Initialized
INFO - 2023-02-17 03:08:05 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:05 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:05 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:05 --> Total execution time: 0.0104
INFO - 2023-02-17 03:08:07 --> Config Class Initialized
INFO - 2023-02-17 03:08:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:07 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:07 --> URI Class Initialized
INFO - 2023-02-17 03:08:07 --> Router Class Initialized
INFO - 2023-02-17 03:08:07 --> Output Class Initialized
INFO - 2023-02-17 03:08:07 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:07 --> Input Class Initialized
INFO - 2023-02-17 03:08:07 --> Language Class Initialized
INFO - 2023-02-17 03:08:07 --> Loader Class Initialized
INFO - 2023-02-17 03:08:07 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:07 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:07 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:07 --> Total execution time: 0.0152
INFO - 2023-02-17 03:08:10 --> Config Class Initialized
INFO - 2023-02-17 03:08:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:10 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:10 --> URI Class Initialized
INFO - 2023-02-17 03:08:10 --> Router Class Initialized
INFO - 2023-02-17 03:08:10 --> Output Class Initialized
INFO - 2023-02-17 03:08:10 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:10 --> Input Class Initialized
INFO - 2023-02-17 03:08:10 --> Language Class Initialized
INFO - 2023-02-17 03:08:10 --> Loader Class Initialized
INFO - 2023-02-17 03:08:10 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:10 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:10 --> Total execution time: 0.0040
INFO - 2023-02-17 03:08:10 --> Config Class Initialized
INFO - 2023-02-17 03:08:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:10 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:10 --> URI Class Initialized
INFO - 2023-02-17 03:08:10 --> Router Class Initialized
INFO - 2023-02-17 03:08:10 --> Output Class Initialized
INFO - 2023-02-17 03:08:10 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:10 --> Input Class Initialized
INFO - 2023-02-17 03:08:10 --> Language Class Initialized
INFO - 2023-02-17 03:08:10 --> Loader Class Initialized
INFO - 2023-02-17 03:08:10 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:10 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:10 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:10 --> Total execution time: 0.0113
INFO - 2023-02-17 03:08:29 --> Config Class Initialized
INFO - 2023-02-17 03:08:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:29 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:29 --> URI Class Initialized
INFO - 2023-02-17 03:08:29 --> Router Class Initialized
INFO - 2023-02-17 03:08:29 --> Output Class Initialized
INFO - 2023-02-17 03:08:29 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:29 --> Input Class Initialized
INFO - 2023-02-17 03:08:29 --> Language Class Initialized
INFO - 2023-02-17 03:08:29 --> Loader Class Initialized
INFO - 2023-02-17 03:08:29 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:29 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:29 --> Total execution time: 0.0034
INFO - 2023-02-17 03:08:29 --> Config Class Initialized
INFO - 2023-02-17 03:08:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:29 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:29 --> URI Class Initialized
INFO - 2023-02-17 03:08:29 --> Router Class Initialized
INFO - 2023-02-17 03:08:29 --> Output Class Initialized
INFO - 2023-02-17 03:08:29 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:29 --> Input Class Initialized
INFO - 2023-02-17 03:08:29 --> Language Class Initialized
INFO - 2023-02-17 03:08:29 --> Loader Class Initialized
INFO - 2023-02-17 03:08:29 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:29 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:34 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:34 --> Total execution time: 5.0824
INFO - 2023-02-17 03:08:40 --> Config Class Initialized
INFO - 2023-02-17 03:08:40 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:40 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:40 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:40 --> URI Class Initialized
INFO - 2023-02-17 03:08:40 --> Router Class Initialized
INFO - 2023-02-17 03:08:40 --> Output Class Initialized
INFO - 2023-02-17 03:08:40 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:40 --> Input Class Initialized
INFO - 2023-02-17 03:08:40 --> Language Class Initialized
INFO - 2023-02-17 03:08:40 --> Loader Class Initialized
INFO - 2023-02-17 03:08:40 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:40 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:40 --> Total execution time: 0.0218
INFO - 2023-02-17 03:08:40 --> Config Class Initialized
INFO - 2023-02-17 03:08:40 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:40 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:40 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:40 --> URI Class Initialized
INFO - 2023-02-17 03:08:40 --> Router Class Initialized
INFO - 2023-02-17 03:08:40 --> Output Class Initialized
INFO - 2023-02-17 03:08:40 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:40 --> Input Class Initialized
INFO - 2023-02-17 03:08:40 --> Language Class Initialized
INFO - 2023-02-17 03:08:40 --> Loader Class Initialized
INFO - 2023-02-17 03:08:40 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:40 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:40 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:40 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:40 --> Total execution time: 0.0100
INFO - 2023-02-17 03:08:42 --> Config Class Initialized
INFO - 2023-02-17 03:08:42 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:42 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:42 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:42 --> URI Class Initialized
INFO - 2023-02-17 03:08:42 --> Router Class Initialized
INFO - 2023-02-17 03:08:42 --> Output Class Initialized
INFO - 2023-02-17 03:08:42 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:42 --> Input Class Initialized
INFO - 2023-02-17 03:08:42 --> Language Class Initialized
INFO - 2023-02-17 03:08:42 --> Loader Class Initialized
INFO - 2023-02-17 03:08:42 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:42 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:42 --> Total execution time: 0.0037
INFO - 2023-02-17 03:08:42 --> Config Class Initialized
INFO - 2023-02-17 03:08:42 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:42 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:42 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:42 --> URI Class Initialized
INFO - 2023-02-17 03:08:42 --> Router Class Initialized
INFO - 2023-02-17 03:08:42 --> Output Class Initialized
INFO - 2023-02-17 03:08:42 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:42 --> Input Class Initialized
INFO - 2023-02-17 03:08:42 --> Language Class Initialized
INFO - 2023-02-17 03:08:42 --> Loader Class Initialized
INFO - 2023-02-17 03:08:42 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:42 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:42 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:42 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:42 --> Total execution time: 0.0127
INFO - 2023-02-17 03:08:47 --> Config Class Initialized
INFO - 2023-02-17 03:08:47 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:47 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:47 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:47 --> URI Class Initialized
INFO - 2023-02-17 03:08:47 --> Router Class Initialized
INFO - 2023-02-17 03:08:47 --> Output Class Initialized
INFO - 2023-02-17 03:08:47 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:47 --> Input Class Initialized
INFO - 2023-02-17 03:08:47 --> Language Class Initialized
INFO - 2023-02-17 03:08:47 --> Loader Class Initialized
INFO - 2023-02-17 03:08:47 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:47 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:47 --> Total execution time: 0.0039
INFO - 2023-02-17 03:08:47 --> Config Class Initialized
INFO - 2023-02-17 03:08:47 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:08:47 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:08:47 --> Utf8 Class Initialized
INFO - 2023-02-17 03:08:47 --> URI Class Initialized
INFO - 2023-02-17 03:08:47 --> Router Class Initialized
INFO - 2023-02-17 03:08:47 --> Output Class Initialized
INFO - 2023-02-17 03:08:47 --> Security Class Initialized
DEBUG - 2023-02-17 03:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:08:47 --> Input Class Initialized
INFO - 2023-02-17 03:08:47 --> Language Class Initialized
INFO - 2023-02-17 03:08:47 --> Loader Class Initialized
INFO - 2023-02-17 03:08:47 --> Controller Class Initialized
DEBUG - 2023-02-17 03:08:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:08:47 --> Database Driver Class Initialized
INFO - 2023-02-17 03:08:47 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:08:52 --> Final output sent to browser
DEBUG - 2023-02-17 03:08:52 --> Total execution time: 5.0519
INFO - 2023-02-17 03:09:08 --> Config Class Initialized
INFO - 2023-02-17 03:09:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:09:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:09:08 --> Utf8 Class Initialized
INFO - 2023-02-17 03:09:08 --> URI Class Initialized
INFO - 2023-02-17 03:09:08 --> Router Class Initialized
INFO - 2023-02-17 03:09:08 --> Output Class Initialized
INFO - 2023-02-17 03:09:08 --> Security Class Initialized
DEBUG - 2023-02-17 03:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:09:08 --> Input Class Initialized
INFO - 2023-02-17 03:09:08 --> Language Class Initialized
INFO - 2023-02-17 03:09:08 --> Loader Class Initialized
INFO - 2023-02-17 03:09:08 --> Controller Class Initialized
DEBUG - 2023-02-17 03:09:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:09:08 --> Final output sent to browser
DEBUG - 2023-02-17 03:09:08 --> Total execution time: 0.0039
INFO - 2023-02-17 03:09:08 --> Config Class Initialized
INFO - 2023-02-17 03:09:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:09:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:09:08 --> Utf8 Class Initialized
INFO - 2023-02-17 03:09:08 --> URI Class Initialized
INFO - 2023-02-17 03:09:08 --> Router Class Initialized
INFO - 2023-02-17 03:09:08 --> Output Class Initialized
INFO - 2023-02-17 03:09:08 --> Security Class Initialized
DEBUG - 2023-02-17 03:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:09:08 --> Input Class Initialized
INFO - 2023-02-17 03:09:08 --> Language Class Initialized
INFO - 2023-02-17 03:09:08 --> Loader Class Initialized
INFO - 2023-02-17 03:09:08 --> Controller Class Initialized
DEBUG - 2023-02-17 03:09:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:09:08 --> Database Driver Class Initialized
INFO - 2023-02-17 03:09:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:09:13 --> Final output sent to browser
DEBUG - 2023-02-17 03:09:13 --> Total execution time: 5.1100
INFO - 2023-02-17 03:29:26 --> Config Class Initialized
INFO - 2023-02-17 03:29:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:29:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:29:26 --> Utf8 Class Initialized
INFO - 2023-02-17 03:29:26 --> URI Class Initialized
INFO - 2023-02-17 03:29:26 --> Router Class Initialized
INFO - 2023-02-17 03:29:26 --> Output Class Initialized
INFO - 2023-02-17 03:29:26 --> Security Class Initialized
DEBUG - 2023-02-17 03:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:29:26 --> Input Class Initialized
INFO - 2023-02-17 03:29:26 --> Language Class Initialized
INFO - 2023-02-17 03:29:26 --> Loader Class Initialized
INFO - 2023-02-17 03:29:26 --> Controller Class Initialized
DEBUG - 2023-02-17 03:29:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:29:26 --> Database Driver Class Initialized
INFO - 2023-02-17 03:29:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:29:26 --> Database Driver Class Initialized
INFO - 2023-02-17 03:29:26 --> Model "Login_model" initialized
INFO - 2023-02-17 03:29:26 --> Final output sent to browser
DEBUG - 2023-02-17 03:29:26 --> Total execution time: 0.1386
INFO - 2023-02-17 03:29:26 --> Config Class Initialized
INFO - 2023-02-17 03:29:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 03:29:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 03:29:26 --> Utf8 Class Initialized
INFO - 2023-02-17 03:29:26 --> URI Class Initialized
INFO - 2023-02-17 03:29:26 --> Router Class Initialized
INFO - 2023-02-17 03:29:26 --> Output Class Initialized
INFO - 2023-02-17 03:29:26 --> Security Class Initialized
DEBUG - 2023-02-17 03:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 03:29:26 --> Input Class Initialized
INFO - 2023-02-17 03:29:26 --> Language Class Initialized
INFO - 2023-02-17 03:29:26 --> Loader Class Initialized
INFO - 2023-02-17 03:29:26 --> Controller Class Initialized
DEBUG - 2023-02-17 03:29:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 03:29:26 --> Database Driver Class Initialized
INFO - 2023-02-17 03:29:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 03:29:26 --> Database Driver Class Initialized
INFO - 2023-02-17 03:29:26 --> Model "Login_model" initialized
INFO - 2023-02-17 03:29:26 --> Final output sent to browser
DEBUG - 2023-02-17 03:29:26 --> Total execution time: 0.0852
INFO - 2023-02-17 04:07:04 --> Config Class Initialized
INFO - 2023-02-17 04:07:04 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:07:04 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:07:04 --> Utf8 Class Initialized
INFO - 2023-02-17 04:07:04 --> URI Class Initialized
INFO - 2023-02-17 04:07:04 --> Router Class Initialized
INFO - 2023-02-17 04:07:04 --> Output Class Initialized
INFO - 2023-02-17 04:07:04 --> Security Class Initialized
DEBUG - 2023-02-17 04:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:07:04 --> Input Class Initialized
INFO - 2023-02-17 04:07:04 --> Language Class Initialized
INFO - 2023-02-17 04:07:04 --> Loader Class Initialized
INFO - 2023-02-17 04:07:04 --> Controller Class Initialized
DEBUG - 2023-02-17 04:07:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:07:04 --> Database Driver Class Initialized
INFO - 2023-02-17 04:07:04 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:07:04 --> Database Driver Class Initialized
INFO - 2023-02-17 04:07:04 --> Model "Login_model" initialized
INFO - 2023-02-17 04:07:04 --> Final output sent to browser
DEBUG - 2023-02-17 04:07:04 --> Total execution time: 0.1409
INFO - 2023-02-17 04:07:04 --> Config Class Initialized
INFO - 2023-02-17 04:07:04 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:07:04 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:07:04 --> Utf8 Class Initialized
INFO - 2023-02-17 04:07:04 --> URI Class Initialized
INFO - 2023-02-17 04:07:04 --> Router Class Initialized
INFO - 2023-02-17 04:07:04 --> Output Class Initialized
INFO - 2023-02-17 04:07:04 --> Security Class Initialized
DEBUG - 2023-02-17 04:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:07:04 --> Input Class Initialized
INFO - 2023-02-17 04:07:04 --> Language Class Initialized
INFO - 2023-02-17 04:07:04 --> Loader Class Initialized
INFO - 2023-02-17 04:07:04 --> Controller Class Initialized
DEBUG - 2023-02-17 04:07:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:07:04 --> Database Driver Class Initialized
INFO - 2023-02-17 04:07:04 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:07:04 --> Database Driver Class Initialized
INFO - 2023-02-17 04:07:04 --> Model "Login_model" initialized
INFO - 2023-02-17 04:07:04 --> Final output sent to browser
DEBUG - 2023-02-17 04:07:04 --> Total execution time: 0.0679
INFO - 2023-02-17 04:07:06 --> Config Class Initialized
INFO - 2023-02-17 04:07:06 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:07:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:07:06 --> Utf8 Class Initialized
INFO - 2023-02-17 04:07:06 --> URI Class Initialized
INFO - 2023-02-17 04:07:07 --> Router Class Initialized
INFO - 2023-02-17 04:07:07 --> Output Class Initialized
INFO - 2023-02-17 04:07:07 --> Security Class Initialized
DEBUG - 2023-02-17 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:07:07 --> Input Class Initialized
INFO - 2023-02-17 04:07:07 --> Language Class Initialized
INFO - 2023-02-17 04:07:07 --> Loader Class Initialized
INFO - 2023-02-17 04:07:07 --> Controller Class Initialized
DEBUG - 2023-02-17 04:07:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:07:07 --> Database Driver Class Initialized
INFO - 2023-02-17 04:07:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:07:07 --> Final output sent to browser
INFO - 2023-02-17 04:07:07 --> Config Class Initialized
DEBUG - 2023-02-17 04:07:07 --> Total execution time: 0.3098
INFO - 2023-02-17 04:07:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:07:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:07:07 --> Utf8 Class Initialized
INFO - 2023-02-17 04:07:07 --> URI Class Initialized
INFO - 2023-02-17 04:07:07 --> Router Class Initialized
INFO - 2023-02-17 04:07:07 --> Output Class Initialized
INFO - 2023-02-17 04:07:07 --> Security Class Initialized
DEBUG - 2023-02-17 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:07:07 --> Input Class Initialized
INFO - 2023-02-17 04:07:07 --> Language Class Initialized
INFO - 2023-02-17 04:07:07 --> Loader Class Initialized
INFO - 2023-02-17 04:07:07 --> Controller Class Initialized
DEBUG - 2023-02-17 04:07:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:07:07 --> Database Driver Class Initialized
INFO - 2023-02-17 04:07:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:07:07 --> Final output sent to browser
DEBUG - 2023-02-17 04:07:07 --> Total execution time: 0.0816
INFO - 2023-02-17 04:37:13 --> Config Class Initialized
INFO - 2023-02-17 04:37:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:37:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:37:13 --> Utf8 Class Initialized
INFO - 2023-02-17 04:37:13 --> URI Class Initialized
INFO - 2023-02-17 04:37:13 --> Router Class Initialized
INFO - 2023-02-17 04:37:13 --> Output Class Initialized
INFO - 2023-02-17 04:37:13 --> Security Class Initialized
DEBUG - 2023-02-17 04:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:37:13 --> Input Class Initialized
INFO - 2023-02-17 04:37:13 --> Language Class Initialized
INFO - 2023-02-17 04:37:13 --> Loader Class Initialized
INFO - 2023-02-17 04:37:13 --> Controller Class Initialized
DEBUG - 2023-02-17 04:37:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:37:13 --> Database Driver Class Initialized
INFO - 2023-02-17 04:37:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:37:13 --> Final output sent to browser
DEBUG - 2023-02-17 04:37:13 --> Total execution time: 0.1123
INFO - 2023-02-17 04:37:13 --> Config Class Initialized
INFO - 2023-02-17 04:37:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:37:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:37:13 --> Utf8 Class Initialized
INFO - 2023-02-17 04:37:13 --> URI Class Initialized
INFO - 2023-02-17 04:37:13 --> Router Class Initialized
INFO - 2023-02-17 04:37:13 --> Output Class Initialized
INFO - 2023-02-17 04:37:13 --> Security Class Initialized
DEBUG - 2023-02-17 04:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:37:13 --> Input Class Initialized
INFO - 2023-02-17 04:37:13 --> Language Class Initialized
INFO - 2023-02-17 04:37:13 --> Loader Class Initialized
INFO - 2023-02-17 04:37:13 --> Controller Class Initialized
DEBUG - 2023-02-17 04:37:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:37:13 --> Database Driver Class Initialized
INFO - 2023-02-17 04:37:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:37:13 --> Final output sent to browser
DEBUG - 2023-02-17 04:37:13 --> Total execution time: 0.0390
INFO - 2023-02-17 04:37:49 --> Config Class Initialized
INFO - 2023-02-17 04:37:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:37:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:37:49 --> Utf8 Class Initialized
INFO - 2023-02-17 04:37:49 --> URI Class Initialized
INFO - 2023-02-17 04:37:49 --> Router Class Initialized
INFO - 2023-02-17 04:37:49 --> Output Class Initialized
INFO - 2023-02-17 04:37:49 --> Security Class Initialized
DEBUG - 2023-02-17 04:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:37:49 --> Input Class Initialized
INFO - 2023-02-17 04:37:49 --> Language Class Initialized
INFO - 2023-02-17 04:37:49 --> Loader Class Initialized
INFO - 2023-02-17 04:37:49 --> Controller Class Initialized
DEBUG - 2023-02-17 04:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:37:49 --> Database Driver Class Initialized
INFO - 2023-02-17 04:37:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:37:49 --> Final output sent to browser
DEBUG - 2023-02-17 04:37:49 --> Total execution time: 0.2469
INFO - 2023-02-17 04:37:49 --> Config Class Initialized
INFO - 2023-02-17 04:37:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:37:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:37:49 --> Utf8 Class Initialized
INFO - 2023-02-17 04:37:49 --> URI Class Initialized
INFO - 2023-02-17 04:37:49 --> Router Class Initialized
INFO - 2023-02-17 04:37:49 --> Output Class Initialized
INFO - 2023-02-17 04:37:49 --> Security Class Initialized
DEBUG - 2023-02-17 04:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:37:49 --> Input Class Initialized
INFO - 2023-02-17 04:37:49 --> Language Class Initialized
INFO - 2023-02-17 04:37:49 --> Loader Class Initialized
INFO - 2023-02-17 04:37:49 --> Controller Class Initialized
DEBUG - 2023-02-17 04:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:37:49 --> Database Driver Class Initialized
INFO - 2023-02-17 04:37:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:37:49 --> Final output sent to browser
DEBUG - 2023-02-17 04:37:49 --> Total execution time: 0.0804
INFO - 2023-02-17 04:38:39 --> Config Class Initialized
INFO - 2023-02-17 04:38:39 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:38:39 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:38:39 --> Utf8 Class Initialized
INFO - 2023-02-17 04:38:39 --> URI Class Initialized
INFO - 2023-02-17 04:38:39 --> Router Class Initialized
INFO - 2023-02-17 04:38:39 --> Output Class Initialized
INFO - 2023-02-17 04:38:39 --> Security Class Initialized
DEBUG - 2023-02-17 04:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:38:39 --> Input Class Initialized
INFO - 2023-02-17 04:38:39 --> Language Class Initialized
INFO - 2023-02-17 04:38:39 --> Loader Class Initialized
INFO - 2023-02-17 04:38:39 --> Controller Class Initialized
DEBUG - 2023-02-17 04:38:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:38:39 --> Database Driver Class Initialized
INFO - 2023-02-17 04:38:39 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:38:39 --> Final output sent to browser
DEBUG - 2023-02-17 04:38:39 --> Total execution time: 0.1872
INFO - 2023-02-17 04:38:39 --> Config Class Initialized
INFO - 2023-02-17 04:38:39 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:38:39 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:38:39 --> Utf8 Class Initialized
INFO - 2023-02-17 04:38:39 --> URI Class Initialized
INFO - 2023-02-17 04:38:39 --> Router Class Initialized
INFO - 2023-02-17 04:38:39 --> Output Class Initialized
INFO - 2023-02-17 04:38:39 --> Security Class Initialized
DEBUG - 2023-02-17 04:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:38:39 --> Input Class Initialized
INFO - 2023-02-17 04:38:39 --> Language Class Initialized
INFO - 2023-02-17 04:38:39 --> Loader Class Initialized
INFO - 2023-02-17 04:38:39 --> Controller Class Initialized
DEBUG - 2023-02-17 04:38:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:38:39 --> Database Driver Class Initialized
INFO - 2023-02-17 04:38:39 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:38:39 --> Final output sent to browser
DEBUG - 2023-02-17 04:38:39 --> Total execution time: 0.0435
INFO - 2023-02-17 04:43:16 --> Config Class Initialized
INFO - 2023-02-17 04:43:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:43:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:43:16 --> Utf8 Class Initialized
INFO - 2023-02-17 04:43:16 --> URI Class Initialized
INFO - 2023-02-17 04:43:16 --> Router Class Initialized
INFO - 2023-02-17 04:43:16 --> Output Class Initialized
INFO - 2023-02-17 04:43:16 --> Security Class Initialized
DEBUG - 2023-02-17 04:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:43:16 --> Input Class Initialized
INFO - 2023-02-17 04:43:16 --> Language Class Initialized
INFO - 2023-02-17 04:43:16 --> Loader Class Initialized
INFO - 2023-02-17 04:43:16 --> Controller Class Initialized
DEBUG - 2023-02-17 04:43:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:43:16 --> Database Driver Class Initialized
INFO - 2023-02-17 04:43:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:43:16 --> Final output sent to browser
DEBUG - 2023-02-17 04:43:16 --> Total execution time: 0.1755
INFO - 2023-02-17 04:43:16 --> Config Class Initialized
INFO - 2023-02-17 04:43:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:43:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:43:16 --> Utf8 Class Initialized
INFO - 2023-02-17 04:43:16 --> URI Class Initialized
INFO - 2023-02-17 04:43:16 --> Router Class Initialized
INFO - 2023-02-17 04:43:16 --> Output Class Initialized
INFO - 2023-02-17 04:43:16 --> Security Class Initialized
DEBUG - 2023-02-17 04:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:43:16 --> Input Class Initialized
INFO - 2023-02-17 04:43:16 --> Language Class Initialized
INFO - 2023-02-17 04:43:16 --> Loader Class Initialized
INFO - 2023-02-17 04:43:16 --> Controller Class Initialized
DEBUG - 2023-02-17 04:43:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:43:16 --> Database Driver Class Initialized
INFO - 2023-02-17 04:43:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:43:16 --> Final output sent to browser
DEBUG - 2023-02-17 04:43:16 --> Total execution time: 0.0413
INFO - 2023-02-17 04:46:57 --> Config Class Initialized
INFO - 2023-02-17 04:46:57 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:46:57 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:46:57 --> Utf8 Class Initialized
INFO - 2023-02-17 04:46:57 --> URI Class Initialized
INFO - 2023-02-17 04:46:57 --> Router Class Initialized
INFO - 2023-02-17 04:46:57 --> Output Class Initialized
INFO - 2023-02-17 04:46:57 --> Security Class Initialized
DEBUG - 2023-02-17 04:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:46:57 --> Input Class Initialized
INFO - 2023-02-17 04:46:57 --> Language Class Initialized
INFO - 2023-02-17 04:46:57 --> Loader Class Initialized
INFO - 2023-02-17 04:46:57 --> Controller Class Initialized
DEBUG - 2023-02-17 04:46:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:46:57 --> Database Driver Class Initialized
INFO - 2023-02-17 04:46:57 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:46:57 --> Final output sent to browser
DEBUG - 2023-02-17 04:46:57 --> Total execution time: 0.1592
INFO - 2023-02-17 04:46:57 --> Config Class Initialized
INFO - 2023-02-17 04:46:57 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:46:57 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:46:57 --> Utf8 Class Initialized
INFO - 2023-02-17 04:46:57 --> URI Class Initialized
INFO - 2023-02-17 04:46:57 --> Router Class Initialized
INFO - 2023-02-17 04:46:57 --> Output Class Initialized
INFO - 2023-02-17 04:46:57 --> Security Class Initialized
DEBUG - 2023-02-17 04:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:46:57 --> Input Class Initialized
INFO - 2023-02-17 04:46:57 --> Language Class Initialized
INFO - 2023-02-17 04:46:57 --> Loader Class Initialized
INFO - 2023-02-17 04:46:57 --> Controller Class Initialized
DEBUG - 2023-02-17 04:46:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:46:57 --> Database Driver Class Initialized
INFO - 2023-02-17 04:46:57 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:46:57 --> Final output sent to browser
DEBUG - 2023-02-17 04:46:57 --> Total execution time: 0.0427
INFO - 2023-02-17 04:52:58 --> Config Class Initialized
INFO - 2023-02-17 04:52:58 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:52:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:52:59 --> Utf8 Class Initialized
INFO - 2023-02-17 04:52:59 --> URI Class Initialized
INFO - 2023-02-17 04:52:59 --> Router Class Initialized
INFO - 2023-02-17 04:52:59 --> Output Class Initialized
INFO - 2023-02-17 04:52:59 --> Security Class Initialized
DEBUG - 2023-02-17 04:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:52:59 --> Input Class Initialized
INFO - 2023-02-17 04:52:59 --> Language Class Initialized
INFO - 2023-02-17 04:52:59 --> Loader Class Initialized
INFO - 2023-02-17 04:52:59 --> Controller Class Initialized
DEBUG - 2023-02-17 04:52:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:52:59 --> Database Driver Class Initialized
INFO - 2023-02-17 04:52:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:52:59 --> Final output sent to browser
DEBUG - 2023-02-17 04:52:59 --> Total execution time: 0.1375
INFO - 2023-02-17 04:52:59 --> Config Class Initialized
INFO - 2023-02-17 04:52:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:52:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:52:59 --> Utf8 Class Initialized
INFO - 2023-02-17 04:52:59 --> URI Class Initialized
INFO - 2023-02-17 04:52:59 --> Router Class Initialized
INFO - 2023-02-17 04:52:59 --> Output Class Initialized
INFO - 2023-02-17 04:52:59 --> Security Class Initialized
DEBUG - 2023-02-17 04:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:52:59 --> Input Class Initialized
INFO - 2023-02-17 04:52:59 --> Language Class Initialized
INFO - 2023-02-17 04:52:59 --> Loader Class Initialized
INFO - 2023-02-17 04:52:59 --> Controller Class Initialized
DEBUG - 2023-02-17 04:52:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:52:59 --> Database Driver Class Initialized
INFO - 2023-02-17 04:52:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:52:59 --> Final output sent to browser
DEBUG - 2023-02-17 04:52:59 --> Total execution time: 0.0772
INFO - 2023-02-17 04:53:53 --> Config Class Initialized
INFO - 2023-02-17 04:53:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:53:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:53:53 --> Utf8 Class Initialized
INFO - 2023-02-17 04:53:53 --> URI Class Initialized
INFO - 2023-02-17 04:53:53 --> Router Class Initialized
INFO - 2023-02-17 04:53:53 --> Output Class Initialized
INFO - 2023-02-17 04:53:53 --> Security Class Initialized
DEBUG - 2023-02-17 04:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:53:53 --> Input Class Initialized
INFO - 2023-02-17 04:53:53 --> Language Class Initialized
INFO - 2023-02-17 04:53:53 --> Loader Class Initialized
INFO - 2023-02-17 04:53:53 --> Controller Class Initialized
DEBUG - 2023-02-17 04:53:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:53:53 --> Database Driver Class Initialized
INFO - 2023-02-17 04:53:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:53:53 --> Final output sent to browser
DEBUG - 2023-02-17 04:53:53 --> Total execution time: 0.0867
INFO - 2023-02-17 04:53:53 --> Config Class Initialized
INFO - 2023-02-17 04:53:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:53:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:53:53 --> Utf8 Class Initialized
INFO - 2023-02-17 04:53:53 --> URI Class Initialized
INFO - 2023-02-17 04:53:53 --> Router Class Initialized
INFO - 2023-02-17 04:53:53 --> Output Class Initialized
INFO - 2023-02-17 04:53:53 --> Security Class Initialized
DEBUG - 2023-02-17 04:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:53:53 --> Input Class Initialized
INFO - 2023-02-17 04:53:53 --> Language Class Initialized
INFO - 2023-02-17 04:53:53 --> Loader Class Initialized
INFO - 2023-02-17 04:53:53 --> Controller Class Initialized
DEBUG - 2023-02-17 04:53:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:53:53 --> Database Driver Class Initialized
INFO - 2023-02-17 04:53:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:53:53 --> Final output sent to browser
DEBUG - 2023-02-17 04:53:53 --> Total execution time: 0.0525
INFO - 2023-02-17 04:53:54 --> Config Class Initialized
INFO - 2023-02-17 04:53:54 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:53:54 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:53:54 --> Utf8 Class Initialized
INFO - 2023-02-17 04:53:54 --> URI Class Initialized
INFO - 2023-02-17 04:53:54 --> Router Class Initialized
INFO - 2023-02-17 04:53:54 --> Output Class Initialized
INFO - 2023-02-17 04:53:54 --> Security Class Initialized
DEBUG - 2023-02-17 04:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:53:54 --> Input Class Initialized
INFO - 2023-02-17 04:53:54 --> Language Class Initialized
INFO - 2023-02-17 04:53:54 --> Loader Class Initialized
INFO - 2023-02-17 04:53:54 --> Controller Class Initialized
DEBUG - 2023-02-17 04:53:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:53:54 --> Database Driver Class Initialized
INFO - 2023-02-17 04:53:54 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:53:54 --> Final output sent to browser
DEBUG - 2023-02-17 04:53:54 --> Total execution time: 0.0475
INFO - 2023-02-17 04:53:54 --> Config Class Initialized
INFO - 2023-02-17 04:53:54 --> Hooks Class Initialized
DEBUG - 2023-02-17 04:53:54 --> UTF-8 Support Enabled
INFO - 2023-02-17 04:53:54 --> Utf8 Class Initialized
INFO - 2023-02-17 04:53:54 --> URI Class Initialized
INFO - 2023-02-17 04:53:54 --> Router Class Initialized
INFO - 2023-02-17 04:53:54 --> Output Class Initialized
INFO - 2023-02-17 04:53:54 --> Security Class Initialized
DEBUG - 2023-02-17 04:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 04:53:54 --> Input Class Initialized
INFO - 2023-02-17 04:53:54 --> Language Class Initialized
INFO - 2023-02-17 04:53:54 --> Loader Class Initialized
INFO - 2023-02-17 04:53:54 --> Controller Class Initialized
DEBUG - 2023-02-17 04:53:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 04:53:54 --> Database Driver Class Initialized
INFO - 2023-02-17 04:53:54 --> Model "Cluster_model" initialized
INFO - 2023-02-17 04:53:54 --> Final output sent to browser
DEBUG - 2023-02-17 04:53:54 --> Total execution time: 0.0433
INFO - 2023-02-17 05:47:28 --> Config Class Initialized
INFO - 2023-02-17 05:47:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:28 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:28 --> URI Class Initialized
INFO - 2023-02-17 05:47:28 --> Router Class Initialized
INFO - 2023-02-17 05:47:28 --> Output Class Initialized
INFO - 2023-02-17 05:47:28 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:28 --> Input Class Initialized
INFO - 2023-02-17 05:47:28 --> Language Class Initialized
INFO - 2023-02-17 05:47:28 --> Loader Class Initialized
INFO - 2023-02-17 05:47:28 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:28 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:28 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:28 --> Total execution time: 0.1812
INFO - 2023-02-17 05:47:28 --> Config Class Initialized
INFO - 2023-02-17 05:47:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:28 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:28 --> URI Class Initialized
INFO - 2023-02-17 05:47:28 --> Router Class Initialized
INFO - 2023-02-17 05:47:28 --> Output Class Initialized
INFO - 2023-02-17 05:47:28 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:28 --> Input Class Initialized
INFO - 2023-02-17 05:47:28 --> Language Class Initialized
INFO - 2023-02-17 05:47:28 --> Loader Class Initialized
INFO - 2023-02-17 05:47:28 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:28 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:28 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:28 --> Total execution time: 0.0492
INFO - 2023-02-17 05:47:35 --> Config Class Initialized
INFO - 2023-02-17 05:47:35 --> Config Class Initialized
INFO - 2023-02-17 05:47:35 --> Hooks Class Initialized
INFO - 2023-02-17 05:47:35 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:35 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:35 --> Utf8 Class Initialized
DEBUG - 2023-02-17 05:47:35 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:35 --> URI Class Initialized
INFO - 2023-02-17 05:47:35 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:35 --> URI Class Initialized
INFO - 2023-02-17 05:47:35 --> Router Class Initialized
INFO - 2023-02-17 05:47:35 --> Router Class Initialized
INFO - 2023-02-17 05:47:35 --> Output Class Initialized
INFO - 2023-02-17 05:47:35 --> Output Class Initialized
INFO - 2023-02-17 05:47:35 --> Security Class Initialized
INFO - 2023-02-17 05:47:35 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 05:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:35 --> Input Class Initialized
INFO - 2023-02-17 05:47:35 --> Input Class Initialized
INFO - 2023-02-17 05:47:35 --> Language Class Initialized
INFO - 2023-02-17 05:47:35 --> Language Class Initialized
INFO - 2023-02-17 05:47:35 --> Loader Class Initialized
INFO - 2023-02-17 05:47:35 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:35 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:35 --> Loader Class Initialized
INFO - 2023-02-17 05:47:35 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:35 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:35 --> Total execution time: 0.0455
INFO - 2023-02-17 05:47:35 --> Config Class Initialized
INFO - 2023-02-17 05:47:35 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:35 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:35 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:35 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:35 --> URI Class Initialized
INFO - 2023-02-17 05:47:35 --> Router Class Initialized
INFO - 2023-02-17 05:47:35 --> Output Class Initialized
INFO - 2023-02-17 05:47:35 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:35 --> Input Class Initialized
INFO - 2023-02-17 05:47:35 --> Language Class Initialized
INFO - 2023-02-17 05:47:35 --> Loader Class Initialized
INFO - 2023-02-17 05:47:35 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:35 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:35 --> Total execution time: 0.0961
INFO - 2023-02-17 05:47:35 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:35 --> Config Class Initialized
INFO - 2023-02-17 05:47:35 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:35 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:35 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:35 --> URI Class Initialized
INFO - 2023-02-17 05:47:35 --> Router Class Initialized
INFO - 2023-02-17 05:47:35 --> Output Class Initialized
INFO - 2023-02-17 05:47:35 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:35 --> Input Class Initialized
INFO - 2023-02-17 05:47:35 --> Language Class Initialized
INFO - 2023-02-17 05:47:35 --> Loader Class Initialized
INFO - 2023-02-17 05:47:35 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:35 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:35 --> Model "Login_model" initialized
INFO - 2023-02-17 05:47:35 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:35 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:35 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:35 --> Total execution time: 0.0128
INFO - 2023-02-17 05:47:35 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:35 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:35 --> Total execution time: 0.1065
INFO - 2023-02-17 05:47:38 --> Config Class Initialized
INFO - 2023-02-17 05:47:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:38 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:38 --> URI Class Initialized
INFO - 2023-02-17 05:47:38 --> Router Class Initialized
INFO - 2023-02-17 05:47:38 --> Output Class Initialized
INFO - 2023-02-17 05:47:38 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:38 --> Input Class Initialized
INFO - 2023-02-17 05:47:38 --> Language Class Initialized
INFO - 2023-02-17 05:47:38 --> Loader Class Initialized
INFO - 2023-02-17 05:47:38 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:38 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:38 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:38 --> Total execution time: 0.0476
INFO - 2023-02-17 05:47:38 --> Config Class Initialized
INFO - 2023-02-17 05:47:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:38 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:38 --> URI Class Initialized
INFO - 2023-02-17 05:47:38 --> Router Class Initialized
INFO - 2023-02-17 05:47:38 --> Output Class Initialized
INFO - 2023-02-17 05:47:38 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:38 --> Input Class Initialized
INFO - 2023-02-17 05:47:38 --> Language Class Initialized
INFO - 2023-02-17 05:47:38 --> Loader Class Initialized
INFO - 2023-02-17 05:47:38 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:38 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:38 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:38 --> Total execution time: 0.0413
INFO - 2023-02-17 05:47:40 --> Config Class Initialized
INFO - 2023-02-17 05:47:40 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:40 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:40 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:40 --> URI Class Initialized
INFO - 2023-02-17 05:47:40 --> Router Class Initialized
INFO - 2023-02-17 05:47:40 --> Output Class Initialized
INFO - 2023-02-17 05:47:40 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:40 --> Input Class Initialized
INFO - 2023-02-17 05:47:40 --> Language Class Initialized
INFO - 2023-02-17 05:47:40 --> Loader Class Initialized
INFO - 2023-02-17 05:47:40 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:40 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:40 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:40 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:40 --> Model "Login_model" initialized
INFO - 2023-02-17 05:47:40 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:40 --> Total execution time: 0.0472
INFO - 2023-02-17 05:47:40 --> Config Class Initialized
INFO - 2023-02-17 05:47:40 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:40 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:40 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:40 --> URI Class Initialized
INFO - 2023-02-17 05:47:40 --> Router Class Initialized
INFO - 2023-02-17 05:47:40 --> Output Class Initialized
INFO - 2023-02-17 05:47:40 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:40 --> Input Class Initialized
INFO - 2023-02-17 05:47:40 --> Language Class Initialized
INFO - 2023-02-17 05:47:40 --> Loader Class Initialized
INFO - 2023-02-17 05:47:40 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:40 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:40 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:40 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:40 --> Model "Login_model" initialized
INFO - 2023-02-17 05:47:40 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:40 --> Total execution time: 0.0685
INFO - 2023-02-17 05:47:43 --> Config Class Initialized
INFO - 2023-02-17 05:47:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:43 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:43 --> URI Class Initialized
INFO - 2023-02-17 05:47:43 --> Router Class Initialized
INFO - 2023-02-17 05:47:43 --> Output Class Initialized
INFO - 2023-02-17 05:47:43 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:43 --> Input Class Initialized
INFO - 2023-02-17 05:47:43 --> Language Class Initialized
INFO - 2023-02-17 05:47:43 --> Loader Class Initialized
INFO - 2023-02-17 05:47:43 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:43 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:43 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:43 --> Total execution time: 0.0155
INFO - 2023-02-17 05:47:43 --> Config Class Initialized
INFO - 2023-02-17 05:47:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:43 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:43 --> URI Class Initialized
INFO - 2023-02-17 05:47:43 --> Router Class Initialized
INFO - 2023-02-17 05:47:43 --> Output Class Initialized
INFO - 2023-02-17 05:47:43 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:43 --> Input Class Initialized
INFO - 2023-02-17 05:47:43 --> Language Class Initialized
INFO - 2023-02-17 05:47:43 --> Loader Class Initialized
INFO - 2023-02-17 05:47:43 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:43 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:43 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:43 --> Total execution time: 0.0115
INFO - 2023-02-17 05:47:45 --> Config Class Initialized
INFO - 2023-02-17 05:47:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:45 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:45 --> URI Class Initialized
INFO - 2023-02-17 05:47:45 --> Router Class Initialized
INFO - 2023-02-17 05:47:45 --> Output Class Initialized
INFO - 2023-02-17 05:47:45 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:45 --> Input Class Initialized
INFO - 2023-02-17 05:47:45 --> Language Class Initialized
INFO - 2023-02-17 05:47:45 --> Loader Class Initialized
INFO - 2023-02-17 05:47:45 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:45 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:45 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:45 --> Total execution time: 0.0243
INFO - 2023-02-17 05:47:45 --> Config Class Initialized
INFO - 2023-02-17 05:47:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:47:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:47:45 --> Utf8 Class Initialized
INFO - 2023-02-17 05:47:45 --> URI Class Initialized
INFO - 2023-02-17 05:47:45 --> Router Class Initialized
INFO - 2023-02-17 05:47:45 --> Output Class Initialized
INFO - 2023-02-17 05:47:45 --> Security Class Initialized
DEBUG - 2023-02-17 05:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:47:45 --> Input Class Initialized
INFO - 2023-02-17 05:47:45 --> Language Class Initialized
INFO - 2023-02-17 05:47:45 --> Loader Class Initialized
INFO - 2023-02-17 05:47:45 --> Controller Class Initialized
DEBUG - 2023-02-17 05:47:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:47:45 --> Database Driver Class Initialized
INFO - 2023-02-17 05:47:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:47:45 --> Final output sent to browser
DEBUG - 2023-02-17 05:47:45 --> Total execution time: 0.0551
INFO - 2023-02-17 05:48:12 --> Config Class Initialized
INFO - 2023-02-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:12 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:12 --> URI Class Initialized
INFO - 2023-02-17 05:48:12 --> Router Class Initialized
INFO - 2023-02-17 05:48:12 --> Output Class Initialized
INFO - 2023-02-17 05:48:12 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:12 --> Input Class Initialized
INFO - 2023-02-17 05:48:12 --> Language Class Initialized
INFO - 2023-02-17 05:48:12 --> Loader Class Initialized
INFO - 2023-02-17 05:48:12 --> Controller Class Initialized
INFO - 2023-02-17 05:48:12 --> Helper loaded: form_helper
INFO - 2023-02-17 05:48:12 --> Helper loaded: url_helper
DEBUG - 2023-02-17 05:48:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:12 --> Model "Change_model" initialized
INFO - 2023-02-17 05:48:12 --> Model "Grafana_model" initialized
INFO - 2023-02-17 05:48:12 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:12 --> Total execution time: 0.0352
INFO - 2023-02-17 05:48:12 --> Config Class Initialized
INFO - 2023-02-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:12 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:12 --> URI Class Initialized
INFO - 2023-02-17 05:48:12 --> Router Class Initialized
INFO - 2023-02-17 05:48:12 --> Output Class Initialized
INFO - 2023-02-17 05:48:12 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:12 --> Input Class Initialized
INFO - 2023-02-17 05:48:12 --> Language Class Initialized
INFO - 2023-02-17 05:48:12 --> Loader Class Initialized
INFO - 2023-02-17 05:48:12 --> Controller Class Initialized
INFO - 2023-02-17 05:48:12 --> Helper loaded: form_helper
INFO - 2023-02-17 05:48:12 --> Helper loaded: url_helper
DEBUG - 2023-02-17 05:48:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:12 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:12 --> Total execution time: 0.0443
INFO - 2023-02-17 05:48:12 --> Config Class Initialized
INFO - 2023-02-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:12 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:12 --> URI Class Initialized
INFO - 2023-02-17 05:48:12 --> Router Class Initialized
INFO - 2023-02-17 05:48:12 --> Output Class Initialized
INFO - 2023-02-17 05:48:12 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:12 --> Input Class Initialized
INFO - 2023-02-17 05:48:12 --> Language Class Initialized
INFO - 2023-02-17 05:48:12 --> Loader Class Initialized
INFO - 2023-02-17 05:48:12 --> Controller Class Initialized
INFO - 2023-02-17 05:48:12 --> Helper loaded: form_helper
INFO - 2023-02-17 05:48:12 --> Helper loaded: url_helper
DEBUG - 2023-02-17 05:48:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:12 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:12 --> Model "Login_model" initialized
INFO - 2023-02-17 05:48:12 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:12 --> Total execution time: 0.0153
INFO - 2023-02-17 05:48:12 --> Config Class Initialized
INFO - 2023-02-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:12 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:12 --> URI Class Initialized
INFO - 2023-02-17 05:48:12 --> Router Class Initialized
INFO - 2023-02-17 05:48:12 --> Output Class Initialized
INFO - 2023-02-17 05:48:12 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:12 --> Input Class Initialized
INFO - 2023-02-17 05:48:12 --> Language Class Initialized
INFO - 2023-02-17 05:48:12 --> Loader Class Initialized
INFO - 2023-02-17 05:48:12 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:12 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:12 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:12 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:12 --> Total execution time: 0.0136
INFO - 2023-02-17 05:48:12 --> Config Class Initialized
INFO - 2023-02-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:12 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:12 --> URI Class Initialized
INFO - 2023-02-17 05:48:12 --> Router Class Initialized
INFO - 2023-02-17 05:48:12 --> Output Class Initialized
INFO - 2023-02-17 05:48:12 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:12 --> Input Class Initialized
INFO - 2023-02-17 05:48:12 --> Language Class Initialized
INFO - 2023-02-17 05:48:12 --> Loader Class Initialized
INFO - 2023-02-17 05:48:12 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:12 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:12 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:12 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:12 --> Total execution time: 0.0130
INFO - 2023-02-17 05:48:12 --> Config Class Initialized
INFO - 2023-02-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:12 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:12 --> URI Class Initialized
INFO - 2023-02-17 05:48:12 --> Router Class Initialized
INFO - 2023-02-17 05:48:12 --> Output Class Initialized
INFO - 2023-02-17 05:48:12 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:12 --> Input Class Initialized
INFO - 2023-02-17 05:48:12 --> Language Class Initialized
INFO - 2023-02-17 05:48:12 --> Loader Class Initialized
INFO - 2023-02-17 05:48:12 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:12 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:12 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:12 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:12 --> Model "Login_model" initialized
INFO - 2023-02-17 05:48:12 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:12 --> Total execution time: 0.0461
INFO - 2023-02-17 05:48:12 --> Config Class Initialized
INFO - 2023-02-17 05:48:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:12 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:12 --> URI Class Initialized
INFO - 2023-02-17 05:48:12 --> Router Class Initialized
INFO - 2023-02-17 05:48:12 --> Output Class Initialized
INFO - 2023-02-17 05:48:12 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:12 --> Input Class Initialized
INFO - 2023-02-17 05:48:12 --> Language Class Initialized
INFO - 2023-02-17 05:48:12 --> Loader Class Initialized
INFO - 2023-02-17 05:48:12 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:12 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:12 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:12 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:12 --> Model "Login_model" initialized
INFO - 2023-02-17 05:48:12 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:12 --> Total execution time: 0.0419
INFO - 2023-02-17 05:48:14 --> Config Class Initialized
INFO - 2023-02-17 05:48:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:14 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:14 --> URI Class Initialized
INFO - 2023-02-17 05:48:14 --> Router Class Initialized
INFO - 2023-02-17 05:48:14 --> Output Class Initialized
INFO - 2023-02-17 05:48:14 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:14 --> Input Class Initialized
INFO - 2023-02-17 05:48:14 --> Language Class Initialized
INFO - 2023-02-17 05:48:14 --> Loader Class Initialized
INFO - 2023-02-17 05:48:14 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:14 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:14 --> Total execution time: 0.0045
INFO - 2023-02-17 05:48:14 --> Config Class Initialized
INFO - 2023-02-17 05:48:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:14 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:14 --> URI Class Initialized
INFO - 2023-02-17 05:48:14 --> Router Class Initialized
INFO - 2023-02-17 05:48:14 --> Output Class Initialized
INFO - 2023-02-17 05:48:14 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:14 --> Input Class Initialized
INFO - 2023-02-17 05:48:14 --> Language Class Initialized
INFO - 2023-02-17 05:48:14 --> Loader Class Initialized
INFO - 2023-02-17 05:48:14 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:14 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:14 --> Model "Login_model" initialized
INFO - 2023-02-17 05:48:14 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:14 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:14 --> Total execution time: 0.0210
INFO - 2023-02-17 05:48:14 --> Config Class Initialized
INFO - 2023-02-17 05:48:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:14 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:14 --> URI Class Initialized
INFO - 2023-02-17 05:48:14 --> Router Class Initialized
INFO - 2023-02-17 05:48:14 --> Output Class Initialized
INFO - 2023-02-17 05:48:14 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:14 --> Input Class Initialized
INFO - 2023-02-17 05:48:14 --> Language Class Initialized
INFO - 2023-02-17 05:48:14 --> Loader Class Initialized
INFO - 2023-02-17 05:48:14 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:14 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:14 --> Total execution time: 0.0459
INFO - 2023-02-17 05:48:14 --> Config Class Initialized
INFO - 2023-02-17 05:48:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:14 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:14 --> URI Class Initialized
INFO - 2023-02-17 05:48:14 --> Router Class Initialized
INFO - 2023-02-17 05:48:14 --> Output Class Initialized
INFO - 2023-02-17 05:48:14 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:14 --> Input Class Initialized
INFO - 2023-02-17 05:48:14 --> Language Class Initialized
INFO - 2023-02-17 05:48:14 --> Loader Class Initialized
INFO - 2023-02-17 05:48:14 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:14 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:14 --> Model "Login_model" initialized
INFO - 2023-02-17 05:48:14 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:14 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:14 --> Total execution time: 0.0196
INFO - 2023-02-17 05:48:15 --> Config Class Initialized
INFO - 2023-02-17 05:48:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:15 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:15 --> URI Class Initialized
INFO - 2023-02-17 05:48:15 --> Router Class Initialized
INFO - 2023-02-17 05:48:15 --> Output Class Initialized
INFO - 2023-02-17 05:48:15 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:15 --> Input Class Initialized
INFO - 2023-02-17 05:48:15 --> Language Class Initialized
INFO - 2023-02-17 05:48:15 --> Loader Class Initialized
INFO - 2023-02-17 05:48:15 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:15 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:15 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:15 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:15 --> Total execution time: 0.0185
INFO - 2023-02-17 05:48:15 --> Config Class Initialized
INFO - 2023-02-17 05:48:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:15 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:15 --> URI Class Initialized
INFO - 2023-02-17 05:48:15 --> Router Class Initialized
INFO - 2023-02-17 05:48:15 --> Output Class Initialized
INFO - 2023-02-17 05:48:15 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:15 --> Input Class Initialized
INFO - 2023-02-17 05:48:15 --> Language Class Initialized
INFO - 2023-02-17 05:48:15 --> Loader Class Initialized
INFO - 2023-02-17 05:48:15 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:15 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:15 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:15 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:15 --> Total execution time: 0.0521
INFO - 2023-02-17 05:48:24 --> Config Class Initialized
INFO - 2023-02-17 05:48:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:24 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:24 --> URI Class Initialized
INFO - 2023-02-17 05:48:24 --> Router Class Initialized
INFO - 2023-02-17 05:48:24 --> Output Class Initialized
INFO - 2023-02-17 05:48:24 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:24 --> Input Class Initialized
INFO - 2023-02-17 05:48:24 --> Language Class Initialized
INFO - 2023-02-17 05:48:24 --> Loader Class Initialized
INFO - 2023-02-17 05:48:24 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:24 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:24 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:24 --> Total execution time: 0.0205
INFO - 2023-02-17 05:48:24 --> Config Class Initialized
INFO - 2023-02-17 05:48:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:24 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:24 --> URI Class Initialized
INFO - 2023-02-17 05:48:24 --> Router Class Initialized
INFO - 2023-02-17 05:48:24 --> Output Class Initialized
INFO - 2023-02-17 05:48:24 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:24 --> Input Class Initialized
INFO - 2023-02-17 05:48:24 --> Language Class Initialized
INFO - 2023-02-17 05:48:24 --> Loader Class Initialized
INFO - 2023-02-17 05:48:24 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:24 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:24 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:24 --> Total execution time: 0.0134
INFO - 2023-02-17 05:48:25 --> Config Class Initialized
INFO - 2023-02-17 05:48:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:25 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:25 --> URI Class Initialized
INFO - 2023-02-17 05:48:25 --> Router Class Initialized
INFO - 2023-02-17 05:48:25 --> Output Class Initialized
INFO - 2023-02-17 05:48:25 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:25 --> Input Class Initialized
INFO - 2023-02-17 05:48:25 --> Language Class Initialized
INFO - 2023-02-17 05:48:25 --> Loader Class Initialized
INFO - 2023-02-17 05:48:25 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:25 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:25 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:25 --> Total execution time: 0.0158
INFO - 2023-02-17 05:48:25 --> Config Class Initialized
INFO - 2023-02-17 05:48:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:25 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:25 --> URI Class Initialized
INFO - 2023-02-17 05:48:25 --> Router Class Initialized
INFO - 2023-02-17 05:48:25 --> Output Class Initialized
INFO - 2023-02-17 05:48:25 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:25 --> Input Class Initialized
INFO - 2023-02-17 05:48:25 --> Language Class Initialized
INFO - 2023-02-17 05:48:25 --> Loader Class Initialized
INFO - 2023-02-17 05:48:25 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:25 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:25 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:25 --> Total execution time: 0.0118
INFO - 2023-02-17 05:48:28 --> Config Class Initialized
INFO - 2023-02-17 05:48:28 --> Config Class Initialized
INFO - 2023-02-17 05:48:28 --> Hooks Class Initialized
INFO - 2023-02-17 05:48:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:28 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 05:48:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:28 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:28 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:28 --> URI Class Initialized
INFO - 2023-02-17 05:48:28 --> URI Class Initialized
INFO - 2023-02-17 05:48:28 --> Router Class Initialized
INFO - 2023-02-17 05:48:28 --> Router Class Initialized
INFO - 2023-02-17 05:48:28 --> Output Class Initialized
INFO - 2023-02-17 05:48:28 --> Output Class Initialized
INFO - 2023-02-17 05:48:28 --> Security Class Initialized
INFO - 2023-02-17 05:48:28 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:28 --> Input Class Initialized
INFO - 2023-02-17 05:48:28 --> Input Class Initialized
INFO - 2023-02-17 05:48:28 --> Language Class Initialized
INFO - 2023-02-17 05:48:28 --> Language Class Initialized
INFO - 2023-02-17 05:48:28 --> Loader Class Initialized
INFO - 2023-02-17 05:48:28 --> Loader Class Initialized
INFO - 2023-02-17 05:48:28 --> Controller Class Initialized
INFO - 2023-02-17 05:48:28 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 05:48:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:28 --> Final output sent to browser
INFO - 2023-02-17 05:48:28 --> Database Driver Class Initialized
DEBUG - 2023-02-17 05:48:28 --> Total execution time: 0.0044
INFO - 2023-02-17 05:48:28 --> Config Class Initialized
INFO - 2023-02-17 05:48:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:28 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:28 --> URI Class Initialized
INFO - 2023-02-17 05:48:28 --> Router Class Initialized
INFO - 2023-02-17 05:48:28 --> Output Class Initialized
INFO - 2023-02-17 05:48:28 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:28 --> Input Class Initialized
INFO - 2023-02-17 05:48:28 --> Language Class Initialized
INFO - 2023-02-17 05:48:28 --> Loader Class Initialized
INFO - 2023-02-17 05:48:28 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:28 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:28 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:28 --> Total execution time: 0.0171
INFO - 2023-02-17 05:48:28 --> Model "Login_model" initialized
INFO - 2023-02-17 05:48:28 --> Config Class Initialized
INFO - 2023-02-17 05:48:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:48:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:48:28 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:28 --> Utf8 Class Initialized
INFO - 2023-02-17 05:48:28 --> URI Class Initialized
INFO - 2023-02-17 05:48:28 --> Router Class Initialized
INFO - 2023-02-17 05:48:28 --> Output Class Initialized
INFO - 2023-02-17 05:48:28 --> Security Class Initialized
DEBUG - 2023-02-17 05:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:48:28 --> Input Class Initialized
INFO - 2023-02-17 05:48:28 --> Language Class Initialized
INFO - 2023-02-17 05:48:28 --> Loader Class Initialized
INFO - 2023-02-17 05:48:28 --> Controller Class Initialized
DEBUG - 2023-02-17 05:48:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:48:28 --> Database Driver Class Initialized
INFO - 2023-02-17 05:48:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:48:28 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:28 --> Total execution time: 0.0221
INFO - 2023-02-17 05:48:28 --> Final output sent to browser
DEBUG - 2023-02-17 05:48:28 --> Total execution time: 0.0128
INFO - 2023-02-17 05:49:03 --> Config Class Initialized
INFO - 2023-02-17 05:49:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:49:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:49:03 --> Utf8 Class Initialized
INFO - 2023-02-17 05:49:03 --> URI Class Initialized
INFO - 2023-02-17 05:49:03 --> Router Class Initialized
INFO - 2023-02-17 05:49:03 --> Output Class Initialized
INFO - 2023-02-17 05:49:03 --> Security Class Initialized
DEBUG - 2023-02-17 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:49:03 --> Input Class Initialized
INFO - 2023-02-17 05:49:03 --> Language Class Initialized
INFO - 2023-02-17 05:49:03 --> Loader Class Initialized
INFO - 2023-02-17 05:49:03 --> Controller Class Initialized
DEBUG - 2023-02-17 05:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:49:03 --> Database Driver Class Initialized
INFO - 2023-02-17 05:49:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:49:03 --> Final output sent to browser
DEBUG - 2023-02-17 05:49:03 --> Total execution time: 0.0558
INFO - 2023-02-17 05:49:03 --> Config Class Initialized
INFO - 2023-02-17 05:49:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 05:49:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 05:49:03 --> Utf8 Class Initialized
INFO - 2023-02-17 05:49:03 --> URI Class Initialized
INFO - 2023-02-17 05:49:03 --> Router Class Initialized
INFO - 2023-02-17 05:49:03 --> Output Class Initialized
INFO - 2023-02-17 05:49:03 --> Security Class Initialized
DEBUG - 2023-02-17 05:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 05:49:03 --> Input Class Initialized
INFO - 2023-02-17 05:49:03 --> Language Class Initialized
INFO - 2023-02-17 05:49:03 --> Loader Class Initialized
INFO - 2023-02-17 05:49:03 --> Controller Class Initialized
DEBUG - 2023-02-17 05:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 05:49:03 --> Database Driver Class Initialized
INFO - 2023-02-17 05:49:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 05:49:03 --> Final output sent to browser
DEBUG - 2023-02-17 05:49:03 --> Total execution time: 0.0477
INFO - 2023-02-17 06:44:01 --> Config Class Initialized
INFO - 2023-02-17 06:44:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:44:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:44:01 --> Utf8 Class Initialized
INFO - 2023-02-17 06:44:01 --> URI Class Initialized
INFO - 2023-02-17 06:44:01 --> Router Class Initialized
INFO - 2023-02-17 06:44:01 --> Output Class Initialized
INFO - 2023-02-17 06:44:01 --> Security Class Initialized
DEBUG - 2023-02-17 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:44:01 --> Input Class Initialized
INFO - 2023-02-17 06:44:01 --> Language Class Initialized
INFO - 2023-02-17 06:44:01 --> Loader Class Initialized
INFO - 2023-02-17 06:44:01 --> Controller Class Initialized
INFO - 2023-02-17 06:44:01 --> Helper loaded: form_helper
INFO - 2023-02-17 06:44:01 --> Helper loaded: url_helper
DEBUG - 2023-02-17 06:44:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:44:01 --> Model "Change_model" initialized
INFO - 2023-02-17 06:44:01 --> Model "Grafana_model" initialized
INFO - 2023-02-17 06:44:01 --> Final output sent to browser
DEBUG - 2023-02-17 06:44:01 --> Total execution time: 0.0282
INFO - 2023-02-17 06:44:01 --> Config Class Initialized
INFO - 2023-02-17 06:44:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:44:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:44:01 --> Utf8 Class Initialized
INFO - 2023-02-17 06:44:01 --> URI Class Initialized
INFO - 2023-02-17 06:44:01 --> Router Class Initialized
INFO - 2023-02-17 06:44:01 --> Output Class Initialized
INFO - 2023-02-17 06:44:01 --> Security Class Initialized
DEBUG - 2023-02-17 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:44:01 --> Input Class Initialized
INFO - 2023-02-17 06:44:01 --> Language Class Initialized
INFO - 2023-02-17 06:44:01 --> Loader Class Initialized
INFO - 2023-02-17 06:44:01 --> Controller Class Initialized
INFO - 2023-02-17 06:44:01 --> Helper loaded: form_helper
INFO - 2023-02-17 06:44:01 --> Helper loaded: url_helper
DEBUG - 2023-02-17 06:44:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:44:01 --> Final output sent to browser
DEBUG - 2023-02-17 06:44:01 --> Total execution time: 0.0031
INFO - 2023-02-17 06:44:01 --> Config Class Initialized
INFO - 2023-02-17 06:44:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:44:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:44:01 --> Utf8 Class Initialized
INFO - 2023-02-17 06:44:01 --> URI Class Initialized
INFO - 2023-02-17 06:44:01 --> Router Class Initialized
INFO - 2023-02-17 06:44:01 --> Output Class Initialized
INFO - 2023-02-17 06:44:01 --> Security Class Initialized
DEBUG - 2023-02-17 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:44:01 --> Input Class Initialized
INFO - 2023-02-17 06:44:01 --> Language Class Initialized
INFO - 2023-02-17 06:44:01 --> Loader Class Initialized
INFO - 2023-02-17 06:44:01 --> Controller Class Initialized
INFO - 2023-02-17 06:44:01 --> Helper loaded: form_helper
INFO - 2023-02-17 06:44:01 --> Helper loaded: url_helper
DEBUG - 2023-02-17 06:44:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:44:01 --> Database Driver Class Initialized
INFO - 2023-02-17 06:44:01 --> Model "Login_model" initialized
INFO - 2023-02-17 06:44:01 --> Final output sent to browser
DEBUG - 2023-02-17 06:44:01 --> Total execution time: 0.1001
INFO - 2023-02-17 06:44:01 --> Config Class Initialized
INFO - 2023-02-17 06:44:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:44:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:44:01 --> Utf8 Class Initialized
INFO - 2023-02-17 06:44:01 --> URI Class Initialized
INFO - 2023-02-17 06:44:01 --> Router Class Initialized
INFO - 2023-02-17 06:44:01 --> Output Class Initialized
INFO - 2023-02-17 06:44:01 --> Security Class Initialized
DEBUG - 2023-02-17 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:44:01 --> Input Class Initialized
INFO - 2023-02-17 06:44:01 --> Language Class Initialized
INFO - 2023-02-17 06:44:01 --> Loader Class Initialized
INFO - 2023-02-17 06:44:01 --> Controller Class Initialized
DEBUG - 2023-02-17 06:44:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:44:01 --> Database Driver Class Initialized
INFO - 2023-02-17 06:44:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:44:01 --> Final output sent to browser
DEBUG - 2023-02-17 06:44:01 --> Total execution time: 0.0534
INFO - 2023-02-17 06:44:01 --> Config Class Initialized
INFO - 2023-02-17 06:44:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:44:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:44:01 --> Utf8 Class Initialized
INFO - 2023-02-17 06:44:01 --> URI Class Initialized
INFO - 2023-02-17 06:44:01 --> Router Class Initialized
INFO - 2023-02-17 06:44:01 --> Output Class Initialized
INFO - 2023-02-17 06:44:01 --> Security Class Initialized
DEBUG - 2023-02-17 06:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:44:01 --> Input Class Initialized
INFO - 2023-02-17 06:44:01 --> Language Class Initialized
INFO - 2023-02-17 06:44:01 --> Loader Class Initialized
INFO - 2023-02-17 06:44:01 --> Controller Class Initialized
DEBUG - 2023-02-17 06:44:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:44:01 --> Database Driver Class Initialized
INFO - 2023-02-17 06:44:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:44:01 --> Final output sent to browser
DEBUG - 2023-02-17 06:44:01 --> Total execution time: 0.0163
INFO - 2023-02-17 06:44:02 --> Config Class Initialized
INFO - 2023-02-17 06:44:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:44:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:44:02 --> Utf8 Class Initialized
INFO - 2023-02-17 06:44:02 --> URI Class Initialized
INFO - 2023-02-17 06:44:02 --> Router Class Initialized
INFO - 2023-02-17 06:44:02 --> Output Class Initialized
INFO - 2023-02-17 06:44:02 --> Security Class Initialized
DEBUG - 2023-02-17 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:44:02 --> Input Class Initialized
INFO - 2023-02-17 06:44:02 --> Language Class Initialized
INFO - 2023-02-17 06:44:02 --> Loader Class Initialized
INFO - 2023-02-17 06:44:02 --> Controller Class Initialized
DEBUG - 2023-02-17 06:44:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:44:02 --> Database Driver Class Initialized
INFO - 2023-02-17 06:44:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:44:02 --> Database Driver Class Initialized
INFO - 2023-02-17 06:44:02 --> Model "Login_model" initialized
INFO - 2023-02-17 06:44:02 --> Final output sent to browser
DEBUG - 2023-02-17 06:44:02 --> Total execution time: 0.0467
INFO - 2023-02-17 06:44:02 --> Config Class Initialized
INFO - 2023-02-17 06:44:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:44:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:44:02 --> Utf8 Class Initialized
INFO - 2023-02-17 06:44:02 --> URI Class Initialized
INFO - 2023-02-17 06:44:02 --> Router Class Initialized
INFO - 2023-02-17 06:44:02 --> Output Class Initialized
INFO - 2023-02-17 06:44:02 --> Security Class Initialized
DEBUG - 2023-02-17 06:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:44:02 --> Input Class Initialized
INFO - 2023-02-17 06:44:02 --> Language Class Initialized
INFO - 2023-02-17 06:44:02 --> Loader Class Initialized
INFO - 2023-02-17 06:44:02 --> Controller Class Initialized
DEBUG - 2023-02-17 06:44:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:44:02 --> Database Driver Class Initialized
INFO - 2023-02-17 06:44:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:44:02 --> Database Driver Class Initialized
INFO - 2023-02-17 06:44:02 --> Model "Login_model" initialized
INFO - 2023-02-17 06:44:02 --> Final output sent to browser
DEBUG - 2023-02-17 06:44:02 --> Total execution time: 0.0756
INFO - 2023-02-17 06:46:24 --> Config Class Initialized
INFO - 2023-02-17 06:46:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:46:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:46:24 --> Utf8 Class Initialized
INFO - 2023-02-17 06:46:24 --> URI Class Initialized
INFO - 2023-02-17 06:46:24 --> Router Class Initialized
INFO - 2023-02-17 06:46:24 --> Output Class Initialized
INFO - 2023-02-17 06:46:24 --> Security Class Initialized
DEBUG - 2023-02-17 06:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:46:24 --> Input Class Initialized
INFO - 2023-02-17 06:46:24 --> Language Class Initialized
INFO - 2023-02-17 06:46:24 --> Loader Class Initialized
INFO - 2023-02-17 06:46:24 --> Controller Class Initialized
DEBUG - 2023-02-17 06:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:46:24 --> Database Driver Class Initialized
INFO - 2023-02-17 06:46:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:46:24 --> Final output sent to browser
DEBUG - 2023-02-17 06:46:24 --> Total execution time: 0.0177
INFO - 2023-02-17 06:46:24 --> Config Class Initialized
INFO - 2023-02-17 06:46:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:46:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:46:24 --> Utf8 Class Initialized
INFO - 2023-02-17 06:46:24 --> URI Class Initialized
INFO - 2023-02-17 06:46:24 --> Router Class Initialized
INFO - 2023-02-17 06:46:24 --> Output Class Initialized
INFO - 2023-02-17 06:46:24 --> Security Class Initialized
DEBUG - 2023-02-17 06:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:46:24 --> Input Class Initialized
INFO - 2023-02-17 06:46:24 --> Language Class Initialized
INFO - 2023-02-17 06:46:24 --> Loader Class Initialized
INFO - 2023-02-17 06:46:24 --> Controller Class Initialized
DEBUG - 2023-02-17 06:46:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:46:24 --> Database Driver Class Initialized
INFO - 2023-02-17 06:46:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:46:24 --> Final output sent to browser
DEBUG - 2023-02-17 06:46:24 --> Total execution time: 0.0591
INFO - 2023-02-17 06:46:26 --> Config Class Initialized
INFO - 2023-02-17 06:46:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:46:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:46:26 --> Utf8 Class Initialized
INFO - 2023-02-17 06:46:26 --> URI Class Initialized
INFO - 2023-02-17 06:46:26 --> Router Class Initialized
INFO - 2023-02-17 06:46:26 --> Output Class Initialized
INFO - 2023-02-17 06:46:26 --> Security Class Initialized
DEBUG - 2023-02-17 06:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:46:26 --> Input Class Initialized
INFO - 2023-02-17 06:46:26 --> Language Class Initialized
INFO - 2023-02-17 06:46:26 --> Loader Class Initialized
INFO - 2023-02-17 06:46:26 --> Controller Class Initialized
DEBUG - 2023-02-17 06:46:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:46:26 --> Database Driver Class Initialized
INFO - 2023-02-17 06:46:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:46:26 --> Final output sent to browser
DEBUG - 2023-02-17 06:46:26 --> Total execution time: 0.0503
INFO - 2023-02-17 06:46:26 --> Config Class Initialized
INFO - 2023-02-17 06:46:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:46:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:46:26 --> Utf8 Class Initialized
INFO - 2023-02-17 06:46:26 --> URI Class Initialized
INFO - 2023-02-17 06:46:26 --> Router Class Initialized
INFO - 2023-02-17 06:46:26 --> Output Class Initialized
INFO - 2023-02-17 06:46:26 --> Security Class Initialized
DEBUG - 2023-02-17 06:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:46:26 --> Input Class Initialized
INFO - 2023-02-17 06:46:26 --> Language Class Initialized
INFO - 2023-02-17 06:46:26 --> Loader Class Initialized
INFO - 2023-02-17 06:46:26 --> Controller Class Initialized
DEBUG - 2023-02-17 06:46:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:46:26 --> Database Driver Class Initialized
INFO - 2023-02-17 06:46:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:46:26 --> Final output sent to browser
DEBUG - 2023-02-17 06:46:26 --> Total execution time: 0.0888
INFO - 2023-02-17 06:46:29 --> Config Class Initialized
INFO - 2023-02-17 06:46:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:46:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:46:29 --> Utf8 Class Initialized
INFO - 2023-02-17 06:46:29 --> URI Class Initialized
INFO - 2023-02-17 06:46:29 --> Router Class Initialized
INFO - 2023-02-17 06:46:29 --> Output Class Initialized
INFO - 2023-02-17 06:46:29 --> Security Class Initialized
DEBUG - 2023-02-17 06:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:46:29 --> Input Class Initialized
INFO - 2023-02-17 06:46:29 --> Language Class Initialized
INFO - 2023-02-17 06:46:29 --> Loader Class Initialized
INFO - 2023-02-17 06:46:29 --> Controller Class Initialized
DEBUG - 2023-02-17 06:46:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:46:29 --> Database Driver Class Initialized
INFO - 2023-02-17 06:46:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:46:29 --> Final output sent to browser
DEBUG - 2023-02-17 06:46:29 --> Total execution time: 0.0179
INFO - 2023-02-17 06:46:29 --> Config Class Initialized
INFO - 2023-02-17 06:46:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:46:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:46:29 --> Utf8 Class Initialized
INFO - 2023-02-17 06:46:29 --> URI Class Initialized
INFO - 2023-02-17 06:46:29 --> Router Class Initialized
INFO - 2023-02-17 06:46:29 --> Output Class Initialized
INFO - 2023-02-17 06:46:29 --> Security Class Initialized
DEBUG - 2023-02-17 06:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:46:29 --> Input Class Initialized
INFO - 2023-02-17 06:46:29 --> Language Class Initialized
INFO - 2023-02-17 06:46:29 --> Loader Class Initialized
INFO - 2023-02-17 06:46:29 --> Controller Class Initialized
DEBUG - 2023-02-17 06:46:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:46:29 --> Database Driver Class Initialized
INFO - 2023-02-17 06:46:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:46:29 --> Final output sent to browser
DEBUG - 2023-02-17 06:46:29 --> Total execution time: 0.0138
INFO - 2023-02-17 06:53:02 --> Config Class Initialized
INFO - 2023-02-17 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:53:02 --> Utf8 Class Initialized
INFO - 2023-02-17 06:53:02 --> URI Class Initialized
INFO - 2023-02-17 06:53:02 --> Router Class Initialized
INFO - 2023-02-17 06:53:02 --> Output Class Initialized
INFO - 2023-02-17 06:53:02 --> Security Class Initialized
DEBUG - 2023-02-17 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:53:02 --> Input Class Initialized
INFO - 2023-02-17 06:53:02 --> Language Class Initialized
INFO - 2023-02-17 06:53:02 --> Loader Class Initialized
INFO - 2023-02-17 06:53:02 --> Controller Class Initialized
DEBUG - 2023-02-17 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:53:02 --> Database Driver Class Initialized
INFO - 2023-02-17 06:53:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:53:02 --> Final output sent to browser
DEBUG - 2023-02-17 06:53:02 --> Total execution time: 0.0435
INFO - 2023-02-17 06:53:02 --> Config Class Initialized
INFO - 2023-02-17 06:53:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:53:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:53:02 --> Utf8 Class Initialized
INFO - 2023-02-17 06:53:02 --> URI Class Initialized
INFO - 2023-02-17 06:53:02 --> Router Class Initialized
INFO - 2023-02-17 06:53:02 --> Output Class Initialized
INFO - 2023-02-17 06:53:02 --> Security Class Initialized
DEBUG - 2023-02-17 06:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:53:02 --> Input Class Initialized
INFO - 2023-02-17 06:53:02 --> Language Class Initialized
INFO - 2023-02-17 06:53:02 --> Loader Class Initialized
INFO - 2023-02-17 06:53:02 --> Controller Class Initialized
DEBUG - 2023-02-17 06:53:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:53:02 --> Database Driver Class Initialized
INFO - 2023-02-17 06:53:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:53:02 --> Final output sent to browser
DEBUG - 2023-02-17 06:53:02 --> Total execution time: 0.0801
INFO - 2023-02-17 06:53:04 --> Config Class Initialized
INFO - 2023-02-17 06:53:04 --> Config Class Initialized
INFO - 2023-02-17 06:53:04 --> Hooks Class Initialized
INFO - 2023-02-17 06:53:04 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 06:53:04 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:53:04 --> Utf8 Class Initialized
INFO - 2023-02-17 06:53:04 --> Utf8 Class Initialized
INFO - 2023-02-17 06:53:04 --> URI Class Initialized
INFO - 2023-02-17 06:53:04 --> URI Class Initialized
INFO - 2023-02-17 06:53:04 --> Router Class Initialized
INFO - 2023-02-17 06:53:04 --> Router Class Initialized
INFO - 2023-02-17 06:53:04 --> Output Class Initialized
INFO - 2023-02-17 06:53:04 --> Output Class Initialized
INFO - 2023-02-17 06:53:04 --> Security Class Initialized
INFO - 2023-02-17 06:53:04 --> Security Class Initialized
DEBUG - 2023-02-17 06:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 06:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:53:04 --> Input Class Initialized
INFO - 2023-02-17 06:53:04 --> Input Class Initialized
INFO - 2023-02-17 06:53:04 --> Language Class Initialized
INFO - 2023-02-17 06:53:04 --> Language Class Initialized
INFO - 2023-02-17 06:53:04 --> Loader Class Initialized
INFO - 2023-02-17 06:53:04 --> Loader Class Initialized
INFO - 2023-02-17 06:53:04 --> Controller Class Initialized
INFO - 2023-02-17 06:53:04 --> Controller Class Initialized
DEBUG - 2023-02-17 06:53:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 06:53:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:53:04 --> Final output sent to browser
DEBUG - 2023-02-17 06:53:04 --> Total execution time: 0.0026
INFO - 2023-02-17 06:53:04 --> Database Driver Class Initialized
INFO - 2023-02-17 06:53:04 --> Config Class Initialized
INFO - 2023-02-17 06:53:04 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:53:05 --> Hooks Class Initialized
INFO - 2023-02-17 06:53:05 --> Final output sent to browser
DEBUG - 2023-02-17 06:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 06:53:05 --> Total execution time: 0.0962
INFO - 2023-02-17 06:53:05 --> Utf8 Class Initialized
INFO - 2023-02-17 06:53:05 --> URI Class Initialized
INFO - 2023-02-17 06:53:05 --> Router Class Initialized
INFO - 2023-02-17 06:53:05 --> Output Class Initialized
INFO - 2023-02-17 06:53:05 --> Security Class Initialized
DEBUG - 2023-02-17 06:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:53:05 --> Input Class Initialized
INFO - 2023-02-17 06:53:05 --> Language Class Initialized
INFO - 2023-02-17 06:53:05 --> Loader Class Initialized
INFO - 2023-02-17 06:53:05 --> Controller Class Initialized
DEBUG - 2023-02-17 06:53:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:53:05 --> Config Class Initialized
INFO - 2023-02-17 06:53:05 --> Hooks Class Initialized
INFO - 2023-02-17 06:53:05 --> Database Driver Class Initialized
DEBUG - 2023-02-17 06:53:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:53:05 --> Utf8 Class Initialized
INFO - 2023-02-17 06:53:05 --> URI Class Initialized
INFO - 2023-02-17 06:53:05 --> Router Class Initialized
INFO - 2023-02-17 06:53:05 --> Output Class Initialized
INFO - 2023-02-17 06:53:05 --> Security Class Initialized
DEBUG - 2023-02-17 06:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:53:05 --> Input Class Initialized
INFO - 2023-02-17 06:53:05 --> Language Class Initialized
INFO - 2023-02-17 06:53:05 --> Loader Class Initialized
INFO - 2023-02-17 06:53:05 --> Controller Class Initialized
DEBUG - 2023-02-17 06:53:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:53:05 --> Database Driver Class Initialized
INFO - 2023-02-17 06:53:05 --> Model "Login_model" initialized
INFO - 2023-02-17 06:53:05 --> Database Driver Class Initialized
INFO - 2023-02-17 06:53:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:53:05 --> Final output sent to browser
DEBUG - 2023-02-17 06:53:05 --> Total execution time: 0.0441
INFO - 2023-02-17 06:53:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:53:05 --> Final output sent to browser
DEBUG - 2023-02-17 06:53:05 --> Total execution time: 0.3844
INFO - 2023-02-17 06:58:00 --> Config Class Initialized
INFO - 2023-02-17 06:58:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:58:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:58:00 --> Utf8 Class Initialized
INFO - 2023-02-17 06:58:00 --> URI Class Initialized
INFO - 2023-02-17 06:58:00 --> Router Class Initialized
INFO - 2023-02-17 06:58:00 --> Output Class Initialized
INFO - 2023-02-17 06:58:00 --> Security Class Initialized
DEBUG - 2023-02-17 06:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:58:00 --> Input Class Initialized
INFO - 2023-02-17 06:58:00 --> Language Class Initialized
INFO - 2023-02-17 06:58:00 --> Loader Class Initialized
INFO - 2023-02-17 06:58:00 --> Controller Class Initialized
DEBUG - 2023-02-17 06:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:58:00 --> Database Driver Class Initialized
INFO - 2023-02-17 06:58:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:58:00 --> Final output sent to browser
DEBUG - 2023-02-17 06:58:00 --> Total execution time: 0.0423
INFO - 2023-02-17 06:58:00 --> Config Class Initialized
INFO - 2023-02-17 06:58:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:58:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:58:00 --> Utf8 Class Initialized
INFO - 2023-02-17 06:58:00 --> URI Class Initialized
INFO - 2023-02-17 06:58:00 --> Router Class Initialized
INFO - 2023-02-17 06:58:00 --> Output Class Initialized
INFO - 2023-02-17 06:58:00 --> Security Class Initialized
DEBUG - 2023-02-17 06:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:58:00 --> Input Class Initialized
INFO - 2023-02-17 06:58:00 --> Language Class Initialized
INFO - 2023-02-17 06:58:00 --> Loader Class Initialized
INFO - 2023-02-17 06:58:00 --> Controller Class Initialized
DEBUG - 2023-02-17 06:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:58:00 --> Database Driver Class Initialized
INFO - 2023-02-17 06:58:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:58:00 --> Final output sent to browser
DEBUG - 2023-02-17 06:58:00 --> Total execution time: 0.0390
INFO - 2023-02-17 06:58:05 --> Config Class Initialized
INFO - 2023-02-17 06:58:05 --> Config Class Initialized
INFO - 2023-02-17 06:58:05 --> Hooks Class Initialized
INFO - 2023-02-17 06:58:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:58:05 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 06:58:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:58:05 --> Utf8 Class Initialized
INFO - 2023-02-17 06:58:05 --> Utf8 Class Initialized
INFO - 2023-02-17 06:58:05 --> URI Class Initialized
INFO - 2023-02-17 06:58:05 --> URI Class Initialized
INFO - 2023-02-17 06:58:05 --> Router Class Initialized
INFO - 2023-02-17 06:58:05 --> Router Class Initialized
INFO - 2023-02-17 06:58:05 --> Output Class Initialized
INFO - 2023-02-17 06:58:05 --> Output Class Initialized
INFO - 2023-02-17 06:58:05 --> Security Class Initialized
INFO - 2023-02-17 06:58:05 --> Security Class Initialized
DEBUG - 2023-02-17 06:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 06:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:58:05 --> Input Class Initialized
INFO - 2023-02-17 06:58:05 --> Input Class Initialized
INFO - 2023-02-17 06:58:05 --> Language Class Initialized
INFO - 2023-02-17 06:58:05 --> Language Class Initialized
INFO - 2023-02-17 06:58:05 --> Loader Class Initialized
INFO - 2023-02-17 06:58:05 --> Loader Class Initialized
INFO - 2023-02-17 06:58:05 --> Controller Class Initialized
INFO - 2023-02-17 06:58:05 --> Controller Class Initialized
DEBUG - 2023-02-17 06:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 06:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:58:05 --> Final output sent to browser
DEBUG - 2023-02-17 06:58:05 --> Total execution time: 0.0047
INFO - 2023-02-17 06:58:05 --> Database Driver Class Initialized
INFO - 2023-02-17 06:58:05 --> Config Class Initialized
INFO - 2023-02-17 06:58:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:58:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:58:05 --> Utf8 Class Initialized
INFO - 2023-02-17 06:58:05 --> URI Class Initialized
INFO - 2023-02-17 06:58:05 --> Router Class Initialized
INFO - 2023-02-17 06:58:05 --> Output Class Initialized
INFO - 2023-02-17 06:58:05 --> Security Class Initialized
DEBUG - 2023-02-17 06:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:58:05 --> Input Class Initialized
INFO - 2023-02-17 06:58:05 --> Language Class Initialized
INFO - 2023-02-17 06:58:05 --> Loader Class Initialized
INFO - 2023-02-17 06:58:05 --> Controller Class Initialized
DEBUG - 2023-02-17 06:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:58:05 --> Database Driver Class Initialized
INFO - 2023-02-17 06:58:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:58:05 --> Model "Login_model" initialized
INFO - 2023-02-17 06:58:05 --> Final output sent to browser
DEBUG - 2023-02-17 06:58:05 --> Total execution time: 0.0157
INFO - 2023-02-17 06:58:05 --> Database Driver Class Initialized
INFO - 2023-02-17 06:58:05 --> Config Class Initialized
INFO - 2023-02-17 06:58:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:58:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:58:05 --> Utf8 Class Initialized
INFO - 2023-02-17 06:58:05 --> URI Class Initialized
INFO - 2023-02-17 06:58:05 --> Router Class Initialized
INFO - 2023-02-17 06:58:05 --> Output Class Initialized
INFO - 2023-02-17 06:58:05 --> Security Class Initialized
DEBUG - 2023-02-17 06:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:58:05 --> Input Class Initialized
INFO - 2023-02-17 06:58:05 --> Language Class Initialized
INFO - 2023-02-17 06:58:05 --> Loader Class Initialized
INFO - 2023-02-17 06:58:05 --> Controller Class Initialized
DEBUG - 2023-02-17 06:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:58:05 --> Database Driver Class Initialized
INFO - 2023-02-17 06:58:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:58:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:58:05 --> Final output sent to browser
DEBUG - 2023-02-17 06:58:05 --> Total execution time: 0.0201
INFO - 2023-02-17 06:58:05 --> Final output sent to browser
DEBUG - 2023-02-17 06:58:05 --> Total execution time: 0.0125
INFO - 2023-02-17 06:58:08 --> Config Class Initialized
INFO - 2023-02-17 06:58:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:58:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:58:08 --> Utf8 Class Initialized
INFO - 2023-02-17 06:58:08 --> URI Class Initialized
INFO - 2023-02-17 06:58:08 --> Router Class Initialized
INFO - 2023-02-17 06:58:08 --> Output Class Initialized
INFO - 2023-02-17 06:58:08 --> Security Class Initialized
DEBUG - 2023-02-17 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:58:08 --> Input Class Initialized
INFO - 2023-02-17 06:58:08 --> Language Class Initialized
INFO - 2023-02-17 06:58:08 --> Loader Class Initialized
INFO - 2023-02-17 06:58:08 --> Controller Class Initialized
DEBUG - 2023-02-17 06:58:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:58:08 --> Database Driver Class Initialized
INFO - 2023-02-17 06:58:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:58:08 --> Final output sent to browser
DEBUG - 2023-02-17 06:58:08 --> Total execution time: 0.0163
INFO - 2023-02-17 06:58:08 --> Config Class Initialized
INFO - 2023-02-17 06:58:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 06:58:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 06:58:08 --> Utf8 Class Initialized
INFO - 2023-02-17 06:58:08 --> URI Class Initialized
INFO - 2023-02-17 06:58:08 --> Router Class Initialized
INFO - 2023-02-17 06:58:08 --> Output Class Initialized
INFO - 2023-02-17 06:58:08 --> Security Class Initialized
DEBUG - 2023-02-17 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 06:58:08 --> Input Class Initialized
INFO - 2023-02-17 06:58:08 --> Language Class Initialized
INFO - 2023-02-17 06:58:08 --> Loader Class Initialized
INFO - 2023-02-17 06:58:08 --> Controller Class Initialized
DEBUG - 2023-02-17 06:58:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 06:58:08 --> Database Driver Class Initialized
INFO - 2023-02-17 06:58:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 06:58:08 --> Final output sent to browser
DEBUG - 2023-02-17 06:58:08 --> Total execution time: 0.0552
INFO - 2023-02-17 07:05:00 --> Config Class Initialized
INFO - 2023-02-17 07:05:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:05:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:05:00 --> Utf8 Class Initialized
INFO - 2023-02-17 07:05:00 --> URI Class Initialized
INFO - 2023-02-17 07:05:00 --> Router Class Initialized
INFO - 2023-02-17 07:05:00 --> Output Class Initialized
INFO - 2023-02-17 07:05:00 --> Security Class Initialized
DEBUG - 2023-02-17 07:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:05:00 --> Input Class Initialized
INFO - 2023-02-17 07:05:00 --> Language Class Initialized
INFO - 2023-02-17 07:05:00 --> Loader Class Initialized
INFO - 2023-02-17 07:05:00 --> Controller Class Initialized
DEBUG - 2023-02-17 07:05:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:05:00 --> Database Driver Class Initialized
INFO - 2023-02-17 07:05:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:05:00 --> Final output sent to browser
DEBUG - 2023-02-17 07:05:00 --> Total execution time: 0.1005
INFO - 2023-02-17 07:05:00 --> Config Class Initialized
INFO - 2023-02-17 07:05:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:05:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:05:00 --> Utf8 Class Initialized
INFO - 2023-02-17 07:05:00 --> URI Class Initialized
INFO - 2023-02-17 07:05:00 --> Router Class Initialized
INFO - 2023-02-17 07:05:00 --> Output Class Initialized
INFO - 2023-02-17 07:05:00 --> Security Class Initialized
DEBUG - 2023-02-17 07:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:05:00 --> Input Class Initialized
INFO - 2023-02-17 07:05:00 --> Language Class Initialized
INFO - 2023-02-17 07:05:00 --> Loader Class Initialized
INFO - 2023-02-17 07:05:00 --> Controller Class Initialized
DEBUG - 2023-02-17 07:05:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:05:00 --> Database Driver Class Initialized
INFO - 2023-02-17 07:05:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:05:00 --> Final output sent to browser
DEBUG - 2023-02-17 07:05:00 --> Total execution time: 0.0122
INFO - 2023-02-17 07:05:05 --> Config Class Initialized
INFO - 2023-02-17 07:05:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:05:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:05:05 --> Utf8 Class Initialized
INFO - 2023-02-17 07:05:05 --> URI Class Initialized
INFO - 2023-02-17 07:05:05 --> Router Class Initialized
INFO - 2023-02-17 07:05:05 --> Output Class Initialized
INFO - 2023-02-17 07:05:05 --> Security Class Initialized
DEBUG - 2023-02-17 07:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:05:05 --> Input Class Initialized
INFO - 2023-02-17 07:05:05 --> Language Class Initialized
INFO - 2023-02-17 07:05:05 --> Loader Class Initialized
INFO - 2023-02-17 07:05:05 --> Controller Class Initialized
DEBUG - 2023-02-17 07:05:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:05:05 --> Database Driver Class Initialized
INFO - 2023-02-17 07:05:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:05:05 --> Final output sent to browser
DEBUG - 2023-02-17 07:05:05 --> Total execution time: 0.0449
INFO - 2023-02-17 07:05:05 --> Config Class Initialized
INFO - 2023-02-17 07:05:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:05:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:05:05 --> Utf8 Class Initialized
INFO - 2023-02-17 07:05:05 --> URI Class Initialized
INFO - 2023-02-17 07:05:05 --> Router Class Initialized
INFO - 2023-02-17 07:05:05 --> Output Class Initialized
INFO - 2023-02-17 07:05:05 --> Security Class Initialized
DEBUG - 2023-02-17 07:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:05:05 --> Input Class Initialized
INFO - 2023-02-17 07:05:05 --> Language Class Initialized
INFO - 2023-02-17 07:05:05 --> Loader Class Initialized
INFO - 2023-02-17 07:05:05 --> Controller Class Initialized
DEBUG - 2023-02-17 07:05:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:05:05 --> Database Driver Class Initialized
INFO - 2023-02-17 07:05:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:05:05 --> Final output sent to browser
DEBUG - 2023-02-17 07:05:05 --> Total execution time: 0.0864
INFO - 2023-02-17 07:05:08 --> Config Class Initialized
INFO - 2023-02-17 07:05:08 --> Config Class Initialized
INFO - 2023-02-17 07:05:08 --> Hooks Class Initialized
INFO - 2023-02-17 07:05:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:05:08 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 07:05:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:05:08 --> Utf8 Class Initialized
INFO - 2023-02-17 07:05:08 --> Utf8 Class Initialized
INFO - 2023-02-17 07:05:08 --> URI Class Initialized
INFO - 2023-02-17 07:05:08 --> URI Class Initialized
INFO - 2023-02-17 07:05:08 --> Router Class Initialized
INFO - 2023-02-17 07:05:08 --> Router Class Initialized
INFO - 2023-02-17 07:05:08 --> Output Class Initialized
INFO - 2023-02-17 07:05:08 --> Output Class Initialized
INFO - 2023-02-17 07:05:08 --> Security Class Initialized
INFO - 2023-02-17 07:05:08 --> Security Class Initialized
DEBUG - 2023-02-17 07:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 07:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:05:08 --> Input Class Initialized
INFO - 2023-02-17 07:05:08 --> Input Class Initialized
INFO - 2023-02-17 07:05:08 --> Language Class Initialized
INFO - 2023-02-17 07:05:08 --> Language Class Initialized
INFO - 2023-02-17 07:05:08 --> Loader Class Initialized
INFO - 2023-02-17 07:05:08 --> Loader Class Initialized
INFO - 2023-02-17 07:05:08 --> Controller Class Initialized
INFO - 2023-02-17 07:05:08 --> Controller Class Initialized
DEBUG - 2023-02-17 07:05:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 07:05:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:05:08 --> Final output sent to browser
DEBUG - 2023-02-17 07:05:08 --> Total execution time: 0.0047
INFO - 2023-02-17 07:05:08 --> Database Driver Class Initialized
INFO - 2023-02-17 07:05:08 --> Config Class Initialized
INFO - 2023-02-17 07:05:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:05:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:05:08 --> Utf8 Class Initialized
INFO - 2023-02-17 07:05:08 --> URI Class Initialized
INFO - 2023-02-17 07:05:08 --> Router Class Initialized
INFO - 2023-02-17 07:05:08 --> Output Class Initialized
INFO - 2023-02-17 07:05:08 --> Security Class Initialized
DEBUG - 2023-02-17 07:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:05:08 --> Input Class Initialized
INFO - 2023-02-17 07:05:08 --> Language Class Initialized
INFO - 2023-02-17 07:05:08 --> Loader Class Initialized
INFO - 2023-02-17 07:05:08 --> Controller Class Initialized
DEBUG - 2023-02-17 07:05:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:05:08 --> Database Driver Class Initialized
INFO - 2023-02-17 07:05:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:05:08 --> Model "Login_model" initialized
INFO - 2023-02-17 07:05:08 --> Database Driver Class Initialized
INFO - 2023-02-17 07:05:08 --> Final output sent to browser
DEBUG - 2023-02-17 07:05:08 --> Total execution time: 0.0195
INFO - 2023-02-17 07:05:08 --> Config Class Initialized
INFO - 2023-02-17 07:05:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:05:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:05:08 --> Utf8 Class Initialized
INFO - 2023-02-17 07:05:08 --> URI Class Initialized
INFO - 2023-02-17 07:05:08 --> Router Class Initialized
INFO - 2023-02-17 07:05:08 --> Output Class Initialized
INFO - 2023-02-17 07:05:08 --> Security Class Initialized
DEBUG - 2023-02-17 07:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:05:08 --> Input Class Initialized
INFO - 2023-02-17 07:05:08 --> Language Class Initialized
INFO - 2023-02-17 07:05:08 --> Loader Class Initialized
INFO - 2023-02-17 07:05:08 --> Controller Class Initialized
DEBUG - 2023-02-17 07:05:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:05:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:05:08 --> Database Driver Class Initialized
INFO - 2023-02-17 07:05:08 --> Final output sent to browser
DEBUG - 2023-02-17 07:05:08 --> Total execution time: 0.0204
INFO - 2023-02-17 07:05:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:05:08 --> Final output sent to browser
DEBUG - 2023-02-17 07:05:08 --> Total execution time: 0.0560
INFO - 2023-02-17 07:06:19 --> Config Class Initialized
INFO - 2023-02-17 07:06:19 --> Config Class Initialized
INFO - 2023-02-17 07:06:19 --> Hooks Class Initialized
INFO - 2023-02-17 07:06:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 07:06:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:19 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:19 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:19 --> URI Class Initialized
INFO - 2023-02-17 07:06:19 --> URI Class Initialized
INFO - 2023-02-17 07:06:19 --> Router Class Initialized
INFO - 2023-02-17 07:06:19 --> Router Class Initialized
INFO - 2023-02-17 07:06:19 --> Output Class Initialized
INFO - 2023-02-17 07:06:19 --> Output Class Initialized
INFO - 2023-02-17 07:06:19 --> Security Class Initialized
INFO - 2023-02-17 07:06:19 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:19 --> Input Class Initialized
INFO - 2023-02-17 07:06:19 --> Input Class Initialized
INFO - 2023-02-17 07:06:19 --> Language Class Initialized
INFO - 2023-02-17 07:06:19 --> Language Class Initialized
INFO - 2023-02-17 07:06:19 --> Loader Class Initialized
INFO - 2023-02-17 07:06:19 --> Loader Class Initialized
INFO - 2023-02-17 07:06:19 --> Controller Class Initialized
INFO - 2023-02-17 07:06:19 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 07:06:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:19 --> Final output sent to browser
INFO - 2023-02-17 07:06:19 --> Database Driver Class Initialized
DEBUG - 2023-02-17 07:06:19 --> Total execution time: 0.0417
INFO - 2023-02-17 07:06:19 --> Config Class Initialized
INFO - 2023-02-17 07:06:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:19 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:19 --> URI Class Initialized
INFO - 2023-02-17 07:06:19 --> Router Class Initialized
INFO - 2023-02-17 07:06:19 --> Output Class Initialized
INFO - 2023-02-17 07:06:19 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:19 --> Input Class Initialized
INFO - 2023-02-17 07:06:19 --> Language Class Initialized
INFO - 2023-02-17 07:06:19 --> Loader Class Initialized
INFO - 2023-02-17 07:06:19 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:19 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:19 --> Model "Login_model" initialized
INFO - 2023-02-17 07:06:19 --> Final output sent to browser
INFO - 2023-02-17 07:06:19 --> Database Driver Class Initialized
DEBUG - 2023-02-17 07:06:19 --> Total execution time: 0.0598
INFO - 2023-02-17 07:06:19 --> Config Class Initialized
INFO - 2023-02-17 07:06:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:19 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:19 --> URI Class Initialized
INFO - 2023-02-17 07:06:19 --> Router Class Initialized
INFO - 2023-02-17 07:06:19 --> Output Class Initialized
INFO - 2023-02-17 07:06:19 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:19 --> Input Class Initialized
INFO - 2023-02-17 07:06:19 --> Language Class Initialized
INFO - 2023-02-17 07:06:19 --> Loader Class Initialized
INFO - 2023-02-17 07:06:19 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:19 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:19 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:19 --> Total execution time: 0.1420
INFO - 2023-02-17 07:06:19 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:20 --> Total execution time: 0.0876
INFO - 2023-02-17 07:06:26 --> Config Class Initialized
INFO - 2023-02-17 07:06:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:26 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:26 --> URI Class Initialized
INFO - 2023-02-17 07:06:26 --> Router Class Initialized
INFO - 2023-02-17 07:06:26 --> Output Class Initialized
INFO - 2023-02-17 07:06:26 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:26 --> Input Class Initialized
INFO - 2023-02-17 07:06:26 --> Language Class Initialized
INFO - 2023-02-17 07:06:26 --> Loader Class Initialized
INFO - 2023-02-17 07:06:26 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:26 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:26 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:26 --> Model "Login_model" initialized
INFO - 2023-02-17 07:06:26 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:26 --> Total execution time: 0.0507
INFO - 2023-02-17 07:06:26 --> Config Class Initialized
INFO - 2023-02-17 07:06:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:26 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:26 --> URI Class Initialized
INFO - 2023-02-17 07:06:26 --> Router Class Initialized
INFO - 2023-02-17 07:06:26 --> Output Class Initialized
INFO - 2023-02-17 07:06:26 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:26 --> Input Class Initialized
INFO - 2023-02-17 07:06:26 --> Language Class Initialized
INFO - 2023-02-17 07:06:26 --> Loader Class Initialized
INFO - 2023-02-17 07:06:26 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:26 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:26 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:26 --> Model "Login_model" initialized
INFO - 2023-02-17 07:06:26 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:26 --> Total execution time: 0.0792
INFO - 2023-02-17 07:06:30 --> Config Class Initialized
INFO - 2023-02-17 07:06:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:30 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:30 --> URI Class Initialized
INFO - 2023-02-17 07:06:30 --> Router Class Initialized
INFO - 2023-02-17 07:06:30 --> Output Class Initialized
INFO - 2023-02-17 07:06:30 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:30 --> Input Class Initialized
INFO - 2023-02-17 07:06:30 --> Language Class Initialized
INFO - 2023-02-17 07:06:30 --> Loader Class Initialized
INFO - 2023-02-17 07:06:30 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:30 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:30 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:30 --> Total execution time: 0.0183
INFO - 2023-02-17 07:06:30 --> Config Class Initialized
INFO - 2023-02-17 07:06:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:30 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:30 --> URI Class Initialized
INFO - 2023-02-17 07:06:30 --> Router Class Initialized
INFO - 2023-02-17 07:06:30 --> Output Class Initialized
INFO - 2023-02-17 07:06:30 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:30 --> Input Class Initialized
INFO - 2023-02-17 07:06:30 --> Language Class Initialized
INFO - 2023-02-17 07:06:30 --> Loader Class Initialized
INFO - 2023-02-17 07:06:30 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:30 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:30 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:30 --> Total execution time: 0.0584
INFO - 2023-02-17 07:06:35 --> Config Class Initialized
INFO - 2023-02-17 07:06:35 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:35 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:35 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:35 --> URI Class Initialized
INFO - 2023-02-17 07:06:35 --> Router Class Initialized
INFO - 2023-02-17 07:06:35 --> Output Class Initialized
INFO - 2023-02-17 07:06:35 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:35 --> Input Class Initialized
INFO - 2023-02-17 07:06:35 --> Language Class Initialized
INFO - 2023-02-17 07:06:35 --> Loader Class Initialized
INFO - 2023-02-17 07:06:35 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:35 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:35 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:35 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:35 --> Total execution time: 0.0152
INFO - 2023-02-17 07:06:35 --> Config Class Initialized
INFO - 2023-02-17 07:06:35 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:35 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:35 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:35 --> URI Class Initialized
INFO - 2023-02-17 07:06:35 --> Router Class Initialized
INFO - 2023-02-17 07:06:35 --> Output Class Initialized
INFO - 2023-02-17 07:06:35 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:35 --> Input Class Initialized
INFO - 2023-02-17 07:06:35 --> Language Class Initialized
INFO - 2023-02-17 07:06:35 --> Loader Class Initialized
INFO - 2023-02-17 07:06:35 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:35 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:35 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:35 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:35 --> Total execution time: 0.0522
INFO - 2023-02-17 07:06:38 --> Config Class Initialized
INFO - 2023-02-17 07:06:38 --> Config Class Initialized
INFO - 2023-02-17 07:06:38 --> Hooks Class Initialized
INFO - 2023-02-17 07:06:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:38 --> Utf8 Class Initialized
DEBUG - 2023-02-17 07:06:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:38 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:38 --> URI Class Initialized
INFO - 2023-02-17 07:06:38 --> URI Class Initialized
INFO - 2023-02-17 07:06:38 --> Router Class Initialized
INFO - 2023-02-17 07:06:38 --> Router Class Initialized
INFO - 2023-02-17 07:06:38 --> Output Class Initialized
INFO - 2023-02-17 07:06:38 --> Output Class Initialized
INFO - 2023-02-17 07:06:38 --> Security Class Initialized
INFO - 2023-02-17 07:06:38 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 07:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:38 --> Input Class Initialized
INFO - 2023-02-17 07:06:38 --> Input Class Initialized
INFO - 2023-02-17 07:06:38 --> Language Class Initialized
INFO - 2023-02-17 07:06:38 --> Language Class Initialized
INFO - 2023-02-17 07:06:38 --> Loader Class Initialized
INFO - 2023-02-17 07:06:38 --> Loader Class Initialized
INFO - 2023-02-17 07:06:38 --> Controller Class Initialized
INFO - 2023-02-17 07:06:38 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 07:06:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:38 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:38 --> Total execution time: 0.0044
INFO - 2023-02-17 07:06:38 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:38 --> Config Class Initialized
INFO - 2023-02-17 07:06:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:38 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:38 --> URI Class Initialized
INFO - 2023-02-17 07:06:38 --> Router Class Initialized
INFO - 2023-02-17 07:06:38 --> Output Class Initialized
INFO - 2023-02-17 07:06:38 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:38 --> Input Class Initialized
INFO - 2023-02-17 07:06:38 --> Language Class Initialized
INFO - 2023-02-17 07:06:38 --> Loader Class Initialized
INFO - 2023-02-17 07:06:38 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:38 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:38 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:38 --> Total execution time: 0.0144
INFO - 2023-02-17 07:06:38 --> Model "Login_model" initialized
INFO - 2023-02-17 07:06:38 --> Config Class Initialized
INFO - 2023-02-17 07:06:38 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:38 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:38 --> URI Class Initialized
INFO - 2023-02-17 07:06:38 --> Router Class Initialized
INFO - 2023-02-17 07:06:38 --> Output Class Initialized
INFO - 2023-02-17 07:06:38 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:38 --> Input Class Initialized
INFO - 2023-02-17 07:06:38 --> Language Class Initialized
INFO - 2023-02-17 07:06:38 --> Loader Class Initialized
INFO - 2023-02-17 07:06:38 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:38 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:38 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:38 --> Total execution time: 0.0179
INFO - 2023-02-17 07:06:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:38 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:38 --> Total execution time: 0.0523
INFO - 2023-02-17 07:06:41 --> Config Class Initialized
INFO - 2023-02-17 07:06:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:41 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:41 --> URI Class Initialized
INFO - 2023-02-17 07:06:41 --> Router Class Initialized
INFO - 2023-02-17 07:06:41 --> Output Class Initialized
INFO - 2023-02-17 07:06:41 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:41 --> Input Class Initialized
INFO - 2023-02-17 07:06:41 --> Language Class Initialized
INFO - 2023-02-17 07:06:41 --> Loader Class Initialized
INFO - 2023-02-17 07:06:41 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:41 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:41 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:41 --> Total execution time: 0.0202
INFO - 2023-02-17 07:06:41 --> Config Class Initialized
INFO - 2023-02-17 07:06:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:41 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:41 --> URI Class Initialized
INFO - 2023-02-17 07:06:41 --> Router Class Initialized
INFO - 2023-02-17 07:06:41 --> Output Class Initialized
INFO - 2023-02-17 07:06:41 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:41 --> Input Class Initialized
INFO - 2023-02-17 07:06:41 --> Language Class Initialized
INFO - 2023-02-17 07:06:41 --> Loader Class Initialized
INFO - 2023-02-17 07:06:41 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:41 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:41 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:41 --> Total execution time: 0.0112
INFO - 2023-02-17 07:06:44 --> Config Class Initialized
INFO - 2023-02-17 07:06:44 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:44 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:44 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:44 --> URI Class Initialized
INFO - 2023-02-17 07:06:44 --> Router Class Initialized
INFO - 2023-02-17 07:06:44 --> Output Class Initialized
INFO - 2023-02-17 07:06:44 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:44 --> Input Class Initialized
INFO - 2023-02-17 07:06:44 --> Language Class Initialized
INFO - 2023-02-17 07:06:44 --> Loader Class Initialized
INFO - 2023-02-17 07:06:44 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:44 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:44 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:44 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:44 --> Model "Login_model" initialized
INFO - 2023-02-17 07:06:44 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:44 --> Total execution time: 0.0421
INFO - 2023-02-17 07:06:44 --> Config Class Initialized
INFO - 2023-02-17 07:06:44 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:44 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:44 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:44 --> URI Class Initialized
INFO - 2023-02-17 07:06:44 --> Router Class Initialized
INFO - 2023-02-17 07:06:44 --> Output Class Initialized
INFO - 2023-02-17 07:06:44 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:44 --> Input Class Initialized
INFO - 2023-02-17 07:06:44 --> Language Class Initialized
INFO - 2023-02-17 07:06:44 --> Loader Class Initialized
INFO - 2023-02-17 07:06:44 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:44 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:44 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:44 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:44 --> Model "Login_model" initialized
INFO - 2023-02-17 07:06:44 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:44 --> Total execution time: 0.0368
INFO - 2023-02-17 07:06:46 --> Config Class Initialized
INFO - 2023-02-17 07:06:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:46 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:46 --> URI Class Initialized
INFO - 2023-02-17 07:06:46 --> Router Class Initialized
INFO - 2023-02-17 07:06:46 --> Output Class Initialized
INFO - 2023-02-17 07:06:46 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:46 --> Input Class Initialized
INFO - 2023-02-17 07:06:46 --> Language Class Initialized
INFO - 2023-02-17 07:06:46 --> Loader Class Initialized
INFO - 2023-02-17 07:06:46 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:46 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:46 --> Total execution time: 0.0041
INFO - 2023-02-17 07:06:46 --> Config Class Initialized
INFO - 2023-02-17 07:06:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:46 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:46 --> URI Class Initialized
INFO - 2023-02-17 07:06:46 --> Router Class Initialized
INFO - 2023-02-17 07:06:46 --> Output Class Initialized
INFO - 2023-02-17 07:06:46 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:46 --> Input Class Initialized
INFO - 2023-02-17 07:06:46 --> Language Class Initialized
INFO - 2023-02-17 07:06:46 --> Loader Class Initialized
INFO - 2023-02-17 07:06:46 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:46 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:46 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:46 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:46 --> Total execution time: 0.0115
INFO - 2023-02-17 07:06:46 --> Config Class Initialized
INFO - 2023-02-17 07:06:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:46 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:46 --> URI Class Initialized
INFO - 2023-02-17 07:06:46 --> Router Class Initialized
INFO - 2023-02-17 07:06:46 --> Output Class Initialized
INFO - 2023-02-17 07:06:46 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:46 --> Input Class Initialized
INFO - 2023-02-17 07:06:46 --> Language Class Initialized
INFO - 2023-02-17 07:06:46 --> Loader Class Initialized
INFO - 2023-02-17 07:06:46 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:46 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:46 --> Total execution time: 0.0456
INFO - 2023-02-17 07:06:46 --> Config Class Initialized
INFO - 2023-02-17 07:06:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:06:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:06:46 --> Utf8 Class Initialized
INFO - 2023-02-17 07:06:46 --> URI Class Initialized
INFO - 2023-02-17 07:06:46 --> Router Class Initialized
INFO - 2023-02-17 07:06:46 --> Output Class Initialized
INFO - 2023-02-17 07:06:46 --> Security Class Initialized
DEBUG - 2023-02-17 07:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:06:46 --> Input Class Initialized
INFO - 2023-02-17 07:06:46 --> Language Class Initialized
INFO - 2023-02-17 07:06:46 --> Loader Class Initialized
INFO - 2023-02-17 07:06:46 --> Controller Class Initialized
DEBUG - 2023-02-17 07:06:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:06:46 --> Database Driver Class Initialized
INFO - 2023-02-17 07:06:46 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:06:46 --> Final output sent to browser
DEBUG - 2023-02-17 07:06:46 --> Total execution time: 0.0109
INFO - 2023-02-17 07:07:00 --> Config Class Initialized
INFO - 2023-02-17 07:07:00 --> Config Class Initialized
INFO - 2023-02-17 07:07:00 --> Hooks Class Initialized
INFO - 2023-02-17 07:07:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:00 --> Utf8 Class Initialized
DEBUG - 2023-02-17 07:07:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:00 --> URI Class Initialized
INFO - 2023-02-17 07:07:00 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:00 --> Router Class Initialized
INFO - 2023-02-17 07:07:00 --> URI Class Initialized
INFO - 2023-02-17 07:07:00 --> Output Class Initialized
INFO - 2023-02-17 07:07:00 --> Router Class Initialized
INFO - 2023-02-17 07:07:00 --> Security Class Initialized
INFO - 2023-02-17 07:07:00 --> Output Class Initialized
DEBUG - 2023-02-17 07:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:00 --> Security Class Initialized
INFO - 2023-02-17 07:07:00 --> Input Class Initialized
DEBUG - 2023-02-17 07:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:00 --> Language Class Initialized
INFO - 2023-02-17 07:07:00 --> Input Class Initialized
INFO - 2023-02-17 07:07:00 --> Language Class Initialized
INFO - 2023-02-17 07:07:00 --> Loader Class Initialized
INFO - 2023-02-17 07:07:00 --> Loader Class Initialized
INFO - 2023-02-17 07:07:00 --> Controller Class Initialized
INFO - 2023-02-17 07:07:00 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 07:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:00 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:00 --> Total execution time: 0.0045
INFO - 2023-02-17 07:07:00 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:00 --> Config Class Initialized
INFO - 2023-02-17 07:07:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:00 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:00 --> URI Class Initialized
INFO - 2023-02-17 07:07:00 --> Router Class Initialized
INFO - 2023-02-17 07:07:00 --> Output Class Initialized
INFO - 2023-02-17 07:07:00 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:00 --> Input Class Initialized
INFO - 2023-02-17 07:07:00 --> Language Class Initialized
INFO - 2023-02-17 07:07:00 --> Loader Class Initialized
INFO - 2023-02-17 07:07:00 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:00 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:00 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:00 --> Total execution time: 0.0164
INFO - 2023-02-17 07:07:00 --> Model "Login_model" initialized
INFO - 2023-02-17 07:07:00 --> Config Class Initialized
INFO - 2023-02-17 07:07:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:00 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:00 --> URI Class Initialized
INFO - 2023-02-17 07:07:00 --> Router Class Initialized
INFO - 2023-02-17 07:07:00 --> Output Class Initialized
INFO - 2023-02-17 07:07:00 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:00 --> Input Class Initialized
INFO - 2023-02-17 07:07:00 --> Language Class Initialized
INFO - 2023-02-17 07:07:00 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:00 --> Loader Class Initialized
INFO - 2023-02-17 07:07:00 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:00 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:00 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:00 --> Total execution time: 0.0206
INFO - 2023-02-17 07:07:00 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:00 --> Total execution time: 0.0126
INFO - 2023-02-17 07:07:02 --> Config Class Initialized
INFO - 2023-02-17 07:07:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:02 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:02 --> URI Class Initialized
INFO - 2023-02-17 07:07:02 --> Router Class Initialized
INFO - 2023-02-17 07:07:02 --> Output Class Initialized
INFO - 2023-02-17 07:07:02 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:02 --> Input Class Initialized
INFO - 2023-02-17 07:07:02 --> Language Class Initialized
INFO - 2023-02-17 07:07:02 --> Loader Class Initialized
INFO - 2023-02-17 07:07:02 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:02 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:02 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:02 --> Total execution time: 0.0604
INFO - 2023-02-17 07:07:02 --> Config Class Initialized
INFO - 2023-02-17 07:07:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:02 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:02 --> URI Class Initialized
INFO - 2023-02-17 07:07:02 --> Router Class Initialized
INFO - 2023-02-17 07:07:02 --> Output Class Initialized
INFO - 2023-02-17 07:07:02 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:02 --> Input Class Initialized
INFO - 2023-02-17 07:07:02 --> Language Class Initialized
INFO - 2023-02-17 07:07:02 --> Loader Class Initialized
INFO - 2023-02-17 07:07:02 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:02 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:02 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:02 --> Total execution time: 0.0380
INFO - 2023-02-17 07:07:05 --> Config Class Initialized
INFO - 2023-02-17 07:07:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:05 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:05 --> URI Class Initialized
INFO - 2023-02-17 07:07:05 --> Router Class Initialized
INFO - 2023-02-17 07:07:05 --> Output Class Initialized
INFO - 2023-02-17 07:07:05 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:05 --> Input Class Initialized
INFO - 2023-02-17 07:07:05 --> Language Class Initialized
INFO - 2023-02-17 07:07:05 --> Loader Class Initialized
INFO - 2023-02-17 07:07:05 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:05 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:05 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:05 --> Model "Login_model" initialized
INFO - 2023-02-17 07:07:05 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:05 --> Total execution time: 0.0397
INFO - 2023-02-17 07:07:05 --> Config Class Initialized
INFO - 2023-02-17 07:07:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:05 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:05 --> URI Class Initialized
INFO - 2023-02-17 07:07:05 --> Router Class Initialized
INFO - 2023-02-17 07:07:05 --> Output Class Initialized
INFO - 2023-02-17 07:07:05 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:05 --> Input Class Initialized
INFO - 2023-02-17 07:07:05 --> Language Class Initialized
INFO - 2023-02-17 07:07:05 --> Loader Class Initialized
INFO - 2023-02-17 07:07:05 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:05 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:05 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:05 --> Model "Login_model" initialized
INFO - 2023-02-17 07:07:05 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:05 --> Total execution time: 0.0363
INFO - 2023-02-17 07:07:10 --> Config Class Initialized
INFO - 2023-02-17 07:07:10 --> Config Class Initialized
INFO - 2023-02-17 07:07:10 --> Hooks Class Initialized
INFO - 2023-02-17 07:07:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:10 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 07:07:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:10 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:10 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:10 --> URI Class Initialized
INFO - 2023-02-17 07:07:10 --> URI Class Initialized
INFO - 2023-02-17 07:07:10 --> Router Class Initialized
INFO - 2023-02-17 07:07:10 --> Router Class Initialized
INFO - 2023-02-17 07:07:10 --> Output Class Initialized
INFO - 2023-02-17 07:07:10 --> Output Class Initialized
INFO - 2023-02-17 07:07:10 --> Security Class Initialized
INFO - 2023-02-17 07:07:10 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 07:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:10 --> Input Class Initialized
INFO - 2023-02-17 07:07:10 --> Input Class Initialized
INFO - 2023-02-17 07:07:10 --> Language Class Initialized
INFO - 2023-02-17 07:07:10 --> Language Class Initialized
INFO - 2023-02-17 07:07:10 --> Loader Class Initialized
INFO - 2023-02-17 07:07:10 --> Loader Class Initialized
INFO - 2023-02-17 07:07:10 --> Controller Class Initialized
INFO - 2023-02-17 07:07:10 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 07:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:10 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:10 --> Total execution time: 0.0061
INFO - 2023-02-17 07:07:10 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:10 --> Config Class Initialized
INFO - 2023-02-17 07:07:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:10 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:10 --> URI Class Initialized
INFO - 2023-02-17 07:07:10 --> Router Class Initialized
INFO - 2023-02-17 07:07:10 --> Output Class Initialized
INFO - 2023-02-17 07:07:10 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:10 --> Input Class Initialized
INFO - 2023-02-17 07:07:10 --> Language Class Initialized
INFO - 2023-02-17 07:07:10 --> Loader Class Initialized
INFO - 2023-02-17 07:07:10 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:10 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:10 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:10 --> Total execution time: 0.0160
INFO - 2023-02-17 07:07:10 --> Model "Login_model" initialized
INFO - 2023-02-17 07:07:10 --> Config Class Initialized
INFO - 2023-02-17 07:07:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:10 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:10 --> URI Class Initialized
INFO - 2023-02-17 07:07:10 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:10 --> Router Class Initialized
INFO - 2023-02-17 07:07:10 --> Output Class Initialized
INFO - 2023-02-17 07:07:10 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:10 --> Input Class Initialized
INFO - 2023-02-17 07:07:10 --> Language Class Initialized
INFO - 2023-02-17 07:07:10 --> Loader Class Initialized
INFO - 2023-02-17 07:07:10 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:10 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:10 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:10 --> Total execution time: 0.0195
INFO - 2023-02-17 07:07:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:10 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:10 --> Total execution time: 0.0539
INFO - 2023-02-17 07:07:14 --> Config Class Initialized
INFO - 2023-02-17 07:07:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:14 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:14 --> URI Class Initialized
INFO - 2023-02-17 07:07:14 --> Router Class Initialized
INFO - 2023-02-17 07:07:14 --> Output Class Initialized
INFO - 2023-02-17 07:07:14 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:14 --> Input Class Initialized
INFO - 2023-02-17 07:07:14 --> Language Class Initialized
INFO - 2023-02-17 07:07:14 --> Loader Class Initialized
INFO - 2023-02-17 07:07:14 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:14 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:14 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:14 --> Total execution time: 0.0173
INFO - 2023-02-17 07:07:14 --> Config Class Initialized
INFO - 2023-02-17 07:07:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:14 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:14 --> URI Class Initialized
INFO - 2023-02-17 07:07:14 --> Router Class Initialized
INFO - 2023-02-17 07:07:14 --> Output Class Initialized
INFO - 2023-02-17 07:07:14 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:14 --> Input Class Initialized
INFO - 2023-02-17 07:07:14 --> Language Class Initialized
INFO - 2023-02-17 07:07:14 --> Loader Class Initialized
INFO - 2023-02-17 07:07:14 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:14 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:14 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:14 --> Total execution time: 0.0117
INFO - 2023-02-17 07:07:16 --> Config Class Initialized
INFO - 2023-02-17 07:07:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:16 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:16 --> URI Class Initialized
INFO - 2023-02-17 07:07:16 --> Router Class Initialized
INFO - 2023-02-17 07:07:16 --> Output Class Initialized
INFO - 2023-02-17 07:07:16 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:16 --> Input Class Initialized
INFO - 2023-02-17 07:07:16 --> Language Class Initialized
INFO - 2023-02-17 07:07:16 --> Loader Class Initialized
INFO - 2023-02-17 07:07:16 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:16 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:16 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:16 --> Total execution time: 0.0479
INFO - 2023-02-17 07:07:16 --> Config Class Initialized
INFO - 2023-02-17 07:07:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:16 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:16 --> URI Class Initialized
INFO - 2023-02-17 07:07:16 --> Router Class Initialized
INFO - 2023-02-17 07:07:16 --> Output Class Initialized
INFO - 2023-02-17 07:07:16 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:16 --> Input Class Initialized
INFO - 2023-02-17 07:07:16 --> Language Class Initialized
INFO - 2023-02-17 07:07:16 --> Loader Class Initialized
INFO - 2023-02-17 07:07:16 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:16 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:16 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:16 --> Total execution time: 0.0536
INFO - 2023-02-17 07:07:21 --> Config Class Initialized
INFO - 2023-02-17 07:07:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:21 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:21 --> URI Class Initialized
INFO - 2023-02-17 07:07:21 --> Router Class Initialized
INFO - 2023-02-17 07:07:21 --> Output Class Initialized
INFO - 2023-02-17 07:07:21 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:21 --> Input Class Initialized
INFO - 2023-02-17 07:07:21 --> Language Class Initialized
INFO - 2023-02-17 07:07:21 --> Loader Class Initialized
INFO - 2023-02-17 07:07:21 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:21 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:21 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:21 --> Total execution time: 0.0194
INFO - 2023-02-17 07:07:21 --> Config Class Initialized
INFO - 2023-02-17 07:07:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:21 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:21 --> URI Class Initialized
INFO - 2023-02-17 07:07:21 --> Router Class Initialized
INFO - 2023-02-17 07:07:21 --> Output Class Initialized
INFO - 2023-02-17 07:07:21 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:21 --> Input Class Initialized
INFO - 2023-02-17 07:07:21 --> Language Class Initialized
INFO - 2023-02-17 07:07:21 --> Loader Class Initialized
INFO - 2023-02-17 07:07:21 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:21 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:21 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:21 --> Total execution time: 0.0118
INFO - 2023-02-17 07:07:25 --> Config Class Initialized
INFO - 2023-02-17 07:07:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:25 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:25 --> URI Class Initialized
INFO - 2023-02-17 07:07:25 --> Router Class Initialized
INFO - 2023-02-17 07:07:25 --> Output Class Initialized
INFO - 2023-02-17 07:07:25 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:25 --> Input Class Initialized
INFO - 2023-02-17 07:07:25 --> Language Class Initialized
INFO - 2023-02-17 07:07:25 --> Loader Class Initialized
INFO - 2023-02-17 07:07:25 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:25 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:25 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:25 --> Total execution time: 0.0159
INFO - 2023-02-17 07:07:25 --> Config Class Initialized
INFO - 2023-02-17 07:07:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:25 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:25 --> URI Class Initialized
INFO - 2023-02-17 07:07:25 --> Router Class Initialized
INFO - 2023-02-17 07:07:25 --> Output Class Initialized
INFO - 2023-02-17 07:07:25 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:25 --> Input Class Initialized
INFO - 2023-02-17 07:07:25 --> Language Class Initialized
INFO - 2023-02-17 07:07:25 --> Loader Class Initialized
INFO - 2023-02-17 07:07:25 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:25 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:25 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:25 --> Total execution time: 0.0134
INFO - 2023-02-17 07:07:27 --> Config Class Initialized
INFO - 2023-02-17 07:07:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:27 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:27 --> URI Class Initialized
INFO - 2023-02-17 07:07:27 --> Router Class Initialized
INFO - 2023-02-17 07:07:27 --> Output Class Initialized
INFO - 2023-02-17 07:07:27 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:27 --> Input Class Initialized
INFO - 2023-02-17 07:07:27 --> Language Class Initialized
INFO - 2023-02-17 07:07:27 --> Loader Class Initialized
INFO - 2023-02-17 07:07:27 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:27 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:27 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:27 --> Total execution time: 0.0157
INFO - 2023-02-17 07:07:27 --> Config Class Initialized
INFO - 2023-02-17 07:07:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:27 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:27 --> URI Class Initialized
INFO - 2023-02-17 07:07:27 --> Router Class Initialized
INFO - 2023-02-17 07:07:27 --> Output Class Initialized
INFO - 2023-02-17 07:07:27 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:27 --> Input Class Initialized
INFO - 2023-02-17 07:07:27 --> Language Class Initialized
INFO - 2023-02-17 07:07:27 --> Loader Class Initialized
INFO - 2023-02-17 07:07:27 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:27 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:27 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:27 --> Total execution time: 0.0142
INFO - 2023-02-17 07:07:30 --> Config Class Initialized
INFO - 2023-02-17 07:07:30 --> Hooks Class Initialized
INFO - 2023-02-17 07:07:30 --> Config Class Initialized
INFO - 2023-02-17 07:07:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:30 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 07:07:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:30 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:30 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:30 --> URI Class Initialized
INFO - 2023-02-17 07:07:30 --> URI Class Initialized
INFO - 2023-02-17 07:07:30 --> Router Class Initialized
INFO - 2023-02-17 07:07:30 --> Router Class Initialized
INFO - 2023-02-17 07:07:30 --> Output Class Initialized
INFO - 2023-02-17 07:07:30 --> Output Class Initialized
INFO - 2023-02-17 07:07:30 --> Security Class Initialized
INFO - 2023-02-17 07:07:30 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:30 --> Input Class Initialized
INFO - 2023-02-17 07:07:30 --> Input Class Initialized
INFO - 2023-02-17 07:07:30 --> Language Class Initialized
INFO - 2023-02-17 07:07:30 --> Language Class Initialized
INFO - 2023-02-17 07:07:30 --> Loader Class Initialized
INFO - 2023-02-17 07:07:30 --> Loader Class Initialized
INFO - 2023-02-17 07:07:30 --> Controller Class Initialized
INFO - 2023-02-17 07:07:30 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 07:07:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:30 --> Final output sent to browser
INFO - 2023-02-17 07:07:30 --> Database Driver Class Initialized
DEBUG - 2023-02-17 07:07:30 --> Total execution time: 0.0201
INFO - 2023-02-17 07:07:30 --> Config Class Initialized
INFO - 2023-02-17 07:07:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:30 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:30 --> URI Class Initialized
INFO - 2023-02-17 07:07:30 --> Router Class Initialized
INFO - 2023-02-17 07:07:30 --> Output Class Initialized
INFO - 2023-02-17 07:07:30 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:30 --> Input Class Initialized
INFO - 2023-02-17 07:07:30 --> Language Class Initialized
INFO - 2023-02-17 07:07:30 --> Loader Class Initialized
INFO - 2023-02-17 07:07:30 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:30 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:30 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:30 --> Total execution time: 0.0351
INFO - 2023-02-17 07:07:30 --> Config Class Initialized
INFO - 2023-02-17 07:07:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:30 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:30 --> URI Class Initialized
INFO - 2023-02-17 07:07:30 --> Router Class Initialized
INFO - 2023-02-17 07:07:30 --> Output Class Initialized
INFO - 2023-02-17 07:07:30 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:30 --> Input Class Initialized
INFO - 2023-02-17 07:07:30 --> Language Class Initialized
INFO - 2023-02-17 07:07:30 --> Loader Class Initialized
INFO - 2023-02-17 07:07:30 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:30 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:30 --> Model "Login_model" initialized
INFO - 2023-02-17 07:07:30 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:30 --> Final output sent to browser
INFO - 2023-02-17 07:07:30 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:30 --> Total execution time: 0.0217
DEBUG - 2023-02-17 07:07:30 --> Total execution time: 0.0117
INFO - 2023-02-17 07:07:32 --> Config Class Initialized
INFO - 2023-02-17 07:07:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:32 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:32 --> URI Class Initialized
INFO - 2023-02-17 07:07:32 --> Router Class Initialized
INFO - 2023-02-17 07:07:32 --> Output Class Initialized
INFO - 2023-02-17 07:07:32 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:32 --> Input Class Initialized
INFO - 2023-02-17 07:07:32 --> Language Class Initialized
INFO - 2023-02-17 07:07:32 --> Loader Class Initialized
INFO - 2023-02-17 07:07:32 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:32 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:32 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:32 --> Model "Login_model" initialized
INFO - 2023-02-17 07:07:32 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:32 --> Total execution time: 0.0392
INFO - 2023-02-17 07:07:32 --> Config Class Initialized
INFO - 2023-02-17 07:07:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:32 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:32 --> URI Class Initialized
INFO - 2023-02-17 07:07:32 --> Router Class Initialized
INFO - 2023-02-17 07:07:32 --> Output Class Initialized
INFO - 2023-02-17 07:07:32 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:32 --> Input Class Initialized
INFO - 2023-02-17 07:07:32 --> Language Class Initialized
INFO - 2023-02-17 07:07:32 --> Loader Class Initialized
INFO - 2023-02-17 07:07:32 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:32 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:32 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:32 --> Model "Login_model" initialized
INFO - 2023-02-17 07:07:32 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:32 --> Total execution time: 0.0784
INFO - 2023-02-17 07:07:34 --> Config Class Initialized
INFO - 2023-02-17 07:07:34 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:34 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:34 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:34 --> URI Class Initialized
INFO - 2023-02-17 07:07:34 --> Router Class Initialized
INFO - 2023-02-17 07:07:34 --> Output Class Initialized
INFO - 2023-02-17 07:07:34 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:34 --> Input Class Initialized
INFO - 2023-02-17 07:07:34 --> Language Class Initialized
INFO - 2023-02-17 07:07:34 --> Loader Class Initialized
INFO - 2023-02-17 07:07:34 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:34 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:34 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:34 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:34 --> Model "Login_model" initialized
INFO - 2023-02-17 07:07:34 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:34 --> Total execution time: 0.0418
INFO - 2023-02-17 07:07:37 --> Config Class Initialized
INFO - 2023-02-17 07:07:37 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:37 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:37 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:37 --> URI Class Initialized
INFO - 2023-02-17 07:07:37 --> Router Class Initialized
INFO - 2023-02-17 07:07:37 --> Output Class Initialized
INFO - 2023-02-17 07:07:37 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:37 --> Input Class Initialized
INFO - 2023-02-17 07:07:37 --> Language Class Initialized
INFO - 2023-02-17 07:07:37 --> Loader Class Initialized
INFO - 2023-02-17 07:07:37 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:37 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:37 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:37 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:37 --> Total execution time: 0.0514
INFO - 2023-02-17 07:07:37 --> Config Class Initialized
INFO - 2023-02-17 07:07:37 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:07:37 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:07:37 --> Utf8 Class Initialized
INFO - 2023-02-17 07:07:37 --> URI Class Initialized
INFO - 2023-02-17 07:07:37 --> Router Class Initialized
INFO - 2023-02-17 07:07:37 --> Output Class Initialized
INFO - 2023-02-17 07:07:37 --> Security Class Initialized
DEBUG - 2023-02-17 07:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:07:37 --> Input Class Initialized
INFO - 2023-02-17 07:07:37 --> Language Class Initialized
INFO - 2023-02-17 07:07:37 --> Loader Class Initialized
INFO - 2023-02-17 07:07:37 --> Controller Class Initialized
DEBUG - 2023-02-17 07:07:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:07:37 --> Database Driver Class Initialized
INFO - 2023-02-17 07:07:37 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:07:37 --> Final output sent to browser
DEBUG - 2023-02-17 07:07:37 --> Total execution time: 0.0579
INFO - 2023-02-17 07:09:14 --> Config Class Initialized
INFO - 2023-02-17 07:09:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:09:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:09:14 --> Utf8 Class Initialized
INFO - 2023-02-17 07:09:14 --> URI Class Initialized
INFO - 2023-02-17 07:09:14 --> Router Class Initialized
INFO - 2023-02-17 07:09:14 --> Output Class Initialized
INFO - 2023-02-17 07:09:14 --> Security Class Initialized
DEBUG - 2023-02-17 07:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:09:14 --> Input Class Initialized
INFO - 2023-02-17 07:09:14 --> Language Class Initialized
INFO - 2023-02-17 07:09:14 --> Loader Class Initialized
INFO - 2023-02-17 07:09:14 --> Controller Class Initialized
DEBUG - 2023-02-17 07:09:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:09:14 --> Database Driver Class Initialized
INFO - 2023-02-17 07:09:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:09:14 --> Final output sent to browser
DEBUG - 2023-02-17 07:09:14 --> Total execution time: 0.1249
INFO - 2023-02-17 07:09:14 --> Config Class Initialized
INFO - 2023-02-17 07:09:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:09:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:09:14 --> Utf8 Class Initialized
INFO - 2023-02-17 07:09:14 --> URI Class Initialized
INFO - 2023-02-17 07:09:14 --> Router Class Initialized
INFO - 2023-02-17 07:09:14 --> Output Class Initialized
INFO - 2023-02-17 07:09:14 --> Security Class Initialized
DEBUG - 2023-02-17 07:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:09:14 --> Input Class Initialized
INFO - 2023-02-17 07:09:14 --> Language Class Initialized
INFO - 2023-02-17 07:09:14 --> Loader Class Initialized
INFO - 2023-02-17 07:09:14 --> Controller Class Initialized
DEBUG - 2023-02-17 07:09:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:09:14 --> Database Driver Class Initialized
INFO - 2023-02-17 07:09:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:09:14 --> Final output sent to browser
DEBUG - 2023-02-17 07:09:14 --> Total execution time: 0.0408
INFO - 2023-02-17 07:09:27 --> Config Class Initialized
INFO - 2023-02-17 07:09:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:09:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:09:27 --> Utf8 Class Initialized
INFO - 2023-02-17 07:09:27 --> URI Class Initialized
INFO - 2023-02-17 07:09:27 --> Router Class Initialized
INFO - 2023-02-17 07:09:27 --> Output Class Initialized
INFO - 2023-02-17 07:09:27 --> Security Class Initialized
DEBUG - 2023-02-17 07:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:09:27 --> Input Class Initialized
INFO - 2023-02-17 07:09:27 --> Language Class Initialized
INFO - 2023-02-17 07:09:27 --> Loader Class Initialized
INFO - 2023-02-17 07:09:27 --> Controller Class Initialized
DEBUG - 2023-02-17 07:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:09:27 --> Database Driver Class Initialized
INFO - 2023-02-17 07:09:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:09:27 --> Final output sent to browser
DEBUG - 2023-02-17 07:09:27 --> Total execution time: 0.1292
INFO - 2023-02-17 07:09:27 --> Config Class Initialized
INFO - 2023-02-17 07:09:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:09:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:09:27 --> Utf8 Class Initialized
INFO - 2023-02-17 07:09:27 --> URI Class Initialized
INFO - 2023-02-17 07:09:27 --> Router Class Initialized
INFO - 2023-02-17 07:09:27 --> Output Class Initialized
INFO - 2023-02-17 07:09:27 --> Security Class Initialized
DEBUG - 2023-02-17 07:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:09:27 --> Input Class Initialized
INFO - 2023-02-17 07:09:27 --> Language Class Initialized
INFO - 2023-02-17 07:09:27 --> Loader Class Initialized
INFO - 2023-02-17 07:09:27 --> Controller Class Initialized
DEBUG - 2023-02-17 07:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:09:27 --> Database Driver Class Initialized
INFO - 2023-02-17 07:09:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:09:27 --> Final output sent to browser
DEBUG - 2023-02-17 07:09:27 --> Total execution time: 0.0542
INFO - 2023-02-17 07:18:23 --> Config Class Initialized
INFO - 2023-02-17 07:18:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:18:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:18:23 --> Utf8 Class Initialized
INFO - 2023-02-17 07:18:23 --> URI Class Initialized
INFO - 2023-02-17 07:18:23 --> Router Class Initialized
INFO - 2023-02-17 07:18:23 --> Output Class Initialized
INFO - 2023-02-17 07:18:23 --> Security Class Initialized
DEBUG - 2023-02-17 07:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:18:23 --> Input Class Initialized
INFO - 2023-02-17 07:18:23 --> Language Class Initialized
INFO - 2023-02-17 07:18:23 --> Loader Class Initialized
INFO - 2023-02-17 07:18:23 --> Controller Class Initialized
DEBUG - 2023-02-17 07:18:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:18:23 --> Database Driver Class Initialized
INFO - 2023-02-17 07:18:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:18:23 --> Final output sent to browser
DEBUG - 2023-02-17 07:18:23 --> Total execution time: 0.1751
INFO - 2023-02-17 07:18:23 --> Config Class Initialized
INFO - 2023-02-17 07:18:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:18:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:18:23 --> Utf8 Class Initialized
INFO - 2023-02-17 07:18:23 --> URI Class Initialized
INFO - 2023-02-17 07:18:23 --> Router Class Initialized
INFO - 2023-02-17 07:18:23 --> Output Class Initialized
INFO - 2023-02-17 07:18:23 --> Security Class Initialized
DEBUG - 2023-02-17 07:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:18:23 --> Input Class Initialized
INFO - 2023-02-17 07:18:23 --> Language Class Initialized
INFO - 2023-02-17 07:18:23 --> Loader Class Initialized
INFO - 2023-02-17 07:18:23 --> Controller Class Initialized
DEBUG - 2023-02-17 07:18:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:18:23 --> Database Driver Class Initialized
INFO - 2023-02-17 07:18:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:18:23 --> Final output sent to browser
DEBUG - 2023-02-17 07:18:23 --> Total execution time: 0.0459
INFO - 2023-02-17 07:19:11 --> Config Class Initialized
INFO - 2023-02-17 07:19:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:19:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:19:11 --> Utf8 Class Initialized
INFO - 2023-02-17 07:19:11 --> URI Class Initialized
INFO - 2023-02-17 07:19:11 --> Router Class Initialized
INFO - 2023-02-17 07:19:11 --> Output Class Initialized
INFO - 2023-02-17 07:19:11 --> Security Class Initialized
DEBUG - 2023-02-17 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:19:11 --> Input Class Initialized
INFO - 2023-02-17 07:19:11 --> Language Class Initialized
INFO - 2023-02-17 07:19:11 --> Loader Class Initialized
INFO - 2023-02-17 07:19:11 --> Controller Class Initialized
DEBUG - 2023-02-17 07:19:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:19:11 --> Database Driver Class Initialized
INFO - 2023-02-17 07:19:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:19:11 --> Final output sent to browser
DEBUG - 2023-02-17 07:19:11 --> Total execution time: 0.0910
INFO - 2023-02-17 07:19:11 --> Config Class Initialized
INFO - 2023-02-17 07:19:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:19:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:19:11 --> Utf8 Class Initialized
INFO - 2023-02-17 07:19:11 --> URI Class Initialized
INFO - 2023-02-17 07:19:11 --> Router Class Initialized
INFO - 2023-02-17 07:19:11 --> Output Class Initialized
INFO - 2023-02-17 07:19:11 --> Security Class Initialized
DEBUG - 2023-02-17 07:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:19:11 --> Input Class Initialized
INFO - 2023-02-17 07:19:11 --> Language Class Initialized
INFO - 2023-02-17 07:19:11 --> Loader Class Initialized
INFO - 2023-02-17 07:19:11 --> Controller Class Initialized
DEBUG - 2023-02-17 07:19:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:19:11 --> Database Driver Class Initialized
INFO - 2023-02-17 07:19:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:19:11 --> Final output sent to browser
DEBUG - 2023-02-17 07:19:11 --> Total execution time: 0.0772
INFO - 2023-02-17 07:19:24 --> Config Class Initialized
INFO - 2023-02-17 07:19:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:19:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:19:24 --> Utf8 Class Initialized
INFO - 2023-02-17 07:19:24 --> URI Class Initialized
INFO - 2023-02-17 07:19:24 --> Router Class Initialized
INFO - 2023-02-17 07:19:24 --> Output Class Initialized
INFO - 2023-02-17 07:19:24 --> Security Class Initialized
DEBUG - 2023-02-17 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:19:24 --> Input Class Initialized
INFO - 2023-02-17 07:19:24 --> Language Class Initialized
INFO - 2023-02-17 07:19:24 --> Loader Class Initialized
INFO - 2023-02-17 07:19:24 --> Controller Class Initialized
DEBUG - 2023-02-17 07:19:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:19:24 --> Database Driver Class Initialized
INFO - 2023-02-17 07:19:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:19:24 --> Final output sent to browser
DEBUG - 2023-02-17 07:19:24 --> Total execution time: 0.1395
INFO - 2023-02-17 07:19:24 --> Config Class Initialized
INFO - 2023-02-17 07:19:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:19:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:19:24 --> Utf8 Class Initialized
INFO - 2023-02-17 07:19:24 --> URI Class Initialized
INFO - 2023-02-17 07:19:24 --> Router Class Initialized
INFO - 2023-02-17 07:19:24 --> Output Class Initialized
INFO - 2023-02-17 07:19:24 --> Security Class Initialized
DEBUG - 2023-02-17 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:19:24 --> Input Class Initialized
INFO - 2023-02-17 07:19:24 --> Language Class Initialized
INFO - 2023-02-17 07:19:24 --> Loader Class Initialized
INFO - 2023-02-17 07:19:24 --> Controller Class Initialized
DEBUG - 2023-02-17 07:19:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:19:24 --> Database Driver Class Initialized
INFO - 2023-02-17 07:19:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:19:24 --> Final output sent to browser
DEBUG - 2023-02-17 07:19:24 --> Total execution time: 0.0442
INFO - 2023-02-17 07:20:11 --> Config Class Initialized
INFO - 2023-02-17 07:20:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:20:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:20:11 --> Utf8 Class Initialized
INFO - 2023-02-17 07:20:11 --> URI Class Initialized
INFO - 2023-02-17 07:20:11 --> Router Class Initialized
INFO - 2023-02-17 07:20:11 --> Output Class Initialized
INFO - 2023-02-17 07:20:11 --> Security Class Initialized
DEBUG - 2023-02-17 07:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:20:11 --> Input Class Initialized
INFO - 2023-02-17 07:20:11 --> Language Class Initialized
INFO - 2023-02-17 07:20:11 --> Loader Class Initialized
INFO - 2023-02-17 07:20:11 --> Controller Class Initialized
DEBUG - 2023-02-17 07:20:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:20:11 --> Database Driver Class Initialized
INFO - 2023-02-17 07:20:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:20:11 --> Final output sent to browser
DEBUG - 2023-02-17 07:20:11 --> Total execution time: 0.2085
INFO - 2023-02-17 07:20:11 --> Config Class Initialized
INFO - 2023-02-17 07:20:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 07:20:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 07:20:11 --> Utf8 Class Initialized
INFO - 2023-02-17 07:20:11 --> URI Class Initialized
INFO - 2023-02-17 07:20:11 --> Router Class Initialized
INFO - 2023-02-17 07:20:11 --> Output Class Initialized
INFO - 2023-02-17 07:20:11 --> Security Class Initialized
DEBUG - 2023-02-17 07:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 07:20:11 --> Input Class Initialized
INFO - 2023-02-17 07:20:11 --> Language Class Initialized
INFO - 2023-02-17 07:20:11 --> Loader Class Initialized
INFO - 2023-02-17 07:20:11 --> Controller Class Initialized
DEBUG - 2023-02-17 07:20:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 07:20:11 --> Database Driver Class Initialized
INFO - 2023-02-17 07:20:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 07:20:11 --> Final output sent to browser
DEBUG - 2023-02-17 07:20:11 --> Total execution time: 0.0406
INFO - 2023-02-17 08:13:09 --> Config Class Initialized
INFO - 2023-02-17 08:13:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:13:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-02-17 08:13:09 --> URI Class Initialized
INFO - 2023-02-17 08:13:09 --> Router Class Initialized
INFO - 2023-02-17 08:13:09 --> Output Class Initialized
INFO - 2023-02-17 08:13:09 --> Security Class Initialized
DEBUG - 2023-02-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:13:09 --> Input Class Initialized
INFO - 2023-02-17 08:13:09 --> Language Class Initialized
INFO - 2023-02-17 08:13:09 --> Loader Class Initialized
INFO - 2023-02-17 08:13:09 --> Controller Class Initialized
DEBUG - 2023-02-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:13:09 --> Model "Login_model" initialized
INFO - 2023-02-17 08:13:09 --> Final output sent to browser
DEBUG - 2023-02-17 08:13:09 --> Total execution time: 0.1331
INFO - 2023-02-17 08:13:09 --> Config Class Initialized
INFO - 2023-02-17 08:13:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:13:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:13:09 --> Utf8 Class Initialized
INFO - 2023-02-17 08:13:09 --> URI Class Initialized
INFO - 2023-02-17 08:13:09 --> Router Class Initialized
INFO - 2023-02-17 08:13:09 --> Output Class Initialized
INFO - 2023-02-17 08:13:09 --> Security Class Initialized
DEBUG - 2023-02-17 08:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:13:09 --> Input Class Initialized
INFO - 2023-02-17 08:13:09 --> Language Class Initialized
INFO - 2023-02-17 08:13:09 --> Loader Class Initialized
INFO - 2023-02-17 08:13:09 --> Controller Class Initialized
DEBUG - 2023-02-17 08:13:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:13:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:13:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:13:09 --> Model "Login_model" initialized
INFO - 2023-02-17 08:13:09 --> Final output sent to browser
DEBUG - 2023-02-17 08:13:09 --> Total execution time: 0.0500
INFO - 2023-02-17 08:13:13 --> Config Class Initialized
INFO - 2023-02-17 08:13:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:13:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:13:13 --> Utf8 Class Initialized
INFO - 2023-02-17 08:13:13 --> URI Class Initialized
INFO - 2023-02-17 08:13:13 --> Router Class Initialized
INFO - 2023-02-17 08:13:13 --> Output Class Initialized
INFO - 2023-02-17 08:13:13 --> Security Class Initialized
DEBUG - 2023-02-17 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:13:13 --> Input Class Initialized
INFO - 2023-02-17 08:13:13 --> Language Class Initialized
INFO - 2023-02-17 08:13:13 --> Loader Class Initialized
INFO - 2023-02-17 08:13:13 --> Controller Class Initialized
DEBUG - 2023-02-17 08:13:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:13:13 --> Database Driver Class Initialized
INFO - 2023-02-17 08:13:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:13:13 --> Final output sent to browser
DEBUG - 2023-02-17 08:13:13 --> Total execution time: 0.0536
INFO - 2023-02-17 08:13:13 --> Config Class Initialized
INFO - 2023-02-17 08:13:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:13:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:13:13 --> Utf8 Class Initialized
INFO - 2023-02-17 08:13:13 --> URI Class Initialized
INFO - 2023-02-17 08:13:13 --> Router Class Initialized
INFO - 2023-02-17 08:13:13 --> Output Class Initialized
INFO - 2023-02-17 08:13:13 --> Security Class Initialized
DEBUG - 2023-02-17 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:13:13 --> Input Class Initialized
INFO - 2023-02-17 08:13:13 --> Language Class Initialized
INFO - 2023-02-17 08:13:13 --> Loader Class Initialized
INFO - 2023-02-17 08:13:13 --> Controller Class Initialized
DEBUG - 2023-02-17 08:13:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:13:13 --> Database Driver Class Initialized
INFO - 2023-02-17 08:13:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:13:13 --> Final output sent to browser
DEBUG - 2023-02-17 08:13:13 --> Total execution time: 0.0878
INFO - 2023-02-17 08:13:48 --> Config Class Initialized
INFO - 2023-02-17 08:13:48 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:13:48 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:13:48 --> Utf8 Class Initialized
INFO - 2023-02-17 08:13:48 --> URI Class Initialized
INFO - 2023-02-17 08:13:48 --> Router Class Initialized
INFO - 2023-02-17 08:13:48 --> Output Class Initialized
INFO - 2023-02-17 08:13:48 --> Security Class Initialized
DEBUG - 2023-02-17 08:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:13:48 --> Input Class Initialized
INFO - 2023-02-17 08:13:48 --> Language Class Initialized
INFO - 2023-02-17 08:13:48 --> Loader Class Initialized
INFO - 2023-02-17 08:13:48 --> Controller Class Initialized
DEBUG - 2023-02-17 08:13:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:13:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:13:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:13:49 --> Final output sent to browser
DEBUG - 2023-02-17 08:13:49 --> Total execution time: 0.1299
INFO - 2023-02-17 08:13:49 --> Config Class Initialized
INFO - 2023-02-17 08:13:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:13:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:13:49 --> Utf8 Class Initialized
INFO - 2023-02-17 08:13:49 --> URI Class Initialized
INFO - 2023-02-17 08:13:49 --> Router Class Initialized
INFO - 2023-02-17 08:13:49 --> Output Class Initialized
INFO - 2023-02-17 08:13:49 --> Security Class Initialized
DEBUG - 2023-02-17 08:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:13:49 --> Input Class Initialized
INFO - 2023-02-17 08:13:49 --> Language Class Initialized
INFO - 2023-02-17 08:13:49 --> Loader Class Initialized
INFO - 2023-02-17 08:13:49 --> Controller Class Initialized
DEBUG - 2023-02-17 08:13:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:13:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:13:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:13:49 --> Final output sent to browser
DEBUG - 2023-02-17 08:13:49 --> Total execution time: 0.0963
INFO - 2023-02-17 08:14:02 --> Config Class Initialized
INFO - 2023-02-17 08:14:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:02 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:02 --> URI Class Initialized
INFO - 2023-02-17 08:14:02 --> Router Class Initialized
INFO - 2023-02-17 08:14:02 --> Output Class Initialized
INFO - 2023-02-17 08:14:02 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:02 --> Input Class Initialized
INFO - 2023-02-17 08:14:02 --> Language Class Initialized
INFO - 2023-02-17 08:14:02 --> Loader Class Initialized
INFO - 2023-02-17 08:14:02 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:02 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:02 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:02 --> Total execution time: 0.0162
INFO - 2023-02-17 08:14:02 --> Config Class Initialized
INFO - 2023-02-17 08:14:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:02 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:02 --> URI Class Initialized
INFO - 2023-02-17 08:14:02 --> Router Class Initialized
INFO - 2023-02-17 08:14:02 --> Output Class Initialized
INFO - 2023-02-17 08:14:02 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:02 --> Input Class Initialized
INFO - 2023-02-17 08:14:02 --> Language Class Initialized
INFO - 2023-02-17 08:14:02 --> Loader Class Initialized
INFO - 2023-02-17 08:14:02 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:02 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:02 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:02 --> Total execution time: 0.0556
INFO - 2023-02-17 08:14:12 --> Config Class Initialized
INFO - 2023-02-17 08:14:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:12 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:12 --> URI Class Initialized
INFO - 2023-02-17 08:14:12 --> Router Class Initialized
INFO - 2023-02-17 08:14:12 --> Output Class Initialized
INFO - 2023-02-17 08:14:12 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:12 --> Input Class Initialized
INFO - 2023-02-17 08:14:12 --> Language Class Initialized
INFO - 2023-02-17 08:14:12 --> Loader Class Initialized
INFO - 2023-02-17 08:14:12 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:12 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:12 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:12 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:12 --> Total execution time: 0.0198
INFO - 2023-02-17 08:14:12 --> Config Class Initialized
INFO - 2023-02-17 08:14:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:12 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:12 --> URI Class Initialized
INFO - 2023-02-17 08:14:12 --> Router Class Initialized
INFO - 2023-02-17 08:14:12 --> Output Class Initialized
INFO - 2023-02-17 08:14:12 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:12 --> Input Class Initialized
INFO - 2023-02-17 08:14:12 --> Language Class Initialized
INFO - 2023-02-17 08:14:12 --> Loader Class Initialized
INFO - 2023-02-17 08:14:12 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:12 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:12 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:12 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:12 --> Total execution time: 0.0672
INFO - 2023-02-17 08:14:16 --> Config Class Initialized
INFO - 2023-02-17 08:14:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:16 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:16 --> URI Class Initialized
INFO - 2023-02-17 08:14:16 --> Router Class Initialized
INFO - 2023-02-17 08:14:16 --> Output Class Initialized
INFO - 2023-02-17 08:14:16 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:16 --> Input Class Initialized
INFO - 2023-02-17 08:14:16 --> Language Class Initialized
INFO - 2023-02-17 08:14:16 --> Loader Class Initialized
INFO - 2023-02-17 08:14:16 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:16 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:16 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:16 --> Total execution time: 0.0786
INFO - 2023-02-17 08:14:16 --> Config Class Initialized
INFO - 2023-02-17 08:14:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:16 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:16 --> URI Class Initialized
INFO - 2023-02-17 08:14:16 --> Router Class Initialized
INFO - 2023-02-17 08:14:16 --> Output Class Initialized
INFO - 2023-02-17 08:14:16 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:16 --> Input Class Initialized
INFO - 2023-02-17 08:14:16 --> Language Class Initialized
INFO - 2023-02-17 08:14:16 --> Loader Class Initialized
INFO - 2023-02-17 08:14:16 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:16 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:16 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:16 --> Total execution time: 0.0510
INFO - 2023-02-17 08:14:32 --> Config Class Initialized
INFO - 2023-02-17 08:14:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:32 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:32 --> URI Class Initialized
INFO - 2023-02-17 08:14:32 --> Router Class Initialized
INFO - 2023-02-17 08:14:32 --> Output Class Initialized
INFO - 2023-02-17 08:14:32 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:32 --> Input Class Initialized
INFO - 2023-02-17 08:14:32 --> Language Class Initialized
INFO - 2023-02-17 08:14:32 --> Loader Class Initialized
INFO - 2023-02-17 08:14:32 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:32 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:32 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:32 --> Model "Login_model" initialized
INFO - 2023-02-17 08:14:32 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:32 --> Total execution time: 0.1329
INFO - 2023-02-17 08:14:32 --> Config Class Initialized
INFO - 2023-02-17 08:14:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:32 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:32 --> URI Class Initialized
INFO - 2023-02-17 08:14:32 --> Router Class Initialized
INFO - 2023-02-17 08:14:32 --> Output Class Initialized
INFO - 2023-02-17 08:14:32 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:32 --> Input Class Initialized
INFO - 2023-02-17 08:14:32 --> Language Class Initialized
INFO - 2023-02-17 08:14:32 --> Loader Class Initialized
INFO - 2023-02-17 08:14:32 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:32 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:32 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:32 --> Model "Login_model" initialized
INFO - 2023-02-17 08:14:32 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:32 --> Total execution time: 0.1303
INFO - 2023-02-17 08:14:43 --> Config Class Initialized
INFO - 2023-02-17 08:14:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:43 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:43 --> URI Class Initialized
INFO - 2023-02-17 08:14:43 --> Router Class Initialized
INFO - 2023-02-17 08:14:43 --> Output Class Initialized
INFO - 2023-02-17 08:14:43 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:43 --> Input Class Initialized
INFO - 2023-02-17 08:14:43 --> Language Class Initialized
INFO - 2023-02-17 08:14:43 --> Loader Class Initialized
INFO - 2023-02-17 08:14:43 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:43 --> Model "Login_model" initialized
INFO - 2023-02-17 08:14:43 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:43 --> Total execution time: 0.1288
INFO - 2023-02-17 08:14:43 --> Config Class Initialized
INFO - 2023-02-17 08:14:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:14:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:14:43 --> Utf8 Class Initialized
INFO - 2023-02-17 08:14:43 --> URI Class Initialized
INFO - 2023-02-17 08:14:43 --> Router Class Initialized
INFO - 2023-02-17 08:14:43 --> Output Class Initialized
INFO - 2023-02-17 08:14:43 --> Security Class Initialized
DEBUG - 2023-02-17 08:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:14:43 --> Input Class Initialized
INFO - 2023-02-17 08:14:43 --> Language Class Initialized
INFO - 2023-02-17 08:14:43 --> Loader Class Initialized
INFO - 2023-02-17 08:14:43 --> Controller Class Initialized
DEBUG - 2023-02-17 08:14:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:14:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:14:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:14:43 --> Model "Login_model" initialized
INFO - 2023-02-17 08:14:43 --> Final output sent to browser
DEBUG - 2023-02-17 08:14:43 --> Total execution time: 0.0406
INFO - 2023-02-17 08:19:49 --> Config Class Initialized
INFO - 2023-02-17 08:19:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:19:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:19:49 --> Utf8 Class Initialized
INFO - 2023-02-17 08:19:49 --> URI Class Initialized
INFO - 2023-02-17 08:19:49 --> Router Class Initialized
INFO - 2023-02-17 08:19:49 --> Output Class Initialized
INFO - 2023-02-17 08:19:49 --> Security Class Initialized
DEBUG - 2023-02-17 08:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:19:49 --> Input Class Initialized
INFO - 2023-02-17 08:19:49 --> Language Class Initialized
INFO - 2023-02-17 08:19:49 --> Loader Class Initialized
INFO - 2023-02-17 08:19:49 --> Controller Class Initialized
DEBUG - 2023-02-17 08:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:19:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:19:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:19:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:19:49 --> Model "Login_model" initialized
INFO - 2023-02-17 08:19:49 --> Final output sent to browser
DEBUG - 2023-02-17 08:19:49 --> Total execution time: 0.1253
INFO - 2023-02-17 08:19:49 --> Config Class Initialized
INFO - 2023-02-17 08:19:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:19:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:19:49 --> Utf8 Class Initialized
INFO - 2023-02-17 08:19:49 --> URI Class Initialized
INFO - 2023-02-17 08:19:49 --> Router Class Initialized
INFO - 2023-02-17 08:19:49 --> Output Class Initialized
INFO - 2023-02-17 08:19:49 --> Security Class Initialized
DEBUG - 2023-02-17 08:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:19:49 --> Input Class Initialized
INFO - 2023-02-17 08:19:49 --> Language Class Initialized
INFO - 2023-02-17 08:19:49 --> Loader Class Initialized
INFO - 2023-02-17 08:19:49 --> Controller Class Initialized
DEBUG - 2023-02-17 08:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:19:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:19:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:19:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:19:50 --> Model "Login_model" initialized
INFO - 2023-02-17 08:19:50 --> Final output sent to browser
DEBUG - 2023-02-17 08:19:50 --> Total execution time: 0.1245
INFO - 2023-02-17 08:21:08 --> Config Class Initialized
INFO - 2023-02-17 08:21:08 --> Config Class Initialized
INFO - 2023-02-17 08:21:08 --> Hooks Class Initialized
INFO - 2023-02-17 08:21:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 08:21:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:08 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:08 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:08 --> URI Class Initialized
INFO - 2023-02-17 08:21:08 --> URI Class Initialized
INFO - 2023-02-17 08:21:08 --> Router Class Initialized
INFO - 2023-02-17 08:21:08 --> Router Class Initialized
INFO - 2023-02-17 08:21:08 --> Output Class Initialized
INFO - 2023-02-17 08:21:08 --> Output Class Initialized
INFO - 2023-02-17 08:21:08 --> Security Class Initialized
INFO - 2023-02-17 08:21:08 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:08 --> Input Class Initialized
INFO - 2023-02-17 08:21:08 --> Input Class Initialized
INFO - 2023-02-17 08:21:08 --> Language Class Initialized
INFO - 2023-02-17 08:21:08 --> Language Class Initialized
INFO - 2023-02-17 08:21:08 --> Loader Class Initialized
INFO - 2023-02-17 08:21:08 --> Loader Class Initialized
INFO - 2023-02-17 08:21:08 --> Controller Class Initialized
INFO - 2023-02-17 08:21:08 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 08:21:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:08 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:08 --> Total execution time: 0.0042
INFO - 2023-02-17 08:21:08 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:08 --> Config Class Initialized
INFO - 2023-02-17 08:21:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:08 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:08 --> URI Class Initialized
INFO - 2023-02-17 08:21:08 --> Router Class Initialized
INFO - 2023-02-17 08:21:08 --> Output Class Initialized
INFO - 2023-02-17 08:21:08 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:08 --> Input Class Initialized
INFO - 2023-02-17 08:21:08 --> Language Class Initialized
INFO - 2023-02-17 08:21:08 --> Loader Class Initialized
INFO - 2023-02-17 08:21:08 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:08 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:08 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:08 --> Total execution time: 0.0571
INFO - 2023-02-17 08:21:08 --> Config Class Initialized
INFO - 2023-02-17 08:21:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:08 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:08 --> URI Class Initialized
INFO - 2023-02-17 08:21:08 --> Router Class Initialized
INFO - 2023-02-17 08:21:08 --> Output Class Initialized
INFO - 2023-02-17 08:21:08 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:08 --> Input Class Initialized
INFO - 2023-02-17 08:21:08 --> Language Class Initialized
INFO - 2023-02-17 08:21:08 --> Loader Class Initialized
INFO - 2023-02-17 08:21:08 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:08 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:08 --> Model "Login_model" initialized
INFO - 2023-02-17 08:21:08 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:08 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:08 --> Total execution time: 0.0146
INFO - 2023-02-17 08:21:08 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:08 --> Total execution time: 0.0617
INFO - 2023-02-17 08:21:10 --> Config Class Initialized
INFO - 2023-02-17 08:21:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:10 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:10 --> URI Class Initialized
INFO - 2023-02-17 08:21:10 --> Router Class Initialized
INFO - 2023-02-17 08:21:10 --> Output Class Initialized
INFO - 2023-02-17 08:21:10 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:10 --> Input Class Initialized
INFO - 2023-02-17 08:21:10 --> Language Class Initialized
INFO - 2023-02-17 08:21:10 --> Loader Class Initialized
INFO - 2023-02-17 08:21:10 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:10 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:10 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:10 --> Model "Login_model" initialized
INFO - 2023-02-17 08:21:10 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:10 --> Total execution time: 0.1010
INFO - 2023-02-17 08:21:10 --> Config Class Initialized
INFO - 2023-02-17 08:21:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:10 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:10 --> URI Class Initialized
INFO - 2023-02-17 08:21:10 --> Router Class Initialized
INFO - 2023-02-17 08:21:10 --> Output Class Initialized
INFO - 2023-02-17 08:21:10 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:10 --> Input Class Initialized
INFO - 2023-02-17 08:21:10 --> Language Class Initialized
INFO - 2023-02-17 08:21:10 --> Loader Class Initialized
INFO - 2023-02-17 08:21:10 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:10 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:10 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:10 --> Model "Login_model" initialized
INFO - 2023-02-17 08:21:10 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:10 --> Total execution time: 0.0423
INFO - 2023-02-17 08:21:17 --> Config Class Initialized
INFO - 2023-02-17 08:21:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:17 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:17 --> URI Class Initialized
INFO - 2023-02-17 08:21:17 --> Router Class Initialized
INFO - 2023-02-17 08:21:17 --> Output Class Initialized
INFO - 2023-02-17 08:21:17 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:17 --> Input Class Initialized
INFO - 2023-02-17 08:21:17 --> Language Class Initialized
INFO - 2023-02-17 08:21:17 --> Loader Class Initialized
INFO - 2023-02-17 08:21:17 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:17 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:17 --> Total execution time: 0.0075
INFO - 2023-02-17 08:21:17 --> Config Class Initialized
INFO - 2023-02-17 08:21:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:17 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:17 --> URI Class Initialized
INFO - 2023-02-17 08:21:17 --> Router Class Initialized
INFO - 2023-02-17 08:21:17 --> Output Class Initialized
INFO - 2023-02-17 08:21:17 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:17 --> Input Class Initialized
INFO - 2023-02-17 08:21:17 --> Language Class Initialized
INFO - 2023-02-17 08:21:17 --> Loader Class Initialized
INFO - 2023-02-17 08:21:17 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:17 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:17 --> Model "Login_model" initialized
INFO - 2023-02-17 08:21:17 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:17 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:17 --> Total execution time: 0.0275
INFO - 2023-02-17 08:21:17 --> Config Class Initialized
INFO - 2023-02-17 08:21:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:17 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:17 --> URI Class Initialized
INFO - 2023-02-17 08:21:17 --> Router Class Initialized
INFO - 2023-02-17 08:21:17 --> Output Class Initialized
INFO - 2023-02-17 08:21:17 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:17 --> Input Class Initialized
INFO - 2023-02-17 08:21:17 --> Language Class Initialized
INFO - 2023-02-17 08:21:17 --> Loader Class Initialized
INFO - 2023-02-17 08:21:17 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:17 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:17 --> Total execution time: 0.0424
INFO - 2023-02-17 08:21:17 --> Config Class Initialized
INFO - 2023-02-17 08:21:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:17 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:17 --> URI Class Initialized
INFO - 2023-02-17 08:21:17 --> Router Class Initialized
INFO - 2023-02-17 08:21:17 --> Output Class Initialized
INFO - 2023-02-17 08:21:17 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:17 --> Input Class Initialized
INFO - 2023-02-17 08:21:17 --> Language Class Initialized
INFO - 2023-02-17 08:21:17 --> Loader Class Initialized
INFO - 2023-02-17 08:21:17 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:17 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:17 --> Model "Login_model" initialized
INFO - 2023-02-17 08:21:17 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:17 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:17 --> Total execution time: 0.0245
INFO - 2023-02-17 08:21:19 --> Config Class Initialized
INFO - 2023-02-17 08:21:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:19 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:19 --> URI Class Initialized
INFO - 2023-02-17 08:21:19 --> Router Class Initialized
INFO - 2023-02-17 08:21:19 --> Output Class Initialized
INFO - 2023-02-17 08:21:19 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:19 --> Input Class Initialized
INFO - 2023-02-17 08:21:19 --> Language Class Initialized
INFO - 2023-02-17 08:21:19 --> Loader Class Initialized
INFO - 2023-02-17 08:21:19 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:19 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:19 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:19 --> Model "Login_model" initialized
INFO - 2023-02-17 08:21:19 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:19 --> Total execution time: 0.1103
INFO - 2023-02-17 08:21:19 --> Config Class Initialized
INFO - 2023-02-17 08:21:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:21:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:21:19 --> Utf8 Class Initialized
INFO - 2023-02-17 08:21:19 --> URI Class Initialized
INFO - 2023-02-17 08:21:19 --> Router Class Initialized
INFO - 2023-02-17 08:21:19 --> Output Class Initialized
INFO - 2023-02-17 08:21:19 --> Security Class Initialized
DEBUG - 2023-02-17 08:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:21:19 --> Input Class Initialized
INFO - 2023-02-17 08:21:19 --> Language Class Initialized
INFO - 2023-02-17 08:21:19 --> Loader Class Initialized
INFO - 2023-02-17 08:21:19 --> Controller Class Initialized
DEBUG - 2023-02-17 08:21:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:21:19 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:21:19 --> Database Driver Class Initialized
INFO - 2023-02-17 08:21:19 --> Model "Login_model" initialized
INFO - 2023-02-17 08:21:19 --> Final output sent to browser
DEBUG - 2023-02-17 08:21:19 --> Total execution time: 0.0393
INFO - 2023-02-17 08:23:30 --> Config Class Initialized
INFO - 2023-02-17 08:23:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:23:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:23:30 --> Utf8 Class Initialized
INFO - 2023-02-17 08:23:30 --> URI Class Initialized
INFO - 2023-02-17 08:23:30 --> Router Class Initialized
INFO - 2023-02-17 08:23:30 --> Output Class Initialized
INFO - 2023-02-17 08:23:30 --> Security Class Initialized
DEBUG - 2023-02-17 08:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:23:30 --> Input Class Initialized
INFO - 2023-02-17 08:23:30 --> Language Class Initialized
INFO - 2023-02-17 08:23:30 --> Loader Class Initialized
INFO - 2023-02-17 08:23:30 --> Controller Class Initialized
DEBUG - 2023-02-17 08:23:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:23:30 --> Database Driver Class Initialized
INFO - 2023-02-17 08:23:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:23:30 --> Database Driver Class Initialized
INFO - 2023-02-17 08:23:30 --> Model "Login_model" initialized
INFO - 2023-02-17 08:23:30 --> Final output sent to browser
DEBUG - 2023-02-17 08:23:30 --> Total execution time: 0.1620
INFO - 2023-02-17 08:23:30 --> Config Class Initialized
INFO - 2023-02-17 08:23:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:23:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:23:31 --> Utf8 Class Initialized
INFO - 2023-02-17 08:23:31 --> URI Class Initialized
INFO - 2023-02-17 08:23:31 --> Router Class Initialized
INFO - 2023-02-17 08:23:31 --> Output Class Initialized
INFO - 2023-02-17 08:23:31 --> Security Class Initialized
DEBUG - 2023-02-17 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:23:31 --> Input Class Initialized
INFO - 2023-02-17 08:23:31 --> Language Class Initialized
INFO - 2023-02-17 08:23:31 --> Loader Class Initialized
INFO - 2023-02-17 08:23:31 --> Controller Class Initialized
DEBUG - 2023-02-17 08:23:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:23:31 --> Database Driver Class Initialized
INFO - 2023-02-17 08:23:31 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:23:31 --> Database Driver Class Initialized
INFO - 2023-02-17 08:23:31 --> Model "Login_model" initialized
INFO - 2023-02-17 08:23:31 --> Final output sent to browser
DEBUG - 2023-02-17 08:23:31 --> Total execution time: 0.2743
INFO - 2023-02-17 08:25:36 --> Config Class Initialized
INFO - 2023-02-17 08:25:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:25:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:25:36 --> Utf8 Class Initialized
INFO - 2023-02-17 08:25:36 --> URI Class Initialized
INFO - 2023-02-17 08:25:36 --> Router Class Initialized
INFO - 2023-02-17 08:25:36 --> Output Class Initialized
INFO - 2023-02-17 08:25:36 --> Security Class Initialized
DEBUG - 2023-02-17 08:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:25:36 --> Input Class Initialized
INFO - 2023-02-17 08:25:36 --> Language Class Initialized
INFO - 2023-02-17 08:25:36 --> Loader Class Initialized
INFO - 2023-02-17 08:25:36 --> Controller Class Initialized
DEBUG - 2023-02-17 08:25:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:25:36 --> Database Driver Class Initialized
INFO - 2023-02-17 08:25:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:25:36 --> Database Driver Class Initialized
INFO - 2023-02-17 08:25:36 --> Model "Login_model" initialized
INFO - 2023-02-17 08:25:36 --> Final output sent to browser
DEBUG - 2023-02-17 08:25:36 --> Total execution time: 0.1311
INFO - 2023-02-17 08:25:36 --> Config Class Initialized
INFO - 2023-02-17 08:25:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:25:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:25:36 --> Utf8 Class Initialized
INFO - 2023-02-17 08:25:36 --> URI Class Initialized
INFO - 2023-02-17 08:25:36 --> Router Class Initialized
INFO - 2023-02-17 08:25:36 --> Output Class Initialized
INFO - 2023-02-17 08:25:36 --> Security Class Initialized
DEBUG - 2023-02-17 08:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:25:36 --> Input Class Initialized
INFO - 2023-02-17 08:25:36 --> Language Class Initialized
INFO - 2023-02-17 08:25:36 --> Loader Class Initialized
INFO - 2023-02-17 08:25:36 --> Controller Class Initialized
DEBUG - 2023-02-17 08:25:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:25:36 --> Database Driver Class Initialized
INFO - 2023-02-17 08:25:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:25:36 --> Database Driver Class Initialized
INFO - 2023-02-17 08:25:36 --> Model "Login_model" initialized
INFO - 2023-02-17 08:25:36 --> Final output sent to browser
DEBUG - 2023-02-17 08:25:36 --> Total execution time: 0.0504
INFO - 2023-02-17 08:27:49 --> Config Class Initialized
INFO - 2023-02-17 08:27:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:27:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:27:49 --> Utf8 Class Initialized
INFO - 2023-02-17 08:27:49 --> URI Class Initialized
INFO - 2023-02-17 08:27:49 --> Router Class Initialized
INFO - 2023-02-17 08:27:49 --> Output Class Initialized
INFO - 2023-02-17 08:27:49 --> Security Class Initialized
DEBUG - 2023-02-17 08:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:27:49 --> Input Class Initialized
INFO - 2023-02-17 08:27:49 --> Language Class Initialized
INFO - 2023-02-17 08:27:49 --> Loader Class Initialized
INFO - 2023-02-17 08:27:49 --> Controller Class Initialized
DEBUG - 2023-02-17 08:27:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:27:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:27:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:27:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:27:49 --> Model "Login_model" initialized
INFO - 2023-02-17 08:27:49 --> Final output sent to browser
DEBUG - 2023-02-17 08:27:49 --> Total execution time: 0.1936
INFO - 2023-02-17 08:27:49 --> Config Class Initialized
INFO - 2023-02-17 08:27:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:27:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:27:49 --> Utf8 Class Initialized
INFO - 2023-02-17 08:27:49 --> URI Class Initialized
INFO - 2023-02-17 08:27:49 --> Router Class Initialized
INFO - 2023-02-17 08:27:49 --> Output Class Initialized
INFO - 2023-02-17 08:27:49 --> Security Class Initialized
DEBUG - 2023-02-17 08:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:27:49 --> Input Class Initialized
INFO - 2023-02-17 08:27:49 --> Language Class Initialized
INFO - 2023-02-17 08:27:49 --> Loader Class Initialized
INFO - 2023-02-17 08:27:49 --> Controller Class Initialized
DEBUG - 2023-02-17 08:27:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:27:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:27:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:27:49 --> Database Driver Class Initialized
INFO - 2023-02-17 08:27:49 --> Model "Login_model" initialized
INFO - 2023-02-17 08:27:49 --> Final output sent to browser
DEBUG - 2023-02-17 08:27:49 --> Total execution time: 0.2333
INFO - 2023-02-17 08:28:05 --> Config Class Initialized
INFO - 2023-02-17 08:28:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:05 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:05 --> URI Class Initialized
INFO - 2023-02-17 08:28:05 --> Router Class Initialized
INFO - 2023-02-17 08:28:05 --> Output Class Initialized
INFO - 2023-02-17 08:28:05 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:05 --> Input Class Initialized
INFO - 2023-02-17 08:28:05 --> Language Class Initialized
INFO - 2023-02-17 08:28:05 --> Loader Class Initialized
INFO - 2023-02-17 08:28:05 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:05 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:05 --> Total execution time: 0.0036
INFO - 2023-02-17 08:28:05 --> Config Class Initialized
INFO - 2023-02-17 08:28:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:05 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:05 --> URI Class Initialized
INFO - 2023-02-17 08:28:05 --> Router Class Initialized
INFO - 2023-02-17 08:28:05 --> Output Class Initialized
INFO - 2023-02-17 08:28:05 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:05 --> Input Class Initialized
INFO - 2023-02-17 08:28:05 --> Language Class Initialized
INFO - 2023-02-17 08:28:05 --> Loader Class Initialized
INFO - 2023-02-17 08:28:05 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:05 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:05 --> Model "Login_model" initialized
INFO - 2023-02-17 08:28:05 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:05 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:05 --> Total execution time: 0.0282
INFO - 2023-02-17 08:28:05 --> Config Class Initialized
INFO - 2023-02-17 08:28:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:05 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:05 --> URI Class Initialized
INFO - 2023-02-17 08:28:05 --> Router Class Initialized
INFO - 2023-02-17 08:28:05 --> Output Class Initialized
INFO - 2023-02-17 08:28:05 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:05 --> Input Class Initialized
INFO - 2023-02-17 08:28:05 --> Language Class Initialized
INFO - 2023-02-17 08:28:05 --> Loader Class Initialized
INFO - 2023-02-17 08:28:05 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:05 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:05 --> Total execution time: 0.0427
INFO - 2023-02-17 08:28:05 --> Config Class Initialized
INFO - 2023-02-17 08:28:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:05 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:05 --> URI Class Initialized
INFO - 2023-02-17 08:28:05 --> Router Class Initialized
INFO - 2023-02-17 08:28:05 --> Output Class Initialized
INFO - 2023-02-17 08:28:05 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:05 --> Input Class Initialized
INFO - 2023-02-17 08:28:05 --> Language Class Initialized
INFO - 2023-02-17 08:28:05 --> Loader Class Initialized
INFO - 2023-02-17 08:28:05 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:05 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:05 --> Model "Login_model" initialized
INFO - 2023-02-17 08:28:05 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:05 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:05 --> Total execution time: 0.0350
INFO - 2023-02-17 08:28:07 --> Config Class Initialized
INFO - 2023-02-17 08:28:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:07 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:07 --> URI Class Initialized
INFO - 2023-02-17 08:28:07 --> Router Class Initialized
INFO - 2023-02-17 08:28:07 --> Output Class Initialized
INFO - 2023-02-17 08:28:07 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:07 --> Input Class Initialized
INFO - 2023-02-17 08:28:07 --> Language Class Initialized
INFO - 2023-02-17 08:28:07 --> Loader Class Initialized
INFO - 2023-02-17 08:28:07 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:07 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:07 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:07 --> Total execution time: 0.0236
INFO - 2023-02-17 08:28:07 --> Config Class Initialized
INFO - 2023-02-17 08:28:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:07 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:07 --> URI Class Initialized
INFO - 2023-02-17 08:28:07 --> Router Class Initialized
INFO - 2023-02-17 08:28:07 --> Output Class Initialized
INFO - 2023-02-17 08:28:07 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:07 --> Input Class Initialized
INFO - 2023-02-17 08:28:07 --> Language Class Initialized
INFO - 2023-02-17 08:28:07 --> Loader Class Initialized
INFO - 2023-02-17 08:28:07 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:07 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:07 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:07 --> Total execution time: 0.0530
INFO - 2023-02-17 08:28:09 --> Config Class Initialized
INFO - 2023-02-17 08:28:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:09 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:09 --> URI Class Initialized
INFO - 2023-02-17 08:28:09 --> Router Class Initialized
INFO - 2023-02-17 08:28:09 --> Output Class Initialized
INFO - 2023-02-17 08:28:09 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:09 --> Input Class Initialized
INFO - 2023-02-17 08:28:09 --> Language Class Initialized
INFO - 2023-02-17 08:28:09 --> Loader Class Initialized
INFO - 2023-02-17 08:28:09 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:09 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:09 --> Total execution time: 0.0037
INFO - 2023-02-17 08:28:09 --> Config Class Initialized
INFO - 2023-02-17 08:28:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:09 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:09 --> URI Class Initialized
INFO - 2023-02-17 08:28:09 --> Router Class Initialized
INFO - 2023-02-17 08:28:09 --> Output Class Initialized
INFO - 2023-02-17 08:28:09 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:09 --> Input Class Initialized
INFO - 2023-02-17 08:28:09 --> Language Class Initialized
INFO - 2023-02-17 08:28:09 --> Loader Class Initialized
INFO - 2023-02-17 08:28:09 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:09 --> Model "Login_model" initialized
INFO - 2023-02-17 08:28:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:09 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:09 --> Total execution time: 0.0279
INFO - 2023-02-17 08:28:09 --> Config Class Initialized
INFO - 2023-02-17 08:28:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:09 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:09 --> URI Class Initialized
INFO - 2023-02-17 08:28:09 --> Router Class Initialized
INFO - 2023-02-17 08:28:09 --> Output Class Initialized
INFO - 2023-02-17 08:28:09 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:09 --> Input Class Initialized
INFO - 2023-02-17 08:28:09 --> Language Class Initialized
INFO - 2023-02-17 08:28:09 --> Loader Class Initialized
INFO - 2023-02-17 08:28:09 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:09 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:09 --> Total execution time: 0.0459
INFO - 2023-02-17 08:28:09 --> Config Class Initialized
INFO - 2023-02-17 08:28:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:09 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:09 --> URI Class Initialized
INFO - 2023-02-17 08:28:09 --> Router Class Initialized
INFO - 2023-02-17 08:28:09 --> Output Class Initialized
INFO - 2023-02-17 08:28:09 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:09 --> Input Class Initialized
INFO - 2023-02-17 08:28:09 --> Language Class Initialized
INFO - 2023-02-17 08:28:09 --> Loader Class Initialized
INFO - 2023-02-17 08:28:09 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:09 --> Model "Login_model" initialized
INFO - 2023-02-17 08:28:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:09 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:09 --> Total execution time: 0.0664
INFO - 2023-02-17 08:28:10 --> Config Class Initialized
INFO - 2023-02-17 08:28:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:10 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:10 --> URI Class Initialized
INFO - 2023-02-17 08:28:10 --> Router Class Initialized
INFO - 2023-02-17 08:28:10 --> Output Class Initialized
INFO - 2023-02-17 08:28:10 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:10 --> Input Class Initialized
INFO - 2023-02-17 08:28:10 --> Language Class Initialized
INFO - 2023-02-17 08:28:10 --> Loader Class Initialized
INFO - 2023-02-17 08:28:10 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:10 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:10 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:10 --> Model "Login_model" initialized
INFO - 2023-02-17 08:28:10 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:10 --> Total execution time: 0.0563
INFO - 2023-02-17 08:28:10 --> Config Class Initialized
INFO - 2023-02-17 08:28:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:10 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:10 --> URI Class Initialized
INFO - 2023-02-17 08:28:10 --> Router Class Initialized
INFO - 2023-02-17 08:28:10 --> Output Class Initialized
INFO - 2023-02-17 08:28:10 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:10 --> Input Class Initialized
INFO - 2023-02-17 08:28:10 --> Language Class Initialized
INFO - 2023-02-17 08:28:10 --> Loader Class Initialized
INFO - 2023-02-17 08:28:10 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:10 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:10 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:10 --> Model "Login_model" initialized
INFO - 2023-02-17 08:28:10 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:10 --> Total execution time: 0.0398
INFO - 2023-02-17 08:28:16 --> Config Class Initialized
INFO - 2023-02-17 08:28:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:16 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:16 --> URI Class Initialized
INFO - 2023-02-17 08:28:16 --> Router Class Initialized
INFO - 2023-02-17 08:28:16 --> Output Class Initialized
INFO - 2023-02-17 08:28:16 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:16 --> Input Class Initialized
INFO - 2023-02-17 08:28:16 --> Language Class Initialized
INFO - 2023-02-17 08:28:16 --> Loader Class Initialized
INFO - 2023-02-17 08:28:16 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:16 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:16 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:16 --> Total execution time: 0.0491
INFO - 2023-02-17 08:28:16 --> Config Class Initialized
INFO - 2023-02-17 08:28:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:16 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:16 --> URI Class Initialized
INFO - 2023-02-17 08:28:16 --> Router Class Initialized
INFO - 2023-02-17 08:28:16 --> Output Class Initialized
INFO - 2023-02-17 08:28:16 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:16 --> Input Class Initialized
INFO - 2023-02-17 08:28:16 --> Language Class Initialized
INFO - 2023-02-17 08:28:16 --> Loader Class Initialized
INFO - 2023-02-17 08:28:16 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:16 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:16 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:16 --> Total execution time: 0.0840
INFO - 2023-02-17 08:28:20 --> Config Class Initialized
INFO - 2023-02-17 08:28:20 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:20 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:20 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:20 --> URI Class Initialized
INFO - 2023-02-17 08:28:20 --> Router Class Initialized
INFO - 2023-02-17 08:28:20 --> Output Class Initialized
INFO - 2023-02-17 08:28:20 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:20 --> Input Class Initialized
INFO - 2023-02-17 08:28:20 --> Language Class Initialized
INFO - 2023-02-17 08:28:20 --> Loader Class Initialized
INFO - 2023-02-17 08:28:20 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:20 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:21 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:21 --> Total execution time: 1.0154
INFO - 2023-02-17 08:28:21 --> Config Class Initialized
INFO - 2023-02-17 08:28:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:21 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:21 --> URI Class Initialized
INFO - 2023-02-17 08:28:21 --> Router Class Initialized
INFO - 2023-02-17 08:28:21 --> Output Class Initialized
INFO - 2023-02-17 08:28:21 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:21 --> Input Class Initialized
INFO - 2023-02-17 08:28:21 --> Language Class Initialized
INFO - 2023-02-17 08:28:21 --> Loader Class Initialized
INFO - 2023-02-17 08:28:21 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:21 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:21 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:21 --> Total execution time: 0.0588
INFO - 2023-02-17 08:28:25 --> Config Class Initialized
INFO - 2023-02-17 08:28:25 --> Config Class Initialized
INFO - 2023-02-17 08:28:25 --> Hooks Class Initialized
INFO - 2023-02-17 08:28:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:25 --> Utf8 Class Initialized
DEBUG - 2023-02-17 08:28:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:25 --> URI Class Initialized
INFO - 2023-02-17 08:28:25 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:25 --> Router Class Initialized
INFO - 2023-02-17 08:28:25 --> URI Class Initialized
INFO - 2023-02-17 08:28:25 --> Output Class Initialized
INFO - 2023-02-17 08:28:25 --> Router Class Initialized
INFO - 2023-02-17 08:28:25 --> Output Class Initialized
INFO - 2023-02-17 08:28:25 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:25 --> Input Class Initialized
INFO - 2023-02-17 08:28:25 --> Language Class Initialized
INFO - 2023-02-17 08:28:25 --> Loader Class Initialized
INFO - 2023-02-17 08:28:25 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:25 --> Input Class Initialized
INFO - 2023-02-17 08:28:25 --> Language Class Initialized
INFO - 2023-02-17 08:28:25 --> Loader Class Initialized
INFO - 2023-02-17 08:28:25 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:25 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:25 --> Total execution time: 0.0120
INFO - 2023-02-17 08:28:25 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:25 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:25 --> Config Class Initialized
INFO - 2023-02-17 08:28:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:25 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:25 --> URI Class Initialized
INFO - 2023-02-17 08:28:25 --> Router Class Initialized
INFO - 2023-02-17 08:28:25 --> Output Class Initialized
INFO - 2023-02-17 08:28:25 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:25 --> Input Class Initialized
INFO - 2023-02-17 08:28:25 --> Language Class Initialized
INFO - 2023-02-17 08:28:25 --> Loader Class Initialized
INFO - 2023-02-17 08:28:25 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:25 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:25 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:25 --> Total execution time: 0.0611
INFO - 2023-02-17 08:28:25 --> Config Class Initialized
INFO - 2023-02-17 08:28:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:25 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:25 --> URI Class Initialized
INFO - 2023-02-17 08:28:25 --> Router Class Initialized
INFO - 2023-02-17 08:28:25 --> Output Class Initialized
INFO - 2023-02-17 08:28:25 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:25 --> Input Class Initialized
INFO - 2023-02-17 08:28:25 --> Language Class Initialized
INFO - 2023-02-17 08:28:25 --> Loader Class Initialized
INFO - 2023-02-17 08:28:25 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:25 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:25 --> Model "Login_model" initialized
INFO - 2023-02-17 08:28:25 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:25 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:25 --> Total execution time: 0.0155
INFO - 2023-02-17 08:28:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:25 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:25 --> Total execution time: 0.1047
INFO - 2023-02-17 08:28:28 --> Config Class Initialized
INFO - 2023-02-17 08:28:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:28 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:28 --> URI Class Initialized
INFO - 2023-02-17 08:28:28 --> Router Class Initialized
INFO - 2023-02-17 08:28:28 --> Output Class Initialized
INFO - 2023-02-17 08:28:28 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:28 --> Input Class Initialized
INFO - 2023-02-17 08:28:28 --> Language Class Initialized
INFO - 2023-02-17 08:28:28 --> Loader Class Initialized
INFO - 2023-02-17 08:28:28 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:28 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:28 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:28 --> Total execution time: 0.0802
INFO - 2023-02-17 08:28:28 --> Config Class Initialized
INFO - 2023-02-17 08:28:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:28:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:28:28 --> Utf8 Class Initialized
INFO - 2023-02-17 08:28:28 --> URI Class Initialized
INFO - 2023-02-17 08:28:28 --> Router Class Initialized
INFO - 2023-02-17 08:28:28 --> Output Class Initialized
INFO - 2023-02-17 08:28:28 --> Security Class Initialized
DEBUG - 2023-02-17 08:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:28:28 --> Input Class Initialized
INFO - 2023-02-17 08:28:28 --> Language Class Initialized
INFO - 2023-02-17 08:28:28 --> Loader Class Initialized
INFO - 2023-02-17 08:28:28 --> Controller Class Initialized
DEBUG - 2023-02-17 08:28:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:28:28 --> Database Driver Class Initialized
INFO - 2023-02-17 08:28:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:28:28 --> Final output sent to browser
DEBUG - 2023-02-17 08:28:28 --> Total execution time: 0.0791
INFO - 2023-02-17 08:29:05 --> Config Class Initialized
INFO - 2023-02-17 08:29:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:29:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:29:05 --> Utf8 Class Initialized
INFO - 2023-02-17 08:29:05 --> URI Class Initialized
INFO - 2023-02-17 08:29:05 --> Router Class Initialized
INFO - 2023-02-17 08:29:05 --> Output Class Initialized
INFO - 2023-02-17 08:29:05 --> Security Class Initialized
DEBUG - 2023-02-17 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:29:05 --> Input Class Initialized
INFO - 2023-02-17 08:29:05 --> Language Class Initialized
INFO - 2023-02-17 08:29:05 --> Loader Class Initialized
INFO - 2023-02-17 08:29:05 --> Controller Class Initialized
DEBUG - 2023-02-17 08:29:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:29:05 --> Database Driver Class Initialized
INFO - 2023-02-17 08:29:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:29:05 --> Database Driver Class Initialized
INFO - 2023-02-17 08:29:05 --> Model "Login_model" initialized
INFO - 2023-02-17 08:29:05 --> Final output sent to browser
DEBUG - 2023-02-17 08:29:05 --> Total execution time: 0.0462
INFO - 2023-02-17 08:29:05 --> Config Class Initialized
INFO - 2023-02-17 08:29:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:29:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:29:05 --> Utf8 Class Initialized
INFO - 2023-02-17 08:29:05 --> URI Class Initialized
INFO - 2023-02-17 08:29:05 --> Router Class Initialized
INFO - 2023-02-17 08:29:05 --> Output Class Initialized
INFO - 2023-02-17 08:29:05 --> Security Class Initialized
DEBUG - 2023-02-17 08:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:29:05 --> Input Class Initialized
INFO - 2023-02-17 08:29:05 --> Language Class Initialized
INFO - 2023-02-17 08:29:05 --> Loader Class Initialized
INFO - 2023-02-17 08:29:05 --> Controller Class Initialized
DEBUG - 2023-02-17 08:29:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:29:05 --> Database Driver Class Initialized
INFO - 2023-02-17 08:29:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:29:05 --> Database Driver Class Initialized
INFO - 2023-02-17 08:29:05 --> Model "Login_model" initialized
INFO - 2023-02-17 08:29:05 --> Final output sent to browser
DEBUG - 2023-02-17 08:29:05 --> Total execution time: 0.1077
INFO - 2023-02-17 08:29:13 --> Config Class Initialized
INFO - 2023-02-17 08:29:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:29:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:29:13 --> Utf8 Class Initialized
INFO - 2023-02-17 08:29:13 --> URI Class Initialized
INFO - 2023-02-17 08:29:13 --> Router Class Initialized
INFO - 2023-02-17 08:29:13 --> Output Class Initialized
INFO - 2023-02-17 08:29:13 --> Security Class Initialized
DEBUG - 2023-02-17 08:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:29:13 --> Input Class Initialized
INFO - 2023-02-17 08:29:13 --> Language Class Initialized
INFO - 2023-02-17 08:29:13 --> Loader Class Initialized
INFO - 2023-02-17 08:29:13 --> Controller Class Initialized
DEBUG - 2023-02-17 08:29:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:29:13 --> Database Driver Class Initialized
INFO - 2023-02-17 08:29:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:29:13 --> Database Driver Class Initialized
INFO - 2023-02-17 08:29:13 --> Model "Login_model" initialized
INFO - 2023-02-17 08:29:13 --> Final output sent to browser
DEBUG - 2023-02-17 08:29:13 --> Total execution time: 0.0515
INFO - 2023-02-17 08:29:13 --> Config Class Initialized
INFO - 2023-02-17 08:29:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:29:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:29:13 --> Utf8 Class Initialized
INFO - 2023-02-17 08:29:13 --> URI Class Initialized
INFO - 2023-02-17 08:29:13 --> Router Class Initialized
INFO - 2023-02-17 08:29:13 --> Output Class Initialized
INFO - 2023-02-17 08:29:13 --> Security Class Initialized
DEBUG - 2023-02-17 08:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:29:13 --> Input Class Initialized
INFO - 2023-02-17 08:29:13 --> Language Class Initialized
INFO - 2023-02-17 08:29:13 --> Loader Class Initialized
INFO - 2023-02-17 08:29:13 --> Controller Class Initialized
DEBUG - 2023-02-17 08:29:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:29:13 --> Database Driver Class Initialized
INFO - 2023-02-17 08:29:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:29:13 --> Database Driver Class Initialized
INFO - 2023-02-17 08:29:13 --> Model "Login_model" initialized
INFO - 2023-02-17 08:29:13 --> Final output sent to browser
DEBUG - 2023-02-17 08:29:13 --> Total execution time: 0.0393
INFO - 2023-02-17 08:31:59 --> Config Class Initialized
INFO - 2023-02-17 08:31:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:31:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:31:59 --> Utf8 Class Initialized
INFO - 2023-02-17 08:31:59 --> URI Class Initialized
INFO - 2023-02-17 08:31:59 --> Router Class Initialized
INFO - 2023-02-17 08:31:59 --> Output Class Initialized
INFO - 2023-02-17 08:31:59 --> Security Class Initialized
DEBUG - 2023-02-17 08:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:31:59 --> Input Class Initialized
INFO - 2023-02-17 08:31:59 --> Language Class Initialized
INFO - 2023-02-17 08:31:59 --> Loader Class Initialized
INFO - 2023-02-17 08:31:59 --> Controller Class Initialized
DEBUG - 2023-02-17 08:31:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:31:59 --> Database Driver Class Initialized
INFO - 2023-02-17 08:31:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:31:59 --> Database Driver Class Initialized
INFO - 2023-02-17 08:31:59 --> Model "Login_model" initialized
INFO - 2023-02-17 08:31:59 --> Final output sent to browser
DEBUG - 2023-02-17 08:31:59 --> Total execution time: 0.1466
INFO - 2023-02-17 08:31:59 --> Config Class Initialized
INFO - 2023-02-17 08:32:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:32:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:32:00 --> Utf8 Class Initialized
INFO - 2023-02-17 08:32:00 --> URI Class Initialized
INFO - 2023-02-17 08:32:00 --> Router Class Initialized
INFO - 2023-02-17 08:32:00 --> Output Class Initialized
INFO - 2023-02-17 08:32:00 --> Security Class Initialized
DEBUG - 2023-02-17 08:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:32:00 --> Input Class Initialized
INFO - 2023-02-17 08:32:00 --> Language Class Initialized
INFO - 2023-02-17 08:32:00 --> Loader Class Initialized
INFO - 2023-02-17 08:32:00 --> Controller Class Initialized
DEBUG - 2023-02-17 08:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:32:00 --> Database Driver Class Initialized
INFO - 2023-02-17 08:32:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:32:00 --> Database Driver Class Initialized
INFO - 2023-02-17 08:32:00 --> Model "Login_model" initialized
INFO - 2023-02-17 08:32:00 --> Final output sent to browser
DEBUG - 2023-02-17 08:32:00 --> Total execution time: 0.1215
INFO - 2023-02-17 08:32:43 --> Config Class Initialized
INFO - 2023-02-17 08:32:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:32:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:32:43 --> Utf8 Class Initialized
INFO - 2023-02-17 08:32:43 --> URI Class Initialized
INFO - 2023-02-17 08:32:43 --> Router Class Initialized
INFO - 2023-02-17 08:32:43 --> Output Class Initialized
INFO - 2023-02-17 08:32:43 --> Security Class Initialized
DEBUG - 2023-02-17 08:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:32:43 --> Input Class Initialized
INFO - 2023-02-17 08:32:43 --> Language Class Initialized
INFO - 2023-02-17 08:32:43 --> Loader Class Initialized
INFO - 2023-02-17 08:32:43 --> Controller Class Initialized
DEBUG - 2023-02-17 08:32:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:32:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:32:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:32:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:32:43 --> Model "Login_model" initialized
INFO - 2023-02-17 08:32:44 --> Final output sent to browser
DEBUG - 2023-02-17 08:32:44 --> Total execution time: 0.1748
INFO - 2023-02-17 08:32:44 --> Config Class Initialized
INFO - 2023-02-17 08:32:44 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:32:44 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:32:44 --> Utf8 Class Initialized
INFO - 2023-02-17 08:32:44 --> URI Class Initialized
INFO - 2023-02-17 08:32:44 --> Router Class Initialized
INFO - 2023-02-17 08:32:44 --> Output Class Initialized
INFO - 2023-02-17 08:32:44 --> Security Class Initialized
DEBUG - 2023-02-17 08:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:32:44 --> Input Class Initialized
INFO - 2023-02-17 08:32:44 --> Language Class Initialized
INFO - 2023-02-17 08:32:44 --> Loader Class Initialized
INFO - 2023-02-17 08:32:44 --> Controller Class Initialized
DEBUG - 2023-02-17 08:32:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:32:44 --> Database Driver Class Initialized
INFO - 2023-02-17 08:32:44 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:32:44 --> Database Driver Class Initialized
INFO - 2023-02-17 08:32:44 --> Model "Login_model" initialized
INFO - 2023-02-17 08:32:44 --> Final output sent to browser
DEBUG - 2023-02-17 08:32:44 --> Total execution time: 0.0479
INFO - 2023-02-17 08:33:14 --> Config Class Initialized
INFO - 2023-02-17 08:33:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:33:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:33:14 --> Utf8 Class Initialized
INFO - 2023-02-17 08:33:14 --> URI Class Initialized
INFO - 2023-02-17 08:33:14 --> Router Class Initialized
INFO - 2023-02-17 08:33:14 --> Output Class Initialized
INFO - 2023-02-17 08:33:14 --> Security Class Initialized
DEBUG - 2023-02-17 08:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:33:14 --> Input Class Initialized
INFO - 2023-02-17 08:33:14 --> Language Class Initialized
INFO - 2023-02-17 08:33:14 --> Loader Class Initialized
INFO - 2023-02-17 08:33:14 --> Controller Class Initialized
DEBUG - 2023-02-17 08:33:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:33:14 --> Database Driver Class Initialized
INFO - 2023-02-17 08:33:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:33:14 --> Database Driver Class Initialized
INFO - 2023-02-17 08:33:14 --> Model "Login_model" initialized
INFO - 2023-02-17 08:33:14 --> Final output sent to browser
DEBUG - 2023-02-17 08:33:14 --> Total execution time: 0.2086
INFO - 2023-02-17 08:33:14 --> Config Class Initialized
INFO - 2023-02-17 08:33:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:33:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:33:14 --> Utf8 Class Initialized
INFO - 2023-02-17 08:33:14 --> URI Class Initialized
INFO - 2023-02-17 08:33:14 --> Router Class Initialized
INFO - 2023-02-17 08:33:14 --> Output Class Initialized
INFO - 2023-02-17 08:33:14 --> Security Class Initialized
DEBUG - 2023-02-17 08:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:33:14 --> Input Class Initialized
INFO - 2023-02-17 08:33:14 --> Language Class Initialized
INFO - 2023-02-17 08:33:14 --> Loader Class Initialized
INFO - 2023-02-17 08:33:14 --> Controller Class Initialized
DEBUG - 2023-02-17 08:33:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:33:14 --> Database Driver Class Initialized
INFO - 2023-02-17 08:33:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:33:14 --> Database Driver Class Initialized
INFO - 2023-02-17 08:33:14 --> Model "Login_model" initialized
INFO - 2023-02-17 08:33:14 --> Final output sent to browser
DEBUG - 2023-02-17 08:33:14 --> Total execution time: 0.0425
INFO - 2023-02-17 08:37:43 --> Config Class Initialized
INFO - 2023-02-17 08:37:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:37:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:37:43 --> Utf8 Class Initialized
INFO - 2023-02-17 08:37:43 --> URI Class Initialized
INFO - 2023-02-17 08:37:43 --> Router Class Initialized
INFO - 2023-02-17 08:37:43 --> Output Class Initialized
INFO - 2023-02-17 08:37:43 --> Security Class Initialized
DEBUG - 2023-02-17 08:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:37:43 --> Input Class Initialized
INFO - 2023-02-17 08:37:43 --> Language Class Initialized
INFO - 2023-02-17 08:37:43 --> Loader Class Initialized
INFO - 2023-02-17 08:37:43 --> Controller Class Initialized
DEBUG - 2023-02-17 08:37:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:37:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:37:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:37:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:37:43 --> Model "Login_model" initialized
INFO - 2023-02-17 08:37:43 --> Final output sent to browser
DEBUG - 2023-02-17 08:37:43 --> Total execution time: 0.1460
INFO - 2023-02-17 08:37:43 --> Config Class Initialized
INFO - 2023-02-17 08:37:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:37:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:37:43 --> Utf8 Class Initialized
INFO - 2023-02-17 08:37:43 --> URI Class Initialized
INFO - 2023-02-17 08:37:43 --> Router Class Initialized
INFO - 2023-02-17 08:37:43 --> Output Class Initialized
INFO - 2023-02-17 08:37:43 --> Security Class Initialized
DEBUG - 2023-02-17 08:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:37:43 --> Input Class Initialized
INFO - 2023-02-17 08:37:43 --> Language Class Initialized
INFO - 2023-02-17 08:37:43 --> Loader Class Initialized
INFO - 2023-02-17 08:37:43 --> Controller Class Initialized
DEBUG - 2023-02-17 08:37:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:37:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:37:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:37:43 --> Database Driver Class Initialized
INFO - 2023-02-17 08:37:43 --> Model "Login_model" initialized
INFO - 2023-02-17 08:37:43 --> Final output sent to browser
DEBUG - 2023-02-17 08:37:43 --> Total execution time: 0.0451
INFO - 2023-02-17 08:39:55 --> Config Class Initialized
INFO - 2023-02-17 08:39:56 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:39:56 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:39:56 --> Utf8 Class Initialized
INFO - 2023-02-17 08:39:56 --> URI Class Initialized
INFO - 2023-02-17 08:39:56 --> Router Class Initialized
INFO - 2023-02-17 08:39:56 --> Output Class Initialized
INFO - 2023-02-17 08:39:56 --> Security Class Initialized
DEBUG - 2023-02-17 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:39:56 --> Input Class Initialized
INFO - 2023-02-17 08:39:56 --> Language Class Initialized
INFO - 2023-02-17 08:39:56 --> Loader Class Initialized
INFO - 2023-02-17 08:39:56 --> Controller Class Initialized
DEBUG - 2023-02-17 08:39:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:39:56 --> Database Driver Class Initialized
INFO - 2023-02-17 08:39:56 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:39:56 --> Database Driver Class Initialized
INFO - 2023-02-17 08:39:56 --> Model "Login_model" initialized
INFO - 2023-02-17 08:39:56 --> Final output sent to browser
DEBUG - 2023-02-17 08:39:56 --> Total execution time: 0.1774
INFO - 2023-02-17 08:39:56 --> Config Class Initialized
INFO - 2023-02-17 08:39:56 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:39:56 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:39:56 --> Utf8 Class Initialized
INFO - 2023-02-17 08:39:56 --> URI Class Initialized
INFO - 2023-02-17 08:39:56 --> Router Class Initialized
INFO - 2023-02-17 08:39:56 --> Output Class Initialized
INFO - 2023-02-17 08:39:56 --> Security Class Initialized
DEBUG - 2023-02-17 08:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:39:56 --> Input Class Initialized
INFO - 2023-02-17 08:39:56 --> Language Class Initialized
INFO - 2023-02-17 08:39:56 --> Loader Class Initialized
INFO - 2023-02-17 08:39:56 --> Controller Class Initialized
DEBUG - 2023-02-17 08:39:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:39:56 --> Database Driver Class Initialized
INFO - 2023-02-17 08:39:56 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:39:56 --> Database Driver Class Initialized
INFO - 2023-02-17 08:39:56 --> Model "Login_model" initialized
INFO - 2023-02-17 08:39:56 --> Final output sent to browser
DEBUG - 2023-02-17 08:39:56 --> Total execution time: 0.0412
INFO - 2023-02-17 08:46:09 --> Config Class Initialized
INFO - 2023-02-17 08:46:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:46:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:46:09 --> Utf8 Class Initialized
INFO - 2023-02-17 08:46:09 --> URI Class Initialized
INFO - 2023-02-17 08:46:09 --> Router Class Initialized
INFO - 2023-02-17 08:46:09 --> Output Class Initialized
INFO - 2023-02-17 08:46:09 --> Security Class Initialized
DEBUG - 2023-02-17 08:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:46:09 --> Input Class Initialized
INFO - 2023-02-17 08:46:09 --> Language Class Initialized
INFO - 2023-02-17 08:46:09 --> Loader Class Initialized
INFO - 2023-02-17 08:46:09 --> Controller Class Initialized
DEBUG - 2023-02-17 08:46:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:46:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:46:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:46:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:46:09 --> Model "Login_model" initialized
INFO - 2023-02-17 08:46:09 --> Final output sent to browser
DEBUG - 2023-02-17 08:46:09 --> Total execution time: 0.1777
INFO - 2023-02-17 08:46:09 --> Config Class Initialized
INFO - 2023-02-17 08:46:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:46:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:46:09 --> Utf8 Class Initialized
INFO - 2023-02-17 08:46:09 --> URI Class Initialized
INFO - 2023-02-17 08:46:09 --> Router Class Initialized
INFO - 2023-02-17 08:46:09 --> Output Class Initialized
INFO - 2023-02-17 08:46:09 --> Security Class Initialized
DEBUG - 2023-02-17 08:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:46:09 --> Input Class Initialized
INFO - 2023-02-17 08:46:09 --> Language Class Initialized
INFO - 2023-02-17 08:46:09 --> Loader Class Initialized
INFO - 2023-02-17 08:46:09 --> Controller Class Initialized
DEBUG - 2023-02-17 08:46:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:46:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:46:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:46:09 --> Database Driver Class Initialized
INFO - 2023-02-17 08:46:09 --> Model "Login_model" initialized
INFO - 2023-02-17 08:46:09 --> Final output sent to browser
DEBUG - 2023-02-17 08:46:09 --> Total execution time: 0.1298
INFO - 2023-02-17 08:50:16 --> Config Class Initialized
INFO - 2023-02-17 08:50:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:50:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:50:17 --> Utf8 Class Initialized
INFO - 2023-02-17 08:50:17 --> URI Class Initialized
INFO - 2023-02-17 08:50:17 --> Router Class Initialized
INFO - 2023-02-17 08:50:17 --> Output Class Initialized
INFO - 2023-02-17 08:50:17 --> Security Class Initialized
DEBUG - 2023-02-17 08:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:50:17 --> Input Class Initialized
INFO - 2023-02-17 08:50:17 --> Language Class Initialized
INFO - 2023-02-17 08:50:17 --> Loader Class Initialized
INFO - 2023-02-17 08:50:17 --> Controller Class Initialized
DEBUG - 2023-02-17 08:50:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:50:17 --> Database Driver Class Initialized
INFO - 2023-02-17 08:50:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:50:17 --> Database Driver Class Initialized
INFO - 2023-02-17 08:50:17 --> Model "Login_model" initialized
INFO - 2023-02-17 08:50:17 --> Final output sent to browser
DEBUG - 2023-02-17 08:50:17 --> Total execution time: 0.1266
INFO - 2023-02-17 08:50:17 --> Config Class Initialized
INFO - 2023-02-17 08:50:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:50:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:50:17 --> Utf8 Class Initialized
INFO - 2023-02-17 08:50:17 --> URI Class Initialized
INFO - 2023-02-17 08:50:17 --> Router Class Initialized
INFO - 2023-02-17 08:50:17 --> Output Class Initialized
INFO - 2023-02-17 08:50:17 --> Security Class Initialized
DEBUG - 2023-02-17 08:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:50:17 --> Input Class Initialized
INFO - 2023-02-17 08:50:17 --> Language Class Initialized
INFO - 2023-02-17 08:50:17 --> Loader Class Initialized
INFO - 2023-02-17 08:50:17 --> Controller Class Initialized
DEBUG - 2023-02-17 08:50:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:50:17 --> Database Driver Class Initialized
INFO - 2023-02-17 08:50:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:50:17 --> Database Driver Class Initialized
INFO - 2023-02-17 08:50:17 --> Model "Login_model" initialized
INFO - 2023-02-17 08:50:17 --> Final output sent to browser
DEBUG - 2023-02-17 08:50:17 --> Total execution time: 0.0882
INFO - 2023-02-17 08:54:01 --> Config Class Initialized
INFO - 2023-02-17 08:54:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:54:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:54:01 --> Utf8 Class Initialized
INFO - 2023-02-17 08:54:01 --> URI Class Initialized
INFO - 2023-02-17 08:54:01 --> Router Class Initialized
INFO - 2023-02-17 08:54:01 --> Output Class Initialized
INFO - 2023-02-17 08:54:01 --> Security Class Initialized
DEBUG - 2023-02-17 08:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:54:01 --> Input Class Initialized
INFO - 2023-02-17 08:54:01 --> Language Class Initialized
INFO - 2023-02-17 08:54:01 --> Loader Class Initialized
INFO - 2023-02-17 08:54:01 --> Controller Class Initialized
DEBUG - 2023-02-17 08:54:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:54:01 --> Database Driver Class Initialized
INFO - 2023-02-17 08:54:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:54:01 --> Database Driver Class Initialized
INFO - 2023-02-17 08:54:01 --> Model "Login_model" initialized
INFO - 2023-02-17 08:54:01 --> Final output sent to browser
DEBUG - 2023-02-17 08:54:01 --> Total execution time: 0.1247
INFO - 2023-02-17 08:54:01 --> Config Class Initialized
INFO - 2023-02-17 08:54:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:54:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:54:01 --> Utf8 Class Initialized
INFO - 2023-02-17 08:54:01 --> URI Class Initialized
INFO - 2023-02-17 08:54:01 --> Router Class Initialized
INFO - 2023-02-17 08:54:01 --> Output Class Initialized
INFO - 2023-02-17 08:54:01 --> Security Class Initialized
DEBUG - 2023-02-17 08:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:54:01 --> Input Class Initialized
INFO - 2023-02-17 08:54:01 --> Language Class Initialized
INFO - 2023-02-17 08:54:01 --> Loader Class Initialized
INFO - 2023-02-17 08:54:01 --> Controller Class Initialized
DEBUG - 2023-02-17 08:54:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:54:01 --> Database Driver Class Initialized
INFO - 2023-02-17 08:54:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:54:01 --> Database Driver Class Initialized
INFO - 2023-02-17 08:54:01 --> Model "Login_model" initialized
INFO - 2023-02-17 08:54:01 --> Final output sent to browser
DEBUG - 2023-02-17 08:54:01 --> Total execution time: 0.0827
INFO - 2023-02-17 08:54:53 --> Config Class Initialized
INFO - 2023-02-17 08:54:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:54:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:54:53 --> Utf8 Class Initialized
INFO - 2023-02-17 08:54:53 --> URI Class Initialized
INFO - 2023-02-17 08:54:53 --> Router Class Initialized
INFO - 2023-02-17 08:54:53 --> Output Class Initialized
INFO - 2023-02-17 08:54:53 --> Security Class Initialized
DEBUG - 2023-02-17 08:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:54:53 --> Input Class Initialized
INFO - 2023-02-17 08:54:53 --> Language Class Initialized
INFO - 2023-02-17 08:54:53 --> Loader Class Initialized
INFO - 2023-02-17 08:54:53 --> Controller Class Initialized
DEBUG - 2023-02-17 08:54:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:54:53 --> Database Driver Class Initialized
INFO - 2023-02-17 08:54:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:54:53 --> Database Driver Class Initialized
INFO - 2023-02-17 08:54:53 --> Model "Login_model" initialized
INFO - 2023-02-17 08:54:53 --> Final output sent to browser
DEBUG - 2023-02-17 08:54:53 --> Total execution time: 0.1621
INFO - 2023-02-17 08:54:53 --> Config Class Initialized
INFO - 2023-02-17 08:54:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:54:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:54:53 --> Utf8 Class Initialized
INFO - 2023-02-17 08:54:53 --> URI Class Initialized
INFO - 2023-02-17 08:54:53 --> Router Class Initialized
INFO - 2023-02-17 08:54:53 --> Output Class Initialized
INFO - 2023-02-17 08:54:53 --> Security Class Initialized
DEBUG - 2023-02-17 08:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:54:53 --> Input Class Initialized
INFO - 2023-02-17 08:54:53 --> Language Class Initialized
INFO - 2023-02-17 08:54:53 --> Loader Class Initialized
INFO - 2023-02-17 08:54:53 --> Controller Class Initialized
DEBUG - 2023-02-17 08:54:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:54:53 --> Database Driver Class Initialized
INFO - 2023-02-17 08:54:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:54:53 --> Database Driver Class Initialized
INFO - 2023-02-17 08:54:53 --> Model "Login_model" initialized
INFO - 2023-02-17 08:54:53 --> Final output sent to browser
DEBUG - 2023-02-17 08:54:53 --> Total execution time: 0.0785
INFO - 2023-02-17 08:55:18 --> Config Class Initialized
INFO - 2023-02-17 08:55:18 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:18 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:18 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:18 --> URI Class Initialized
INFO - 2023-02-17 08:55:18 --> Router Class Initialized
INFO - 2023-02-17 08:55:18 --> Output Class Initialized
INFO - 2023-02-17 08:55:18 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:18 --> Input Class Initialized
INFO - 2023-02-17 08:55:18 --> Language Class Initialized
INFO - 2023-02-17 08:55:18 --> Loader Class Initialized
INFO - 2023-02-17 08:55:18 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:18 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:18 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:18 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:18 --> Model "Login_model" initialized
INFO - 2023-02-17 08:55:19 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:19 --> Total execution time: 0.1672
INFO - 2023-02-17 08:55:19 --> Config Class Initialized
INFO - 2023-02-17 08:55:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:19 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:19 --> URI Class Initialized
INFO - 2023-02-17 08:55:19 --> Router Class Initialized
INFO - 2023-02-17 08:55:19 --> Output Class Initialized
INFO - 2023-02-17 08:55:19 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:19 --> Input Class Initialized
INFO - 2023-02-17 08:55:19 --> Language Class Initialized
INFO - 2023-02-17 08:55:19 --> Loader Class Initialized
INFO - 2023-02-17 08:55:19 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:19 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:19 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:19 --> Model "Login_model" initialized
INFO - 2023-02-17 08:55:19 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:19 --> Total execution time: 0.0828
INFO - 2023-02-17 08:55:29 --> Config Class Initialized
INFO - 2023-02-17 08:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:29 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:29 --> URI Class Initialized
INFO - 2023-02-17 08:55:29 --> Router Class Initialized
INFO - 2023-02-17 08:55:29 --> Output Class Initialized
INFO - 2023-02-17 08:55:29 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:29 --> Input Class Initialized
INFO - 2023-02-17 08:55:29 --> Language Class Initialized
INFO - 2023-02-17 08:55:29 --> Loader Class Initialized
INFO - 2023-02-17 08:55:29 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:29 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:29 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:29 --> Total execution time: 0.0459
INFO - 2023-02-17 08:55:29 --> Config Class Initialized
INFO - 2023-02-17 08:55:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:29 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:29 --> URI Class Initialized
INFO - 2023-02-17 08:55:29 --> Router Class Initialized
INFO - 2023-02-17 08:55:29 --> Output Class Initialized
INFO - 2023-02-17 08:55:29 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:29 --> Input Class Initialized
INFO - 2023-02-17 08:55:29 --> Language Class Initialized
INFO - 2023-02-17 08:55:29 --> Loader Class Initialized
INFO - 2023-02-17 08:55:29 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:29 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:29 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:29 --> Total execution time: 0.0482
INFO - 2023-02-17 08:55:32 --> Config Class Initialized
INFO - 2023-02-17 08:55:32 --> Config Class Initialized
INFO - 2023-02-17 08:55:32 --> Hooks Class Initialized
INFO - 2023-02-17 08:55:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 08:55:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:32 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:32 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:32 --> URI Class Initialized
INFO - 2023-02-17 08:55:32 --> URI Class Initialized
INFO - 2023-02-17 08:55:32 --> Router Class Initialized
INFO - 2023-02-17 08:55:32 --> Router Class Initialized
INFO - 2023-02-17 08:55:32 --> Output Class Initialized
INFO - 2023-02-17 08:55:32 --> Output Class Initialized
INFO - 2023-02-17 08:55:32 --> Security Class Initialized
INFO - 2023-02-17 08:55:32 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 08:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:32 --> Input Class Initialized
INFO - 2023-02-17 08:55:32 --> Input Class Initialized
INFO - 2023-02-17 08:55:32 --> Language Class Initialized
INFO - 2023-02-17 08:55:32 --> Language Class Initialized
INFO - 2023-02-17 08:55:32 --> Loader Class Initialized
INFO - 2023-02-17 08:55:32 --> Loader Class Initialized
INFO - 2023-02-17 08:55:32 --> Controller Class Initialized
INFO - 2023-02-17 08:55:32 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 08:55:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:32 --> Final output sent to browser
INFO - 2023-02-17 08:55:32 --> Database Driver Class Initialized
DEBUG - 2023-02-17 08:55:32 --> Total execution time: 0.0051
INFO - 2023-02-17 08:55:32 --> Config Class Initialized
INFO - 2023-02-17 08:55:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:32 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:32 --> URI Class Initialized
INFO - 2023-02-17 08:55:32 --> Router Class Initialized
INFO - 2023-02-17 08:55:32 --> Output Class Initialized
INFO - 2023-02-17 08:55:32 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:32 --> Input Class Initialized
INFO - 2023-02-17 08:55:32 --> Language Class Initialized
INFO - 2023-02-17 08:55:32 --> Loader Class Initialized
INFO - 2023-02-17 08:55:32 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:32 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:32 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:32 --> Total execution time: 0.0513
INFO - 2023-02-17 08:55:32 --> Config Class Initialized
INFO - 2023-02-17 08:55:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:32 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:32 --> URI Class Initialized
INFO - 2023-02-17 08:55:32 --> Router Class Initialized
INFO - 2023-02-17 08:55:32 --> Output Class Initialized
INFO - 2023-02-17 08:55:32 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:32 --> Input Class Initialized
INFO - 2023-02-17 08:55:32 --> Language Class Initialized
INFO - 2023-02-17 08:55:32 --> Loader Class Initialized
INFO - 2023-02-17 08:55:32 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:32 --> Model "Login_model" initialized
INFO - 2023-02-17 08:55:32 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:32 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:32 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:32 --> Total execution time: 0.0683
INFO - 2023-02-17 08:55:32 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:32 --> Total execution time: 0.0174
INFO - 2023-02-17 08:55:34 --> Config Class Initialized
INFO - 2023-02-17 08:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:34 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:34 --> URI Class Initialized
INFO - 2023-02-17 08:55:34 --> Router Class Initialized
INFO - 2023-02-17 08:55:34 --> Output Class Initialized
INFO - 2023-02-17 08:55:34 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:34 --> Input Class Initialized
INFO - 2023-02-17 08:55:34 --> Language Class Initialized
INFO - 2023-02-17 08:55:34 --> Loader Class Initialized
INFO - 2023-02-17 08:55:34 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:34 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:34 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:34 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:34 --> Total execution time: 0.0157
INFO - 2023-02-17 08:55:34 --> Config Class Initialized
INFO - 2023-02-17 08:55:34 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:34 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:34 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:34 --> URI Class Initialized
INFO - 2023-02-17 08:55:34 --> Router Class Initialized
INFO - 2023-02-17 08:55:34 --> Output Class Initialized
INFO - 2023-02-17 08:55:34 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:34 --> Input Class Initialized
INFO - 2023-02-17 08:55:34 --> Language Class Initialized
INFO - 2023-02-17 08:55:34 --> Loader Class Initialized
INFO - 2023-02-17 08:55:34 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:34 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:34 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:34 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:34 --> Total execution time: 0.0532
INFO - 2023-02-17 08:55:38 --> Config Class Initialized
INFO - 2023-02-17 08:55:38 --> Config Class Initialized
INFO - 2023-02-17 08:55:38 --> Hooks Class Initialized
INFO - 2023-02-17 08:55:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:38 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 08:55:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:38 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:38 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:38 --> URI Class Initialized
INFO - 2023-02-17 08:55:38 --> URI Class Initialized
INFO - 2023-02-17 08:55:38 --> Router Class Initialized
INFO - 2023-02-17 08:55:38 --> Router Class Initialized
INFO - 2023-02-17 08:55:38 --> Output Class Initialized
INFO - 2023-02-17 08:55:38 --> Output Class Initialized
INFO - 2023-02-17 08:55:38 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:38 --> Security Class Initialized
INFO - 2023-02-17 08:55:38 --> Input Class Initialized
DEBUG - 2023-02-17 08:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:38 --> Language Class Initialized
INFO - 2023-02-17 08:55:38 --> Input Class Initialized
INFO - 2023-02-17 08:55:38 --> Language Class Initialized
INFO - 2023-02-17 08:55:38 --> Loader Class Initialized
INFO - 2023-02-17 08:55:38 --> Loader Class Initialized
INFO - 2023-02-17 08:55:38 --> Controller Class Initialized
INFO - 2023-02-17 08:55:38 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 08:55:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:38 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:38 --> Total execution time: 0.0040
INFO - 2023-02-17 08:55:38 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:38 --> Config Class Initialized
INFO - 2023-02-17 08:55:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:38 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:38 --> URI Class Initialized
INFO - 2023-02-17 08:55:38 --> Router Class Initialized
INFO - 2023-02-17 08:55:38 --> Output Class Initialized
INFO - 2023-02-17 08:55:38 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:38 --> Input Class Initialized
INFO - 2023-02-17 08:55:38 --> Language Class Initialized
INFO - 2023-02-17 08:55:38 --> Loader Class Initialized
INFO - 2023-02-17 08:55:38 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:38 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:38 --> Model "Login_model" initialized
INFO - 2023-02-17 08:55:38 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:38 --> Total execution time: 0.0197
INFO - 2023-02-17 08:55:38 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:38 --> Config Class Initialized
INFO - 2023-02-17 08:55:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:38 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:38 --> URI Class Initialized
INFO - 2023-02-17 08:55:38 --> Router Class Initialized
INFO - 2023-02-17 08:55:38 --> Output Class Initialized
INFO - 2023-02-17 08:55:38 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:38 --> Input Class Initialized
INFO - 2023-02-17 08:55:38 --> Language Class Initialized
INFO - 2023-02-17 08:55:38 --> Loader Class Initialized
INFO - 2023-02-17 08:55:38 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:38 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:38 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:38 --> Total execution time: 0.0237
INFO - 2023-02-17 08:55:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:38 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:38 --> Total execution time: 0.0560
INFO - 2023-02-17 08:55:42 --> Config Class Initialized
INFO - 2023-02-17 08:55:42 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:42 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:42 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:42 --> URI Class Initialized
INFO - 2023-02-17 08:55:42 --> Router Class Initialized
INFO - 2023-02-17 08:55:42 --> Output Class Initialized
INFO - 2023-02-17 08:55:42 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:42 --> Input Class Initialized
INFO - 2023-02-17 08:55:42 --> Language Class Initialized
INFO - 2023-02-17 08:55:42 --> Loader Class Initialized
INFO - 2023-02-17 08:55:42 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:42 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:42 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:42 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:42 --> Total execution time: 0.0180
INFO - 2023-02-17 08:55:42 --> Config Class Initialized
INFO - 2023-02-17 08:55:42 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:42 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:42 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:42 --> URI Class Initialized
INFO - 2023-02-17 08:55:42 --> Router Class Initialized
INFO - 2023-02-17 08:55:42 --> Output Class Initialized
INFO - 2023-02-17 08:55:42 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:42 --> Input Class Initialized
INFO - 2023-02-17 08:55:42 --> Language Class Initialized
INFO - 2023-02-17 08:55:42 --> Loader Class Initialized
INFO - 2023-02-17 08:55:42 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:42 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:42 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:42 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:42 --> Total execution time: 0.0552
INFO - 2023-02-17 08:55:47 --> Config Class Initialized
INFO - 2023-02-17 08:55:47 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:47 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:47 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:47 --> URI Class Initialized
INFO - 2023-02-17 08:55:47 --> Router Class Initialized
INFO - 2023-02-17 08:55:47 --> Output Class Initialized
INFO - 2023-02-17 08:55:47 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:47 --> Input Class Initialized
INFO - 2023-02-17 08:55:47 --> Language Class Initialized
INFO - 2023-02-17 08:55:47 --> Loader Class Initialized
INFO - 2023-02-17 08:55:47 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:47 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:47 --> Total execution time: 0.0471
INFO - 2023-02-17 08:55:47 --> Config Class Initialized
INFO - 2023-02-17 08:55:47 --> Hooks Class Initialized
DEBUG - 2023-02-17 08:55:47 --> UTF-8 Support Enabled
INFO - 2023-02-17 08:55:47 --> Utf8 Class Initialized
INFO - 2023-02-17 08:55:47 --> URI Class Initialized
INFO - 2023-02-17 08:55:47 --> Router Class Initialized
INFO - 2023-02-17 08:55:47 --> Output Class Initialized
INFO - 2023-02-17 08:55:47 --> Security Class Initialized
DEBUG - 2023-02-17 08:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 08:55:47 --> Input Class Initialized
INFO - 2023-02-17 08:55:47 --> Language Class Initialized
INFO - 2023-02-17 08:55:47 --> Loader Class Initialized
INFO - 2023-02-17 08:55:47 --> Controller Class Initialized
DEBUG - 2023-02-17 08:55:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 08:55:47 --> Database Driver Class Initialized
INFO - 2023-02-17 08:55:47 --> Model "Cluster_model" initialized
INFO - 2023-02-17 08:55:47 --> Final output sent to browser
DEBUG - 2023-02-17 08:55:47 --> Total execution time: 0.0514
INFO - 2023-02-17 09:17:36 --> Config Class Initialized
INFO - 2023-02-17 09:17:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:17:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:17:36 --> Utf8 Class Initialized
INFO - 2023-02-17 09:17:36 --> URI Class Initialized
INFO - 2023-02-17 09:17:36 --> Router Class Initialized
INFO - 2023-02-17 09:17:36 --> Output Class Initialized
INFO - 2023-02-17 09:17:36 --> Security Class Initialized
DEBUG - 2023-02-17 09:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:17:36 --> Input Class Initialized
INFO - 2023-02-17 09:17:36 --> Language Class Initialized
INFO - 2023-02-17 09:17:36 --> Loader Class Initialized
INFO - 2023-02-17 09:17:36 --> Controller Class Initialized
DEBUG - 2023-02-17 09:17:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:17:36 --> Final output sent to browser
DEBUG - 2023-02-17 09:17:36 --> Total execution time: 0.0062
INFO - 2023-02-17 09:17:36 --> Config Class Initialized
INFO - 2023-02-17 09:17:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:17:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:17:36 --> Utf8 Class Initialized
INFO - 2023-02-17 09:17:36 --> URI Class Initialized
INFO - 2023-02-17 09:17:36 --> Router Class Initialized
INFO - 2023-02-17 09:17:36 --> Output Class Initialized
INFO - 2023-02-17 09:17:36 --> Security Class Initialized
DEBUG - 2023-02-17 09:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:17:36 --> Input Class Initialized
INFO - 2023-02-17 09:17:36 --> Language Class Initialized
INFO - 2023-02-17 09:17:36 --> Loader Class Initialized
INFO - 2023-02-17 09:17:36 --> Controller Class Initialized
DEBUG - 2023-02-17 09:17:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:17:36 --> Database Driver Class Initialized
INFO - 2023-02-17 09:17:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:17:36 --> Final output sent to browser
DEBUG - 2023-02-17 09:17:36 --> Total execution time: 0.0615
INFO - 2023-02-17 09:17:45 --> Config Class Initialized
INFO - 2023-02-17 09:17:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:17:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:17:45 --> Utf8 Class Initialized
INFO - 2023-02-17 09:17:45 --> URI Class Initialized
INFO - 2023-02-17 09:17:45 --> Router Class Initialized
INFO - 2023-02-17 09:17:45 --> Output Class Initialized
INFO - 2023-02-17 09:17:45 --> Security Class Initialized
DEBUG - 2023-02-17 09:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:17:45 --> Input Class Initialized
INFO - 2023-02-17 09:17:45 --> Language Class Initialized
INFO - 2023-02-17 09:17:45 --> Loader Class Initialized
INFO - 2023-02-17 09:17:45 --> Controller Class Initialized
DEBUG - 2023-02-17 09:17:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:17:45 --> Database Driver Class Initialized
INFO - 2023-02-17 09:17:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:17:45 --> Final output sent to browser
DEBUG - 2023-02-17 09:17:45 --> Total execution time: 0.0197
INFO - 2023-02-17 09:17:45 --> Config Class Initialized
INFO - 2023-02-17 09:17:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:17:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:17:45 --> Utf8 Class Initialized
INFO - 2023-02-17 09:17:45 --> URI Class Initialized
INFO - 2023-02-17 09:17:45 --> Router Class Initialized
INFO - 2023-02-17 09:17:45 --> Output Class Initialized
INFO - 2023-02-17 09:17:45 --> Security Class Initialized
DEBUG - 2023-02-17 09:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:17:45 --> Input Class Initialized
INFO - 2023-02-17 09:17:45 --> Language Class Initialized
INFO - 2023-02-17 09:17:45 --> Loader Class Initialized
INFO - 2023-02-17 09:17:45 --> Controller Class Initialized
DEBUG - 2023-02-17 09:17:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:17:45 --> Database Driver Class Initialized
INFO - 2023-02-17 09:17:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:17:45 --> Final output sent to browser
DEBUG - 2023-02-17 09:17:45 --> Total execution time: 0.0175
INFO - 2023-02-17 09:17:50 --> Config Class Initialized
INFO - 2023-02-17 09:17:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:17:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:17:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:17:50 --> URI Class Initialized
INFO - 2023-02-17 09:17:50 --> Router Class Initialized
INFO - 2023-02-17 09:17:50 --> Output Class Initialized
INFO - 2023-02-17 09:17:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:17:50 --> Input Class Initialized
INFO - 2023-02-17 09:17:50 --> Language Class Initialized
INFO - 2023-02-17 09:17:50 --> Loader Class Initialized
INFO - 2023-02-17 09:17:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:17:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:17:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:17:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:17:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:17:50 --> Model "Login_model" initialized
INFO - 2023-02-17 09:17:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:17:50 --> Total execution time: 0.0495
INFO - 2023-02-17 09:17:50 --> Config Class Initialized
INFO - 2023-02-17 09:17:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:17:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:17:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:17:50 --> URI Class Initialized
INFO - 2023-02-17 09:17:50 --> Router Class Initialized
INFO - 2023-02-17 09:17:50 --> Output Class Initialized
INFO - 2023-02-17 09:17:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:17:50 --> Input Class Initialized
INFO - 2023-02-17 09:17:50 --> Language Class Initialized
INFO - 2023-02-17 09:17:50 --> Loader Class Initialized
INFO - 2023-02-17 09:17:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:17:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:17:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:17:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:17:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:17:50 --> Model "Login_model" initialized
INFO - 2023-02-17 09:17:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:17:50 --> Total execution time: 0.0793
INFO - 2023-02-17 09:22:31 --> Config Class Initialized
INFO - 2023-02-17 09:22:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:22:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:22:31 --> Utf8 Class Initialized
INFO - 2023-02-17 09:22:31 --> URI Class Initialized
INFO - 2023-02-17 09:22:31 --> Router Class Initialized
INFO - 2023-02-17 09:22:31 --> Output Class Initialized
INFO - 2023-02-17 09:22:31 --> Security Class Initialized
DEBUG - 2023-02-17 09:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:22:31 --> Input Class Initialized
INFO - 2023-02-17 09:22:31 --> Language Class Initialized
INFO - 2023-02-17 09:22:31 --> Loader Class Initialized
INFO - 2023-02-17 09:22:31 --> Controller Class Initialized
DEBUG - 2023-02-17 09:22:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:22:31 --> Database Driver Class Initialized
INFO - 2023-02-17 09:22:31 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:22:32 --> Final output sent to browser
DEBUG - 2023-02-17 09:22:32 --> Total execution time: 0.7802
INFO - 2023-02-17 09:22:32 --> Config Class Initialized
INFO - 2023-02-17 09:22:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:22:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:22:32 --> Utf8 Class Initialized
INFO - 2023-02-17 09:22:32 --> URI Class Initialized
INFO - 2023-02-17 09:22:32 --> Router Class Initialized
INFO - 2023-02-17 09:22:32 --> Output Class Initialized
INFO - 2023-02-17 09:22:32 --> Security Class Initialized
DEBUG - 2023-02-17 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:22:32 --> Input Class Initialized
INFO - 2023-02-17 09:22:32 --> Language Class Initialized
INFO - 2023-02-17 09:22:32 --> Loader Class Initialized
INFO - 2023-02-17 09:22:32 --> Controller Class Initialized
DEBUG - 2023-02-17 09:22:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:22:32 --> Database Driver Class Initialized
INFO - 2023-02-17 09:22:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:22:32 --> Final output sent to browser
DEBUG - 2023-02-17 09:22:32 --> Total execution time: 0.0370
INFO - 2023-02-17 09:23:15 --> Config Class Initialized
INFO - 2023-02-17 09:23:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:23:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:23:15 --> Utf8 Class Initialized
INFO - 2023-02-17 09:23:15 --> URI Class Initialized
INFO - 2023-02-17 09:23:15 --> Router Class Initialized
INFO - 2023-02-17 09:23:15 --> Output Class Initialized
INFO - 2023-02-17 09:23:15 --> Security Class Initialized
DEBUG - 2023-02-17 09:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:23:15 --> Input Class Initialized
INFO - 2023-02-17 09:23:15 --> Language Class Initialized
INFO - 2023-02-17 09:23:15 --> Loader Class Initialized
INFO - 2023-02-17 09:23:15 --> Controller Class Initialized
DEBUG - 2023-02-17 09:23:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:23:15 --> Final output sent to browser
DEBUG - 2023-02-17 09:23:15 --> Total execution time: 0.0053
INFO - 2023-02-17 09:23:15 --> Config Class Initialized
INFO - 2023-02-17 09:23:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:23:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:23:15 --> Utf8 Class Initialized
INFO - 2023-02-17 09:23:15 --> URI Class Initialized
INFO - 2023-02-17 09:23:15 --> Router Class Initialized
INFO - 2023-02-17 09:23:15 --> Output Class Initialized
INFO - 2023-02-17 09:23:15 --> Security Class Initialized
DEBUG - 2023-02-17 09:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:23:15 --> Input Class Initialized
INFO - 2023-02-17 09:23:15 --> Language Class Initialized
INFO - 2023-02-17 09:23:15 --> Loader Class Initialized
INFO - 2023-02-17 09:23:15 --> Controller Class Initialized
DEBUG - 2023-02-17 09:23:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:23:15 --> Database Driver Class Initialized
INFO - 2023-02-17 09:23:15 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:23:15 --> Model "Node_model" initialized
INFO - 2023-02-17 09:23:15 --> Model "Grafana_model" initialized
INFO - 2023-02-17 09:23:15 --> Final output sent to browser
DEBUG - 2023-02-17 09:23:15 --> Total execution time: 0.0496
INFO - 2023-02-17 09:25:26 --> Config Class Initialized
INFO - 2023-02-17 09:25:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:25:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:25:26 --> Utf8 Class Initialized
INFO - 2023-02-17 09:25:26 --> URI Class Initialized
INFO - 2023-02-17 09:25:26 --> Router Class Initialized
INFO - 2023-02-17 09:25:26 --> Output Class Initialized
INFO - 2023-02-17 09:25:26 --> Security Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:25:26 --> Input Class Initialized
INFO - 2023-02-17 09:25:26 --> Language Class Initialized
INFO - 2023-02-17 09:25:26 --> Loader Class Initialized
INFO - 2023-02-17 09:25:26 --> Controller Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:25:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:25:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:25:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:25:26 --> Model "Login_model" initialized
INFO - 2023-02-17 09:25:26 --> Final output sent to browser
DEBUG - 2023-02-17 09:25:26 --> Total execution time: 0.0444
INFO - 2023-02-17 09:25:26 --> Config Class Initialized
INFO - 2023-02-17 09:25:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:25:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:25:26 --> Utf8 Class Initialized
INFO - 2023-02-17 09:25:26 --> URI Class Initialized
INFO - 2023-02-17 09:25:26 --> Router Class Initialized
INFO - 2023-02-17 09:25:26 --> Output Class Initialized
INFO - 2023-02-17 09:25:26 --> Security Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:25:26 --> Input Class Initialized
INFO - 2023-02-17 09:25:26 --> Language Class Initialized
INFO - 2023-02-17 09:25:26 --> Loader Class Initialized
INFO - 2023-02-17 09:25:26 --> Controller Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:25:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:25:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:25:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:25:26 --> Model "Login_model" initialized
INFO - 2023-02-17 09:25:26 --> Final output sent to browser
DEBUG - 2023-02-17 09:25:26 --> Total execution time: 0.0524
INFO - 2023-02-17 09:25:26 --> Config Class Initialized
INFO - 2023-02-17 09:25:26 --> Hooks Class Initialized
INFO - 2023-02-17 09:25:26 --> Config Class Initialized
DEBUG - 2023-02-17 09:25:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:25:26 --> Hooks Class Initialized
INFO - 2023-02-17 09:25:26 --> Utf8 Class Initialized
DEBUG - 2023-02-17 09:25:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:25:26 --> URI Class Initialized
INFO - 2023-02-17 09:25:26 --> Utf8 Class Initialized
INFO - 2023-02-17 09:25:26 --> Router Class Initialized
INFO - 2023-02-17 09:25:26 --> URI Class Initialized
INFO - 2023-02-17 09:25:26 --> Output Class Initialized
INFO - 2023-02-17 09:25:26 --> Router Class Initialized
INFO - 2023-02-17 09:25:26 --> Security Class Initialized
INFO - 2023-02-17 09:25:26 --> Output Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:25:26 --> Security Class Initialized
INFO - 2023-02-17 09:25:26 --> Input Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:25:26 --> Language Class Initialized
INFO - 2023-02-17 09:25:26 --> Input Class Initialized
INFO - 2023-02-17 09:25:26 --> Language Class Initialized
INFO - 2023-02-17 09:25:26 --> Loader Class Initialized
INFO - 2023-02-17 09:25:26 --> Controller Class Initialized
INFO - 2023-02-17 09:25:26 --> Loader Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:25:26 --> Controller Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:25:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:25:26 --> Final output sent to browser
DEBUG - 2023-02-17 09:25:26 --> Total execution time: 0.0039
INFO - 2023-02-17 09:25:26 --> Config Class Initialized
INFO - 2023-02-17 09:25:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:25:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:25:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:25:26 --> Utf8 Class Initialized
INFO - 2023-02-17 09:25:26 --> URI Class Initialized
INFO - 2023-02-17 09:25:26 --> Router Class Initialized
INFO - 2023-02-17 09:25:26 --> Output Class Initialized
INFO - 2023-02-17 09:25:26 --> Security Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:25:26 --> Input Class Initialized
INFO - 2023-02-17 09:25:26 --> Language Class Initialized
INFO - 2023-02-17 09:25:26 --> Loader Class Initialized
INFO - 2023-02-17 09:25:26 --> Controller Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:25:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:25:26 --> Final output sent to browser
DEBUG - 2023-02-17 09:25:26 --> Total execution time: 0.0517
INFO - 2023-02-17 09:25:26 --> Config Class Initialized
INFO - 2023-02-17 09:25:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:25:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:25:26 --> Utf8 Class Initialized
INFO - 2023-02-17 09:25:26 --> URI Class Initialized
INFO - 2023-02-17 09:25:26 --> Router Class Initialized
INFO - 2023-02-17 09:25:26 --> Output Class Initialized
INFO - 2023-02-17 09:25:26 --> Security Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:25:26 --> Input Class Initialized
INFO - 2023-02-17 09:25:26 --> Language Class Initialized
INFO - 2023-02-17 09:25:26 --> Loader Class Initialized
INFO - 2023-02-17 09:25:26 --> Controller Class Initialized
DEBUG - 2023-02-17 09:25:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:25:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:25:26 --> Model "Login_model" initialized
INFO - 2023-02-17 09:25:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:25:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:25:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:25:26 --> Final output sent to browser
DEBUG - 2023-02-17 09:25:26 --> Total execution time: 0.0137
INFO - 2023-02-17 09:25:26 --> Final output sent to browser
DEBUG - 2023-02-17 09:25:26 --> Total execution time: 0.0621
INFO - 2023-02-17 09:29:59 --> Config Class Initialized
INFO - 2023-02-17 09:29:59 --> Config Class Initialized
INFO - 2023-02-17 09:29:59 --> Hooks Class Initialized
INFO - 2023-02-17 09:29:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:29:59 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 09:29:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:29:59 --> Utf8 Class Initialized
INFO - 2023-02-17 09:29:59 --> Utf8 Class Initialized
INFO - 2023-02-17 09:29:59 --> URI Class Initialized
INFO - 2023-02-17 09:29:59 --> URI Class Initialized
INFO - 2023-02-17 09:29:59 --> Router Class Initialized
INFO - 2023-02-17 09:29:59 --> Output Class Initialized
INFO - 2023-02-17 09:29:59 --> Security Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:29:59 --> Input Class Initialized
INFO - 2023-02-17 09:29:59 --> Language Class Initialized
INFO - 2023-02-17 09:29:59 --> Loader Class Initialized
INFO - 2023-02-17 09:29:59 --> Controller Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:29:59 --> Database Driver Class Initialized
INFO - 2023-02-17 09:29:59 --> Router Class Initialized
INFO - 2023-02-17 09:29:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:29:59 --> Output Class Initialized
INFO - 2023-02-17 09:29:59 --> Security Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:29:59 --> Final output sent to browser
INFO - 2023-02-17 09:29:59 --> Input Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Total execution time: 0.1064
INFO - 2023-02-17 09:29:59 --> Language Class Initialized
INFO - 2023-02-17 09:29:59 --> Loader Class Initialized
INFO - 2023-02-17 09:29:59 --> Controller Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:29:59 --> Final output sent to browser
DEBUG - 2023-02-17 09:29:59 --> Total execution time: 0.1098
INFO - 2023-02-17 09:29:59 --> Config Class Initialized
INFO - 2023-02-17 09:29:59 --> Config Class Initialized
INFO - 2023-02-17 09:29:59 --> Hooks Class Initialized
INFO - 2023-02-17 09:29:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:29:59 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 09:29:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:29:59 --> Utf8 Class Initialized
INFO - 2023-02-17 09:29:59 --> Utf8 Class Initialized
INFO - 2023-02-17 09:29:59 --> URI Class Initialized
INFO - 2023-02-17 09:29:59 --> URI Class Initialized
INFO - 2023-02-17 09:29:59 --> Router Class Initialized
INFO - 2023-02-17 09:29:59 --> Router Class Initialized
INFO - 2023-02-17 09:29:59 --> Output Class Initialized
INFO - 2023-02-17 09:29:59 --> Output Class Initialized
INFO - 2023-02-17 09:29:59 --> Security Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:29:59 --> Security Class Initialized
INFO - 2023-02-17 09:29:59 --> Input Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:29:59 --> Language Class Initialized
INFO - 2023-02-17 09:29:59 --> Input Class Initialized
INFO - 2023-02-17 09:29:59 --> Language Class Initialized
INFO - 2023-02-17 09:29:59 --> Loader Class Initialized
INFO - 2023-02-17 09:29:59 --> Controller Class Initialized
INFO - 2023-02-17 09:29:59 --> Loader Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:29:59 --> Controller Class Initialized
DEBUG - 2023-02-17 09:29:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:29:59 --> Database Driver Class Initialized
INFO - 2023-02-17 09:29:59 --> Database Driver Class Initialized
INFO - 2023-02-17 09:29:59 --> Model "Login_model" initialized
INFO - 2023-02-17 09:29:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:29:59 --> Database Driver Class Initialized
INFO - 2023-02-17 09:29:59 --> Final output sent to browser
DEBUG - 2023-02-17 09:29:59 --> Total execution time: 0.0154
INFO - 2023-02-17 09:29:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:29:59 --> Final output sent to browser
DEBUG - 2023-02-17 09:29:59 --> Total execution time: 0.0236
INFO - 2023-02-17 09:30:24 --> Config Class Initialized
INFO - 2023-02-17 09:30:24 --> Config Class Initialized
INFO - 2023-02-17 09:30:24 --> Hooks Class Initialized
INFO - 2023-02-17 09:30:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:30:24 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 09:30:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:30:24 --> Utf8 Class Initialized
INFO - 2023-02-17 09:30:24 --> Utf8 Class Initialized
INFO - 2023-02-17 09:30:24 --> URI Class Initialized
INFO - 2023-02-17 09:30:24 --> URI Class Initialized
INFO - 2023-02-17 09:30:24 --> Router Class Initialized
INFO - 2023-02-17 09:30:24 --> Router Class Initialized
INFO - 2023-02-17 09:30:24 --> Output Class Initialized
INFO - 2023-02-17 09:30:24 --> Output Class Initialized
INFO - 2023-02-17 09:30:24 --> Security Class Initialized
INFO - 2023-02-17 09:30:24 --> Security Class Initialized
DEBUG - 2023-02-17 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:30:24 --> Input Class Initialized
DEBUG - 2023-02-17 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:30:24 --> Input Class Initialized
INFO - 2023-02-17 09:30:24 --> Language Class Initialized
INFO - 2023-02-17 09:30:24 --> Language Class Initialized
INFO - 2023-02-17 09:30:24 --> Loader Class Initialized
INFO - 2023-02-17 09:30:24 --> Loader Class Initialized
INFO - 2023-02-17 09:30:24 --> Controller Class Initialized
INFO - 2023-02-17 09:30:24 --> Controller Class Initialized
DEBUG - 2023-02-17 09:30:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 09:30:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:30:24 --> Final output sent to browser
INFO - 2023-02-17 09:30:24 --> Database Driver Class Initialized
DEBUG - 2023-02-17 09:30:24 --> Total execution time: 0.0453
INFO - 2023-02-17 09:30:24 --> Config Class Initialized
INFO - 2023-02-17 09:30:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:30:24 --> Final output sent to browser
DEBUG - 2023-02-17 09:30:24 --> Total execution time: 0.0876
INFO - 2023-02-17 09:30:24 --> Config Class Initialized
INFO - 2023-02-17 09:30:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:30:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:30:24 --> Utf8 Class Initialized
INFO - 2023-02-17 09:30:24 --> URI Class Initialized
INFO - 2023-02-17 09:30:24 --> Router Class Initialized
INFO - 2023-02-17 09:30:24 --> Output Class Initialized
INFO - 2023-02-17 09:30:24 --> Security Class Initialized
DEBUG - 2023-02-17 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:30:24 --> Input Class Initialized
INFO - 2023-02-17 09:30:24 --> Language Class Initialized
INFO - 2023-02-17 09:30:24 --> Loader Class Initialized
INFO - 2023-02-17 09:30:24 --> Controller Class Initialized
DEBUG - 2023-02-17 09:30:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:30:24 --> Database Driver Class Initialized
INFO - 2023-02-17 09:30:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:30:24 --> Final output sent to browser
DEBUG - 2023-02-17 09:30:24 --> Total execution time: 0.0151
INFO - 2023-02-17 09:30:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:30:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:30:24 --> Utf8 Class Initialized
INFO - 2023-02-17 09:30:24 --> URI Class Initialized
INFO - 2023-02-17 09:30:24 --> Router Class Initialized
INFO - 2023-02-17 09:30:24 --> Output Class Initialized
INFO - 2023-02-17 09:30:24 --> Security Class Initialized
DEBUG - 2023-02-17 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:30:24 --> Input Class Initialized
INFO - 2023-02-17 09:30:24 --> Language Class Initialized
INFO - 2023-02-17 09:30:24 --> Loader Class Initialized
INFO - 2023-02-17 09:30:24 --> Controller Class Initialized
DEBUG - 2023-02-17 09:30:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:30:24 --> Database Driver Class Initialized
INFO - 2023-02-17 09:30:24 --> Model "Login_model" initialized
INFO - 2023-02-17 09:30:24 --> Database Driver Class Initialized
INFO - 2023-02-17 09:30:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:30:24 --> Final output sent to browser
DEBUG - 2023-02-17 09:30:24 --> Total execution time: 0.1541
INFO - 2023-02-17 09:33:19 --> Config Class Initialized
INFO - 2023-02-17 09:33:19 --> Config Class Initialized
INFO - 2023-02-17 09:33:19 --> Hooks Class Initialized
INFO - 2023-02-17 09:33:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:33:19 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 09:33:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:33:19 --> Utf8 Class Initialized
INFO - 2023-02-17 09:33:19 --> Utf8 Class Initialized
INFO - 2023-02-17 09:33:19 --> URI Class Initialized
INFO - 2023-02-17 09:33:19 --> URI Class Initialized
INFO - 2023-02-17 09:33:19 --> Router Class Initialized
INFO - 2023-02-17 09:33:19 --> Router Class Initialized
INFO - 2023-02-17 09:33:19 --> Output Class Initialized
INFO - 2023-02-17 09:33:19 --> Output Class Initialized
INFO - 2023-02-17 09:33:19 --> Security Class Initialized
INFO - 2023-02-17 09:33:19 --> Security Class Initialized
DEBUG - 2023-02-17 09:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 09:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:33:19 --> Input Class Initialized
INFO - 2023-02-17 09:33:19 --> Input Class Initialized
INFO - 2023-02-17 09:33:19 --> Language Class Initialized
INFO - 2023-02-17 09:33:19 --> Language Class Initialized
INFO - 2023-02-17 09:33:19 --> Loader Class Initialized
INFO - 2023-02-17 09:33:19 --> Loader Class Initialized
INFO - 2023-02-17 09:33:19 --> Controller Class Initialized
INFO - 2023-02-17 09:33:19 --> Controller Class Initialized
DEBUG - 2023-02-17 09:33:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 09:33:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:33:19 --> Final output sent to browser
DEBUG - 2023-02-17 09:33:19 --> Total execution time: 0.0045
INFO - 2023-02-17 09:33:19 --> Database Driver Class Initialized
INFO - 2023-02-17 09:33:19 --> Config Class Initialized
INFO - 2023-02-17 09:33:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:33:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:33:19 --> Utf8 Class Initialized
INFO - 2023-02-17 09:33:19 --> URI Class Initialized
INFO - 2023-02-17 09:33:19 --> Router Class Initialized
INFO - 2023-02-17 09:33:19 --> Output Class Initialized
INFO - 2023-02-17 09:33:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:33:19 --> Security Class Initialized
DEBUG - 2023-02-17 09:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:33:19 --> Input Class Initialized
INFO - 2023-02-17 09:33:19 --> Language Class Initialized
INFO - 2023-02-17 09:33:19 --> Loader Class Initialized
INFO - 2023-02-17 09:33:19 --> Controller Class Initialized
DEBUG - 2023-02-17 09:33:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:33:19 --> Database Driver Class Initialized
INFO - 2023-02-17 09:33:19 --> Final output sent to browser
DEBUG - 2023-02-17 09:33:19 --> Total execution time: 0.0623
INFO - 2023-02-17 09:33:20 --> Config Class Initialized
INFO - 2023-02-17 09:33:20 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:33:20 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:33:20 --> Utf8 Class Initialized
INFO - 2023-02-17 09:33:20 --> URI Class Initialized
INFO - 2023-02-17 09:33:20 --> Router Class Initialized
INFO - 2023-02-17 09:33:20 --> Output Class Initialized
INFO - 2023-02-17 09:33:20 --> Security Class Initialized
DEBUG - 2023-02-17 09:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:33:20 --> Input Class Initialized
INFO - 2023-02-17 09:33:20 --> Language Class Initialized
INFO - 2023-02-17 09:33:20 --> Loader Class Initialized
INFO - 2023-02-17 09:33:20 --> Controller Class Initialized
DEBUG - 2023-02-17 09:33:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:33:20 --> Model "Login_model" initialized
INFO - 2023-02-17 09:33:20 --> Database Driver Class Initialized
INFO - 2023-02-17 09:33:20 --> Database Driver Class Initialized
INFO - 2023-02-17 09:33:20 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:33:20 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:33:20 --> Final output sent to browser
DEBUG - 2023-02-17 09:33:20 --> Total execution time: 0.0297
INFO - 2023-02-17 09:33:20 --> Final output sent to browser
DEBUG - 2023-02-17 09:33:20 --> Total execution time: 0.0170
INFO - 2023-02-17 09:40:09 --> Config Class Initialized
INFO - 2023-02-17 09:40:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:40:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:40:09 --> Utf8 Class Initialized
INFO - 2023-02-17 09:40:09 --> URI Class Initialized
INFO - 2023-02-17 09:40:09 --> Router Class Initialized
INFO - 2023-02-17 09:40:09 --> Output Class Initialized
INFO - 2023-02-17 09:40:09 --> Security Class Initialized
DEBUG - 2023-02-17 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:40:09 --> Config Class Initialized
INFO - 2023-02-17 09:40:09 --> Input Class Initialized
INFO - 2023-02-17 09:40:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:40:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:40:09 --> Utf8 Class Initialized
INFO - 2023-02-17 09:40:09 --> Language Class Initialized
INFO - 2023-02-17 09:40:09 --> URI Class Initialized
INFO - 2023-02-17 09:40:09 --> Loader Class Initialized
INFO - 2023-02-17 09:40:09 --> Router Class Initialized
INFO - 2023-02-17 09:40:09 --> Output Class Initialized
INFO - 2023-02-17 09:40:09 --> Security Class Initialized
INFO - 2023-02-17 09:40:09 --> Controller Class Initialized
DEBUG - 2023-02-17 09:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 09:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:40:09 --> Input Class Initialized
INFO - 2023-02-17 09:40:09 --> Database Driver Class Initialized
INFO - 2023-02-17 09:40:09 --> Language Class Initialized
INFO - 2023-02-17 09:40:09 --> Loader Class Initialized
INFO - 2023-02-17 09:40:09 --> Controller Class Initialized
DEBUG - 2023-02-17 09:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:40:09 --> Final output sent to browser
DEBUG - 2023-02-17 09:40:09 --> Total execution time: 0.0085
INFO - 2023-02-17 09:40:09 --> Config Class Initialized
INFO - 2023-02-17 09:40:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:40:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:40:09 --> Utf8 Class Initialized
INFO - 2023-02-17 09:40:09 --> URI Class Initialized
INFO - 2023-02-17 09:40:09 --> Router Class Initialized
INFO - 2023-02-17 09:40:09 --> Output Class Initialized
INFO - 2023-02-17 09:40:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:40:09 --> Security Class Initialized
DEBUG - 2023-02-17 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:40:09 --> Input Class Initialized
INFO - 2023-02-17 09:40:09 --> Language Class Initialized
INFO - 2023-02-17 09:40:09 --> Loader Class Initialized
INFO - 2023-02-17 09:40:09 --> Controller Class Initialized
DEBUG - 2023-02-17 09:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:40:09 --> Database Driver Class Initialized
INFO - 2023-02-17 09:40:09 --> Final output sent to browser
DEBUG - 2023-02-17 09:40:09 --> Total execution time: 0.0230
INFO - 2023-02-17 09:40:09 --> Model "Login_model" initialized
INFO - 2023-02-17 09:40:09 --> Config Class Initialized
INFO - 2023-02-17 09:40:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:40:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:40:09 --> Utf8 Class Initialized
INFO - 2023-02-17 09:40:09 --> URI Class Initialized
INFO - 2023-02-17 09:40:09 --> Database Driver Class Initialized
INFO - 2023-02-17 09:40:09 --> Router Class Initialized
INFO - 2023-02-17 09:40:09 --> Output Class Initialized
INFO - 2023-02-17 09:40:09 --> Security Class Initialized
DEBUG - 2023-02-17 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:40:09 --> Input Class Initialized
INFO - 2023-02-17 09:40:09 --> Language Class Initialized
INFO - 2023-02-17 09:40:09 --> Loader Class Initialized
INFO - 2023-02-17 09:40:09 --> Controller Class Initialized
DEBUG - 2023-02-17 09:40:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:40:09 --> Database Driver Class Initialized
INFO - 2023-02-17 09:40:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:40:09 --> Final output sent to browser
DEBUG - 2023-02-17 09:40:09 --> Total execution time: 0.0328
INFO - 2023-02-17 09:40:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:40:09 --> Final output sent to browser
DEBUG - 2023-02-17 09:40:09 --> Total execution time: 0.0945
INFO - 2023-02-17 09:41:43 --> Config Class Initialized
INFO - 2023-02-17 09:41:43 --> Hooks Class Initialized
INFO - 2023-02-17 09:41:43 --> Config Class Initialized
DEBUG - 2023-02-17 09:41:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:41:43 --> Utf8 Class Initialized
INFO - 2023-02-17 09:41:43 --> Hooks Class Initialized
INFO - 2023-02-17 09:41:43 --> URI Class Initialized
INFO - 2023-02-17 09:41:43 --> Router Class Initialized
INFO - 2023-02-17 09:41:43 --> Output Class Initialized
DEBUG - 2023-02-17 09:41:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:41:43 --> Security Class Initialized
INFO - 2023-02-17 09:41:43 --> Utf8 Class Initialized
INFO - 2023-02-17 09:41:43 --> URI Class Initialized
DEBUG - 2023-02-17 09:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:41:43 --> Router Class Initialized
INFO - 2023-02-17 09:41:43 --> Input Class Initialized
INFO - 2023-02-17 09:41:43 --> Output Class Initialized
INFO - 2023-02-17 09:41:43 --> Language Class Initialized
INFO - 2023-02-17 09:41:43 --> Security Class Initialized
INFO - 2023-02-17 09:41:43 --> Loader Class Initialized
DEBUG - 2023-02-17 09:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:41:43 --> Controller Class Initialized
INFO - 2023-02-17 09:41:43 --> Input Class Initialized
INFO - 2023-02-17 09:41:43 --> Language Class Initialized
DEBUG - 2023-02-17 09:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:41:43 --> Loader Class Initialized
INFO - 2023-02-17 09:41:43 --> Database Driver Class Initialized
INFO - 2023-02-17 09:41:43 --> Controller Class Initialized
DEBUG - 2023-02-17 09:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:41:43 --> Final output sent to browser
DEBUG - 2023-02-17 09:41:43 --> Total execution time: 0.0096
INFO - 2023-02-17 09:41:43 --> Config Class Initialized
INFO - 2023-02-17 09:41:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:41:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:41:43 --> Utf8 Class Initialized
INFO - 2023-02-17 09:41:43 --> URI Class Initialized
INFO - 2023-02-17 09:41:43 --> Router Class Initialized
INFO - 2023-02-17 09:41:43 --> Output Class Initialized
INFO - 2023-02-17 09:41:43 --> Security Class Initialized
INFO - 2023-02-17 09:41:43 --> Model "Cluster_model" initialized
DEBUG - 2023-02-17 09:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:41:43 --> Input Class Initialized
INFO - 2023-02-17 09:41:43 --> Language Class Initialized
INFO - 2023-02-17 09:41:43 --> Loader Class Initialized
INFO - 2023-02-17 09:41:43 --> Controller Class Initialized
DEBUG - 2023-02-17 09:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:41:43 --> Database Driver Class Initialized
INFO - 2023-02-17 09:41:43 --> Final output sent to browser
DEBUG - 2023-02-17 09:41:43 --> Total execution time: 0.0701
INFO - 2023-02-17 09:41:43 --> Config Class Initialized
INFO - 2023-02-17 09:41:43 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:41:43 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:41:43 --> Utf8 Class Initialized
INFO - 2023-02-17 09:41:43 --> URI Class Initialized
INFO - 2023-02-17 09:41:43 --> Model "Login_model" initialized
INFO - 2023-02-17 09:41:43 --> Router Class Initialized
INFO - 2023-02-17 09:41:43 --> Output Class Initialized
INFO - 2023-02-17 09:41:43 --> Security Class Initialized
DEBUG - 2023-02-17 09:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:41:43 --> Input Class Initialized
INFO - 2023-02-17 09:41:43 --> Language Class Initialized
INFO - 2023-02-17 09:41:43 --> Loader Class Initialized
INFO - 2023-02-17 09:41:43 --> Controller Class Initialized
DEBUG - 2023-02-17 09:41:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:41:43 --> Database Driver Class Initialized
INFO - 2023-02-17 09:41:43 --> Database Driver Class Initialized
INFO - 2023-02-17 09:41:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:41:43 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:41:43 --> Final output sent to browser
DEBUG - 2023-02-17 09:41:43 --> Total execution time: 0.0287
INFO - 2023-02-17 09:41:43 --> Final output sent to browser
DEBUG - 2023-02-17 09:41:43 --> Total execution time: 0.0202
INFO - 2023-02-17 09:41:50 --> Config Class Initialized
INFO - 2023-02-17 09:41:50 --> Config Class Initialized
INFO - 2023-02-17 09:41:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:41:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:41:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:41:50 --> URI Class Initialized
INFO - 2023-02-17 09:41:50 --> Router Class Initialized
INFO - 2023-02-17 09:41:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:41:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:41:50 --> Output Class Initialized
INFO - 2023-02-17 09:41:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:41:50 --> Security Class Initialized
INFO - 2023-02-17 09:41:50 --> URI Class Initialized
DEBUG - 2023-02-17 09:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:41:50 --> Input Class Initialized
INFO - 2023-02-17 09:41:50 --> Router Class Initialized
INFO - 2023-02-17 09:41:50 --> Language Class Initialized
INFO - 2023-02-17 09:41:50 --> Output Class Initialized
INFO - 2023-02-17 09:41:50 --> Loader Class Initialized
INFO - 2023-02-17 09:41:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:41:50 --> Controller Class Initialized
INFO - 2023-02-17 09:41:50 --> Input Class Initialized
DEBUG - 2023-02-17 09:41:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:41:50 --> Language Class Initialized
INFO - 2023-02-17 09:41:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:41:50 --> Total execution time: 0.0866
INFO - 2023-02-17 09:41:50 --> Loader Class Initialized
INFO - 2023-02-17 09:41:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:41:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:41:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:41:50 --> Config Class Initialized
INFO - 2023-02-17 09:41:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:41:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:41:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:41:50 --> URI Class Initialized
INFO - 2023-02-17 09:41:50 --> Router Class Initialized
INFO - 2023-02-17 09:41:50 --> Output Class Initialized
INFO - 2023-02-17 09:41:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:41:50 --> Input Class Initialized
INFO - 2023-02-17 09:41:50 --> Language Class Initialized
INFO - 2023-02-17 09:41:50 --> Loader Class Initialized
INFO - 2023-02-17 09:41:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:41:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:41:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:41:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:41:50 --> Final output sent to browser
INFO - 2023-02-17 09:41:50 --> Model "Login_model" initialized
DEBUG - 2023-02-17 09:41:50 --> Total execution time: 0.1047
INFO - 2023-02-17 09:41:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:41:50 --> Config Class Initialized
INFO - 2023-02-17 09:41:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:41:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:41:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:41:50 --> URI Class Initialized
INFO - 2023-02-17 09:41:50 --> Router Class Initialized
INFO - 2023-02-17 09:41:50 --> Output Class Initialized
INFO - 2023-02-17 09:41:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:41:50 --> Input Class Initialized
INFO - 2023-02-17 09:41:50 --> Language Class Initialized
INFO - 2023-02-17 09:41:50 --> Loader Class Initialized
INFO - 2023-02-17 09:41:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:41:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:41:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:41:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:41:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:41:50 --> Total execution time: 0.1152
INFO - 2023-02-17 09:41:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:41:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:41:50 --> Total execution time: 0.0834
INFO - 2023-02-17 09:42:11 --> Config Class Initialized
INFO - 2023-02-17 09:42:11 --> Config Class Initialized
INFO - 2023-02-17 09:42:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:42:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:42:11 --> Utf8 Class Initialized
INFO - 2023-02-17 09:42:11 --> URI Class Initialized
INFO - 2023-02-17 09:42:11 --> Router Class Initialized
INFO - 2023-02-17 09:42:11 --> Output Class Initialized
INFO - 2023-02-17 09:42:11 --> Security Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:42:11 --> Input Class Initialized
INFO - 2023-02-17 09:42:11 --> Language Class Initialized
INFO - 2023-02-17 09:42:11 --> Loader Class Initialized
INFO - 2023-02-17 09:42:11 --> Controller Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:42:11 --> Database Driver Class Initialized
INFO - 2023-02-17 09:42:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:42:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:42:11 --> Utf8 Class Initialized
INFO - 2023-02-17 09:42:11 --> URI Class Initialized
INFO - 2023-02-17 09:42:11 --> Router Class Initialized
INFO - 2023-02-17 09:42:11 --> Output Class Initialized
INFO - 2023-02-17 09:42:11 --> Security Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:42:11 --> Input Class Initialized
INFO - 2023-02-17 09:42:11 --> Language Class Initialized
INFO - 2023-02-17 09:42:11 --> Loader Class Initialized
INFO - 2023-02-17 09:42:11 --> Controller Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:42:11 --> Final output sent to browser
DEBUG - 2023-02-17 09:42:11 --> Total execution time: 0.0696
INFO - 2023-02-17 09:42:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:42:11 --> Config Class Initialized
INFO - 2023-02-17 09:42:11 --> Final output sent to browser
INFO - 2023-02-17 09:42:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Total execution time: 0.0821
DEBUG - 2023-02-17 09:42:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:42:11 --> Utf8 Class Initialized
INFO - 2023-02-17 09:42:11 --> Config Class Initialized
INFO - 2023-02-17 09:42:11 --> URI Class Initialized
INFO - 2023-02-17 09:42:11 --> Hooks Class Initialized
INFO - 2023-02-17 09:42:11 --> Router Class Initialized
DEBUG - 2023-02-17 09:42:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:42:11 --> Output Class Initialized
INFO - 2023-02-17 09:42:11 --> Utf8 Class Initialized
INFO - 2023-02-17 09:42:11 --> Security Class Initialized
INFO - 2023-02-17 09:42:11 --> URI Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:42:11 --> Router Class Initialized
INFO - 2023-02-17 09:42:11 --> Input Class Initialized
INFO - 2023-02-17 09:42:11 --> Language Class Initialized
INFO - 2023-02-17 09:42:11 --> Output Class Initialized
INFO - 2023-02-17 09:42:11 --> Security Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:42:11 --> Loader Class Initialized
INFO - 2023-02-17 09:42:11 --> Input Class Initialized
INFO - 2023-02-17 09:42:11 --> Controller Class Initialized
INFO - 2023-02-17 09:42:11 --> Language Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:42:11 --> Loader Class Initialized
INFO - 2023-02-17 09:42:11 --> Controller Class Initialized
INFO - 2023-02-17 09:42:11 --> Database Driver Class Initialized
DEBUG - 2023-02-17 09:42:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:42:11 --> Database Driver Class Initialized
INFO - 2023-02-17 09:42:11 --> Model "Login_model" initialized
INFO - 2023-02-17 09:42:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:42:11 --> Database Driver Class Initialized
INFO - 2023-02-17 09:42:11 --> Final output sent to browser
DEBUG - 2023-02-17 09:42:11 --> Total execution time: 0.0178
INFO - 2023-02-17 09:42:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:42:11 --> Final output sent to browser
DEBUG - 2023-02-17 09:42:11 --> Total execution time: 0.1492
INFO - 2023-02-17 09:43:41 --> Config Class Initialized
INFO - 2023-02-17 09:43:41 --> Config Class Initialized
INFO - 2023-02-17 09:43:41 --> Hooks Class Initialized
INFO - 2023-02-17 09:43:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:43:41 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 09:43:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:43:41 --> Utf8 Class Initialized
INFO - 2023-02-17 09:43:41 --> Utf8 Class Initialized
INFO - 2023-02-17 09:43:41 --> URI Class Initialized
INFO - 2023-02-17 09:43:41 --> URI Class Initialized
INFO - 2023-02-17 09:43:41 --> Router Class Initialized
INFO - 2023-02-17 09:43:41 --> Output Class Initialized
INFO - 2023-02-17 09:43:41 --> Router Class Initialized
INFO - 2023-02-17 09:43:41 --> Security Class Initialized
INFO - 2023-02-17 09:43:41 --> Output Class Initialized
DEBUG - 2023-02-17 09:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:43:41 --> Security Class Initialized
INFO - 2023-02-17 09:43:41 --> Input Class Initialized
DEBUG - 2023-02-17 09:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:43:41 --> Input Class Initialized
INFO - 2023-02-17 09:43:41 --> Language Class Initialized
INFO - 2023-02-17 09:43:41 --> Language Class Initialized
INFO - 2023-02-17 09:43:41 --> Loader Class Initialized
INFO - 2023-02-17 09:43:41 --> Loader Class Initialized
INFO - 2023-02-17 09:43:41 --> Controller Class Initialized
INFO - 2023-02-17 09:43:41 --> Controller Class Initialized
DEBUG - 2023-02-17 09:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 09:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:43:41 --> Final output sent to browser
DEBUG - 2023-02-17 09:43:41 --> Total execution time: 0.0833
INFO - 2023-02-17 09:43:41 --> Database Driver Class Initialized
INFO - 2023-02-17 09:43:41 --> Config Class Initialized
INFO - 2023-02-17 09:43:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:43:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:43:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:43:41 --> Utf8 Class Initialized
INFO - 2023-02-17 09:43:41 --> URI Class Initialized
INFO - 2023-02-17 09:43:41 --> Router Class Initialized
INFO - 2023-02-17 09:43:41 --> Output Class Initialized
INFO - 2023-02-17 09:43:41 --> Security Class Initialized
DEBUG - 2023-02-17 09:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:43:41 --> Input Class Initialized
INFO - 2023-02-17 09:43:41 --> Language Class Initialized
INFO - 2023-02-17 09:43:41 --> Loader Class Initialized
INFO - 2023-02-17 09:43:41 --> Controller Class Initialized
DEBUG - 2023-02-17 09:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:43:41 --> Database Driver Class Initialized
INFO - 2023-02-17 09:43:41 --> Final output sent to browser
DEBUG - 2023-02-17 09:43:41 --> Total execution time: 0.1710
INFO - 2023-02-17 09:43:41 --> Config Class Initialized
INFO - 2023-02-17 09:43:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:43:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:43:41 --> Utf8 Class Initialized
INFO - 2023-02-17 09:43:41 --> URI Class Initialized
INFO - 2023-02-17 09:43:41 --> Router Class Initialized
INFO - 2023-02-17 09:43:41 --> Output Class Initialized
INFO - 2023-02-17 09:43:41 --> Security Class Initialized
DEBUG - 2023-02-17 09:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:43:41 --> Input Class Initialized
INFO - 2023-02-17 09:43:41 --> Language Class Initialized
INFO - 2023-02-17 09:43:41 --> Loader Class Initialized
INFO - 2023-02-17 09:43:41 --> Controller Class Initialized
DEBUG - 2023-02-17 09:43:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:43:41 --> Database Driver Class Initialized
INFO - 2023-02-17 09:43:41 --> Model "Login_model" initialized
INFO - 2023-02-17 09:43:41 --> Database Driver Class Initialized
INFO - 2023-02-17 09:43:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:43:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:43:41 --> Final output sent to browser
DEBUG - 2023-02-17 09:43:41 --> Total execution time: 0.0472
INFO - 2023-02-17 09:43:41 --> Final output sent to browser
DEBUG - 2023-02-17 09:43:41 --> Total execution time: 0.1366
INFO - 2023-02-17 09:44:10 --> Config Class Initialized
INFO - 2023-02-17 09:44:10 --> Config Class Initialized
INFO - 2023-02-17 09:44:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:10 --> Hooks Class Initialized
INFO - 2023-02-17 09:44:10 --> Utf8 Class Initialized
DEBUG - 2023-02-17 09:44:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:10 --> URI Class Initialized
INFO - 2023-02-17 09:44:10 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:10 --> Router Class Initialized
INFO - 2023-02-17 09:44:10 --> Output Class Initialized
INFO - 2023-02-17 09:44:10 --> URI Class Initialized
INFO - 2023-02-17 09:44:10 --> Security Class Initialized
INFO - 2023-02-17 09:44:10 --> Router Class Initialized
DEBUG - 2023-02-17 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:10 --> Output Class Initialized
INFO - 2023-02-17 09:44:10 --> Input Class Initialized
INFO - 2023-02-17 09:44:10 --> Security Class Initialized
INFO - 2023-02-17 09:44:10 --> Language Class Initialized
DEBUG - 2023-02-17 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:10 --> Input Class Initialized
INFO - 2023-02-17 09:44:10 --> Language Class Initialized
INFO - 2023-02-17 09:44:10 --> Loader Class Initialized
INFO - 2023-02-17 09:44:10 --> Controller Class Initialized
INFO - 2023-02-17 09:44:10 --> Loader Class Initialized
DEBUG - 2023-02-17 09:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:10 --> Controller Class Initialized
INFO - 2023-02-17 09:44:10 --> Database Driver Class Initialized
DEBUG - 2023-02-17 09:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:10 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:10 --> Total execution time: 0.0603
INFO - 2023-02-17 09:44:10 --> Config Class Initialized
INFO - 2023-02-17 09:44:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:10 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:10 --> URI Class Initialized
INFO - 2023-02-17 09:44:10 --> Router Class Initialized
INFO - 2023-02-17 09:44:10 --> Output Class Initialized
INFO - 2023-02-17 09:44:10 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:10 --> Input Class Initialized
INFO - 2023-02-17 09:44:10 --> Language Class Initialized
INFO - 2023-02-17 09:44:10 --> Loader Class Initialized
INFO - 2023-02-17 09:44:10 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:10 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:10 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:10 --> Total execution time: 0.0838
INFO - 2023-02-17 09:44:10 --> Config Class Initialized
INFO - 2023-02-17 09:44:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:10 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:10 --> URI Class Initialized
INFO - 2023-02-17 09:44:10 --> Router Class Initialized
INFO - 2023-02-17 09:44:10 --> Output Class Initialized
INFO - 2023-02-17 09:44:10 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:10 --> Input Class Initialized
INFO - 2023-02-17 09:44:10 --> Language Class Initialized
INFO - 2023-02-17 09:44:10 --> Model "Login_model" initialized
INFO - 2023-02-17 09:44:10 --> Loader Class Initialized
INFO - 2023-02-17 09:44:10 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:10 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:10 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:10 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:10 --> Total execution time: 0.0296
INFO - 2023-02-17 09:44:10 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:10 --> Total execution time: 0.0210
INFO - 2023-02-17 09:44:25 --> Config Class Initialized
INFO - 2023-02-17 09:44:25 --> Config Class Initialized
INFO - 2023-02-17 09:44:25 --> Hooks Class Initialized
INFO - 2023-02-17 09:44:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:25 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 09:44:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:25 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:25 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:25 --> URI Class Initialized
INFO - 2023-02-17 09:44:25 --> URI Class Initialized
INFO - 2023-02-17 09:44:25 --> Router Class Initialized
INFO - 2023-02-17 09:44:25 --> Router Class Initialized
INFO - 2023-02-17 09:44:25 --> Output Class Initialized
INFO - 2023-02-17 09:44:25 --> Output Class Initialized
INFO - 2023-02-17 09:44:25 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:25 --> Security Class Initialized
INFO - 2023-02-17 09:44:25 --> Input Class Initialized
DEBUG - 2023-02-17 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:25 --> Language Class Initialized
INFO - 2023-02-17 09:44:25 --> Input Class Initialized
INFO - 2023-02-17 09:44:25 --> Language Class Initialized
INFO - 2023-02-17 09:44:25 --> Loader Class Initialized
INFO - 2023-02-17 09:44:25 --> Loader Class Initialized
INFO - 2023-02-17 09:44:25 --> Controller Class Initialized
INFO - 2023-02-17 09:44:25 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 09:44:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:25 --> Final output sent to browser
INFO - 2023-02-17 09:44:25 --> Database Driver Class Initialized
DEBUG - 2023-02-17 09:44:25 --> Total execution time: 0.0474
INFO - 2023-02-17 09:44:25 --> Config Class Initialized
INFO - 2023-02-17 09:44:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:25 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:25 --> URI Class Initialized
INFO - 2023-02-17 09:44:25 --> Router Class Initialized
INFO - 2023-02-17 09:44:25 --> Output Class Initialized
INFO - 2023-02-17 09:44:25 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:25 --> Input Class Initialized
INFO - 2023-02-17 09:44:25 --> Language Class Initialized
INFO - 2023-02-17 09:44:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:25 --> Loader Class Initialized
INFO - 2023-02-17 09:44:25 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:25 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:25 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:25 --> Total execution time: 0.2780
INFO - 2023-02-17 09:44:25 --> Model "Login_model" initialized
INFO - 2023-02-17 09:44:25 --> Config Class Initialized
INFO - 2023-02-17 09:44:25 --> Hooks Class Initialized
INFO - 2023-02-17 09:44:25 --> Database Driver Class Initialized
DEBUG - 2023-02-17 09:44:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:25 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:25 --> URI Class Initialized
INFO - 2023-02-17 09:44:25 --> Router Class Initialized
INFO - 2023-02-17 09:44:25 --> Output Class Initialized
INFO - 2023-02-17 09:44:25 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:25 --> Input Class Initialized
INFO - 2023-02-17 09:44:25 --> Language Class Initialized
INFO - 2023-02-17 09:44:25 --> Loader Class Initialized
INFO - 2023-02-17 09:44:25 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:25 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:25 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:25 --> Total execution time: 0.2035
INFO - 2023-02-17 09:44:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:25 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:25 --> Total execution time: 0.2044
INFO - 2023-02-17 09:44:46 --> Config Class Initialized
INFO - 2023-02-17 09:44:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:46 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:46 --> URI Class Initialized
INFO - 2023-02-17 09:44:46 --> Router Class Initialized
INFO - 2023-02-17 09:44:46 --> Output Class Initialized
INFO - 2023-02-17 09:44:46 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:46 --> Input Class Initialized
INFO - 2023-02-17 09:44:46 --> Language Class Initialized
INFO - 2023-02-17 09:44:46 --> Loader Class Initialized
INFO - 2023-02-17 09:44:46 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:46 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:46 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:46 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:46 --> Total execution time: 0.0509
INFO - 2023-02-17 09:44:46 --> Config Class Initialized
INFO - 2023-02-17 09:44:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:46 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:46 --> URI Class Initialized
INFO - 2023-02-17 09:44:46 --> Router Class Initialized
INFO - 2023-02-17 09:44:46 --> Output Class Initialized
INFO - 2023-02-17 09:44:46 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:46 --> Input Class Initialized
INFO - 2023-02-17 09:44:46 --> Language Class Initialized
INFO - 2023-02-17 09:44:46 --> Loader Class Initialized
INFO - 2023-02-17 09:44:46 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:46 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:46 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:47 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:47 --> Total execution time: 0.0904
INFO - 2023-02-17 09:44:50 --> Config Class Initialized
INFO - 2023-02-17 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:50 --> URI Class Initialized
INFO - 2023-02-17 09:44:50 --> Router Class Initialized
INFO - 2023-02-17 09:44:50 --> Output Class Initialized
INFO - 2023-02-17 09:44:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:50 --> Input Class Initialized
INFO - 2023-02-17 09:44:50 --> Language Class Initialized
INFO - 2023-02-17 09:44:50 --> Loader Class Initialized
INFO - 2023-02-17 09:44:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:50 --> Model "Login_model" initialized
INFO - 2023-02-17 09:44:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:50 --> Total execution time: 0.0589
INFO - 2023-02-17 09:44:50 --> Config Class Initialized
INFO - 2023-02-17 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:50 --> URI Class Initialized
INFO - 2023-02-17 09:44:50 --> Router Class Initialized
INFO - 2023-02-17 09:44:50 --> Output Class Initialized
INFO - 2023-02-17 09:44:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:50 --> Input Class Initialized
INFO - 2023-02-17 09:44:50 --> Language Class Initialized
INFO - 2023-02-17 09:44:50 --> Loader Class Initialized
INFO - 2023-02-17 09:44:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:50 --> Model "Login_model" initialized
INFO - 2023-02-17 09:44:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:50 --> Total execution time: 0.0981
INFO - 2023-02-17 09:44:54 --> Config Class Initialized
INFO - 2023-02-17 09:44:54 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:54 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:54 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:54 --> URI Class Initialized
INFO - 2023-02-17 09:44:54 --> Router Class Initialized
INFO - 2023-02-17 09:44:54 --> Output Class Initialized
INFO - 2023-02-17 09:44:54 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:54 --> Input Class Initialized
INFO - 2023-02-17 09:44:54 --> Language Class Initialized
INFO - 2023-02-17 09:44:54 --> Loader Class Initialized
INFO - 2023-02-17 09:44:54 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:54 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:54 --> Total execution time: 0.0061
INFO - 2023-02-17 09:44:54 --> Config Class Initialized
INFO - 2023-02-17 09:44:54 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:54 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:54 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:54 --> URI Class Initialized
INFO - 2023-02-17 09:44:54 --> Router Class Initialized
INFO - 2023-02-17 09:44:54 --> Output Class Initialized
INFO - 2023-02-17 09:44:54 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:54 --> Input Class Initialized
INFO - 2023-02-17 09:44:54 --> Language Class Initialized
INFO - 2023-02-17 09:44:54 --> Loader Class Initialized
INFO - 2023-02-17 09:44:54 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:54 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:54 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:54 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:54 --> Total execution time: 0.0138
INFO - 2023-02-17 09:44:58 --> Config Class Initialized
INFO - 2023-02-17 09:44:58 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:58 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:58 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:58 --> URI Class Initialized
INFO - 2023-02-17 09:44:58 --> Router Class Initialized
INFO - 2023-02-17 09:44:58 --> Output Class Initialized
INFO - 2023-02-17 09:44:58 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:58 --> Input Class Initialized
INFO - 2023-02-17 09:44:58 --> Language Class Initialized
INFO - 2023-02-17 09:44:58 --> Loader Class Initialized
INFO - 2023-02-17 09:44:58 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:58 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:58 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:58 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:58 --> Total execution time: 0.0182
INFO - 2023-02-17 09:44:58 --> Config Class Initialized
INFO - 2023-02-17 09:44:58 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:44:58 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:44:58 --> Utf8 Class Initialized
INFO - 2023-02-17 09:44:58 --> URI Class Initialized
INFO - 2023-02-17 09:44:58 --> Router Class Initialized
INFO - 2023-02-17 09:44:58 --> Output Class Initialized
INFO - 2023-02-17 09:44:58 --> Security Class Initialized
DEBUG - 2023-02-17 09:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:44:58 --> Input Class Initialized
INFO - 2023-02-17 09:44:58 --> Language Class Initialized
INFO - 2023-02-17 09:44:58 --> Loader Class Initialized
INFO - 2023-02-17 09:44:58 --> Controller Class Initialized
DEBUG - 2023-02-17 09:44:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:44:58 --> Database Driver Class Initialized
INFO - 2023-02-17 09:44:58 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:44:58 --> Final output sent to browser
DEBUG - 2023-02-17 09:44:58 --> Total execution time: 0.0544
INFO - 2023-02-17 09:45:00 --> Config Class Initialized
INFO - 2023-02-17 09:45:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:00 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:00 --> URI Class Initialized
INFO - 2023-02-17 09:45:00 --> Router Class Initialized
INFO - 2023-02-17 09:45:00 --> Output Class Initialized
INFO - 2023-02-17 09:45:00 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:00 --> Input Class Initialized
INFO - 2023-02-17 09:45:00 --> Language Class Initialized
INFO - 2023-02-17 09:45:00 --> Loader Class Initialized
INFO - 2023-02-17 09:45:00 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:00 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:00 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:00 --> Total execution time: 0.0143
INFO - 2023-02-17 09:45:00 --> Config Class Initialized
INFO - 2023-02-17 09:45:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:00 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:00 --> URI Class Initialized
INFO - 2023-02-17 09:45:00 --> Router Class Initialized
INFO - 2023-02-17 09:45:00 --> Output Class Initialized
INFO - 2023-02-17 09:45:00 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:00 --> Input Class Initialized
INFO - 2023-02-17 09:45:00 --> Language Class Initialized
INFO - 2023-02-17 09:45:00 --> Loader Class Initialized
INFO - 2023-02-17 09:45:00 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:00 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:00 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:00 --> Total execution time: 0.0546
INFO - 2023-02-17 09:45:01 --> Config Class Initialized
INFO - 2023-02-17 09:45:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:01 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:01 --> URI Class Initialized
INFO - 2023-02-17 09:45:01 --> Router Class Initialized
INFO - 2023-02-17 09:45:01 --> Output Class Initialized
INFO - 2023-02-17 09:45:01 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:01 --> Input Class Initialized
INFO - 2023-02-17 09:45:01 --> Language Class Initialized
INFO - 2023-02-17 09:45:01 --> Loader Class Initialized
INFO - 2023-02-17 09:45:01 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:01 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:01 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:01 --> Total execution time: 0.0174
INFO - 2023-02-17 09:45:04 --> Config Class Initialized
INFO - 2023-02-17 09:45:04 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:04 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:04 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:04 --> URI Class Initialized
INFO - 2023-02-17 09:45:04 --> Router Class Initialized
INFO - 2023-02-17 09:45:04 --> Output Class Initialized
INFO - 2023-02-17 09:45:04 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:04 --> Input Class Initialized
INFO - 2023-02-17 09:45:04 --> Language Class Initialized
INFO - 2023-02-17 09:45:04 --> Loader Class Initialized
INFO - 2023-02-17 09:45:04 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:04 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:04 --> Total execution time: 0.0051
INFO - 2023-02-17 09:45:04 --> Config Class Initialized
INFO - 2023-02-17 09:45:04 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:04 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:04 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:04 --> URI Class Initialized
INFO - 2023-02-17 09:45:04 --> Router Class Initialized
INFO - 2023-02-17 09:45:04 --> Output Class Initialized
INFO - 2023-02-17 09:45:04 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:04 --> Input Class Initialized
INFO - 2023-02-17 09:45:04 --> Language Class Initialized
INFO - 2023-02-17 09:45:04 --> Loader Class Initialized
INFO - 2023-02-17 09:45:04 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:04 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:05 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:05 --> Total execution time: 0.0135
INFO - 2023-02-17 09:45:06 --> Config Class Initialized
INFO - 2023-02-17 09:45:06 --> Config Class Initialized
INFO - 2023-02-17 09:45:06 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:06 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:06 --> Hooks Class Initialized
INFO - 2023-02-17 09:45:06 --> URI Class Initialized
DEBUG - 2023-02-17 09:45:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:06 --> Router Class Initialized
INFO - 2023-02-17 09:45:06 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:06 --> Output Class Initialized
INFO - 2023-02-17 09:45:06 --> URI Class Initialized
INFO - 2023-02-17 09:45:06 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:06 --> Router Class Initialized
INFO - 2023-02-17 09:45:06 --> Input Class Initialized
INFO - 2023-02-17 09:45:06 --> Output Class Initialized
INFO - 2023-02-17 09:45:06 --> Language Class Initialized
INFO - 2023-02-17 09:45:06 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:06 --> Loader Class Initialized
INFO - 2023-02-17 09:45:06 --> Input Class Initialized
INFO - 2023-02-17 09:45:06 --> Controller Class Initialized
INFO - 2023-02-17 09:45:06 --> Language Class Initialized
DEBUG - 2023-02-17 09:45:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:06 --> Loader Class Initialized
INFO - 2023-02-17 09:45:06 --> Final output sent to browser
INFO - 2023-02-17 09:45:06 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:06 --> Total execution time: 0.0049
DEBUG - 2023-02-17 09:45:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:06 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:06 --> Total execution time: 0.0054
INFO - 2023-02-17 09:45:06 --> Config Class Initialized
INFO - 2023-02-17 09:45:06 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:06 --> Config Class Initialized
INFO - 2023-02-17 09:45:06 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:06 --> Hooks Class Initialized
INFO - 2023-02-17 09:45:06 --> URI Class Initialized
DEBUG - 2023-02-17 09:45:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:06 --> Router Class Initialized
INFO - 2023-02-17 09:45:06 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:06 --> Output Class Initialized
INFO - 2023-02-17 09:45:06 --> URI Class Initialized
INFO - 2023-02-17 09:45:06 --> Security Class Initialized
INFO - 2023-02-17 09:45:06 --> Router Class Initialized
DEBUG - 2023-02-17 09:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:06 --> Output Class Initialized
INFO - 2023-02-17 09:45:06 --> Input Class Initialized
INFO - 2023-02-17 09:45:06 --> Security Class Initialized
INFO - 2023-02-17 09:45:06 --> Language Class Initialized
DEBUG - 2023-02-17 09:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:06 --> Input Class Initialized
INFO - 2023-02-17 09:45:06 --> Loader Class Initialized
INFO - 2023-02-17 09:45:06 --> Language Class Initialized
INFO - 2023-02-17 09:45:06 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:06 --> Loader Class Initialized
INFO - 2023-02-17 09:45:06 --> Controller Class Initialized
INFO - 2023-02-17 09:45:06 --> Database Driver Class Initialized
DEBUG - 2023-02-17 09:45:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:06 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:06 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:06 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:06 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:06 --> Total execution time: 0.0127
INFO - 2023-02-17 09:45:06 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:06 --> Total execution time: 0.0138
INFO - 2023-02-17 09:45:11 --> Config Class Initialized
INFO - 2023-02-17 09:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:11 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:11 --> URI Class Initialized
INFO - 2023-02-17 09:45:11 --> Router Class Initialized
INFO - 2023-02-17 09:45:11 --> Output Class Initialized
INFO - 2023-02-17 09:45:11 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:11 --> Input Class Initialized
INFO - 2023-02-17 09:45:11 --> Language Class Initialized
INFO - 2023-02-17 09:45:11 --> Loader Class Initialized
INFO - 2023-02-17 09:45:11 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:11 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:11 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:11 --> Total execution time: 0.0171
INFO - 2023-02-17 09:45:11 --> Config Class Initialized
INFO - 2023-02-17 09:45:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:11 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:11 --> URI Class Initialized
INFO - 2023-02-17 09:45:11 --> Router Class Initialized
INFO - 2023-02-17 09:45:11 --> Output Class Initialized
INFO - 2023-02-17 09:45:11 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:11 --> Input Class Initialized
INFO - 2023-02-17 09:45:11 --> Language Class Initialized
INFO - 2023-02-17 09:45:11 --> Loader Class Initialized
INFO - 2023-02-17 09:45:11 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:11 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:11 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:11 --> Total execution time: 0.0527
INFO - 2023-02-17 09:45:13 --> Config Class Initialized
INFO - 2023-02-17 09:45:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:13 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:13 --> URI Class Initialized
INFO - 2023-02-17 09:45:13 --> Router Class Initialized
INFO - 2023-02-17 09:45:13 --> Output Class Initialized
INFO - 2023-02-17 09:45:13 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:13 --> Input Class Initialized
INFO - 2023-02-17 09:45:13 --> Language Class Initialized
INFO - 2023-02-17 09:45:13 --> Loader Class Initialized
INFO - 2023-02-17 09:45:13 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:13 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:13 --> Total execution time: 0.0040
INFO - 2023-02-17 09:45:13 --> Config Class Initialized
INFO - 2023-02-17 09:45:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:13 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:13 --> URI Class Initialized
INFO - 2023-02-17 09:45:13 --> Router Class Initialized
INFO - 2023-02-17 09:45:13 --> Output Class Initialized
INFO - 2023-02-17 09:45:13 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:13 --> Input Class Initialized
INFO - 2023-02-17 09:45:13 --> Language Class Initialized
INFO - 2023-02-17 09:45:13 --> Loader Class Initialized
INFO - 2023-02-17 09:45:13 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:13 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:13 --> Model "Login_model" initialized
INFO - 2023-02-17 09:45:13 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:13 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:13 --> Total execution time: 0.0220
INFO - 2023-02-17 09:45:13 --> Config Class Initialized
INFO - 2023-02-17 09:45:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:13 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:13 --> URI Class Initialized
INFO - 2023-02-17 09:45:13 --> Router Class Initialized
INFO - 2023-02-17 09:45:13 --> Output Class Initialized
INFO - 2023-02-17 09:45:13 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:13 --> Input Class Initialized
INFO - 2023-02-17 09:45:13 --> Language Class Initialized
INFO - 2023-02-17 09:45:13 --> Loader Class Initialized
INFO - 2023-02-17 09:45:13 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:13 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:13 --> Total execution time: 0.0425
INFO - 2023-02-17 09:45:13 --> Config Class Initialized
INFO - 2023-02-17 09:45:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:13 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:13 --> URI Class Initialized
INFO - 2023-02-17 09:45:13 --> Router Class Initialized
INFO - 2023-02-17 09:45:13 --> Output Class Initialized
INFO - 2023-02-17 09:45:13 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:13 --> Input Class Initialized
INFO - 2023-02-17 09:45:13 --> Language Class Initialized
INFO - 2023-02-17 09:45:13 --> Loader Class Initialized
INFO - 2023-02-17 09:45:13 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:13 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:13 --> Model "Login_model" initialized
INFO - 2023-02-17 09:45:13 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:13 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:13 --> Total execution time: 0.0219
INFO - 2023-02-17 09:45:14 --> Config Class Initialized
INFO - 2023-02-17 09:45:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:14 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:14 --> URI Class Initialized
INFO - 2023-02-17 09:45:14 --> Router Class Initialized
INFO - 2023-02-17 09:45:14 --> Output Class Initialized
INFO - 2023-02-17 09:45:14 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:14 --> Input Class Initialized
INFO - 2023-02-17 09:45:14 --> Language Class Initialized
INFO - 2023-02-17 09:45:14 --> Loader Class Initialized
INFO - 2023-02-17 09:45:14 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:14 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:14 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:14 --> Model "Login_model" initialized
INFO - 2023-02-17 09:45:14 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:14 --> Total execution time: 0.0742
INFO - 2023-02-17 09:45:14 --> Config Class Initialized
INFO - 2023-02-17 09:45:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:14 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:14 --> URI Class Initialized
INFO - 2023-02-17 09:45:14 --> Router Class Initialized
INFO - 2023-02-17 09:45:14 --> Output Class Initialized
INFO - 2023-02-17 09:45:14 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:14 --> Input Class Initialized
INFO - 2023-02-17 09:45:14 --> Language Class Initialized
INFO - 2023-02-17 09:45:14 --> Loader Class Initialized
INFO - 2023-02-17 09:45:14 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:14 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:14 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:14 --> Model "Login_model" initialized
INFO - 2023-02-17 09:45:14 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:14 --> Total execution time: 0.0401
INFO - 2023-02-17 09:45:17 --> Config Class Initialized
INFO - 2023-02-17 09:45:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:17 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:17 --> URI Class Initialized
INFO - 2023-02-17 09:45:17 --> Router Class Initialized
INFO - 2023-02-17 09:45:17 --> Output Class Initialized
INFO - 2023-02-17 09:45:17 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:17 --> Input Class Initialized
INFO - 2023-02-17 09:45:17 --> Language Class Initialized
INFO - 2023-02-17 09:45:17 --> Loader Class Initialized
INFO - 2023-02-17 09:45:17 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:17 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:17 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:17 --> Total execution time: 0.0247
INFO - 2023-02-17 09:45:17 --> Config Class Initialized
INFO - 2023-02-17 09:45:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:45:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:45:17 --> Utf8 Class Initialized
INFO - 2023-02-17 09:45:17 --> URI Class Initialized
INFO - 2023-02-17 09:45:17 --> Router Class Initialized
INFO - 2023-02-17 09:45:17 --> Output Class Initialized
INFO - 2023-02-17 09:45:17 --> Security Class Initialized
DEBUG - 2023-02-17 09:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:45:17 --> Input Class Initialized
INFO - 2023-02-17 09:45:17 --> Language Class Initialized
INFO - 2023-02-17 09:45:17 --> Loader Class Initialized
INFO - 2023-02-17 09:45:17 --> Controller Class Initialized
DEBUG - 2023-02-17 09:45:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:45:17 --> Database Driver Class Initialized
INFO - 2023-02-17 09:45:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:45:17 --> Final output sent to browser
DEBUG - 2023-02-17 09:45:17 --> Total execution time: 0.0523
INFO - 2023-02-17 09:48:01 --> Config Class Initialized
INFO - 2023-02-17 09:48:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:48:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:48:01 --> Utf8 Class Initialized
INFO - 2023-02-17 09:48:01 --> URI Class Initialized
INFO - 2023-02-17 09:48:01 --> Router Class Initialized
INFO - 2023-02-17 09:48:01 --> Output Class Initialized
INFO - 2023-02-17 09:48:01 --> Security Class Initialized
DEBUG - 2023-02-17 09:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:48:01 --> Input Class Initialized
INFO - 2023-02-17 09:48:01 --> Language Class Initialized
INFO - 2023-02-17 09:48:01 --> Loader Class Initialized
INFO - 2023-02-17 09:48:01 --> Controller Class Initialized
DEBUG - 2023-02-17 09:48:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:48:01 --> Database Driver Class Initialized
INFO - 2023-02-17 09:48:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:48:01 --> Final output sent to browser
DEBUG - 2023-02-17 09:48:01 --> Total execution time: 0.1064
INFO - 2023-02-17 09:48:01 --> Config Class Initialized
INFO - 2023-02-17 09:48:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:48:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:48:01 --> Utf8 Class Initialized
INFO - 2023-02-17 09:48:01 --> URI Class Initialized
INFO - 2023-02-17 09:48:01 --> Router Class Initialized
INFO - 2023-02-17 09:48:01 --> Output Class Initialized
INFO - 2023-02-17 09:48:01 --> Security Class Initialized
DEBUG - 2023-02-17 09:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:48:01 --> Input Class Initialized
INFO - 2023-02-17 09:48:01 --> Language Class Initialized
INFO - 2023-02-17 09:48:01 --> Loader Class Initialized
INFO - 2023-02-17 09:48:01 --> Controller Class Initialized
DEBUG - 2023-02-17 09:48:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:48:01 --> Database Driver Class Initialized
INFO - 2023-02-17 09:48:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:48:01 --> Final output sent to browser
DEBUG - 2023-02-17 09:48:01 --> Total execution time: 0.0168
INFO - 2023-02-17 09:48:05 --> Config Class Initialized
INFO - 2023-02-17 09:48:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:48:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:48:05 --> Utf8 Class Initialized
INFO - 2023-02-17 09:48:05 --> URI Class Initialized
INFO - 2023-02-17 09:48:05 --> Router Class Initialized
INFO - 2023-02-17 09:48:05 --> Output Class Initialized
INFO - 2023-02-17 09:48:05 --> Security Class Initialized
DEBUG - 2023-02-17 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:48:05 --> Input Class Initialized
INFO - 2023-02-17 09:48:05 --> Language Class Initialized
INFO - 2023-02-17 09:48:05 --> Loader Class Initialized
INFO - 2023-02-17 09:48:05 --> Controller Class Initialized
DEBUG - 2023-02-17 09:48:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:48:05 --> Database Driver Class Initialized
INFO - 2023-02-17 09:48:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:48:05 --> Final output sent to browser
DEBUG - 2023-02-17 09:48:05 --> Total execution time: 0.0579
INFO - 2023-02-17 09:48:23 --> Config Class Initialized
INFO - 2023-02-17 09:48:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:48:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:48:23 --> Utf8 Class Initialized
INFO - 2023-02-17 09:48:23 --> URI Class Initialized
INFO - 2023-02-17 09:48:23 --> Router Class Initialized
INFO - 2023-02-17 09:48:23 --> Output Class Initialized
INFO - 2023-02-17 09:48:23 --> Security Class Initialized
DEBUG - 2023-02-17 09:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:48:23 --> Input Class Initialized
INFO - 2023-02-17 09:48:23 --> Language Class Initialized
INFO - 2023-02-17 09:48:23 --> Loader Class Initialized
INFO - 2023-02-17 09:48:23 --> Controller Class Initialized
DEBUG - 2023-02-17 09:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:48:23 --> Database Driver Class Initialized
INFO - 2023-02-17 09:48:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:48:23 --> Final output sent to browser
DEBUG - 2023-02-17 09:48:23 --> Total execution time: 0.1164
INFO - 2023-02-17 09:48:23 --> Config Class Initialized
INFO - 2023-02-17 09:48:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:48:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:48:23 --> Utf8 Class Initialized
INFO - 2023-02-17 09:48:23 --> URI Class Initialized
INFO - 2023-02-17 09:48:23 --> Router Class Initialized
INFO - 2023-02-17 09:48:23 --> Output Class Initialized
INFO - 2023-02-17 09:48:23 --> Security Class Initialized
DEBUG - 2023-02-17 09:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:48:23 --> Input Class Initialized
INFO - 2023-02-17 09:48:23 --> Language Class Initialized
INFO - 2023-02-17 09:48:23 --> Loader Class Initialized
INFO - 2023-02-17 09:48:23 --> Controller Class Initialized
DEBUG - 2023-02-17 09:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:48:23 --> Database Driver Class Initialized
INFO - 2023-02-17 09:48:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:48:23 --> Final output sent to browser
DEBUG - 2023-02-17 09:48:23 --> Total execution time: 0.0156
INFO - 2023-02-17 09:48:42 --> Config Class Initialized
INFO - 2023-02-17 09:48:42 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:48:42 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:48:42 --> Utf8 Class Initialized
INFO - 2023-02-17 09:48:42 --> URI Class Initialized
INFO - 2023-02-17 09:48:42 --> Router Class Initialized
INFO - 2023-02-17 09:48:42 --> Output Class Initialized
INFO - 2023-02-17 09:48:42 --> Security Class Initialized
DEBUG - 2023-02-17 09:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:48:42 --> Input Class Initialized
INFO - 2023-02-17 09:48:42 --> Language Class Initialized
INFO - 2023-02-17 09:48:42 --> Loader Class Initialized
INFO - 2023-02-17 09:48:42 --> Controller Class Initialized
DEBUG - 2023-02-17 09:48:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:48:42 --> Database Driver Class Initialized
INFO - 2023-02-17 09:48:42 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:48:42 --> Final output sent to browser
DEBUG - 2023-02-17 09:48:42 --> Total execution time: 0.0987
INFO - 2023-02-17 09:48:42 --> Config Class Initialized
INFO - 2023-02-17 09:48:42 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:48:42 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:48:42 --> Utf8 Class Initialized
INFO - 2023-02-17 09:48:42 --> URI Class Initialized
INFO - 2023-02-17 09:48:42 --> Router Class Initialized
INFO - 2023-02-17 09:48:42 --> Output Class Initialized
INFO - 2023-02-17 09:48:42 --> Security Class Initialized
DEBUG - 2023-02-17 09:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:48:42 --> Input Class Initialized
INFO - 2023-02-17 09:48:42 --> Language Class Initialized
INFO - 2023-02-17 09:48:42 --> Loader Class Initialized
INFO - 2023-02-17 09:48:42 --> Controller Class Initialized
DEBUG - 2023-02-17 09:48:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:48:42 --> Database Driver Class Initialized
INFO - 2023-02-17 09:48:42 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:48:42 --> Final output sent to browser
DEBUG - 2023-02-17 09:48:42 --> Total execution time: 0.0123
INFO - 2023-02-17 09:49:20 --> Config Class Initialized
INFO - 2023-02-17 09:49:20 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:20 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:20 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:20 --> URI Class Initialized
INFO - 2023-02-17 09:49:20 --> Router Class Initialized
INFO - 2023-02-17 09:49:20 --> Output Class Initialized
INFO - 2023-02-17 09:49:21 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:21 --> Input Class Initialized
INFO - 2023-02-17 09:49:21 --> Language Class Initialized
INFO - 2023-02-17 09:49:21 --> Loader Class Initialized
INFO - 2023-02-17 09:49:21 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:21 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:21 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:21 --> Total execution time: 0.0971
INFO - 2023-02-17 09:49:21 --> Config Class Initialized
INFO - 2023-02-17 09:49:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:21 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:21 --> URI Class Initialized
INFO - 2023-02-17 09:49:21 --> Router Class Initialized
INFO - 2023-02-17 09:49:21 --> Output Class Initialized
INFO - 2023-02-17 09:49:21 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:21 --> Input Class Initialized
INFO - 2023-02-17 09:49:21 --> Language Class Initialized
INFO - 2023-02-17 09:49:21 --> Loader Class Initialized
INFO - 2023-02-17 09:49:21 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:21 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:21 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:21 --> Total execution time: 0.0116
INFO - 2023-02-17 09:49:25 --> Config Class Initialized
INFO - 2023-02-17 09:49:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:26 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:26 --> URI Class Initialized
INFO - 2023-02-17 09:49:26 --> Router Class Initialized
INFO - 2023-02-17 09:49:26 --> Output Class Initialized
INFO - 2023-02-17 09:49:26 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:26 --> Input Class Initialized
INFO - 2023-02-17 09:49:26 --> Language Class Initialized
INFO - 2023-02-17 09:49:26 --> Loader Class Initialized
INFO - 2023-02-17 09:49:26 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:26 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:26 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:26 --> Total execution time: 0.0623
INFO - 2023-02-17 09:49:28 --> Config Class Initialized
INFO - 2023-02-17 09:49:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:28 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:28 --> URI Class Initialized
INFO - 2023-02-17 09:49:28 --> Router Class Initialized
INFO - 2023-02-17 09:49:28 --> Output Class Initialized
INFO - 2023-02-17 09:49:28 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:28 --> Input Class Initialized
INFO - 2023-02-17 09:49:28 --> Language Class Initialized
INFO - 2023-02-17 09:49:28 --> Loader Class Initialized
INFO - 2023-02-17 09:49:28 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:28 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:28 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:28 --> Model "Login_model" initialized
INFO - 2023-02-17 09:49:28 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:28 --> Total execution time: 0.0446
INFO - 2023-02-17 09:49:28 --> Config Class Initialized
INFO - 2023-02-17 09:49:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:28 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:28 --> URI Class Initialized
INFO - 2023-02-17 09:49:28 --> Router Class Initialized
INFO - 2023-02-17 09:49:28 --> Output Class Initialized
INFO - 2023-02-17 09:49:28 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:28 --> Input Class Initialized
INFO - 2023-02-17 09:49:28 --> Language Class Initialized
INFO - 2023-02-17 09:49:28 --> Loader Class Initialized
INFO - 2023-02-17 09:49:28 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:28 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:28 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:28 --> Model "Login_model" initialized
INFO - 2023-02-17 09:49:28 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:28 --> Total execution time: 0.0456
INFO - 2023-02-17 09:49:29 --> Config Class Initialized
INFO - 2023-02-17 09:49:29 --> Hooks Class Initialized
INFO - 2023-02-17 09:49:29 --> Config Class Initialized
INFO - 2023-02-17 09:49:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 09:49:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:29 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:29 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:29 --> URI Class Initialized
INFO - 2023-02-17 09:49:29 --> URI Class Initialized
INFO - 2023-02-17 09:49:29 --> Router Class Initialized
INFO - 2023-02-17 09:49:29 --> Router Class Initialized
INFO - 2023-02-17 09:49:29 --> Output Class Initialized
INFO - 2023-02-17 09:49:29 --> Output Class Initialized
INFO - 2023-02-17 09:49:29 --> Security Class Initialized
INFO - 2023-02-17 09:49:29 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:29 --> Input Class Initialized
INFO - 2023-02-17 09:49:29 --> Input Class Initialized
INFO - 2023-02-17 09:49:29 --> Language Class Initialized
INFO - 2023-02-17 09:49:29 --> Language Class Initialized
INFO - 2023-02-17 09:49:29 --> Loader Class Initialized
INFO - 2023-02-17 09:49:29 --> Loader Class Initialized
INFO - 2023-02-17 09:49:29 --> Controller Class Initialized
INFO - 2023-02-17 09:49:29 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 09:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:29 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:29 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:29 --> Total execution time: 0.0040
INFO - 2023-02-17 09:49:29 --> Config Class Initialized
INFO - 2023-02-17 09:49:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:29 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:29 --> URI Class Initialized
INFO - 2023-02-17 09:49:29 --> Router Class Initialized
INFO - 2023-02-17 09:49:29 --> Output Class Initialized
INFO - 2023-02-17 09:49:29 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:29 --> Input Class Initialized
INFO - 2023-02-17 09:49:29 --> Language Class Initialized
INFO - 2023-02-17 09:49:29 --> Loader Class Initialized
INFO - 2023-02-17 09:49:29 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:29 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:29 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:29 --> Total execution time: 0.0146
INFO - 2023-02-17 09:49:29 --> Model "Login_model" initialized
INFO - 2023-02-17 09:49:29 --> Config Class Initialized
INFO - 2023-02-17 09:49:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:29 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:29 --> URI Class Initialized
INFO - 2023-02-17 09:49:29 --> Router Class Initialized
INFO - 2023-02-17 09:49:29 --> Output Class Initialized
INFO - 2023-02-17 09:49:29 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:29 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:29 --> Input Class Initialized
INFO - 2023-02-17 09:49:29 --> Language Class Initialized
INFO - 2023-02-17 09:49:29 --> Loader Class Initialized
INFO - 2023-02-17 09:49:29 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:29 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:29 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:29 --> Total execution time: 0.0185
INFO - 2023-02-17 09:49:29 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:29 --> Total execution time: 0.0119
INFO - 2023-02-17 09:49:31 --> Config Class Initialized
INFO - 2023-02-17 09:49:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:31 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:31 --> URI Class Initialized
INFO - 2023-02-17 09:49:31 --> Router Class Initialized
INFO - 2023-02-17 09:49:31 --> Output Class Initialized
INFO - 2023-02-17 09:49:31 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:31 --> Input Class Initialized
INFO - 2023-02-17 09:49:31 --> Language Class Initialized
INFO - 2023-02-17 09:49:31 --> Loader Class Initialized
INFO - 2023-02-17 09:49:31 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:31 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:31 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:31 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:31 --> Total execution time: 0.0481
INFO - 2023-02-17 09:49:31 --> Config Class Initialized
INFO - 2023-02-17 09:49:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:31 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:31 --> URI Class Initialized
INFO - 2023-02-17 09:49:31 --> Router Class Initialized
INFO - 2023-02-17 09:49:31 --> Output Class Initialized
INFO - 2023-02-17 09:49:31 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:31 --> Input Class Initialized
INFO - 2023-02-17 09:49:31 --> Language Class Initialized
INFO - 2023-02-17 09:49:31 --> Loader Class Initialized
INFO - 2023-02-17 09:49:31 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:31 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:31 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:31 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:31 --> Total execution time: 0.0453
INFO - 2023-02-17 09:49:34 --> Config Class Initialized
INFO - 2023-02-17 09:49:34 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:34 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:34 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:34 --> URI Class Initialized
INFO - 2023-02-17 09:49:34 --> Router Class Initialized
INFO - 2023-02-17 09:49:34 --> Output Class Initialized
INFO - 2023-02-17 09:49:34 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:34 --> Input Class Initialized
INFO - 2023-02-17 09:49:34 --> Language Class Initialized
INFO - 2023-02-17 09:49:34 --> Loader Class Initialized
INFO - 2023-02-17 09:49:34 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:34 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:34 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:34 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:34 --> Total execution time: 0.0206
INFO - 2023-02-17 09:49:34 --> Config Class Initialized
INFO - 2023-02-17 09:49:34 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:34 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:34 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:34 --> URI Class Initialized
INFO - 2023-02-17 09:49:34 --> Router Class Initialized
INFO - 2023-02-17 09:49:34 --> Output Class Initialized
INFO - 2023-02-17 09:49:34 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:34 --> Input Class Initialized
INFO - 2023-02-17 09:49:34 --> Language Class Initialized
INFO - 2023-02-17 09:49:34 --> Loader Class Initialized
INFO - 2023-02-17 09:49:34 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:34 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:34 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:34 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:34 --> Total execution time: 0.0132
INFO - 2023-02-17 09:49:41 --> Config Class Initialized
INFO - 2023-02-17 09:49:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:41 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:41 --> URI Class Initialized
INFO - 2023-02-17 09:49:41 --> Router Class Initialized
INFO - 2023-02-17 09:49:41 --> Output Class Initialized
INFO - 2023-02-17 09:49:41 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:41 --> Input Class Initialized
INFO - 2023-02-17 09:49:41 --> Language Class Initialized
INFO - 2023-02-17 09:49:41 --> Loader Class Initialized
INFO - 2023-02-17 09:49:41 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:41 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:41 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:41 --> Total execution time: 0.0690
INFO - 2023-02-17 09:49:41 --> Config Class Initialized
INFO - 2023-02-17 09:49:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:41 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:41 --> URI Class Initialized
INFO - 2023-02-17 09:49:41 --> Router Class Initialized
INFO - 2023-02-17 09:49:41 --> Output Class Initialized
INFO - 2023-02-17 09:49:41 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:41 --> Input Class Initialized
INFO - 2023-02-17 09:49:41 --> Language Class Initialized
INFO - 2023-02-17 09:49:41 --> Loader Class Initialized
INFO - 2023-02-17 09:49:41 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:41 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:41 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:41 --> Total execution time: 0.0521
INFO - 2023-02-17 09:49:45 --> Config Class Initialized
INFO - 2023-02-17 09:49:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:45 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:45 --> URI Class Initialized
INFO - 2023-02-17 09:49:45 --> Router Class Initialized
INFO - 2023-02-17 09:49:45 --> Output Class Initialized
INFO - 2023-02-17 09:49:45 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:45 --> Input Class Initialized
INFO - 2023-02-17 09:49:45 --> Language Class Initialized
INFO - 2023-02-17 09:49:45 --> Loader Class Initialized
INFO - 2023-02-17 09:49:45 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:45 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:45 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:45 --> Total execution time: 0.0462
INFO - 2023-02-17 09:49:45 --> Config Class Initialized
INFO - 2023-02-17 09:49:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:45 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:45 --> URI Class Initialized
INFO - 2023-02-17 09:49:45 --> Router Class Initialized
INFO - 2023-02-17 09:49:45 --> Output Class Initialized
INFO - 2023-02-17 09:49:45 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:45 --> Input Class Initialized
INFO - 2023-02-17 09:49:45 --> Language Class Initialized
INFO - 2023-02-17 09:49:45 --> Loader Class Initialized
INFO - 2023-02-17 09:49:45 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:45 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:45 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:45 --> Total execution time: 0.0399
INFO - 2023-02-17 09:49:46 --> Config Class Initialized
INFO - 2023-02-17 09:49:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:46 --> URI Class Initialized
INFO - 2023-02-17 09:49:46 --> Router Class Initialized
INFO - 2023-02-17 09:49:46 --> Output Class Initialized
INFO - 2023-02-17 09:49:46 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:46 --> Input Class Initialized
INFO - 2023-02-17 09:49:46 --> Language Class Initialized
INFO - 2023-02-17 09:49:46 --> Loader Class Initialized
INFO - 2023-02-17 09:49:46 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:46 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:46 --> Total execution time: 0.0228
INFO - 2023-02-17 09:49:46 --> Config Class Initialized
INFO - 2023-02-17 09:49:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:46 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:46 --> URI Class Initialized
INFO - 2023-02-17 09:49:46 --> Router Class Initialized
INFO - 2023-02-17 09:49:46 --> Output Class Initialized
INFO - 2023-02-17 09:49:46 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:46 --> Input Class Initialized
INFO - 2023-02-17 09:49:46 --> Language Class Initialized
INFO - 2023-02-17 09:49:46 --> Loader Class Initialized
INFO - 2023-02-17 09:49:46 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:46 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:46 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:46 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:46 --> Total execution time: 0.0184
INFO - 2023-02-17 09:49:49 --> Config Class Initialized
INFO - 2023-02-17 09:49:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:49 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:49 --> URI Class Initialized
INFO - 2023-02-17 09:49:49 --> Router Class Initialized
INFO - 2023-02-17 09:49:49 --> Output Class Initialized
INFO - 2023-02-17 09:49:49 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:49 --> Input Class Initialized
INFO - 2023-02-17 09:49:49 --> Language Class Initialized
INFO - 2023-02-17 09:49:49 --> Loader Class Initialized
INFO - 2023-02-17 09:49:49 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:49 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:49 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:49 --> Total execution time: 0.0565
INFO - 2023-02-17 09:49:49 --> Config Class Initialized
INFO - 2023-02-17 09:49:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:49 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:49 --> URI Class Initialized
INFO - 2023-02-17 09:49:49 --> Router Class Initialized
INFO - 2023-02-17 09:49:49 --> Output Class Initialized
INFO - 2023-02-17 09:49:49 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:49 --> Input Class Initialized
INFO - 2023-02-17 09:49:49 --> Language Class Initialized
INFO - 2023-02-17 09:49:49 --> Loader Class Initialized
INFO - 2023-02-17 09:49:49 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:49 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:49 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:49 --> Total execution time: 0.0520
INFO - 2023-02-17 09:49:52 --> Config Class Initialized
INFO - 2023-02-17 09:49:52 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:52 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:52 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:52 --> URI Class Initialized
INFO - 2023-02-17 09:49:52 --> Router Class Initialized
INFO - 2023-02-17 09:49:52 --> Output Class Initialized
INFO - 2023-02-17 09:49:52 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:52 --> Input Class Initialized
INFO - 2023-02-17 09:49:52 --> Language Class Initialized
INFO - 2023-02-17 09:49:52 --> Loader Class Initialized
INFO - 2023-02-17 09:49:52 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:52 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:52 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:52 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:52 --> Total execution time: 0.0702
INFO - 2023-02-17 09:49:52 --> Config Class Initialized
INFO - 2023-02-17 09:49:52 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:52 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:52 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:52 --> URI Class Initialized
INFO - 2023-02-17 09:49:52 --> Router Class Initialized
INFO - 2023-02-17 09:49:52 --> Output Class Initialized
INFO - 2023-02-17 09:49:52 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:52 --> Input Class Initialized
INFO - 2023-02-17 09:49:52 --> Language Class Initialized
INFO - 2023-02-17 09:49:52 --> Loader Class Initialized
INFO - 2023-02-17 09:49:52 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:52 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:52 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:52 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:52 --> Total execution time: 0.1060
INFO - 2023-02-17 09:49:59 --> Config Class Initialized
INFO - 2023-02-17 09:49:59 --> Config Class Initialized
INFO - 2023-02-17 09:49:59 --> Hooks Class Initialized
INFO - 2023-02-17 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:59 --> Utf8 Class Initialized
DEBUG - 2023-02-17 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:59 --> URI Class Initialized
INFO - 2023-02-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:59 --> Router Class Initialized
INFO - 2023-02-17 09:49:59 --> URI Class Initialized
INFO - 2023-02-17 09:49:59 --> Output Class Initialized
INFO - 2023-02-17 09:49:59 --> Router Class Initialized
INFO - 2023-02-17 09:49:59 --> Security Class Initialized
INFO - 2023-02-17 09:49:59 --> Output Class Initialized
DEBUG - 2023-02-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:59 --> Security Class Initialized
INFO - 2023-02-17 09:49:59 --> Input Class Initialized
DEBUG - 2023-02-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:59 --> Language Class Initialized
INFO - 2023-02-17 09:49:59 --> Input Class Initialized
INFO - 2023-02-17 09:49:59 --> Language Class Initialized
INFO - 2023-02-17 09:49:59 --> Loader Class Initialized
INFO - 2023-02-17 09:49:59 --> Loader Class Initialized
INFO - 2023-02-17 09:49:59 --> Controller Class Initialized
INFO - 2023-02-17 09:49:59 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:59 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:59 --> Total execution time: 0.0043
INFO - 2023-02-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:59 --> Config Class Initialized
INFO - 2023-02-17 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:59 --> URI Class Initialized
INFO - 2023-02-17 09:49:59 --> Router Class Initialized
INFO - 2023-02-17 09:49:59 --> Output Class Initialized
INFO - 2023-02-17 09:49:59 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:59 --> Input Class Initialized
INFO - 2023-02-17 09:49:59 --> Language Class Initialized
INFO - 2023-02-17 09:49:59 --> Loader Class Initialized
INFO - 2023-02-17 09:49:59 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:59 --> Model "Login_model" initialized
INFO - 2023-02-17 09:49:59 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:59 --> Total execution time: 0.0185
INFO - 2023-02-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:59 --> Config Class Initialized
INFO - 2023-02-17 09:49:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:49:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:49:59 --> Utf8 Class Initialized
INFO - 2023-02-17 09:49:59 --> URI Class Initialized
INFO - 2023-02-17 09:49:59 --> Router Class Initialized
INFO - 2023-02-17 09:49:59 --> Output Class Initialized
INFO - 2023-02-17 09:49:59 --> Security Class Initialized
DEBUG - 2023-02-17 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:49:59 --> Input Class Initialized
INFO - 2023-02-17 09:49:59 --> Language Class Initialized
INFO - 2023-02-17 09:49:59 --> Loader Class Initialized
INFO - 2023-02-17 09:49:59 --> Controller Class Initialized
DEBUG - 2023-02-17 09:49:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:49:59 --> Database Driver Class Initialized
INFO - 2023-02-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:59 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:59 --> Total execution time: 0.0219
INFO - 2023-02-17 09:49:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:49:59 --> Final output sent to browser
DEBUG - 2023-02-17 09:49:59 --> Total execution time: 0.0524
INFO - 2023-02-17 09:50:03 --> Config Class Initialized
INFO - 2023-02-17 09:50:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:03 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:03 --> URI Class Initialized
INFO - 2023-02-17 09:50:03 --> Router Class Initialized
INFO - 2023-02-17 09:50:03 --> Output Class Initialized
INFO - 2023-02-17 09:50:03 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:03 --> Input Class Initialized
INFO - 2023-02-17 09:50:03 --> Language Class Initialized
INFO - 2023-02-17 09:50:03 --> Loader Class Initialized
INFO - 2023-02-17 09:50:03 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:03 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:03 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:03 --> Model "Login_model" initialized
INFO - 2023-02-17 09:50:03 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:03 --> Total execution time: 0.0386
INFO - 2023-02-17 09:50:03 --> Config Class Initialized
INFO - 2023-02-17 09:50:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:03 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:03 --> URI Class Initialized
INFO - 2023-02-17 09:50:03 --> Router Class Initialized
INFO - 2023-02-17 09:50:03 --> Output Class Initialized
INFO - 2023-02-17 09:50:03 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:03 --> Input Class Initialized
INFO - 2023-02-17 09:50:03 --> Language Class Initialized
INFO - 2023-02-17 09:50:03 --> Loader Class Initialized
INFO - 2023-02-17 09:50:03 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:03 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:03 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:03 --> Model "Login_model" initialized
INFO - 2023-02-17 09:50:03 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:03 --> Total execution time: 0.0355
INFO - 2023-02-17 09:50:45 --> Config Class Initialized
INFO - 2023-02-17 09:50:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:45 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:45 --> URI Class Initialized
INFO - 2023-02-17 09:50:45 --> Router Class Initialized
INFO - 2023-02-17 09:50:45 --> Output Class Initialized
INFO - 2023-02-17 09:50:45 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:45 --> Input Class Initialized
INFO - 2023-02-17 09:50:45 --> Language Class Initialized
INFO - 2023-02-17 09:50:45 --> Loader Class Initialized
INFO - 2023-02-17 09:50:45 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:45 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:45 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:45 --> Total execution time: 0.0147
INFO - 2023-02-17 09:50:45 --> Config Class Initialized
INFO - 2023-02-17 09:50:45 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:45 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:45 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:45 --> URI Class Initialized
INFO - 2023-02-17 09:50:45 --> Router Class Initialized
INFO - 2023-02-17 09:50:45 --> Output Class Initialized
INFO - 2023-02-17 09:50:45 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:45 --> Input Class Initialized
INFO - 2023-02-17 09:50:45 --> Language Class Initialized
INFO - 2023-02-17 09:50:45 --> Loader Class Initialized
INFO - 2023-02-17 09:50:45 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:45 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:45 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:45 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:45 --> Total execution time: 0.0142
INFO - 2023-02-17 09:50:47 --> Config Class Initialized
INFO - 2023-02-17 09:50:47 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:47 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:47 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:47 --> URI Class Initialized
INFO - 2023-02-17 09:50:47 --> Router Class Initialized
INFO - 2023-02-17 09:50:47 --> Output Class Initialized
INFO - 2023-02-17 09:50:47 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:47 --> Input Class Initialized
INFO - 2023-02-17 09:50:47 --> Language Class Initialized
INFO - 2023-02-17 09:50:47 --> Loader Class Initialized
INFO - 2023-02-17 09:50:47 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:47 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:47 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:47 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:47 --> Total execution time: 0.1060
INFO - 2023-02-17 09:50:47 --> Config Class Initialized
INFO - 2023-02-17 09:50:47 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:47 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:47 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:47 --> URI Class Initialized
INFO - 2023-02-17 09:50:47 --> Router Class Initialized
INFO - 2023-02-17 09:50:47 --> Output Class Initialized
INFO - 2023-02-17 09:50:47 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:47 --> Input Class Initialized
INFO - 2023-02-17 09:50:47 --> Language Class Initialized
INFO - 2023-02-17 09:50:47 --> Loader Class Initialized
INFO - 2023-02-17 09:50:47 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:47 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:47 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:47 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:47 --> Total execution time: 0.0477
INFO - 2023-02-17 09:50:50 --> Config Class Initialized
INFO - 2023-02-17 09:50:50 --> Config Class Initialized
INFO - 2023-02-17 09:50:50 --> Hooks Class Initialized
INFO - 2023-02-17 09:50:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 09:50:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:50 --> URI Class Initialized
INFO - 2023-02-17 09:50:50 --> URI Class Initialized
INFO - 2023-02-17 09:50:50 --> Router Class Initialized
INFO - 2023-02-17 09:50:50 --> Router Class Initialized
INFO - 2023-02-17 09:50:50 --> Output Class Initialized
INFO - 2023-02-17 09:50:50 --> Output Class Initialized
INFO - 2023-02-17 09:50:50 --> Security Class Initialized
INFO - 2023-02-17 09:50:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 09:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:50 --> Input Class Initialized
INFO - 2023-02-17 09:50:50 --> Input Class Initialized
INFO - 2023-02-17 09:50:50 --> Language Class Initialized
INFO - 2023-02-17 09:50:50 --> Language Class Initialized
INFO - 2023-02-17 09:50:50 --> Loader Class Initialized
INFO - 2023-02-17 09:50:50 --> Loader Class Initialized
INFO - 2023-02-17 09:50:50 --> Controller Class Initialized
INFO - 2023-02-17 09:50:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 09:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:50 --> Total execution time: 0.0043
INFO - 2023-02-17 09:50:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:50 --> Config Class Initialized
INFO - 2023-02-17 09:50:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:50 --> URI Class Initialized
INFO - 2023-02-17 09:50:50 --> Router Class Initialized
INFO - 2023-02-17 09:50:50 --> Output Class Initialized
INFO - 2023-02-17 09:50:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:50 --> Input Class Initialized
INFO - 2023-02-17 09:50:50 --> Language Class Initialized
INFO - 2023-02-17 09:50:50 --> Loader Class Initialized
INFO - 2023-02-17 09:50:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:50 --> Model "Login_model" initialized
INFO - 2023-02-17 09:50:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:50 --> Total execution time: 0.0203
INFO - 2023-02-17 09:50:50 --> Config Class Initialized
INFO - 2023-02-17 09:50:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:50 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:50 --> URI Class Initialized
INFO - 2023-02-17 09:50:50 --> Router Class Initialized
INFO - 2023-02-17 09:50:50 --> Output Class Initialized
INFO - 2023-02-17 09:50:50 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:50 --> Input Class Initialized
INFO - 2023-02-17 09:50:50 --> Language Class Initialized
INFO - 2023-02-17 09:50:50 --> Loader Class Initialized
INFO - 2023-02-17 09:50:50 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:50 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:50 --> Total execution time: 0.0247
INFO - 2023-02-17 09:50:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:50 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:50 --> Total execution time: 0.0557
INFO - 2023-02-17 09:50:53 --> Config Class Initialized
INFO - 2023-02-17 09:50:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:53 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:53 --> URI Class Initialized
INFO - 2023-02-17 09:50:53 --> Router Class Initialized
INFO - 2023-02-17 09:50:53 --> Output Class Initialized
INFO - 2023-02-17 09:50:53 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:53 --> Input Class Initialized
INFO - 2023-02-17 09:50:53 --> Language Class Initialized
INFO - 2023-02-17 09:50:53 --> Loader Class Initialized
INFO - 2023-02-17 09:50:53 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:53 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:53 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:53 --> Model "Login_model" initialized
INFO - 2023-02-17 09:50:53 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:53 --> Total execution time: 0.0755
INFO - 2023-02-17 09:50:53 --> Config Class Initialized
INFO - 2023-02-17 09:50:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 09:50:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 09:50:53 --> Utf8 Class Initialized
INFO - 2023-02-17 09:50:53 --> URI Class Initialized
INFO - 2023-02-17 09:50:53 --> Router Class Initialized
INFO - 2023-02-17 09:50:53 --> Output Class Initialized
INFO - 2023-02-17 09:50:53 --> Security Class Initialized
DEBUG - 2023-02-17 09:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 09:50:53 --> Input Class Initialized
INFO - 2023-02-17 09:50:53 --> Language Class Initialized
INFO - 2023-02-17 09:50:53 --> Loader Class Initialized
INFO - 2023-02-17 09:50:53 --> Controller Class Initialized
DEBUG - 2023-02-17 09:50:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 09:50:53 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 09:50:53 --> Database Driver Class Initialized
INFO - 2023-02-17 09:50:53 --> Model "Login_model" initialized
INFO - 2023-02-17 09:50:53 --> Final output sent to browser
DEBUG - 2023-02-17 09:50:53 --> Total execution time: 0.0513
INFO - 2023-02-17 10:10:00 --> Config Class Initialized
INFO - 2023-02-17 10:10:00 --> Config Class Initialized
INFO - 2023-02-17 10:10:00 --> Hooks Class Initialized
INFO - 2023-02-17 10:10:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:00 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:10:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:00 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:00 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:00 --> URI Class Initialized
INFO - 2023-02-17 10:10:00 --> URI Class Initialized
INFO - 2023-02-17 10:10:00 --> Router Class Initialized
INFO - 2023-02-17 10:10:00 --> Router Class Initialized
INFO - 2023-02-17 10:10:00 --> Output Class Initialized
INFO - 2023-02-17 10:10:00 --> Output Class Initialized
INFO - 2023-02-17 10:10:00 --> Security Class Initialized
INFO - 2023-02-17 10:10:00 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:00 --> Input Class Initialized
INFO - 2023-02-17 10:10:00 --> Input Class Initialized
INFO - 2023-02-17 10:10:00 --> Language Class Initialized
INFO - 2023-02-17 10:10:00 --> Language Class Initialized
INFO - 2023-02-17 10:10:00 --> Loader Class Initialized
INFO - 2023-02-17 10:10:00 --> Loader Class Initialized
INFO - 2023-02-17 10:10:00 --> Controller Class Initialized
INFO - 2023-02-17 10:10:00 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:10:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:00 --> Final output sent to browser
INFO - 2023-02-17 10:10:00 --> Database Driver Class Initialized
DEBUG - 2023-02-17 10:10:00 --> Total execution time: 0.0043
INFO - 2023-02-17 10:10:00 --> Config Class Initialized
INFO - 2023-02-17 10:10:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:00 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:00 --> URI Class Initialized
INFO - 2023-02-17 10:10:00 --> Router Class Initialized
INFO - 2023-02-17 10:10:00 --> Output Class Initialized
INFO - 2023-02-17 10:10:00 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:00 --> Input Class Initialized
INFO - 2023-02-17 10:10:00 --> Language Class Initialized
INFO - 2023-02-17 10:10:00 --> Loader Class Initialized
INFO - 2023-02-17 10:10:00 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:00 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:00 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:00 --> Total execution time: 0.0494
INFO - 2023-02-17 10:10:00 --> Config Class Initialized
INFO - 2023-02-17 10:10:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:00 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:00 --> URI Class Initialized
INFO - 2023-02-17 10:10:00 --> Router Class Initialized
INFO - 2023-02-17 10:10:00 --> Output Class Initialized
INFO - 2023-02-17 10:10:00 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:00 --> Input Class Initialized
INFO - 2023-02-17 10:10:00 --> Language Class Initialized
INFO - 2023-02-17 10:10:00 --> Loader Class Initialized
INFO - 2023-02-17 10:10:00 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:00 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:00 --> Model "Login_model" initialized
INFO - 2023-02-17 10:10:00 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:00 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:00 --> Total execution time: 0.0152
INFO - 2023-02-17 10:10:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:00 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:00 --> Total execution time: 0.0668
INFO - 2023-02-17 10:10:02 --> Config Class Initialized
INFO - 2023-02-17 10:10:02 --> Config Class Initialized
INFO - 2023-02-17 10:10:02 --> Hooks Class Initialized
INFO - 2023-02-17 10:10:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:02 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:10:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:02 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:02 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:02 --> URI Class Initialized
INFO - 2023-02-17 10:10:02 --> URI Class Initialized
INFO - 2023-02-17 10:10:02 --> Router Class Initialized
INFO - 2023-02-17 10:10:02 --> Router Class Initialized
INFO - 2023-02-17 10:10:02 --> Output Class Initialized
INFO - 2023-02-17 10:10:02 --> Output Class Initialized
INFO - 2023-02-17 10:10:02 --> Security Class Initialized
INFO - 2023-02-17 10:10:02 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:02 --> Input Class Initialized
INFO - 2023-02-17 10:10:02 --> Input Class Initialized
INFO - 2023-02-17 10:10:02 --> Language Class Initialized
INFO - 2023-02-17 10:10:02 --> Language Class Initialized
INFO - 2023-02-17 10:10:02 --> Loader Class Initialized
INFO - 2023-02-17 10:10:02 --> Loader Class Initialized
INFO - 2023-02-17 10:10:02 --> Controller Class Initialized
INFO - 2023-02-17 10:10:02 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:10:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:02 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:02 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:02 --> Model "Login_model" initialized
INFO - 2023-02-17 10:10:02 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:02 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:02 --> Total execution time: 0.1019
INFO - 2023-02-17 10:10:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:02 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:02 --> Total execution time: 0.1088
INFO - 2023-02-17 10:10:06 --> Config Class Initialized
INFO - 2023-02-17 10:10:06 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:06 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:06 --> URI Class Initialized
INFO - 2023-02-17 10:10:06 --> Router Class Initialized
INFO - 2023-02-17 10:10:06 --> Output Class Initialized
INFO - 2023-02-17 10:10:06 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:06 --> Input Class Initialized
INFO - 2023-02-17 10:10:06 --> Language Class Initialized
INFO - 2023-02-17 10:10:06 --> Loader Class Initialized
INFO - 2023-02-17 10:10:06 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:06 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:06 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:06 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:06 --> Model "Login_model" initialized
INFO - 2023-02-17 10:10:06 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:06 --> Total execution time: 0.1232
INFO - 2023-02-17 10:10:06 --> Config Class Initialized
INFO - 2023-02-17 10:10:06 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:06 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:06 --> URI Class Initialized
INFO - 2023-02-17 10:10:06 --> Router Class Initialized
INFO - 2023-02-17 10:10:06 --> Output Class Initialized
INFO - 2023-02-17 10:10:06 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:06 --> Input Class Initialized
INFO - 2023-02-17 10:10:06 --> Language Class Initialized
INFO - 2023-02-17 10:10:06 --> Loader Class Initialized
INFO - 2023-02-17 10:10:06 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:06 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:06 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:06 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:06 --> Model "Login_model" initialized
INFO - 2023-02-17 10:10:06 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:06 --> Total execution time: 0.0520
INFO - 2023-02-17 10:10:09 --> Config Class Initialized
INFO - 2023-02-17 10:10:09 --> Config Class Initialized
INFO - 2023-02-17 10:10:09 --> Hooks Class Initialized
INFO - 2023-02-17 10:10:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:09 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:10:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:09 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:09 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:09 --> URI Class Initialized
INFO - 2023-02-17 10:10:09 --> URI Class Initialized
INFO - 2023-02-17 10:10:09 --> Router Class Initialized
INFO - 2023-02-17 10:10:09 --> Router Class Initialized
INFO - 2023-02-17 10:10:09 --> Output Class Initialized
INFO - 2023-02-17 10:10:09 --> Output Class Initialized
INFO - 2023-02-17 10:10:09 --> Security Class Initialized
INFO - 2023-02-17 10:10:09 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:09 --> Input Class Initialized
INFO - 2023-02-17 10:10:09 --> Input Class Initialized
INFO - 2023-02-17 10:10:09 --> Language Class Initialized
INFO - 2023-02-17 10:10:09 --> Language Class Initialized
INFO - 2023-02-17 10:10:09 --> Loader Class Initialized
INFO - 2023-02-17 10:10:09 --> Loader Class Initialized
INFO - 2023-02-17 10:10:09 --> Controller Class Initialized
INFO - 2023-02-17 10:10:09 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:10:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:09 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:09 --> Total execution time: 0.0042
INFO - 2023-02-17 10:10:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:09 --> Config Class Initialized
INFO - 2023-02-17 10:10:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:09 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:09 --> URI Class Initialized
INFO - 2023-02-17 10:10:09 --> Router Class Initialized
INFO - 2023-02-17 10:10:09 --> Output Class Initialized
INFO - 2023-02-17 10:10:09 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:09 --> Input Class Initialized
INFO - 2023-02-17 10:10:09 --> Language Class Initialized
INFO - 2023-02-17 10:10:09 --> Loader Class Initialized
INFO - 2023-02-17 10:10:09 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:09 --> Model "Login_model" initialized
INFO - 2023-02-17 10:10:09 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:09 --> Total execution time: 0.0175
INFO - 2023-02-17 10:10:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:09 --> Config Class Initialized
INFO - 2023-02-17 10:10:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:09 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:09 --> URI Class Initialized
INFO - 2023-02-17 10:10:09 --> Router Class Initialized
INFO - 2023-02-17 10:10:09 --> Output Class Initialized
INFO - 2023-02-17 10:10:09 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:09 --> Input Class Initialized
INFO - 2023-02-17 10:10:09 --> Language Class Initialized
INFO - 2023-02-17 10:10:09 --> Loader Class Initialized
INFO - 2023-02-17 10:10:09 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:09 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:09 --> Total execution time: 0.0202
INFO - 2023-02-17 10:10:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:09 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:09 --> Total execution time: 0.0544
INFO - 2023-02-17 10:10:12 --> Config Class Initialized
INFO - 2023-02-17 10:10:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:12 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:12 --> URI Class Initialized
INFO - 2023-02-17 10:10:12 --> Router Class Initialized
INFO - 2023-02-17 10:10:12 --> Output Class Initialized
INFO - 2023-02-17 10:10:12 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:12 --> Input Class Initialized
INFO - 2023-02-17 10:10:12 --> Language Class Initialized
INFO - 2023-02-17 10:10:12 --> Loader Class Initialized
INFO - 2023-02-17 10:10:12 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:12 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:12 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:12 --> Final output sent to browser
INFO - 2023-02-17 10:10:12 --> Config Class Initialized
INFO - 2023-02-17 10:10:12 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:12 --> Total execution time: 0.0407
DEBUG - 2023-02-17 10:10:12 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:12 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:12 --> URI Class Initialized
INFO - 2023-02-17 10:10:12 --> Router Class Initialized
INFO - 2023-02-17 10:10:12 --> Output Class Initialized
INFO - 2023-02-17 10:10:12 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:12 --> Input Class Initialized
INFO - 2023-02-17 10:10:12 --> Language Class Initialized
INFO - 2023-02-17 10:10:12 --> Loader Class Initialized
INFO - 2023-02-17 10:10:12 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:12 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:12 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:12 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:12 --> Total execution time: 0.0775
INFO - 2023-02-17 10:10:13 --> Config Class Initialized
INFO - 2023-02-17 10:10:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:13 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:13 --> URI Class Initialized
INFO - 2023-02-17 10:10:13 --> Router Class Initialized
INFO - 2023-02-17 10:10:13 --> Output Class Initialized
INFO - 2023-02-17 10:10:13 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:13 --> Input Class Initialized
INFO - 2023-02-17 10:10:13 --> Language Class Initialized
INFO - 2023-02-17 10:10:13 --> Loader Class Initialized
INFO - 2023-02-17 10:10:13 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:13 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:13 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:13 --> Total execution time: 0.0157
INFO - 2023-02-17 10:10:13 --> Config Class Initialized
INFO - 2023-02-17 10:10:13 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:13 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:13 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:13 --> URI Class Initialized
INFO - 2023-02-17 10:10:13 --> Router Class Initialized
INFO - 2023-02-17 10:10:13 --> Output Class Initialized
INFO - 2023-02-17 10:10:13 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:13 --> Input Class Initialized
INFO - 2023-02-17 10:10:13 --> Language Class Initialized
INFO - 2023-02-17 10:10:13 --> Loader Class Initialized
INFO - 2023-02-17 10:10:13 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:13 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:13 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:13 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:13 --> Total execution time: 0.0120
INFO - 2023-02-17 10:10:15 --> Config Class Initialized
INFO - 2023-02-17 10:10:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:15 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:15 --> URI Class Initialized
INFO - 2023-02-17 10:10:15 --> Router Class Initialized
INFO - 2023-02-17 10:10:15 --> Output Class Initialized
INFO - 2023-02-17 10:10:15 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:15 --> Input Class Initialized
INFO - 2023-02-17 10:10:15 --> Language Class Initialized
INFO - 2023-02-17 10:10:15 --> Loader Class Initialized
INFO - 2023-02-17 10:10:15 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:15 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:15 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:15 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:15 --> Model "Login_model" initialized
INFO - 2023-02-17 10:10:15 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:15 --> Total execution time: 0.0405
INFO - 2023-02-17 10:10:15 --> Config Class Initialized
INFO - 2023-02-17 10:10:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:10:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:10:15 --> Utf8 Class Initialized
INFO - 2023-02-17 10:10:15 --> URI Class Initialized
INFO - 2023-02-17 10:10:15 --> Router Class Initialized
INFO - 2023-02-17 10:10:15 --> Output Class Initialized
INFO - 2023-02-17 10:10:15 --> Security Class Initialized
DEBUG - 2023-02-17 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:10:15 --> Input Class Initialized
INFO - 2023-02-17 10:10:15 --> Language Class Initialized
INFO - 2023-02-17 10:10:15 --> Loader Class Initialized
INFO - 2023-02-17 10:10:15 --> Controller Class Initialized
DEBUG - 2023-02-17 10:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:10:15 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:15 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:10:15 --> Database Driver Class Initialized
INFO - 2023-02-17 10:10:15 --> Model "Login_model" initialized
INFO - 2023-02-17 10:10:15 --> Final output sent to browser
DEBUG - 2023-02-17 10:10:15 --> Total execution time: 0.0372
INFO - 2023-02-17 10:11:01 --> Config Class Initialized
INFO - 2023-02-17 10:11:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:01 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:01 --> URI Class Initialized
INFO - 2023-02-17 10:11:01 --> Router Class Initialized
INFO - 2023-02-17 10:11:01 --> Output Class Initialized
INFO - 2023-02-17 10:11:01 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:01 --> Input Class Initialized
INFO - 2023-02-17 10:11:01 --> Language Class Initialized
INFO - 2023-02-17 10:11:01 --> Loader Class Initialized
INFO - 2023-02-17 10:11:01 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:01 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:01 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:01 --> Total execution time: 0.0436
INFO - 2023-02-17 10:11:01 --> Config Class Initialized
INFO - 2023-02-17 10:11:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:01 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:01 --> URI Class Initialized
INFO - 2023-02-17 10:11:01 --> Router Class Initialized
INFO - 2023-02-17 10:11:01 --> Output Class Initialized
INFO - 2023-02-17 10:11:01 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:01 --> Input Class Initialized
INFO - 2023-02-17 10:11:01 --> Language Class Initialized
INFO - 2023-02-17 10:11:01 --> Loader Class Initialized
INFO - 2023-02-17 10:11:01 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:01 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:01 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:01 --> Total execution time: 0.0367
INFO - 2023-02-17 10:11:03 --> Config Class Initialized
INFO - 2023-02-17 10:11:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:03 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:03 --> URI Class Initialized
INFO - 2023-02-17 10:11:03 --> Router Class Initialized
INFO - 2023-02-17 10:11:03 --> Output Class Initialized
INFO - 2023-02-17 10:11:03 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:03 --> Input Class Initialized
INFO - 2023-02-17 10:11:03 --> Language Class Initialized
INFO - 2023-02-17 10:11:03 --> Loader Class Initialized
INFO - 2023-02-17 10:11:03 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:03 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:03 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:03 --> Total execution time: 0.0167
INFO - 2023-02-17 10:11:03 --> Config Class Initialized
INFO - 2023-02-17 10:11:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:03 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:03 --> URI Class Initialized
INFO - 2023-02-17 10:11:03 --> Router Class Initialized
INFO - 2023-02-17 10:11:03 --> Output Class Initialized
INFO - 2023-02-17 10:11:03 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:03 --> Input Class Initialized
INFO - 2023-02-17 10:11:03 --> Language Class Initialized
INFO - 2023-02-17 10:11:03 --> Loader Class Initialized
INFO - 2023-02-17 10:11:03 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:03 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:03 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:03 --> Total execution time: 0.0113
INFO - 2023-02-17 10:11:06 --> Config Class Initialized
INFO - 2023-02-17 10:11:06 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:06 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:06 --> URI Class Initialized
INFO - 2023-02-17 10:11:06 --> Router Class Initialized
INFO - 2023-02-17 10:11:06 --> Output Class Initialized
INFO - 2023-02-17 10:11:06 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:06 --> Input Class Initialized
INFO - 2023-02-17 10:11:06 --> Language Class Initialized
INFO - 2023-02-17 10:11:06 --> Loader Class Initialized
INFO - 2023-02-17 10:11:06 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:06 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:06 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:06 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:06 --> Total execution time: 0.0209
INFO - 2023-02-17 10:11:06 --> Config Class Initialized
INFO - 2023-02-17 10:11:06 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:06 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:06 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:06 --> URI Class Initialized
INFO - 2023-02-17 10:11:06 --> Router Class Initialized
INFO - 2023-02-17 10:11:06 --> Output Class Initialized
INFO - 2023-02-17 10:11:06 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:06 --> Input Class Initialized
INFO - 2023-02-17 10:11:06 --> Language Class Initialized
INFO - 2023-02-17 10:11:06 --> Loader Class Initialized
INFO - 2023-02-17 10:11:06 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:06 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:06 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:06 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:06 --> Total execution time: 0.0517
INFO - 2023-02-17 10:11:07 --> Config Class Initialized
INFO - 2023-02-17 10:11:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:07 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:07 --> URI Class Initialized
INFO - 2023-02-17 10:11:07 --> Router Class Initialized
INFO - 2023-02-17 10:11:07 --> Output Class Initialized
INFO - 2023-02-17 10:11:07 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:07 --> Input Class Initialized
INFO - 2023-02-17 10:11:07 --> Language Class Initialized
INFO - 2023-02-17 10:11:07 --> Loader Class Initialized
INFO - 2023-02-17 10:11:07 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:07 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:07 --> Total execution time: 0.0454
INFO - 2023-02-17 10:11:07 --> Config Class Initialized
INFO - 2023-02-17 10:11:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:08 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:08 --> URI Class Initialized
INFO - 2023-02-17 10:11:08 --> Router Class Initialized
INFO - 2023-02-17 10:11:08 --> Output Class Initialized
INFO - 2023-02-17 10:11:08 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:08 --> Input Class Initialized
INFO - 2023-02-17 10:11:08 --> Language Class Initialized
INFO - 2023-02-17 10:11:08 --> Loader Class Initialized
INFO - 2023-02-17 10:11:08 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:08 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:08 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:08 --> Total execution time: 0.0558
INFO - 2023-02-17 10:11:09 --> Config Class Initialized
INFO - 2023-02-17 10:11:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:09 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:09 --> URI Class Initialized
INFO - 2023-02-17 10:11:09 --> Router Class Initialized
INFO - 2023-02-17 10:11:09 --> Output Class Initialized
INFO - 2023-02-17 10:11:09 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:09 --> Input Class Initialized
INFO - 2023-02-17 10:11:09 --> Language Class Initialized
INFO - 2023-02-17 10:11:09 --> Loader Class Initialized
INFO - 2023-02-17 10:11:09 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:09 --> Model "Login_model" initialized
INFO - 2023-02-17 10:11:09 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:09 --> Total execution time: 0.0979
INFO - 2023-02-17 10:11:09 --> Config Class Initialized
INFO - 2023-02-17 10:11:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:09 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:09 --> URI Class Initialized
INFO - 2023-02-17 10:11:09 --> Router Class Initialized
INFO - 2023-02-17 10:11:09 --> Output Class Initialized
INFO - 2023-02-17 10:11:09 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:09 --> Input Class Initialized
INFO - 2023-02-17 10:11:09 --> Language Class Initialized
INFO - 2023-02-17 10:11:09 --> Loader Class Initialized
INFO - 2023-02-17 10:11:09 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:09 --> Model "Login_model" initialized
INFO - 2023-02-17 10:11:09 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:09 --> Total execution time: 0.0406
INFO - 2023-02-17 10:11:14 --> Config Class Initialized
INFO - 2023-02-17 10:11:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:14 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:14 --> URI Class Initialized
INFO - 2023-02-17 10:11:14 --> Router Class Initialized
INFO - 2023-02-17 10:11:14 --> Output Class Initialized
INFO - 2023-02-17 10:11:14 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:14 --> Input Class Initialized
INFO - 2023-02-17 10:11:14 --> Language Class Initialized
INFO - 2023-02-17 10:11:14 --> Loader Class Initialized
INFO - 2023-02-17 10:11:14 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:14 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:14 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:14 --> Total execution time: 0.0263
INFO - 2023-02-17 10:11:14 --> Config Class Initialized
INFO - 2023-02-17 10:11:14 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:14 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:14 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:14 --> URI Class Initialized
INFO - 2023-02-17 10:11:14 --> Router Class Initialized
INFO - 2023-02-17 10:11:14 --> Output Class Initialized
INFO - 2023-02-17 10:11:14 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:14 --> Input Class Initialized
INFO - 2023-02-17 10:11:14 --> Language Class Initialized
INFO - 2023-02-17 10:11:14 --> Loader Class Initialized
INFO - 2023-02-17 10:11:14 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:14 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:14 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:14 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:14 --> Total execution time: 0.0585
INFO - 2023-02-17 10:11:17 --> Config Class Initialized
INFO - 2023-02-17 10:11:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:17 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:17 --> URI Class Initialized
INFO - 2023-02-17 10:11:17 --> Router Class Initialized
INFO - 2023-02-17 10:11:17 --> Output Class Initialized
INFO - 2023-02-17 10:11:17 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:17 --> Input Class Initialized
INFO - 2023-02-17 10:11:17 --> Language Class Initialized
INFO - 2023-02-17 10:11:17 --> Loader Class Initialized
INFO - 2023-02-17 10:11:17 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:17 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:17 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:17 --> Total execution time: 0.0460
INFO - 2023-02-17 10:11:17 --> Config Class Initialized
INFO - 2023-02-17 10:11:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:17 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:17 --> URI Class Initialized
INFO - 2023-02-17 10:11:17 --> Router Class Initialized
INFO - 2023-02-17 10:11:17 --> Output Class Initialized
INFO - 2023-02-17 10:11:17 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:17 --> Input Class Initialized
INFO - 2023-02-17 10:11:17 --> Language Class Initialized
INFO - 2023-02-17 10:11:17 --> Loader Class Initialized
INFO - 2023-02-17 10:11:17 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:17 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:17 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:17 --> Total execution time: 0.0429
INFO - 2023-02-17 10:11:19 --> Config Class Initialized
INFO - 2023-02-17 10:11:19 --> Hooks Class Initialized
INFO - 2023-02-17 10:11:19 --> Config Class Initialized
DEBUG - 2023-02-17 10:11:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:19 --> Hooks Class Initialized
INFO - 2023-02-17 10:11:19 --> Utf8 Class Initialized
DEBUG - 2023-02-17 10:11:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:19 --> URI Class Initialized
INFO - 2023-02-17 10:11:19 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:19 --> Router Class Initialized
INFO - 2023-02-17 10:11:19 --> URI Class Initialized
INFO - 2023-02-17 10:11:19 --> Output Class Initialized
INFO - 2023-02-17 10:11:19 --> Router Class Initialized
INFO - 2023-02-17 10:11:19 --> Security Class Initialized
INFO - 2023-02-17 10:11:19 --> Output Class Initialized
DEBUG - 2023-02-17 10:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:19 --> Security Class Initialized
INFO - 2023-02-17 10:11:19 --> Input Class Initialized
DEBUG - 2023-02-17 10:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:19 --> Language Class Initialized
INFO - 2023-02-17 10:11:19 --> Input Class Initialized
INFO - 2023-02-17 10:11:19 --> Language Class Initialized
INFO - 2023-02-17 10:11:19 --> Loader Class Initialized
INFO - 2023-02-17 10:11:19 --> Loader Class Initialized
INFO - 2023-02-17 10:11:19 --> Controller Class Initialized
INFO - 2023-02-17 10:11:19 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:11:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:19 --> Final output sent to browser
INFO - 2023-02-17 10:11:19 --> Database Driver Class Initialized
DEBUG - 2023-02-17 10:11:19 --> Total execution time: 0.0043
INFO - 2023-02-17 10:11:19 --> Config Class Initialized
INFO - 2023-02-17 10:11:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:19 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:19 --> URI Class Initialized
INFO - 2023-02-17 10:11:19 --> Router Class Initialized
INFO - 2023-02-17 10:11:19 --> Output Class Initialized
INFO - 2023-02-17 10:11:19 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:19 --> Input Class Initialized
INFO - 2023-02-17 10:11:19 --> Language Class Initialized
INFO - 2023-02-17 10:11:19 --> Loader Class Initialized
INFO - 2023-02-17 10:11:19 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:19 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:19 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:19 --> Total execution time: 0.0161
INFO - 2023-02-17 10:11:19 --> Config Class Initialized
INFO - 2023-02-17 10:11:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:19 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:19 --> URI Class Initialized
INFO - 2023-02-17 10:11:19 --> Router Class Initialized
INFO - 2023-02-17 10:11:19 --> Output Class Initialized
INFO - 2023-02-17 10:11:19 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:19 --> Input Class Initialized
INFO - 2023-02-17 10:11:19 --> Language Class Initialized
INFO - 2023-02-17 10:11:19 --> Loader Class Initialized
INFO - 2023-02-17 10:11:19 --> Controller Class Initialized
INFO - 2023-02-17 10:11:19 --> Model "Login_model" initialized
DEBUG - 2023-02-17 10:11:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:19 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:19 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:19 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:19 --> Total execution time: 0.0217
INFO - 2023-02-17 10:11:19 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:19 --> Total execution time: 0.0118
INFO - 2023-02-17 10:11:21 --> Config Class Initialized
INFO - 2023-02-17 10:11:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:21 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:21 --> URI Class Initialized
INFO - 2023-02-17 10:11:21 --> Router Class Initialized
INFO - 2023-02-17 10:11:21 --> Output Class Initialized
INFO - 2023-02-17 10:11:21 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:21 --> Input Class Initialized
INFO - 2023-02-17 10:11:21 --> Language Class Initialized
INFO - 2023-02-17 10:11:21 --> Loader Class Initialized
INFO - 2023-02-17 10:11:21 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:21 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:21 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:21 --> Model "Login_model" initialized
INFO - 2023-02-17 10:11:21 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:21 --> Total execution time: 0.0442
INFO - 2023-02-17 10:11:21 --> Config Class Initialized
INFO - 2023-02-17 10:11:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:21 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:21 --> URI Class Initialized
INFO - 2023-02-17 10:11:21 --> Router Class Initialized
INFO - 2023-02-17 10:11:21 --> Output Class Initialized
INFO - 2023-02-17 10:11:21 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:21 --> Input Class Initialized
INFO - 2023-02-17 10:11:21 --> Language Class Initialized
INFO - 2023-02-17 10:11:21 --> Loader Class Initialized
INFO - 2023-02-17 10:11:21 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:21 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:21 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:21 --> Model "Login_model" initialized
INFO - 2023-02-17 10:11:21 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:21 --> Total execution time: 0.0424
INFO - 2023-02-17 10:11:24 --> Config Class Initialized
INFO - 2023-02-17 10:11:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:24 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:24 --> URI Class Initialized
INFO - 2023-02-17 10:11:24 --> Router Class Initialized
INFO - 2023-02-17 10:11:24 --> Output Class Initialized
INFO - 2023-02-17 10:11:24 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:24 --> Input Class Initialized
INFO - 2023-02-17 10:11:24 --> Language Class Initialized
INFO - 2023-02-17 10:11:24 --> Loader Class Initialized
INFO - 2023-02-17 10:11:24 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:24 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:24 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:24 --> Model "Login_model" initialized
INFO - 2023-02-17 10:11:24 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:24 --> Total execution time: 0.1216
INFO - 2023-02-17 10:11:26 --> Config Class Initialized
INFO - 2023-02-17 10:11:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:27 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:27 --> URI Class Initialized
INFO - 2023-02-17 10:11:27 --> Router Class Initialized
INFO - 2023-02-17 10:11:27 --> Output Class Initialized
INFO - 2023-02-17 10:11:27 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:27 --> Input Class Initialized
INFO - 2023-02-17 10:11:27 --> Language Class Initialized
INFO - 2023-02-17 10:11:27 --> Loader Class Initialized
INFO - 2023-02-17 10:11:27 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:27 --> Model "Login_model" initialized
INFO - 2023-02-17 10:11:27 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:27 --> Total execution time: 0.1227
INFO - 2023-02-17 10:11:27 --> Config Class Initialized
INFO - 2023-02-17 10:11:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:27 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:27 --> URI Class Initialized
INFO - 2023-02-17 10:11:27 --> Router Class Initialized
INFO - 2023-02-17 10:11:27 --> Output Class Initialized
INFO - 2023-02-17 10:11:27 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:27 --> Input Class Initialized
INFO - 2023-02-17 10:11:27 --> Language Class Initialized
INFO - 2023-02-17 10:11:27 --> Loader Class Initialized
INFO - 2023-02-17 10:11:27 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:27 --> Model "Login_model" initialized
INFO - 2023-02-17 10:11:27 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:27 --> Total execution time: 0.0456
INFO - 2023-02-17 10:11:30 --> Config Class Initialized
INFO - 2023-02-17 10:11:30 --> Config Class Initialized
INFO - 2023-02-17 10:11:30 --> Hooks Class Initialized
INFO - 2023-02-17 10:11:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:11:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:30 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:30 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:30 --> URI Class Initialized
INFO - 2023-02-17 10:11:30 --> URI Class Initialized
INFO - 2023-02-17 10:11:30 --> Router Class Initialized
INFO - 2023-02-17 10:11:30 --> Router Class Initialized
INFO - 2023-02-17 10:11:30 --> Output Class Initialized
INFO - 2023-02-17 10:11:30 --> Output Class Initialized
INFO - 2023-02-17 10:11:30 --> Security Class Initialized
INFO - 2023-02-17 10:11:30 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:30 --> Input Class Initialized
INFO - 2023-02-17 10:11:30 --> Input Class Initialized
INFO - 2023-02-17 10:11:30 --> Language Class Initialized
INFO - 2023-02-17 10:11:30 --> Language Class Initialized
INFO - 2023-02-17 10:11:30 --> Loader Class Initialized
INFO - 2023-02-17 10:11:30 --> Loader Class Initialized
INFO - 2023-02-17 10:11:30 --> Controller Class Initialized
INFO - 2023-02-17 10:11:30 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:11:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:30 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:30 --> Total execution time: 0.0040
INFO - 2023-02-17 10:11:30 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:30 --> Config Class Initialized
INFO - 2023-02-17 10:11:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:30 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:30 --> URI Class Initialized
INFO - 2023-02-17 10:11:30 --> Router Class Initialized
INFO - 2023-02-17 10:11:30 --> Output Class Initialized
INFO - 2023-02-17 10:11:30 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:30 --> Input Class Initialized
INFO - 2023-02-17 10:11:30 --> Language Class Initialized
INFO - 2023-02-17 10:11:30 --> Loader Class Initialized
INFO - 2023-02-17 10:11:30 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:30 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:30 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:30 --> Total execution time: 0.0150
INFO - 2023-02-17 10:11:30 --> Model "Login_model" initialized
INFO - 2023-02-17 10:11:30 --> Config Class Initialized
INFO - 2023-02-17 10:11:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:30 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:30 --> URI Class Initialized
INFO - 2023-02-17 10:11:30 --> Router Class Initialized
INFO - 2023-02-17 10:11:30 --> Output Class Initialized
INFO - 2023-02-17 10:11:30 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:30 --> Input Class Initialized
INFO - 2023-02-17 10:11:30 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:30 --> Language Class Initialized
INFO - 2023-02-17 10:11:30 --> Loader Class Initialized
INFO - 2023-02-17 10:11:30 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:30 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:30 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:30 --> Total execution time: 0.0226
INFO - 2023-02-17 10:11:30 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:30 --> Total execution time: 0.0147
INFO - 2023-02-17 10:11:36 --> Config Class Initialized
INFO - 2023-02-17 10:11:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:36 --> URI Class Initialized
INFO - 2023-02-17 10:11:36 --> Router Class Initialized
INFO - 2023-02-17 10:11:36 --> Output Class Initialized
INFO - 2023-02-17 10:11:36 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:36 --> Input Class Initialized
INFO - 2023-02-17 10:11:36 --> Language Class Initialized
INFO - 2023-02-17 10:11:36 --> Loader Class Initialized
INFO - 2023-02-17 10:11:36 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:36 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:36 --> Total execution time: 0.0422
INFO - 2023-02-17 10:11:36 --> Config Class Initialized
INFO - 2023-02-17 10:11:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:36 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:36 --> URI Class Initialized
INFO - 2023-02-17 10:11:36 --> Router Class Initialized
INFO - 2023-02-17 10:11:36 --> Output Class Initialized
INFO - 2023-02-17 10:11:36 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:36 --> Input Class Initialized
INFO - 2023-02-17 10:11:36 --> Language Class Initialized
INFO - 2023-02-17 10:11:36 --> Loader Class Initialized
INFO - 2023-02-17 10:11:36 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:36 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:36 --> Total execution time: 0.0396
INFO - 2023-02-17 10:11:40 --> Config Class Initialized
INFO - 2023-02-17 10:11:40 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:40 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:40 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:40 --> URI Class Initialized
INFO - 2023-02-17 10:11:40 --> Router Class Initialized
INFO - 2023-02-17 10:11:40 --> Output Class Initialized
INFO - 2023-02-17 10:11:40 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:40 --> Input Class Initialized
INFO - 2023-02-17 10:11:40 --> Language Class Initialized
INFO - 2023-02-17 10:11:40 --> Loader Class Initialized
INFO - 2023-02-17 10:11:40 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:40 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:40 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:40 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:40 --> Total execution time: 0.0161
INFO - 2023-02-17 10:11:40 --> Config Class Initialized
INFO - 2023-02-17 10:11:40 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:11:40 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:11:40 --> Utf8 Class Initialized
INFO - 2023-02-17 10:11:40 --> URI Class Initialized
INFO - 2023-02-17 10:11:40 --> Router Class Initialized
INFO - 2023-02-17 10:11:40 --> Output Class Initialized
INFO - 2023-02-17 10:11:40 --> Security Class Initialized
DEBUG - 2023-02-17 10:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:11:40 --> Input Class Initialized
INFO - 2023-02-17 10:11:40 --> Language Class Initialized
INFO - 2023-02-17 10:11:40 --> Loader Class Initialized
INFO - 2023-02-17 10:11:40 --> Controller Class Initialized
DEBUG - 2023-02-17 10:11:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:11:40 --> Database Driver Class Initialized
INFO - 2023-02-17 10:11:40 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:11:40 --> Final output sent to browser
DEBUG - 2023-02-17 10:11:40 --> Total execution time: 0.0121
INFO - 2023-02-17 10:12:50 --> Config Class Initialized
INFO - 2023-02-17 10:12:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:12:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:12:50 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:50 --> URI Class Initialized
INFO - 2023-02-17 10:12:50 --> Router Class Initialized
INFO - 2023-02-17 10:12:50 --> Output Class Initialized
INFO - 2023-02-17 10:12:50 --> Security Class Initialized
DEBUG - 2023-02-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:12:50 --> Input Class Initialized
INFO - 2023-02-17 10:12:50 --> Language Class Initialized
INFO - 2023-02-17 10:12:50 --> Loader Class Initialized
INFO - 2023-02-17 10:12:50 --> Controller Class Initialized
DEBUG - 2023-02-17 10:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:12:50 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:12:50 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:50 --> Total execution time: 0.0985
INFO - 2023-02-17 10:12:50 --> Config Class Initialized
INFO - 2023-02-17 10:12:50 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:12:50 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:12:50 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:50 --> URI Class Initialized
INFO - 2023-02-17 10:12:50 --> Router Class Initialized
INFO - 2023-02-17 10:12:50 --> Output Class Initialized
INFO - 2023-02-17 10:12:50 --> Security Class Initialized
DEBUG - 2023-02-17 10:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:12:50 --> Input Class Initialized
INFO - 2023-02-17 10:12:50 --> Language Class Initialized
INFO - 2023-02-17 10:12:50 --> Loader Class Initialized
INFO - 2023-02-17 10:12:50 --> Controller Class Initialized
DEBUG - 2023-02-17 10:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:12:50 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:50 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:12:50 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:50 --> Total execution time: 0.0126
INFO - 2023-02-17 10:12:55 --> Config Class Initialized
INFO - 2023-02-17 10:12:55 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:12:55 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:12:55 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:55 --> URI Class Initialized
INFO - 2023-02-17 10:12:55 --> Router Class Initialized
INFO - 2023-02-17 10:12:55 --> Output Class Initialized
INFO - 2023-02-17 10:12:55 --> Security Class Initialized
DEBUG - 2023-02-17 10:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:12:55 --> Input Class Initialized
INFO - 2023-02-17 10:12:55 --> Language Class Initialized
INFO - 2023-02-17 10:12:55 --> Loader Class Initialized
INFO - 2023-02-17 10:12:55 --> Controller Class Initialized
DEBUG - 2023-02-17 10:12:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:12:55 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:55 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:12:55 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:55 --> Model "Login_model" initialized
INFO - 2023-02-17 10:12:55 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:55 --> Total execution time: 0.0479
INFO - 2023-02-17 10:12:55 --> Config Class Initialized
INFO - 2023-02-17 10:12:55 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:12:55 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:12:55 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:55 --> URI Class Initialized
INFO - 2023-02-17 10:12:55 --> Router Class Initialized
INFO - 2023-02-17 10:12:55 --> Output Class Initialized
INFO - 2023-02-17 10:12:55 --> Security Class Initialized
DEBUG - 2023-02-17 10:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:12:55 --> Input Class Initialized
INFO - 2023-02-17 10:12:55 --> Language Class Initialized
INFO - 2023-02-17 10:12:55 --> Loader Class Initialized
INFO - 2023-02-17 10:12:55 --> Controller Class Initialized
DEBUG - 2023-02-17 10:12:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:12:55 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:55 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:12:55 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:55 --> Model "Login_model" initialized
INFO - 2023-02-17 10:12:55 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:55 --> Total execution time: 0.0397
INFO - 2023-02-17 10:12:57 --> Config Class Initialized
INFO - 2023-02-17 10:12:57 --> Config Class Initialized
INFO - 2023-02-17 10:12:57 --> Hooks Class Initialized
INFO - 2023-02-17 10:12:57 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:12:57 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:12:57 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:12:57 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:57 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:57 --> URI Class Initialized
INFO - 2023-02-17 10:12:57 --> URI Class Initialized
INFO - 2023-02-17 10:12:57 --> Router Class Initialized
INFO - 2023-02-17 10:12:57 --> Router Class Initialized
INFO - 2023-02-17 10:12:57 --> Output Class Initialized
INFO - 2023-02-17 10:12:57 --> Output Class Initialized
INFO - 2023-02-17 10:12:57 --> Security Class Initialized
INFO - 2023-02-17 10:12:57 --> Security Class Initialized
DEBUG - 2023-02-17 10:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:12:57 --> Input Class Initialized
INFO - 2023-02-17 10:12:57 --> Input Class Initialized
INFO - 2023-02-17 10:12:57 --> Language Class Initialized
INFO - 2023-02-17 10:12:57 --> Language Class Initialized
INFO - 2023-02-17 10:12:57 --> Loader Class Initialized
INFO - 2023-02-17 10:12:57 --> Loader Class Initialized
INFO - 2023-02-17 10:12:57 --> Controller Class Initialized
INFO - 2023-02-17 10:12:57 --> Controller Class Initialized
DEBUG - 2023-02-17 10:12:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:12:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:12:57 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:57 --> Total execution time: 0.0441
INFO - 2023-02-17 10:12:57 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:57 --> Config Class Initialized
INFO - 2023-02-17 10:12:57 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:12:57 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:12:57 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:12:57 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:57 --> URI Class Initialized
INFO - 2023-02-17 10:12:57 --> Router Class Initialized
INFO - 2023-02-17 10:12:57 --> Output Class Initialized
INFO - 2023-02-17 10:12:57 --> Security Class Initialized
DEBUG - 2023-02-17 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:12:57 --> Input Class Initialized
INFO - 2023-02-17 10:12:57 --> Language Class Initialized
INFO - 2023-02-17 10:12:57 --> Loader Class Initialized
INFO - 2023-02-17 10:12:57 --> Controller Class Initialized
DEBUG - 2023-02-17 10:12:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:12:57 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:57 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:57 --> Total execution time: 0.1010
INFO - 2023-02-17 10:12:57 --> Config Class Initialized
INFO - 2023-02-17 10:12:57 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:12:57 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:12:57 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:57 --> URI Class Initialized
INFO - 2023-02-17 10:12:57 --> Router Class Initialized
INFO - 2023-02-17 10:12:57 --> Output Class Initialized
INFO - 2023-02-17 10:12:57 --> Security Class Initialized
DEBUG - 2023-02-17 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:12:57 --> Input Class Initialized
INFO - 2023-02-17 10:12:57 --> Language Class Initialized
INFO - 2023-02-17 10:12:57 --> Loader Class Initialized
INFO - 2023-02-17 10:12:57 --> Model "Login_model" initialized
INFO - 2023-02-17 10:12:57 --> Controller Class Initialized
DEBUG - 2023-02-17 10:12:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:12:57 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:57 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:57 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:12:57 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:12:57 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:57 --> Total execution time: 0.0700
INFO - 2023-02-17 10:12:57 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:57 --> Total execution time: 0.0146
INFO - 2023-02-17 10:12:59 --> Config Class Initialized
INFO - 2023-02-17 10:12:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:12:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:12:59 --> Utf8 Class Initialized
INFO - 2023-02-17 10:12:59 --> URI Class Initialized
INFO - 2023-02-17 10:12:59 --> Router Class Initialized
INFO - 2023-02-17 10:12:59 --> Output Class Initialized
INFO - 2023-02-17 10:12:59 --> Security Class Initialized
DEBUG - 2023-02-17 10:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:12:59 --> Input Class Initialized
INFO - 2023-02-17 10:12:59 --> Language Class Initialized
INFO - 2023-02-17 10:12:59 --> Loader Class Initialized
INFO - 2023-02-17 10:12:59 --> Controller Class Initialized
DEBUG - 2023-02-17 10:12:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:12:59 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:12:59 --> Database Driver Class Initialized
INFO - 2023-02-17 10:12:59 --> Model "Login_model" initialized
INFO - 2023-02-17 10:12:59 --> Final output sent to browser
DEBUG - 2023-02-17 10:12:59 --> Total execution time: 0.0544
INFO - 2023-02-17 10:13:01 --> Config Class Initialized
INFO - 2023-02-17 10:13:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:01 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:01 --> URI Class Initialized
INFO - 2023-02-17 10:13:01 --> Router Class Initialized
INFO - 2023-02-17 10:13:01 --> Output Class Initialized
INFO - 2023-02-17 10:13:01 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:01 --> Input Class Initialized
INFO - 2023-02-17 10:13:01 --> Language Class Initialized
INFO - 2023-02-17 10:13:01 --> Loader Class Initialized
INFO - 2023-02-17 10:13:01 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:01 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:01 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:01 --> Total execution time: 0.0436
INFO - 2023-02-17 10:13:01 --> Config Class Initialized
INFO - 2023-02-17 10:13:01 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:01 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:01 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:01 --> URI Class Initialized
INFO - 2023-02-17 10:13:01 --> Router Class Initialized
INFO - 2023-02-17 10:13:01 --> Output Class Initialized
INFO - 2023-02-17 10:13:01 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:01 --> Input Class Initialized
INFO - 2023-02-17 10:13:01 --> Language Class Initialized
INFO - 2023-02-17 10:13:01 --> Loader Class Initialized
INFO - 2023-02-17 10:13:01 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:01 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:01 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:01 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:01 --> Total execution time: 0.0817
INFO - 2023-02-17 10:13:04 --> Config Class Initialized
INFO - 2023-02-17 10:13:04 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:04 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:04 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:04 --> URI Class Initialized
INFO - 2023-02-17 10:13:04 --> Router Class Initialized
INFO - 2023-02-17 10:13:04 --> Output Class Initialized
INFO - 2023-02-17 10:13:04 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:04 --> Input Class Initialized
INFO - 2023-02-17 10:13:04 --> Language Class Initialized
INFO - 2023-02-17 10:13:04 --> Loader Class Initialized
INFO - 2023-02-17 10:13:04 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:04 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:04 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:04 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:04 --> Total execution time: 0.0140
INFO - 2023-02-17 10:13:04 --> Config Class Initialized
INFO - 2023-02-17 10:13:04 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:04 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:04 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:04 --> URI Class Initialized
INFO - 2023-02-17 10:13:04 --> Router Class Initialized
INFO - 2023-02-17 10:13:04 --> Output Class Initialized
INFO - 2023-02-17 10:13:04 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:04 --> Input Class Initialized
INFO - 2023-02-17 10:13:04 --> Language Class Initialized
INFO - 2023-02-17 10:13:04 --> Loader Class Initialized
INFO - 2023-02-17 10:13:04 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:04 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:04 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:04 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:04 --> Total execution time: 0.0112
INFO - 2023-02-17 10:13:07 --> Config Class Initialized
INFO - 2023-02-17 10:13:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:07 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:07 --> URI Class Initialized
INFO - 2023-02-17 10:13:07 --> Router Class Initialized
INFO - 2023-02-17 10:13:07 --> Output Class Initialized
INFO - 2023-02-17 10:13:07 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:07 --> Input Class Initialized
INFO - 2023-02-17 10:13:07 --> Language Class Initialized
INFO - 2023-02-17 10:13:07 --> Loader Class Initialized
INFO - 2023-02-17 10:13:07 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:07 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:07 --> Total execution time: 0.0161
INFO - 2023-02-17 10:13:07 --> Config Class Initialized
INFO - 2023-02-17 10:13:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:07 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:07 --> URI Class Initialized
INFO - 2023-02-17 10:13:07 --> Router Class Initialized
INFO - 2023-02-17 10:13:07 --> Output Class Initialized
INFO - 2023-02-17 10:13:07 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:07 --> Input Class Initialized
INFO - 2023-02-17 10:13:07 --> Language Class Initialized
INFO - 2023-02-17 10:13:07 --> Loader Class Initialized
INFO - 2023-02-17 10:13:07 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:07 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:07 --> Total execution time: 0.0529
INFO - 2023-02-17 10:13:10 --> Config Class Initialized
INFO - 2023-02-17 10:13:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:10 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:10 --> URI Class Initialized
INFO - 2023-02-17 10:13:10 --> Router Class Initialized
INFO - 2023-02-17 10:13:10 --> Output Class Initialized
INFO - 2023-02-17 10:13:10 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:10 --> Input Class Initialized
INFO - 2023-02-17 10:13:10 --> Language Class Initialized
INFO - 2023-02-17 10:13:10 --> Loader Class Initialized
INFO - 2023-02-17 10:13:10 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:10 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:10 --> Total execution time: 0.0429
INFO - 2023-02-17 10:13:10 --> Config Class Initialized
INFO - 2023-02-17 10:13:10 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:10 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:10 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:10 --> URI Class Initialized
INFO - 2023-02-17 10:13:10 --> Router Class Initialized
INFO - 2023-02-17 10:13:10 --> Output Class Initialized
INFO - 2023-02-17 10:13:10 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:10 --> Input Class Initialized
INFO - 2023-02-17 10:13:10 --> Language Class Initialized
INFO - 2023-02-17 10:13:10 --> Loader Class Initialized
INFO - 2023-02-17 10:13:10 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:10 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:10 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:10 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:10 --> Total execution time: 0.0140
INFO - 2023-02-17 10:13:11 --> Config Class Initialized
INFO - 2023-02-17 10:13:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:11 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:11 --> URI Class Initialized
INFO - 2023-02-17 10:13:11 --> Router Class Initialized
INFO - 2023-02-17 10:13:11 --> Output Class Initialized
INFO - 2023-02-17 10:13:11 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:11 --> Input Class Initialized
INFO - 2023-02-17 10:13:11 --> Language Class Initialized
INFO - 2023-02-17 10:13:11 --> Loader Class Initialized
INFO - 2023-02-17 10:13:11 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:11 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:11 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:11 --> Total execution time: 0.0151
INFO - 2023-02-17 10:13:11 --> Config Class Initialized
INFO - 2023-02-17 10:13:11 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:11 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:11 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:11 --> URI Class Initialized
INFO - 2023-02-17 10:13:11 --> Router Class Initialized
INFO - 2023-02-17 10:13:11 --> Output Class Initialized
INFO - 2023-02-17 10:13:11 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:11 --> Input Class Initialized
INFO - 2023-02-17 10:13:11 --> Language Class Initialized
INFO - 2023-02-17 10:13:11 --> Loader Class Initialized
INFO - 2023-02-17 10:13:11 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:11 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:11 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:11 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:11 --> Total execution time: 0.0115
INFO - 2023-02-17 10:13:26 --> Config Class Initialized
INFO - 2023-02-17 10:13:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:26 --> URI Class Initialized
INFO - 2023-02-17 10:13:26 --> Router Class Initialized
INFO - 2023-02-17 10:13:26 --> Output Class Initialized
INFO - 2023-02-17 10:13:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:26 --> Input Class Initialized
INFO - 2023-02-17 10:13:26 --> Language Class Initialized
INFO - 2023-02-17 10:13:26 --> Loader Class Initialized
INFO - 2023-02-17 10:13:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:26 --> Total execution time: 0.0413
INFO - 2023-02-17 10:13:26 --> Config Class Initialized
INFO - 2023-02-17 10:13:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:26 --> URI Class Initialized
INFO - 2023-02-17 10:13:26 --> Router Class Initialized
INFO - 2023-02-17 10:13:26 --> Output Class Initialized
INFO - 2023-02-17 10:13:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:26 --> Input Class Initialized
INFO - 2023-02-17 10:13:26 --> Language Class Initialized
INFO - 2023-02-17 10:13:26 --> Loader Class Initialized
INFO - 2023-02-17 10:13:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:26 --> Total execution time: 0.0829
INFO - 2023-02-17 10:13:29 --> Config Class Initialized
INFO - 2023-02-17 10:13:29 --> Config Class Initialized
INFO - 2023-02-17 10:13:29 --> Hooks Class Initialized
INFO - 2023-02-17 10:13:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:29 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:13:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:29 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:29 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:29 --> URI Class Initialized
INFO - 2023-02-17 10:13:29 --> URI Class Initialized
INFO - 2023-02-17 10:13:29 --> Router Class Initialized
INFO - 2023-02-17 10:13:29 --> Router Class Initialized
INFO - 2023-02-17 10:13:29 --> Output Class Initialized
INFO - 2023-02-17 10:13:29 --> Output Class Initialized
INFO - 2023-02-17 10:13:29 --> Security Class Initialized
INFO - 2023-02-17 10:13:29 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:29 --> Input Class Initialized
INFO - 2023-02-17 10:13:29 --> Input Class Initialized
INFO - 2023-02-17 10:13:29 --> Language Class Initialized
INFO - 2023-02-17 10:13:29 --> Language Class Initialized
INFO - 2023-02-17 10:13:29 --> Loader Class Initialized
INFO - 2023-02-17 10:13:29 --> Loader Class Initialized
INFO - 2023-02-17 10:13:29 --> Controller Class Initialized
INFO - 2023-02-17 10:13:29 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:13:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:29 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:29 --> Total execution time: 0.0170
INFO - 2023-02-17 10:13:29 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:29 --> Config Class Initialized
INFO - 2023-02-17 10:13:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:29 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:29 --> URI Class Initialized
INFO - 2023-02-17 10:13:29 --> Router Class Initialized
INFO - 2023-02-17 10:13:29 --> Output Class Initialized
INFO - 2023-02-17 10:13:29 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:29 --> Input Class Initialized
INFO - 2023-02-17 10:13:29 --> Language Class Initialized
INFO - 2023-02-17 10:13:29 --> Loader Class Initialized
INFO - 2023-02-17 10:13:29 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:29 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:29 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:29 --> Total execution time: 0.0362
INFO - 2023-02-17 10:13:29 --> Model "Login_model" initialized
INFO - 2023-02-17 10:13:29 --> Config Class Initialized
INFO - 2023-02-17 10:13:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:29 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:29 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:29 --> URI Class Initialized
INFO - 2023-02-17 10:13:29 --> Router Class Initialized
INFO - 2023-02-17 10:13:29 --> Output Class Initialized
INFO - 2023-02-17 10:13:29 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:29 --> Input Class Initialized
INFO - 2023-02-17 10:13:29 --> Language Class Initialized
INFO - 2023-02-17 10:13:29 --> Loader Class Initialized
INFO - 2023-02-17 10:13:29 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:29 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:29 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:29 --> Total execution time: 0.0240
INFO - 2023-02-17 10:13:29 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:29 --> Total execution time: 0.0152
INFO - 2023-02-17 10:13:32 --> Config Class Initialized
INFO - 2023-02-17 10:13:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:32 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:32 --> URI Class Initialized
INFO - 2023-02-17 10:13:32 --> Router Class Initialized
INFO - 2023-02-17 10:13:32 --> Output Class Initialized
INFO - 2023-02-17 10:13:32 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:32 --> Input Class Initialized
INFO - 2023-02-17 10:13:32 --> Language Class Initialized
INFO - 2023-02-17 10:13:32 --> Loader Class Initialized
INFO - 2023-02-17 10:13:32 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:32 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:32 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:32 --> Model "Login_model" initialized
INFO - 2023-02-17 10:13:32 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:32 --> Total execution time: 0.0432
INFO - 2023-02-17 10:13:32 --> Config Class Initialized
INFO - 2023-02-17 10:13:32 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:13:32 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:13:32 --> Utf8 Class Initialized
INFO - 2023-02-17 10:13:32 --> URI Class Initialized
INFO - 2023-02-17 10:13:32 --> Router Class Initialized
INFO - 2023-02-17 10:13:32 --> Output Class Initialized
INFO - 2023-02-17 10:13:32 --> Security Class Initialized
DEBUG - 2023-02-17 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:13:32 --> Input Class Initialized
INFO - 2023-02-17 10:13:32 --> Language Class Initialized
INFO - 2023-02-17 10:13:32 --> Loader Class Initialized
INFO - 2023-02-17 10:13:32 --> Controller Class Initialized
DEBUG - 2023-02-17 10:13:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:13:32 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:32 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:13:32 --> Database Driver Class Initialized
INFO - 2023-02-17 10:13:32 --> Model "Login_model" initialized
INFO - 2023-02-17 10:13:32 --> Final output sent to browser
DEBUG - 2023-02-17 10:13:32 --> Total execution time: 0.0803
INFO - 2023-02-17 10:14:48 --> Config Class Initialized
INFO - 2023-02-17 10:14:48 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:14:48 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:14:48 --> Utf8 Class Initialized
INFO - 2023-02-17 10:14:48 --> URI Class Initialized
INFO - 2023-02-17 10:14:48 --> Router Class Initialized
INFO - 2023-02-17 10:14:48 --> Output Class Initialized
INFO - 2023-02-17 10:14:48 --> Security Class Initialized
DEBUG - 2023-02-17 10:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:14:48 --> Input Class Initialized
INFO - 2023-02-17 10:14:48 --> Language Class Initialized
INFO - 2023-02-17 10:14:48 --> Loader Class Initialized
INFO - 2023-02-17 10:14:48 --> Controller Class Initialized
DEBUG - 2023-02-17 10:14:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:14:48 --> Database Driver Class Initialized
INFO - 2023-02-17 10:14:48 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:14:48 --> Database Driver Class Initialized
INFO - 2023-02-17 10:14:48 --> Model "Login_model" initialized
INFO - 2023-02-17 10:14:48 --> Final output sent to browser
DEBUG - 2023-02-17 10:14:48 --> Total execution time: 0.1219
INFO - 2023-02-17 10:14:48 --> Config Class Initialized
INFO - 2023-02-17 10:14:48 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:14:48 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:14:48 --> Utf8 Class Initialized
INFO - 2023-02-17 10:14:48 --> URI Class Initialized
INFO - 2023-02-17 10:14:48 --> Router Class Initialized
INFO - 2023-02-17 10:14:48 --> Output Class Initialized
INFO - 2023-02-17 10:14:48 --> Security Class Initialized
DEBUG - 2023-02-17 10:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:14:48 --> Input Class Initialized
INFO - 2023-02-17 10:14:48 --> Language Class Initialized
INFO - 2023-02-17 10:14:48 --> Loader Class Initialized
INFO - 2023-02-17 10:14:48 --> Controller Class Initialized
DEBUG - 2023-02-17 10:14:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:14:48 --> Database Driver Class Initialized
INFO - 2023-02-17 10:14:48 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:14:48 --> Database Driver Class Initialized
INFO - 2023-02-17 10:14:48 --> Model "Login_model" initialized
INFO - 2023-02-17 10:14:48 --> Final output sent to browser
DEBUG - 2023-02-17 10:14:48 --> Total execution time: 0.0791
INFO - 2023-02-17 10:14:52 --> Config Class Initialized
INFO - 2023-02-17 10:14:52 --> Config Class Initialized
INFO - 2023-02-17 10:14:52 --> Hooks Class Initialized
INFO - 2023-02-17 10:14:52 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:14:52 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:14:52 --> Utf8 Class Initialized
DEBUG - 2023-02-17 10:14:52 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:14:52 --> URI Class Initialized
INFO - 2023-02-17 10:14:52 --> Utf8 Class Initialized
INFO - 2023-02-17 10:14:52 --> Router Class Initialized
INFO - 2023-02-17 10:14:52 --> URI Class Initialized
INFO - 2023-02-17 10:14:52 --> Output Class Initialized
INFO - 2023-02-17 10:14:52 --> Router Class Initialized
INFO - 2023-02-17 10:14:52 --> Security Class Initialized
INFO - 2023-02-17 10:14:52 --> Output Class Initialized
DEBUG - 2023-02-17 10:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:14:52 --> Security Class Initialized
INFO - 2023-02-17 10:14:52 --> Input Class Initialized
DEBUG - 2023-02-17 10:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:14:52 --> Language Class Initialized
INFO - 2023-02-17 10:14:52 --> Input Class Initialized
INFO - 2023-02-17 10:14:52 --> Language Class Initialized
INFO - 2023-02-17 10:14:52 --> Loader Class Initialized
INFO - 2023-02-17 10:14:52 --> Loader Class Initialized
INFO - 2023-02-17 10:14:52 --> Controller Class Initialized
INFO - 2023-02-17 10:14:52 --> Controller Class Initialized
DEBUG - 2023-02-17 10:14:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:14:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:14:52 --> Final output sent to browser
DEBUG - 2023-02-17 10:14:52 --> Total execution time: 0.0044
INFO - 2023-02-17 10:14:52 --> Database Driver Class Initialized
INFO - 2023-02-17 10:14:52 --> Config Class Initialized
INFO - 2023-02-17 10:14:52 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:14:52 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:14:52 --> Utf8 Class Initialized
INFO - 2023-02-17 10:14:52 --> URI Class Initialized
INFO - 2023-02-17 10:14:52 --> Router Class Initialized
INFO - 2023-02-17 10:14:52 --> Output Class Initialized
INFO - 2023-02-17 10:14:52 --> Security Class Initialized
DEBUG - 2023-02-17 10:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:14:52 --> Input Class Initialized
INFO - 2023-02-17 10:14:52 --> Language Class Initialized
INFO - 2023-02-17 10:14:52 --> Loader Class Initialized
INFO - 2023-02-17 10:14:52 --> Controller Class Initialized
DEBUG - 2023-02-17 10:14:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:14:52 --> Database Driver Class Initialized
INFO - 2023-02-17 10:14:52 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:14:52 --> Final output sent to browser
DEBUG - 2023-02-17 10:14:52 --> Total execution time: 0.0149
INFO - 2023-02-17 10:14:52 --> Config Class Initialized
INFO - 2023-02-17 10:14:52 --> Hooks Class Initialized
INFO - 2023-02-17 10:14:52 --> Model "Login_model" initialized
DEBUG - 2023-02-17 10:14:52 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:14:52 --> Utf8 Class Initialized
INFO - 2023-02-17 10:14:52 --> URI Class Initialized
INFO - 2023-02-17 10:14:52 --> Router Class Initialized
INFO - 2023-02-17 10:14:52 --> Output Class Initialized
INFO - 2023-02-17 10:14:52 --> Security Class Initialized
DEBUG - 2023-02-17 10:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:14:52 --> Input Class Initialized
INFO - 2023-02-17 10:14:52 --> Language Class Initialized
INFO - 2023-02-17 10:14:52 --> Loader Class Initialized
INFO - 2023-02-17 10:14:52 --> Controller Class Initialized
DEBUG - 2023-02-17 10:14:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:14:52 --> Database Driver Class Initialized
INFO - 2023-02-17 10:14:52 --> Database Driver Class Initialized
INFO - 2023-02-17 10:14:52 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:14:52 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:14:52 --> Final output sent to browser
DEBUG - 2023-02-17 10:14:52 --> Total execution time: 0.0215
INFO - 2023-02-17 10:14:52 --> Final output sent to browser
DEBUG - 2023-02-17 10:14:52 --> Total execution time: 0.0130
INFO - 2023-02-17 10:15:00 --> Config Class Initialized
INFO - 2023-02-17 10:15:00 --> Config Class Initialized
INFO - 2023-02-17 10:15:00 --> Hooks Class Initialized
INFO - 2023-02-17 10:15:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:00 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:15:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:00 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:00 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:00 --> URI Class Initialized
INFO - 2023-02-17 10:15:00 --> URI Class Initialized
INFO - 2023-02-17 10:15:00 --> Router Class Initialized
INFO - 2023-02-17 10:15:00 --> Router Class Initialized
INFO - 2023-02-17 10:15:00 --> Output Class Initialized
INFO - 2023-02-17 10:15:00 --> Output Class Initialized
INFO - 2023-02-17 10:15:00 --> Security Class Initialized
INFO - 2023-02-17 10:15:00 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:00 --> Input Class Initialized
INFO - 2023-02-17 10:15:00 --> Input Class Initialized
INFO - 2023-02-17 10:15:00 --> Language Class Initialized
INFO - 2023-02-17 10:15:00 --> Language Class Initialized
INFO - 2023-02-17 10:15:00 --> Loader Class Initialized
INFO - 2023-02-17 10:15:00 --> Loader Class Initialized
INFO - 2023-02-17 10:15:00 --> Controller Class Initialized
INFO - 2023-02-17 10:15:00 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:15:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:00 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:00 --> Total execution time: 0.0432
INFO - 2023-02-17 10:15:00 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:00 --> Config Class Initialized
INFO - 2023-02-17 10:15:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:00 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:00 --> URI Class Initialized
INFO - 2023-02-17 10:15:00 --> Router Class Initialized
INFO - 2023-02-17 10:15:00 --> Output Class Initialized
INFO - 2023-02-17 10:15:00 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:00 --> Input Class Initialized
INFO - 2023-02-17 10:15:00 --> Language Class Initialized
INFO - 2023-02-17 10:15:00 --> Loader Class Initialized
INFO - 2023-02-17 10:15:00 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:00 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:00 --> Model "Login_model" initialized
INFO - 2023-02-17 10:15:00 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:00 --> Total execution time: 0.0568
INFO - 2023-02-17 10:15:00 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:00 --> Config Class Initialized
INFO - 2023-02-17 10:15:00 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:00 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:00 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:00 --> URI Class Initialized
INFO - 2023-02-17 10:15:00 --> Router Class Initialized
INFO - 2023-02-17 10:15:00 --> Output Class Initialized
INFO - 2023-02-17 10:15:00 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:00 --> Input Class Initialized
INFO - 2023-02-17 10:15:00 --> Language Class Initialized
INFO - 2023-02-17 10:15:00 --> Loader Class Initialized
INFO - 2023-02-17 10:15:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:00 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:00 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:00 --> Total execution time: 0.0226
INFO - 2023-02-17 10:15:00 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:00 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:00 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:00 --> Total execution time: 0.0599
INFO - 2023-02-17 10:15:03 --> Config Class Initialized
INFO - 2023-02-17 10:15:03 --> Config Class Initialized
INFO - 2023-02-17 10:15:03 --> Hooks Class Initialized
INFO - 2023-02-17 10:15:03 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:03 --> Utf8 Class Initialized
DEBUG - 2023-02-17 10:15:03 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:03 --> URI Class Initialized
INFO - 2023-02-17 10:15:03 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:03 --> Router Class Initialized
INFO - 2023-02-17 10:15:03 --> URI Class Initialized
INFO - 2023-02-17 10:15:03 --> Output Class Initialized
INFO - 2023-02-17 10:15:03 --> Router Class Initialized
INFO - 2023-02-17 10:15:03 --> Security Class Initialized
INFO - 2023-02-17 10:15:03 --> Output Class Initialized
INFO - 2023-02-17 10:15:03 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:03 --> Input Class Initialized
INFO - 2023-02-17 10:15:03 --> Input Class Initialized
INFO - 2023-02-17 10:15:03 --> Language Class Initialized
INFO - 2023-02-17 10:15:03 --> Language Class Initialized
INFO - 2023-02-17 10:15:03 --> Loader Class Initialized
INFO - 2023-02-17 10:15:03 --> Loader Class Initialized
INFO - 2023-02-17 10:15:03 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:03 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:03 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:03 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:03 --> Model "Login_model" initialized
INFO - 2023-02-17 10:15:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:03 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:03 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:03 --> Total execution time: 0.1031
INFO - 2023-02-17 10:15:03 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:03 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:03 --> Total execution time: 0.1094
INFO - 2023-02-17 10:15:15 --> Config Class Initialized
INFO - 2023-02-17 10:15:15 --> Config Class Initialized
INFO - 2023-02-17 10:15:15 --> Hooks Class Initialized
INFO - 2023-02-17 10:15:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:15 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:15:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:15 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:15 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:15 --> URI Class Initialized
INFO - 2023-02-17 10:15:15 --> URI Class Initialized
INFO - 2023-02-17 10:15:15 --> Router Class Initialized
INFO - 2023-02-17 10:15:15 --> Router Class Initialized
INFO - 2023-02-17 10:15:15 --> Output Class Initialized
INFO - 2023-02-17 10:15:15 --> Output Class Initialized
INFO - 2023-02-17 10:15:15 --> Security Class Initialized
INFO - 2023-02-17 10:15:15 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:15 --> Input Class Initialized
INFO - 2023-02-17 10:15:15 --> Input Class Initialized
INFO - 2023-02-17 10:15:15 --> Language Class Initialized
INFO - 2023-02-17 10:15:15 --> Language Class Initialized
INFO - 2023-02-17 10:15:15 --> Loader Class Initialized
INFO - 2023-02-17 10:15:15 --> Loader Class Initialized
INFO - 2023-02-17 10:15:15 --> Controller Class Initialized
INFO - 2023-02-17 10:15:15 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:15:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:15 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:15 --> Total execution time: 0.0417
INFO - 2023-02-17 10:15:15 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:15 --> Config Class Initialized
INFO - 2023-02-17 10:15:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:15 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:15 --> URI Class Initialized
INFO - 2023-02-17 10:15:15 --> Router Class Initialized
INFO - 2023-02-17 10:15:15 --> Output Class Initialized
INFO - 2023-02-17 10:15:15 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:15 --> Input Class Initialized
INFO - 2023-02-17 10:15:15 --> Language Class Initialized
INFO - 2023-02-17 10:15:15 --> Loader Class Initialized
INFO - 2023-02-17 10:15:15 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:15 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:15 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:15 --> Final output sent to browser
INFO - 2023-02-17 10:15:15 --> Model "Login_model" initialized
DEBUG - 2023-02-17 10:15:15 --> Total execution time: 0.0542
INFO - 2023-02-17 10:15:15 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:15 --> Config Class Initialized
INFO - 2023-02-17 10:15:15 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:15 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:15 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:15 --> URI Class Initialized
INFO - 2023-02-17 10:15:15 --> Router Class Initialized
INFO - 2023-02-17 10:15:15 --> Output Class Initialized
INFO - 2023-02-17 10:15:15 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:15 --> Input Class Initialized
INFO - 2023-02-17 10:15:15 --> Language Class Initialized
INFO - 2023-02-17 10:15:15 --> Loader Class Initialized
INFO - 2023-02-17 10:15:15 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:15 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:15 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:15 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:15 --> Final output sent to browser
INFO - 2023-02-17 10:15:15 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:15 --> Total execution time: 0.1092
DEBUG - 2023-02-17 10:15:15 --> Total execution time: 0.1331
INFO - 2023-02-17 10:15:16 --> Config Class Initialized
INFO - 2023-02-17 10:15:16 --> Config Class Initialized
INFO - 2023-02-17 10:15:16 --> Hooks Class Initialized
INFO - 2023-02-17 10:15:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:16 --> Utf8 Class Initialized
DEBUG - 2023-02-17 10:15:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:16 --> URI Class Initialized
INFO - 2023-02-17 10:15:16 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:16 --> Router Class Initialized
INFO - 2023-02-17 10:15:16 --> URI Class Initialized
INFO - 2023-02-17 10:15:16 --> Output Class Initialized
INFO - 2023-02-17 10:15:16 --> Router Class Initialized
INFO - 2023-02-17 10:15:16 --> Security Class Initialized
INFO - 2023-02-17 10:15:16 --> Output Class Initialized
DEBUG - 2023-02-17 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:16 --> Security Class Initialized
INFO - 2023-02-17 10:15:16 --> Input Class Initialized
DEBUG - 2023-02-17 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:16 --> Language Class Initialized
INFO - 2023-02-17 10:15:16 --> Input Class Initialized
INFO - 2023-02-17 10:15:16 --> Loader Class Initialized
INFO - 2023-02-17 10:15:16 --> Language Class Initialized
INFO - 2023-02-17 10:15:16 --> Controller Class Initialized
INFO - 2023-02-17 10:15:16 --> Loader Class Initialized
DEBUG - 2023-02-17 10:15:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:16 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:16 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:16 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:16 --> Model "Login_model" initialized
INFO - 2023-02-17 10:15:16 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:16 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:16 --> Total execution time: 0.1030
INFO - 2023-02-17 10:15:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:16 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:16 --> Total execution time: 0.1105
INFO - 2023-02-17 10:15:21 --> Config Class Initialized
INFO - 2023-02-17 10:15:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:21 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:21 --> URI Class Initialized
INFO - 2023-02-17 10:15:21 --> Router Class Initialized
INFO - 2023-02-17 10:15:21 --> Output Class Initialized
INFO - 2023-02-17 10:15:21 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:21 --> Input Class Initialized
INFO - 2023-02-17 10:15:21 --> Language Class Initialized
INFO - 2023-02-17 10:15:21 --> Loader Class Initialized
INFO - 2023-02-17 10:15:21 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:21 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:21 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:21 --> Total execution time: 0.1281
INFO - 2023-02-17 10:15:21 --> Config Class Initialized
INFO - 2023-02-17 10:15:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:21 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:21 --> URI Class Initialized
INFO - 2023-02-17 10:15:21 --> Router Class Initialized
INFO - 2023-02-17 10:15:21 --> Output Class Initialized
INFO - 2023-02-17 10:15:21 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:21 --> Input Class Initialized
INFO - 2023-02-17 10:15:21 --> Language Class Initialized
INFO - 2023-02-17 10:15:21 --> Loader Class Initialized
INFO - 2023-02-17 10:15:21 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:21 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:21 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:21 --> Total execution time: 0.0796
INFO - 2023-02-17 10:15:23 --> Config Class Initialized
INFO - 2023-02-17 10:15:23 --> Config Class Initialized
INFO - 2023-02-17 10:15:23 --> Hooks Class Initialized
INFO - 2023-02-17 10:15:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:23 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:15:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:23 --> URI Class Initialized
INFO - 2023-02-17 10:15:23 --> URI Class Initialized
INFO - 2023-02-17 10:15:23 --> Router Class Initialized
INFO - 2023-02-17 10:15:23 --> Router Class Initialized
INFO - 2023-02-17 10:15:23 --> Output Class Initialized
INFO - 2023-02-17 10:15:23 --> Output Class Initialized
INFO - 2023-02-17 10:15:23 --> Security Class Initialized
INFO - 2023-02-17 10:15:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:23 --> Input Class Initialized
INFO - 2023-02-17 10:15:23 --> Input Class Initialized
INFO - 2023-02-17 10:15:23 --> Language Class Initialized
INFO - 2023-02-17 10:15:23 --> Language Class Initialized
INFO - 2023-02-17 10:15:23 --> Loader Class Initialized
INFO - 2023-02-17 10:15:23 --> Controller Class Initialized
INFO - 2023-02-17 10:15:23 --> Loader Class Initialized
DEBUG - 2023-02-17 10:15:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:23 --> Total execution time: 0.0048
INFO - 2023-02-17 10:15:23 --> Config Class Initialized
INFO - 2023-02-17 10:15:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:23 --> URI Class Initialized
INFO - 2023-02-17 10:15:23 --> Router Class Initialized
INFO - 2023-02-17 10:15:23 --> Output Class Initialized
INFO - 2023-02-17 10:15:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:23 --> Input Class Initialized
INFO - 2023-02-17 10:15:23 --> Language Class Initialized
INFO - 2023-02-17 10:15:23 --> Loader Class Initialized
INFO - 2023-02-17 10:15:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:23 --> Model "Login_model" initialized
INFO - 2023-02-17 10:15:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:23 --> Total execution time: 0.0193
INFO - 2023-02-17 10:15:23 --> Config Class Initialized
INFO - 2023-02-17 10:15:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:23 --> URI Class Initialized
INFO - 2023-02-17 10:15:23 --> Router Class Initialized
INFO - 2023-02-17 10:15:23 --> Output Class Initialized
INFO - 2023-02-17 10:15:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:23 --> Input Class Initialized
INFO - 2023-02-17 10:15:23 --> Language Class Initialized
INFO - 2023-02-17 10:15:23 --> Loader Class Initialized
INFO - 2023-02-17 10:15:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:23 --> Total execution time: 0.0228
INFO - 2023-02-17 10:15:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:23 --> Total execution time: 0.0117
INFO - 2023-02-17 10:15:24 --> Config Class Initialized
INFO - 2023-02-17 10:15:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:24 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:24 --> URI Class Initialized
INFO - 2023-02-17 10:15:24 --> Router Class Initialized
INFO - 2023-02-17 10:15:24 --> Output Class Initialized
INFO - 2023-02-17 10:15:24 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:24 --> Input Class Initialized
INFO - 2023-02-17 10:15:24 --> Language Class Initialized
INFO - 2023-02-17 10:15:24 --> Loader Class Initialized
INFO - 2023-02-17 10:15:24 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:24 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:24 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:24 --> Model "Login_model" initialized
INFO - 2023-02-17 10:15:24 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:24 --> Total execution time: 0.0436
INFO - 2023-02-17 10:15:24 --> Config Class Initialized
INFO - 2023-02-17 10:15:24 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:24 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:24 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:24 --> URI Class Initialized
INFO - 2023-02-17 10:15:24 --> Router Class Initialized
INFO - 2023-02-17 10:15:24 --> Output Class Initialized
INFO - 2023-02-17 10:15:24 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:24 --> Input Class Initialized
INFO - 2023-02-17 10:15:24 --> Language Class Initialized
INFO - 2023-02-17 10:15:24 --> Loader Class Initialized
INFO - 2023-02-17 10:15:24 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:24 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:24 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:24 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:24 --> Model "Login_model" initialized
INFO - 2023-02-17 10:15:24 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:24 --> Total execution time: 0.0781
INFO - 2023-02-17 10:15:26 --> Config Class Initialized
INFO - 2023-02-17 10:15:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:26 --> URI Class Initialized
INFO - 2023-02-17 10:15:26 --> Router Class Initialized
INFO - 2023-02-17 10:15:26 --> Output Class Initialized
INFO - 2023-02-17 10:15:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:26 --> Input Class Initialized
INFO - 2023-02-17 10:15:26 --> Language Class Initialized
INFO - 2023-02-17 10:15:26 --> Loader Class Initialized
INFO - 2023-02-17 10:15:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:26 --> Total execution time: 0.0141
INFO - 2023-02-17 10:15:26 --> Config Class Initialized
INFO - 2023-02-17 10:15:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:26 --> URI Class Initialized
INFO - 2023-02-17 10:15:26 --> Router Class Initialized
INFO - 2023-02-17 10:15:26 --> Output Class Initialized
INFO - 2023-02-17 10:15:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:26 --> Input Class Initialized
INFO - 2023-02-17 10:15:26 --> Language Class Initialized
INFO - 2023-02-17 10:15:26 --> Loader Class Initialized
INFO - 2023-02-17 10:15:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:26 --> Total execution time: 0.0493
INFO - 2023-02-17 10:15:27 --> Config Class Initialized
INFO - 2023-02-17 10:15:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:27 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:27 --> URI Class Initialized
INFO - 2023-02-17 10:15:27 --> Router Class Initialized
INFO - 2023-02-17 10:15:27 --> Output Class Initialized
INFO - 2023-02-17 10:15:27 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:27 --> Input Class Initialized
INFO - 2023-02-17 10:15:27 --> Language Class Initialized
INFO - 2023-02-17 10:15:27 --> Loader Class Initialized
INFO - 2023-02-17 10:15:27 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:27 --> Model "Login_model" initialized
INFO - 2023-02-17 10:15:27 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:27 --> Total execution time: 0.0461
INFO - 2023-02-17 10:15:46 --> Config Class Initialized
INFO - 2023-02-17 10:15:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:46 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:46 --> URI Class Initialized
INFO - 2023-02-17 10:15:46 --> Router Class Initialized
INFO - 2023-02-17 10:15:46 --> Output Class Initialized
INFO - 2023-02-17 10:15:46 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:46 --> Input Class Initialized
INFO - 2023-02-17 10:15:46 --> Language Class Initialized
INFO - 2023-02-17 10:15:46 --> Loader Class Initialized
INFO - 2023-02-17 10:15:46 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:46 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:46 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:46 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:46 --> Total execution time: 0.0178
INFO - 2023-02-17 10:15:46 --> Config Class Initialized
INFO - 2023-02-17 10:15:46 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:46 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:46 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:46 --> URI Class Initialized
INFO - 2023-02-17 10:15:46 --> Router Class Initialized
INFO - 2023-02-17 10:15:46 --> Output Class Initialized
INFO - 2023-02-17 10:15:46 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:46 --> Input Class Initialized
INFO - 2023-02-17 10:15:46 --> Language Class Initialized
INFO - 2023-02-17 10:15:46 --> Loader Class Initialized
INFO - 2023-02-17 10:15:46 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:46 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:46 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:46 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:46 --> Total execution time: 0.0570
INFO - 2023-02-17 10:15:49 --> Config Class Initialized
INFO - 2023-02-17 10:15:49 --> Config Class Initialized
INFO - 2023-02-17 10:15:49 --> Hooks Class Initialized
INFO - 2023-02-17 10:15:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:49 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:15:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:49 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:49 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:49 --> URI Class Initialized
INFO - 2023-02-17 10:15:49 --> URI Class Initialized
INFO - 2023-02-17 10:15:49 --> Router Class Initialized
INFO - 2023-02-17 10:15:49 --> Router Class Initialized
INFO - 2023-02-17 10:15:49 --> Output Class Initialized
INFO - 2023-02-17 10:15:49 --> Output Class Initialized
INFO - 2023-02-17 10:15:49 --> Security Class Initialized
INFO - 2023-02-17 10:15:49 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:49 --> Input Class Initialized
INFO - 2023-02-17 10:15:49 --> Input Class Initialized
INFO - 2023-02-17 10:15:49 --> Language Class Initialized
INFO - 2023-02-17 10:15:49 --> Language Class Initialized
INFO - 2023-02-17 10:15:49 --> Loader Class Initialized
INFO - 2023-02-17 10:15:49 --> Loader Class Initialized
INFO - 2023-02-17 10:15:49 --> Controller Class Initialized
INFO - 2023-02-17 10:15:49 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:15:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:49 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:49 --> Total execution time: 0.0043
INFO - 2023-02-17 10:15:49 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:49 --> Config Class Initialized
INFO - 2023-02-17 10:15:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:49 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:49 --> URI Class Initialized
INFO - 2023-02-17 10:15:49 --> Router Class Initialized
INFO - 2023-02-17 10:15:49 --> Output Class Initialized
INFO - 2023-02-17 10:15:49 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:49 --> Input Class Initialized
INFO - 2023-02-17 10:15:49 --> Language Class Initialized
INFO - 2023-02-17 10:15:49 --> Loader Class Initialized
INFO - 2023-02-17 10:15:49 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:49 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:49 --> Model "Login_model" initialized
INFO - 2023-02-17 10:15:49 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:49 --> Total execution time: 0.0183
INFO - 2023-02-17 10:15:49 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:49 --> Config Class Initialized
INFO - 2023-02-17 10:15:49 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:15:49 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:15:49 --> Utf8 Class Initialized
INFO - 2023-02-17 10:15:49 --> URI Class Initialized
INFO - 2023-02-17 10:15:49 --> Router Class Initialized
INFO - 2023-02-17 10:15:49 --> Output Class Initialized
INFO - 2023-02-17 10:15:49 --> Security Class Initialized
DEBUG - 2023-02-17 10:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:15:49 --> Input Class Initialized
INFO - 2023-02-17 10:15:49 --> Language Class Initialized
INFO - 2023-02-17 10:15:49 --> Loader Class Initialized
INFO - 2023-02-17 10:15:49 --> Controller Class Initialized
DEBUG - 2023-02-17 10:15:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:15:49 --> Database Driver Class Initialized
INFO - 2023-02-17 10:15:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:49 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:15:49 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:49 --> Total execution time: 0.0268
INFO - 2023-02-17 10:15:49 --> Final output sent to browser
DEBUG - 2023-02-17 10:15:49 --> Total execution time: 0.0171
INFO - 2023-02-17 10:18:20 --> Config Class Initialized
INFO - 2023-02-17 10:18:20 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:18:20 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:18:20 --> Utf8 Class Initialized
INFO - 2023-02-17 10:18:20 --> URI Class Initialized
INFO - 2023-02-17 10:18:20 --> Router Class Initialized
INFO - 2023-02-17 10:18:20 --> Output Class Initialized
INFO - 2023-02-17 10:18:20 --> Security Class Initialized
DEBUG - 2023-02-17 10:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:18:20 --> Input Class Initialized
INFO - 2023-02-17 10:18:20 --> Language Class Initialized
INFO - 2023-02-17 10:18:20 --> Loader Class Initialized
INFO - 2023-02-17 10:18:20 --> Controller Class Initialized
DEBUG - 2023-02-17 10:18:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:18:20 --> Database Driver Class Initialized
INFO - 2023-02-17 10:18:22 --> Config Class Initialized
INFO - 2023-02-17 10:18:22 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:18:22 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:18:22 --> Utf8 Class Initialized
INFO - 2023-02-17 10:18:22 --> URI Class Initialized
INFO - 2023-02-17 10:18:22 --> Router Class Initialized
INFO - 2023-02-17 10:18:22 --> Output Class Initialized
INFO - 2023-02-17 10:18:22 --> Security Class Initialized
DEBUG - 2023-02-17 10:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:18:22 --> Input Class Initialized
INFO - 2023-02-17 10:18:22 --> Language Class Initialized
INFO - 2023-02-17 10:18:22 --> Loader Class Initialized
INFO - 2023-02-17 10:18:22 --> Controller Class Initialized
DEBUG - 2023-02-17 10:18:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:18:22 --> Database Driver Class Initialized
ERROR - 2023-02-17 10:18:30 --> Unable to connect to the database
INFO - 2023-02-17 10:18:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-02-17 10:18:32 --> Unable to connect to the database
INFO - 2023-02-17 10:18:32 --> Language file loaded: language/english/db_lang.php
INFO - 2023-02-17 10:21:23 --> Config Class Initialized
INFO - 2023-02-17 10:21:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:23 --> URI Class Initialized
INFO - 2023-02-17 10:21:23 --> Router Class Initialized
INFO - 2023-02-17 10:21:23 --> Output Class Initialized
INFO - 2023-02-17 10:21:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:23 --> Input Class Initialized
INFO - 2023-02-17 10:21:23 --> Language Class Initialized
INFO - 2023-02-17 10:21:23 --> Loader Class Initialized
INFO - 2023-02-17 10:21:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:23 --> Total execution time: 0.1022
INFO - 2023-02-17 10:21:23 --> Config Class Initialized
INFO - 2023-02-17 10:21:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:23 --> URI Class Initialized
INFO - 2023-02-17 10:21:23 --> Router Class Initialized
INFO - 2023-02-17 10:21:23 --> Output Class Initialized
INFO - 2023-02-17 10:21:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:23 --> Input Class Initialized
INFO - 2023-02-17 10:21:23 --> Language Class Initialized
INFO - 2023-02-17 10:21:23 --> Loader Class Initialized
INFO - 2023-02-17 10:21:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:23 --> Total execution time: 0.0134
INFO - 2023-02-17 10:21:26 --> Config Class Initialized
INFO - 2023-02-17 10:21:26 --> Config Class Initialized
INFO - 2023-02-17 10:21:26 --> Hooks Class Initialized
INFO - 2023-02-17 10:21:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:26 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:21:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:26 --> URI Class Initialized
INFO - 2023-02-17 10:21:26 --> URI Class Initialized
INFO - 2023-02-17 10:21:26 --> Router Class Initialized
INFO - 2023-02-17 10:21:26 --> Router Class Initialized
INFO - 2023-02-17 10:21:26 --> Output Class Initialized
INFO - 2023-02-17 10:21:26 --> Output Class Initialized
INFO - 2023-02-17 10:21:26 --> Security Class Initialized
INFO - 2023-02-17 10:21:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:26 --> Input Class Initialized
INFO - 2023-02-17 10:21:26 --> Input Class Initialized
INFO - 2023-02-17 10:21:26 --> Language Class Initialized
INFO - 2023-02-17 10:21:26 --> Language Class Initialized
INFO - 2023-02-17 10:21:26 --> Loader Class Initialized
INFO - 2023-02-17 10:21:26 --> Loader Class Initialized
INFO - 2023-02-17 10:21:26 --> Controller Class Initialized
INFO - 2023-02-17 10:21:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:26 --> Total execution time: 0.0048
INFO - 2023-02-17 10:21:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:26 --> Config Class Initialized
INFO - 2023-02-17 10:21:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:26 --> URI Class Initialized
INFO - 2023-02-17 10:21:26 --> Router Class Initialized
INFO - 2023-02-17 10:21:26 --> Output Class Initialized
INFO - 2023-02-17 10:21:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:26 --> Input Class Initialized
INFO - 2023-02-17 10:21:26 --> Language Class Initialized
INFO - 2023-02-17 10:21:26 --> Loader Class Initialized
INFO - 2023-02-17 10:21:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:26 --> Model "Login_model" initialized
INFO - 2023-02-17 10:21:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:26 --> Total execution time: 0.0213
INFO - 2023-02-17 10:21:26 --> Config Class Initialized
INFO - 2023-02-17 10:21:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:26 --> URI Class Initialized
INFO - 2023-02-17 10:21:26 --> Router Class Initialized
INFO - 2023-02-17 10:21:26 --> Output Class Initialized
INFO - 2023-02-17 10:21:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:26 --> Input Class Initialized
INFO - 2023-02-17 10:21:26 --> Language Class Initialized
INFO - 2023-02-17 10:21:26 --> Loader Class Initialized
INFO - 2023-02-17 10:21:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:26 --> Total execution time: 0.0228
INFO - 2023-02-17 10:21:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:26 --> Total execution time: 0.0543
INFO - 2023-02-17 10:21:28 --> Config Class Initialized
INFO - 2023-02-17 10:21:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:28 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:28 --> URI Class Initialized
INFO - 2023-02-17 10:21:28 --> Router Class Initialized
INFO - 2023-02-17 10:21:28 --> Output Class Initialized
INFO - 2023-02-17 10:21:28 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:28 --> Input Class Initialized
INFO - 2023-02-17 10:21:28 --> Language Class Initialized
INFO - 2023-02-17 10:21:28 --> Loader Class Initialized
INFO - 2023-02-17 10:21:28 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:28 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:28 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:28 --> Total execution time: 0.0434
INFO - 2023-02-17 10:21:28 --> Config Class Initialized
INFO - 2023-02-17 10:21:28 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:28 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:28 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:28 --> URI Class Initialized
INFO - 2023-02-17 10:21:28 --> Router Class Initialized
INFO - 2023-02-17 10:21:28 --> Output Class Initialized
INFO - 2023-02-17 10:21:28 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:28 --> Input Class Initialized
INFO - 2023-02-17 10:21:28 --> Language Class Initialized
INFO - 2023-02-17 10:21:28 --> Loader Class Initialized
INFO - 2023-02-17 10:21:28 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:28 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:28 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:28 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:28 --> Total execution time: 0.0848
INFO - 2023-02-17 10:21:30 --> Config Class Initialized
INFO - 2023-02-17 10:21:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:30 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:30 --> URI Class Initialized
INFO - 2023-02-17 10:21:30 --> Router Class Initialized
INFO - 2023-02-17 10:21:30 --> Output Class Initialized
INFO - 2023-02-17 10:21:30 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:30 --> Input Class Initialized
INFO - 2023-02-17 10:21:30 --> Language Class Initialized
INFO - 2023-02-17 10:21:30 --> Loader Class Initialized
INFO - 2023-02-17 10:21:30 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:30 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:30 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:30 --> Total execution time: 0.0154
INFO - 2023-02-17 10:21:30 --> Config Class Initialized
INFO - 2023-02-17 10:21:30 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:21:30 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:21:30 --> Utf8 Class Initialized
INFO - 2023-02-17 10:21:30 --> URI Class Initialized
INFO - 2023-02-17 10:21:30 --> Router Class Initialized
INFO - 2023-02-17 10:21:30 --> Output Class Initialized
INFO - 2023-02-17 10:21:30 --> Security Class Initialized
DEBUG - 2023-02-17 10:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:21:30 --> Input Class Initialized
INFO - 2023-02-17 10:21:30 --> Language Class Initialized
INFO - 2023-02-17 10:21:30 --> Loader Class Initialized
INFO - 2023-02-17 10:21:30 --> Controller Class Initialized
DEBUG - 2023-02-17 10:21:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:21:30 --> Database Driver Class Initialized
INFO - 2023-02-17 10:21:30 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:21:30 --> Final output sent to browser
DEBUG - 2023-02-17 10:21:30 --> Total execution time: 0.0103
INFO - 2023-02-17 10:25:25 --> Config Class Initialized
INFO - 2023-02-17 10:25:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:25 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:25 --> URI Class Initialized
INFO - 2023-02-17 10:25:25 --> Router Class Initialized
INFO - 2023-02-17 10:25:25 --> Output Class Initialized
INFO - 2023-02-17 10:25:25 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:25 --> Input Class Initialized
INFO - 2023-02-17 10:25:25 --> Language Class Initialized
INFO - 2023-02-17 10:25:25 --> Loader Class Initialized
INFO - 2023-02-17 10:25:25 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:25 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:25 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:25 --> Total execution time: 0.0468
INFO - 2023-02-17 10:25:25 --> Config Class Initialized
INFO - 2023-02-17 10:25:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:25 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:25 --> URI Class Initialized
INFO - 2023-02-17 10:25:25 --> Router Class Initialized
INFO - 2023-02-17 10:25:25 --> Output Class Initialized
INFO - 2023-02-17 10:25:25 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:25 --> Input Class Initialized
INFO - 2023-02-17 10:25:25 --> Language Class Initialized
INFO - 2023-02-17 10:25:25 --> Loader Class Initialized
INFO - 2023-02-17 10:25:25 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:25 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:25 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:25 --> Total execution time: 0.0414
INFO - 2023-02-17 10:25:27 --> Config Class Initialized
INFO - 2023-02-17 10:25:27 --> Config Class Initialized
INFO - 2023-02-17 10:25:27 --> Hooks Class Initialized
INFO - 2023-02-17 10:25:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:27 --> Utf8 Class Initialized
DEBUG - 2023-02-17 10:25:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:27 --> URI Class Initialized
INFO - 2023-02-17 10:25:27 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:27 --> Router Class Initialized
INFO - 2023-02-17 10:25:27 --> URI Class Initialized
INFO - 2023-02-17 10:25:27 --> Output Class Initialized
INFO - 2023-02-17 10:25:27 --> Router Class Initialized
INFO - 2023-02-17 10:25:27 --> Security Class Initialized
INFO - 2023-02-17 10:25:27 --> Output Class Initialized
DEBUG - 2023-02-17 10:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:27 --> Security Class Initialized
INFO - 2023-02-17 10:25:27 --> Input Class Initialized
DEBUG - 2023-02-17 10:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:27 --> Language Class Initialized
INFO - 2023-02-17 10:25:27 --> Input Class Initialized
INFO - 2023-02-17 10:25:27 --> Language Class Initialized
INFO - 2023-02-17 10:25:27 --> Loader Class Initialized
INFO - 2023-02-17 10:25:27 --> Controller Class Initialized
INFO - 2023-02-17 10:25:27 --> Loader Class Initialized
DEBUG - 2023-02-17 10:25:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:27 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:27 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:27 --> Total execution time: 0.0200
INFO - 2023-02-17 10:25:27 --> Config Class Initialized
INFO - 2023-02-17 10:25:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:27 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:27 --> URI Class Initialized
INFO - 2023-02-17 10:25:27 --> Router Class Initialized
INFO - 2023-02-17 10:25:27 --> Output Class Initialized
INFO - 2023-02-17 10:25:27 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:27 --> Input Class Initialized
INFO - 2023-02-17 10:25:27 --> Language Class Initialized
INFO - 2023-02-17 10:25:27 --> Loader Class Initialized
INFO - 2023-02-17 10:25:27 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:27 --> Model "Login_model" initialized
INFO - 2023-02-17 10:25:27 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:27 --> Total execution time: 0.0319
INFO - 2023-02-17 10:25:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:27 --> Config Class Initialized
INFO - 2023-02-17 10:25:27 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:27 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:27 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:27 --> URI Class Initialized
INFO - 2023-02-17 10:25:27 --> Router Class Initialized
INFO - 2023-02-17 10:25:27 --> Output Class Initialized
INFO - 2023-02-17 10:25:27 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:27 --> Input Class Initialized
INFO - 2023-02-17 10:25:27 --> Language Class Initialized
INFO - 2023-02-17 10:25:27 --> Loader Class Initialized
INFO - 2023-02-17 10:25:27 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:27 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:27 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:27 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:27 --> Total execution time: 0.0215
INFO - 2023-02-17 10:25:27 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:28 --> Total execution time: 0.0145
INFO - 2023-02-17 10:25:31 --> Config Class Initialized
INFO - 2023-02-17 10:25:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:31 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:31 --> URI Class Initialized
INFO - 2023-02-17 10:25:31 --> Router Class Initialized
INFO - 2023-02-17 10:25:31 --> Output Class Initialized
INFO - 2023-02-17 10:25:31 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:31 --> Input Class Initialized
INFO - 2023-02-17 10:25:31 --> Language Class Initialized
INFO - 2023-02-17 10:25:31 --> Loader Class Initialized
INFO - 2023-02-17 10:25:31 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:31 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:31 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:31 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:31 --> Model "Login_model" initialized
INFO - 2023-02-17 10:25:31 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:31 --> Total execution time: 0.0507
INFO - 2023-02-17 10:25:31 --> Config Class Initialized
INFO - 2023-02-17 10:25:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:31 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:31 --> URI Class Initialized
INFO - 2023-02-17 10:25:31 --> Router Class Initialized
INFO - 2023-02-17 10:25:31 --> Output Class Initialized
INFO - 2023-02-17 10:25:31 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:31 --> Input Class Initialized
INFO - 2023-02-17 10:25:31 --> Language Class Initialized
INFO - 2023-02-17 10:25:31 --> Loader Class Initialized
INFO - 2023-02-17 10:25:31 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:31 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:31 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:31 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:31 --> Model "Login_model" initialized
INFO - 2023-02-17 10:25:31 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:31 --> Total execution time: 0.0810
INFO - 2023-02-17 10:25:34 --> Config Class Initialized
INFO - 2023-02-17 10:25:34 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:34 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:34 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:34 --> URI Class Initialized
INFO - 2023-02-17 10:25:34 --> Router Class Initialized
INFO - 2023-02-17 10:25:34 --> Output Class Initialized
INFO - 2023-02-17 10:25:34 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:34 --> Input Class Initialized
INFO - 2023-02-17 10:25:34 --> Language Class Initialized
INFO - 2023-02-17 10:25:34 --> Loader Class Initialized
INFO - 2023-02-17 10:25:34 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:34 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:35 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:35 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:35 --> Total execution time: 0.0147
INFO - 2023-02-17 10:25:35 --> Config Class Initialized
INFO - 2023-02-17 10:25:35 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:35 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:35 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:35 --> URI Class Initialized
INFO - 2023-02-17 10:25:35 --> Router Class Initialized
INFO - 2023-02-17 10:25:35 --> Output Class Initialized
INFO - 2023-02-17 10:25:35 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:35 --> Input Class Initialized
INFO - 2023-02-17 10:25:35 --> Language Class Initialized
INFO - 2023-02-17 10:25:35 --> Loader Class Initialized
INFO - 2023-02-17 10:25:35 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:35 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:35 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:35 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:35 --> Total execution time: 0.0122
INFO - 2023-02-17 10:25:36 --> Config Class Initialized
INFO - 2023-02-17 10:25:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:36 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:36 --> URI Class Initialized
INFO - 2023-02-17 10:25:36 --> Router Class Initialized
INFO - 2023-02-17 10:25:36 --> Output Class Initialized
INFO - 2023-02-17 10:25:36 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:36 --> Input Class Initialized
INFO - 2023-02-17 10:25:36 --> Language Class Initialized
INFO - 2023-02-17 10:25:36 --> Loader Class Initialized
INFO - 2023-02-17 10:25:36 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:36 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:36 --> Total execution time: 0.0755
INFO - 2023-02-17 10:25:36 --> Config Class Initialized
INFO - 2023-02-17 10:25:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:25:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:25:36 --> Utf8 Class Initialized
INFO - 2023-02-17 10:25:36 --> URI Class Initialized
INFO - 2023-02-17 10:25:36 --> Router Class Initialized
INFO - 2023-02-17 10:25:36 --> Output Class Initialized
INFO - 2023-02-17 10:25:36 --> Security Class Initialized
DEBUG - 2023-02-17 10:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:25:36 --> Input Class Initialized
INFO - 2023-02-17 10:25:36 --> Language Class Initialized
INFO - 2023-02-17 10:25:36 --> Loader Class Initialized
INFO - 2023-02-17 10:25:36 --> Controller Class Initialized
DEBUG - 2023-02-17 10:25:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:25:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:25:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:25:36 --> Final output sent to browser
DEBUG - 2023-02-17 10:25:36 --> Total execution time: 0.0147
INFO - 2023-02-17 10:26:18 --> Config Class Initialized
INFO - 2023-02-17 10:26:18 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:26:18 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:26:18 --> Utf8 Class Initialized
INFO - 2023-02-17 10:26:18 --> URI Class Initialized
INFO - 2023-02-17 10:26:18 --> Router Class Initialized
INFO - 2023-02-17 10:26:18 --> Output Class Initialized
INFO - 2023-02-17 10:26:18 --> Security Class Initialized
DEBUG - 2023-02-17 10:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:26:18 --> Input Class Initialized
INFO - 2023-02-17 10:26:18 --> Language Class Initialized
INFO - 2023-02-17 10:26:18 --> Loader Class Initialized
INFO - 2023-02-17 10:26:18 --> Controller Class Initialized
DEBUG - 2023-02-17 10:26:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:26:18 --> Database Driver Class Initialized
INFO - 2023-02-17 10:26:18 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:26:18 --> Final output sent to browser
DEBUG - 2023-02-17 10:26:18 --> Total execution time: 0.0155
INFO - 2023-02-17 10:26:18 --> Config Class Initialized
INFO - 2023-02-17 10:26:18 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:26:18 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:26:18 --> Utf8 Class Initialized
INFO - 2023-02-17 10:26:18 --> URI Class Initialized
INFO - 2023-02-17 10:26:18 --> Router Class Initialized
INFO - 2023-02-17 10:26:18 --> Output Class Initialized
INFO - 2023-02-17 10:26:18 --> Security Class Initialized
DEBUG - 2023-02-17 10:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:26:18 --> Input Class Initialized
INFO - 2023-02-17 10:26:18 --> Language Class Initialized
INFO - 2023-02-17 10:26:18 --> Loader Class Initialized
INFO - 2023-02-17 10:26:18 --> Controller Class Initialized
DEBUG - 2023-02-17 10:26:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:26:18 --> Database Driver Class Initialized
INFO - 2023-02-17 10:26:18 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:26:18 --> Final output sent to browser
DEBUG - 2023-02-17 10:26:18 --> Total execution time: 0.0122
INFO - 2023-02-17 10:26:21 --> Config Class Initialized
INFO - 2023-02-17 10:26:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:26:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:26:21 --> Utf8 Class Initialized
INFO - 2023-02-17 10:26:21 --> URI Class Initialized
INFO - 2023-02-17 10:26:21 --> Router Class Initialized
INFO - 2023-02-17 10:26:21 --> Output Class Initialized
INFO - 2023-02-17 10:26:21 --> Security Class Initialized
DEBUG - 2023-02-17 10:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:26:21 --> Input Class Initialized
INFO - 2023-02-17 10:26:21 --> Language Class Initialized
INFO - 2023-02-17 10:26:21 --> Loader Class Initialized
INFO - 2023-02-17 10:26:21 --> Controller Class Initialized
DEBUG - 2023-02-17 10:26:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:26:21 --> Database Driver Class Initialized
INFO - 2023-02-17 10:26:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:26:21 --> Final output sent to browser
DEBUG - 2023-02-17 10:26:21 --> Total execution time: 0.0496
INFO - 2023-02-17 10:26:21 --> Config Class Initialized
INFO - 2023-02-17 10:26:21 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:26:21 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:26:21 --> Utf8 Class Initialized
INFO - 2023-02-17 10:26:21 --> URI Class Initialized
INFO - 2023-02-17 10:26:21 --> Router Class Initialized
INFO - 2023-02-17 10:26:21 --> Output Class Initialized
INFO - 2023-02-17 10:26:21 --> Security Class Initialized
DEBUG - 2023-02-17 10:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:26:21 --> Input Class Initialized
INFO - 2023-02-17 10:26:21 --> Language Class Initialized
INFO - 2023-02-17 10:26:21 --> Loader Class Initialized
INFO - 2023-02-17 10:26:21 --> Controller Class Initialized
DEBUG - 2023-02-17 10:26:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:26:21 --> Database Driver Class Initialized
INFO - 2023-02-17 10:26:21 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:26:21 --> Final output sent to browser
DEBUG - 2023-02-17 10:26:21 --> Total execution time: 0.0459
INFO - 2023-02-17 10:26:31 --> Config Class Initialized
INFO - 2023-02-17 10:26:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:26:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:26:31 --> Utf8 Class Initialized
INFO - 2023-02-17 10:26:31 --> URI Class Initialized
INFO - 2023-02-17 10:26:31 --> Router Class Initialized
INFO - 2023-02-17 10:26:31 --> Output Class Initialized
INFO - 2023-02-17 10:26:31 --> Security Class Initialized
DEBUG - 2023-02-17 10:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:26:31 --> Input Class Initialized
INFO - 2023-02-17 10:26:31 --> Language Class Initialized
INFO - 2023-02-17 10:26:31 --> Loader Class Initialized
INFO - 2023-02-17 10:26:31 --> Controller Class Initialized
DEBUG - 2023-02-17 10:26:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:26:31 --> Database Driver Class Initialized
INFO - 2023-02-17 10:26:31 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:26:31 --> Final output sent to browser
DEBUG - 2023-02-17 10:26:31 --> Total execution time: 0.0164
INFO - 2023-02-17 10:26:31 --> Config Class Initialized
INFO - 2023-02-17 10:26:31 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:26:31 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:26:31 --> Utf8 Class Initialized
INFO - 2023-02-17 10:26:31 --> URI Class Initialized
INFO - 2023-02-17 10:26:31 --> Router Class Initialized
INFO - 2023-02-17 10:26:31 --> Output Class Initialized
INFO - 2023-02-17 10:26:31 --> Security Class Initialized
DEBUG - 2023-02-17 10:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:26:31 --> Input Class Initialized
INFO - 2023-02-17 10:26:31 --> Language Class Initialized
INFO - 2023-02-17 10:26:31 --> Loader Class Initialized
INFO - 2023-02-17 10:26:31 --> Controller Class Initialized
DEBUG - 2023-02-17 10:26:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:26:31 --> Database Driver Class Initialized
INFO - 2023-02-17 10:26:31 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:26:31 --> Final output sent to browser
DEBUG - 2023-02-17 10:26:31 --> Total execution time: 0.0123
INFO - 2023-02-17 10:26:35 --> Config Class Initialized
INFO - 2023-02-17 10:26:35 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:26:35 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:26:35 --> Utf8 Class Initialized
INFO - 2023-02-17 10:26:35 --> URI Class Initialized
INFO - 2023-02-17 10:26:35 --> Router Class Initialized
INFO - 2023-02-17 10:26:35 --> Output Class Initialized
INFO - 2023-02-17 10:26:35 --> Security Class Initialized
DEBUG - 2023-02-17 10:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:26:35 --> Input Class Initialized
INFO - 2023-02-17 10:26:35 --> Language Class Initialized
INFO - 2023-02-17 10:26:35 --> Loader Class Initialized
INFO - 2023-02-17 10:26:35 --> Controller Class Initialized
DEBUG - 2023-02-17 10:26:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:26:35 --> Database Driver Class Initialized
INFO - 2023-02-17 10:26:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:26:36 --> Final output sent to browser
DEBUG - 2023-02-17 10:26:36 --> Total execution time: 0.0199
INFO - 2023-02-17 10:26:36 --> Config Class Initialized
INFO - 2023-02-17 10:26:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:26:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:26:36 --> Utf8 Class Initialized
INFO - 2023-02-17 10:26:36 --> URI Class Initialized
INFO - 2023-02-17 10:26:36 --> Router Class Initialized
INFO - 2023-02-17 10:26:36 --> Output Class Initialized
INFO - 2023-02-17 10:26:36 --> Security Class Initialized
DEBUG - 2023-02-17 10:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:26:36 --> Input Class Initialized
INFO - 2023-02-17 10:26:36 --> Language Class Initialized
INFO - 2023-02-17 10:26:36 --> Loader Class Initialized
INFO - 2023-02-17 10:26:36 --> Controller Class Initialized
DEBUG - 2023-02-17 10:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:26:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:26:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:26:36 --> Final output sent to browser
DEBUG - 2023-02-17 10:26:36 --> Total execution time: 0.0165
INFO - 2023-02-17 10:27:38 --> Config Class Initialized
INFO - 2023-02-17 10:27:38 --> Config Class Initialized
INFO - 2023-02-17 10:27:38 --> Hooks Class Initialized
INFO - 2023-02-17 10:27:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:27:38 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:27:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:27:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:27:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:27:38 --> URI Class Initialized
INFO - 2023-02-17 10:27:38 --> URI Class Initialized
INFO - 2023-02-17 10:27:38 --> Router Class Initialized
INFO - 2023-02-17 10:27:38 --> Router Class Initialized
INFO - 2023-02-17 10:27:38 --> Output Class Initialized
INFO - 2023-02-17 10:27:38 --> Output Class Initialized
INFO - 2023-02-17 10:27:38 --> Security Class Initialized
INFO - 2023-02-17 10:27:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:27:38 --> Input Class Initialized
INFO - 2023-02-17 10:27:38 --> Input Class Initialized
INFO - 2023-02-17 10:27:38 --> Language Class Initialized
INFO - 2023-02-17 10:27:38 --> Language Class Initialized
INFO - 2023-02-17 10:27:38 --> Loader Class Initialized
INFO - 2023-02-17 10:27:38 --> Loader Class Initialized
INFO - 2023-02-17 10:27:38 --> Controller Class Initialized
INFO - 2023-02-17 10:27:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:27:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:27:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:27:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:27:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:27:38 --> Model "Login_model" initialized
INFO - 2023-02-17 10:27:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:27:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:27:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:27:38 --> Total execution time: 0.0286
INFO - 2023-02-17 10:27:38 --> Config Class Initialized
INFO - 2023-02-17 10:27:38 --> Hooks Class Initialized
INFO - 2023-02-17 10:27:38 --> Model "Cluster_model" initialized
DEBUG - 2023-02-17 10:27:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:27:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:27:38 --> URI Class Initialized
INFO - 2023-02-17 10:27:38 --> Router Class Initialized
INFO - 2023-02-17 10:27:38 --> Output Class Initialized
INFO - 2023-02-17 10:27:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:27:38 --> Input Class Initialized
INFO - 2023-02-17 10:27:38 --> Language Class Initialized
INFO - 2023-02-17 10:27:38 --> Loader Class Initialized
INFO - 2023-02-17 10:27:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:27:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:27:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:27:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:27:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:27:38 --> Total execution time: 0.0163
INFO - 2023-02-17 10:27:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:27:38 --> Total execution time: 0.6192
INFO - 2023-02-17 10:27:38 --> Config Class Initialized
INFO - 2023-02-17 10:27:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:27:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:27:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:27:38 --> URI Class Initialized
INFO - 2023-02-17 10:27:38 --> Router Class Initialized
INFO - 2023-02-17 10:27:38 --> Output Class Initialized
INFO - 2023-02-17 10:27:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:27:38 --> Input Class Initialized
INFO - 2023-02-17 10:27:38 --> Language Class Initialized
INFO - 2023-02-17 10:27:38 --> Loader Class Initialized
INFO - 2023-02-17 10:27:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:27:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:27:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:27:38 --> Model "Login_model" initialized
INFO - 2023-02-17 10:27:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:27:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:27:39 --> Final output sent to browser
DEBUG - 2023-02-17 10:27:39 --> Total execution time: 0.5778
INFO - 2023-02-17 10:28:36 --> Config Class Initialized
INFO - 2023-02-17 10:28:36 --> Config Class Initialized
INFO - 2023-02-17 10:28:36 --> Hooks Class Initialized
INFO - 2023-02-17 10:28:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:28:36 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:28:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:28:36 --> Utf8 Class Initialized
INFO - 2023-02-17 10:28:36 --> Utf8 Class Initialized
INFO - 2023-02-17 10:28:36 --> URI Class Initialized
INFO - 2023-02-17 10:28:36 --> URI Class Initialized
INFO - 2023-02-17 10:28:36 --> Router Class Initialized
INFO - 2023-02-17 10:28:36 --> Router Class Initialized
INFO - 2023-02-17 10:28:36 --> Output Class Initialized
INFO - 2023-02-17 10:28:36 --> Output Class Initialized
INFO - 2023-02-17 10:28:36 --> Security Class Initialized
INFO - 2023-02-17 10:28:36 --> Security Class Initialized
DEBUG - 2023-02-17 10:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:28:36 --> Input Class Initialized
INFO - 2023-02-17 10:28:36 --> Input Class Initialized
INFO - 2023-02-17 10:28:36 --> Language Class Initialized
INFO - 2023-02-17 10:28:36 --> Language Class Initialized
INFO - 2023-02-17 10:28:36 --> Loader Class Initialized
INFO - 2023-02-17 10:28:36 --> Loader Class Initialized
INFO - 2023-02-17 10:28:36 --> Controller Class Initialized
INFO - 2023-02-17 10:28:36 --> Controller Class Initialized
DEBUG - 2023-02-17 10:28:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:28:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:28:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:28:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:28:36 --> Model "Login_model" initialized
INFO - 2023-02-17 10:28:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:28:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:28:36 --> Final output sent to browser
DEBUG - 2023-02-17 10:28:36 --> Total execution time: 0.0226
INFO - 2023-02-17 10:28:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:28:36 --> Config Class Initialized
INFO - 2023-02-17 10:28:36 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:28:36 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:28:36 --> Utf8 Class Initialized
INFO - 2023-02-17 10:28:36 --> URI Class Initialized
INFO - 2023-02-17 10:28:36 --> Router Class Initialized
INFO - 2023-02-17 10:28:36 --> Output Class Initialized
INFO - 2023-02-17 10:28:36 --> Security Class Initialized
DEBUG - 2023-02-17 10:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:28:36 --> Input Class Initialized
INFO - 2023-02-17 10:28:36 --> Language Class Initialized
INFO - 2023-02-17 10:28:36 --> Loader Class Initialized
INFO - 2023-02-17 10:28:36 --> Controller Class Initialized
DEBUG - 2023-02-17 10:28:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:28:36 --> Database Driver Class Initialized
INFO - 2023-02-17 10:28:36 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:28:36 --> Final output sent to browser
DEBUG - 2023-02-17 10:28:36 --> Total execution time: 0.0166
INFO - 2023-02-17 10:28:37 --> Final output sent to browser
DEBUG - 2023-02-17 10:28:37 --> Total execution time: 0.5142
INFO - 2023-02-17 10:28:37 --> Config Class Initialized
INFO - 2023-02-17 10:28:37 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:28:37 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:28:37 --> Utf8 Class Initialized
INFO - 2023-02-17 10:28:37 --> URI Class Initialized
INFO - 2023-02-17 10:28:37 --> Router Class Initialized
INFO - 2023-02-17 10:28:37 --> Output Class Initialized
INFO - 2023-02-17 10:28:37 --> Security Class Initialized
DEBUG - 2023-02-17 10:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:28:37 --> Input Class Initialized
INFO - 2023-02-17 10:28:37 --> Language Class Initialized
INFO - 2023-02-17 10:28:37 --> Loader Class Initialized
INFO - 2023-02-17 10:28:37 --> Controller Class Initialized
DEBUG - 2023-02-17 10:28:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:28:37 --> Database Driver Class Initialized
INFO - 2023-02-17 10:28:37 --> Model "Login_model" initialized
INFO - 2023-02-17 10:28:37 --> Database Driver Class Initialized
INFO - 2023-02-17 10:28:37 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:28:37 --> Final output sent to browser
DEBUG - 2023-02-17 10:28:37 --> Total execution time: 0.5319
INFO - 2023-02-17 10:29:37 --> Config Class Initialized
INFO - 2023-02-17 10:29:37 --> Config Class Initialized
INFO - 2023-02-17 10:29:37 --> Hooks Class Initialized
INFO - 2023-02-17 10:29:37 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:29:37 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:29:37 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:29:37 --> Utf8 Class Initialized
INFO - 2023-02-17 10:29:37 --> Utf8 Class Initialized
INFO - 2023-02-17 10:29:37 --> URI Class Initialized
INFO - 2023-02-17 10:29:37 --> URI Class Initialized
INFO - 2023-02-17 10:29:37 --> Router Class Initialized
INFO - 2023-02-17 10:29:37 --> Router Class Initialized
INFO - 2023-02-17 10:29:37 --> Output Class Initialized
INFO - 2023-02-17 10:29:37 --> Output Class Initialized
INFO - 2023-02-17 10:29:37 --> Security Class Initialized
INFO - 2023-02-17 10:29:37 --> Security Class Initialized
DEBUG - 2023-02-17 10:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:29:37 --> Input Class Initialized
INFO - 2023-02-17 10:29:37 --> Input Class Initialized
INFO - 2023-02-17 10:29:37 --> Language Class Initialized
INFO - 2023-02-17 10:29:37 --> Language Class Initialized
INFO - 2023-02-17 10:29:37 --> Loader Class Initialized
INFO - 2023-02-17 10:29:37 --> Loader Class Initialized
INFO - 2023-02-17 10:29:37 --> Controller Class Initialized
INFO - 2023-02-17 10:29:37 --> Controller Class Initialized
DEBUG - 2023-02-17 10:29:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:29:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:29:37 --> Database Driver Class Initialized
INFO - 2023-02-17 10:29:37 --> Database Driver Class Initialized
INFO - 2023-02-17 10:29:37 --> Model "Login_model" initialized
INFO - 2023-02-17 10:29:37 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:29:37 --> Database Driver Class Initialized
INFO - 2023-02-17 10:29:37 --> Final output sent to browser
DEBUG - 2023-02-17 10:29:37 --> Total execution time: 0.0223
INFO - 2023-02-17 10:29:37 --> Config Class Initialized
INFO - 2023-02-17 10:29:37 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:29:37 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:29:37 --> Utf8 Class Initialized
INFO - 2023-02-17 10:29:37 --> URI Class Initialized
INFO - 2023-02-17 10:29:37 --> Router Class Initialized
INFO - 2023-02-17 10:29:37 --> Output Class Initialized
INFO - 2023-02-17 10:29:37 --> Security Class Initialized
DEBUG - 2023-02-17 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:29:37 --> Input Class Initialized
INFO - 2023-02-17 10:29:37 --> Language Class Initialized
INFO - 2023-02-17 10:29:37 --> Loader Class Initialized
INFO - 2023-02-17 10:29:37 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:29:37 --> Controller Class Initialized
DEBUG - 2023-02-17 10:29:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:29:37 --> Database Driver Class Initialized
INFO - 2023-02-17 10:29:37 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:29:37 --> Final output sent to browser
DEBUG - 2023-02-17 10:29:37 --> Total execution time: 0.0155
INFO - 2023-02-17 10:29:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:29:38 --> Total execution time: 0.5968
INFO - 2023-02-17 10:29:38 --> Config Class Initialized
INFO - 2023-02-17 10:29:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:29:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:29:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:29:38 --> URI Class Initialized
INFO - 2023-02-17 10:29:38 --> Router Class Initialized
INFO - 2023-02-17 10:29:38 --> Output Class Initialized
INFO - 2023-02-17 10:29:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:29:38 --> Input Class Initialized
INFO - 2023-02-17 10:29:38 --> Language Class Initialized
INFO - 2023-02-17 10:29:38 --> Loader Class Initialized
INFO - 2023-02-17 10:29:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:29:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:29:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:29:38 --> Model "Login_model" initialized
INFO - 2023-02-17 10:29:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:29:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:29:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:29:38 --> Total execution time: 0.5738
INFO - 2023-02-17 10:30:38 --> Config Class Initialized
INFO - 2023-02-17 10:30:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:30:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:30:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:30:38 --> URI Class Initialized
INFO - 2023-02-17 10:30:38 --> Router Class Initialized
INFO - 2023-02-17 10:30:38 --> Output Class Initialized
INFO - 2023-02-17 10:30:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:30:38 --> Input Class Initialized
INFO - 2023-02-17 10:30:38 --> Language Class Initialized
INFO - 2023-02-17 10:30:38 --> Loader Class Initialized
INFO - 2023-02-17 10:30:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:30:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:30:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:30:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:30:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:30:38 --> Total execution time: 0.0187
INFO - 2023-02-17 10:30:38 --> Config Class Initialized
INFO - 2023-02-17 10:30:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:30:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:30:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:30:38 --> URI Class Initialized
INFO - 2023-02-17 10:30:38 --> Router Class Initialized
INFO - 2023-02-17 10:30:38 --> Output Class Initialized
INFO - 2023-02-17 10:30:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:30:38 --> Input Class Initialized
INFO - 2023-02-17 10:30:38 --> Language Class Initialized
INFO - 2023-02-17 10:30:38 --> Loader Class Initialized
INFO - 2023-02-17 10:30:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:30:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:30:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:30:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:30:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:30:38 --> Total execution time: 0.0591
INFO - 2023-02-17 10:30:38 --> Config Class Initialized
INFO - 2023-02-17 10:30:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:30:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:30:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:30:38 --> URI Class Initialized
INFO - 2023-02-17 10:30:38 --> Router Class Initialized
INFO - 2023-02-17 10:30:38 --> Output Class Initialized
INFO - 2023-02-17 10:30:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:30:38 --> Input Class Initialized
INFO - 2023-02-17 10:30:38 --> Language Class Initialized
INFO - 2023-02-17 10:30:38 --> Loader Class Initialized
INFO - 2023-02-17 10:30:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:30:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:30:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:30:38 --> Model "Login_model" initialized
INFO - 2023-02-17 10:30:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:30:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:30:39 --> Final output sent to browser
DEBUG - 2023-02-17 10:30:39 --> Total execution time: 0.5552
INFO - 2023-02-17 10:30:39 --> Config Class Initialized
INFO - 2023-02-17 10:30:39 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:30:39 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:30:39 --> Utf8 Class Initialized
INFO - 2023-02-17 10:30:39 --> URI Class Initialized
INFO - 2023-02-17 10:30:39 --> Router Class Initialized
INFO - 2023-02-17 10:30:39 --> Output Class Initialized
INFO - 2023-02-17 10:30:39 --> Security Class Initialized
DEBUG - 2023-02-17 10:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:30:39 --> Input Class Initialized
INFO - 2023-02-17 10:30:39 --> Language Class Initialized
INFO - 2023-02-17 10:30:39 --> Loader Class Initialized
INFO - 2023-02-17 10:30:39 --> Controller Class Initialized
DEBUG - 2023-02-17 10:30:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:30:39 --> Database Driver Class Initialized
INFO - 2023-02-17 10:30:39 --> Model "Login_model" initialized
INFO - 2023-02-17 10:30:39 --> Database Driver Class Initialized
INFO - 2023-02-17 10:30:39 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:30:40 --> Final output sent to browser
DEBUG - 2023-02-17 10:30:40 --> Total execution time: 0.6139
INFO - 2023-02-17 10:31:38 --> Config Class Initialized
INFO - 2023-02-17 10:31:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:31:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:31:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:31:38 --> URI Class Initialized
INFO - 2023-02-17 10:31:38 --> Router Class Initialized
INFO - 2023-02-17 10:31:38 --> Output Class Initialized
INFO - 2023-02-17 10:31:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:31:38 --> Input Class Initialized
INFO - 2023-02-17 10:31:38 --> Language Class Initialized
INFO - 2023-02-17 10:31:38 --> Loader Class Initialized
INFO - 2023-02-17 10:31:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:31:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:31:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:31:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:31:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:31:38 --> Total execution time: 0.0228
INFO - 2023-02-17 10:31:38 --> Config Class Initialized
INFO - 2023-02-17 10:31:38 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:31:38 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:31:38 --> Utf8 Class Initialized
INFO - 2023-02-17 10:31:38 --> URI Class Initialized
INFO - 2023-02-17 10:31:38 --> Router Class Initialized
INFO - 2023-02-17 10:31:38 --> Output Class Initialized
INFO - 2023-02-17 10:31:38 --> Security Class Initialized
DEBUG - 2023-02-17 10:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:31:38 --> Input Class Initialized
INFO - 2023-02-17 10:31:38 --> Language Class Initialized
INFO - 2023-02-17 10:31:38 --> Loader Class Initialized
INFO - 2023-02-17 10:31:38 --> Controller Class Initialized
DEBUG - 2023-02-17 10:31:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:31:38 --> Database Driver Class Initialized
INFO - 2023-02-17 10:31:38 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:31:38 --> Final output sent to browser
DEBUG - 2023-02-17 10:31:38 --> Total execution time: 0.0137
INFO - 2023-02-17 10:31:40 --> Config Class Initialized
INFO - 2023-02-17 10:31:40 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:31:40 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:31:40 --> Utf8 Class Initialized
INFO - 2023-02-17 10:31:40 --> URI Class Initialized
INFO - 2023-02-17 10:31:40 --> Router Class Initialized
INFO - 2023-02-17 10:31:40 --> Output Class Initialized
INFO - 2023-02-17 10:31:40 --> Security Class Initialized
DEBUG - 2023-02-17 10:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:31:40 --> Input Class Initialized
INFO - 2023-02-17 10:31:40 --> Language Class Initialized
INFO - 2023-02-17 10:31:40 --> Loader Class Initialized
INFO - 2023-02-17 10:31:40 --> Controller Class Initialized
DEBUG - 2023-02-17 10:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:31:40 --> Database Driver Class Initialized
INFO - 2023-02-17 10:31:40 --> Model "Login_model" initialized
INFO - 2023-02-17 10:31:40 --> Database Driver Class Initialized
INFO - 2023-02-17 10:31:40 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:31:40 --> Final output sent to browser
DEBUG - 2023-02-17 10:31:40 --> Total execution time: 0.6369
INFO - 2023-02-17 10:31:40 --> Config Class Initialized
INFO - 2023-02-17 10:31:40 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:31:40 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:31:40 --> Utf8 Class Initialized
INFO - 2023-02-17 10:31:40 --> URI Class Initialized
INFO - 2023-02-17 10:31:40 --> Router Class Initialized
INFO - 2023-02-17 10:31:40 --> Output Class Initialized
INFO - 2023-02-17 10:31:40 --> Security Class Initialized
DEBUG - 2023-02-17 10:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:31:40 --> Input Class Initialized
INFO - 2023-02-17 10:31:40 --> Language Class Initialized
INFO - 2023-02-17 10:31:40 --> Loader Class Initialized
INFO - 2023-02-17 10:31:40 --> Controller Class Initialized
DEBUG - 2023-02-17 10:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:31:40 --> Database Driver Class Initialized
INFO - 2023-02-17 10:31:40 --> Model "Login_model" initialized
INFO - 2023-02-17 10:31:40 --> Database Driver Class Initialized
INFO - 2023-02-17 10:31:40 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:31:41 --> Final output sent to browser
DEBUG - 2023-02-17 10:31:41 --> Total execution time: 0.6081
INFO - 2023-02-17 10:32:17 --> Config Class Initialized
INFO - 2023-02-17 10:32:17 --> Config Class Initialized
INFO - 2023-02-17 10:32:17 --> Hooks Class Initialized
INFO - 2023-02-17 10:32:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:17 --> Utf8 Class Initialized
DEBUG - 2023-02-17 10:32:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:17 --> URI Class Initialized
INFO - 2023-02-17 10:32:17 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:17 --> Router Class Initialized
INFO - 2023-02-17 10:32:17 --> URI Class Initialized
INFO - 2023-02-17 10:32:17 --> Output Class Initialized
INFO - 2023-02-17 10:32:17 --> Router Class Initialized
INFO - 2023-02-17 10:32:17 --> Security Class Initialized
INFO - 2023-02-17 10:32:17 --> Output Class Initialized
DEBUG - 2023-02-17 10:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:17 --> Security Class Initialized
INFO - 2023-02-17 10:32:17 --> Input Class Initialized
DEBUG - 2023-02-17 10:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:17 --> Language Class Initialized
INFO - 2023-02-17 10:32:17 --> Input Class Initialized
INFO - 2023-02-17 10:32:17 --> Language Class Initialized
INFO - 2023-02-17 10:32:17 --> Loader Class Initialized
INFO - 2023-02-17 10:32:17 --> Loader Class Initialized
INFO - 2023-02-17 10:32:17 --> Controller Class Initialized
INFO - 2023-02-17 10:32:17 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:32:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:17 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:17 --> Total execution time: 0.0044
INFO - 2023-02-17 10:32:17 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:17 --> Config Class Initialized
INFO - 2023-02-17 10:32:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:17 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:17 --> URI Class Initialized
INFO - 2023-02-17 10:32:17 --> Router Class Initialized
INFO - 2023-02-17 10:32:17 --> Output Class Initialized
INFO - 2023-02-17 10:32:17 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:17 --> Input Class Initialized
INFO - 2023-02-17 10:32:17 --> Language Class Initialized
INFO - 2023-02-17 10:32:17 --> Loader Class Initialized
INFO - 2023-02-17 10:32:17 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:17 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:17 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:17 --> Total execution time: 0.0510
INFO - 2023-02-17 10:32:17 --> Config Class Initialized
INFO - 2023-02-17 10:32:17 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:17 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:17 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:17 --> URI Class Initialized
INFO - 2023-02-17 10:32:17 --> Router Class Initialized
INFO - 2023-02-17 10:32:17 --> Output Class Initialized
INFO - 2023-02-17 10:32:17 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:17 --> Input Class Initialized
INFO - 2023-02-17 10:32:17 --> Language Class Initialized
INFO - 2023-02-17 10:32:17 --> Loader Class Initialized
INFO - 2023-02-17 10:32:17 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:17 --> Model "Login_model" initialized
INFO - 2023-02-17 10:32:17 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:17 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:17 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:17 --> Total execution time: 0.0497
INFO - 2023-02-17 10:32:17 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:17 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:17 --> Total execution time: 0.1430
INFO - 2023-02-17 10:32:19 --> Config Class Initialized
INFO - 2023-02-17 10:32:19 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:19 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:19 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:19 --> URI Class Initialized
INFO - 2023-02-17 10:32:19 --> Router Class Initialized
INFO - 2023-02-17 10:32:19 --> Output Class Initialized
INFO - 2023-02-17 10:32:19 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:19 --> Input Class Initialized
INFO - 2023-02-17 10:32:19 --> Language Class Initialized
INFO - 2023-02-17 10:32:19 --> Loader Class Initialized
INFO - 2023-02-17 10:32:19 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:19 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:19 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:20 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:20 --> Total execution time: 0.0615
INFO - 2023-02-17 10:32:20 --> Config Class Initialized
INFO - 2023-02-17 10:32:20 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:20 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:20 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:20 --> URI Class Initialized
INFO - 2023-02-17 10:32:20 --> Router Class Initialized
INFO - 2023-02-17 10:32:20 --> Output Class Initialized
INFO - 2023-02-17 10:32:20 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:20 --> Input Class Initialized
INFO - 2023-02-17 10:32:20 --> Language Class Initialized
INFO - 2023-02-17 10:32:20 --> Loader Class Initialized
INFO - 2023-02-17 10:32:20 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:20 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:20 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:20 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:20 --> Total execution time: 0.0901
INFO - 2023-02-17 10:32:23 --> Config Class Initialized
INFO - 2023-02-17 10:32:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:23 --> URI Class Initialized
INFO - 2023-02-17 10:32:23 --> Router Class Initialized
INFO - 2023-02-17 10:32:23 --> Output Class Initialized
INFO - 2023-02-17 10:32:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:23 --> Input Class Initialized
INFO - 2023-02-17 10:32:23 --> Language Class Initialized
INFO - 2023-02-17 10:32:23 --> Loader Class Initialized
INFO - 2023-02-17 10:32:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:23 --> Model "Login_model" initialized
INFO - 2023-02-17 10:32:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:23 --> Total execution time: 0.0390
INFO - 2023-02-17 10:32:23 --> Config Class Initialized
INFO - 2023-02-17 10:32:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:23 --> URI Class Initialized
INFO - 2023-02-17 10:32:23 --> Router Class Initialized
INFO - 2023-02-17 10:32:23 --> Output Class Initialized
INFO - 2023-02-17 10:32:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:23 --> Input Class Initialized
INFO - 2023-02-17 10:32:23 --> Language Class Initialized
INFO - 2023-02-17 10:32:23 --> Loader Class Initialized
INFO - 2023-02-17 10:32:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:23 --> Model "Login_model" initialized
INFO - 2023-02-17 10:32:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:23 --> Total execution time: 0.0787
INFO - 2023-02-17 10:32:25 --> Config Class Initialized
INFO - 2023-02-17 10:32:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:25 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:25 --> URI Class Initialized
INFO - 2023-02-17 10:32:25 --> Router Class Initialized
INFO - 2023-02-17 10:32:25 --> Output Class Initialized
INFO - 2023-02-17 10:32:25 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:25 --> Input Class Initialized
INFO - 2023-02-17 10:32:25 --> Language Class Initialized
INFO - 2023-02-17 10:32:25 --> Loader Class Initialized
INFO - 2023-02-17 10:32:25 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:25 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:25 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:25 --> Total execution time: 0.0163
INFO - 2023-02-17 10:32:25 --> Config Class Initialized
INFO - 2023-02-17 10:32:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:26 --> URI Class Initialized
INFO - 2023-02-17 10:32:26 --> Router Class Initialized
INFO - 2023-02-17 10:32:26 --> Output Class Initialized
INFO - 2023-02-17 10:32:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:26 --> Input Class Initialized
INFO - 2023-02-17 10:32:26 --> Language Class Initialized
INFO - 2023-02-17 10:32:26 --> Loader Class Initialized
INFO - 2023-02-17 10:32:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:26 --> Total execution time: 0.0559
INFO - 2023-02-17 10:32:29 --> Config Class Initialized
INFO - 2023-02-17 10:32:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:29 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:29 --> URI Class Initialized
INFO - 2023-02-17 10:32:29 --> Router Class Initialized
INFO - 2023-02-17 10:32:29 --> Output Class Initialized
INFO - 2023-02-17 10:32:29 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:29 --> Input Class Initialized
INFO - 2023-02-17 10:32:29 --> Language Class Initialized
INFO - 2023-02-17 10:32:29 --> Loader Class Initialized
INFO - 2023-02-17 10:32:29 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:29 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:29 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:29 --> Model "Login_model" initialized
INFO - 2023-02-17 10:32:29 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:29 --> Total execution time: 0.0702
INFO - 2023-02-17 10:32:29 --> Config Class Initialized
INFO - 2023-02-17 10:32:29 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:29 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:29 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:29 --> URI Class Initialized
INFO - 2023-02-17 10:32:29 --> Router Class Initialized
INFO - 2023-02-17 10:32:29 --> Output Class Initialized
INFO - 2023-02-17 10:32:29 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:29 --> Input Class Initialized
INFO - 2023-02-17 10:32:29 --> Language Class Initialized
INFO - 2023-02-17 10:32:29 --> Loader Class Initialized
INFO - 2023-02-17 10:32:29 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:29 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:29 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:29 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:29 --> Model "Login_model" initialized
INFO - 2023-02-17 10:32:29 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:29 --> Total execution time: 0.0369
INFO - 2023-02-17 10:32:53 --> Config Class Initialized
INFO - 2023-02-17 10:32:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:53 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:53 --> URI Class Initialized
INFO - 2023-02-17 10:32:53 --> Router Class Initialized
INFO - 2023-02-17 10:32:53 --> Output Class Initialized
INFO - 2023-02-17 10:32:53 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:53 --> Input Class Initialized
INFO - 2023-02-17 10:32:53 --> Language Class Initialized
INFO - 2023-02-17 10:32:53 --> Loader Class Initialized
INFO - 2023-02-17 10:32:53 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:53 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:53 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:53 --> Total execution time: 0.0498
INFO - 2023-02-17 10:32:53 --> Config Class Initialized
INFO - 2023-02-17 10:32:53 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:53 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:53 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:53 --> URI Class Initialized
INFO - 2023-02-17 10:32:53 --> Router Class Initialized
INFO - 2023-02-17 10:32:53 --> Output Class Initialized
INFO - 2023-02-17 10:32:53 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:53 --> Input Class Initialized
INFO - 2023-02-17 10:32:53 --> Language Class Initialized
INFO - 2023-02-17 10:32:53 --> Loader Class Initialized
INFO - 2023-02-17 10:32:53 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:53 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:53 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:53 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:53 --> Total execution time: 0.0807
INFO - 2023-02-17 10:32:58 --> Config Class Initialized
INFO - 2023-02-17 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:58 --> URI Class Initialized
INFO - 2023-02-17 10:32:58 --> Router Class Initialized
INFO - 2023-02-17 10:32:58 --> Output Class Initialized
INFO - 2023-02-17 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:58 --> Input Class Initialized
INFO - 2023-02-17 10:32:58 --> Language Class Initialized
INFO - 2023-02-17 10:32:58 --> Loader Class Initialized
INFO - 2023-02-17 10:32:58 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:58 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:58 --> Total execution time: 0.0510
INFO - 2023-02-17 10:32:58 --> Config Class Initialized
INFO - 2023-02-17 10:32:58 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:58 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:58 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:58 --> URI Class Initialized
INFO - 2023-02-17 10:32:58 --> Router Class Initialized
INFO - 2023-02-17 10:32:58 --> Output Class Initialized
INFO - 2023-02-17 10:32:58 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:58 --> Input Class Initialized
INFO - 2023-02-17 10:32:58 --> Language Class Initialized
INFO - 2023-02-17 10:32:58 --> Loader Class Initialized
INFO - 2023-02-17 10:32:58 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:58 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:58 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:58 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:58 --> Total execution time: 0.0853
INFO - 2023-02-17 10:32:59 --> Config Class Initialized
INFO - 2023-02-17 10:32:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:59 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:59 --> URI Class Initialized
INFO - 2023-02-17 10:32:59 --> Router Class Initialized
INFO - 2023-02-17 10:32:59 --> Output Class Initialized
INFO - 2023-02-17 10:32:59 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:59 --> Input Class Initialized
INFO - 2023-02-17 10:32:59 --> Language Class Initialized
INFO - 2023-02-17 10:32:59 --> Loader Class Initialized
INFO - 2023-02-17 10:32:59 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:59 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:59 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:59 --> Total execution time: 0.0275
INFO - 2023-02-17 10:32:59 --> Config Class Initialized
INFO - 2023-02-17 10:32:59 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:32:59 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:32:59 --> Utf8 Class Initialized
INFO - 2023-02-17 10:32:59 --> URI Class Initialized
INFO - 2023-02-17 10:32:59 --> Router Class Initialized
INFO - 2023-02-17 10:32:59 --> Output Class Initialized
INFO - 2023-02-17 10:32:59 --> Security Class Initialized
DEBUG - 2023-02-17 10:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:32:59 --> Input Class Initialized
INFO - 2023-02-17 10:32:59 --> Language Class Initialized
INFO - 2023-02-17 10:32:59 --> Loader Class Initialized
INFO - 2023-02-17 10:32:59 --> Controller Class Initialized
DEBUG - 2023-02-17 10:32:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:32:59 --> Database Driver Class Initialized
INFO - 2023-02-17 10:32:59 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:32:59 --> Final output sent to browser
DEBUG - 2023-02-17 10:32:59 --> Total execution time: 0.0613
INFO - 2023-02-17 10:33:02 --> Config Class Initialized
INFO - 2023-02-17 10:33:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:02 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:02 --> URI Class Initialized
INFO - 2023-02-17 10:33:02 --> Router Class Initialized
INFO - 2023-02-17 10:33:02 --> Output Class Initialized
INFO - 2023-02-17 10:33:02 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:02 --> Input Class Initialized
INFO - 2023-02-17 10:33:02 --> Language Class Initialized
INFO - 2023-02-17 10:33:02 --> Loader Class Initialized
INFO - 2023-02-17 10:33:02 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:02 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:02 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:02 --> Total execution time: 0.0455
INFO - 2023-02-17 10:33:02 --> Config Class Initialized
INFO - 2023-02-17 10:33:02 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:02 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:02 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:02 --> URI Class Initialized
INFO - 2023-02-17 10:33:02 --> Router Class Initialized
INFO - 2023-02-17 10:33:02 --> Output Class Initialized
INFO - 2023-02-17 10:33:02 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:02 --> Input Class Initialized
INFO - 2023-02-17 10:33:02 --> Language Class Initialized
INFO - 2023-02-17 10:33:02 --> Loader Class Initialized
INFO - 2023-02-17 10:33:02 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:02 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:02 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:02 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:02 --> Total execution time: 0.0387
INFO - 2023-02-17 10:33:05 --> Config Class Initialized
INFO - 2023-02-17 10:33:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:05 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:05 --> URI Class Initialized
INFO - 2023-02-17 10:33:05 --> Router Class Initialized
INFO - 2023-02-17 10:33:05 --> Output Class Initialized
INFO - 2023-02-17 10:33:05 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:05 --> Input Class Initialized
INFO - 2023-02-17 10:33:05 --> Language Class Initialized
INFO - 2023-02-17 10:33:05 --> Loader Class Initialized
INFO - 2023-02-17 10:33:05 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:05 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:05 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:05 --> Total execution time: 0.0178
INFO - 2023-02-17 10:33:05 --> Config Class Initialized
INFO - 2023-02-17 10:33:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:05 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:05 --> URI Class Initialized
INFO - 2023-02-17 10:33:05 --> Router Class Initialized
INFO - 2023-02-17 10:33:05 --> Output Class Initialized
INFO - 2023-02-17 10:33:05 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:05 --> Input Class Initialized
INFO - 2023-02-17 10:33:05 --> Language Class Initialized
INFO - 2023-02-17 10:33:05 --> Loader Class Initialized
INFO - 2023-02-17 10:33:05 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:05 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:05 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:05 --> Total execution time: 0.0107
INFO - 2023-02-17 10:33:07 --> Config Class Initialized
INFO - 2023-02-17 10:33:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:07 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:07 --> URI Class Initialized
INFO - 2023-02-17 10:33:07 --> Router Class Initialized
INFO - 2023-02-17 10:33:07 --> Output Class Initialized
INFO - 2023-02-17 10:33:07 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:07 --> Input Class Initialized
INFO - 2023-02-17 10:33:07 --> Language Class Initialized
INFO - 2023-02-17 10:33:07 --> Loader Class Initialized
INFO - 2023-02-17 10:33:07 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:07 --> Model "Login_model" initialized
INFO - 2023-02-17 10:33:07 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:07 --> Total execution time: 0.0726
INFO - 2023-02-17 10:33:07 --> Config Class Initialized
INFO - 2023-02-17 10:33:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:07 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:07 --> URI Class Initialized
INFO - 2023-02-17 10:33:07 --> Router Class Initialized
INFO - 2023-02-17 10:33:07 --> Output Class Initialized
INFO - 2023-02-17 10:33:07 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:07 --> Input Class Initialized
INFO - 2023-02-17 10:33:07 --> Language Class Initialized
INFO - 2023-02-17 10:33:07 --> Loader Class Initialized
INFO - 2023-02-17 10:33:07 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:07 --> Model "Login_model" initialized
INFO - 2023-02-17 10:33:07 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:07 --> Total execution time: 0.0538
INFO - 2023-02-17 10:33:18 --> Config Class Initialized
INFO - 2023-02-17 10:33:18 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:18 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:18 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:18 --> URI Class Initialized
INFO - 2023-02-17 10:33:18 --> Router Class Initialized
INFO - 2023-02-17 10:33:18 --> Output Class Initialized
INFO - 2023-02-17 10:33:18 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:18 --> Input Class Initialized
INFO - 2023-02-17 10:33:18 --> Language Class Initialized
INFO - 2023-02-17 10:33:18 --> Loader Class Initialized
INFO - 2023-02-17 10:33:18 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:18 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:18 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:18 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:18 --> Total execution time: 0.0488
INFO - 2023-02-17 10:33:18 --> Config Class Initialized
INFO - 2023-02-17 10:33:18 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:18 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:18 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:18 --> URI Class Initialized
INFO - 2023-02-17 10:33:18 --> Router Class Initialized
INFO - 2023-02-17 10:33:18 --> Output Class Initialized
INFO - 2023-02-17 10:33:18 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:18 --> Input Class Initialized
INFO - 2023-02-17 10:33:18 --> Language Class Initialized
INFO - 2023-02-17 10:33:18 --> Loader Class Initialized
INFO - 2023-02-17 10:33:18 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:18 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:18 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:18 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:18 --> Total execution time: 0.0464
INFO - 2023-02-17 10:33:26 --> Config Class Initialized
INFO - 2023-02-17 10:33:26 --> Config Class Initialized
INFO - 2023-02-17 10:33:26 --> Hooks Class Initialized
INFO - 2023-02-17 10:33:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:26 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:33:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:26 --> URI Class Initialized
INFO - 2023-02-17 10:33:26 --> URI Class Initialized
INFO - 2023-02-17 10:33:26 --> Router Class Initialized
INFO - 2023-02-17 10:33:26 --> Router Class Initialized
INFO - 2023-02-17 10:33:26 --> Output Class Initialized
INFO - 2023-02-17 10:33:26 --> Output Class Initialized
INFO - 2023-02-17 10:33:26 --> Security Class Initialized
INFO - 2023-02-17 10:33:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:26 --> Input Class Initialized
INFO - 2023-02-17 10:33:26 --> Input Class Initialized
INFO - 2023-02-17 10:33:26 --> Language Class Initialized
INFO - 2023-02-17 10:33:26 --> Language Class Initialized
INFO - 2023-02-17 10:33:26 --> Loader Class Initialized
INFO - 2023-02-17 10:33:26 --> Loader Class Initialized
INFO - 2023-02-17 10:33:26 --> Controller Class Initialized
INFO - 2023-02-17 10:33:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:33:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:26 --> Total execution time: 0.0042
INFO - 2023-02-17 10:33:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:26 --> Config Class Initialized
INFO - 2023-02-17 10:33:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:26 --> URI Class Initialized
INFO - 2023-02-17 10:33:26 --> Router Class Initialized
INFO - 2023-02-17 10:33:26 --> Output Class Initialized
INFO - 2023-02-17 10:33:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:26 --> Input Class Initialized
INFO - 2023-02-17 10:33:26 --> Language Class Initialized
INFO - 2023-02-17 10:33:26 --> Loader Class Initialized
INFO - 2023-02-17 10:33:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:26 --> Total execution time: 0.0163
INFO - 2023-02-17 10:33:26 --> Model "Login_model" initialized
INFO - 2023-02-17 10:33:26 --> Config Class Initialized
INFO - 2023-02-17 10:33:26 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:33:26 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:33:26 --> Utf8 Class Initialized
INFO - 2023-02-17 10:33:26 --> URI Class Initialized
INFO - 2023-02-17 10:33:26 --> Router Class Initialized
INFO - 2023-02-17 10:33:26 --> Output Class Initialized
INFO - 2023-02-17 10:33:26 --> Security Class Initialized
DEBUG - 2023-02-17 10:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:33:26 --> Input Class Initialized
INFO - 2023-02-17 10:33:26 --> Language Class Initialized
INFO - 2023-02-17 10:33:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:26 --> Loader Class Initialized
INFO - 2023-02-17 10:33:26 --> Controller Class Initialized
DEBUG - 2023-02-17 10:33:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:33:26 --> Database Driver Class Initialized
INFO - 2023-02-17 10:33:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:26 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:33:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:26 --> Total execution time: 0.0229
INFO - 2023-02-17 10:33:26 --> Final output sent to browser
DEBUG - 2023-02-17 10:33:26 --> Total execution time: 0.0143
INFO - 2023-02-17 10:34:07 --> Config Class Initialized
INFO - 2023-02-17 10:34:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:34:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:34:07 --> Utf8 Class Initialized
INFO - 2023-02-17 10:34:07 --> URI Class Initialized
INFO - 2023-02-17 10:34:07 --> Router Class Initialized
INFO - 2023-02-17 10:34:07 --> Output Class Initialized
INFO - 2023-02-17 10:34:07 --> Security Class Initialized
DEBUG - 2023-02-17 10:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:34:07 --> Input Class Initialized
INFO - 2023-02-17 10:34:07 --> Language Class Initialized
INFO - 2023-02-17 10:34:07 --> Loader Class Initialized
INFO - 2023-02-17 10:34:07 --> Controller Class Initialized
DEBUG - 2023-02-17 10:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:34:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:34:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:34:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:34:07 --> Model "Login_model" initialized
INFO - 2023-02-17 10:34:07 --> Final output sent to browser
DEBUG - 2023-02-17 10:34:07 --> Total execution time: 0.0642
INFO - 2023-02-17 10:34:07 --> Config Class Initialized
INFO - 2023-02-17 10:34:07 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:34:07 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:34:07 --> Utf8 Class Initialized
INFO - 2023-02-17 10:34:07 --> URI Class Initialized
INFO - 2023-02-17 10:34:07 --> Router Class Initialized
INFO - 2023-02-17 10:34:07 --> Output Class Initialized
INFO - 2023-02-17 10:34:07 --> Security Class Initialized
DEBUG - 2023-02-17 10:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:34:07 --> Input Class Initialized
INFO - 2023-02-17 10:34:07 --> Language Class Initialized
INFO - 2023-02-17 10:34:07 --> Loader Class Initialized
INFO - 2023-02-17 10:34:07 --> Controller Class Initialized
DEBUG - 2023-02-17 10:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:34:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:34:07 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:34:07 --> Database Driver Class Initialized
INFO - 2023-02-17 10:34:07 --> Model "Login_model" initialized
INFO - 2023-02-17 10:34:07 --> Final output sent to browser
DEBUG - 2023-02-17 10:34:07 --> Total execution time: 0.0373
INFO - 2023-02-17 10:36:05 --> Config Class Initialized
INFO - 2023-02-17 10:36:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:36:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:36:05 --> Utf8 Class Initialized
INFO - 2023-02-17 10:36:05 --> URI Class Initialized
INFO - 2023-02-17 10:36:05 --> Router Class Initialized
INFO - 2023-02-17 10:36:05 --> Output Class Initialized
INFO - 2023-02-17 10:36:05 --> Security Class Initialized
DEBUG - 2023-02-17 10:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:36:05 --> Input Class Initialized
INFO - 2023-02-17 10:36:05 --> Language Class Initialized
INFO - 2023-02-17 10:36:05 --> Loader Class Initialized
INFO - 2023-02-17 10:36:05 --> Controller Class Initialized
DEBUG - 2023-02-17 10:36:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:36:05 --> Database Driver Class Initialized
INFO - 2023-02-17 10:36:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:36:05 --> Database Driver Class Initialized
INFO - 2023-02-17 10:36:05 --> Model "Login_model" initialized
INFO - 2023-02-17 10:36:05 --> Final output sent to browser
DEBUG - 2023-02-17 10:36:05 --> Total execution time: 0.1268
INFO - 2023-02-17 10:36:05 --> Config Class Initialized
INFO - 2023-02-17 10:36:05 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:36:05 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:36:05 --> Utf8 Class Initialized
INFO - 2023-02-17 10:36:05 --> URI Class Initialized
INFO - 2023-02-17 10:36:05 --> Router Class Initialized
INFO - 2023-02-17 10:36:05 --> Output Class Initialized
INFO - 2023-02-17 10:36:05 --> Security Class Initialized
DEBUG - 2023-02-17 10:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:36:05 --> Input Class Initialized
INFO - 2023-02-17 10:36:05 --> Language Class Initialized
INFO - 2023-02-17 10:36:05 --> Loader Class Initialized
INFO - 2023-02-17 10:36:05 --> Controller Class Initialized
DEBUG - 2023-02-17 10:36:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:36:05 --> Database Driver Class Initialized
INFO - 2023-02-17 10:36:05 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:36:05 --> Database Driver Class Initialized
INFO - 2023-02-17 10:36:05 --> Model "Login_model" initialized
INFO - 2023-02-17 10:36:05 --> Final output sent to browser
DEBUG - 2023-02-17 10:36:05 --> Total execution time: 0.0411
INFO - 2023-02-17 10:36:25 --> Config Class Initialized
INFO - 2023-02-17 10:36:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:36:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:36:25 --> Utf8 Class Initialized
INFO - 2023-02-17 10:36:25 --> URI Class Initialized
INFO - 2023-02-17 10:36:25 --> Router Class Initialized
INFO - 2023-02-17 10:36:25 --> Output Class Initialized
INFO - 2023-02-17 10:36:25 --> Security Class Initialized
DEBUG - 2023-02-17 10:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:36:25 --> Input Class Initialized
INFO - 2023-02-17 10:36:25 --> Language Class Initialized
INFO - 2023-02-17 10:36:25 --> Loader Class Initialized
INFO - 2023-02-17 10:36:25 --> Controller Class Initialized
DEBUG - 2023-02-17 10:36:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:36:25 --> Database Driver Class Initialized
INFO - 2023-02-17 10:36:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:36:25 --> Database Driver Class Initialized
INFO - 2023-02-17 10:36:25 --> Model "Login_model" initialized
INFO - 2023-02-17 10:36:25 --> Final output sent to browser
DEBUG - 2023-02-17 10:36:25 --> Total execution time: 0.1285
INFO - 2023-02-17 10:36:25 --> Config Class Initialized
INFO - 2023-02-17 10:36:25 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:36:25 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:36:25 --> Utf8 Class Initialized
INFO - 2023-02-17 10:36:25 --> URI Class Initialized
INFO - 2023-02-17 10:36:25 --> Router Class Initialized
INFO - 2023-02-17 10:36:25 --> Output Class Initialized
INFO - 2023-02-17 10:36:25 --> Security Class Initialized
DEBUG - 2023-02-17 10:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:36:25 --> Input Class Initialized
INFO - 2023-02-17 10:36:25 --> Language Class Initialized
INFO - 2023-02-17 10:36:25 --> Loader Class Initialized
INFO - 2023-02-17 10:36:25 --> Controller Class Initialized
DEBUG - 2023-02-17 10:36:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:36:25 --> Database Driver Class Initialized
INFO - 2023-02-17 10:36:25 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:36:25 --> Database Driver Class Initialized
INFO - 2023-02-17 10:36:25 --> Model "Login_model" initialized
INFO - 2023-02-17 10:36:25 --> Final output sent to browser
DEBUG - 2023-02-17 10:36:25 --> Total execution time: 0.0623
INFO - 2023-02-17 10:38:16 --> Config Class Initialized
INFO - 2023-02-17 10:38:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:16 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:16 --> URI Class Initialized
INFO - 2023-02-17 10:38:16 --> Router Class Initialized
INFO - 2023-02-17 10:38:16 --> Output Class Initialized
INFO - 2023-02-17 10:38:16 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:16 --> Input Class Initialized
INFO - 2023-02-17 10:38:16 --> Language Class Initialized
INFO - 2023-02-17 10:38:16 --> Loader Class Initialized
INFO - 2023-02-17 10:38:16 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:16 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:16 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:16 --> Model "Login_model" initialized
INFO - 2023-02-17 10:38:16 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:16 --> Total execution time: 0.1356
INFO - 2023-02-17 10:38:16 --> Config Class Initialized
INFO - 2023-02-17 10:38:16 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:16 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:16 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:16 --> URI Class Initialized
INFO - 2023-02-17 10:38:16 --> Router Class Initialized
INFO - 2023-02-17 10:38:16 --> Output Class Initialized
INFO - 2023-02-17 10:38:16 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:16 --> Input Class Initialized
INFO - 2023-02-17 10:38:16 --> Language Class Initialized
INFO - 2023-02-17 10:38:16 --> Loader Class Initialized
INFO - 2023-02-17 10:38:16 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:16 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:16 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:16 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:16 --> Model "Login_model" initialized
INFO - 2023-02-17 10:38:16 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:16 --> Total execution time: 0.1260
INFO - 2023-02-17 10:38:23 --> Config Class Initialized
INFO - 2023-02-17 10:38:23 --> Config Class Initialized
INFO - 2023-02-17 10:38:23 --> Hooks Class Initialized
INFO - 2023-02-17 10:38:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:38:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:23 --> URI Class Initialized
INFO - 2023-02-17 10:38:23 --> URI Class Initialized
INFO - 2023-02-17 10:38:23 --> Router Class Initialized
INFO - 2023-02-17 10:38:23 --> Router Class Initialized
INFO - 2023-02-17 10:38:23 --> Output Class Initialized
INFO - 2023-02-17 10:38:23 --> Output Class Initialized
INFO - 2023-02-17 10:38:23 --> Security Class Initialized
INFO - 2023-02-17 10:38:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:23 --> Input Class Initialized
INFO - 2023-02-17 10:38:23 --> Input Class Initialized
INFO - 2023-02-17 10:38:23 --> Language Class Initialized
INFO - 2023-02-17 10:38:23 --> Language Class Initialized
INFO - 2023-02-17 10:38:23 --> Loader Class Initialized
INFO - 2023-02-17 10:38:23 --> Loader Class Initialized
INFO - 2023-02-17 10:38:23 --> Controller Class Initialized
INFO - 2023-02-17 10:38:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:23 --> Final output sent to browser
INFO - 2023-02-17 10:38:23 --> Database Driver Class Initialized
DEBUG - 2023-02-17 10:38:23 --> Total execution time: 0.0071
INFO - 2023-02-17 10:38:23 --> Config Class Initialized
INFO - 2023-02-17 10:38:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:23 --> URI Class Initialized
INFO - 2023-02-17 10:38:23 --> Router Class Initialized
INFO - 2023-02-17 10:38:23 --> Output Class Initialized
INFO - 2023-02-17 10:38:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:23 --> Input Class Initialized
INFO - 2023-02-17 10:38:23 --> Language Class Initialized
INFO - 2023-02-17 10:38:23 --> Loader Class Initialized
INFO - 2023-02-17 10:38:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:23 --> Total execution time: 0.0206
INFO - 2023-02-17 10:38:23 --> Config Class Initialized
INFO - 2023-02-17 10:38:23 --> Hooks Class Initialized
INFO - 2023-02-17 10:38:23 --> Model "Login_model" initialized
DEBUG - 2023-02-17 10:38:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:23 --> URI Class Initialized
INFO - 2023-02-17 10:38:23 --> Router Class Initialized
INFO - 2023-02-17 10:38:23 --> Output Class Initialized
INFO - 2023-02-17 10:38:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:23 --> Input Class Initialized
INFO - 2023-02-17 10:38:23 --> Language Class Initialized
INFO - 2023-02-17 10:38:23 --> Loader Class Initialized
INFO - 2023-02-17 10:38:23 --> Controller Class Initialized
INFO - 2023-02-17 10:38:23 --> Database Driver Class Initialized
DEBUG - 2023-02-17 10:38:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:23 --> Total execution time: 0.0217
INFO - 2023-02-17 10:38:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:23 --> Total execution time: 0.0149
INFO - 2023-02-17 10:38:39 --> Config Class Initialized
INFO - 2023-02-17 10:38:39 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:39 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:39 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:39 --> URI Class Initialized
INFO - 2023-02-17 10:38:39 --> Router Class Initialized
INFO - 2023-02-17 10:38:39 --> Output Class Initialized
INFO - 2023-02-17 10:38:39 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:39 --> Input Class Initialized
INFO - 2023-02-17 10:38:39 --> Language Class Initialized
INFO - 2023-02-17 10:38:39 --> Loader Class Initialized
INFO - 2023-02-17 10:38:39 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:39 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:39 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:39 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:39 --> Total execution time: 0.0139
INFO - 2023-02-17 10:38:39 --> Config Class Initialized
INFO - 2023-02-17 10:38:39 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:39 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:39 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:39 --> URI Class Initialized
INFO - 2023-02-17 10:38:39 --> Router Class Initialized
INFO - 2023-02-17 10:38:39 --> Output Class Initialized
INFO - 2023-02-17 10:38:39 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:39 --> Input Class Initialized
INFO - 2023-02-17 10:38:39 --> Language Class Initialized
INFO - 2023-02-17 10:38:39 --> Loader Class Initialized
INFO - 2023-02-17 10:38:39 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:39 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:39 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:39 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:39 --> Total execution time: 0.0116
INFO - 2023-02-17 10:38:41 --> Config Class Initialized
INFO - 2023-02-17 10:38:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:41 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:41 --> URI Class Initialized
INFO - 2023-02-17 10:38:41 --> Router Class Initialized
INFO - 2023-02-17 10:38:41 --> Output Class Initialized
INFO - 2023-02-17 10:38:41 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:41 --> Input Class Initialized
INFO - 2023-02-17 10:38:41 --> Language Class Initialized
INFO - 2023-02-17 10:38:41 --> Loader Class Initialized
INFO - 2023-02-17 10:38:41 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:41 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:41 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:41 --> Total execution time: 0.0595
INFO - 2023-02-17 10:38:41 --> Config Class Initialized
INFO - 2023-02-17 10:38:41 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:41 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:41 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:41 --> URI Class Initialized
INFO - 2023-02-17 10:38:41 --> Router Class Initialized
INFO - 2023-02-17 10:38:41 --> Output Class Initialized
INFO - 2023-02-17 10:38:41 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:41 --> Input Class Initialized
INFO - 2023-02-17 10:38:41 --> Language Class Initialized
INFO - 2023-02-17 10:38:41 --> Loader Class Initialized
INFO - 2023-02-17 10:38:41 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:41 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:41 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:41 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:41 --> Total execution time: 0.0445
INFO - 2023-02-17 10:38:44 --> Config Class Initialized
INFO - 2023-02-17 10:38:44 --> Config Class Initialized
INFO - 2023-02-17 10:38:44 --> Hooks Class Initialized
INFO - 2023-02-17 10:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:44 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:44 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:44 --> URI Class Initialized
INFO - 2023-02-17 10:38:44 --> URI Class Initialized
INFO - 2023-02-17 10:38:44 --> Router Class Initialized
INFO - 2023-02-17 10:38:44 --> Router Class Initialized
INFO - 2023-02-17 10:38:44 --> Output Class Initialized
INFO - 2023-02-17 10:38:44 --> Output Class Initialized
INFO - 2023-02-17 10:38:44 --> Security Class Initialized
INFO - 2023-02-17 10:38:44 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:44 --> Input Class Initialized
INFO - 2023-02-17 10:38:44 --> Input Class Initialized
INFO - 2023-02-17 10:38:44 --> Language Class Initialized
INFO - 2023-02-17 10:38:44 --> Language Class Initialized
INFO - 2023-02-17 10:38:44 --> Loader Class Initialized
INFO - 2023-02-17 10:38:44 --> Loader Class Initialized
INFO - 2023-02-17 10:38:44 --> Controller Class Initialized
INFO - 2023-02-17 10:38:44 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:44 --> Final output sent to browser
INFO - 2023-02-17 10:38:44 --> Database Driver Class Initialized
DEBUG - 2023-02-17 10:38:44 --> Total execution time: 0.0088
INFO - 2023-02-17 10:38:44 --> Config Class Initialized
INFO - 2023-02-17 10:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:44 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:44 --> URI Class Initialized
INFO - 2023-02-17 10:38:44 --> Router Class Initialized
INFO - 2023-02-17 10:38:44 --> Output Class Initialized
INFO - 2023-02-17 10:38:44 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:44 --> Input Class Initialized
INFO - 2023-02-17 10:38:44 --> Language Class Initialized
INFO - 2023-02-17 10:38:44 --> Loader Class Initialized
INFO - 2023-02-17 10:38:44 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:44 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:44 --> Model "Login_model" initialized
INFO - 2023-02-17 10:38:44 --> Final output sent to browser
INFO - 2023-02-17 10:38:44 --> Database Driver Class Initialized
DEBUG - 2023-02-17 10:38:44 --> Total execution time: 0.0248
INFO - 2023-02-17 10:38:44 --> Config Class Initialized
INFO - 2023-02-17 10:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:44 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:44 --> URI Class Initialized
INFO - 2023-02-17 10:38:44 --> Router Class Initialized
INFO - 2023-02-17 10:38:44 --> Output Class Initialized
INFO - 2023-02-17 10:38:44 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:44 --> Input Class Initialized
INFO - 2023-02-17 10:38:44 --> Language Class Initialized
INFO - 2023-02-17 10:38:44 --> Loader Class Initialized
INFO - 2023-02-17 10:38:44 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:44 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:44 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:44 --> Total execution time: 0.0224
INFO - 2023-02-17 10:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:44 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:44 --> Total execution time: 0.0530
INFO - 2023-02-17 10:38:47 --> Config Class Initialized
INFO - 2023-02-17 10:38:47 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:47 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:47 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:47 --> URI Class Initialized
INFO - 2023-02-17 10:38:47 --> Router Class Initialized
INFO - 2023-02-17 10:38:47 --> Output Class Initialized
INFO - 2023-02-17 10:38:47 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:47 --> Input Class Initialized
INFO - 2023-02-17 10:38:47 --> Language Class Initialized
INFO - 2023-02-17 10:38:47 --> Loader Class Initialized
INFO - 2023-02-17 10:38:47 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:47 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:47 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:47 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:47 --> Model "Login_model" initialized
INFO - 2023-02-17 10:38:47 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:47 --> Total execution time: 0.0929
INFO - 2023-02-17 10:38:47 --> Config Class Initialized
INFO - 2023-02-17 10:38:47 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:38:47 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:38:47 --> Utf8 Class Initialized
INFO - 2023-02-17 10:38:47 --> URI Class Initialized
INFO - 2023-02-17 10:38:47 --> Router Class Initialized
INFO - 2023-02-17 10:38:47 --> Output Class Initialized
INFO - 2023-02-17 10:38:47 --> Security Class Initialized
DEBUG - 2023-02-17 10:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:38:47 --> Input Class Initialized
INFO - 2023-02-17 10:38:47 --> Language Class Initialized
INFO - 2023-02-17 10:38:47 --> Loader Class Initialized
INFO - 2023-02-17 10:38:47 --> Controller Class Initialized
DEBUG - 2023-02-17 10:38:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:38:47 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:47 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:38:47 --> Database Driver Class Initialized
INFO - 2023-02-17 10:38:47 --> Model "Login_model" initialized
INFO - 2023-02-17 10:38:47 --> Final output sent to browser
DEBUG - 2023-02-17 10:38:47 --> Total execution time: 0.0473
INFO - 2023-02-17 10:53:08 --> Config Class Initialized
INFO - 2023-02-17 10:53:08 --> Config Class Initialized
INFO - 2023-02-17 10:53:08 --> Hooks Class Initialized
INFO - 2023-02-17 10:53:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:53:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:08 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:08 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:08 --> URI Class Initialized
INFO - 2023-02-17 10:53:08 --> URI Class Initialized
INFO - 2023-02-17 10:53:08 --> Router Class Initialized
INFO - 2023-02-17 10:53:08 --> Router Class Initialized
INFO - 2023-02-17 10:53:08 --> Output Class Initialized
INFO - 2023-02-17 10:53:08 --> Output Class Initialized
INFO - 2023-02-17 10:53:08 --> Security Class Initialized
INFO - 2023-02-17 10:53:08 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:08 --> Input Class Initialized
INFO - 2023-02-17 10:53:08 --> Input Class Initialized
INFO - 2023-02-17 10:53:08 --> Language Class Initialized
INFO - 2023-02-17 10:53:08 --> Language Class Initialized
INFO - 2023-02-17 10:53:08 --> Loader Class Initialized
INFO - 2023-02-17 10:53:08 --> Loader Class Initialized
INFO - 2023-02-17 10:53:08 --> Controller Class Initialized
INFO - 2023-02-17 10:53:08 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:53:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:08 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:08 --> Total execution time: 0.0048
INFO - 2023-02-17 10:53:08 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:08 --> Config Class Initialized
INFO - 2023-02-17 10:53:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:08 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:08 --> URI Class Initialized
INFO - 2023-02-17 10:53:08 --> Router Class Initialized
INFO - 2023-02-17 10:53:08 --> Output Class Initialized
INFO - 2023-02-17 10:53:08 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:08 --> Input Class Initialized
INFO - 2023-02-17 10:53:08 --> Language Class Initialized
INFO - 2023-02-17 10:53:08 --> Loader Class Initialized
INFO - 2023-02-17 10:53:08 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:08 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:08 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:08 --> Total execution time: 0.0211
INFO - 2023-02-17 10:53:08 --> Model "Login_model" initialized
INFO - 2023-02-17 10:53:08 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:08 --> Config Class Initialized
INFO - 2023-02-17 10:53:08 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:08 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:08 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:08 --> URI Class Initialized
INFO - 2023-02-17 10:53:08 --> Router Class Initialized
INFO - 2023-02-17 10:53:08 --> Output Class Initialized
INFO - 2023-02-17 10:53:08 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:08 --> Input Class Initialized
INFO - 2023-02-17 10:53:08 --> Language Class Initialized
INFO - 2023-02-17 10:53:08 --> Loader Class Initialized
INFO - 2023-02-17 10:53:08 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:08 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:08 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:08 --> Total execution time: 0.0292
INFO - 2023-02-17 10:53:08 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:08 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:08 --> Total execution time: 0.0567
INFO - 2023-02-17 10:53:09 --> Config Class Initialized
INFO - 2023-02-17 10:53:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:09 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:09 --> URI Class Initialized
INFO - 2023-02-17 10:53:09 --> Router Class Initialized
INFO - 2023-02-17 10:53:09 --> Output Class Initialized
INFO - 2023-02-17 10:53:09 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:09 --> Input Class Initialized
INFO - 2023-02-17 10:53:09 --> Language Class Initialized
INFO - 2023-02-17 10:53:09 --> Loader Class Initialized
INFO - 2023-02-17 10:53:09 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:09 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:09 --> Total execution time: 0.0758
INFO - 2023-02-17 10:53:09 --> Config Class Initialized
INFO - 2023-02-17 10:53:09 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:09 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:09 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:09 --> URI Class Initialized
INFO - 2023-02-17 10:53:09 --> Router Class Initialized
INFO - 2023-02-17 10:53:09 --> Output Class Initialized
INFO - 2023-02-17 10:53:09 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:09 --> Input Class Initialized
INFO - 2023-02-17 10:53:09 --> Language Class Initialized
INFO - 2023-02-17 10:53:09 --> Loader Class Initialized
INFO - 2023-02-17 10:53:09 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:09 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:09 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:09 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:09 --> Total execution time: 0.0411
INFO - 2023-02-17 10:53:20 --> Config Class Initialized
INFO - 2023-02-17 10:53:20 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:20 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:20 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:20 --> URI Class Initialized
INFO - 2023-02-17 10:53:20 --> Router Class Initialized
INFO - 2023-02-17 10:53:20 --> Output Class Initialized
INFO - 2023-02-17 10:53:20 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:20 --> Input Class Initialized
INFO - 2023-02-17 10:53:20 --> Language Class Initialized
INFO - 2023-02-17 10:53:20 --> Loader Class Initialized
INFO - 2023-02-17 10:53:20 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:20 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:20 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:20 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:20 --> Total execution time: 0.0177
INFO - 2023-02-17 10:53:20 --> Config Class Initialized
INFO - 2023-02-17 10:53:20 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:20 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:20 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:20 --> URI Class Initialized
INFO - 2023-02-17 10:53:20 --> Router Class Initialized
INFO - 2023-02-17 10:53:20 --> Output Class Initialized
INFO - 2023-02-17 10:53:20 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:20 --> Input Class Initialized
INFO - 2023-02-17 10:53:20 --> Language Class Initialized
INFO - 2023-02-17 10:53:20 --> Loader Class Initialized
INFO - 2023-02-17 10:53:20 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:20 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:20 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:20 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:20 --> Total execution time: 0.0108
INFO - 2023-02-17 10:53:23 --> Config Class Initialized
INFO - 2023-02-17 10:53:23 --> Config Class Initialized
INFO - 2023-02-17 10:53:23 --> Hooks Class Initialized
INFO - 2023-02-17 10:53:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2023-02-17 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:23 --> URI Class Initialized
INFO - 2023-02-17 10:53:23 --> URI Class Initialized
INFO - 2023-02-17 10:53:23 --> Router Class Initialized
INFO - 2023-02-17 10:53:23 --> Router Class Initialized
INFO - 2023-02-17 10:53:23 --> Output Class Initialized
INFO - 2023-02-17 10:53:23 --> Output Class Initialized
INFO - 2023-02-17 10:53:23 --> Security Class Initialized
INFO - 2023-02-17 10:53:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-17 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:23 --> Input Class Initialized
INFO - 2023-02-17 10:53:23 --> Input Class Initialized
INFO - 2023-02-17 10:53:23 --> Language Class Initialized
INFO - 2023-02-17 10:53:23 --> Language Class Initialized
INFO - 2023-02-17 10:53:23 --> Loader Class Initialized
INFO - 2023-02-17 10:53:23 --> Loader Class Initialized
INFO - 2023-02-17 10:53:23 --> Controller Class Initialized
INFO - 2023-02-17 10:53:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-17 10:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:23 --> Total execution time: 0.0042
INFO - 2023-02-17 10:53:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:23 --> Config Class Initialized
INFO - 2023-02-17 10:53:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:23 --> URI Class Initialized
INFO - 2023-02-17 10:53:23 --> Router Class Initialized
INFO - 2023-02-17 10:53:23 --> Output Class Initialized
INFO - 2023-02-17 10:53:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:23 --> Input Class Initialized
INFO - 2023-02-17 10:53:23 --> Language Class Initialized
INFO - 2023-02-17 10:53:23 --> Loader Class Initialized
INFO - 2023-02-17 10:53:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:23 --> Model "Login_model" initialized
INFO - 2023-02-17 10:53:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:23 --> Total execution time: 0.0311
INFO - 2023-02-17 10:53:23 --> Config Class Initialized
INFO - 2023-02-17 10:53:23 --> Hooks Class Initialized
DEBUG - 2023-02-17 10:53:23 --> UTF-8 Support Enabled
INFO - 2023-02-17 10:53:23 --> Utf8 Class Initialized
INFO - 2023-02-17 10:53:23 --> URI Class Initialized
INFO - 2023-02-17 10:53:23 --> Router Class Initialized
INFO - 2023-02-17 10:53:23 --> Output Class Initialized
INFO - 2023-02-17 10:53:23 --> Security Class Initialized
DEBUG - 2023-02-17 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-17 10:53:23 --> Input Class Initialized
INFO - 2023-02-17 10:53:23 --> Language Class Initialized
INFO - 2023-02-17 10:53:23 --> Loader Class Initialized
INFO - 2023-02-17 10:53:23 --> Controller Class Initialized
DEBUG - 2023-02-17 10:53:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-17 10:53:23 --> Database Driver Class Initialized
INFO - 2023-02-17 10:53:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:23 --> Total execution time: 0.0325
INFO - 2023-02-17 10:53:23 --> Model "Cluster_model" initialized
INFO - 2023-02-17 10:53:23 --> Final output sent to browser
DEBUG - 2023-02-17 10:53:23 --> Total execution time: 0.0539
