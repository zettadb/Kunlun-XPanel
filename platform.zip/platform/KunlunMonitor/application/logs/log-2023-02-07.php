<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-07 03:03:55 --> Config Class Initialized
INFO - 2023-02-07 03:03:55 --> Hooks Class Initialized
DEBUG - 2023-02-07 03:03:55 --> UTF-8 Support Enabled
INFO - 2023-02-07 03:03:55 --> Utf8 Class Initialized
INFO - 2023-02-07 03:03:55 --> URI Class Initialized
INFO - 2023-02-07 03:03:55 --> Router Class Initialized
INFO - 2023-02-07 03:03:55 --> Output Class Initialized
INFO - 2023-02-07 03:03:55 --> Security Class Initialized
DEBUG - 2023-02-07 03:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 03:03:55 --> Input Class Initialized
INFO - 2023-02-07 03:03:55 --> Language Class Initialized
INFO - 2023-02-07 03:03:55 --> Loader Class Initialized
INFO - 2023-02-07 03:03:55 --> Controller Class Initialized
INFO - 2023-02-07 03:03:55 --> Helper loaded: form_helper
INFO - 2023-02-07 03:03:55 --> Helper loaded: url_helper
DEBUG - 2023-02-07 03:03:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 03:03:55 --> Model "Change_model" initialized
INFO - 2023-02-07 03:04:06 --> Config Class Initialized
INFO - 2023-02-07 03:04:06 --> Hooks Class Initialized
DEBUG - 2023-02-07 03:04:06 --> UTF-8 Support Enabled
INFO - 2023-02-07 03:04:06 --> Utf8 Class Initialized
INFO - 2023-02-07 03:04:06 --> URI Class Initialized
INFO - 2023-02-07 03:04:06 --> Router Class Initialized
INFO - 2023-02-07 03:04:06 --> Output Class Initialized
INFO - 2023-02-07 03:04:06 --> Security Class Initialized
DEBUG - 2023-02-07 03:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 03:04:06 --> Input Class Initialized
INFO - 2023-02-07 03:04:06 --> Language Class Initialized
INFO - 2023-02-07 03:04:06 --> Loader Class Initialized
INFO - 2023-02-07 03:04:06 --> Controller Class Initialized
INFO - 2023-02-07 03:04:06 --> Helper loaded: form_helper
INFO - 2023-02-07 03:04:06 --> Helper loaded: url_helper
DEBUG - 2023-02-07 03:04:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 03:04:06 --> Model "Change_model" initialized
INFO - 2023-02-07 03:05:01 --> Config Class Initialized
INFO - 2023-02-07 03:05:01 --> Hooks Class Initialized
DEBUG - 2023-02-07 03:05:01 --> UTF-8 Support Enabled
INFO - 2023-02-07 03:05:01 --> Utf8 Class Initialized
INFO - 2023-02-07 03:05:01 --> URI Class Initialized
INFO - 2023-02-07 03:05:01 --> Router Class Initialized
INFO - 2023-02-07 03:05:01 --> Output Class Initialized
INFO - 2023-02-07 03:05:01 --> Security Class Initialized
DEBUG - 2023-02-07 03:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 03:05:01 --> Input Class Initialized
INFO - 2023-02-07 03:05:01 --> Language Class Initialized
INFO - 2023-02-07 03:05:01 --> Loader Class Initialized
INFO - 2023-02-07 03:05:01 --> Controller Class Initialized
INFO - 2023-02-07 03:05:01 --> Helper loaded: form_helper
INFO - 2023-02-07 03:05:01 --> Helper loaded: url_helper
DEBUG - 2023-02-07 03:05:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 03:05:01 --> Model "Change_model" initialized
INFO - 2023-02-07 03:05:01 --> Final output sent to browser
DEBUG - 2023-02-07 03:05:01 --> Total execution time: 0.0638
INFO - 2023-02-07 03:48:30 --> Final output sent to browser
INFO - 2023-02-07 03:48:30 --> Final output sent to browser
DEBUG - 2023-02-07 03:48:30 --> Total execution time: 2,674.5842
DEBUG - 2023-02-07 03:48:30 --> Total execution time: 2,663.6215
INFO - 2023-02-07 05:51:41 --> Config Class Initialized
INFO - 2023-02-07 05:51:41 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:41 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:41 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:41 --> URI Class Initialized
INFO - 2023-02-07 05:51:41 --> Router Class Initialized
INFO - 2023-02-07 05:51:41 --> Output Class Initialized
INFO - 2023-02-07 05:51:41 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:41 --> Input Class Initialized
INFO - 2023-02-07 05:51:41 --> Language Class Initialized
INFO - 2023-02-07 05:51:41 --> Loader Class Initialized
INFO - 2023-02-07 05:51:41 --> Controller Class Initialized
INFO - 2023-02-07 05:51:41 --> Helper loaded: form_helper
INFO - 2023-02-07 05:51:41 --> Helper loaded: url_helper
DEBUG - 2023-02-07 05:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:41 --> Model "Change_model" initialized
INFO - 2023-02-07 05:51:41 --> Model "Grafana_model" initialized
INFO - 2023-02-07 05:51:41 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:41 --> Total execution time: 0.0282
INFO - 2023-02-07 05:51:41 --> Config Class Initialized
INFO - 2023-02-07 05:51:41 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:41 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:41 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:41 --> URI Class Initialized
INFO - 2023-02-07 05:51:41 --> Router Class Initialized
INFO - 2023-02-07 05:51:41 --> Output Class Initialized
INFO - 2023-02-07 05:51:41 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:41 --> Input Class Initialized
INFO - 2023-02-07 05:51:41 --> Language Class Initialized
INFO - 2023-02-07 05:51:41 --> Loader Class Initialized
INFO - 2023-02-07 05:51:41 --> Controller Class Initialized
INFO - 2023-02-07 05:51:41 --> Helper loaded: form_helper
INFO - 2023-02-07 05:51:41 --> Helper loaded: url_helper
DEBUG - 2023-02-07 05:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:41 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:41 --> Total execution time: 0.0427
INFO - 2023-02-07 05:51:41 --> Config Class Initialized
INFO - 2023-02-07 05:51:41 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:41 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:41 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:41 --> URI Class Initialized
INFO - 2023-02-07 05:51:41 --> Router Class Initialized
INFO - 2023-02-07 05:51:41 --> Output Class Initialized
INFO - 2023-02-07 05:51:41 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:41 --> Input Class Initialized
INFO - 2023-02-07 05:51:41 --> Language Class Initialized
INFO - 2023-02-07 05:51:41 --> Loader Class Initialized
INFO - 2023-02-07 05:51:41 --> Controller Class Initialized
INFO - 2023-02-07 05:51:41 --> Helper loaded: form_helper
INFO - 2023-02-07 05:51:41 --> Helper loaded: url_helper
DEBUG - 2023-02-07 05:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:41 --> Database Driver Class Initialized
INFO - 2023-02-07 05:51:41 --> Model "Login_model" initialized
INFO - 2023-02-07 05:51:41 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:41 --> Total execution time: 0.0135
INFO - 2023-02-07 05:51:47 --> Config Class Initialized
INFO - 2023-02-07 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:47 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:47 --> URI Class Initialized
INFO - 2023-02-07 05:51:47 --> Router Class Initialized
INFO - 2023-02-07 05:51:47 --> Output Class Initialized
INFO - 2023-02-07 05:51:47 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:47 --> Input Class Initialized
INFO - 2023-02-07 05:51:47 --> Language Class Initialized
INFO - 2023-02-07 05:51:47 --> Loader Class Initialized
INFO - 2023-02-07 05:51:47 --> Controller Class Initialized
INFO - 2023-02-07 05:51:47 --> Helper loaded: form_helper
INFO - 2023-02-07 05:51:47 --> Helper loaded: url_helper
DEBUG - 2023-02-07 05:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:47 --> Model "Change_model" initialized
INFO - 2023-02-07 05:51:47 --> Model "Grafana_model" initialized
INFO - 2023-02-07 05:51:47 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:47 --> Total execution time: 0.0256
INFO - 2023-02-07 05:51:47 --> Config Class Initialized
INFO - 2023-02-07 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:47 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:47 --> URI Class Initialized
INFO - 2023-02-07 05:51:47 --> Router Class Initialized
INFO - 2023-02-07 05:51:47 --> Output Class Initialized
INFO - 2023-02-07 05:51:47 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:47 --> Input Class Initialized
INFO - 2023-02-07 05:51:47 --> Language Class Initialized
INFO - 2023-02-07 05:51:47 --> Loader Class Initialized
INFO - 2023-02-07 05:51:47 --> Controller Class Initialized
INFO - 2023-02-07 05:51:47 --> Helper loaded: form_helper
INFO - 2023-02-07 05:51:47 --> Helper loaded: url_helper
DEBUG - 2023-02-07 05:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:47 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:47 --> Total execution time: 0.0018
INFO - 2023-02-07 05:51:47 --> Config Class Initialized
INFO - 2023-02-07 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:47 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:47 --> URI Class Initialized
INFO - 2023-02-07 05:51:47 --> Router Class Initialized
INFO - 2023-02-07 05:51:47 --> Output Class Initialized
INFO - 2023-02-07 05:51:47 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:47 --> Input Class Initialized
INFO - 2023-02-07 05:51:47 --> Language Class Initialized
INFO - 2023-02-07 05:51:47 --> Loader Class Initialized
INFO - 2023-02-07 05:51:47 --> Controller Class Initialized
INFO - 2023-02-07 05:51:47 --> Helper loaded: form_helper
INFO - 2023-02-07 05:51:47 --> Helper loaded: url_helper
DEBUG - 2023-02-07 05:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:47 --> Database Driver Class Initialized
INFO - 2023-02-07 05:51:47 --> Model "Login_model" initialized
INFO - 2023-02-07 05:51:47 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:47 --> Total execution time: 0.0162
INFO - 2023-02-07 05:51:47 --> Config Class Initialized
INFO - 2023-02-07 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:47 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:47 --> URI Class Initialized
INFO - 2023-02-07 05:51:47 --> Router Class Initialized
INFO - 2023-02-07 05:51:47 --> Output Class Initialized
INFO - 2023-02-07 05:51:47 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:47 --> Input Class Initialized
INFO - 2023-02-07 05:51:47 --> Language Class Initialized
INFO - 2023-02-07 05:51:47 --> Loader Class Initialized
INFO - 2023-02-07 05:51:47 --> Controller Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:47 --> Database Driver Class Initialized
INFO - 2023-02-07 05:51:47 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:51:47 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:47 --> Total execution time: 0.0131
INFO - 2023-02-07 05:51:47 --> Config Class Initialized
INFO - 2023-02-07 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:47 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:47 --> URI Class Initialized
INFO - 2023-02-07 05:51:47 --> Router Class Initialized
INFO - 2023-02-07 05:51:47 --> Output Class Initialized
INFO - 2023-02-07 05:51:47 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:47 --> Input Class Initialized
INFO - 2023-02-07 05:51:47 --> Language Class Initialized
INFO - 2023-02-07 05:51:47 --> Loader Class Initialized
INFO - 2023-02-07 05:51:47 --> Controller Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:47 --> Database Driver Class Initialized
INFO - 2023-02-07 05:51:47 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:51:47 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:47 --> Total execution time: 0.0143
INFO - 2023-02-07 05:51:47 --> Config Class Initialized
INFO - 2023-02-07 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:47 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:47 --> URI Class Initialized
INFO - 2023-02-07 05:51:47 --> Router Class Initialized
INFO - 2023-02-07 05:51:47 --> Output Class Initialized
INFO - 2023-02-07 05:51:47 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:47 --> Input Class Initialized
INFO - 2023-02-07 05:51:47 --> Language Class Initialized
INFO - 2023-02-07 05:51:47 --> Loader Class Initialized
INFO - 2023-02-07 05:51:47 --> Controller Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:47 --> Database Driver Class Initialized
INFO - 2023-02-07 05:51:47 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:51:47 --> Database Driver Class Initialized
INFO - 2023-02-07 05:51:47 --> Model "Login_model" initialized
INFO - 2023-02-07 05:51:47 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:47 --> Total execution time: 0.1179
INFO - 2023-02-07 05:51:47 --> Config Class Initialized
INFO - 2023-02-07 05:51:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:51:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:51:47 --> Utf8 Class Initialized
INFO - 2023-02-07 05:51:47 --> URI Class Initialized
INFO - 2023-02-07 05:51:47 --> Router Class Initialized
INFO - 2023-02-07 05:51:47 --> Output Class Initialized
INFO - 2023-02-07 05:51:47 --> Security Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:51:47 --> Input Class Initialized
INFO - 2023-02-07 05:51:47 --> Language Class Initialized
INFO - 2023-02-07 05:51:47 --> Loader Class Initialized
INFO - 2023-02-07 05:51:47 --> Controller Class Initialized
DEBUG - 2023-02-07 05:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:51:47 --> Database Driver Class Initialized
INFO - 2023-02-07 05:51:47 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:51:47 --> Database Driver Class Initialized
INFO - 2023-02-07 05:51:47 --> Model "Login_model" initialized
INFO - 2023-02-07 05:51:47 --> Final output sent to browser
DEBUG - 2023-02-07 05:51:47 --> Total execution time: 0.0742
INFO - 2023-02-07 05:52:13 --> Config Class Initialized
INFO - 2023-02-07 05:52:13 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:52:13 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:52:13 --> Utf8 Class Initialized
INFO - 2023-02-07 05:52:13 --> URI Class Initialized
INFO - 2023-02-07 05:52:13 --> Router Class Initialized
INFO - 2023-02-07 05:52:13 --> Output Class Initialized
INFO - 2023-02-07 05:52:13 --> Security Class Initialized
DEBUG - 2023-02-07 05:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:52:13 --> Input Class Initialized
INFO - 2023-02-07 05:52:13 --> Language Class Initialized
INFO - 2023-02-07 05:52:13 --> Loader Class Initialized
INFO - 2023-02-07 05:52:13 --> Controller Class Initialized
DEBUG - 2023-02-07 05:52:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:52:13 --> Database Driver Class Initialized
INFO - 2023-02-07 05:52:13 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:52:13 --> Database Driver Class Initialized
INFO - 2023-02-07 05:52:13 --> Model "Login_model" initialized
INFO - 2023-02-07 05:52:13 --> Final output sent to browser
DEBUG - 2023-02-07 05:52:13 --> Total execution time: 0.1171
INFO - 2023-02-07 05:52:13 --> Config Class Initialized
INFO - 2023-02-07 05:52:13 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:52:13 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:52:13 --> Utf8 Class Initialized
INFO - 2023-02-07 05:52:13 --> URI Class Initialized
INFO - 2023-02-07 05:52:13 --> Router Class Initialized
INFO - 2023-02-07 05:52:13 --> Output Class Initialized
INFO - 2023-02-07 05:52:13 --> Security Class Initialized
DEBUG - 2023-02-07 05:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:52:13 --> Input Class Initialized
INFO - 2023-02-07 05:52:13 --> Language Class Initialized
INFO - 2023-02-07 05:52:13 --> Loader Class Initialized
INFO - 2023-02-07 05:52:13 --> Controller Class Initialized
DEBUG - 2023-02-07 05:52:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:52:13 --> Database Driver Class Initialized
INFO - 2023-02-07 05:52:13 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:52:13 --> Database Driver Class Initialized
INFO - 2023-02-07 05:52:13 --> Model "Login_model" initialized
INFO - 2023-02-07 05:52:13 --> Final output sent to browser
DEBUG - 2023-02-07 05:52:13 --> Total execution time: 0.0310
INFO - 2023-02-07 05:53:16 --> Config Class Initialized
INFO - 2023-02-07 05:53:16 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:53:16 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:53:16 --> Utf8 Class Initialized
INFO - 2023-02-07 05:53:16 --> URI Class Initialized
INFO - 2023-02-07 05:53:16 --> Router Class Initialized
INFO - 2023-02-07 05:53:16 --> Output Class Initialized
INFO - 2023-02-07 05:53:16 --> Security Class Initialized
DEBUG - 2023-02-07 05:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:53:16 --> Input Class Initialized
INFO - 2023-02-07 05:53:16 --> Language Class Initialized
INFO - 2023-02-07 05:53:16 --> Loader Class Initialized
INFO - 2023-02-07 05:53:16 --> Controller Class Initialized
DEBUG - 2023-02-07 05:53:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:53:16 --> Database Driver Class Initialized
INFO - 2023-02-07 05:53:16 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:53:16 --> Final output sent to browser
DEBUG - 2023-02-07 05:53:16 --> Total execution time: 0.0394
INFO - 2023-02-07 05:53:16 --> Config Class Initialized
INFO - 2023-02-07 05:53:16 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:53:16 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:53:16 --> Utf8 Class Initialized
INFO - 2023-02-07 05:53:16 --> URI Class Initialized
INFO - 2023-02-07 05:53:16 --> Router Class Initialized
INFO - 2023-02-07 05:53:16 --> Output Class Initialized
INFO - 2023-02-07 05:53:16 --> Security Class Initialized
DEBUG - 2023-02-07 05:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:53:16 --> Input Class Initialized
INFO - 2023-02-07 05:53:16 --> Language Class Initialized
INFO - 2023-02-07 05:53:16 --> Loader Class Initialized
INFO - 2023-02-07 05:53:16 --> Controller Class Initialized
DEBUG - 2023-02-07 05:53:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:53:16 --> Database Driver Class Initialized
INFO - 2023-02-07 05:53:16 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:53:16 --> Final output sent to browser
DEBUG - 2023-02-07 05:53:16 --> Total execution time: 0.0117
INFO - 2023-02-07 05:54:35 --> Config Class Initialized
INFO - 2023-02-07 05:54:35 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:54:35 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:54:35 --> Utf8 Class Initialized
INFO - 2023-02-07 05:54:35 --> URI Class Initialized
INFO - 2023-02-07 05:54:35 --> Router Class Initialized
INFO - 2023-02-07 05:54:35 --> Output Class Initialized
INFO - 2023-02-07 05:54:35 --> Security Class Initialized
DEBUG - 2023-02-07 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:54:35 --> Input Class Initialized
INFO - 2023-02-07 05:54:35 --> Language Class Initialized
INFO - 2023-02-07 05:54:35 --> Loader Class Initialized
INFO - 2023-02-07 05:54:35 --> Controller Class Initialized
DEBUG - 2023-02-07 05:54:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:54:35 --> Database Driver Class Initialized
INFO - 2023-02-07 05:54:35 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:54:35 --> Final output sent to browser
DEBUG - 2023-02-07 05:54:35 --> Total execution time: 0.0247
INFO - 2023-02-07 05:54:35 --> Config Class Initialized
INFO - 2023-02-07 05:54:35 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:54:35 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:54:35 --> Utf8 Class Initialized
INFO - 2023-02-07 05:54:35 --> URI Class Initialized
INFO - 2023-02-07 05:54:35 --> Router Class Initialized
INFO - 2023-02-07 05:54:35 --> Output Class Initialized
INFO - 2023-02-07 05:54:35 --> Security Class Initialized
DEBUG - 2023-02-07 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:54:35 --> Input Class Initialized
INFO - 2023-02-07 05:54:35 --> Language Class Initialized
INFO - 2023-02-07 05:54:35 --> Loader Class Initialized
INFO - 2023-02-07 05:54:35 --> Controller Class Initialized
DEBUG - 2023-02-07 05:54:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:54:35 --> Database Driver Class Initialized
INFO - 2023-02-07 05:54:35 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:54:35 --> Final output sent to browser
DEBUG - 2023-02-07 05:54:35 --> Total execution time: 0.0591
INFO - 2023-02-07 05:54:35 --> Config Class Initialized
INFO - 2023-02-07 05:54:35 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:54:35 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:54:35 --> Utf8 Class Initialized
INFO - 2023-02-07 05:54:35 --> URI Class Initialized
INFO - 2023-02-07 05:54:35 --> Router Class Initialized
INFO - 2023-02-07 05:54:35 --> Output Class Initialized
INFO - 2023-02-07 05:54:35 --> Security Class Initialized
DEBUG - 2023-02-07 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:54:35 --> Input Class Initialized
INFO - 2023-02-07 05:54:35 --> Language Class Initialized
INFO - 2023-02-07 05:54:35 --> Loader Class Initialized
INFO - 2023-02-07 05:54:35 --> Controller Class Initialized
DEBUG - 2023-02-07 05:54:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:54:35 --> Database Driver Class Initialized
INFO - 2023-02-07 05:54:35 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:54:35 --> Final output sent to browser
DEBUG - 2023-02-07 05:54:35 --> Total execution time: 0.0494
INFO - 2023-02-07 05:54:35 --> Config Class Initialized
INFO - 2023-02-07 05:54:35 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:54:35 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:54:35 --> Utf8 Class Initialized
INFO - 2023-02-07 05:54:35 --> URI Class Initialized
INFO - 2023-02-07 05:54:35 --> Router Class Initialized
INFO - 2023-02-07 05:54:35 --> Output Class Initialized
INFO - 2023-02-07 05:54:35 --> Security Class Initialized
DEBUG - 2023-02-07 05:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:54:35 --> Input Class Initialized
INFO - 2023-02-07 05:54:35 --> Language Class Initialized
INFO - 2023-02-07 05:54:35 --> Loader Class Initialized
INFO - 2023-02-07 05:54:35 --> Controller Class Initialized
DEBUG - 2023-02-07 05:54:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:54:35 --> Database Driver Class Initialized
INFO - 2023-02-07 05:54:35 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:54:35 --> Final output sent to browser
DEBUG - 2023-02-07 05:54:35 --> Total execution time: 0.0149
INFO - 2023-02-07 05:56:32 --> Config Class Initialized
INFO - 2023-02-07 05:56:32 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:56:32 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:56:32 --> Utf8 Class Initialized
INFO - 2023-02-07 05:56:32 --> URI Class Initialized
INFO - 2023-02-07 05:56:32 --> Router Class Initialized
INFO - 2023-02-07 05:56:32 --> Output Class Initialized
INFO - 2023-02-07 05:56:32 --> Security Class Initialized
DEBUG - 2023-02-07 05:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:56:32 --> Input Class Initialized
INFO - 2023-02-07 05:56:32 --> Language Class Initialized
INFO - 2023-02-07 05:56:32 --> Loader Class Initialized
INFO - 2023-02-07 05:56:32 --> Controller Class Initialized
DEBUG - 2023-02-07 05:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:56:32 --> Database Driver Class Initialized
INFO - 2023-02-07 05:56:32 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:56:32 --> Final output sent to browser
DEBUG - 2023-02-07 05:56:32 --> Total execution time: 0.0551
INFO - 2023-02-07 05:56:32 --> Config Class Initialized
INFO - 2023-02-07 05:56:32 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:56:32 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:56:32 --> Utf8 Class Initialized
INFO - 2023-02-07 05:56:32 --> URI Class Initialized
INFO - 2023-02-07 05:56:32 --> Router Class Initialized
INFO - 2023-02-07 05:56:32 --> Output Class Initialized
INFO - 2023-02-07 05:56:32 --> Security Class Initialized
DEBUG - 2023-02-07 05:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:56:32 --> Input Class Initialized
INFO - 2023-02-07 05:56:32 --> Language Class Initialized
INFO - 2023-02-07 05:56:32 --> Loader Class Initialized
INFO - 2023-02-07 05:56:32 --> Controller Class Initialized
DEBUG - 2023-02-07 05:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:56:32 --> Database Driver Class Initialized
INFO - 2023-02-07 05:56:32 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:56:33 --> Final output sent to browser
DEBUG - 2023-02-07 05:56:33 --> Total execution time: 0.0168
INFO - 2023-02-07 05:58:42 --> Config Class Initialized
INFO - 2023-02-07 05:58:42 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:58:42 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:58:42 --> Utf8 Class Initialized
INFO - 2023-02-07 05:58:42 --> URI Class Initialized
INFO - 2023-02-07 05:58:42 --> Router Class Initialized
INFO - 2023-02-07 05:58:42 --> Output Class Initialized
INFO - 2023-02-07 05:58:42 --> Security Class Initialized
DEBUG - 2023-02-07 05:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:58:42 --> Input Class Initialized
INFO - 2023-02-07 05:58:42 --> Language Class Initialized
INFO - 2023-02-07 05:58:42 --> Loader Class Initialized
INFO - 2023-02-07 05:58:42 --> Controller Class Initialized
DEBUG - 2023-02-07 05:58:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:58:42 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:42 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:58:42 --> Final output sent to browser
DEBUG - 2023-02-07 05:58:42 --> Total execution time: 0.0529
INFO - 2023-02-07 05:58:42 --> Config Class Initialized
INFO - 2023-02-07 05:58:42 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:58:42 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:58:42 --> Utf8 Class Initialized
INFO - 2023-02-07 05:58:42 --> URI Class Initialized
INFO - 2023-02-07 05:58:42 --> Router Class Initialized
INFO - 2023-02-07 05:58:42 --> Output Class Initialized
INFO - 2023-02-07 05:58:42 --> Security Class Initialized
DEBUG - 2023-02-07 05:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:58:42 --> Input Class Initialized
INFO - 2023-02-07 05:58:42 --> Language Class Initialized
INFO - 2023-02-07 05:58:42 --> Loader Class Initialized
INFO - 2023-02-07 05:58:42 --> Controller Class Initialized
DEBUG - 2023-02-07 05:58:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:58:42 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:42 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:58:42 --> Final output sent to browser
DEBUG - 2023-02-07 05:58:42 --> Total execution time: 0.0113
INFO - 2023-02-07 05:58:48 --> Config Class Initialized
INFO - 2023-02-07 05:58:48 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:58:48 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:58:48 --> Utf8 Class Initialized
INFO - 2023-02-07 05:58:48 --> URI Class Initialized
INFO - 2023-02-07 05:58:48 --> Router Class Initialized
INFO - 2023-02-07 05:58:48 --> Output Class Initialized
INFO - 2023-02-07 05:58:48 --> Security Class Initialized
DEBUG - 2023-02-07 05:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:58:48 --> Input Class Initialized
INFO - 2023-02-07 05:58:48 --> Language Class Initialized
INFO - 2023-02-07 05:58:48 --> Loader Class Initialized
INFO - 2023-02-07 05:58:48 --> Controller Class Initialized
DEBUG - 2023-02-07 05:58:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:58:48 --> Final output sent to browser
DEBUG - 2023-02-07 05:58:48 --> Total execution time: 0.0043
INFO - 2023-02-07 05:58:48 --> Config Class Initialized
INFO - 2023-02-07 05:58:48 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:58:48 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:58:48 --> Utf8 Class Initialized
INFO - 2023-02-07 05:58:48 --> URI Class Initialized
INFO - 2023-02-07 05:58:48 --> Router Class Initialized
INFO - 2023-02-07 05:58:48 --> Output Class Initialized
INFO - 2023-02-07 05:58:48 --> Security Class Initialized
DEBUG - 2023-02-07 05:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:58:48 --> Input Class Initialized
INFO - 2023-02-07 05:58:48 --> Language Class Initialized
INFO - 2023-02-07 05:58:48 --> Loader Class Initialized
INFO - 2023-02-07 05:58:48 --> Controller Class Initialized
DEBUG - 2023-02-07 05:58:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:58:48 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:48 --> Model "Login_model" initialized
INFO - 2023-02-07 05:58:48 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:48 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:58:48 --> Final output sent to browser
DEBUG - 2023-02-07 05:58:48 --> Total execution time: 0.0231
INFO - 2023-02-07 05:58:48 --> Config Class Initialized
INFO - 2023-02-07 05:58:49 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:58:49 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:58:49 --> Utf8 Class Initialized
INFO - 2023-02-07 05:58:49 --> URI Class Initialized
INFO - 2023-02-07 05:58:49 --> Router Class Initialized
INFO - 2023-02-07 05:58:49 --> Output Class Initialized
INFO - 2023-02-07 05:58:49 --> Security Class Initialized
DEBUG - 2023-02-07 05:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:58:49 --> Input Class Initialized
INFO - 2023-02-07 05:58:49 --> Language Class Initialized
INFO - 2023-02-07 05:58:49 --> Loader Class Initialized
INFO - 2023-02-07 05:58:49 --> Controller Class Initialized
DEBUG - 2023-02-07 05:58:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:58:49 --> Final output sent to browser
DEBUG - 2023-02-07 05:58:49 --> Total execution time: 0.0427
INFO - 2023-02-07 05:58:49 --> Config Class Initialized
INFO - 2023-02-07 05:58:49 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:58:49 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:58:49 --> Utf8 Class Initialized
INFO - 2023-02-07 05:58:49 --> URI Class Initialized
INFO - 2023-02-07 05:58:49 --> Router Class Initialized
INFO - 2023-02-07 05:58:49 --> Output Class Initialized
INFO - 2023-02-07 05:58:49 --> Security Class Initialized
DEBUG - 2023-02-07 05:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:58:49 --> Input Class Initialized
INFO - 2023-02-07 05:58:49 --> Language Class Initialized
INFO - 2023-02-07 05:58:49 --> Loader Class Initialized
INFO - 2023-02-07 05:58:49 --> Controller Class Initialized
DEBUG - 2023-02-07 05:58:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:58:49 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:49 --> Model "Login_model" initialized
INFO - 2023-02-07 05:58:49 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:49 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:58:49 --> Final output sent to browser
DEBUG - 2023-02-07 05:58:49 --> Total execution time: 0.0200
INFO - 2023-02-07 05:58:50 --> Config Class Initialized
INFO - 2023-02-07 05:58:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:58:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:58:50 --> Utf8 Class Initialized
INFO - 2023-02-07 05:58:50 --> URI Class Initialized
INFO - 2023-02-07 05:58:50 --> Router Class Initialized
INFO - 2023-02-07 05:58:50 --> Output Class Initialized
INFO - 2023-02-07 05:58:50 --> Security Class Initialized
DEBUG - 2023-02-07 05:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:58:50 --> Input Class Initialized
INFO - 2023-02-07 05:58:50 --> Language Class Initialized
INFO - 2023-02-07 05:58:50 --> Loader Class Initialized
INFO - 2023-02-07 05:58:50 --> Controller Class Initialized
DEBUG - 2023-02-07 05:58:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:58:50 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:50 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:58:50 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:50 --> Model "Login_model" initialized
INFO - 2023-02-07 05:58:50 --> Final output sent to browser
DEBUG - 2023-02-07 05:58:50 --> Total execution time: 0.0549
INFO - 2023-02-07 05:58:50 --> Config Class Initialized
INFO - 2023-02-07 05:58:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:58:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:58:50 --> Utf8 Class Initialized
INFO - 2023-02-07 05:58:50 --> URI Class Initialized
INFO - 2023-02-07 05:58:50 --> Router Class Initialized
INFO - 2023-02-07 05:58:50 --> Output Class Initialized
INFO - 2023-02-07 05:58:50 --> Security Class Initialized
DEBUG - 2023-02-07 05:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:58:50 --> Input Class Initialized
INFO - 2023-02-07 05:58:50 --> Language Class Initialized
INFO - 2023-02-07 05:58:50 --> Loader Class Initialized
INFO - 2023-02-07 05:58:50 --> Controller Class Initialized
DEBUG - 2023-02-07 05:58:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:58:50 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:50 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:58:50 --> Database Driver Class Initialized
INFO - 2023-02-07 05:58:50 --> Model "Login_model" initialized
INFO - 2023-02-07 05:58:50 --> Final output sent to browser
DEBUG - 2023-02-07 05:58:50 --> Total execution time: 0.0333
INFO - 2023-02-07 05:59:46 --> Config Class Initialized
INFO - 2023-02-07 05:59:46 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:46 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:46 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:46 --> URI Class Initialized
INFO - 2023-02-07 05:59:46 --> Router Class Initialized
INFO - 2023-02-07 05:59:46 --> Output Class Initialized
INFO - 2023-02-07 05:59:46 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:46 --> Input Class Initialized
INFO - 2023-02-07 05:59:46 --> Language Class Initialized
INFO - 2023-02-07 05:59:46 --> Loader Class Initialized
INFO - 2023-02-07 05:59:46 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:46 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:46 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:46 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:46 --> Total execution time: 0.0158
INFO - 2023-02-07 05:59:46 --> Config Class Initialized
INFO - 2023-02-07 05:59:46 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:46 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:46 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:46 --> URI Class Initialized
INFO - 2023-02-07 05:59:46 --> Router Class Initialized
INFO - 2023-02-07 05:59:46 --> Output Class Initialized
INFO - 2023-02-07 05:59:46 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:46 --> Input Class Initialized
INFO - 2023-02-07 05:59:46 --> Language Class Initialized
INFO - 2023-02-07 05:59:46 --> Loader Class Initialized
INFO - 2023-02-07 05:59:46 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:46 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:46 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:46 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:46 --> Total execution time: 0.0574
INFO - 2023-02-07 05:59:48 --> Config Class Initialized
INFO - 2023-02-07 05:59:48 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:48 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:48 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:48 --> URI Class Initialized
INFO - 2023-02-07 05:59:48 --> Router Class Initialized
INFO - 2023-02-07 05:59:48 --> Output Class Initialized
INFO - 2023-02-07 05:59:48 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:48 --> Input Class Initialized
INFO - 2023-02-07 05:59:48 --> Language Class Initialized
INFO - 2023-02-07 05:59:48 --> Loader Class Initialized
INFO - 2023-02-07 05:59:48 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:48 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:48 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:48 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:48 --> Total execution time: 0.0246
INFO - 2023-02-07 05:59:48 --> Config Class Initialized
INFO - 2023-02-07 05:59:48 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:48 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:48 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:48 --> URI Class Initialized
INFO - 2023-02-07 05:59:48 --> Router Class Initialized
INFO - 2023-02-07 05:59:48 --> Output Class Initialized
INFO - 2023-02-07 05:59:48 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:48 --> Input Class Initialized
INFO - 2023-02-07 05:59:48 --> Language Class Initialized
INFO - 2023-02-07 05:59:48 --> Loader Class Initialized
INFO - 2023-02-07 05:59:48 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:48 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:48 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:48 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:48 --> Total execution time: 0.0679
INFO - 2023-02-07 05:59:50 --> Config Class Initialized
INFO - 2023-02-07 05:59:50 --> Config Class Initialized
INFO - 2023-02-07 05:59:50 --> Hooks Class Initialized
INFO - 2023-02-07 05:59:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2023-02-07 05:59:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:50 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:50 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:50 --> URI Class Initialized
INFO - 2023-02-07 05:59:50 --> URI Class Initialized
INFO - 2023-02-07 05:59:50 --> Router Class Initialized
INFO - 2023-02-07 05:59:50 --> Router Class Initialized
INFO - 2023-02-07 05:59:50 --> Output Class Initialized
INFO - 2023-02-07 05:59:50 --> Output Class Initialized
INFO - 2023-02-07 05:59:50 --> Security Class Initialized
INFO - 2023-02-07 05:59:50 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-07 05:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:50 --> Input Class Initialized
INFO - 2023-02-07 05:59:50 --> Input Class Initialized
INFO - 2023-02-07 05:59:50 --> Language Class Initialized
INFO - 2023-02-07 05:59:50 --> Language Class Initialized
INFO - 2023-02-07 05:59:50 --> Loader Class Initialized
INFO - 2023-02-07 05:59:50 --> Loader Class Initialized
INFO - 2023-02-07 05:59:50 --> Controller Class Initialized
INFO - 2023-02-07 05:59:50 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-07 05:59:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:50 --> Final output sent to browser
INFO - 2023-02-07 05:59:50 --> Database Driver Class Initialized
DEBUG - 2023-02-07 05:59:50 --> Total execution time: 0.0442
INFO - 2023-02-07 05:59:50 --> Config Class Initialized
INFO - 2023-02-07 05:59:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:50 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:50 --> URI Class Initialized
INFO - 2023-02-07 05:59:50 --> Router Class Initialized
INFO - 2023-02-07 05:59:50 --> Output Class Initialized
INFO - 2023-02-07 05:59:50 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:50 --> Input Class Initialized
INFO - 2023-02-07 05:59:50 --> Language Class Initialized
INFO - 2023-02-07 05:59:50 --> Loader Class Initialized
INFO - 2023-02-07 05:59:50 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:50 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:50 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:50 --> Model "Login_model" initialized
INFO - 2023-02-07 05:59:50 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:50 --> Total execution time: 0.0590
INFO - 2023-02-07 05:59:50 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:50 --> Config Class Initialized
INFO - 2023-02-07 05:59:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:50 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:50 --> URI Class Initialized
INFO - 2023-02-07 05:59:50 --> Router Class Initialized
INFO - 2023-02-07 05:59:50 --> Output Class Initialized
INFO - 2023-02-07 05:59:50 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:50 --> Input Class Initialized
INFO - 2023-02-07 05:59:50 --> Language Class Initialized
INFO - 2023-02-07 05:59:50 --> Loader Class Initialized
INFO - 2023-02-07 05:59:50 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:50 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:50 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:50 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:50 --> Total execution time: 0.0245
INFO - 2023-02-07 05:59:50 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:50 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:50 --> Total execution time: 0.0579
INFO - 2023-02-07 05:59:51 --> Config Class Initialized
INFO - 2023-02-07 05:59:51 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:51 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:51 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:51 --> URI Class Initialized
INFO - 2023-02-07 05:59:51 --> Router Class Initialized
INFO - 2023-02-07 05:59:51 --> Output Class Initialized
INFO - 2023-02-07 05:59:51 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:51 --> Input Class Initialized
INFO - 2023-02-07 05:59:51 --> Language Class Initialized
INFO - 2023-02-07 05:59:51 --> Loader Class Initialized
INFO - 2023-02-07 05:59:51 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:51 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:51 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:51 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:51 --> Total execution time: 0.0277
INFO - 2023-02-07 05:59:57 --> Config Class Initialized
INFO - 2023-02-07 05:59:57 --> Config Class Initialized
INFO - 2023-02-07 05:59:57 --> Hooks Class Initialized
INFO - 2023-02-07 05:59:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:57 --> UTF-8 Support Enabled
DEBUG - 2023-02-07 05:59:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:57 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:57 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:57 --> URI Class Initialized
INFO - 2023-02-07 05:59:57 --> URI Class Initialized
INFO - 2023-02-07 05:59:57 --> Router Class Initialized
INFO - 2023-02-07 05:59:57 --> Router Class Initialized
INFO - 2023-02-07 05:59:57 --> Output Class Initialized
INFO - 2023-02-07 05:59:57 --> Output Class Initialized
INFO - 2023-02-07 05:59:57 --> Security Class Initialized
INFO - 2023-02-07 05:59:57 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-07 05:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:57 --> Input Class Initialized
INFO - 2023-02-07 05:59:57 --> Input Class Initialized
INFO - 2023-02-07 05:59:57 --> Language Class Initialized
INFO - 2023-02-07 05:59:57 --> Language Class Initialized
INFO - 2023-02-07 05:59:57 --> Loader Class Initialized
INFO - 2023-02-07 05:59:57 --> Loader Class Initialized
INFO - 2023-02-07 05:59:57 --> Controller Class Initialized
INFO - 2023-02-07 05:59:57 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-07 05:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:57 --> Final output sent to browser
INFO - 2023-02-07 05:59:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 05:59:57 --> Total execution time: 0.0053
INFO - 2023-02-07 05:59:57 --> Config Class Initialized
INFO - 2023-02-07 05:59:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:57 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:57 --> URI Class Initialized
INFO - 2023-02-07 05:59:57 --> Router Class Initialized
INFO - 2023-02-07 05:59:57 --> Output Class Initialized
INFO - 2023-02-07 05:59:57 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:57 --> Input Class Initialized
INFO - 2023-02-07 05:59:57 --> Language Class Initialized
INFO - 2023-02-07 05:59:57 --> Loader Class Initialized
INFO - 2023-02-07 05:59:57 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:57 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:57 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:57 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:57 --> Total execution time: 0.0174
INFO - 2023-02-07 05:59:57 --> Model "Login_model" initialized
INFO - 2023-02-07 05:59:57 --> Config Class Initialized
INFO - 2023-02-07 05:59:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:57 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:57 --> URI Class Initialized
INFO - 2023-02-07 05:59:57 --> Router Class Initialized
INFO - 2023-02-07 05:59:57 --> Output Class Initialized
INFO - 2023-02-07 05:59:57 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:57 --> Input Class Initialized
INFO - 2023-02-07 05:59:57 --> Language Class Initialized
INFO - 2023-02-07 05:59:57 --> Loader Class Initialized
INFO - 2023-02-07 05:59:57 --> Controller Class Initialized
INFO - 2023-02-07 05:59:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 05:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:57 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:57 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:57 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:57 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:57 --> Total execution time: 0.0226
INFO - 2023-02-07 05:59:57 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:57 --> Total execution time: 0.0147
INFO - 2023-02-07 05:59:59 --> Config Class Initialized
INFO - 2023-02-07 05:59:59 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:59 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:59 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:59 --> URI Class Initialized
INFO - 2023-02-07 05:59:59 --> Router Class Initialized
INFO - 2023-02-07 05:59:59 --> Output Class Initialized
INFO - 2023-02-07 05:59:59 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:59 --> Input Class Initialized
INFO - 2023-02-07 05:59:59 --> Language Class Initialized
INFO - 2023-02-07 05:59:59 --> Loader Class Initialized
INFO - 2023-02-07 05:59:59 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:59 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:59 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:59 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:59 --> Model "Login_model" initialized
INFO - 2023-02-07 05:59:59 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:59 --> Total execution time: 0.0524
INFO - 2023-02-07 05:59:59 --> Config Class Initialized
INFO - 2023-02-07 05:59:59 --> Hooks Class Initialized
DEBUG - 2023-02-07 05:59:59 --> UTF-8 Support Enabled
INFO - 2023-02-07 05:59:59 --> Utf8 Class Initialized
INFO - 2023-02-07 05:59:59 --> URI Class Initialized
INFO - 2023-02-07 05:59:59 --> Router Class Initialized
INFO - 2023-02-07 05:59:59 --> Output Class Initialized
INFO - 2023-02-07 05:59:59 --> Security Class Initialized
DEBUG - 2023-02-07 05:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 05:59:59 --> Input Class Initialized
INFO - 2023-02-07 05:59:59 --> Language Class Initialized
INFO - 2023-02-07 05:59:59 --> Loader Class Initialized
INFO - 2023-02-07 05:59:59 --> Controller Class Initialized
DEBUG - 2023-02-07 05:59:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 05:59:59 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:59 --> Model "Cluster_model" initialized
INFO - 2023-02-07 05:59:59 --> Database Driver Class Initialized
INFO - 2023-02-07 05:59:59 --> Model "Login_model" initialized
INFO - 2023-02-07 05:59:59 --> Final output sent to browser
DEBUG - 2023-02-07 05:59:59 --> Total execution time: 0.0316
INFO - 2023-02-07 06:00:00 --> Config Class Initialized
INFO - 2023-02-07 06:00:00 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:00 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:00 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:00 --> URI Class Initialized
INFO - 2023-02-07 06:00:00 --> Router Class Initialized
INFO - 2023-02-07 06:00:00 --> Output Class Initialized
INFO - 2023-02-07 06:00:00 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:00 --> Input Class Initialized
INFO - 2023-02-07 06:00:00 --> Language Class Initialized
INFO - 2023-02-07 06:00:00 --> Loader Class Initialized
INFO - 2023-02-07 06:00:00 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:00 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:00 --> Model "Cluster_model" initialized
INFO - 2023-02-07 06:00:00 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:00 --> Total execution time: 0.0149
INFO - 2023-02-07 06:00:00 --> Config Class Initialized
INFO - 2023-02-07 06:00:00 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:00 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:00 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:00 --> URI Class Initialized
INFO - 2023-02-07 06:00:00 --> Router Class Initialized
INFO - 2023-02-07 06:00:00 --> Output Class Initialized
INFO - 2023-02-07 06:00:00 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:00 --> Input Class Initialized
INFO - 2023-02-07 06:00:00 --> Language Class Initialized
INFO - 2023-02-07 06:00:00 --> Loader Class Initialized
INFO - 2023-02-07 06:00:00 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:00 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:00 --> Model "Cluster_model" initialized
INFO - 2023-02-07 06:00:00 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:00 --> Total execution time: 0.0511
INFO - 2023-02-07 06:00:02 --> Config Class Initialized
INFO - 2023-02-07 06:00:02 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:02 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:02 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:02 --> URI Class Initialized
INFO - 2023-02-07 06:00:02 --> Router Class Initialized
INFO - 2023-02-07 06:00:02 --> Output Class Initialized
INFO - 2023-02-07 06:00:02 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:02 --> Input Class Initialized
INFO - 2023-02-07 06:00:02 --> Language Class Initialized
INFO - 2023-02-07 06:00:02 --> Loader Class Initialized
INFO - 2023-02-07 06:00:02 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:02 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:02 --> Model "Cluster_model" initialized
INFO - 2023-02-07 06:00:02 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:02 --> Total execution time: 0.0637
INFO - 2023-02-07 06:00:02 --> Config Class Initialized
INFO - 2023-02-07 06:00:02 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:02 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:02 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:02 --> URI Class Initialized
INFO - 2023-02-07 06:00:02 --> Router Class Initialized
INFO - 2023-02-07 06:00:02 --> Output Class Initialized
INFO - 2023-02-07 06:00:02 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:02 --> Input Class Initialized
INFO - 2023-02-07 06:00:02 --> Language Class Initialized
INFO - 2023-02-07 06:00:02 --> Loader Class Initialized
INFO - 2023-02-07 06:00:02 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:02 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:02 --> Model "Cluster_model" initialized
INFO - 2023-02-07 06:00:02 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:02 --> Total execution time: 0.0151
INFO - 2023-02-07 06:00:06 --> Config Class Initialized
INFO - 2023-02-07 06:00:06 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:06 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:06 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:06 --> URI Class Initialized
INFO - 2023-02-07 06:00:06 --> Router Class Initialized
INFO - 2023-02-07 06:00:06 --> Output Class Initialized
INFO - 2023-02-07 06:00:06 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:06 --> Input Class Initialized
INFO - 2023-02-07 06:00:06 --> Language Class Initialized
INFO - 2023-02-07 06:00:06 --> Loader Class Initialized
INFO - 2023-02-07 06:00:06 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:06 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:06 --> Model "Cluster_model" initialized
INFO - 2023-02-07 06:00:06 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:06 --> Total execution time: 0.0204
INFO - 2023-02-07 06:00:06 --> Config Class Initialized
INFO - 2023-02-07 06:00:06 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:06 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:06 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:06 --> URI Class Initialized
INFO - 2023-02-07 06:00:06 --> Router Class Initialized
INFO - 2023-02-07 06:00:06 --> Output Class Initialized
INFO - 2023-02-07 06:00:06 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:06 --> Input Class Initialized
INFO - 2023-02-07 06:00:06 --> Language Class Initialized
INFO - 2023-02-07 06:00:06 --> Loader Class Initialized
INFO - 2023-02-07 06:00:06 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:06 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:06 --> Model "Cluster_model" initialized
INFO - 2023-02-07 06:00:06 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:06 --> Total execution time: 0.0574
INFO - 2023-02-07 06:00:16 --> Config Class Initialized
INFO - 2023-02-07 06:00:16 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:16 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:16 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:16 --> URI Class Initialized
INFO - 2023-02-07 06:00:16 --> Router Class Initialized
INFO - 2023-02-07 06:00:16 --> Output Class Initialized
INFO - 2023-02-07 06:00:16 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:16 --> Input Class Initialized
INFO - 2023-02-07 06:00:16 --> Language Class Initialized
INFO - 2023-02-07 06:00:16 --> Loader Class Initialized
INFO - 2023-02-07 06:00:16 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:16 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:16 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:16 --> Model "Login_model" initialized
INFO - 2023-02-07 06:00:16 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:16 --> Total execution time: 0.0259
INFO - 2023-02-07 06:00:16 --> Config Class Initialized
INFO - 2023-02-07 06:00:16 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:16 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:16 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:16 --> URI Class Initialized
INFO - 2023-02-07 06:00:16 --> Router Class Initialized
INFO - 2023-02-07 06:00:16 --> Output Class Initialized
INFO - 2023-02-07 06:00:16 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:16 --> Input Class Initialized
INFO - 2023-02-07 06:00:16 --> Language Class Initialized
INFO - 2023-02-07 06:00:16 --> Loader Class Initialized
INFO - 2023-02-07 06:00:16 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:16 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:16 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:16 --> Model "Login_model" initialized
INFO - 2023-02-07 06:00:16 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:16 --> Total execution time: 0.0642
INFO - 2023-02-07 06:00:18 --> Config Class Initialized
INFO - 2023-02-07 06:00:18 --> Config Class Initialized
INFO - 2023-02-07 06:00:18 --> Config Class Initialized
INFO - 2023-02-07 06:00:18 --> Hooks Class Initialized
INFO - 2023-02-07 06:00:18 --> Hooks Class Initialized
INFO - 2023-02-07 06:00:18 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-07 06:00:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-07 06:00:18 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:18 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:18 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:18 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:18 --> URI Class Initialized
INFO - 2023-02-07 06:00:18 --> URI Class Initialized
INFO - 2023-02-07 06:00:18 --> URI Class Initialized
INFO - 2023-02-07 06:00:18 --> Router Class Initialized
INFO - 2023-02-07 06:00:18 --> Router Class Initialized
INFO - 2023-02-07 06:00:18 --> Router Class Initialized
INFO - 2023-02-07 06:00:18 --> Output Class Initialized
INFO - 2023-02-07 06:00:18 --> Output Class Initialized
INFO - 2023-02-07 06:00:18 --> Output Class Initialized
INFO - 2023-02-07 06:00:18 --> Security Class Initialized
INFO - 2023-02-07 06:00:18 --> Security Class Initialized
INFO - 2023-02-07 06:00:18 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-07 06:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-07 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:18 --> Input Class Initialized
INFO - 2023-02-07 06:00:18 --> Input Class Initialized
INFO - 2023-02-07 06:00:18 --> Input Class Initialized
INFO - 2023-02-07 06:00:18 --> Language Class Initialized
INFO - 2023-02-07 06:00:18 --> Language Class Initialized
INFO - 2023-02-07 06:00:18 --> Language Class Initialized
INFO - 2023-02-07 06:00:18 --> Loader Class Initialized
INFO - 2023-02-07 06:00:18 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Loader Class Initialized
INFO - 2023-02-07 06:00:18 --> Controller Class Initialized
INFO - 2023-02-07 06:00:18 --> Loader Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:18 --> Controller Class Initialized
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Model "Login_model" initialized
INFO - 2023-02-07 06:00:18 --> Final output sent to browser
INFO - 2023-02-07 06:00:18 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:18 --> Total execution time: 0.0176
DEBUG - 2023-02-07 06:00:18 --> Total execution time: 0.0176
INFO - 2023-02-07 06:00:18 --> Config Class Initialized
INFO - 2023-02-07 06:00:18 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:18 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:18 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:18 --> Config Class Initialized
INFO - 2023-02-07 06:00:18 --> Final output sent to browser
INFO - 2023-02-07 06:00:18 --> URI Class Initialized
INFO - 2023-02-07 06:00:18 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Total execution time: 0.0222
INFO - 2023-02-07 06:00:18 --> Router Class Initialized
DEBUG - 2023-02-07 06:00:18 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:18 --> Output Class Initialized
INFO - 2023-02-07 06:00:18 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:18 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:18 --> URI Class Initialized
INFO - 2023-02-07 06:00:18 --> Input Class Initialized
INFO - 2023-02-07 06:00:18 --> Router Class Initialized
INFO - 2023-02-07 06:00:18 --> Language Class Initialized
INFO - 2023-02-07 06:00:18 --> Output Class Initialized
INFO - 2023-02-07 06:00:18 --> Config Class Initialized
INFO - 2023-02-07 06:00:18 --> Loader Class Initialized
INFO - 2023-02-07 06:00:18 --> Security Class Initialized
INFO - 2023-02-07 06:00:18 --> Hooks Class Initialized
INFO - 2023-02-07 06:00:18 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-07 06:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-07 06:00:18 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:18 --> Final output sent to browser
INFO - 2023-02-07 06:00:18 --> Input Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Total execution time: 0.0847
INFO - 2023-02-07 06:00:18 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:18 --> Language Class Initialized
INFO - 2023-02-07 06:00:18 --> URI Class Initialized
INFO - 2023-02-07 06:00:18 --> Config Class Initialized
INFO - 2023-02-07 06:00:18 --> Router Class Initialized
INFO - 2023-02-07 06:00:18 --> Loader Class Initialized
INFO - 2023-02-07 06:00:18 --> Hooks Class Initialized
INFO - 2023-02-07 06:00:18 --> Output Class Initialized
INFO - 2023-02-07 06:00:18 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:18 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:18 --> Security Class Initialized
INFO - 2023-02-07 06:00:18 --> Utf8 Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-07 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:18 --> URI Class Initialized
INFO - 2023-02-07 06:00:18 --> Input Class Initialized
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Router Class Initialized
INFO - 2023-02-07 06:00:18 --> Language Class Initialized
INFO - 2023-02-07 06:00:18 --> Output Class Initialized
INFO - 2023-02-07 06:00:18 --> Loader Class Initialized
INFO - 2023-02-07 06:00:18 --> Security Class Initialized
INFO - 2023-02-07 06:00:18 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-07 06:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:18 --> Input Class Initialized
INFO - 2023-02-07 06:00:18 --> Language Class Initialized
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Loader Class Initialized
INFO - 2023-02-07 06:00:18 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Model "Login_model" initialized
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Model "Login_model" initialized
INFO - 2023-02-07 06:00:18 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:18 --> Total execution time: 0.0195
INFO - 2023-02-07 06:00:18 --> Config Class Initialized
INFO - 2023-02-07 06:00:18 --> Model "Login_model" initialized
INFO - 2023-02-07 06:00:18 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:18 --> Total execution time: 0.1469
INFO - 2023-02-07 06:00:18 --> Hooks Class Initialized
DEBUG - 2023-02-07 06:00:18 --> UTF-8 Support Enabled
INFO - 2023-02-07 06:00:18 --> Utf8 Class Initialized
INFO - 2023-02-07 06:00:18 --> URI Class Initialized
INFO - 2023-02-07 06:00:18 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:18 --> Total execution time: 0.1069
INFO - 2023-02-07 06:00:18 --> Router Class Initialized
INFO - 2023-02-07 06:00:18 --> Output Class Initialized
INFO - 2023-02-07 06:00:18 --> Security Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 06:00:18 --> Input Class Initialized
INFO - 2023-02-07 06:00:18 --> Language Class Initialized
INFO - 2023-02-07 06:00:18 --> Loader Class Initialized
INFO - 2023-02-07 06:00:18 --> Controller Class Initialized
DEBUG - 2023-02-07 06:00:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Model "Login_model" initialized
INFO - 2023-02-07 06:00:18 --> Database Driver Class Initialized
INFO - 2023-02-07 06:00:18 --> Model "Cluster_model" initialized
INFO - 2023-02-07 06:00:18 --> Final output sent to browser
DEBUG - 2023-02-07 06:00:18 --> Total execution time: 0.1421
