<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-04 01:59:21 --> Config Class Initialized
INFO - 2023-03-04 01:59:21 --> Hooks Class Initialized
DEBUG - 2023-03-04 01:59:21 --> UTF-8 Support Enabled
INFO - 2023-03-04 01:59:21 --> Utf8 Class Initialized
INFO - 2023-03-04 01:59:21 --> URI Class Initialized
INFO - 2023-03-04 01:59:21 --> Router Class Initialized
INFO - 2023-03-04 01:59:21 --> Output Class Initialized
INFO - 2023-03-04 01:59:21 --> Security Class Initialized
DEBUG - 2023-03-04 01:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-04 01:59:21 --> Input Class Initialized
INFO - 2023-03-04 01:59:21 --> Language Class Initialized
INFO - 2023-03-04 01:59:21 --> Loader Class Initialized
INFO - 2023-03-04 01:59:21 --> Controller Class Initialized
DEBUG - 2023-03-04 01:59:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-04 01:59:21 --> Database Driver Class Initialized
ERROR - 2023-03-04 01:59:26 --> Unable to connect to the database
INFO - 2023-03-04 01:59:26 --> Language file loaded: language/english/db_lang.php
