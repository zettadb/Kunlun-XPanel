<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-12 12:45:49 --> Config Class Initialized
INFO - 2023-03-12 12:45:49 --> Hooks Class Initialized
DEBUG - 2023-03-12 12:45:49 --> UTF-8 Support Enabled
INFO - 2023-03-12 12:45:49 --> Utf8 Class Initialized
INFO - 2023-03-12 12:45:49 --> URI Class Initialized
INFO - 2023-03-12 12:45:49 --> Router Class Initialized
INFO - 2023-03-12 12:45:49 --> Output Class Initialized
INFO - 2023-03-12 12:45:49 --> Security Class Initialized
DEBUG - 2023-03-12 12:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 12:45:49 --> Input Class Initialized
INFO - 2023-03-12 12:45:49 --> Language Class Initialized
INFO - 2023-03-12 12:45:49 --> Loader Class Initialized
INFO - 2023-03-12 12:45:49 --> Controller Class Initialized
INFO - 2023-03-12 12:45:49 --> Helper loaded: form_helper
INFO - 2023-03-12 12:45:49 --> Helper loaded: url_helper
DEBUG - 2023-03-12 12:45:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 12:45:49 --> Model "Change_model" initialized
INFO - 2023-03-12 12:47:42 --> Config Class Initialized
INFO - 2023-03-12 12:47:42 --> Hooks Class Initialized
DEBUG - 2023-03-12 12:47:42 --> UTF-8 Support Enabled
INFO - 2023-03-12 12:47:42 --> Utf8 Class Initialized
INFO - 2023-03-12 12:47:42 --> URI Class Initialized
INFO - 2023-03-12 12:47:42 --> Router Class Initialized
INFO - 2023-03-12 12:47:42 --> Output Class Initialized
INFO - 2023-03-12 12:47:42 --> Security Class Initialized
DEBUG - 2023-03-12 12:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 12:47:42 --> Input Class Initialized
INFO - 2023-03-12 12:47:42 --> Language Class Initialized
INFO - 2023-03-12 12:47:42 --> Loader Class Initialized
INFO - 2023-03-12 12:47:42 --> Controller Class Initialized
INFO - 2023-03-12 12:47:42 --> Helper loaded: form_helper
INFO - 2023-03-12 12:47:42 --> Helper loaded: url_helper
DEBUG - 2023-03-12 12:47:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 12:47:42 --> Model "Change_model" initialized
INFO - 2023-03-12 12:47:42 --> Model "Grafana_model" initialized
INFO - 2023-03-12 12:47:43 --> Final output sent to browser
DEBUG - 2023-03-12 12:47:43 --> Total execution time: 0.8924
INFO - 2023-03-12 12:47:43 --> Config Class Initialized
INFO - 2023-03-12 12:47:43 --> Hooks Class Initialized
DEBUG - 2023-03-12 12:47:43 --> UTF-8 Support Enabled
INFO - 2023-03-12 12:47:43 --> Utf8 Class Initialized
INFO - 2023-03-12 12:47:43 --> URI Class Initialized
INFO - 2023-03-12 12:47:43 --> Router Class Initialized
INFO - 2023-03-12 12:47:43 --> Output Class Initialized
INFO - 2023-03-12 12:47:43 --> Security Class Initialized
DEBUG - 2023-03-12 12:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 12:47:43 --> Input Class Initialized
INFO - 2023-03-12 12:47:43 --> Language Class Initialized
INFO - 2023-03-12 12:47:43 --> Loader Class Initialized
INFO - 2023-03-12 12:47:43 --> Controller Class Initialized
INFO - 2023-03-12 12:47:43 --> Helper loaded: form_helper
INFO - 2023-03-12 12:47:43 --> Helper loaded: url_helper
DEBUG - 2023-03-12 12:47:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 12:47:43 --> Final output sent to browser
DEBUG - 2023-03-12 12:47:43 --> Total execution time: 0.0042
INFO - 2023-03-12 12:47:43 --> Config Class Initialized
INFO - 2023-03-12 12:47:43 --> Hooks Class Initialized
DEBUG - 2023-03-12 12:47:43 --> UTF-8 Support Enabled
INFO - 2023-03-12 12:47:43 --> Utf8 Class Initialized
INFO - 2023-03-12 12:47:43 --> URI Class Initialized
INFO - 2023-03-12 12:47:43 --> Router Class Initialized
INFO - 2023-03-12 12:47:43 --> Output Class Initialized
INFO - 2023-03-12 12:47:43 --> Security Class Initialized
DEBUG - 2023-03-12 12:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 12:47:43 --> Input Class Initialized
INFO - 2023-03-12 12:47:43 --> Language Class Initialized
INFO - 2023-03-12 12:47:43 --> Loader Class Initialized
INFO - 2023-03-12 12:47:43 --> Controller Class Initialized
INFO - 2023-03-12 12:47:43 --> Helper loaded: form_helper
INFO - 2023-03-12 12:47:43 --> Helper loaded: url_helper
DEBUG - 2023-03-12 12:47:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 12:47:43 --> Database Driver Class Initialized
ERROR - 2023-03-12 12:47:53 --> Unable to connect to the database
INFO - 2023-03-12 12:47:53 --> Model "Login_model" initialized
ERROR - 2023-03-12 12:48:03 --> Unable to connect to the database
ERROR - 2023-03-12 12:48:03 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-03-12 12:48:03 --> Final output sent to browser
DEBUG - 2023-03-12 12:48:03 --> Total execution time: 20.0206
INFO - 2023-03-12 12:48:23 --> Config Class Initialized
INFO - 2023-03-12 12:48:23 --> Hooks Class Initialized
DEBUG - 2023-03-12 12:48:23 --> UTF-8 Support Enabled
INFO - 2023-03-12 12:48:23 --> Utf8 Class Initialized
INFO - 2023-03-12 12:48:23 --> URI Class Initialized
INFO - 2023-03-12 12:48:23 --> Router Class Initialized
INFO - 2023-03-12 12:48:23 --> Output Class Initialized
INFO - 2023-03-12 12:48:23 --> Security Class Initialized
DEBUG - 2023-03-12 12:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 12:48:23 --> Input Class Initialized
INFO - 2023-03-12 12:48:23 --> Language Class Initialized
INFO - 2023-03-12 12:48:23 --> Loader Class Initialized
INFO - 2023-03-12 12:48:23 --> Controller Class Initialized
INFO - 2023-03-12 12:48:23 --> Helper loaded: form_helper
INFO - 2023-03-12 12:48:23 --> Helper loaded: url_helper
DEBUG - 2023-03-12 12:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 12:48:23 --> Model "Change_model" initialized
INFO - 2023-03-12 12:48:23 --> Model "Grafana_model" initialized
INFO - 2023-03-12 12:48:23 --> Final output sent to browser
DEBUG - 2023-03-12 12:48:23 --> Total execution time: 0.6955
INFO - 2023-03-12 12:48:23 --> Config Class Initialized
INFO - 2023-03-12 12:48:23 --> Hooks Class Initialized
DEBUG - 2023-03-12 12:48:23 --> UTF-8 Support Enabled
INFO - 2023-03-12 12:48:23 --> Utf8 Class Initialized
INFO - 2023-03-12 12:48:23 --> URI Class Initialized
INFO - 2023-03-12 12:48:23 --> Router Class Initialized
INFO - 2023-03-12 12:48:23 --> Output Class Initialized
INFO - 2023-03-12 12:48:23 --> Security Class Initialized
DEBUG - 2023-03-12 12:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 12:48:23 --> Input Class Initialized
INFO - 2023-03-12 12:48:23 --> Language Class Initialized
INFO - 2023-03-12 12:48:23 --> Loader Class Initialized
INFO - 2023-03-12 12:48:23 --> Controller Class Initialized
INFO - 2023-03-12 12:48:23 --> Helper loaded: form_helper
INFO - 2023-03-12 12:48:23 --> Helper loaded: url_helper
DEBUG - 2023-03-12 12:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 12:48:23 --> Final output sent to browser
DEBUG - 2023-03-12 12:48:23 --> Total execution time: 0.0045
INFO - 2023-03-12 12:48:23 --> Config Class Initialized
INFO - 2023-03-12 12:48:23 --> Hooks Class Initialized
DEBUG - 2023-03-12 12:48:23 --> UTF-8 Support Enabled
INFO - 2023-03-12 12:48:23 --> Utf8 Class Initialized
INFO - 2023-03-12 12:48:23 --> URI Class Initialized
INFO - 2023-03-12 12:48:23 --> Router Class Initialized
INFO - 2023-03-12 12:48:23 --> Output Class Initialized
INFO - 2023-03-12 12:48:23 --> Security Class Initialized
DEBUG - 2023-03-12 12:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 12:48:23 --> Input Class Initialized
INFO - 2023-03-12 12:48:23 --> Language Class Initialized
INFO - 2023-03-12 12:48:23 --> Loader Class Initialized
INFO - 2023-03-12 12:48:23 --> Controller Class Initialized
INFO - 2023-03-12 12:48:23 --> Helper loaded: form_helper
INFO - 2023-03-12 12:48:23 --> Helper loaded: url_helper
DEBUG - 2023-03-12 12:48:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 12:48:23 --> Database Driver Class Initialized
ERROR - 2023-03-12 12:48:33 --> Unable to connect to the database
INFO - 2023-03-12 12:48:33 --> Model "Login_model" initialized
ERROR - 2023-03-12 12:48:43 --> Unable to connect to the database
ERROR - 2023-03-12 12:48:43 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-03-12 12:48:43 --> Final output sent to browser
DEBUG - 2023-03-12 12:48:43 --> Total execution time: 20.0088
INFO - 2023-03-12 12:48:49 --> Final output sent to browser
DEBUG - 2023-03-12 12:48:49 --> Total execution time: 180.0578
INFO - 2023-03-12 13:03:14 --> Config Class Initialized
INFO - 2023-03-12 13:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-12 13:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-12 13:03:14 --> Utf8 Class Initialized
INFO - 2023-03-12 13:03:14 --> URI Class Initialized
INFO - 2023-03-12 13:03:14 --> Router Class Initialized
INFO - 2023-03-12 13:03:14 --> Output Class Initialized
INFO - 2023-03-12 13:03:14 --> Security Class Initialized
DEBUG - 2023-03-12 13:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 13:03:14 --> Input Class Initialized
INFO - 2023-03-12 13:03:14 --> Language Class Initialized
INFO - 2023-03-12 13:03:14 --> Loader Class Initialized
INFO - 2023-03-12 13:03:14 --> Controller Class Initialized
INFO - 2023-03-12 13:03:14 --> Helper loaded: form_helper
INFO - 2023-03-12 13:03:14 --> Helper loaded: url_helper
DEBUG - 2023-03-12 13:03:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 13:03:14 --> Model "Change_model" initialized
INFO - 2023-03-12 13:03:14 --> Model "Grafana_model" initialized
INFO - 2023-03-12 13:03:15 --> Final output sent to browser
DEBUG - 2023-03-12 13:03:15 --> Total execution time: 0.8799
INFO - 2023-03-12 13:03:15 --> Config Class Initialized
INFO - 2023-03-12 13:03:15 --> Hooks Class Initialized
DEBUG - 2023-03-12 13:03:15 --> UTF-8 Support Enabled
INFO - 2023-03-12 13:03:15 --> Utf8 Class Initialized
INFO - 2023-03-12 13:03:15 --> URI Class Initialized
INFO - 2023-03-12 13:03:15 --> Router Class Initialized
INFO - 2023-03-12 13:03:15 --> Output Class Initialized
INFO - 2023-03-12 13:03:15 --> Security Class Initialized
DEBUG - 2023-03-12 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 13:03:15 --> Input Class Initialized
INFO - 2023-03-12 13:03:15 --> Language Class Initialized
INFO - 2023-03-12 13:03:15 --> Loader Class Initialized
INFO - 2023-03-12 13:03:15 --> Controller Class Initialized
INFO - 2023-03-12 13:03:15 --> Helper loaded: form_helper
INFO - 2023-03-12 13:03:15 --> Helper loaded: url_helper
DEBUG - 2023-03-12 13:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 13:03:15 --> Final output sent to browser
DEBUG - 2023-03-12 13:03:15 --> Total execution time: 0.0020
INFO - 2023-03-12 13:03:15 --> Config Class Initialized
INFO - 2023-03-12 13:03:15 --> Hooks Class Initialized
DEBUG - 2023-03-12 13:03:15 --> UTF-8 Support Enabled
INFO - 2023-03-12 13:03:15 --> Utf8 Class Initialized
INFO - 2023-03-12 13:03:15 --> URI Class Initialized
INFO - 2023-03-12 13:03:15 --> Router Class Initialized
INFO - 2023-03-12 13:03:15 --> Output Class Initialized
INFO - 2023-03-12 13:03:15 --> Security Class Initialized
DEBUG - 2023-03-12 13:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 13:03:15 --> Input Class Initialized
INFO - 2023-03-12 13:03:15 --> Language Class Initialized
INFO - 2023-03-12 13:03:15 --> Loader Class Initialized
INFO - 2023-03-12 13:03:15 --> Controller Class Initialized
INFO - 2023-03-12 13:03:15 --> Helper loaded: form_helper
INFO - 2023-03-12 13:03:15 --> Helper loaded: url_helper
DEBUG - 2023-03-12 13:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 13:03:15 --> Database Driver Class Initialized
ERROR - 2023-03-12 13:03:25 --> Unable to connect to the database
INFO - 2023-03-12 13:03:25 --> Model "Login_model" initialized
ERROR - 2023-03-12 13:03:35 --> Unable to connect to the database
ERROR - 2023-03-12 13:03:35 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-03-12 13:03:35 --> Final output sent to browser
DEBUG - 2023-03-12 13:03:35 --> Total execution time: 20.0060
INFO - 2023-03-12 13:22:06 --> Config Class Initialized
INFO - 2023-03-12 13:22:06 --> Hooks Class Initialized
DEBUG - 2023-03-12 13:22:06 --> UTF-8 Support Enabled
INFO - 2023-03-12 13:22:06 --> Utf8 Class Initialized
INFO - 2023-03-12 13:22:06 --> URI Class Initialized
INFO - 2023-03-12 13:22:06 --> Router Class Initialized
INFO - 2023-03-12 13:22:06 --> Output Class Initialized
INFO - 2023-03-12 13:22:06 --> Security Class Initialized
DEBUG - 2023-03-12 13:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 13:22:06 --> Input Class Initialized
INFO - 2023-03-12 13:22:06 --> Language Class Initialized
INFO - 2023-03-12 13:22:06 --> Loader Class Initialized
INFO - 2023-03-12 13:22:06 --> Controller Class Initialized
INFO - 2023-03-12 13:22:06 --> Helper loaded: form_helper
INFO - 2023-03-12 13:22:06 --> Helper loaded: url_helper
DEBUG - 2023-03-12 13:22:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 13:22:06 --> Model "Change_model" initialized
INFO - 2023-03-12 13:22:06 --> Model "Grafana_model" initialized
INFO - 2023-03-12 13:22:06 --> Final output sent to browser
DEBUG - 2023-03-12 13:22:06 --> Total execution time: 0.8623
INFO - 2023-03-12 13:22:06 --> Config Class Initialized
INFO - 2023-03-12 13:22:06 --> Hooks Class Initialized
DEBUG - 2023-03-12 13:22:06 --> UTF-8 Support Enabled
INFO - 2023-03-12 13:22:06 --> Utf8 Class Initialized
INFO - 2023-03-12 13:22:06 --> URI Class Initialized
INFO - 2023-03-12 13:22:06 --> Router Class Initialized
INFO - 2023-03-12 13:22:06 --> Output Class Initialized
INFO - 2023-03-12 13:22:06 --> Security Class Initialized
DEBUG - 2023-03-12 13:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 13:22:06 --> Input Class Initialized
INFO - 2023-03-12 13:22:06 --> Language Class Initialized
INFO - 2023-03-12 13:22:06 --> Loader Class Initialized
INFO - 2023-03-12 13:22:06 --> Controller Class Initialized
INFO - 2023-03-12 13:22:06 --> Helper loaded: form_helper
INFO - 2023-03-12 13:22:06 --> Helper loaded: url_helper
DEBUG - 2023-03-12 13:22:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 13:22:06 --> Final output sent to browser
DEBUG - 2023-03-12 13:22:06 --> Total execution time: 0.0836
INFO - 2023-03-12 13:22:06 --> Config Class Initialized
INFO - 2023-03-12 13:22:06 --> Hooks Class Initialized
DEBUG - 2023-03-12 13:22:06 --> UTF-8 Support Enabled
INFO - 2023-03-12 13:22:06 --> Utf8 Class Initialized
INFO - 2023-03-12 13:22:06 --> URI Class Initialized
INFO - 2023-03-12 13:22:06 --> Router Class Initialized
INFO - 2023-03-12 13:22:06 --> Output Class Initialized
INFO - 2023-03-12 13:22:06 --> Security Class Initialized
DEBUG - 2023-03-12 13:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 13:22:06 --> Input Class Initialized
INFO - 2023-03-12 13:22:06 --> Language Class Initialized
INFO - 2023-03-12 13:22:06 --> Loader Class Initialized
INFO - 2023-03-12 13:22:06 --> Controller Class Initialized
INFO - 2023-03-12 13:22:06 --> Helper loaded: form_helper
INFO - 2023-03-12 13:22:06 --> Helper loaded: url_helper
DEBUG - 2023-03-12 13:22:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 13:22:06 --> Database Driver Class Initialized
ERROR - 2023-03-12 13:22:16 --> Unable to connect to the database
INFO - 2023-03-12 13:22:16 --> Model "Login_model" initialized
ERROR - 2023-03-12 13:22:27 --> Unable to connect to the database
ERROR - 2023-03-12 13:22:27 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-03-12 13:22:27 --> Final output sent to browser
DEBUG - 2023-03-12 13:22:27 --> Total execution time: 20.0289
INFO - 2023-03-12 14:33:35 --> Config Class Initialized
INFO - 2023-03-12 14:33:35 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:33:35 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:33:35 --> Utf8 Class Initialized
INFO - 2023-03-12 14:33:35 --> URI Class Initialized
INFO - 2023-03-12 14:33:35 --> Router Class Initialized
INFO - 2023-03-12 14:33:35 --> Output Class Initialized
INFO - 2023-03-12 14:33:35 --> Security Class Initialized
DEBUG - 2023-03-12 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:33:35 --> Input Class Initialized
INFO - 2023-03-12 14:33:35 --> Language Class Initialized
INFO - 2023-03-12 14:33:35 --> Loader Class Initialized
INFO - 2023-03-12 14:33:35 --> Controller Class Initialized
INFO - 2023-03-12 14:33:35 --> Helper loaded: form_helper
INFO - 2023-03-12 14:33:35 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:33:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:33:35 --> Model "Change_model" initialized
INFO - 2023-03-12 14:33:35 --> Model "Grafana_model" initialized
INFO - 2023-03-12 14:33:35 --> Final output sent to browser
DEBUG - 2023-03-12 14:33:35 --> Total execution time: 0.8421
INFO - 2023-03-12 14:33:35 --> Config Class Initialized
INFO - 2023-03-12 14:33:35 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:33:35 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:33:35 --> Utf8 Class Initialized
INFO - 2023-03-12 14:33:35 --> URI Class Initialized
INFO - 2023-03-12 14:33:35 --> Router Class Initialized
INFO - 2023-03-12 14:33:35 --> Output Class Initialized
INFO - 2023-03-12 14:33:35 --> Security Class Initialized
DEBUG - 2023-03-12 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:33:35 --> Input Class Initialized
INFO - 2023-03-12 14:33:35 --> Language Class Initialized
INFO - 2023-03-12 14:33:35 --> Loader Class Initialized
INFO - 2023-03-12 14:33:35 --> Controller Class Initialized
INFO - 2023-03-12 14:33:35 --> Helper loaded: form_helper
INFO - 2023-03-12 14:33:35 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:33:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:33:35 --> Final output sent to browser
DEBUG - 2023-03-12 14:33:35 --> Total execution time: 0.0039
INFO - 2023-03-12 14:33:35 --> Config Class Initialized
INFO - 2023-03-12 14:33:35 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:33:35 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:33:35 --> Utf8 Class Initialized
INFO - 2023-03-12 14:33:35 --> URI Class Initialized
INFO - 2023-03-12 14:33:35 --> Router Class Initialized
INFO - 2023-03-12 14:33:35 --> Output Class Initialized
INFO - 2023-03-12 14:33:35 --> Security Class Initialized
DEBUG - 2023-03-12 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:33:35 --> Input Class Initialized
INFO - 2023-03-12 14:33:35 --> Language Class Initialized
INFO - 2023-03-12 14:33:35 --> Loader Class Initialized
INFO - 2023-03-12 14:33:35 --> Controller Class Initialized
INFO - 2023-03-12 14:33:35 --> Helper loaded: form_helper
INFO - 2023-03-12 14:33:35 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:33:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:33:35 --> Database Driver Class Initialized
ERROR - 2023-03-12 14:33:45 --> Unable to connect to the database
INFO - 2023-03-12 14:33:45 --> Model "Login_model" initialized
ERROR - 2023-03-12 14:33:55 --> Unable to connect to the database
ERROR - 2023-03-12 14:33:56 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-03-12 14:33:56 --> Final output sent to browser
DEBUG - 2023-03-12 14:33:56 --> Total execution time: 20.1583
INFO - 2023-03-12 14:34:49 --> Config Class Initialized
INFO - 2023-03-12 14:34:49 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:34:49 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:34:49 --> Utf8 Class Initialized
INFO - 2023-03-12 14:34:49 --> URI Class Initialized
INFO - 2023-03-12 14:34:49 --> Router Class Initialized
INFO - 2023-03-12 14:34:49 --> Output Class Initialized
INFO - 2023-03-12 14:34:49 --> Security Class Initialized
DEBUG - 2023-03-12 14:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:34:49 --> Input Class Initialized
INFO - 2023-03-12 14:34:49 --> Language Class Initialized
INFO - 2023-03-12 14:34:49 --> Loader Class Initialized
INFO - 2023-03-12 14:34:49 --> Controller Class Initialized
INFO - 2023-03-12 14:34:49 --> Helper loaded: form_helper
INFO - 2023-03-12 14:34:49 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:34:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:34:49 --> Final output sent to browser
DEBUG - 2023-03-12 14:34:49 --> Total execution time: 0.0860
INFO - 2023-03-12 14:34:50 --> Config Class Initialized
INFO - 2023-03-12 14:34:50 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:34:50 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:34:50 --> Utf8 Class Initialized
INFO - 2023-03-12 14:34:50 --> URI Class Initialized
INFO - 2023-03-12 14:34:50 --> Router Class Initialized
INFO - 2023-03-12 14:34:50 --> Output Class Initialized
INFO - 2023-03-12 14:34:50 --> Security Class Initialized
DEBUG - 2023-03-12 14:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:34:50 --> Input Class Initialized
INFO - 2023-03-12 14:34:50 --> Language Class Initialized
ERROR - 2023-03-12 14:34:50 --> 404 Page Not Found: Faviconico/index
INFO - 2023-03-12 14:34:55 --> Config Class Initialized
INFO - 2023-03-12 14:34:55 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:34:55 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:34:55 --> Utf8 Class Initialized
INFO - 2023-03-12 14:34:55 --> URI Class Initialized
INFO - 2023-03-12 14:34:55 --> Router Class Initialized
INFO - 2023-03-12 14:34:55 --> Output Class Initialized
INFO - 2023-03-12 14:34:55 --> Security Class Initialized
DEBUG - 2023-03-12 14:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:34:55 --> Input Class Initialized
INFO - 2023-03-12 14:34:55 --> Language Class Initialized
INFO - 2023-03-12 14:34:55 --> Loader Class Initialized
INFO - 2023-03-12 14:34:55 --> Controller Class Initialized
INFO - 2023-03-12 14:34:55 --> Helper loaded: form_helper
INFO - 2023-03-12 14:34:55 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:34:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:34:55 --> Model "Change_model" initialized
INFO - 2023-03-12 14:34:55 --> Model "Grafana_model" initialized
INFO - 2023-03-12 14:34:56 --> Final output sent to browser
DEBUG - 2023-03-12 14:34:56 --> Total execution time: 0.7602
INFO - 2023-03-12 14:34:56 --> Config Class Initialized
INFO - 2023-03-12 14:34:56 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:34:56 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:34:56 --> Utf8 Class Initialized
INFO - 2023-03-12 14:34:56 --> URI Class Initialized
INFO - 2023-03-12 14:34:56 --> Router Class Initialized
INFO - 2023-03-12 14:34:56 --> Output Class Initialized
INFO - 2023-03-12 14:34:56 --> Security Class Initialized
DEBUG - 2023-03-12 14:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:34:56 --> Input Class Initialized
INFO - 2023-03-12 14:34:56 --> Language Class Initialized
INFO - 2023-03-12 14:34:56 --> Loader Class Initialized
INFO - 2023-03-12 14:34:56 --> Controller Class Initialized
INFO - 2023-03-12 14:34:56 --> Helper loaded: form_helper
INFO - 2023-03-12 14:34:56 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:34:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:34:56 --> Final output sent to browser
DEBUG - 2023-03-12 14:34:56 --> Total execution time: 0.0039
INFO - 2023-03-12 14:34:56 --> Config Class Initialized
INFO - 2023-03-12 14:34:56 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:34:56 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:34:56 --> Utf8 Class Initialized
INFO - 2023-03-12 14:34:56 --> URI Class Initialized
INFO - 2023-03-12 14:34:56 --> Router Class Initialized
INFO - 2023-03-12 14:34:56 --> Output Class Initialized
INFO - 2023-03-12 14:34:56 --> Security Class Initialized
DEBUG - 2023-03-12 14:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:34:56 --> Input Class Initialized
INFO - 2023-03-12 14:34:56 --> Language Class Initialized
INFO - 2023-03-12 14:34:56 --> Loader Class Initialized
INFO - 2023-03-12 14:34:56 --> Controller Class Initialized
INFO - 2023-03-12 14:34:56 --> Helper loaded: form_helper
INFO - 2023-03-12 14:34:56 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:34:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:34:56 --> Database Driver Class Initialized
ERROR - 2023-03-12 14:35:06 --> Unable to connect to the database
INFO - 2023-03-12 14:35:06 --> Model "Login_model" initialized
ERROR - 2023-03-12 14:35:16 --> Unable to connect to the database
ERROR - 2023-03-12 14:35:16 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-03-12 14:35:16 --> Final output sent to browser
DEBUG - 2023-03-12 14:35:16 --> Total execution time: 20.0074
INFO - 2023-03-12 14:41:57 --> Config Class Initialized
INFO - 2023-03-12 14:41:57 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:41:57 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:41:57 --> Utf8 Class Initialized
INFO - 2023-03-12 14:41:57 --> URI Class Initialized
INFO - 2023-03-12 14:41:57 --> Router Class Initialized
INFO - 2023-03-12 14:41:57 --> Output Class Initialized
INFO - 2023-03-12 14:41:57 --> Security Class Initialized
DEBUG - 2023-03-12 14:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:41:57 --> Input Class Initialized
INFO - 2023-03-12 14:41:57 --> Language Class Initialized
INFO - 2023-03-12 14:41:57 --> Loader Class Initialized
INFO - 2023-03-12 14:41:57 --> Controller Class Initialized
INFO - 2023-03-12 14:41:57 --> Helper loaded: form_helper
INFO - 2023-03-12 14:41:57 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:41:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:41:57 --> Model "Change_model" initialized
INFO - 2023-03-12 14:42:05 --> Model "Grafana_model" initialized
INFO - 2023-03-12 14:42:07 --> Final output sent to browser
DEBUG - 2023-03-12 14:42:07 --> Total execution time: 10.7619
INFO - 2023-03-12 14:42:07 --> Config Class Initialized
INFO - 2023-03-12 14:42:07 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:42:07 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:42:07 --> Utf8 Class Initialized
INFO - 2023-03-12 14:42:07 --> URI Class Initialized
INFO - 2023-03-12 14:42:07 --> Router Class Initialized
INFO - 2023-03-12 14:42:07 --> Output Class Initialized
INFO - 2023-03-12 14:42:07 --> Security Class Initialized
DEBUG - 2023-03-12 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:42:07 --> Input Class Initialized
INFO - 2023-03-12 14:42:07 --> Language Class Initialized
INFO - 2023-03-12 14:42:07 --> Loader Class Initialized
INFO - 2023-03-12 14:42:07 --> Controller Class Initialized
INFO - 2023-03-12 14:42:07 --> Helper loaded: form_helper
INFO - 2023-03-12 14:42:07 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:42:07 --> Final output sent to browser
DEBUG - 2023-03-12 14:42:07 --> Total execution time: 0.0052
INFO - 2023-03-12 14:42:07 --> Config Class Initialized
INFO - 2023-03-12 14:42:07 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:42:07 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:42:07 --> Utf8 Class Initialized
INFO - 2023-03-12 14:42:07 --> URI Class Initialized
INFO - 2023-03-12 14:42:07 --> Router Class Initialized
INFO - 2023-03-12 14:42:07 --> Output Class Initialized
INFO - 2023-03-12 14:42:07 --> Security Class Initialized
DEBUG - 2023-03-12 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:42:07 --> Input Class Initialized
INFO - 2023-03-12 14:42:07 --> Language Class Initialized
INFO - 2023-03-12 14:42:07 --> Loader Class Initialized
INFO - 2023-03-12 14:42:07 --> Controller Class Initialized
INFO - 2023-03-12 14:42:07 --> Helper loaded: form_helper
INFO - 2023-03-12 14:42:07 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:42:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:42:07 --> Database Driver Class Initialized
ERROR - 2023-03-12 14:42:17 --> Unable to connect to the database
INFO - 2023-03-12 14:42:17 --> Model "Login_model" initialized
ERROR - 2023-03-12 14:42:27 --> Unable to connect to the database
ERROR - 2023-03-12 14:42:27 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-03-12 14:42:27 --> Final output sent to browser
DEBUG - 2023-03-12 14:42:27 --> Total execution time: 20.0069
INFO - 2023-03-12 14:44:04 --> Config Class Initialized
INFO - 2023-03-12 14:44:04 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:44:04 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:44:04 --> Utf8 Class Initialized
INFO - 2023-03-12 14:44:04 --> URI Class Initialized
INFO - 2023-03-12 14:44:04 --> Router Class Initialized
INFO - 2023-03-12 14:44:04 --> Output Class Initialized
INFO - 2023-03-12 14:44:04 --> Security Class Initialized
DEBUG - 2023-03-12 14:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:44:04 --> Input Class Initialized
INFO - 2023-03-12 14:44:04 --> Language Class Initialized
INFO - 2023-03-12 14:44:04 --> Loader Class Initialized
INFO - 2023-03-12 14:44:04 --> Controller Class Initialized
INFO - 2023-03-12 14:44:04 --> Helper loaded: form_helper
INFO - 2023-03-12 14:44:04 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:44:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:44:04 --> Model "Change_model" initialized
INFO - 2023-03-12 14:44:07 --> Model "Grafana_model" initialized
INFO - 2023-03-12 14:44:08 --> Final output sent to browser
DEBUG - 2023-03-12 14:44:08 --> Total execution time: 4.4328
INFO - 2023-03-12 14:44:08 --> Config Class Initialized
INFO - 2023-03-12 14:44:08 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:44:08 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:44:08 --> Utf8 Class Initialized
INFO - 2023-03-12 14:44:08 --> URI Class Initialized
INFO - 2023-03-12 14:44:08 --> Router Class Initialized
INFO - 2023-03-12 14:44:08 --> Output Class Initialized
INFO - 2023-03-12 14:44:08 --> Security Class Initialized
DEBUG - 2023-03-12 14:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:44:08 --> Input Class Initialized
INFO - 2023-03-12 14:44:08 --> Language Class Initialized
INFO - 2023-03-12 14:44:08 --> Loader Class Initialized
INFO - 2023-03-12 14:44:08 --> Controller Class Initialized
INFO - 2023-03-12 14:44:08 --> Helper loaded: form_helper
INFO - 2023-03-12 14:44:08 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:44:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:44:08 --> Final output sent to browser
DEBUG - 2023-03-12 14:44:08 --> Total execution time: 0.0435
INFO - 2023-03-12 14:44:08 --> Config Class Initialized
INFO - 2023-03-12 14:44:08 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:44:08 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:44:08 --> Utf8 Class Initialized
INFO - 2023-03-12 14:44:08 --> URI Class Initialized
INFO - 2023-03-12 14:44:08 --> Router Class Initialized
INFO - 2023-03-12 14:44:08 --> Output Class Initialized
INFO - 2023-03-12 14:44:08 --> Security Class Initialized
DEBUG - 2023-03-12 14:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:44:08 --> Input Class Initialized
INFO - 2023-03-12 14:44:08 --> Language Class Initialized
INFO - 2023-03-12 14:44:08 --> Loader Class Initialized
INFO - 2023-03-12 14:44:08 --> Controller Class Initialized
INFO - 2023-03-12 14:44:08 --> Helper loaded: form_helper
INFO - 2023-03-12 14:44:08 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:44:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:44:08 --> Database Driver Class Initialized
ERROR - 2023-03-12 14:44:18 --> Unable to connect to the database
INFO - 2023-03-12 14:44:18 --> Model "Login_model" initialized
ERROR - 2023-03-12 14:44:28 --> Unable to connect to the database
ERROR - 2023-03-12 14:44:28 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='halfeng' and password='Aa_12345';
INFO - 2023-03-12 14:44:28 --> Final output sent to browser
DEBUG - 2023-03-12 14:44:28 --> Total execution time: 20.0066
INFO - 2023-03-12 14:45:04 --> Config Class Initialized
INFO - 2023-03-12 14:45:04 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:45:04 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:45:04 --> Utf8 Class Initialized
INFO - 2023-03-12 14:45:04 --> URI Class Initialized
INFO - 2023-03-12 14:45:04 --> Router Class Initialized
INFO - 2023-03-12 14:45:04 --> Output Class Initialized
INFO - 2023-03-12 14:45:04 --> Security Class Initialized
DEBUG - 2023-03-12 14:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:45:04 --> Input Class Initialized
INFO - 2023-03-12 14:45:04 --> Language Class Initialized
INFO - 2023-03-12 14:45:04 --> Loader Class Initialized
INFO - 2023-03-12 14:45:04 --> Controller Class Initialized
INFO - 2023-03-12 14:45:04 --> Helper loaded: form_helper
INFO - 2023-03-12 14:45:04 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:45:04 --> Model "Change_model" initialized
INFO - 2023-03-12 14:45:05 --> Model "Grafana_model" initialized
INFO - 2023-03-12 14:45:05 --> Final output sent to browser
DEBUG - 2023-03-12 14:45:05 --> Total execution time: 0.8696
INFO - 2023-03-12 14:45:05 --> Config Class Initialized
INFO - 2023-03-12 14:45:05 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:45:05 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:45:05 --> Utf8 Class Initialized
INFO - 2023-03-12 14:45:05 --> URI Class Initialized
INFO - 2023-03-12 14:45:05 --> Router Class Initialized
INFO - 2023-03-12 14:45:05 --> Output Class Initialized
INFO - 2023-03-12 14:45:05 --> Security Class Initialized
DEBUG - 2023-03-12 14:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:45:05 --> Input Class Initialized
INFO - 2023-03-12 14:45:05 --> Language Class Initialized
INFO - 2023-03-12 14:45:05 --> Loader Class Initialized
INFO - 2023-03-12 14:45:05 --> Controller Class Initialized
INFO - 2023-03-12 14:45:05 --> Helper loaded: form_helper
INFO - 2023-03-12 14:45:05 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:45:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:45:05 --> Final output sent to browser
DEBUG - 2023-03-12 14:45:05 --> Total execution time: 0.0026
INFO - 2023-03-12 14:45:05 --> Config Class Initialized
INFO - 2023-03-12 14:45:05 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:45:05 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:45:05 --> Utf8 Class Initialized
INFO - 2023-03-12 14:45:05 --> URI Class Initialized
INFO - 2023-03-12 14:45:05 --> Router Class Initialized
INFO - 2023-03-12 14:45:05 --> Output Class Initialized
INFO - 2023-03-12 14:45:05 --> Security Class Initialized
DEBUG - 2023-03-12 14:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:45:05 --> Input Class Initialized
INFO - 2023-03-12 14:45:05 --> Language Class Initialized
INFO - 2023-03-12 14:45:05 --> Loader Class Initialized
INFO - 2023-03-12 14:45:05 --> Controller Class Initialized
INFO - 2023-03-12 14:45:05 --> Helper loaded: form_helper
INFO - 2023-03-12 14:45:05 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:45:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:45:05 --> Database Driver Class Initialized
ERROR - 2023-03-12 14:45:15 --> Unable to connect to the database
INFO - 2023-03-12 14:45:15 --> Model "Login_model" initialized
ERROR - 2023-03-12 14:45:25 --> Unable to connect to the database
ERROR - 2023-03-12 14:45:25 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='halfeng' and password='Aa_12345';
INFO - 2023-03-12 14:45:25 --> Final output sent to browser
DEBUG - 2023-03-12 14:45:25 --> Total execution time: 20.0108
INFO - 2023-03-12 14:45:35 --> Config Class Initialized
INFO - 2023-03-12 14:45:35 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:45:35 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:45:35 --> Utf8 Class Initialized
INFO - 2023-03-12 14:45:35 --> URI Class Initialized
INFO - 2023-03-12 14:45:35 --> Router Class Initialized
INFO - 2023-03-12 14:45:35 --> Output Class Initialized
INFO - 2023-03-12 14:45:35 --> Security Class Initialized
DEBUG - 2023-03-12 14:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:45:35 --> Input Class Initialized
INFO - 2023-03-12 14:45:35 --> Language Class Initialized
INFO - 2023-03-12 14:45:35 --> Loader Class Initialized
INFO - 2023-03-12 14:45:35 --> Controller Class Initialized
INFO - 2023-03-12 14:45:35 --> Helper loaded: form_helper
INFO - 2023-03-12 14:45:35 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:45:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:45:35 --> Model "Change_model" initialized
INFO - 2023-03-12 14:45:35 --> Model "Grafana_model" initialized
INFO - 2023-03-12 14:45:36 --> Final output sent to browser
DEBUG - 2023-03-12 14:45:36 --> Total execution time: 0.8139
INFO - 2023-03-12 14:45:36 --> Config Class Initialized
INFO - 2023-03-12 14:45:36 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:45:36 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:45:36 --> Utf8 Class Initialized
INFO - 2023-03-12 14:45:36 --> URI Class Initialized
INFO - 2023-03-12 14:45:36 --> Router Class Initialized
INFO - 2023-03-12 14:45:36 --> Output Class Initialized
INFO - 2023-03-12 14:45:36 --> Security Class Initialized
DEBUG - 2023-03-12 14:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:45:36 --> Input Class Initialized
INFO - 2023-03-12 14:45:36 --> Language Class Initialized
INFO - 2023-03-12 14:45:36 --> Loader Class Initialized
INFO - 2023-03-12 14:45:36 --> Controller Class Initialized
INFO - 2023-03-12 14:45:36 --> Helper loaded: form_helper
INFO - 2023-03-12 14:45:36 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:45:36 --> Final output sent to browser
DEBUG - 2023-03-12 14:45:36 --> Total execution time: 0.0041
INFO - 2023-03-12 14:45:36 --> Config Class Initialized
INFO - 2023-03-12 14:45:36 --> Hooks Class Initialized
DEBUG - 2023-03-12 14:45:36 --> UTF-8 Support Enabled
INFO - 2023-03-12 14:45:36 --> Utf8 Class Initialized
INFO - 2023-03-12 14:45:36 --> URI Class Initialized
INFO - 2023-03-12 14:45:36 --> Router Class Initialized
INFO - 2023-03-12 14:45:36 --> Output Class Initialized
INFO - 2023-03-12 14:45:36 --> Security Class Initialized
DEBUG - 2023-03-12 14:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 14:45:36 --> Input Class Initialized
INFO - 2023-03-12 14:45:36 --> Language Class Initialized
INFO - 2023-03-12 14:45:36 --> Loader Class Initialized
INFO - 2023-03-12 14:45:36 --> Controller Class Initialized
INFO - 2023-03-12 14:45:36 --> Helper loaded: form_helper
INFO - 2023-03-12 14:45:36 --> Helper loaded: url_helper
DEBUG - 2023-03-12 14:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 14:45:36 --> Database Driver Class Initialized
ERROR - 2023-03-12 14:45:46 --> Unable to connect to the database
INFO - 2023-03-12 14:45:46 --> Model "Login_model" initialized
ERROR - 2023-03-12 14:45:56 --> Unable to connect to the database
ERROR - 2023-03-12 14:45:56 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='halfeng' and password='Aa_12345';
INFO - 2023-03-12 14:45:56 --> Final output sent to browser
DEBUG - 2023-03-12 14:45:56 --> Total execution time: 20.0129
INFO - 2023-03-12 15:01:42 --> Config Class Initialized
INFO - 2023-03-12 15:01:42 --> Hooks Class Initialized
DEBUG - 2023-03-12 15:01:42 --> UTF-8 Support Enabled
INFO - 2023-03-12 15:01:42 --> Utf8 Class Initialized
INFO - 2023-03-12 15:01:42 --> URI Class Initialized
INFO - 2023-03-12 15:01:42 --> Router Class Initialized
INFO - 2023-03-12 15:01:42 --> Output Class Initialized
INFO - 2023-03-12 15:01:42 --> Security Class Initialized
DEBUG - 2023-03-12 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 15:01:42 --> Input Class Initialized
INFO - 2023-03-12 15:01:42 --> Language Class Initialized
INFO - 2023-03-12 15:01:42 --> Loader Class Initialized
INFO - 2023-03-12 15:01:42 --> Controller Class Initialized
INFO - 2023-03-12 15:01:42 --> Helper loaded: form_helper
INFO - 2023-03-12 15:01:42 --> Helper loaded: url_helper
DEBUG - 2023-03-12 15:01:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 15:01:42 --> Model "Change_model" initialized
INFO - 2023-03-12 15:01:43 --> Model "Grafana_model" initialized
INFO - 2023-03-12 15:01:43 --> Final output sent to browser
DEBUG - 2023-03-12 15:01:43 --> Total execution time: 1.0480
INFO - 2023-03-12 15:01:43 --> Config Class Initialized
INFO - 2023-03-12 15:01:43 --> Hooks Class Initialized
DEBUG - 2023-03-12 15:01:43 --> UTF-8 Support Enabled
INFO - 2023-03-12 15:01:43 --> Utf8 Class Initialized
INFO - 2023-03-12 15:01:43 --> URI Class Initialized
INFO - 2023-03-12 15:01:43 --> Router Class Initialized
INFO - 2023-03-12 15:01:43 --> Output Class Initialized
INFO - 2023-03-12 15:01:43 --> Security Class Initialized
DEBUG - 2023-03-12 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 15:01:43 --> Input Class Initialized
INFO - 2023-03-12 15:01:43 --> Language Class Initialized
INFO - 2023-03-12 15:01:43 --> Loader Class Initialized
INFO - 2023-03-12 15:01:43 --> Controller Class Initialized
INFO - 2023-03-12 15:01:43 --> Helper loaded: form_helper
INFO - 2023-03-12 15:01:43 --> Helper loaded: url_helper
DEBUG - 2023-03-12 15:01:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 15:01:43 --> Final output sent to browser
DEBUG - 2023-03-12 15:01:43 --> Total execution time: 0.0422
INFO - 2023-03-12 15:01:43 --> Config Class Initialized
INFO - 2023-03-12 15:01:43 --> Hooks Class Initialized
DEBUG - 2023-03-12 15:01:43 --> UTF-8 Support Enabled
INFO - 2023-03-12 15:01:43 --> Utf8 Class Initialized
INFO - 2023-03-12 15:01:43 --> URI Class Initialized
INFO - 2023-03-12 15:01:43 --> Router Class Initialized
INFO - 2023-03-12 15:01:43 --> Output Class Initialized
INFO - 2023-03-12 15:01:43 --> Security Class Initialized
DEBUG - 2023-03-12 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-12 15:01:43 --> Input Class Initialized
INFO - 2023-03-12 15:01:43 --> Language Class Initialized
INFO - 2023-03-12 15:01:43 --> Loader Class Initialized
INFO - 2023-03-12 15:01:43 --> Controller Class Initialized
INFO - 2023-03-12 15:01:43 --> Helper loaded: form_helper
INFO - 2023-03-12 15:01:43 --> Helper loaded: url_helper
DEBUG - 2023-03-12 15:01:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-12 15:01:43 --> Database Driver Class Initialized
ERROR - 2023-03-12 15:01:53 --> Unable to connect to the database
INFO - 2023-03-12 15:01:53 --> Model "Login_model" initialized
ERROR - 2023-03-12 15:02:03 --> Unable to connect to the database
ERROR - 2023-03-12 15:02:03 --> Query error: Operation timed out - Invalid query: select count(id) as count,id from kunlun_user where name='halfeng' and password='Aa_12345';
INFO - 2023-03-12 15:02:03 --> Final output sent to browser
DEBUG - 2023-03-12 15:02:03 --> Total execution time: 20.0100
