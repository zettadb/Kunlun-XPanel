<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-03 02:33:16 --> Config Class Initialized
INFO - 2023-04-03 02:33:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:16 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:16 --> URI Class Initialized
INFO - 2023-04-03 02:33:16 --> Router Class Initialized
INFO - 2023-04-03 02:33:16 --> Output Class Initialized
INFO - 2023-04-03 02:33:16 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:16 --> Input Class Initialized
INFO - 2023-04-03 02:33:16 --> Language Class Initialized
INFO - 2023-04-03 02:33:16 --> Loader Class Initialized
INFO - 2023-04-03 02:33:16 --> Controller Class Initialized
INFO - 2023-04-03 02:33:16 --> Helper loaded: form_helper
INFO - 2023-04-03 02:33:16 --> Helper loaded: url_helper
DEBUG - 2023-04-03 02:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:16 --> Model "Change_model" initialized
INFO - 2023-04-03 02:33:16 --> Model "Grafana_model" initialized
INFO - 2023-04-03 02:33:16 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:16 --> Total execution time: 0.0419
INFO - 2023-04-03 02:33:16 --> Config Class Initialized
INFO - 2023-04-03 02:33:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:16 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:16 --> URI Class Initialized
INFO - 2023-04-03 02:33:16 --> Router Class Initialized
INFO - 2023-04-03 02:33:16 --> Output Class Initialized
INFO - 2023-04-03 02:33:16 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:16 --> Input Class Initialized
INFO - 2023-04-03 02:33:16 --> Language Class Initialized
INFO - 2023-04-03 02:33:16 --> Loader Class Initialized
INFO - 2023-04-03 02:33:16 --> Controller Class Initialized
INFO - 2023-04-03 02:33:16 --> Helper loaded: form_helper
INFO - 2023-04-03 02:33:16 --> Helper loaded: url_helper
DEBUG - 2023-04-03 02:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:16 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:16 --> Total execution time: 0.0431
INFO - 2023-04-03 02:33:16 --> Config Class Initialized
INFO - 2023-04-03 02:33:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:16 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:16 --> URI Class Initialized
INFO - 2023-04-03 02:33:16 --> Router Class Initialized
INFO - 2023-04-03 02:33:16 --> Output Class Initialized
INFO - 2023-04-03 02:33:16 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:16 --> Input Class Initialized
INFO - 2023-04-03 02:33:16 --> Language Class Initialized
INFO - 2023-04-03 02:33:16 --> Loader Class Initialized
INFO - 2023-04-03 02:33:16 --> Controller Class Initialized
INFO - 2023-04-03 02:33:16 --> Helper loaded: form_helper
INFO - 2023-04-03 02:33:16 --> Helper loaded: url_helper
DEBUG - 2023-04-03 02:33:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:16 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:16 --> Model "Login_model" initialized
INFO - 2023-04-03 02:33:16 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:16 --> Total execution time: 0.0195
INFO - 2023-04-03 02:33:16 --> Config Class Initialized
INFO - 2023-04-03 02:33:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:17 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:17 --> URI Class Initialized
INFO - 2023-04-03 02:33:17 --> Router Class Initialized
INFO - 2023-04-03 02:33:17 --> Output Class Initialized
INFO - 2023-04-03 02:33:17 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:17 --> Input Class Initialized
INFO - 2023-04-03 02:33:17 --> Language Class Initialized
INFO - 2023-04-03 02:33:17 --> Loader Class Initialized
INFO - 2023-04-03 02:33:17 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:17 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:17 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:17 --> Total execution time: 0.0522
INFO - 2023-04-03 02:33:17 --> Config Class Initialized
INFO - 2023-04-03 02:33:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:17 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:17 --> URI Class Initialized
INFO - 2023-04-03 02:33:17 --> Router Class Initialized
INFO - 2023-04-03 02:33:17 --> Output Class Initialized
INFO - 2023-04-03 02:33:17 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:17 --> Input Class Initialized
INFO - 2023-04-03 02:33:17 --> Language Class Initialized
INFO - 2023-04-03 02:33:17 --> Loader Class Initialized
INFO - 2023-04-03 02:33:17 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:17 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:17 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:17 --> Total execution time: 0.0140
INFO - 2023-04-03 02:33:17 --> Config Class Initialized
INFO - 2023-04-03 02:33:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:17 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:17 --> URI Class Initialized
INFO - 2023-04-03 02:33:17 --> Router Class Initialized
INFO - 2023-04-03 02:33:17 --> Output Class Initialized
INFO - 2023-04-03 02:33:17 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:17 --> Input Class Initialized
INFO - 2023-04-03 02:33:17 --> Language Class Initialized
INFO - 2023-04-03 02:33:17 --> Loader Class Initialized
INFO - 2023-04-03 02:33:17 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:17 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:17 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:17 --> Model "Login_model" initialized
INFO - 2023-04-03 02:33:17 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:17 --> Total execution time: 0.2445
INFO - 2023-04-03 02:33:17 --> Config Class Initialized
INFO - 2023-04-03 02:33:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:17 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:17 --> URI Class Initialized
INFO - 2023-04-03 02:33:17 --> Router Class Initialized
INFO - 2023-04-03 02:33:17 --> Output Class Initialized
INFO - 2023-04-03 02:33:17 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:17 --> Input Class Initialized
INFO - 2023-04-03 02:33:17 --> Language Class Initialized
INFO - 2023-04-03 02:33:17 --> Loader Class Initialized
INFO - 2023-04-03 02:33:17 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:17 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:17 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:17 --> Model "Login_model" initialized
INFO - 2023-04-03 02:33:17 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:17 --> Total execution time: 0.0698
INFO - 2023-04-03 02:33:20 --> Config Class Initialized
INFO - 2023-04-03 02:33:20 --> Config Class Initialized
INFO - 2023-04-03 02:33:20 --> Hooks Class Initialized
INFO - 2023-04-03 02:33:20 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:20 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:21 --> Utf8 Class Initialized
DEBUG - 2023-04-03 02:33:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:21 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:21 --> URI Class Initialized
INFO - 2023-04-03 02:33:21 --> URI Class Initialized
INFO - 2023-04-03 02:33:21 --> Router Class Initialized
INFO - 2023-04-03 02:33:21 --> Router Class Initialized
INFO - 2023-04-03 02:33:21 --> Output Class Initialized
INFO - 2023-04-03 02:33:21 --> Output Class Initialized
INFO - 2023-04-03 02:33:21 --> Security Class Initialized
INFO - 2023-04-03 02:33:21 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 02:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:21 --> Input Class Initialized
INFO - 2023-04-03 02:33:21 --> Input Class Initialized
INFO - 2023-04-03 02:33:21 --> Language Class Initialized
INFO - 2023-04-03 02:33:21 --> Language Class Initialized
INFO - 2023-04-03 02:33:21 --> Loader Class Initialized
INFO - 2023-04-03 02:33:21 --> Loader Class Initialized
INFO - 2023-04-03 02:33:21 --> Controller Class Initialized
INFO - 2023-04-03 02:33:21 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 02:33:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:21 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:21 --> Total execution time: 0.0459
INFO - 2023-04-03 02:33:21 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:21 --> Config Class Initialized
INFO - 2023-04-03 02:33:21 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:21 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:21 --> URI Class Initialized
INFO - 2023-04-03 02:33:21 --> Router Class Initialized
INFO - 2023-04-03 02:33:21 --> Output Class Initialized
INFO - 2023-04-03 02:33:21 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:21 --> Input Class Initialized
INFO - 2023-04-03 02:33:21 --> Language Class Initialized
INFO - 2023-04-03 02:33:21 --> Loader Class Initialized
INFO - 2023-04-03 02:33:21 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:21 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:21 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:21 --> Total execution time: 0.0927
INFO - 2023-04-03 02:33:21 --> Config Class Initialized
INFO - 2023-04-03 02:33:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:21 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:21 --> URI Class Initialized
INFO - 2023-04-03 02:33:21 --> Router Class Initialized
INFO - 2023-04-03 02:33:21 --> Output Class Initialized
INFO - 2023-04-03 02:33:21 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:21 --> Input Class Initialized
INFO - 2023-04-03 02:33:21 --> Language Class Initialized
INFO - 2023-04-03 02:33:21 --> Loader Class Initialized
INFO - 2023-04-03 02:33:21 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:21 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:21 --> Model "Login_model" initialized
INFO - 2023-04-03 02:33:21 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:21 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:21 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:21 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:21 --> Total execution time: 0.0605
INFO - 2023-04-03 02:33:21 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:21 --> Total execution time: 0.0151
INFO - 2023-04-03 02:33:30 --> Config Class Initialized
INFO - 2023-04-03 02:33:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:30 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:30 --> URI Class Initialized
INFO - 2023-04-03 02:33:30 --> Router Class Initialized
INFO - 2023-04-03 02:33:30 --> Output Class Initialized
INFO - 2023-04-03 02:33:30 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:30 --> Input Class Initialized
INFO - 2023-04-03 02:33:30 --> Language Class Initialized
INFO - 2023-04-03 02:33:30 --> Loader Class Initialized
INFO - 2023-04-03 02:33:30 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:30 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:30 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:30 --> Total execution time: 0.0176
INFO - 2023-04-03 02:33:30 --> Config Class Initialized
INFO - 2023-04-03 02:33:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:30 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:30 --> URI Class Initialized
INFO - 2023-04-03 02:33:30 --> Router Class Initialized
INFO - 2023-04-03 02:33:30 --> Output Class Initialized
INFO - 2023-04-03 02:33:30 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:30 --> Input Class Initialized
INFO - 2023-04-03 02:33:30 --> Language Class Initialized
INFO - 2023-04-03 02:33:30 --> Loader Class Initialized
INFO - 2023-04-03 02:33:30 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:30 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:30 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:30 --> Total execution time: 0.0545
INFO - 2023-04-03 02:33:31 --> Config Class Initialized
INFO - 2023-04-03 02:33:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:31 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:31 --> URI Class Initialized
INFO - 2023-04-03 02:33:31 --> Router Class Initialized
INFO - 2023-04-03 02:33:31 --> Output Class Initialized
INFO - 2023-04-03 02:33:31 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:31 --> Input Class Initialized
INFO - 2023-04-03 02:33:31 --> Language Class Initialized
INFO - 2023-04-03 02:33:31 --> Loader Class Initialized
INFO - 2023-04-03 02:33:31 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:31 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:31 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:31 --> Total execution time: 0.0930
INFO - 2023-04-03 02:33:31 --> Config Class Initialized
INFO - 2023-04-03 02:33:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:31 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:31 --> URI Class Initialized
INFO - 2023-04-03 02:33:31 --> Router Class Initialized
INFO - 2023-04-03 02:33:31 --> Output Class Initialized
INFO - 2023-04-03 02:33:31 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:31 --> Input Class Initialized
INFO - 2023-04-03 02:33:31 --> Language Class Initialized
INFO - 2023-04-03 02:33:31 --> Loader Class Initialized
INFO - 2023-04-03 02:33:31 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:31 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:31 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:31 --> Total execution time: 0.1599
INFO - 2023-04-03 02:33:33 --> Config Class Initialized
INFO - 2023-04-03 02:33:33 --> Config Class Initialized
INFO - 2023-04-03 02:33:33 --> Hooks Class Initialized
INFO - 2023-04-03 02:33:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 02:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:33 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:33 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:33 --> URI Class Initialized
INFO - 2023-04-03 02:33:33 --> URI Class Initialized
INFO - 2023-04-03 02:33:33 --> Router Class Initialized
INFO - 2023-04-03 02:33:33 --> Router Class Initialized
INFO - 2023-04-03 02:33:33 --> Output Class Initialized
INFO - 2023-04-03 02:33:33 --> Output Class Initialized
INFO - 2023-04-03 02:33:33 --> Security Class Initialized
INFO - 2023-04-03 02:33:33 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 02:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:33 --> Input Class Initialized
INFO - 2023-04-03 02:33:33 --> Input Class Initialized
INFO - 2023-04-03 02:33:33 --> Language Class Initialized
INFO - 2023-04-03 02:33:33 --> Language Class Initialized
INFO - 2023-04-03 02:33:33 --> Loader Class Initialized
INFO - 2023-04-03 02:33:33 --> Loader Class Initialized
INFO - 2023-04-03 02:33:33 --> Controller Class Initialized
INFO - 2023-04-03 02:33:33 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 02:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:33 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:33 --> Total execution time: 0.0043
INFO - 2023-04-03 02:33:33 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:33 --> Config Class Initialized
INFO - 2023-04-03 02:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:33 --> Hooks Class Initialized
INFO - 2023-04-03 02:33:33 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:33 --> Total execution time: 0.0919
DEBUG - 2023-04-03 02:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:33 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:33 --> URI Class Initialized
INFO - 2023-04-03 02:33:33 --> Router Class Initialized
INFO - 2023-04-03 02:33:33 --> Output Class Initialized
INFO - 2023-04-03 02:33:33 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:33 --> Input Class Initialized
INFO - 2023-04-03 02:33:33 --> Language Class Initialized
INFO - 2023-04-03 02:33:33 --> Loader Class Initialized
INFO - 2023-04-03 02:33:33 --> Controller Class Initialized
INFO - 2023-04-03 02:33:33 --> Config Class Initialized
DEBUG - 2023-04-03 02:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:33:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:33:33 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:33 --> Utf8 Class Initialized
INFO - 2023-04-03 02:33:33 --> URI Class Initialized
INFO - 2023-04-03 02:33:33 --> Router Class Initialized
INFO - 2023-04-03 02:33:33 --> Output Class Initialized
INFO - 2023-04-03 02:33:33 --> Security Class Initialized
DEBUG - 2023-04-03 02:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:33:33 --> Input Class Initialized
INFO - 2023-04-03 02:33:33 --> Language Class Initialized
INFO - 2023-04-03 02:33:33 --> Loader Class Initialized
INFO - 2023-04-03 02:33:33 --> Controller Class Initialized
DEBUG - 2023-04-03 02:33:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:33:33 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:33 --> Model "Login_model" initialized
INFO - 2023-04-03 02:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:33 --> Database Driver Class Initialized
INFO - 2023-04-03 02:33:33 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:33 --> Total execution time: 0.0159
INFO - 2023-04-03 02:33:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:33:33 --> Final output sent to browser
DEBUG - 2023-04-03 02:33:33 --> Total execution time: 0.1468
INFO - 2023-04-03 02:46:57 --> Config Class Initialized
INFO - 2023-04-03 02:46:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:46:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:46:57 --> Utf8 Class Initialized
INFO - 2023-04-03 02:46:57 --> URI Class Initialized
INFO - 2023-04-03 02:46:57 --> Router Class Initialized
INFO - 2023-04-03 02:46:57 --> Output Class Initialized
INFO - 2023-04-03 02:46:57 --> Security Class Initialized
DEBUG - 2023-04-03 02:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:46:57 --> Input Class Initialized
INFO - 2023-04-03 02:46:57 --> Language Class Initialized
INFO - 2023-04-03 02:46:57 --> Loader Class Initialized
INFO - 2023-04-03 02:46:57 --> Controller Class Initialized
DEBUG - 2023-04-03 02:46:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:46:57 --> Database Driver Class Initialized
INFO - 2023-04-03 02:46:57 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:46:57 --> Final output sent to browser
INFO - 2023-04-03 02:46:57 --> Config Class Initialized
DEBUG - 2023-04-03 02:46:57 --> Total execution time: 0.0510
INFO - 2023-04-03 02:46:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 02:46:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 02:46:57 --> Utf8 Class Initialized
INFO - 2023-04-03 02:46:57 --> URI Class Initialized
INFO - 2023-04-03 02:46:57 --> Router Class Initialized
INFO - 2023-04-03 02:46:57 --> Output Class Initialized
INFO - 2023-04-03 02:46:57 --> Security Class Initialized
DEBUG - 2023-04-03 02:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 02:46:57 --> Input Class Initialized
INFO - 2023-04-03 02:46:57 --> Language Class Initialized
INFO - 2023-04-03 02:46:57 --> Loader Class Initialized
INFO - 2023-04-03 02:46:57 --> Controller Class Initialized
DEBUG - 2023-04-03 02:46:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 02:46:57 --> Database Driver Class Initialized
INFO - 2023-04-03 02:46:57 --> Model "Cluster_model" initialized
INFO - 2023-04-03 02:46:57 --> Final output sent to browser
DEBUG - 2023-04-03 02:46:57 --> Total execution time: 0.0941
INFO - 2023-04-03 03:31:14 --> Config Class Initialized
INFO - 2023-04-03 03:31:14 --> Config Class Initialized
INFO - 2023-04-03 03:31:14 --> Hooks Class Initialized
INFO - 2023-04-03 03:31:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 03:31:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:14 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:14 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:14 --> URI Class Initialized
INFO - 2023-04-03 03:31:14 --> URI Class Initialized
INFO - 2023-04-03 03:31:14 --> Router Class Initialized
INFO - 2023-04-03 03:31:14 --> Router Class Initialized
INFO - 2023-04-03 03:31:14 --> Output Class Initialized
INFO - 2023-04-03 03:31:14 --> Output Class Initialized
INFO - 2023-04-03 03:31:14 --> Security Class Initialized
INFO - 2023-04-03 03:31:14 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 03:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:14 --> Input Class Initialized
INFO - 2023-04-03 03:31:14 --> Input Class Initialized
INFO - 2023-04-03 03:31:14 --> Language Class Initialized
INFO - 2023-04-03 03:31:14 --> Language Class Initialized
INFO - 2023-04-03 03:31:14 --> Loader Class Initialized
INFO - 2023-04-03 03:31:14 --> Loader Class Initialized
INFO - 2023-04-03 03:31:14 --> Controller Class Initialized
INFO - 2023-04-03 03:31:14 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 03:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:14 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:14 --> Total execution time: 0.0056
INFO - 2023-04-03 03:31:14 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:14 --> Config Class Initialized
INFO - 2023-04-03 03:31:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:14 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:14 --> URI Class Initialized
INFO - 2023-04-03 03:31:14 --> Router Class Initialized
INFO - 2023-04-03 03:31:14 --> Output Class Initialized
INFO - 2023-04-03 03:31:14 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:14 --> Input Class Initialized
INFO - 2023-04-03 03:31:14 --> Language Class Initialized
INFO - 2023-04-03 03:31:14 --> Loader Class Initialized
INFO - 2023-04-03 03:31:14 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:14 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:14 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:14 --> Total execution time: 0.0548
INFO - 2023-04-03 03:31:14 --> Config Class Initialized
INFO - 2023-04-03 03:31:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:14 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:14 --> URI Class Initialized
INFO - 2023-04-03 03:31:14 --> Router Class Initialized
INFO - 2023-04-03 03:31:14 --> Output Class Initialized
INFO - 2023-04-03 03:31:14 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:14 --> Input Class Initialized
INFO - 2023-04-03 03:31:14 --> Language Class Initialized
INFO - 2023-04-03 03:31:14 --> Model "Login_model" initialized
INFO - 2023-04-03 03:31:14 --> Loader Class Initialized
INFO - 2023-04-03 03:31:14 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:14 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:14 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:14 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:14 --> Total execution time: 0.0640
INFO - 2023-04-03 03:31:14 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:14 --> Total execution time: 0.0160
INFO - 2023-04-03 03:31:15 --> Config Class Initialized
INFO - 2023-04-03 03:31:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:15 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:15 --> URI Class Initialized
INFO - 2023-04-03 03:31:15 --> Router Class Initialized
INFO - 2023-04-03 03:31:15 --> Output Class Initialized
INFO - 2023-04-03 03:31:15 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:15 --> Input Class Initialized
INFO - 2023-04-03 03:31:15 --> Language Class Initialized
INFO - 2023-04-03 03:31:15 --> Loader Class Initialized
INFO - 2023-04-03 03:31:15 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:15 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:15 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:15 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:15 --> Total execution time: 0.0884
INFO - 2023-04-03 03:31:15 --> Config Class Initialized
INFO - 2023-04-03 03:31:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:16 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:16 --> URI Class Initialized
INFO - 2023-04-03 03:31:16 --> Router Class Initialized
INFO - 2023-04-03 03:31:16 --> Output Class Initialized
INFO - 2023-04-03 03:31:16 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:16 --> Input Class Initialized
INFO - 2023-04-03 03:31:16 --> Language Class Initialized
INFO - 2023-04-03 03:31:16 --> Loader Class Initialized
INFO - 2023-04-03 03:31:16 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:16 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:16 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:16 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:16 --> Total execution time: 0.0907
INFO - 2023-04-03 03:31:17 --> Config Class Initialized
INFO - 2023-04-03 03:31:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:17 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:17 --> URI Class Initialized
INFO - 2023-04-03 03:31:17 --> Router Class Initialized
INFO - 2023-04-03 03:31:17 --> Output Class Initialized
INFO - 2023-04-03 03:31:17 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:17 --> Input Class Initialized
INFO - 2023-04-03 03:31:17 --> Language Class Initialized
INFO - 2023-04-03 03:31:17 --> Loader Class Initialized
INFO - 2023-04-03 03:31:17 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:17 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:17 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:17 --> Total execution time: 0.0165
INFO - 2023-04-03 03:31:17 --> Config Class Initialized
INFO - 2023-04-03 03:31:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:17 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:17 --> URI Class Initialized
INFO - 2023-04-03 03:31:17 --> Router Class Initialized
INFO - 2023-04-03 03:31:17 --> Output Class Initialized
INFO - 2023-04-03 03:31:17 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:17 --> Input Class Initialized
INFO - 2023-04-03 03:31:17 --> Language Class Initialized
INFO - 2023-04-03 03:31:17 --> Loader Class Initialized
INFO - 2023-04-03 03:31:17 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:17 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:17 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:17 --> Total execution time: 0.0575
INFO - 2023-04-03 03:31:20 --> Config Class Initialized
INFO - 2023-04-03 03:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:20 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:20 --> URI Class Initialized
INFO - 2023-04-03 03:31:20 --> Router Class Initialized
INFO - 2023-04-03 03:31:20 --> Output Class Initialized
INFO - 2023-04-03 03:31:20 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:20 --> Input Class Initialized
INFO - 2023-04-03 03:31:20 --> Language Class Initialized
INFO - 2023-04-03 03:31:20 --> Loader Class Initialized
INFO - 2023-04-03 03:31:20 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:20 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:20 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:20 --> Model "Login_model" initialized
INFO - 2023-04-03 03:31:20 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:20 --> Total execution time: 0.0424
INFO - 2023-04-03 03:31:20 --> Config Class Initialized
INFO - 2023-04-03 03:31:20 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:31:20 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:31:20 --> Utf8 Class Initialized
INFO - 2023-04-03 03:31:20 --> URI Class Initialized
INFO - 2023-04-03 03:31:20 --> Router Class Initialized
INFO - 2023-04-03 03:31:20 --> Output Class Initialized
INFO - 2023-04-03 03:31:20 --> Security Class Initialized
DEBUG - 2023-04-03 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:31:20 --> Input Class Initialized
INFO - 2023-04-03 03:31:20 --> Language Class Initialized
INFO - 2023-04-03 03:31:20 --> Loader Class Initialized
INFO - 2023-04-03 03:31:20 --> Controller Class Initialized
DEBUG - 2023-04-03 03:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:31:20 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:20 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:31:20 --> Database Driver Class Initialized
INFO - 2023-04-03 03:31:20 --> Model "Login_model" initialized
INFO - 2023-04-03 03:31:20 --> Final output sent to browser
DEBUG - 2023-04-03 03:31:20 --> Total execution time: 0.0679
INFO - 2023-04-03 03:32:35 --> Config Class Initialized
INFO - 2023-04-03 03:32:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:32:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:32:35 --> Utf8 Class Initialized
INFO - 2023-04-03 03:32:35 --> URI Class Initialized
INFO - 2023-04-03 03:32:35 --> Router Class Initialized
INFO - 2023-04-03 03:32:35 --> Output Class Initialized
INFO - 2023-04-03 03:32:35 --> Security Class Initialized
DEBUG - 2023-04-03 03:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:32:35 --> Input Class Initialized
INFO - 2023-04-03 03:32:35 --> Language Class Initialized
INFO - 2023-04-03 03:32:35 --> Loader Class Initialized
INFO - 2023-04-03 03:32:35 --> Controller Class Initialized
DEBUG - 2023-04-03 03:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:32:35 --> Database Driver Class Initialized
INFO - 2023-04-03 03:32:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:32:35 --> Final output sent to browser
DEBUG - 2023-04-03 03:32:35 --> Total execution time: 0.0610
INFO - 2023-04-03 03:32:35 --> Config Class Initialized
INFO - 2023-04-03 03:32:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:32:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:32:35 --> Utf8 Class Initialized
INFO - 2023-04-03 03:32:35 --> URI Class Initialized
INFO - 2023-04-03 03:32:35 --> Router Class Initialized
INFO - 2023-04-03 03:32:35 --> Output Class Initialized
INFO - 2023-04-03 03:32:35 --> Security Class Initialized
DEBUG - 2023-04-03 03:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:32:35 --> Input Class Initialized
INFO - 2023-04-03 03:32:35 --> Language Class Initialized
INFO - 2023-04-03 03:32:35 --> Loader Class Initialized
INFO - 2023-04-03 03:32:35 --> Controller Class Initialized
DEBUG - 2023-04-03 03:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:32:35 --> Database Driver Class Initialized
INFO - 2023-04-03 03:32:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:32:36 --> Final output sent to browser
DEBUG - 2023-04-03 03:32:36 --> Total execution time: 0.0488
INFO - 2023-04-03 03:32:38 --> Config Class Initialized
INFO - 2023-04-03 03:32:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:32:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:32:38 --> Utf8 Class Initialized
INFO - 2023-04-03 03:32:38 --> URI Class Initialized
INFO - 2023-04-03 03:32:38 --> Router Class Initialized
INFO - 2023-04-03 03:32:38 --> Output Class Initialized
INFO - 2023-04-03 03:32:38 --> Security Class Initialized
DEBUG - 2023-04-03 03:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:32:38 --> Input Class Initialized
INFO - 2023-04-03 03:32:38 --> Language Class Initialized
INFO - 2023-04-03 03:32:38 --> Loader Class Initialized
INFO - 2023-04-03 03:32:38 --> Controller Class Initialized
DEBUG - 2023-04-03 03:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:32:38 --> Database Driver Class Initialized
INFO - 2023-04-03 03:32:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:32:38 --> Final output sent to browser
DEBUG - 2023-04-03 03:32:38 --> Total execution time: 0.0150
INFO - 2023-04-03 03:32:38 --> Config Class Initialized
INFO - 2023-04-03 03:32:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:32:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:32:38 --> Utf8 Class Initialized
INFO - 2023-04-03 03:32:38 --> URI Class Initialized
INFO - 2023-04-03 03:32:38 --> Router Class Initialized
INFO - 2023-04-03 03:32:38 --> Output Class Initialized
INFO - 2023-04-03 03:32:38 --> Security Class Initialized
DEBUG - 2023-04-03 03:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:32:38 --> Input Class Initialized
INFO - 2023-04-03 03:32:38 --> Language Class Initialized
INFO - 2023-04-03 03:32:38 --> Loader Class Initialized
INFO - 2023-04-03 03:32:38 --> Controller Class Initialized
DEBUG - 2023-04-03 03:32:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:32:38 --> Database Driver Class Initialized
INFO - 2023-04-03 03:32:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:32:38 --> Final output sent to browser
DEBUG - 2023-04-03 03:32:38 --> Total execution time: 0.0115
INFO - 2023-04-03 03:32:41 --> Config Class Initialized
INFO - 2023-04-03 03:32:41 --> Config Class Initialized
INFO - 2023-04-03 03:32:41 --> Hooks Class Initialized
INFO - 2023-04-03 03:32:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:32:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 03:32:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:32:41 --> Utf8 Class Initialized
INFO - 2023-04-03 03:32:41 --> Utf8 Class Initialized
INFO - 2023-04-03 03:32:41 --> URI Class Initialized
INFO - 2023-04-03 03:32:41 --> URI Class Initialized
INFO - 2023-04-03 03:32:41 --> Router Class Initialized
INFO - 2023-04-03 03:32:41 --> Router Class Initialized
INFO - 2023-04-03 03:32:41 --> Output Class Initialized
INFO - 2023-04-03 03:32:41 --> Output Class Initialized
INFO - 2023-04-03 03:32:41 --> Security Class Initialized
INFO - 2023-04-03 03:32:41 --> Security Class Initialized
DEBUG - 2023-04-03 03:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 03:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:32:41 --> Input Class Initialized
INFO - 2023-04-03 03:32:41 --> Input Class Initialized
INFO - 2023-04-03 03:32:41 --> Language Class Initialized
INFO - 2023-04-03 03:32:41 --> Language Class Initialized
INFO - 2023-04-03 03:32:41 --> Loader Class Initialized
INFO - 2023-04-03 03:32:41 --> Loader Class Initialized
INFO - 2023-04-03 03:32:41 --> Controller Class Initialized
INFO - 2023-04-03 03:32:41 --> Controller Class Initialized
DEBUG - 2023-04-03 03:32:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 03:32:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:32:41 --> Final output sent to browser
DEBUG - 2023-04-03 03:32:41 --> Total execution time: 0.0054
INFO - 2023-04-03 03:32:41 --> Database Driver Class Initialized
INFO - 2023-04-03 03:32:41 --> Config Class Initialized
INFO - 2023-04-03 03:32:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:32:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:32:41 --> Utf8 Class Initialized
INFO - 2023-04-03 03:32:41 --> URI Class Initialized
INFO - 2023-04-03 03:32:41 --> Router Class Initialized
INFO - 2023-04-03 03:32:41 --> Output Class Initialized
INFO - 2023-04-03 03:32:41 --> Security Class Initialized
DEBUG - 2023-04-03 03:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:32:41 --> Input Class Initialized
INFO - 2023-04-03 03:32:41 --> Language Class Initialized
INFO - 2023-04-03 03:32:41 --> Loader Class Initialized
INFO - 2023-04-03 03:32:41 --> Controller Class Initialized
DEBUG - 2023-04-03 03:32:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:32:41 --> Database Driver Class Initialized
INFO - 2023-04-03 03:32:41 --> Model "Login_model" initialized
INFO - 2023-04-03 03:32:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:32:41 --> Database Driver Class Initialized
INFO - 2023-04-03 03:32:41 --> Final output sent to browser
DEBUG - 2023-04-03 03:32:41 --> Total execution time: 0.1177
INFO - 2023-04-03 03:32:41 --> Config Class Initialized
INFO - 2023-04-03 03:32:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 03:32:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 03:32:41 --> Utf8 Class Initialized
INFO - 2023-04-03 03:32:41 --> URI Class Initialized
INFO - 2023-04-03 03:32:41 --> Router Class Initialized
INFO - 2023-04-03 03:32:41 --> Output Class Initialized
INFO - 2023-04-03 03:32:41 --> Security Class Initialized
DEBUG - 2023-04-03 03:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 03:32:41 --> Input Class Initialized
INFO - 2023-04-03 03:32:41 --> Language Class Initialized
INFO - 2023-04-03 03:32:41 --> Loader Class Initialized
INFO - 2023-04-03 03:32:41 --> Controller Class Initialized
DEBUG - 2023-04-03 03:32:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 03:32:41 --> Database Driver Class Initialized
INFO - 2023-04-03 03:32:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:32:41 --> Final output sent to browser
DEBUG - 2023-04-03 03:32:41 --> Total execution time: 0.1179
INFO - 2023-04-03 03:32:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 03:32:41 --> Final output sent to browser
DEBUG - 2023-04-03 03:32:41 --> Total execution time: 0.0609
INFO - 2023-04-03 05:35:54 --> Config Class Initialized
INFO - 2023-04-03 05:35:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 05:35:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 05:35:54 --> Utf8 Class Initialized
INFO - 2023-04-03 05:35:54 --> URI Class Initialized
INFO - 2023-04-03 05:35:54 --> Router Class Initialized
INFO - 2023-04-03 05:35:54 --> Output Class Initialized
INFO - 2023-04-03 05:35:54 --> Security Class Initialized
DEBUG - 2023-04-03 05:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 05:35:54 --> Input Class Initialized
INFO - 2023-04-03 05:35:54 --> Language Class Initialized
INFO - 2023-04-03 05:35:54 --> Loader Class Initialized
INFO - 2023-04-03 05:35:54 --> Controller Class Initialized
DEBUG - 2023-04-03 05:35:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 05:35:54 --> Database Driver Class Initialized
INFO - 2023-04-03 05:35:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 05:35:54 --> Final output sent to browser
INFO - 2023-04-03 05:35:54 --> Config Class Initialized
DEBUG - 2023-04-03 05:35:54 --> Total execution time: 0.0500
INFO - 2023-04-03 05:35:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 05:35:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 05:35:54 --> Utf8 Class Initialized
INFO - 2023-04-03 05:35:54 --> URI Class Initialized
INFO - 2023-04-03 05:35:54 --> Router Class Initialized
INFO - 2023-04-03 05:35:54 --> Output Class Initialized
INFO - 2023-04-03 05:35:54 --> Security Class Initialized
DEBUG - 2023-04-03 05:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 05:35:54 --> Input Class Initialized
INFO - 2023-04-03 05:35:54 --> Language Class Initialized
INFO - 2023-04-03 05:35:54 --> Loader Class Initialized
INFO - 2023-04-03 05:35:54 --> Controller Class Initialized
DEBUG - 2023-04-03 05:35:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 05:35:54 --> Database Driver Class Initialized
INFO - 2023-04-03 05:35:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 05:35:54 --> Final output sent to browser
DEBUG - 2023-04-03 05:35:54 --> Total execution time: 0.1224
INFO - 2023-04-03 05:35:56 --> Config Class Initialized
INFO - 2023-04-03 05:35:56 --> Hooks Class Initialized
INFO - 2023-04-03 05:35:56 --> Config Class Initialized
DEBUG - 2023-04-03 05:35:56 --> UTF-8 Support Enabled
INFO - 2023-04-03 05:35:56 --> Hooks Class Initialized
INFO - 2023-04-03 05:35:56 --> Utf8 Class Initialized
INFO - 2023-04-03 05:35:56 --> URI Class Initialized
DEBUG - 2023-04-03 05:35:56 --> UTF-8 Support Enabled
INFO - 2023-04-03 05:35:56 --> Utf8 Class Initialized
INFO - 2023-04-03 05:35:56 --> Router Class Initialized
INFO - 2023-04-03 05:35:56 --> Output Class Initialized
INFO - 2023-04-03 05:35:56 --> URI Class Initialized
INFO - 2023-04-03 05:35:56 --> Security Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 05:35:56 --> Router Class Initialized
INFO - 2023-04-03 05:35:56 --> Input Class Initialized
INFO - 2023-04-03 05:35:56 --> Output Class Initialized
INFO - 2023-04-03 05:35:56 --> Language Class Initialized
INFO - 2023-04-03 05:35:56 --> Security Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 05:35:56 --> Loader Class Initialized
INFO - 2023-04-03 05:35:56 --> Input Class Initialized
INFO - 2023-04-03 05:35:56 --> Controller Class Initialized
INFO - 2023-04-03 05:35:56 --> Language Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 05:35:56 --> Final output sent to browser
INFO - 2023-04-03 05:35:56 --> Loader Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Total execution time: 0.0040
INFO - 2023-04-03 05:35:56 --> Controller Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 05:35:56 --> Database Driver Class Initialized
INFO - 2023-04-03 05:35:56 --> Config Class Initialized
INFO - 2023-04-03 05:35:56 --> Model "Cluster_model" initialized
INFO - 2023-04-03 05:35:56 --> Hooks Class Initialized
DEBUG - 2023-04-03 05:35:56 --> UTF-8 Support Enabled
INFO - 2023-04-03 05:35:56 --> Utf8 Class Initialized
INFO - 2023-04-03 05:35:56 --> URI Class Initialized
INFO - 2023-04-03 05:35:56 --> Router Class Initialized
INFO - 2023-04-03 05:35:56 --> Output Class Initialized
INFO - 2023-04-03 05:35:56 --> Security Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 05:35:56 --> Input Class Initialized
INFO - 2023-04-03 05:35:56 --> Language Class Initialized
INFO - 2023-04-03 05:35:56 --> Loader Class Initialized
INFO - 2023-04-03 05:35:56 --> Controller Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 05:35:56 --> Database Driver Class Initialized
INFO - 2023-04-03 05:35:56 --> Final output sent to browser
DEBUG - 2023-04-03 05:35:56 --> Total execution time: 0.0496
INFO - 2023-04-03 05:35:56 --> Config Class Initialized
INFO - 2023-04-03 05:35:56 --> Hooks Class Initialized
DEBUG - 2023-04-03 05:35:56 --> UTF-8 Support Enabled
INFO - 2023-04-03 05:35:56 --> Utf8 Class Initialized
INFO - 2023-04-03 05:35:56 --> URI Class Initialized
INFO - 2023-04-03 05:35:56 --> Router Class Initialized
INFO - 2023-04-03 05:35:56 --> Output Class Initialized
INFO - 2023-04-03 05:35:56 --> Security Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 05:35:56 --> Input Class Initialized
INFO - 2023-04-03 05:35:56 --> Language Class Initialized
INFO - 2023-04-03 05:35:56 --> Loader Class Initialized
INFO - 2023-04-03 05:35:56 --> Controller Class Initialized
DEBUG - 2023-04-03 05:35:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 05:35:56 --> Database Driver Class Initialized
INFO - 2023-04-03 05:35:56 --> Model "Login_model" initialized
INFO - 2023-04-03 05:35:56 --> Database Driver Class Initialized
INFO - 2023-04-03 05:35:56 --> Model "Cluster_model" initialized
INFO - 2023-04-03 05:35:56 --> Model "Cluster_model" initialized
INFO - 2023-04-03 05:35:56 --> Final output sent to browser
DEBUG - 2023-04-03 05:35:56 --> Total execution time: 0.0151
INFO - 2023-04-03 05:35:56 --> Final output sent to browser
DEBUG - 2023-04-03 05:35:56 --> Total execution time: 0.0652
INFO - 2023-04-03 05:35:57 --> Config Class Initialized
INFO - 2023-04-03 05:35:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 05:35:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 05:35:57 --> Utf8 Class Initialized
INFO - 2023-04-03 05:35:57 --> URI Class Initialized
INFO - 2023-04-03 05:35:57 --> Router Class Initialized
INFO - 2023-04-03 05:35:57 --> Output Class Initialized
INFO - 2023-04-03 05:35:57 --> Security Class Initialized
DEBUG - 2023-04-03 05:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 05:35:57 --> Input Class Initialized
INFO - 2023-04-03 05:35:57 --> Language Class Initialized
INFO - 2023-04-03 05:35:57 --> Loader Class Initialized
INFO - 2023-04-03 05:35:57 --> Controller Class Initialized
DEBUG - 2023-04-03 05:35:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 05:35:57 --> Database Driver Class Initialized
INFO - 2023-04-03 05:35:57 --> Model "Cluster_model" initialized
INFO - 2023-04-03 05:35:57 --> Final output sent to browser
DEBUG - 2023-04-03 05:35:57 --> Total execution time: 0.0433
INFO - 2023-04-03 06:18:27 --> Config Class Initialized
INFO - 2023-04-03 06:18:27 --> Config Class Initialized
INFO - 2023-04-03 06:18:27 --> Hooks Class Initialized
INFO - 2023-04-03 06:18:27 --> Config Class Initialized
INFO - 2023-04-03 06:18:27 --> Hooks Class Initialized
INFO - 2023-04-03 06:18:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:18:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:18:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:18:27 --> Utf8 Class Initialized
DEBUG - 2023-04-03 06:18:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:18:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:18:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:18:27 --> URI Class Initialized
INFO - 2023-04-03 06:18:27 --> URI Class Initialized
INFO - 2023-04-03 06:18:27 --> URI Class Initialized
INFO - 2023-04-03 06:18:27 --> Router Class Initialized
INFO - 2023-04-03 06:18:27 --> Router Class Initialized
INFO - 2023-04-03 06:18:27 --> Router Class Initialized
INFO - 2023-04-03 06:18:27 --> Output Class Initialized
INFO - 2023-04-03 06:18:27 --> Output Class Initialized
INFO - 2023-04-03 06:18:27 --> Output Class Initialized
INFO - 2023-04-03 06:18:27 --> Security Class Initialized
INFO - 2023-04-03 06:18:27 --> Security Class Initialized
INFO - 2023-04-03 06:18:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:18:27 --> Input Class Initialized
INFO - 2023-04-03 06:18:27 --> Input Class Initialized
INFO - 2023-04-03 06:18:27 --> Input Class Initialized
INFO - 2023-04-03 06:18:27 --> Language Class Initialized
INFO - 2023-04-03 06:18:27 --> Language Class Initialized
INFO - 2023-04-03 06:18:27 --> Language Class Initialized
INFO - 2023-04-03 06:18:27 --> Loader Class Initialized
INFO - 2023-04-03 06:18:27 --> Loader Class Initialized
INFO - 2023-04-03 06:18:27 --> Loader Class Initialized
INFO - 2023-04-03 06:18:27 --> Controller Class Initialized
INFO - 2023-04-03 06:18:27 --> Controller Class Initialized
INFO - 2023-04-03 06:18:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:18:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:18:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:18:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:18:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:18:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:18:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:27 --> Model "Login_model" initialized
INFO - 2023-04-03 06:18:27 --> Final output sent to browser
DEBUG - 2023-04-03 06:18:27 --> Total execution time: 0.0272
INFO - 2023-04-03 06:18:27 --> Config Class Initialized
INFO - 2023-04-03 06:18:27 --> Hooks Class Initialized
INFO - 2023-04-03 06:18:27 --> Final output sent to browser
INFO - 2023-04-03 06:18:27 --> Final output sent to browser
DEBUG - 2023-04-03 06:18:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:18:27 --> Total execution time: 0.0346
DEBUG - 2023-04-03 06:18:27 --> Total execution time: 0.0451
INFO - 2023-04-03 06:18:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:18:27 --> URI Class Initialized
INFO - 2023-04-03 06:18:27 --> Router Class Initialized
INFO - 2023-04-03 06:18:27 --> Output Class Initialized
INFO - 2023-04-03 06:18:27 --> Security Class Initialized
INFO - 2023-04-03 06:18:27 --> Config Class Initialized
INFO - 2023-04-03 06:18:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:18:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:18:27 --> Utf8 Class Initialized
DEBUG - 2023-04-03 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:18:27 --> URI Class Initialized
INFO - 2023-04-03 06:18:27 --> Config Class Initialized
INFO - 2023-04-03 06:18:27 --> Router Class Initialized
INFO - 2023-04-03 06:18:27 --> Input Class Initialized
INFO - 2023-04-03 06:18:27 --> Hooks Class Initialized
INFO - 2023-04-03 06:18:27 --> Output Class Initialized
INFO - 2023-04-03 06:18:27 --> Language Class Initialized
INFO - 2023-04-03 06:18:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:18:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:18:27 --> Loader Class Initialized
INFO - 2023-04-03 06:18:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:18:27 --> Input Class Initialized
INFO - 2023-04-03 06:18:27 --> Controller Class Initialized
INFO - 2023-04-03 06:18:27 --> URI Class Initialized
INFO - 2023-04-03 06:18:27 --> Language Class Initialized
DEBUG - 2023-04-03 06:18:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:18:27 --> Router Class Initialized
INFO - 2023-04-03 06:18:27 --> Loader Class Initialized
INFO - 2023-04-03 06:18:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:27 --> Output Class Initialized
INFO - 2023-04-03 06:18:27 --> Controller Class Initialized
INFO - 2023-04-03 06:18:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:18:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:18:27 --> Database Driver Class Initialized
DEBUG - 2023-04-03 06:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:18:27 --> Input Class Initialized
INFO - 2023-04-03 06:18:27 --> Language Class Initialized
INFO - 2023-04-03 06:18:27 --> Loader Class Initialized
INFO - 2023-04-03 06:18:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:18:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:18:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:18:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:18:27 --> Model "Login_model" initialized
INFO - 2023-04-03 06:18:27 --> Final output sent to browser
DEBUG - 2023-04-03 06:18:27 --> Total execution time: 0.0618
INFO - 2023-04-03 06:18:27 --> Config Class Initialized
INFO - 2023-04-03 06:18:27 --> Final output sent to browser
INFO - 2023-04-03 06:18:28 --> Final output sent to browser
INFO - 2023-04-03 06:18:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:18:28 --> Total execution time: 0.0746
DEBUG - 2023-04-03 06:18:28 --> Total execution time: 0.1459
DEBUG - 2023-04-03 06:18:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:18:28 --> Utf8 Class Initialized
INFO - 2023-04-03 06:18:28 --> URI Class Initialized
INFO - 2023-04-03 06:18:28 --> Config Class Initialized
INFO - 2023-04-03 06:18:28 --> Hooks Class Initialized
INFO - 2023-04-03 06:18:28 --> Router Class Initialized
INFO - 2023-04-03 06:18:28 --> Output Class Initialized
DEBUG - 2023-04-03 06:18:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:18:28 --> Security Class Initialized
INFO - 2023-04-03 06:18:28 --> Utf8 Class Initialized
DEBUG - 2023-04-03 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:18:28 --> URI Class Initialized
INFO - 2023-04-03 06:18:28 --> Input Class Initialized
INFO - 2023-04-03 06:18:28 --> Router Class Initialized
INFO - 2023-04-03 06:18:28 --> Language Class Initialized
INFO - 2023-04-03 06:18:28 --> Output Class Initialized
INFO - 2023-04-03 06:18:28 --> Security Class Initialized
INFO - 2023-04-03 06:18:28 --> Loader Class Initialized
DEBUG - 2023-04-03 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:18:28 --> Controller Class Initialized
INFO - 2023-04-03 06:18:28 --> Input Class Initialized
DEBUG - 2023-04-03 06:18:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:18:28 --> Language Class Initialized
INFO - 2023-04-03 06:18:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:28 --> Loader Class Initialized
INFO - 2023-04-03 06:18:28 --> Controller Class Initialized
DEBUG - 2023-04-03 06:18:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:18:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:18:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:18:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:18:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:18:28 --> Total execution time: 0.1446
INFO - 2023-04-03 06:18:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:18:28 --> Total execution time: 0.0594
INFO - 2023-04-03 06:19:27 --> Config Class Initialized
INFO - 2023-04-03 06:19:27 --> Config Class Initialized
INFO - 2023-04-03 06:19:27 --> Hooks Class Initialized
INFO - 2023-04-03 06:19:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:19:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:19:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:19:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:19:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:19:27 --> URI Class Initialized
INFO - 2023-04-03 06:19:27 --> URI Class Initialized
INFO - 2023-04-03 06:19:27 --> Router Class Initialized
INFO - 2023-04-03 06:19:27 --> Router Class Initialized
INFO - 2023-04-03 06:19:27 --> Output Class Initialized
INFO - 2023-04-03 06:19:27 --> Output Class Initialized
INFO - 2023-04-03 06:19:27 --> Security Class Initialized
INFO - 2023-04-03 06:19:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:19:27 --> Input Class Initialized
INFO - 2023-04-03 06:19:27 --> Input Class Initialized
INFO - 2023-04-03 06:19:27 --> Language Class Initialized
INFO - 2023-04-03 06:19:27 --> Language Class Initialized
INFO - 2023-04-03 06:19:27 --> Loader Class Initialized
INFO - 2023-04-03 06:19:27 --> Loader Class Initialized
INFO - 2023-04-03 06:19:27 --> Controller Class Initialized
INFO - 2023-04-03 06:19:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:19:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:19:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:19:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:19:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:19:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:19:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:19:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:19:27 --> Model "Login_model" initialized
INFO - 2023-04-03 06:19:27 --> Final output sent to browser
DEBUG - 2023-04-03 06:19:27 --> Total execution time: 0.0862
INFO - 2023-04-03 06:19:27 --> Config Class Initialized
INFO - 2023-04-03 06:19:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:19:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:19:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:19:27 --> URI Class Initialized
INFO - 2023-04-03 06:19:27 --> Router Class Initialized
INFO - 2023-04-03 06:19:27 --> Output Class Initialized
INFO - 2023-04-03 06:19:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:19:27 --> Input Class Initialized
INFO - 2023-04-03 06:19:27 --> Language Class Initialized
INFO - 2023-04-03 06:19:27 --> Loader Class Initialized
INFO - 2023-04-03 06:19:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:19:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:19:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:19:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:19:27 --> Final output sent to browser
DEBUG - 2023-04-03 06:19:27 --> Total execution time: 0.0508
INFO - 2023-04-03 06:19:29 --> Final output sent to browser
DEBUG - 2023-04-03 06:19:29 --> Total execution time: 1.2089
INFO - 2023-04-03 06:19:29 --> Config Class Initialized
INFO - 2023-04-03 06:19:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:19:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:19:29 --> Utf8 Class Initialized
INFO - 2023-04-03 06:19:29 --> URI Class Initialized
INFO - 2023-04-03 06:19:29 --> Router Class Initialized
INFO - 2023-04-03 06:19:29 --> Output Class Initialized
INFO - 2023-04-03 06:19:29 --> Security Class Initialized
DEBUG - 2023-04-03 06:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:19:29 --> Input Class Initialized
INFO - 2023-04-03 06:19:29 --> Language Class Initialized
INFO - 2023-04-03 06:19:29 --> Loader Class Initialized
INFO - 2023-04-03 06:19:29 --> Controller Class Initialized
DEBUG - 2023-04-03 06:19:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:19:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:19:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:19:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:19:29 --> Model "Login_model" initialized
INFO - 2023-04-03 06:19:29 --> Final output sent to browser
DEBUG - 2023-04-03 06:19:29 --> Total execution time: 0.7320
INFO - 2023-04-03 06:20:27 --> Config Class Initialized
INFO - 2023-04-03 06:20:27 --> Config Class Initialized
INFO - 2023-04-03 06:20:27 --> Hooks Class Initialized
INFO - 2023-04-03 06:20:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:20:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:20:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:20:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:20:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:20:27 --> URI Class Initialized
INFO - 2023-04-03 06:20:27 --> URI Class Initialized
INFO - 2023-04-03 06:20:27 --> Router Class Initialized
INFO - 2023-04-03 06:20:27 --> Router Class Initialized
INFO - 2023-04-03 06:20:27 --> Output Class Initialized
INFO - 2023-04-03 06:20:27 --> Output Class Initialized
INFO - 2023-04-03 06:20:27 --> Security Class Initialized
INFO - 2023-04-03 06:20:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:20:27 --> Input Class Initialized
INFO - 2023-04-03 06:20:27 --> Input Class Initialized
INFO - 2023-04-03 06:20:27 --> Language Class Initialized
INFO - 2023-04-03 06:20:27 --> Language Class Initialized
INFO - 2023-04-03 06:20:27 --> Loader Class Initialized
INFO - 2023-04-03 06:20:27 --> Loader Class Initialized
INFO - 2023-04-03 06:20:27 --> Controller Class Initialized
INFO - 2023-04-03 06:20:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:20:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:20:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:20:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:20:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:20:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:20:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:20:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:20:28 --> Model "Login_model" initialized
INFO - 2023-04-03 06:20:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:20:28 --> Total execution time: 0.0497
INFO - 2023-04-03 06:20:28 --> Config Class Initialized
INFO - 2023-04-03 06:20:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:20:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:20:28 --> Utf8 Class Initialized
INFO - 2023-04-03 06:20:28 --> URI Class Initialized
INFO - 2023-04-03 06:20:28 --> Router Class Initialized
INFO - 2023-04-03 06:20:28 --> Output Class Initialized
INFO - 2023-04-03 06:20:28 --> Security Class Initialized
DEBUG - 2023-04-03 06:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:20:28 --> Input Class Initialized
INFO - 2023-04-03 06:20:28 --> Language Class Initialized
INFO - 2023-04-03 06:20:28 --> Loader Class Initialized
INFO - 2023-04-03 06:20:28 --> Controller Class Initialized
DEBUG - 2023-04-03 06:20:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:20:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:20:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:20:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:20:28 --> Total execution time: 0.0846
INFO - 2023-04-03 06:20:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:20:28 --> Total execution time: 0.7045
INFO - 2023-04-03 06:20:28 --> Config Class Initialized
INFO - 2023-04-03 06:20:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:20:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:20:28 --> Utf8 Class Initialized
INFO - 2023-04-03 06:20:28 --> URI Class Initialized
INFO - 2023-04-03 06:20:28 --> Router Class Initialized
INFO - 2023-04-03 06:20:28 --> Output Class Initialized
INFO - 2023-04-03 06:20:28 --> Security Class Initialized
DEBUG - 2023-04-03 06:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:20:28 --> Input Class Initialized
INFO - 2023-04-03 06:20:28 --> Language Class Initialized
INFO - 2023-04-03 06:20:28 --> Loader Class Initialized
INFO - 2023-04-03 06:20:28 --> Controller Class Initialized
DEBUG - 2023-04-03 06:20:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:20:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:20:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:20:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:20:28 --> Model "Login_model" initialized
INFO - 2023-04-03 06:20:29 --> Final output sent to browser
DEBUG - 2023-04-03 06:20:29 --> Total execution time: 0.7392
INFO - 2023-04-03 06:21:27 --> Config Class Initialized
INFO - 2023-04-03 06:21:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:21:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:21:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:21:27 --> URI Class Initialized
INFO - 2023-04-03 06:21:27 --> Router Class Initialized
INFO - 2023-04-03 06:21:27 --> Output Class Initialized
INFO - 2023-04-03 06:21:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:21:27 --> Input Class Initialized
INFO - 2023-04-03 06:21:27 --> Language Class Initialized
INFO - 2023-04-03 06:21:27 --> Loader Class Initialized
INFO - 2023-04-03 06:21:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:21:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:21:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:21:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:21:27 --> Final output sent to browser
DEBUG - 2023-04-03 06:21:27 --> Total execution time: 0.0503
INFO - 2023-04-03 06:21:27 --> Config Class Initialized
INFO - 2023-04-03 06:21:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:21:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:21:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:21:27 --> URI Class Initialized
INFO - 2023-04-03 06:21:27 --> Router Class Initialized
INFO - 2023-04-03 06:21:27 --> Output Class Initialized
INFO - 2023-04-03 06:21:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:21:27 --> Input Class Initialized
INFO - 2023-04-03 06:21:27 --> Language Class Initialized
INFO - 2023-04-03 06:21:27 --> Loader Class Initialized
INFO - 2023-04-03 06:21:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:21:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:21:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:21:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:21:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:21:28 --> Total execution time: 0.0395
INFO - 2023-04-03 06:21:28 --> Config Class Initialized
INFO - 2023-04-03 06:21:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:21:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:21:28 --> Utf8 Class Initialized
INFO - 2023-04-03 06:21:28 --> URI Class Initialized
INFO - 2023-04-03 06:21:28 --> Router Class Initialized
INFO - 2023-04-03 06:21:28 --> Output Class Initialized
INFO - 2023-04-03 06:21:28 --> Security Class Initialized
DEBUG - 2023-04-03 06:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:21:28 --> Input Class Initialized
INFO - 2023-04-03 06:21:28 --> Language Class Initialized
INFO - 2023-04-03 06:21:28 --> Loader Class Initialized
INFO - 2023-04-03 06:21:28 --> Controller Class Initialized
DEBUG - 2023-04-03 06:21:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:21:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:21:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:21:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:21:28 --> Model "Login_model" initialized
INFO - 2023-04-03 06:21:29 --> Final output sent to browser
DEBUG - 2023-04-03 06:21:29 --> Total execution time: 0.6285
INFO - 2023-04-03 06:21:29 --> Config Class Initialized
INFO - 2023-04-03 06:21:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:21:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:21:29 --> Utf8 Class Initialized
INFO - 2023-04-03 06:21:29 --> URI Class Initialized
INFO - 2023-04-03 06:21:29 --> Router Class Initialized
INFO - 2023-04-03 06:21:29 --> Output Class Initialized
INFO - 2023-04-03 06:21:29 --> Security Class Initialized
DEBUG - 2023-04-03 06:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:21:29 --> Input Class Initialized
INFO - 2023-04-03 06:21:29 --> Language Class Initialized
INFO - 2023-04-03 06:21:29 --> Loader Class Initialized
INFO - 2023-04-03 06:21:29 --> Controller Class Initialized
DEBUG - 2023-04-03 06:21:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:21:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:21:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:21:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:21:29 --> Model "Login_model" initialized
INFO - 2023-04-03 06:21:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:21:30 --> Total execution time: 0.6855
INFO - 2023-04-03 06:22:28 --> Config Class Initialized
INFO - 2023-04-03 06:22:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:22:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:22:28 --> Utf8 Class Initialized
INFO - 2023-04-03 06:22:28 --> URI Class Initialized
INFO - 2023-04-03 06:22:28 --> Router Class Initialized
INFO - 2023-04-03 06:22:28 --> Output Class Initialized
INFO - 2023-04-03 06:22:28 --> Security Class Initialized
DEBUG - 2023-04-03 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:22:28 --> Input Class Initialized
INFO - 2023-04-03 06:22:28 --> Language Class Initialized
INFO - 2023-04-03 06:22:28 --> Loader Class Initialized
INFO - 2023-04-03 06:22:28 --> Controller Class Initialized
DEBUG - 2023-04-03 06:22:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:22:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:22:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:22:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:22:28 --> Total execution time: 0.1236
INFO - 2023-04-03 06:22:28 --> Config Class Initialized
INFO - 2023-04-03 06:22:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:22:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:22:28 --> Utf8 Class Initialized
INFO - 2023-04-03 06:22:28 --> URI Class Initialized
INFO - 2023-04-03 06:22:28 --> Router Class Initialized
INFO - 2023-04-03 06:22:28 --> Output Class Initialized
INFO - 2023-04-03 06:22:28 --> Security Class Initialized
DEBUG - 2023-04-03 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:22:28 --> Input Class Initialized
INFO - 2023-04-03 06:22:28 --> Language Class Initialized
INFO - 2023-04-03 06:22:28 --> Loader Class Initialized
INFO - 2023-04-03 06:22:28 --> Controller Class Initialized
DEBUG - 2023-04-03 06:22:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:22:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:22:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:22:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:22:28 --> Total execution time: 0.1182
INFO - 2023-04-03 06:22:29 --> Config Class Initialized
INFO - 2023-04-03 06:22:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:22:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:22:29 --> Utf8 Class Initialized
INFO - 2023-04-03 06:22:29 --> URI Class Initialized
INFO - 2023-04-03 06:22:29 --> Router Class Initialized
INFO - 2023-04-03 06:22:29 --> Output Class Initialized
INFO - 2023-04-03 06:22:29 --> Security Class Initialized
DEBUG - 2023-04-03 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:22:29 --> Input Class Initialized
INFO - 2023-04-03 06:22:29 --> Language Class Initialized
INFO - 2023-04-03 06:22:29 --> Loader Class Initialized
INFO - 2023-04-03 06:22:29 --> Controller Class Initialized
DEBUG - 2023-04-03 06:22:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:22:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:22:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:22:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:22:29 --> Model "Login_model" initialized
INFO - 2023-04-03 06:22:29 --> Final output sent to browser
DEBUG - 2023-04-03 06:22:29 --> Total execution time: 0.6751
INFO - 2023-04-03 06:22:29 --> Config Class Initialized
INFO - 2023-04-03 06:22:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:22:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:22:29 --> Utf8 Class Initialized
INFO - 2023-04-03 06:22:29 --> URI Class Initialized
INFO - 2023-04-03 06:22:29 --> Router Class Initialized
INFO - 2023-04-03 06:22:29 --> Output Class Initialized
INFO - 2023-04-03 06:22:29 --> Security Class Initialized
DEBUG - 2023-04-03 06:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:22:29 --> Input Class Initialized
INFO - 2023-04-03 06:22:29 --> Language Class Initialized
INFO - 2023-04-03 06:22:29 --> Loader Class Initialized
INFO - 2023-04-03 06:22:29 --> Controller Class Initialized
DEBUG - 2023-04-03 06:22:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:22:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:22:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:22:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:22:29 --> Model "Login_model" initialized
INFO - 2023-04-03 06:22:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:22:30 --> Total execution time: 0.7101
INFO - 2023-04-03 06:23:27 --> Config Class Initialized
INFO - 2023-04-03 06:23:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:23:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:23:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:23:27 --> URI Class Initialized
INFO - 2023-04-03 06:23:27 --> Router Class Initialized
INFO - 2023-04-03 06:23:27 --> Output Class Initialized
INFO - 2023-04-03 06:23:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:23:27 --> Input Class Initialized
INFO - 2023-04-03 06:23:27 --> Language Class Initialized
INFO - 2023-04-03 06:23:27 --> Loader Class Initialized
INFO - 2023-04-03 06:23:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:23:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:23:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:23:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:23:27 --> Final output sent to browser
DEBUG - 2023-04-03 06:23:27 --> Total execution time: 0.0393
INFO - 2023-04-03 06:23:27 --> Config Class Initialized
INFO - 2023-04-03 06:23:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:23:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:23:27 --> Utf8 Class Initialized
INFO - 2023-04-03 06:23:27 --> URI Class Initialized
INFO - 2023-04-03 06:23:27 --> Router Class Initialized
INFO - 2023-04-03 06:23:27 --> Output Class Initialized
INFO - 2023-04-03 06:23:27 --> Security Class Initialized
DEBUG - 2023-04-03 06:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:23:27 --> Input Class Initialized
INFO - 2023-04-03 06:23:27 --> Language Class Initialized
INFO - 2023-04-03 06:23:27 --> Loader Class Initialized
INFO - 2023-04-03 06:23:27 --> Controller Class Initialized
DEBUG - 2023-04-03 06:23:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:23:27 --> Database Driver Class Initialized
INFO - 2023-04-03 06:23:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:23:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:23:28 --> Total execution time: 0.0765
INFO - 2023-04-03 06:23:29 --> Config Class Initialized
INFO - 2023-04-03 06:23:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:23:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:23:29 --> Utf8 Class Initialized
INFO - 2023-04-03 06:23:29 --> URI Class Initialized
INFO - 2023-04-03 06:23:29 --> Router Class Initialized
INFO - 2023-04-03 06:23:29 --> Output Class Initialized
INFO - 2023-04-03 06:23:29 --> Security Class Initialized
DEBUG - 2023-04-03 06:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:23:29 --> Input Class Initialized
INFO - 2023-04-03 06:23:29 --> Language Class Initialized
INFO - 2023-04-03 06:23:29 --> Loader Class Initialized
INFO - 2023-04-03 06:23:29 --> Controller Class Initialized
DEBUG - 2023-04-03 06:23:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:23:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:23:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:23:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:23:29 --> Model "Login_model" initialized
INFO - 2023-04-03 06:23:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:23:30 --> Total execution time: 0.9266
INFO - 2023-04-03 06:23:30 --> Config Class Initialized
INFO - 2023-04-03 06:23:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:23:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:23:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:23:30 --> URI Class Initialized
INFO - 2023-04-03 06:23:30 --> Router Class Initialized
INFO - 2023-04-03 06:23:30 --> Output Class Initialized
INFO - 2023-04-03 06:23:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:23:30 --> Input Class Initialized
INFO - 2023-04-03 06:23:30 --> Language Class Initialized
INFO - 2023-04-03 06:23:30 --> Loader Class Initialized
INFO - 2023-04-03 06:23:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:23:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:23:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:23:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:23:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:23:30 --> Model "Login_model" initialized
INFO - 2023-04-03 06:23:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:23:30 --> Total execution time: 0.7122
INFO - 2023-04-03 06:24:28 --> Config Class Initialized
INFO - 2023-04-03 06:24:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:24:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:24:28 --> Utf8 Class Initialized
INFO - 2023-04-03 06:24:28 --> URI Class Initialized
INFO - 2023-04-03 06:24:28 --> Router Class Initialized
INFO - 2023-04-03 06:24:28 --> Output Class Initialized
INFO - 2023-04-03 06:24:28 --> Security Class Initialized
DEBUG - 2023-04-03 06:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:24:28 --> Input Class Initialized
INFO - 2023-04-03 06:24:28 --> Language Class Initialized
INFO - 2023-04-03 06:24:28 --> Loader Class Initialized
INFO - 2023-04-03 06:24:28 --> Controller Class Initialized
DEBUG - 2023-04-03 06:24:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:24:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:24:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:24:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:24:28 --> Total execution time: 0.1487
INFO - 2023-04-03 06:24:28 --> Config Class Initialized
INFO - 2023-04-03 06:24:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:24:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:24:28 --> Utf8 Class Initialized
INFO - 2023-04-03 06:24:28 --> URI Class Initialized
INFO - 2023-04-03 06:24:28 --> Router Class Initialized
INFO - 2023-04-03 06:24:28 --> Output Class Initialized
INFO - 2023-04-03 06:24:28 --> Security Class Initialized
DEBUG - 2023-04-03 06:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:24:28 --> Input Class Initialized
INFO - 2023-04-03 06:24:28 --> Language Class Initialized
INFO - 2023-04-03 06:24:28 --> Loader Class Initialized
INFO - 2023-04-03 06:24:28 --> Controller Class Initialized
DEBUG - 2023-04-03 06:24:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:24:28 --> Database Driver Class Initialized
INFO - 2023-04-03 06:24:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:24:28 --> Final output sent to browser
DEBUG - 2023-04-03 06:24:28 --> Total execution time: 0.0331
INFO - 2023-04-03 06:24:29 --> Config Class Initialized
INFO - 2023-04-03 06:24:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:24:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:24:29 --> Utf8 Class Initialized
INFO - 2023-04-03 06:24:29 --> URI Class Initialized
INFO - 2023-04-03 06:24:29 --> Router Class Initialized
INFO - 2023-04-03 06:24:29 --> Output Class Initialized
INFO - 2023-04-03 06:24:29 --> Security Class Initialized
DEBUG - 2023-04-03 06:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:24:29 --> Input Class Initialized
INFO - 2023-04-03 06:24:29 --> Language Class Initialized
INFO - 2023-04-03 06:24:29 --> Loader Class Initialized
INFO - 2023-04-03 06:24:29 --> Controller Class Initialized
DEBUG - 2023-04-03 06:24:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:24:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:24:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:24:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:24:29 --> Model "Login_model" initialized
INFO - 2023-04-03 06:24:29 --> Final output sent to browser
DEBUG - 2023-04-03 06:24:29 --> Total execution time: 0.7451
INFO - 2023-04-03 06:24:29 --> Config Class Initialized
INFO - 2023-04-03 06:24:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:24:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:24:29 --> Utf8 Class Initialized
INFO - 2023-04-03 06:24:29 --> URI Class Initialized
INFO - 2023-04-03 06:24:29 --> Router Class Initialized
INFO - 2023-04-03 06:24:29 --> Output Class Initialized
INFO - 2023-04-03 06:24:29 --> Security Class Initialized
DEBUG - 2023-04-03 06:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:24:29 --> Input Class Initialized
INFO - 2023-04-03 06:24:29 --> Language Class Initialized
INFO - 2023-04-03 06:24:29 --> Loader Class Initialized
INFO - 2023-04-03 06:24:29 --> Controller Class Initialized
DEBUG - 2023-04-03 06:24:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:24:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:24:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:24:29 --> Database Driver Class Initialized
INFO - 2023-04-03 06:24:29 --> Model "Login_model" initialized
INFO - 2023-04-03 06:24:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:24:30 --> Total execution time: 0.6878
INFO - 2023-04-03 06:26:04 --> Config Class Initialized
INFO - 2023-04-03 06:26:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:26:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:26:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:26:04 --> URI Class Initialized
INFO - 2023-04-03 06:26:04 --> Router Class Initialized
INFO - 2023-04-03 06:26:04 --> Output Class Initialized
INFO - 2023-04-03 06:26:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:26:04 --> Input Class Initialized
INFO - 2023-04-03 06:26:04 --> Language Class Initialized
INFO - 2023-04-03 06:26:04 --> Loader Class Initialized
INFO - 2023-04-03 06:26:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:26:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:26:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:26:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:26:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:26:04 --> Total execution time: 0.0342
INFO - 2023-04-03 06:26:04 --> Config Class Initialized
INFO - 2023-04-03 06:26:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:26:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:26:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:26:04 --> URI Class Initialized
INFO - 2023-04-03 06:26:04 --> Router Class Initialized
INFO - 2023-04-03 06:26:04 --> Output Class Initialized
INFO - 2023-04-03 06:26:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:26:04 --> Input Class Initialized
INFO - 2023-04-03 06:26:04 --> Language Class Initialized
INFO - 2023-04-03 06:26:04 --> Loader Class Initialized
INFO - 2023-04-03 06:26:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:26:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:26:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:26:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:26:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:26:04 --> Total execution time: 0.0313
INFO - 2023-04-03 06:27:03 --> Config Class Initialized
INFO - 2023-04-03 06:27:03 --> Config Class Initialized
INFO - 2023-04-03 06:27:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:27:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:27:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:27:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:27:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:27:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:27:03 --> URI Class Initialized
INFO - 2023-04-03 06:27:03 --> URI Class Initialized
INFO - 2023-04-03 06:27:03 --> Router Class Initialized
INFO - 2023-04-03 06:27:03 --> Router Class Initialized
INFO - 2023-04-03 06:27:03 --> Output Class Initialized
INFO - 2023-04-03 06:27:03 --> Output Class Initialized
INFO - 2023-04-03 06:27:03 --> Security Class Initialized
INFO - 2023-04-03 06:27:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:27:03 --> Input Class Initialized
INFO - 2023-04-03 06:27:03 --> Input Class Initialized
INFO - 2023-04-03 06:27:03 --> Language Class Initialized
INFO - 2023-04-03 06:27:03 --> Language Class Initialized
INFO - 2023-04-03 06:27:03 --> Loader Class Initialized
INFO - 2023-04-03 06:27:03 --> Controller Class Initialized
INFO - 2023-04-03 06:27:03 --> Loader Class Initialized
DEBUG - 2023-04-03 06:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:27:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:27:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:27:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:27:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:27:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:27:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:27:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:27:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:27:03 --> Total execution time: 0.0867
INFO - 2023-04-03 06:27:03 --> Config Class Initialized
INFO - 2023-04-03 06:27:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:27:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:27:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:27:03 --> URI Class Initialized
INFO - 2023-04-03 06:27:03 --> Router Class Initialized
INFO - 2023-04-03 06:27:03 --> Output Class Initialized
INFO - 2023-04-03 06:27:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:27:03 --> Input Class Initialized
INFO - 2023-04-03 06:27:03 --> Language Class Initialized
INFO - 2023-04-03 06:27:03 --> Loader Class Initialized
INFO - 2023-04-03 06:27:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:27:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:27:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:27:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:27:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:27:04 --> Total execution time: 0.0452
INFO - 2023-04-03 06:27:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:27:04 --> Total execution time: 0.7502
INFO - 2023-04-03 06:27:04 --> Config Class Initialized
INFO - 2023-04-03 06:27:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:27:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:27:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:27:04 --> URI Class Initialized
INFO - 2023-04-03 06:27:04 --> Router Class Initialized
INFO - 2023-04-03 06:27:04 --> Output Class Initialized
INFO - 2023-04-03 06:27:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:27:04 --> Input Class Initialized
INFO - 2023-04-03 06:27:04 --> Language Class Initialized
INFO - 2023-04-03 06:27:04 --> Loader Class Initialized
INFO - 2023-04-03 06:27:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:27:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:27:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:27:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:27:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:27:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:27:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:27:05 --> Total execution time: 0.6674
INFO - 2023-04-03 06:28:03 --> Config Class Initialized
INFO - 2023-04-03 06:28:03 --> Config Class Initialized
INFO - 2023-04-03 06:28:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:28:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:28:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:28:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:28:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:28:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:28:03 --> URI Class Initialized
INFO - 2023-04-03 06:28:03 --> URI Class Initialized
INFO - 2023-04-03 06:28:03 --> Router Class Initialized
INFO - 2023-04-03 06:28:03 --> Router Class Initialized
INFO - 2023-04-03 06:28:03 --> Output Class Initialized
INFO - 2023-04-03 06:28:03 --> Output Class Initialized
INFO - 2023-04-03 06:28:03 --> Security Class Initialized
INFO - 2023-04-03 06:28:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:28:03 --> Input Class Initialized
INFO - 2023-04-03 06:28:03 --> Input Class Initialized
INFO - 2023-04-03 06:28:03 --> Language Class Initialized
INFO - 2023-04-03 06:28:03 --> Language Class Initialized
INFO - 2023-04-03 06:28:03 --> Loader Class Initialized
INFO - 2023-04-03 06:28:03 --> Loader Class Initialized
INFO - 2023-04-03 06:28:03 --> Controller Class Initialized
INFO - 2023-04-03 06:28:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:28:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:28:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:28:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:28:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:28:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:28:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:28:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:28:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:28:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:28:03 --> Total execution time: 0.0550
INFO - 2023-04-03 06:28:03 --> Config Class Initialized
INFO - 2023-04-03 06:28:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:28:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:28:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:28:03 --> URI Class Initialized
INFO - 2023-04-03 06:28:03 --> Router Class Initialized
INFO - 2023-04-03 06:28:03 --> Output Class Initialized
INFO - 2023-04-03 06:28:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:28:03 --> Input Class Initialized
INFO - 2023-04-03 06:28:03 --> Language Class Initialized
INFO - 2023-04-03 06:28:03 --> Loader Class Initialized
INFO - 2023-04-03 06:28:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:28:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:28:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:28:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:28:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:28:04 --> Total execution time: 0.0415
INFO - 2023-04-03 06:28:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:28:04 --> Total execution time: 0.7831
INFO - 2023-04-03 06:28:04 --> Config Class Initialized
INFO - 2023-04-03 06:28:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:28:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:28:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:28:04 --> URI Class Initialized
INFO - 2023-04-03 06:28:04 --> Router Class Initialized
INFO - 2023-04-03 06:28:04 --> Output Class Initialized
INFO - 2023-04-03 06:28:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:28:04 --> Input Class Initialized
INFO - 2023-04-03 06:28:04 --> Language Class Initialized
INFO - 2023-04-03 06:28:04 --> Loader Class Initialized
INFO - 2023-04-03 06:28:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:28:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:28:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:28:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:28:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:28:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:28:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:28:05 --> Total execution time: 0.6408
INFO - 2023-04-03 06:29:04 --> Config Class Initialized
INFO - 2023-04-03 06:29:04 --> Config Class Initialized
INFO - 2023-04-03 06:29:04 --> Hooks Class Initialized
INFO - 2023-04-03 06:29:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:29:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:29:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:29:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:29:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:29:04 --> URI Class Initialized
INFO - 2023-04-03 06:29:04 --> URI Class Initialized
INFO - 2023-04-03 06:29:04 --> Router Class Initialized
INFO - 2023-04-03 06:29:04 --> Router Class Initialized
INFO - 2023-04-03 06:29:04 --> Output Class Initialized
INFO - 2023-04-03 06:29:04 --> Output Class Initialized
INFO - 2023-04-03 06:29:04 --> Security Class Initialized
INFO - 2023-04-03 06:29:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:29:04 --> Input Class Initialized
INFO - 2023-04-03 06:29:04 --> Input Class Initialized
INFO - 2023-04-03 06:29:04 --> Language Class Initialized
INFO - 2023-04-03 06:29:04 --> Language Class Initialized
INFO - 2023-04-03 06:29:04 --> Loader Class Initialized
INFO - 2023-04-03 06:29:04 --> Loader Class Initialized
INFO - 2023-04-03 06:29:04 --> Controller Class Initialized
INFO - 2023-04-03 06:29:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:29:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:29:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:29:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:29:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:29:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:29:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:29:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:29:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:29:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:29:04 --> Total execution time: 0.0370
INFO - 2023-04-03 06:29:04 --> Config Class Initialized
INFO - 2023-04-03 06:29:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:29:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:29:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:29:04 --> URI Class Initialized
INFO - 2023-04-03 06:29:04 --> Router Class Initialized
INFO - 2023-04-03 06:29:04 --> Output Class Initialized
INFO - 2023-04-03 06:29:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:29:04 --> Input Class Initialized
INFO - 2023-04-03 06:29:04 --> Language Class Initialized
INFO - 2023-04-03 06:29:04 --> Loader Class Initialized
INFO - 2023-04-03 06:29:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:29:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:29:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:29:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:29:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:29:04 --> Total execution time: 0.0819
INFO - 2023-04-03 06:29:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:29:04 --> Total execution time: 0.7200
INFO - 2023-04-03 06:29:04 --> Config Class Initialized
INFO - 2023-04-03 06:29:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:29:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:29:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:29:04 --> URI Class Initialized
INFO - 2023-04-03 06:29:04 --> Router Class Initialized
INFO - 2023-04-03 06:29:04 --> Output Class Initialized
INFO - 2023-04-03 06:29:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:29:04 --> Input Class Initialized
INFO - 2023-04-03 06:29:04 --> Language Class Initialized
INFO - 2023-04-03 06:29:04 --> Loader Class Initialized
INFO - 2023-04-03 06:29:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:29:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:29:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:29:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:29:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:29:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:29:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:29:05 --> Total execution time: 0.6842
INFO - 2023-04-03 06:30:04 --> Config Class Initialized
INFO - 2023-04-03 06:30:04 --> Config Class Initialized
INFO - 2023-04-03 06:30:04 --> Hooks Class Initialized
INFO - 2023-04-03 06:30:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:30:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:30:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:30:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:30:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:30:04 --> URI Class Initialized
INFO - 2023-04-03 06:30:04 --> URI Class Initialized
INFO - 2023-04-03 06:30:04 --> Router Class Initialized
INFO - 2023-04-03 06:30:04 --> Router Class Initialized
INFO - 2023-04-03 06:30:04 --> Output Class Initialized
INFO - 2023-04-03 06:30:04 --> Output Class Initialized
INFO - 2023-04-03 06:30:04 --> Security Class Initialized
INFO - 2023-04-03 06:30:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:30:04 --> Input Class Initialized
INFO - 2023-04-03 06:30:04 --> Input Class Initialized
INFO - 2023-04-03 06:30:04 --> Language Class Initialized
INFO - 2023-04-03 06:30:04 --> Language Class Initialized
INFO - 2023-04-03 06:30:04 --> Loader Class Initialized
INFO - 2023-04-03 06:30:04 --> Loader Class Initialized
INFO - 2023-04-03 06:30:04 --> Controller Class Initialized
INFO - 2023-04-03 06:30:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:30:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:30:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:30:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:30:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:30:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:30:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:30:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:30:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:30:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:30:04 --> Total execution time: 0.0580
INFO - 2023-04-03 06:30:04 --> Config Class Initialized
INFO - 2023-04-03 06:30:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:30:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:30:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:30:04 --> URI Class Initialized
INFO - 2023-04-03 06:30:04 --> Router Class Initialized
INFO - 2023-04-03 06:30:04 --> Output Class Initialized
INFO - 2023-04-03 06:30:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:30:04 --> Input Class Initialized
INFO - 2023-04-03 06:30:04 --> Language Class Initialized
INFO - 2023-04-03 06:30:04 --> Loader Class Initialized
INFO - 2023-04-03 06:30:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:30:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:30:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:30:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:30:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:30:04 --> Total execution time: 0.0893
INFO - 2023-04-03 06:30:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:30:04 --> Total execution time: 0.8993
INFO - 2023-04-03 06:30:04 --> Config Class Initialized
INFO - 2023-04-03 06:30:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:30:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:30:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:30:04 --> URI Class Initialized
INFO - 2023-04-03 06:30:04 --> Router Class Initialized
INFO - 2023-04-03 06:30:04 --> Output Class Initialized
INFO - 2023-04-03 06:30:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:30:04 --> Input Class Initialized
INFO - 2023-04-03 06:30:04 --> Language Class Initialized
INFO - 2023-04-03 06:30:04 --> Loader Class Initialized
INFO - 2023-04-03 06:30:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:30:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:30:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:30:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:30:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:30:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:30:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:30:05 --> Total execution time: 0.8755
INFO - 2023-04-03 06:31:04 --> Config Class Initialized
INFO - 2023-04-03 06:31:04 --> Config Class Initialized
INFO - 2023-04-03 06:31:04 --> Hooks Class Initialized
INFO - 2023-04-03 06:31:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:31:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:31:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:31:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:31:04 --> URI Class Initialized
INFO - 2023-04-03 06:31:04 --> URI Class Initialized
INFO - 2023-04-03 06:31:04 --> Router Class Initialized
INFO - 2023-04-03 06:31:04 --> Router Class Initialized
INFO - 2023-04-03 06:31:04 --> Output Class Initialized
INFO - 2023-04-03 06:31:04 --> Output Class Initialized
INFO - 2023-04-03 06:31:04 --> Security Class Initialized
INFO - 2023-04-03 06:31:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:31:04 --> Input Class Initialized
INFO - 2023-04-03 06:31:04 --> Input Class Initialized
INFO - 2023-04-03 06:31:04 --> Language Class Initialized
INFO - 2023-04-03 06:31:04 --> Language Class Initialized
INFO - 2023-04-03 06:31:04 --> Loader Class Initialized
INFO - 2023-04-03 06:31:04 --> Loader Class Initialized
INFO - 2023-04-03 06:31:04 --> Controller Class Initialized
INFO - 2023-04-03 06:31:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:31:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:31:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:31:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:31:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:31:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:31:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:31:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:31:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:31:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:31:04 --> Total execution time: 0.0389
INFO - 2023-04-03 06:31:04 --> Config Class Initialized
INFO - 2023-04-03 06:31:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:31:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:31:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:31:04 --> URI Class Initialized
INFO - 2023-04-03 06:31:04 --> Router Class Initialized
INFO - 2023-04-03 06:31:04 --> Output Class Initialized
INFO - 2023-04-03 06:31:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:31:04 --> Input Class Initialized
INFO - 2023-04-03 06:31:04 --> Language Class Initialized
INFO - 2023-04-03 06:31:04 --> Loader Class Initialized
INFO - 2023-04-03 06:31:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:31:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:31:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:31:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:31:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:31:04 --> Total execution time: 0.0398
INFO - 2023-04-03 06:31:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:31:04 --> Total execution time: 0.6902
INFO - 2023-04-03 06:31:04 --> Config Class Initialized
INFO - 2023-04-03 06:31:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:31:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:31:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:31:04 --> URI Class Initialized
INFO - 2023-04-03 06:31:04 --> Router Class Initialized
INFO - 2023-04-03 06:31:04 --> Output Class Initialized
INFO - 2023-04-03 06:31:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:31:04 --> Input Class Initialized
INFO - 2023-04-03 06:31:04 --> Language Class Initialized
INFO - 2023-04-03 06:31:04 --> Loader Class Initialized
INFO - 2023-04-03 06:31:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:31:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:31:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:31:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:31:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:31:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:31:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:31:05 --> Total execution time: 0.7569
INFO - 2023-04-03 06:32:03 --> Config Class Initialized
INFO - 2023-04-03 06:32:03 --> Config Class Initialized
INFO - 2023-04-03 06:32:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:32:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:32:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:32:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:32:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:32:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:32:03 --> URI Class Initialized
INFO - 2023-04-03 06:32:03 --> URI Class Initialized
INFO - 2023-04-03 06:32:03 --> Router Class Initialized
INFO - 2023-04-03 06:32:03 --> Router Class Initialized
INFO - 2023-04-03 06:32:03 --> Output Class Initialized
INFO - 2023-04-03 06:32:03 --> Output Class Initialized
INFO - 2023-04-03 06:32:03 --> Security Class Initialized
INFO - 2023-04-03 06:32:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:32:03 --> Input Class Initialized
INFO - 2023-04-03 06:32:03 --> Input Class Initialized
INFO - 2023-04-03 06:32:03 --> Language Class Initialized
INFO - 2023-04-03 06:32:03 --> Language Class Initialized
INFO - 2023-04-03 06:32:03 --> Loader Class Initialized
INFO - 2023-04-03 06:32:03 --> Loader Class Initialized
INFO - 2023-04-03 06:32:03 --> Controller Class Initialized
INFO - 2023-04-03 06:32:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:32:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:32:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:32:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:32:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:32:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:32:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:32:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:32:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:32:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:32:03 --> Total execution time: 0.0450
INFO - 2023-04-03 06:32:03 --> Config Class Initialized
INFO - 2023-04-03 06:32:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:32:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:32:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:32:03 --> URI Class Initialized
INFO - 2023-04-03 06:32:03 --> Router Class Initialized
INFO - 2023-04-03 06:32:03 --> Output Class Initialized
INFO - 2023-04-03 06:32:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:32:03 --> Input Class Initialized
INFO - 2023-04-03 06:32:03 --> Language Class Initialized
INFO - 2023-04-03 06:32:03 --> Loader Class Initialized
INFO - 2023-04-03 06:32:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:32:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:32:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:32:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:32:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:32:03 --> Total execution time: 0.0396
INFO - 2023-04-03 06:32:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:32:04 --> Total execution time: 0.7511
INFO - 2023-04-03 06:32:04 --> Config Class Initialized
INFO - 2023-04-03 06:32:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:32:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:32:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:32:04 --> URI Class Initialized
INFO - 2023-04-03 06:32:04 --> Router Class Initialized
INFO - 2023-04-03 06:32:04 --> Output Class Initialized
INFO - 2023-04-03 06:32:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:32:04 --> Input Class Initialized
INFO - 2023-04-03 06:32:04 --> Language Class Initialized
INFO - 2023-04-03 06:32:04 --> Loader Class Initialized
INFO - 2023-04-03 06:32:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:32:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:32:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:32:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:32:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:32:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:32:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:32:05 --> Total execution time: 0.7415
INFO - 2023-04-03 06:33:03 --> Config Class Initialized
INFO - 2023-04-03 06:33:03 --> Config Class Initialized
INFO - 2023-04-03 06:33:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:33:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:33:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:33:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:33:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:33:03 --> URI Class Initialized
INFO - 2023-04-03 06:33:03 --> URI Class Initialized
INFO - 2023-04-03 06:33:03 --> Router Class Initialized
INFO - 2023-04-03 06:33:03 --> Router Class Initialized
INFO - 2023-04-03 06:33:03 --> Output Class Initialized
INFO - 2023-04-03 06:33:03 --> Output Class Initialized
INFO - 2023-04-03 06:33:03 --> Security Class Initialized
INFO - 2023-04-03 06:33:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:33:03 --> Input Class Initialized
INFO - 2023-04-03 06:33:03 --> Input Class Initialized
INFO - 2023-04-03 06:33:03 --> Language Class Initialized
INFO - 2023-04-03 06:33:03 --> Language Class Initialized
INFO - 2023-04-03 06:33:03 --> Loader Class Initialized
INFO - 2023-04-03 06:33:03 --> Loader Class Initialized
INFO - 2023-04-03 06:33:03 --> Controller Class Initialized
INFO - 2023-04-03 06:33:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:33:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:33:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:33:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:33:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:33:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:33:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:33:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:33:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:33:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:33:03 --> Total execution time: 0.0444
INFO - 2023-04-03 06:33:03 --> Config Class Initialized
INFO - 2023-04-03 06:33:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:33:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:33:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:33:03 --> URI Class Initialized
INFO - 2023-04-03 06:33:03 --> Router Class Initialized
INFO - 2023-04-03 06:33:03 --> Output Class Initialized
INFO - 2023-04-03 06:33:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:33:03 --> Input Class Initialized
INFO - 2023-04-03 06:33:03 --> Language Class Initialized
INFO - 2023-04-03 06:33:03 --> Loader Class Initialized
INFO - 2023-04-03 06:33:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:33:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:33:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:33:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:33:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:33:03 --> Total execution time: 0.0444
INFO - 2023-04-03 06:33:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:33:04 --> Total execution time: 0.7230
INFO - 2023-04-03 06:33:04 --> Config Class Initialized
INFO - 2023-04-03 06:33:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:33:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:33:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:33:04 --> URI Class Initialized
INFO - 2023-04-03 06:33:04 --> Router Class Initialized
INFO - 2023-04-03 06:33:04 --> Output Class Initialized
INFO - 2023-04-03 06:33:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:33:04 --> Input Class Initialized
INFO - 2023-04-03 06:33:04 --> Language Class Initialized
INFO - 2023-04-03 06:33:04 --> Loader Class Initialized
INFO - 2023-04-03 06:33:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:33:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:33:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:33:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:33:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:33:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:33:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:33:05 --> Total execution time: 0.6928
INFO - 2023-04-03 06:34:04 --> Config Class Initialized
INFO - 2023-04-03 06:34:04 --> Config Class Initialized
INFO - 2023-04-03 06:34:04 --> Hooks Class Initialized
INFO - 2023-04-03 06:34:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:34:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:34:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:34:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:34:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:34:04 --> URI Class Initialized
INFO - 2023-04-03 06:34:04 --> URI Class Initialized
INFO - 2023-04-03 06:34:04 --> Router Class Initialized
INFO - 2023-04-03 06:34:04 --> Router Class Initialized
INFO - 2023-04-03 06:34:04 --> Output Class Initialized
INFO - 2023-04-03 06:34:04 --> Output Class Initialized
INFO - 2023-04-03 06:34:04 --> Security Class Initialized
INFO - 2023-04-03 06:34:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:34:04 --> Input Class Initialized
INFO - 2023-04-03 06:34:04 --> Input Class Initialized
INFO - 2023-04-03 06:34:04 --> Language Class Initialized
INFO - 2023-04-03 06:34:04 --> Language Class Initialized
INFO - 2023-04-03 06:34:04 --> Loader Class Initialized
INFO - 2023-04-03 06:34:04 --> Loader Class Initialized
INFO - 2023-04-03 06:34:04 --> Controller Class Initialized
INFO - 2023-04-03 06:34:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:34:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:34:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:34:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:34:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:34:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:34:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:34:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:34:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:34:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:34:04 --> Total execution time: 0.0410
INFO - 2023-04-03 06:34:04 --> Config Class Initialized
INFO - 2023-04-03 06:34:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:34:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:34:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:34:04 --> URI Class Initialized
INFO - 2023-04-03 06:34:04 --> Router Class Initialized
INFO - 2023-04-03 06:34:04 --> Output Class Initialized
INFO - 2023-04-03 06:34:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:34:04 --> Input Class Initialized
INFO - 2023-04-03 06:34:04 --> Language Class Initialized
INFO - 2023-04-03 06:34:04 --> Loader Class Initialized
INFO - 2023-04-03 06:34:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:34:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:34:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:34:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:34:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:34:04 --> Total execution time: 0.0366
INFO - 2023-04-03 06:34:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:34:04 --> Total execution time: 0.6663
INFO - 2023-04-03 06:34:04 --> Config Class Initialized
INFO - 2023-04-03 06:34:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:34:05 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:34:05 --> Utf8 Class Initialized
INFO - 2023-04-03 06:34:05 --> URI Class Initialized
INFO - 2023-04-03 06:34:05 --> Router Class Initialized
INFO - 2023-04-03 06:34:05 --> Output Class Initialized
INFO - 2023-04-03 06:34:05 --> Security Class Initialized
DEBUG - 2023-04-03 06:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:34:05 --> Input Class Initialized
INFO - 2023-04-03 06:34:05 --> Language Class Initialized
INFO - 2023-04-03 06:34:05 --> Loader Class Initialized
INFO - 2023-04-03 06:34:05 --> Controller Class Initialized
DEBUG - 2023-04-03 06:34:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:34:05 --> Database Driver Class Initialized
INFO - 2023-04-03 06:34:05 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:34:05 --> Database Driver Class Initialized
INFO - 2023-04-03 06:34:05 --> Model "Login_model" initialized
INFO - 2023-04-03 06:34:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:34:05 --> Total execution time: 0.6640
INFO - 2023-04-03 06:35:04 --> Config Class Initialized
INFO - 2023-04-03 06:35:04 --> Config Class Initialized
INFO - 2023-04-03 06:35:04 --> Hooks Class Initialized
INFO - 2023-04-03 06:35:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:35:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:35:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:35:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:35:04 --> URI Class Initialized
INFO - 2023-04-03 06:35:04 --> URI Class Initialized
INFO - 2023-04-03 06:35:04 --> Router Class Initialized
INFO - 2023-04-03 06:35:04 --> Router Class Initialized
INFO - 2023-04-03 06:35:04 --> Output Class Initialized
INFO - 2023-04-03 06:35:04 --> Output Class Initialized
INFO - 2023-04-03 06:35:04 --> Security Class Initialized
INFO - 2023-04-03 06:35:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:35:04 --> Input Class Initialized
INFO - 2023-04-03 06:35:04 --> Input Class Initialized
INFO - 2023-04-03 06:35:04 --> Language Class Initialized
INFO - 2023-04-03 06:35:04 --> Language Class Initialized
INFO - 2023-04-03 06:35:04 --> Loader Class Initialized
INFO - 2023-04-03 06:35:04 --> Loader Class Initialized
INFO - 2023-04-03 06:35:04 --> Controller Class Initialized
INFO - 2023-04-03 06:35:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:35:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:35:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:35:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:35:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:35:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:35:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:35:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:35:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:35:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:35:04 --> Total execution time: 0.0395
INFO - 2023-04-03 06:35:04 --> Config Class Initialized
INFO - 2023-04-03 06:35:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:35:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:35:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:35:04 --> URI Class Initialized
INFO - 2023-04-03 06:35:04 --> Router Class Initialized
INFO - 2023-04-03 06:35:04 --> Output Class Initialized
INFO - 2023-04-03 06:35:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:35:04 --> Input Class Initialized
INFO - 2023-04-03 06:35:04 --> Language Class Initialized
INFO - 2023-04-03 06:35:04 --> Loader Class Initialized
INFO - 2023-04-03 06:35:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:35:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:35:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:35:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:35:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:35:04 --> Total execution time: 0.0733
INFO - 2023-04-03 06:35:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:35:04 --> Total execution time: 0.6784
INFO - 2023-04-03 06:35:04 --> Config Class Initialized
INFO - 2023-04-03 06:35:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:35:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:35:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:35:04 --> URI Class Initialized
INFO - 2023-04-03 06:35:04 --> Router Class Initialized
INFO - 2023-04-03 06:35:04 --> Output Class Initialized
INFO - 2023-04-03 06:35:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:35:04 --> Input Class Initialized
INFO - 2023-04-03 06:35:04 --> Language Class Initialized
INFO - 2023-04-03 06:35:04 --> Loader Class Initialized
INFO - 2023-04-03 06:35:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:35:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:35:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:35:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:35:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:35:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:35:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:35:05 --> Total execution time: 0.7068
INFO - 2023-04-03 06:36:04 --> Config Class Initialized
INFO - 2023-04-03 06:36:04 --> Config Class Initialized
INFO - 2023-04-03 06:36:04 --> Hooks Class Initialized
INFO - 2023-04-03 06:36:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:36:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:04 --> URI Class Initialized
INFO - 2023-04-03 06:36:04 --> URI Class Initialized
INFO - 2023-04-03 06:36:04 --> Router Class Initialized
INFO - 2023-04-03 06:36:04 --> Router Class Initialized
INFO - 2023-04-03 06:36:04 --> Output Class Initialized
INFO - 2023-04-03 06:36:04 --> Output Class Initialized
INFO - 2023-04-03 06:36:04 --> Security Class Initialized
INFO - 2023-04-03 06:36:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:04 --> Input Class Initialized
INFO - 2023-04-03 06:36:04 --> Input Class Initialized
INFO - 2023-04-03 06:36:04 --> Language Class Initialized
INFO - 2023-04-03 06:36:04 --> Language Class Initialized
INFO - 2023-04-03 06:36:04 --> Loader Class Initialized
INFO - 2023-04-03 06:36:04 --> Loader Class Initialized
INFO - 2023-04-03 06:36:04 --> Controller Class Initialized
INFO - 2023-04-03 06:36:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:36:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:36:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:04 --> Total execution time: 0.0374
INFO - 2023-04-03 06:36:04 --> Config Class Initialized
INFO - 2023-04-03 06:36:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:04 --> URI Class Initialized
INFO - 2023-04-03 06:36:04 --> Router Class Initialized
INFO - 2023-04-03 06:36:04 --> Output Class Initialized
INFO - 2023-04-03 06:36:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:04 --> Input Class Initialized
INFO - 2023-04-03 06:36:04 --> Language Class Initialized
INFO - 2023-04-03 06:36:04 --> Loader Class Initialized
INFO - 2023-04-03 06:36:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:04 --> Total execution time: 0.0798
INFO - 2023-04-03 06:36:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:04 --> Total execution time: 0.6183
INFO - 2023-04-03 06:36:04 --> Config Class Initialized
INFO - 2023-04-03 06:36:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:04 --> URI Class Initialized
INFO - 2023-04-03 06:36:04 --> Router Class Initialized
INFO - 2023-04-03 06:36:04 --> Output Class Initialized
INFO - 2023-04-03 06:36:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:04 --> Input Class Initialized
INFO - 2023-04-03 06:36:04 --> Language Class Initialized
INFO - 2023-04-03 06:36:04 --> Loader Class Initialized
INFO - 2023-04-03 06:36:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:36:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:05 --> Total execution time: 0.6506
INFO - 2023-04-03 06:36:50 --> Config Class Initialized
INFO - 2023-04-03 06:36:50 --> Config Class Initialized
INFO - 2023-04-03 06:36:50 --> Hooks Class Initialized
INFO - 2023-04-03 06:36:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:36:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:50 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:50 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:50 --> URI Class Initialized
INFO - 2023-04-03 06:36:50 --> URI Class Initialized
INFO - 2023-04-03 06:36:50 --> Router Class Initialized
INFO - 2023-04-03 06:36:50 --> Router Class Initialized
INFO - 2023-04-03 06:36:50 --> Output Class Initialized
INFO - 2023-04-03 06:36:50 --> Output Class Initialized
INFO - 2023-04-03 06:36:50 --> Security Class Initialized
INFO - 2023-04-03 06:36:50 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:50 --> Input Class Initialized
INFO - 2023-04-03 06:36:50 --> Input Class Initialized
INFO - 2023-04-03 06:36:50 --> Language Class Initialized
INFO - 2023-04-03 06:36:50 --> Language Class Initialized
INFO - 2023-04-03 06:36:50 --> Loader Class Initialized
INFO - 2023-04-03 06:36:50 --> Loader Class Initialized
INFO - 2023-04-03 06:36:50 --> Controller Class Initialized
INFO - 2023-04-03 06:36:50 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:50 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:50 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:50 --> Config Class Initialized
INFO - 2023-04-03 06:36:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:50 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:50 --> URI Class Initialized
INFO - 2023-04-03 06:36:50 --> Router Class Initialized
INFO - 2023-04-03 06:36:50 --> Output Class Initialized
INFO - 2023-04-03 06:36:50 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:50 --> Input Class Initialized
INFO - 2023-04-03 06:36:50 --> Language Class Initialized
INFO - 2023-04-03 06:36:50 --> Loader Class Initialized
INFO - 2023-04-03 06:36:50 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:50 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:50 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:50 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:50 --> Model "Login_model" initialized
INFO - 2023-04-03 06:36:50 --> Model "Login_model" initialized
INFO - 2023-04-03 06:36:50 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:50 --> Total execution time: 0.0420
INFO - 2023-04-03 06:36:50 --> Config Class Initialized
INFO - 2023-04-03 06:36:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:50 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:50 --> URI Class Initialized
INFO - 2023-04-03 06:36:50 --> Router Class Initialized
INFO - 2023-04-03 06:36:50 --> Output Class Initialized
INFO - 2023-04-03 06:36:50 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:50 --> Input Class Initialized
INFO - 2023-04-03 06:36:50 --> Language Class Initialized
INFO - 2023-04-03 06:36:50 --> Loader Class Initialized
INFO - 2023-04-03 06:36:50 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:50 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:50 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:50 --> Total execution time: 0.0543
INFO - 2023-04-03 06:36:50 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:50 --> Total execution time: 0.8272
INFO - 2023-04-03 06:36:50 --> Config Class Initialized
INFO - 2023-04-03 06:36:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:50 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:50 --> URI Class Initialized
INFO - 2023-04-03 06:36:50 --> Router Class Initialized
INFO - 2023-04-03 06:36:50 --> Output Class Initialized
INFO - 2023-04-03 06:36:50 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:50 --> Input Class Initialized
INFO - 2023-04-03 06:36:50 --> Language Class Initialized
INFO - 2023-04-03 06:36:50 --> Loader Class Initialized
INFO - 2023-04-03 06:36:50 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:50 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:50 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:50 --> Total execution time: 0.8274
INFO - 2023-04-03 06:36:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:50 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:50 --> Model "Login_model" initialized
INFO - 2023-04-03 06:36:51 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:51 --> Total execution time: 0.6511
INFO - 2023-04-03 06:36:51 --> Config Class Initialized
INFO - 2023-04-03 06:36:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:51 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:51 --> URI Class Initialized
INFO - 2023-04-03 06:36:51 --> Router Class Initialized
INFO - 2023-04-03 06:36:51 --> Output Class Initialized
INFO - 2023-04-03 06:36:51 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:51 --> Input Class Initialized
INFO - 2023-04-03 06:36:51 --> Language Class Initialized
INFO - 2023-04-03 06:36:51 --> Loader Class Initialized
INFO - 2023-04-03 06:36:51 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:51 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:51 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:51 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:51 --> Model "Login_model" initialized
INFO - 2023-04-03 06:36:52 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:52 --> Total execution time: 0.6868
INFO - 2023-04-03 06:36:52 --> Config Class Initialized
INFO - 2023-04-03 06:36:52 --> Config Class Initialized
INFO - 2023-04-03 06:36:52 --> Hooks Class Initialized
INFO - 2023-04-03 06:36:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:36:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:52 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:52 --> Config Class Initialized
INFO - 2023-04-03 06:36:52 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:52 --> Hooks Class Initialized
INFO - 2023-04-03 06:36:52 --> URI Class Initialized
INFO - 2023-04-03 06:36:52 --> URI Class Initialized
DEBUG - 2023-04-03 06:36:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:52 --> Router Class Initialized
INFO - 2023-04-03 06:36:52 --> Router Class Initialized
INFO - 2023-04-03 06:36:52 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:52 --> Output Class Initialized
INFO - 2023-04-03 06:36:52 --> Output Class Initialized
INFO - 2023-04-03 06:36:52 --> URI Class Initialized
INFO - 2023-04-03 06:36:52 --> Security Class Initialized
INFO - 2023-04-03 06:36:52 --> Security Class Initialized
INFO - 2023-04-03 06:36:52 --> Router Class Initialized
DEBUG - 2023-04-03 06:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:52 --> Output Class Initialized
INFO - 2023-04-03 06:36:52 --> Input Class Initialized
INFO - 2023-04-03 06:36:52 --> Security Class Initialized
INFO - 2023-04-03 06:36:52 --> Input Class Initialized
INFO - 2023-04-03 06:36:53 --> Language Class Initialized
INFO - 2023-04-03 06:36:53 --> Language Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:53 --> Loader Class Initialized
INFO - 2023-04-03 06:36:53 --> Input Class Initialized
INFO - 2023-04-03 06:36:53 --> Loader Class Initialized
INFO - 2023-04-03 06:36:53 --> Controller Class Initialized
INFO - 2023-04-03 06:36:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:53 --> Language Class Initialized
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Loader Class Initialized
INFO - 2023-04-03 06:36:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Model "Login_model" initialized
INFO - 2023-04-03 06:36:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:53 --> Total execution time: 0.1065
INFO - 2023-04-03 06:36:53 --> Config Class Initialized
INFO - 2023-04-03 06:36:53 --> Final output sent to browser
INFO - 2023-04-03 06:36:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:53 --> Total execution time: 0.1107
INFO - 2023-04-03 06:36:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Total execution time: 0.1194
DEBUG - 2023-04-03 06:36:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:53 --> URI Class Initialized
INFO - 2023-04-03 06:36:53 --> Config Class Initialized
INFO - 2023-04-03 06:36:53 --> Router Class Initialized
INFO - 2023-04-03 06:36:53 --> Config Class Initialized
INFO - 2023-04-03 06:36:53 --> Hooks Class Initialized
INFO - 2023-04-03 06:36:53 --> Hooks Class Initialized
INFO - 2023-04-03 06:36:53 --> Output Class Initialized
DEBUG - 2023-04-03 06:36:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:53 --> Utf8 Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:53 --> URI Class Initialized
INFO - 2023-04-03 06:36:53 --> URI Class Initialized
INFO - 2023-04-03 06:36:53 --> Input Class Initialized
INFO - 2023-04-03 06:36:53 --> Router Class Initialized
INFO - 2023-04-03 06:36:53 --> Router Class Initialized
INFO - 2023-04-03 06:36:53 --> Language Class Initialized
INFO - 2023-04-03 06:36:53 --> Output Class Initialized
INFO - 2023-04-03 06:36:53 --> Output Class Initialized
INFO - 2023-04-03 06:36:53 --> Security Class Initialized
INFO - 2023-04-03 06:36:53 --> Security Class Initialized
INFO - 2023-04-03 06:36:53 --> Loader Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:53 --> Input Class Initialized
INFO - 2023-04-03 06:36:53 --> Controller Class Initialized
INFO - 2023-04-03 06:36:53 --> Input Class Initialized
INFO - 2023-04-03 06:36:53 --> Language Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:53 --> Language Class Initialized
INFO - 2023-04-03 06:36:53 --> Loader Class Initialized
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Loader Class Initialized
INFO - 2023-04-03 06:36:53 --> Controller Class Initialized
INFO - 2023-04-03 06:36:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Model "Login_model" initialized
INFO - 2023-04-03 06:36:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:53 --> Total execution time: 0.0646
INFO - 2023-04-03 06:36:53 --> Final output sent to browser
INFO - 2023-04-03 06:36:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:53 --> Total execution time: 0.1075
DEBUG - 2023-04-03 06:36:53 --> Total execution time: 0.0644
INFO - 2023-04-03 06:36:53 --> Config Class Initialized
INFO - 2023-04-03 06:36:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:36:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:36:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:36:53 --> URI Class Initialized
INFO - 2023-04-03 06:36:53 --> Router Class Initialized
INFO - 2023-04-03 06:36:53 --> Output Class Initialized
INFO - 2023-04-03 06:36:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:36:53 --> Input Class Initialized
INFO - 2023-04-03 06:36:53 --> Language Class Initialized
INFO - 2023-04-03 06:36:53 --> Loader Class Initialized
INFO - 2023-04-03 06:36:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:36:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:36:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:36:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:36:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:36:53 --> Total execution time: 0.1008
INFO - 2023-04-03 06:37:52 --> Config Class Initialized
INFO - 2023-04-03 06:37:52 --> Config Class Initialized
INFO - 2023-04-03 06:37:52 --> Hooks Class Initialized
INFO - 2023-04-03 06:37:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:37:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:37:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:37:52 --> Utf8 Class Initialized
INFO - 2023-04-03 06:37:52 --> Utf8 Class Initialized
INFO - 2023-04-03 06:37:52 --> URI Class Initialized
INFO - 2023-04-03 06:37:52 --> URI Class Initialized
INFO - 2023-04-03 06:37:52 --> Router Class Initialized
INFO - 2023-04-03 06:37:52 --> Router Class Initialized
INFO - 2023-04-03 06:37:52 --> Output Class Initialized
INFO - 2023-04-03 06:37:52 --> Output Class Initialized
INFO - 2023-04-03 06:37:52 --> Security Class Initialized
INFO - 2023-04-03 06:37:52 --> Security Class Initialized
DEBUG - 2023-04-03 06:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:37:52 --> Input Class Initialized
INFO - 2023-04-03 06:37:52 --> Input Class Initialized
INFO - 2023-04-03 06:37:52 --> Language Class Initialized
INFO - 2023-04-03 06:37:52 --> Language Class Initialized
INFO - 2023-04-03 06:37:52 --> Loader Class Initialized
INFO - 2023-04-03 06:37:52 --> Loader Class Initialized
INFO - 2023-04-03 06:37:52 --> Controller Class Initialized
INFO - 2023-04-03 06:37:52 --> Controller Class Initialized
DEBUG - 2023-04-03 06:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:37:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:37:52 --> Database Driver Class Initialized
INFO - 2023-04-03 06:37:52 --> Database Driver Class Initialized
INFO - 2023-04-03 06:37:52 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:37:52 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:37:52 --> Database Driver Class Initialized
INFO - 2023-04-03 06:37:53 --> Final output sent to browser
INFO - 2023-04-03 06:37:53 --> Model "Login_model" initialized
INFO - 2023-04-03 06:37:53 --> Config Class Initialized
INFO - 2023-04-03 06:37:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:37:53 --> Total execution time: 0.1137
DEBUG - 2023-04-03 06:37:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:37:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:37:53 --> URI Class Initialized
INFO - 2023-04-03 06:37:53 --> Router Class Initialized
INFO - 2023-04-03 06:37:53 --> Output Class Initialized
INFO - 2023-04-03 06:37:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:37:53 --> Input Class Initialized
INFO - 2023-04-03 06:37:53 --> Language Class Initialized
INFO - 2023-04-03 06:37:53 --> Loader Class Initialized
INFO - 2023-04-03 06:37:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:37:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:37:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:37:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:37:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:37:53 --> Total execution time: 0.0728
INFO - 2023-04-03 06:37:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:37:53 --> Total execution time: 0.8396
INFO - 2023-04-03 06:37:53 --> Config Class Initialized
INFO - 2023-04-03 06:37:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:37:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:37:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:37:53 --> URI Class Initialized
INFO - 2023-04-03 06:37:53 --> Router Class Initialized
INFO - 2023-04-03 06:37:53 --> Output Class Initialized
INFO - 2023-04-03 06:37:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:37:53 --> Input Class Initialized
INFO - 2023-04-03 06:37:53 --> Language Class Initialized
INFO - 2023-04-03 06:37:53 --> Loader Class Initialized
INFO - 2023-04-03 06:37:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:37:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:37:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:37:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:37:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:37:53 --> Model "Login_model" initialized
INFO - 2023-04-03 06:37:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:37:54 --> Total execution time: 0.6012
INFO - 2023-04-03 06:38:52 --> Config Class Initialized
INFO - 2023-04-03 06:38:52 --> Config Class Initialized
INFO - 2023-04-03 06:38:52 --> Hooks Class Initialized
INFO - 2023-04-03 06:38:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:38:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:38:52 --> Utf8 Class Initialized
INFO - 2023-04-03 06:38:52 --> Utf8 Class Initialized
INFO - 2023-04-03 06:38:52 --> URI Class Initialized
INFO - 2023-04-03 06:38:52 --> URI Class Initialized
INFO - 2023-04-03 06:38:52 --> Router Class Initialized
INFO - 2023-04-03 06:38:52 --> Router Class Initialized
INFO - 2023-04-03 06:38:52 --> Output Class Initialized
INFO - 2023-04-03 06:38:52 --> Output Class Initialized
INFO - 2023-04-03 06:38:52 --> Security Class Initialized
INFO - 2023-04-03 06:38:52 --> Security Class Initialized
DEBUG - 2023-04-03 06:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:38:52 --> Input Class Initialized
INFO - 2023-04-03 06:38:52 --> Input Class Initialized
INFO - 2023-04-03 06:38:52 --> Language Class Initialized
INFO - 2023-04-03 06:38:52 --> Language Class Initialized
INFO - 2023-04-03 06:38:52 --> Loader Class Initialized
INFO - 2023-04-03 06:38:52 --> Loader Class Initialized
INFO - 2023-04-03 06:38:52 --> Controller Class Initialized
INFO - 2023-04-03 06:38:52 --> Controller Class Initialized
DEBUG - 2023-04-03 06:38:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:38:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:38:52 --> Database Driver Class Initialized
INFO - 2023-04-03 06:38:52 --> Database Driver Class Initialized
INFO - 2023-04-03 06:38:52 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:38:52 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:38:52 --> Database Driver Class Initialized
INFO - 2023-04-03 06:38:52 --> Model "Login_model" initialized
INFO - 2023-04-03 06:38:52 --> Final output sent to browser
DEBUG - 2023-04-03 06:38:52 --> Total execution time: 0.0424
INFO - 2023-04-03 06:38:52 --> Config Class Initialized
INFO - 2023-04-03 06:38:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:38:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:38:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:38:53 --> URI Class Initialized
INFO - 2023-04-03 06:38:53 --> Router Class Initialized
INFO - 2023-04-03 06:38:53 --> Output Class Initialized
INFO - 2023-04-03 06:38:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:38:53 --> Input Class Initialized
INFO - 2023-04-03 06:38:53 --> Language Class Initialized
INFO - 2023-04-03 06:38:53 --> Loader Class Initialized
INFO - 2023-04-03 06:38:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:38:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:38:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:38:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:38:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:38:53 --> Total execution time: 0.0796
INFO - 2023-04-03 06:38:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:38:53 --> Total execution time: 0.6677
INFO - 2023-04-03 06:38:53 --> Config Class Initialized
INFO - 2023-04-03 06:38:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:38:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:38:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:38:53 --> URI Class Initialized
INFO - 2023-04-03 06:38:53 --> Router Class Initialized
INFO - 2023-04-03 06:38:53 --> Output Class Initialized
INFO - 2023-04-03 06:38:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:38:53 --> Input Class Initialized
INFO - 2023-04-03 06:38:53 --> Language Class Initialized
INFO - 2023-04-03 06:38:53 --> Loader Class Initialized
INFO - 2023-04-03 06:38:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:38:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:38:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:38:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:38:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:38:53 --> Model "Login_model" initialized
INFO - 2023-04-03 06:38:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:38:54 --> Total execution time: 0.6026
INFO - 2023-04-03 06:39:54 --> Config Class Initialized
INFO - 2023-04-03 06:39:54 --> Config Class Initialized
INFO - 2023-04-03 06:39:54 --> Hooks Class Initialized
INFO - 2023-04-03 06:39:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:39:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:39:54 --> Utf8 Class Initialized
INFO - 2023-04-03 06:39:54 --> Utf8 Class Initialized
INFO - 2023-04-03 06:39:54 --> URI Class Initialized
INFO - 2023-04-03 06:39:54 --> URI Class Initialized
INFO - 2023-04-03 06:39:54 --> Router Class Initialized
INFO - 2023-04-03 06:39:54 --> Router Class Initialized
INFO - 2023-04-03 06:39:54 --> Output Class Initialized
INFO - 2023-04-03 06:39:54 --> Output Class Initialized
INFO - 2023-04-03 06:39:54 --> Security Class Initialized
INFO - 2023-04-03 06:39:54 --> Security Class Initialized
DEBUG - 2023-04-03 06:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:39:54 --> Input Class Initialized
INFO - 2023-04-03 06:39:54 --> Input Class Initialized
INFO - 2023-04-03 06:39:54 --> Language Class Initialized
INFO - 2023-04-03 06:39:54 --> Language Class Initialized
INFO - 2023-04-03 06:39:54 --> Loader Class Initialized
INFO - 2023-04-03 06:39:54 --> Loader Class Initialized
INFO - 2023-04-03 06:39:54 --> Controller Class Initialized
INFO - 2023-04-03 06:39:54 --> Controller Class Initialized
DEBUG - 2023-04-03 06:39:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:39:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:39:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:39:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:39:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:39:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:39:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:39:54 --> Model "Login_model" initialized
INFO - 2023-04-03 06:39:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:39:54 --> Total execution time: 0.0379
INFO - 2023-04-03 06:39:54 --> Config Class Initialized
INFO - 2023-04-03 06:39:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:39:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:39:54 --> Utf8 Class Initialized
INFO - 2023-04-03 06:39:54 --> URI Class Initialized
INFO - 2023-04-03 06:39:54 --> Router Class Initialized
INFO - 2023-04-03 06:39:54 --> Output Class Initialized
INFO - 2023-04-03 06:39:54 --> Security Class Initialized
DEBUG - 2023-04-03 06:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:39:54 --> Input Class Initialized
INFO - 2023-04-03 06:39:54 --> Language Class Initialized
INFO - 2023-04-03 06:39:54 --> Loader Class Initialized
INFO - 2023-04-03 06:39:54 --> Controller Class Initialized
DEBUG - 2023-04-03 06:39:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:39:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:39:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:39:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:39:54 --> Total execution time: 0.0739
INFO - 2023-04-03 06:39:55 --> Final output sent to browser
DEBUG - 2023-04-03 06:39:55 --> Total execution time: 0.6690
INFO - 2023-04-03 06:39:55 --> Config Class Initialized
INFO - 2023-04-03 06:39:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:39:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:39:55 --> Utf8 Class Initialized
INFO - 2023-04-03 06:39:55 --> URI Class Initialized
INFO - 2023-04-03 06:39:55 --> Router Class Initialized
INFO - 2023-04-03 06:39:55 --> Output Class Initialized
INFO - 2023-04-03 06:39:55 --> Security Class Initialized
DEBUG - 2023-04-03 06:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:39:55 --> Input Class Initialized
INFO - 2023-04-03 06:39:55 --> Language Class Initialized
INFO - 2023-04-03 06:39:55 --> Loader Class Initialized
INFO - 2023-04-03 06:39:55 --> Controller Class Initialized
DEBUG - 2023-04-03 06:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:39:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:39:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:39:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:39:55 --> Model "Login_model" initialized
INFO - 2023-04-03 06:39:56 --> Final output sent to browser
DEBUG - 2023-04-03 06:39:56 --> Total execution time: 0.7493
INFO - 2023-04-03 06:40:54 --> Config Class Initialized
INFO - 2023-04-03 06:40:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:40:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:40:54 --> Utf8 Class Initialized
INFO - 2023-04-03 06:40:54 --> URI Class Initialized
INFO - 2023-04-03 06:40:54 --> Router Class Initialized
INFO - 2023-04-03 06:40:54 --> Output Class Initialized
INFO - 2023-04-03 06:40:54 --> Security Class Initialized
DEBUG - 2023-04-03 06:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:40:54 --> Input Class Initialized
INFO - 2023-04-03 06:40:54 --> Language Class Initialized
INFO - 2023-04-03 06:40:54 --> Loader Class Initialized
INFO - 2023-04-03 06:40:54 --> Controller Class Initialized
DEBUG - 2023-04-03 06:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:40:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:40:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:40:54 --> Final output sent to browser
INFO - 2023-04-03 06:40:54 --> Config Class Initialized
INFO - 2023-04-03 06:40:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:40:54 --> Total execution time: 0.0343
DEBUG - 2023-04-03 06:40:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:40:54 --> Utf8 Class Initialized
INFO - 2023-04-03 06:40:54 --> URI Class Initialized
INFO - 2023-04-03 06:40:54 --> Router Class Initialized
INFO - 2023-04-03 06:40:54 --> Output Class Initialized
INFO - 2023-04-03 06:40:54 --> Security Class Initialized
DEBUG - 2023-04-03 06:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:40:54 --> Input Class Initialized
INFO - 2023-04-03 06:40:54 --> Language Class Initialized
INFO - 2023-04-03 06:40:54 --> Loader Class Initialized
INFO - 2023-04-03 06:40:54 --> Controller Class Initialized
DEBUG - 2023-04-03 06:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:40:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:40:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:40:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:40:54 --> Total execution time: 0.0737
INFO - 2023-04-03 06:40:54 --> Config Class Initialized
INFO - 2023-04-03 06:40:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:40:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:40:55 --> Utf8 Class Initialized
INFO - 2023-04-03 06:40:55 --> URI Class Initialized
INFO - 2023-04-03 06:40:55 --> Router Class Initialized
INFO - 2023-04-03 06:40:55 --> Output Class Initialized
INFO - 2023-04-03 06:40:55 --> Security Class Initialized
DEBUG - 2023-04-03 06:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:40:55 --> Input Class Initialized
INFO - 2023-04-03 06:40:55 --> Language Class Initialized
INFO - 2023-04-03 06:40:55 --> Loader Class Initialized
INFO - 2023-04-03 06:40:55 --> Controller Class Initialized
DEBUG - 2023-04-03 06:40:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:40:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:40:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:40:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:40:55 --> Model "Login_model" initialized
INFO - 2023-04-03 06:40:55 --> Final output sent to browser
DEBUG - 2023-04-03 06:40:55 --> Total execution time: 0.6026
INFO - 2023-04-03 06:40:55 --> Config Class Initialized
INFO - 2023-04-03 06:40:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:40:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:40:55 --> Utf8 Class Initialized
INFO - 2023-04-03 06:40:55 --> URI Class Initialized
INFO - 2023-04-03 06:40:55 --> Router Class Initialized
INFO - 2023-04-03 06:40:55 --> Output Class Initialized
INFO - 2023-04-03 06:40:55 --> Security Class Initialized
DEBUG - 2023-04-03 06:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:40:55 --> Input Class Initialized
INFO - 2023-04-03 06:40:55 --> Language Class Initialized
INFO - 2023-04-03 06:40:55 --> Loader Class Initialized
INFO - 2023-04-03 06:40:55 --> Controller Class Initialized
DEBUG - 2023-04-03 06:40:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:40:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:40:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:40:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:40:55 --> Model "Login_model" initialized
INFO - 2023-04-03 06:40:56 --> Final output sent to browser
DEBUG - 2023-04-03 06:40:56 --> Total execution time: 0.6417
INFO - 2023-04-03 06:41:53 --> Config Class Initialized
INFO - 2023-04-03 06:41:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:41:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:41:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:41:53 --> URI Class Initialized
INFO - 2023-04-03 06:41:53 --> Router Class Initialized
INFO - 2023-04-03 06:41:53 --> Output Class Initialized
INFO - 2023-04-03 06:41:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:41:53 --> Input Class Initialized
INFO - 2023-04-03 06:41:53 --> Language Class Initialized
INFO - 2023-04-03 06:41:53 --> Loader Class Initialized
INFO - 2023-04-03 06:41:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:41:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:41:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:41:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:41:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:41:53 --> Total execution time: 0.0354
INFO - 2023-04-03 06:41:53 --> Config Class Initialized
INFO - 2023-04-03 06:41:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:41:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:41:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:41:54 --> URI Class Initialized
INFO - 2023-04-03 06:41:54 --> Router Class Initialized
INFO - 2023-04-03 06:41:54 --> Output Class Initialized
INFO - 2023-04-03 06:41:54 --> Security Class Initialized
DEBUG - 2023-04-03 06:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:41:54 --> Input Class Initialized
INFO - 2023-04-03 06:41:54 --> Language Class Initialized
INFO - 2023-04-03 06:41:54 --> Loader Class Initialized
INFO - 2023-04-03 06:41:54 --> Controller Class Initialized
DEBUG - 2023-04-03 06:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:41:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:41:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:41:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:41:54 --> Total execution time: 0.2424
INFO - 2023-04-03 06:41:55 --> Config Class Initialized
INFO - 2023-04-03 06:41:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:41:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:41:55 --> Utf8 Class Initialized
INFO - 2023-04-03 06:41:55 --> URI Class Initialized
INFO - 2023-04-03 06:41:55 --> Router Class Initialized
INFO - 2023-04-03 06:41:55 --> Output Class Initialized
INFO - 2023-04-03 06:41:55 --> Security Class Initialized
DEBUG - 2023-04-03 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:41:55 --> Input Class Initialized
INFO - 2023-04-03 06:41:55 --> Language Class Initialized
INFO - 2023-04-03 06:41:55 --> Loader Class Initialized
INFO - 2023-04-03 06:41:55 --> Controller Class Initialized
DEBUG - 2023-04-03 06:41:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:41:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:41:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:41:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:41:55 --> Model "Login_model" initialized
INFO - 2023-04-03 06:41:55 --> Final output sent to browser
DEBUG - 2023-04-03 06:41:55 --> Total execution time: 0.6668
INFO - 2023-04-03 06:41:55 --> Config Class Initialized
INFO - 2023-04-03 06:41:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:41:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:41:55 --> Utf8 Class Initialized
INFO - 2023-04-03 06:41:55 --> URI Class Initialized
INFO - 2023-04-03 06:41:55 --> Router Class Initialized
INFO - 2023-04-03 06:41:55 --> Output Class Initialized
INFO - 2023-04-03 06:41:55 --> Security Class Initialized
DEBUG - 2023-04-03 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:41:55 --> Input Class Initialized
INFO - 2023-04-03 06:41:55 --> Language Class Initialized
INFO - 2023-04-03 06:41:55 --> Loader Class Initialized
INFO - 2023-04-03 06:41:55 --> Controller Class Initialized
DEBUG - 2023-04-03 06:41:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:41:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:41:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:41:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:41:55 --> Model "Login_model" initialized
INFO - 2023-04-03 06:41:56 --> Final output sent to browser
DEBUG - 2023-04-03 06:41:56 --> Total execution time: 0.6453
INFO - 2023-04-03 06:42:54 --> Config Class Initialized
INFO - 2023-04-03 06:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:42:54 --> Utf8 Class Initialized
INFO - 2023-04-03 06:42:54 --> URI Class Initialized
INFO - 2023-04-03 06:42:54 --> Router Class Initialized
INFO - 2023-04-03 06:42:54 --> Output Class Initialized
INFO - 2023-04-03 06:42:54 --> Security Class Initialized
DEBUG - 2023-04-03 06:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:42:54 --> Input Class Initialized
INFO - 2023-04-03 06:42:54 --> Language Class Initialized
INFO - 2023-04-03 06:42:54 --> Loader Class Initialized
INFO - 2023-04-03 06:42:54 --> Controller Class Initialized
DEBUG - 2023-04-03 06:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:42:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:42:54 --> Config Class Initialized
INFO - 2023-04-03 06:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:42:54 --> Utf8 Class Initialized
INFO - 2023-04-03 06:42:54 --> URI Class Initialized
INFO - 2023-04-03 06:42:54 --> Router Class Initialized
INFO - 2023-04-03 06:42:54 --> Output Class Initialized
INFO - 2023-04-03 06:42:54 --> Security Class Initialized
DEBUG - 2023-04-03 06:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:42:54 --> Input Class Initialized
INFO - 2023-04-03 06:42:54 --> Language Class Initialized
INFO - 2023-04-03 06:42:54 --> Loader Class Initialized
INFO - 2023-04-03 06:42:54 --> Controller Class Initialized
DEBUG - 2023-04-03 06:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:42:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:42:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:42:54 --> Model "Login_model" initialized
INFO - 2023-04-03 06:42:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:42:54 --> Total execution time: 0.0371
INFO - 2023-04-03 06:42:54 --> Config Class Initialized
INFO - 2023-04-03 06:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:42:54 --> Utf8 Class Initialized
INFO - 2023-04-03 06:42:54 --> URI Class Initialized
INFO - 2023-04-03 06:42:54 --> Router Class Initialized
INFO - 2023-04-03 06:42:54 --> Output Class Initialized
INFO - 2023-04-03 06:42:54 --> Security Class Initialized
DEBUG - 2023-04-03 06:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:42:54 --> Input Class Initialized
INFO - 2023-04-03 06:42:54 --> Language Class Initialized
INFO - 2023-04-03 06:42:54 --> Loader Class Initialized
INFO - 2023-04-03 06:42:54 --> Controller Class Initialized
DEBUG - 2023-04-03 06:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:42:54 --> Database Driver Class Initialized
INFO - 2023-04-03 06:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:42:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:42:54 --> Total execution time: 0.0436
INFO - 2023-04-03 06:42:55 --> Final output sent to browser
DEBUG - 2023-04-03 06:42:55 --> Total execution time: 0.6436
INFO - 2023-04-03 06:42:55 --> Config Class Initialized
INFO - 2023-04-03 06:42:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:42:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:42:55 --> Utf8 Class Initialized
INFO - 2023-04-03 06:42:55 --> URI Class Initialized
INFO - 2023-04-03 06:42:55 --> Router Class Initialized
INFO - 2023-04-03 06:42:55 --> Output Class Initialized
INFO - 2023-04-03 06:42:55 --> Security Class Initialized
DEBUG - 2023-04-03 06:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:42:55 --> Input Class Initialized
INFO - 2023-04-03 06:42:55 --> Language Class Initialized
INFO - 2023-04-03 06:42:55 --> Loader Class Initialized
INFO - 2023-04-03 06:42:55 --> Controller Class Initialized
DEBUG - 2023-04-03 06:42:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:42:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:42:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:42:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:42:55 --> Model "Login_model" initialized
INFO - 2023-04-03 06:42:56 --> Final output sent to browser
DEBUG - 2023-04-03 06:42:56 --> Total execution time: 0.7036
INFO - 2023-04-03 06:43:53 --> Config Class Initialized
INFO - 2023-04-03 06:43:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:43:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:43:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:43:53 --> URI Class Initialized
INFO - 2023-04-03 06:43:53 --> Router Class Initialized
INFO - 2023-04-03 06:43:53 --> Output Class Initialized
INFO - 2023-04-03 06:43:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:43:53 --> Input Class Initialized
INFO - 2023-04-03 06:43:53 --> Language Class Initialized
INFO - 2023-04-03 06:43:53 --> Loader Class Initialized
INFO - 2023-04-03 06:43:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:43:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:43:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:43:53 --> Final output sent to browser
DEBUG - 2023-04-03 06:43:53 --> Total execution time: 0.0388
INFO - 2023-04-03 06:43:53 --> Config Class Initialized
INFO - 2023-04-03 06:43:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:43:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:43:53 --> Utf8 Class Initialized
INFO - 2023-04-03 06:43:53 --> URI Class Initialized
INFO - 2023-04-03 06:43:53 --> Router Class Initialized
INFO - 2023-04-03 06:43:53 --> Output Class Initialized
INFO - 2023-04-03 06:43:53 --> Security Class Initialized
DEBUG - 2023-04-03 06:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:43:53 --> Input Class Initialized
INFO - 2023-04-03 06:43:53 --> Language Class Initialized
INFO - 2023-04-03 06:43:53 --> Loader Class Initialized
INFO - 2023-04-03 06:43:53 --> Controller Class Initialized
DEBUG - 2023-04-03 06:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:43:53 --> Database Driver Class Initialized
INFO - 2023-04-03 06:43:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:43:54 --> Final output sent to browser
DEBUG - 2023-04-03 06:43:54 --> Total execution time: 0.0380
INFO - 2023-04-03 06:43:55 --> Config Class Initialized
INFO - 2023-04-03 06:43:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:43:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:43:55 --> Utf8 Class Initialized
INFO - 2023-04-03 06:43:55 --> URI Class Initialized
INFO - 2023-04-03 06:43:55 --> Router Class Initialized
INFO - 2023-04-03 06:43:55 --> Output Class Initialized
INFO - 2023-04-03 06:43:55 --> Security Class Initialized
DEBUG - 2023-04-03 06:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:43:55 --> Input Class Initialized
INFO - 2023-04-03 06:43:55 --> Language Class Initialized
INFO - 2023-04-03 06:43:55 --> Loader Class Initialized
INFO - 2023-04-03 06:43:55 --> Controller Class Initialized
DEBUG - 2023-04-03 06:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:43:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:43:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:43:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:43:55 --> Model "Login_model" initialized
INFO - 2023-04-03 06:43:55 --> Final output sent to browser
DEBUG - 2023-04-03 06:43:55 --> Total execution time: 0.7569
INFO - 2023-04-03 06:43:55 --> Config Class Initialized
INFO - 2023-04-03 06:43:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:43:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:43:55 --> Utf8 Class Initialized
INFO - 2023-04-03 06:43:55 --> URI Class Initialized
INFO - 2023-04-03 06:43:55 --> Router Class Initialized
INFO - 2023-04-03 06:43:55 --> Output Class Initialized
INFO - 2023-04-03 06:43:55 --> Security Class Initialized
DEBUG - 2023-04-03 06:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:43:55 --> Input Class Initialized
INFO - 2023-04-03 06:43:55 --> Language Class Initialized
INFO - 2023-04-03 06:43:55 --> Loader Class Initialized
INFO - 2023-04-03 06:43:55 --> Controller Class Initialized
DEBUG - 2023-04-03 06:43:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:43:55 --> Database Driver Class Initialized
INFO - 2023-04-03 06:43:56 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:43:56 --> Database Driver Class Initialized
INFO - 2023-04-03 06:43:56 --> Model "Login_model" initialized
INFO - 2023-04-03 06:43:56 --> Final output sent to browser
DEBUG - 2023-04-03 06:43:56 --> Total execution time: 0.7916
INFO - 2023-04-03 06:45:12 --> Config Class Initialized
INFO - 2023-04-03 06:45:12 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:45:12 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:45:12 --> Utf8 Class Initialized
INFO - 2023-04-03 06:45:12 --> URI Class Initialized
INFO - 2023-04-03 06:45:12 --> Router Class Initialized
INFO - 2023-04-03 06:45:12 --> Output Class Initialized
INFO - 2023-04-03 06:45:12 --> Security Class Initialized
DEBUG - 2023-04-03 06:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:45:12 --> Input Class Initialized
INFO - 2023-04-03 06:45:12 --> Language Class Initialized
INFO - 2023-04-03 06:45:12 --> Loader Class Initialized
INFO - 2023-04-03 06:45:12 --> Controller Class Initialized
DEBUG - 2023-04-03 06:45:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:45:12 --> Database Driver Class Initialized
INFO - 2023-04-03 06:45:12 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:45:12 --> Final output sent to browser
DEBUG - 2023-04-03 06:45:12 --> Total execution time: 0.0808
INFO - 2023-04-03 06:45:12 --> Config Class Initialized
INFO - 2023-04-03 06:45:12 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:45:12 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:45:12 --> Utf8 Class Initialized
INFO - 2023-04-03 06:45:12 --> URI Class Initialized
INFO - 2023-04-03 06:45:12 --> Router Class Initialized
INFO - 2023-04-03 06:45:12 --> Output Class Initialized
INFO - 2023-04-03 06:45:12 --> Security Class Initialized
DEBUG - 2023-04-03 06:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:45:12 --> Input Class Initialized
INFO - 2023-04-03 06:45:12 --> Language Class Initialized
INFO - 2023-04-03 06:45:12 --> Loader Class Initialized
INFO - 2023-04-03 06:45:12 --> Controller Class Initialized
DEBUG - 2023-04-03 06:45:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:45:12 --> Database Driver Class Initialized
INFO - 2023-04-03 06:45:12 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:45:12 --> Final output sent to browser
DEBUG - 2023-04-03 06:45:12 --> Total execution time: 0.0359
INFO - 2023-04-03 06:46:11 --> Config Class Initialized
INFO - 2023-04-03 06:46:11 --> Config Class Initialized
INFO - 2023-04-03 06:46:11 --> Hooks Class Initialized
INFO - 2023-04-03 06:46:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:46:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:46:11 --> Utf8 Class Initialized
INFO - 2023-04-03 06:46:11 --> Utf8 Class Initialized
INFO - 2023-04-03 06:46:11 --> URI Class Initialized
INFO - 2023-04-03 06:46:11 --> URI Class Initialized
INFO - 2023-04-03 06:46:11 --> Router Class Initialized
INFO - 2023-04-03 06:46:11 --> Router Class Initialized
INFO - 2023-04-03 06:46:11 --> Output Class Initialized
INFO - 2023-04-03 06:46:11 --> Output Class Initialized
INFO - 2023-04-03 06:46:11 --> Security Class Initialized
INFO - 2023-04-03 06:46:11 --> Security Class Initialized
DEBUG - 2023-04-03 06:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:46:11 --> Input Class Initialized
INFO - 2023-04-03 06:46:11 --> Input Class Initialized
INFO - 2023-04-03 06:46:11 --> Language Class Initialized
INFO - 2023-04-03 06:46:11 --> Language Class Initialized
INFO - 2023-04-03 06:46:11 --> Loader Class Initialized
INFO - 2023-04-03 06:46:11 --> Loader Class Initialized
INFO - 2023-04-03 06:46:11 --> Controller Class Initialized
INFO - 2023-04-03 06:46:11 --> Controller Class Initialized
DEBUG - 2023-04-03 06:46:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:46:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:46:11 --> Database Driver Class Initialized
INFO - 2023-04-03 06:46:11 --> Database Driver Class Initialized
INFO - 2023-04-03 06:46:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:46:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:46:11 --> Database Driver Class Initialized
INFO - 2023-04-03 06:46:11 --> Model "Login_model" initialized
INFO - 2023-04-03 06:46:11 --> Final output sent to browser
DEBUG - 2023-04-03 06:46:11 --> Total execution time: 0.0392
INFO - 2023-04-03 06:46:11 --> Config Class Initialized
INFO - 2023-04-03 06:46:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:46:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:46:11 --> Utf8 Class Initialized
INFO - 2023-04-03 06:46:11 --> URI Class Initialized
INFO - 2023-04-03 06:46:11 --> Router Class Initialized
INFO - 2023-04-03 06:46:11 --> Output Class Initialized
INFO - 2023-04-03 06:46:11 --> Security Class Initialized
DEBUG - 2023-04-03 06:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:46:11 --> Input Class Initialized
INFO - 2023-04-03 06:46:11 --> Language Class Initialized
INFO - 2023-04-03 06:46:11 --> Loader Class Initialized
INFO - 2023-04-03 06:46:11 --> Controller Class Initialized
DEBUG - 2023-04-03 06:46:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:46:11 --> Database Driver Class Initialized
INFO - 2023-04-03 06:46:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:46:11 --> Final output sent to browser
DEBUG - 2023-04-03 06:46:11 --> Total execution time: 0.0818
INFO - 2023-04-03 06:46:12 --> Final output sent to browser
DEBUG - 2023-04-03 06:46:12 --> Total execution time: 0.6697
INFO - 2023-04-03 06:46:12 --> Config Class Initialized
INFO - 2023-04-03 06:46:12 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:46:12 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:46:12 --> Utf8 Class Initialized
INFO - 2023-04-03 06:46:12 --> URI Class Initialized
INFO - 2023-04-03 06:46:12 --> Router Class Initialized
INFO - 2023-04-03 06:46:12 --> Output Class Initialized
INFO - 2023-04-03 06:46:12 --> Security Class Initialized
DEBUG - 2023-04-03 06:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:46:12 --> Input Class Initialized
INFO - 2023-04-03 06:46:12 --> Language Class Initialized
INFO - 2023-04-03 06:46:12 --> Loader Class Initialized
INFO - 2023-04-03 06:46:12 --> Controller Class Initialized
DEBUG - 2023-04-03 06:46:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:46:12 --> Database Driver Class Initialized
INFO - 2023-04-03 06:46:12 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:46:12 --> Database Driver Class Initialized
INFO - 2023-04-03 06:46:12 --> Model "Login_model" initialized
INFO - 2023-04-03 06:46:13 --> Final output sent to browser
DEBUG - 2023-04-03 06:46:13 --> Total execution time: 0.6842
INFO - 2023-04-03 06:47:03 --> Config Class Initialized
INFO - 2023-04-03 06:47:03 --> Config Class Initialized
INFO - 2023-04-03 06:47:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:47:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:47:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:47:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:47:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:47:03 --> URI Class Initialized
INFO - 2023-04-03 06:47:03 --> URI Class Initialized
INFO - 2023-04-03 06:47:03 --> Router Class Initialized
INFO - 2023-04-03 06:47:03 --> Router Class Initialized
INFO - 2023-04-03 06:47:03 --> Output Class Initialized
INFO - 2023-04-03 06:47:03 --> Output Class Initialized
INFO - 2023-04-03 06:47:03 --> Security Class Initialized
INFO - 2023-04-03 06:47:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:47:03 --> Input Class Initialized
DEBUG - 2023-04-03 06:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:47:03 --> Language Class Initialized
INFO - 2023-04-03 06:47:03 --> Input Class Initialized
INFO - 2023-04-03 06:47:03 --> Loader Class Initialized
INFO - 2023-04-03 06:47:03 --> Language Class Initialized
INFO - 2023-04-03 06:47:03 --> Controller Class Initialized
INFO - 2023-04-03 06:47:03 --> Loader Class Initialized
DEBUG - 2023-04-03 06:47:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:47:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:47:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:47:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:47:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:47:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:47:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:47:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:47:03 --> Total execution time: 0.0430
INFO - 2023-04-03 06:47:03 --> Config Class Initialized
INFO - 2023-04-03 06:47:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:47:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:47:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:47:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:47:03 --> URI Class Initialized
INFO - 2023-04-03 06:47:03 --> Router Class Initialized
INFO - 2023-04-03 06:47:03 --> Output Class Initialized
INFO - 2023-04-03 06:47:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:47:03 --> Input Class Initialized
INFO - 2023-04-03 06:47:03 --> Language Class Initialized
INFO - 2023-04-03 06:47:03 --> Loader Class Initialized
INFO - 2023-04-03 06:47:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:47:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:47:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:47:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:47:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:47:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:47:03 --> Total execution time: 0.0859
INFO - 2023-04-03 06:47:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:47:04 --> Total execution time: 0.7161
INFO - 2023-04-03 06:47:04 --> Config Class Initialized
INFO - 2023-04-03 06:47:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:47:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:47:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:47:04 --> URI Class Initialized
INFO - 2023-04-03 06:47:04 --> Router Class Initialized
INFO - 2023-04-03 06:47:04 --> Output Class Initialized
INFO - 2023-04-03 06:47:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:47:04 --> Input Class Initialized
INFO - 2023-04-03 06:47:04 --> Language Class Initialized
INFO - 2023-04-03 06:47:04 --> Loader Class Initialized
INFO - 2023-04-03 06:47:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:47:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:47:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:47:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:47:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:47:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:47:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:47:05 --> Total execution time: 0.6153
INFO - 2023-04-03 06:48:03 --> Config Class Initialized
INFO - 2023-04-03 06:48:03 --> Config Class Initialized
INFO - 2023-04-03 06:48:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:48:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:48:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:48:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:48:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:48:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:48:03 --> URI Class Initialized
INFO - 2023-04-03 06:48:03 --> URI Class Initialized
INFO - 2023-04-03 06:48:03 --> Router Class Initialized
INFO - 2023-04-03 06:48:03 --> Router Class Initialized
INFO - 2023-04-03 06:48:03 --> Output Class Initialized
INFO - 2023-04-03 06:48:03 --> Output Class Initialized
INFO - 2023-04-03 06:48:03 --> Security Class Initialized
INFO - 2023-04-03 06:48:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:48:03 --> Input Class Initialized
INFO - 2023-04-03 06:48:03 --> Input Class Initialized
INFO - 2023-04-03 06:48:03 --> Language Class Initialized
INFO - 2023-04-03 06:48:03 --> Language Class Initialized
INFO - 2023-04-03 06:48:03 --> Loader Class Initialized
INFO - 2023-04-03 06:48:03 --> Loader Class Initialized
INFO - 2023-04-03 06:48:03 --> Controller Class Initialized
INFO - 2023-04-03 06:48:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:48:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:48:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:48:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:48:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:48:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:48:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:48:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:48:03 --> Total execution time: 0.0848
INFO - 2023-04-03 06:48:03 --> Config Class Initialized
INFO - 2023-04-03 06:48:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:48:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:48:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:48:03 --> URI Class Initialized
INFO - 2023-04-03 06:48:03 --> Router Class Initialized
INFO - 2023-04-03 06:48:03 --> Output Class Initialized
INFO - 2023-04-03 06:48:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:48:03 --> Input Class Initialized
INFO - 2023-04-03 06:48:03 --> Language Class Initialized
INFO - 2023-04-03 06:48:03 --> Loader Class Initialized
INFO - 2023-04-03 06:48:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:48:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:48:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:48:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:48:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:48:03 --> Total execution time: 0.0455
INFO - 2023-04-03 06:48:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:48:04 --> Total execution time: 0.8991
INFO - 2023-04-03 06:48:04 --> Config Class Initialized
INFO - 2023-04-03 06:48:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:48:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:48:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:48:04 --> URI Class Initialized
INFO - 2023-04-03 06:48:04 --> Router Class Initialized
INFO - 2023-04-03 06:48:04 --> Output Class Initialized
INFO - 2023-04-03 06:48:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:48:04 --> Input Class Initialized
INFO - 2023-04-03 06:48:04 --> Language Class Initialized
INFO - 2023-04-03 06:48:04 --> Loader Class Initialized
INFO - 2023-04-03 06:48:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:48:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:48:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:48:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:48:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:48:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:48:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:48:05 --> Total execution time: 0.7238
INFO - 2023-04-03 06:49:03 --> Config Class Initialized
INFO - 2023-04-03 06:49:03 --> Config Class Initialized
INFO - 2023-04-03 06:49:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:49:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:49:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:49:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:49:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:49:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:49:03 --> URI Class Initialized
INFO - 2023-04-03 06:49:03 --> URI Class Initialized
INFO - 2023-04-03 06:49:03 --> Router Class Initialized
INFO - 2023-04-03 06:49:03 --> Router Class Initialized
INFO - 2023-04-03 06:49:03 --> Output Class Initialized
INFO - 2023-04-03 06:49:03 --> Output Class Initialized
INFO - 2023-04-03 06:49:03 --> Security Class Initialized
INFO - 2023-04-03 06:49:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:49:03 --> Input Class Initialized
INFO - 2023-04-03 06:49:03 --> Input Class Initialized
INFO - 2023-04-03 06:49:03 --> Language Class Initialized
INFO - 2023-04-03 06:49:03 --> Language Class Initialized
INFO - 2023-04-03 06:49:03 --> Loader Class Initialized
INFO - 2023-04-03 06:49:03 --> Controller Class Initialized
INFO - 2023-04-03 06:49:03 --> Loader Class Initialized
DEBUG - 2023-04-03 06:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:49:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:49:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:49:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:49:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:49:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:49:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:49:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:49:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:49:03 --> Total execution time: 0.0840
INFO - 2023-04-03 06:49:03 --> Config Class Initialized
INFO - 2023-04-03 06:49:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:49:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:49:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:49:03 --> URI Class Initialized
INFO - 2023-04-03 06:49:03 --> Router Class Initialized
INFO - 2023-04-03 06:49:03 --> Output Class Initialized
INFO - 2023-04-03 06:49:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:49:03 --> Input Class Initialized
INFO - 2023-04-03 06:49:03 --> Language Class Initialized
INFO - 2023-04-03 06:49:03 --> Loader Class Initialized
INFO - 2023-04-03 06:49:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:49:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:49:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:49:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:49:03 --> Total execution time: 0.0431
INFO - 2023-04-03 06:49:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:49:04 --> Total execution time: 0.6944
INFO - 2023-04-03 06:49:04 --> Config Class Initialized
INFO - 2023-04-03 06:49:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:49:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:49:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:49:04 --> URI Class Initialized
INFO - 2023-04-03 06:49:04 --> Router Class Initialized
INFO - 2023-04-03 06:49:04 --> Output Class Initialized
INFO - 2023-04-03 06:49:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:49:04 --> Input Class Initialized
INFO - 2023-04-03 06:49:04 --> Language Class Initialized
INFO - 2023-04-03 06:49:04 --> Loader Class Initialized
INFO - 2023-04-03 06:49:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:49:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:49:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:49:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:49:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:49:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:49:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:49:05 --> Total execution time: 0.7300
INFO - 2023-04-03 06:50:03 --> Config Class Initialized
INFO - 2023-04-03 06:50:03 --> Config Class Initialized
INFO - 2023-04-03 06:50:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:50:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:50:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:50:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:50:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:50:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:50:03 --> URI Class Initialized
INFO - 2023-04-03 06:50:03 --> URI Class Initialized
INFO - 2023-04-03 06:50:03 --> Router Class Initialized
INFO - 2023-04-03 06:50:03 --> Router Class Initialized
INFO - 2023-04-03 06:50:03 --> Output Class Initialized
INFO - 2023-04-03 06:50:03 --> Output Class Initialized
INFO - 2023-04-03 06:50:03 --> Security Class Initialized
INFO - 2023-04-03 06:50:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:50:03 --> Input Class Initialized
INFO - 2023-04-03 06:50:03 --> Input Class Initialized
INFO - 2023-04-03 06:50:03 --> Language Class Initialized
INFO - 2023-04-03 06:50:03 --> Language Class Initialized
INFO - 2023-04-03 06:50:03 --> Loader Class Initialized
INFO - 2023-04-03 06:50:03 --> Loader Class Initialized
INFO - 2023-04-03 06:50:03 --> Controller Class Initialized
INFO - 2023-04-03 06:50:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:50:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:50:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:50:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:50:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:50:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:50:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:50:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:50:03 --> Total execution time: 0.0969
INFO - 2023-04-03 06:50:03 --> Config Class Initialized
INFO - 2023-04-03 06:50:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:50:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:50:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:50:03 --> URI Class Initialized
INFO - 2023-04-03 06:50:03 --> Router Class Initialized
INFO - 2023-04-03 06:50:03 --> Output Class Initialized
INFO - 2023-04-03 06:50:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:50:03 --> Input Class Initialized
INFO - 2023-04-03 06:50:03 --> Language Class Initialized
INFO - 2023-04-03 06:50:03 --> Loader Class Initialized
INFO - 2023-04-03 06:50:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:50:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:50:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:50:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:50:03 --> Total execution time: 0.0418
INFO - 2023-04-03 06:50:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:50:04 --> Total execution time: 0.7501
INFO - 2023-04-03 06:50:04 --> Config Class Initialized
INFO - 2023-04-03 06:50:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:50:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:50:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:50:04 --> URI Class Initialized
INFO - 2023-04-03 06:50:04 --> Router Class Initialized
INFO - 2023-04-03 06:50:04 --> Output Class Initialized
INFO - 2023-04-03 06:50:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:50:04 --> Input Class Initialized
INFO - 2023-04-03 06:50:04 --> Language Class Initialized
INFO - 2023-04-03 06:50:04 --> Loader Class Initialized
INFO - 2023-04-03 06:50:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:50:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:50:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:50:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:50:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:50:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:50:05 --> Total execution time: 0.5914
INFO - 2023-04-03 06:51:03 --> Config Class Initialized
INFO - 2023-04-03 06:51:03 --> Config Class Initialized
INFO - 2023-04-03 06:51:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:51:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:03 --> URI Class Initialized
INFO - 2023-04-03 06:51:03 --> URI Class Initialized
INFO - 2023-04-03 06:51:03 --> Router Class Initialized
INFO - 2023-04-03 06:51:03 --> Router Class Initialized
INFO - 2023-04-03 06:51:03 --> Output Class Initialized
INFO - 2023-04-03 06:51:03 --> Output Class Initialized
INFO - 2023-04-03 06:51:03 --> Security Class Initialized
INFO - 2023-04-03 06:51:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:03 --> Input Class Initialized
INFO - 2023-04-03 06:51:03 --> Input Class Initialized
INFO - 2023-04-03 06:51:03 --> Language Class Initialized
INFO - 2023-04-03 06:51:03 --> Language Class Initialized
INFO - 2023-04-03 06:51:03 --> Loader Class Initialized
INFO - 2023-04-03 06:51:03 --> Loader Class Initialized
INFO - 2023-04-03 06:51:03 --> Controller Class Initialized
INFO - 2023-04-03 06:51:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:03 --> Total execution time: 0.0397
INFO - 2023-04-03 06:51:03 --> Config Class Initialized
INFO - 2023-04-03 06:51:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:03 --> URI Class Initialized
INFO - 2023-04-03 06:51:03 --> Router Class Initialized
INFO - 2023-04-03 06:51:03 --> Output Class Initialized
INFO - 2023-04-03 06:51:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:03 --> Input Class Initialized
INFO - 2023-04-03 06:51:03 --> Language Class Initialized
INFO - 2023-04-03 06:51:03 --> Loader Class Initialized
INFO - 2023-04-03 06:51:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:51:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:03 --> Total execution time: 0.0377
INFO - 2023-04-03 06:51:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:04 --> Total execution time: 0.6813
INFO - 2023-04-03 06:51:04 --> Config Class Initialized
INFO - 2023-04-03 06:51:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:04 --> URI Class Initialized
INFO - 2023-04-03 06:51:04 --> Router Class Initialized
INFO - 2023-04-03 06:51:04 --> Output Class Initialized
INFO - 2023-04-03 06:51:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:04 --> Input Class Initialized
INFO - 2023-04-03 06:51:04 --> Language Class Initialized
INFO - 2023-04-03 06:51:04 --> Loader Class Initialized
INFO - 2023-04-03 06:51:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:51:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:05 --> Total execution time: 0.6069
INFO - 2023-04-03 06:51:22 --> Config Class Initialized
INFO - 2023-04-03 06:51:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:22 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:22 --> URI Class Initialized
INFO - 2023-04-03 06:51:22 --> Router Class Initialized
INFO - 2023-04-03 06:51:22 --> Output Class Initialized
INFO - 2023-04-03 06:51:22 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:22 --> Input Class Initialized
INFO - 2023-04-03 06:51:22 --> Language Class Initialized
INFO - 2023-04-03 06:51:22 --> Loader Class Initialized
INFO - 2023-04-03 06:51:22 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:22 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:22 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:22 --> Model "Login_model" initialized
INFO - 2023-04-03 06:51:23 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:23 --> Total execution time: 0.6264
INFO - 2023-04-03 06:51:23 --> Config Class Initialized
INFO - 2023-04-03 06:51:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:23 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:23 --> URI Class Initialized
INFO - 2023-04-03 06:51:23 --> Router Class Initialized
INFO - 2023-04-03 06:51:23 --> Output Class Initialized
INFO - 2023-04-03 06:51:23 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:23 --> Input Class Initialized
INFO - 2023-04-03 06:51:23 --> Language Class Initialized
INFO - 2023-04-03 06:51:23 --> Loader Class Initialized
INFO - 2023-04-03 06:51:23 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:23 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:23 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:23 --> Model "Login_model" initialized
INFO - 2023-04-03 06:51:23 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:23 --> Total execution time: 0.5822
INFO - 2023-04-03 06:51:26 --> Config Class Initialized
INFO - 2023-04-03 06:51:26 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:26 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:26 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:26 --> URI Class Initialized
INFO - 2023-04-03 06:51:26 --> Router Class Initialized
INFO - 2023-04-03 06:51:26 --> Output Class Initialized
INFO - 2023-04-03 06:51:26 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:26 --> Input Class Initialized
INFO - 2023-04-03 06:51:26 --> Language Class Initialized
INFO - 2023-04-03 06:51:26 --> Loader Class Initialized
INFO - 2023-04-03 06:51:26 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:26 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:26 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:26 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:26 --> Total execution time: 0.0134
INFO - 2023-04-03 06:51:26 --> Config Class Initialized
INFO - 2023-04-03 06:51:26 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:26 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:26 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:26 --> URI Class Initialized
INFO - 2023-04-03 06:51:26 --> Router Class Initialized
INFO - 2023-04-03 06:51:26 --> Output Class Initialized
INFO - 2023-04-03 06:51:26 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:26 --> Input Class Initialized
INFO - 2023-04-03 06:51:26 --> Language Class Initialized
INFO - 2023-04-03 06:51:26 --> Loader Class Initialized
INFO - 2023-04-03 06:51:26 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:26 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:26 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:26 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:26 --> Total execution time: 0.0500
INFO - 2023-04-03 06:51:30 --> Config Class Initialized
INFO - 2023-04-03 06:51:30 --> Config Class Initialized
INFO - 2023-04-03 06:51:30 --> Hooks Class Initialized
INFO - 2023-04-03 06:51:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:30 --> Config Class Initialized
INFO - 2023-04-03 06:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:30 --> Hooks Class Initialized
INFO - 2023-04-03 06:51:30 --> URI Class Initialized
INFO - 2023-04-03 06:51:30 --> URI Class Initialized
DEBUG - 2023-04-03 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:30 --> Router Class Initialized
INFO - 2023-04-03 06:51:30 --> Router Class Initialized
INFO - 2023-04-03 06:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:30 --> Output Class Initialized
INFO - 2023-04-03 06:51:30 --> Output Class Initialized
INFO - 2023-04-03 06:51:30 --> URI Class Initialized
INFO - 2023-04-03 06:51:30 --> Security Class Initialized
INFO - 2023-04-03 06:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:30 --> Router Class Initialized
INFO - 2023-04-03 06:51:30 --> Input Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:30 --> Output Class Initialized
INFO - 2023-04-03 06:51:30 --> Input Class Initialized
INFO - 2023-04-03 06:51:30 --> Language Class Initialized
INFO - 2023-04-03 06:51:30 --> Security Class Initialized
INFO - 2023-04-03 06:51:30 --> Language Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:30 --> Loader Class Initialized
INFO - 2023-04-03 06:51:30 --> Input Class Initialized
INFO - 2023-04-03 06:51:30 --> Loader Class Initialized
INFO - 2023-04-03 06:51:30 --> Language Class Initialized
INFO - 2023-04-03 06:51:30 --> Controller Class Initialized
INFO - 2023-04-03 06:51:30 --> Controller Class Initialized
INFO - 2023-04-03 06:51:30 --> Loader Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:30 --> Controller Class Initialized
INFO - 2023-04-03 06:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:30 --> Database Driver Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:30 --> Model "Login_model" initialized
INFO - 2023-04-03 06:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:30 --> Total execution time: 0.0226
INFO - 2023-04-03 06:51:30 --> Config Class Initialized
INFO - 2023-04-03 06:51:30 --> Final output sent to browser
INFO - 2023-04-03 06:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:30 --> Total execution time: 0.0371
INFO - 2023-04-03 06:51:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Total execution time: 0.0268
DEBUG - 2023-04-03 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:30 --> URI Class Initialized
INFO - 2023-04-03 06:51:30 --> Router Class Initialized
INFO - 2023-04-03 06:51:30 --> Config Class Initialized
INFO - 2023-04-03 06:51:30 --> Config Class Initialized
INFO - 2023-04-03 06:51:30 --> Hooks Class Initialized
INFO - 2023-04-03 06:51:30 --> Output Class Initialized
INFO - 2023-04-03 06:51:30 --> Hooks Class Initialized
INFO - 2023-04-03 06:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:30 --> Utf8 Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:30 --> Input Class Initialized
INFO - 2023-04-03 06:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:30 --> URI Class Initialized
INFO - 2023-04-03 06:51:30 --> Language Class Initialized
INFO - 2023-04-03 06:51:30 --> URI Class Initialized
INFO - 2023-04-03 06:51:30 --> Router Class Initialized
INFO - 2023-04-03 06:51:30 --> Loader Class Initialized
INFO - 2023-04-03 06:51:30 --> Router Class Initialized
INFO - 2023-04-03 06:51:30 --> Output Class Initialized
INFO - 2023-04-03 06:51:30 --> Output Class Initialized
INFO - 2023-04-03 06:51:30 --> Controller Class Initialized
INFO - 2023-04-03 06:51:30 --> Security Class Initialized
INFO - 2023-04-03 06:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:30 --> Input Class Initialized
INFO - 2023-04-03 06:51:30 --> Input Class Initialized
INFO - 2023-04-03 06:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:30 --> Language Class Initialized
INFO - 2023-04-03 06:51:30 --> Language Class Initialized
INFO - 2023-04-03 06:51:30 --> Loader Class Initialized
INFO - 2023-04-03 06:51:30 --> Loader Class Initialized
INFO - 2023-04-03 06:51:30 --> Controller Class Initialized
INFO - 2023-04-03 06:51:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:30 --> Model "Login_model" initialized
INFO - 2023-04-03 06:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:30 --> Total execution time: 0.0623
INFO - 2023-04-03 06:51:30 --> Config Class Initialized
INFO - 2023-04-03 06:51:30 --> Final output sent to browser
INFO - 2023-04-03 06:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:31 --> Total execution time: 0.0732
DEBUG - 2023-04-03 06:51:31 --> Total execution time: 0.1069
INFO - 2023-04-03 06:51:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:51:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:31 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:31 --> Config Class Initialized
INFO - 2023-04-03 06:51:31 --> Hooks Class Initialized
INFO - 2023-04-03 06:51:31 --> URI Class Initialized
DEBUG - 2023-04-03 06:51:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:51:31 --> Router Class Initialized
INFO - 2023-04-03 06:51:31 --> Utf8 Class Initialized
INFO - 2023-04-03 06:51:31 --> Output Class Initialized
INFO - 2023-04-03 06:51:31 --> URI Class Initialized
INFO - 2023-04-03 06:51:31 --> Security Class Initialized
INFO - 2023-04-03 06:51:31 --> Router Class Initialized
DEBUG - 2023-04-03 06:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:31 --> Output Class Initialized
INFO - 2023-04-03 06:51:31 --> Security Class Initialized
DEBUG - 2023-04-03 06:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:51:31 --> Input Class Initialized
INFO - 2023-04-03 06:51:31 --> Language Class Initialized
INFO - 2023-04-03 06:51:31 --> Input Class Initialized
INFO - 2023-04-03 06:51:31 --> Loader Class Initialized
INFO - 2023-04-03 06:51:31 --> Language Class Initialized
INFO - 2023-04-03 06:51:31 --> Controller Class Initialized
INFO - 2023-04-03 06:51:31 --> Loader Class Initialized
DEBUG - 2023-04-03 06:51:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:31 --> Controller Class Initialized
DEBUG - 2023-04-03 06:51:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:51:31 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:31 --> Database Driver Class Initialized
INFO - 2023-04-03 06:51:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:51:31 --> Final output sent to browser
INFO - 2023-04-03 06:51:31 --> Final output sent to browser
DEBUG - 2023-04-03 06:51:31 --> Total execution time: 0.0968
DEBUG - 2023-04-03 06:51:31 --> Total execution time: 0.0517
INFO - 2023-04-03 06:52:30 --> Config Class Initialized
INFO - 2023-04-03 06:52:30 --> Config Class Initialized
INFO - 2023-04-03 06:52:30 --> Hooks Class Initialized
INFO - 2023-04-03 06:52:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:52:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:52:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:52:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:52:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:52:30 --> URI Class Initialized
INFO - 2023-04-03 06:52:30 --> URI Class Initialized
INFO - 2023-04-03 06:52:30 --> Router Class Initialized
INFO - 2023-04-03 06:52:30 --> Router Class Initialized
INFO - 2023-04-03 06:52:30 --> Output Class Initialized
INFO - 2023-04-03 06:52:30 --> Output Class Initialized
INFO - 2023-04-03 06:52:30 --> Security Class Initialized
INFO - 2023-04-03 06:52:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:52:30 --> Input Class Initialized
INFO - 2023-04-03 06:52:30 --> Input Class Initialized
INFO - 2023-04-03 06:52:30 --> Language Class Initialized
INFO - 2023-04-03 06:52:30 --> Language Class Initialized
INFO - 2023-04-03 06:52:30 --> Loader Class Initialized
INFO - 2023-04-03 06:52:30 --> Loader Class Initialized
INFO - 2023-04-03 06:52:30 --> Controller Class Initialized
INFO - 2023-04-03 06:52:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:52:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:52:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:52:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:52:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:52:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:52:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:52:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:52:30 --> Model "Login_model" initialized
INFO - 2023-04-03 06:52:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:52:30 --> Total execution time: 0.0995
INFO - 2023-04-03 06:52:30 --> Config Class Initialized
INFO - 2023-04-03 06:52:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:52:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:52:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:52:30 --> URI Class Initialized
INFO - 2023-04-03 06:52:30 --> Router Class Initialized
INFO - 2023-04-03 06:52:30 --> Output Class Initialized
INFO - 2023-04-03 06:52:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:52:30 --> Input Class Initialized
INFO - 2023-04-03 06:52:30 --> Language Class Initialized
INFO - 2023-04-03 06:52:30 --> Loader Class Initialized
INFO - 2023-04-03 06:52:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:52:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:52:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:52:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:52:31 --> Final output sent to browser
DEBUG - 2023-04-03 06:52:31 --> Total execution time: 0.0734
INFO - 2023-04-03 06:52:31 --> Final output sent to browser
DEBUG - 2023-04-03 06:52:31 --> Total execution time: 0.7588
INFO - 2023-04-03 06:52:31 --> Config Class Initialized
INFO - 2023-04-03 06:52:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:52:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:52:31 --> Utf8 Class Initialized
INFO - 2023-04-03 06:52:31 --> URI Class Initialized
INFO - 2023-04-03 06:52:31 --> Router Class Initialized
INFO - 2023-04-03 06:52:31 --> Output Class Initialized
INFO - 2023-04-03 06:52:31 --> Security Class Initialized
DEBUG - 2023-04-03 06:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:52:31 --> Input Class Initialized
INFO - 2023-04-03 06:52:31 --> Language Class Initialized
INFO - 2023-04-03 06:52:31 --> Loader Class Initialized
INFO - 2023-04-03 06:52:31 --> Controller Class Initialized
DEBUG - 2023-04-03 06:52:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:52:31 --> Database Driver Class Initialized
INFO - 2023-04-03 06:52:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:52:31 --> Database Driver Class Initialized
INFO - 2023-04-03 06:52:31 --> Model "Login_model" initialized
INFO - 2023-04-03 06:52:32 --> Final output sent to browser
DEBUG - 2023-04-03 06:52:32 --> Total execution time: 0.6816
INFO - 2023-04-03 06:53:30 --> Config Class Initialized
INFO - 2023-04-03 06:53:30 --> Config Class Initialized
INFO - 2023-04-03 06:53:30 --> Hooks Class Initialized
INFO - 2023-04-03 06:53:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:53:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:53:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:53:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:53:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:53:30 --> URI Class Initialized
INFO - 2023-04-03 06:53:30 --> URI Class Initialized
INFO - 2023-04-03 06:53:30 --> Router Class Initialized
INFO - 2023-04-03 06:53:30 --> Router Class Initialized
INFO - 2023-04-03 06:53:30 --> Output Class Initialized
INFO - 2023-04-03 06:53:30 --> Output Class Initialized
INFO - 2023-04-03 06:53:30 --> Security Class Initialized
INFO - 2023-04-03 06:53:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:53:30 --> Input Class Initialized
INFO - 2023-04-03 06:53:30 --> Input Class Initialized
INFO - 2023-04-03 06:53:30 --> Language Class Initialized
INFO - 2023-04-03 06:53:30 --> Language Class Initialized
INFO - 2023-04-03 06:53:30 --> Loader Class Initialized
INFO - 2023-04-03 06:53:30 --> Loader Class Initialized
INFO - 2023-04-03 06:53:30 --> Controller Class Initialized
INFO - 2023-04-03 06:53:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:53:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:53:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:53:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:53:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:53:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:53:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:53:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:53:30 --> Model "Login_model" initialized
INFO - 2023-04-03 06:53:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:53:30 --> Total execution time: 0.0459
INFO - 2023-04-03 06:53:30 --> Config Class Initialized
INFO - 2023-04-03 06:53:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:53:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:53:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:53:30 --> URI Class Initialized
INFO - 2023-04-03 06:53:30 --> Router Class Initialized
INFO - 2023-04-03 06:53:30 --> Output Class Initialized
INFO - 2023-04-03 06:53:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:53:30 --> Input Class Initialized
INFO - 2023-04-03 06:53:30 --> Language Class Initialized
INFO - 2023-04-03 06:53:30 --> Loader Class Initialized
INFO - 2023-04-03 06:53:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:53:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:53:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:53:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:53:31 --> Final output sent to browser
DEBUG - 2023-04-03 06:53:31 --> Total execution time: 0.1603
INFO - 2023-04-03 06:53:31 --> Final output sent to browser
DEBUG - 2023-04-03 06:53:31 --> Total execution time: 0.6734
INFO - 2023-04-03 06:53:31 --> Config Class Initialized
INFO - 2023-04-03 06:53:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:53:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:53:31 --> Utf8 Class Initialized
INFO - 2023-04-03 06:53:31 --> URI Class Initialized
INFO - 2023-04-03 06:53:31 --> Router Class Initialized
INFO - 2023-04-03 06:53:31 --> Output Class Initialized
INFO - 2023-04-03 06:53:31 --> Security Class Initialized
DEBUG - 2023-04-03 06:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:53:31 --> Input Class Initialized
INFO - 2023-04-03 06:53:31 --> Language Class Initialized
INFO - 2023-04-03 06:53:31 --> Loader Class Initialized
INFO - 2023-04-03 06:53:31 --> Controller Class Initialized
DEBUG - 2023-04-03 06:53:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:53:31 --> Database Driver Class Initialized
INFO - 2023-04-03 06:53:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:53:31 --> Database Driver Class Initialized
INFO - 2023-04-03 06:53:31 --> Model "Login_model" initialized
INFO - 2023-04-03 06:53:32 --> Final output sent to browser
DEBUG - 2023-04-03 06:53:32 --> Total execution time: 0.6069
INFO - 2023-04-03 06:54:30 --> Config Class Initialized
INFO - 2023-04-03 06:54:30 --> Config Class Initialized
INFO - 2023-04-03 06:54:30 --> Hooks Class Initialized
INFO - 2023-04-03 06:54:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:54:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 06:54:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:54:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:54:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:54:30 --> URI Class Initialized
INFO - 2023-04-03 06:54:30 --> URI Class Initialized
INFO - 2023-04-03 06:54:30 --> Router Class Initialized
INFO - 2023-04-03 06:54:30 --> Router Class Initialized
INFO - 2023-04-03 06:54:30 --> Output Class Initialized
INFO - 2023-04-03 06:54:30 --> Output Class Initialized
INFO - 2023-04-03 06:54:30 --> Security Class Initialized
INFO - 2023-04-03 06:54:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 06:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:54:30 --> Input Class Initialized
INFO - 2023-04-03 06:54:30 --> Input Class Initialized
INFO - 2023-04-03 06:54:30 --> Language Class Initialized
INFO - 2023-04-03 06:54:30 --> Language Class Initialized
INFO - 2023-04-03 06:54:30 --> Loader Class Initialized
INFO - 2023-04-03 06:54:30 --> Loader Class Initialized
INFO - 2023-04-03 06:54:30 --> Controller Class Initialized
INFO - 2023-04-03 06:54:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:54:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:54:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:54:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:54:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:54:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:54:30 --> Model "Login_model" initialized
INFO - 2023-04-03 06:54:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:54:30 --> Total execution time: 0.0382
INFO - 2023-04-03 06:54:30 --> Config Class Initialized
INFO - 2023-04-03 06:54:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:54:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:54:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:54:30 --> URI Class Initialized
INFO - 2023-04-03 06:54:30 --> Router Class Initialized
INFO - 2023-04-03 06:54:30 --> Output Class Initialized
INFO - 2023-04-03 06:54:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:54:30 --> Input Class Initialized
INFO - 2023-04-03 06:54:30 --> Language Class Initialized
INFO - 2023-04-03 06:54:30 --> Loader Class Initialized
INFO - 2023-04-03 06:54:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:54:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:54:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:54:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:54:31 --> Final output sent to browser
DEBUG - 2023-04-03 06:54:31 --> Total execution time: 0.0876
INFO - 2023-04-03 06:54:31 --> Final output sent to browser
DEBUG - 2023-04-03 06:54:31 --> Total execution time: 0.6534
INFO - 2023-04-03 06:54:31 --> Config Class Initialized
INFO - 2023-04-03 06:54:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:54:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:54:31 --> Utf8 Class Initialized
INFO - 2023-04-03 06:54:31 --> URI Class Initialized
INFO - 2023-04-03 06:54:31 --> Router Class Initialized
INFO - 2023-04-03 06:54:31 --> Output Class Initialized
INFO - 2023-04-03 06:54:31 --> Security Class Initialized
DEBUG - 2023-04-03 06:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:54:31 --> Input Class Initialized
INFO - 2023-04-03 06:54:31 --> Language Class Initialized
INFO - 2023-04-03 06:54:31 --> Loader Class Initialized
INFO - 2023-04-03 06:54:31 --> Controller Class Initialized
DEBUG - 2023-04-03 06:54:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:54:31 --> Database Driver Class Initialized
INFO - 2023-04-03 06:54:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:54:31 --> Database Driver Class Initialized
INFO - 2023-04-03 06:54:31 --> Model "Login_model" initialized
INFO - 2023-04-03 06:54:32 --> Final output sent to browser
DEBUG - 2023-04-03 06:54:32 --> Total execution time: 0.5949
INFO - 2023-04-03 06:55:35 --> Config Class Initialized
INFO - 2023-04-03 06:55:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:55:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:55:35 --> Utf8 Class Initialized
INFO - 2023-04-03 06:55:35 --> URI Class Initialized
INFO - 2023-04-03 06:55:35 --> Router Class Initialized
INFO - 2023-04-03 06:55:35 --> Output Class Initialized
INFO - 2023-04-03 06:55:35 --> Security Class Initialized
DEBUG - 2023-04-03 06:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:55:35 --> Input Class Initialized
INFO - 2023-04-03 06:55:35 --> Language Class Initialized
INFO - 2023-04-03 06:55:35 --> Loader Class Initialized
INFO - 2023-04-03 06:55:35 --> Controller Class Initialized
DEBUG - 2023-04-03 06:55:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:55:35 --> Database Driver Class Initialized
INFO - 2023-04-03 06:55:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:55:35 --> Final output sent to browser
DEBUG - 2023-04-03 06:55:35 --> Total execution time: 0.0377
INFO - 2023-04-03 06:55:35 --> Config Class Initialized
INFO - 2023-04-03 06:55:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:55:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:55:35 --> Utf8 Class Initialized
INFO - 2023-04-03 06:55:35 --> URI Class Initialized
INFO - 2023-04-03 06:55:35 --> Router Class Initialized
INFO - 2023-04-03 06:55:35 --> Output Class Initialized
INFO - 2023-04-03 06:55:35 --> Security Class Initialized
DEBUG - 2023-04-03 06:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:55:35 --> Input Class Initialized
INFO - 2023-04-03 06:55:35 --> Language Class Initialized
INFO - 2023-04-03 06:55:35 --> Loader Class Initialized
INFO - 2023-04-03 06:55:35 --> Controller Class Initialized
DEBUG - 2023-04-03 06:55:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:55:35 --> Database Driver Class Initialized
INFO - 2023-04-03 06:55:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:55:35 --> Final output sent to browser
DEBUG - 2023-04-03 06:55:35 --> Total execution time: 0.0924
INFO - 2023-04-03 06:55:35 --> Config Class Initialized
INFO - 2023-04-03 06:55:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:55:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:55:35 --> Utf8 Class Initialized
INFO - 2023-04-03 06:55:35 --> URI Class Initialized
INFO - 2023-04-03 06:55:35 --> Router Class Initialized
INFO - 2023-04-03 06:55:35 --> Output Class Initialized
INFO - 2023-04-03 06:55:35 --> Security Class Initialized
DEBUG - 2023-04-03 06:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:55:35 --> Input Class Initialized
INFO - 2023-04-03 06:55:35 --> Language Class Initialized
INFO - 2023-04-03 06:55:35 --> Loader Class Initialized
INFO - 2023-04-03 06:55:35 --> Controller Class Initialized
DEBUG - 2023-04-03 06:55:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:55:35 --> Database Driver Class Initialized
INFO - 2023-04-03 06:55:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:55:35 --> Database Driver Class Initialized
INFO - 2023-04-03 06:55:35 --> Model "Login_model" initialized
INFO - 2023-04-03 06:55:36 --> Final output sent to browser
DEBUG - 2023-04-03 06:55:36 --> Total execution time: 0.6822
INFO - 2023-04-03 06:55:36 --> Config Class Initialized
INFO - 2023-04-03 06:55:36 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:55:36 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:55:36 --> Utf8 Class Initialized
INFO - 2023-04-03 06:55:36 --> URI Class Initialized
INFO - 2023-04-03 06:55:36 --> Router Class Initialized
INFO - 2023-04-03 06:55:36 --> Output Class Initialized
INFO - 2023-04-03 06:55:36 --> Security Class Initialized
DEBUG - 2023-04-03 06:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:55:36 --> Input Class Initialized
INFO - 2023-04-03 06:55:36 --> Language Class Initialized
INFO - 2023-04-03 06:55:36 --> Loader Class Initialized
INFO - 2023-04-03 06:55:36 --> Controller Class Initialized
DEBUG - 2023-04-03 06:55:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:55:36 --> Database Driver Class Initialized
INFO - 2023-04-03 06:55:36 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:55:36 --> Database Driver Class Initialized
INFO - 2023-04-03 06:55:36 --> Model "Login_model" initialized
INFO - 2023-04-03 06:55:37 --> Final output sent to browser
DEBUG - 2023-04-03 06:55:37 --> Total execution time: 0.6610
INFO - 2023-04-03 06:56:30 --> Config Class Initialized
INFO - 2023-04-03 06:56:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:56:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:56:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:56:30 --> URI Class Initialized
INFO - 2023-04-03 06:56:30 --> Router Class Initialized
INFO - 2023-04-03 06:56:30 --> Output Class Initialized
INFO - 2023-04-03 06:56:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:56:30 --> Input Class Initialized
INFO - 2023-04-03 06:56:30 --> Language Class Initialized
INFO - 2023-04-03 06:56:30 --> Loader Class Initialized
INFO - 2023-04-03 06:56:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:56:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:56:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:56:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:56:30 --> Final output sent to browser
DEBUG - 2023-04-03 06:56:30 --> Total execution time: 0.1268
INFO - 2023-04-03 06:56:30 --> Config Class Initialized
INFO - 2023-04-03 06:56:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:56:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:56:30 --> Utf8 Class Initialized
INFO - 2023-04-03 06:56:30 --> URI Class Initialized
INFO - 2023-04-03 06:56:30 --> Router Class Initialized
INFO - 2023-04-03 06:56:30 --> Output Class Initialized
INFO - 2023-04-03 06:56:30 --> Security Class Initialized
DEBUG - 2023-04-03 06:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:56:30 --> Input Class Initialized
INFO - 2023-04-03 06:56:30 --> Language Class Initialized
INFO - 2023-04-03 06:56:30 --> Loader Class Initialized
INFO - 2023-04-03 06:56:30 --> Controller Class Initialized
DEBUG - 2023-04-03 06:56:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:56:30 --> Database Driver Class Initialized
INFO - 2023-04-03 06:56:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:56:31 --> Final output sent to browser
DEBUG - 2023-04-03 06:56:31 --> Total execution time: 0.1253
INFO - 2023-04-03 06:56:32 --> Config Class Initialized
INFO - 2023-04-03 06:56:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:56:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:56:32 --> Utf8 Class Initialized
INFO - 2023-04-03 06:56:32 --> URI Class Initialized
INFO - 2023-04-03 06:56:32 --> Router Class Initialized
INFO - 2023-04-03 06:56:32 --> Output Class Initialized
INFO - 2023-04-03 06:56:32 --> Security Class Initialized
DEBUG - 2023-04-03 06:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:56:32 --> Input Class Initialized
INFO - 2023-04-03 06:56:32 --> Language Class Initialized
INFO - 2023-04-03 06:56:32 --> Loader Class Initialized
INFO - 2023-04-03 06:56:32 --> Controller Class Initialized
DEBUG - 2023-04-03 06:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:56:32 --> Database Driver Class Initialized
INFO - 2023-04-03 06:56:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:56:32 --> Database Driver Class Initialized
INFO - 2023-04-03 06:56:32 --> Model "Login_model" initialized
INFO - 2023-04-03 06:56:32 --> Final output sent to browser
DEBUG - 2023-04-03 06:56:32 --> Total execution time: 0.8393
INFO - 2023-04-03 06:56:32 --> Config Class Initialized
INFO - 2023-04-03 06:56:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:56:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:56:32 --> Utf8 Class Initialized
INFO - 2023-04-03 06:56:32 --> URI Class Initialized
INFO - 2023-04-03 06:56:32 --> Router Class Initialized
INFO - 2023-04-03 06:56:32 --> Output Class Initialized
INFO - 2023-04-03 06:56:32 --> Security Class Initialized
DEBUG - 2023-04-03 06:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:56:32 --> Input Class Initialized
INFO - 2023-04-03 06:56:32 --> Language Class Initialized
INFO - 2023-04-03 06:56:32 --> Loader Class Initialized
INFO - 2023-04-03 06:56:32 --> Controller Class Initialized
DEBUG - 2023-04-03 06:56:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:56:32 --> Database Driver Class Initialized
INFO - 2023-04-03 06:56:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:56:33 --> Database Driver Class Initialized
INFO - 2023-04-03 06:56:33 --> Model "Login_model" initialized
INFO - 2023-04-03 06:56:33 --> Final output sent to browser
DEBUG - 2023-04-03 06:56:33 --> Total execution time: 0.5965
INFO - 2023-04-03 06:58:03 --> Config Class Initialized
INFO - 2023-04-03 06:58:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:58:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:58:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:58:03 --> URI Class Initialized
INFO - 2023-04-03 06:58:03 --> Router Class Initialized
INFO - 2023-04-03 06:58:03 --> Output Class Initialized
INFO - 2023-04-03 06:58:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:58:03 --> Input Class Initialized
INFO - 2023-04-03 06:58:03 --> Language Class Initialized
INFO - 2023-04-03 06:58:03 --> Loader Class Initialized
INFO - 2023-04-03 06:58:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:58:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:58:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:58:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:58:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:58:03 --> Total execution time: 0.1551
INFO - 2023-04-03 06:58:03 --> Config Class Initialized
INFO - 2023-04-03 06:58:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:58:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:58:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:58:04 --> URI Class Initialized
INFO - 2023-04-03 06:58:04 --> Router Class Initialized
INFO - 2023-04-03 06:58:04 --> Output Class Initialized
INFO - 2023-04-03 06:58:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:58:04 --> Input Class Initialized
INFO - 2023-04-03 06:58:04 --> Language Class Initialized
INFO - 2023-04-03 06:58:04 --> Loader Class Initialized
INFO - 2023-04-03 06:58:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:58:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:58:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:58:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:58:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:58:04 --> Total execution time: 0.0752
INFO - 2023-04-03 06:59:03 --> Config Class Initialized
INFO - 2023-04-03 06:59:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:59:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:59:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:59:03 --> URI Class Initialized
INFO - 2023-04-03 06:59:03 --> Config Class Initialized
INFO - 2023-04-03 06:59:03 --> Router Class Initialized
INFO - 2023-04-03 06:59:03 --> Hooks Class Initialized
INFO - 2023-04-03 06:59:03 --> Output Class Initialized
DEBUG - 2023-04-03 06:59:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:59:03 --> Security Class Initialized
INFO - 2023-04-03 06:59:03 --> Utf8 Class Initialized
DEBUG - 2023-04-03 06:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:59:03 --> Input Class Initialized
INFO - 2023-04-03 06:59:03 --> URI Class Initialized
INFO - 2023-04-03 06:59:03 --> Language Class Initialized
INFO - 2023-04-03 06:59:03 --> Router Class Initialized
INFO - 2023-04-03 06:59:03 --> Loader Class Initialized
INFO - 2023-04-03 06:59:03 --> Output Class Initialized
INFO - 2023-04-03 06:59:03 --> Controller Class Initialized
INFO - 2023-04-03 06:59:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:59:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 06:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:59:03 --> Input Class Initialized
INFO - 2023-04-03 06:59:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:59:03 --> Language Class Initialized
INFO - 2023-04-03 06:59:03 --> Loader Class Initialized
INFO - 2023-04-03 06:59:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:59:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:59:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:59:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:59:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:59:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:59:03 --> Model "Login_model" initialized
INFO - 2023-04-03 06:59:03 --> Final output sent to browser
DEBUG - 2023-04-03 06:59:03 --> Total execution time: 0.0771
INFO - 2023-04-03 06:59:03 --> Config Class Initialized
INFO - 2023-04-03 06:59:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:59:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:59:03 --> Utf8 Class Initialized
INFO - 2023-04-03 06:59:03 --> URI Class Initialized
INFO - 2023-04-03 06:59:03 --> Router Class Initialized
INFO - 2023-04-03 06:59:03 --> Output Class Initialized
INFO - 2023-04-03 06:59:03 --> Security Class Initialized
DEBUG - 2023-04-03 06:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:59:03 --> Input Class Initialized
INFO - 2023-04-03 06:59:03 --> Language Class Initialized
INFO - 2023-04-03 06:59:03 --> Loader Class Initialized
INFO - 2023-04-03 06:59:03 --> Controller Class Initialized
DEBUG - 2023-04-03 06:59:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:59:03 --> Database Driver Class Initialized
INFO - 2023-04-03 06:59:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:59:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:59:04 --> Total execution time: 0.0929
INFO - 2023-04-03 06:59:04 --> Final output sent to browser
DEBUG - 2023-04-03 06:59:04 --> Total execution time: 0.7376
INFO - 2023-04-03 06:59:04 --> Config Class Initialized
INFO - 2023-04-03 06:59:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 06:59:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 06:59:04 --> Utf8 Class Initialized
INFO - 2023-04-03 06:59:04 --> URI Class Initialized
INFO - 2023-04-03 06:59:04 --> Router Class Initialized
INFO - 2023-04-03 06:59:04 --> Output Class Initialized
INFO - 2023-04-03 06:59:04 --> Security Class Initialized
DEBUG - 2023-04-03 06:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 06:59:04 --> Input Class Initialized
INFO - 2023-04-03 06:59:04 --> Language Class Initialized
INFO - 2023-04-03 06:59:04 --> Loader Class Initialized
INFO - 2023-04-03 06:59:04 --> Controller Class Initialized
DEBUG - 2023-04-03 06:59:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 06:59:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:59:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 06:59:04 --> Database Driver Class Initialized
INFO - 2023-04-03 06:59:04 --> Model "Login_model" initialized
INFO - 2023-04-03 06:59:05 --> Final output sent to browser
DEBUG - 2023-04-03 06:59:05 --> Total execution time: 0.6243
INFO - 2023-04-03 07:00:03 --> Config Class Initialized
INFO - 2023-04-03 07:00:03 --> Config Class Initialized
INFO - 2023-04-03 07:00:03 --> Hooks Class Initialized
INFO - 2023-04-03 07:00:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:00:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:00:04 --> Utf8 Class Initialized
INFO - 2023-04-03 07:00:04 --> Utf8 Class Initialized
INFO - 2023-04-03 07:00:04 --> URI Class Initialized
INFO - 2023-04-03 07:00:04 --> URI Class Initialized
INFO - 2023-04-03 07:00:04 --> Router Class Initialized
INFO - 2023-04-03 07:00:04 --> Router Class Initialized
INFO - 2023-04-03 07:00:04 --> Output Class Initialized
INFO - 2023-04-03 07:00:04 --> Output Class Initialized
INFO - 2023-04-03 07:00:04 --> Security Class Initialized
INFO - 2023-04-03 07:00:04 --> Security Class Initialized
DEBUG - 2023-04-03 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:00:04 --> Input Class Initialized
INFO - 2023-04-03 07:00:04 --> Input Class Initialized
INFO - 2023-04-03 07:00:04 --> Language Class Initialized
INFO - 2023-04-03 07:00:05 --> Language Class Initialized
INFO - 2023-04-03 07:00:05 --> Loader Class Initialized
INFO - 2023-04-03 07:00:05 --> Loader Class Initialized
INFO - 2023-04-03 07:00:05 --> Controller Class Initialized
INFO - 2023-04-03 07:00:05 --> Controller Class Initialized
DEBUG - 2023-04-03 07:00:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:00:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:00:05 --> Database Driver Class Initialized
INFO - 2023-04-03 07:00:05 --> Database Driver Class Initialized
INFO - 2023-04-03 07:00:05 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:00:05 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:00:05 --> Database Driver Class Initialized
INFO - 2023-04-03 07:00:05 --> Final output sent to browser
INFO - 2023-04-03 07:00:05 --> Config Class Initialized
INFO - 2023-04-03 07:00:05 --> Model "Login_model" initialized
DEBUG - 2023-04-03 07:00:05 --> Total execution time: 1.9489
INFO - 2023-04-03 07:00:05 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:00:06 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:00:06 --> Utf8 Class Initialized
INFO - 2023-04-03 07:00:06 --> URI Class Initialized
INFO - 2023-04-03 07:00:06 --> Router Class Initialized
INFO - 2023-04-03 07:00:06 --> Output Class Initialized
INFO - 2023-04-03 07:00:06 --> Security Class Initialized
DEBUG - 2023-04-03 07:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:00:06 --> Input Class Initialized
INFO - 2023-04-03 07:00:06 --> Language Class Initialized
INFO - 2023-04-03 07:00:06 --> Loader Class Initialized
INFO - 2023-04-03 07:00:06 --> Controller Class Initialized
DEBUG - 2023-04-03 07:00:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:00:06 --> Database Driver Class Initialized
INFO - 2023-04-03 07:00:06 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:00:06 --> Final output sent to browser
DEBUG - 2023-04-03 07:00:06 --> Total execution time: 0.6706
INFO - 2023-04-03 07:00:06 --> Final output sent to browser
DEBUG - 2023-04-03 07:00:06 --> Total execution time: 3.1020
INFO - 2023-04-03 07:00:07 --> Config Class Initialized
INFO - 2023-04-03 07:00:07 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:00:07 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:00:07 --> Utf8 Class Initialized
INFO - 2023-04-03 07:00:07 --> URI Class Initialized
INFO - 2023-04-03 07:00:07 --> Router Class Initialized
INFO - 2023-04-03 07:00:07 --> Output Class Initialized
INFO - 2023-04-03 07:00:07 --> Security Class Initialized
DEBUG - 2023-04-03 07:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:00:07 --> Input Class Initialized
INFO - 2023-04-03 07:00:07 --> Language Class Initialized
INFO - 2023-04-03 07:00:07 --> Loader Class Initialized
INFO - 2023-04-03 07:00:07 --> Controller Class Initialized
DEBUG - 2023-04-03 07:00:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:00:08 --> Database Driver Class Initialized
INFO - 2023-04-03 07:00:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:00:08 --> Database Driver Class Initialized
INFO - 2023-04-03 07:00:08 --> Model "Login_model" initialized
INFO - 2023-04-03 07:00:08 --> Final output sent to browser
DEBUG - 2023-04-03 07:00:08 --> Total execution time: 1.8859
INFO - 2023-04-03 07:01:27 --> Config Class Initialized
INFO - 2023-04-03 07:01:27 --> Config Class Initialized
INFO - 2023-04-03 07:01:27 --> Hooks Class Initialized
INFO - 2023-04-03 07:01:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:01:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:01:27 --> Utf8 Class Initialized
INFO - 2023-04-03 07:01:27 --> Utf8 Class Initialized
INFO - 2023-04-03 07:01:27 --> URI Class Initialized
INFO - 2023-04-03 07:01:27 --> URI Class Initialized
INFO - 2023-04-03 07:01:27 --> Router Class Initialized
INFO - 2023-04-03 07:01:27 --> Router Class Initialized
INFO - 2023-04-03 07:01:27 --> Output Class Initialized
INFO - 2023-04-03 07:01:27 --> Output Class Initialized
INFO - 2023-04-03 07:01:27 --> Security Class Initialized
INFO - 2023-04-03 07:01:27 --> Security Class Initialized
DEBUG - 2023-04-03 07:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:01:27 --> Input Class Initialized
INFO - 2023-04-03 07:01:27 --> Input Class Initialized
INFO - 2023-04-03 07:01:27 --> Language Class Initialized
INFO - 2023-04-03 07:01:27 --> Language Class Initialized
INFO - 2023-04-03 07:01:27 --> Loader Class Initialized
INFO - 2023-04-03 07:01:27 --> Loader Class Initialized
INFO - 2023-04-03 07:01:27 --> Controller Class Initialized
INFO - 2023-04-03 07:01:27 --> Controller Class Initialized
DEBUG - 2023-04-03 07:01:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:01:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:01:27 --> Database Driver Class Initialized
INFO - 2023-04-03 07:01:27 --> Database Driver Class Initialized
INFO - 2023-04-03 07:01:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:01:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:01:27 --> Database Driver Class Initialized
INFO - 2023-04-03 07:01:27 --> Model "Login_model" initialized
INFO - 2023-04-03 07:01:27 --> Final output sent to browser
DEBUG - 2023-04-03 07:01:27 --> Total execution time: 0.1275
INFO - 2023-04-03 07:01:27 --> Config Class Initialized
INFO - 2023-04-03 07:01:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:01:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:01:27 --> Utf8 Class Initialized
INFO - 2023-04-03 07:01:27 --> URI Class Initialized
INFO - 2023-04-03 07:01:27 --> Router Class Initialized
INFO - 2023-04-03 07:01:27 --> Output Class Initialized
INFO - 2023-04-03 07:01:27 --> Security Class Initialized
DEBUG - 2023-04-03 07:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:01:27 --> Input Class Initialized
INFO - 2023-04-03 07:01:27 --> Language Class Initialized
INFO - 2023-04-03 07:01:27 --> Loader Class Initialized
INFO - 2023-04-03 07:01:27 --> Controller Class Initialized
DEBUG - 2023-04-03 07:01:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:01:27 --> Database Driver Class Initialized
INFO - 2023-04-03 07:01:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:01:27 --> Final output sent to browser
DEBUG - 2023-04-03 07:01:27 --> Total execution time: 0.1115
INFO - 2023-04-03 07:01:28 --> Final output sent to browser
DEBUG - 2023-04-03 07:01:28 --> Total execution time: 0.8560
INFO - 2023-04-03 07:01:28 --> Config Class Initialized
INFO - 2023-04-03 07:01:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:01:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:01:28 --> Utf8 Class Initialized
INFO - 2023-04-03 07:01:28 --> URI Class Initialized
INFO - 2023-04-03 07:01:28 --> Router Class Initialized
INFO - 2023-04-03 07:01:28 --> Output Class Initialized
INFO - 2023-04-03 07:01:28 --> Security Class Initialized
DEBUG - 2023-04-03 07:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:01:28 --> Input Class Initialized
INFO - 2023-04-03 07:01:28 --> Language Class Initialized
INFO - 2023-04-03 07:01:28 --> Loader Class Initialized
INFO - 2023-04-03 07:01:28 --> Controller Class Initialized
DEBUG - 2023-04-03 07:01:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:01:28 --> Database Driver Class Initialized
INFO - 2023-04-03 07:01:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:01:28 --> Database Driver Class Initialized
INFO - 2023-04-03 07:01:28 --> Model "Login_model" initialized
INFO - 2023-04-03 07:01:28 --> Final output sent to browser
DEBUG - 2023-04-03 07:01:28 --> Total execution time: 0.6753
INFO - 2023-04-03 07:02:03 --> Config Class Initialized
INFO - 2023-04-03 07:02:03 --> Config Class Initialized
INFO - 2023-04-03 07:02:03 --> Hooks Class Initialized
INFO - 2023-04-03 07:02:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:02:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:02:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:03 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:03 --> URI Class Initialized
INFO - 2023-04-03 07:02:03 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:03 --> Router Class Initialized
INFO - 2023-04-03 07:02:03 --> URI Class Initialized
INFO - 2023-04-03 07:02:03 --> Output Class Initialized
INFO - 2023-04-03 07:02:03 --> Router Class Initialized
INFO - 2023-04-03 07:02:03 --> Output Class Initialized
INFO - 2023-04-03 07:02:03 --> Security Class Initialized
INFO - 2023-04-03 07:02:03 --> Security Class Initialized
DEBUG - 2023-04-03 07:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:03 --> Input Class Initialized
INFO - 2023-04-03 07:02:03 --> Input Class Initialized
INFO - 2023-04-03 07:02:03 --> Language Class Initialized
INFO - 2023-04-03 07:02:03 --> Language Class Initialized
INFO - 2023-04-03 07:02:03 --> Loader Class Initialized
INFO - 2023-04-03 07:02:03 --> Loader Class Initialized
INFO - 2023-04-03 07:02:03 --> Controller Class Initialized
DEBUG - 2023-04-03 07:02:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:03 --> Controller Class Initialized
DEBUG - 2023-04-03 07:02:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:03 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:03 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:03 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:03 --> Model "Login_model" initialized
INFO - 2023-04-03 07:02:04 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:04 --> Total execution time: 0.2061
INFO - 2023-04-03 07:02:04 --> Config Class Initialized
INFO - 2023-04-03 07:02:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:02:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:04 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:04 --> URI Class Initialized
INFO - 2023-04-03 07:02:04 --> Router Class Initialized
INFO - 2023-04-03 07:02:04 --> Output Class Initialized
INFO - 2023-04-03 07:02:04 --> Security Class Initialized
DEBUG - 2023-04-03 07:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:04 --> Input Class Initialized
INFO - 2023-04-03 07:02:04 --> Language Class Initialized
INFO - 2023-04-03 07:02:04 --> Loader Class Initialized
INFO - 2023-04-03 07:02:04 --> Controller Class Initialized
DEBUG - 2023-04-03 07:02:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:04 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:04 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:04 --> Total execution time: 0.1035
INFO - 2023-04-03 07:02:05 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:05 --> Total execution time: 1.1904
INFO - 2023-04-03 07:02:05 --> Config Class Initialized
INFO - 2023-04-03 07:02:05 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:02:05 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:05 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:05 --> URI Class Initialized
INFO - 2023-04-03 07:02:05 --> Router Class Initialized
INFO - 2023-04-03 07:02:05 --> Output Class Initialized
INFO - 2023-04-03 07:02:05 --> Security Class Initialized
DEBUG - 2023-04-03 07:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:05 --> Input Class Initialized
INFO - 2023-04-03 07:02:05 --> Language Class Initialized
INFO - 2023-04-03 07:02:05 --> Loader Class Initialized
INFO - 2023-04-03 07:02:05 --> Controller Class Initialized
DEBUG - 2023-04-03 07:02:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:05 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:05 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:05 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:05 --> Model "Login_model" initialized
INFO - 2023-04-03 07:02:06 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:06 --> Total execution time: 1.2636
INFO - 2023-04-03 07:02:33 --> Config Class Initialized
INFO - 2023-04-03 07:02:33 --> Config Class Initialized
INFO - 2023-04-03 07:02:33 --> Hooks Class Initialized
INFO - 2023-04-03 07:02:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:02:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:33 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:02:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:33 --> Config Class Initialized
INFO - 2023-04-03 07:02:33 --> URI Class Initialized
INFO - 2023-04-03 07:02:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:33 --> Hooks Class Initialized
INFO - 2023-04-03 07:02:33 --> URI Class Initialized
DEBUG - 2023-04-03 07:02:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:33 --> Router Class Initialized
INFO - 2023-04-03 07:02:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:33 --> Router Class Initialized
INFO - 2023-04-03 07:02:33 --> Output Class Initialized
INFO - 2023-04-03 07:02:33 --> URI Class Initialized
INFO - 2023-04-03 07:02:33 --> Output Class Initialized
INFO - 2023-04-03 07:02:33 --> Security Class Initialized
INFO - 2023-04-03 07:02:33 --> Router Class Initialized
INFO - 2023-04-03 07:02:33 --> Output Class Initialized
DEBUG - 2023-04-03 07:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:33 --> Security Class Initialized
INFO - 2023-04-03 07:02:33 --> Security Class Initialized
DEBUG - 2023-04-03 07:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:33 --> Input Class Initialized
DEBUG - 2023-04-03 07:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:33 --> Input Class Initialized
INFO - 2023-04-03 07:02:33 --> Input Class Initialized
INFO - 2023-04-03 07:02:33 --> Language Class Initialized
INFO - 2023-04-03 07:02:33 --> Language Class Initialized
INFO - 2023-04-03 07:02:33 --> Language Class Initialized
INFO - 2023-04-03 07:02:33 --> Loader Class Initialized
INFO - 2023-04-03 07:02:33 --> Loader Class Initialized
INFO - 2023-04-03 07:02:33 --> Controller Class Initialized
INFO - 2023-04-03 07:02:33 --> Controller Class Initialized
DEBUG - 2023-04-03 07:02:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:33 --> Loader Class Initialized
INFO - 2023-04-03 07:02:33 --> Controller Class Initialized
INFO - 2023-04-03 07:02:33 --> Database Driver Class Initialized
DEBUG - 2023-04-03 07:02:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:02:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:33 --> Model "Login_model" initialized
INFO - 2023-04-03 07:02:33 --> Model "Login_model" initialized
INFO - 2023-04-03 07:02:33 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:33 --> Total execution time: 0.4471
INFO - 2023-04-03 07:02:33 --> Config Class Initialized
INFO - 2023-04-03 07:02:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:02:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:33 --> URI Class Initialized
INFO - 2023-04-03 07:02:33 --> Router Class Initialized
INFO - 2023-04-03 07:02:33 --> Output Class Initialized
INFO - 2023-04-03 07:02:33 --> Security Class Initialized
DEBUG - 2023-04-03 07:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:33 --> Input Class Initialized
INFO - 2023-04-03 07:02:33 --> Language Class Initialized
INFO - 2023-04-03 07:02:33 --> Loader Class Initialized
INFO - 2023-04-03 07:02:33 --> Controller Class Initialized
DEBUG - 2023-04-03 07:02:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:34 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:34 --> Total execution time: 0.2022
INFO - 2023-04-03 07:02:35 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:35 --> Total execution time: 1.6516
INFO - 2023-04-03 07:02:35 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:35 --> Total execution time: 1.6544
INFO - 2023-04-03 07:02:35 --> Config Class Initialized
INFO - 2023-04-03 07:02:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:02:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:35 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:35 --> URI Class Initialized
INFO - 2023-04-03 07:02:35 --> Router Class Initialized
INFO - 2023-04-03 07:02:35 --> Output Class Initialized
INFO - 2023-04-03 07:02:35 --> Security Class Initialized
DEBUG - 2023-04-03 07:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:35 --> Input Class Initialized
INFO - 2023-04-03 07:02:35 --> Language Class Initialized
INFO - 2023-04-03 07:02:35 --> Loader Class Initialized
INFO - 2023-04-03 07:02:35 --> Controller Class Initialized
DEBUG - 2023-04-03 07:02:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:35 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:35 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:35 --> Model "Login_model" initialized
INFO - 2023-04-03 07:02:36 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:36 --> Total execution time: 1.2401
INFO - 2023-04-03 07:02:36 --> Config Class Initialized
INFO - 2023-04-03 07:02:36 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:02:36 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:02:36 --> Utf8 Class Initialized
INFO - 2023-04-03 07:02:36 --> URI Class Initialized
INFO - 2023-04-03 07:02:36 --> Router Class Initialized
INFO - 2023-04-03 07:02:36 --> Output Class Initialized
INFO - 2023-04-03 07:02:36 --> Security Class Initialized
DEBUG - 2023-04-03 07:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:02:36 --> Input Class Initialized
INFO - 2023-04-03 07:02:36 --> Language Class Initialized
INFO - 2023-04-03 07:02:36 --> Loader Class Initialized
INFO - 2023-04-03 07:02:36 --> Controller Class Initialized
DEBUG - 2023-04-03 07:02:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:02:36 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:36 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:02:36 --> Database Driver Class Initialized
INFO - 2023-04-03 07:02:36 --> Model "Login_model" initialized
INFO - 2023-04-03 07:02:37 --> Final output sent to browser
DEBUG - 2023-04-03 07:02:37 --> Total execution time: 0.9703
INFO - 2023-04-03 07:03:30 --> Config Class Initialized
INFO - 2023-04-03 07:03:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:03:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:03:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:03:30 --> URI Class Initialized
INFO - 2023-04-03 07:03:30 --> Router Class Initialized
INFO - 2023-04-03 07:03:30 --> Output Class Initialized
INFO - 2023-04-03 07:03:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:03:30 --> Input Class Initialized
INFO - 2023-04-03 07:03:30 --> Language Class Initialized
INFO - 2023-04-03 07:03:30 --> Loader Class Initialized
INFO - 2023-04-03 07:03:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:03:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:03:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:03:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:03:30 --> Total execution time: 0.0358
INFO - 2023-04-03 07:03:30 --> Config Class Initialized
INFO - 2023-04-03 07:03:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:03:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:03:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:03:30 --> URI Class Initialized
INFO - 2023-04-03 07:03:30 --> Router Class Initialized
INFO - 2023-04-03 07:03:30 --> Output Class Initialized
INFO - 2023-04-03 07:03:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:03:30 --> Input Class Initialized
INFO - 2023-04-03 07:03:30 --> Language Class Initialized
INFO - 2023-04-03 07:03:30 --> Loader Class Initialized
INFO - 2023-04-03 07:03:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:03:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:03:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:03:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:03:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:03:30 --> Total execution time: 0.0758
INFO - 2023-04-03 07:03:32 --> Config Class Initialized
INFO - 2023-04-03 07:03:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:03:32 --> Utf8 Class Initialized
INFO - 2023-04-03 07:03:32 --> URI Class Initialized
INFO - 2023-04-03 07:03:32 --> Router Class Initialized
INFO - 2023-04-03 07:03:32 --> Output Class Initialized
INFO - 2023-04-03 07:03:32 --> Security Class Initialized
DEBUG - 2023-04-03 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:03:32 --> Input Class Initialized
INFO - 2023-04-03 07:03:32 --> Language Class Initialized
INFO - 2023-04-03 07:03:32 --> Loader Class Initialized
INFO - 2023-04-03 07:03:32 --> Controller Class Initialized
DEBUG - 2023-04-03 07:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:03:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:03:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:03:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:03:32 --> Model "Login_model" initialized
INFO - 2023-04-03 07:03:32 --> Final output sent to browser
DEBUG - 2023-04-03 07:03:32 --> Total execution time: 0.7475
INFO - 2023-04-03 07:03:32 --> Config Class Initialized
INFO - 2023-04-03 07:03:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:03:32 --> Utf8 Class Initialized
INFO - 2023-04-03 07:03:32 --> URI Class Initialized
INFO - 2023-04-03 07:03:32 --> Router Class Initialized
INFO - 2023-04-03 07:03:32 --> Output Class Initialized
INFO - 2023-04-03 07:03:32 --> Security Class Initialized
DEBUG - 2023-04-03 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:03:32 --> Input Class Initialized
INFO - 2023-04-03 07:03:32 --> Language Class Initialized
INFO - 2023-04-03 07:03:32 --> Loader Class Initialized
INFO - 2023-04-03 07:03:32 --> Controller Class Initialized
DEBUG - 2023-04-03 07:03:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:03:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:03:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:03:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:03:32 --> Model "Login_model" initialized
INFO - 2023-04-03 07:03:33 --> Final output sent to browser
DEBUG - 2023-04-03 07:03:33 --> Total execution time: 0.7655
INFO - 2023-04-03 07:04:32 --> Config Class Initialized
INFO - 2023-04-03 07:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:04:32 --> Utf8 Class Initialized
INFO - 2023-04-03 07:04:32 --> URI Class Initialized
INFO - 2023-04-03 07:04:32 --> Router Class Initialized
INFO - 2023-04-03 07:04:32 --> Output Class Initialized
INFO - 2023-04-03 07:04:32 --> Security Class Initialized
DEBUG - 2023-04-03 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:04:32 --> Input Class Initialized
INFO - 2023-04-03 07:04:32 --> Language Class Initialized
INFO - 2023-04-03 07:04:32 --> Loader Class Initialized
INFO - 2023-04-03 07:04:32 --> Controller Class Initialized
DEBUG - 2023-04-03 07:04:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:04:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:04:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:04:33 --> Final output sent to browser
INFO - 2023-04-03 07:04:33 --> Config Class Initialized
DEBUG - 2023-04-03 07:04:33 --> Total execution time: 0.1212
INFO - 2023-04-03 07:04:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:04:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:04:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:04:33 --> URI Class Initialized
INFO - 2023-04-03 07:04:33 --> Router Class Initialized
INFO - 2023-04-03 07:04:33 --> Output Class Initialized
INFO - 2023-04-03 07:04:33 --> Security Class Initialized
DEBUG - 2023-04-03 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:04:33 --> Input Class Initialized
INFO - 2023-04-03 07:04:33 --> Language Class Initialized
INFO - 2023-04-03 07:04:33 --> Loader Class Initialized
INFO - 2023-04-03 07:04:33 --> Controller Class Initialized
DEBUG - 2023-04-03 07:04:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:04:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:04:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:04:33 --> Final output sent to browser
DEBUG - 2023-04-03 07:04:33 --> Total execution time: 0.1383
INFO - 2023-04-03 07:04:33 --> Config Class Initialized
INFO - 2023-04-03 07:04:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:04:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:04:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:04:33 --> URI Class Initialized
INFO - 2023-04-03 07:04:33 --> Router Class Initialized
INFO - 2023-04-03 07:04:33 --> Output Class Initialized
INFO - 2023-04-03 07:04:33 --> Security Class Initialized
DEBUG - 2023-04-03 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:04:33 --> Input Class Initialized
INFO - 2023-04-03 07:04:33 --> Language Class Initialized
INFO - 2023-04-03 07:04:33 --> Loader Class Initialized
INFO - 2023-04-03 07:04:33 --> Controller Class Initialized
DEBUG - 2023-04-03 07:04:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:04:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:04:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:04:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:04:33 --> Model "Login_model" initialized
INFO - 2023-04-03 07:04:34 --> Final output sent to browser
DEBUG - 2023-04-03 07:04:34 --> Total execution time: 0.6906
INFO - 2023-04-03 07:04:34 --> Config Class Initialized
INFO - 2023-04-03 07:04:34 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:04:34 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:04:34 --> Utf8 Class Initialized
INFO - 2023-04-03 07:04:34 --> URI Class Initialized
INFO - 2023-04-03 07:04:34 --> Router Class Initialized
INFO - 2023-04-03 07:04:34 --> Output Class Initialized
INFO - 2023-04-03 07:04:34 --> Security Class Initialized
DEBUG - 2023-04-03 07:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:04:34 --> Input Class Initialized
INFO - 2023-04-03 07:04:34 --> Language Class Initialized
INFO - 2023-04-03 07:04:34 --> Loader Class Initialized
INFO - 2023-04-03 07:04:34 --> Controller Class Initialized
DEBUG - 2023-04-03 07:04:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:04:34 --> Database Driver Class Initialized
INFO - 2023-04-03 07:04:34 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:04:34 --> Database Driver Class Initialized
INFO - 2023-04-03 07:04:34 --> Model "Login_model" initialized
INFO - 2023-04-03 07:04:35 --> Final output sent to browser
DEBUG - 2023-04-03 07:04:35 --> Total execution time: 0.6058
INFO - 2023-04-03 07:05:33 --> Config Class Initialized
INFO - 2023-04-03 07:05:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:05:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:05:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:05:33 --> URI Class Initialized
INFO - 2023-04-03 07:05:33 --> Router Class Initialized
INFO - 2023-04-03 07:05:33 --> Output Class Initialized
INFO - 2023-04-03 07:05:33 --> Security Class Initialized
DEBUG - 2023-04-03 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:05:33 --> Input Class Initialized
INFO - 2023-04-03 07:05:33 --> Language Class Initialized
INFO - 2023-04-03 07:05:33 --> Loader Class Initialized
INFO - 2023-04-03 07:05:33 --> Controller Class Initialized
DEBUG - 2023-04-03 07:05:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:05:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:05:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:05:33 --> Final output sent to browser
DEBUG - 2023-04-03 07:05:33 --> Total execution time: 0.1212
INFO - 2023-04-03 07:05:33 --> Config Class Initialized
INFO - 2023-04-03 07:05:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:05:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:05:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:05:33 --> URI Class Initialized
INFO - 2023-04-03 07:05:33 --> Router Class Initialized
INFO - 2023-04-03 07:05:33 --> Output Class Initialized
INFO - 2023-04-03 07:05:33 --> Security Class Initialized
DEBUG - 2023-04-03 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:05:33 --> Input Class Initialized
INFO - 2023-04-03 07:05:33 --> Language Class Initialized
INFO - 2023-04-03 07:05:33 --> Loader Class Initialized
INFO - 2023-04-03 07:05:33 --> Controller Class Initialized
DEBUG - 2023-04-03 07:05:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:05:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:05:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:05:33 --> Final output sent to browser
DEBUG - 2023-04-03 07:05:33 --> Total execution time: 0.1563
INFO - 2023-04-03 07:05:33 --> Config Class Initialized
INFO - 2023-04-03 07:05:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:05:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:05:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:05:33 --> URI Class Initialized
INFO - 2023-04-03 07:05:33 --> Router Class Initialized
INFO - 2023-04-03 07:05:33 --> Output Class Initialized
INFO - 2023-04-03 07:05:33 --> Security Class Initialized
DEBUG - 2023-04-03 07:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:05:33 --> Input Class Initialized
INFO - 2023-04-03 07:05:33 --> Language Class Initialized
INFO - 2023-04-03 07:05:33 --> Loader Class Initialized
INFO - 2023-04-03 07:05:33 --> Controller Class Initialized
DEBUG - 2023-04-03 07:05:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:05:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:05:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:05:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:05:33 --> Model "Login_model" initialized
INFO - 2023-04-03 07:05:34 --> Final output sent to browser
DEBUG - 2023-04-03 07:05:34 --> Total execution time: 0.7686
INFO - 2023-04-03 07:05:34 --> Config Class Initialized
INFO - 2023-04-03 07:05:34 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:05:34 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:05:34 --> Utf8 Class Initialized
INFO - 2023-04-03 07:05:34 --> URI Class Initialized
INFO - 2023-04-03 07:05:34 --> Router Class Initialized
INFO - 2023-04-03 07:05:34 --> Output Class Initialized
INFO - 2023-04-03 07:05:34 --> Security Class Initialized
DEBUG - 2023-04-03 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:05:34 --> Input Class Initialized
INFO - 2023-04-03 07:05:34 --> Language Class Initialized
INFO - 2023-04-03 07:05:34 --> Loader Class Initialized
INFO - 2023-04-03 07:05:34 --> Controller Class Initialized
DEBUG - 2023-04-03 07:05:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:05:34 --> Database Driver Class Initialized
INFO - 2023-04-03 07:05:34 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:05:34 --> Database Driver Class Initialized
INFO - 2023-04-03 07:05:34 --> Model "Login_model" initialized
INFO - 2023-04-03 07:05:35 --> Final output sent to browser
DEBUG - 2023-04-03 07:05:35 --> Total execution time: 0.7139
INFO - 2023-04-03 07:06:30 --> Config Class Initialized
INFO - 2023-04-03 07:06:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:06:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:06:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:06:30 --> URI Class Initialized
INFO - 2023-04-03 07:06:30 --> Router Class Initialized
INFO - 2023-04-03 07:06:30 --> Output Class Initialized
INFO - 2023-04-03 07:06:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:06:30 --> Input Class Initialized
INFO - 2023-04-03 07:06:30 --> Language Class Initialized
INFO - 2023-04-03 07:06:30 --> Loader Class Initialized
INFO - 2023-04-03 07:06:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:06:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:06:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:06:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:06:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:06:30 --> Total execution time: 0.0353
INFO - 2023-04-03 07:06:30 --> Config Class Initialized
INFO - 2023-04-03 07:06:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:06:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:06:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:06:30 --> URI Class Initialized
INFO - 2023-04-03 07:06:30 --> Router Class Initialized
INFO - 2023-04-03 07:06:30 --> Output Class Initialized
INFO - 2023-04-03 07:06:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:06:30 --> Input Class Initialized
INFO - 2023-04-03 07:06:30 --> Language Class Initialized
INFO - 2023-04-03 07:06:30 --> Loader Class Initialized
INFO - 2023-04-03 07:06:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:06:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:06:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:06:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:06:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:06:30 --> Total execution time: 0.0317
INFO - 2023-04-03 07:06:32 --> Config Class Initialized
INFO - 2023-04-03 07:06:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:06:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:06:32 --> Utf8 Class Initialized
INFO - 2023-04-03 07:06:32 --> URI Class Initialized
INFO - 2023-04-03 07:06:32 --> Router Class Initialized
INFO - 2023-04-03 07:06:32 --> Output Class Initialized
INFO - 2023-04-03 07:06:32 --> Security Class Initialized
DEBUG - 2023-04-03 07:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:06:32 --> Input Class Initialized
INFO - 2023-04-03 07:06:32 --> Language Class Initialized
INFO - 2023-04-03 07:06:32 --> Loader Class Initialized
INFO - 2023-04-03 07:06:32 --> Controller Class Initialized
DEBUG - 2023-04-03 07:06:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:06:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:06:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:06:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:06:32 --> Model "Login_model" initialized
INFO - 2023-04-03 07:06:32 --> Final output sent to browser
DEBUG - 2023-04-03 07:06:32 --> Total execution time: 0.6620
INFO - 2023-04-03 07:06:32 --> Config Class Initialized
INFO - 2023-04-03 07:06:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:06:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:06:32 --> Utf8 Class Initialized
INFO - 2023-04-03 07:06:32 --> URI Class Initialized
INFO - 2023-04-03 07:06:32 --> Router Class Initialized
INFO - 2023-04-03 07:06:32 --> Output Class Initialized
INFO - 2023-04-03 07:06:32 --> Security Class Initialized
DEBUG - 2023-04-03 07:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:06:32 --> Input Class Initialized
INFO - 2023-04-03 07:06:32 --> Language Class Initialized
INFO - 2023-04-03 07:06:32 --> Loader Class Initialized
INFO - 2023-04-03 07:06:32 --> Controller Class Initialized
DEBUG - 2023-04-03 07:06:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:06:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:06:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:06:32 --> Database Driver Class Initialized
INFO - 2023-04-03 07:06:32 --> Model "Login_model" initialized
INFO - 2023-04-03 07:06:33 --> Final output sent to browser
DEBUG - 2023-04-03 07:06:33 --> Total execution time: 0.5939
INFO - 2023-04-03 07:07:30 --> Config Class Initialized
INFO - 2023-04-03 07:07:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:07:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:07:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:07:30 --> URI Class Initialized
INFO - 2023-04-03 07:07:30 --> Router Class Initialized
INFO - 2023-04-03 07:07:30 --> Output Class Initialized
INFO - 2023-04-03 07:07:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:07:30 --> Input Class Initialized
INFO - 2023-04-03 07:07:30 --> Language Class Initialized
INFO - 2023-04-03 07:07:30 --> Loader Class Initialized
INFO - 2023-04-03 07:07:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:07:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:07:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:07:30 --> Config Class Initialized
INFO - 2023-04-03 07:07:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:07:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:07:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:07:30 --> URI Class Initialized
INFO - 2023-04-03 07:07:30 --> Router Class Initialized
INFO - 2023-04-03 07:07:30 --> Output Class Initialized
INFO - 2023-04-03 07:07:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:07:30 --> Input Class Initialized
INFO - 2023-04-03 07:07:30 --> Language Class Initialized
INFO - 2023-04-03 07:07:30 --> Loader Class Initialized
INFO - 2023-04-03 07:07:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:07:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:07:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:07:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:07:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:07:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:07:30 --> Model "Login_model" initialized
INFO - 2023-04-03 07:07:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:07:30 --> Total execution time: 0.0506
INFO - 2023-04-03 07:07:30 --> Config Class Initialized
INFO - 2023-04-03 07:07:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:07:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:07:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:07:30 --> URI Class Initialized
INFO - 2023-04-03 07:07:30 --> Router Class Initialized
INFO - 2023-04-03 07:07:30 --> Output Class Initialized
INFO - 2023-04-03 07:07:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:07:30 --> Input Class Initialized
INFO - 2023-04-03 07:07:30 --> Language Class Initialized
INFO - 2023-04-03 07:07:30 --> Loader Class Initialized
INFO - 2023-04-03 07:07:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:07:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:07:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:07:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:07:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:07:30 --> Total execution time: 0.0430
INFO - 2023-04-03 07:07:31 --> Final output sent to browser
DEBUG - 2023-04-03 07:07:31 --> Total execution time: 0.6991
INFO - 2023-04-03 07:07:31 --> Config Class Initialized
INFO - 2023-04-03 07:07:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:07:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:07:31 --> Utf8 Class Initialized
INFO - 2023-04-03 07:07:31 --> URI Class Initialized
INFO - 2023-04-03 07:07:31 --> Router Class Initialized
INFO - 2023-04-03 07:07:31 --> Output Class Initialized
INFO - 2023-04-03 07:07:31 --> Security Class Initialized
DEBUG - 2023-04-03 07:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:07:31 --> Input Class Initialized
INFO - 2023-04-03 07:07:31 --> Language Class Initialized
INFO - 2023-04-03 07:07:31 --> Loader Class Initialized
INFO - 2023-04-03 07:07:31 --> Controller Class Initialized
DEBUG - 2023-04-03 07:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:07:31 --> Database Driver Class Initialized
INFO - 2023-04-03 07:07:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:07:31 --> Database Driver Class Initialized
INFO - 2023-04-03 07:07:31 --> Model "Login_model" initialized
INFO - 2023-04-03 07:07:32 --> Final output sent to browser
DEBUG - 2023-04-03 07:07:32 --> Total execution time: 0.7170
INFO - 2023-04-03 07:08:30 --> Config Class Initialized
INFO - 2023-04-03 07:08:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:08:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:08:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:08:30 --> URI Class Initialized
INFO - 2023-04-03 07:08:30 --> Router Class Initialized
INFO - 2023-04-03 07:08:30 --> Output Class Initialized
INFO - 2023-04-03 07:08:30 --> Config Class Initialized
INFO - 2023-04-03 07:08:30 --> Security Class Initialized
INFO - 2023-04-03 07:08:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:08:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:08:30 --> Input Class Initialized
INFO - 2023-04-03 07:08:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:08:30 --> Language Class Initialized
INFO - 2023-04-03 07:08:30 --> URI Class Initialized
INFO - 2023-04-03 07:08:30 --> Loader Class Initialized
INFO - 2023-04-03 07:08:30 --> Router Class Initialized
INFO - 2023-04-03 07:08:30 --> Controller Class Initialized
INFO - 2023-04-03 07:08:30 --> Output Class Initialized
DEBUG - 2023-04-03 07:08:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:08:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:08:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:08:30 --> Input Class Initialized
INFO - 2023-04-03 07:08:30 --> Language Class Initialized
INFO - 2023-04-03 07:08:30 --> Loader Class Initialized
INFO - 2023-04-03 07:08:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:08:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:08:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:08:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:08:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:08:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:08:30 --> Model "Login_model" initialized
INFO - 2023-04-03 07:08:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:08:30 --> Total execution time: 0.0454
INFO - 2023-04-03 07:08:30 --> Config Class Initialized
INFO - 2023-04-03 07:08:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:08:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:08:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:08:30 --> URI Class Initialized
INFO - 2023-04-03 07:08:30 --> Router Class Initialized
INFO - 2023-04-03 07:08:30 --> Output Class Initialized
INFO - 2023-04-03 07:08:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:08:30 --> Input Class Initialized
INFO - 2023-04-03 07:08:30 --> Language Class Initialized
INFO - 2023-04-03 07:08:30 --> Loader Class Initialized
INFO - 2023-04-03 07:08:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:08:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:08:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:08:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:08:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:08:30 --> Total execution time: 0.0413
INFO - 2023-04-03 07:08:31 --> Final output sent to browser
DEBUG - 2023-04-03 07:08:31 --> Total execution time: 0.6442
INFO - 2023-04-03 07:08:31 --> Config Class Initialized
INFO - 2023-04-03 07:08:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:08:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:08:31 --> Utf8 Class Initialized
INFO - 2023-04-03 07:08:31 --> URI Class Initialized
INFO - 2023-04-03 07:08:31 --> Router Class Initialized
INFO - 2023-04-03 07:08:31 --> Output Class Initialized
INFO - 2023-04-03 07:08:31 --> Security Class Initialized
DEBUG - 2023-04-03 07:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:08:31 --> Input Class Initialized
INFO - 2023-04-03 07:08:31 --> Language Class Initialized
INFO - 2023-04-03 07:08:31 --> Loader Class Initialized
INFO - 2023-04-03 07:08:31 --> Controller Class Initialized
DEBUG - 2023-04-03 07:08:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:08:31 --> Database Driver Class Initialized
INFO - 2023-04-03 07:08:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:08:31 --> Database Driver Class Initialized
INFO - 2023-04-03 07:08:31 --> Model "Login_model" initialized
INFO - 2023-04-03 07:08:32 --> Final output sent to browser
DEBUG - 2023-04-03 07:08:32 --> Total execution time: 0.5908
INFO - 2023-04-03 07:09:30 --> Config Class Initialized
INFO - 2023-04-03 07:09:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:09:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:09:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:09:30 --> Config Class Initialized
INFO - 2023-04-03 07:09:30 --> URI Class Initialized
INFO - 2023-04-03 07:09:30 --> Hooks Class Initialized
INFO - 2023-04-03 07:09:30 --> Router Class Initialized
DEBUG - 2023-04-03 07:09:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:09:30 --> Output Class Initialized
INFO - 2023-04-03 07:09:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:09:30 --> Security Class Initialized
INFO - 2023-04-03 07:09:30 --> URI Class Initialized
DEBUG - 2023-04-03 07:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:09:30 --> Router Class Initialized
INFO - 2023-04-03 07:09:30 --> Input Class Initialized
INFO - 2023-04-03 07:09:30 --> Output Class Initialized
INFO - 2023-04-03 07:09:30 --> Language Class Initialized
INFO - 2023-04-03 07:09:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:09:30 --> Loader Class Initialized
INFO - 2023-04-03 07:09:30 --> Input Class Initialized
INFO - 2023-04-03 07:09:30 --> Controller Class Initialized
INFO - 2023-04-03 07:09:30 --> Language Class Initialized
DEBUG - 2023-04-03 07:09:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:09:30 --> Loader Class Initialized
INFO - 2023-04-03 07:09:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:09:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:09:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:09:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:09:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:09:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:09:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:09:30 --> Model "Login_model" initialized
INFO - 2023-04-03 07:09:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:09:30 --> Total execution time: 0.0472
INFO - 2023-04-03 07:09:30 --> Config Class Initialized
INFO - 2023-04-03 07:09:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:09:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:09:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:09:30 --> URI Class Initialized
INFO - 2023-04-03 07:09:30 --> Router Class Initialized
INFO - 2023-04-03 07:09:30 --> Output Class Initialized
INFO - 2023-04-03 07:09:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:09:30 --> Input Class Initialized
INFO - 2023-04-03 07:09:30 --> Language Class Initialized
INFO - 2023-04-03 07:09:30 --> Loader Class Initialized
INFO - 2023-04-03 07:09:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:09:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:09:30 --> Database Driver Class Initialized
INFO - 2023-04-03 07:09:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:09:30 --> Final output sent to browser
DEBUG - 2023-04-03 07:09:30 --> Total execution time: 0.0837
INFO - 2023-04-03 07:09:31 --> Final output sent to browser
DEBUG - 2023-04-03 07:09:31 --> Total execution time: 0.7809
INFO - 2023-04-03 07:09:31 --> Config Class Initialized
INFO - 2023-04-03 07:09:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:09:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:09:31 --> Utf8 Class Initialized
INFO - 2023-04-03 07:09:31 --> URI Class Initialized
INFO - 2023-04-03 07:09:31 --> Router Class Initialized
INFO - 2023-04-03 07:09:31 --> Output Class Initialized
INFO - 2023-04-03 07:09:31 --> Security Class Initialized
DEBUG - 2023-04-03 07:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:09:31 --> Input Class Initialized
INFO - 2023-04-03 07:09:31 --> Language Class Initialized
INFO - 2023-04-03 07:09:31 --> Loader Class Initialized
INFO - 2023-04-03 07:09:31 --> Controller Class Initialized
DEBUG - 2023-04-03 07:09:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:09:31 --> Database Driver Class Initialized
INFO - 2023-04-03 07:09:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:09:31 --> Database Driver Class Initialized
INFO - 2023-04-03 07:09:31 --> Model "Login_model" initialized
INFO - 2023-04-03 07:09:32 --> Final output sent to browser
DEBUG - 2023-04-03 07:09:32 --> Total execution time: 0.7630
INFO - 2023-04-03 07:10:25 --> Config Class Initialized
INFO - 2023-04-03 07:10:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:10:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:10:25 --> Utf8 Class Initialized
INFO - 2023-04-03 07:10:25 --> URI Class Initialized
INFO - 2023-04-03 07:10:25 --> Router Class Initialized
INFO - 2023-04-03 07:10:25 --> Output Class Initialized
INFO - 2023-04-03 07:10:25 --> Security Class Initialized
DEBUG - 2023-04-03 07:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:10:25 --> Input Class Initialized
INFO - 2023-04-03 07:10:25 --> Language Class Initialized
INFO - 2023-04-03 07:10:25 --> Loader Class Initialized
INFO - 2023-04-03 07:10:25 --> Controller Class Initialized
DEBUG - 2023-04-03 07:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:10:25 --> Database Driver Class Initialized
INFO - 2023-04-03 07:10:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:10:25 --> Final output sent to browser
DEBUG - 2023-04-03 07:10:25 --> Total execution time: 0.0142
INFO - 2023-04-03 07:10:25 --> Config Class Initialized
INFO - 2023-04-03 07:10:26 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:10:26 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:10:26 --> Utf8 Class Initialized
INFO - 2023-04-03 07:10:26 --> URI Class Initialized
INFO - 2023-04-03 07:10:26 --> Router Class Initialized
INFO - 2023-04-03 07:10:26 --> Output Class Initialized
INFO - 2023-04-03 07:10:26 --> Security Class Initialized
DEBUG - 2023-04-03 07:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:10:26 --> Input Class Initialized
INFO - 2023-04-03 07:10:26 --> Language Class Initialized
INFO - 2023-04-03 07:10:26 --> Loader Class Initialized
INFO - 2023-04-03 07:10:26 --> Controller Class Initialized
DEBUG - 2023-04-03 07:10:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:10:26 --> Database Driver Class Initialized
INFO - 2023-04-03 07:10:26 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:10:26 --> Final output sent to browser
DEBUG - 2023-04-03 07:10:26 --> Total execution time: 0.0519
INFO - 2023-04-03 07:42:40 --> Config Class Initialized
INFO - 2023-04-03 07:42:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:40 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:40 --> URI Class Initialized
INFO - 2023-04-03 07:42:40 --> Router Class Initialized
INFO - 2023-04-03 07:42:40 --> Output Class Initialized
INFO - 2023-04-03 07:42:40 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:40 --> Input Class Initialized
INFO - 2023-04-03 07:42:40 --> Language Class Initialized
INFO - 2023-04-03 07:42:40 --> Loader Class Initialized
INFO - 2023-04-03 07:42:40 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:40 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:40 --> Total execution time: 0.0442
INFO - 2023-04-03 07:42:40 --> Config Class Initialized
INFO - 2023-04-03 07:42:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:40 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:40 --> URI Class Initialized
INFO - 2023-04-03 07:42:40 --> Router Class Initialized
INFO - 2023-04-03 07:42:40 --> Output Class Initialized
INFO - 2023-04-03 07:42:40 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:40 --> Input Class Initialized
INFO - 2023-04-03 07:42:40 --> Language Class Initialized
INFO - 2023-04-03 07:42:40 --> Loader Class Initialized
INFO - 2023-04-03 07:42:40 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:40 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:40 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:40 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:40 --> Total execution time: 0.0235
INFO - 2023-04-03 07:42:42 --> Config Class Initialized
INFO - 2023-04-03 07:42:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:42 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:42 --> URI Class Initialized
INFO - 2023-04-03 07:42:42 --> Router Class Initialized
INFO - 2023-04-03 07:42:42 --> Output Class Initialized
INFO - 2023-04-03 07:42:42 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:42 --> Input Class Initialized
INFO - 2023-04-03 07:42:42 --> Language Class Initialized
INFO - 2023-04-03 07:42:42 --> Loader Class Initialized
INFO - 2023-04-03 07:42:42 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:42 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:42 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:42 --> Total execution time: 0.0165
INFO - 2023-04-03 07:42:42 --> Config Class Initialized
INFO - 2023-04-03 07:42:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:42 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:42 --> URI Class Initialized
INFO - 2023-04-03 07:42:42 --> Router Class Initialized
INFO - 2023-04-03 07:42:42 --> Output Class Initialized
INFO - 2023-04-03 07:42:42 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:42 --> Input Class Initialized
INFO - 2023-04-03 07:42:42 --> Language Class Initialized
INFO - 2023-04-03 07:42:42 --> Loader Class Initialized
INFO - 2023-04-03 07:42:42 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:42 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:42 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:42 --> Total execution time: 0.0543
INFO - 2023-04-03 07:42:46 --> Config Class Initialized
INFO - 2023-04-03 07:42:46 --> Hooks Class Initialized
INFO - 2023-04-03 07:42:46 --> Config Class Initialized
INFO - 2023-04-03 07:42:46 --> Config Class Initialized
INFO - 2023-04-03 07:42:46 --> Hooks Class Initialized
INFO - 2023-04-03 07:42:46 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:46 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:46 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:46 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:46 --> URI Class Initialized
INFO - 2023-04-03 07:42:46 --> URI Class Initialized
INFO - 2023-04-03 07:42:46 --> URI Class Initialized
INFO - 2023-04-03 07:42:46 --> Router Class Initialized
INFO - 2023-04-03 07:42:46 --> Router Class Initialized
INFO - 2023-04-03 07:42:46 --> Router Class Initialized
INFO - 2023-04-03 07:42:46 --> Output Class Initialized
INFO - 2023-04-03 07:42:46 --> Output Class Initialized
INFO - 2023-04-03 07:42:46 --> Security Class Initialized
INFO - 2023-04-03 07:42:46 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:46 --> Output Class Initialized
INFO - 2023-04-03 07:42:46 --> Input Class Initialized
INFO - 2023-04-03 07:42:46 --> Input Class Initialized
INFO - 2023-04-03 07:42:46 --> Security Class Initialized
INFO - 2023-04-03 07:42:46 --> Language Class Initialized
INFO - 2023-04-03 07:42:46 --> Language Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:46 --> Input Class Initialized
INFO - 2023-04-03 07:42:46 --> Language Class Initialized
INFO - 2023-04-03 07:42:46 --> Loader Class Initialized
INFO - 2023-04-03 07:42:46 --> Loader Class Initialized
INFO - 2023-04-03 07:42:46 --> Loader Class Initialized
INFO - 2023-04-03 07:42:46 --> Controller Class Initialized
INFO - 2023-04-03 07:42:46 --> Controller Class Initialized
INFO - 2023-04-03 07:42:46 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Model "Login_model" initialized
INFO - 2023-04-03 07:42:46 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:46 --> Total execution time: 0.0254
INFO - 2023-04-03 07:42:46 --> Config Class Initialized
INFO - 2023-04-03 07:42:46 --> Hooks Class Initialized
INFO - 2023-04-03 07:42:46 --> Final output sent to browser
INFO - 2023-04-03 07:42:46 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:42:46 --> Total execution time: 0.0417
INFO - 2023-04-03 07:42:46 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Total execution time: 0.0314
INFO - 2023-04-03 07:42:46 --> URI Class Initialized
INFO - 2023-04-03 07:42:46 --> Config Class Initialized
INFO - 2023-04-03 07:42:46 --> Config Class Initialized
INFO - 2023-04-03 07:42:46 --> Hooks Class Initialized
INFO - 2023-04-03 07:42:46 --> Router Class Initialized
DEBUG - 2023-04-03 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:46 --> Hooks Class Initialized
INFO - 2023-04-03 07:42:46 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:46 --> Output Class Initialized
DEBUG - 2023-04-03 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:46 --> URI Class Initialized
INFO - 2023-04-03 07:42:46 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:46 --> Security Class Initialized
INFO - 2023-04-03 07:42:46 --> Router Class Initialized
INFO - 2023-04-03 07:42:46 --> URI Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:46 --> Output Class Initialized
INFO - 2023-04-03 07:42:46 --> Input Class Initialized
INFO - 2023-04-03 07:42:46 --> Router Class Initialized
INFO - 2023-04-03 07:42:46 --> Language Class Initialized
INFO - 2023-04-03 07:42:46 --> Security Class Initialized
INFO - 2023-04-03 07:42:46 --> Output Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:46 --> Loader Class Initialized
INFO - 2023-04-03 07:42:46 --> Security Class Initialized
INFO - 2023-04-03 07:42:46 --> Input Class Initialized
INFO - 2023-04-03 07:42:46 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:46 --> Input Class Initialized
INFO - 2023-04-03 07:42:46 --> Language Class Initialized
INFO - 2023-04-03 07:42:46 --> Language Class Initialized
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Loader Class Initialized
INFO - 2023-04-03 07:42:46 --> Loader Class Initialized
INFO - 2023-04-03 07:42:46 --> Controller Class Initialized
INFO - 2023-04-03 07:42:46 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:46 --> Model "Login_model" initialized
INFO - 2023-04-03 07:42:46 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:46 --> Total execution time: 0.0661
INFO - 2023-04-03 07:42:46 --> Config Class Initialized
INFO - 2023-04-03 07:42:46 --> Final output sent to browser
INFO - 2023-04-03 07:42:46 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:46 --> Total execution time: 0.0963
INFO - 2023-04-03 07:42:46 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Total execution time: 0.1535
DEBUG - 2023-04-03 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:46 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:46 --> URI Class Initialized
INFO - 2023-04-03 07:42:46 --> Router Class Initialized
INFO - 2023-04-03 07:42:46 --> Output Class Initialized
INFO - 2023-04-03 07:42:46 --> Security Class Initialized
INFO - 2023-04-03 07:42:46 --> Config Class Initialized
INFO - 2023-04-03 07:42:46 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:42:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:46 --> Input Class Initialized
INFO - 2023-04-03 07:42:46 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:46 --> Language Class Initialized
INFO - 2023-04-03 07:42:46 --> URI Class Initialized
INFO - 2023-04-03 07:42:46 --> Loader Class Initialized
INFO - 2023-04-03 07:42:46 --> Router Class Initialized
INFO - 2023-04-03 07:42:46 --> Controller Class Initialized
INFO - 2023-04-03 07:42:46 --> Output Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:46 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Input Class Initialized
INFO - 2023-04-03 07:42:46 --> Language Class Initialized
INFO - 2023-04-03 07:42:46 --> Loader Class Initialized
INFO - 2023-04-03 07:42:46 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:46 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:46 --> Final output sent to browser
INFO - 2023-04-03 07:42:46 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:46 --> Total execution time: 0.1524
DEBUG - 2023-04-03 07:42:46 --> Total execution time: 0.0677
INFO - 2023-04-03 07:42:50 --> Config Class Initialized
INFO - 2023-04-03 07:42:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:50 --> URI Class Initialized
INFO - 2023-04-03 07:42:50 --> Router Class Initialized
INFO - 2023-04-03 07:42:50 --> Output Class Initialized
INFO - 2023-04-03 07:42:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:50 --> Input Class Initialized
INFO - 2023-04-03 07:42:50 --> Language Class Initialized
INFO - 2023-04-03 07:42:50 --> Loader Class Initialized
INFO - 2023-04-03 07:42:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:50 --> Total execution time: 0.0045
INFO - 2023-04-03 07:42:50 --> Config Class Initialized
INFO - 2023-04-03 07:42:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:50 --> URI Class Initialized
INFO - 2023-04-03 07:42:50 --> Router Class Initialized
INFO - 2023-04-03 07:42:50 --> Output Class Initialized
INFO - 2023-04-03 07:42:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:50 --> Input Class Initialized
INFO - 2023-04-03 07:42:50 --> Language Class Initialized
INFO - 2023-04-03 07:42:50 --> Loader Class Initialized
INFO - 2023-04-03 07:42:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:50 --> Total execution time: 0.0523
INFO - 2023-04-03 07:42:54 --> Config Class Initialized
INFO - 2023-04-03 07:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:54 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:54 --> URI Class Initialized
INFO - 2023-04-03 07:42:54 --> Router Class Initialized
INFO - 2023-04-03 07:42:54 --> Output Class Initialized
INFO - 2023-04-03 07:42:54 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:54 --> Input Class Initialized
INFO - 2023-04-03 07:42:54 --> Language Class Initialized
INFO - 2023-04-03 07:42:54 --> Loader Class Initialized
INFO - 2023-04-03 07:42:54 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:54 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:54 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:54 --> Total execution time: 0.0448
INFO - 2023-04-03 07:42:54 --> Config Class Initialized
INFO - 2023-04-03 07:42:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:42:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:42:54 --> Utf8 Class Initialized
INFO - 2023-04-03 07:42:54 --> URI Class Initialized
INFO - 2023-04-03 07:42:54 --> Router Class Initialized
INFO - 2023-04-03 07:42:54 --> Output Class Initialized
INFO - 2023-04-03 07:42:54 --> Security Class Initialized
DEBUG - 2023-04-03 07:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:42:54 --> Input Class Initialized
INFO - 2023-04-03 07:42:54 --> Language Class Initialized
INFO - 2023-04-03 07:42:54 --> Loader Class Initialized
INFO - 2023-04-03 07:42:54 --> Controller Class Initialized
DEBUG - 2023-04-03 07:42:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:42:54 --> Database Driver Class Initialized
INFO - 2023-04-03 07:42:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:42:54 --> Final output sent to browser
DEBUG - 2023-04-03 07:42:54 --> Total execution time: 0.0808
INFO - 2023-04-03 07:43:13 --> Config Class Initialized
INFO - 2023-04-03 07:43:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:43:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:43:13 --> Utf8 Class Initialized
INFO - 2023-04-03 07:43:13 --> URI Class Initialized
INFO - 2023-04-03 07:43:13 --> Router Class Initialized
INFO - 2023-04-03 07:43:13 --> Output Class Initialized
INFO - 2023-04-03 07:43:13 --> Security Class Initialized
DEBUG - 2023-04-03 07:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:43:13 --> Input Class Initialized
INFO - 2023-04-03 07:43:13 --> Language Class Initialized
INFO - 2023-04-03 07:43:13 --> Loader Class Initialized
INFO - 2023-04-03 07:43:13 --> Controller Class Initialized
DEBUG - 2023-04-03 07:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:43:13 --> Database Driver Class Initialized
INFO - 2023-04-03 07:43:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:43:13 --> Final output sent to browser
DEBUG - 2023-04-03 07:43:13 --> Total execution time: 0.0264
INFO - 2023-04-03 07:43:13 --> Config Class Initialized
INFO - 2023-04-03 07:43:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:43:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:43:13 --> Utf8 Class Initialized
INFO - 2023-04-03 07:43:13 --> URI Class Initialized
INFO - 2023-04-03 07:43:13 --> Router Class Initialized
INFO - 2023-04-03 07:43:13 --> Output Class Initialized
INFO - 2023-04-03 07:43:13 --> Security Class Initialized
DEBUG - 2023-04-03 07:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:43:13 --> Input Class Initialized
INFO - 2023-04-03 07:43:13 --> Language Class Initialized
INFO - 2023-04-03 07:43:13 --> Loader Class Initialized
INFO - 2023-04-03 07:43:13 --> Controller Class Initialized
DEBUG - 2023-04-03 07:43:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:43:13 --> Database Driver Class Initialized
INFO - 2023-04-03 07:43:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:43:13 --> Final output sent to browser
DEBUG - 2023-04-03 07:43:13 --> Total execution time: 0.0604
INFO - 2023-04-03 07:43:15 --> Config Class Initialized
INFO - 2023-04-03 07:43:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:43:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:43:15 --> Utf8 Class Initialized
INFO - 2023-04-03 07:43:15 --> URI Class Initialized
INFO - 2023-04-03 07:43:15 --> Router Class Initialized
INFO - 2023-04-03 07:43:15 --> Output Class Initialized
INFO - 2023-04-03 07:43:15 --> Security Class Initialized
DEBUG - 2023-04-03 07:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:43:15 --> Input Class Initialized
INFO - 2023-04-03 07:43:15 --> Language Class Initialized
INFO - 2023-04-03 07:43:15 --> Loader Class Initialized
INFO - 2023-04-03 07:43:15 --> Controller Class Initialized
DEBUG - 2023-04-03 07:43:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:43:15 --> Database Driver Class Initialized
INFO - 2023-04-03 07:43:15 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:43:15 --> Final output sent to browser
DEBUG - 2023-04-03 07:43:15 --> Total execution time: 0.0432
INFO - 2023-04-03 07:43:15 --> Config Class Initialized
INFO - 2023-04-03 07:43:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:43:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:43:15 --> Utf8 Class Initialized
INFO - 2023-04-03 07:43:15 --> URI Class Initialized
INFO - 2023-04-03 07:43:15 --> Router Class Initialized
INFO - 2023-04-03 07:43:15 --> Output Class Initialized
INFO - 2023-04-03 07:43:15 --> Security Class Initialized
DEBUG - 2023-04-03 07:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:43:15 --> Input Class Initialized
INFO - 2023-04-03 07:43:15 --> Language Class Initialized
INFO - 2023-04-03 07:43:15 --> Loader Class Initialized
INFO - 2023-04-03 07:43:15 --> Controller Class Initialized
DEBUG - 2023-04-03 07:43:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:43:15 --> Database Driver Class Initialized
INFO - 2023-04-03 07:43:15 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:43:15 --> Final output sent to browser
DEBUG - 2023-04-03 07:43:15 --> Total execution time: 0.0878
INFO - 2023-04-03 07:44:16 --> Config Class Initialized
INFO - 2023-04-03 07:44:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:44:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:44:16 --> Utf8 Class Initialized
INFO - 2023-04-03 07:44:16 --> URI Class Initialized
INFO - 2023-04-03 07:44:16 --> Router Class Initialized
INFO - 2023-04-03 07:44:16 --> Output Class Initialized
INFO - 2023-04-03 07:44:16 --> Security Class Initialized
DEBUG - 2023-04-03 07:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:44:16 --> Input Class Initialized
INFO - 2023-04-03 07:44:16 --> Language Class Initialized
INFO - 2023-04-03 07:44:16 --> Loader Class Initialized
INFO - 2023-04-03 07:44:16 --> Controller Class Initialized
DEBUG - 2023-04-03 07:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:44:16 --> Database Driver Class Initialized
INFO - 2023-04-03 07:44:16 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:44:16 --> Final output sent to browser
DEBUG - 2023-04-03 07:44:16 --> Total execution time: 0.1222
INFO - 2023-04-03 07:44:16 --> Config Class Initialized
INFO - 2023-04-03 07:44:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:44:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:44:16 --> Utf8 Class Initialized
INFO - 2023-04-03 07:44:16 --> URI Class Initialized
INFO - 2023-04-03 07:44:16 --> Router Class Initialized
INFO - 2023-04-03 07:44:16 --> Output Class Initialized
INFO - 2023-04-03 07:44:16 --> Security Class Initialized
DEBUG - 2023-04-03 07:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:44:16 --> Input Class Initialized
INFO - 2023-04-03 07:44:16 --> Language Class Initialized
INFO - 2023-04-03 07:44:16 --> Loader Class Initialized
INFO - 2023-04-03 07:44:16 --> Controller Class Initialized
DEBUG - 2023-04-03 07:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:44:16 --> Database Driver Class Initialized
INFO - 2023-04-03 07:44:16 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:44:16 --> Final output sent to browser
DEBUG - 2023-04-03 07:44:16 --> Total execution time: 0.0371
INFO - 2023-04-03 07:44:18 --> Config Class Initialized
INFO - 2023-04-03 07:44:18 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:44:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:44:18 --> Utf8 Class Initialized
INFO - 2023-04-03 07:44:18 --> URI Class Initialized
INFO - 2023-04-03 07:44:18 --> Router Class Initialized
INFO - 2023-04-03 07:44:18 --> Output Class Initialized
INFO - 2023-04-03 07:44:18 --> Security Class Initialized
DEBUG - 2023-04-03 07:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:44:18 --> Input Class Initialized
INFO - 2023-04-03 07:44:18 --> Language Class Initialized
INFO - 2023-04-03 07:44:18 --> Loader Class Initialized
INFO - 2023-04-03 07:44:18 --> Controller Class Initialized
DEBUG - 2023-04-03 07:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:44:18 --> Final output sent to browser
DEBUG - 2023-04-03 07:44:18 --> Total execution time: 0.0453
INFO - 2023-04-03 07:44:18 --> Config Class Initialized
INFO - 2023-04-03 07:44:18 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:44:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:44:18 --> Utf8 Class Initialized
INFO - 2023-04-03 07:44:18 --> URI Class Initialized
INFO - 2023-04-03 07:44:18 --> Router Class Initialized
INFO - 2023-04-03 07:44:18 --> Output Class Initialized
INFO - 2023-04-03 07:44:18 --> Security Class Initialized
DEBUG - 2023-04-03 07:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:44:18 --> Input Class Initialized
INFO - 2023-04-03 07:44:18 --> Language Class Initialized
INFO - 2023-04-03 07:44:18 --> Loader Class Initialized
INFO - 2023-04-03 07:44:18 --> Controller Class Initialized
DEBUG - 2023-04-03 07:44:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:44:18 --> Database Driver Class Initialized
INFO - 2023-04-03 07:44:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:44:18 --> Final output sent to browser
DEBUG - 2023-04-03 07:44:18 --> Total execution time: 0.0568
INFO - 2023-04-03 07:44:21 --> Config Class Initialized
INFO - 2023-04-03 07:44:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:44:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:44:21 --> Utf8 Class Initialized
INFO - 2023-04-03 07:44:21 --> URI Class Initialized
INFO - 2023-04-03 07:44:21 --> Router Class Initialized
INFO - 2023-04-03 07:44:21 --> Output Class Initialized
INFO - 2023-04-03 07:44:21 --> Security Class Initialized
DEBUG - 2023-04-03 07:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:44:21 --> Input Class Initialized
INFO - 2023-04-03 07:44:21 --> Language Class Initialized
INFO - 2023-04-03 07:44:21 --> Loader Class Initialized
INFO - 2023-04-03 07:44:21 --> Controller Class Initialized
DEBUG - 2023-04-03 07:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:44:21 --> Database Driver Class Initialized
INFO - 2023-04-03 07:44:21 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:44:21 --> Final output sent to browser
DEBUG - 2023-04-03 07:44:21 --> Total execution time: 0.0446
INFO - 2023-04-03 07:44:21 --> Config Class Initialized
INFO - 2023-04-03 07:44:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:44:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:44:21 --> Utf8 Class Initialized
INFO - 2023-04-03 07:44:21 --> URI Class Initialized
INFO - 2023-04-03 07:44:21 --> Router Class Initialized
INFO - 2023-04-03 07:44:21 --> Output Class Initialized
INFO - 2023-04-03 07:44:21 --> Security Class Initialized
DEBUG - 2023-04-03 07:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:44:21 --> Input Class Initialized
INFO - 2023-04-03 07:44:21 --> Language Class Initialized
INFO - 2023-04-03 07:44:21 --> Loader Class Initialized
INFO - 2023-04-03 07:44:21 --> Controller Class Initialized
DEBUG - 2023-04-03 07:44:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:44:21 --> Database Driver Class Initialized
INFO - 2023-04-03 07:44:21 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:44:21 --> Final output sent to browser
DEBUG - 2023-04-03 07:44:21 --> Total execution time: 0.0402
INFO - 2023-04-03 07:48:26 --> Config Class Initialized
INFO - 2023-04-03 07:48:26 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:48:26 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:48:26 --> Utf8 Class Initialized
INFO - 2023-04-03 07:48:26 --> URI Class Initialized
INFO - 2023-04-03 07:48:26 --> Router Class Initialized
INFO - 2023-04-03 07:48:26 --> Output Class Initialized
INFO - 2023-04-03 07:48:26 --> Security Class Initialized
DEBUG - 2023-04-03 07:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:48:26 --> Input Class Initialized
INFO - 2023-04-03 07:48:26 --> Language Class Initialized
INFO - 2023-04-03 07:48:26 --> Loader Class Initialized
INFO - 2023-04-03 07:48:26 --> Controller Class Initialized
DEBUG - 2023-04-03 07:48:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:48:26 --> Database Driver Class Initialized
INFO - 2023-04-03 07:48:26 --> Database Driver Class Initialized
INFO - 2023-04-03 07:48:26 --> Model "Login_model" initialized
INFO - 2023-04-03 07:48:26 --> Final output sent to browser
DEBUG - 2023-04-03 07:48:26 --> Total execution time: 0.0282
INFO - 2023-04-03 07:48:26 --> Config Class Initialized
INFO - 2023-04-03 07:48:26 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:48:26 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:48:26 --> Utf8 Class Initialized
INFO - 2023-04-03 07:48:26 --> URI Class Initialized
INFO - 2023-04-03 07:48:26 --> Router Class Initialized
INFO - 2023-04-03 07:48:26 --> Output Class Initialized
INFO - 2023-04-03 07:48:26 --> Security Class Initialized
DEBUG - 2023-04-03 07:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:48:26 --> Input Class Initialized
INFO - 2023-04-03 07:48:26 --> Language Class Initialized
INFO - 2023-04-03 07:48:26 --> Loader Class Initialized
INFO - 2023-04-03 07:48:26 --> Controller Class Initialized
DEBUG - 2023-04-03 07:48:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:48:26 --> Database Driver Class Initialized
INFO - 2023-04-03 07:48:26 --> Database Driver Class Initialized
INFO - 2023-04-03 07:48:26 --> Model "Login_model" initialized
INFO - 2023-04-03 07:48:26 --> Final output sent to browser
DEBUG - 2023-04-03 07:48:26 --> Total execution time: 0.0602
INFO - 2023-04-03 07:48:29 --> Config Class Initialized
INFO - 2023-04-03 07:48:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:48:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:48:29 --> Utf8 Class Initialized
INFO - 2023-04-03 07:48:29 --> URI Class Initialized
INFO - 2023-04-03 07:48:29 --> Router Class Initialized
INFO - 2023-04-03 07:48:29 --> Output Class Initialized
INFO - 2023-04-03 07:48:29 --> Security Class Initialized
DEBUG - 2023-04-03 07:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:48:29 --> Input Class Initialized
INFO - 2023-04-03 07:48:29 --> Language Class Initialized
INFO - 2023-04-03 07:48:29 --> Loader Class Initialized
INFO - 2023-04-03 07:48:29 --> Controller Class Initialized
DEBUG - 2023-04-03 07:48:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:48:29 --> Database Driver Class Initialized
INFO - 2023-04-03 07:48:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:48:29 --> Final output sent to browser
DEBUG - 2023-04-03 07:48:29 --> Total execution time: 0.0215
INFO - 2023-04-03 07:48:29 --> Config Class Initialized
INFO - 2023-04-03 07:48:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:48:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:48:29 --> Utf8 Class Initialized
INFO - 2023-04-03 07:48:29 --> URI Class Initialized
INFO - 2023-04-03 07:48:29 --> Router Class Initialized
INFO - 2023-04-03 07:48:29 --> Output Class Initialized
INFO - 2023-04-03 07:48:29 --> Security Class Initialized
DEBUG - 2023-04-03 07:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:48:29 --> Input Class Initialized
INFO - 2023-04-03 07:48:29 --> Language Class Initialized
INFO - 2023-04-03 07:48:29 --> Loader Class Initialized
INFO - 2023-04-03 07:48:29 --> Controller Class Initialized
DEBUG - 2023-04-03 07:48:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:48:29 --> Database Driver Class Initialized
INFO - 2023-04-03 07:48:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:48:29 --> Final output sent to browser
DEBUG - 2023-04-03 07:48:29 --> Total execution time: 0.0550
INFO - 2023-04-03 07:51:37 --> Config Class Initialized
INFO - 2023-04-03 07:51:37 --> Config Class Initialized
INFO - 2023-04-03 07:51:37 --> Hooks Class Initialized
INFO - 2023-04-03 07:51:37 --> Config Class Initialized
INFO - 2023-04-03 07:51:37 --> Hooks Class Initialized
INFO - 2023-04-03 07:51:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:37 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:37 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:37 --> URI Class Initialized
INFO - 2023-04-03 07:51:37 --> URI Class Initialized
INFO - 2023-04-03 07:51:37 --> Router Class Initialized
INFO - 2023-04-03 07:51:37 --> Output Class Initialized
INFO - 2023-04-03 07:51:37 --> Security Class Initialized
INFO - 2023-04-03 07:51:37 --> Router Class Initialized
INFO - 2023-04-03 07:51:37 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:37 --> Input Class Initialized
INFO - 2023-04-03 07:51:37 --> Output Class Initialized
INFO - 2023-04-03 07:51:37 --> URI Class Initialized
INFO - 2023-04-03 07:51:37 --> Language Class Initialized
INFO - 2023-04-03 07:51:37 --> Router Class Initialized
INFO - 2023-04-03 07:51:37 --> Security Class Initialized
INFO - 2023-04-03 07:51:37 --> Output Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:37 --> Loader Class Initialized
INFO - 2023-04-03 07:51:37 --> Input Class Initialized
INFO - 2023-04-03 07:51:37 --> Security Class Initialized
INFO - 2023-04-03 07:51:37 --> Controller Class Initialized
INFO - 2023-04-03 07:51:37 --> Language Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:37 --> Loader Class Initialized
INFO - 2023-04-03 07:51:37 --> Input Class Initialized
INFO - 2023-04-03 07:51:37 --> Controller Class Initialized
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Language Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:37 --> Loader Class Initialized
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Model "Login_model" initialized
INFO - 2023-04-03 07:51:37 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:37 --> Total execution time: 0.0277
INFO - 2023-04-03 07:51:37 --> Config Class Initialized
INFO - 2023-04-03 07:51:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:37 --> Final output sent to browser
INFO - 2023-04-03 07:51:37 --> Final output sent to browser
INFO - 2023-04-03 07:51:37 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Total execution time: 0.0482
DEBUG - 2023-04-03 07:51:37 --> Total execution time: 0.0320
INFO - 2023-04-03 07:51:37 --> URI Class Initialized
INFO - 2023-04-03 07:51:37 --> Config Class Initialized
INFO - 2023-04-03 07:51:37 --> Config Class Initialized
INFO - 2023-04-03 07:51:37 --> Hooks Class Initialized
INFO - 2023-04-03 07:51:37 --> Router Class Initialized
INFO - 2023-04-03 07:51:37 --> Hooks Class Initialized
INFO - 2023-04-03 07:51:37 --> Output Class Initialized
INFO - 2023-04-03 07:51:37 --> Security Class Initialized
DEBUG - 2023-04-03 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:37 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:37 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:37 --> Input Class Initialized
INFO - 2023-04-03 07:51:37 --> URI Class Initialized
INFO - 2023-04-03 07:51:37 --> URI Class Initialized
INFO - 2023-04-03 07:51:37 --> Language Class Initialized
INFO - 2023-04-03 07:51:37 --> Router Class Initialized
INFO - 2023-04-03 07:51:37 --> Router Class Initialized
INFO - 2023-04-03 07:51:37 --> Output Class Initialized
INFO - 2023-04-03 07:51:37 --> Output Class Initialized
INFO - 2023-04-03 07:51:37 --> Loader Class Initialized
INFO - 2023-04-03 07:51:37 --> Security Class Initialized
INFO - 2023-04-03 07:51:37 --> Security Class Initialized
INFO - 2023-04-03 07:51:37 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:37 --> Input Class Initialized
INFO - 2023-04-03 07:51:37 --> Input Class Initialized
INFO - 2023-04-03 07:51:37 --> Language Class Initialized
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Language Class Initialized
INFO - 2023-04-03 07:51:37 --> Loader Class Initialized
INFO - 2023-04-03 07:51:37 --> Loader Class Initialized
INFO - 2023-04-03 07:51:37 --> Controller Class Initialized
INFO - 2023-04-03 07:51:37 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Model "Login_model" initialized
INFO - 2023-04-03 07:51:37 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:37 --> Total execution time: 0.0680
INFO - 2023-04-03 07:51:37 --> Config Class Initialized
INFO - 2023-04-03 07:51:37 --> Final output sent to browser
INFO - 2023-04-03 07:51:37 --> Final output sent to browser
INFO - 2023-04-03 07:51:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Total execution time: 0.0801
DEBUG - 2023-04-03 07:51:37 --> Total execution time: 0.1537
DEBUG - 2023-04-03 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:37 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:37 --> URI Class Initialized
INFO - 2023-04-03 07:51:37 --> Router Class Initialized
INFO - 2023-04-03 07:51:37 --> Config Class Initialized
INFO - 2023-04-03 07:51:37 --> Hooks Class Initialized
INFO - 2023-04-03 07:51:37 --> Output Class Initialized
DEBUG - 2023-04-03 07:51:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:37 --> Security Class Initialized
INFO - 2023-04-03 07:51:37 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:37 --> URI Class Initialized
INFO - 2023-04-03 07:51:37 --> Input Class Initialized
INFO - 2023-04-03 07:51:37 --> Router Class Initialized
INFO - 2023-04-03 07:51:37 --> Language Class Initialized
INFO - 2023-04-03 07:51:37 --> Output Class Initialized
INFO - 2023-04-03 07:51:37 --> Loader Class Initialized
INFO - 2023-04-03 07:51:37 --> Security Class Initialized
INFO - 2023-04-03 07:51:37 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:37 --> Input Class Initialized
INFO - 2023-04-03 07:51:37 --> Language Class Initialized
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Loader Class Initialized
INFO - 2023-04-03 07:51:37 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:37 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:37 --> Final output sent to browser
INFO - 2023-04-03 07:51:37 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:37 --> Total execution time: 0.0601
DEBUG - 2023-04-03 07:51:37 --> Total execution time: 0.1028
INFO - 2023-04-03 07:51:50 --> Config Class Initialized
INFO - 2023-04-03 07:51:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:50 --> URI Class Initialized
INFO - 2023-04-03 07:51:50 --> Router Class Initialized
INFO - 2023-04-03 07:51:50 --> Output Class Initialized
INFO - 2023-04-03 07:51:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:50 --> Input Class Initialized
INFO - 2023-04-03 07:51:50 --> Language Class Initialized
INFO - 2023-04-03 07:51:50 --> Loader Class Initialized
INFO - 2023-04-03 07:51:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:50 --> Total execution time: 0.0048
INFO - 2023-04-03 07:51:50 --> Config Class Initialized
INFO - 2023-04-03 07:51:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:50 --> URI Class Initialized
INFO - 2023-04-03 07:51:50 --> Router Class Initialized
INFO - 2023-04-03 07:51:50 --> Output Class Initialized
INFO - 2023-04-03 07:51:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:50 --> Input Class Initialized
INFO - 2023-04-03 07:51:50 --> Language Class Initialized
INFO - 2023-04-03 07:51:50 --> Loader Class Initialized
INFO - 2023-04-03 07:51:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:50 --> Total execution time: 0.0517
INFO - 2023-04-03 07:51:53 --> Config Class Initialized
INFO - 2023-04-03 07:51:53 --> Config Class Initialized
INFO - 2023-04-03 07:51:53 --> Config Class Initialized
INFO - 2023-04-03 07:51:53 --> Hooks Class Initialized
INFO - 2023-04-03 07:51:53 --> Hooks Class Initialized
INFO - 2023-04-03 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:53 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:53 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:53 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:53 --> URI Class Initialized
INFO - 2023-04-03 07:51:53 --> URI Class Initialized
INFO - 2023-04-03 07:51:53 --> URI Class Initialized
INFO - 2023-04-03 07:51:53 --> Router Class Initialized
INFO - 2023-04-03 07:51:53 --> Router Class Initialized
INFO - 2023-04-03 07:51:53 --> Router Class Initialized
INFO - 2023-04-03 07:51:53 --> Output Class Initialized
INFO - 2023-04-03 07:51:53 --> Output Class Initialized
INFO - 2023-04-03 07:51:53 --> Output Class Initialized
INFO - 2023-04-03 07:51:53 --> Security Class Initialized
INFO - 2023-04-03 07:51:53 --> Security Class Initialized
INFO - 2023-04-03 07:51:53 --> Security Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:53 --> Input Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:53 --> Input Class Initialized
INFO - 2023-04-03 07:51:53 --> Input Class Initialized
INFO - 2023-04-03 07:51:53 --> Language Class Initialized
INFO - 2023-04-03 07:51:53 --> Language Class Initialized
INFO - 2023-04-03 07:51:53 --> Language Class Initialized
INFO - 2023-04-03 07:51:53 --> Loader Class Initialized
INFO - 2023-04-03 07:51:53 --> Loader Class Initialized
INFO - 2023-04-03 07:51:53 --> Controller Class Initialized
INFO - 2023-04-03 07:51:53 --> Loader Class Initialized
INFO - 2023-04-03 07:51:53 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:53 --> Controller Class Initialized
INFO - 2023-04-03 07:51:53 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:53 --> Database Driver Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:53 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:53 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:53 --> Model "Login_model" initialized
INFO - 2023-04-03 07:51:53 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:53 --> Total execution time: 0.0276
INFO - 2023-04-03 07:51:53 --> Config Class Initialized
INFO - 2023-04-03 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:53 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:53 --> URI Class Initialized
INFO - 2023-04-03 07:51:53 --> Router Class Initialized
INFO - 2023-04-03 07:51:53 --> Output Class Initialized
INFO - 2023-04-03 07:51:53 --> Security Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:53 --> Input Class Initialized
INFO - 2023-04-03 07:51:53 --> Language Class Initialized
INFO - 2023-04-03 07:51:53 --> Loader Class Initialized
INFO - 2023-04-03 07:51:53 --> Controller Class Initialized
INFO - 2023-04-03 07:51:53 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:51:53 --> Total execution time: 0.0308
INFO - 2023-04-03 07:51:53 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:53 --> Config Class Initialized
INFO - 2023-04-03 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:53 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:53 --> URI Class Initialized
INFO - 2023-04-03 07:51:53 --> Router Class Initialized
INFO - 2023-04-03 07:51:53 --> Output Class Initialized
INFO - 2023-04-03 07:51:53 --> Security Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:53 --> Input Class Initialized
INFO - 2023-04-03 07:51:53 --> Language Class Initialized
INFO - 2023-04-03 07:51:53 --> Loader Class Initialized
INFO - 2023-04-03 07:51:53 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:53 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:53 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:53 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:53 --> Total execution time: 0.0434
INFO - 2023-04-03 07:51:53 --> Config Class Initialized
INFO - 2023-04-03 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:53 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:53 --> URI Class Initialized
INFO - 2023-04-03 07:51:53 --> Router Class Initialized
INFO - 2023-04-03 07:51:53 --> Output Class Initialized
INFO - 2023-04-03 07:51:53 --> Security Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:53 --> Input Class Initialized
INFO - 2023-04-03 07:51:53 --> Language Class Initialized
INFO - 2023-04-03 07:51:53 --> Loader Class Initialized
INFO - 2023-04-03 07:51:53 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:53 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:54 --> Model "Login_model" initialized
INFO - 2023-04-03 07:51:54 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:54 --> Total execution time: 0.0233
INFO - 2023-04-03 07:51:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:54 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:54 --> Total execution time: 0.0273
INFO - 2023-04-03 07:51:54 --> Config Class Initialized
INFO - 2023-04-03 07:51:54 --> Config Class Initialized
INFO - 2023-04-03 07:51:54 --> Final output sent to browser
INFO - 2023-04-03 07:51:54 --> Hooks Class Initialized
INFO - 2023-04-03 07:51:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:51:54 --> Total execution time: 0.0263
DEBUG - 2023-04-03 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:51:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:51:54 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:54 --> Utf8 Class Initialized
INFO - 2023-04-03 07:51:54 --> URI Class Initialized
INFO - 2023-04-03 07:51:54 --> URI Class Initialized
INFO - 2023-04-03 07:51:54 --> Router Class Initialized
INFO - 2023-04-03 07:51:54 --> Router Class Initialized
INFO - 2023-04-03 07:51:54 --> Output Class Initialized
INFO - 2023-04-03 07:51:54 --> Security Class Initialized
INFO - 2023-04-03 07:51:54 --> Output Class Initialized
DEBUG - 2023-04-03 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:54 --> Security Class Initialized
INFO - 2023-04-03 07:51:54 --> Input Class Initialized
DEBUG - 2023-04-03 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:51:54 --> Language Class Initialized
INFO - 2023-04-03 07:51:54 --> Input Class Initialized
INFO - 2023-04-03 07:51:54 --> Language Class Initialized
INFO - 2023-04-03 07:51:54 --> Loader Class Initialized
INFO - 2023-04-03 07:51:54 --> Loader Class Initialized
INFO - 2023-04-03 07:51:54 --> Controller Class Initialized
INFO - 2023-04-03 07:51:54 --> Controller Class Initialized
DEBUG - 2023-04-03 07:51:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:51:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:51:54 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:54 --> Database Driver Class Initialized
INFO - 2023-04-03 07:51:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:51:54 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:54 --> Total execution time: 0.1071
INFO - 2023-04-03 07:51:54 --> Final output sent to browser
DEBUG - 2023-04-03 07:51:54 --> Total execution time: 0.1186
INFO - 2023-04-03 07:52:04 --> Config Class Initialized
INFO - 2023-04-03 07:52:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:04 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:04 --> URI Class Initialized
INFO - 2023-04-03 07:52:04 --> Router Class Initialized
INFO - 2023-04-03 07:52:04 --> Output Class Initialized
INFO - 2023-04-03 07:52:04 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:04 --> Input Class Initialized
INFO - 2023-04-03 07:52:04 --> Language Class Initialized
INFO - 2023-04-03 07:52:04 --> Loader Class Initialized
INFO - 2023-04-03 07:52:04 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:04 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:04 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:04 --> Total execution time: 0.0156
INFO - 2023-04-03 07:52:04 --> Config Class Initialized
INFO - 2023-04-03 07:52:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:04 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:04 --> URI Class Initialized
INFO - 2023-04-03 07:52:04 --> Router Class Initialized
INFO - 2023-04-03 07:52:04 --> Output Class Initialized
INFO - 2023-04-03 07:52:04 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:04 --> Input Class Initialized
INFO - 2023-04-03 07:52:04 --> Language Class Initialized
INFO - 2023-04-03 07:52:04 --> Loader Class Initialized
INFO - 2023-04-03 07:52:04 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:04 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:04 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:04 --> Total execution time: 0.0578
INFO - 2023-04-03 07:52:09 --> Config Class Initialized
INFO - 2023-04-03 07:52:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:09 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:09 --> URI Class Initialized
INFO - 2023-04-03 07:52:09 --> Router Class Initialized
INFO - 2023-04-03 07:52:09 --> Output Class Initialized
INFO - 2023-04-03 07:52:09 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:09 --> Input Class Initialized
INFO - 2023-04-03 07:52:09 --> Language Class Initialized
INFO - 2023-04-03 07:52:09 --> Loader Class Initialized
INFO - 2023-04-03 07:52:09 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:09 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:09 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:09 --> Model "Login_model" initialized
INFO - 2023-04-03 07:52:09 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:09 --> Total execution time: 0.0611
INFO - 2023-04-03 07:52:09 --> Config Class Initialized
INFO - 2023-04-03 07:52:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:09 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:09 --> URI Class Initialized
INFO - 2023-04-03 07:52:09 --> Router Class Initialized
INFO - 2023-04-03 07:52:09 --> Output Class Initialized
INFO - 2023-04-03 07:52:09 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:09 --> Input Class Initialized
INFO - 2023-04-03 07:52:09 --> Language Class Initialized
INFO - 2023-04-03 07:52:09 --> Loader Class Initialized
INFO - 2023-04-03 07:52:09 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:09 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:09 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:09 --> Model "Login_model" initialized
INFO - 2023-04-03 07:52:09 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:09 --> Total execution time: 0.0862
INFO - 2023-04-03 07:52:14 --> Config Class Initialized
INFO - 2023-04-03 07:52:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:14 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:14 --> URI Class Initialized
INFO - 2023-04-03 07:52:14 --> Router Class Initialized
INFO - 2023-04-03 07:52:14 --> Output Class Initialized
INFO - 2023-04-03 07:52:14 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:14 --> Input Class Initialized
INFO - 2023-04-03 07:52:14 --> Language Class Initialized
INFO - 2023-04-03 07:52:14 --> Loader Class Initialized
INFO - 2023-04-03 07:52:14 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:14 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:14 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:14 --> Total execution time: 0.0425
INFO - 2023-04-03 07:52:14 --> Config Class Initialized
INFO - 2023-04-03 07:52:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:14 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:14 --> URI Class Initialized
INFO - 2023-04-03 07:52:14 --> Router Class Initialized
INFO - 2023-04-03 07:52:14 --> Output Class Initialized
INFO - 2023-04-03 07:52:14 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:14 --> Input Class Initialized
INFO - 2023-04-03 07:52:14 --> Language Class Initialized
INFO - 2023-04-03 07:52:14 --> Loader Class Initialized
INFO - 2023-04-03 07:52:14 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:14 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:14 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:14 --> Total execution time: 0.0412
INFO - 2023-04-03 07:52:15 --> Config Class Initialized
INFO - 2023-04-03 07:52:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:15 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:15 --> URI Class Initialized
INFO - 2023-04-03 07:52:15 --> Router Class Initialized
INFO - 2023-04-03 07:52:15 --> Output Class Initialized
INFO - 2023-04-03 07:52:15 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:15 --> Input Class Initialized
INFO - 2023-04-03 07:52:15 --> Language Class Initialized
INFO - 2023-04-03 07:52:15 --> Loader Class Initialized
INFO - 2023-04-03 07:52:15 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:15 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:15 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:15 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:15 --> Total execution time: 0.0369
INFO - 2023-04-03 07:52:15 --> Config Class Initialized
INFO - 2023-04-03 07:52:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:15 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:15 --> URI Class Initialized
INFO - 2023-04-03 07:52:15 --> Router Class Initialized
INFO - 2023-04-03 07:52:15 --> Output Class Initialized
INFO - 2023-04-03 07:52:15 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:15 --> Input Class Initialized
INFO - 2023-04-03 07:52:15 --> Language Class Initialized
INFO - 2023-04-03 07:52:15 --> Loader Class Initialized
INFO - 2023-04-03 07:52:15 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:15 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:15 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:15 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:15 --> Total execution time: 0.0527
INFO - 2023-04-03 07:52:17 --> Config Class Initialized
INFO - 2023-04-03 07:52:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:17 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:17 --> URI Class Initialized
INFO - 2023-04-03 07:52:17 --> Router Class Initialized
INFO - 2023-04-03 07:52:17 --> Output Class Initialized
INFO - 2023-04-03 07:52:17 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:17 --> Input Class Initialized
INFO - 2023-04-03 07:52:17 --> Language Class Initialized
INFO - 2023-04-03 07:52:17 --> Loader Class Initialized
INFO - 2023-04-03 07:52:17 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:17 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:17 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:17 --> Total execution time: 0.0213
INFO - 2023-04-03 07:52:17 --> Config Class Initialized
INFO - 2023-04-03 07:52:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:17 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:17 --> URI Class Initialized
INFO - 2023-04-03 07:52:17 --> Router Class Initialized
INFO - 2023-04-03 07:52:17 --> Output Class Initialized
INFO - 2023-04-03 07:52:17 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:17 --> Input Class Initialized
INFO - 2023-04-03 07:52:17 --> Language Class Initialized
INFO - 2023-04-03 07:52:17 --> Loader Class Initialized
INFO - 2023-04-03 07:52:17 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:17 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:17 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:17 --> Total execution time: 0.0556
INFO - 2023-04-03 07:52:28 --> Config Class Initialized
INFO - 2023-04-03 07:52:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:28 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:28 --> URI Class Initialized
INFO - 2023-04-03 07:52:28 --> Router Class Initialized
INFO - 2023-04-03 07:52:28 --> Output Class Initialized
INFO - 2023-04-03 07:52:28 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:28 --> Input Class Initialized
INFO - 2023-04-03 07:52:28 --> Language Class Initialized
INFO - 2023-04-03 07:52:28 --> Loader Class Initialized
INFO - 2023-04-03 07:52:28 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:28 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:28 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:28 --> Total execution time: 0.0133
INFO - 2023-04-03 07:52:28 --> Config Class Initialized
INFO - 2023-04-03 07:52:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:28 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:28 --> URI Class Initialized
INFO - 2023-04-03 07:52:28 --> Router Class Initialized
INFO - 2023-04-03 07:52:28 --> Output Class Initialized
INFO - 2023-04-03 07:52:28 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:28 --> Input Class Initialized
INFO - 2023-04-03 07:52:28 --> Language Class Initialized
INFO - 2023-04-03 07:52:28 --> Loader Class Initialized
INFO - 2023-04-03 07:52:28 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:28 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:28 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:28 --> Total execution time: 0.0528
INFO - 2023-04-03 07:52:31 --> Config Class Initialized
INFO - 2023-04-03 07:52:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:31 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:31 --> URI Class Initialized
INFO - 2023-04-03 07:52:31 --> Router Class Initialized
INFO - 2023-04-03 07:52:31 --> Output Class Initialized
INFO - 2023-04-03 07:52:31 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:31 --> Input Class Initialized
INFO - 2023-04-03 07:52:31 --> Language Class Initialized
INFO - 2023-04-03 07:52:31 --> Loader Class Initialized
INFO - 2023-04-03 07:52:31 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:31 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:31 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:31 --> Total execution time: 0.0127
INFO - 2023-04-03 07:52:33 --> Config Class Initialized
INFO - 2023-04-03 07:52:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:33 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:33 --> URI Class Initialized
INFO - 2023-04-03 07:52:33 --> Router Class Initialized
INFO - 2023-04-03 07:52:33 --> Output Class Initialized
INFO - 2023-04-03 07:52:33 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:33 --> Input Class Initialized
INFO - 2023-04-03 07:52:33 --> Language Class Initialized
INFO - 2023-04-03 07:52:33 --> Loader Class Initialized
INFO - 2023-04-03 07:52:33 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:33 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:33 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:33 --> Total execution time: 0.0151
INFO - 2023-04-03 07:52:42 --> Config Class Initialized
INFO - 2023-04-03 07:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:42 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:42 --> URI Class Initialized
INFO - 2023-04-03 07:52:42 --> Router Class Initialized
INFO - 2023-04-03 07:52:42 --> Output Class Initialized
INFO - 2023-04-03 07:52:42 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:42 --> Input Class Initialized
INFO - 2023-04-03 07:52:42 --> Language Class Initialized
INFO - 2023-04-03 07:52:42 --> Loader Class Initialized
INFO - 2023-04-03 07:52:42 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:42 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:42 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:42 --> Total execution time: 0.0233
INFO - 2023-04-03 07:52:42 --> Config Class Initialized
INFO - 2023-04-03 07:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:42 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:42 --> URI Class Initialized
INFO - 2023-04-03 07:52:42 --> Router Class Initialized
INFO - 2023-04-03 07:52:42 --> Output Class Initialized
INFO - 2023-04-03 07:52:42 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:42 --> Input Class Initialized
INFO - 2023-04-03 07:52:42 --> Language Class Initialized
INFO - 2023-04-03 07:52:42 --> Loader Class Initialized
INFO - 2023-04-03 07:52:42 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:42 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:42 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:42 --> Total execution time: 0.0588
INFO - 2023-04-03 07:52:43 --> Config Class Initialized
INFO - 2023-04-03 07:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:43 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:43 --> URI Class Initialized
INFO - 2023-04-03 07:52:43 --> Router Class Initialized
INFO - 2023-04-03 07:52:43 --> Output Class Initialized
INFO - 2023-04-03 07:52:43 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:43 --> Input Class Initialized
INFO - 2023-04-03 07:52:43 --> Language Class Initialized
INFO - 2023-04-03 07:52:43 --> Loader Class Initialized
INFO - 2023-04-03 07:52:43 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:43 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:43 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:43 --> Total execution time: 0.0391
INFO - 2023-04-03 07:52:43 --> Config Class Initialized
INFO - 2023-04-03 07:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:43 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:43 --> URI Class Initialized
INFO - 2023-04-03 07:52:43 --> Router Class Initialized
INFO - 2023-04-03 07:52:43 --> Output Class Initialized
INFO - 2023-04-03 07:52:43 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:43 --> Input Class Initialized
INFO - 2023-04-03 07:52:43 --> Language Class Initialized
INFO - 2023-04-03 07:52:43 --> Loader Class Initialized
INFO - 2023-04-03 07:52:43 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:43 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:43 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:43 --> Total execution time: 0.0550
INFO - 2023-04-03 07:52:48 --> Config Class Initialized
INFO - 2023-04-03 07:52:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:48 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:48 --> URI Class Initialized
INFO - 2023-04-03 07:52:48 --> Router Class Initialized
INFO - 2023-04-03 07:52:48 --> Output Class Initialized
INFO - 2023-04-03 07:52:48 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:48 --> Input Class Initialized
INFO - 2023-04-03 07:52:48 --> Language Class Initialized
INFO - 2023-04-03 07:52:48 --> Loader Class Initialized
INFO - 2023-04-03 07:52:48 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:48 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:48 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:48 --> Total execution time: 0.0149
INFO - 2023-04-03 07:52:48 --> Config Class Initialized
INFO - 2023-04-03 07:52:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:48 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:48 --> URI Class Initialized
INFO - 2023-04-03 07:52:48 --> Router Class Initialized
INFO - 2023-04-03 07:52:48 --> Output Class Initialized
INFO - 2023-04-03 07:52:48 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:48 --> Input Class Initialized
INFO - 2023-04-03 07:52:48 --> Language Class Initialized
INFO - 2023-04-03 07:52:48 --> Loader Class Initialized
INFO - 2023-04-03 07:52:48 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:48 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:48 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:48 --> Model "Login_model" initialized
INFO - 2023-04-03 07:52:48 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:48 --> Total execution time: 0.0328
INFO - 2023-04-03 07:52:48 --> Config Class Initialized
INFO - 2023-04-03 07:52:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:48 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:48 --> URI Class Initialized
INFO - 2023-04-03 07:52:48 --> Router Class Initialized
INFO - 2023-04-03 07:52:48 --> Output Class Initialized
INFO - 2023-04-03 07:52:48 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:48 --> Input Class Initialized
INFO - 2023-04-03 07:52:48 --> Language Class Initialized
INFO - 2023-04-03 07:52:48 --> Loader Class Initialized
INFO - 2023-04-03 07:52:48 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:48 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:48 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:48 --> Total execution time: 0.0112
INFO - 2023-04-03 07:52:48 --> Config Class Initialized
INFO - 2023-04-03 07:52:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:48 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:48 --> URI Class Initialized
INFO - 2023-04-03 07:52:48 --> Router Class Initialized
INFO - 2023-04-03 07:52:48 --> Output Class Initialized
INFO - 2023-04-03 07:52:48 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:48 --> Input Class Initialized
INFO - 2023-04-03 07:52:48 --> Language Class Initialized
INFO - 2023-04-03 07:52:48 --> Loader Class Initialized
INFO - 2023-04-03 07:52:48 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:48 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:48 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:48 --> Total execution time: 0.0136
INFO - 2023-04-03 07:52:53 --> Config Class Initialized
INFO - 2023-04-03 07:52:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:53 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:53 --> URI Class Initialized
INFO - 2023-04-03 07:52:53 --> Router Class Initialized
INFO - 2023-04-03 07:52:53 --> Output Class Initialized
INFO - 2023-04-03 07:52:53 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:53 --> Input Class Initialized
INFO - 2023-04-03 07:52:53 --> Language Class Initialized
INFO - 2023-04-03 07:52:53 --> Loader Class Initialized
INFO - 2023-04-03 07:52:53 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:53 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:53 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:53 --> Total execution time: 0.0210
INFO - 2023-04-03 07:52:58 --> Config Class Initialized
INFO - 2023-04-03 07:52:58 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:58 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:58 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:58 --> URI Class Initialized
INFO - 2023-04-03 07:52:58 --> Router Class Initialized
INFO - 2023-04-03 07:52:58 --> Output Class Initialized
INFO - 2023-04-03 07:52:58 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:58 --> Input Class Initialized
INFO - 2023-04-03 07:52:58 --> Language Class Initialized
INFO - 2023-04-03 07:52:58 --> Loader Class Initialized
INFO - 2023-04-03 07:52:58 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:58 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:58 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:58 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:58 --> Total execution time: 0.0132
INFO - 2023-04-03 07:52:58 --> Config Class Initialized
INFO - 2023-04-03 07:52:58 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:52:58 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:52:58 --> Utf8 Class Initialized
INFO - 2023-04-03 07:52:58 --> URI Class Initialized
INFO - 2023-04-03 07:52:58 --> Router Class Initialized
INFO - 2023-04-03 07:52:58 --> Output Class Initialized
INFO - 2023-04-03 07:52:58 --> Security Class Initialized
DEBUG - 2023-04-03 07:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:52:58 --> Input Class Initialized
INFO - 2023-04-03 07:52:58 --> Language Class Initialized
INFO - 2023-04-03 07:52:58 --> Loader Class Initialized
INFO - 2023-04-03 07:52:58 --> Controller Class Initialized
DEBUG - 2023-04-03 07:52:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:52:58 --> Database Driver Class Initialized
INFO - 2023-04-03 07:52:58 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:52:58 --> Final output sent to browser
DEBUG - 2023-04-03 07:52:58 --> Total execution time: 0.0138
INFO - 2023-04-03 07:53:03 --> Config Class Initialized
INFO - 2023-04-03 07:53:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:53:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:53:03 --> Utf8 Class Initialized
INFO - 2023-04-03 07:53:03 --> URI Class Initialized
INFO - 2023-04-03 07:53:03 --> Router Class Initialized
INFO - 2023-04-03 07:53:03 --> Output Class Initialized
INFO - 2023-04-03 07:53:03 --> Security Class Initialized
DEBUG - 2023-04-03 07:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:53:03 --> Input Class Initialized
INFO - 2023-04-03 07:53:03 --> Language Class Initialized
INFO - 2023-04-03 07:53:03 --> Loader Class Initialized
INFO - 2023-04-03 07:53:03 --> Controller Class Initialized
DEBUG - 2023-04-03 07:53:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:53:03 --> Database Driver Class Initialized
INFO - 2023-04-03 07:53:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:53:03 --> Final output sent to browser
DEBUG - 2023-04-03 07:53:03 --> Total execution time: 0.0178
INFO - 2023-04-03 07:53:08 --> Config Class Initialized
INFO - 2023-04-03 07:53:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:53:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:53:08 --> Utf8 Class Initialized
INFO - 2023-04-03 07:53:08 --> URI Class Initialized
INFO - 2023-04-03 07:53:08 --> Router Class Initialized
INFO - 2023-04-03 07:53:08 --> Output Class Initialized
INFO - 2023-04-03 07:53:08 --> Security Class Initialized
DEBUG - 2023-04-03 07:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:53:08 --> Input Class Initialized
INFO - 2023-04-03 07:53:08 --> Language Class Initialized
INFO - 2023-04-03 07:53:08 --> Loader Class Initialized
INFO - 2023-04-03 07:53:08 --> Controller Class Initialized
DEBUG - 2023-04-03 07:53:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:53:08 --> Database Driver Class Initialized
INFO - 2023-04-03 07:53:13 --> Config Class Initialized
INFO - 2023-04-03 07:53:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:53:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:53:13 --> Utf8 Class Initialized
INFO - 2023-04-03 07:53:13 --> URI Class Initialized
INFO - 2023-04-03 07:53:13 --> Router Class Initialized
INFO - 2023-04-03 07:53:13 --> Output Class Initialized
INFO - 2023-04-03 07:53:13 --> Security Class Initialized
DEBUG - 2023-04-03 07:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:53:13 --> Input Class Initialized
INFO - 2023-04-03 07:53:13 --> Language Class Initialized
INFO - 2023-04-03 07:53:13 --> Loader Class Initialized
INFO - 2023-04-03 07:53:13 --> Controller Class Initialized
DEBUG - 2023-04-03 07:53:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:53:13 --> Database Driver Class Initialized
INFO - 2023-04-03 07:53:20 --> Config Class Initialized
INFO - 2023-04-03 07:53:20 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:53:20 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:53:20 --> Utf8 Class Initialized
INFO - 2023-04-03 07:53:20 --> URI Class Initialized
INFO - 2023-04-03 07:53:20 --> Router Class Initialized
INFO - 2023-04-03 07:53:20 --> Output Class Initialized
INFO - 2023-04-03 07:53:20 --> Security Class Initialized
DEBUG - 2023-04-03 07:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:53:20 --> Input Class Initialized
INFO - 2023-04-03 07:53:20 --> Language Class Initialized
INFO - 2023-04-03 07:53:20 --> Loader Class Initialized
INFO - 2023-04-03 07:53:20 --> Controller Class Initialized
DEBUG - 2023-04-03 07:53:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:53:20 --> Database Driver Class Initialized
INFO - 2023-04-03 07:53:25 --> Config Class Initialized
INFO - 2023-04-03 07:53:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:53:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:53:25 --> Utf8 Class Initialized
INFO - 2023-04-03 07:53:25 --> URI Class Initialized
INFO - 2023-04-03 07:53:25 --> Router Class Initialized
INFO - 2023-04-03 07:53:25 --> Output Class Initialized
INFO - 2023-04-03 07:53:25 --> Security Class Initialized
DEBUG - 2023-04-03 07:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:53:25 --> Input Class Initialized
INFO - 2023-04-03 07:53:25 --> Language Class Initialized
INFO - 2023-04-03 07:53:25 --> Loader Class Initialized
INFO - 2023-04-03 07:53:25 --> Controller Class Initialized
DEBUG - 2023-04-03 07:53:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:53:25 --> Database Driver Class Initialized
INFO - 2023-04-03 07:53:31 --> Config Class Initialized
INFO - 2023-04-03 07:53:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:53:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:53:31 --> Utf8 Class Initialized
INFO - 2023-04-03 07:53:31 --> URI Class Initialized
INFO - 2023-04-03 07:53:31 --> Router Class Initialized
INFO - 2023-04-03 07:53:31 --> Output Class Initialized
INFO - 2023-04-03 07:53:31 --> Security Class Initialized
DEBUG - 2023-04-03 07:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:53:31 --> Input Class Initialized
INFO - 2023-04-03 07:53:31 --> Language Class Initialized
INFO - 2023-04-03 07:53:31 --> Loader Class Initialized
INFO - 2023-04-03 07:53:31 --> Controller Class Initialized
DEBUG - 2023-04-03 07:53:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:53:31 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 84.4946
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 78.8773
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 96.9671
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 101.9683
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 89.9446
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0159
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0160
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0161
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0161
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0161
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0112
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0123
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0124
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0124
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0177
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0260
INFO - 2023-04-03 07:54:50 --> Config Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0168
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0223
INFO - 2023-04-03 07:54:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0231
DEBUG - 2023-04-03 07:54:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:50 --> URI Class Initialized
INFO - 2023-04-03 07:54:50 --> Router Class Initialized
INFO - 2023-04-03 07:54:50 --> Output Class Initialized
INFO - 2023-04-03 07:54:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:50 --> Input Class Initialized
INFO - 2023-04-03 07:54:50 --> Language Class Initialized
INFO - 2023-04-03 07:54:50 --> Loader Class Initialized
INFO - 2023-04-03 07:54:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:50 --> Database Driver Class Initialized
INFO - 2023-04-03 07:54:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 07:54:50 --> Final output sent to browser
DEBUG - 2023-04-03 07:54:50 --> Total execution time: 0.0546
INFO - 2023-04-03 07:54:51 --> Config Class Initialized
INFO - 2023-04-03 07:54:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:54:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:51 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:51 --> URI Class Initialized
INFO - 2023-04-03 07:54:51 --> Router Class Initialized
INFO - 2023-04-03 07:54:51 --> Output Class Initialized
INFO - 2023-04-03 07:54:51 --> Security Class Initialized
DEBUG - 2023-04-03 07:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:51 --> Input Class Initialized
INFO - 2023-04-03 07:54:51 --> Language Class Initialized
INFO - 2023-04-03 07:54:51 --> Loader Class Initialized
INFO - 2023-04-03 07:54:51 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:51 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:54:51 --> Unable to connect to the database
INFO - 2023-04-03 07:54:51 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:54:55 --> Config Class Initialized
INFO - 2023-04-03 07:54:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:54:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:54:55 --> Utf8 Class Initialized
INFO - 2023-04-03 07:54:55 --> URI Class Initialized
INFO - 2023-04-03 07:54:55 --> Router Class Initialized
INFO - 2023-04-03 07:54:55 --> Output Class Initialized
INFO - 2023-04-03 07:54:55 --> Security Class Initialized
DEBUG - 2023-04-03 07:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:54:55 --> Input Class Initialized
INFO - 2023-04-03 07:54:55 --> Language Class Initialized
INFO - 2023-04-03 07:54:55 --> Loader Class Initialized
INFO - 2023-04-03 07:54:55 --> Controller Class Initialized
DEBUG - 2023-04-03 07:54:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:54:55 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:54:55 --> Unable to connect to the database
INFO - 2023-04-03 07:54:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:00 --> Config Class Initialized
INFO - 2023-04-03 07:55:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:00 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:00 --> URI Class Initialized
INFO - 2023-04-03 07:55:00 --> Router Class Initialized
INFO - 2023-04-03 07:55:00 --> Output Class Initialized
INFO - 2023-04-03 07:55:00 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:00 --> Input Class Initialized
INFO - 2023-04-03 07:55:00 --> Language Class Initialized
INFO - 2023-04-03 07:55:00 --> Loader Class Initialized
INFO - 2023-04-03 07:55:00 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:00 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:00 --> Unable to connect to the database
INFO - 2023-04-03 07:55:00 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:06 --> Config Class Initialized
INFO - 2023-04-03 07:55:06 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:06 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:06 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:06 --> URI Class Initialized
INFO - 2023-04-03 07:55:06 --> Router Class Initialized
INFO - 2023-04-03 07:55:06 --> Output Class Initialized
INFO - 2023-04-03 07:55:06 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:06 --> Input Class Initialized
INFO - 2023-04-03 07:55:06 --> Language Class Initialized
INFO - 2023-04-03 07:55:06 --> Loader Class Initialized
INFO - 2023-04-03 07:55:06 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:06 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:06 --> Unable to connect to the database
INFO - 2023-04-03 07:55:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:11 --> Config Class Initialized
INFO - 2023-04-03 07:55:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:11 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:11 --> URI Class Initialized
INFO - 2023-04-03 07:55:11 --> Router Class Initialized
INFO - 2023-04-03 07:55:11 --> Output Class Initialized
INFO - 2023-04-03 07:55:11 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:11 --> Input Class Initialized
INFO - 2023-04-03 07:55:11 --> Language Class Initialized
INFO - 2023-04-03 07:55:11 --> Loader Class Initialized
INFO - 2023-04-03 07:55:11 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:11 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:11 --> Unable to connect to the database
INFO - 2023-04-03 07:55:11 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:15 --> Config Class Initialized
INFO - 2023-04-03 07:55:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:15 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:15 --> URI Class Initialized
INFO - 2023-04-03 07:55:15 --> Router Class Initialized
INFO - 2023-04-03 07:55:15 --> Output Class Initialized
INFO - 2023-04-03 07:55:15 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:15 --> Input Class Initialized
INFO - 2023-04-03 07:55:15 --> Language Class Initialized
INFO - 2023-04-03 07:55:15 --> Loader Class Initialized
INFO - 2023-04-03 07:55:15 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:15 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:15 --> Unable to connect to the database
INFO - 2023-04-03 07:55:15 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:20 --> Config Class Initialized
INFO - 2023-04-03 07:55:20 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:20 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:20 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:20 --> URI Class Initialized
INFO - 2023-04-03 07:55:20 --> Router Class Initialized
INFO - 2023-04-03 07:55:20 --> Output Class Initialized
INFO - 2023-04-03 07:55:20 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:20 --> Input Class Initialized
INFO - 2023-04-03 07:55:20 --> Language Class Initialized
INFO - 2023-04-03 07:55:20 --> Loader Class Initialized
INFO - 2023-04-03 07:55:20 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:20 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:20 --> Unable to connect to the database
INFO - 2023-04-03 07:55:20 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:26 --> Config Class Initialized
INFO - 2023-04-03 07:55:26 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:26 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:26 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:26 --> URI Class Initialized
INFO - 2023-04-03 07:55:26 --> Router Class Initialized
INFO - 2023-04-03 07:55:26 --> Output Class Initialized
INFO - 2023-04-03 07:55:26 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:26 --> Input Class Initialized
INFO - 2023-04-03 07:55:26 --> Language Class Initialized
INFO - 2023-04-03 07:55:26 --> Loader Class Initialized
INFO - 2023-04-03 07:55:26 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:26 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:26 --> Unable to connect to the database
INFO - 2023-04-03 07:55:26 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:31 --> Config Class Initialized
INFO - 2023-04-03 07:55:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:31 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:31 --> URI Class Initialized
INFO - 2023-04-03 07:55:31 --> Router Class Initialized
INFO - 2023-04-03 07:55:31 --> Output Class Initialized
INFO - 2023-04-03 07:55:31 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:31 --> Input Class Initialized
INFO - 2023-04-03 07:55:31 --> Language Class Initialized
INFO - 2023-04-03 07:55:31 --> Loader Class Initialized
INFO - 2023-04-03 07:55:31 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:31 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:31 --> Unable to connect to the database
INFO - 2023-04-03 07:55:31 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:35 --> Config Class Initialized
INFO - 2023-04-03 07:55:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:35 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:35 --> URI Class Initialized
INFO - 2023-04-03 07:55:35 --> Router Class Initialized
INFO - 2023-04-03 07:55:35 --> Output Class Initialized
INFO - 2023-04-03 07:55:35 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:35 --> Input Class Initialized
INFO - 2023-04-03 07:55:35 --> Language Class Initialized
INFO - 2023-04-03 07:55:35 --> Loader Class Initialized
INFO - 2023-04-03 07:55:35 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:35 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:35 --> Unable to connect to the database
INFO - 2023-04-03 07:55:35 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:40 --> Config Class Initialized
INFO - 2023-04-03 07:55:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:40 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:40 --> URI Class Initialized
INFO - 2023-04-03 07:55:40 --> Router Class Initialized
INFO - 2023-04-03 07:55:40 --> Output Class Initialized
INFO - 2023-04-03 07:55:40 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:40 --> Input Class Initialized
INFO - 2023-04-03 07:55:40 --> Language Class Initialized
INFO - 2023-04-03 07:55:40 --> Loader Class Initialized
INFO - 2023-04-03 07:55:40 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:40 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:40 --> Unable to connect to the database
INFO - 2023-04-03 07:55:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:46 --> Config Class Initialized
INFO - 2023-04-03 07:55:46 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:46 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:46 --> URI Class Initialized
INFO - 2023-04-03 07:55:46 --> Router Class Initialized
INFO - 2023-04-03 07:55:46 --> Output Class Initialized
INFO - 2023-04-03 07:55:46 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:46 --> Input Class Initialized
INFO - 2023-04-03 07:55:46 --> Language Class Initialized
INFO - 2023-04-03 07:55:46 --> Loader Class Initialized
INFO - 2023-04-03 07:55:46 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:46 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:46 --> Unable to connect to the database
INFO - 2023-04-03 07:55:46 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:51 --> Config Class Initialized
INFO - 2023-04-03 07:55:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:51 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:51 --> URI Class Initialized
INFO - 2023-04-03 07:55:51 --> Router Class Initialized
INFO - 2023-04-03 07:55:51 --> Output Class Initialized
INFO - 2023-04-03 07:55:51 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:51 --> Input Class Initialized
INFO - 2023-04-03 07:55:51 --> Language Class Initialized
INFO - 2023-04-03 07:55:51 --> Loader Class Initialized
INFO - 2023-04-03 07:55:51 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:51 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:51 --> Unable to connect to the database
INFO - 2023-04-03 07:55:51 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:55:55 --> Config Class Initialized
INFO - 2023-04-03 07:55:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:55:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:55:55 --> Utf8 Class Initialized
INFO - 2023-04-03 07:55:55 --> URI Class Initialized
INFO - 2023-04-03 07:55:55 --> Router Class Initialized
INFO - 2023-04-03 07:55:55 --> Output Class Initialized
INFO - 2023-04-03 07:55:55 --> Security Class Initialized
DEBUG - 2023-04-03 07:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:55:55 --> Input Class Initialized
INFO - 2023-04-03 07:55:55 --> Language Class Initialized
INFO - 2023-04-03 07:55:55 --> Loader Class Initialized
INFO - 2023-04-03 07:55:55 --> Controller Class Initialized
DEBUG - 2023-04-03 07:55:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:55:55 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:55:55 --> Unable to connect to the database
INFO - 2023-04-03 07:55:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:00 --> Config Class Initialized
INFO - 2023-04-03 07:56:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:00 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:00 --> URI Class Initialized
INFO - 2023-04-03 07:56:00 --> Router Class Initialized
INFO - 2023-04-03 07:56:00 --> Output Class Initialized
INFO - 2023-04-03 07:56:00 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:00 --> Input Class Initialized
INFO - 2023-04-03 07:56:00 --> Language Class Initialized
INFO - 2023-04-03 07:56:00 --> Loader Class Initialized
INFO - 2023-04-03 07:56:00 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:00 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:00 --> Unable to connect to the database
INFO - 2023-04-03 07:56:00 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:06 --> Config Class Initialized
INFO - 2023-04-03 07:56:06 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:06 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:06 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:06 --> URI Class Initialized
INFO - 2023-04-03 07:56:06 --> Router Class Initialized
INFO - 2023-04-03 07:56:06 --> Output Class Initialized
INFO - 2023-04-03 07:56:06 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:06 --> Input Class Initialized
INFO - 2023-04-03 07:56:06 --> Language Class Initialized
INFO - 2023-04-03 07:56:06 --> Loader Class Initialized
INFO - 2023-04-03 07:56:06 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:06 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:06 --> Unable to connect to the database
INFO - 2023-04-03 07:56:06 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:11 --> Config Class Initialized
INFO - 2023-04-03 07:56:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:11 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:11 --> URI Class Initialized
INFO - 2023-04-03 07:56:11 --> Router Class Initialized
INFO - 2023-04-03 07:56:11 --> Output Class Initialized
INFO - 2023-04-03 07:56:11 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:11 --> Input Class Initialized
INFO - 2023-04-03 07:56:11 --> Language Class Initialized
INFO - 2023-04-03 07:56:11 --> Loader Class Initialized
INFO - 2023-04-03 07:56:11 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:11 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:11 --> Unable to connect to the database
INFO - 2023-04-03 07:56:11 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:15 --> Config Class Initialized
INFO - 2023-04-03 07:56:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:15 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:15 --> URI Class Initialized
INFO - 2023-04-03 07:56:15 --> Router Class Initialized
INFO - 2023-04-03 07:56:15 --> Output Class Initialized
INFO - 2023-04-03 07:56:15 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:15 --> Input Class Initialized
INFO - 2023-04-03 07:56:15 --> Language Class Initialized
INFO - 2023-04-03 07:56:15 --> Loader Class Initialized
INFO - 2023-04-03 07:56:15 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:15 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:15 --> Unable to connect to the database
INFO - 2023-04-03 07:56:15 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:20 --> Config Class Initialized
INFO - 2023-04-03 07:56:20 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:20 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:20 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:20 --> URI Class Initialized
INFO - 2023-04-03 07:56:20 --> Router Class Initialized
INFO - 2023-04-03 07:56:20 --> Output Class Initialized
INFO - 2023-04-03 07:56:20 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:20 --> Input Class Initialized
INFO - 2023-04-03 07:56:20 --> Language Class Initialized
INFO - 2023-04-03 07:56:20 --> Loader Class Initialized
INFO - 2023-04-03 07:56:20 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:20 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:20 --> Unable to connect to the database
INFO - 2023-04-03 07:56:20 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:26 --> Config Class Initialized
INFO - 2023-04-03 07:56:26 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:26 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:26 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:26 --> URI Class Initialized
INFO - 2023-04-03 07:56:26 --> Router Class Initialized
INFO - 2023-04-03 07:56:26 --> Output Class Initialized
INFO - 2023-04-03 07:56:26 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:26 --> Input Class Initialized
INFO - 2023-04-03 07:56:26 --> Language Class Initialized
INFO - 2023-04-03 07:56:26 --> Loader Class Initialized
INFO - 2023-04-03 07:56:26 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:26 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:26 --> Unable to connect to the database
INFO - 2023-04-03 07:56:26 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:31 --> Config Class Initialized
INFO - 2023-04-03 07:56:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:31 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:31 --> URI Class Initialized
INFO - 2023-04-03 07:56:31 --> Router Class Initialized
INFO - 2023-04-03 07:56:31 --> Output Class Initialized
INFO - 2023-04-03 07:56:31 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:31 --> Input Class Initialized
INFO - 2023-04-03 07:56:31 --> Language Class Initialized
INFO - 2023-04-03 07:56:31 --> Loader Class Initialized
INFO - 2023-04-03 07:56:31 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:31 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:31 --> Unable to connect to the database
INFO - 2023-04-03 07:56:31 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:35 --> Config Class Initialized
INFO - 2023-04-03 07:56:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:35 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:35 --> URI Class Initialized
INFO - 2023-04-03 07:56:35 --> Router Class Initialized
INFO - 2023-04-03 07:56:35 --> Output Class Initialized
INFO - 2023-04-03 07:56:35 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:35 --> Input Class Initialized
INFO - 2023-04-03 07:56:35 --> Language Class Initialized
INFO - 2023-04-03 07:56:35 --> Loader Class Initialized
INFO - 2023-04-03 07:56:35 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:35 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:35 --> Unable to connect to the database
INFO - 2023-04-03 07:56:35 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:40 --> Config Class Initialized
INFO - 2023-04-03 07:56:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:40 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:40 --> URI Class Initialized
INFO - 2023-04-03 07:56:40 --> Router Class Initialized
INFO - 2023-04-03 07:56:40 --> Output Class Initialized
INFO - 2023-04-03 07:56:40 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:40 --> Input Class Initialized
INFO - 2023-04-03 07:56:40 --> Language Class Initialized
INFO - 2023-04-03 07:56:40 --> Loader Class Initialized
INFO - 2023-04-03 07:56:40 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:40 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:40 --> Unable to connect to the database
INFO - 2023-04-03 07:56:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:45 --> Config Class Initialized
INFO - 2023-04-03 07:56:45 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:45 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:45 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:45 --> URI Class Initialized
INFO - 2023-04-03 07:56:45 --> Router Class Initialized
INFO - 2023-04-03 07:56:45 --> Output Class Initialized
INFO - 2023-04-03 07:56:45 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:45 --> Input Class Initialized
INFO - 2023-04-03 07:56:45 --> Language Class Initialized
INFO - 2023-04-03 07:56:45 --> Loader Class Initialized
INFO - 2023-04-03 07:56:45 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:45 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:45 --> Unable to connect to the database
INFO - 2023-04-03 07:56:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:50 --> Config Class Initialized
INFO - 2023-04-03 07:56:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:50 --> URI Class Initialized
INFO - 2023-04-03 07:56:50 --> Router Class Initialized
INFO - 2023-04-03 07:56:50 --> Output Class Initialized
INFO - 2023-04-03 07:56:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:50 --> Input Class Initialized
INFO - 2023-04-03 07:56:50 --> Language Class Initialized
INFO - 2023-04-03 07:56:50 --> Loader Class Initialized
INFO - 2023-04-03 07:56:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:50 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:50 --> Unable to connect to the database
INFO - 2023-04-03 07:56:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:56:55 --> Config Class Initialized
INFO - 2023-04-03 07:56:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:56:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:56:55 --> Utf8 Class Initialized
INFO - 2023-04-03 07:56:55 --> URI Class Initialized
INFO - 2023-04-03 07:56:55 --> Router Class Initialized
INFO - 2023-04-03 07:56:55 --> Output Class Initialized
INFO - 2023-04-03 07:56:55 --> Security Class Initialized
DEBUG - 2023-04-03 07:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:56:55 --> Input Class Initialized
INFO - 2023-04-03 07:56:55 --> Language Class Initialized
INFO - 2023-04-03 07:56:55 --> Loader Class Initialized
INFO - 2023-04-03 07:56:55 --> Controller Class Initialized
DEBUG - 2023-04-03 07:56:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:56:55 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:56:55 --> Unable to connect to the database
INFO - 2023-04-03 07:56:55 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:01 --> Config Class Initialized
INFO - 2023-04-03 07:57:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:01 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:01 --> URI Class Initialized
INFO - 2023-04-03 07:57:01 --> Router Class Initialized
INFO - 2023-04-03 07:57:01 --> Output Class Initialized
INFO - 2023-04-03 07:57:01 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:01 --> Input Class Initialized
INFO - 2023-04-03 07:57:01 --> Language Class Initialized
INFO - 2023-04-03 07:57:01 --> Loader Class Initialized
INFO - 2023-04-03 07:57:01 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:01 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:01 --> Unable to connect to the database
INFO - 2023-04-03 07:57:01 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:05 --> Config Class Initialized
INFO - 2023-04-03 07:57:05 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:05 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:05 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:05 --> URI Class Initialized
INFO - 2023-04-03 07:57:05 --> Router Class Initialized
INFO - 2023-04-03 07:57:05 --> Output Class Initialized
INFO - 2023-04-03 07:57:05 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:05 --> Input Class Initialized
INFO - 2023-04-03 07:57:05 --> Language Class Initialized
INFO - 2023-04-03 07:57:05 --> Loader Class Initialized
INFO - 2023-04-03 07:57:05 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:05 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:05 --> Unable to connect to the database
INFO - 2023-04-03 07:57:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:10 --> Config Class Initialized
INFO - 2023-04-03 07:57:10 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:10 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:10 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:10 --> URI Class Initialized
INFO - 2023-04-03 07:57:10 --> Router Class Initialized
INFO - 2023-04-03 07:57:10 --> Output Class Initialized
INFO - 2023-04-03 07:57:10 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:10 --> Input Class Initialized
INFO - 2023-04-03 07:57:10 --> Language Class Initialized
INFO - 2023-04-03 07:57:10 --> Loader Class Initialized
INFO - 2023-04-03 07:57:10 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:10 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:10 --> Unable to connect to the database
INFO - 2023-04-03 07:57:10 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:16 --> Config Class Initialized
INFO - 2023-04-03 07:57:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:16 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:16 --> URI Class Initialized
INFO - 2023-04-03 07:57:16 --> Router Class Initialized
INFO - 2023-04-03 07:57:16 --> Output Class Initialized
INFO - 2023-04-03 07:57:16 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:16 --> Input Class Initialized
INFO - 2023-04-03 07:57:16 --> Language Class Initialized
INFO - 2023-04-03 07:57:16 --> Loader Class Initialized
INFO - 2023-04-03 07:57:16 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:16 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:16 --> Unable to connect to the database
INFO - 2023-04-03 07:57:16 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:21 --> Config Class Initialized
INFO - 2023-04-03 07:57:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:21 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:21 --> URI Class Initialized
INFO - 2023-04-03 07:57:21 --> Router Class Initialized
INFO - 2023-04-03 07:57:21 --> Output Class Initialized
INFO - 2023-04-03 07:57:21 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:21 --> Input Class Initialized
INFO - 2023-04-03 07:57:21 --> Language Class Initialized
INFO - 2023-04-03 07:57:21 --> Loader Class Initialized
INFO - 2023-04-03 07:57:21 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:21 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:21 --> Unable to connect to the database
INFO - 2023-04-03 07:57:21 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:25 --> Config Class Initialized
INFO - 2023-04-03 07:57:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:25 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:25 --> URI Class Initialized
INFO - 2023-04-03 07:57:25 --> Router Class Initialized
INFO - 2023-04-03 07:57:25 --> Output Class Initialized
INFO - 2023-04-03 07:57:25 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:25 --> Input Class Initialized
INFO - 2023-04-03 07:57:25 --> Language Class Initialized
INFO - 2023-04-03 07:57:25 --> Loader Class Initialized
INFO - 2023-04-03 07:57:25 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:25 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:25 --> Unable to connect to the database
INFO - 2023-04-03 07:57:25 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:30 --> Config Class Initialized
INFO - 2023-04-03 07:57:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:30 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:30 --> URI Class Initialized
INFO - 2023-04-03 07:57:30 --> Router Class Initialized
INFO - 2023-04-03 07:57:30 --> Output Class Initialized
INFO - 2023-04-03 07:57:30 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:30 --> Input Class Initialized
INFO - 2023-04-03 07:57:30 --> Language Class Initialized
INFO - 2023-04-03 07:57:30 --> Loader Class Initialized
INFO - 2023-04-03 07:57:30 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:30 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:30 --> Unable to connect to the database
INFO - 2023-04-03 07:57:30 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:36 --> Config Class Initialized
INFO - 2023-04-03 07:57:36 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:36 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:36 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:36 --> URI Class Initialized
INFO - 2023-04-03 07:57:36 --> Router Class Initialized
INFO - 2023-04-03 07:57:36 --> Output Class Initialized
INFO - 2023-04-03 07:57:36 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:36 --> Input Class Initialized
INFO - 2023-04-03 07:57:36 --> Language Class Initialized
INFO - 2023-04-03 07:57:36 --> Loader Class Initialized
INFO - 2023-04-03 07:57:36 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:36 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:36 --> Unable to connect to the database
INFO - 2023-04-03 07:57:36 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:41 --> Config Class Initialized
INFO - 2023-04-03 07:57:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:41 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:41 --> URI Class Initialized
INFO - 2023-04-03 07:57:41 --> Router Class Initialized
INFO - 2023-04-03 07:57:41 --> Output Class Initialized
INFO - 2023-04-03 07:57:41 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:41 --> Input Class Initialized
INFO - 2023-04-03 07:57:41 --> Language Class Initialized
INFO - 2023-04-03 07:57:41 --> Loader Class Initialized
INFO - 2023-04-03 07:57:41 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:41 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:41 --> Unable to connect to the database
INFO - 2023-04-03 07:57:41 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:45 --> Config Class Initialized
INFO - 2023-04-03 07:57:45 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:45 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:45 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:45 --> URI Class Initialized
INFO - 2023-04-03 07:57:45 --> Router Class Initialized
INFO - 2023-04-03 07:57:45 --> Output Class Initialized
INFO - 2023-04-03 07:57:45 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:45 --> Input Class Initialized
INFO - 2023-04-03 07:57:45 --> Language Class Initialized
INFO - 2023-04-03 07:57:45 --> Loader Class Initialized
INFO - 2023-04-03 07:57:45 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:45 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:45 --> Unable to connect to the database
INFO - 2023-04-03 07:57:45 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:50 --> Config Class Initialized
INFO - 2023-04-03 07:57:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:50 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:50 --> URI Class Initialized
INFO - 2023-04-03 07:57:50 --> Router Class Initialized
INFO - 2023-04-03 07:57:50 --> Output Class Initialized
INFO - 2023-04-03 07:57:50 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:50 --> Input Class Initialized
INFO - 2023-04-03 07:57:50 --> Language Class Initialized
INFO - 2023-04-03 07:57:50 --> Loader Class Initialized
INFO - 2023-04-03 07:57:50 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:50 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:50 --> Unable to connect to the database
INFO - 2023-04-03 07:57:50 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:57:56 --> Config Class Initialized
INFO - 2023-04-03 07:57:56 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:57:56 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:57:56 --> Utf8 Class Initialized
INFO - 2023-04-03 07:57:56 --> URI Class Initialized
INFO - 2023-04-03 07:57:56 --> Router Class Initialized
INFO - 2023-04-03 07:57:56 --> Output Class Initialized
INFO - 2023-04-03 07:57:56 --> Security Class Initialized
DEBUG - 2023-04-03 07:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:57:56 --> Input Class Initialized
INFO - 2023-04-03 07:57:56 --> Language Class Initialized
INFO - 2023-04-03 07:57:56 --> Loader Class Initialized
INFO - 2023-04-03 07:57:56 --> Controller Class Initialized
DEBUG - 2023-04-03 07:57:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:57:56 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:57:56 --> Unable to connect to the database
INFO - 2023-04-03 07:57:56 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:58:01 --> Config Class Initialized
INFO - 2023-04-03 07:58:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:58:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:58:01 --> Utf8 Class Initialized
INFO - 2023-04-03 07:58:01 --> URI Class Initialized
INFO - 2023-04-03 07:58:01 --> Router Class Initialized
INFO - 2023-04-03 07:58:01 --> Output Class Initialized
INFO - 2023-04-03 07:58:01 --> Security Class Initialized
DEBUG - 2023-04-03 07:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:58:01 --> Input Class Initialized
INFO - 2023-04-03 07:58:01 --> Language Class Initialized
INFO - 2023-04-03 07:58:01 --> Loader Class Initialized
INFO - 2023-04-03 07:58:01 --> Controller Class Initialized
DEBUG - 2023-04-03 07:58:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:58:01 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:58:01 --> Unable to connect to the database
INFO - 2023-04-03 07:58:01 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:58:05 --> Config Class Initialized
INFO - 2023-04-03 07:58:05 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:58:05 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:58:05 --> Utf8 Class Initialized
INFO - 2023-04-03 07:58:05 --> URI Class Initialized
INFO - 2023-04-03 07:58:05 --> Router Class Initialized
INFO - 2023-04-03 07:58:05 --> Output Class Initialized
INFO - 2023-04-03 07:58:05 --> Security Class Initialized
DEBUG - 2023-04-03 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:58:05 --> Input Class Initialized
INFO - 2023-04-03 07:58:05 --> Language Class Initialized
INFO - 2023-04-03 07:58:05 --> Loader Class Initialized
INFO - 2023-04-03 07:58:05 --> Controller Class Initialized
DEBUG - 2023-04-03 07:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:58:05 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:58:05 --> Unable to connect to the database
INFO - 2023-04-03 07:58:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:58:10 --> Config Class Initialized
INFO - 2023-04-03 07:58:10 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:58:10 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:58:10 --> Utf8 Class Initialized
INFO - 2023-04-03 07:58:10 --> URI Class Initialized
INFO - 2023-04-03 07:58:10 --> Router Class Initialized
INFO - 2023-04-03 07:58:10 --> Output Class Initialized
INFO - 2023-04-03 07:58:10 --> Security Class Initialized
DEBUG - 2023-04-03 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:58:10 --> Input Class Initialized
INFO - 2023-04-03 07:58:10 --> Language Class Initialized
INFO - 2023-04-03 07:58:10 --> Loader Class Initialized
INFO - 2023-04-03 07:58:10 --> Controller Class Initialized
DEBUG - 2023-04-03 07:58:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:58:10 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:58:10 --> Unable to connect to the database
INFO - 2023-04-03 07:58:10 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 07:59:05 --> Config Class Initialized
INFO - 2023-04-03 07:59:05 --> Hooks Class Initialized
DEBUG - 2023-04-03 07:59:05 --> UTF-8 Support Enabled
INFO - 2023-04-03 07:59:05 --> Utf8 Class Initialized
INFO - 2023-04-03 07:59:05 --> URI Class Initialized
INFO - 2023-04-03 07:59:05 --> Router Class Initialized
INFO - 2023-04-03 07:59:05 --> Output Class Initialized
INFO - 2023-04-03 07:59:05 --> Security Class Initialized
DEBUG - 2023-04-03 07:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 07:59:05 --> Input Class Initialized
INFO - 2023-04-03 07:59:05 --> Language Class Initialized
INFO - 2023-04-03 07:59:05 --> Loader Class Initialized
INFO - 2023-04-03 07:59:05 --> Controller Class Initialized
DEBUG - 2023-04-03 07:59:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 07:59:05 --> Database Driver Class Initialized
ERROR - 2023-04-03 07:59:05 --> Unable to connect to the database
INFO - 2023-04-03 07:59:05 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:00:07 --> Config Class Initialized
INFO - 2023-04-03 08:00:07 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:00:07 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:00:07 --> Utf8 Class Initialized
INFO - 2023-04-03 08:00:07 --> URI Class Initialized
INFO - 2023-04-03 08:00:07 --> Router Class Initialized
INFO - 2023-04-03 08:00:07 --> Output Class Initialized
INFO - 2023-04-03 08:00:07 --> Security Class Initialized
DEBUG - 2023-04-03 08:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:00:07 --> Input Class Initialized
INFO - 2023-04-03 08:00:07 --> Language Class Initialized
INFO - 2023-04-03 08:00:07 --> Loader Class Initialized
INFO - 2023-04-03 08:00:07 --> Controller Class Initialized
DEBUG - 2023-04-03 08:00:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:00:07 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:00:07 --> Unable to connect to the database
INFO - 2023-04-03 08:00:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:01:07 --> Config Class Initialized
INFO - 2023-04-03 08:01:07 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:01:07 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:01:07 --> Utf8 Class Initialized
INFO - 2023-04-03 08:01:07 --> URI Class Initialized
INFO - 2023-04-03 08:01:07 --> Router Class Initialized
INFO - 2023-04-03 08:01:07 --> Output Class Initialized
INFO - 2023-04-03 08:01:07 --> Security Class Initialized
DEBUG - 2023-04-03 08:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:01:07 --> Input Class Initialized
INFO - 2023-04-03 08:01:07 --> Language Class Initialized
INFO - 2023-04-03 08:01:07 --> Loader Class Initialized
INFO - 2023-04-03 08:01:07 --> Controller Class Initialized
DEBUG - 2023-04-03 08:01:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:01:07 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:01:07 --> Unable to connect to the database
INFO - 2023-04-03 08:01:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:01:52 --> Config Class Initialized
INFO - 2023-04-03 08:01:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:01:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:01:52 --> Utf8 Class Initialized
INFO - 2023-04-03 08:01:52 --> URI Class Initialized
INFO - 2023-04-03 08:01:52 --> Router Class Initialized
INFO - 2023-04-03 08:01:52 --> Output Class Initialized
INFO - 2023-04-03 08:01:52 --> Security Class Initialized
DEBUG - 2023-04-03 08:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:01:52 --> Input Class Initialized
INFO - 2023-04-03 08:01:52 --> Language Class Initialized
INFO - 2023-04-03 08:01:52 --> Loader Class Initialized
INFO - 2023-04-03 08:01:52 --> Controller Class Initialized
DEBUG - 2023-04-03 08:01:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:01:52 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:01:52 --> Unable to connect to the database
INFO - 2023-04-03 08:01:52 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:01:52 --> Config Class Initialized
INFO - 2023-04-03 08:01:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:01:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:01:52 --> Utf8 Class Initialized
INFO - 2023-04-03 08:01:52 --> URI Class Initialized
INFO - 2023-04-03 08:01:52 --> Router Class Initialized
INFO - 2023-04-03 08:01:52 --> Output Class Initialized
INFO - 2023-04-03 08:01:52 --> Security Class Initialized
DEBUG - 2023-04-03 08:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:01:52 --> Input Class Initialized
INFO - 2023-04-03 08:01:52 --> Language Class Initialized
INFO - 2023-04-03 08:01:52 --> Loader Class Initialized
INFO - 2023-04-03 08:01:52 --> Controller Class Initialized
DEBUG - 2023-04-03 08:01:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:01:52 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:01:52 --> Unable to connect to the database
INFO - 2023-04-03 08:01:52 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:01:53 --> Config Class Initialized
INFO - 2023-04-03 08:01:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:01:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:01:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:01:53 --> URI Class Initialized
INFO - 2023-04-03 08:01:53 --> Router Class Initialized
INFO - 2023-04-03 08:01:53 --> Output Class Initialized
INFO - 2023-04-03 08:01:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:01:53 --> Input Class Initialized
INFO - 2023-04-03 08:01:53 --> Language Class Initialized
INFO - 2023-04-03 08:01:53 --> Loader Class Initialized
INFO - 2023-04-03 08:01:53 --> Controller Class Initialized
DEBUG - 2023-04-03 08:01:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:01:53 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:01:53 --> Unable to connect to the database
INFO - 2023-04-03 08:01:53 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:01:57 --> Config Class Initialized
INFO - 2023-04-03 08:01:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:01:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:01:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:01:57 --> URI Class Initialized
INFO - 2023-04-03 08:01:57 --> Router Class Initialized
INFO - 2023-04-03 08:01:57 --> Output Class Initialized
INFO - 2023-04-03 08:01:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:01:57 --> Input Class Initialized
INFO - 2023-04-03 08:01:57 --> Language Class Initialized
INFO - 2023-04-03 08:01:57 --> Loader Class Initialized
INFO - 2023-04-03 08:01:57 --> Controller Class Initialized
DEBUG - 2023-04-03 08:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:01:57 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:01:57 --> Unable to connect to the database
INFO - 2023-04-03 08:01:57 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:02:01 --> Config Class Initialized
INFO - 2023-04-03 08:02:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:01 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:01 --> URI Class Initialized
INFO - 2023-04-03 08:02:01 --> Router Class Initialized
INFO - 2023-04-03 08:02:01 --> Output Class Initialized
INFO - 2023-04-03 08:02:01 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:01 --> Input Class Initialized
INFO - 2023-04-03 08:02:01 --> Language Class Initialized
INFO - 2023-04-03 08:02:01 --> Loader Class Initialized
INFO - 2023-04-03 08:02:01 --> Controller Class Initialized
DEBUG - 2023-04-03 08:02:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:01 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:02:01 --> Unable to connect to the database
INFO - 2023-04-03 08:02:01 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:02:13 --> Config Class Initialized
INFO - 2023-04-03 08:02:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:13 --> URI Class Initialized
INFO - 2023-04-03 08:02:13 --> Router Class Initialized
INFO - 2023-04-03 08:02:13 --> Output Class Initialized
INFO - 2023-04-03 08:02:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:13 --> Input Class Initialized
INFO - 2023-04-03 08:02:13 --> Language Class Initialized
INFO - 2023-04-03 08:02:13 --> Loader Class Initialized
INFO - 2023-04-03 08:02:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:02:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:13 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:02:13 --> Unable to connect to the database
INFO - 2023-04-03 08:02:13 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 08:02:17 --> Config Class Initialized
INFO - 2023-04-03 08:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:17 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:17 --> URI Class Initialized
INFO - 2023-04-03 08:02:17 --> Router Class Initialized
INFO - 2023-04-03 08:02:17 --> Output Class Initialized
INFO - 2023-04-03 08:02:17 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:17 --> Input Class Initialized
INFO - 2023-04-03 08:02:17 --> Language Class Initialized
INFO - 2023-04-03 08:02:17 --> Loader Class Initialized
INFO - 2023-04-03 08:02:17 --> Controller Class Initialized
INFO - 2023-04-03 08:02:17 --> Helper loaded: form_helper
INFO - 2023-04-03 08:02:17 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:17 --> Model "Change_model" initialized
INFO - 2023-04-03 08:02:17 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:02:17 --> Final output sent to browser
DEBUG - 2023-04-03 08:02:17 --> Total execution time: 0.1008
INFO - 2023-04-03 08:02:17 --> Config Class Initialized
INFO - 2023-04-03 08:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:17 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:17 --> URI Class Initialized
INFO - 2023-04-03 08:02:17 --> Router Class Initialized
INFO - 2023-04-03 08:02:17 --> Output Class Initialized
INFO - 2023-04-03 08:02:17 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:17 --> Input Class Initialized
INFO - 2023-04-03 08:02:17 --> Language Class Initialized
INFO - 2023-04-03 08:02:17 --> Loader Class Initialized
INFO - 2023-04-03 08:02:17 --> Controller Class Initialized
INFO - 2023-04-03 08:02:17 --> Helper loaded: form_helper
INFO - 2023-04-03 08:02:17 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:17 --> Final output sent to browser
DEBUG - 2023-04-03 08:02:17 --> Total execution time: 0.0257
INFO - 2023-04-03 08:02:17 --> Config Class Initialized
INFO - 2023-04-03 08:02:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:17 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:17 --> URI Class Initialized
INFO - 2023-04-03 08:02:17 --> Router Class Initialized
INFO - 2023-04-03 08:02:17 --> Output Class Initialized
INFO - 2023-04-03 08:02:17 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:17 --> Input Class Initialized
INFO - 2023-04-03 08:02:17 --> Language Class Initialized
INFO - 2023-04-03 08:02:17 --> Loader Class Initialized
INFO - 2023-04-03 08:02:17 --> Controller Class Initialized
INFO - 2023-04-03 08:02:17 --> Helper loaded: form_helper
INFO - 2023-04-03 08:02:17 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:02:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:17 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:02:17 --> Unable to connect to the database
INFO - 2023-04-03 08:02:17 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:02:17 --> Unable to connect to the database
ERROR - 2023-04-03 08:02:17 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:02:17 --> Final output sent to browser
DEBUG - 2023-04-03 08:02:17 --> Total execution time: 0.0925
INFO - 2023-04-03 08:02:22 --> Config Class Initialized
INFO - 2023-04-03 08:02:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:22 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:22 --> URI Class Initialized
INFO - 2023-04-03 08:02:22 --> Router Class Initialized
INFO - 2023-04-03 08:02:22 --> Output Class Initialized
INFO - 2023-04-03 08:02:22 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:22 --> Input Class Initialized
INFO - 2023-04-03 08:02:22 --> Language Class Initialized
INFO - 2023-04-03 08:02:22 --> Loader Class Initialized
INFO - 2023-04-03 08:02:22 --> Controller Class Initialized
INFO - 2023-04-03 08:02:22 --> Helper loaded: form_helper
INFO - 2023-04-03 08:02:22 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:02:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:22 --> Model "Change_model" initialized
INFO - 2023-04-03 08:02:22 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:02:22 --> Final output sent to browser
DEBUG - 2023-04-03 08:02:22 --> Total execution time: 0.0452
INFO - 2023-04-03 08:02:22 --> Config Class Initialized
INFO - 2023-04-03 08:02:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:22 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:22 --> URI Class Initialized
INFO - 2023-04-03 08:02:22 --> Router Class Initialized
INFO - 2023-04-03 08:02:22 --> Output Class Initialized
INFO - 2023-04-03 08:02:22 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:22 --> Input Class Initialized
INFO - 2023-04-03 08:02:22 --> Language Class Initialized
INFO - 2023-04-03 08:02:22 --> Loader Class Initialized
INFO - 2023-04-03 08:02:22 --> Controller Class Initialized
INFO - 2023-04-03 08:02:22 --> Helper loaded: form_helper
INFO - 2023-04-03 08:02:22 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:02:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:22 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:02:22 --> Unable to connect to the database
INFO - 2023-04-03 08:02:22 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:02:22 --> Unable to connect to the database
ERROR - 2023-04-03 08:02:22 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:02:22 --> Final output sent to browser
DEBUG - 2023-04-03 08:02:22 --> Total execution time: 0.0136
INFO - 2023-04-03 08:02:51 --> Config Class Initialized
INFO - 2023-04-03 08:02:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:51 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:51 --> URI Class Initialized
INFO - 2023-04-03 08:02:51 --> Router Class Initialized
INFO - 2023-04-03 08:02:51 --> Output Class Initialized
INFO - 2023-04-03 08:02:51 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:51 --> Input Class Initialized
INFO - 2023-04-03 08:02:51 --> Language Class Initialized
INFO - 2023-04-03 08:02:51 --> Loader Class Initialized
INFO - 2023-04-03 08:02:51 --> Controller Class Initialized
INFO - 2023-04-03 08:02:51 --> Helper loaded: form_helper
INFO - 2023-04-03 08:02:51 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:02:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:51 --> Model "Change_model" initialized
INFO - 2023-04-03 08:02:51 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:02:51 --> Final output sent to browser
DEBUG - 2023-04-03 08:02:51 --> Total execution time: 0.0634
INFO - 2023-04-03 08:02:51 --> Config Class Initialized
INFO - 2023-04-03 08:02:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:51 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:51 --> URI Class Initialized
INFO - 2023-04-03 08:02:51 --> Router Class Initialized
INFO - 2023-04-03 08:02:51 --> Output Class Initialized
INFO - 2023-04-03 08:02:51 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:51 --> Input Class Initialized
INFO - 2023-04-03 08:02:51 --> Language Class Initialized
INFO - 2023-04-03 08:02:51 --> Loader Class Initialized
INFO - 2023-04-03 08:02:51 --> Controller Class Initialized
INFO - 2023-04-03 08:02:51 --> Helper loaded: form_helper
INFO - 2023-04-03 08:02:51 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:02:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:51 --> Final output sent to browser
DEBUG - 2023-04-03 08:02:51 --> Total execution time: 0.0430
INFO - 2023-04-03 08:02:51 --> Config Class Initialized
INFO - 2023-04-03 08:02:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:02:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:02:51 --> Utf8 Class Initialized
INFO - 2023-04-03 08:02:51 --> URI Class Initialized
INFO - 2023-04-03 08:02:51 --> Router Class Initialized
INFO - 2023-04-03 08:02:51 --> Output Class Initialized
INFO - 2023-04-03 08:02:51 --> Security Class Initialized
DEBUG - 2023-04-03 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:02:51 --> Input Class Initialized
INFO - 2023-04-03 08:02:51 --> Language Class Initialized
INFO - 2023-04-03 08:02:51 --> Loader Class Initialized
INFO - 2023-04-03 08:02:51 --> Controller Class Initialized
INFO - 2023-04-03 08:02:51 --> Helper loaded: form_helper
INFO - 2023-04-03 08:02:51 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:02:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:02:51 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:02:51 --> Unable to connect to the database
INFO - 2023-04-03 08:02:51 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:02:51 --> Unable to connect to the database
ERROR - 2023-04-03 08:02:51 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:02:51 --> Final output sent to browser
DEBUG - 2023-04-03 08:02:51 --> Total execution time: 0.0081
INFO - 2023-04-03 08:03:53 --> Config Class Initialized
INFO - 2023-04-03 08:03:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:03:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:03:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:03:53 --> URI Class Initialized
INFO - 2023-04-03 08:03:53 --> Router Class Initialized
INFO - 2023-04-03 08:03:53 --> Output Class Initialized
INFO - 2023-04-03 08:03:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:03:53 --> Input Class Initialized
INFO - 2023-04-03 08:03:53 --> Language Class Initialized
INFO - 2023-04-03 08:03:53 --> Loader Class Initialized
INFO - 2023-04-03 08:03:53 --> Controller Class Initialized
INFO - 2023-04-03 08:03:53 --> Helper loaded: form_helper
INFO - 2023-04-03 08:03:53 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:03:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:03:53 --> Model "Change_model" initialized
INFO - 2023-04-03 08:03:53 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:03:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:03:53 --> Total execution time: 0.0430
INFO - 2023-04-03 08:03:53 --> Config Class Initialized
INFO - 2023-04-03 08:03:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:03:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:03:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:03:53 --> URI Class Initialized
INFO - 2023-04-03 08:03:53 --> Router Class Initialized
INFO - 2023-04-03 08:03:53 --> Output Class Initialized
INFO - 2023-04-03 08:03:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:03:53 --> Input Class Initialized
INFO - 2023-04-03 08:03:53 --> Language Class Initialized
INFO - 2023-04-03 08:03:53 --> Loader Class Initialized
INFO - 2023-04-03 08:03:53 --> Controller Class Initialized
INFO - 2023-04-03 08:03:53 --> Helper loaded: form_helper
INFO - 2023-04-03 08:03:53 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:03:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:03:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:03:53 --> Total execution time: 0.0040
INFO - 2023-04-03 08:03:53 --> Config Class Initialized
INFO - 2023-04-03 08:03:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:03:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:03:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:03:53 --> URI Class Initialized
INFO - 2023-04-03 08:03:53 --> Router Class Initialized
INFO - 2023-04-03 08:03:53 --> Output Class Initialized
INFO - 2023-04-03 08:03:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:03:53 --> Input Class Initialized
INFO - 2023-04-03 08:03:53 --> Language Class Initialized
INFO - 2023-04-03 08:03:53 --> Loader Class Initialized
INFO - 2023-04-03 08:03:53 --> Controller Class Initialized
INFO - 2023-04-03 08:03:53 --> Helper loaded: form_helper
INFO - 2023-04-03 08:03:53 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:03:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:03:53 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:03:53 --> Unable to connect to the database
INFO - 2023-04-03 08:03:53 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:03:53 --> Unable to connect to the database
ERROR - 2023-04-03 08:03:53 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:03:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:03:53 --> Total execution time: 0.0062
INFO - 2023-04-03 08:04:13 --> Config Class Initialized
INFO - 2023-04-03 08:04:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:04:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:04:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:04:13 --> URI Class Initialized
INFO - 2023-04-03 08:04:13 --> Router Class Initialized
INFO - 2023-04-03 08:04:13 --> Output Class Initialized
INFO - 2023-04-03 08:04:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:04:13 --> Input Class Initialized
INFO - 2023-04-03 08:04:13 --> Language Class Initialized
INFO - 2023-04-03 08:04:13 --> Loader Class Initialized
INFO - 2023-04-03 08:04:13 --> Controller Class Initialized
INFO - 2023-04-03 08:04:13 --> Helper loaded: form_helper
INFO - 2023-04-03 08:04:13 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:04:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:04:13 --> Model "Change_model" initialized
INFO - 2023-04-03 08:04:13 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:04:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:04:13 --> Total execution time: 0.0260
INFO - 2023-04-03 08:04:13 --> Config Class Initialized
INFO - 2023-04-03 08:04:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:04:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:04:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:04:13 --> URI Class Initialized
INFO - 2023-04-03 08:04:13 --> Router Class Initialized
INFO - 2023-04-03 08:04:13 --> Output Class Initialized
INFO - 2023-04-03 08:04:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:04:13 --> Input Class Initialized
INFO - 2023-04-03 08:04:13 --> Language Class Initialized
INFO - 2023-04-03 08:04:13 --> Loader Class Initialized
INFO - 2023-04-03 08:04:13 --> Controller Class Initialized
INFO - 2023-04-03 08:04:13 --> Helper loaded: form_helper
INFO - 2023-04-03 08:04:13 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:04:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:04:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:04:13 --> Total execution time: 0.0056
INFO - 2023-04-03 08:04:13 --> Config Class Initialized
INFO - 2023-04-03 08:04:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:04:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:04:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:04:13 --> URI Class Initialized
INFO - 2023-04-03 08:04:13 --> Router Class Initialized
INFO - 2023-04-03 08:04:13 --> Output Class Initialized
INFO - 2023-04-03 08:04:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:04:13 --> Input Class Initialized
INFO - 2023-04-03 08:04:13 --> Language Class Initialized
INFO - 2023-04-03 08:04:13 --> Loader Class Initialized
INFO - 2023-04-03 08:04:13 --> Controller Class Initialized
INFO - 2023-04-03 08:04:13 --> Helper loaded: form_helper
INFO - 2023-04-03 08:04:13 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:04:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:04:13 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:04:13 --> Unable to connect to the database
INFO - 2023-04-03 08:04:13 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:04:13 --> Unable to connect to the database
ERROR - 2023-04-03 08:04:13 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:04:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:04:13 --> Total execution time: 0.0090
INFO - 2023-04-03 08:13:27 --> Config Class Initialized
INFO - 2023-04-03 08:13:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:13:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:13:27 --> Utf8 Class Initialized
INFO - 2023-04-03 08:13:27 --> URI Class Initialized
INFO - 2023-04-03 08:13:27 --> Router Class Initialized
INFO - 2023-04-03 08:13:27 --> Output Class Initialized
INFO - 2023-04-03 08:13:27 --> Security Class Initialized
DEBUG - 2023-04-03 08:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:13:27 --> Input Class Initialized
INFO - 2023-04-03 08:13:27 --> Language Class Initialized
INFO - 2023-04-03 08:13:27 --> Loader Class Initialized
INFO - 2023-04-03 08:13:27 --> Controller Class Initialized
INFO - 2023-04-03 08:13:27 --> Helper loaded: form_helper
INFO - 2023-04-03 08:13:27 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:13:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:13:27 --> Model "Change_model" initialized
INFO - 2023-04-03 08:13:27 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:13:27 --> Final output sent to browser
DEBUG - 2023-04-03 08:13:27 --> Total execution time: 0.0291
INFO - 2023-04-03 08:13:28 --> Config Class Initialized
INFO - 2023-04-03 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:13:28 --> Utf8 Class Initialized
INFO - 2023-04-03 08:13:28 --> URI Class Initialized
INFO - 2023-04-03 08:13:28 --> Router Class Initialized
INFO - 2023-04-03 08:13:28 --> Output Class Initialized
INFO - 2023-04-03 08:13:28 --> Security Class Initialized
DEBUG - 2023-04-03 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:13:28 --> Input Class Initialized
INFO - 2023-04-03 08:13:28 --> Language Class Initialized
INFO - 2023-04-03 08:13:28 --> Loader Class Initialized
INFO - 2023-04-03 08:13:28 --> Controller Class Initialized
INFO - 2023-04-03 08:13:28 --> Helper loaded: form_helper
INFO - 2023-04-03 08:13:28 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:13:28 --> Final output sent to browser
DEBUG - 2023-04-03 08:13:28 --> Total execution time: 0.0030
INFO - 2023-04-03 08:13:28 --> Config Class Initialized
INFO - 2023-04-03 08:13:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:13:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:13:28 --> Utf8 Class Initialized
INFO - 2023-04-03 08:13:28 --> URI Class Initialized
INFO - 2023-04-03 08:13:28 --> Router Class Initialized
INFO - 2023-04-03 08:13:28 --> Output Class Initialized
INFO - 2023-04-03 08:13:28 --> Security Class Initialized
DEBUG - 2023-04-03 08:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:13:28 --> Input Class Initialized
INFO - 2023-04-03 08:13:28 --> Language Class Initialized
INFO - 2023-04-03 08:13:28 --> Loader Class Initialized
INFO - 2023-04-03 08:13:28 --> Controller Class Initialized
INFO - 2023-04-03 08:13:28 --> Helper loaded: form_helper
INFO - 2023-04-03 08:13:28 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:13:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:13:28 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:13:28 --> Unable to connect to the database
INFO - 2023-04-03 08:13:28 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:13:28 --> Unable to connect to the database
ERROR - 2023-04-03 08:13:28 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:13:28 --> Final output sent to browser
DEBUG - 2023-04-03 08:13:28 --> Total execution time: 0.0099
INFO - 2023-04-03 08:14:29 --> Config Class Initialized
INFO - 2023-04-03 08:14:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:14:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:14:29 --> Utf8 Class Initialized
INFO - 2023-04-03 08:14:29 --> URI Class Initialized
INFO - 2023-04-03 08:14:29 --> Router Class Initialized
INFO - 2023-04-03 08:14:29 --> Output Class Initialized
INFO - 2023-04-03 08:14:29 --> Security Class Initialized
DEBUG - 2023-04-03 08:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:14:29 --> Input Class Initialized
INFO - 2023-04-03 08:14:29 --> Language Class Initialized
INFO - 2023-04-03 08:14:29 --> Loader Class Initialized
INFO - 2023-04-03 08:14:29 --> Controller Class Initialized
INFO - 2023-04-03 08:14:29 --> Helper loaded: form_helper
INFO - 2023-04-03 08:14:29 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:14:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:14:29 --> Model "Change_model" initialized
INFO - 2023-04-03 08:14:29 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:14:29 --> Final output sent to browser
DEBUG - 2023-04-03 08:14:29 --> Total execution time: 0.1033
INFO - 2023-04-03 08:14:29 --> Config Class Initialized
INFO - 2023-04-03 08:14:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:14:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:14:29 --> Utf8 Class Initialized
INFO - 2023-04-03 08:14:29 --> URI Class Initialized
INFO - 2023-04-03 08:14:29 --> Router Class Initialized
INFO - 2023-04-03 08:14:29 --> Output Class Initialized
INFO - 2023-04-03 08:14:29 --> Security Class Initialized
DEBUG - 2023-04-03 08:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:14:29 --> Input Class Initialized
INFO - 2023-04-03 08:14:29 --> Language Class Initialized
INFO - 2023-04-03 08:14:29 --> Loader Class Initialized
INFO - 2023-04-03 08:14:29 --> Controller Class Initialized
INFO - 2023-04-03 08:14:29 --> Helper loaded: form_helper
INFO - 2023-04-03 08:14:29 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:14:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:14:29 --> Final output sent to browser
DEBUG - 2023-04-03 08:14:29 --> Total execution time: 0.0426
INFO - 2023-04-03 08:14:29 --> Config Class Initialized
INFO - 2023-04-03 08:14:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:14:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:14:29 --> Utf8 Class Initialized
INFO - 2023-04-03 08:14:29 --> URI Class Initialized
INFO - 2023-04-03 08:14:29 --> Router Class Initialized
INFO - 2023-04-03 08:14:29 --> Output Class Initialized
INFO - 2023-04-03 08:14:29 --> Security Class Initialized
DEBUG - 2023-04-03 08:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:14:29 --> Input Class Initialized
INFO - 2023-04-03 08:14:29 --> Language Class Initialized
INFO - 2023-04-03 08:14:29 --> Loader Class Initialized
INFO - 2023-04-03 08:14:29 --> Controller Class Initialized
INFO - 2023-04-03 08:14:29 --> Helper loaded: form_helper
INFO - 2023-04-03 08:14:29 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:14:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:14:29 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:14:29 --> Unable to connect to the database
INFO - 2023-04-03 08:14:29 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:14:29 --> Unable to connect to the database
ERROR - 2023-04-03 08:14:29 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:14:29 --> Final output sent to browser
DEBUG - 2023-04-03 08:14:29 --> Total execution time: 0.0061
INFO - 2023-04-03 08:16:01 --> Config Class Initialized
INFO - 2023-04-03 08:16:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:16:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:16:01 --> Utf8 Class Initialized
INFO - 2023-04-03 08:16:01 --> URI Class Initialized
INFO - 2023-04-03 08:16:01 --> Router Class Initialized
INFO - 2023-04-03 08:16:01 --> Output Class Initialized
INFO - 2023-04-03 08:16:01 --> Security Class Initialized
DEBUG - 2023-04-03 08:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:16:01 --> Input Class Initialized
INFO - 2023-04-03 08:16:01 --> Language Class Initialized
INFO - 2023-04-03 08:16:01 --> Loader Class Initialized
INFO - 2023-04-03 08:16:01 --> Controller Class Initialized
INFO - 2023-04-03 08:16:01 --> Helper loaded: form_helper
INFO - 2023-04-03 08:16:01 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:16:01 --> Model "Change_model" initialized
INFO - 2023-04-03 08:16:01 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:16:01 --> Final output sent to browser
DEBUG - 2023-04-03 08:16:01 --> Total execution time: 0.0300
INFO - 2023-04-03 08:16:01 --> Config Class Initialized
INFO - 2023-04-03 08:16:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:16:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:16:01 --> Utf8 Class Initialized
INFO - 2023-04-03 08:16:01 --> URI Class Initialized
INFO - 2023-04-03 08:16:01 --> Router Class Initialized
INFO - 2023-04-03 08:16:01 --> Output Class Initialized
INFO - 2023-04-03 08:16:01 --> Security Class Initialized
DEBUG - 2023-04-03 08:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:16:01 --> Input Class Initialized
INFO - 2023-04-03 08:16:01 --> Language Class Initialized
INFO - 2023-04-03 08:16:01 --> Loader Class Initialized
INFO - 2023-04-03 08:16:01 --> Controller Class Initialized
INFO - 2023-04-03 08:16:01 --> Helper loaded: form_helper
INFO - 2023-04-03 08:16:01 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:16:01 --> Final output sent to browser
DEBUG - 2023-04-03 08:16:01 --> Total execution time: 0.0025
INFO - 2023-04-03 08:16:01 --> Config Class Initialized
INFO - 2023-04-03 08:16:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:16:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:16:01 --> Utf8 Class Initialized
INFO - 2023-04-03 08:16:01 --> URI Class Initialized
INFO - 2023-04-03 08:16:01 --> Router Class Initialized
INFO - 2023-04-03 08:16:01 --> Output Class Initialized
INFO - 2023-04-03 08:16:01 --> Security Class Initialized
DEBUG - 2023-04-03 08:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:16:01 --> Input Class Initialized
INFO - 2023-04-03 08:16:01 --> Language Class Initialized
INFO - 2023-04-03 08:16:01 --> Loader Class Initialized
INFO - 2023-04-03 08:16:01 --> Controller Class Initialized
INFO - 2023-04-03 08:16:01 --> Helper loaded: form_helper
INFO - 2023-04-03 08:16:01 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:16:01 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:16:01 --> Unable to connect to the database
INFO - 2023-04-03 08:16:01 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:16:01 --> Unable to connect to the database
ERROR - 2023-04-03 08:16:01 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:16:01 --> Final output sent to browser
DEBUG - 2023-04-03 08:16:01 --> Total execution time: 0.0065
INFO - 2023-04-03 08:39:01 --> Config Class Initialized
INFO - 2023-04-03 08:39:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:39:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:39:01 --> Utf8 Class Initialized
INFO - 2023-04-03 08:39:01 --> URI Class Initialized
INFO - 2023-04-03 08:39:01 --> Router Class Initialized
INFO - 2023-04-03 08:39:01 --> Output Class Initialized
INFO - 2023-04-03 08:39:01 --> Security Class Initialized
DEBUG - 2023-04-03 08:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:39:01 --> Input Class Initialized
INFO - 2023-04-03 08:39:01 --> Language Class Initialized
INFO - 2023-04-03 08:39:01 --> Loader Class Initialized
INFO - 2023-04-03 08:39:01 --> Controller Class Initialized
INFO - 2023-04-03 08:39:01 --> Helper loaded: form_helper
INFO - 2023-04-03 08:39:01 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:39:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:39:01 --> Model "Change_model" initialized
INFO - 2023-04-03 08:39:01 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:39:01 --> Final output sent to browser
DEBUG - 2023-04-03 08:39:01 --> Total execution time: 0.0762
INFO - 2023-04-03 08:39:01 --> Config Class Initialized
INFO - 2023-04-03 08:39:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:39:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:39:01 --> Utf8 Class Initialized
INFO - 2023-04-03 08:39:01 --> URI Class Initialized
INFO - 2023-04-03 08:39:01 --> Router Class Initialized
INFO - 2023-04-03 08:39:01 --> Output Class Initialized
INFO - 2023-04-03 08:39:01 --> Security Class Initialized
DEBUG - 2023-04-03 08:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:39:01 --> Input Class Initialized
INFO - 2023-04-03 08:39:01 --> Language Class Initialized
INFO - 2023-04-03 08:39:01 --> Loader Class Initialized
INFO - 2023-04-03 08:39:01 --> Controller Class Initialized
INFO - 2023-04-03 08:39:01 --> Helper loaded: form_helper
INFO - 2023-04-03 08:39:01 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:39:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:39:01 --> Final output sent to browser
DEBUG - 2023-04-03 08:39:01 --> Total execution time: 0.0058
INFO - 2023-04-03 08:39:01 --> Config Class Initialized
INFO - 2023-04-03 08:39:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:39:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:39:01 --> Utf8 Class Initialized
INFO - 2023-04-03 08:39:01 --> URI Class Initialized
INFO - 2023-04-03 08:39:01 --> Router Class Initialized
INFO - 2023-04-03 08:39:01 --> Output Class Initialized
INFO - 2023-04-03 08:39:01 --> Security Class Initialized
DEBUG - 2023-04-03 08:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:39:01 --> Input Class Initialized
INFO - 2023-04-03 08:39:01 --> Language Class Initialized
INFO - 2023-04-03 08:39:01 --> Loader Class Initialized
INFO - 2023-04-03 08:39:01 --> Controller Class Initialized
INFO - 2023-04-03 08:39:01 --> Helper loaded: form_helper
INFO - 2023-04-03 08:39:01 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:39:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:39:01 --> Database Driver Class Initialized
ERROR - 2023-04-03 08:39:01 --> Unable to connect to the database
INFO - 2023-04-03 08:39:01 --> Model "Login_model" initialized
ERROR - 2023-04-03 08:39:01 --> Unable to connect to the database
ERROR - 2023-04-03 08:39:01 --> Query error: Connection refused - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' and password='Aa_12345';
INFO - 2023-04-03 08:39:01 --> Final output sent to browser
DEBUG - 2023-04-03 08:39:01 --> Total execution time: 0.0103
INFO - 2023-04-03 08:41:48 --> Config Class Initialized
INFO - 2023-04-03 08:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:41:48 --> URI Class Initialized
INFO - 2023-04-03 08:41:48 --> Router Class Initialized
INFO - 2023-04-03 08:41:48 --> Output Class Initialized
INFO - 2023-04-03 08:41:48 --> Security Class Initialized
DEBUG - 2023-04-03 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:41:48 --> Input Class Initialized
INFO - 2023-04-03 08:41:48 --> Language Class Initialized
INFO - 2023-04-03 08:41:48 --> Loader Class Initialized
INFO - 2023-04-03 08:41:48 --> Controller Class Initialized
INFO - 2023-04-03 08:41:48 --> Helper loaded: form_helper
INFO - 2023-04-03 08:41:48 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:41:48 --> Model "Change_model" initialized
INFO - 2023-04-03 08:41:48 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:41:48 --> Final output sent to browser
DEBUG - 2023-04-03 08:41:48 --> Total execution time: 0.0307
INFO - 2023-04-03 08:41:48 --> Config Class Initialized
INFO - 2023-04-03 08:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:41:48 --> URI Class Initialized
INFO - 2023-04-03 08:41:48 --> Router Class Initialized
INFO - 2023-04-03 08:41:48 --> Output Class Initialized
INFO - 2023-04-03 08:41:48 --> Security Class Initialized
DEBUG - 2023-04-03 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:41:48 --> Input Class Initialized
INFO - 2023-04-03 08:41:48 --> Language Class Initialized
INFO - 2023-04-03 08:41:48 --> Loader Class Initialized
INFO - 2023-04-03 08:41:48 --> Controller Class Initialized
INFO - 2023-04-03 08:41:48 --> Helper loaded: form_helper
INFO - 2023-04-03 08:41:48 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:41:48 --> Final output sent to browser
DEBUG - 2023-04-03 08:41:48 --> Total execution time: 0.1241
INFO - 2023-04-03 08:41:48 --> Config Class Initialized
INFO - 2023-04-03 08:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:41:48 --> URI Class Initialized
INFO - 2023-04-03 08:41:48 --> Router Class Initialized
INFO - 2023-04-03 08:41:48 --> Output Class Initialized
INFO - 2023-04-03 08:41:48 --> Security Class Initialized
DEBUG - 2023-04-03 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:41:48 --> Input Class Initialized
INFO - 2023-04-03 08:41:48 --> Language Class Initialized
INFO - 2023-04-03 08:41:48 --> Loader Class Initialized
INFO - 2023-04-03 08:41:48 --> Controller Class Initialized
INFO - 2023-04-03 08:41:48 --> Helper loaded: form_helper
INFO - 2023-04-03 08:41:48 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:41:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:41:48 --> Model "Login_model" initialized
INFO - 2023-04-03 08:41:48 --> Final output sent to browser
DEBUG - 2023-04-03 08:41:48 --> Total execution time: 0.0260
INFO - 2023-04-03 08:41:48 --> Config Class Initialized
INFO - 2023-04-03 08:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:41:48 --> URI Class Initialized
INFO - 2023-04-03 08:41:48 --> Router Class Initialized
INFO - 2023-04-03 08:41:48 --> Output Class Initialized
INFO - 2023-04-03 08:41:48 --> Security Class Initialized
DEBUG - 2023-04-03 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:41:48 --> Input Class Initialized
INFO - 2023-04-03 08:41:48 --> Language Class Initialized
INFO - 2023-04-03 08:41:48 --> Loader Class Initialized
INFO - 2023-04-03 08:41:48 --> Controller Class Initialized
DEBUG - 2023-04-03 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:41:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:41:48 --> Final output sent to browser
DEBUG - 2023-04-03 08:41:48 --> Total execution time: 0.0167
INFO - 2023-04-03 08:41:48 --> Config Class Initialized
INFO - 2023-04-03 08:41:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:41:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:41:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:41:48 --> URI Class Initialized
INFO - 2023-04-03 08:41:48 --> Router Class Initialized
INFO - 2023-04-03 08:41:48 --> Output Class Initialized
INFO - 2023-04-03 08:41:48 --> Security Class Initialized
DEBUG - 2023-04-03 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:41:48 --> Input Class Initialized
INFO - 2023-04-03 08:41:48 --> Language Class Initialized
INFO - 2023-04-03 08:41:48 --> Loader Class Initialized
INFO - 2023-04-03 08:41:48 --> Controller Class Initialized
DEBUG - 2023-04-03 08:41:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:41:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:41:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:41:48 --> Final output sent to browser
DEBUG - 2023-04-03 08:41:48 --> Total execution time: 0.0161
INFO - 2023-04-03 08:44:57 --> Config Class Initialized
INFO - 2023-04-03 08:44:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:44:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:44:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:44:57 --> URI Class Initialized
INFO - 2023-04-03 08:44:57 --> Router Class Initialized
INFO - 2023-04-03 08:44:57 --> Output Class Initialized
INFO - 2023-04-03 08:44:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:44:57 --> Input Class Initialized
INFO - 2023-04-03 08:44:57 --> Language Class Initialized
INFO - 2023-04-03 08:44:57 --> Loader Class Initialized
INFO - 2023-04-03 08:44:57 --> Controller Class Initialized
INFO - 2023-04-03 08:44:57 --> Helper loaded: form_helper
INFO - 2023-04-03 08:44:57 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:44:57 --> Model "Change_model" initialized
INFO - 2023-04-03 08:44:57 --> Model "Grafana_model" initialized
INFO - 2023-04-03 08:44:57 --> Final output sent to browser
DEBUG - 2023-04-03 08:44:57 --> Total execution time: 0.0238
INFO - 2023-04-03 08:44:57 --> Config Class Initialized
INFO - 2023-04-03 08:44:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:44:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:44:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:44:57 --> URI Class Initialized
INFO - 2023-04-03 08:44:57 --> Router Class Initialized
INFO - 2023-04-03 08:44:57 --> Output Class Initialized
INFO - 2023-04-03 08:44:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:44:57 --> Input Class Initialized
INFO - 2023-04-03 08:44:57 --> Language Class Initialized
INFO - 2023-04-03 08:44:57 --> Loader Class Initialized
INFO - 2023-04-03 08:44:57 --> Controller Class Initialized
INFO - 2023-04-03 08:44:57 --> Helper loaded: form_helper
INFO - 2023-04-03 08:44:57 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:44:57 --> Final output sent to browser
DEBUG - 2023-04-03 08:44:57 --> Total execution time: 0.0040
INFO - 2023-04-03 08:44:57 --> Config Class Initialized
INFO - 2023-04-03 08:44:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:44:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:44:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:44:57 --> URI Class Initialized
INFO - 2023-04-03 08:44:57 --> Router Class Initialized
INFO - 2023-04-03 08:44:57 --> Output Class Initialized
INFO - 2023-04-03 08:44:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:44:57 --> Input Class Initialized
INFO - 2023-04-03 08:44:57 --> Language Class Initialized
INFO - 2023-04-03 08:44:57 --> Loader Class Initialized
INFO - 2023-04-03 08:44:57 --> Controller Class Initialized
INFO - 2023-04-03 08:44:57 --> Helper loaded: form_helper
INFO - 2023-04-03 08:44:57 --> Helper loaded: url_helper
DEBUG - 2023-04-03 08:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:44:57 --> Database Driver Class Initialized
INFO - 2023-04-03 08:44:57 --> Model "Login_model" initialized
INFO - 2023-04-03 08:44:57 --> Final output sent to browser
DEBUG - 2023-04-03 08:44:57 --> Total execution time: 0.0162
INFO - 2023-04-03 08:44:57 --> Config Class Initialized
INFO - 2023-04-03 08:44:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:44:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:44:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:44:57 --> URI Class Initialized
INFO - 2023-04-03 08:44:57 --> Router Class Initialized
INFO - 2023-04-03 08:44:57 --> Output Class Initialized
INFO - 2023-04-03 08:44:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:44:57 --> Input Class Initialized
INFO - 2023-04-03 08:44:57 --> Language Class Initialized
INFO - 2023-04-03 08:44:57 --> Loader Class Initialized
INFO - 2023-04-03 08:44:57 --> Controller Class Initialized
DEBUG - 2023-04-03 08:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:44:57 --> Database Driver Class Initialized
INFO - 2023-04-03 08:44:57 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:44:57 --> Final output sent to browser
DEBUG - 2023-04-03 08:44:57 --> Total execution time: 0.0181
INFO - 2023-04-03 08:44:57 --> Config Class Initialized
INFO - 2023-04-03 08:44:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:44:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:44:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:44:57 --> URI Class Initialized
INFO - 2023-04-03 08:44:57 --> Router Class Initialized
INFO - 2023-04-03 08:44:57 --> Output Class Initialized
INFO - 2023-04-03 08:44:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:44:57 --> Input Class Initialized
INFO - 2023-04-03 08:44:57 --> Language Class Initialized
INFO - 2023-04-03 08:44:57 --> Loader Class Initialized
INFO - 2023-04-03 08:44:57 --> Controller Class Initialized
DEBUG - 2023-04-03 08:44:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:44:57 --> Database Driver Class Initialized
INFO - 2023-04-03 08:44:57 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:44:57 --> Final output sent to browser
DEBUG - 2023-04-03 08:44:57 --> Total execution time: 0.0175
INFO - 2023-04-03 08:44:58 --> Config Class Initialized
INFO - 2023-04-03 08:44:58 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:44:58 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:44:58 --> Utf8 Class Initialized
INFO - 2023-04-03 08:44:58 --> URI Class Initialized
INFO - 2023-04-03 08:44:58 --> Router Class Initialized
INFO - 2023-04-03 08:44:58 --> Output Class Initialized
INFO - 2023-04-03 08:44:58 --> Security Class Initialized
DEBUG - 2023-04-03 08:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:44:58 --> Input Class Initialized
INFO - 2023-04-03 08:44:58 --> Language Class Initialized
INFO - 2023-04-03 08:44:58 --> Loader Class Initialized
INFO - 2023-04-03 08:44:58 --> Controller Class Initialized
DEBUG - 2023-04-03 08:44:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:44:58 --> Database Driver Class Initialized
INFO - 2023-04-03 08:44:58 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:44:58 --> Database Driver Class Initialized
INFO - 2023-04-03 08:44:58 --> Model "Login_model" initialized
INFO - 2023-04-03 08:44:58 --> Final output sent to browser
DEBUG - 2023-04-03 08:44:58 --> Total execution time: 0.1064
INFO - 2023-04-03 08:44:58 --> Config Class Initialized
INFO - 2023-04-03 08:44:58 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:44:58 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:44:58 --> Utf8 Class Initialized
INFO - 2023-04-03 08:44:58 --> URI Class Initialized
INFO - 2023-04-03 08:44:58 --> Router Class Initialized
INFO - 2023-04-03 08:44:58 --> Output Class Initialized
INFO - 2023-04-03 08:44:58 --> Security Class Initialized
DEBUG - 2023-04-03 08:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:44:58 --> Input Class Initialized
INFO - 2023-04-03 08:44:58 --> Language Class Initialized
INFO - 2023-04-03 08:44:58 --> Loader Class Initialized
INFO - 2023-04-03 08:44:58 --> Controller Class Initialized
DEBUG - 2023-04-03 08:44:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:44:58 --> Database Driver Class Initialized
INFO - 2023-04-03 08:44:58 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:44:58 --> Database Driver Class Initialized
INFO - 2023-04-03 08:44:58 --> Model "Login_model" initialized
INFO - 2023-04-03 08:44:58 --> Final output sent to browser
DEBUG - 2023-04-03 08:44:58 --> Total execution time: 0.0782
INFO - 2023-04-03 08:45:03 --> Config Class Initialized
INFO - 2023-04-03 08:45:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:45:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:45:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:45:03 --> URI Class Initialized
INFO - 2023-04-03 08:45:03 --> Router Class Initialized
INFO - 2023-04-03 08:45:03 --> Output Class Initialized
INFO - 2023-04-03 08:45:03 --> Security Class Initialized
DEBUG - 2023-04-03 08:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:45:03 --> Input Class Initialized
INFO - 2023-04-03 08:45:03 --> Language Class Initialized
INFO - 2023-04-03 08:45:03 --> Loader Class Initialized
INFO - 2023-04-03 08:45:03 --> Controller Class Initialized
DEBUG - 2023-04-03 08:45:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:45:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:45:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:45:03 --> Final output sent to browser
DEBUG - 2023-04-03 08:45:03 --> Total execution time: 0.0507
INFO - 2023-04-03 08:45:03 --> Config Class Initialized
INFO - 2023-04-03 08:45:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:45:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:45:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:45:03 --> URI Class Initialized
INFO - 2023-04-03 08:45:03 --> Router Class Initialized
INFO - 2023-04-03 08:45:03 --> Output Class Initialized
INFO - 2023-04-03 08:45:03 --> Security Class Initialized
DEBUG - 2023-04-03 08:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:45:03 --> Input Class Initialized
INFO - 2023-04-03 08:45:03 --> Language Class Initialized
INFO - 2023-04-03 08:45:03 --> Loader Class Initialized
INFO - 2023-04-03 08:45:03 --> Controller Class Initialized
DEBUG - 2023-04-03 08:45:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:45:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:45:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:45:03 --> Final output sent to browser
DEBUG - 2023-04-03 08:45:03 --> Total execution time: 0.2016
INFO - 2023-04-03 08:48:19 --> Config Class Initialized
INFO - 2023-04-03 08:48:19 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:19 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:19 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:19 --> URI Class Initialized
INFO - 2023-04-03 08:48:19 --> Router Class Initialized
INFO - 2023-04-03 08:48:19 --> Output Class Initialized
INFO - 2023-04-03 08:48:19 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:19 --> Input Class Initialized
INFO - 2023-04-03 08:48:19 --> Language Class Initialized
INFO - 2023-04-03 08:48:19 --> Loader Class Initialized
INFO - 2023-04-03 08:48:19 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:19 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:19 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:19 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:19 --> Model "Login_model" initialized
INFO - 2023-04-03 08:48:19 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:19 --> Total execution time: 0.0558
INFO - 2023-04-03 08:48:19 --> Config Class Initialized
INFO - 2023-04-03 08:48:19 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:19 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:19 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:19 --> URI Class Initialized
INFO - 2023-04-03 08:48:19 --> Router Class Initialized
INFO - 2023-04-03 08:48:19 --> Output Class Initialized
INFO - 2023-04-03 08:48:19 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:19 --> Input Class Initialized
INFO - 2023-04-03 08:48:19 --> Language Class Initialized
INFO - 2023-04-03 08:48:19 --> Loader Class Initialized
INFO - 2023-04-03 08:48:19 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:19 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:19 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:19 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:19 --> Model "Login_model" initialized
INFO - 2023-04-03 08:48:19 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:19 --> Total execution time: 0.0411
INFO - 2023-04-03 08:48:24 --> Config Class Initialized
INFO - 2023-04-03 08:48:24 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:24 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:24 --> URI Class Initialized
INFO - 2023-04-03 08:48:24 --> Router Class Initialized
INFO - 2023-04-03 08:48:24 --> Output Class Initialized
INFO - 2023-04-03 08:48:24 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:24 --> Input Class Initialized
INFO - 2023-04-03 08:48:24 --> Language Class Initialized
INFO - 2023-04-03 08:48:24 --> Loader Class Initialized
INFO - 2023-04-03 08:48:24 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:24 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:24 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:24 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:24 --> Total execution time: 0.0297
INFO - 2023-04-03 08:48:24 --> Config Class Initialized
INFO - 2023-04-03 08:48:24 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:24 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:24 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:24 --> URI Class Initialized
INFO - 2023-04-03 08:48:24 --> Router Class Initialized
INFO - 2023-04-03 08:48:24 --> Output Class Initialized
INFO - 2023-04-03 08:48:24 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:24 --> Input Class Initialized
INFO - 2023-04-03 08:48:24 --> Language Class Initialized
INFO - 2023-04-03 08:48:24 --> Loader Class Initialized
INFO - 2023-04-03 08:48:24 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:24 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:24 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:24 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:24 --> Total execution time: 0.0296
INFO - 2023-04-03 08:48:25 --> Config Class Initialized
INFO - 2023-04-03 08:48:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:25 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:25 --> URI Class Initialized
INFO - 2023-04-03 08:48:25 --> Router Class Initialized
INFO - 2023-04-03 08:48:25 --> Output Class Initialized
INFO - 2023-04-03 08:48:25 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:25 --> Input Class Initialized
INFO - 2023-04-03 08:48:25 --> Language Class Initialized
INFO - 2023-04-03 08:48:25 --> Loader Class Initialized
INFO - 2023-04-03 08:48:25 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:25 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:25 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:25 --> Total execution time: 0.0452
INFO - 2023-04-03 08:48:25 --> Config Class Initialized
INFO - 2023-04-03 08:48:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:25 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:25 --> URI Class Initialized
INFO - 2023-04-03 08:48:25 --> Router Class Initialized
INFO - 2023-04-03 08:48:25 --> Output Class Initialized
INFO - 2023-04-03 08:48:25 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:25 --> Input Class Initialized
INFO - 2023-04-03 08:48:25 --> Language Class Initialized
INFO - 2023-04-03 08:48:25 --> Loader Class Initialized
INFO - 2023-04-03 08:48:25 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:25 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:25 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:25 --> Total execution time: 0.0776
INFO - 2023-04-03 08:48:35 --> Config Class Initialized
INFO - 2023-04-03 08:48:35 --> Config Class Initialized
INFO - 2023-04-03 08:48:35 --> Hooks Class Initialized
INFO - 2023-04-03 08:48:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:35 --> Utf8 Class Initialized
DEBUG - 2023-04-03 08:48:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:35 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:35 --> URI Class Initialized
INFO - 2023-04-03 08:48:35 --> URI Class Initialized
INFO - 2023-04-03 08:48:35 --> Router Class Initialized
INFO - 2023-04-03 08:48:35 --> Router Class Initialized
INFO - 2023-04-03 08:48:35 --> Output Class Initialized
INFO - 2023-04-03 08:48:35 --> Output Class Initialized
INFO - 2023-04-03 08:48:35 --> Security Class Initialized
INFO - 2023-04-03 08:48:35 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:35 --> Input Class Initialized
INFO - 2023-04-03 08:48:35 --> Input Class Initialized
INFO - 2023-04-03 08:48:35 --> Language Class Initialized
INFO - 2023-04-03 08:48:35 --> Language Class Initialized
INFO - 2023-04-03 08:48:35 --> Loader Class Initialized
INFO - 2023-04-03 08:48:35 --> Loader Class Initialized
INFO - 2023-04-03 08:48:35 --> Controller Class Initialized
INFO - 2023-04-03 08:48:35 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:48:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:35 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:35 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:35 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:35 --> Total execution time: 0.0531
INFO - 2023-04-03 08:48:35 --> Config Class Initialized
INFO - 2023-04-03 08:48:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:35 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:35 --> URI Class Initialized
INFO - 2023-04-03 08:48:35 --> Router Class Initialized
INFO - 2023-04-03 08:48:35 --> Output Class Initialized
INFO - 2023-04-03 08:48:35 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:35 --> Input Class Initialized
INFO - 2023-04-03 08:48:35 --> Language Class Initialized
INFO - 2023-04-03 08:48:35 --> Loader Class Initialized
INFO - 2023-04-03 08:48:35 --> Controller Class Initialized
INFO - 2023-04-03 08:48:35 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:48:35 --> Total execution time: 0.0581
INFO - 2023-04-03 08:48:35 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:35 --> Config Class Initialized
INFO - 2023-04-03 08:48:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:35 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:35 --> URI Class Initialized
INFO - 2023-04-03 08:48:35 --> Router Class Initialized
INFO - 2023-04-03 08:48:35 --> Output Class Initialized
INFO - 2023-04-03 08:48:35 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:35 --> Input Class Initialized
INFO - 2023-04-03 08:48:35 --> Language Class Initialized
INFO - 2023-04-03 08:48:35 --> Loader Class Initialized
INFO - 2023-04-03 08:48:35 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:35 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:35 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:35 --> Total execution time: 0.0486
INFO - 2023-04-03 08:48:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:35 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:35 --> Total execution time: 0.0617
INFO - 2023-04-03 08:48:36 --> Config Class Initialized
INFO - 2023-04-03 08:48:36 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:36 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:36 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:36 --> URI Class Initialized
INFO - 2023-04-03 08:48:36 --> Router Class Initialized
INFO - 2023-04-03 08:48:36 --> Output Class Initialized
INFO - 2023-04-03 08:48:36 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:36 --> Input Class Initialized
INFO - 2023-04-03 08:48:36 --> Language Class Initialized
INFO - 2023-04-03 08:48:36 --> Loader Class Initialized
INFO - 2023-04-03 08:48:36 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:36 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:36 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:36 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:36 --> Total execution time: 0.0504
INFO - 2023-04-03 08:48:36 --> Config Class Initialized
INFO - 2023-04-03 08:48:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:37 --> URI Class Initialized
INFO - 2023-04-03 08:48:37 --> Router Class Initialized
INFO - 2023-04-03 08:48:37 --> Output Class Initialized
INFO - 2023-04-03 08:48:37 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:37 --> Input Class Initialized
INFO - 2023-04-03 08:48:37 --> Language Class Initialized
INFO - 2023-04-03 08:48:37 --> Loader Class Initialized
INFO - 2023-04-03 08:48:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:37 --> Total execution time: 0.0927
INFO - 2023-04-03 08:48:39 --> Config Class Initialized
INFO - 2023-04-03 08:48:39 --> Config Class Initialized
INFO - 2023-04-03 08:48:39 --> Hooks Class Initialized
INFO - 2023-04-03 08:48:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:48:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:39 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:39 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:39 --> URI Class Initialized
INFO - 2023-04-03 08:48:39 --> URI Class Initialized
INFO - 2023-04-03 08:48:39 --> Router Class Initialized
INFO - 2023-04-03 08:48:39 --> Router Class Initialized
INFO - 2023-04-03 08:48:39 --> Output Class Initialized
INFO - 2023-04-03 08:48:39 --> Output Class Initialized
INFO - 2023-04-03 08:48:39 --> Security Class Initialized
INFO - 2023-04-03 08:48:39 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:39 --> Input Class Initialized
INFO - 2023-04-03 08:48:39 --> Language Class Initialized
INFO - 2023-04-03 08:48:39 --> Input Class Initialized
INFO - 2023-04-03 08:48:39 --> Language Class Initialized
INFO - 2023-04-03 08:48:39 --> Loader Class Initialized
INFO - 2023-04-03 08:48:39 --> Loader Class Initialized
INFO - 2023-04-03 08:48:39 --> Controller Class Initialized
INFO - 2023-04-03 08:48:39 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:48:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:39 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:39 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:39 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:39 --> Total execution time: 0.0292
INFO - 2023-04-03 08:48:39 --> Final output sent to browser
INFO - 2023-04-03 08:48:39 --> Config Class Initialized
DEBUG - 2023-04-03 08:48:39 --> Total execution time: 0.0337
INFO - 2023-04-03 08:48:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:39 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:39 --> URI Class Initialized
INFO - 2023-04-03 08:48:39 --> Router Class Initialized
INFO - 2023-04-03 08:48:39 --> Output Class Initialized
INFO - 2023-04-03 08:48:39 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:39 --> Input Class Initialized
INFO - 2023-04-03 08:48:39 --> Language Class Initialized
INFO - 2023-04-03 08:48:39 --> Loader Class Initialized
INFO - 2023-04-03 08:48:39 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:39 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:39 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:39 --> Total execution time: 0.1074
INFO - 2023-04-03 08:48:52 --> Config Class Initialized
INFO - 2023-04-03 08:48:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:52 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:52 --> URI Class Initialized
INFO - 2023-04-03 08:48:52 --> Router Class Initialized
INFO - 2023-04-03 08:48:52 --> Output Class Initialized
INFO - 2023-04-03 08:48:52 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:52 --> Input Class Initialized
INFO - 2023-04-03 08:48:52 --> Language Class Initialized
INFO - 2023-04-03 08:48:52 --> Loader Class Initialized
INFO - 2023-04-03 08:48:52 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:52 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:53 --> Total execution time: 0.0607
INFO - 2023-04-03 08:48:53 --> Config Class Initialized
INFO - 2023-04-03 08:48:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:53 --> URI Class Initialized
INFO - 2023-04-03 08:48:53 --> Router Class Initialized
INFO - 2023-04-03 08:48:53 --> Output Class Initialized
INFO - 2023-04-03 08:48:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:53 --> Input Class Initialized
INFO - 2023-04-03 08:48:53 --> Language Class Initialized
INFO - 2023-04-03 08:48:53 --> Loader Class Initialized
INFO - 2023-04-03 08:48:53 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:53 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:53 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:53 --> Model "Login_model" initialized
INFO - 2023-04-03 08:48:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:53 --> Total execution time: 0.1345
INFO - 2023-04-03 08:48:53 --> Config Class Initialized
INFO - 2023-04-03 08:48:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:53 --> URI Class Initialized
INFO - 2023-04-03 08:48:53 --> Router Class Initialized
INFO - 2023-04-03 08:48:53 --> Output Class Initialized
INFO - 2023-04-03 08:48:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:53 --> Input Class Initialized
INFO - 2023-04-03 08:48:53 --> Language Class Initialized
INFO - 2023-04-03 08:48:53 --> Loader Class Initialized
INFO - 2023-04-03 08:48:53 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:53 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:53 --> Total execution time: 0.0173
INFO - 2023-04-03 08:48:53 --> Config Class Initialized
INFO - 2023-04-03 08:48:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:53 --> URI Class Initialized
INFO - 2023-04-03 08:48:53 --> Router Class Initialized
INFO - 2023-04-03 08:48:53 --> Output Class Initialized
INFO - 2023-04-03 08:48:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:53 --> Input Class Initialized
INFO - 2023-04-03 08:48:53 --> Language Class Initialized
INFO - 2023-04-03 08:48:53 --> Loader Class Initialized
INFO - 2023-04-03 08:48:53 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:53 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:53 --> Total execution time: 0.0269
INFO - 2023-04-03 08:48:58 --> Config Class Initialized
INFO - 2023-04-03 08:48:58 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:48:58 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:48:58 --> Utf8 Class Initialized
INFO - 2023-04-03 08:48:58 --> URI Class Initialized
INFO - 2023-04-03 08:48:58 --> Router Class Initialized
INFO - 2023-04-03 08:48:58 --> Output Class Initialized
INFO - 2023-04-03 08:48:58 --> Security Class Initialized
DEBUG - 2023-04-03 08:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:48:58 --> Input Class Initialized
INFO - 2023-04-03 08:48:58 --> Language Class Initialized
INFO - 2023-04-03 08:48:58 --> Loader Class Initialized
INFO - 2023-04-03 08:48:58 --> Controller Class Initialized
DEBUG - 2023-04-03 08:48:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:48:58 --> Database Driver Class Initialized
INFO - 2023-04-03 08:48:58 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:48:58 --> Final output sent to browser
DEBUG - 2023-04-03 08:48:58 --> Total execution time: 0.0210
INFO - 2023-04-03 08:49:03 --> Config Class Initialized
INFO - 2023-04-03 08:49:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:03 --> URI Class Initialized
INFO - 2023-04-03 08:49:03 --> Router Class Initialized
INFO - 2023-04-03 08:49:03 --> Output Class Initialized
INFO - 2023-04-03 08:49:03 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:03 --> Input Class Initialized
INFO - 2023-04-03 08:49:03 --> Language Class Initialized
INFO - 2023-04-03 08:49:03 --> Loader Class Initialized
INFO - 2023-04-03 08:49:03 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:03 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:03 --> Total execution time: 0.0108
INFO - 2023-04-03 08:49:03 --> Config Class Initialized
INFO - 2023-04-03 08:49:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:03 --> URI Class Initialized
INFO - 2023-04-03 08:49:03 --> Router Class Initialized
INFO - 2023-04-03 08:49:03 --> Output Class Initialized
INFO - 2023-04-03 08:49:03 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:03 --> Input Class Initialized
INFO - 2023-04-03 08:49:03 --> Language Class Initialized
INFO - 2023-04-03 08:49:03 --> Loader Class Initialized
INFO - 2023-04-03 08:49:03 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:03 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:03 --> Total execution time: 0.0136
INFO - 2023-04-03 08:49:08 --> Config Class Initialized
INFO - 2023-04-03 08:49:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:08 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:08 --> URI Class Initialized
INFO - 2023-04-03 08:49:08 --> Router Class Initialized
INFO - 2023-04-03 08:49:08 --> Output Class Initialized
INFO - 2023-04-03 08:49:08 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:08 --> Input Class Initialized
INFO - 2023-04-03 08:49:08 --> Language Class Initialized
INFO - 2023-04-03 08:49:08 --> Loader Class Initialized
INFO - 2023-04-03 08:49:08 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:08 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:08 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:08 --> Total execution time: 0.0534
INFO - 2023-04-03 08:49:13 --> Config Class Initialized
INFO - 2023-04-03 08:49:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:13 --> URI Class Initialized
INFO - 2023-04-03 08:49:13 --> Router Class Initialized
INFO - 2023-04-03 08:49:13 --> Output Class Initialized
INFO - 2023-04-03 08:49:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:13 --> Input Class Initialized
INFO - 2023-04-03 08:49:13 --> Language Class Initialized
INFO - 2023-04-03 08:49:13 --> Loader Class Initialized
INFO - 2023-04-03 08:49:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:13 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:13 --> Total execution time: 0.0111
INFO - 2023-04-03 08:49:13 --> Config Class Initialized
INFO - 2023-04-03 08:49:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:13 --> URI Class Initialized
INFO - 2023-04-03 08:49:13 --> Router Class Initialized
INFO - 2023-04-03 08:49:13 --> Output Class Initialized
INFO - 2023-04-03 08:49:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:13 --> Input Class Initialized
INFO - 2023-04-03 08:49:13 --> Language Class Initialized
INFO - 2023-04-03 08:49:13 --> Loader Class Initialized
INFO - 2023-04-03 08:49:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:13 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:13 --> Total execution time: 0.0125
INFO - 2023-04-03 08:49:18 --> Config Class Initialized
INFO - 2023-04-03 08:49:18 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:18 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:18 --> URI Class Initialized
INFO - 2023-04-03 08:49:18 --> Router Class Initialized
INFO - 2023-04-03 08:49:18 --> Output Class Initialized
INFO - 2023-04-03 08:49:18 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:18 --> Input Class Initialized
INFO - 2023-04-03 08:49:18 --> Language Class Initialized
INFO - 2023-04-03 08:49:18 --> Loader Class Initialized
INFO - 2023-04-03 08:49:18 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:18 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:18 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:18 --> Total execution time: 0.0145
INFO - 2023-04-03 08:49:23 --> Config Class Initialized
INFO - 2023-04-03 08:49:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:23 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:23 --> URI Class Initialized
INFO - 2023-04-03 08:49:23 --> Router Class Initialized
INFO - 2023-04-03 08:49:23 --> Output Class Initialized
INFO - 2023-04-03 08:49:23 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:23 --> Input Class Initialized
INFO - 2023-04-03 08:49:23 --> Language Class Initialized
INFO - 2023-04-03 08:49:23 --> Loader Class Initialized
INFO - 2023-04-03 08:49:23 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:23 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:23 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:23 --> Total execution time: 0.0105
INFO - 2023-04-03 08:49:23 --> Config Class Initialized
INFO - 2023-04-03 08:49:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:23 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:23 --> URI Class Initialized
INFO - 2023-04-03 08:49:23 --> Router Class Initialized
INFO - 2023-04-03 08:49:23 --> Output Class Initialized
INFO - 2023-04-03 08:49:23 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:23 --> Input Class Initialized
INFO - 2023-04-03 08:49:23 --> Language Class Initialized
INFO - 2023-04-03 08:49:23 --> Loader Class Initialized
INFO - 2023-04-03 08:49:23 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:23 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:23 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:23 --> Total execution time: 0.0118
INFO - 2023-04-03 08:49:28 --> Config Class Initialized
INFO - 2023-04-03 08:49:28 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:28 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:28 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:28 --> URI Class Initialized
INFO - 2023-04-03 08:49:28 --> Router Class Initialized
INFO - 2023-04-03 08:49:28 --> Output Class Initialized
INFO - 2023-04-03 08:49:28 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:28 --> Input Class Initialized
INFO - 2023-04-03 08:49:28 --> Language Class Initialized
INFO - 2023-04-03 08:49:28 --> Loader Class Initialized
INFO - 2023-04-03 08:49:28 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:28 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:28 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:28 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:28 --> Total execution time: 0.0211
INFO - 2023-04-03 08:49:33 --> Config Class Initialized
INFO - 2023-04-03 08:49:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:33 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:33 --> URI Class Initialized
INFO - 2023-04-03 08:49:33 --> Router Class Initialized
INFO - 2023-04-03 08:49:33 --> Output Class Initialized
INFO - 2023-04-03 08:49:33 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:33 --> Input Class Initialized
INFO - 2023-04-03 08:49:33 --> Language Class Initialized
INFO - 2023-04-03 08:49:33 --> Loader Class Initialized
INFO - 2023-04-03 08:49:33 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:33 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:33 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:33 --> Total execution time: 0.0130
INFO - 2023-04-03 08:49:33 --> Config Class Initialized
INFO - 2023-04-03 08:49:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:33 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:33 --> URI Class Initialized
INFO - 2023-04-03 08:49:33 --> Router Class Initialized
INFO - 2023-04-03 08:49:33 --> Output Class Initialized
INFO - 2023-04-03 08:49:33 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:33 --> Input Class Initialized
INFO - 2023-04-03 08:49:33 --> Language Class Initialized
INFO - 2023-04-03 08:49:33 --> Loader Class Initialized
INFO - 2023-04-03 08:49:33 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:33 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:33 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:33 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:33 --> Total execution time: 0.0146
INFO - 2023-04-03 08:49:38 --> Config Class Initialized
INFO - 2023-04-03 08:49:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:38 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:38 --> URI Class Initialized
INFO - 2023-04-03 08:49:38 --> Router Class Initialized
INFO - 2023-04-03 08:49:38 --> Output Class Initialized
INFO - 2023-04-03 08:49:38 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:38 --> Input Class Initialized
INFO - 2023-04-03 08:49:38 --> Language Class Initialized
INFO - 2023-04-03 08:49:38 --> Loader Class Initialized
INFO - 2023-04-03 08:49:38 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:38 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:38 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:38 --> Total execution time: 0.0175
INFO - 2023-04-03 08:49:43 --> Config Class Initialized
INFO - 2023-04-03 08:49:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:43 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:43 --> URI Class Initialized
INFO - 2023-04-03 08:49:43 --> Router Class Initialized
INFO - 2023-04-03 08:49:43 --> Output Class Initialized
INFO - 2023-04-03 08:49:43 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:43 --> Input Class Initialized
INFO - 2023-04-03 08:49:43 --> Language Class Initialized
INFO - 2023-04-03 08:49:43 --> Loader Class Initialized
INFO - 2023-04-03 08:49:43 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:43 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:43 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:43 --> Total execution time: 0.0118
INFO - 2023-04-03 08:49:43 --> Config Class Initialized
INFO - 2023-04-03 08:49:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:43 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:43 --> URI Class Initialized
INFO - 2023-04-03 08:49:43 --> Router Class Initialized
INFO - 2023-04-03 08:49:43 --> Output Class Initialized
INFO - 2023-04-03 08:49:43 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:43 --> Input Class Initialized
INFO - 2023-04-03 08:49:43 --> Language Class Initialized
INFO - 2023-04-03 08:49:43 --> Loader Class Initialized
INFO - 2023-04-03 08:49:43 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:43 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:43 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:43 --> Total execution time: 0.0128
INFO - 2023-04-03 08:49:48 --> Config Class Initialized
INFO - 2023-04-03 08:49:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:48 --> URI Class Initialized
INFO - 2023-04-03 08:49:48 --> Router Class Initialized
INFO - 2023-04-03 08:49:48 --> Output Class Initialized
INFO - 2023-04-03 08:49:48 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:48 --> Input Class Initialized
INFO - 2023-04-03 08:49:48 --> Language Class Initialized
INFO - 2023-04-03 08:49:48 --> Loader Class Initialized
INFO - 2023-04-03 08:49:48 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:48 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:48 --> Total execution time: 0.0152
INFO - 2023-04-03 08:49:53 --> Config Class Initialized
INFO - 2023-04-03 08:49:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:53 --> URI Class Initialized
INFO - 2023-04-03 08:49:53 --> Router Class Initialized
INFO - 2023-04-03 08:49:53 --> Output Class Initialized
INFO - 2023-04-03 08:49:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:53 --> Input Class Initialized
INFO - 2023-04-03 08:49:53 --> Language Class Initialized
INFO - 2023-04-03 08:49:53 --> Loader Class Initialized
INFO - 2023-04-03 08:49:53 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:53 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:53 --> Total execution time: 0.0149
INFO - 2023-04-03 08:49:53 --> Config Class Initialized
INFO - 2023-04-03 08:49:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:53 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:53 --> URI Class Initialized
INFO - 2023-04-03 08:49:53 --> Router Class Initialized
INFO - 2023-04-03 08:49:53 --> Output Class Initialized
INFO - 2023-04-03 08:49:53 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:53 --> Input Class Initialized
INFO - 2023-04-03 08:49:53 --> Language Class Initialized
INFO - 2023-04-03 08:49:53 --> Loader Class Initialized
INFO - 2023-04-03 08:49:53 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:53 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:53 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:53 --> Total execution time: 0.0166
INFO - 2023-04-03 08:49:58 --> Config Class Initialized
INFO - 2023-04-03 08:49:58 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:49:58 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:49:58 --> Utf8 Class Initialized
INFO - 2023-04-03 08:49:58 --> URI Class Initialized
INFO - 2023-04-03 08:49:58 --> Router Class Initialized
INFO - 2023-04-03 08:49:58 --> Output Class Initialized
INFO - 2023-04-03 08:49:58 --> Security Class Initialized
DEBUG - 2023-04-03 08:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:49:58 --> Input Class Initialized
INFO - 2023-04-03 08:49:58 --> Language Class Initialized
INFO - 2023-04-03 08:49:58 --> Loader Class Initialized
INFO - 2023-04-03 08:49:58 --> Controller Class Initialized
DEBUG - 2023-04-03 08:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:49:58 --> Database Driver Class Initialized
INFO - 2023-04-03 08:49:58 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:49:58 --> Final output sent to browser
DEBUG - 2023-04-03 08:49:58 --> Total execution time: 0.0235
INFO - 2023-04-03 08:50:03 --> Config Class Initialized
INFO - 2023-04-03 08:50:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:03 --> URI Class Initialized
INFO - 2023-04-03 08:50:03 --> Router Class Initialized
INFO - 2023-04-03 08:50:03 --> Output Class Initialized
INFO - 2023-04-03 08:50:03 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:03 --> Input Class Initialized
INFO - 2023-04-03 08:50:03 --> Language Class Initialized
INFO - 2023-04-03 08:50:03 --> Loader Class Initialized
INFO - 2023-04-03 08:50:03 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:03 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:03 --> Total execution time: 0.0557
INFO - 2023-04-03 08:50:03 --> Config Class Initialized
INFO - 2023-04-03 08:50:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:03 --> URI Class Initialized
INFO - 2023-04-03 08:50:03 --> Router Class Initialized
INFO - 2023-04-03 08:50:03 --> Output Class Initialized
INFO - 2023-04-03 08:50:03 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:03 --> Input Class Initialized
INFO - 2023-04-03 08:50:03 --> Language Class Initialized
INFO - 2023-04-03 08:50:03 --> Loader Class Initialized
INFO - 2023-04-03 08:50:03 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:03 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:03 --> Total execution time: 0.0136
INFO - 2023-04-03 08:50:08 --> Config Class Initialized
INFO - 2023-04-03 08:50:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:08 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:08 --> URI Class Initialized
INFO - 2023-04-03 08:50:08 --> Router Class Initialized
INFO - 2023-04-03 08:50:08 --> Output Class Initialized
INFO - 2023-04-03 08:50:08 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:08 --> Input Class Initialized
INFO - 2023-04-03 08:50:08 --> Language Class Initialized
INFO - 2023-04-03 08:50:08 --> Loader Class Initialized
INFO - 2023-04-03 08:50:08 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:08 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:08 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:08 --> Total execution time: 0.0144
INFO - 2023-04-03 08:50:13 --> Config Class Initialized
INFO - 2023-04-03 08:50:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:13 --> URI Class Initialized
INFO - 2023-04-03 08:50:13 --> Router Class Initialized
INFO - 2023-04-03 08:50:13 --> Output Class Initialized
INFO - 2023-04-03 08:50:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:13 --> Input Class Initialized
INFO - 2023-04-03 08:50:13 --> Language Class Initialized
INFO - 2023-04-03 08:50:13 --> Loader Class Initialized
INFO - 2023-04-03 08:50:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:13 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:13 --> Total execution time: 0.0130
INFO - 2023-04-03 08:50:13 --> Config Class Initialized
INFO - 2023-04-03 08:50:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:13 --> URI Class Initialized
INFO - 2023-04-03 08:50:13 --> Router Class Initialized
INFO - 2023-04-03 08:50:13 --> Output Class Initialized
INFO - 2023-04-03 08:50:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:13 --> Input Class Initialized
INFO - 2023-04-03 08:50:13 --> Language Class Initialized
INFO - 2023-04-03 08:50:13 --> Loader Class Initialized
INFO - 2023-04-03 08:50:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:13 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:13 --> Total execution time: 0.0132
INFO - 2023-04-03 08:50:18 --> Config Class Initialized
INFO - 2023-04-03 08:50:18 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:18 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:18 --> URI Class Initialized
INFO - 2023-04-03 08:50:18 --> Router Class Initialized
INFO - 2023-04-03 08:50:18 --> Output Class Initialized
INFO - 2023-04-03 08:50:18 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:18 --> Input Class Initialized
INFO - 2023-04-03 08:50:18 --> Language Class Initialized
INFO - 2023-04-03 08:50:18 --> Loader Class Initialized
INFO - 2023-04-03 08:50:18 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:18 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:18 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:18 --> Total execution time: 0.0141
INFO - 2023-04-03 08:50:23 --> Config Class Initialized
INFO - 2023-04-03 08:50:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:23 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:23 --> URI Class Initialized
INFO - 2023-04-03 08:50:23 --> Router Class Initialized
INFO - 2023-04-03 08:50:23 --> Output Class Initialized
INFO - 2023-04-03 08:50:23 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:23 --> Input Class Initialized
INFO - 2023-04-03 08:50:23 --> Language Class Initialized
INFO - 2023-04-03 08:50:23 --> Loader Class Initialized
INFO - 2023-04-03 08:50:23 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:23 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:23 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:23 --> Total execution time: 0.0112
INFO - 2023-04-03 08:50:23 --> Config Class Initialized
INFO - 2023-04-03 08:50:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:23 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:23 --> URI Class Initialized
INFO - 2023-04-03 08:50:23 --> Router Class Initialized
INFO - 2023-04-03 08:50:23 --> Output Class Initialized
INFO - 2023-04-03 08:50:23 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:23 --> Input Class Initialized
INFO - 2023-04-03 08:50:23 --> Language Class Initialized
INFO - 2023-04-03 08:50:23 --> Loader Class Initialized
INFO - 2023-04-03 08:50:23 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:23 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:23 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:23 --> Total execution time: 0.0146
INFO - 2023-04-03 08:50:23 --> Config Class Initialized
INFO - 2023-04-03 08:50:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:23 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:23 --> URI Class Initialized
INFO - 2023-04-03 08:50:23 --> Router Class Initialized
INFO - 2023-04-03 08:50:23 --> Output Class Initialized
INFO - 2023-04-03 08:50:23 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:23 --> Input Class Initialized
INFO - 2023-04-03 08:50:23 --> Language Class Initialized
INFO - 2023-04-03 08:50:23 --> Loader Class Initialized
INFO - 2023-04-03 08:50:23 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:23 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:23 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:23 --> Total execution time: 0.0276
INFO - 2023-04-03 08:50:23 --> Config Class Initialized
INFO - 2023-04-03 08:50:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:50:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:50:23 --> Utf8 Class Initialized
INFO - 2023-04-03 08:50:23 --> URI Class Initialized
INFO - 2023-04-03 08:50:23 --> Router Class Initialized
INFO - 2023-04-03 08:50:23 --> Output Class Initialized
INFO - 2023-04-03 08:50:23 --> Security Class Initialized
DEBUG - 2023-04-03 08:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:50:23 --> Input Class Initialized
INFO - 2023-04-03 08:50:23 --> Language Class Initialized
INFO - 2023-04-03 08:50:23 --> Loader Class Initialized
INFO - 2023-04-03 08:50:23 --> Controller Class Initialized
DEBUG - 2023-04-03 08:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:50:23 --> Database Driver Class Initialized
INFO - 2023-04-03 08:50:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:50:23 --> Final output sent to browser
DEBUG - 2023-04-03 08:50:23 --> Total execution time: 0.0567
INFO - 2023-04-03 08:51:41 --> Config Class Initialized
INFO - 2023-04-03 08:51:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:51:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:51:41 --> Utf8 Class Initialized
INFO - 2023-04-03 08:51:41 --> URI Class Initialized
INFO - 2023-04-03 08:51:41 --> Router Class Initialized
INFO - 2023-04-03 08:51:41 --> Output Class Initialized
INFO - 2023-04-03 08:51:41 --> Security Class Initialized
DEBUG - 2023-04-03 08:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:51:41 --> Input Class Initialized
INFO - 2023-04-03 08:51:41 --> Language Class Initialized
INFO - 2023-04-03 08:51:41 --> Loader Class Initialized
INFO - 2023-04-03 08:51:41 --> Controller Class Initialized
DEBUG - 2023-04-03 08:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:51:41 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:51:41 --> Final output sent to browser
DEBUG - 2023-04-03 08:51:41 --> Total execution time: 0.1185
INFO - 2023-04-03 08:51:41 --> Config Class Initialized
INFO - 2023-04-03 08:51:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:51:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:51:41 --> Utf8 Class Initialized
INFO - 2023-04-03 08:51:41 --> URI Class Initialized
INFO - 2023-04-03 08:51:41 --> Router Class Initialized
INFO - 2023-04-03 08:51:41 --> Output Class Initialized
INFO - 2023-04-03 08:51:41 --> Security Class Initialized
DEBUG - 2023-04-03 08:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:51:41 --> Input Class Initialized
INFO - 2023-04-03 08:51:41 --> Language Class Initialized
INFO - 2023-04-03 08:51:41 --> Loader Class Initialized
INFO - 2023-04-03 08:51:41 --> Controller Class Initialized
DEBUG - 2023-04-03 08:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:51:41 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:51:41 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:41 --> Model "Login_model" initialized
INFO - 2023-04-03 08:51:41 --> Final output sent to browser
DEBUG - 2023-04-03 08:51:41 --> Total execution time: 0.0205
INFO - 2023-04-03 08:51:41 --> Config Class Initialized
INFO - 2023-04-03 08:51:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:51:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:51:41 --> Utf8 Class Initialized
INFO - 2023-04-03 08:51:41 --> URI Class Initialized
INFO - 2023-04-03 08:51:41 --> Router Class Initialized
INFO - 2023-04-03 08:51:41 --> Output Class Initialized
INFO - 2023-04-03 08:51:41 --> Security Class Initialized
DEBUG - 2023-04-03 08:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:51:41 --> Input Class Initialized
INFO - 2023-04-03 08:51:41 --> Language Class Initialized
INFO - 2023-04-03 08:51:41 --> Loader Class Initialized
INFO - 2023-04-03 08:51:41 --> Controller Class Initialized
DEBUG - 2023-04-03 08:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:51:41 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:51:41 --> Final output sent to browser
DEBUG - 2023-04-03 08:51:41 --> Total execution time: 0.0950
INFO - 2023-04-03 08:51:41 --> Config Class Initialized
INFO - 2023-04-03 08:51:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:51:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:51:41 --> Utf8 Class Initialized
INFO - 2023-04-03 08:51:41 --> URI Class Initialized
INFO - 2023-04-03 08:51:41 --> Router Class Initialized
INFO - 2023-04-03 08:51:41 --> Output Class Initialized
INFO - 2023-04-03 08:51:41 --> Security Class Initialized
DEBUG - 2023-04-03 08:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:51:41 --> Input Class Initialized
INFO - 2023-04-03 08:51:41 --> Language Class Initialized
INFO - 2023-04-03 08:51:41 --> Loader Class Initialized
INFO - 2023-04-03 08:51:41 --> Controller Class Initialized
DEBUG - 2023-04-03 08:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:51:41 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:51:41 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:41 --> Model "Login_model" initialized
INFO - 2023-04-03 08:51:41 --> Final output sent to browser
DEBUG - 2023-04-03 08:51:41 --> Total execution time: 0.0291
INFO - 2023-04-03 08:51:50 --> Config Class Initialized
INFO - 2023-04-03 08:51:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:51:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:51:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:51:50 --> URI Class Initialized
INFO - 2023-04-03 08:51:50 --> Router Class Initialized
INFO - 2023-04-03 08:51:50 --> Output Class Initialized
INFO - 2023-04-03 08:51:50 --> Security Class Initialized
DEBUG - 2023-04-03 08:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:51:50 --> Input Class Initialized
INFO - 2023-04-03 08:51:50 --> Language Class Initialized
INFO - 2023-04-03 08:51:50 --> Loader Class Initialized
INFO - 2023-04-03 08:51:50 --> Controller Class Initialized
DEBUG - 2023-04-03 08:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:51:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:51:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:50 --> Model "Login_model" initialized
INFO - 2023-04-03 08:51:50 --> Final output sent to browser
DEBUG - 2023-04-03 08:51:50 --> Total execution time: 0.0730
INFO - 2023-04-03 08:51:50 --> Config Class Initialized
INFO - 2023-04-03 08:51:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:51:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:51:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:51:50 --> URI Class Initialized
INFO - 2023-04-03 08:51:50 --> Router Class Initialized
INFO - 2023-04-03 08:51:50 --> Output Class Initialized
INFO - 2023-04-03 08:51:51 --> Security Class Initialized
DEBUG - 2023-04-03 08:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:51:51 --> Input Class Initialized
INFO - 2023-04-03 08:51:51 --> Language Class Initialized
INFO - 2023-04-03 08:51:51 --> Loader Class Initialized
INFO - 2023-04-03 08:51:51 --> Controller Class Initialized
DEBUG - 2023-04-03 08:51:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:51:51 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:51 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:51:51 --> Database Driver Class Initialized
INFO - 2023-04-03 08:51:51 --> Model "Login_model" initialized
INFO - 2023-04-03 08:51:51 --> Final output sent to browser
DEBUG - 2023-04-03 08:51:51 --> Total execution time: 0.4158
INFO - 2023-04-03 08:52:13 --> Config Class Initialized
INFO - 2023-04-03 08:52:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:13 --> URI Class Initialized
INFO - 2023-04-03 08:52:13 --> Router Class Initialized
INFO - 2023-04-03 08:52:13 --> Output Class Initialized
INFO - 2023-04-03 08:52:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:13 --> Input Class Initialized
INFO - 2023-04-03 08:52:13 --> Language Class Initialized
INFO - 2023-04-03 08:52:13 --> Loader Class Initialized
INFO - 2023-04-03 08:52:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:13 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:13 --> Total execution time: 0.0201
INFO - 2023-04-03 08:52:13 --> Config Class Initialized
INFO - 2023-04-03 08:52:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:13 --> URI Class Initialized
INFO - 2023-04-03 08:52:13 --> Router Class Initialized
INFO - 2023-04-03 08:52:13 --> Output Class Initialized
INFO - 2023-04-03 08:52:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:13 --> Input Class Initialized
INFO - 2023-04-03 08:52:13 --> Language Class Initialized
INFO - 2023-04-03 08:52:13 --> Loader Class Initialized
INFO - 2023-04-03 08:52:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:13 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:13 --> Total execution time: 0.0523
INFO - 2023-04-03 08:52:25 --> Config Class Initialized
INFO - 2023-04-03 08:52:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:25 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:25 --> URI Class Initialized
INFO - 2023-04-03 08:52:25 --> Router Class Initialized
INFO - 2023-04-03 08:52:25 --> Output Class Initialized
INFO - 2023-04-03 08:52:25 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:25 --> Input Class Initialized
INFO - 2023-04-03 08:52:25 --> Language Class Initialized
INFO - 2023-04-03 08:52:25 --> Loader Class Initialized
INFO - 2023-04-03 08:52:25 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:25 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:25 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:25 --> Total execution time: 0.0545
INFO - 2023-04-03 08:52:25 --> Config Class Initialized
INFO - 2023-04-03 08:52:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:25 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:25 --> URI Class Initialized
INFO - 2023-04-03 08:52:25 --> Router Class Initialized
INFO - 2023-04-03 08:52:25 --> Output Class Initialized
INFO - 2023-04-03 08:52:25 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:25 --> Input Class Initialized
INFO - 2023-04-03 08:52:25 --> Language Class Initialized
INFO - 2023-04-03 08:52:25 --> Loader Class Initialized
INFO - 2023-04-03 08:52:25 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:25 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:25 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:25 --> Total execution time: 0.0108
INFO - 2023-04-03 08:52:37 --> Config Class Initialized
INFO - 2023-04-03 08:52:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:37 --> URI Class Initialized
INFO - 2023-04-03 08:52:37 --> Router Class Initialized
INFO - 2023-04-03 08:52:37 --> Output Class Initialized
INFO - 2023-04-03 08:52:37 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:37 --> Input Class Initialized
INFO - 2023-04-03 08:52:37 --> Language Class Initialized
INFO - 2023-04-03 08:52:37 --> Loader Class Initialized
INFO - 2023-04-03 08:52:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:37 --> Total execution time: 0.0768
INFO - 2023-04-03 08:52:37 --> Config Class Initialized
INFO - 2023-04-03 08:52:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:37 --> URI Class Initialized
INFO - 2023-04-03 08:52:37 --> Router Class Initialized
INFO - 2023-04-03 08:52:37 --> Output Class Initialized
INFO - 2023-04-03 08:52:37 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:37 --> Input Class Initialized
INFO - 2023-04-03 08:52:37 --> Language Class Initialized
INFO - 2023-04-03 08:52:37 --> Loader Class Initialized
INFO - 2023-04-03 08:52:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:37 --> Total execution time: 0.0585
INFO - 2023-04-03 08:52:37 --> Config Class Initialized
INFO - 2023-04-03 08:52:37 --> Config Class Initialized
INFO - 2023-04-03 08:52:37 --> Hooks Class Initialized
INFO - 2023-04-03 08:52:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:52:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:37 --> URI Class Initialized
INFO - 2023-04-03 08:52:37 --> URI Class Initialized
INFO - 2023-04-03 08:52:37 --> Router Class Initialized
INFO - 2023-04-03 08:52:37 --> Router Class Initialized
INFO - 2023-04-03 08:52:37 --> Output Class Initialized
INFO - 2023-04-03 08:52:37 --> Output Class Initialized
INFO - 2023-04-03 08:52:37 --> Security Class Initialized
INFO - 2023-04-03 08:52:37 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:37 --> Input Class Initialized
INFO - 2023-04-03 08:52:37 --> Input Class Initialized
INFO - 2023-04-03 08:52:37 --> Language Class Initialized
INFO - 2023-04-03 08:52:37 --> Language Class Initialized
INFO - 2023-04-03 08:52:37 --> Loader Class Initialized
INFO - 2023-04-03 08:52:37 --> Loader Class Initialized
INFO - 2023-04-03 08:52:37 --> Controller Class Initialized
INFO - 2023-04-03 08:52:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:52:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:37 --> Total execution time: 0.0139
INFO - 2023-04-03 08:52:37 --> Final output sent to browser
INFO - 2023-04-03 08:52:37 --> Config Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Total execution time: 0.0157
INFO - 2023-04-03 08:52:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:37 --> URI Class Initialized
INFO - 2023-04-03 08:52:37 --> Config Class Initialized
INFO - 2023-04-03 08:52:37 --> Hooks Class Initialized
INFO - 2023-04-03 08:52:37 --> Router Class Initialized
DEBUG - 2023-04-03 08:52:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:37 --> Output Class Initialized
INFO - 2023-04-03 08:52:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:37 --> Security Class Initialized
INFO - 2023-04-03 08:52:37 --> URI Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:37 --> Input Class Initialized
INFO - 2023-04-03 08:52:37 --> Router Class Initialized
INFO - 2023-04-03 08:52:37 --> Language Class Initialized
INFO - 2023-04-03 08:52:37 --> Output Class Initialized
INFO - 2023-04-03 08:52:37 --> Security Class Initialized
INFO - 2023-04-03 08:52:37 --> Loader Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:37 --> Input Class Initialized
INFO - 2023-04-03 08:52:37 --> Controller Class Initialized
INFO - 2023-04-03 08:52:37 --> Language Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:37 --> Loader Class Initialized
INFO - 2023-04-03 08:52:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:37 --> Final output sent to browser
INFO - 2023-04-03 08:52:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:37 --> Total execution time: 0.0568
DEBUG - 2023-04-03 08:52:37 --> Total execution time: 0.0542
INFO - 2023-04-03 08:52:39 --> Config Class Initialized
INFO - 2023-04-03 08:52:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:39 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:39 --> URI Class Initialized
INFO - 2023-04-03 08:52:39 --> Router Class Initialized
INFO - 2023-04-03 08:52:39 --> Output Class Initialized
INFO - 2023-04-03 08:52:39 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:39 --> Input Class Initialized
INFO - 2023-04-03 08:52:39 --> Language Class Initialized
INFO - 2023-04-03 08:52:39 --> Loader Class Initialized
INFO - 2023-04-03 08:52:39 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:39 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:39 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:39 --> Total execution time: 0.0226
INFO - 2023-04-03 08:52:39 --> Config Class Initialized
INFO - 2023-04-03 08:52:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:39 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:39 --> URI Class Initialized
INFO - 2023-04-03 08:52:39 --> Router Class Initialized
INFO - 2023-04-03 08:52:39 --> Output Class Initialized
INFO - 2023-04-03 08:52:39 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:39 --> Input Class Initialized
INFO - 2023-04-03 08:52:39 --> Language Class Initialized
INFO - 2023-04-03 08:52:39 --> Loader Class Initialized
INFO - 2023-04-03 08:52:39 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:39 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:39 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:39 --> Total execution time: 0.0198
INFO - 2023-04-03 08:52:42 --> Config Class Initialized
INFO - 2023-04-03 08:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:42 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:42 --> URI Class Initialized
INFO - 2023-04-03 08:52:42 --> Router Class Initialized
INFO - 2023-04-03 08:52:42 --> Output Class Initialized
INFO - 2023-04-03 08:52:42 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:42 --> Input Class Initialized
INFO - 2023-04-03 08:52:42 --> Language Class Initialized
INFO - 2023-04-03 08:52:42 --> Loader Class Initialized
INFO - 2023-04-03 08:52:42 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:42 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:42 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:42 --> Total execution time: 0.0178
INFO - 2023-04-03 08:52:42 --> Config Class Initialized
INFO - 2023-04-03 08:52:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:42 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:42 --> URI Class Initialized
INFO - 2023-04-03 08:52:42 --> Router Class Initialized
INFO - 2023-04-03 08:52:42 --> Output Class Initialized
INFO - 2023-04-03 08:52:42 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:42 --> Input Class Initialized
INFO - 2023-04-03 08:52:42 --> Language Class Initialized
INFO - 2023-04-03 08:52:42 --> Loader Class Initialized
INFO - 2023-04-03 08:52:42 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:42 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:42 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:42 --> Total execution time: 0.0524
INFO - 2023-04-03 08:52:43 --> Config Class Initialized
INFO - 2023-04-03 08:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:43 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:43 --> URI Class Initialized
INFO - 2023-04-03 08:52:43 --> Router Class Initialized
INFO - 2023-04-03 08:52:43 --> Output Class Initialized
INFO - 2023-04-03 08:52:43 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:43 --> Input Class Initialized
INFO - 2023-04-03 08:52:43 --> Language Class Initialized
INFO - 2023-04-03 08:52:43 --> Loader Class Initialized
INFO - 2023-04-03 08:52:43 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:43 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:43 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:43 --> Total execution time: 0.0195
INFO - 2023-04-03 08:52:43 --> Config Class Initialized
INFO - 2023-04-03 08:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:43 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:43 --> URI Class Initialized
INFO - 2023-04-03 08:52:43 --> Router Class Initialized
INFO - 2023-04-03 08:52:43 --> Output Class Initialized
INFO - 2023-04-03 08:52:43 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:43 --> Input Class Initialized
INFO - 2023-04-03 08:52:43 --> Language Class Initialized
INFO - 2023-04-03 08:52:43 --> Loader Class Initialized
INFO - 2023-04-03 08:52:43 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:43 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:43 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:43 --> Total execution time: 0.0168
INFO - 2023-04-03 08:52:47 --> Config Class Initialized
INFO - 2023-04-03 08:52:47 --> Config Class Initialized
INFO - 2023-04-03 08:52:47 --> Hooks Class Initialized
INFO - 2023-04-03 08:52:47 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:52:47 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:47 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:47 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:47 --> URI Class Initialized
INFO - 2023-04-03 08:52:47 --> URI Class Initialized
INFO - 2023-04-03 08:52:47 --> Router Class Initialized
INFO - 2023-04-03 08:52:47 --> Router Class Initialized
INFO - 2023-04-03 08:52:47 --> Output Class Initialized
INFO - 2023-04-03 08:52:47 --> Output Class Initialized
INFO - 2023-04-03 08:52:47 --> Security Class Initialized
INFO - 2023-04-03 08:52:47 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:47 --> Input Class Initialized
INFO - 2023-04-03 08:52:47 --> Input Class Initialized
INFO - 2023-04-03 08:52:47 --> Language Class Initialized
INFO - 2023-04-03 08:52:47 --> Language Class Initialized
INFO - 2023-04-03 08:52:47 --> Loader Class Initialized
INFO - 2023-04-03 08:52:47 --> Loader Class Initialized
INFO - 2023-04-03 08:52:47 --> Controller Class Initialized
INFO - 2023-04-03 08:52:47 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:47 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:47 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:47 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:47 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:47 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:47 --> Total execution time: 0.0400
INFO - 2023-04-03 08:52:47 --> Config Class Initialized
INFO - 2023-04-03 08:52:47 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:47 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:47 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:47 --> URI Class Initialized
INFO - 2023-04-03 08:52:47 --> Router Class Initialized
INFO - 2023-04-03 08:52:47 --> Output Class Initialized
INFO - 2023-04-03 08:52:47 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:47 --> Input Class Initialized
INFO - 2023-04-03 08:52:47 --> Language Class Initialized
INFO - 2023-04-03 08:52:47 --> Loader Class Initialized
INFO - 2023-04-03 08:52:47 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:47 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:47 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:47 --> Final output sent to browser
DEBUG - 2023-04-03 08:52:47 --> Total execution time: 0.0494
INFO - 2023-04-03 08:52:47 --> Config Class Initialized
INFO - 2023-04-03 08:52:47 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:47 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:47 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:47 --> URI Class Initialized
INFO - 2023-04-03 08:52:47 --> Router Class Initialized
INFO - 2023-04-03 08:52:47 --> Output Class Initialized
INFO - 2023-04-03 08:52:47 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:47 --> Input Class Initialized
INFO - 2023-04-03 08:52:47 --> Language Class Initialized
INFO - 2023-04-03 08:52:47 --> Loader Class Initialized
INFO - 2023-04-03 08:52:47 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:47 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:47 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:54 --> Config Class Initialized
INFO - 2023-04-03 08:52:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:54 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:54 --> URI Class Initialized
INFO - 2023-04-03 08:52:54 --> Router Class Initialized
INFO - 2023-04-03 08:52:54 --> Output Class Initialized
INFO - 2023-04-03 08:52:54 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:54 --> Input Class Initialized
INFO - 2023-04-03 08:52:54 --> Language Class Initialized
INFO - 2023-04-03 08:52:54 --> Loader Class Initialized
INFO - 2023-04-03 08:52:54 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:54 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:52:54 --> Config Class Initialized
INFO - 2023-04-03 08:52:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:52:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:52:54 --> Utf8 Class Initialized
INFO - 2023-04-03 08:52:54 --> URI Class Initialized
INFO - 2023-04-03 08:52:54 --> Router Class Initialized
INFO - 2023-04-03 08:52:54 --> Output Class Initialized
INFO - 2023-04-03 08:52:54 --> Security Class Initialized
DEBUG - 2023-04-03 08:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:52:54 --> Input Class Initialized
INFO - 2023-04-03 08:52:54 --> Language Class Initialized
INFO - 2023-04-03 08:52:54 --> Loader Class Initialized
INFO - 2023-04-03 08:52:54 --> Controller Class Initialized
DEBUG - 2023-04-03 08:52:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:52:54 --> Database Driver Class Initialized
INFO - 2023-04-03 08:52:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:03 --> Config Class Initialized
INFO - 2023-04-03 08:53:03 --> Hooks Class Initialized
INFO - 2023-04-03 08:53:03 --> Config Class Initialized
INFO - 2023-04-03 08:53:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:53:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:03 --> URI Class Initialized
INFO - 2023-04-03 08:53:03 --> URI Class Initialized
INFO - 2023-04-03 08:53:03 --> Router Class Initialized
INFO - 2023-04-03 08:53:03 --> Router Class Initialized
INFO - 2023-04-03 08:53:03 --> Output Class Initialized
INFO - 2023-04-03 08:53:03 --> Output Class Initialized
INFO - 2023-04-03 08:53:03 --> Security Class Initialized
INFO - 2023-04-03 08:53:03 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:03 --> Input Class Initialized
INFO - 2023-04-03 08:53:03 --> Input Class Initialized
INFO - 2023-04-03 08:53:03 --> Language Class Initialized
INFO - 2023-04-03 08:53:03 --> Language Class Initialized
INFO - 2023-04-03 08:53:03 --> Loader Class Initialized
INFO - 2023-04-03 08:53:03 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:03 --> Loader Class Initialized
INFO - 2023-04-03 08:53:03 --> Controller Class Initialized
INFO - 2023-04-03 08:53:03 --> Database Driver Class Initialized
DEBUG - 2023-04-03 08:53:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:03 --> Final output sent to browser
DEBUG - 2023-04-03 08:53:03 --> Total execution time: 0.0170
INFO - 2023-04-03 08:53:03 --> Config Class Initialized
INFO - 2023-04-03 08:53:03 --> Config Class Initialized
INFO - 2023-04-03 08:53:03 --> Hooks Class Initialized
INFO - 2023-04-03 08:53:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:03 --> Utf8 Class Initialized
DEBUG - 2023-04-03 08:53:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:03 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:03 --> URI Class Initialized
INFO - 2023-04-03 08:53:03 --> URI Class Initialized
INFO - 2023-04-03 08:53:03 --> Router Class Initialized
INFO - 2023-04-03 08:53:03 --> Router Class Initialized
INFO - 2023-04-03 08:53:03 --> Output Class Initialized
INFO - 2023-04-03 08:53:03 --> Output Class Initialized
INFO - 2023-04-03 08:53:03 --> Security Class Initialized
INFO - 2023-04-03 08:53:03 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:03 --> Input Class Initialized
INFO - 2023-04-03 08:53:03 --> Input Class Initialized
INFO - 2023-04-03 08:53:03 --> Language Class Initialized
INFO - 2023-04-03 08:53:03 --> Language Class Initialized
INFO - 2023-04-03 08:53:03 --> Loader Class Initialized
INFO - 2023-04-03 08:53:03 --> Loader Class Initialized
INFO - 2023-04-03 08:53:03 --> Controller Class Initialized
INFO - 2023-04-03 08:53:03 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:53:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:03 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:03 --> Final output sent to browser
DEBUG - 2023-04-03 08:53:03 --> Total execution time: 0.0934
INFO - 2023-04-03 08:53:11 --> Config Class Initialized
INFO - 2023-04-03 08:53:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:11 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:11 --> URI Class Initialized
INFO - 2023-04-03 08:53:11 --> Router Class Initialized
INFO - 2023-04-03 08:53:11 --> Output Class Initialized
INFO - 2023-04-03 08:53:11 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:11 --> Input Class Initialized
INFO - 2023-04-03 08:53:11 --> Language Class Initialized
INFO - 2023-04-03 08:53:11 --> Loader Class Initialized
INFO - 2023-04-03 08:53:11 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:11 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:11 --> Config Class Initialized
INFO - 2023-04-03 08:53:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:11 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:11 --> URI Class Initialized
INFO - 2023-04-03 08:53:11 --> Router Class Initialized
INFO - 2023-04-03 08:53:11 --> Output Class Initialized
INFO - 2023-04-03 08:53:11 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:11 --> Input Class Initialized
INFO - 2023-04-03 08:53:11 --> Language Class Initialized
INFO - 2023-04-03 08:53:11 --> Loader Class Initialized
INFO - 2023-04-03 08:53:11 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:11 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:13 --> Config Class Initialized
INFO - 2023-04-03 08:53:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:13 --> URI Class Initialized
INFO - 2023-04-03 08:53:13 --> Router Class Initialized
INFO - 2023-04-03 08:53:13 --> Output Class Initialized
INFO - 2023-04-03 08:53:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:13 --> Input Class Initialized
INFO - 2023-04-03 08:53:13 --> Language Class Initialized
INFO - 2023-04-03 08:53:13 --> Loader Class Initialized
INFO - 2023-04-03 08:53:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:13 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:53:13 --> Total execution time: 0.0147
INFO - 2023-04-03 08:53:13 --> Config Class Initialized
INFO - 2023-04-03 08:53:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:13 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:13 --> URI Class Initialized
INFO - 2023-04-03 08:53:13 --> Router Class Initialized
INFO - 2023-04-03 08:53:13 --> Output Class Initialized
INFO - 2023-04-03 08:53:13 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:13 --> Input Class Initialized
INFO - 2023-04-03 08:53:13 --> Language Class Initialized
INFO - 2023-04-03 08:53:13 --> Loader Class Initialized
INFO - 2023-04-03 08:53:13 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:13 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:13 --> Final output sent to browser
DEBUG - 2023-04-03 08:53:13 --> Total execution time: 0.0385
INFO - 2023-04-03 08:53:24 --> Config Class Initialized
INFO - 2023-04-03 08:53:24 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:24 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:24 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:24 --> URI Class Initialized
INFO - 2023-04-03 08:53:24 --> Router Class Initialized
INFO - 2023-04-03 08:53:24 --> Output Class Initialized
INFO - 2023-04-03 08:53:24 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:24 --> Input Class Initialized
INFO - 2023-04-03 08:53:24 --> Language Class Initialized
INFO - 2023-04-03 08:53:24 --> Loader Class Initialized
INFO - 2023-04-03 08:53:24 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:24 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:24 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:24 --> Final output sent to browser
DEBUG - 2023-04-03 08:53:24 --> Total execution time: 0.0137
INFO - 2023-04-03 08:53:24 --> Config Class Initialized
INFO - 2023-04-03 08:53:24 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:24 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:24 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:24 --> URI Class Initialized
INFO - 2023-04-03 08:53:24 --> Router Class Initialized
INFO - 2023-04-03 08:53:24 --> Output Class Initialized
INFO - 2023-04-03 08:53:24 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:24 --> Input Class Initialized
INFO - 2023-04-03 08:53:24 --> Language Class Initialized
INFO - 2023-04-03 08:53:24 --> Loader Class Initialized
INFO - 2023-04-03 08:53:24 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:24 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:24 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:24 --> Final output sent to browser
DEBUG - 2023-04-03 08:53:24 --> Total execution time: 0.0103
INFO - 2023-04-03 08:53:50 --> Config Class Initialized
INFO - 2023-04-03 08:53:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:50 --> URI Class Initialized
INFO - 2023-04-03 08:53:50 --> Router Class Initialized
INFO - 2023-04-03 08:53:50 --> Output Class Initialized
INFO - 2023-04-03 08:53:50 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:50 --> Input Class Initialized
INFO - 2023-04-03 08:53:50 --> Language Class Initialized
INFO - 2023-04-03 08:53:50 --> Loader Class Initialized
INFO - 2023-04-03 08:53:50 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:50 --> Final output sent to browser
DEBUG - 2023-04-03 08:53:50 --> Total execution time: 0.0150
INFO - 2023-04-03 08:53:50 --> Config Class Initialized
INFO - 2023-04-03 08:53:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:53:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:53:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:53:50 --> URI Class Initialized
INFO - 2023-04-03 08:53:50 --> Router Class Initialized
INFO - 2023-04-03 08:53:50 --> Output Class Initialized
INFO - 2023-04-03 08:53:50 --> Security Class Initialized
DEBUG - 2023-04-03 08:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:53:50 --> Input Class Initialized
INFO - 2023-04-03 08:53:50 --> Language Class Initialized
INFO - 2023-04-03 08:53:50 --> Loader Class Initialized
INFO - 2023-04-03 08:53:50 --> Controller Class Initialized
DEBUG - 2023-04-03 08:53:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:53:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:53:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:53:50 --> Final output sent to browser
DEBUG - 2023-04-03 08:53:50 --> Total execution time: 0.0114
INFO - 2023-04-03 08:56:38 --> Config Class Initialized
INFO - 2023-04-03 08:56:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:38 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:38 --> URI Class Initialized
INFO - 2023-04-03 08:56:38 --> Router Class Initialized
INFO - 2023-04-03 08:56:38 --> Output Class Initialized
INFO - 2023-04-03 08:56:38 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:38 --> Input Class Initialized
INFO - 2023-04-03 08:56:38 --> Language Class Initialized
INFO - 2023-04-03 08:56:38 --> Loader Class Initialized
INFO - 2023-04-03 08:56:38 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:38 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:38 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:38 --> Total execution time: 0.0150
INFO - 2023-04-03 08:56:38 --> Config Class Initialized
INFO - 2023-04-03 08:56:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:38 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:38 --> URI Class Initialized
INFO - 2023-04-03 08:56:38 --> Router Class Initialized
INFO - 2023-04-03 08:56:38 --> Output Class Initialized
INFO - 2023-04-03 08:56:38 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:38 --> Input Class Initialized
INFO - 2023-04-03 08:56:38 --> Language Class Initialized
INFO - 2023-04-03 08:56:38 --> Loader Class Initialized
INFO - 2023-04-03 08:56:38 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:38 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:38 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:38 --> Model "Login_model" initialized
INFO - 2023-04-03 08:56:38 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:38 --> Total execution time: 0.0828
INFO - 2023-04-03 08:56:38 --> Config Class Initialized
INFO - 2023-04-03 08:56:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:39 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:39 --> URI Class Initialized
INFO - 2023-04-03 08:56:39 --> Router Class Initialized
INFO - 2023-04-03 08:56:39 --> Output Class Initialized
INFO - 2023-04-03 08:56:39 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:39 --> Input Class Initialized
INFO - 2023-04-03 08:56:39 --> Language Class Initialized
INFO - 2023-04-03 08:56:39 --> Loader Class Initialized
INFO - 2023-04-03 08:56:39 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:39 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:39 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:39 --> Total execution time: 0.0496
INFO - 2023-04-03 08:56:39 --> Config Class Initialized
INFO - 2023-04-03 08:56:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:39 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:39 --> URI Class Initialized
INFO - 2023-04-03 08:56:39 --> Router Class Initialized
INFO - 2023-04-03 08:56:39 --> Output Class Initialized
INFO - 2023-04-03 08:56:39 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:39 --> Input Class Initialized
INFO - 2023-04-03 08:56:39 --> Language Class Initialized
INFO - 2023-04-03 08:56:39 --> Loader Class Initialized
INFO - 2023-04-03 08:56:39 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:39 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:39 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:39 --> Model "Login_model" initialized
INFO - 2023-04-03 08:56:39 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:39 --> Total execution time: 0.0244
INFO - 2023-04-03 08:56:41 --> Config Class Initialized
INFO - 2023-04-03 08:56:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:41 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:41 --> URI Class Initialized
INFO - 2023-04-03 08:56:41 --> Router Class Initialized
INFO - 2023-04-03 08:56:41 --> Output Class Initialized
INFO - 2023-04-03 08:56:41 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:41 --> Input Class Initialized
INFO - 2023-04-03 08:56:41 --> Language Class Initialized
INFO - 2023-04-03 08:56:41 --> Loader Class Initialized
INFO - 2023-04-03 08:56:41 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:41 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:41 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:41 --> Model "Login_model" initialized
INFO - 2023-04-03 08:56:41 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:41 --> Total execution time: 0.0851
INFO - 2023-04-03 08:56:41 --> Config Class Initialized
INFO - 2023-04-03 08:56:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:42 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:42 --> URI Class Initialized
INFO - 2023-04-03 08:56:42 --> Router Class Initialized
INFO - 2023-04-03 08:56:42 --> Output Class Initialized
INFO - 2023-04-03 08:56:42 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:42 --> Input Class Initialized
INFO - 2023-04-03 08:56:42 --> Language Class Initialized
INFO - 2023-04-03 08:56:42 --> Loader Class Initialized
INFO - 2023-04-03 08:56:42 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:42 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:42 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:42 --> Model "Login_model" initialized
INFO - 2023-04-03 08:56:42 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:42 --> Total execution time: 0.0996
INFO - 2023-04-03 08:56:49 --> Config Class Initialized
INFO - 2023-04-03 08:56:49 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:49 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:49 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:49 --> URI Class Initialized
INFO - 2023-04-03 08:56:49 --> Router Class Initialized
INFO - 2023-04-03 08:56:49 --> Output Class Initialized
INFO - 2023-04-03 08:56:49 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:49 --> Input Class Initialized
INFO - 2023-04-03 08:56:49 --> Language Class Initialized
INFO - 2023-04-03 08:56:49 --> Loader Class Initialized
INFO - 2023-04-03 08:56:49 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:49 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:49 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:49 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:49 --> Total execution time: 0.0132
INFO - 2023-04-03 08:56:49 --> Config Class Initialized
INFO - 2023-04-03 08:56:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:50 --> URI Class Initialized
INFO - 2023-04-03 08:56:50 --> Router Class Initialized
INFO - 2023-04-03 08:56:50 --> Output Class Initialized
INFO - 2023-04-03 08:56:50 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:50 --> Input Class Initialized
INFO - 2023-04-03 08:56:50 --> Language Class Initialized
INFO - 2023-04-03 08:56:50 --> Loader Class Initialized
INFO - 2023-04-03 08:56:50 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:50 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:50 --> Total execution time: 0.0589
INFO - 2023-04-03 08:56:50 --> Config Class Initialized
INFO - 2023-04-03 08:56:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:50 --> URI Class Initialized
INFO - 2023-04-03 08:56:50 --> Router Class Initialized
INFO - 2023-04-03 08:56:50 --> Output Class Initialized
INFO - 2023-04-03 08:56:50 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:50 --> Input Class Initialized
INFO - 2023-04-03 08:56:50 --> Language Class Initialized
INFO - 2023-04-03 08:56:50 --> Loader Class Initialized
INFO - 2023-04-03 08:56:50 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:50 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:50 --> Total execution time: 0.0527
INFO - 2023-04-03 08:56:50 --> Config Class Initialized
INFO - 2023-04-03 08:56:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:56:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:56:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:56:50 --> URI Class Initialized
INFO - 2023-04-03 08:56:50 --> Router Class Initialized
INFO - 2023-04-03 08:56:50 --> Output Class Initialized
INFO - 2023-04-03 08:56:50 --> Security Class Initialized
DEBUG - 2023-04-03 08:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:56:50 --> Input Class Initialized
INFO - 2023-04-03 08:56:50 --> Language Class Initialized
INFO - 2023-04-03 08:56:50 --> Loader Class Initialized
INFO - 2023-04-03 08:56:50 --> Controller Class Initialized
DEBUG - 2023-04-03 08:56:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:56:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:56:50 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:56:50 --> Final output sent to browser
DEBUG - 2023-04-03 08:56:50 --> Total execution time: 0.0501
INFO - 2023-04-03 08:57:22 --> Config Class Initialized
INFO - 2023-04-03 08:57:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:22 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:22 --> URI Class Initialized
INFO - 2023-04-03 08:57:22 --> Router Class Initialized
INFO - 2023-04-03 08:57:22 --> Output Class Initialized
INFO - 2023-04-03 08:57:22 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:22 --> Input Class Initialized
INFO - 2023-04-03 08:57:22 --> Language Class Initialized
INFO - 2023-04-03 08:57:22 --> Loader Class Initialized
INFO - 2023-04-03 08:57:22 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:22 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:22 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:22 --> Total execution time: 0.0117
INFO - 2023-04-03 08:57:22 --> Config Class Initialized
INFO - 2023-04-03 08:57:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:22 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:22 --> URI Class Initialized
INFO - 2023-04-03 08:57:22 --> Router Class Initialized
INFO - 2023-04-03 08:57:22 --> Output Class Initialized
INFO - 2023-04-03 08:57:22 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:22 --> Input Class Initialized
INFO - 2023-04-03 08:57:22 --> Language Class Initialized
INFO - 2023-04-03 08:57:22 --> Loader Class Initialized
INFO - 2023-04-03 08:57:22 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:22 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:22 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:22 --> Model "Login_model" initialized
INFO - 2023-04-03 08:57:22 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:22 --> Total execution time: 0.0277
INFO - 2023-04-03 08:57:22 --> Config Class Initialized
INFO - 2023-04-03 08:57:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:22 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:22 --> URI Class Initialized
INFO - 2023-04-03 08:57:22 --> Router Class Initialized
INFO - 2023-04-03 08:57:22 --> Output Class Initialized
INFO - 2023-04-03 08:57:22 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:22 --> Input Class Initialized
INFO - 2023-04-03 08:57:22 --> Language Class Initialized
INFO - 2023-04-03 08:57:22 --> Loader Class Initialized
INFO - 2023-04-03 08:57:22 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:22 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:22 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:22 --> Total execution time: 0.0108
INFO - 2023-04-03 08:57:22 --> Config Class Initialized
INFO - 2023-04-03 08:57:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:22 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:22 --> URI Class Initialized
INFO - 2023-04-03 08:57:22 --> Router Class Initialized
INFO - 2023-04-03 08:57:22 --> Output Class Initialized
INFO - 2023-04-03 08:57:22 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:22 --> Input Class Initialized
INFO - 2023-04-03 08:57:22 --> Language Class Initialized
INFO - 2023-04-03 08:57:22 --> Loader Class Initialized
INFO - 2023-04-03 08:57:22 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:22 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:22 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:22 --> Total execution time: 0.0189
INFO - 2023-04-03 08:57:27 --> Config Class Initialized
INFO - 2023-04-03 08:57:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:27 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:27 --> URI Class Initialized
INFO - 2023-04-03 08:57:27 --> Router Class Initialized
INFO - 2023-04-03 08:57:27 --> Output Class Initialized
INFO - 2023-04-03 08:57:27 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:27 --> Input Class Initialized
INFO - 2023-04-03 08:57:27 --> Language Class Initialized
INFO - 2023-04-03 08:57:27 --> Loader Class Initialized
INFO - 2023-04-03 08:57:27 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:27 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:27 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:27 --> Total execution time: 0.0158
INFO - 2023-04-03 08:57:32 --> Config Class Initialized
INFO - 2023-04-03 08:57:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:32 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:32 --> URI Class Initialized
INFO - 2023-04-03 08:57:32 --> Router Class Initialized
INFO - 2023-04-03 08:57:32 --> Output Class Initialized
INFO - 2023-04-03 08:57:32 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:32 --> Input Class Initialized
INFO - 2023-04-03 08:57:32 --> Language Class Initialized
INFO - 2023-04-03 08:57:32 --> Loader Class Initialized
INFO - 2023-04-03 08:57:32 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:32 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:32 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:32 --> Total execution time: 0.0104
INFO - 2023-04-03 08:57:32 --> Config Class Initialized
INFO - 2023-04-03 08:57:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:32 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:32 --> URI Class Initialized
INFO - 2023-04-03 08:57:32 --> Router Class Initialized
INFO - 2023-04-03 08:57:32 --> Output Class Initialized
INFO - 2023-04-03 08:57:32 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:32 --> Input Class Initialized
INFO - 2023-04-03 08:57:32 --> Language Class Initialized
INFO - 2023-04-03 08:57:32 --> Loader Class Initialized
INFO - 2023-04-03 08:57:32 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:32 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:32 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:32 --> Total execution time: 0.0167
INFO - 2023-04-03 08:57:37 --> Config Class Initialized
INFO - 2023-04-03 08:57:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:37 --> URI Class Initialized
INFO - 2023-04-03 08:57:37 --> Router Class Initialized
INFO - 2023-04-03 08:57:37 --> Output Class Initialized
INFO - 2023-04-03 08:57:37 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:37 --> Input Class Initialized
INFO - 2023-04-03 08:57:37 --> Language Class Initialized
INFO - 2023-04-03 08:57:37 --> Loader Class Initialized
INFO - 2023-04-03 08:57:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:37 --> Total execution time: 0.0187
INFO - 2023-04-03 08:57:42 --> Config Class Initialized
INFO - 2023-04-03 08:57:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:42 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:42 --> URI Class Initialized
INFO - 2023-04-03 08:57:42 --> Router Class Initialized
INFO - 2023-04-03 08:57:42 --> Output Class Initialized
INFO - 2023-04-03 08:57:42 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:42 --> Input Class Initialized
INFO - 2023-04-03 08:57:42 --> Language Class Initialized
INFO - 2023-04-03 08:57:42 --> Loader Class Initialized
INFO - 2023-04-03 08:57:42 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:42 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:42 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:42 --> Total execution time: 0.0461
INFO - 2023-04-03 08:57:42 --> Config Class Initialized
INFO - 2023-04-03 08:57:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:42 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:42 --> URI Class Initialized
INFO - 2023-04-03 08:57:42 --> Router Class Initialized
INFO - 2023-04-03 08:57:42 --> Output Class Initialized
INFO - 2023-04-03 08:57:42 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:42 --> Input Class Initialized
INFO - 2023-04-03 08:57:42 --> Language Class Initialized
INFO - 2023-04-03 08:57:42 --> Loader Class Initialized
INFO - 2023-04-03 08:57:42 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:42 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:42 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:42 --> Total execution time: 0.0122
INFO - 2023-04-03 08:57:47 --> Config Class Initialized
INFO - 2023-04-03 08:57:47 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:47 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:47 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:47 --> URI Class Initialized
INFO - 2023-04-03 08:57:47 --> Router Class Initialized
INFO - 2023-04-03 08:57:47 --> Output Class Initialized
INFO - 2023-04-03 08:57:47 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:47 --> Input Class Initialized
INFO - 2023-04-03 08:57:47 --> Language Class Initialized
INFO - 2023-04-03 08:57:47 --> Loader Class Initialized
INFO - 2023-04-03 08:57:47 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:47 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:47 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:47 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:47 --> Total execution time: 0.0166
INFO - 2023-04-03 08:57:52 --> Config Class Initialized
INFO - 2023-04-03 08:57:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:52 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:52 --> URI Class Initialized
INFO - 2023-04-03 08:57:52 --> Router Class Initialized
INFO - 2023-04-03 08:57:52 --> Output Class Initialized
INFO - 2023-04-03 08:57:52 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:52 --> Input Class Initialized
INFO - 2023-04-03 08:57:52 --> Language Class Initialized
INFO - 2023-04-03 08:57:52 --> Loader Class Initialized
INFO - 2023-04-03 08:57:52 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:52 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:52 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:52 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:52 --> Total execution time: 0.0142
INFO - 2023-04-03 08:57:52 --> Config Class Initialized
INFO - 2023-04-03 08:57:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:52 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:52 --> URI Class Initialized
INFO - 2023-04-03 08:57:52 --> Router Class Initialized
INFO - 2023-04-03 08:57:52 --> Output Class Initialized
INFO - 2023-04-03 08:57:52 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:52 --> Input Class Initialized
INFO - 2023-04-03 08:57:52 --> Language Class Initialized
INFO - 2023-04-03 08:57:52 --> Loader Class Initialized
INFO - 2023-04-03 08:57:52 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:52 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:52 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:52 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:52 --> Total execution time: 0.0123
INFO - 2023-04-03 08:57:57 --> Config Class Initialized
INFO - 2023-04-03 08:57:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:57:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:57:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:57:57 --> URI Class Initialized
INFO - 2023-04-03 08:57:57 --> Router Class Initialized
INFO - 2023-04-03 08:57:57 --> Output Class Initialized
INFO - 2023-04-03 08:57:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:57:57 --> Input Class Initialized
INFO - 2023-04-03 08:57:57 --> Language Class Initialized
INFO - 2023-04-03 08:57:57 --> Loader Class Initialized
INFO - 2023-04-03 08:57:57 --> Controller Class Initialized
DEBUG - 2023-04-03 08:57:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:57:57 --> Database Driver Class Initialized
INFO - 2023-04-03 08:57:57 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:57:57 --> Final output sent to browser
DEBUG - 2023-04-03 08:57:57 --> Total execution time: 0.0164
INFO - 2023-04-03 08:58:02 --> Config Class Initialized
INFO - 2023-04-03 08:58:02 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:02 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:02 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:02 --> URI Class Initialized
INFO - 2023-04-03 08:58:02 --> Router Class Initialized
INFO - 2023-04-03 08:58:02 --> Output Class Initialized
INFO - 2023-04-03 08:58:02 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:02 --> Input Class Initialized
INFO - 2023-04-03 08:58:02 --> Language Class Initialized
INFO - 2023-04-03 08:58:02 --> Loader Class Initialized
INFO - 2023-04-03 08:58:02 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:02 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:02 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:02 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:02 --> Total execution time: 0.0124
INFO - 2023-04-03 08:58:02 --> Config Class Initialized
INFO - 2023-04-03 08:58:02 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:02 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:02 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:02 --> URI Class Initialized
INFO - 2023-04-03 08:58:02 --> Router Class Initialized
INFO - 2023-04-03 08:58:02 --> Output Class Initialized
INFO - 2023-04-03 08:58:02 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:02 --> Input Class Initialized
INFO - 2023-04-03 08:58:02 --> Language Class Initialized
INFO - 2023-04-03 08:58:02 --> Loader Class Initialized
INFO - 2023-04-03 08:58:02 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:02 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:02 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:02 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:02 --> Total execution time: 0.0135
INFO - 2023-04-03 08:58:07 --> Config Class Initialized
INFO - 2023-04-03 08:58:07 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:07 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:07 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:07 --> URI Class Initialized
INFO - 2023-04-03 08:58:07 --> Router Class Initialized
INFO - 2023-04-03 08:58:07 --> Output Class Initialized
INFO - 2023-04-03 08:58:07 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:07 --> Input Class Initialized
INFO - 2023-04-03 08:58:07 --> Language Class Initialized
INFO - 2023-04-03 08:58:07 --> Loader Class Initialized
INFO - 2023-04-03 08:58:07 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:07 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:07 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:07 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:07 --> Total execution time: 0.0144
INFO - 2023-04-03 08:58:12 --> Config Class Initialized
INFO - 2023-04-03 08:58:12 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:12 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:12 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:12 --> URI Class Initialized
INFO - 2023-04-03 08:58:12 --> Router Class Initialized
INFO - 2023-04-03 08:58:12 --> Output Class Initialized
INFO - 2023-04-03 08:58:12 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:12 --> Input Class Initialized
INFO - 2023-04-03 08:58:12 --> Language Class Initialized
INFO - 2023-04-03 08:58:12 --> Loader Class Initialized
INFO - 2023-04-03 08:58:12 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:12 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:12 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:12 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:12 --> Total execution time: 0.0119
INFO - 2023-04-03 08:58:12 --> Config Class Initialized
INFO - 2023-04-03 08:58:12 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:12 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:12 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:12 --> URI Class Initialized
INFO - 2023-04-03 08:58:12 --> Router Class Initialized
INFO - 2023-04-03 08:58:12 --> Output Class Initialized
INFO - 2023-04-03 08:58:12 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:12 --> Input Class Initialized
INFO - 2023-04-03 08:58:12 --> Language Class Initialized
INFO - 2023-04-03 08:58:12 --> Loader Class Initialized
INFO - 2023-04-03 08:58:12 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:12 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:12 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:12 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:12 --> Total execution time: 0.0577
INFO - 2023-04-03 08:58:17 --> Config Class Initialized
INFO - 2023-04-03 08:58:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:17 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:17 --> URI Class Initialized
INFO - 2023-04-03 08:58:17 --> Router Class Initialized
INFO - 2023-04-03 08:58:17 --> Output Class Initialized
INFO - 2023-04-03 08:58:17 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:17 --> Input Class Initialized
INFO - 2023-04-03 08:58:17 --> Language Class Initialized
INFO - 2023-04-03 08:58:17 --> Loader Class Initialized
INFO - 2023-04-03 08:58:17 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:17 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:17 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:17 --> Total execution time: 0.0156
INFO - 2023-04-03 08:58:22 --> Config Class Initialized
INFO - 2023-04-03 08:58:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:22 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:22 --> URI Class Initialized
INFO - 2023-04-03 08:58:22 --> Router Class Initialized
INFO - 2023-04-03 08:58:22 --> Output Class Initialized
INFO - 2023-04-03 08:58:22 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:22 --> Input Class Initialized
INFO - 2023-04-03 08:58:22 --> Language Class Initialized
INFO - 2023-04-03 08:58:22 --> Loader Class Initialized
INFO - 2023-04-03 08:58:22 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:22 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:22 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:22 --> Total execution time: 0.0117
INFO - 2023-04-03 08:58:22 --> Config Class Initialized
INFO - 2023-04-03 08:58:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:22 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:22 --> URI Class Initialized
INFO - 2023-04-03 08:58:22 --> Router Class Initialized
INFO - 2023-04-03 08:58:22 --> Output Class Initialized
INFO - 2023-04-03 08:58:22 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:22 --> Input Class Initialized
INFO - 2023-04-03 08:58:22 --> Language Class Initialized
INFO - 2023-04-03 08:58:22 --> Loader Class Initialized
INFO - 2023-04-03 08:58:22 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:22 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:22 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:22 --> Total execution time: 0.0139
INFO - 2023-04-03 08:58:27 --> Config Class Initialized
INFO - 2023-04-03 08:58:27 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:27 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:27 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:27 --> URI Class Initialized
INFO - 2023-04-03 08:58:27 --> Router Class Initialized
INFO - 2023-04-03 08:58:27 --> Output Class Initialized
INFO - 2023-04-03 08:58:27 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:27 --> Input Class Initialized
INFO - 2023-04-03 08:58:27 --> Language Class Initialized
INFO - 2023-04-03 08:58:27 --> Loader Class Initialized
INFO - 2023-04-03 08:58:27 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:27 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:27 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:27 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:27 --> Total execution time: 0.0165
INFO - 2023-04-03 08:58:32 --> Config Class Initialized
INFO - 2023-04-03 08:58:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:32 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:32 --> URI Class Initialized
INFO - 2023-04-03 08:58:32 --> Router Class Initialized
INFO - 2023-04-03 08:58:32 --> Output Class Initialized
INFO - 2023-04-03 08:58:32 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:32 --> Input Class Initialized
INFO - 2023-04-03 08:58:32 --> Language Class Initialized
INFO - 2023-04-03 08:58:32 --> Loader Class Initialized
INFO - 2023-04-03 08:58:32 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:32 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:32 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:32 --> Total execution time: 0.0145
INFO - 2023-04-03 08:58:32 --> Config Class Initialized
INFO - 2023-04-03 08:58:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:32 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:32 --> URI Class Initialized
INFO - 2023-04-03 08:58:32 --> Router Class Initialized
INFO - 2023-04-03 08:58:32 --> Output Class Initialized
INFO - 2023-04-03 08:58:32 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:32 --> Input Class Initialized
INFO - 2023-04-03 08:58:32 --> Language Class Initialized
INFO - 2023-04-03 08:58:32 --> Loader Class Initialized
INFO - 2023-04-03 08:58:32 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:32 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:32 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:32 --> Total execution time: 0.0123
INFO - 2023-04-03 08:58:37 --> Config Class Initialized
INFO - 2023-04-03 08:58:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:37 --> URI Class Initialized
INFO - 2023-04-03 08:58:37 --> Router Class Initialized
INFO - 2023-04-03 08:58:37 --> Output Class Initialized
INFO - 2023-04-03 08:58:37 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:37 --> Input Class Initialized
INFO - 2023-04-03 08:58:37 --> Language Class Initialized
INFO - 2023-04-03 08:58:37 --> Loader Class Initialized
INFO - 2023-04-03 08:58:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:37 --> Total execution time: 0.0157
INFO - 2023-04-03 08:58:40 --> Config Class Initialized
INFO - 2023-04-03 08:58:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:40 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:40 --> URI Class Initialized
INFO - 2023-04-03 08:58:40 --> Router Class Initialized
INFO - 2023-04-03 08:58:40 --> Output Class Initialized
INFO - 2023-04-03 08:58:40 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:40 --> Input Class Initialized
INFO - 2023-04-03 08:58:40 --> Language Class Initialized
INFO - 2023-04-03 08:58:40 --> Loader Class Initialized
INFO - 2023-04-03 08:58:40 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:40 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:40 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:40 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:40 --> Model "Login_model" initialized
INFO - 2023-04-03 08:58:40 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:40 --> Total execution time: 0.0669
INFO - 2023-04-03 08:58:40 --> Config Class Initialized
INFO - 2023-04-03 08:58:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:40 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:40 --> URI Class Initialized
INFO - 2023-04-03 08:58:40 --> Router Class Initialized
INFO - 2023-04-03 08:58:40 --> Output Class Initialized
INFO - 2023-04-03 08:58:40 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:40 --> Input Class Initialized
INFO - 2023-04-03 08:58:40 --> Language Class Initialized
INFO - 2023-04-03 08:58:40 --> Loader Class Initialized
INFO - 2023-04-03 08:58:40 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:40 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:40 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:40 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:40 --> Model "Login_model" initialized
INFO - 2023-04-03 08:58:40 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:40 --> Total execution time: 0.1051
INFO - 2023-04-03 08:58:44 --> Config Class Initialized
INFO - 2023-04-03 08:58:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:44 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:44 --> URI Class Initialized
INFO - 2023-04-03 08:58:44 --> Router Class Initialized
INFO - 2023-04-03 08:58:44 --> Output Class Initialized
INFO - 2023-04-03 08:58:44 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:44 --> Input Class Initialized
INFO - 2023-04-03 08:58:44 --> Language Class Initialized
INFO - 2023-04-03 08:58:44 --> Loader Class Initialized
INFO - 2023-04-03 08:58:44 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:44 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:44 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:44 --> Model "Login_model" initialized
INFO - 2023-04-03 08:58:44 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:44 --> Total execution time: 0.2214
INFO - 2023-04-03 08:58:48 --> Config Class Initialized
INFO - 2023-04-03 08:58:48 --> Config Class Initialized
INFO - 2023-04-03 08:58:48 --> Hooks Class Initialized
INFO - 2023-04-03 08:58:48 --> Hooks Class Initialized
INFO - 2023-04-03 08:58:48 --> Config Class Initialized
DEBUG - 2023-04-03 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:58:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:48 --> Hooks Class Initialized
INFO - 2023-04-03 08:58:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:48 --> Utf8 Class Initialized
DEBUG - 2023-04-03 08:58:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:48 --> URI Class Initialized
INFO - 2023-04-03 08:58:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:48 --> URI Class Initialized
INFO - 2023-04-03 08:58:48 --> URI Class Initialized
INFO - 2023-04-03 08:58:48 --> Router Class Initialized
INFO - 2023-04-03 08:58:48 --> Router Class Initialized
INFO - 2023-04-03 08:58:48 --> Router Class Initialized
INFO - 2023-04-03 08:58:48 --> Output Class Initialized
INFO - 2023-04-03 08:58:48 --> Output Class Initialized
INFO - 2023-04-03 08:58:48 --> Output Class Initialized
INFO - 2023-04-03 08:58:48 --> Security Class Initialized
INFO - 2023-04-03 08:58:48 --> Security Class Initialized
INFO - 2023-04-03 08:58:48 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:48 --> Input Class Initialized
DEBUG - 2023-04-03 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:48 --> Input Class Initialized
INFO - 2023-04-03 08:58:48 --> Input Class Initialized
INFO - 2023-04-03 08:58:48 --> Language Class Initialized
INFO - 2023-04-03 08:58:48 --> Language Class Initialized
INFO - 2023-04-03 08:58:48 --> Loader Class Initialized
INFO - 2023-04-03 08:58:48 --> Controller Class Initialized
INFO - 2023-04-03 08:58:48 --> Loader Class Initialized
INFO - 2023-04-03 08:58:48 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:48 --> Language Class Initialized
DEBUG - 2023-04-03 08:58:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:48 --> Loader Class Initialized
INFO - 2023-04-03 08:58:48 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:48 --> Model "Login_model" initialized
INFO - 2023-04-03 08:58:48 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:48 --> Total execution time: 0.0340
INFO - 2023-04-03 08:58:48 --> Config Class Initialized
INFO - 2023-04-03 08:58:48 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:48 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:48 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:48 --> URI Class Initialized
INFO - 2023-04-03 08:58:48 --> Router Class Initialized
INFO - 2023-04-03 08:58:48 --> Output Class Initialized
INFO - 2023-04-03 08:58:48 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:48 --> Input Class Initialized
INFO - 2023-04-03 08:58:48 --> Language Class Initialized
INFO - 2023-04-03 08:58:48 --> Loader Class Initialized
INFO - 2023-04-03 08:58:48 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:48 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:48 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:49 --> Config Class Initialized
INFO - 2023-04-03 08:58:49 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:49 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:49 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:49 --> URI Class Initialized
INFO - 2023-04-03 08:58:49 --> Router Class Initialized
INFO - 2023-04-03 08:58:49 --> Output Class Initialized
INFO - 2023-04-03 08:58:49 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:49 --> Input Class Initialized
INFO - 2023-04-03 08:58:49 --> Language Class Initialized
INFO - 2023-04-03 08:58:49 --> Loader Class Initialized
INFO - 2023-04-03 08:58:49 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:49 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:49 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:49 --> Model "Login_model" initialized
INFO - 2023-04-03 08:58:49 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:49 --> Total execution time: 0.0233
INFO - 2023-04-03 08:58:50 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:50 --> Total execution time: 2.4061
INFO - 2023-04-03 08:58:50 --> Config Class Initialized
INFO - 2023-04-03 08:58:50 --> Final output sent to browser
INFO - 2023-04-03 08:58:50 --> Config Class Initialized
DEBUG - 2023-04-03 08:58:50 --> Total execution time: 2.4169
INFO - 2023-04-03 08:58:50 --> Hooks Class Initialized
INFO - 2023-04-03 08:58:50 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:58:50 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:50 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:50 --> URI Class Initialized
INFO - 2023-04-03 08:58:50 --> URI Class Initialized
INFO - 2023-04-03 08:58:50 --> Router Class Initialized
INFO - 2023-04-03 08:58:50 --> Router Class Initialized
INFO - 2023-04-03 08:58:50 --> Output Class Initialized
INFO - 2023-04-03 08:58:50 --> Output Class Initialized
INFO - 2023-04-03 08:58:50 --> Security Class Initialized
INFO - 2023-04-03 08:58:50 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:50 --> Input Class Initialized
INFO - 2023-04-03 08:58:50 --> Input Class Initialized
INFO - 2023-04-03 08:58:50 --> Language Class Initialized
INFO - 2023-04-03 08:58:50 --> Language Class Initialized
INFO - 2023-04-03 08:58:50 --> Loader Class Initialized
INFO - 2023-04-03 08:58:50 --> Loader Class Initialized
INFO - 2023-04-03 08:58:50 --> Controller Class Initialized
INFO - 2023-04-03 08:58:50 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:58:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:50 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:51 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:51 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:51 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:51 --> Total execution time: 2.5157
INFO - 2023-04-03 08:58:51 --> Config Class Initialized
INFO - 2023-04-03 08:58:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:58:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:58:51 --> Utf8 Class Initialized
INFO - 2023-04-03 08:58:51 --> URI Class Initialized
INFO - 2023-04-03 08:58:51 --> Router Class Initialized
INFO - 2023-04-03 08:58:51 --> Output Class Initialized
INFO - 2023-04-03 08:58:51 --> Security Class Initialized
DEBUG - 2023-04-03 08:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:58:51 --> Input Class Initialized
INFO - 2023-04-03 08:58:51 --> Language Class Initialized
INFO - 2023-04-03 08:58:51 --> Loader Class Initialized
INFO - 2023-04-03 08:58:51 --> Controller Class Initialized
DEBUG - 2023-04-03 08:58:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:58:51 --> Database Driver Class Initialized
INFO - 2023-04-03 08:58:51 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:58:54 --> Final output sent to browser
INFO - 2023-04-03 08:58:54 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:54 --> Total execution time: 3.4032
DEBUG - 2023-04-03 08:58:54 --> Total execution time: 3.5492
INFO - 2023-04-03 08:58:54 --> Final output sent to browser
DEBUG - 2023-04-03 08:58:54 --> Total execution time: 3.5552
INFO - 2023-04-03 08:59:00 --> Config Class Initialized
INFO - 2023-04-03 08:59:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:00 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:00 --> URI Class Initialized
INFO - 2023-04-03 08:59:00 --> Router Class Initialized
INFO - 2023-04-03 08:59:00 --> Output Class Initialized
INFO - 2023-04-03 08:59:00 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:00 --> Input Class Initialized
INFO - 2023-04-03 08:59:00 --> Language Class Initialized
INFO - 2023-04-03 08:59:00 --> Loader Class Initialized
INFO - 2023-04-03 08:59:00 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:00 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:01 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:01 --> Model "Login_model" initialized
INFO - 2023-04-03 08:59:01 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:01 --> Total execution time: 0.1025
INFO - 2023-04-03 08:59:01 --> Config Class Initialized
INFO - 2023-04-03 08:59:01 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:01 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:01 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:01 --> URI Class Initialized
INFO - 2023-04-03 08:59:01 --> Router Class Initialized
INFO - 2023-04-03 08:59:01 --> Output Class Initialized
INFO - 2023-04-03 08:59:01 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:01 --> Input Class Initialized
INFO - 2023-04-03 08:59:01 --> Language Class Initialized
INFO - 2023-04-03 08:59:01 --> Loader Class Initialized
INFO - 2023-04-03 08:59:01 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:01 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:01 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:01 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:01 --> Model "Login_model" initialized
INFO - 2023-04-03 08:59:01 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:01 --> Total execution time: 0.0616
INFO - 2023-04-03 08:59:07 --> Config Class Initialized
INFO - 2023-04-03 08:59:07 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:07 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:07 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:07 --> URI Class Initialized
INFO - 2023-04-03 08:59:07 --> Router Class Initialized
INFO - 2023-04-03 08:59:07 --> Output Class Initialized
INFO - 2023-04-03 08:59:07 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:07 --> Input Class Initialized
INFO - 2023-04-03 08:59:07 --> Language Class Initialized
INFO - 2023-04-03 08:59:07 --> Loader Class Initialized
INFO - 2023-04-03 08:59:07 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:07 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:07 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:07 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:07 --> Total execution time: 0.0175
INFO - 2023-04-03 08:59:07 --> Config Class Initialized
INFO - 2023-04-03 08:59:07 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:07 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:07 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:07 --> URI Class Initialized
INFO - 2023-04-03 08:59:07 --> Router Class Initialized
INFO - 2023-04-03 08:59:07 --> Output Class Initialized
INFO - 2023-04-03 08:59:07 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:07 --> Input Class Initialized
INFO - 2023-04-03 08:59:07 --> Language Class Initialized
INFO - 2023-04-03 08:59:07 --> Loader Class Initialized
INFO - 2023-04-03 08:59:07 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:07 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:07 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:07 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:07 --> Total execution time: 0.0546
INFO - 2023-04-03 08:59:09 --> Config Class Initialized
INFO - 2023-04-03 08:59:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:09 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:09 --> URI Class Initialized
INFO - 2023-04-03 08:59:09 --> Router Class Initialized
INFO - 2023-04-03 08:59:09 --> Output Class Initialized
INFO - 2023-04-03 08:59:09 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:09 --> Input Class Initialized
INFO - 2023-04-03 08:59:09 --> Language Class Initialized
INFO - 2023-04-03 08:59:09 --> Loader Class Initialized
INFO - 2023-04-03 08:59:09 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:09 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:09 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:09 --> Total execution time: 0.0134
INFO - 2023-04-03 08:59:09 --> Config Class Initialized
INFO - 2023-04-03 08:59:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:09 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:09 --> URI Class Initialized
INFO - 2023-04-03 08:59:09 --> Router Class Initialized
INFO - 2023-04-03 08:59:09 --> Output Class Initialized
INFO - 2023-04-03 08:59:09 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:09 --> Input Class Initialized
INFO - 2023-04-03 08:59:09 --> Language Class Initialized
INFO - 2023-04-03 08:59:09 --> Loader Class Initialized
INFO - 2023-04-03 08:59:09 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:09 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:09 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:09 --> Total execution time: 0.0507
INFO - 2023-04-03 08:59:15 --> Config Class Initialized
INFO - 2023-04-03 08:59:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:15 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:15 --> URI Class Initialized
INFO - 2023-04-03 08:59:15 --> Router Class Initialized
INFO - 2023-04-03 08:59:15 --> Output Class Initialized
INFO - 2023-04-03 08:59:15 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:15 --> Input Class Initialized
INFO - 2023-04-03 08:59:15 --> Language Class Initialized
INFO - 2023-04-03 08:59:15 --> Loader Class Initialized
INFO - 2023-04-03 08:59:15 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:15 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:15 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:15 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:15 --> Total execution time: 0.0197
INFO - 2023-04-03 08:59:15 --> Config Class Initialized
INFO - 2023-04-03 08:59:15 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:15 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:15 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:15 --> URI Class Initialized
INFO - 2023-04-03 08:59:15 --> Router Class Initialized
INFO - 2023-04-03 08:59:15 --> Output Class Initialized
INFO - 2023-04-03 08:59:15 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:15 --> Input Class Initialized
INFO - 2023-04-03 08:59:15 --> Language Class Initialized
INFO - 2023-04-03 08:59:15 --> Loader Class Initialized
INFO - 2023-04-03 08:59:15 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:15 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:15 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:15 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:15 --> Total execution time: 0.0555
INFO - 2023-04-03 08:59:18 --> Config Class Initialized
INFO - 2023-04-03 08:59:18 --> Config Class Initialized
INFO - 2023-04-03 08:59:18 --> Hooks Class Initialized
INFO - 2023-04-03 08:59:18 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:59:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:18 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:18 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:18 --> URI Class Initialized
INFO - 2023-04-03 08:59:18 --> URI Class Initialized
INFO - 2023-04-03 08:59:18 --> Router Class Initialized
INFO - 2023-04-03 08:59:18 --> Router Class Initialized
INFO - 2023-04-03 08:59:18 --> Output Class Initialized
INFO - 2023-04-03 08:59:18 --> Output Class Initialized
INFO - 2023-04-03 08:59:18 --> Security Class Initialized
INFO - 2023-04-03 08:59:18 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:18 --> Input Class Initialized
INFO - 2023-04-03 08:59:18 --> Language Class Initialized
INFO - 2023-04-03 08:59:18 --> Input Class Initialized
INFO - 2023-04-03 08:59:18 --> Language Class Initialized
INFO - 2023-04-03 08:59:18 --> Loader Class Initialized
INFO - 2023-04-03 08:59:18 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:18 --> Loader Class Initialized
INFO - 2023-04-03 08:59:18 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:18 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:18 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:18 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:18 --> Total execution time: 0.0169
INFO - 2023-04-03 08:59:18 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:18 --> Total execution time: 0.0190
INFO - 2023-04-03 08:59:18 --> Config Class Initialized
INFO - 2023-04-03 08:59:18 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:18 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:18 --> URI Class Initialized
INFO - 2023-04-03 08:59:18 --> Router Class Initialized
INFO - 2023-04-03 08:59:18 --> Config Class Initialized
INFO - 2023-04-03 08:59:18 --> Hooks Class Initialized
INFO - 2023-04-03 08:59:18 --> Output Class Initialized
DEBUG - 2023-04-03 08:59:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:18 --> Security Class Initialized
INFO - 2023-04-03 08:59:18 --> Utf8 Class Initialized
DEBUG - 2023-04-03 08:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:18 --> URI Class Initialized
INFO - 2023-04-03 08:59:18 --> Input Class Initialized
INFO - 2023-04-03 08:59:18 --> Router Class Initialized
INFO - 2023-04-03 08:59:18 --> Language Class Initialized
INFO - 2023-04-03 08:59:18 --> Output Class Initialized
INFO - 2023-04-03 08:59:18 --> Loader Class Initialized
INFO - 2023-04-03 08:59:18 --> Security Class Initialized
INFO - 2023-04-03 08:59:18 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:59:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:18 --> Input Class Initialized
INFO - 2023-04-03 08:59:18 --> Language Class Initialized
INFO - 2023-04-03 08:59:18 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:18 --> Loader Class Initialized
INFO - 2023-04-03 08:59:18 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:18 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:18 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:18 --> Total execution time: 0.0524
INFO - 2023-04-03 08:59:18 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:18 --> Total execution time: 0.0506
INFO - 2023-04-03 08:59:20 --> Config Class Initialized
INFO - 2023-04-03 08:59:20 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:20 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:20 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:20 --> URI Class Initialized
INFO - 2023-04-03 08:59:20 --> Router Class Initialized
INFO - 2023-04-03 08:59:20 --> Output Class Initialized
INFO - 2023-04-03 08:59:20 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:20 --> Input Class Initialized
INFO - 2023-04-03 08:59:20 --> Language Class Initialized
INFO - 2023-04-03 08:59:20 --> Loader Class Initialized
INFO - 2023-04-03 08:59:20 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:20 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:20 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:20 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:20 --> Total execution time: 0.1124
INFO - 2023-04-03 08:59:20 --> Config Class Initialized
INFO - 2023-04-03 08:59:20 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:20 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:20 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:20 --> URI Class Initialized
INFO - 2023-04-03 08:59:20 --> Router Class Initialized
INFO - 2023-04-03 08:59:20 --> Output Class Initialized
INFO - 2023-04-03 08:59:20 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:20 --> Input Class Initialized
INFO - 2023-04-03 08:59:20 --> Language Class Initialized
INFO - 2023-04-03 08:59:20 --> Loader Class Initialized
INFO - 2023-04-03 08:59:20 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:20 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:20 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:20 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:20 --> Total execution time: 0.0110
INFO - 2023-04-03 08:59:23 --> Config Class Initialized
INFO - 2023-04-03 08:59:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:23 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:23 --> URI Class Initialized
INFO - 2023-04-03 08:59:23 --> Router Class Initialized
INFO - 2023-04-03 08:59:23 --> Output Class Initialized
INFO - 2023-04-03 08:59:23 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:23 --> Input Class Initialized
INFO - 2023-04-03 08:59:23 --> Language Class Initialized
INFO - 2023-04-03 08:59:23 --> Loader Class Initialized
INFO - 2023-04-03 08:59:23 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:23 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:23 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:23 --> Total execution time: 0.0262
INFO - 2023-04-03 08:59:23 --> Config Class Initialized
INFO - 2023-04-03 08:59:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:23 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:23 --> URI Class Initialized
INFO - 2023-04-03 08:59:23 --> Router Class Initialized
INFO - 2023-04-03 08:59:23 --> Output Class Initialized
INFO - 2023-04-03 08:59:23 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:23 --> Input Class Initialized
INFO - 2023-04-03 08:59:23 --> Language Class Initialized
INFO - 2023-04-03 08:59:23 --> Loader Class Initialized
INFO - 2023-04-03 08:59:23 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:23 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:23 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:24 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:24 --> Total execution time: 0.0151
INFO - 2023-04-03 08:59:29 --> Config Class Initialized
INFO - 2023-04-03 08:59:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:29 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:29 --> URI Class Initialized
INFO - 2023-04-03 08:59:29 --> Router Class Initialized
INFO - 2023-04-03 08:59:29 --> Output Class Initialized
INFO - 2023-04-03 08:59:29 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:29 --> Input Class Initialized
INFO - 2023-04-03 08:59:29 --> Language Class Initialized
INFO - 2023-04-03 08:59:29 --> Loader Class Initialized
INFO - 2023-04-03 08:59:29 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:29 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:29 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:29 --> Total execution time: 0.0152
INFO - 2023-04-03 08:59:29 --> Config Class Initialized
INFO - 2023-04-03 08:59:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:29 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:29 --> URI Class Initialized
INFO - 2023-04-03 08:59:29 --> Router Class Initialized
INFO - 2023-04-03 08:59:29 --> Output Class Initialized
INFO - 2023-04-03 08:59:29 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:29 --> Input Class Initialized
INFO - 2023-04-03 08:59:29 --> Language Class Initialized
INFO - 2023-04-03 08:59:29 --> Loader Class Initialized
INFO - 2023-04-03 08:59:29 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:29 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:29 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:29 --> Total execution time: 0.0105
INFO - 2023-04-03 08:59:31 --> Config Class Initialized
INFO - 2023-04-03 08:59:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:31 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:31 --> URI Class Initialized
INFO - 2023-04-03 08:59:31 --> Router Class Initialized
INFO - 2023-04-03 08:59:31 --> Output Class Initialized
INFO - 2023-04-03 08:59:31 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:31 --> Input Class Initialized
INFO - 2023-04-03 08:59:31 --> Language Class Initialized
INFO - 2023-04-03 08:59:31 --> Loader Class Initialized
INFO - 2023-04-03 08:59:31 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:31 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:31 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:31 --> Total execution time: 0.0110
INFO - 2023-04-03 08:59:31 --> Config Class Initialized
INFO - 2023-04-03 08:59:31 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:31 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:31 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:31 --> URI Class Initialized
INFO - 2023-04-03 08:59:31 --> Router Class Initialized
INFO - 2023-04-03 08:59:31 --> Output Class Initialized
INFO - 2023-04-03 08:59:31 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:31 --> Input Class Initialized
INFO - 2023-04-03 08:59:31 --> Language Class Initialized
INFO - 2023-04-03 08:59:31 --> Loader Class Initialized
INFO - 2023-04-03 08:59:31 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:31 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:31 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:31 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:31 --> Total execution time: 0.0091
INFO - 2023-04-03 08:59:32 --> Config Class Initialized
INFO - 2023-04-03 08:59:32 --> Config Class Initialized
INFO - 2023-04-03 08:59:32 --> Hooks Class Initialized
INFO - 2023-04-03 08:59:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:59:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:32 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:32 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:32 --> URI Class Initialized
INFO - 2023-04-03 08:59:32 --> URI Class Initialized
INFO - 2023-04-03 08:59:32 --> Router Class Initialized
INFO - 2023-04-03 08:59:32 --> Router Class Initialized
INFO - 2023-04-03 08:59:32 --> Output Class Initialized
INFO - 2023-04-03 08:59:32 --> Output Class Initialized
INFO - 2023-04-03 08:59:32 --> Security Class Initialized
INFO - 2023-04-03 08:59:32 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:32 --> Input Class Initialized
INFO - 2023-04-03 08:59:32 --> Language Class Initialized
INFO - 2023-04-03 08:59:32 --> Input Class Initialized
INFO - 2023-04-03 08:59:32 --> Language Class Initialized
INFO - 2023-04-03 08:59:32 --> Loader Class Initialized
INFO - 2023-04-03 08:59:32 --> Loader Class Initialized
INFO - 2023-04-03 08:59:32 --> Controller Class Initialized
INFO - 2023-04-03 08:59:32 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:59:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:32 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:32 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:32 --> Final output sent to browser
INFO - 2023-04-03 08:59:32 --> Model "Cluster_model" initialized
DEBUG - 2023-04-03 08:59:32 --> Total execution time: 0.0137
INFO - 2023-04-03 08:59:32 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:32 --> Total execution time: 0.0140
INFO - 2023-04-03 08:59:32 --> Config Class Initialized
INFO - 2023-04-03 08:59:32 --> Config Class Initialized
INFO - 2023-04-03 08:59:32 --> Hooks Class Initialized
INFO - 2023-04-03 08:59:32 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:59:32 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:32 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:32 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:32 --> URI Class Initialized
INFO - 2023-04-03 08:59:32 --> URI Class Initialized
INFO - 2023-04-03 08:59:32 --> Router Class Initialized
INFO - 2023-04-03 08:59:32 --> Router Class Initialized
INFO - 2023-04-03 08:59:32 --> Output Class Initialized
INFO - 2023-04-03 08:59:32 --> Output Class Initialized
INFO - 2023-04-03 08:59:32 --> Security Class Initialized
INFO - 2023-04-03 08:59:32 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:32 --> Input Class Initialized
INFO - 2023-04-03 08:59:32 --> Input Class Initialized
INFO - 2023-04-03 08:59:32 --> Language Class Initialized
INFO - 2023-04-03 08:59:32 --> Language Class Initialized
INFO - 2023-04-03 08:59:32 --> Loader Class Initialized
INFO - 2023-04-03 08:59:32 --> Loader Class Initialized
INFO - 2023-04-03 08:59:32 --> Controller Class Initialized
INFO - 2023-04-03 08:59:32 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:59:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:32 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:32 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:32 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:32 --> Final output sent to browser
INFO - 2023-04-03 08:59:32 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:32 --> Total execution time: 0.0130
DEBUG - 2023-04-03 08:59:32 --> Total execution time: 0.0130
INFO - 2023-04-03 08:59:34 --> Config Class Initialized
INFO - 2023-04-03 08:59:34 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:34 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:34 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:34 --> URI Class Initialized
INFO - 2023-04-03 08:59:34 --> Router Class Initialized
INFO - 2023-04-03 08:59:34 --> Output Class Initialized
INFO - 2023-04-03 08:59:34 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:34 --> Input Class Initialized
INFO - 2023-04-03 08:59:34 --> Language Class Initialized
INFO - 2023-04-03 08:59:34 --> Loader Class Initialized
INFO - 2023-04-03 08:59:34 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:34 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:34 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:34 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:34 --> Total execution time: 0.0231
INFO - 2023-04-03 08:59:34 --> Config Class Initialized
INFO - 2023-04-03 08:59:34 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:34 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:34 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:34 --> URI Class Initialized
INFO - 2023-04-03 08:59:34 --> Router Class Initialized
INFO - 2023-04-03 08:59:34 --> Output Class Initialized
INFO - 2023-04-03 08:59:34 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:34 --> Input Class Initialized
INFO - 2023-04-03 08:59:34 --> Language Class Initialized
INFO - 2023-04-03 08:59:34 --> Loader Class Initialized
INFO - 2023-04-03 08:59:34 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:34 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:34 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:34 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:34 --> Total execution time: 0.0142
INFO - 2023-04-03 08:59:37 --> Config Class Initialized
INFO - 2023-04-03 08:59:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:37 --> URI Class Initialized
INFO - 2023-04-03 08:59:37 --> Router Class Initialized
INFO - 2023-04-03 08:59:37 --> Output Class Initialized
INFO - 2023-04-03 08:59:37 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:37 --> Input Class Initialized
INFO - 2023-04-03 08:59:37 --> Language Class Initialized
INFO - 2023-04-03 08:59:37 --> Loader Class Initialized
INFO - 2023-04-03 08:59:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:37 --> Total execution time: 0.0144
INFO - 2023-04-03 08:59:37 --> Config Class Initialized
INFO - 2023-04-03 08:59:37 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:37 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:37 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:37 --> URI Class Initialized
INFO - 2023-04-03 08:59:37 --> Router Class Initialized
INFO - 2023-04-03 08:59:37 --> Output Class Initialized
INFO - 2023-04-03 08:59:37 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:37 --> Input Class Initialized
INFO - 2023-04-03 08:59:37 --> Language Class Initialized
INFO - 2023-04-03 08:59:37 --> Loader Class Initialized
INFO - 2023-04-03 08:59:37 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:37 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:37 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:37 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:37 --> Total execution time: 0.0520
INFO - 2023-04-03 08:59:44 --> Config Class Initialized
INFO - 2023-04-03 08:59:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:44 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:44 --> URI Class Initialized
INFO - 2023-04-03 08:59:44 --> Router Class Initialized
INFO - 2023-04-03 08:59:44 --> Output Class Initialized
INFO - 2023-04-03 08:59:44 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:44 --> Input Class Initialized
INFO - 2023-04-03 08:59:44 --> Language Class Initialized
INFO - 2023-04-03 08:59:44 --> Loader Class Initialized
INFO - 2023-04-03 08:59:44 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:44 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:44 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:44 --> Total execution time: 0.0738
INFO - 2023-04-03 08:59:44 --> Config Class Initialized
INFO - 2023-04-03 08:59:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:44 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:44 --> URI Class Initialized
INFO - 2023-04-03 08:59:44 --> Router Class Initialized
INFO - 2023-04-03 08:59:44 --> Output Class Initialized
INFO - 2023-04-03 08:59:44 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:44 --> Input Class Initialized
INFO - 2023-04-03 08:59:44 --> Language Class Initialized
INFO - 2023-04-03 08:59:44 --> Loader Class Initialized
INFO - 2023-04-03 08:59:44 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:44 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:44 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:44 --> Total execution time: 0.1045
INFO - 2023-04-03 08:59:55 --> Config Class Initialized
INFO - 2023-04-03 08:59:55 --> Config Class Initialized
INFO - 2023-04-03 08:59:55 --> Hooks Class Initialized
INFO - 2023-04-03 08:59:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 08:59:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:55 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:55 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:55 --> URI Class Initialized
INFO - 2023-04-03 08:59:55 --> URI Class Initialized
INFO - 2023-04-03 08:59:55 --> Router Class Initialized
INFO - 2023-04-03 08:59:55 --> Router Class Initialized
INFO - 2023-04-03 08:59:55 --> Output Class Initialized
INFO - 2023-04-03 08:59:55 --> Output Class Initialized
INFO - 2023-04-03 08:59:55 --> Security Class Initialized
INFO - 2023-04-03 08:59:55 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:55 --> Input Class Initialized
INFO - 2023-04-03 08:59:55 --> Input Class Initialized
INFO - 2023-04-03 08:59:55 --> Language Class Initialized
INFO - 2023-04-03 08:59:55 --> Language Class Initialized
INFO - 2023-04-03 08:59:55 --> Loader Class Initialized
INFO - 2023-04-03 08:59:55 --> Loader Class Initialized
INFO - 2023-04-03 08:59:55 --> Controller Class Initialized
INFO - 2023-04-03 08:59:55 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 08:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:55 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:55 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:55 --> Total execution time: 0.0043
INFO - 2023-04-03 08:59:55 --> Config Class Initialized
INFO - 2023-04-03 08:59:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:55 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:55 --> URI Class Initialized
INFO - 2023-04-03 08:59:55 --> Router Class Initialized
INFO - 2023-04-03 08:59:55 --> Output Class Initialized
INFO - 2023-04-03 08:59:55 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:55 --> Input Class Initialized
INFO - 2023-04-03 08:59:55 --> Language Class Initialized
INFO - 2023-04-03 08:59:55 --> Loader Class Initialized
INFO - 2023-04-03 08:59:55 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:55 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:55 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:55 --> Total execution time: 0.0496
INFO - 2023-04-03 08:59:55 --> Config Class Initialized
INFO - 2023-04-03 08:59:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:55 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:55 --> URI Class Initialized
INFO - 2023-04-03 08:59:55 --> Router Class Initialized
INFO - 2023-04-03 08:59:55 --> Output Class Initialized
INFO - 2023-04-03 08:59:55 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:55 --> Input Class Initialized
INFO - 2023-04-03 08:59:55 --> Language Class Initialized
INFO - 2023-04-03 08:59:55 --> Loader Class Initialized
INFO - 2023-04-03 08:59:55 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:55 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:55 --> Model "Login_model" initialized
INFO - 2023-04-03 08:59:55 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:55 --> Final output sent to browser
INFO - 2023-04-03 08:59:55 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:55 --> Total execution time: 0.0613
DEBUG - 2023-04-03 08:59:55 --> Total execution time: 0.0159
INFO - 2023-04-03 08:59:57 --> Config Class Initialized
INFO - 2023-04-03 08:59:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:57 --> URI Class Initialized
INFO - 2023-04-03 08:59:57 --> Router Class Initialized
INFO - 2023-04-03 08:59:57 --> Output Class Initialized
INFO - 2023-04-03 08:59:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:57 --> Input Class Initialized
INFO - 2023-04-03 08:59:57 --> Language Class Initialized
INFO - 2023-04-03 08:59:57 --> Loader Class Initialized
INFO - 2023-04-03 08:59:57 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:57 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:57 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:57 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:57 --> Model "Login_model" initialized
INFO - 2023-04-03 08:59:57 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:57 --> Total execution time: 0.1001
INFO - 2023-04-03 08:59:57 --> Config Class Initialized
INFO - 2023-04-03 08:59:57 --> Hooks Class Initialized
DEBUG - 2023-04-03 08:59:57 --> UTF-8 Support Enabled
INFO - 2023-04-03 08:59:57 --> Utf8 Class Initialized
INFO - 2023-04-03 08:59:57 --> URI Class Initialized
INFO - 2023-04-03 08:59:57 --> Router Class Initialized
INFO - 2023-04-03 08:59:57 --> Output Class Initialized
INFO - 2023-04-03 08:59:57 --> Security Class Initialized
DEBUG - 2023-04-03 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 08:59:57 --> Input Class Initialized
INFO - 2023-04-03 08:59:57 --> Language Class Initialized
INFO - 2023-04-03 08:59:57 --> Loader Class Initialized
INFO - 2023-04-03 08:59:57 --> Controller Class Initialized
DEBUG - 2023-04-03 08:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 08:59:57 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:57 --> Model "Cluster_model" initialized
INFO - 2023-04-03 08:59:57 --> Database Driver Class Initialized
INFO - 2023-04-03 08:59:57 --> Model "Login_model" initialized
INFO - 2023-04-03 08:59:57 --> Final output sent to browser
DEBUG - 2023-04-03 08:59:57 --> Total execution time: 0.0651
INFO - 2023-04-03 09:00:35 --> Config Class Initialized
INFO - 2023-04-03 09:00:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:35 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:35 --> URI Class Initialized
INFO - 2023-04-03 09:00:35 --> Router Class Initialized
INFO - 2023-04-03 09:00:35 --> Output Class Initialized
INFO - 2023-04-03 09:00:35 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:35 --> Input Class Initialized
INFO - 2023-04-03 09:00:35 --> Language Class Initialized
INFO - 2023-04-03 09:00:35 --> Loader Class Initialized
INFO - 2023-04-03 09:00:35 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:35 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:35 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:35 --> Total execution time: 0.0295
INFO - 2023-04-03 09:00:35 --> Config Class Initialized
INFO - 2023-04-03 09:00:36 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:36 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:36 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:36 --> URI Class Initialized
INFO - 2023-04-03 09:00:36 --> Router Class Initialized
INFO - 2023-04-03 09:00:36 --> Output Class Initialized
INFO - 2023-04-03 09:00:36 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:36 --> Input Class Initialized
INFO - 2023-04-03 09:00:36 --> Language Class Initialized
INFO - 2023-04-03 09:00:36 --> Loader Class Initialized
INFO - 2023-04-03 09:00:36 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:36 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:36 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:36 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:36 --> Total execution time: 0.0592
INFO - 2023-04-03 09:00:39 --> Config Class Initialized
INFO - 2023-04-03 09:00:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:39 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:39 --> URI Class Initialized
INFO - 2023-04-03 09:00:39 --> Router Class Initialized
INFO - 2023-04-03 09:00:39 --> Output Class Initialized
INFO - 2023-04-03 09:00:39 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:39 --> Input Class Initialized
INFO - 2023-04-03 09:00:39 --> Language Class Initialized
INFO - 2023-04-03 09:00:39 --> Loader Class Initialized
INFO - 2023-04-03 09:00:39 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:39 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:39 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:39 --> Total execution time: 0.0166
INFO - 2023-04-03 09:00:39 --> Config Class Initialized
INFO - 2023-04-03 09:00:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:39 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:39 --> URI Class Initialized
INFO - 2023-04-03 09:00:39 --> Router Class Initialized
INFO - 2023-04-03 09:00:39 --> Output Class Initialized
INFO - 2023-04-03 09:00:39 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:39 --> Input Class Initialized
INFO - 2023-04-03 09:00:39 --> Language Class Initialized
INFO - 2023-04-03 09:00:39 --> Loader Class Initialized
INFO - 2023-04-03 09:00:39 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:39 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:39 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:39 --> Total execution time: 0.0543
INFO - 2023-04-03 09:00:40 --> Config Class Initialized
INFO - 2023-04-03 09:00:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:40 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:40 --> URI Class Initialized
INFO - 2023-04-03 09:00:40 --> Router Class Initialized
INFO - 2023-04-03 09:00:40 --> Output Class Initialized
INFO - 2023-04-03 09:00:40 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:40 --> Input Class Initialized
INFO - 2023-04-03 09:00:40 --> Language Class Initialized
INFO - 2023-04-03 09:00:40 --> Loader Class Initialized
INFO - 2023-04-03 09:00:40 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:40 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:40 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:40 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:40 --> Total execution time: 0.0360
INFO - 2023-04-03 09:00:40 --> Config Class Initialized
INFO - 2023-04-03 09:00:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:40 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:40 --> URI Class Initialized
INFO - 2023-04-03 09:00:40 --> Router Class Initialized
INFO - 2023-04-03 09:00:40 --> Output Class Initialized
INFO - 2023-04-03 09:00:40 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:40 --> Input Class Initialized
INFO - 2023-04-03 09:00:40 --> Language Class Initialized
INFO - 2023-04-03 09:00:40 --> Loader Class Initialized
INFO - 2023-04-03 09:00:40 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:40 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:40 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:40 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:40 --> Total execution time: 0.0543
INFO - 2023-04-03 09:00:45 --> Config Class Initialized
INFO - 2023-04-03 09:00:45 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:45 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:45 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:45 --> URI Class Initialized
INFO - 2023-04-03 09:00:45 --> Router Class Initialized
INFO - 2023-04-03 09:00:45 --> Output Class Initialized
INFO - 2023-04-03 09:00:45 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:45 --> Input Class Initialized
INFO - 2023-04-03 09:00:45 --> Language Class Initialized
INFO - 2023-04-03 09:00:45 --> Loader Class Initialized
INFO - 2023-04-03 09:00:45 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:45 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:45 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:45 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:45 --> Total execution time: 0.0145
INFO - 2023-04-03 09:00:45 --> Config Class Initialized
INFO - 2023-04-03 09:00:45 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:45 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:45 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:45 --> URI Class Initialized
INFO - 2023-04-03 09:00:45 --> Router Class Initialized
INFO - 2023-04-03 09:00:45 --> Output Class Initialized
INFO - 2023-04-03 09:00:45 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:45 --> Input Class Initialized
INFO - 2023-04-03 09:00:45 --> Language Class Initialized
INFO - 2023-04-03 09:00:45 --> Loader Class Initialized
INFO - 2023-04-03 09:00:45 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:45 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:45 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:45 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:45 --> Total execution time: 0.0109
INFO - 2023-04-03 09:00:46 --> Config Class Initialized
INFO - 2023-04-03 09:00:46 --> Config Class Initialized
INFO - 2023-04-03 09:00:46 --> Hooks Class Initialized
INFO - 2023-04-03 09:00:46 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 09:00:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:46 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:46 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:46 --> URI Class Initialized
INFO - 2023-04-03 09:00:46 --> URI Class Initialized
INFO - 2023-04-03 09:00:46 --> Router Class Initialized
INFO - 2023-04-03 09:00:46 --> Router Class Initialized
INFO - 2023-04-03 09:00:46 --> Output Class Initialized
INFO - 2023-04-03 09:00:46 --> Output Class Initialized
INFO - 2023-04-03 09:00:46 --> Security Class Initialized
INFO - 2023-04-03 09:00:46 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 09:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:46 --> Input Class Initialized
INFO - 2023-04-03 09:00:46 --> Input Class Initialized
INFO - 2023-04-03 09:00:46 --> Language Class Initialized
INFO - 2023-04-03 09:00:46 --> Language Class Initialized
INFO - 2023-04-03 09:00:46 --> Loader Class Initialized
INFO - 2023-04-03 09:00:46 --> Loader Class Initialized
INFO - 2023-04-03 09:00:46 --> Controller Class Initialized
INFO - 2023-04-03 09:00:46 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 09:00:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:46 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:46 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:46 --> Final output sent to browser
INFO - 2023-04-03 09:00:46 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:46 --> Total execution time: 0.0146
DEBUG - 2023-04-03 09:00:46 --> Total execution time: 0.0145
INFO - 2023-04-03 09:00:46 --> Config Class Initialized
INFO - 2023-04-03 09:00:46 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:46 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:46 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:46 --> URI Class Initialized
INFO - 2023-04-03 09:00:46 --> Router Class Initialized
INFO - 2023-04-03 09:00:46 --> Output Class Initialized
INFO - 2023-04-03 09:00:46 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:46 --> Input Class Initialized
INFO - 2023-04-03 09:00:46 --> Language Class Initialized
INFO - 2023-04-03 09:00:46 --> Loader Class Initialized
INFO - 2023-04-03 09:00:46 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:46 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:46 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:46 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:46 --> Total execution time: 0.0096
INFO - 2023-04-03 09:00:47 --> Config Class Initialized
INFO - 2023-04-03 09:00:47 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:47 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:47 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:47 --> URI Class Initialized
INFO - 2023-04-03 09:00:47 --> Router Class Initialized
INFO - 2023-04-03 09:00:47 --> Output Class Initialized
INFO - 2023-04-03 09:00:47 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:47 --> Input Class Initialized
INFO - 2023-04-03 09:00:47 --> Language Class Initialized
INFO - 2023-04-03 09:00:47 --> Loader Class Initialized
INFO - 2023-04-03 09:00:47 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:47 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:47 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:47 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:47 --> Total execution time: 0.0197
INFO - 2023-04-03 09:00:47 --> Config Class Initialized
INFO - 2023-04-03 09:00:47 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:47 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:47 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:47 --> URI Class Initialized
INFO - 2023-04-03 09:00:47 --> Router Class Initialized
INFO - 2023-04-03 09:00:47 --> Output Class Initialized
INFO - 2023-04-03 09:00:47 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:47 --> Input Class Initialized
INFO - 2023-04-03 09:00:47 --> Language Class Initialized
INFO - 2023-04-03 09:00:47 --> Loader Class Initialized
INFO - 2023-04-03 09:00:47 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:47 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:47 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:47 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:47 --> Total execution time: 0.0575
INFO - 2023-04-03 09:00:51 --> Config Class Initialized
INFO - 2023-04-03 09:00:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:51 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:51 --> URI Class Initialized
INFO - 2023-04-03 09:00:51 --> Router Class Initialized
INFO - 2023-04-03 09:00:51 --> Output Class Initialized
INFO - 2023-04-03 09:00:51 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:51 --> Input Class Initialized
INFO - 2023-04-03 09:00:51 --> Language Class Initialized
INFO - 2023-04-03 09:00:51 --> Loader Class Initialized
INFO - 2023-04-03 09:00:51 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:51 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:51 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:51 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:51 --> Total execution time: 0.0146
INFO - 2023-04-03 09:00:51 --> Config Class Initialized
INFO - 2023-04-03 09:00:51 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:51 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:51 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:51 --> URI Class Initialized
INFO - 2023-04-03 09:00:51 --> Router Class Initialized
INFO - 2023-04-03 09:00:51 --> Output Class Initialized
INFO - 2023-04-03 09:00:51 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:51 --> Input Class Initialized
INFO - 2023-04-03 09:00:51 --> Language Class Initialized
INFO - 2023-04-03 09:00:51 --> Loader Class Initialized
INFO - 2023-04-03 09:00:51 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:51 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:51 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:51 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:51 --> Total execution time: 0.0554
INFO - 2023-04-03 09:00:55 --> Config Class Initialized
INFO - 2023-04-03 09:00:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:55 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:55 --> URI Class Initialized
INFO - 2023-04-03 09:00:55 --> Router Class Initialized
INFO - 2023-04-03 09:00:55 --> Output Class Initialized
INFO - 2023-04-03 09:00:55 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:55 --> Input Class Initialized
INFO - 2023-04-03 09:00:55 --> Language Class Initialized
INFO - 2023-04-03 09:00:55 --> Loader Class Initialized
INFO - 2023-04-03 09:00:55 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:55 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:55 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:55 --> Total execution time: 0.0125
INFO - 2023-04-03 09:00:55 --> Config Class Initialized
INFO - 2023-04-03 09:00:55 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:55 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:55 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:55 --> URI Class Initialized
INFO - 2023-04-03 09:00:55 --> Router Class Initialized
INFO - 2023-04-03 09:00:55 --> Output Class Initialized
INFO - 2023-04-03 09:00:55 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:55 --> Input Class Initialized
INFO - 2023-04-03 09:00:55 --> Language Class Initialized
INFO - 2023-04-03 09:00:55 --> Loader Class Initialized
INFO - 2023-04-03 09:00:55 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:55 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:55 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:55 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:55 --> Total execution time: 0.0101
INFO - 2023-04-03 09:00:58 --> Config Class Initialized
INFO - 2023-04-03 09:00:58 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:58 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:58 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:58 --> URI Class Initialized
INFO - 2023-04-03 09:00:58 --> Router Class Initialized
INFO - 2023-04-03 09:00:58 --> Output Class Initialized
INFO - 2023-04-03 09:00:58 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:58 --> Input Class Initialized
INFO - 2023-04-03 09:00:58 --> Language Class Initialized
INFO - 2023-04-03 09:00:58 --> Loader Class Initialized
INFO - 2023-04-03 09:00:58 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:58 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:58 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:58 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:58 --> Total execution time: 0.0105
INFO - 2023-04-03 09:00:58 --> Config Class Initialized
INFO - 2023-04-03 09:00:58 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:00:58 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:00:58 --> Utf8 Class Initialized
INFO - 2023-04-03 09:00:58 --> URI Class Initialized
INFO - 2023-04-03 09:00:58 --> Router Class Initialized
INFO - 2023-04-03 09:00:58 --> Output Class Initialized
INFO - 2023-04-03 09:00:58 --> Security Class Initialized
DEBUG - 2023-04-03 09:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:00:58 --> Input Class Initialized
INFO - 2023-04-03 09:00:58 --> Language Class Initialized
INFO - 2023-04-03 09:00:58 --> Loader Class Initialized
INFO - 2023-04-03 09:00:58 --> Controller Class Initialized
DEBUG - 2023-04-03 09:00:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:00:58 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:58 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:00:58 --> Database Driver Class Initialized
INFO - 2023-04-03 09:00:58 --> Model "Login_model" initialized
INFO - 2023-04-03 09:00:58 --> Final output sent to browser
DEBUG - 2023-04-03 09:00:58 --> Total execution time: 0.0205
INFO - 2023-04-03 09:01:00 --> Config Class Initialized
INFO - 2023-04-03 09:01:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:01:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:01:00 --> Utf8 Class Initialized
INFO - 2023-04-03 09:01:00 --> URI Class Initialized
INFO - 2023-04-03 09:01:00 --> Router Class Initialized
INFO - 2023-04-03 09:01:00 --> Output Class Initialized
INFO - 2023-04-03 09:01:00 --> Security Class Initialized
DEBUG - 2023-04-03 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:01:00 --> Input Class Initialized
INFO - 2023-04-03 09:01:00 --> Language Class Initialized
INFO - 2023-04-03 09:01:00 --> Loader Class Initialized
INFO - 2023-04-03 09:01:00 --> Controller Class Initialized
DEBUG - 2023-04-03 09:01:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:01:00 --> Database Driver Class Initialized
INFO - 2023-04-03 09:01:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:01:00 --> Final output sent to browser
DEBUG - 2023-04-03 09:01:00 --> Total execution time: 0.0130
INFO - 2023-04-03 09:01:00 --> Config Class Initialized
INFO - 2023-04-03 09:01:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:01:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:01:00 --> Utf8 Class Initialized
INFO - 2023-04-03 09:01:00 --> URI Class Initialized
INFO - 2023-04-03 09:01:00 --> Router Class Initialized
INFO - 2023-04-03 09:01:00 --> Output Class Initialized
INFO - 2023-04-03 09:01:00 --> Security Class Initialized
DEBUG - 2023-04-03 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:01:00 --> Input Class Initialized
INFO - 2023-04-03 09:01:00 --> Language Class Initialized
INFO - 2023-04-03 09:01:00 --> Loader Class Initialized
INFO - 2023-04-03 09:01:00 --> Controller Class Initialized
DEBUG - 2023-04-03 09:01:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:01:00 --> Database Driver Class Initialized
INFO - 2023-04-03 09:01:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:01:00 --> Database Driver Class Initialized
INFO - 2023-04-03 09:01:00 --> Model "Login_model" initialized
INFO - 2023-04-03 09:01:00 --> Final output sent to browser
DEBUG - 2023-04-03 09:01:00 --> Total execution time: 0.2047
INFO - 2023-04-03 09:01:03 --> Config Class Initialized
INFO - 2023-04-03 09:01:03 --> Config Class Initialized
INFO - 2023-04-03 09:01:03 --> Hooks Class Initialized
INFO - 2023-04-03 09:01:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 09:01:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:01:03 --> Utf8 Class Initialized
INFO - 2023-04-03 09:01:03 --> Utf8 Class Initialized
INFO - 2023-04-03 09:01:03 --> URI Class Initialized
INFO - 2023-04-03 09:01:03 --> URI Class Initialized
INFO - 2023-04-03 09:01:03 --> Router Class Initialized
INFO - 2023-04-03 09:01:03 --> Router Class Initialized
INFO - 2023-04-03 09:01:03 --> Output Class Initialized
INFO - 2023-04-03 09:01:03 --> Output Class Initialized
INFO - 2023-04-03 09:01:03 --> Security Class Initialized
INFO - 2023-04-03 09:01:03 --> Security Class Initialized
DEBUG - 2023-04-03 09:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 09:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:01:03 --> Input Class Initialized
INFO - 2023-04-03 09:01:03 --> Input Class Initialized
INFO - 2023-04-03 09:01:03 --> Language Class Initialized
INFO - 2023-04-03 09:01:03 --> Language Class Initialized
INFO - 2023-04-03 09:01:03 --> Loader Class Initialized
INFO - 2023-04-03 09:01:03 --> Loader Class Initialized
INFO - 2023-04-03 09:01:03 --> Controller Class Initialized
INFO - 2023-04-03 09:01:03 --> Controller Class Initialized
DEBUG - 2023-04-03 09:01:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 09:01:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:01:03 --> Database Driver Class Initialized
INFO - 2023-04-03 09:01:03 --> Database Driver Class Initialized
INFO - 2023-04-03 09:01:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:01:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:01:03 --> Final output sent to browser
DEBUG - 2023-04-03 09:01:03 --> Total execution time: 0.0564
INFO - 2023-04-03 09:01:03 --> Final output sent to browser
DEBUG - 2023-04-03 09:01:03 --> Total execution time: 0.0568
INFO - 2023-04-03 09:01:03 --> Config Class Initialized
INFO - 2023-04-03 09:01:03 --> Config Class Initialized
INFO - 2023-04-03 09:01:03 --> Hooks Class Initialized
INFO - 2023-04-03 09:01:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 09:01:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:01:03 --> Utf8 Class Initialized
INFO - 2023-04-03 09:01:03 --> Utf8 Class Initialized
INFO - 2023-04-03 09:01:03 --> URI Class Initialized
INFO - 2023-04-03 09:01:03 --> URI Class Initialized
INFO - 2023-04-03 09:01:03 --> Router Class Initialized
INFO - 2023-04-03 09:01:03 --> Router Class Initialized
INFO - 2023-04-03 09:01:03 --> Output Class Initialized
INFO - 2023-04-03 09:01:03 --> Output Class Initialized
INFO - 2023-04-03 09:01:03 --> Security Class Initialized
INFO - 2023-04-03 09:01:03 --> Security Class Initialized
DEBUG - 2023-04-03 09:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 09:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:01:03 --> Input Class Initialized
INFO - 2023-04-03 09:01:03 --> Input Class Initialized
INFO - 2023-04-03 09:01:03 --> Language Class Initialized
INFO - 2023-04-03 09:01:03 --> Language Class Initialized
INFO - 2023-04-03 09:01:03 --> Loader Class Initialized
INFO - 2023-04-03 09:01:03 --> Loader Class Initialized
INFO - 2023-04-03 09:01:03 --> Controller Class Initialized
INFO - 2023-04-03 09:01:03 --> Controller Class Initialized
DEBUG - 2023-04-03 09:01:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 09:01:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:01:03 --> Database Driver Class Initialized
INFO - 2023-04-03 09:01:03 --> Database Driver Class Initialized
INFO - 2023-04-03 09:01:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:01:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:01:03 --> Final output sent to browser
DEBUG - 2023-04-03 09:01:03 --> Total execution time: 0.0114
INFO - 2023-04-03 09:01:03 --> Final output sent to browser
DEBUG - 2023-04-03 09:01:03 --> Total execution time: 0.0117
INFO - 2023-04-03 09:35:52 --> Config Class Initialized
INFO - 2023-04-03 09:35:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:35:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:35:52 --> Utf8 Class Initialized
INFO - 2023-04-03 09:35:52 --> URI Class Initialized
INFO - 2023-04-03 09:35:52 --> Router Class Initialized
INFO - 2023-04-03 09:35:52 --> Output Class Initialized
INFO - 2023-04-03 09:35:52 --> Security Class Initialized
DEBUG - 2023-04-03 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:35:52 --> Input Class Initialized
INFO - 2023-04-03 09:35:52 --> Language Class Initialized
INFO - 2023-04-03 09:35:52 --> Loader Class Initialized
INFO - 2023-04-03 09:35:52 --> Controller Class Initialized
INFO - 2023-04-03 09:35:52 --> Helper loaded: form_helper
INFO - 2023-04-03 09:35:52 --> Helper loaded: url_helper
DEBUG - 2023-04-03 09:35:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:35:52 --> Model "Change_model" initialized
INFO - 2023-04-03 09:35:52 --> Model "Grafana_model" initialized
INFO - 2023-04-03 09:35:52 --> Final output sent to browser
DEBUG - 2023-04-03 09:35:52 --> Total execution time: 0.0283
INFO - 2023-04-03 09:35:52 --> Config Class Initialized
INFO - 2023-04-03 09:35:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:35:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:35:52 --> Utf8 Class Initialized
INFO - 2023-04-03 09:35:52 --> URI Class Initialized
INFO - 2023-04-03 09:35:52 --> Router Class Initialized
INFO - 2023-04-03 09:35:52 --> Output Class Initialized
INFO - 2023-04-03 09:35:52 --> Security Class Initialized
DEBUG - 2023-04-03 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:35:52 --> Input Class Initialized
INFO - 2023-04-03 09:35:52 --> Language Class Initialized
INFO - 2023-04-03 09:35:52 --> Loader Class Initialized
INFO - 2023-04-03 09:35:52 --> Controller Class Initialized
INFO - 2023-04-03 09:35:52 --> Helper loaded: form_helper
INFO - 2023-04-03 09:35:52 --> Helper loaded: url_helper
DEBUG - 2023-04-03 09:35:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:35:52 --> Final output sent to browser
DEBUG - 2023-04-03 09:35:52 --> Total execution time: 0.0061
INFO - 2023-04-03 09:35:52 --> Config Class Initialized
INFO - 2023-04-03 09:35:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:35:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:35:52 --> Utf8 Class Initialized
INFO - 2023-04-03 09:35:52 --> URI Class Initialized
INFO - 2023-04-03 09:35:52 --> Router Class Initialized
INFO - 2023-04-03 09:35:52 --> Output Class Initialized
INFO - 2023-04-03 09:35:52 --> Security Class Initialized
DEBUG - 2023-04-03 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:35:52 --> Input Class Initialized
INFO - 2023-04-03 09:35:52 --> Language Class Initialized
INFO - 2023-04-03 09:35:52 --> Loader Class Initialized
INFO - 2023-04-03 09:35:52 --> Controller Class Initialized
INFO - 2023-04-03 09:35:52 --> Helper loaded: form_helper
INFO - 2023-04-03 09:35:52 --> Helper loaded: url_helper
DEBUG - 2023-04-03 09:35:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:35:52 --> Database Driver Class Initialized
INFO - 2023-04-03 09:35:52 --> Model "Login_model" initialized
INFO - 2023-04-03 09:35:52 --> Final output sent to browser
DEBUG - 2023-04-03 09:35:52 --> Total execution time: 0.0187
INFO - 2023-04-03 09:35:52 --> Config Class Initialized
INFO - 2023-04-03 09:35:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:35:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:35:53 --> Utf8 Class Initialized
INFO - 2023-04-03 09:35:53 --> URI Class Initialized
INFO - 2023-04-03 09:35:53 --> Router Class Initialized
INFO - 2023-04-03 09:35:53 --> Output Class Initialized
INFO - 2023-04-03 09:35:53 --> Security Class Initialized
DEBUG - 2023-04-03 09:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:35:53 --> Input Class Initialized
INFO - 2023-04-03 09:35:53 --> Language Class Initialized
INFO - 2023-04-03 09:35:53 --> Loader Class Initialized
INFO - 2023-04-03 09:35:53 --> Controller Class Initialized
DEBUG - 2023-04-03 09:35:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:35:53 --> Database Driver Class Initialized
INFO - 2023-04-03 09:35:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:35:53 --> Final output sent to browser
DEBUG - 2023-04-03 09:35:53 --> Total execution time: 0.0537
INFO - 2023-04-03 09:35:53 --> Config Class Initialized
INFO - 2023-04-03 09:35:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:35:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:35:53 --> Utf8 Class Initialized
INFO - 2023-04-03 09:35:53 --> URI Class Initialized
INFO - 2023-04-03 09:35:53 --> Router Class Initialized
INFO - 2023-04-03 09:35:53 --> Output Class Initialized
INFO - 2023-04-03 09:35:53 --> Security Class Initialized
DEBUG - 2023-04-03 09:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:35:53 --> Input Class Initialized
INFO - 2023-04-03 09:35:53 --> Language Class Initialized
INFO - 2023-04-03 09:35:53 --> Loader Class Initialized
INFO - 2023-04-03 09:35:53 --> Controller Class Initialized
DEBUG - 2023-04-03 09:35:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:35:53 --> Database Driver Class Initialized
INFO - 2023-04-03 09:35:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:35:53 --> Final output sent to browser
DEBUG - 2023-04-03 09:35:53 --> Total execution time: 0.0138
INFO - 2023-04-03 09:35:53 --> Config Class Initialized
INFO - 2023-04-03 09:35:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:35:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:35:53 --> Utf8 Class Initialized
INFO - 2023-04-03 09:35:53 --> URI Class Initialized
INFO - 2023-04-03 09:35:53 --> Router Class Initialized
INFO - 2023-04-03 09:35:53 --> Output Class Initialized
INFO - 2023-04-03 09:35:53 --> Security Class Initialized
DEBUG - 2023-04-03 09:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:35:53 --> Input Class Initialized
INFO - 2023-04-03 09:35:53 --> Language Class Initialized
INFO - 2023-04-03 09:35:53 --> Loader Class Initialized
INFO - 2023-04-03 09:35:53 --> Controller Class Initialized
DEBUG - 2023-04-03 09:35:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:35:53 --> Database Driver Class Initialized
INFO - 2023-04-03 09:35:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:35:53 --> Database Driver Class Initialized
INFO - 2023-04-03 09:35:53 --> Model "Login_model" initialized
INFO - 2023-04-03 09:35:53 --> Final output sent to browser
DEBUG - 2023-04-03 09:35:53 --> Total execution time: 0.1171
INFO - 2023-04-03 09:35:53 --> Config Class Initialized
INFO - 2023-04-03 09:35:53 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:35:53 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:35:53 --> Utf8 Class Initialized
INFO - 2023-04-03 09:35:53 --> URI Class Initialized
INFO - 2023-04-03 09:35:53 --> Router Class Initialized
INFO - 2023-04-03 09:35:53 --> Output Class Initialized
INFO - 2023-04-03 09:35:53 --> Security Class Initialized
DEBUG - 2023-04-03 09:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:35:53 --> Input Class Initialized
INFO - 2023-04-03 09:35:53 --> Language Class Initialized
INFO - 2023-04-03 09:35:53 --> Loader Class Initialized
INFO - 2023-04-03 09:35:53 --> Controller Class Initialized
DEBUG - 2023-04-03 09:35:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:35:53 --> Database Driver Class Initialized
INFO - 2023-04-03 09:35:53 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:35:53 --> Database Driver Class Initialized
INFO - 2023-04-03 09:35:53 --> Model "Login_model" initialized
INFO - 2023-04-03 09:35:53 --> Final output sent to browser
DEBUG - 2023-04-03 09:35:53 --> Total execution time: 0.1162
INFO - 2023-04-03 09:36:14 --> Config Class Initialized
INFO - 2023-04-03 09:36:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:14 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:14 --> URI Class Initialized
INFO - 2023-04-03 09:36:14 --> Router Class Initialized
INFO - 2023-04-03 09:36:14 --> Output Class Initialized
INFO - 2023-04-03 09:36:14 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:14 --> Input Class Initialized
INFO - 2023-04-03 09:36:14 --> Language Class Initialized
INFO - 2023-04-03 09:36:14 --> Loader Class Initialized
INFO - 2023-04-03 09:36:14 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:14 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:14 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:14 --> Total execution time: 0.0145
INFO - 2023-04-03 09:36:14 --> Config Class Initialized
INFO - 2023-04-03 09:36:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:14 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:14 --> URI Class Initialized
INFO - 2023-04-03 09:36:14 --> Router Class Initialized
INFO - 2023-04-03 09:36:14 --> Output Class Initialized
INFO - 2023-04-03 09:36:14 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:14 --> Input Class Initialized
INFO - 2023-04-03 09:36:14 --> Language Class Initialized
INFO - 2023-04-03 09:36:14 --> Loader Class Initialized
INFO - 2023-04-03 09:36:14 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:14 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:14 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:14 --> Total execution time: 0.0557
INFO - 2023-04-03 09:36:16 --> Config Class Initialized
INFO - 2023-04-03 09:36:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:16 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:16 --> URI Class Initialized
INFO - 2023-04-03 09:36:16 --> Router Class Initialized
INFO - 2023-04-03 09:36:16 --> Output Class Initialized
INFO - 2023-04-03 09:36:16 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:16 --> Input Class Initialized
INFO - 2023-04-03 09:36:16 --> Language Class Initialized
INFO - 2023-04-03 09:36:16 --> Loader Class Initialized
INFO - 2023-04-03 09:36:16 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:16 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:16 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:16 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:16 --> Total execution time: 0.0423
INFO - 2023-04-03 09:36:16 --> Config Class Initialized
INFO - 2023-04-03 09:36:16 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:16 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:16 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:16 --> URI Class Initialized
INFO - 2023-04-03 09:36:16 --> Router Class Initialized
INFO - 2023-04-03 09:36:16 --> Output Class Initialized
INFO - 2023-04-03 09:36:16 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:16 --> Input Class Initialized
INFO - 2023-04-03 09:36:16 --> Language Class Initialized
INFO - 2023-04-03 09:36:16 --> Loader Class Initialized
INFO - 2023-04-03 09:36:16 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:16 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:16 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:17 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:17 --> Total execution time: 0.0818
INFO - 2023-04-03 09:36:22 --> Config Class Initialized
INFO - 2023-04-03 09:36:22 --> Config Class Initialized
INFO - 2023-04-03 09:36:22 --> Hooks Class Initialized
INFO - 2023-04-03 09:36:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:22 --> Utf8 Class Initialized
DEBUG - 2023-04-03 09:36:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:22 --> URI Class Initialized
INFO - 2023-04-03 09:36:22 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:22 --> Router Class Initialized
INFO - 2023-04-03 09:36:22 --> URI Class Initialized
INFO - 2023-04-03 09:36:22 --> Output Class Initialized
INFO - 2023-04-03 09:36:22 --> Router Class Initialized
INFO - 2023-04-03 09:36:22 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:22 --> Output Class Initialized
INFO - 2023-04-03 09:36:22 --> Input Class Initialized
INFO - 2023-04-03 09:36:22 --> Security Class Initialized
INFO - 2023-04-03 09:36:22 --> Language Class Initialized
DEBUG - 2023-04-03 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:22 --> Input Class Initialized
INFO - 2023-04-03 09:36:22 --> Loader Class Initialized
INFO - 2023-04-03 09:36:22 --> Language Class Initialized
INFO - 2023-04-03 09:36:22 --> Controller Class Initialized
INFO - 2023-04-03 09:36:22 --> Loader Class Initialized
DEBUG - 2023-04-03 09:36:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:22 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:22 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:22 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:22 --> Total execution time: 0.0123
INFO - 2023-04-03 09:36:22 --> Config Class Initialized
INFO - 2023-04-03 09:36:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:22 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:22 --> URI Class Initialized
INFO - 2023-04-03 09:36:22 --> Router Class Initialized
INFO - 2023-04-03 09:36:22 --> Output Class Initialized
INFO - 2023-04-03 09:36:22 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:22 --> Input Class Initialized
INFO - 2023-04-03 09:36:22 --> Language Class Initialized
INFO - 2023-04-03 09:36:22 --> Loader Class Initialized
INFO - 2023-04-03 09:36:22 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:22 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:22 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:22 --> Total execution time: 0.0449
INFO - 2023-04-03 09:36:22 --> Config Class Initialized
INFO - 2023-04-03 09:36:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:22 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:22 --> URI Class Initialized
INFO - 2023-04-03 09:36:22 --> Router Class Initialized
INFO - 2023-04-03 09:36:22 --> Output Class Initialized
INFO - 2023-04-03 09:36:22 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:22 --> Input Class Initialized
INFO - 2023-04-03 09:36:22 --> Language Class Initialized
INFO - 2023-04-03 09:36:22 --> Loader Class Initialized
INFO - 2023-04-03 09:36:22 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:22 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:22 --> Model "Login_model" initialized
INFO - 2023-04-03 09:36:22 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:22 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:22 --> Total execution time: 0.0135
INFO - 2023-04-03 09:36:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:22 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:22 --> Total execution time: 0.0888
INFO - 2023-04-03 09:36:24 --> Config Class Initialized
INFO - 2023-04-03 09:36:24 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:24 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:24 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:24 --> URI Class Initialized
INFO - 2023-04-03 09:36:24 --> Router Class Initialized
INFO - 2023-04-03 09:36:24 --> Output Class Initialized
INFO - 2023-04-03 09:36:24 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:24 --> Input Class Initialized
INFO - 2023-04-03 09:36:24 --> Language Class Initialized
INFO - 2023-04-03 09:36:24 --> Loader Class Initialized
INFO - 2023-04-03 09:36:24 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:24 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:24 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:24 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:24 --> Model "Login_model" initialized
INFO - 2023-04-03 09:36:24 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:24 --> Total execution time: 0.1062
INFO - 2023-04-03 09:36:24 --> Config Class Initialized
INFO - 2023-04-03 09:36:24 --> Hooks Class Initialized
DEBUG - 2023-04-03 09:36:24 --> UTF-8 Support Enabled
INFO - 2023-04-03 09:36:24 --> Utf8 Class Initialized
INFO - 2023-04-03 09:36:24 --> URI Class Initialized
INFO - 2023-04-03 09:36:24 --> Router Class Initialized
INFO - 2023-04-03 09:36:24 --> Output Class Initialized
INFO - 2023-04-03 09:36:24 --> Security Class Initialized
DEBUG - 2023-04-03 09:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 09:36:24 --> Input Class Initialized
INFO - 2023-04-03 09:36:24 --> Language Class Initialized
INFO - 2023-04-03 09:36:24 --> Loader Class Initialized
INFO - 2023-04-03 09:36:25 --> Controller Class Initialized
DEBUG - 2023-04-03 09:36:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 09:36:25 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 09:36:25 --> Database Driver Class Initialized
INFO - 2023-04-03 09:36:25 --> Model "Login_model" initialized
INFO - 2023-04-03 09:36:25 --> Final output sent to browser
DEBUG - 2023-04-03 09:36:25 --> Total execution time: 0.1022
INFO - 2023-04-03 10:17:23 --> Config Class Initialized
INFO - 2023-04-03 10:17:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:23 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:23 --> URI Class Initialized
INFO - 2023-04-03 10:17:23 --> Router Class Initialized
INFO - 2023-04-03 10:17:23 --> Output Class Initialized
INFO - 2023-04-03 10:17:23 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:23 --> Input Class Initialized
INFO - 2023-04-03 10:17:23 --> Language Class Initialized
INFO - 2023-04-03 10:17:23 --> Loader Class Initialized
INFO - 2023-04-03 10:17:23 --> Controller Class Initialized
INFO - 2023-04-03 10:17:23 --> Helper loaded: form_helper
INFO - 2023-04-03 10:17:23 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:17:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:23 --> Model "Change_model" initialized
INFO - 2023-04-03 10:17:23 --> Model "Grafana_model" initialized
INFO - 2023-04-03 10:17:23 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:23 --> Total execution time: 0.0294
INFO - 2023-04-03 10:17:23 --> Config Class Initialized
INFO - 2023-04-03 10:17:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:23 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:23 --> URI Class Initialized
INFO - 2023-04-03 10:17:23 --> Router Class Initialized
INFO - 2023-04-03 10:17:23 --> Output Class Initialized
INFO - 2023-04-03 10:17:23 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:23 --> Input Class Initialized
INFO - 2023-04-03 10:17:23 --> Language Class Initialized
INFO - 2023-04-03 10:17:23 --> Loader Class Initialized
INFO - 2023-04-03 10:17:23 --> Controller Class Initialized
INFO - 2023-04-03 10:17:23 --> Helper loaded: form_helper
INFO - 2023-04-03 10:17:23 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:17:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:23 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:23 --> Total execution time: 0.0878
INFO - 2023-04-03 10:17:23 --> Config Class Initialized
INFO - 2023-04-03 10:17:23 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:23 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:23 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:23 --> URI Class Initialized
INFO - 2023-04-03 10:17:23 --> Router Class Initialized
INFO - 2023-04-03 10:17:23 --> Output Class Initialized
INFO - 2023-04-03 10:17:23 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:23 --> Input Class Initialized
INFO - 2023-04-03 10:17:23 --> Language Class Initialized
INFO - 2023-04-03 10:17:23 --> Loader Class Initialized
INFO - 2023-04-03 10:17:23 --> Controller Class Initialized
INFO - 2023-04-03 10:17:23 --> Helper loaded: form_helper
INFO - 2023-04-03 10:17:23 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:17:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:23 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:23 --> Model "Login_model" initialized
INFO - 2023-04-03 10:17:23 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:23 --> Total execution time: 0.0137
INFO - 2023-04-03 10:17:33 --> Config Class Initialized
INFO - 2023-04-03 10:17:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:33 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:33 --> URI Class Initialized
INFO - 2023-04-03 10:17:33 --> Router Class Initialized
INFO - 2023-04-03 10:17:33 --> Output Class Initialized
INFO - 2023-04-03 10:17:33 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:33 --> Input Class Initialized
INFO - 2023-04-03 10:17:33 --> Language Class Initialized
INFO - 2023-04-03 10:17:33 --> Loader Class Initialized
INFO - 2023-04-03 10:17:33 --> Controller Class Initialized
INFO - 2023-04-03 10:17:33 --> Helper loaded: form_helper
INFO - 2023-04-03 10:17:33 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:17:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:33 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:33 --> Total execution time: 0.0025
INFO - 2023-04-03 10:17:33 --> Config Class Initialized
INFO - 2023-04-03 10:17:33 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:33 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:33 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:33 --> URI Class Initialized
INFO - 2023-04-03 10:17:33 --> Router Class Initialized
INFO - 2023-04-03 10:17:33 --> Output Class Initialized
INFO - 2023-04-03 10:17:33 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:33 --> Input Class Initialized
INFO - 2023-04-03 10:17:33 --> Language Class Initialized
INFO - 2023-04-03 10:17:33 --> Loader Class Initialized
INFO - 2023-04-03 10:17:33 --> Controller Class Initialized
INFO - 2023-04-03 10:17:33 --> Helper loaded: form_helper
INFO - 2023-04-03 10:17:33 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:17:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:33 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:33 --> Model "Login_model" initialized
INFO - 2023-04-03 10:17:33 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:33 --> Total execution time: 0.0221
INFO - 2023-04-03 10:17:38 --> Config Class Initialized
INFO - 2023-04-03 10:17:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:38 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:38 --> URI Class Initialized
INFO - 2023-04-03 10:17:38 --> Router Class Initialized
INFO - 2023-04-03 10:17:38 --> Output Class Initialized
INFO - 2023-04-03 10:17:38 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:38 --> Input Class Initialized
INFO - 2023-04-03 10:17:38 --> Language Class Initialized
INFO - 2023-04-03 10:17:38 --> Loader Class Initialized
INFO - 2023-04-03 10:17:38 --> Controller Class Initialized
INFO - 2023-04-03 10:17:38 --> Helper loaded: form_helper
INFO - 2023-04-03 10:17:38 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:17:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:38 --> Model "Change_model" initialized
INFO - 2023-04-03 10:17:38 --> Model "Grafana_model" initialized
INFO - 2023-04-03 10:17:38 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:38 --> Total execution time: 0.0232
INFO - 2023-04-03 10:17:38 --> Config Class Initialized
INFO - 2023-04-03 10:17:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:38 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:38 --> URI Class Initialized
INFO - 2023-04-03 10:17:38 --> Router Class Initialized
INFO - 2023-04-03 10:17:38 --> Output Class Initialized
INFO - 2023-04-03 10:17:38 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:38 --> Input Class Initialized
INFO - 2023-04-03 10:17:38 --> Language Class Initialized
INFO - 2023-04-03 10:17:38 --> Loader Class Initialized
INFO - 2023-04-03 10:17:38 --> Controller Class Initialized
INFO - 2023-04-03 10:17:38 --> Helper loaded: form_helper
INFO - 2023-04-03 10:17:38 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:17:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:38 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:38 --> Total execution time: 0.0027
INFO - 2023-04-03 10:17:38 --> Config Class Initialized
INFO - 2023-04-03 10:17:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:38 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:38 --> URI Class Initialized
INFO - 2023-04-03 10:17:38 --> Router Class Initialized
INFO - 2023-04-03 10:17:38 --> Output Class Initialized
INFO - 2023-04-03 10:17:38 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:38 --> Input Class Initialized
INFO - 2023-04-03 10:17:38 --> Language Class Initialized
INFO - 2023-04-03 10:17:38 --> Loader Class Initialized
INFO - 2023-04-03 10:17:38 --> Controller Class Initialized
INFO - 2023-04-03 10:17:38 --> Helper loaded: form_helper
INFO - 2023-04-03 10:17:38 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:17:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:38 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:38 --> Model "Login_model" initialized
INFO - 2023-04-03 10:17:38 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:38 --> Total execution time: 0.0138
INFO - 2023-04-03 10:17:38 --> Config Class Initialized
INFO - 2023-04-03 10:17:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:38 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:38 --> URI Class Initialized
INFO - 2023-04-03 10:17:38 --> Router Class Initialized
INFO - 2023-04-03 10:17:38 --> Output Class Initialized
INFO - 2023-04-03 10:17:38 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:38 --> Input Class Initialized
INFO - 2023-04-03 10:17:38 --> Language Class Initialized
INFO - 2023-04-03 10:17:38 --> Loader Class Initialized
INFO - 2023-04-03 10:17:38 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:38 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:38 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:38 --> Total execution time: 0.0128
INFO - 2023-04-03 10:17:38 --> Config Class Initialized
INFO - 2023-04-03 10:17:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:38 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:38 --> URI Class Initialized
INFO - 2023-04-03 10:17:38 --> Router Class Initialized
INFO - 2023-04-03 10:17:38 --> Output Class Initialized
INFO - 2023-04-03 10:17:38 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:38 --> Input Class Initialized
INFO - 2023-04-03 10:17:38 --> Language Class Initialized
INFO - 2023-04-03 10:17:38 --> Loader Class Initialized
INFO - 2023-04-03 10:17:38 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:38 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:38 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:38 --> Total execution time: 0.0119
INFO - 2023-04-03 10:17:38 --> Config Class Initialized
INFO - 2023-04-03 10:17:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:38 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:38 --> URI Class Initialized
INFO - 2023-04-03 10:17:38 --> Router Class Initialized
INFO - 2023-04-03 10:17:38 --> Output Class Initialized
INFO - 2023-04-03 10:17:38 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:38 --> Input Class Initialized
INFO - 2023-04-03 10:17:38 --> Language Class Initialized
INFO - 2023-04-03 10:17:38 --> Loader Class Initialized
INFO - 2023-04-03 10:17:38 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:38 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:38 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:38 --> Total execution time: 0.0609
INFO - 2023-04-03 10:17:38 --> Config Class Initialized
INFO - 2023-04-03 10:17:38 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:38 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:38 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:38 --> URI Class Initialized
INFO - 2023-04-03 10:17:38 --> Router Class Initialized
INFO - 2023-04-03 10:17:38 --> Output Class Initialized
INFO - 2023-04-03 10:17:38 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:38 --> Input Class Initialized
INFO - 2023-04-03 10:17:38 --> Language Class Initialized
INFO - 2023-04-03 10:17:38 --> Loader Class Initialized
INFO - 2023-04-03 10:17:38 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:38 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:38 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:38 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:38 --> Total execution time: 0.0567
INFO - 2023-04-03 10:17:42 --> Config Class Initialized
INFO - 2023-04-03 10:17:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:42 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:42 --> URI Class Initialized
INFO - 2023-04-03 10:17:42 --> Router Class Initialized
INFO - 2023-04-03 10:17:42 --> Output Class Initialized
INFO - 2023-04-03 10:17:42 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:42 --> Input Class Initialized
INFO - 2023-04-03 10:17:42 --> Language Class Initialized
INFO - 2023-04-03 10:17:42 --> Loader Class Initialized
INFO - 2023-04-03 10:17:42 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:42 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:42 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:42 --> Total execution time: 0.0112
INFO - 2023-04-03 10:17:42 --> Config Class Initialized
INFO - 2023-04-03 10:17:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:42 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:42 --> URI Class Initialized
INFO - 2023-04-03 10:17:42 --> Router Class Initialized
INFO - 2023-04-03 10:17:42 --> Output Class Initialized
INFO - 2023-04-03 10:17:42 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:42 --> Input Class Initialized
INFO - 2023-04-03 10:17:42 --> Language Class Initialized
INFO - 2023-04-03 10:17:42 --> Loader Class Initialized
INFO - 2023-04-03 10:17:42 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:42 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:42 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:42 --> Model "Login_model" initialized
INFO - 2023-04-03 10:17:42 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:42 --> Total execution time: 0.0173
INFO - 2023-04-03 10:17:43 --> Config Class Initialized
INFO - 2023-04-03 10:17:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:43 --> URI Class Initialized
INFO - 2023-04-03 10:17:43 --> Router Class Initialized
INFO - 2023-04-03 10:17:43 --> Output Class Initialized
INFO - 2023-04-03 10:17:43 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:43 --> Input Class Initialized
INFO - 2023-04-03 10:17:43 --> Language Class Initialized
INFO - 2023-04-03 10:17:43 --> Loader Class Initialized
INFO - 2023-04-03 10:17:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:43 --> Total execution time: 0.0146
INFO - 2023-04-03 10:17:43 --> Config Class Initialized
INFO - 2023-04-03 10:17:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:43 --> URI Class Initialized
INFO - 2023-04-03 10:17:43 --> Router Class Initialized
INFO - 2023-04-03 10:17:43 --> Output Class Initialized
INFO - 2023-04-03 10:17:43 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:43 --> Input Class Initialized
INFO - 2023-04-03 10:17:43 --> Language Class Initialized
INFO - 2023-04-03 10:17:43 --> Loader Class Initialized
INFO - 2023-04-03 10:17:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:43 --> Total execution time: 0.0542
INFO - 2023-04-03 10:17:44 --> Config Class Initialized
INFO - 2023-04-03 10:17:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:44 --> URI Class Initialized
INFO - 2023-04-03 10:17:44 --> Router Class Initialized
INFO - 2023-04-03 10:17:44 --> Output Class Initialized
INFO - 2023-04-03 10:17:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:44 --> Input Class Initialized
INFO - 2023-04-03 10:17:44 --> Language Class Initialized
INFO - 2023-04-03 10:17:44 --> Loader Class Initialized
INFO - 2023-04-03 10:17:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:44 --> Model "Login_model" initialized
INFO - 2023-04-03 10:17:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:44 --> Total execution time: 0.0627
INFO - 2023-04-03 10:17:45 --> Config Class Initialized
INFO - 2023-04-03 10:17:45 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:45 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:45 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:45 --> URI Class Initialized
INFO - 2023-04-03 10:17:45 --> Router Class Initialized
INFO - 2023-04-03 10:17:45 --> Output Class Initialized
INFO - 2023-04-03 10:17:45 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:45 --> Input Class Initialized
INFO - 2023-04-03 10:17:45 --> Language Class Initialized
INFO - 2023-04-03 10:17:45 --> Loader Class Initialized
INFO - 2023-04-03 10:17:45 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:45 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:45 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:45 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:45 --> Total execution time: 0.0142
INFO - 2023-04-03 10:17:45 --> Config Class Initialized
INFO - 2023-04-03 10:17:45 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:45 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:45 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:45 --> URI Class Initialized
INFO - 2023-04-03 10:17:45 --> Router Class Initialized
INFO - 2023-04-03 10:17:45 --> Output Class Initialized
INFO - 2023-04-03 10:17:45 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:45 --> Input Class Initialized
INFO - 2023-04-03 10:17:45 --> Language Class Initialized
INFO - 2023-04-03 10:17:45 --> Loader Class Initialized
INFO - 2023-04-03 10:17:45 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:45 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:45 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:45 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:45 --> Total execution time: 0.0113
INFO - 2023-04-03 10:17:49 --> Config Class Initialized
INFO - 2023-04-03 10:17:49 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:49 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:49 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:49 --> URI Class Initialized
INFO - 2023-04-03 10:17:49 --> Router Class Initialized
INFO - 2023-04-03 10:17:49 --> Output Class Initialized
INFO - 2023-04-03 10:17:49 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:49 --> Input Class Initialized
INFO - 2023-04-03 10:17:49 --> Language Class Initialized
INFO - 2023-04-03 10:17:49 --> Loader Class Initialized
INFO - 2023-04-03 10:17:49 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:49 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:49 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:49 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:49 --> Total execution time: 0.0118
INFO - 2023-04-03 10:17:49 --> Config Class Initialized
INFO - 2023-04-03 10:17:49 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:49 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:49 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:49 --> URI Class Initialized
INFO - 2023-04-03 10:17:49 --> Router Class Initialized
INFO - 2023-04-03 10:17:49 --> Output Class Initialized
INFO - 2023-04-03 10:17:49 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:49 --> Input Class Initialized
INFO - 2023-04-03 10:17:49 --> Language Class Initialized
INFO - 2023-04-03 10:17:49 --> Loader Class Initialized
INFO - 2023-04-03 10:17:49 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:49 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:49 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:49 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:49 --> Total execution time: 0.0520
INFO - 2023-04-03 10:17:49 --> Config Class Initialized
INFO - 2023-04-03 10:17:49 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:49 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:49 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:49 --> URI Class Initialized
INFO - 2023-04-03 10:17:49 --> Router Class Initialized
INFO - 2023-04-03 10:17:49 --> Output Class Initialized
INFO - 2023-04-03 10:17:49 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:49 --> Input Class Initialized
INFO - 2023-04-03 10:17:49 --> Language Class Initialized
INFO - 2023-04-03 10:17:49 --> Loader Class Initialized
INFO - 2023-04-03 10:17:49 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:49 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:49 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:49 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:49 --> Total execution time: 0.0529
INFO - 2023-04-03 10:17:49 --> Config Class Initialized
INFO - 2023-04-03 10:17:49 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:17:49 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:17:49 --> Utf8 Class Initialized
INFO - 2023-04-03 10:17:49 --> URI Class Initialized
INFO - 2023-04-03 10:17:49 --> Router Class Initialized
INFO - 2023-04-03 10:17:49 --> Output Class Initialized
INFO - 2023-04-03 10:17:49 --> Security Class Initialized
DEBUG - 2023-04-03 10:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:17:49 --> Input Class Initialized
INFO - 2023-04-03 10:17:49 --> Language Class Initialized
INFO - 2023-04-03 10:17:49 --> Loader Class Initialized
INFO - 2023-04-03 10:17:49 --> Controller Class Initialized
DEBUG - 2023-04-03 10:17:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:17:49 --> Database Driver Class Initialized
INFO - 2023-04-03 10:17:49 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:17:49 --> Final output sent to browser
DEBUG - 2023-04-03 10:17:49 --> Total execution time: 0.0547
INFO - 2023-04-03 10:18:06 --> Config Class Initialized
INFO - 2023-04-03 10:18:06 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:06 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:06 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:06 --> URI Class Initialized
INFO - 2023-04-03 10:18:06 --> Router Class Initialized
INFO - 2023-04-03 10:18:06 --> Output Class Initialized
INFO - 2023-04-03 10:18:06 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:06 --> Input Class Initialized
INFO - 2023-04-03 10:18:06 --> Language Class Initialized
INFO - 2023-04-03 10:18:06 --> Loader Class Initialized
INFO - 2023-04-03 10:18:06 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:06 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:06 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:06 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:06 --> Total execution time: 0.0174
INFO - 2023-04-03 10:18:06 --> Config Class Initialized
INFO - 2023-04-03 10:18:06 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:06 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:06 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:06 --> URI Class Initialized
INFO - 2023-04-03 10:18:06 --> Router Class Initialized
INFO - 2023-04-03 10:18:06 --> Output Class Initialized
INFO - 2023-04-03 10:18:06 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:06 --> Input Class Initialized
INFO - 2023-04-03 10:18:06 --> Language Class Initialized
INFO - 2023-04-03 10:18:06 --> Loader Class Initialized
INFO - 2023-04-03 10:18:06 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:06 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:06 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:06 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:06 --> Model "Login_model" initialized
INFO - 2023-04-03 10:18:06 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:06 --> Total execution time: 0.0328
INFO - 2023-04-03 10:18:06 --> Config Class Initialized
INFO - 2023-04-03 10:18:06 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:06 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:06 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:06 --> URI Class Initialized
INFO - 2023-04-03 10:18:06 --> Router Class Initialized
INFO - 2023-04-03 10:18:06 --> Output Class Initialized
INFO - 2023-04-03 10:18:06 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:06 --> Input Class Initialized
INFO - 2023-04-03 10:18:06 --> Language Class Initialized
INFO - 2023-04-03 10:18:06 --> Loader Class Initialized
INFO - 2023-04-03 10:18:06 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:06 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:06 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:06 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:06 --> Total execution time: 0.0126
INFO - 2023-04-03 10:18:06 --> Config Class Initialized
INFO - 2023-04-03 10:18:06 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:06 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:06 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:06 --> URI Class Initialized
INFO - 2023-04-03 10:18:06 --> Router Class Initialized
INFO - 2023-04-03 10:18:06 --> Output Class Initialized
INFO - 2023-04-03 10:18:06 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:06 --> Input Class Initialized
INFO - 2023-04-03 10:18:06 --> Language Class Initialized
INFO - 2023-04-03 10:18:06 --> Loader Class Initialized
INFO - 2023-04-03 10:18:06 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:06 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:06 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:06 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:06 --> Total execution time: 0.0118
INFO - 2023-04-03 10:18:11 --> Config Class Initialized
INFO - 2023-04-03 10:18:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:11 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:11 --> URI Class Initialized
INFO - 2023-04-03 10:18:11 --> Router Class Initialized
INFO - 2023-04-03 10:18:11 --> Output Class Initialized
INFO - 2023-04-03 10:18:11 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:11 --> Input Class Initialized
INFO - 2023-04-03 10:18:11 --> Language Class Initialized
INFO - 2023-04-03 10:18:11 --> Loader Class Initialized
INFO - 2023-04-03 10:18:11 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:11 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:11 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:11 --> Total execution time: 0.0175
INFO - 2023-04-03 10:18:44 --> Config Class Initialized
INFO - 2023-04-03 10:18:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:44 --> URI Class Initialized
INFO - 2023-04-03 10:18:44 --> Router Class Initialized
INFO - 2023-04-03 10:18:44 --> Output Class Initialized
INFO - 2023-04-03 10:18:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:44 --> Input Class Initialized
INFO - 2023-04-03 10:18:44 --> Language Class Initialized
INFO - 2023-04-03 10:18:44 --> Loader Class Initialized
INFO - 2023-04-03 10:18:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:44 --> Total execution time: 0.0167
INFO - 2023-04-03 10:18:44 --> Config Class Initialized
INFO - 2023-04-03 10:18:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:44 --> URI Class Initialized
INFO - 2023-04-03 10:18:44 --> Router Class Initialized
INFO - 2023-04-03 10:18:44 --> Output Class Initialized
INFO - 2023-04-03 10:18:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:44 --> Input Class Initialized
INFO - 2023-04-03 10:18:44 --> Language Class Initialized
INFO - 2023-04-03 10:18:44 --> Loader Class Initialized
INFO - 2023-04-03 10:18:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:44 --> Total execution time: 0.0104
INFO - 2023-04-03 10:18:44 --> Config Class Initialized
INFO - 2023-04-03 10:18:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:44 --> URI Class Initialized
INFO - 2023-04-03 10:18:44 --> Router Class Initialized
INFO - 2023-04-03 10:18:44 --> Output Class Initialized
INFO - 2023-04-03 10:18:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:44 --> Input Class Initialized
INFO - 2023-04-03 10:18:44 --> Language Class Initialized
INFO - 2023-04-03 10:18:44 --> Loader Class Initialized
INFO - 2023-04-03 10:18:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:44 --> Total execution time: 0.0104
INFO - 2023-04-03 10:18:44 --> Config Class Initialized
INFO - 2023-04-03 10:18:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:18:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:18:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:18:44 --> URI Class Initialized
INFO - 2023-04-03 10:18:44 --> Router Class Initialized
INFO - 2023-04-03 10:18:44 --> Output Class Initialized
INFO - 2023-04-03 10:18:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:18:44 --> Input Class Initialized
INFO - 2023-04-03 10:18:44 --> Language Class Initialized
INFO - 2023-04-03 10:18:44 --> Loader Class Initialized
INFO - 2023-04-03 10:18:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:18:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:18:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:18:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:18:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:18:44 --> Total execution time: 0.0112
INFO - 2023-04-03 10:19:07 --> Config Class Initialized
INFO - 2023-04-03 10:19:07 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:07 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:07 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:07 --> URI Class Initialized
INFO - 2023-04-03 10:19:07 --> Router Class Initialized
INFO - 2023-04-03 10:19:07 --> Output Class Initialized
INFO - 2023-04-03 10:19:07 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:07 --> Input Class Initialized
INFO - 2023-04-03 10:19:07 --> Language Class Initialized
INFO - 2023-04-03 10:19:07 --> Loader Class Initialized
INFO - 2023-04-03 10:19:07 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:07 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:07 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:07 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:07 --> Total execution time: 0.0113
INFO - 2023-04-03 10:19:08 --> Config Class Initialized
INFO - 2023-04-03 10:19:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:08 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:08 --> URI Class Initialized
INFO - 2023-04-03 10:19:08 --> Router Class Initialized
INFO - 2023-04-03 10:19:08 --> Output Class Initialized
INFO - 2023-04-03 10:19:08 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:08 --> Input Class Initialized
INFO - 2023-04-03 10:19:08 --> Language Class Initialized
INFO - 2023-04-03 10:19:08 --> Loader Class Initialized
INFO - 2023-04-03 10:19:08 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:08 --> Model "Login_model" initialized
INFO - 2023-04-03 10:19:08 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:08 --> Total execution time: 0.0305
INFO - 2023-04-03 10:19:08 --> Config Class Initialized
INFO - 2023-04-03 10:19:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:08 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:08 --> URI Class Initialized
INFO - 2023-04-03 10:19:08 --> Router Class Initialized
INFO - 2023-04-03 10:19:08 --> Output Class Initialized
INFO - 2023-04-03 10:19:08 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:08 --> Input Class Initialized
INFO - 2023-04-03 10:19:08 --> Language Class Initialized
INFO - 2023-04-03 10:19:08 --> Loader Class Initialized
INFO - 2023-04-03 10:19:08 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:08 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:08 --> Total execution time: 0.0144
INFO - 2023-04-03 10:19:08 --> Config Class Initialized
INFO - 2023-04-03 10:19:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:08 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:08 --> URI Class Initialized
INFO - 2023-04-03 10:19:08 --> Router Class Initialized
INFO - 2023-04-03 10:19:08 --> Output Class Initialized
INFO - 2023-04-03 10:19:08 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:08 --> Input Class Initialized
INFO - 2023-04-03 10:19:08 --> Language Class Initialized
INFO - 2023-04-03 10:19:08 --> Loader Class Initialized
INFO - 2023-04-03 10:19:08 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:08 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:08 --> Total execution time: 0.0180
INFO - 2023-04-03 10:19:13 --> Config Class Initialized
INFO - 2023-04-03 10:19:13 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:13 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:13 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:13 --> URI Class Initialized
INFO - 2023-04-03 10:19:13 --> Router Class Initialized
INFO - 2023-04-03 10:19:13 --> Output Class Initialized
INFO - 2023-04-03 10:19:13 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:13 --> Input Class Initialized
INFO - 2023-04-03 10:19:13 --> Language Class Initialized
INFO - 2023-04-03 10:19:13 --> Loader Class Initialized
INFO - 2023-04-03 10:19:13 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:13 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:13 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:13 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:13 --> Total execution time: 0.0139
INFO - 2023-04-03 10:19:43 --> Config Class Initialized
INFO - 2023-04-03 10:19:43 --> Config Class Initialized
INFO - 2023-04-03 10:19:43 --> Config Class Initialized
INFO - 2023-04-03 10:19:43 --> Hooks Class Initialized
INFO - 2023-04-03 10:19:43 --> Hooks Class Initialized
INFO - 2023-04-03 10:19:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:43 --> URI Class Initialized
INFO - 2023-04-03 10:19:43 --> URI Class Initialized
INFO - 2023-04-03 10:19:43 --> URI Class Initialized
INFO - 2023-04-03 10:19:43 --> Router Class Initialized
INFO - 2023-04-03 10:19:43 --> Router Class Initialized
INFO - 2023-04-03 10:19:43 --> Router Class Initialized
INFO - 2023-04-03 10:19:43 --> Output Class Initialized
INFO - 2023-04-03 10:19:43 --> Output Class Initialized
INFO - 2023-04-03 10:19:43 --> Output Class Initialized
INFO - 2023-04-03 10:19:43 --> Security Class Initialized
INFO - 2023-04-03 10:19:43 --> Security Class Initialized
INFO - 2023-04-03 10:19:43 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:43 --> Input Class Initialized
INFO - 2023-04-03 10:19:43 --> Language Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:43 --> Input Class Initialized
INFO - 2023-04-03 10:19:43 --> Loader Class Initialized
INFO - 2023-04-03 10:19:43 --> Language Class Initialized
INFO - 2023-04-03 10:19:43 --> Input Class Initialized
INFO - 2023-04-03 10:19:43 --> Controller Class Initialized
INFO - 2023-04-03 10:19:43 --> Language Class Initialized
INFO - 2023-04-03 10:19:43 --> Loader Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:43 --> Controller Class Initialized
INFO - 2023-04-03 10:19:43 --> Loader Class Initialized
INFO - 2023-04-03 10:19:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Model "Login_model" initialized
INFO - 2023-04-03 10:19:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:43 --> Total execution time: 0.0259
INFO - 2023-04-03 10:19:43 --> Config Class Initialized
INFO - 2023-04-03 10:19:43 --> Final output sent to browser
INFO - 2023-04-03 10:19:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:43 --> Total execution time: 0.0489
DEBUG - 2023-04-03 10:19:43 --> Total execution time: 0.0496
INFO - 2023-04-03 10:19:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:43 --> URI Class Initialized
INFO - 2023-04-03 10:19:43 --> Config Class Initialized
INFO - 2023-04-03 10:19:43 --> Hooks Class Initialized
INFO - 2023-04-03 10:19:43 --> Router Class Initialized
DEBUG - 2023-04-03 10:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:43 --> Output Class Initialized
INFO - 2023-04-03 10:19:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:43 --> Security Class Initialized
INFO - 2023-04-03 10:19:43 --> URI Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:43 --> Config Class Initialized
INFO - 2023-04-03 10:19:43 --> Input Class Initialized
INFO - 2023-04-03 10:19:43 --> Hooks Class Initialized
INFO - 2023-04-03 10:19:43 --> Language Class Initialized
INFO - 2023-04-03 10:19:43 --> Router Class Initialized
DEBUG - 2023-04-03 10:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:43 --> Loader Class Initialized
INFO - 2023-04-03 10:19:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:43 --> Output Class Initialized
INFO - 2023-04-03 10:19:43 --> Controller Class Initialized
INFO - 2023-04-03 10:19:43 --> URI Class Initialized
INFO - 2023-04-03 10:19:43 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:43 --> Router Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Output Class Initialized
INFO - 2023-04-03 10:19:43 --> Input Class Initialized
INFO - 2023-04-03 10:19:43 --> Security Class Initialized
INFO - 2023-04-03 10:19:43 --> Language Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:43 --> Input Class Initialized
INFO - 2023-04-03 10:19:43 --> Loader Class Initialized
INFO - 2023-04-03 10:19:43 --> Language Class Initialized
INFO - 2023-04-03 10:19:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:43 --> Loader Class Initialized
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:43 --> Model "Login_model" initialized
INFO - 2023-04-03 10:19:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:43 --> Total execution time: 0.0616
INFO - 2023-04-03 10:19:43 --> Config Class Initialized
INFO - 2023-04-03 10:19:43 --> Final output sent to browser
INFO - 2023-04-03 10:19:43 --> Final output sent to browser
INFO - 2023-04-03 10:19:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Total execution time: 0.1055
DEBUG - 2023-04-03 10:19:43 --> Total execution time: 0.0623
DEBUG - 2023-04-03 10:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:43 --> Config Class Initialized
INFO - 2023-04-03 10:19:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:43 --> Hooks Class Initialized
INFO - 2023-04-03 10:19:43 --> URI Class Initialized
DEBUG - 2023-04-03 10:19:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:43 --> Router Class Initialized
INFO - 2023-04-03 10:19:43 --> URI Class Initialized
INFO - 2023-04-03 10:19:43 --> Output Class Initialized
INFO - 2023-04-03 10:19:43 --> Router Class Initialized
INFO - 2023-04-03 10:19:43 --> Security Class Initialized
INFO - 2023-04-03 10:19:43 --> Output Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:43 --> Security Class Initialized
INFO - 2023-04-03 10:19:43 --> Input Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:43 --> Language Class Initialized
INFO - 2023-04-03 10:19:43 --> Input Class Initialized
INFO - 2023-04-03 10:19:43 --> Loader Class Initialized
INFO - 2023-04-03 10:19:43 --> Language Class Initialized
INFO - 2023-04-03 10:19:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:43 --> Loader Class Initialized
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:43 --> Total execution time: 0.1027
INFO - 2023-04-03 10:19:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:43 --> Total execution time: 0.1080
INFO - 2023-04-03 10:19:52 --> Config Class Initialized
INFO - 2023-04-03 10:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:52 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:52 --> URI Class Initialized
INFO - 2023-04-03 10:19:52 --> Router Class Initialized
INFO - 2023-04-03 10:19:52 --> Output Class Initialized
INFO - 2023-04-03 10:19:52 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:52 --> Input Class Initialized
INFO - 2023-04-03 10:19:52 --> Language Class Initialized
INFO - 2023-04-03 10:19:52 --> Loader Class Initialized
INFO - 2023-04-03 10:19:52 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:52 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:52 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:52 --> Total execution time: 0.0198
INFO - 2023-04-03 10:19:52 --> Config Class Initialized
INFO - 2023-04-03 10:19:52 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:52 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:52 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:52 --> URI Class Initialized
INFO - 2023-04-03 10:19:52 --> Router Class Initialized
INFO - 2023-04-03 10:19:52 --> Output Class Initialized
INFO - 2023-04-03 10:19:52 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:52 --> Input Class Initialized
INFO - 2023-04-03 10:19:52 --> Language Class Initialized
INFO - 2023-04-03 10:19:52 --> Loader Class Initialized
INFO - 2023-04-03 10:19:52 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:52 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:52 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:52 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:52 --> Total execution time: 0.0535
INFO - 2023-04-03 10:19:54 --> Config Class Initialized
INFO - 2023-04-03 10:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:54 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:54 --> URI Class Initialized
INFO - 2023-04-03 10:19:54 --> Router Class Initialized
INFO - 2023-04-03 10:19:54 --> Output Class Initialized
INFO - 2023-04-03 10:19:54 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:54 --> Input Class Initialized
INFO - 2023-04-03 10:19:54 --> Language Class Initialized
INFO - 2023-04-03 10:19:54 --> Loader Class Initialized
INFO - 2023-04-03 10:19:54 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:54 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:54 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:54 --> Total execution time: 0.0204
INFO - 2023-04-03 10:19:54 --> Config Class Initialized
INFO - 2023-04-03 10:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:19:54 --> Utf8 Class Initialized
INFO - 2023-04-03 10:19:54 --> URI Class Initialized
INFO - 2023-04-03 10:19:54 --> Router Class Initialized
INFO - 2023-04-03 10:19:54 --> Output Class Initialized
INFO - 2023-04-03 10:19:54 --> Security Class Initialized
DEBUG - 2023-04-03 10:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:19:54 --> Input Class Initialized
INFO - 2023-04-03 10:19:54 --> Language Class Initialized
INFO - 2023-04-03 10:19:54 --> Loader Class Initialized
INFO - 2023-04-03 10:19:54 --> Controller Class Initialized
DEBUG - 2023-04-03 10:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:19:54 --> Database Driver Class Initialized
INFO - 2023-04-03 10:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:19:54 --> Final output sent to browser
DEBUG - 2023-04-03 10:19:54 --> Total execution time: 0.0599
INFO - 2023-04-03 10:23:42 --> Config Class Initialized
INFO - 2023-04-03 10:23:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:23:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:23:42 --> Utf8 Class Initialized
INFO - 2023-04-03 10:23:42 --> URI Class Initialized
INFO - 2023-04-03 10:23:42 --> Router Class Initialized
INFO - 2023-04-03 10:23:42 --> Output Class Initialized
INFO - 2023-04-03 10:23:42 --> Security Class Initialized
DEBUG - 2023-04-03 10:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:23:42 --> Input Class Initialized
INFO - 2023-04-03 10:23:42 --> Language Class Initialized
INFO - 2023-04-03 10:23:42 --> Loader Class Initialized
INFO - 2023-04-03 10:23:42 --> Controller Class Initialized
DEBUG - 2023-04-03 10:23:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:23:42 --> Database Driver Class Initialized
INFO - 2023-04-03 10:23:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:23:42 --> Final output sent to browser
DEBUG - 2023-04-03 10:23:42 --> Total execution time: 0.0252
INFO - 2023-04-03 10:23:42 --> Config Class Initialized
INFO - 2023-04-03 10:23:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:23:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:23:42 --> Utf8 Class Initialized
INFO - 2023-04-03 10:23:42 --> URI Class Initialized
INFO - 2023-04-03 10:23:42 --> Router Class Initialized
INFO - 2023-04-03 10:23:42 --> Output Class Initialized
INFO - 2023-04-03 10:23:42 --> Security Class Initialized
DEBUG - 2023-04-03 10:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:23:42 --> Input Class Initialized
INFO - 2023-04-03 10:23:42 --> Language Class Initialized
INFO - 2023-04-03 10:23:42 --> Loader Class Initialized
INFO - 2023-04-03 10:23:42 --> Controller Class Initialized
DEBUG - 2023-04-03 10:23:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:23:42 --> Database Driver Class Initialized
INFO - 2023-04-03 10:23:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:23:42 --> Final output sent to browser
DEBUG - 2023-04-03 10:23:42 --> Total execution time: 0.1425
INFO - 2023-04-03 10:23:44 --> Config Class Initialized
INFO - 2023-04-03 10:23:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:23:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:23:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:23:44 --> URI Class Initialized
INFO - 2023-04-03 10:23:44 --> Router Class Initialized
INFO - 2023-04-03 10:23:44 --> Output Class Initialized
INFO - 2023-04-03 10:23:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:23:44 --> Input Class Initialized
INFO - 2023-04-03 10:23:44 --> Language Class Initialized
INFO - 2023-04-03 10:23:44 --> Loader Class Initialized
INFO - 2023-04-03 10:23:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:23:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:23:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:23:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:23:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:23:44 --> Total execution time: 0.0178
INFO - 2023-04-03 10:23:44 --> Config Class Initialized
INFO - 2023-04-03 10:23:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:23:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:23:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:23:44 --> URI Class Initialized
INFO - 2023-04-03 10:23:44 --> Router Class Initialized
INFO - 2023-04-03 10:23:44 --> Output Class Initialized
INFO - 2023-04-03 10:23:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:23:44 --> Input Class Initialized
INFO - 2023-04-03 10:23:44 --> Language Class Initialized
INFO - 2023-04-03 10:23:44 --> Loader Class Initialized
INFO - 2023-04-03 10:23:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:23:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:23:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:23:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:23:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:23:44 --> Total execution time: 0.0511
INFO - 2023-04-03 10:23:44 --> Config Class Initialized
INFO - 2023-04-03 10:23:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:23:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:23:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:23:44 --> URI Class Initialized
INFO - 2023-04-03 10:23:44 --> Router Class Initialized
INFO - 2023-04-03 10:23:44 --> Output Class Initialized
INFO - 2023-04-03 10:23:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:23:44 --> Input Class Initialized
INFO - 2023-04-03 10:23:44 --> Language Class Initialized
INFO - 2023-04-03 10:23:44 --> Loader Class Initialized
INFO - 2023-04-03 10:23:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:23:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:23:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:23:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:23:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:23:44 --> Total execution time: 0.0204
INFO - 2023-04-03 10:23:44 --> Config Class Initialized
INFO - 2023-04-03 10:23:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:23:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:23:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:23:44 --> URI Class Initialized
INFO - 2023-04-03 10:23:44 --> Router Class Initialized
INFO - 2023-04-03 10:23:44 --> Output Class Initialized
INFO - 2023-04-03 10:23:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:23:44 --> Input Class Initialized
INFO - 2023-04-03 10:23:44 --> Language Class Initialized
INFO - 2023-04-03 10:23:44 --> Loader Class Initialized
INFO - 2023-04-03 10:23:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:23:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:23:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:23:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:23:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:23:44 --> Total execution time: 0.0100
INFO - 2023-04-03 10:24:04 --> Config Class Initialized
INFO - 2023-04-03 10:24:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:24:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:24:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:24:04 --> URI Class Initialized
INFO - 2023-04-03 10:24:04 --> Router Class Initialized
INFO - 2023-04-03 10:24:04 --> Output Class Initialized
INFO - 2023-04-03 10:24:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:24:04 --> Input Class Initialized
INFO - 2023-04-03 10:24:04 --> Language Class Initialized
INFO - 2023-04-03 10:24:04 --> Loader Class Initialized
INFO - 2023-04-03 10:24:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:24:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:24:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:24:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:24:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:24:04 --> Total execution time: 0.0121
INFO - 2023-04-03 10:24:04 --> Config Class Initialized
INFO - 2023-04-03 10:24:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:24:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:24:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:24:04 --> URI Class Initialized
INFO - 2023-04-03 10:24:04 --> Router Class Initialized
INFO - 2023-04-03 10:24:04 --> Output Class Initialized
INFO - 2023-04-03 10:24:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:24:04 --> Input Class Initialized
INFO - 2023-04-03 10:24:04 --> Language Class Initialized
INFO - 2023-04-03 10:24:04 --> Loader Class Initialized
INFO - 2023-04-03 10:24:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:24:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:24:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:24:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:24:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:24:04 --> Model "Login_model" initialized
INFO - 2023-04-03 10:24:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:24:04 --> Total execution time: 0.0757
INFO - 2023-04-03 10:24:04 --> Config Class Initialized
INFO - 2023-04-03 10:24:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:24:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:24:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:24:04 --> URI Class Initialized
INFO - 2023-04-03 10:24:04 --> Router Class Initialized
INFO - 2023-04-03 10:24:04 --> Output Class Initialized
INFO - 2023-04-03 10:24:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:24:04 --> Input Class Initialized
INFO - 2023-04-03 10:24:04 --> Language Class Initialized
INFO - 2023-04-03 10:24:04 --> Loader Class Initialized
INFO - 2023-04-03 10:24:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:24:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:24:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:24:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:24:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:24:04 --> Total execution time: 0.0128
INFO - 2023-04-03 10:24:04 --> Config Class Initialized
INFO - 2023-04-03 10:24:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:24:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:24:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:24:04 --> URI Class Initialized
INFO - 2023-04-03 10:24:04 --> Router Class Initialized
INFO - 2023-04-03 10:24:04 --> Output Class Initialized
INFO - 2023-04-03 10:24:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:24:04 --> Input Class Initialized
INFO - 2023-04-03 10:24:04 --> Language Class Initialized
INFO - 2023-04-03 10:24:04 --> Loader Class Initialized
INFO - 2023-04-03 10:24:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:24:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:24:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:24:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:24:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:24:04 --> Total execution time: 0.0166
INFO - 2023-04-03 10:24:09 --> Config Class Initialized
INFO - 2023-04-03 10:24:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:24:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:24:09 --> Utf8 Class Initialized
INFO - 2023-04-03 10:24:09 --> URI Class Initialized
INFO - 2023-04-03 10:24:09 --> Router Class Initialized
INFO - 2023-04-03 10:24:09 --> Output Class Initialized
INFO - 2023-04-03 10:24:09 --> Security Class Initialized
DEBUG - 2023-04-03 10:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:24:09 --> Input Class Initialized
INFO - 2023-04-03 10:24:09 --> Language Class Initialized
INFO - 2023-04-03 10:24:09 --> Loader Class Initialized
INFO - 2023-04-03 10:24:09 --> Controller Class Initialized
DEBUG - 2023-04-03 10:24:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:24:09 --> Database Driver Class Initialized
INFO - 2023-04-03 10:24:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:24:09 --> Final output sent to browser
DEBUG - 2023-04-03 10:24:09 --> Total execution time: 0.0260
INFO - 2023-04-03 10:38:00 --> Config Class Initialized
INFO - 2023-04-03 10:38:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:00 --> URI Class Initialized
INFO - 2023-04-03 10:38:00 --> Router Class Initialized
INFO - 2023-04-03 10:38:00 --> Output Class Initialized
INFO - 2023-04-03 10:38:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:00 --> Input Class Initialized
INFO - 2023-04-03 10:38:00 --> Language Class Initialized
INFO - 2023-04-03 10:38:00 --> Loader Class Initialized
INFO - 2023-04-03 10:38:00 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:00 --> Total execution time: 0.0554
INFO - 2023-04-03 10:38:00 --> Config Class Initialized
INFO - 2023-04-03 10:38:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:00 --> URI Class Initialized
INFO - 2023-04-03 10:38:00 --> Router Class Initialized
INFO - 2023-04-03 10:38:00 --> Output Class Initialized
INFO - 2023-04-03 10:38:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:00 --> Input Class Initialized
INFO - 2023-04-03 10:38:00 --> Language Class Initialized
INFO - 2023-04-03 10:38:00 --> Loader Class Initialized
INFO - 2023-04-03 10:38:00 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:00 --> Total execution time: 0.0118
INFO - 2023-04-03 10:38:00 --> Config Class Initialized
INFO - 2023-04-03 10:38:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:00 --> URI Class Initialized
INFO - 2023-04-03 10:38:00 --> Router Class Initialized
INFO - 2023-04-03 10:38:00 --> Output Class Initialized
INFO - 2023-04-03 10:38:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:00 --> Input Class Initialized
INFO - 2023-04-03 10:38:00 --> Language Class Initialized
INFO - 2023-04-03 10:38:00 --> Loader Class Initialized
INFO - 2023-04-03 10:38:00 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:00 --> Total execution time: 0.0108
INFO - 2023-04-03 10:38:00 --> Config Class Initialized
INFO - 2023-04-03 10:38:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:00 --> URI Class Initialized
INFO - 2023-04-03 10:38:00 --> Router Class Initialized
INFO - 2023-04-03 10:38:00 --> Output Class Initialized
INFO - 2023-04-03 10:38:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:00 --> Input Class Initialized
INFO - 2023-04-03 10:38:00 --> Language Class Initialized
INFO - 2023-04-03 10:38:00 --> Loader Class Initialized
INFO - 2023-04-03 10:38:00 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:00 --> Total execution time: 0.0111
INFO - 2023-04-03 10:38:25 --> Config Class Initialized
INFO - 2023-04-03 10:38:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:25 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:25 --> URI Class Initialized
INFO - 2023-04-03 10:38:25 --> Router Class Initialized
INFO - 2023-04-03 10:38:25 --> Output Class Initialized
INFO - 2023-04-03 10:38:25 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:25 --> Input Class Initialized
INFO - 2023-04-03 10:38:25 --> Language Class Initialized
INFO - 2023-04-03 10:38:25 --> Loader Class Initialized
INFO - 2023-04-03 10:38:25 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:25 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:25 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:25 --> Total execution time: 0.0128
INFO - 2023-04-03 10:38:25 --> Config Class Initialized
INFO - 2023-04-03 10:38:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:25 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:25 --> URI Class Initialized
INFO - 2023-04-03 10:38:25 --> Router Class Initialized
INFO - 2023-04-03 10:38:25 --> Output Class Initialized
INFO - 2023-04-03 10:38:25 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:25 --> Input Class Initialized
INFO - 2023-04-03 10:38:25 --> Language Class Initialized
INFO - 2023-04-03 10:38:25 --> Loader Class Initialized
INFO - 2023-04-03 10:38:25 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:25 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:25 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:25 --> Model "Login_model" initialized
INFO - 2023-04-03 10:38:25 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:25 --> Total execution time: 0.0363
INFO - 2023-04-03 10:38:25 --> Config Class Initialized
INFO - 2023-04-03 10:38:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:25 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:25 --> URI Class Initialized
INFO - 2023-04-03 10:38:25 --> Router Class Initialized
INFO - 2023-04-03 10:38:25 --> Output Class Initialized
INFO - 2023-04-03 10:38:25 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:25 --> Input Class Initialized
INFO - 2023-04-03 10:38:25 --> Language Class Initialized
INFO - 2023-04-03 10:38:25 --> Loader Class Initialized
INFO - 2023-04-03 10:38:25 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:25 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:25 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:25 --> Total execution time: 0.0121
INFO - 2023-04-03 10:38:25 --> Config Class Initialized
INFO - 2023-04-03 10:38:25 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:25 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:25 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:25 --> URI Class Initialized
INFO - 2023-04-03 10:38:25 --> Router Class Initialized
INFO - 2023-04-03 10:38:25 --> Output Class Initialized
INFO - 2023-04-03 10:38:25 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:25 --> Input Class Initialized
INFO - 2023-04-03 10:38:25 --> Language Class Initialized
INFO - 2023-04-03 10:38:25 --> Loader Class Initialized
INFO - 2023-04-03 10:38:25 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:25 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:25 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:25 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:25 --> Total execution time: 0.2757
INFO - 2023-04-03 10:38:30 --> Config Class Initialized
INFO - 2023-04-03 10:38:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:30 --> URI Class Initialized
INFO - 2023-04-03 10:38:30 --> Router Class Initialized
INFO - 2023-04-03 10:38:30 --> Output Class Initialized
INFO - 2023-04-03 10:38:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:30 --> Input Class Initialized
INFO - 2023-04-03 10:38:30 --> Language Class Initialized
INFO - 2023-04-03 10:38:30 --> Loader Class Initialized
INFO - 2023-04-03 10:38:30 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:30 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:30 --> Total execution time: 0.0226
INFO - 2023-04-03 10:38:35 --> Config Class Initialized
INFO - 2023-04-03 10:38:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:35 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:35 --> URI Class Initialized
INFO - 2023-04-03 10:38:35 --> Router Class Initialized
INFO - 2023-04-03 10:38:35 --> Output Class Initialized
INFO - 2023-04-03 10:38:35 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:35 --> Input Class Initialized
INFO - 2023-04-03 10:38:35 --> Language Class Initialized
INFO - 2023-04-03 10:38:35 --> Loader Class Initialized
INFO - 2023-04-03 10:38:35 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:35 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:35 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:35 --> Total execution time: 0.0109
INFO - 2023-04-03 10:38:35 --> Config Class Initialized
INFO - 2023-04-03 10:38:35 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:35 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:35 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:35 --> URI Class Initialized
INFO - 2023-04-03 10:38:35 --> Router Class Initialized
INFO - 2023-04-03 10:38:35 --> Output Class Initialized
INFO - 2023-04-03 10:38:35 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:35 --> Input Class Initialized
INFO - 2023-04-03 10:38:35 --> Language Class Initialized
INFO - 2023-04-03 10:38:35 --> Loader Class Initialized
INFO - 2023-04-03 10:38:35 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:35 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:35 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:35 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:35 --> Total execution time: 0.0405
INFO - 2023-04-03 10:38:40 --> Config Class Initialized
INFO - 2023-04-03 10:38:40 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:38:40 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:38:40 --> Utf8 Class Initialized
INFO - 2023-04-03 10:38:40 --> URI Class Initialized
INFO - 2023-04-03 10:38:40 --> Router Class Initialized
INFO - 2023-04-03 10:38:40 --> Output Class Initialized
INFO - 2023-04-03 10:38:40 --> Security Class Initialized
DEBUG - 2023-04-03 10:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:38:40 --> Input Class Initialized
INFO - 2023-04-03 10:38:40 --> Language Class Initialized
INFO - 2023-04-03 10:38:40 --> Loader Class Initialized
INFO - 2023-04-03 10:38:40 --> Controller Class Initialized
DEBUG - 2023-04-03 10:38:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:38:40 --> Database Driver Class Initialized
INFO - 2023-04-03 10:38:40 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:38:40 --> Final output sent to browser
DEBUG - 2023-04-03 10:38:40 --> Total execution time: 0.0163
INFO - 2023-04-03 10:44:41 --> Config Class Initialized
INFO - 2023-04-03 10:44:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:44:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:44:41 --> Utf8 Class Initialized
INFO - 2023-04-03 10:44:41 --> URI Class Initialized
INFO - 2023-04-03 10:44:41 --> Router Class Initialized
INFO - 2023-04-03 10:44:41 --> Output Class Initialized
INFO - 2023-04-03 10:44:41 --> Security Class Initialized
DEBUG - 2023-04-03 10:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:44:41 --> Input Class Initialized
INFO - 2023-04-03 10:44:41 --> Language Class Initialized
INFO - 2023-04-03 10:44:41 --> Loader Class Initialized
INFO - 2023-04-03 10:44:41 --> Controller Class Initialized
DEBUG - 2023-04-03 10:44:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:44:41 --> Database Driver Class Initialized
INFO - 2023-04-03 10:44:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:44:41 --> Final output sent to browser
DEBUG - 2023-04-03 10:44:41 --> Total execution time: 0.0148
INFO - 2023-04-03 10:44:41 --> Config Class Initialized
INFO - 2023-04-03 10:44:41 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:44:41 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:44:41 --> Utf8 Class Initialized
INFO - 2023-04-03 10:44:41 --> URI Class Initialized
INFO - 2023-04-03 10:44:41 --> Router Class Initialized
INFO - 2023-04-03 10:44:41 --> Output Class Initialized
INFO - 2023-04-03 10:44:41 --> Security Class Initialized
DEBUG - 2023-04-03 10:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:44:41 --> Input Class Initialized
INFO - 2023-04-03 10:44:41 --> Language Class Initialized
INFO - 2023-04-03 10:44:41 --> Loader Class Initialized
INFO - 2023-04-03 10:44:41 --> Controller Class Initialized
DEBUG - 2023-04-03 10:44:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:44:41 --> Database Driver Class Initialized
INFO - 2023-04-03 10:44:41 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:44:41 --> Final output sent to browser
DEBUG - 2023-04-03 10:44:41 --> Total execution time: 0.0565
INFO - 2023-04-03 10:44:42 --> Config Class Initialized
INFO - 2023-04-03 10:44:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:44:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:44:42 --> Utf8 Class Initialized
INFO - 2023-04-03 10:44:42 --> URI Class Initialized
INFO - 2023-04-03 10:44:42 --> Router Class Initialized
INFO - 2023-04-03 10:44:42 --> Output Class Initialized
INFO - 2023-04-03 10:44:42 --> Security Class Initialized
DEBUG - 2023-04-03 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:44:42 --> Input Class Initialized
INFO - 2023-04-03 10:44:42 --> Language Class Initialized
INFO - 2023-04-03 10:44:42 --> Loader Class Initialized
INFO - 2023-04-03 10:44:42 --> Controller Class Initialized
DEBUG - 2023-04-03 10:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:44:42 --> Database Driver Class Initialized
INFO - 2023-04-03 10:44:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:44:42 --> Final output sent to browser
DEBUG - 2023-04-03 10:44:42 --> Total execution time: 0.0572
INFO - 2023-04-03 10:44:42 --> Config Class Initialized
INFO - 2023-04-03 10:44:42 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:44:42 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:44:42 --> Utf8 Class Initialized
INFO - 2023-04-03 10:44:42 --> URI Class Initialized
INFO - 2023-04-03 10:44:42 --> Router Class Initialized
INFO - 2023-04-03 10:44:42 --> Output Class Initialized
INFO - 2023-04-03 10:44:42 --> Security Class Initialized
DEBUG - 2023-04-03 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:44:42 --> Input Class Initialized
INFO - 2023-04-03 10:44:42 --> Language Class Initialized
INFO - 2023-04-03 10:44:42 --> Loader Class Initialized
INFO - 2023-04-03 10:44:42 --> Controller Class Initialized
DEBUG - 2023-04-03 10:44:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:44:42 --> Database Driver Class Initialized
INFO - 2023-04-03 10:44:42 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:44:42 --> Final output sent to browser
DEBUG - 2023-04-03 10:44:42 --> Total execution time: 0.0552
INFO - 2023-04-03 10:45:04 --> Config Class Initialized
INFO - 2023-04-03 10:45:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:04 --> URI Class Initialized
INFO - 2023-04-03 10:45:04 --> Router Class Initialized
INFO - 2023-04-03 10:45:04 --> Output Class Initialized
INFO - 2023-04-03 10:45:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:04 --> Input Class Initialized
INFO - 2023-04-03 10:45:04 --> Language Class Initialized
INFO - 2023-04-03 10:45:04 --> Loader Class Initialized
INFO - 2023-04-03 10:45:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:04 --> Total execution time: 0.0110
INFO - 2023-04-03 10:45:04 --> Config Class Initialized
INFO - 2023-04-03 10:45:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:04 --> URI Class Initialized
INFO - 2023-04-03 10:45:04 --> Router Class Initialized
INFO - 2023-04-03 10:45:04 --> Output Class Initialized
INFO - 2023-04-03 10:45:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:04 --> Input Class Initialized
INFO - 2023-04-03 10:45:04 --> Language Class Initialized
INFO - 2023-04-03 10:45:04 --> Loader Class Initialized
INFO - 2023-04-03 10:45:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:04 --> Model "Login_model" initialized
INFO - 2023-04-03 10:45:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:04 --> Total execution time: 0.1034
INFO - 2023-04-03 10:45:04 --> Config Class Initialized
INFO - 2023-04-03 10:45:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:04 --> URI Class Initialized
INFO - 2023-04-03 10:45:04 --> Router Class Initialized
INFO - 2023-04-03 10:45:04 --> Output Class Initialized
INFO - 2023-04-03 10:45:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:04 --> Input Class Initialized
INFO - 2023-04-03 10:45:04 --> Language Class Initialized
INFO - 2023-04-03 10:45:04 --> Loader Class Initialized
INFO - 2023-04-03 10:45:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:04 --> Total execution time: 0.0155
INFO - 2023-04-03 10:45:04 --> Config Class Initialized
INFO - 2023-04-03 10:45:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:04 --> URI Class Initialized
INFO - 2023-04-03 10:45:04 --> Router Class Initialized
INFO - 2023-04-03 10:45:04 --> Output Class Initialized
INFO - 2023-04-03 10:45:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:04 --> Input Class Initialized
INFO - 2023-04-03 10:45:04 --> Language Class Initialized
INFO - 2023-04-03 10:45:04 --> Loader Class Initialized
INFO - 2023-04-03 10:45:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:07 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:07 --> Total execution time: 2.4537
INFO - 2023-04-03 10:45:09 --> Config Class Initialized
INFO - 2023-04-03 10:45:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:09 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:09 --> URI Class Initialized
INFO - 2023-04-03 10:45:09 --> Router Class Initialized
INFO - 2023-04-03 10:45:09 --> Output Class Initialized
INFO - 2023-04-03 10:45:09 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:09 --> Input Class Initialized
INFO - 2023-04-03 10:45:09 --> Language Class Initialized
INFO - 2023-04-03 10:45:09 --> Loader Class Initialized
INFO - 2023-04-03 10:45:09 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:09 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:09 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:09 --> Total execution time: 0.0587
INFO - 2023-04-03 10:45:14 --> Config Class Initialized
INFO - 2023-04-03 10:45:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:14 --> URI Class Initialized
INFO - 2023-04-03 10:45:14 --> Router Class Initialized
INFO - 2023-04-03 10:45:14 --> Output Class Initialized
INFO - 2023-04-03 10:45:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:14 --> Input Class Initialized
INFO - 2023-04-03 10:45:14 --> Language Class Initialized
INFO - 2023-04-03 10:45:14 --> Loader Class Initialized
INFO - 2023-04-03 10:45:14 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:14 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:14 --> Total execution time: 0.0142
INFO - 2023-04-03 10:45:14 --> Config Class Initialized
INFO - 2023-04-03 10:45:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:14 --> URI Class Initialized
INFO - 2023-04-03 10:45:14 --> Router Class Initialized
INFO - 2023-04-03 10:45:14 --> Output Class Initialized
INFO - 2023-04-03 10:45:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:14 --> Input Class Initialized
INFO - 2023-04-03 10:45:14 --> Language Class Initialized
INFO - 2023-04-03 10:45:14 --> Loader Class Initialized
INFO - 2023-04-03 10:45:14 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:14 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:14 --> Total execution time: 0.0166
INFO - 2023-04-03 10:45:19 --> Config Class Initialized
INFO - 2023-04-03 10:45:19 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:19 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:19 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:19 --> URI Class Initialized
INFO - 2023-04-03 10:45:19 --> Router Class Initialized
INFO - 2023-04-03 10:45:19 --> Output Class Initialized
INFO - 2023-04-03 10:45:19 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:19 --> Input Class Initialized
INFO - 2023-04-03 10:45:19 --> Language Class Initialized
INFO - 2023-04-03 10:45:19 --> Loader Class Initialized
INFO - 2023-04-03 10:45:19 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:19 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:19 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:19 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:19 --> Total execution time: 0.0327
INFO - 2023-04-03 10:45:24 --> Config Class Initialized
INFO - 2023-04-03 10:45:24 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:24 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:24 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:24 --> URI Class Initialized
INFO - 2023-04-03 10:45:24 --> Router Class Initialized
INFO - 2023-04-03 10:45:24 --> Output Class Initialized
INFO - 2023-04-03 10:45:24 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:24 --> Input Class Initialized
INFO - 2023-04-03 10:45:24 --> Language Class Initialized
INFO - 2023-04-03 10:45:24 --> Loader Class Initialized
INFO - 2023-04-03 10:45:24 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:24 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:24 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:24 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:24 --> Total execution time: 0.0550
INFO - 2023-04-03 10:45:24 --> Config Class Initialized
INFO - 2023-04-03 10:45:24 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:24 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:24 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:24 --> URI Class Initialized
INFO - 2023-04-03 10:45:24 --> Router Class Initialized
INFO - 2023-04-03 10:45:24 --> Output Class Initialized
INFO - 2023-04-03 10:45:24 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:24 --> Input Class Initialized
INFO - 2023-04-03 10:45:24 --> Language Class Initialized
INFO - 2023-04-03 10:45:24 --> Loader Class Initialized
INFO - 2023-04-03 10:45:24 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:24 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:24 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:24 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:24 --> Total execution time: 0.0268
INFO - 2023-04-03 10:45:29 --> Config Class Initialized
INFO - 2023-04-03 10:45:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:29 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:29 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:29 --> URI Class Initialized
INFO - 2023-04-03 10:45:29 --> Router Class Initialized
INFO - 2023-04-03 10:45:29 --> Output Class Initialized
INFO - 2023-04-03 10:45:29 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:29 --> Input Class Initialized
INFO - 2023-04-03 10:45:29 --> Language Class Initialized
INFO - 2023-04-03 10:45:29 --> Loader Class Initialized
INFO - 2023-04-03 10:45:29 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:29 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:29 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:29 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:29 --> Total execution time: 0.0574
INFO - 2023-04-03 10:45:34 --> Config Class Initialized
INFO - 2023-04-03 10:45:34 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:34 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:34 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:34 --> URI Class Initialized
INFO - 2023-04-03 10:45:34 --> Router Class Initialized
INFO - 2023-04-03 10:45:34 --> Output Class Initialized
INFO - 2023-04-03 10:45:34 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:34 --> Input Class Initialized
INFO - 2023-04-03 10:45:34 --> Language Class Initialized
INFO - 2023-04-03 10:45:34 --> Loader Class Initialized
INFO - 2023-04-03 10:45:34 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:34 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:34 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:34 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:34 --> Total execution time: 0.0189
INFO - 2023-04-03 10:45:34 --> Config Class Initialized
INFO - 2023-04-03 10:45:34 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:34 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:34 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:34 --> URI Class Initialized
INFO - 2023-04-03 10:45:34 --> Router Class Initialized
INFO - 2023-04-03 10:45:34 --> Output Class Initialized
INFO - 2023-04-03 10:45:34 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:34 --> Input Class Initialized
INFO - 2023-04-03 10:45:34 --> Language Class Initialized
INFO - 2023-04-03 10:45:34 --> Loader Class Initialized
INFO - 2023-04-03 10:45:34 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:34 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:34 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:34 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:34 --> Total execution time: 0.0248
INFO - 2023-04-03 10:45:39 --> Config Class Initialized
INFO - 2023-04-03 10:45:39 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:39 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:39 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:39 --> URI Class Initialized
INFO - 2023-04-03 10:45:39 --> Router Class Initialized
INFO - 2023-04-03 10:45:39 --> Output Class Initialized
INFO - 2023-04-03 10:45:39 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:39 --> Input Class Initialized
INFO - 2023-04-03 10:45:39 --> Language Class Initialized
INFO - 2023-04-03 10:45:39 --> Loader Class Initialized
INFO - 2023-04-03 10:45:39 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:39 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:39 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:39 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:39 --> Total execution time: 0.0612
INFO - 2023-04-03 10:45:44 --> Config Class Initialized
INFO - 2023-04-03 10:45:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:44 --> URI Class Initialized
INFO - 2023-04-03 10:45:44 --> Router Class Initialized
INFO - 2023-04-03 10:45:44 --> Output Class Initialized
INFO - 2023-04-03 10:45:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:44 --> Input Class Initialized
INFO - 2023-04-03 10:45:44 --> Language Class Initialized
INFO - 2023-04-03 10:45:44 --> Loader Class Initialized
INFO - 2023-04-03 10:45:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:44 --> Total execution time: 0.0523
INFO - 2023-04-03 10:45:44 --> Config Class Initialized
INFO - 2023-04-03 10:45:44 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:44 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:44 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:44 --> URI Class Initialized
INFO - 2023-04-03 10:45:44 --> Router Class Initialized
INFO - 2023-04-03 10:45:44 --> Output Class Initialized
INFO - 2023-04-03 10:45:44 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:44 --> Input Class Initialized
INFO - 2023-04-03 10:45:44 --> Language Class Initialized
INFO - 2023-04-03 10:45:44 --> Loader Class Initialized
INFO - 2023-04-03 10:45:44 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:44 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:44 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:44 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:44 --> Total execution time: 0.0221
INFO - 2023-04-03 10:45:49 --> Config Class Initialized
INFO - 2023-04-03 10:45:49 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:49 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:49 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:49 --> URI Class Initialized
INFO - 2023-04-03 10:45:49 --> Router Class Initialized
INFO - 2023-04-03 10:45:49 --> Output Class Initialized
INFO - 2023-04-03 10:45:49 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:49 --> Input Class Initialized
INFO - 2023-04-03 10:45:49 --> Language Class Initialized
INFO - 2023-04-03 10:45:49 --> Loader Class Initialized
INFO - 2023-04-03 10:45:49 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:49 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:49 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:49 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:49 --> Total execution time: 0.0183
INFO - 2023-04-03 10:45:54 --> Config Class Initialized
INFO - 2023-04-03 10:45:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:54 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:54 --> URI Class Initialized
INFO - 2023-04-03 10:45:54 --> Router Class Initialized
INFO - 2023-04-03 10:45:54 --> Output Class Initialized
INFO - 2023-04-03 10:45:54 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:54 --> Input Class Initialized
INFO - 2023-04-03 10:45:54 --> Language Class Initialized
INFO - 2023-04-03 10:45:54 --> Loader Class Initialized
INFO - 2023-04-03 10:45:54 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:54 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:54 --> Total execution time: 0.0133
INFO - 2023-04-03 10:45:54 --> Config Class Initialized
INFO - 2023-04-03 10:45:54 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:54 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:54 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:54 --> URI Class Initialized
INFO - 2023-04-03 10:45:54 --> Router Class Initialized
INFO - 2023-04-03 10:45:54 --> Output Class Initialized
INFO - 2023-04-03 10:45:54 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:54 --> Input Class Initialized
INFO - 2023-04-03 10:45:54 --> Language Class Initialized
INFO - 2023-04-03 10:45:54 --> Loader Class Initialized
INFO - 2023-04-03 10:45:54 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:54 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:54 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:54 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:54 --> Total execution time: 0.0158
INFO - 2023-04-03 10:45:59 --> Config Class Initialized
INFO - 2023-04-03 10:45:59 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:45:59 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:45:59 --> Utf8 Class Initialized
INFO - 2023-04-03 10:45:59 --> URI Class Initialized
INFO - 2023-04-03 10:45:59 --> Router Class Initialized
INFO - 2023-04-03 10:45:59 --> Output Class Initialized
INFO - 2023-04-03 10:45:59 --> Security Class Initialized
DEBUG - 2023-04-03 10:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:45:59 --> Input Class Initialized
INFO - 2023-04-03 10:45:59 --> Language Class Initialized
INFO - 2023-04-03 10:45:59 --> Loader Class Initialized
INFO - 2023-04-03 10:45:59 --> Controller Class Initialized
DEBUG - 2023-04-03 10:45:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:45:59 --> Database Driver Class Initialized
INFO - 2023-04-03 10:45:59 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:45:59 --> Final output sent to browser
DEBUG - 2023-04-03 10:45:59 --> Total execution time: 0.0158
INFO - 2023-04-03 10:46:04 --> Config Class Initialized
INFO - 2023-04-03 10:46:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:46:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:46:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:46:04 --> URI Class Initialized
INFO - 2023-04-03 10:46:04 --> Router Class Initialized
INFO - 2023-04-03 10:46:04 --> Output Class Initialized
INFO - 2023-04-03 10:46:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:46:04 --> Input Class Initialized
INFO - 2023-04-03 10:46:04 --> Language Class Initialized
INFO - 2023-04-03 10:46:04 --> Loader Class Initialized
INFO - 2023-04-03 10:46:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:46:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:46:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:46:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:46:04 --> Total execution time: 0.0143
INFO - 2023-04-03 10:46:04 --> Config Class Initialized
INFO - 2023-04-03 10:46:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:46:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:46:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:46:04 --> URI Class Initialized
INFO - 2023-04-03 10:46:04 --> Router Class Initialized
INFO - 2023-04-03 10:46:04 --> Output Class Initialized
INFO - 2023-04-03 10:46:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:46:04 --> Input Class Initialized
INFO - 2023-04-03 10:46:04 --> Language Class Initialized
INFO - 2023-04-03 10:46:04 --> Loader Class Initialized
INFO - 2023-04-03 10:46:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:46:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:46:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:46:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:46:04 --> Total execution time: 0.0319
INFO - 2023-04-03 10:46:09 --> Config Class Initialized
INFO - 2023-04-03 10:46:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:46:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:46:09 --> Utf8 Class Initialized
INFO - 2023-04-03 10:46:09 --> URI Class Initialized
INFO - 2023-04-03 10:46:09 --> Router Class Initialized
INFO - 2023-04-03 10:46:09 --> Output Class Initialized
INFO - 2023-04-03 10:46:09 --> Security Class Initialized
DEBUG - 2023-04-03 10:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:46:09 --> Input Class Initialized
INFO - 2023-04-03 10:46:09 --> Language Class Initialized
INFO - 2023-04-03 10:46:09 --> Loader Class Initialized
INFO - 2023-04-03 10:46:09 --> Controller Class Initialized
DEBUG - 2023-04-03 10:46:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:46:09 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:46:09 --> Final output sent to browser
DEBUG - 2023-04-03 10:46:09 --> Total execution time: 0.0603
INFO - 2023-04-03 10:46:14 --> Config Class Initialized
INFO - 2023-04-03 10:46:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:46:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:46:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:46:14 --> URI Class Initialized
INFO - 2023-04-03 10:46:14 --> Router Class Initialized
INFO - 2023-04-03 10:46:14 --> Output Class Initialized
INFO - 2023-04-03 10:46:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:46:14 --> Input Class Initialized
INFO - 2023-04-03 10:46:14 --> Language Class Initialized
INFO - 2023-04-03 10:46:14 --> Loader Class Initialized
INFO - 2023-04-03 10:46:14 --> Controller Class Initialized
DEBUG - 2023-04-03 10:46:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:46:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:46:14 --> Final output sent to browser
DEBUG - 2023-04-03 10:46:14 --> Total execution time: 0.0111
INFO - 2023-04-03 10:46:14 --> Config Class Initialized
INFO - 2023-04-03 10:46:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:46:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:46:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:46:14 --> URI Class Initialized
INFO - 2023-04-03 10:46:14 --> Router Class Initialized
INFO - 2023-04-03 10:46:14 --> Output Class Initialized
INFO - 2023-04-03 10:46:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:46:14 --> Input Class Initialized
INFO - 2023-04-03 10:46:14 --> Language Class Initialized
INFO - 2023-04-03 10:46:14 --> Loader Class Initialized
INFO - 2023-04-03 10:46:14 --> Controller Class Initialized
DEBUG - 2023-04-03 10:46:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:46:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:46:14 --> Final output sent to browser
DEBUG - 2023-04-03 10:46:14 --> Total execution time: 0.0159
INFO - 2023-04-03 10:46:19 --> Config Class Initialized
INFO - 2023-04-03 10:46:19 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:46:19 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:46:19 --> Utf8 Class Initialized
INFO - 2023-04-03 10:46:19 --> URI Class Initialized
INFO - 2023-04-03 10:46:19 --> Router Class Initialized
INFO - 2023-04-03 10:46:19 --> Output Class Initialized
INFO - 2023-04-03 10:46:19 --> Security Class Initialized
DEBUG - 2023-04-03 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:46:19 --> Input Class Initialized
INFO - 2023-04-03 10:46:19 --> Language Class Initialized
INFO - 2023-04-03 10:46:19 --> Loader Class Initialized
INFO - 2023-04-03 10:46:19 --> Controller Class Initialized
DEBUG - 2023-04-03 10:46:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:46:19 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:19 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:46:19 --> Final output sent to browser
DEBUG - 2023-04-03 10:46:19 --> Total execution time: 0.0190
INFO - 2023-04-03 10:46:22 --> Config Class Initialized
INFO - 2023-04-03 10:46:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:46:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:46:22 --> Utf8 Class Initialized
INFO - 2023-04-03 10:46:22 --> URI Class Initialized
INFO - 2023-04-03 10:46:22 --> Router Class Initialized
INFO - 2023-04-03 10:46:22 --> Output Class Initialized
INFO - 2023-04-03 10:46:22 --> Security Class Initialized
DEBUG - 2023-04-03 10:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:46:22 --> Input Class Initialized
INFO - 2023-04-03 10:46:22 --> Language Class Initialized
INFO - 2023-04-03 10:46:22 --> Loader Class Initialized
INFO - 2023-04-03 10:46:22 --> Controller Class Initialized
DEBUG - 2023-04-03 10:46:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:46:22 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:46:22 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:22 --> Model "Login_model" initialized
INFO - 2023-04-03 10:46:22 --> Final output sent to browser
DEBUG - 2023-04-03 10:46:22 --> Total execution time: 0.0686
INFO - 2023-04-03 10:46:22 --> Config Class Initialized
INFO - 2023-04-03 10:46:22 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:46:22 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:46:22 --> Utf8 Class Initialized
INFO - 2023-04-03 10:46:22 --> URI Class Initialized
INFO - 2023-04-03 10:46:22 --> Router Class Initialized
INFO - 2023-04-03 10:46:22 --> Output Class Initialized
INFO - 2023-04-03 10:46:22 --> Security Class Initialized
DEBUG - 2023-04-03 10:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:46:22 --> Input Class Initialized
INFO - 2023-04-03 10:46:22 --> Language Class Initialized
INFO - 2023-04-03 10:46:22 --> Loader Class Initialized
INFO - 2023-04-03 10:46:22 --> Controller Class Initialized
DEBUG - 2023-04-03 10:46:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:46:22 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:22 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:46:22 --> Database Driver Class Initialized
INFO - 2023-04-03 10:46:22 --> Model "Login_model" initialized
INFO - 2023-04-03 10:46:23 --> Final output sent to browser
DEBUG - 2023-04-03 10:46:23 --> Total execution time: 0.1404
INFO - 2023-04-03 10:47:17 --> Config Class Initialized
INFO - 2023-04-03 10:47:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:47:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:47:17 --> Utf8 Class Initialized
INFO - 2023-04-03 10:47:17 --> URI Class Initialized
INFO - 2023-04-03 10:47:17 --> Router Class Initialized
INFO - 2023-04-03 10:47:17 --> Output Class Initialized
INFO - 2023-04-03 10:47:17 --> Security Class Initialized
DEBUG - 2023-04-03 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:47:17 --> Input Class Initialized
INFO - 2023-04-03 10:47:17 --> Language Class Initialized
INFO - 2023-04-03 10:47:17 --> Loader Class Initialized
INFO - 2023-04-03 10:47:17 --> Controller Class Initialized
DEBUG - 2023-04-03 10:47:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:47:17 --> Database Driver Class Initialized
INFO - 2023-04-03 10:47:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:47:17 --> Database Driver Class Initialized
INFO - 2023-04-03 10:47:17 --> Model "Login_model" initialized
INFO - 2023-04-03 10:47:17 --> Final output sent to browser
DEBUG - 2023-04-03 10:47:17 --> Total execution time: 0.1845
INFO - 2023-04-03 10:47:17 --> Config Class Initialized
INFO - 2023-04-03 10:47:17 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:47:17 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:47:17 --> Utf8 Class Initialized
INFO - 2023-04-03 10:47:17 --> URI Class Initialized
INFO - 2023-04-03 10:47:17 --> Router Class Initialized
INFO - 2023-04-03 10:47:17 --> Output Class Initialized
INFO - 2023-04-03 10:47:17 --> Security Class Initialized
DEBUG - 2023-04-03 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:47:17 --> Input Class Initialized
INFO - 2023-04-03 10:47:17 --> Language Class Initialized
INFO - 2023-04-03 10:47:17 --> Loader Class Initialized
INFO - 2023-04-03 10:47:17 --> Controller Class Initialized
DEBUG - 2023-04-03 10:47:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:47:17 --> Database Driver Class Initialized
INFO - 2023-04-03 10:47:17 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:47:17 --> Database Driver Class Initialized
INFO - 2023-04-03 10:47:17 --> Model "Login_model" initialized
INFO - 2023-04-03 10:47:17 --> Final output sent to browser
DEBUG - 2023-04-03 10:47:17 --> Total execution time: 0.0744
INFO - 2023-04-03 10:50:04 --> Config Class Initialized
INFO - 2023-04-03 10:50:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:04 --> URI Class Initialized
INFO - 2023-04-03 10:50:04 --> Router Class Initialized
INFO - 2023-04-03 10:50:04 --> Output Class Initialized
INFO - 2023-04-03 10:50:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:04 --> Input Class Initialized
INFO - 2023-04-03 10:50:04 --> Language Class Initialized
INFO - 2023-04-03 10:50:04 --> Loader Class Initialized
INFO - 2023-04-03 10:50:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:04 --> Total execution time: 0.0302
INFO - 2023-04-03 10:50:04 --> Config Class Initialized
INFO - 2023-04-03 10:50:04 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:04 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:04 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:04 --> URI Class Initialized
INFO - 2023-04-03 10:50:04 --> Router Class Initialized
INFO - 2023-04-03 10:50:04 --> Output Class Initialized
INFO - 2023-04-03 10:50:04 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:04 --> Input Class Initialized
INFO - 2023-04-03 10:50:04 --> Language Class Initialized
INFO - 2023-04-03 10:50:04 --> Loader Class Initialized
INFO - 2023-04-03 10:50:04 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:04 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:04 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:04 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:04 --> Total execution time: 0.0622
INFO - 2023-04-03 10:50:08 --> Config Class Initialized
INFO - 2023-04-03 10:50:08 --> Config Class Initialized
INFO - 2023-04-03 10:50:08 --> Config Class Initialized
INFO - 2023-04-03 10:50:08 --> Hooks Class Initialized
INFO - 2023-04-03 10:50:08 --> Hooks Class Initialized
INFO - 2023-04-03 10:50:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:50:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:08 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:08 --> Utf8 Class Initialized
DEBUG - 2023-04-03 10:50:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:08 --> URI Class Initialized
INFO - 2023-04-03 10:50:08 --> URI Class Initialized
INFO - 2023-04-03 10:50:08 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:08 --> Router Class Initialized
INFO - 2023-04-03 10:50:08 --> Router Class Initialized
INFO - 2023-04-03 10:50:08 --> URI Class Initialized
INFO - 2023-04-03 10:50:08 --> Output Class Initialized
INFO - 2023-04-03 10:50:08 --> Output Class Initialized
INFO - 2023-04-03 10:50:08 --> Router Class Initialized
INFO - 2023-04-03 10:50:08 --> Security Class Initialized
INFO - 2023-04-03 10:50:08 --> Output Class Initialized
INFO - 2023-04-03 10:50:08 --> Security Class Initialized
INFO - 2023-04-03 10:50:08 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:08 --> Input Class Initialized
DEBUG - 2023-04-03 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:08 --> Input Class Initialized
INFO - 2023-04-03 10:50:08 --> Language Class Initialized
INFO - 2023-04-03 10:50:08 --> Input Class Initialized
INFO - 2023-04-03 10:50:08 --> Language Class Initialized
INFO - 2023-04-03 10:50:08 --> Language Class Initialized
INFO - 2023-04-03 10:50:08 --> Loader Class Initialized
INFO - 2023-04-03 10:50:08 --> Loader Class Initialized
INFO - 2023-04-03 10:50:08 --> Loader Class Initialized
INFO - 2023-04-03 10:50:08 --> Controller Class Initialized
INFO - 2023-04-03 10:50:08 --> Controller Class Initialized
INFO - 2023-04-03 10:50:08 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:08 --> Database Driver Class Initialized
ERROR - 2023-04-03 10:50:08 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:08 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-03 10:50:08 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:08 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 10:50:08 --> Config Class Initialized
INFO - 2023-04-03 10:50:08 --> Model "Login_model" initialized
INFO - 2023-04-03 10:50:08 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:08 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:08 --> URI Class Initialized
INFO - 2023-04-03 10:50:08 --> Router Class Initialized
INFO - 2023-04-03 10:50:08 --> Output Class Initialized
INFO - 2023-04-03 10:50:08 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:08 --> Input Class Initialized
INFO - 2023-04-03 10:50:08 --> Language Class Initialized
INFO - 2023-04-03 10:50:08 --> Loader Class Initialized
INFO - 2023-04-03 10:50:08 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:08 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:08 --> Total execution time: 0.1059
INFO - 2023-04-03 10:50:08 --> Config Class Initialized
INFO - 2023-04-03 10:50:08 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:08 --> Hooks Class Initialized
ERROR - 2023-04-03 10:50:08 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2023-04-03 10:50:08 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:08 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:08 --> URI Class Initialized
INFO - 2023-04-03 10:50:08 --> Router Class Initialized
INFO - 2023-04-03 10:50:08 --> Output Class Initialized
INFO - 2023-04-03 10:50:08 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:08 --> Input Class Initialized
INFO - 2023-04-03 10:50:08 --> Language Class Initialized
INFO - 2023-04-03 10:50:08 --> Loader Class Initialized
INFO - 2023-04-03 10:50:08 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:08 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:08 --> Model "Login_model" initialized
INFO - 2023-04-03 10:50:08 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:08 --> Total execution time: 0.1650
INFO - 2023-04-03 10:50:12 --> Config Class Initialized
INFO - 2023-04-03 10:50:12 --> Config Class Initialized
INFO - 2023-04-03 10:50:12 --> Config Class Initialized
INFO - 2023-04-03 10:50:12 --> Hooks Class Initialized
INFO - 2023-04-03 10:50:12 --> Hooks Class Initialized
INFO - 2023-04-03 10:50:12 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:50:12 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:12 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:12 --> Utf8 Class Initialized
DEBUG - 2023-04-03 10:50:12 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:12 --> URI Class Initialized
INFO - 2023-04-03 10:50:12 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:12 --> URI Class Initialized
INFO - 2023-04-03 10:50:12 --> Router Class Initialized
INFO - 2023-04-03 10:50:12 --> Router Class Initialized
INFO - 2023-04-03 10:50:12 --> Output Class Initialized
INFO - 2023-04-03 10:50:12 --> URI Class Initialized
INFO - 2023-04-03 10:50:12 --> Output Class Initialized
INFO - 2023-04-03 10:50:12 --> Security Class Initialized
INFO - 2023-04-03 10:50:12 --> Router Class Initialized
INFO - 2023-04-03 10:50:12 --> Security Class Initialized
INFO - 2023-04-03 10:50:12 --> Output Class Initialized
DEBUG - 2023-04-03 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 10:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:12 --> Input Class Initialized
INFO - 2023-04-03 10:50:12 --> Security Class Initialized
INFO - 2023-04-03 10:50:12 --> Input Class Initialized
INFO - 2023-04-03 10:50:12 --> Language Class Initialized
DEBUG - 2023-04-03 10:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:12 --> Language Class Initialized
INFO - 2023-04-03 10:50:12 --> Input Class Initialized
INFO - 2023-04-03 10:50:12 --> Loader Class Initialized
INFO - 2023-04-03 10:50:12 --> Loader Class Initialized
INFO - 2023-04-03 10:50:12 --> Language Class Initialized
INFO - 2023-04-03 10:50:12 --> Controller Class Initialized
INFO - 2023-04-03 10:50:12 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:50:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:12 --> Loader Class Initialized
INFO - 2023-04-03 10:50:12 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:12 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:12 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:12 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:12 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:12 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:12 --> Model "Cluster_model" initialized
ERROR - 2023-04-03 10:50:12 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:12 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 10:50:12 --> Config Class Initialized
ERROR - 2023-04-03 10:50:12 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:12 --> Hooks Class Initialized
INFO - 2023-04-03 10:50:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2023-04-03 10:50:12 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:12 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:12 --> URI Class Initialized
INFO - 2023-04-03 10:50:12 --> Router Class Initialized
INFO - 2023-04-03 10:50:12 --> Output Class Initialized
INFO - 2023-04-03 10:50:12 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:12 --> Input Class Initialized
INFO - 2023-04-03 10:50:12 --> Language Class Initialized
INFO - 2023-04-03 10:50:12 --> Loader Class Initialized
INFO - 2023-04-03 10:50:12 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:12 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:12 --> Model "Login_model" initialized
INFO - 2023-04-03 10:50:12 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:12 --> Total execution time: 0.0329
INFO - 2023-04-03 10:50:12 --> Model "Cluster_model" initialized
ERROR - 2023-04-03 10:50:12 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:12 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 10:50:18 --> Config Class Initialized
INFO - 2023-04-03 10:50:18 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:18 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:18 --> URI Class Initialized
INFO - 2023-04-03 10:50:18 --> Router Class Initialized
INFO - 2023-04-03 10:50:18 --> Output Class Initialized
INFO - 2023-04-03 10:50:18 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:18 --> Input Class Initialized
INFO - 2023-04-03 10:50:18 --> Language Class Initialized
INFO - 2023-04-03 10:50:18 --> Loader Class Initialized
INFO - 2023-04-03 10:50:18 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:18 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:18 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:18 --> Model "Login_model" initialized
INFO - 2023-04-03 10:50:18 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:18 --> Total execution time: 0.1226
INFO - 2023-04-03 10:50:18 --> Config Class Initialized
INFO - 2023-04-03 10:50:18 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:18 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:18 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:18 --> URI Class Initialized
INFO - 2023-04-03 10:50:18 --> Router Class Initialized
INFO - 2023-04-03 10:50:18 --> Output Class Initialized
INFO - 2023-04-03 10:50:18 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:18 --> Input Class Initialized
INFO - 2023-04-03 10:50:18 --> Language Class Initialized
INFO - 2023-04-03 10:50:18 --> Loader Class Initialized
INFO - 2023-04-03 10:50:18 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:18 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:18 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:18 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:18 --> Model "Login_model" initialized
INFO - 2023-04-03 10:50:18 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:18 --> Total execution time: 0.1087
INFO - 2023-04-03 10:50:21 --> Config Class Initialized
INFO - 2023-04-03 10:50:21 --> Config Class Initialized
INFO - 2023-04-03 10:50:21 --> Hooks Class Initialized
INFO - 2023-04-03 10:50:21 --> Config Class Initialized
INFO - 2023-04-03 10:50:21 --> Hooks Class Initialized
INFO - 2023-04-03 10:50:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:50:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:50:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:21 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:21 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:21 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:21 --> URI Class Initialized
INFO - 2023-04-03 10:50:21 --> URI Class Initialized
INFO - 2023-04-03 10:50:21 --> URI Class Initialized
INFO - 2023-04-03 10:50:21 --> Router Class Initialized
INFO - 2023-04-03 10:50:21 --> Router Class Initialized
INFO - 2023-04-03 10:50:21 --> Router Class Initialized
INFO - 2023-04-03 10:50:21 --> Output Class Initialized
INFO - 2023-04-03 10:50:21 --> Output Class Initialized
INFO - 2023-04-03 10:50:21 --> Output Class Initialized
INFO - 2023-04-03 10:50:21 --> Security Class Initialized
INFO - 2023-04-03 10:50:21 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:21 --> Security Class Initialized
INFO - 2023-04-03 10:50:21 --> Input Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:21 --> Language Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:21 --> Input Class Initialized
INFO - 2023-04-03 10:50:21 --> Input Class Initialized
INFO - 2023-04-03 10:50:21 --> Language Class Initialized
INFO - 2023-04-03 10:50:21 --> Loader Class Initialized
INFO - 2023-04-03 10:50:21 --> Language Class Initialized
INFO - 2023-04-03 10:50:21 --> Controller Class Initialized
INFO - 2023-04-03 10:50:21 --> Loader Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:21 --> Controller Class Initialized
INFO - 2023-04-03 10:50:21 --> Loader Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:21 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:21 --> Controller Class Initialized
INFO - 2023-04-03 10:50:21 --> Database Driver Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:21 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:21 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:21 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:21 --> Model "Cluster_model" initialized
ERROR - 2023-04-03 10:50:21 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:21 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 10:50:21 --> Config Class Initialized
INFO - 2023-04-03 10:50:21 --> Hooks Class Initialized
ERROR - 2023-04-03 10:50:21 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
DEBUG - 2023-04-03 10:50:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:21 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 10:50:21 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:21 --> URI Class Initialized
INFO - 2023-04-03 10:50:21 --> Router Class Initialized
INFO - 2023-04-03 10:50:21 --> Output Class Initialized
INFO - 2023-04-03 10:50:21 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:21 --> Input Class Initialized
INFO - 2023-04-03 10:50:21 --> Language Class Initialized
INFO - 2023-04-03 10:50:21 --> Loader Class Initialized
INFO - 2023-04-03 10:50:21 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:21 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:21 --> Model "Login_model" initialized
INFO - 2023-04-03 10:50:21 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:21 --> Total execution time: 0.0315
INFO - 2023-04-03 10:50:21 --> Config Class Initialized
INFO - 2023-04-03 10:50:21 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:21 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:21 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:21 --> URI Class Initialized
INFO - 2023-04-03 10:50:21 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:50:21 --> Router Class Initialized
INFO - 2023-04-03 10:50:21 --> Output Class Initialized
INFO - 2023-04-03 10:50:21 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:21 --> Input Class Initialized
INFO - 2023-04-03 10:50:21 --> Language Class Initialized
ERROR - 2023-04-03 10:50:21 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:21 --> Loader Class Initialized
INFO - 2023-04-03 10:50:21 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 10:50:21 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:21 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:21 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:21 --> Model "Login_model" initialized
INFO - 2023-04-03 10:50:21 --> Final output sent to browser
DEBUG - 2023-04-03 10:50:21 --> Total execution time: 0.0201
INFO - 2023-04-03 10:50:29 --> Config Class Initialized
INFO - 2023-04-03 10:50:29 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:30 --> URI Class Initialized
INFO - 2023-04-03 10:50:30 --> Router Class Initialized
INFO - 2023-04-03 10:50:30 --> Output Class Initialized
INFO - 2023-04-03 10:50:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:30 --> Input Class Initialized
INFO - 2023-04-03 10:50:30 --> Language Class Initialized
INFO - 2023-04-03 10:50:30 --> Loader Class Initialized
INFO - 2023-04-03 10:50:30 --> Controller Class Initialized
DEBUG - 2023-04-03 10:50:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:50:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:50:30 --> Model "Cluster_model" initialized
ERROR - 2023-04-03 10:50:30 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS `cluster_alarm_user` (`id` INT NOT NULL AUTO_INCREMENT,`uid` INT DEFAULT NULL,`alarm_type` VARCHAR (128) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '告警类型',`alarm_to_user` VARCHAR (255) COLLATE utf8mb4_0900_as_cs DEFAULT NULL COMMENT '提醒方式',`create_at` INT DEFAULT NULL,`update_at` INT DEFAULT NULL,`delete_at` INT DEFAULT NULL,`status` TINYINT DEFAULT NULL COMMENT '是否生效',PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs;
INFO - 2023-04-03 10:50:30 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-03 10:50:30 --> Config Class Initialized
INFO - 2023-04-03 10:50:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:50:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:50:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:50:30 --> URI Class Initialized
INFO - 2023-04-03 10:50:30 --> Router Class Initialized
INFO - 2023-04-03 10:50:30 --> Output Class Initialized
INFO - 2023-04-03 10:50:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:50:30 --> Input Class Initialized
INFO - 2023-04-03 10:50:30 --> Language Class Initialized
ERROR - 2023-04-03 10:50:30 --> 404 Page Not Found: Faviconico/index
INFO - 2023-04-03 10:51:00 --> Config Class Initialized
INFO - 2023-04-03 10:51:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:00 --> URI Class Initialized
INFO - 2023-04-03 10:51:00 --> Router Class Initialized
INFO - 2023-04-03 10:51:00 --> Output Class Initialized
INFO - 2023-04-03 10:51:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:00 --> Input Class Initialized
INFO - 2023-04-03 10:51:00 --> Language Class Initialized
INFO - 2023-04-03 10:51:00 --> Loader Class Initialized
INFO - 2023-04-03 10:51:00 --> Controller Class Initialized
INFO - 2023-04-03 10:51:00 --> Helper loaded: form_helper
INFO - 2023-04-03 10:51:00 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:00 --> Model "Change_model" initialized
INFO - 2023-04-03 10:51:00 --> Model "Grafana_model" initialized
INFO - 2023-04-03 10:51:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:00 --> Total execution time: 0.0341
INFO - 2023-04-03 10:51:00 --> Config Class Initialized
INFO - 2023-04-03 10:51:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:00 --> URI Class Initialized
INFO - 2023-04-03 10:51:00 --> Router Class Initialized
INFO - 2023-04-03 10:51:00 --> Output Class Initialized
INFO - 2023-04-03 10:51:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:00 --> Input Class Initialized
INFO - 2023-04-03 10:51:00 --> Language Class Initialized
INFO - 2023-04-03 10:51:00 --> Loader Class Initialized
INFO - 2023-04-03 10:51:00 --> Controller Class Initialized
INFO - 2023-04-03 10:51:00 --> Helper loaded: form_helper
INFO - 2023-04-03 10:51:00 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:00 --> Total execution time: 0.0454
INFO - 2023-04-03 10:51:00 --> Config Class Initialized
INFO - 2023-04-03 10:51:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:00 --> URI Class Initialized
INFO - 2023-04-03 10:51:00 --> Router Class Initialized
INFO - 2023-04-03 10:51:00 --> Output Class Initialized
INFO - 2023-04-03 10:51:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:00 --> Input Class Initialized
INFO - 2023-04-03 10:51:00 --> Language Class Initialized
INFO - 2023-04-03 10:51:00 --> Loader Class Initialized
INFO - 2023-04-03 10:51:00 --> Controller Class Initialized
INFO - 2023-04-03 10:51:00 --> Helper loaded: form_helper
INFO - 2023-04-03 10:51:00 --> Helper loaded: url_helper
DEBUG - 2023-04-03 10:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:00 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:00 --> Total execution time: 0.0206
INFO - 2023-04-03 10:51:00 --> Config Class Initialized
INFO - 2023-04-03 10:51:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:00 --> URI Class Initialized
INFO - 2023-04-03 10:51:00 --> Router Class Initialized
INFO - 2023-04-03 10:51:00 --> Output Class Initialized
INFO - 2023-04-03 10:51:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:00 --> Input Class Initialized
INFO - 2023-04-03 10:51:00 --> Language Class Initialized
INFO - 2023-04-03 10:51:00 --> Loader Class Initialized
INFO - 2023-04-03 10:51:00 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:00 --> Total execution time: 0.0582
INFO - 2023-04-03 10:51:00 --> Config Class Initialized
INFO - 2023-04-03 10:51:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:00 --> URI Class Initialized
INFO - 2023-04-03 10:51:00 --> Router Class Initialized
INFO - 2023-04-03 10:51:00 --> Output Class Initialized
INFO - 2023-04-03 10:51:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:00 --> Input Class Initialized
INFO - 2023-04-03 10:51:00 --> Language Class Initialized
INFO - 2023-04-03 10:51:00 --> Loader Class Initialized
INFO - 2023-04-03 10:51:00 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:00 --> Total execution time: 0.0134
INFO - 2023-04-03 10:51:00 --> Config Class Initialized
INFO - 2023-04-03 10:51:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:00 --> URI Class Initialized
INFO - 2023-04-03 10:51:00 --> Router Class Initialized
INFO - 2023-04-03 10:51:00 --> Output Class Initialized
INFO - 2023-04-03 10:51:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:00 --> Input Class Initialized
INFO - 2023-04-03 10:51:00 --> Language Class Initialized
INFO - 2023-04-03 10:51:00 --> Loader Class Initialized
INFO - 2023-04-03 10:51:00 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:00 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:00 --> Total execution time: 0.1505
INFO - 2023-04-03 10:51:00 --> Config Class Initialized
INFO - 2023-04-03 10:51:00 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:00 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:00 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:00 --> URI Class Initialized
INFO - 2023-04-03 10:51:00 --> Router Class Initialized
INFO - 2023-04-03 10:51:00 --> Output Class Initialized
INFO - 2023-04-03 10:51:00 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:00 --> Input Class Initialized
INFO - 2023-04-03 10:51:00 --> Language Class Initialized
INFO - 2023-04-03 10:51:00 --> Loader Class Initialized
INFO - 2023-04-03 10:51:00 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:00 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:00 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:00 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:00 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:00 --> Total execution time: 0.0537
INFO - 2023-04-03 10:51:03 --> Config Class Initialized
INFO - 2023-04-03 10:51:03 --> Config Class Initialized
INFO - 2023-04-03 10:51:03 --> Config Class Initialized
INFO - 2023-04-03 10:51:03 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:03 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:03 --> URI Class Initialized
INFO - 2023-04-03 10:51:03 --> Utf8 Class Initialized
DEBUG - 2023-04-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:03 --> URI Class Initialized
INFO - 2023-04-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:03 --> Router Class Initialized
INFO - 2023-04-03 10:51:03 --> Router Class Initialized
INFO - 2023-04-03 10:51:03 --> URI Class Initialized
INFO - 2023-04-03 10:51:03 --> Router Class Initialized
INFO - 2023-04-03 10:51:03 --> Output Class Initialized
INFO - 2023-04-03 10:51:03 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:03 --> Output Class Initialized
INFO - 2023-04-03 10:51:03 --> Output Class Initialized
INFO - 2023-04-03 10:51:03 --> Input Class Initialized
INFO - 2023-04-03 10:51:03 --> Security Class Initialized
INFO - 2023-04-03 10:51:03 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:03 --> Input Class Initialized
INFO - 2023-04-03 10:51:03 --> Input Class Initialized
INFO - 2023-04-03 10:51:03 --> Language Class Initialized
INFO - 2023-04-03 10:51:03 --> Language Class Initialized
INFO - 2023-04-03 10:51:03 --> Language Class Initialized
INFO - 2023-04-03 10:51:03 --> Loader Class Initialized
INFO - 2023-04-03 10:51:03 --> Loader Class Initialized
INFO - 2023-04-03 10:51:03 --> Loader Class Initialized
INFO - 2023-04-03 10:51:03 --> Controller Class Initialized
INFO - 2023-04-03 10:51:03 --> Controller Class Initialized
INFO - 2023-04-03 10:51:03 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:03 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:03 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:03 --> Total execution time: 0.0343
INFO - 2023-04-03 10:51:03 --> Config Class Initialized
INFO - 2023-04-03 10:51:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:03 --> URI Class Initialized
INFO - 2023-04-03 10:51:03 --> Router Class Initialized
INFO - 2023-04-03 10:51:03 --> Output Class Initialized
INFO - 2023-04-03 10:51:03 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:03 --> Input Class Initialized
INFO - 2023-04-03 10:51:03 --> Language Class Initialized
INFO - 2023-04-03 10:51:03 --> Loader Class Initialized
INFO - 2023-04-03 10:51:03 --> Final output sent to browser
INFO - 2023-04-03 10:51:03 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Total execution time: 0.0413
DEBUG - 2023-04-03 10:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:03 --> Total execution time: 0.0424
INFO - 2023-04-03 10:51:03 --> Config Class Initialized
INFO - 2023-04-03 10:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:03 --> URI Class Initialized
INFO - 2023-04-03 10:51:03 --> Config Class Initialized
INFO - 2023-04-03 10:51:03 --> Final output sent to browser
INFO - 2023-04-03 10:51:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Total execution time: 0.0617
INFO - 2023-04-03 10:51:03 --> Router Class Initialized
DEBUG - 2023-04-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:03 --> Output Class Initialized
INFO - 2023-04-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:03 --> Security Class Initialized
INFO - 2023-04-03 10:51:03 --> URI Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:03 --> Input Class Initialized
INFO - 2023-04-03 10:51:03 --> Router Class Initialized
INFO - 2023-04-03 10:51:03 --> Language Class Initialized
INFO - 2023-04-03 10:51:03 --> Config Class Initialized
INFO - 2023-04-03 10:51:03 --> Output Class Initialized
INFO - 2023-04-03 10:51:03 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:03 --> Loader Class Initialized
INFO - 2023-04-03 10:51:03 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:03 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:03 --> Input Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:03 --> Language Class Initialized
INFO - 2023-04-03 10:51:03 --> URI Class Initialized
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Loader Class Initialized
INFO - 2023-04-03 10:51:03 --> Router Class Initialized
INFO - 2023-04-03 10:51:03 --> Controller Class Initialized
INFO - 2023-04-03 10:51:03 --> Output Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:03 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Input Class Initialized
INFO - 2023-04-03 10:51:03 --> Language Class Initialized
INFO - 2023-04-03 10:51:03 --> Loader Class Initialized
INFO - 2023-04-03 10:51:03 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:03 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:03 --> Total execution time: 0.1424
INFO - 2023-04-03 10:51:03 --> Config Class Initialized
INFO - 2023-04-03 10:51:03 --> Final output sent to browser
INFO - 2023-04-03 10:51:03 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:03 --> Total execution time: 0.0662
INFO - 2023-04-03 10:51:03 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Total execution time: 0.1070
DEBUG - 2023-04-03 10:51:03 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:03 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:03 --> URI Class Initialized
INFO - 2023-04-03 10:51:03 --> Router Class Initialized
INFO - 2023-04-03 10:51:03 --> Output Class Initialized
INFO - 2023-04-03 10:51:03 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:03 --> Input Class Initialized
INFO - 2023-04-03 10:51:03 --> Language Class Initialized
INFO - 2023-04-03 10:51:03 --> Loader Class Initialized
INFO - 2023-04-03 10:51:03 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:03 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:03 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:03 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:03 --> Total execution time: 0.1059
INFO - 2023-04-03 10:51:09 --> Config Class Initialized
INFO - 2023-04-03 10:51:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:09 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:09 --> URI Class Initialized
INFO - 2023-04-03 10:51:09 --> Router Class Initialized
INFO - 2023-04-03 10:51:09 --> Output Class Initialized
INFO - 2023-04-03 10:51:09 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:09 --> Input Class Initialized
INFO - 2023-04-03 10:51:09 --> Language Class Initialized
INFO - 2023-04-03 10:51:09 --> Loader Class Initialized
INFO - 2023-04-03 10:51:09 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:09 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:09 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:09 --> Total execution time: 0.0165
INFO - 2023-04-03 10:51:09 --> Config Class Initialized
INFO - 2023-04-03 10:51:09 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:09 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:09 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:09 --> URI Class Initialized
INFO - 2023-04-03 10:51:09 --> Router Class Initialized
INFO - 2023-04-03 10:51:09 --> Output Class Initialized
INFO - 2023-04-03 10:51:09 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:09 --> Input Class Initialized
INFO - 2023-04-03 10:51:09 --> Language Class Initialized
INFO - 2023-04-03 10:51:09 --> Loader Class Initialized
INFO - 2023-04-03 10:51:09 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:09 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:09 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:09 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:09 --> Total execution time: 0.0564
INFO - 2023-04-03 10:51:10 --> Config Class Initialized
INFO - 2023-04-03 10:51:10 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:10 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:10 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:10 --> URI Class Initialized
INFO - 2023-04-03 10:51:10 --> Router Class Initialized
INFO - 2023-04-03 10:51:10 --> Output Class Initialized
INFO - 2023-04-03 10:51:10 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:10 --> Input Class Initialized
INFO - 2023-04-03 10:51:10 --> Language Class Initialized
INFO - 2023-04-03 10:51:10 --> Loader Class Initialized
INFO - 2023-04-03 10:51:10 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:10 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:10 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:10 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:10 --> Total execution time: 0.0293
INFO - 2023-04-03 10:51:10 --> Config Class Initialized
INFO - 2023-04-03 10:51:10 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:10 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:10 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:10 --> URI Class Initialized
INFO - 2023-04-03 10:51:10 --> Router Class Initialized
INFO - 2023-04-03 10:51:10 --> Output Class Initialized
INFO - 2023-04-03 10:51:10 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:10 --> Input Class Initialized
INFO - 2023-04-03 10:51:10 --> Language Class Initialized
INFO - 2023-04-03 10:51:10 --> Loader Class Initialized
INFO - 2023-04-03 10:51:10 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:10 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:10 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:10 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:10 --> Total execution time: 0.0214
INFO - 2023-04-03 10:51:11 --> Config Class Initialized
INFO - 2023-04-03 10:51:11 --> Config Class Initialized
INFO - 2023-04-03 10:51:11 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:51:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:11 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:11 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:11 --> URI Class Initialized
INFO - 2023-04-03 10:51:11 --> URI Class Initialized
INFO - 2023-04-03 10:51:11 --> Router Class Initialized
INFO - 2023-04-03 10:51:11 --> Router Class Initialized
INFO - 2023-04-03 10:51:11 --> Output Class Initialized
INFO - 2023-04-03 10:51:11 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:11 --> Output Class Initialized
INFO - 2023-04-03 10:51:11 --> Input Class Initialized
INFO - 2023-04-03 10:51:11 --> Security Class Initialized
INFO - 2023-04-03 10:51:11 --> Language Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:11 --> Input Class Initialized
INFO - 2023-04-03 10:51:11 --> Loader Class Initialized
INFO - 2023-04-03 10:51:11 --> Language Class Initialized
INFO - 2023-04-03 10:51:11 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:11 --> Loader Class Initialized
INFO - 2023-04-03 10:51:11 --> Final output sent to browser
INFO - 2023-04-03 10:51:11 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Total execution time: 0.0654
DEBUG - 2023-04-03 10:51:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:11 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:11 --> Config Class Initialized
INFO - 2023-04-03 10:51:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:11 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:11 --> URI Class Initialized
INFO - 2023-04-03 10:51:11 --> Router Class Initialized
INFO - 2023-04-03 10:51:11 --> Output Class Initialized
INFO - 2023-04-03 10:51:11 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:11 --> Input Class Initialized
INFO - 2023-04-03 10:51:11 --> Language Class Initialized
INFO - 2023-04-03 10:51:11 --> Loader Class Initialized
INFO - 2023-04-03 10:51:11 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:11 --> Final output sent to browser
INFO - 2023-04-03 10:51:11 --> Database Driver Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Total execution time: 0.1112
INFO - 2023-04-03 10:51:11 --> Config Class Initialized
INFO - 2023-04-03 10:51:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:11 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:11 --> URI Class Initialized
INFO - 2023-04-03 10:51:11 --> Router Class Initialized
INFO - 2023-04-03 10:51:11 --> Output Class Initialized
INFO - 2023-04-03 10:51:11 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:11 --> Input Class Initialized
INFO - 2023-04-03 10:51:11 --> Language Class Initialized
INFO - 2023-04-03 10:51:11 --> Loader Class Initialized
INFO - 2023-04-03 10:51:11 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:11 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:11 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:11 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:11 --> Config Class Initialized
INFO - 2023-04-03 10:51:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:11 --> Final output sent to browser
INFO - 2023-04-03 10:51:11 --> Utf8 Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Total execution time: 0.0188
INFO - 2023-04-03 10:51:11 --> URI Class Initialized
INFO - 2023-04-03 10:51:11 --> Router Class Initialized
INFO - 2023-04-03 10:51:11 --> Output Class Initialized
INFO - 2023-04-03 10:51:11 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:11 --> Total execution time: 0.0669
INFO - 2023-04-03 10:51:11 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:11 --> Input Class Initialized
INFO - 2023-04-03 10:51:11 --> Language Class Initialized
INFO - 2023-04-03 10:51:11 --> Loader Class Initialized
INFO - 2023-04-03 10:51:11 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:11 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:11 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:11 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:11 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:11 --> Total execution time: 0.1307
INFO - 2023-04-03 10:51:11 --> Config Class Initialized
INFO - 2023-04-03 10:51:11 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:11 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:11 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:11 --> URI Class Initialized
INFO - 2023-04-03 10:51:11 --> Router Class Initialized
INFO - 2023-04-03 10:51:11 --> Output Class Initialized
INFO - 2023-04-03 10:51:11 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:11 --> Input Class Initialized
INFO - 2023-04-03 10:51:11 --> Language Class Initialized
INFO - 2023-04-03 10:51:11 --> Loader Class Initialized
INFO - 2023-04-03 10:51:11 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:11 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:11 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:11 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:11 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:11 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:11 --> Total execution time: 0.0492
INFO - 2023-04-03 10:51:14 --> Config Class Initialized
INFO - 2023-04-03 10:51:14 --> Config Class Initialized
INFO - 2023-04-03 10:51:14 --> Config Class Initialized
INFO - 2023-04-03 10:51:14 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:14 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:51:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:14 --> URI Class Initialized
INFO - 2023-04-03 10:51:14 --> URI Class Initialized
INFO - 2023-04-03 10:51:14 --> URI Class Initialized
INFO - 2023-04-03 10:51:14 --> Router Class Initialized
INFO - 2023-04-03 10:51:14 --> Router Class Initialized
INFO - 2023-04-03 10:51:14 --> Router Class Initialized
INFO - 2023-04-03 10:51:14 --> Output Class Initialized
INFO - 2023-04-03 10:51:14 --> Output Class Initialized
INFO - 2023-04-03 10:51:14 --> Output Class Initialized
INFO - 2023-04-03 10:51:14 --> Security Class Initialized
INFO - 2023-04-03 10:51:14 --> Security Class Initialized
INFO - 2023-04-03 10:51:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:14 --> Input Class Initialized
INFO - 2023-04-03 10:51:14 --> Input Class Initialized
INFO - 2023-04-03 10:51:14 --> Input Class Initialized
INFO - 2023-04-03 10:51:14 --> Language Class Initialized
INFO - 2023-04-03 10:51:14 --> Language Class Initialized
INFO - 2023-04-03 10:51:14 --> Language Class Initialized
INFO - 2023-04-03 10:51:14 --> Loader Class Initialized
INFO - 2023-04-03 10:51:14 --> Loader Class Initialized
INFO - 2023-04-03 10:51:14 --> Loader Class Initialized
INFO - 2023-04-03 10:51:14 --> Controller Class Initialized
INFO - 2023-04-03 10:51:14 --> Controller Class Initialized
INFO - 2023-04-03 10:51:14 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:51:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:51:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:14 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:14 --> Total execution time: 0.0292
INFO - 2023-04-03 10:51:14 --> Config Class Initialized
INFO - 2023-04-03 10:51:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:14 --> URI Class Initialized
INFO - 2023-04-03 10:51:14 --> Router Class Initialized
INFO - 2023-04-03 10:51:14 --> Output Class Initialized
INFO - 2023-04-03 10:51:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:14 --> Input Class Initialized
INFO - 2023-04-03 10:51:14 --> Language Class Initialized
INFO - 2023-04-03 10:51:14 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:14 --> Total execution time: 0.0338
INFO - 2023-04-03 10:51:14 --> Loader Class Initialized
INFO - 2023-04-03 10:51:14 --> Final output sent to browser
INFO - 2023-04-03 10:51:14 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Total execution time: 0.0342
DEBUG - 2023-04-03 10:51:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Config Class Initialized
INFO - 2023-04-03 10:51:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:14 --> URI Class Initialized
INFO - 2023-04-03 10:51:14 --> Router Class Initialized
INFO - 2023-04-03 10:51:14 --> Output Class Initialized
INFO - 2023-04-03 10:51:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:14 --> Config Class Initialized
INFO - 2023-04-03 10:51:14 --> Input Class Initialized
INFO - 2023-04-03 10:51:14 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:14 --> Language Class Initialized
DEBUG - 2023-04-03 10:51:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:14 --> Loader Class Initialized
INFO - 2023-04-03 10:51:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:14 --> Controller Class Initialized
INFO - 2023-04-03 10:51:14 --> URI Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:14 --> Router Class Initialized
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Output Class Initialized
INFO - 2023-04-03 10:51:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:14 --> Input Class Initialized
INFO - 2023-04-03 10:51:14 --> Language Class Initialized
INFO - 2023-04-03 10:51:14 --> Loader Class Initialized
INFO - 2023-04-03 10:51:14 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:14 --> Final output sent to browser
INFO - 2023-04-03 10:51:14 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:14 --> Total execution time: 0.0265
DEBUG - 2023-04-03 10:51:14 --> Total execution time: 0.0239
INFO - 2023-04-03 10:51:14 --> Config Class Initialized
INFO - 2023-04-03 10:51:14 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:14 --> Config Class Initialized
INFO - 2023-04-03 10:51:14 --> Final output sent to browser
INFO - 2023-04-03 10:51:14 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Total execution time: 0.0267
DEBUG - 2023-04-03 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:51:14 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:14 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:14 --> URI Class Initialized
INFO - 2023-04-03 10:51:14 --> URI Class Initialized
INFO - 2023-04-03 10:51:14 --> Router Class Initialized
INFO - 2023-04-03 10:51:14 --> Router Class Initialized
INFO - 2023-04-03 10:51:14 --> Output Class Initialized
INFO - 2023-04-03 10:51:14 --> Output Class Initialized
INFO - 2023-04-03 10:51:14 --> Security Class Initialized
INFO - 2023-04-03 10:51:14 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:14 --> Input Class Initialized
INFO - 2023-04-03 10:51:14 --> Input Class Initialized
INFO - 2023-04-03 10:51:14 --> Language Class Initialized
INFO - 2023-04-03 10:51:14 --> Language Class Initialized
INFO - 2023-04-03 10:51:14 --> Loader Class Initialized
INFO - 2023-04-03 10:51:14 --> Loader Class Initialized
INFO - 2023-04-03 10:51:14 --> Controller Class Initialized
INFO - 2023-04-03 10:51:14 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:51:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:14 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:14 --> Final output sent to browser
INFO - 2023-04-03 10:51:14 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:14 --> Total execution time: 0.1084
DEBUG - 2023-04-03 10:51:14 --> Total execution time: 0.1061
INFO - 2023-04-03 10:51:30 --> Config Class Initialized
INFO - 2023-04-03 10:51:30 --> Config Class Initialized
INFO - 2023-04-03 10:51:30 --> Config Class Initialized
INFO - 2023-04-03 10:51:30 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:30 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-03 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:30 --> Utf8 Class Initialized
DEBUG - 2023-04-03 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:30 --> URI Class Initialized
INFO - 2023-04-03 10:51:30 --> URI Class Initialized
INFO - 2023-04-03 10:51:30 --> URI Class Initialized
INFO - 2023-04-03 10:51:30 --> Router Class Initialized
INFO - 2023-04-03 10:51:30 --> Router Class Initialized
INFO - 2023-04-03 10:51:30 --> Router Class Initialized
INFO - 2023-04-03 10:51:30 --> Output Class Initialized
INFO - 2023-04-03 10:51:30 --> Output Class Initialized
INFO - 2023-04-03 10:51:30 --> Output Class Initialized
INFO - 2023-04-03 10:51:30 --> Security Class Initialized
INFO - 2023-04-03 10:51:30 --> Security Class Initialized
INFO - 2023-04-03 10:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-03 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:30 --> Input Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:30 --> Language Class Initialized
INFO - 2023-04-03 10:51:30 --> Input Class Initialized
INFO - 2023-04-03 10:51:30 --> Input Class Initialized
INFO - 2023-04-03 10:51:30 --> Language Class Initialized
INFO - 2023-04-03 10:51:30 --> Language Class Initialized
INFO - 2023-04-03 10:51:30 --> Loader Class Initialized
INFO - 2023-04-03 10:51:30 --> Loader Class Initialized
INFO - 2023-04-03 10:51:30 --> Loader Class Initialized
INFO - 2023-04-03 10:51:30 --> Controller Class Initialized
INFO - 2023-04-03 10:51:30 --> Controller Class Initialized
INFO - 2023-04-03 10:51:30 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-03 10:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:30 --> Total execution time: 0.1525
INFO - 2023-04-03 10:51:30 --> Config Class Initialized
INFO - 2023-04-03 10:51:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:30 --> URI Class Initialized
INFO - 2023-04-03 10:51:30 --> Router Class Initialized
INFO - 2023-04-03 10:51:30 --> Output Class Initialized
INFO - 2023-04-03 10:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:30 --> Input Class Initialized
INFO - 2023-04-03 10:51:30 --> Language Class Initialized
INFO - 2023-04-03 10:51:30 --> Loader Class Initialized
INFO - 2023-04-03 10:51:30 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:30 --> Final output sent to browser
INFO - 2023-04-03 10:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:30 --> Total execution time: 0.1580
DEBUG - 2023-04-03 10:51:30 --> Total execution time: 0.1567
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Config Class Initialized
INFO - 2023-04-03 10:51:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:30 --> URI Class Initialized
INFO - 2023-04-03 10:51:30 --> Router Class Initialized
INFO - 2023-04-03 10:51:30 --> Output Class Initialized
INFO - 2023-04-03 10:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:30 --> Config Class Initialized
INFO - 2023-04-03 10:51:30 --> Input Class Initialized
INFO - 2023-04-03 10:51:30 --> Hooks Class Initialized
INFO - 2023-04-03 10:51:30 --> Language Class Initialized
DEBUG - 2023-04-03 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:30 --> Loader Class Initialized
INFO - 2023-04-03 10:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:30 --> Controller Class Initialized
INFO - 2023-04-03 10:51:30 --> URI Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:30 --> Router Class Initialized
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Output Class Initialized
INFO - 2023-04-03 10:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:30 --> Input Class Initialized
INFO - 2023-04-03 10:51:30 --> Language Class Initialized
INFO - 2023-04-03 10:51:30 --> Loader Class Initialized
INFO - 2023-04-03 10:51:30 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Model "Login_model" initialized
INFO - 2023-04-03 10:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:30 --> Total execution time: 0.0325
INFO - 2023-04-03 10:51:30 --> Config Class Initialized
INFO - 2023-04-03 10:51:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:30 --> URI Class Initialized
INFO - 2023-04-03 10:51:30 --> Router Class Initialized
INFO - 2023-04-03 10:51:30 --> Output Class Initialized
INFO - 2023-04-03 10:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:30 --> Input Class Initialized
INFO - 2023-04-03 10:51:30 --> Language Class Initialized
INFO - 2023-04-03 10:51:30 --> Loader Class Initialized
INFO - 2023-04-03 10:51:30 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:30 --> Total execution time: 0.0328
INFO - 2023-04-03 10:51:30 --> Config Class Initialized
INFO - 2023-04-03 10:51:30 --> Final output sent to browser
INFO - 2023-04-03 10:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:30 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Total execution time: 0.0328
DEBUG - 2023-04-03 10:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:30 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:30 --> URI Class Initialized
INFO - 2023-04-03 10:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:30 --> Total execution time: 0.0594
INFO - 2023-04-03 10:51:30 --> Router Class Initialized
INFO - 2023-04-03 10:51:30 --> Output Class Initialized
INFO - 2023-04-03 10:51:30 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:30 --> Input Class Initialized
INFO - 2023-04-03 10:51:30 --> Language Class Initialized
INFO - 2023-04-03 10:51:30 --> Loader Class Initialized
INFO - 2023-04-03 10:51:30 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:30 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:30 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:30 --> Total execution time: 0.1198
INFO - 2023-04-03 10:51:43 --> Config Class Initialized
INFO - 2023-04-03 10:51:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:43 --> URI Class Initialized
INFO - 2023-04-03 10:51:43 --> Router Class Initialized
INFO - 2023-04-03 10:51:43 --> Output Class Initialized
INFO - 2023-04-03 10:51:43 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:43 --> Input Class Initialized
INFO - 2023-04-03 10:51:43 --> Language Class Initialized
INFO - 2023-04-03 10:51:43 --> Loader Class Initialized
INFO - 2023-04-03 10:51:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:43 --> Total execution time: 0.0625
INFO - 2023-04-03 10:51:43 --> Config Class Initialized
INFO - 2023-04-03 10:51:43 --> Hooks Class Initialized
DEBUG - 2023-04-03 10:51:43 --> UTF-8 Support Enabled
INFO - 2023-04-03 10:51:43 --> Utf8 Class Initialized
INFO - 2023-04-03 10:51:43 --> URI Class Initialized
INFO - 2023-04-03 10:51:43 --> Router Class Initialized
INFO - 2023-04-03 10:51:43 --> Output Class Initialized
INFO - 2023-04-03 10:51:43 --> Security Class Initialized
DEBUG - 2023-04-03 10:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-03 10:51:43 --> Input Class Initialized
INFO - 2023-04-03 10:51:43 --> Language Class Initialized
INFO - 2023-04-03 10:51:43 --> Loader Class Initialized
INFO - 2023-04-03 10:51:43 --> Controller Class Initialized
DEBUG - 2023-04-03 10:51:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-03 10:51:43 --> Database Driver Class Initialized
INFO - 2023-04-03 10:51:43 --> Model "Cluster_model" initialized
INFO - 2023-04-03 10:51:43 --> Final output sent to browser
DEBUG - 2023-04-03 10:51:43 --> Total execution time: 0.0665
