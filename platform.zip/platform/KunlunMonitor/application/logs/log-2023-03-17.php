<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-17 02:40:03 --> Config Class Initialized
INFO - 2023-03-17 02:40:03 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:03 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:03 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:03 --> URI Class Initialized
INFO - 2023-03-17 02:40:03 --> Router Class Initialized
INFO - 2023-03-17 02:40:03 --> Output Class Initialized
INFO - 2023-03-17 02:40:03 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:03 --> Input Class Initialized
INFO - 2023-03-17 02:40:03 --> Language Class Initialized
INFO - 2023-03-17 02:40:03 --> Loader Class Initialized
INFO - 2023-03-17 02:40:03 --> Controller Class Initialized
INFO - 2023-03-17 02:40:03 --> Helper loaded: form_helper
INFO - 2023-03-17 02:40:03 --> Helper loaded: url_helper
DEBUG - 2023-03-17 02:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:03 --> Model "Change_model" initialized
INFO - 2023-03-17 02:40:03 --> Model "Grafana_model" initialized
INFO - 2023-03-17 02:40:03 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:03 --> Total execution time: 0.0522
INFO - 2023-03-17 02:40:03 --> Config Class Initialized
INFO - 2023-03-17 02:40:03 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:03 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:03 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:03 --> URI Class Initialized
INFO - 2023-03-17 02:40:03 --> Router Class Initialized
INFO - 2023-03-17 02:40:03 --> Output Class Initialized
INFO - 2023-03-17 02:40:03 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:03 --> Input Class Initialized
INFO - 2023-03-17 02:40:03 --> Language Class Initialized
INFO - 2023-03-17 02:40:03 --> Loader Class Initialized
INFO - 2023-03-17 02:40:03 --> Controller Class Initialized
INFO - 2023-03-17 02:40:03 --> Helper loaded: form_helper
INFO - 2023-03-17 02:40:03 --> Helper loaded: url_helper
DEBUG - 2023-03-17 02:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:03 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:03 --> Total execution time: 0.0430
INFO - 2023-03-17 02:40:03 --> Config Class Initialized
INFO - 2023-03-17 02:40:03 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:03 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:03 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:03 --> URI Class Initialized
INFO - 2023-03-17 02:40:03 --> Router Class Initialized
INFO - 2023-03-17 02:40:03 --> Output Class Initialized
INFO - 2023-03-17 02:40:03 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:03 --> Input Class Initialized
INFO - 2023-03-17 02:40:03 --> Language Class Initialized
INFO - 2023-03-17 02:40:03 --> Loader Class Initialized
INFO - 2023-03-17 02:40:03 --> Controller Class Initialized
INFO - 2023-03-17 02:40:03 --> Helper loaded: form_helper
INFO - 2023-03-17 02:40:03 --> Helper loaded: url_helper
DEBUG - 2023-03-17 02:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:03 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:03 --> Model "Login_model" initialized
INFO - 2023-03-17 02:40:03 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:03 --> Total execution time: 0.0174
INFO - 2023-03-17 02:40:03 --> Config Class Initialized
INFO - 2023-03-17 02:40:03 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:03 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:03 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:03 --> URI Class Initialized
INFO - 2023-03-17 02:40:03 --> Router Class Initialized
INFO - 2023-03-17 02:40:03 --> Output Class Initialized
INFO - 2023-03-17 02:40:03 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:03 --> Input Class Initialized
INFO - 2023-03-17 02:40:03 --> Language Class Initialized
INFO - 2023-03-17 02:40:03 --> Loader Class Initialized
INFO - 2023-03-17 02:40:03 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:03 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:03 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:40:03 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:03 --> Total execution time: 0.0308
INFO - 2023-03-17 02:40:03 --> Config Class Initialized
INFO - 2023-03-17 02:40:03 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:03 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:03 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:03 --> URI Class Initialized
INFO - 2023-03-17 02:40:03 --> Router Class Initialized
INFO - 2023-03-17 02:40:03 --> Output Class Initialized
INFO - 2023-03-17 02:40:03 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:03 --> Input Class Initialized
INFO - 2023-03-17 02:40:03 --> Language Class Initialized
INFO - 2023-03-17 02:40:03 --> Loader Class Initialized
INFO - 2023-03-17 02:40:03 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:03 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:03 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:40:03 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:03 --> Total execution time: 0.0145
INFO - 2023-03-17 02:40:03 --> Config Class Initialized
INFO - 2023-03-17 02:40:03 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:03 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:03 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:03 --> URI Class Initialized
INFO - 2023-03-17 02:40:03 --> Router Class Initialized
INFO - 2023-03-17 02:40:03 --> Output Class Initialized
INFO - 2023-03-17 02:40:03 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:03 --> Input Class Initialized
INFO - 2023-03-17 02:40:03 --> Language Class Initialized
INFO - 2023-03-17 02:40:03 --> Loader Class Initialized
INFO - 2023-03-17 02:40:03 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:03 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:03 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:40:03 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:03 --> Model "Login_model" initialized
INFO - 2023-03-17 02:40:03 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:03 --> Total execution time: 0.0458
INFO - 2023-03-17 02:40:03 --> Config Class Initialized
INFO - 2023-03-17 02:40:03 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:03 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:03 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:03 --> URI Class Initialized
INFO - 2023-03-17 02:40:03 --> Router Class Initialized
INFO - 2023-03-17 02:40:03 --> Output Class Initialized
INFO - 2023-03-17 02:40:03 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:03 --> Input Class Initialized
INFO - 2023-03-17 02:40:03 --> Language Class Initialized
INFO - 2023-03-17 02:40:03 --> Loader Class Initialized
INFO - 2023-03-17 02:40:03 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:03 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:03 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:40:03 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:03 --> Model "Login_model" initialized
INFO - 2023-03-17 02:40:03 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:03 --> Total execution time: 0.0855
INFO - 2023-03-17 02:40:05 --> Config Class Initialized
INFO - 2023-03-17 02:40:05 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:05 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:05 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:05 --> URI Class Initialized
INFO - 2023-03-17 02:40:05 --> Router Class Initialized
INFO - 2023-03-17 02:40:05 --> Output Class Initialized
INFO - 2023-03-17 02:40:05 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:05 --> Input Class Initialized
INFO - 2023-03-17 02:40:05 --> Language Class Initialized
INFO - 2023-03-17 02:40:05 --> Loader Class Initialized
INFO - 2023-03-17 02:40:05 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:05 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:05 --> Total execution time: 0.0035
INFO - 2023-03-17 02:40:05 --> Config Class Initialized
INFO - 2023-03-17 02:40:05 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:05 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:05 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:05 --> URI Class Initialized
INFO - 2023-03-17 02:40:05 --> Router Class Initialized
INFO - 2023-03-17 02:40:05 --> Output Class Initialized
INFO - 2023-03-17 02:40:05 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:05 --> Input Class Initialized
INFO - 2023-03-17 02:40:05 --> Language Class Initialized
INFO - 2023-03-17 02:40:05 --> Loader Class Initialized
INFO - 2023-03-17 02:40:05 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:05 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:05 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:40:05 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:05 --> Total execution time: 0.0139
INFO - 2023-03-17 02:40:25 --> Config Class Initialized
INFO - 2023-03-17 02:40:25 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:25 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:25 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:25 --> URI Class Initialized
INFO - 2023-03-17 02:40:25 --> Router Class Initialized
INFO - 2023-03-17 02:40:25 --> Output Class Initialized
INFO - 2023-03-17 02:40:25 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:25 --> Input Class Initialized
INFO - 2023-03-17 02:40:25 --> Language Class Initialized
INFO - 2023-03-17 02:40:25 --> Loader Class Initialized
INFO - 2023-03-17 02:40:25 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:25 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:25 --> Total execution time: 0.0044
INFO - 2023-03-17 02:40:25 --> Config Class Initialized
INFO - 2023-03-17 02:40:25 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:25 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:25 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:25 --> URI Class Initialized
INFO - 2023-03-17 02:40:25 --> Router Class Initialized
INFO - 2023-03-17 02:40:25 --> Output Class Initialized
INFO - 2023-03-17 02:40:25 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:25 --> Input Class Initialized
INFO - 2023-03-17 02:40:25 --> Language Class Initialized
INFO - 2023-03-17 02:40:25 --> Loader Class Initialized
INFO - 2023-03-17 02:40:25 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:25 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:25 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:40:25 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:25 --> Total execution time: 0.0548
INFO - 2023-03-17 02:40:25 --> Config Class Initialized
INFO - 2023-03-17 02:40:25 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:25 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:25 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:25 --> URI Class Initialized
INFO - 2023-03-17 02:40:25 --> Router Class Initialized
INFO - 2023-03-17 02:40:25 --> Output Class Initialized
INFO - 2023-03-17 02:40:25 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:25 --> Input Class Initialized
INFO - 2023-03-17 02:40:25 --> Language Class Initialized
INFO - 2023-03-17 02:40:25 --> Loader Class Initialized
INFO - 2023-03-17 02:40:25 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:25 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:25 --> Total execution time: 0.0463
INFO - 2023-03-17 02:40:25 --> Config Class Initialized
INFO - 2023-03-17 02:40:25 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:40:25 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:40:25 --> Utf8 Class Initialized
INFO - 2023-03-17 02:40:25 --> URI Class Initialized
INFO - 2023-03-17 02:40:25 --> Router Class Initialized
INFO - 2023-03-17 02:40:25 --> Output Class Initialized
INFO - 2023-03-17 02:40:25 --> Security Class Initialized
DEBUG - 2023-03-17 02:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:40:25 --> Input Class Initialized
INFO - 2023-03-17 02:40:25 --> Language Class Initialized
INFO - 2023-03-17 02:40:25 --> Loader Class Initialized
INFO - 2023-03-17 02:40:25 --> Controller Class Initialized
DEBUG - 2023-03-17 02:40:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:40:25 --> Database Driver Class Initialized
INFO - 2023-03-17 02:40:25 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:40:25 --> Final output sent to browser
DEBUG - 2023-03-17 02:40:25 --> Total execution time: 0.0562
INFO - 2023-03-17 02:41:00 --> Config Class Initialized
INFO - 2023-03-17 02:41:00 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:00 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:00 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:00 --> URI Class Initialized
INFO - 2023-03-17 02:41:00 --> Router Class Initialized
INFO - 2023-03-17 02:41:00 --> Output Class Initialized
INFO - 2023-03-17 02:41:00 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:00 --> Input Class Initialized
INFO - 2023-03-17 02:41:00 --> Language Class Initialized
INFO - 2023-03-17 02:41:00 --> Loader Class Initialized
INFO - 2023-03-17 02:41:00 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:00 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:00 --> Total execution time: 0.0040
INFO - 2023-03-17 02:41:00 --> Config Class Initialized
INFO - 2023-03-17 02:41:00 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:00 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:00 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:00 --> URI Class Initialized
INFO - 2023-03-17 02:41:00 --> Router Class Initialized
INFO - 2023-03-17 02:41:00 --> Output Class Initialized
INFO - 2023-03-17 02:41:00 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:00 --> Input Class Initialized
INFO - 2023-03-17 02:41:00 --> Language Class Initialized
INFO - 2023-03-17 02:41:00 --> Loader Class Initialized
INFO - 2023-03-17 02:41:00 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:00 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:00 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:00 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:00 --> Total execution time: 0.0553
INFO - 2023-03-17 02:41:00 --> Config Class Initialized
INFO - 2023-03-17 02:41:00 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:00 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:00 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:00 --> URI Class Initialized
INFO - 2023-03-17 02:41:00 --> Router Class Initialized
INFO - 2023-03-17 02:41:00 --> Output Class Initialized
INFO - 2023-03-17 02:41:00 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:00 --> Input Class Initialized
INFO - 2023-03-17 02:41:00 --> Language Class Initialized
INFO - 2023-03-17 02:41:00 --> Loader Class Initialized
INFO - 2023-03-17 02:41:00 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:00 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:00 --> Total execution time: 0.0453
INFO - 2023-03-17 02:41:00 --> Config Class Initialized
INFO - 2023-03-17 02:41:00 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:00 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:00 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:00 --> URI Class Initialized
INFO - 2023-03-17 02:41:00 --> Router Class Initialized
INFO - 2023-03-17 02:41:00 --> Output Class Initialized
INFO - 2023-03-17 02:41:00 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:00 --> Input Class Initialized
INFO - 2023-03-17 02:41:00 --> Language Class Initialized
INFO - 2023-03-17 02:41:00 --> Loader Class Initialized
INFO - 2023-03-17 02:41:00 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:00 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:00 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:00 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:00 --> Total execution time: 0.0110
INFO - 2023-03-17 02:41:18 --> Config Class Initialized
INFO - 2023-03-17 02:41:18 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:18 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:18 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:18 --> URI Class Initialized
INFO - 2023-03-17 02:41:18 --> Router Class Initialized
INFO - 2023-03-17 02:41:18 --> Output Class Initialized
INFO - 2023-03-17 02:41:18 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:18 --> Input Class Initialized
INFO - 2023-03-17 02:41:18 --> Language Class Initialized
INFO - 2023-03-17 02:41:18 --> Loader Class Initialized
INFO - 2023-03-17 02:41:18 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:18 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:18 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:18 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:18 --> Model "Login_model" initialized
INFO - 2023-03-17 02:41:18 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:18 --> Total execution time: 0.1475
INFO - 2023-03-17 02:41:18 --> Config Class Initialized
INFO - 2023-03-17 02:41:18 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:18 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:18 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:18 --> URI Class Initialized
INFO - 2023-03-17 02:41:18 --> Router Class Initialized
INFO - 2023-03-17 02:41:18 --> Output Class Initialized
INFO - 2023-03-17 02:41:18 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:18 --> Input Class Initialized
INFO - 2023-03-17 02:41:18 --> Language Class Initialized
INFO - 2023-03-17 02:41:18 --> Loader Class Initialized
INFO - 2023-03-17 02:41:18 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:18 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:18 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:18 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:18 --> Model "Login_model" initialized
INFO - 2023-03-17 02:41:18 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:18 --> Total execution time: 0.0700
INFO - 2023-03-17 02:41:21 --> Config Class Initialized
INFO - 2023-03-17 02:41:21 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:21 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:21 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:21 --> URI Class Initialized
INFO - 2023-03-17 02:41:21 --> Router Class Initialized
INFO - 2023-03-17 02:41:21 --> Output Class Initialized
INFO - 2023-03-17 02:41:21 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:21 --> Input Class Initialized
INFO - 2023-03-17 02:41:21 --> Language Class Initialized
INFO - 2023-03-17 02:41:21 --> Loader Class Initialized
INFO - 2023-03-17 02:41:21 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:21 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:21 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:21 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:21 --> Model "Login_model" initialized
INFO - 2023-03-17 02:41:21 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:21 --> Total execution time: 0.0896
INFO - 2023-03-17 02:41:25 --> Config Class Initialized
INFO - 2023-03-17 02:41:25 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:25 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:25 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:25 --> URI Class Initialized
INFO - 2023-03-17 02:41:25 --> Router Class Initialized
INFO - 2023-03-17 02:41:25 --> Output Class Initialized
INFO - 2023-03-17 02:41:25 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:25 --> Input Class Initialized
INFO - 2023-03-17 02:41:25 --> Language Class Initialized
INFO - 2023-03-17 02:41:25 --> Loader Class Initialized
INFO - 2023-03-17 02:41:25 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:25 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:25 --> Total execution time: 0.0035
INFO - 2023-03-17 02:41:25 --> Config Class Initialized
INFO - 2023-03-17 02:41:25 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:25 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:25 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:25 --> URI Class Initialized
INFO - 2023-03-17 02:41:25 --> Router Class Initialized
INFO - 2023-03-17 02:41:25 --> Output Class Initialized
INFO - 2023-03-17 02:41:25 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:25 --> Input Class Initialized
INFO - 2023-03-17 02:41:25 --> Language Class Initialized
INFO - 2023-03-17 02:41:25 --> Loader Class Initialized
INFO - 2023-03-17 02:41:25 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:25 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:25 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:25 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:25 --> Total execution time: 0.0101
INFO - 2023-03-17 02:41:25 --> Config Class Initialized
INFO - 2023-03-17 02:41:25 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:25 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:25 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:25 --> URI Class Initialized
INFO - 2023-03-17 02:41:25 --> Router Class Initialized
INFO - 2023-03-17 02:41:25 --> Output Class Initialized
INFO - 2023-03-17 02:41:25 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:25 --> Input Class Initialized
INFO - 2023-03-17 02:41:25 --> Language Class Initialized
INFO - 2023-03-17 02:41:25 --> Loader Class Initialized
INFO - 2023-03-17 02:41:25 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:25 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:25 --> Total execution time: 0.0443
INFO - 2023-03-17 02:41:25 --> Config Class Initialized
INFO - 2023-03-17 02:41:25 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:25 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:25 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:25 --> URI Class Initialized
INFO - 2023-03-17 02:41:25 --> Router Class Initialized
INFO - 2023-03-17 02:41:25 --> Output Class Initialized
INFO - 2023-03-17 02:41:25 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:25 --> Input Class Initialized
INFO - 2023-03-17 02:41:25 --> Language Class Initialized
INFO - 2023-03-17 02:41:25 --> Loader Class Initialized
INFO - 2023-03-17 02:41:25 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:25 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:25 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:25 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:25 --> Total execution time: 0.0107
INFO - 2023-03-17 02:41:31 --> Config Class Initialized
INFO - 2023-03-17 02:41:31 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:31 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:31 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:31 --> URI Class Initialized
INFO - 2023-03-17 02:41:31 --> Router Class Initialized
INFO - 2023-03-17 02:41:31 --> Output Class Initialized
INFO - 2023-03-17 02:41:31 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:31 --> Input Class Initialized
INFO - 2023-03-17 02:41:31 --> Language Class Initialized
INFO - 2023-03-17 02:41:31 --> Loader Class Initialized
INFO - 2023-03-17 02:41:31 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:31 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:31 --> Total execution time: 0.0035
INFO - 2023-03-17 02:41:31 --> Config Class Initialized
INFO - 2023-03-17 02:41:31 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:31 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:31 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:31 --> URI Class Initialized
INFO - 2023-03-17 02:41:31 --> Router Class Initialized
INFO - 2023-03-17 02:41:31 --> Output Class Initialized
INFO - 2023-03-17 02:41:31 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:31 --> Input Class Initialized
INFO - 2023-03-17 02:41:31 --> Language Class Initialized
INFO - 2023-03-17 02:41:31 --> Loader Class Initialized
INFO - 2023-03-17 02:41:31 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:31 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:31 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:31 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:31 --> Total execution time: 0.0120
INFO - 2023-03-17 02:41:33 --> Config Class Initialized
INFO - 2023-03-17 02:41:33 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:33 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:33 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:33 --> URI Class Initialized
INFO - 2023-03-17 02:41:33 --> Router Class Initialized
INFO - 2023-03-17 02:41:33 --> Output Class Initialized
INFO - 2023-03-17 02:41:33 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:33 --> Input Class Initialized
INFO - 2023-03-17 02:41:33 --> Language Class Initialized
INFO - 2023-03-17 02:41:33 --> Loader Class Initialized
INFO - 2023-03-17 02:41:33 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:33 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:33 --> Total execution time: 0.0040
INFO - 2023-03-17 02:41:33 --> Config Class Initialized
INFO - 2023-03-17 02:41:33 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:33 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:33 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:33 --> URI Class Initialized
INFO - 2023-03-17 02:41:33 --> Router Class Initialized
INFO - 2023-03-17 02:41:33 --> Output Class Initialized
INFO - 2023-03-17 02:41:33 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:33 --> Input Class Initialized
INFO - 2023-03-17 02:41:33 --> Language Class Initialized
INFO - 2023-03-17 02:41:33 --> Loader Class Initialized
INFO - 2023-03-17 02:41:33 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:33 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:33 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:33 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:33 --> Total execution time: 0.0279
INFO - 2023-03-17 02:41:40 --> Config Class Initialized
INFO - 2023-03-17 02:41:40 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:40 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:40 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:40 --> URI Class Initialized
INFO - 2023-03-17 02:41:40 --> Router Class Initialized
INFO - 2023-03-17 02:41:40 --> Output Class Initialized
INFO - 2023-03-17 02:41:40 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:40 --> Input Class Initialized
INFO - 2023-03-17 02:41:40 --> Language Class Initialized
INFO - 2023-03-17 02:41:40 --> Loader Class Initialized
INFO - 2023-03-17 02:41:40 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:40 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:40 --> Total execution time: 0.0043
INFO - 2023-03-17 02:41:40 --> Config Class Initialized
INFO - 2023-03-17 02:41:40 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:40 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:40 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:40 --> URI Class Initialized
INFO - 2023-03-17 02:41:40 --> Router Class Initialized
INFO - 2023-03-17 02:41:40 --> Output Class Initialized
INFO - 2023-03-17 02:41:40 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:40 --> Input Class Initialized
INFO - 2023-03-17 02:41:40 --> Language Class Initialized
INFO - 2023-03-17 02:41:40 --> Loader Class Initialized
INFO - 2023-03-17 02:41:40 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:40 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:40 --> Model "Login_model" initialized
INFO - 2023-03-17 02:41:40 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:40 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:40 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:40 --> Total execution time: 0.0322
INFO - 2023-03-17 02:41:40 --> Config Class Initialized
INFO - 2023-03-17 02:41:40 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:40 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:40 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:40 --> URI Class Initialized
INFO - 2023-03-17 02:41:40 --> Router Class Initialized
INFO - 2023-03-17 02:41:40 --> Output Class Initialized
INFO - 2023-03-17 02:41:40 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:40 --> Input Class Initialized
INFO - 2023-03-17 02:41:40 --> Language Class Initialized
INFO - 2023-03-17 02:41:40 --> Loader Class Initialized
INFO - 2023-03-17 02:41:40 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:40 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:40 --> Total execution time: 0.0043
INFO - 2023-03-17 02:41:40 --> Config Class Initialized
INFO - 2023-03-17 02:41:40 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:40 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:40 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:40 --> URI Class Initialized
INFO - 2023-03-17 02:41:40 --> Router Class Initialized
INFO - 2023-03-17 02:41:40 --> Output Class Initialized
INFO - 2023-03-17 02:41:40 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:40 --> Input Class Initialized
INFO - 2023-03-17 02:41:40 --> Language Class Initialized
INFO - 2023-03-17 02:41:40 --> Loader Class Initialized
INFO - 2023-03-17 02:41:40 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:40 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:40 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:40 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:40 --> Total execution time: 0.0142
INFO - 2023-03-17 02:41:47 --> Config Class Initialized
INFO - 2023-03-17 02:41:47 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:47 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:47 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:47 --> URI Class Initialized
INFO - 2023-03-17 02:41:47 --> Router Class Initialized
INFO - 2023-03-17 02:41:47 --> Output Class Initialized
INFO - 2023-03-17 02:41:47 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:47 --> Input Class Initialized
INFO - 2023-03-17 02:41:47 --> Language Class Initialized
INFO - 2023-03-17 02:41:47 --> Loader Class Initialized
INFO - 2023-03-17 02:41:47 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:47 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:47 --> Total execution time: 0.0038
INFO - 2023-03-17 02:41:47 --> Config Class Initialized
INFO - 2023-03-17 02:41:47 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:47 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:47 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:47 --> URI Class Initialized
INFO - 2023-03-17 02:41:47 --> Router Class Initialized
INFO - 2023-03-17 02:41:47 --> Output Class Initialized
INFO - 2023-03-17 02:41:47 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:47 --> Input Class Initialized
INFO - 2023-03-17 02:41:47 --> Language Class Initialized
INFO - 2023-03-17 02:41:47 --> Loader Class Initialized
INFO - 2023-03-17 02:41:47 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:47 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:47 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:47 --> Total execution time: 0.0134
INFO - 2023-03-17 02:41:49 --> Config Class Initialized
INFO - 2023-03-17 02:41:49 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:49 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:49 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:49 --> URI Class Initialized
INFO - 2023-03-17 02:41:49 --> Router Class Initialized
INFO - 2023-03-17 02:41:49 --> Output Class Initialized
INFO - 2023-03-17 02:41:49 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:49 --> Input Class Initialized
INFO - 2023-03-17 02:41:49 --> Language Class Initialized
INFO - 2023-03-17 02:41:49 --> Loader Class Initialized
INFO - 2023-03-17 02:41:49 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:49 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:49 --> Total execution time: 0.0039
INFO - 2023-03-17 02:41:49 --> Config Class Initialized
INFO - 2023-03-17 02:41:49 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:49 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:49 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:49 --> URI Class Initialized
INFO - 2023-03-17 02:41:49 --> Router Class Initialized
INFO - 2023-03-17 02:41:49 --> Output Class Initialized
INFO - 2023-03-17 02:41:49 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:49 --> Input Class Initialized
INFO - 2023-03-17 02:41:49 --> Language Class Initialized
INFO - 2023-03-17 02:41:49 --> Loader Class Initialized
INFO - 2023-03-17 02:41:49 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:49 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:49 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:49 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:49 --> Total execution time: 0.0121
INFO - 2023-03-17 02:41:54 --> Config Class Initialized
INFO - 2023-03-17 02:41:54 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:54 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:54 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:54 --> URI Class Initialized
INFO - 2023-03-17 02:41:54 --> Router Class Initialized
INFO - 2023-03-17 02:41:54 --> Output Class Initialized
INFO - 2023-03-17 02:41:54 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:54 --> Input Class Initialized
INFO - 2023-03-17 02:41:54 --> Language Class Initialized
INFO - 2023-03-17 02:41:54 --> Loader Class Initialized
INFO - 2023-03-17 02:41:54 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:54 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:54 --> Total execution time: 0.0037
INFO - 2023-03-17 02:41:54 --> Config Class Initialized
INFO - 2023-03-17 02:41:54 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:54 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:54 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:54 --> URI Class Initialized
INFO - 2023-03-17 02:41:54 --> Router Class Initialized
INFO - 2023-03-17 02:41:54 --> Output Class Initialized
INFO - 2023-03-17 02:41:54 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:54 --> Input Class Initialized
INFO - 2023-03-17 02:41:54 --> Language Class Initialized
INFO - 2023-03-17 02:41:54 --> Loader Class Initialized
INFO - 2023-03-17 02:41:54 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:54 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:54 --> Model "Login_model" initialized
INFO - 2023-03-17 02:41:54 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:54 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:54 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:54 --> Total execution time: 0.0299
INFO - 2023-03-17 02:41:54 --> Config Class Initialized
INFO - 2023-03-17 02:41:54 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:54 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:54 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:54 --> URI Class Initialized
INFO - 2023-03-17 02:41:54 --> Router Class Initialized
INFO - 2023-03-17 02:41:54 --> Output Class Initialized
INFO - 2023-03-17 02:41:54 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:54 --> Input Class Initialized
INFO - 2023-03-17 02:41:54 --> Language Class Initialized
INFO - 2023-03-17 02:41:54 --> Loader Class Initialized
INFO - 2023-03-17 02:41:54 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:54 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:54 --> Total execution time: 0.0039
INFO - 2023-03-17 02:41:54 --> Config Class Initialized
INFO - 2023-03-17 02:41:54 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:54 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:54 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:54 --> URI Class Initialized
INFO - 2023-03-17 02:41:54 --> Router Class Initialized
INFO - 2023-03-17 02:41:54 --> Output Class Initialized
INFO - 2023-03-17 02:41:54 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:54 --> Input Class Initialized
INFO - 2023-03-17 02:41:54 --> Language Class Initialized
INFO - 2023-03-17 02:41:54 --> Loader Class Initialized
INFO - 2023-03-17 02:41:54 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:54 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:54 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:54 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:54 --> Total execution time: 0.0129
INFO - 2023-03-17 02:41:59 --> Config Class Initialized
INFO - 2023-03-17 02:41:59 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:41:59 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:41:59 --> Utf8 Class Initialized
INFO - 2023-03-17 02:41:59 --> URI Class Initialized
INFO - 2023-03-17 02:41:59 --> Router Class Initialized
INFO - 2023-03-17 02:41:59 --> Output Class Initialized
INFO - 2023-03-17 02:41:59 --> Security Class Initialized
DEBUG - 2023-03-17 02:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:41:59 --> Input Class Initialized
INFO - 2023-03-17 02:41:59 --> Language Class Initialized
INFO - 2023-03-17 02:41:59 --> Loader Class Initialized
INFO - 2023-03-17 02:41:59 --> Controller Class Initialized
DEBUG - 2023-03-17 02:41:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:41:59 --> Database Driver Class Initialized
INFO - 2023-03-17 02:41:59 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:41:59 --> Final output sent to browser
DEBUG - 2023-03-17 02:41:59 --> Total execution time: 0.0187
INFO - 2023-03-17 02:42:04 --> Config Class Initialized
INFO - 2023-03-17 02:42:04 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:04 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:04 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:04 --> URI Class Initialized
INFO - 2023-03-17 02:42:04 --> Router Class Initialized
INFO - 2023-03-17 02:42:04 --> Output Class Initialized
INFO - 2023-03-17 02:42:04 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:04 --> Input Class Initialized
INFO - 2023-03-17 02:42:04 --> Language Class Initialized
INFO - 2023-03-17 02:42:04 --> Loader Class Initialized
INFO - 2023-03-17 02:42:04 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:04 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:04 --> Total execution time: 0.0041
INFO - 2023-03-17 02:42:04 --> Config Class Initialized
INFO - 2023-03-17 02:42:04 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:04 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:04 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:04 --> URI Class Initialized
INFO - 2023-03-17 02:42:04 --> Router Class Initialized
INFO - 2023-03-17 02:42:04 --> Output Class Initialized
INFO - 2023-03-17 02:42:04 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:04 --> Input Class Initialized
INFO - 2023-03-17 02:42:04 --> Language Class Initialized
INFO - 2023-03-17 02:42:04 --> Loader Class Initialized
INFO - 2023-03-17 02:42:04 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:04 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:04 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:04 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:04 --> Total execution time: 0.0145
INFO - 2023-03-17 02:42:09 --> Config Class Initialized
INFO - 2023-03-17 02:42:09 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:09 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:09 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:09 --> URI Class Initialized
INFO - 2023-03-17 02:42:09 --> Router Class Initialized
INFO - 2023-03-17 02:42:09 --> Output Class Initialized
INFO - 2023-03-17 02:42:09 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:09 --> Input Class Initialized
INFO - 2023-03-17 02:42:09 --> Language Class Initialized
INFO - 2023-03-17 02:42:09 --> Loader Class Initialized
INFO - 2023-03-17 02:42:09 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:09 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:09 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:09 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:09 --> Total execution time: 0.0166
INFO - 2023-03-17 02:42:09 --> Config Class Initialized
INFO - 2023-03-17 02:42:09 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:09 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:09 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:09 --> URI Class Initialized
INFO - 2023-03-17 02:42:09 --> Router Class Initialized
INFO - 2023-03-17 02:42:09 --> Output Class Initialized
INFO - 2023-03-17 02:42:09 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:09 --> Input Class Initialized
INFO - 2023-03-17 02:42:09 --> Language Class Initialized
INFO - 2023-03-17 02:42:09 --> Loader Class Initialized
INFO - 2023-03-17 02:42:09 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:09 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:09 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:09 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:09 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:09 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:09 --> Total execution time: 0.0399
INFO - 2023-03-17 02:42:09 --> Config Class Initialized
INFO - 2023-03-17 02:42:09 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:09 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:09 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:09 --> URI Class Initialized
INFO - 2023-03-17 02:42:09 --> Router Class Initialized
INFO - 2023-03-17 02:42:09 --> Output Class Initialized
INFO - 2023-03-17 02:42:09 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:09 --> Input Class Initialized
INFO - 2023-03-17 02:42:09 --> Language Class Initialized
INFO - 2023-03-17 02:42:09 --> Loader Class Initialized
INFO - 2023-03-17 02:42:09 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:09 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:09 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:09 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:09 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:09 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:09 --> Total execution time: 0.0387
INFO - 2023-03-17 02:42:37 --> Config Class Initialized
INFO - 2023-03-17 02:42:37 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:37 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:37 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:37 --> URI Class Initialized
INFO - 2023-03-17 02:42:37 --> Router Class Initialized
INFO - 2023-03-17 02:42:37 --> Output Class Initialized
INFO - 2023-03-17 02:42:37 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:37 --> Input Class Initialized
INFO - 2023-03-17 02:42:37 --> Language Class Initialized
INFO - 2023-03-17 02:42:37 --> Loader Class Initialized
INFO - 2023-03-17 02:42:37 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:37 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:37 --> Total execution time: 0.0208
INFO - 2023-03-17 02:42:37 --> Config Class Initialized
INFO - 2023-03-17 02:42:37 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:37 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:37 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:37 --> URI Class Initialized
INFO - 2023-03-17 02:42:37 --> Router Class Initialized
INFO - 2023-03-17 02:42:37 --> Output Class Initialized
INFO - 2023-03-17 02:42:37 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:37 --> Input Class Initialized
INFO - 2023-03-17 02:42:37 --> Language Class Initialized
INFO - 2023-03-17 02:42:37 --> Loader Class Initialized
INFO - 2023-03-17 02:42:37 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:37 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:37 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:37 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:37 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:37 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:37 --> Total execution time: 0.0272
INFO - 2023-03-17 02:42:37 --> Config Class Initialized
INFO - 2023-03-17 02:42:37 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:37 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:37 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:37 --> URI Class Initialized
INFO - 2023-03-17 02:42:37 --> Router Class Initialized
INFO - 2023-03-17 02:42:37 --> Output Class Initialized
INFO - 2023-03-17 02:42:37 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:37 --> Input Class Initialized
INFO - 2023-03-17 02:42:37 --> Language Class Initialized
INFO - 2023-03-17 02:42:37 --> Loader Class Initialized
INFO - 2023-03-17 02:42:37 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:37 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:37 --> Total execution time: 0.0017
INFO - 2023-03-17 02:42:37 --> Config Class Initialized
INFO - 2023-03-17 02:42:37 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:37 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:37 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:37 --> URI Class Initialized
INFO - 2023-03-17 02:42:37 --> Router Class Initialized
INFO - 2023-03-17 02:42:37 --> Output Class Initialized
INFO - 2023-03-17 02:42:37 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:37 --> Input Class Initialized
INFO - 2023-03-17 02:42:37 --> Language Class Initialized
INFO - 2023-03-17 02:42:37 --> Loader Class Initialized
INFO - 2023-03-17 02:42:37 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:37 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:37 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:38 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:38 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:38 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:38 --> Total execution time: 0.0643
INFO - 2023-03-17 02:42:39 --> Config Class Initialized
INFO - 2023-03-17 02:42:39 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:39 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:39 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:39 --> URI Class Initialized
INFO - 2023-03-17 02:42:39 --> Router Class Initialized
INFO - 2023-03-17 02:42:39 --> Output Class Initialized
INFO - 2023-03-17 02:42:39 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:39 --> Input Class Initialized
INFO - 2023-03-17 02:42:39 --> Language Class Initialized
INFO - 2023-03-17 02:42:39 --> Loader Class Initialized
INFO - 2023-03-17 02:42:39 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:39 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:39 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:39 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:39 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:39 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:39 --> Total execution time: 0.0538
INFO - 2023-03-17 02:42:39 --> Config Class Initialized
INFO - 2023-03-17 02:42:39 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:39 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:39 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:39 --> URI Class Initialized
INFO - 2023-03-17 02:42:39 --> Router Class Initialized
INFO - 2023-03-17 02:42:39 --> Output Class Initialized
INFO - 2023-03-17 02:42:39 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:39 --> Input Class Initialized
INFO - 2023-03-17 02:42:39 --> Language Class Initialized
INFO - 2023-03-17 02:42:39 --> Loader Class Initialized
INFO - 2023-03-17 02:42:39 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:39 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:39 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:39 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:39 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:39 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:39 --> Total execution time: 0.0384
INFO - 2023-03-17 02:42:44 --> Config Class Initialized
INFO - 2023-03-17 02:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:44 --> URI Class Initialized
INFO - 2023-03-17 02:42:44 --> Router Class Initialized
INFO - 2023-03-17 02:42:44 --> Output Class Initialized
INFO - 2023-03-17 02:42:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:44 --> Input Class Initialized
INFO - 2023-03-17 02:42:44 --> Language Class Initialized
INFO - 2023-03-17 02:42:44 --> Loader Class Initialized
INFO - 2023-03-17 02:42:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:44 --> Total execution time: 0.0036
INFO - 2023-03-17 02:42:44 --> Config Class Initialized
INFO - 2023-03-17 02:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:44 --> URI Class Initialized
INFO - 2023-03-17 02:42:44 --> Router Class Initialized
INFO - 2023-03-17 02:42:44 --> Output Class Initialized
INFO - 2023-03-17 02:42:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:44 --> Input Class Initialized
INFO - 2023-03-17 02:42:44 --> Language Class Initialized
INFO - 2023-03-17 02:42:44 --> Loader Class Initialized
INFO - 2023-03-17 02:42:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:44 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:44 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:44 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:44 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:44 --> Total execution time: 0.0227
INFO - 2023-03-17 02:42:44 --> Config Class Initialized
INFO - 2023-03-17 02:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:44 --> URI Class Initialized
INFO - 2023-03-17 02:42:44 --> Router Class Initialized
INFO - 2023-03-17 02:42:44 --> Output Class Initialized
INFO - 2023-03-17 02:42:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:44 --> Input Class Initialized
INFO - 2023-03-17 02:42:44 --> Language Class Initialized
INFO - 2023-03-17 02:42:44 --> Loader Class Initialized
INFO - 2023-03-17 02:42:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:44 --> Total execution time: 0.0017
INFO - 2023-03-17 02:42:44 --> Config Class Initialized
INFO - 2023-03-17 02:42:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:44 --> URI Class Initialized
INFO - 2023-03-17 02:42:44 --> Router Class Initialized
INFO - 2023-03-17 02:42:44 --> Output Class Initialized
INFO - 2023-03-17 02:42:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:44 --> Input Class Initialized
INFO - 2023-03-17 02:42:44 --> Language Class Initialized
INFO - 2023-03-17 02:42:44 --> Loader Class Initialized
INFO - 2023-03-17 02:42:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:44 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:44 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:44 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:44 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:44 --> Total execution time: 0.0228
INFO - 2023-03-17 02:42:45 --> Config Class Initialized
INFO - 2023-03-17 02:42:45 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:45 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:45 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:45 --> URI Class Initialized
INFO - 2023-03-17 02:42:45 --> Router Class Initialized
INFO - 2023-03-17 02:42:45 --> Output Class Initialized
INFO - 2023-03-17 02:42:45 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:45 --> Input Class Initialized
INFO - 2023-03-17 02:42:45 --> Language Class Initialized
INFO - 2023-03-17 02:42:45 --> Loader Class Initialized
INFO - 2023-03-17 02:42:45 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:45 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:45 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:45 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:45 --> Total execution time: 0.0181
INFO - 2023-03-17 02:42:45 --> Config Class Initialized
INFO - 2023-03-17 02:42:45 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:45 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:45 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:45 --> URI Class Initialized
INFO - 2023-03-17 02:42:45 --> Router Class Initialized
INFO - 2023-03-17 02:42:45 --> Output Class Initialized
INFO - 2023-03-17 02:42:45 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:45 --> Input Class Initialized
INFO - 2023-03-17 02:42:45 --> Language Class Initialized
INFO - 2023-03-17 02:42:45 --> Loader Class Initialized
INFO - 2023-03-17 02:42:45 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:45 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:46 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:46 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:46 --> Total execution time: 0.0518
INFO - 2023-03-17 02:42:47 --> Config Class Initialized
INFO - 2023-03-17 02:42:47 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:47 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:47 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:47 --> URI Class Initialized
INFO - 2023-03-17 02:42:47 --> Router Class Initialized
INFO - 2023-03-17 02:42:47 --> Output Class Initialized
INFO - 2023-03-17 02:42:47 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:47 --> Input Class Initialized
INFO - 2023-03-17 02:42:47 --> Language Class Initialized
INFO - 2023-03-17 02:42:47 --> Loader Class Initialized
INFO - 2023-03-17 02:42:47 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:47 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:47 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:47 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:47 --> Total execution time: 0.0259
INFO - 2023-03-17 02:42:47 --> Config Class Initialized
INFO - 2023-03-17 02:42:47 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:47 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:47 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:47 --> URI Class Initialized
INFO - 2023-03-17 02:42:47 --> Router Class Initialized
INFO - 2023-03-17 02:42:47 --> Output Class Initialized
INFO - 2023-03-17 02:42:47 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:47 --> Input Class Initialized
INFO - 2023-03-17 02:42:47 --> Language Class Initialized
INFO - 2023-03-17 02:42:47 --> Loader Class Initialized
INFO - 2023-03-17 02:42:47 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:47 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:47 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:47 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:47 --> Total execution time: 0.0309
INFO - 2023-03-17 02:42:47 --> Config Class Initialized
INFO - 2023-03-17 02:42:47 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:47 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:47 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:47 --> URI Class Initialized
INFO - 2023-03-17 02:42:47 --> Router Class Initialized
INFO - 2023-03-17 02:42:47 --> Output Class Initialized
INFO - 2023-03-17 02:42:47 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:47 --> Input Class Initialized
INFO - 2023-03-17 02:42:47 --> Language Class Initialized
INFO - 2023-03-17 02:42:47 --> Loader Class Initialized
INFO - 2023-03-17 02:42:47 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:47 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:47 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:47 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:47 --> Total execution time: 0.0802
INFO - 2023-03-17 02:42:47 --> Config Class Initialized
INFO - 2023-03-17 02:42:47 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:47 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:47 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:47 --> URI Class Initialized
INFO - 2023-03-17 02:42:47 --> Router Class Initialized
INFO - 2023-03-17 02:42:47 --> Output Class Initialized
INFO - 2023-03-17 02:42:47 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:47 --> Input Class Initialized
INFO - 2023-03-17 02:42:47 --> Language Class Initialized
INFO - 2023-03-17 02:42:47 --> Loader Class Initialized
INFO - 2023-03-17 02:42:47 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:47 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:47 --> Model "Login_model" initialized
INFO - 2023-03-17 02:42:48 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:48 --> Total execution time: 0.0427
INFO - 2023-03-17 02:42:49 --> Config Class Initialized
INFO - 2023-03-17 02:42:49 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:49 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:49 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:49 --> URI Class Initialized
INFO - 2023-03-17 02:42:49 --> Router Class Initialized
INFO - 2023-03-17 02:42:49 --> Output Class Initialized
INFO - 2023-03-17 02:42:49 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:49 --> Input Class Initialized
INFO - 2023-03-17 02:42:49 --> Language Class Initialized
INFO - 2023-03-17 02:42:49 --> Loader Class Initialized
INFO - 2023-03-17 02:42:49 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:49 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:49 --> Total execution time: 0.0039
INFO - 2023-03-17 02:42:49 --> Config Class Initialized
INFO - 2023-03-17 02:42:49 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:49 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:49 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:49 --> URI Class Initialized
INFO - 2023-03-17 02:42:49 --> Router Class Initialized
INFO - 2023-03-17 02:42:49 --> Output Class Initialized
INFO - 2023-03-17 02:42:49 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:49 --> Input Class Initialized
INFO - 2023-03-17 02:42:49 --> Language Class Initialized
INFO - 2023-03-17 02:42:49 --> Loader Class Initialized
INFO - 2023-03-17 02:42:49 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:49 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:49 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:49 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:49 --> Total execution time: 0.0137
INFO - 2023-03-17 02:42:49 --> Config Class Initialized
INFO - 2023-03-17 02:42:49 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:49 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:49 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:49 --> URI Class Initialized
INFO - 2023-03-17 02:42:49 --> Router Class Initialized
INFO - 2023-03-17 02:42:49 --> Output Class Initialized
INFO - 2023-03-17 02:42:49 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:49 --> Input Class Initialized
INFO - 2023-03-17 02:42:49 --> Language Class Initialized
INFO - 2023-03-17 02:42:49 --> Loader Class Initialized
INFO - 2023-03-17 02:42:49 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:49 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:49 --> Total execution time: 0.0411
INFO - 2023-03-17 02:42:49 --> Config Class Initialized
INFO - 2023-03-17 02:42:49 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:42:49 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:42:49 --> Utf8 Class Initialized
INFO - 2023-03-17 02:42:49 --> URI Class Initialized
INFO - 2023-03-17 02:42:49 --> Router Class Initialized
INFO - 2023-03-17 02:42:49 --> Output Class Initialized
INFO - 2023-03-17 02:42:49 --> Security Class Initialized
DEBUG - 2023-03-17 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:42:49 --> Input Class Initialized
INFO - 2023-03-17 02:42:49 --> Language Class Initialized
INFO - 2023-03-17 02:42:49 --> Loader Class Initialized
INFO - 2023-03-17 02:42:49 --> Controller Class Initialized
DEBUG - 2023-03-17 02:42:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:42:49 --> Database Driver Class Initialized
INFO - 2023-03-17 02:42:49 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:42:49 --> Final output sent to browser
DEBUG - 2023-03-17 02:42:49 --> Total execution time: 0.0150
INFO - 2023-03-17 02:43:04 --> Config Class Initialized
INFO - 2023-03-17 02:43:04 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:04 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:04 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:04 --> URI Class Initialized
INFO - 2023-03-17 02:43:04 --> Router Class Initialized
INFO - 2023-03-17 02:43:04 --> Output Class Initialized
INFO - 2023-03-17 02:43:04 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:04 --> Input Class Initialized
INFO - 2023-03-17 02:43:04 --> Language Class Initialized
INFO - 2023-03-17 02:43:04 --> Loader Class Initialized
INFO - 2023-03-17 02:43:04 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:04 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:04 --> Total execution time: 0.0039
INFO - 2023-03-17 02:43:04 --> Config Class Initialized
INFO - 2023-03-17 02:43:04 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:04 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:04 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:04 --> URI Class Initialized
INFO - 2023-03-17 02:43:04 --> Router Class Initialized
INFO - 2023-03-17 02:43:04 --> Output Class Initialized
INFO - 2023-03-17 02:43:04 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:04 --> Input Class Initialized
INFO - 2023-03-17 02:43:04 --> Language Class Initialized
INFO - 2023-03-17 02:43:04 --> Loader Class Initialized
INFO - 2023-03-17 02:43:04 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:04 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:04 --> Model "Login_model" initialized
INFO - 2023-03-17 02:43:04 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:04 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:04 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:04 --> Total execution time: 0.0542
INFO - 2023-03-17 02:43:04 --> Config Class Initialized
INFO - 2023-03-17 02:43:04 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:04 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:04 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:04 --> URI Class Initialized
INFO - 2023-03-17 02:43:04 --> Router Class Initialized
INFO - 2023-03-17 02:43:04 --> Output Class Initialized
INFO - 2023-03-17 02:43:04 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:04 --> Input Class Initialized
INFO - 2023-03-17 02:43:04 --> Language Class Initialized
INFO - 2023-03-17 02:43:04 --> Loader Class Initialized
INFO - 2023-03-17 02:43:04 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:04 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:04 --> Total execution time: 0.0043
INFO - 2023-03-17 02:43:04 --> Config Class Initialized
INFO - 2023-03-17 02:43:04 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:04 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:04 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:04 --> URI Class Initialized
INFO - 2023-03-17 02:43:04 --> Router Class Initialized
INFO - 2023-03-17 02:43:04 --> Output Class Initialized
INFO - 2023-03-17 02:43:04 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:04 --> Input Class Initialized
INFO - 2023-03-17 02:43:04 --> Language Class Initialized
INFO - 2023-03-17 02:43:04 --> Loader Class Initialized
INFO - 2023-03-17 02:43:04 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:04 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:04 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:05 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:05 --> Total execution time: 0.1587
INFO - 2023-03-17 02:43:09 --> Config Class Initialized
INFO - 2023-03-17 02:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:09 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:09 --> URI Class Initialized
INFO - 2023-03-17 02:43:09 --> Router Class Initialized
INFO - 2023-03-17 02:43:09 --> Output Class Initialized
INFO - 2023-03-17 02:43:09 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:09 --> Input Class Initialized
INFO - 2023-03-17 02:43:09 --> Language Class Initialized
INFO - 2023-03-17 02:43:09 --> Loader Class Initialized
INFO - 2023-03-17 02:43:09 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:09 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:09 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:09 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:09 --> Total execution time: 0.0184
INFO - 2023-03-17 02:43:14 --> Config Class Initialized
INFO - 2023-03-17 02:43:14 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:14 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:14 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:14 --> URI Class Initialized
INFO - 2023-03-17 02:43:14 --> Router Class Initialized
INFO - 2023-03-17 02:43:14 --> Output Class Initialized
INFO - 2023-03-17 02:43:14 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:14 --> Input Class Initialized
INFO - 2023-03-17 02:43:14 --> Language Class Initialized
INFO - 2023-03-17 02:43:14 --> Loader Class Initialized
INFO - 2023-03-17 02:43:14 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:14 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:14 --> Total execution time: 0.0042
INFO - 2023-03-17 02:43:14 --> Config Class Initialized
INFO - 2023-03-17 02:43:14 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:14 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:14 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:14 --> URI Class Initialized
INFO - 2023-03-17 02:43:14 --> Router Class Initialized
INFO - 2023-03-17 02:43:14 --> Output Class Initialized
INFO - 2023-03-17 02:43:14 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:14 --> Input Class Initialized
INFO - 2023-03-17 02:43:14 --> Language Class Initialized
INFO - 2023-03-17 02:43:14 --> Loader Class Initialized
INFO - 2023-03-17 02:43:14 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:14 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:14 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:14 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:14 --> Total execution time: 0.0136
INFO - 2023-03-17 02:43:19 --> Config Class Initialized
INFO - 2023-03-17 02:43:19 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:19 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:19 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:19 --> URI Class Initialized
INFO - 2023-03-17 02:43:19 --> Router Class Initialized
INFO - 2023-03-17 02:43:19 --> Output Class Initialized
INFO - 2023-03-17 02:43:19 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:19 --> Input Class Initialized
INFO - 2023-03-17 02:43:19 --> Language Class Initialized
INFO - 2023-03-17 02:43:19 --> Loader Class Initialized
INFO - 2023-03-17 02:43:19 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:19 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:19 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:19 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:19 --> Total execution time: 0.0172
INFO - 2023-03-17 02:43:24 --> Config Class Initialized
INFO - 2023-03-17 02:43:24 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:24 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:24 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:24 --> URI Class Initialized
INFO - 2023-03-17 02:43:24 --> Router Class Initialized
INFO - 2023-03-17 02:43:24 --> Output Class Initialized
INFO - 2023-03-17 02:43:24 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:24 --> Input Class Initialized
INFO - 2023-03-17 02:43:24 --> Language Class Initialized
INFO - 2023-03-17 02:43:24 --> Loader Class Initialized
INFO - 2023-03-17 02:43:24 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:24 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:24 --> Total execution time: 0.0040
INFO - 2023-03-17 02:43:24 --> Config Class Initialized
INFO - 2023-03-17 02:43:24 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:24 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:24 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:24 --> URI Class Initialized
INFO - 2023-03-17 02:43:24 --> Router Class Initialized
INFO - 2023-03-17 02:43:24 --> Output Class Initialized
INFO - 2023-03-17 02:43:24 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:24 --> Input Class Initialized
INFO - 2023-03-17 02:43:24 --> Language Class Initialized
INFO - 2023-03-17 02:43:24 --> Loader Class Initialized
INFO - 2023-03-17 02:43:24 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:24 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:24 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:24 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:24 --> Total execution time: 0.0165
INFO - 2023-03-17 02:43:29 --> Config Class Initialized
INFO - 2023-03-17 02:43:29 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:29 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:29 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:29 --> URI Class Initialized
INFO - 2023-03-17 02:43:29 --> Router Class Initialized
INFO - 2023-03-17 02:43:29 --> Output Class Initialized
INFO - 2023-03-17 02:43:29 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:29 --> Input Class Initialized
INFO - 2023-03-17 02:43:29 --> Language Class Initialized
INFO - 2023-03-17 02:43:29 --> Loader Class Initialized
INFO - 2023-03-17 02:43:29 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:29 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:29 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:29 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:29 --> Total execution time: 0.0265
INFO - 2023-03-17 02:43:34 --> Config Class Initialized
INFO - 2023-03-17 02:43:34 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:34 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:34 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:34 --> URI Class Initialized
INFO - 2023-03-17 02:43:34 --> Router Class Initialized
INFO - 2023-03-17 02:43:34 --> Output Class Initialized
INFO - 2023-03-17 02:43:34 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:34 --> Input Class Initialized
INFO - 2023-03-17 02:43:34 --> Language Class Initialized
INFO - 2023-03-17 02:43:34 --> Loader Class Initialized
INFO - 2023-03-17 02:43:34 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:34 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:34 --> Total execution time: 0.0048
INFO - 2023-03-17 02:43:34 --> Config Class Initialized
INFO - 2023-03-17 02:43:34 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:34 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:34 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:34 --> URI Class Initialized
INFO - 2023-03-17 02:43:34 --> Router Class Initialized
INFO - 2023-03-17 02:43:34 --> Output Class Initialized
INFO - 2023-03-17 02:43:34 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:34 --> Input Class Initialized
INFO - 2023-03-17 02:43:34 --> Language Class Initialized
INFO - 2023-03-17 02:43:34 --> Loader Class Initialized
INFO - 2023-03-17 02:43:34 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:34 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:34 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:34 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:34 --> Total execution time: 0.0193
INFO - 2023-03-17 02:43:39 --> Config Class Initialized
INFO - 2023-03-17 02:43:39 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:39 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:39 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:39 --> URI Class Initialized
INFO - 2023-03-17 02:43:39 --> Router Class Initialized
INFO - 2023-03-17 02:43:39 --> Output Class Initialized
INFO - 2023-03-17 02:43:39 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:39 --> Input Class Initialized
INFO - 2023-03-17 02:43:39 --> Language Class Initialized
INFO - 2023-03-17 02:43:39 --> Loader Class Initialized
INFO - 2023-03-17 02:43:39 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:39 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:39 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:39 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:39 --> Total execution time: 0.0193
INFO - 2023-03-17 02:43:44 --> Config Class Initialized
INFO - 2023-03-17 02:43:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:44 --> URI Class Initialized
INFO - 2023-03-17 02:43:44 --> Router Class Initialized
INFO - 2023-03-17 02:43:44 --> Output Class Initialized
INFO - 2023-03-17 02:43:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:44 --> Input Class Initialized
INFO - 2023-03-17 02:43:44 --> Language Class Initialized
INFO - 2023-03-17 02:43:44 --> Loader Class Initialized
INFO - 2023-03-17 02:43:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:44 --> Total execution time: 0.0046
INFO - 2023-03-17 02:43:44 --> Config Class Initialized
INFO - 2023-03-17 02:43:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:44 --> URI Class Initialized
INFO - 2023-03-17 02:43:44 --> Router Class Initialized
INFO - 2023-03-17 02:43:44 --> Output Class Initialized
INFO - 2023-03-17 02:43:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:44 --> Input Class Initialized
INFO - 2023-03-17 02:43:44 --> Language Class Initialized
INFO - 2023-03-17 02:43:44 --> Loader Class Initialized
INFO - 2023-03-17 02:43:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:44 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:44 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:44 --> Total execution time: 0.0205
INFO - 2023-03-17 02:43:49 --> Config Class Initialized
INFO - 2023-03-17 02:43:49 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:49 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:49 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:49 --> URI Class Initialized
INFO - 2023-03-17 02:43:49 --> Router Class Initialized
INFO - 2023-03-17 02:43:49 --> Output Class Initialized
INFO - 2023-03-17 02:43:49 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:49 --> Input Class Initialized
INFO - 2023-03-17 02:43:49 --> Language Class Initialized
INFO - 2023-03-17 02:43:49 --> Loader Class Initialized
INFO - 2023-03-17 02:43:49 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:49 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:49 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:49 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:49 --> Total execution time: 0.0219
INFO - 2023-03-17 02:43:54 --> Config Class Initialized
INFO - 2023-03-17 02:43:54 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:54 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:54 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:54 --> URI Class Initialized
INFO - 2023-03-17 02:43:54 --> Router Class Initialized
INFO - 2023-03-17 02:43:54 --> Output Class Initialized
INFO - 2023-03-17 02:43:54 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:54 --> Input Class Initialized
INFO - 2023-03-17 02:43:54 --> Language Class Initialized
INFO - 2023-03-17 02:43:54 --> Loader Class Initialized
INFO - 2023-03-17 02:43:54 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:54 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:54 --> Total execution time: 0.0036
INFO - 2023-03-17 02:43:54 --> Config Class Initialized
INFO - 2023-03-17 02:43:54 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:43:54 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:43:54 --> Utf8 Class Initialized
INFO - 2023-03-17 02:43:54 --> URI Class Initialized
INFO - 2023-03-17 02:43:54 --> Router Class Initialized
INFO - 2023-03-17 02:43:54 --> Output Class Initialized
INFO - 2023-03-17 02:43:54 --> Security Class Initialized
DEBUG - 2023-03-17 02:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:43:54 --> Input Class Initialized
INFO - 2023-03-17 02:43:54 --> Language Class Initialized
INFO - 2023-03-17 02:43:54 --> Loader Class Initialized
INFO - 2023-03-17 02:43:54 --> Controller Class Initialized
DEBUG - 2023-03-17 02:43:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:43:54 --> Database Driver Class Initialized
INFO - 2023-03-17 02:43:54 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:43:54 --> Final output sent to browser
DEBUG - 2023-03-17 02:43:54 --> Total execution time: 0.0155
INFO - 2023-03-17 02:44:01 --> Config Class Initialized
INFO - 2023-03-17 02:44:01 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:01 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:01 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:01 --> URI Class Initialized
INFO - 2023-03-17 02:44:01 --> Router Class Initialized
INFO - 2023-03-17 02:44:01 --> Output Class Initialized
INFO - 2023-03-17 02:44:01 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:01 --> Input Class Initialized
INFO - 2023-03-17 02:44:01 --> Language Class Initialized
INFO - 2023-03-17 02:44:01 --> Loader Class Initialized
INFO - 2023-03-17 02:44:01 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:01 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:01 --> Total execution time: 0.0052
INFO - 2023-03-17 02:44:01 --> Config Class Initialized
INFO - 2023-03-17 02:44:01 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:01 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:01 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:01 --> URI Class Initialized
INFO - 2023-03-17 02:44:01 --> Router Class Initialized
INFO - 2023-03-17 02:44:01 --> Output Class Initialized
INFO - 2023-03-17 02:44:01 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:01 --> Input Class Initialized
INFO - 2023-03-17 02:44:01 --> Language Class Initialized
INFO - 2023-03-17 02:44:01 --> Loader Class Initialized
INFO - 2023-03-17 02:44:01 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:01 --> Database Driver Class Initialized
INFO - 2023-03-17 02:44:01 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:44:01 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:01 --> Total execution time: 0.0180
INFO - 2023-03-17 02:44:06 --> Config Class Initialized
INFO - 2023-03-17 02:44:06 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:06 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:06 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:06 --> URI Class Initialized
INFO - 2023-03-17 02:44:06 --> Router Class Initialized
INFO - 2023-03-17 02:44:06 --> Output Class Initialized
INFO - 2023-03-17 02:44:06 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:06 --> Input Class Initialized
INFO - 2023-03-17 02:44:06 --> Language Class Initialized
INFO - 2023-03-17 02:44:06 --> Loader Class Initialized
INFO - 2023-03-17 02:44:06 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:06 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:06 --> Total execution time: 0.1241
INFO - 2023-03-17 02:44:06 --> Config Class Initialized
INFO - 2023-03-17 02:44:06 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:06 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:06 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:06 --> URI Class Initialized
INFO - 2023-03-17 02:44:06 --> Router Class Initialized
INFO - 2023-03-17 02:44:06 --> Output Class Initialized
INFO - 2023-03-17 02:44:06 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:06 --> Input Class Initialized
INFO - 2023-03-17 02:44:06 --> Language Class Initialized
INFO - 2023-03-17 02:44:06 --> Loader Class Initialized
INFO - 2023-03-17 02:44:06 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:06 --> Database Driver Class Initialized
INFO - 2023-03-17 02:44:06 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:44:06 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:06 --> Total execution time: 0.0143
INFO - 2023-03-17 02:44:10 --> Config Class Initialized
INFO - 2023-03-17 02:44:10 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:10 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:10 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:10 --> URI Class Initialized
INFO - 2023-03-17 02:44:10 --> Router Class Initialized
INFO - 2023-03-17 02:44:10 --> Output Class Initialized
INFO - 2023-03-17 02:44:10 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:10 --> Input Class Initialized
INFO - 2023-03-17 02:44:10 --> Language Class Initialized
INFO - 2023-03-17 02:44:10 --> Loader Class Initialized
INFO - 2023-03-17 02:44:10 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:10 --> Database Driver Class Initialized
INFO - 2023-03-17 02:44:10 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:44:10 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:10 --> Total execution time: 0.0212
INFO - 2023-03-17 02:44:16 --> Config Class Initialized
INFO - 2023-03-17 02:44:16 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:16 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:16 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:16 --> URI Class Initialized
INFO - 2023-03-17 02:44:16 --> Router Class Initialized
INFO - 2023-03-17 02:44:16 --> Output Class Initialized
INFO - 2023-03-17 02:44:16 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:16 --> Input Class Initialized
INFO - 2023-03-17 02:44:16 --> Language Class Initialized
INFO - 2023-03-17 02:44:16 --> Loader Class Initialized
INFO - 2023-03-17 02:44:16 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:16 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:16 --> Total execution time: 0.0050
INFO - 2023-03-17 02:44:16 --> Config Class Initialized
INFO - 2023-03-17 02:44:16 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:16 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:16 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:16 --> URI Class Initialized
INFO - 2023-03-17 02:44:16 --> Router Class Initialized
INFO - 2023-03-17 02:44:16 --> Output Class Initialized
INFO - 2023-03-17 02:44:16 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:16 --> Input Class Initialized
INFO - 2023-03-17 02:44:16 --> Language Class Initialized
INFO - 2023-03-17 02:44:16 --> Loader Class Initialized
INFO - 2023-03-17 02:44:16 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:16 --> Database Driver Class Initialized
INFO - 2023-03-17 02:44:22 --> Config Class Initialized
INFO - 2023-03-17 02:44:22 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:22 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:22 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:22 --> URI Class Initialized
INFO - 2023-03-17 02:44:22 --> Router Class Initialized
INFO - 2023-03-17 02:44:22 --> Output Class Initialized
INFO - 2023-03-17 02:44:22 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:22 --> Input Class Initialized
INFO - 2023-03-17 02:44:22 --> Language Class Initialized
INFO - 2023-03-17 02:44:22 --> Loader Class Initialized
INFO - 2023-03-17 02:44:22 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:22 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:22 --> Total execution time: 0.0429
INFO - 2023-03-17 02:44:22 --> Config Class Initialized
INFO - 2023-03-17 02:44:22 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:22 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:22 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:22 --> URI Class Initialized
INFO - 2023-03-17 02:44:22 --> Router Class Initialized
INFO - 2023-03-17 02:44:22 --> Output Class Initialized
INFO - 2023-03-17 02:44:22 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:22 --> Input Class Initialized
INFO - 2023-03-17 02:44:22 --> Language Class Initialized
INFO - 2023-03-17 02:44:22 --> Loader Class Initialized
INFO - 2023-03-17 02:44:22 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:22 --> Database Driver Class Initialized
INFO - 2023-03-17 02:44:27 --> Config Class Initialized
INFO - 2023-03-17 02:44:27 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:27 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:27 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:27 --> URI Class Initialized
INFO - 2023-03-17 02:44:27 --> Router Class Initialized
INFO - 2023-03-17 02:44:27 --> Output Class Initialized
INFO - 2023-03-17 02:44:27 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:27 --> Input Class Initialized
INFO - 2023-03-17 02:44:27 --> Language Class Initialized
INFO - 2023-03-17 02:44:27 --> Loader Class Initialized
INFO - 2023-03-17 02:44:27 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:27 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:27 --> Total execution time: 0.0051
INFO - 2023-03-17 02:44:27 --> Config Class Initialized
INFO - 2023-03-17 02:44:27 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:27 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:27 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:27 --> URI Class Initialized
INFO - 2023-03-17 02:44:27 --> Router Class Initialized
INFO - 2023-03-17 02:44:27 --> Output Class Initialized
INFO - 2023-03-17 02:44:27 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:27 --> Input Class Initialized
INFO - 2023-03-17 02:44:27 --> Language Class Initialized
INFO - 2023-03-17 02:44:27 --> Loader Class Initialized
INFO - 2023-03-17 02:44:27 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:27 --> Database Driver Class Initialized
INFO - 2023-03-17 02:44:31 --> Config Class Initialized
INFO - 2023-03-17 02:44:31 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:31 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:31 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:31 --> URI Class Initialized
INFO - 2023-03-17 02:44:31 --> Router Class Initialized
INFO - 2023-03-17 02:44:31 --> Output Class Initialized
INFO - 2023-03-17 02:44:31 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:31 --> Input Class Initialized
INFO - 2023-03-17 02:44:31 --> Language Class Initialized
INFO - 2023-03-17 02:44:31 --> Loader Class Initialized
INFO - 2023-03-17 02:44:31 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:31 --> Database Driver Class Initialized
INFO - 2023-03-17 02:44:34 --> Config Class Initialized
INFO - 2023-03-17 02:44:34 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:34 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:34 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:34 --> URI Class Initialized
INFO - 2023-03-17 02:44:34 --> Router Class Initialized
INFO - 2023-03-17 02:44:34 --> Output Class Initialized
INFO - 2023-03-17 02:44:34 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:34 --> Input Class Initialized
INFO - 2023-03-17 02:44:34 --> Language Class Initialized
INFO - 2023-03-17 02:44:34 --> Loader Class Initialized
INFO - 2023-03-17 02:44:34 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:34 --> Final output sent to browser
DEBUG - 2023-03-17 02:44:34 --> Total execution time: 0.0107
INFO - 2023-03-17 02:44:34 --> Config Class Initialized
INFO - 2023-03-17 02:44:34 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:44:34 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:44:34 --> Utf8 Class Initialized
INFO - 2023-03-17 02:44:34 --> URI Class Initialized
INFO - 2023-03-17 02:44:34 --> Router Class Initialized
INFO - 2023-03-17 02:44:34 --> Output Class Initialized
INFO - 2023-03-17 02:44:34 --> Security Class Initialized
DEBUG - 2023-03-17 02:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:44:34 --> Input Class Initialized
INFO - 2023-03-17 02:44:34 --> Language Class Initialized
INFO - 2023-03-17 02:44:34 --> Loader Class Initialized
INFO - 2023-03-17 02:44:34 --> Controller Class Initialized
DEBUG - 2023-03-17 02:44:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:44:34 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 58.5379
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 45.9008
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 49.3057
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 53.4078
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 64.4137
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0043
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0045
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0034
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0034
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0035
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0033
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0034
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0029
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> Database Driver Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:20 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0162
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0168
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0165
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
INFO - 2023-03-17 02:45:20 --> Config Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
DEBUG - 2023-03-17 02:45:20 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> URI Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:20 --> Router Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Output Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
INFO - 2023-03-17 02:45:20 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-17 02:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Input Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Language Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Loader Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
INFO - 2023-03-17 02:45:20 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-17 02:45:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:20 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:20 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0386
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0387
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0270
INFO - 2023-03-17 02:45:20 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0270
DEBUG - 2023-03-17 02:45:20 --> Total execution time: 0.0290
INFO - 2023-03-17 02:45:21 --> Config Class Initialized
INFO - 2023-03-17 02:45:21 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:21 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:21 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:21 --> URI Class Initialized
INFO - 2023-03-17 02:45:21 --> Router Class Initialized
INFO - 2023-03-17 02:45:21 --> Output Class Initialized
INFO - 2023-03-17 02:45:21 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:21 --> Input Class Initialized
INFO - 2023-03-17 02:45:21 --> Language Class Initialized
INFO - 2023-03-17 02:45:21 --> Loader Class Initialized
INFO - 2023-03-17 02:45:21 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:21 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:21 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:21 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:21 --> Total execution time: 0.0186
INFO - 2023-03-17 02:45:27 --> Config Class Initialized
INFO - 2023-03-17 02:45:27 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:27 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:27 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:27 --> URI Class Initialized
INFO - 2023-03-17 02:45:27 --> Router Class Initialized
INFO - 2023-03-17 02:45:27 --> Output Class Initialized
INFO - 2023-03-17 02:45:27 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:27 --> Input Class Initialized
INFO - 2023-03-17 02:45:27 --> Language Class Initialized
INFO - 2023-03-17 02:45:27 --> Loader Class Initialized
INFO - 2023-03-17 02:45:27 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:27 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:27 --> Total execution time: 0.0043
INFO - 2023-03-17 02:45:27 --> Config Class Initialized
INFO - 2023-03-17 02:45:27 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:27 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:27 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:27 --> URI Class Initialized
INFO - 2023-03-17 02:45:27 --> Router Class Initialized
INFO - 2023-03-17 02:45:27 --> Output Class Initialized
INFO - 2023-03-17 02:45:27 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:27 --> Input Class Initialized
INFO - 2023-03-17 02:45:27 --> Language Class Initialized
INFO - 2023-03-17 02:45:27 --> Loader Class Initialized
INFO - 2023-03-17 02:45:27 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:27 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:27 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:27 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:27 --> Total execution time: 0.0146
INFO - 2023-03-17 02:45:32 --> Config Class Initialized
INFO - 2023-03-17 02:45:32 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:32 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:32 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:32 --> URI Class Initialized
INFO - 2023-03-17 02:45:32 --> Router Class Initialized
INFO - 2023-03-17 02:45:32 --> Output Class Initialized
INFO - 2023-03-17 02:45:32 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:32 --> Input Class Initialized
INFO - 2023-03-17 02:45:32 --> Language Class Initialized
INFO - 2023-03-17 02:45:32 --> Loader Class Initialized
INFO - 2023-03-17 02:45:32 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:32 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:32 --> Total execution time: 0.0041
INFO - 2023-03-17 02:45:32 --> Config Class Initialized
INFO - 2023-03-17 02:45:32 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:32 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:32 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:32 --> URI Class Initialized
INFO - 2023-03-17 02:45:32 --> Router Class Initialized
INFO - 2023-03-17 02:45:32 --> Output Class Initialized
INFO - 2023-03-17 02:45:32 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:32 --> Input Class Initialized
INFO - 2023-03-17 02:45:32 --> Language Class Initialized
INFO - 2023-03-17 02:45:32 --> Loader Class Initialized
INFO - 2023-03-17 02:45:32 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:32 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:32 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:32 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:32 --> Total execution time: 0.0153
INFO - 2023-03-17 02:45:36 --> Config Class Initialized
INFO - 2023-03-17 02:45:36 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:36 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:36 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:36 --> URI Class Initialized
INFO - 2023-03-17 02:45:36 --> Router Class Initialized
INFO - 2023-03-17 02:45:36 --> Output Class Initialized
INFO - 2023-03-17 02:45:36 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:36 --> Input Class Initialized
INFO - 2023-03-17 02:45:36 --> Language Class Initialized
INFO - 2023-03-17 02:45:36 --> Loader Class Initialized
INFO - 2023-03-17 02:45:36 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:36 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:36 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:36 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:36 --> Total execution time: 0.0553
INFO - 2023-03-17 02:45:42 --> Config Class Initialized
INFO - 2023-03-17 02:45:42 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:42 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:42 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:42 --> URI Class Initialized
INFO - 2023-03-17 02:45:42 --> Router Class Initialized
INFO - 2023-03-17 02:45:42 --> Output Class Initialized
INFO - 2023-03-17 02:45:42 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:42 --> Input Class Initialized
INFO - 2023-03-17 02:45:42 --> Language Class Initialized
INFO - 2023-03-17 02:45:42 --> Loader Class Initialized
INFO - 2023-03-17 02:45:42 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:42 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:42 --> Total execution time: 0.0053
INFO - 2023-03-17 02:45:42 --> Config Class Initialized
INFO - 2023-03-17 02:45:42 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:42 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:42 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:42 --> URI Class Initialized
INFO - 2023-03-17 02:45:42 --> Router Class Initialized
INFO - 2023-03-17 02:45:42 --> Output Class Initialized
INFO - 2023-03-17 02:45:42 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:42 --> Input Class Initialized
INFO - 2023-03-17 02:45:42 --> Language Class Initialized
INFO - 2023-03-17 02:45:42 --> Loader Class Initialized
INFO - 2023-03-17 02:45:42 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:42 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:42 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:42 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:42 --> Total execution time: 0.0193
INFO - 2023-03-17 02:45:44 --> Config Class Initialized
INFO - 2023-03-17 02:45:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:44 --> URI Class Initialized
INFO - 2023-03-17 02:45:44 --> Router Class Initialized
INFO - 2023-03-17 02:45:44 --> Output Class Initialized
INFO - 2023-03-17 02:45:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:44 --> Input Class Initialized
INFO - 2023-03-17 02:45:44 --> Language Class Initialized
INFO - 2023-03-17 02:45:44 --> Loader Class Initialized
INFO - 2023-03-17 02:45:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:44 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:44 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:44 --> Total execution time: 0.0185
INFO - 2023-03-17 02:45:51 --> Config Class Initialized
INFO - 2023-03-17 02:45:51 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:51 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:51 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:51 --> URI Class Initialized
INFO - 2023-03-17 02:45:51 --> Router Class Initialized
INFO - 2023-03-17 02:45:51 --> Output Class Initialized
INFO - 2023-03-17 02:45:51 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:51 --> Input Class Initialized
INFO - 2023-03-17 02:45:51 --> Language Class Initialized
INFO - 2023-03-17 02:45:51 --> Loader Class Initialized
INFO - 2023-03-17 02:45:51 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:51 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:51 --> Total execution time: 0.0037
INFO - 2023-03-17 02:45:51 --> Config Class Initialized
INFO - 2023-03-17 02:45:51 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:51 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:51 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:51 --> URI Class Initialized
INFO - 2023-03-17 02:45:51 --> Router Class Initialized
INFO - 2023-03-17 02:45:51 --> Output Class Initialized
INFO - 2023-03-17 02:45:51 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:51 --> Input Class Initialized
INFO - 2023-03-17 02:45:51 --> Language Class Initialized
INFO - 2023-03-17 02:45:51 --> Loader Class Initialized
INFO - 2023-03-17 02:45:51 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:51 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:51 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:51 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:51 --> Total execution time: 0.0147
INFO - 2023-03-17 02:45:57 --> Config Class Initialized
INFO - 2023-03-17 02:45:57 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:57 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:57 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:57 --> URI Class Initialized
INFO - 2023-03-17 02:45:57 --> Router Class Initialized
INFO - 2023-03-17 02:45:57 --> Output Class Initialized
INFO - 2023-03-17 02:45:57 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:57 --> Input Class Initialized
INFO - 2023-03-17 02:45:57 --> Language Class Initialized
INFO - 2023-03-17 02:45:57 --> Loader Class Initialized
INFO - 2023-03-17 02:45:57 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:57 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:57 --> Total execution time: 0.0022
INFO - 2023-03-17 02:45:57 --> Config Class Initialized
INFO - 2023-03-17 02:45:57 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:45:57 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:45:57 --> Utf8 Class Initialized
INFO - 2023-03-17 02:45:57 --> URI Class Initialized
INFO - 2023-03-17 02:45:57 --> Router Class Initialized
INFO - 2023-03-17 02:45:57 --> Output Class Initialized
INFO - 2023-03-17 02:45:57 --> Security Class Initialized
DEBUG - 2023-03-17 02:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:45:57 --> Input Class Initialized
INFO - 2023-03-17 02:45:57 --> Language Class Initialized
INFO - 2023-03-17 02:45:57 --> Loader Class Initialized
INFO - 2023-03-17 02:45:57 --> Controller Class Initialized
DEBUG - 2023-03-17 02:45:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:45:57 --> Database Driver Class Initialized
INFO - 2023-03-17 02:45:57 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:45:57 --> Final output sent to browser
DEBUG - 2023-03-17 02:45:57 --> Total execution time: 0.0146
INFO - 2023-03-17 02:46:02 --> Config Class Initialized
INFO - 2023-03-17 02:46:02 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:02 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:02 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:02 --> URI Class Initialized
INFO - 2023-03-17 02:46:02 --> Router Class Initialized
INFO - 2023-03-17 02:46:02 --> Output Class Initialized
INFO - 2023-03-17 02:46:02 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:02 --> Input Class Initialized
INFO - 2023-03-17 02:46:02 --> Language Class Initialized
INFO - 2023-03-17 02:46:02 --> Loader Class Initialized
INFO - 2023-03-17 02:46:02 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:02 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:02 --> Total execution time: 0.0041
INFO - 2023-03-17 02:46:02 --> Config Class Initialized
INFO - 2023-03-17 02:46:02 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:02 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:02 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:02 --> URI Class Initialized
INFO - 2023-03-17 02:46:02 --> Router Class Initialized
INFO - 2023-03-17 02:46:02 --> Output Class Initialized
INFO - 2023-03-17 02:46:02 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:02 --> Input Class Initialized
INFO - 2023-03-17 02:46:02 --> Language Class Initialized
INFO - 2023-03-17 02:46:02 --> Loader Class Initialized
INFO - 2023-03-17 02:46:02 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:02 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:02 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:02 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:02 --> Total execution time: 0.0193
INFO - 2023-03-17 02:46:07 --> Config Class Initialized
INFO - 2023-03-17 02:46:07 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:07 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:07 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:07 --> URI Class Initialized
INFO - 2023-03-17 02:46:07 --> Router Class Initialized
INFO - 2023-03-17 02:46:07 --> Output Class Initialized
INFO - 2023-03-17 02:46:07 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:07 --> Input Class Initialized
INFO - 2023-03-17 02:46:07 --> Language Class Initialized
INFO - 2023-03-17 02:46:07 --> Loader Class Initialized
INFO - 2023-03-17 02:46:07 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:07 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:07 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:07 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:07 --> Total execution time: 0.0236
INFO - 2023-03-17 02:46:11 --> Config Class Initialized
INFO - 2023-03-17 02:46:11 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:11 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:11 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:11 --> URI Class Initialized
INFO - 2023-03-17 02:46:11 --> Router Class Initialized
INFO - 2023-03-17 02:46:11 --> Output Class Initialized
INFO - 2023-03-17 02:46:11 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:11 --> Input Class Initialized
INFO - 2023-03-17 02:46:11 --> Language Class Initialized
INFO - 2023-03-17 02:46:11 --> Loader Class Initialized
INFO - 2023-03-17 02:46:11 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:11 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:11 --> Total execution time: 0.0040
INFO - 2023-03-17 02:46:11 --> Config Class Initialized
INFO - 2023-03-17 02:46:11 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:11 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:11 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:11 --> URI Class Initialized
INFO - 2023-03-17 02:46:11 --> Router Class Initialized
INFO - 2023-03-17 02:46:11 --> Output Class Initialized
INFO - 2023-03-17 02:46:11 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:11 --> Input Class Initialized
INFO - 2023-03-17 02:46:11 --> Language Class Initialized
INFO - 2023-03-17 02:46:11 --> Loader Class Initialized
INFO - 2023-03-17 02:46:11 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:11 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:11 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:11 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:11 --> Total execution time: 0.0145
INFO - 2023-03-17 02:46:16 --> Config Class Initialized
INFO - 2023-03-17 02:46:16 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:16 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:16 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:16 --> URI Class Initialized
INFO - 2023-03-17 02:46:16 --> Router Class Initialized
INFO - 2023-03-17 02:46:16 --> Output Class Initialized
INFO - 2023-03-17 02:46:16 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:16 --> Input Class Initialized
INFO - 2023-03-17 02:46:16 --> Language Class Initialized
INFO - 2023-03-17 02:46:16 --> Loader Class Initialized
INFO - 2023-03-17 02:46:16 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:16 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:16 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:16 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:16 --> Total execution time: 0.0228
INFO - 2023-03-17 02:46:22 --> Config Class Initialized
INFO - 2023-03-17 02:46:22 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:22 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:22 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:22 --> URI Class Initialized
INFO - 2023-03-17 02:46:22 --> Router Class Initialized
INFO - 2023-03-17 02:46:22 --> Output Class Initialized
INFO - 2023-03-17 02:46:22 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:22 --> Input Class Initialized
INFO - 2023-03-17 02:46:22 --> Language Class Initialized
INFO - 2023-03-17 02:46:22 --> Loader Class Initialized
INFO - 2023-03-17 02:46:22 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:22 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:22 --> Total execution time: 0.0041
INFO - 2023-03-17 02:46:22 --> Config Class Initialized
INFO - 2023-03-17 02:46:22 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:22 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:22 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:22 --> URI Class Initialized
INFO - 2023-03-17 02:46:22 --> Router Class Initialized
INFO - 2023-03-17 02:46:22 --> Output Class Initialized
INFO - 2023-03-17 02:46:22 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:22 --> Input Class Initialized
INFO - 2023-03-17 02:46:22 --> Language Class Initialized
INFO - 2023-03-17 02:46:22 --> Loader Class Initialized
INFO - 2023-03-17 02:46:22 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:22 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:22 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:22 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:22 --> Total execution time: 0.0181
INFO - 2023-03-17 02:46:27 --> Config Class Initialized
INFO - 2023-03-17 02:46:27 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:27 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:27 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:27 --> URI Class Initialized
INFO - 2023-03-17 02:46:27 --> Router Class Initialized
INFO - 2023-03-17 02:46:27 --> Output Class Initialized
INFO - 2023-03-17 02:46:27 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:27 --> Input Class Initialized
INFO - 2023-03-17 02:46:27 --> Language Class Initialized
INFO - 2023-03-17 02:46:27 --> Loader Class Initialized
INFO - 2023-03-17 02:46:27 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:27 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:27 --> Total execution time: 0.0042
INFO - 2023-03-17 02:46:27 --> Config Class Initialized
INFO - 2023-03-17 02:46:27 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:27 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:27 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:27 --> URI Class Initialized
INFO - 2023-03-17 02:46:27 --> Router Class Initialized
INFO - 2023-03-17 02:46:27 --> Output Class Initialized
INFO - 2023-03-17 02:46:27 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:27 --> Input Class Initialized
INFO - 2023-03-17 02:46:27 --> Language Class Initialized
INFO - 2023-03-17 02:46:27 --> Loader Class Initialized
INFO - 2023-03-17 02:46:27 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:27 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:27 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:27 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:27 --> Total execution time: 0.0145
INFO - 2023-03-17 02:46:31 --> Config Class Initialized
INFO - 2023-03-17 02:46:31 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:31 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:31 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:31 --> URI Class Initialized
INFO - 2023-03-17 02:46:31 --> Router Class Initialized
INFO - 2023-03-17 02:46:31 --> Output Class Initialized
INFO - 2023-03-17 02:46:31 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:31 --> Input Class Initialized
INFO - 2023-03-17 02:46:31 --> Language Class Initialized
INFO - 2023-03-17 02:46:31 --> Loader Class Initialized
INFO - 2023-03-17 02:46:31 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:31 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:31 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:31 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:31 --> Total execution time: 0.0221
INFO - 2023-03-17 02:46:34 --> Config Class Initialized
INFO - 2023-03-17 02:46:34 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:34 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:34 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:34 --> URI Class Initialized
INFO - 2023-03-17 02:46:34 --> Router Class Initialized
INFO - 2023-03-17 02:46:34 --> Output Class Initialized
INFO - 2023-03-17 02:46:34 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:34 --> Input Class Initialized
INFO - 2023-03-17 02:46:34 --> Language Class Initialized
INFO - 2023-03-17 02:46:34 --> Loader Class Initialized
INFO - 2023-03-17 02:46:34 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:34 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:34 --> Total execution time: 0.0098
INFO - 2023-03-17 02:46:34 --> Config Class Initialized
INFO - 2023-03-17 02:46:34 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:34 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:34 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:34 --> URI Class Initialized
INFO - 2023-03-17 02:46:34 --> Router Class Initialized
INFO - 2023-03-17 02:46:34 --> Output Class Initialized
INFO - 2023-03-17 02:46:34 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:34 --> Input Class Initialized
INFO - 2023-03-17 02:46:34 --> Language Class Initialized
INFO - 2023-03-17 02:46:34 --> Loader Class Initialized
INFO - 2023-03-17 02:46:34 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:34 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:34 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:34 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:34 --> Total execution time: 0.0148
INFO - 2023-03-17 02:46:39 --> Config Class Initialized
INFO - 2023-03-17 02:46:39 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:39 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:39 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:39 --> URI Class Initialized
INFO - 2023-03-17 02:46:39 --> Router Class Initialized
INFO - 2023-03-17 02:46:39 --> Output Class Initialized
INFO - 2023-03-17 02:46:39 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:39 --> Input Class Initialized
INFO - 2023-03-17 02:46:39 --> Language Class Initialized
INFO - 2023-03-17 02:46:39 --> Loader Class Initialized
INFO - 2023-03-17 02:46:39 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:39 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:39 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:39 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:39 --> Total execution time: 0.0197
INFO - 2023-03-17 02:46:44 --> Config Class Initialized
INFO - 2023-03-17 02:46:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:44 --> URI Class Initialized
INFO - 2023-03-17 02:46:44 --> Router Class Initialized
INFO - 2023-03-17 02:46:44 --> Output Class Initialized
INFO - 2023-03-17 02:46:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:44 --> Input Class Initialized
INFO - 2023-03-17 02:46:44 --> Language Class Initialized
INFO - 2023-03-17 02:46:44 --> Loader Class Initialized
INFO - 2023-03-17 02:46:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:44 --> Total execution time: 0.0041
INFO - 2023-03-17 02:46:44 --> Config Class Initialized
INFO - 2023-03-17 02:46:44 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:44 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:44 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:44 --> URI Class Initialized
INFO - 2023-03-17 02:46:44 --> Router Class Initialized
INFO - 2023-03-17 02:46:44 --> Output Class Initialized
INFO - 2023-03-17 02:46:44 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:44 --> Input Class Initialized
INFO - 2023-03-17 02:46:44 --> Language Class Initialized
INFO - 2023-03-17 02:46:44 --> Loader Class Initialized
INFO - 2023-03-17 02:46:44 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:44 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:44 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:44 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:44 --> Total execution time: 0.0164
INFO - 2023-03-17 02:46:49 --> Config Class Initialized
INFO - 2023-03-17 02:46:49 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:49 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:49 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:49 --> URI Class Initialized
INFO - 2023-03-17 02:46:49 --> Router Class Initialized
INFO - 2023-03-17 02:46:49 --> Output Class Initialized
INFO - 2023-03-17 02:46:49 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:49 --> Input Class Initialized
INFO - 2023-03-17 02:46:49 --> Language Class Initialized
INFO - 2023-03-17 02:46:49 --> Loader Class Initialized
INFO - 2023-03-17 02:46:49 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:49 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:49 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:49 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:49 --> Total execution time: 0.0177
INFO - 2023-03-17 02:46:56 --> Config Class Initialized
INFO - 2023-03-17 02:46:56 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:56 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:56 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:56 --> URI Class Initialized
INFO - 2023-03-17 02:46:56 --> Router Class Initialized
INFO - 2023-03-17 02:46:56 --> Output Class Initialized
INFO - 2023-03-17 02:46:56 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:56 --> Input Class Initialized
INFO - 2023-03-17 02:46:56 --> Language Class Initialized
INFO - 2023-03-17 02:46:56 --> Loader Class Initialized
INFO - 2023-03-17 02:46:56 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:56 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:56 --> Total execution time: 0.0022
INFO - 2023-03-17 02:46:56 --> Config Class Initialized
INFO - 2023-03-17 02:46:56 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:46:56 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:46:56 --> Utf8 Class Initialized
INFO - 2023-03-17 02:46:56 --> URI Class Initialized
INFO - 2023-03-17 02:46:56 --> Router Class Initialized
INFO - 2023-03-17 02:46:56 --> Output Class Initialized
INFO - 2023-03-17 02:46:56 --> Security Class Initialized
DEBUG - 2023-03-17 02:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:46:56 --> Input Class Initialized
INFO - 2023-03-17 02:46:56 --> Language Class Initialized
INFO - 2023-03-17 02:46:56 --> Loader Class Initialized
INFO - 2023-03-17 02:46:56 --> Controller Class Initialized
DEBUG - 2023-03-17 02:46:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:46:56 --> Database Driver Class Initialized
INFO - 2023-03-17 02:46:56 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:46:56 --> Final output sent to browser
DEBUG - 2023-03-17 02:46:56 --> Total execution time: 0.0159
INFO - 2023-03-17 02:47:02 --> Config Class Initialized
INFO - 2023-03-17 02:47:02 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:02 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:02 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:02 --> URI Class Initialized
INFO - 2023-03-17 02:47:02 --> Router Class Initialized
INFO - 2023-03-17 02:47:02 --> Output Class Initialized
INFO - 2023-03-17 02:47:02 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:02 --> Input Class Initialized
INFO - 2023-03-17 02:47:02 --> Language Class Initialized
INFO - 2023-03-17 02:47:02 --> Loader Class Initialized
INFO - 2023-03-17 02:47:02 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:02 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:02 --> Total execution time: 0.0029
INFO - 2023-03-17 02:47:02 --> Config Class Initialized
INFO - 2023-03-17 02:47:02 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:02 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:02 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:02 --> URI Class Initialized
INFO - 2023-03-17 02:47:02 --> Router Class Initialized
INFO - 2023-03-17 02:47:02 --> Output Class Initialized
INFO - 2023-03-17 02:47:02 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:02 --> Input Class Initialized
INFO - 2023-03-17 02:47:02 --> Language Class Initialized
INFO - 2023-03-17 02:47:02 --> Loader Class Initialized
INFO - 2023-03-17 02:47:02 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:02 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:02 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:02 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:02 --> Total execution time: 0.0148
INFO - 2023-03-17 02:47:06 --> Config Class Initialized
INFO - 2023-03-17 02:47:06 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:06 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:06 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:06 --> URI Class Initialized
INFO - 2023-03-17 02:47:06 --> Router Class Initialized
INFO - 2023-03-17 02:47:06 --> Output Class Initialized
INFO - 2023-03-17 02:47:06 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:06 --> Input Class Initialized
INFO - 2023-03-17 02:47:06 --> Language Class Initialized
INFO - 2023-03-17 02:47:06 --> Loader Class Initialized
INFO - 2023-03-17 02:47:06 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:06 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:06 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:06 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:06 --> Total execution time: 0.0166
INFO - 2023-03-17 02:47:11 --> Config Class Initialized
INFO - 2023-03-17 02:47:11 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:11 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:11 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:11 --> URI Class Initialized
INFO - 2023-03-17 02:47:11 --> Router Class Initialized
INFO - 2023-03-17 02:47:11 --> Output Class Initialized
INFO - 2023-03-17 02:47:11 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:11 --> Input Class Initialized
INFO - 2023-03-17 02:47:11 --> Language Class Initialized
INFO - 2023-03-17 02:47:11 --> Loader Class Initialized
INFO - 2023-03-17 02:47:11 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:11 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:11 --> Total execution time: 0.0054
INFO - 2023-03-17 02:47:11 --> Config Class Initialized
INFO - 2023-03-17 02:47:11 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:11 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:11 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:11 --> URI Class Initialized
INFO - 2023-03-17 02:47:11 --> Router Class Initialized
INFO - 2023-03-17 02:47:11 --> Output Class Initialized
INFO - 2023-03-17 02:47:11 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:11 --> Input Class Initialized
INFO - 2023-03-17 02:47:11 --> Language Class Initialized
INFO - 2023-03-17 02:47:11 --> Loader Class Initialized
INFO - 2023-03-17 02:47:11 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:11 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:11 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:11 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:11 --> Total execution time: 0.0188
INFO - 2023-03-17 02:47:16 --> Config Class Initialized
INFO - 2023-03-17 02:47:16 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:16 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:16 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:16 --> URI Class Initialized
INFO - 2023-03-17 02:47:16 --> Router Class Initialized
INFO - 2023-03-17 02:47:16 --> Output Class Initialized
INFO - 2023-03-17 02:47:16 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:16 --> Input Class Initialized
INFO - 2023-03-17 02:47:16 --> Language Class Initialized
INFO - 2023-03-17 02:47:16 --> Loader Class Initialized
INFO - 2023-03-17 02:47:16 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:16 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:22 --> Config Class Initialized
INFO - 2023-03-17 02:47:22 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:22 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:22 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:22 --> URI Class Initialized
INFO - 2023-03-17 02:47:22 --> Router Class Initialized
INFO - 2023-03-17 02:47:22 --> Output Class Initialized
INFO - 2023-03-17 02:47:22 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:22 --> Input Class Initialized
INFO - 2023-03-17 02:47:22 --> Language Class Initialized
INFO - 2023-03-17 02:47:22 --> Loader Class Initialized
INFO - 2023-03-17 02:47:22 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:22 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:22 --> Total execution time: 0.0416
INFO - 2023-03-17 02:47:22 --> Config Class Initialized
INFO - 2023-03-17 02:47:22 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:22 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:22 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:22 --> URI Class Initialized
INFO - 2023-03-17 02:47:22 --> Router Class Initialized
INFO - 2023-03-17 02:47:22 --> Output Class Initialized
INFO - 2023-03-17 02:47:22 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:22 --> Input Class Initialized
INFO - 2023-03-17 02:47:22 --> Language Class Initialized
INFO - 2023-03-17 02:47:22 --> Loader Class Initialized
INFO - 2023-03-17 02:47:22 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:22 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:22 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:22 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:22 --> Total execution time: 0.1930
ERROR - 2023-03-17 02:47:26 --> Unable to connect to the database
INFO - 2023-03-17 02:47:26 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-17 02:47:27 --> Config Class Initialized
INFO - 2023-03-17 02:47:27 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:27 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:27 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:27 --> URI Class Initialized
INFO - 2023-03-17 02:47:27 --> Router Class Initialized
INFO - 2023-03-17 02:47:27 --> Output Class Initialized
INFO - 2023-03-17 02:47:27 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:27 --> Input Class Initialized
INFO - 2023-03-17 02:47:27 --> Language Class Initialized
INFO - 2023-03-17 02:47:27 --> Loader Class Initialized
INFO - 2023-03-17 02:47:27 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:27 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:27 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:31 --> Config Class Initialized
INFO - 2023-03-17 02:47:31 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:31 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:31 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:31 --> URI Class Initialized
INFO - 2023-03-17 02:47:31 --> Router Class Initialized
INFO - 2023-03-17 02:47:31 --> Output Class Initialized
INFO - 2023-03-17 02:47:31 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:31 --> Input Class Initialized
INFO - 2023-03-17 02:47:31 --> Language Class Initialized
INFO - 2023-03-17 02:47:31 --> Loader Class Initialized
INFO - 2023-03-17 02:47:31 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:31 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:31 --> Total execution time: 0.0042
INFO - 2023-03-17 02:47:31 --> Config Class Initialized
INFO - 2023-03-17 02:47:31 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:31 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:31 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:31 --> URI Class Initialized
INFO - 2023-03-17 02:47:31 --> Router Class Initialized
INFO - 2023-03-17 02:47:31 --> Output Class Initialized
INFO - 2023-03-17 02:47:31 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:31 --> Input Class Initialized
INFO - 2023-03-17 02:47:31 --> Language Class Initialized
INFO - 2023-03-17 02:47:31 --> Loader Class Initialized
INFO - 2023-03-17 02:47:31 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:31 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:31 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:36 --> Config Class Initialized
INFO - 2023-03-17 02:47:36 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:36 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:36 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:36 --> URI Class Initialized
INFO - 2023-03-17 02:47:36 --> Router Class Initialized
INFO - 2023-03-17 02:47:36 --> Output Class Initialized
INFO - 2023-03-17 02:47:36 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:36 --> Input Class Initialized
INFO - 2023-03-17 02:47:36 --> Language Class Initialized
INFO - 2023-03-17 02:47:36 --> Loader Class Initialized
INFO - 2023-03-17 02:47:36 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:36 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:36 --> Total execution time: 0.0045
INFO - 2023-03-17 02:47:36 --> Config Class Initialized
INFO - 2023-03-17 02:47:36 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:36 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:36 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:36 --> URI Class Initialized
INFO - 2023-03-17 02:47:36 --> Router Class Initialized
INFO - 2023-03-17 02:47:36 --> Output Class Initialized
INFO - 2023-03-17 02:47:36 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:36 --> Input Class Initialized
INFO - 2023-03-17 02:47:36 --> Language Class Initialized
INFO - 2023-03-17 02:47:36 --> Loader Class Initialized
INFO - 2023-03-17 02:47:36 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:36 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:36 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:41 --> Config Class Initialized
INFO - 2023-03-17 02:47:41 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:41 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:41 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:41 --> URI Class Initialized
INFO - 2023-03-17 02:47:41 --> Router Class Initialized
INFO - 2023-03-17 02:47:41 --> Output Class Initialized
INFO - 2023-03-17 02:47:41 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:41 --> Input Class Initialized
INFO - 2023-03-17 02:47:41 --> Language Class Initialized
INFO - 2023-03-17 02:47:41 --> Loader Class Initialized
INFO - 2023-03-17 02:47:41 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:41 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:41 --> Final output sent to browser
INFO - 2023-03-17 02:47:41 --> Final output sent to browser
INFO - 2023-03-17 02:47:41 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:41 --> Total execution time: 14.1196
DEBUG - 2023-03-17 02:47:41 --> Total execution time: 10.0458
DEBUG - 2023-03-17 02:47:41 --> Total execution time: 4.6234
INFO - 2023-03-17 02:47:41 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:42 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:42 --> Total execution time: 1.1881
INFO - 2023-03-17 02:47:46 --> Config Class Initialized
INFO - 2023-03-17 02:47:46 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:46 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:46 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:46 --> URI Class Initialized
INFO - 2023-03-17 02:47:46 --> Router Class Initialized
INFO - 2023-03-17 02:47:46 --> Output Class Initialized
INFO - 2023-03-17 02:47:46 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:46 --> Input Class Initialized
INFO - 2023-03-17 02:47:46 --> Language Class Initialized
INFO - 2023-03-17 02:47:46 --> Loader Class Initialized
INFO - 2023-03-17 02:47:46 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:46 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:46 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:46 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:46 --> Model "Login_model" initialized
INFO - 2023-03-17 02:47:46 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:46 --> Total execution time: 0.0703
INFO - 2023-03-17 02:47:46 --> Config Class Initialized
INFO - 2023-03-17 02:47:46 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:47:46 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:47:46 --> Utf8 Class Initialized
INFO - 2023-03-17 02:47:46 --> URI Class Initialized
INFO - 2023-03-17 02:47:46 --> Router Class Initialized
INFO - 2023-03-17 02:47:46 --> Output Class Initialized
INFO - 2023-03-17 02:47:46 --> Security Class Initialized
DEBUG - 2023-03-17 02:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:47:46 --> Input Class Initialized
INFO - 2023-03-17 02:47:46 --> Language Class Initialized
INFO - 2023-03-17 02:47:46 --> Loader Class Initialized
INFO - 2023-03-17 02:47:46 --> Controller Class Initialized
DEBUG - 2023-03-17 02:47:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:47:46 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:46 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:47:46 --> Database Driver Class Initialized
INFO - 2023-03-17 02:47:46 --> Model "Login_model" initialized
INFO - 2023-03-17 02:47:46 --> Final output sent to browser
DEBUG - 2023-03-17 02:47:46 --> Total execution time: 0.0603
INFO - 2023-03-17 02:49:10 --> Config Class Initialized
INFO - 2023-03-17 02:49:10 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:10 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:10 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:10 --> URI Class Initialized
INFO - 2023-03-17 02:49:10 --> Router Class Initialized
INFO - 2023-03-17 02:49:10 --> Output Class Initialized
INFO - 2023-03-17 02:49:10 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:10 --> Input Class Initialized
INFO - 2023-03-17 02:49:10 --> Language Class Initialized
INFO - 2023-03-17 02:49:10 --> Loader Class Initialized
INFO - 2023-03-17 02:49:10 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:10 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:10 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:10 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:10 --> Model "Login_model" initialized
INFO - 2023-03-17 02:49:10 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:10 --> Total execution time: 0.1564
INFO - 2023-03-17 02:49:10 --> Config Class Initialized
INFO - 2023-03-17 02:49:10 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:10 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:10 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:10 --> URI Class Initialized
INFO - 2023-03-17 02:49:10 --> Router Class Initialized
INFO - 2023-03-17 02:49:10 --> Output Class Initialized
INFO - 2023-03-17 02:49:10 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:10 --> Input Class Initialized
INFO - 2023-03-17 02:49:10 --> Language Class Initialized
INFO - 2023-03-17 02:49:10 --> Loader Class Initialized
INFO - 2023-03-17 02:49:10 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:10 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:10 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:10 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:10 --> Model "Login_model" initialized
INFO - 2023-03-17 02:49:10 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:10 --> Total execution time: 0.0554
INFO - 2023-03-17 02:49:38 --> Config Class Initialized
INFO - 2023-03-17 02:49:38 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:38 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:38 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:38 --> URI Class Initialized
INFO - 2023-03-17 02:49:38 --> Router Class Initialized
INFO - 2023-03-17 02:49:38 --> Output Class Initialized
INFO - 2023-03-17 02:49:38 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:38 --> Input Class Initialized
INFO - 2023-03-17 02:49:38 --> Language Class Initialized
INFO - 2023-03-17 02:49:38 --> Loader Class Initialized
INFO - 2023-03-17 02:49:38 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:38 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:38 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:38 --> Model "Login_model" initialized
INFO - 2023-03-17 02:49:38 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:38 --> Total execution time: 0.0266
INFO - 2023-03-17 02:49:38 --> Config Class Initialized
INFO - 2023-03-17 02:49:38 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:38 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:38 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:38 --> URI Class Initialized
INFO - 2023-03-17 02:49:38 --> Router Class Initialized
INFO - 2023-03-17 02:49:38 --> Output Class Initialized
INFO - 2023-03-17 02:49:38 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:38 --> Input Class Initialized
INFO - 2023-03-17 02:49:38 --> Language Class Initialized
INFO - 2023-03-17 02:49:38 --> Loader Class Initialized
INFO - 2023-03-17 02:49:38 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:38 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:38 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:38 --> Model "Login_model" initialized
INFO - 2023-03-17 02:49:38 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:38 --> Total execution time: 0.0215
INFO - 2023-03-17 02:49:38 --> Config Class Initialized
INFO - 2023-03-17 02:49:38 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:38 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:38 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:38 --> URI Class Initialized
INFO - 2023-03-17 02:49:38 --> Router Class Initialized
INFO - 2023-03-17 02:49:38 --> Output Class Initialized
INFO - 2023-03-17 02:49:38 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:38 --> Input Class Initialized
INFO - 2023-03-17 02:49:38 --> Language Class Initialized
INFO - 2023-03-17 02:49:38 --> Loader Class Initialized
INFO - 2023-03-17 02:49:38 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:38 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:38 --> Total execution time: 0.1521
INFO - 2023-03-17 02:49:38 --> Config Class Initialized
INFO - 2023-03-17 02:49:38 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:38 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:38 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:38 --> URI Class Initialized
INFO - 2023-03-17 02:49:38 --> Router Class Initialized
INFO - 2023-03-17 02:49:38 --> Output Class Initialized
INFO - 2023-03-17 02:49:38 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:38 --> Input Class Initialized
INFO - 2023-03-17 02:49:38 --> Language Class Initialized
INFO - 2023-03-17 02:49:38 --> Loader Class Initialized
INFO - 2023-03-17 02:49:38 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:39 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:39 --> Total execution time: 0.2090
INFO - 2023-03-17 02:49:46 --> Config Class Initialized
INFO - 2023-03-17 02:49:46 --> Config Class Initialized
INFO - 2023-03-17 02:49:46 --> Hooks Class Initialized
INFO - 2023-03-17 02:49:46 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-03-17 02:49:46 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:46 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:46 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:46 --> URI Class Initialized
INFO - 2023-03-17 02:49:46 --> URI Class Initialized
INFO - 2023-03-17 02:49:46 --> Router Class Initialized
INFO - 2023-03-17 02:49:46 --> Router Class Initialized
INFO - 2023-03-17 02:49:46 --> Output Class Initialized
INFO - 2023-03-17 02:49:46 --> Output Class Initialized
INFO - 2023-03-17 02:49:46 --> Security Class Initialized
INFO - 2023-03-17 02:49:46 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-17 02:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:46 --> Input Class Initialized
INFO - 2023-03-17 02:49:46 --> Input Class Initialized
INFO - 2023-03-17 02:49:46 --> Language Class Initialized
INFO - 2023-03-17 02:49:46 --> Language Class Initialized
INFO - 2023-03-17 02:49:46 --> Loader Class Initialized
INFO - 2023-03-17 02:49:46 --> Loader Class Initialized
INFO - 2023-03-17 02:49:46 --> Controller Class Initialized
INFO - 2023-03-17 02:49:46 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-17 02:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:46 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:46 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:46 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:46 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:46 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:46 --> Total execution time: 0.0180
INFO - 2023-03-17 02:49:46 --> Config Class Initialized
INFO - 2023-03-17 02:49:46 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:46 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:46 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:46 --> URI Class Initialized
INFO - 2023-03-17 02:49:46 --> Router Class Initialized
INFO - 2023-03-17 02:49:46 --> Output Class Initialized
INFO - 2023-03-17 02:49:46 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:46 --> Input Class Initialized
INFO - 2023-03-17 02:49:46 --> Language Class Initialized
INFO - 2023-03-17 02:49:46 --> Loader Class Initialized
INFO - 2023-03-17 02:49:46 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:46 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:46 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:46 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:46 --> Total execution time: 0.0924
INFO - 2023-03-17 02:49:47 --> Config Class Initialized
INFO - 2023-03-17 02:49:47 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:47 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:47 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:47 --> URI Class Initialized
INFO - 2023-03-17 02:49:47 --> Router Class Initialized
INFO - 2023-03-17 02:49:47 --> Output Class Initialized
INFO - 2023-03-17 02:49:47 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:47 --> Input Class Initialized
INFO - 2023-03-17 02:49:47 --> Language Class Initialized
INFO - 2023-03-17 02:49:47 --> Loader Class Initialized
INFO - 2023-03-17 02:49:47 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:47 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:47 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:48 --> Config Class Initialized
INFO - 2023-03-17 02:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:48 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:48 --> URI Class Initialized
INFO - 2023-03-17 02:49:48 --> Router Class Initialized
INFO - 2023-03-17 02:49:48 --> Output Class Initialized
INFO - 2023-03-17 02:49:48 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:48 --> Input Class Initialized
INFO - 2023-03-17 02:49:48 --> Language Class Initialized
INFO - 2023-03-17 02:49:48 --> Loader Class Initialized
INFO - 2023-03-17 02:49:48 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:48 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:48 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:48 --> Model "Login_model" initialized
INFO - 2023-03-17 02:49:48 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:48 --> Total execution time: 0.0347
INFO - 2023-03-17 02:49:48 --> Config Class Initialized
INFO - 2023-03-17 02:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:48 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:48 --> URI Class Initialized
INFO - 2023-03-17 02:49:48 --> Router Class Initialized
INFO - 2023-03-17 02:49:48 --> Output Class Initialized
INFO - 2023-03-17 02:49:48 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:48 --> Input Class Initialized
INFO - 2023-03-17 02:49:48 --> Language Class Initialized
INFO - 2023-03-17 02:49:48 --> Loader Class Initialized
INFO - 2023-03-17 02:49:48 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:48 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:48 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:48 --> Model "Login_model" initialized
INFO - 2023-03-17 02:49:48 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:48 --> Total execution time: 0.0189
INFO - 2023-03-17 02:49:48 --> Config Class Initialized
INFO - 2023-03-17 02:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:48 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:48 --> URI Class Initialized
INFO - 2023-03-17 02:49:48 --> Router Class Initialized
INFO - 2023-03-17 02:49:48 --> Output Class Initialized
INFO - 2023-03-17 02:49:48 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:48 --> Input Class Initialized
INFO - 2023-03-17 02:49:48 --> Language Class Initialized
INFO - 2023-03-17 02:49:48 --> Loader Class Initialized
INFO - 2023-03-17 02:49:48 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:48 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:48 --> Total execution time: 0.0433
INFO - 2023-03-17 02:49:48 --> Config Class Initialized
INFO - 2023-03-17 02:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:48 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:48 --> URI Class Initialized
INFO - 2023-03-17 02:49:48 --> Router Class Initialized
INFO - 2023-03-17 02:49:48 --> Output Class Initialized
INFO - 2023-03-17 02:49:48 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:48 --> Input Class Initialized
INFO - 2023-03-17 02:49:48 --> Language Class Initialized
INFO - 2023-03-17 02:49:48 --> Loader Class Initialized
INFO - 2023-03-17 02:49:48 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:48 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:48 --> Total execution time: 0.1373
INFO - 2023-03-17 02:49:54 --> Config Class Initialized
INFO - 2023-03-17 02:49:54 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:54 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:54 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:54 --> URI Class Initialized
INFO - 2023-03-17 02:49:54 --> Router Class Initialized
INFO - 2023-03-17 02:49:54 --> Output Class Initialized
INFO - 2023-03-17 02:49:54 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:54 --> Input Class Initialized
INFO - 2023-03-17 02:49:54 --> Language Class Initialized
INFO - 2023-03-17 02:49:54 --> Loader Class Initialized
INFO - 2023-03-17 02:49:54 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:54 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:54 --> Total execution time: 0.0044
INFO - 2023-03-17 02:49:54 --> Config Class Initialized
INFO - 2023-03-17 02:49:54 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:54 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:54 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:54 --> URI Class Initialized
INFO - 2023-03-17 02:49:54 --> Router Class Initialized
INFO - 2023-03-17 02:49:54 --> Output Class Initialized
INFO - 2023-03-17 02:49:54 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:54 --> Input Class Initialized
INFO - 2023-03-17 02:49:54 --> Language Class Initialized
INFO - 2023-03-17 02:49:54 --> Loader Class Initialized
INFO - 2023-03-17 02:49:54 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:54 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:54 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:54 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:54 --> Total execution time: 0.0106
INFO - 2023-03-17 02:49:56 --> Config Class Initialized
INFO - 2023-03-17 02:49:56 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:56 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:56 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:56 --> URI Class Initialized
INFO - 2023-03-17 02:49:56 --> Router Class Initialized
INFO - 2023-03-17 02:49:56 --> Output Class Initialized
INFO - 2023-03-17 02:49:56 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:56 --> Input Class Initialized
INFO - 2023-03-17 02:49:56 --> Language Class Initialized
INFO - 2023-03-17 02:49:56 --> Loader Class Initialized
INFO - 2023-03-17 02:49:56 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:56 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:56 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:56 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:56 --> Total execution time: 0.0171
INFO - 2023-03-17 02:49:56 --> Config Class Initialized
INFO - 2023-03-17 02:49:56 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:56 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:56 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:56 --> URI Class Initialized
INFO - 2023-03-17 02:49:56 --> Router Class Initialized
INFO - 2023-03-17 02:49:56 --> Output Class Initialized
INFO - 2023-03-17 02:49:56 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:56 --> Input Class Initialized
INFO - 2023-03-17 02:49:56 --> Language Class Initialized
INFO - 2023-03-17 02:49:56 --> Loader Class Initialized
INFO - 2023-03-17 02:49:56 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:56 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:56 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:49:56 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:56 --> Total execution time: 0.0483
INFO - 2023-03-17 02:49:58 --> Config Class Initialized
INFO - 2023-03-17 02:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:58 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:58 --> URI Class Initialized
INFO - 2023-03-17 02:49:58 --> Router Class Initialized
INFO - 2023-03-17 02:49:58 --> Output Class Initialized
INFO - 2023-03-17 02:49:58 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:58 --> Input Class Initialized
INFO - 2023-03-17 02:49:58 --> Language Class Initialized
INFO - 2023-03-17 02:49:58 --> Loader Class Initialized
INFO - 2023-03-17 02:49:58 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:58 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:58 --> Total execution time: 0.0040
INFO - 2023-03-17 02:49:58 --> Config Class Initialized
INFO - 2023-03-17 02:49:58 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:49:58 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:49:58 --> Utf8 Class Initialized
INFO - 2023-03-17 02:49:58 --> URI Class Initialized
INFO - 2023-03-17 02:49:58 --> Router Class Initialized
INFO - 2023-03-17 02:49:58 --> Output Class Initialized
INFO - 2023-03-17 02:49:58 --> Security Class Initialized
DEBUG - 2023-03-17 02:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:49:58 --> Input Class Initialized
INFO - 2023-03-17 02:49:58 --> Language Class Initialized
INFO - 2023-03-17 02:49:58 --> Loader Class Initialized
INFO - 2023-03-17 02:49:58 --> Controller Class Initialized
DEBUG - 2023-03-17 02:49:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:49:58 --> Database Driver Class Initialized
INFO - 2023-03-17 02:49:58 --> Model "Login_model" initialized
INFO - 2023-03-17 02:49:58 --> Final output sent to browser
DEBUG - 2023-03-17 02:49:58 --> Total execution time: 0.0134
INFO - 2023-03-17 02:50:05 --> Config Class Initialized
INFO - 2023-03-17 02:50:05 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:50:05 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:50:05 --> Utf8 Class Initialized
INFO - 2023-03-17 02:50:05 --> URI Class Initialized
INFO - 2023-03-17 02:50:05 --> Router Class Initialized
INFO - 2023-03-17 02:50:05 --> Output Class Initialized
INFO - 2023-03-17 02:50:05 --> Security Class Initialized
DEBUG - 2023-03-17 02:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:50:05 --> Input Class Initialized
INFO - 2023-03-17 02:50:05 --> Language Class Initialized
INFO - 2023-03-17 02:50:05 --> Loader Class Initialized
INFO - 2023-03-17 02:50:05 --> Controller Class Initialized
DEBUG - 2023-03-17 02:50:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:50:05 --> Final output sent to browser
DEBUG - 2023-03-17 02:50:05 --> Total execution time: 0.0039
INFO - 2023-03-17 02:50:05 --> Config Class Initialized
INFO - 2023-03-17 02:50:05 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:50:05 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:50:05 --> Utf8 Class Initialized
INFO - 2023-03-17 02:50:05 --> URI Class Initialized
INFO - 2023-03-17 02:50:05 --> Router Class Initialized
INFO - 2023-03-17 02:50:05 --> Output Class Initialized
INFO - 2023-03-17 02:50:05 --> Security Class Initialized
DEBUG - 2023-03-17 02:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:50:05 --> Input Class Initialized
INFO - 2023-03-17 02:50:05 --> Language Class Initialized
INFO - 2023-03-17 02:50:05 --> Loader Class Initialized
INFO - 2023-03-17 02:50:05 --> Controller Class Initialized
DEBUG - 2023-03-17 02:50:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:50:05 --> Database Driver Class Initialized
INFO - 2023-03-17 02:50:05 --> Model "Login_model" initialized
ERROR - 2023-03-17 02:50:05 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS shard_max_dalay (id int unsigned NOT NULL AUTO_INCREMENT,shard_id int unsigned NOT NULL,db_cluster_id int unsigned NOT NULL,user_id int unsigned NOT NULL,max_delay_time int NOT NULL DEFAULT '100',when_created timestamp NULL DEFAULT CURRENT_TIMESTAMP,update_time timestamp NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (id)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
ERROR - 2023-03-17 02:50:05 --> Query error: The MySQL server is running with the --read-only option so it cannot execute this statement - Invalid query: CREATE TABLE IF NOT EXISTS shard_max_dalay (id int unsigned NOT NULL AUTO_INCREMENT,shard_id int unsigned NOT NULL,db_cluster_id int unsigned NOT NULL,user_id int unsigned NOT NULL,max_delay_time int NOT NULL DEFAULT '100',when_created timestamp NULL DEFAULT CURRENT_TIMESTAMP,update_time timestamp NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY (id)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;
INFO - 2023-03-17 02:50:05 --> Final output sent to browser
DEBUG - 2023-03-17 02:50:05 --> Total execution time: 0.0177
INFO - 2023-03-17 02:50:10 --> Config Class Initialized
INFO - 2023-03-17 02:50:10 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:50:10 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:50:10 --> Utf8 Class Initialized
INFO - 2023-03-17 02:50:10 --> URI Class Initialized
INFO - 2023-03-17 02:50:10 --> Router Class Initialized
INFO - 2023-03-17 02:50:10 --> Output Class Initialized
INFO - 2023-03-17 02:50:10 --> Security Class Initialized
DEBUG - 2023-03-17 02:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:50:10 --> Input Class Initialized
INFO - 2023-03-17 02:50:10 --> Language Class Initialized
INFO - 2023-03-17 02:50:10 --> Loader Class Initialized
INFO - 2023-03-17 02:50:10 --> Controller Class Initialized
DEBUG - 2023-03-17 02:50:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:50:10 --> Database Driver Class Initialized
INFO - 2023-03-17 02:50:10 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:50:10 --> Final output sent to browser
DEBUG - 2023-03-17 02:50:10 --> Total execution time: 0.0204
INFO - 2023-03-17 02:50:10 --> Config Class Initialized
INFO - 2023-03-17 02:50:10 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:50:10 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:50:10 --> Utf8 Class Initialized
INFO - 2023-03-17 02:50:10 --> URI Class Initialized
INFO - 2023-03-17 02:50:10 --> Router Class Initialized
INFO - 2023-03-17 02:50:10 --> Output Class Initialized
INFO - 2023-03-17 02:50:10 --> Security Class Initialized
DEBUG - 2023-03-17 02:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:50:10 --> Input Class Initialized
INFO - 2023-03-17 02:50:10 --> Language Class Initialized
INFO - 2023-03-17 02:50:10 --> Loader Class Initialized
INFO - 2023-03-17 02:50:10 --> Controller Class Initialized
DEBUG - 2023-03-17 02:50:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:50:10 --> Database Driver Class Initialized
INFO - 2023-03-17 02:50:10 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:50:10 --> Final output sent to browser
DEBUG - 2023-03-17 02:50:10 --> Total execution time: 0.0521
INFO - 2023-03-17 02:50:11 --> Config Class Initialized
INFO - 2023-03-17 02:50:11 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:50:11 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:50:11 --> Utf8 Class Initialized
INFO - 2023-03-17 02:50:11 --> URI Class Initialized
INFO - 2023-03-17 02:50:11 --> Router Class Initialized
INFO - 2023-03-17 02:50:11 --> Output Class Initialized
INFO - 2023-03-17 02:50:11 --> Security Class Initialized
DEBUG - 2023-03-17 02:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:50:11 --> Input Class Initialized
INFO - 2023-03-17 02:50:11 --> Language Class Initialized
INFO - 2023-03-17 02:50:11 --> Loader Class Initialized
INFO - 2023-03-17 02:50:11 --> Controller Class Initialized
DEBUG - 2023-03-17 02:50:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:50:11 --> Database Driver Class Initialized
INFO - 2023-03-17 02:50:11 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:50:11 --> Final output sent to browser
DEBUG - 2023-03-17 02:50:11 --> Total execution time: 0.0492
INFO - 2023-03-17 02:50:11 --> Config Class Initialized
INFO - 2023-03-17 02:50:11 --> Hooks Class Initialized
DEBUG - 2023-03-17 02:50:11 --> UTF-8 Support Enabled
INFO - 2023-03-17 02:50:11 --> Utf8 Class Initialized
INFO - 2023-03-17 02:50:11 --> URI Class Initialized
INFO - 2023-03-17 02:50:11 --> Router Class Initialized
INFO - 2023-03-17 02:50:11 --> Output Class Initialized
INFO - 2023-03-17 02:50:11 --> Security Class Initialized
DEBUG - 2023-03-17 02:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 02:50:11 --> Input Class Initialized
INFO - 2023-03-17 02:50:11 --> Language Class Initialized
INFO - 2023-03-17 02:50:11 --> Loader Class Initialized
INFO - 2023-03-17 02:50:11 --> Controller Class Initialized
DEBUG - 2023-03-17 02:50:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 02:50:11 --> Database Driver Class Initialized
INFO - 2023-03-17 02:50:11 --> Model "Cluster_model" initialized
INFO - 2023-03-17 02:50:11 --> Final output sent to browser
DEBUG - 2023-03-17 02:50:11 --> Total execution time: 0.0926
INFO - 2023-03-17 03:31:13 --> Config Class Initialized
INFO - 2023-03-17 03:31:13 --> Config Class Initialized
INFO - 2023-03-17 03:31:13 --> Hooks Class Initialized
INFO - 2023-03-17 03:31:13 --> Hooks Class Initialized
DEBUG - 2023-03-17 03:31:13 --> UTF-8 Support Enabled
DEBUG - 2023-03-17 03:31:13 --> UTF-8 Support Enabled
INFO - 2023-03-17 03:31:13 --> Utf8 Class Initialized
INFO - 2023-03-17 03:31:13 --> Utf8 Class Initialized
INFO - 2023-03-17 03:31:13 --> URI Class Initialized
INFO - 2023-03-17 03:31:13 --> URI Class Initialized
INFO - 2023-03-17 03:31:13 --> Router Class Initialized
INFO - 2023-03-17 03:31:13 --> Router Class Initialized
INFO - 2023-03-17 03:31:13 --> Output Class Initialized
INFO - 2023-03-17 03:31:13 --> Output Class Initialized
INFO - 2023-03-17 03:31:13 --> Security Class Initialized
INFO - 2023-03-17 03:31:13 --> Security Class Initialized
DEBUG - 2023-03-17 03:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-17 03:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 03:31:13 --> Input Class Initialized
INFO - 2023-03-17 03:31:13 --> Input Class Initialized
INFO - 2023-03-17 03:31:13 --> Language Class Initialized
INFO - 2023-03-17 03:31:13 --> Language Class Initialized
INFO - 2023-03-17 03:31:13 --> Loader Class Initialized
INFO - 2023-03-17 03:31:13 --> Loader Class Initialized
INFO - 2023-03-17 03:31:13 --> Controller Class Initialized
INFO - 2023-03-17 03:31:13 --> Controller Class Initialized
DEBUG - 2023-03-17 03:31:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-17 03:31:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 03:31:13 --> Final output sent to browser
DEBUG - 2023-03-17 03:31:13 --> Total execution time: 0.0067
INFO - 2023-03-17 03:31:13 --> Database Driver Class Initialized
INFO - 2023-03-17 03:31:13 --> Config Class Initialized
INFO - 2023-03-17 03:31:13 --> Hooks Class Initialized
DEBUG - 2023-03-17 03:31:13 --> UTF-8 Support Enabled
INFO - 2023-03-17 03:31:13 --> Utf8 Class Initialized
INFO - 2023-03-17 03:31:13 --> URI Class Initialized
INFO - 2023-03-17 03:31:13 --> Router Class Initialized
INFO - 2023-03-17 03:31:13 --> Output Class Initialized
INFO - 2023-03-17 03:31:13 --> Security Class Initialized
DEBUG - 2023-03-17 03:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 03:31:13 --> Input Class Initialized
INFO - 2023-03-17 03:31:13 --> Language Class Initialized
INFO - 2023-03-17 03:31:13 --> Loader Class Initialized
INFO - 2023-03-17 03:31:13 --> Controller Class Initialized
DEBUG - 2023-03-17 03:31:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 03:31:13 --> Database Driver Class Initialized
INFO - 2023-03-17 03:31:13 --> Model "Cluster_model" initialized
INFO - 2023-03-17 03:31:13 --> Model "Login_model" initialized
INFO - 2023-03-17 03:31:13 --> Database Driver Class Initialized
INFO - 2023-03-17 03:31:13 --> Final output sent to browser
DEBUG - 2023-03-17 03:31:13 --> Total execution time: 0.0681
INFO - 2023-03-17 03:31:13 --> Config Class Initialized
INFO - 2023-03-17 03:31:13 --> Hooks Class Initialized
DEBUG - 2023-03-17 03:31:13 --> UTF-8 Support Enabled
INFO - 2023-03-17 03:31:13 --> Utf8 Class Initialized
INFO - 2023-03-17 03:31:13 --> URI Class Initialized
INFO - 2023-03-17 03:31:13 --> Router Class Initialized
INFO - 2023-03-17 03:31:13 --> Output Class Initialized
INFO - 2023-03-17 03:31:13 --> Security Class Initialized
DEBUG - 2023-03-17 03:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 03:31:13 --> Input Class Initialized
INFO - 2023-03-17 03:31:13 --> Language Class Initialized
INFO - 2023-03-17 03:31:13 --> Loader Class Initialized
INFO - 2023-03-17 03:31:13 --> Controller Class Initialized
DEBUG - 2023-03-17 03:31:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 03:31:13 --> Database Driver Class Initialized
INFO - 2023-03-17 03:31:13 --> Model "Cluster_model" initialized
INFO - 2023-03-17 03:31:13 --> Final output sent to browser
DEBUG - 2023-03-17 03:31:13 --> Total execution time: 0.0643
INFO - 2023-03-17 03:31:13 --> Model "Cluster_model" initialized
INFO - 2023-03-17 03:31:13 --> Final output sent to browser
DEBUG - 2023-03-17 03:31:13 --> Total execution time: 0.0360
INFO - 2023-03-17 03:31:17 --> Config Class Initialized
INFO - 2023-03-17 03:31:17 --> Hooks Class Initialized
DEBUG - 2023-03-17 03:31:17 --> UTF-8 Support Enabled
INFO - 2023-03-17 03:31:17 --> Utf8 Class Initialized
INFO - 2023-03-17 03:31:17 --> URI Class Initialized
INFO - 2023-03-17 03:31:17 --> Router Class Initialized
INFO - 2023-03-17 03:31:17 --> Output Class Initialized
INFO - 2023-03-17 03:31:17 --> Security Class Initialized
DEBUG - 2023-03-17 03:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 03:31:17 --> Input Class Initialized
INFO - 2023-03-17 03:31:17 --> Language Class Initialized
INFO - 2023-03-17 03:31:17 --> Loader Class Initialized
INFO - 2023-03-17 03:31:17 --> Controller Class Initialized
DEBUG - 2023-03-17 03:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 03:31:17 --> Database Driver Class Initialized
INFO - 2023-03-17 03:31:17 --> Model "Cluster_model" initialized
INFO - 2023-03-17 03:31:17 --> Database Driver Class Initialized
INFO - 2023-03-17 03:31:17 --> Model "Login_model" initialized
INFO - 2023-03-17 03:31:17 --> Final output sent to browser
DEBUG - 2023-03-17 03:31:17 --> Total execution time: 0.0918
INFO - 2023-03-17 03:31:17 --> Config Class Initialized
INFO - 2023-03-17 03:31:17 --> Hooks Class Initialized
DEBUG - 2023-03-17 03:31:17 --> UTF-8 Support Enabled
INFO - 2023-03-17 03:31:17 --> Utf8 Class Initialized
INFO - 2023-03-17 03:31:17 --> URI Class Initialized
INFO - 2023-03-17 03:31:17 --> Router Class Initialized
INFO - 2023-03-17 03:31:17 --> Output Class Initialized
INFO - 2023-03-17 03:31:17 --> Security Class Initialized
DEBUG - 2023-03-17 03:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-17 03:31:17 --> Input Class Initialized
INFO - 2023-03-17 03:31:17 --> Language Class Initialized
INFO - 2023-03-17 03:31:17 --> Loader Class Initialized
INFO - 2023-03-17 03:31:17 --> Controller Class Initialized
DEBUG - 2023-03-17 03:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-17 03:31:17 --> Database Driver Class Initialized
INFO - 2023-03-17 03:31:17 --> Model "Cluster_model" initialized
INFO - 2023-03-17 03:31:17 --> Database Driver Class Initialized
INFO - 2023-03-17 03:31:17 --> Model "Login_model" initialized
INFO - 2023-03-17 03:31:17 --> Final output sent to browser
DEBUG - 2023-03-17 03:31:17 --> Total execution time: 0.1043
