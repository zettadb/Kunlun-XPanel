<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-08 07:36:17 --> Config Class Initialized
INFO - 2023-04-08 07:36:17 --> Hooks Class Initialized
DEBUG - 2023-04-08 07:36:17 --> UTF-8 Support Enabled
INFO - 2023-04-08 07:36:17 --> Utf8 Class Initialized
INFO - 2023-04-08 07:36:17 --> URI Class Initialized
INFO - 2023-04-08 07:36:17 --> Router Class Initialized
INFO - 2023-04-08 07:36:17 --> Output Class Initialized
INFO - 2023-04-08 07:36:17 --> Security Class Initialized
DEBUG - 2023-04-08 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-08 07:36:17 --> Input Class Initialized
INFO - 2023-04-08 07:36:17 --> Language Class Initialized
INFO - 2023-04-08 07:36:17 --> Loader Class Initialized
INFO - 2023-04-08 07:36:17 --> Controller Class Initialized
DEBUG - 2023-04-08 07:36:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-08 07:36:17 --> Database Driver Class Initialized
ERROR - 2023-04-08 07:36:27 --> Unable to connect to the database
INFO - 2023-04-08 07:36:27 --> Language file loaded: language/english/db_lang.php
