<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-10 05:45:18 --> Config Class Initialized
INFO - 2023-02-10 05:45:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:18 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:18 --> URI Class Initialized
INFO - 2023-02-10 05:45:18 --> Router Class Initialized
INFO - 2023-02-10 05:45:18 --> Output Class Initialized
INFO - 2023-02-10 05:45:18 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:18 --> Input Class Initialized
INFO - 2023-02-10 05:45:18 --> Language Class Initialized
INFO - 2023-02-10 05:45:18 --> Loader Class Initialized
INFO - 2023-02-10 05:45:18 --> Controller Class Initialized
INFO - 2023-02-10 05:45:18 --> Helper loaded: form_helper
INFO - 2023-02-10 05:45:18 --> Helper loaded: url_helper
DEBUG - 2023-02-10 05:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:18 --> Model "Change_model" initialized
INFO - 2023-02-10 05:45:18 --> Model "Grafana_model" initialized
INFO - 2023-02-10 05:45:18 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:18 --> Total execution time: 0.0639
INFO - 2023-02-10 05:45:18 --> Config Class Initialized
INFO - 2023-02-10 05:45:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:18 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:18 --> URI Class Initialized
INFO - 2023-02-10 05:45:18 --> Router Class Initialized
INFO - 2023-02-10 05:45:18 --> Output Class Initialized
INFO - 2023-02-10 05:45:18 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:18 --> Input Class Initialized
INFO - 2023-02-10 05:45:18 --> Language Class Initialized
INFO - 2023-02-10 05:45:18 --> Loader Class Initialized
INFO - 2023-02-10 05:45:18 --> Controller Class Initialized
INFO - 2023-02-10 05:45:18 --> Helper loaded: form_helper
INFO - 2023-02-10 05:45:18 --> Helper loaded: url_helper
DEBUG - 2023-02-10 05:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:18 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:18 --> Total execution time: 0.0427
INFO - 2023-02-10 05:45:18 --> Config Class Initialized
INFO - 2023-02-10 05:45:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:18 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:18 --> URI Class Initialized
INFO - 2023-02-10 05:45:18 --> Router Class Initialized
INFO - 2023-02-10 05:45:18 --> Output Class Initialized
INFO - 2023-02-10 05:45:18 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:18 --> Input Class Initialized
INFO - 2023-02-10 05:45:18 --> Language Class Initialized
INFO - 2023-02-10 05:45:18 --> Loader Class Initialized
INFO - 2023-02-10 05:45:18 --> Controller Class Initialized
INFO - 2023-02-10 05:45:18 --> Helper loaded: form_helper
INFO - 2023-02-10 05:45:18 --> Helper loaded: url_helper
DEBUG - 2023-02-10 05:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:18 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:18 --> Model "Login_model" initialized
INFO - 2023-02-10 05:45:18 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:18 --> Total execution time: 0.0355
INFO - 2023-02-10 05:45:18 --> Config Class Initialized
INFO - 2023-02-10 05:45:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:18 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:18 --> URI Class Initialized
INFO - 2023-02-10 05:45:18 --> Router Class Initialized
INFO - 2023-02-10 05:45:18 --> Output Class Initialized
INFO - 2023-02-10 05:45:18 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:18 --> Input Class Initialized
INFO - 2023-02-10 05:45:18 --> Language Class Initialized
INFO - 2023-02-10 05:45:18 --> Loader Class Initialized
INFO - 2023-02-10 05:45:18 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:18 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:18 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:18 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:18 --> Total execution time: 0.0830
INFO - 2023-02-10 05:45:18 --> Config Class Initialized
INFO - 2023-02-10 05:45:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:18 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:18 --> URI Class Initialized
INFO - 2023-02-10 05:45:18 --> Router Class Initialized
INFO - 2023-02-10 05:45:18 --> Output Class Initialized
INFO - 2023-02-10 05:45:18 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:18 --> Input Class Initialized
INFO - 2023-02-10 05:45:18 --> Language Class Initialized
INFO - 2023-02-10 05:45:18 --> Loader Class Initialized
INFO - 2023-02-10 05:45:18 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:18 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:18 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:18 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:18 --> Total execution time: 0.0180
INFO - 2023-02-10 05:45:19 --> Config Class Initialized
INFO - 2023-02-10 05:45:19 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:19 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:19 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:19 --> URI Class Initialized
INFO - 2023-02-10 05:45:19 --> Router Class Initialized
INFO - 2023-02-10 05:45:19 --> Output Class Initialized
INFO - 2023-02-10 05:45:19 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:19 --> Input Class Initialized
INFO - 2023-02-10 05:45:19 --> Language Class Initialized
INFO - 2023-02-10 05:45:19 --> Loader Class Initialized
INFO - 2023-02-10 05:45:19 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:19 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:19 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:19 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:19 --> Model "Login_model" initialized
INFO - 2023-02-10 05:45:19 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:19 --> Total execution time: 0.0803
INFO - 2023-02-10 05:45:19 --> Config Class Initialized
INFO - 2023-02-10 05:45:19 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:19 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:19 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:19 --> URI Class Initialized
INFO - 2023-02-10 05:45:19 --> Router Class Initialized
INFO - 2023-02-10 05:45:19 --> Output Class Initialized
INFO - 2023-02-10 05:45:19 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:19 --> Input Class Initialized
INFO - 2023-02-10 05:45:19 --> Language Class Initialized
INFO - 2023-02-10 05:45:19 --> Loader Class Initialized
INFO - 2023-02-10 05:45:19 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:19 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:19 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:19 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:19 --> Model "Login_model" initialized
INFO - 2023-02-10 05:45:19 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:19 --> Total execution time: 0.0402
INFO - 2023-02-10 05:45:25 --> Config Class Initialized
INFO - 2023-02-10 05:45:25 --> Config Class Initialized
INFO - 2023-02-10 05:45:25 --> Hooks Class Initialized
INFO - 2023-02-10 05:45:25 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:25 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 05:45:25 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:25 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:25 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:25 --> URI Class Initialized
INFO - 2023-02-10 05:45:25 --> URI Class Initialized
INFO - 2023-02-10 05:45:25 --> Router Class Initialized
INFO - 2023-02-10 05:45:25 --> Router Class Initialized
INFO - 2023-02-10 05:45:25 --> Output Class Initialized
INFO - 2023-02-10 05:45:25 --> Output Class Initialized
INFO - 2023-02-10 05:45:25 --> Security Class Initialized
INFO - 2023-02-10 05:45:25 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 05:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:25 --> Input Class Initialized
INFO - 2023-02-10 05:45:25 --> Input Class Initialized
INFO - 2023-02-10 05:45:25 --> Language Class Initialized
INFO - 2023-02-10 05:45:25 --> Language Class Initialized
INFO - 2023-02-10 05:45:25 --> Loader Class Initialized
INFO - 2023-02-10 05:45:25 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:25 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:25 --> Loader Class Initialized
INFO - 2023-02-10 05:45:25 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:25 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:25 --> Total execution time: 0.0069
INFO - 2023-02-10 05:45:25 --> Config Class Initialized
INFO - 2023-02-10 05:45:25 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:25 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:25 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:25 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:25 --> URI Class Initialized
INFO - 2023-02-10 05:45:25 --> Router Class Initialized
INFO - 2023-02-10 05:45:25 --> Output Class Initialized
INFO - 2023-02-10 05:45:25 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:25 --> Input Class Initialized
INFO - 2023-02-10 05:45:25 --> Language Class Initialized
INFO - 2023-02-10 05:45:25 --> Loader Class Initialized
INFO - 2023-02-10 05:45:25 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:25 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:25 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:25 --> Total execution time: 0.0533
INFO - 2023-02-10 05:45:25 --> Config Class Initialized
INFO - 2023-02-10 05:45:25 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:25 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:25 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:25 --> URI Class Initialized
INFO - 2023-02-10 05:45:25 --> Router Class Initialized
INFO - 2023-02-10 05:45:25 --> Output Class Initialized
INFO - 2023-02-10 05:45:25 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:25 --> Input Class Initialized
INFO - 2023-02-10 05:45:25 --> Language Class Initialized
INFO - 2023-02-10 05:45:25 --> Loader Class Initialized
INFO - 2023-02-10 05:45:25 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:25 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:25 --> Model "Login_model" initialized
INFO - 2023-02-10 05:45:25 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:25 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:25 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:25 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:25 --> Total execution time: 0.0625
INFO - 2023-02-10 05:45:25 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:25 --> Total execution time: 0.0175
INFO - 2023-02-10 05:45:27 --> Config Class Initialized
INFO - 2023-02-10 05:45:27 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:27 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:27 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:27 --> URI Class Initialized
INFO - 2023-02-10 05:45:27 --> Router Class Initialized
INFO - 2023-02-10 05:45:27 --> Output Class Initialized
INFO - 2023-02-10 05:45:27 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:27 --> Input Class Initialized
INFO - 2023-02-10 05:45:27 --> Language Class Initialized
INFO - 2023-02-10 05:45:27 --> Loader Class Initialized
INFO - 2023-02-10 05:45:27 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:27 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:27 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:27 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:27 --> Total execution time: 0.0152
INFO - 2023-02-10 05:45:27 --> Config Class Initialized
INFO - 2023-02-10 05:45:27 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:27 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:27 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:27 --> URI Class Initialized
INFO - 2023-02-10 05:45:27 --> Router Class Initialized
INFO - 2023-02-10 05:45:27 --> Output Class Initialized
INFO - 2023-02-10 05:45:27 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:27 --> Input Class Initialized
INFO - 2023-02-10 05:45:27 --> Language Class Initialized
INFO - 2023-02-10 05:45:27 --> Loader Class Initialized
INFO - 2023-02-10 05:45:27 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:27 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:27 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:27 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:27 --> Total execution time: 0.0917
INFO - 2023-02-10 05:45:29 --> Config Class Initialized
INFO - 2023-02-10 05:45:29 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:29 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:29 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:29 --> URI Class Initialized
INFO - 2023-02-10 05:45:29 --> Router Class Initialized
INFO - 2023-02-10 05:45:29 --> Output Class Initialized
INFO - 2023-02-10 05:45:29 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:29 --> Input Class Initialized
INFO - 2023-02-10 05:45:29 --> Language Class Initialized
INFO - 2023-02-10 05:45:29 --> Loader Class Initialized
INFO - 2023-02-10 05:45:29 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:29 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:29 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:29 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:29 --> Total execution time: 0.0529
INFO - 2023-02-10 05:45:29 --> Config Class Initialized
INFO - 2023-02-10 05:45:29 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:29 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:29 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:29 --> URI Class Initialized
INFO - 2023-02-10 05:45:29 --> Router Class Initialized
INFO - 2023-02-10 05:45:29 --> Output Class Initialized
INFO - 2023-02-10 05:45:29 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:29 --> Input Class Initialized
INFO - 2023-02-10 05:45:29 --> Language Class Initialized
INFO - 2023-02-10 05:45:29 --> Loader Class Initialized
INFO - 2023-02-10 05:45:29 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:29 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:29 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:29 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:29 --> Total execution time: 0.0744
INFO - 2023-02-10 05:45:32 --> Config Class Initialized
INFO - 2023-02-10 05:45:32 --> Config Class Initialized
INFO - 2023-02-10 05:45:32 --> Hooks Class Initialized
INFO - 2023-02-10 05:45:32 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 05:45:32 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:32 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:32 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:32 --> URI Class Initialized
INFO - 2023-02-10 05:45:32 --> URI Class Initialized
INFO - 2023-02-10 05:45:32 --> Router Class Initialized
INFO - 2023-02-10 05:45:32 --> Router Class Initialized
INFO - 2023-02-10 05:45:32 --> Output Class Initialized
INFO - 2023-02-10 05:45:32 --> Output Class Initialized
INFO - 2023-02-10 05:45:32 --> Security Class Initialized
INFO - 2023-02-10 05:45:32 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 05:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:32 --> Input Class Initialized
INFO - 2023-02-10 05:45:32 --> Input Class Initialized
INFO - 2023-02-10 05:45:32 --> Language Class Initialized
INFO - 2023-02-10 05:45:32 --> Language Class Initialized
INFO - 2023-02-10 05:45:32 --> Loader Class Initialized
INFO - 2023-02-10 05:45:32 --> Loader Class Initialized
INFO - 2023-02-10 05:45:32 --> Controller Class Initialized
INFO - 2023-02-10 05:45:32 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 05:45:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:32 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:32 --> Total execution time: 0.0038
INFO - 2023-02-10 05:45:32 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:32 --> Config Class Initialized
INFO - 2023-02-10 05:45:32 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:32 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:32 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:32 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:32 --> URI Class Initialized
INFO - 2023-02-10 05:45:32 --> Router Class Initialized
INFO - 2023-02-10 05:45:32 --> Output Class Initialized
INFO - 2023-02-10 05:45:32 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:32 --> Input Class Initialized
INFO - 2023-02-10 05:45:32 --> Language Class Initialized
INFO - 2023-02-10 05:45:32 --> Loader Class Initialized
INFO - 2023-02-10 05:45:32 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:32 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:32 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:32 --> Total execution time: 0.0560
INFO - 2023-02-10 05:45:32 --> Config Class Initialized
INFO - 2023-02-10 05:45:32 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:32 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:32 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:32 --> Model "Login_model" initialized
INFO - 2023-02-10 05:45:32 --> URI Class Initialized
INFO - 2023-02-10 05:45:32 --> Router Class Initialized
INFO - 2023-02-10 05:45:32 --> Output Class Initialized
INFO - 2023-02-10 05:45:32 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:32 --> Input Class Initialized
INFO - 2023-02-10 05:45:32 --> Language Class Initialized
INFO - 2023-02-10 05:45:32 --> Loader Class Initialized
INFO - 2023-02-10 05:45:32 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:32 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:32 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:32 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:32 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:32 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:32 --> Total execution time: 0.0649
INFO - 2023-02-10 05:45:32 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:32 --> Total execution time: 0.0143
INFO - 2023-02-10 05:45:44 --> Config Class Initialized
INFO - 2023-02-10 05:45:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:44 --> URI Class Initialized
INFO - 2023-02-10 05:45:44 --> Router Class Initialized
INFO - 2023-02-10 05:45:44 --> Output Class Initialized
INFO - 2023-02-10 05:45:44 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:44 --> Input Class Initialized
INFO - 2023-02-10 05:45:44 --> Language Class Initialized
INFO - 2023-02-10 05:45:44 --> Loader Class Initialized
INFO - 2023-02-10 05:45:44 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:44 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:44 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:44 --> Total execution time: 0.0399
INFO - 2023-02-10 05:45:44 --> Config Class Initialized
INFO - 2023-02-10 05:45:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:44 --> URI Class Initialized
INFO - 2023-02-10 05:45:44 --> Router Class Initialized
INFO - 2023-02-10 05:45:44 --> Output Class Initialized
INFO - 2023-02-10 05:45:44 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:44 --> Input Class Initialized
INFO - 2023-02-10 05:45:44 --> Language Class Initialized
INFO - 2023-02-10 05:45:44 --> Loader Class Initialized
INFO - 2023-02-10 05:45:44 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:44 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:44 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:44 --> Total execution time: 0.0773
INFO - 2023-02-10 05:45:47 --> Config Class Initialized
INFO - 2023-02-10 05:45:47 --> Hooks Class Initialized
INFO - 2023-02-10 05:45:47 --> Config Class Initialized
DEBUG - 2023-02-10 05:45:47 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:47 --> Hooks Class Initialized
INFO - 2023-02-10 05:45:47 --> Utf8 Class Initialized
DEBUG - 2023-02-10 05:45:47 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:47 --> URI Class Initialized
INFO - 2023-02-10 05:45:47 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:47 --> URI Class Initialized
INFO - 2023-02-10 05:45:47 --> Router Class Initialized
INFO - 2023-02-10 05:45:47 --> Output Class Initialized
INFO - 2023-02-10 05:45:47 --> Router Class Initialized
INFO - 2023-02-10 05:45:47 --> Output Class Initialized
INFO - 2023-02-10 05:45:47 --> Security Class Initialized
INFO - 2023-02-10 05:45:47 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 05:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:47 --> Input Class Initialized
INFO - 2023-02-10 05:45:47 --> Input Class Initialized
INFO - 2023-02-10 05:45:47 --> Language Class Initialized
INFO - 2023-02-10 05:45:47 --> Language Class Initialized
INFO - 2023-02-10 05:45:47 --> Loader Class Initialized
INFO - 2023-02-10 05:45:47 --> Loader Class Initialized
INFO - 2023-02-10 05:45:47 --> Controller Class Initialized
INFO - 2023-02-10 05:45:47 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 05:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:47 --> Final output sent to browser
INFO - 2023-02-10 05:45:47 --> Database Driver Class Initialized
DEBUG - 2023-02-10 05:45:47 --> Total execution time: 0.0048
INFO - 2023-02-10 05:45:47 --> Config Class Initialized
INFO - 2023-02-10 05:45:47 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:47 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:47 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:47 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:47 --> URI Class Initialized
INFO - 2023-02-10 05:45:47 --> Router Class Initialized
INFO - 2023-02-10 05:45:47 --> Output Class Initialized
INFO - 2023-02-10 05:45:47 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:47 --> Input Class Initialized
INFO - 2023-02-10 05:45:47 --> Language Class Initialized
INFO - 2023-02-10 05:45:47 --> Loader Class Initialized
INFO - 2023-02-10 05:45:47 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:47 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:47 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:47 --> Total execution time: 0.0506
INFO - 2023-02-10 05:45:47 --> Config Class Initialized
INFO - 2023-02-10 05:45:47 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:47 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:47 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:47 --> URI Class Initialized
INFO - 2023-02-10 05:45:47 --> Router Class Initialized
INFO - 2023-02-10 05:45:47 --> Output Class Initialized
INFO - 2023-02-10 05:45:47 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:47 --> Input Class Initialized
INFO - 2023-02-10 05:45:47 --> Language Class Initialized
INFO - 2023-02-10 05:45:47 --> Loader Class Initialized
INFO - 2023-02-10 05:45:47 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:47 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:47 --> Model "Login_model" initialized
INFO - 2023-02-10 05:45:47 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:47 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:47 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:47 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:47 --> Total execution time: 0.0584
INFO - 2023-02-10 05:45:47 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:47 --> Total execution time: 0.0133
INFO - 2023-02-10 05:45:49 --> Config Class Initialized
INFO - 2023-02-10 05:45:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:49 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:49 --> URI Class Initialized
INFO - 2023-02-10 05:45:49 --> Router Class Initialized
INFO - 2023-02-10 05:45:49 --> Output Class Initialized
INFO - 2023-02-10 05:45:49 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:49 --> Input Class Initialized
INFO - 2023-02-10 05:45:49 --> Language Class Initialized
INFO - 2023-02-10 05:45:49 --> Loader Class Initialized
INFO - 2023-02-10 05:45:49 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:49 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:49 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:49 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:49 --> Total execution time: 0.0507
INFO - 2023-02-10 05:45:50 --> Config Class Initialized
INFO - 2023-02-10 05:45:50 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:50 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:50 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:50 --> URI Class Initialized
INFO - 2023-02-10 05:45:50 --> Router Class Initialized
INFO - 2023-02-10 05:45:50 --> Output Class Initialized
INFO - 2023-02-10 05:45:50 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:50 --> Input Class Initialized
INFO - 2023-02-10 05:45:50 --> Language Class Initialized
INFO - 2023-02-10 05:45:50 --> Loader Class Initialized
INFO - 2023-02-10 05:45:50 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:50 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:50 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:50 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:51 --> Model "Login_model" initialized
INFO - 2023-02-10 05:45:51 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:51 --> Total execution time: 0.0419
INFO - 2023-02-10 05:45:51 --> Config Class Initialized
INFO - 2023-02-10 05:45:51 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:51 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:51 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:51 --> URI Class Initialized
INFO - 2023-02-10 05:45:51 --> Router Class Initialized
INFO - 2023-02-10 05:45:51 --> Output Class Initialized
INFO - 2023-02-10 05:45:51 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:51 --> Input Class Initialized
INFO - 2023-02-10 05:45:51 --> Language Class Initialized
INFO - 2023-02-10 05:45:51 --> Loader Class Initialized
INFO - 2023-02-10 05:45:51 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:51 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:51 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:51 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:51 --> Model "Login_model" initialized
INFO - 2023-02-10 05:45:51 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:51 --> Total execution time: 0.0786
INFO - 2023-02-10 05:45:55 --> Config Class Initialized
INFO - 2023-02-10 05:45:55 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:55 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:55 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:55 --> URI Class Initialized
INFO - 2023-02-10 05:45:55 --> Router Class Initialized
INFO - 2023-02-10 05:45:55 --> Output Class Initialized
INFO - 2023-02-10 05:45:55 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:55 --> Input Class Initialized
INFO - 2023-02-10 05:45:55 --> Language Class Initialized
INFO - 2023-02-10 05:45:55 --> Loader Class Initialized
INFO - 2023-02-10 05:45:55 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:55 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:55 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:55 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:55 --> Total execution time: 0.0541
INFO - 2023-02-10 05:45:55 --> Config Class Initialized
INFO - 2023-02-10 05:45:55 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:55 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:55 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:55 --> URI Class Initialized
INFO - 2023-02-10 05:45:55 --> Router Class Initialized
INFO - 2023-02-10 05:45:55 --> Output Class Initialized
INFO - 2023-02-10 05:45:55 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:55 --> Input Class Initialized
INFO - 2023-02-10 05:45:55 --> Language Class Initialized
INFO - 2023-02-10 05:45:55 --> Loader Class Initialized
INFO - 2023-02-10 05:45:55 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:55 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:55 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:55 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:55 --> Total execution time: 0.0111
INFO - 2023-02-10 05:45:58 --> Config Class Initialized
INFO - 2023-02-10 05:45:58 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:58 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:58 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:58 --> URI Class Initialized
INFO - 2023-02-10 05:45:58 --> Router Class Initialized
INFO - 2023-02-10 05:45:58 --> Output Class Initialized
INFO - 2023-02-10 05:45:58 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:58 --> Input Class Initialized
INFO - 2023-02-10 05:45:58 --> Language Class Initialized
INFO - 2023-02-10 05:45:58 --> Loader Class Initialized
INFO - 2023-02-10 05:45:58 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:58 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:58 --> Total execution time: 0.0472
INFO - 2023-02-10 05:45:58 --> Config Class Initialized
INFO - 2023-02-10 05:45:58 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:45:58 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:45:58 --> Utf8 Class Initialized
INFO - 2023-02-10 05:45:58 --> URI Class Initialized
INFO - 2023-02-10 05:45:58 --> Router Class Initialized
INFO - 2023-02-10 05:45:58 --> Output Class Initialized
INFO - 2023-02-10 05:45:58 --> Security Class Initialized
DEBUG - 2023-02-10 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:45:58 --> Input Class Initialized
INFO - 2023-02-10 05:45:58 --> Language Class Initialized
INFO - 2023-02-10 05:45:58 --> Loader Class Initialized
INFO - 2023-02-10 05:45:58 --> Controller Class Initialized
DEBUG - 2023-02-10 05:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:45:58 --> Database Driver Class Initialized
INFO - 2023-02-10 05:45:58 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:45:58 --> Final output sent to browser
DEBUG - 2023-02-10 05:45:58 --> Total execution time: 0.0545
INFO - 2023-02-10 05:46:00 --> Config Class Initialized
INFO - 2023-02-10 05:46:00 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:00 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:00 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:00 --> URI Class Initialized
INFO - 2023-02-10 05:46:00 --> Router Class Initialized
INFO - 2023-02-10 05:46:00 --> Output Class Initialized
INFO - 2023-02-10 05:46:00 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:00 --> Input Class Initialized
INFO - 2023-02-10 05:46:00 --> Language Class Initialized
INFO - 2023-02-10 05:46:00 --> Loader Class Initialized
INFO - 2023-02-10 05:46:00 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:00 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:00 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:46:00 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:00 --> Total execution time: 0.0310
INFO - 2023-02-10 05:46:00 --> Config Class Initialized
INFO - 2023-02-10 05:46:00 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:00 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:00 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:00 --> URI Class Initialized
INFO - 2023-02-10 05:46:00 --> Router Class Initialized
INFO - 2023-02-10 05:46:00 --> Output Class Initialized
INFO - 2023-02-10 05:46:00 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:00 --> Input Class Initialized
INFO - 2023-02-10 05:46:00 --> Language Class Initialized
INFO - 2023-02-10 05:46:00 --> Loader Class Initialized
INFO - 2023-02-10 05:46:00 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:00 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:00 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:46:00 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:00 --> Total execution time: 0.0181
INFO - 2023-02-10 05:46:06 --> Config Class Initialized
INFO - 2023-02-10 05:46:06 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:06 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:06 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:06 --> URI Class Initialized
INFO - 2023-02-10 05:46:06 --> Router Class Initialized
INFO - 2023-02-10 05:46:06 --> Output Class Initialized
INFO - 2023-02-10 05:46:06 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:06 --> Input Class Initialized
INFO - 2023-02-10 05:46:06 --> Language Class Initialized
INFO - 2023-02-10 05:46:06 --> Loader Class Initialized
INFO - 2023-02-10 05:46:06 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:06 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:06 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:06 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:06 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:06 --> Total execution time: 0.0243
INFO - 2023-02-10 05:46:06 --> Config Class Initialized
INFO - 2023-02-10 05:46:06 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:06 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:06 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:06 --> URI Class Initialized
INFO - 2023-02-10 05:46:06 --> Router Class Initialized
INFO - 2023-02-10 05:46:06 --> Output Class Initialized
INFO - 2023-02-10 05:46:06 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:06 --> Input Class Initialized
INFO - 2023-02-10 05:46:06 --> Language Class Initialized
INFO - 2023-02-10 05:46:06 --> Loader Class Initialized
INFO - 2023-02-10 05:46:06 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:06 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:06 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:06 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:06 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:06 --> Total execution time: 0.0242
INFO - 2023-02-10 05:46:10 --> Config Class Initialized
INFO - 2023-02-10 05:46:10 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:10 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:10 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:10 --> URI Class Initialized
INFO - 2023-02-10 05:46:10 --> Router Class Initialized
INFO - 2023-02-10 05:46:10 --> Output Class Initialized
INFO - 2023-02-10 05:46:10 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:10 --> Input Class Initialized
INFO - 2023-02-10 05:46:10 --> Language Class Initialized
INFO - 2023-02-10 05:46:10 --> Loader Class Initialized
INFO - 2023-02-10 05:46:10 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:10 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:11 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:11 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:11 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:11 --> Total execution time: 0.0275
INFO - 2023-02-10 05:46:11 --> Config Class Initialized
INFO - 2023-02-10 05:46:11 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:11 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:11 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:11 --> URI Class Initialized
INFO - 2023-02-10 05:46:11 --> Router Class Initialized
INFO - 2023-02-10 05:46:11 --> Output Class Initialized
INFO - 2023-02-10 05:46:11 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:11 --> Input Class Initialized
INFO - 2023-02-10 05:46:11 --> Language Class Initialized
INFO - 2023-02-10 05:46:11 --> Loader Class Initialized
INFO - 2023-02-10 05:46:11 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:11 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:11 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:11 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:11 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:11 --> Total execution time: 0.0195
INFO - 2023-02-10 05:46:13 --> Config Class Initialized
INFO - 2023-02-10 05:46:13 --> Config Class Initialized
INFO - 2023-02-10 05:46:13 --> Hooks Class Initialized
INFO - 2023-02-10 05:46:13 --> Config Class Initialized
INFO - 2023-02-10 05:46:13 --> Hooks Class Initialized
INFO - 2023-02-10 05:46:13 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:13 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:13 --> Utf8 Class Initialized
DEBUG - 2023-02-10 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:13 --> URI Class Initialized
INFO - 2023-02-10 05:46:13 --> URI Class Initialized
INFO - 2023-02-10 05:46:13 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:13 --> Router Class Initialized
INFO - 2023-02-10 05:46:13 --> Router Class Initialized
INFO - 2023-02-10 05:46:13 --> URI Class Initialized
INFO - 2023-02-10 05:46:13 --> Output Class Initialized
INFO - 2023-02-10 05:46:13 --> Output Class Initialized
INFO - 2023-02-10 05:46:13 --> Router Class Initialized
INFO - 2023-02-10 05:46:13 --> Security Class Initialized
INFO - 2023-02-10 05:46:13 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:13 --> Output Class Initialized
INFO - 2023-02-10 05:46:13 --> Input Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:13 --> Security Class Initialized
INFO - 2023-02-10 05:46:13 --> Language Class Initialized
INFO - 2023-02-10 05:46:13 --> Input Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:13 --> Language Class Initialized
INFO - 2023-02-10 05:46:13 --> Input Class Initialized
INFO - 2023-02-10 05:46:13 --> Loader Class Initialized
INFO - 2023-02-10 05:46:13 --> Language Class Initialized
INFO - 2023-02-10 05:46:13 --> Loader Class Initialized
INFO - 2023-02-10 05:46:13 --> Controller Class Initialized
INFO - 2023-02-10 05:46:13 --> Controller Class Initialized
INFO - 2023-02-10 05:46:13 --> Loader Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:13 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> Final output sent to browser
INFO - 2023-02-10 05:46:13 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:13 --> Total execution time: 0.0354
DEBUG - 2023-02-10 05:46:13 --> Total execution time: 0.0357
INFO - 2023-02-10 05:46:13 --> Config Class Initialized
INFO - 2023-02-10 05:46:13 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:13 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:13 --> URI Class Initialized
INFO - 2023-02-10 05:46:13 --> Router Class Initialized
INFO - 2023-02-10 05:46:13 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:13 --> Config Class Initialized
INFO - 2023-02-10 05:46:13 --> Hooks Class Initialized
INFO - 2023-02-10 05:46:13 --> Output Class Initialized
DEBUG - 2023-02-10 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:13 --> Security Class Initialized
INFO - 2023-02-10 05:46:13 --> Utf8 Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:13 --> URI Class Initialized
INFO - 2023-02-10 05:46:13 --> Input Class Initialized
INFO - 2023-02-10 05:46:13 --> Router Class Initialized
INFO - 2023-02-10 05:46:13 --> Language Class Initialized
INFO - 2023-02-10 05:46:13 --> Output Class Initialized
INFO - 2023-02-10 05:46:13 --> Security Class Initialized
INFO - 2023-02-10 05:46:13 --> Loader Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:13 --> Controller Class Initialized
INFO - 2023-02-10 05:46:13 --> Input Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:13 --> Language Class Initialized
INFO - 2023-02-10 05:46:13 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:13 --> Total execution time: 0.0435
INFO - 2023-02-10 05:46:13 --> Loader Class Initialized
INFO - 2023-02-10 05:46:13 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:13 --> Config Class Initialized
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:13 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:13 --> URI Class Initialized
INFO - 2023-02-10 05:46:13 --> Router Class Initialized
INFO - 2023-02-10 05:46:13 --> Output Class Initialized
INFO - 2023-02-10 05:46:13 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:13 --> Input Class Initialized
INFO - 2023-02-10 05:46:13 --> Language Class Initialized
INFO - 2023-02-10 05:46:13 --> Loader Class Initialized
INFO - 2023-02-10 05:46:13 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:13 --> Total execution time: 0.0840
INFO - 2023-02-10 05:46:13 --> Config Class Initialized
INFO - 2023-02-10 05:46:13 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:13 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> Config Class Initialized
INFO - 2023-02-10 05:46:13 --> Hooks Class Initialized
INFO - 2023-02-10 05:46:13 --> URI Class Initialized
INFO - 2023-02-10 05:46:13 --> Router Class Initialized
DEBUG - 2023-02-10 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:13 --> Output Class Initialized
INFO - 2023-02-10 05:46:13 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:13 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:13 --> Input Class Initialized
INFO - 2023-02-10 05:46:13 --> Language Class Initialized
INFO - 2023-02-10 05:46:13 --> Loader Class Initialized
INFO - 2023-02-10 05:46:13 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> URI Class Initialized
INFO - 2023-02-10 05:46:13 --> Router Class Initialized
INFO - 2023-02-10 05:46:13 --> Output Class Initialized
INFO - 2023-02-10 05:46:13 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:13 --> Input Class Initialized
INFO - 2023-02-10 05:46:13 --> Language Class Initialized
INFO - 2023-02-10 05:46:13 --> Loader Class Initialized
INFO - 2023-02-10 05:46:13 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:13 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:13 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:13 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:13 --> Final output sent to browser
INFO - 2023-02-10 05:46:13 --> Database Driver Class Initialized
DEBUG - 2023-02-10 05:46:13 --> Total execution time: 0.0994
INFO - 2023-02-10 05:46:13 --> Final output sent to browser
INFO - 2023-02-10 05:46:13 --> Model "Cluster_model" initialized
DEBUG - 2023-02-10 05:46:13 --> Total execution time: 0.0579
INFO - 2023-02-10 05:46:13 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:13 --> Total execution time: 0.0956
INFO - 2023-02-10 05:46:13 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:13 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:13 --> Total execution time: 0.1645
INFO - 2023-02-10 05:46:17 --> Config Class Initialized
INFO - 2023-02-10 05:46:17 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:17 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:17 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:17 --> URI Class Initialized
INFO - 2023-02-10 05:46:17 --> Router Class Initialized
INFO - 2023-02-10 05:46:17 --> Output Class Initialized
INFO - 2023-02-10 05:46:17 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:17 --> Input Class Initialized
INFO - 2023-02-10 05:46:17 --> Language Class Initialized
INFO - 2023-02-10 05:46:17 --> Loader Class Initialized
INFO - 2023-02-10 05:46:17 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:17 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:17 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:17 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:17 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:17 --> Total execution time: 0.0210
INFO - 2023-02-10 05:46:17 --> Config Class Initialized
INFO - 2023-02-10 05:46:17 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:17 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:17 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:17 --> URI Class Initialized
INFO - 2023-02-10 05:46:17 --> Router Class Initialized
INFO - 2023-02-10 05:46:17 --> Output Class Initialized
INFO - 2023-02-10 05:46:17 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:17 --> Input Class Initialized
INFO - 2023-02-10 05:46:17 --> Language Class Initialized
INFO - 2023-02-10 05:46:17 --> Loader Class Initialized
INFO - 2023-02-10 05:46:17 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:17 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:17 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:17 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:17 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:17 --> Total execution time: 0.0660
INFO - 2023-02-10 05:46:18 --> Config Class Initialized
INFO - 2023-02-10 05:46:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:18 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:18 --> URI Class Initialized
INFO - 2023-02-10 05:46:18 --> Router Class Initialized
INFO - 2023-02-10 05:46:18 --> Output Class Initialized
INFO - 2023-02-10 05:46:18 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:18 --> Input Class Initialized
INFO - 2023-02-10 05:46:18 --> Language Class Initialized
INFO - 2023-02-10 05:46:18 --> Loader Class Initialized
INFO - 2023-02-10 05:46:18 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:18 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:18 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:18 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:18 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:18 --> Total execution time: 0.0690
INFO - 2023-02-10 05:46:18 --> Config Class Initialized
INFO - 2023-02-10 05:46:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:18 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:18 --> URI Class Initialized
INFO - 2023-02-10 05:46:18 --> Router Class Initialized
INFO - 2023-02-10 05:46:18 --> Output Class Initialized
INFO - 2023-02-10 05:46:18 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:18 --> Input Class Initialized
INFO - 2023-02-10 05:46:18 --> Language Class Initialized
INFO - 2023-02-10 05:46:18 --> Loader Class Initialized
INFO - 2023-02-10 05:46:18 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:18 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:18 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:18 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:18 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:18 --> Total execution time: 0.0622
INFO - 2023-02-10 05:46:41 --> Config Class Initialized
INFO - 2023-02-10 05:46:41 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:41 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:41 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:41 --> URI Class Initialized
INFO - 2023-02-10 05:46:41 --> Router Class Initialized
INFO - 2023-02-10 05:46:41 --> Output Class Initialized
INFO - 2023-02-10 05:46:41 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:41 --> Input Class Initialized
INFO - 2023-02-10 05:46:41 --> Language Class Initialized
INFO - 2023-02-10 05:46:41 --> Loader Class Initialized
INFO - 2023-02-10 05:46:41 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:41 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:41 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:41 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:41 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:41 --> Total execution time: 0.0191
INFO - 2023-02-10 05:46:41 --> Config Class Initialized
INFO - 2023-02-10 05:46:41 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:41 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:41 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:41 --> URI Class Initialized
INFO - 2023-02-10 05:46:41 --> Router Class Initialized
INFO - 2023-02-10 05:46:41 --> Output Class Initialized
INFO - 2023-02-10 05:46:41 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:41 --> Input Class Initialized
INFO - 2023-02-10 05:46:41 --> Language Class Initialized
INFO - 2023-02-10 05:46:41 --> Loader Class Initialized
INFO - 2023-02-10 05:46:41 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:41 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:41 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:41 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:41 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:41 --> Total execution time: 0.0179
INFO - 2023-02-10 05:46:44 --> Config Class Initialized
INFO - 2023-02-10 05:46:44 --> Config Class Initialized
INFO - 2023-02-10 05:46:44 --> Hooks Class Initialized
INFO - 2023-02-10 05:46:44 --> Config Class Initialized
INFO - 2023-02-10 05:46:44 --> Hooks Class Initialized
INFO - 2023-02-10 05:46:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:44 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:44 --> URI Class Initialized
DEBUG - 2023-02-10 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:44 --> URI Class Initialized
INFO - 2023-02-10 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:44 --> Router Class Initialized
INFO - 2023-02-10 05:46:44 --> Router Class Initialized
INFO - 2023-02-10 05:46:44 --> URI Class Initialized
INFO - 2023-02-10 05:46:44 --> Output Class Initialized
INFO - 2023-02-10 05:46:44 --> Output Class Initialized
INFO - 2023-02-10 05:46:44 --> Router Class Initialized
INFO - 2023-02-10 05:46:44 --> Security Class Initialized
INFO - 2023-02-10 05:46:44 --> Security Class Initialized
INFO - 2023-02-10 05:46:44 --> Output Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:44 --> Input Class Initialized
INFO - 2023-02-10 05:46:44 --> Security Class Initialized
INFO - 2023-02-10 05:46:44 --> Input Class Initialized
INFO - 2023-02-10 05:46:44 --> Language Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:44 --> Language Class Initialized
INFO - 2023-02-10 05:46:44 --> Input Class Initialized
INFO - 2023-02-10 05:46:44 --> Loader Class Initialized
INFO - 2023-02-10 05:46:44 --> Language Class Initialized
INFO - 2023-02-10 05:46:44 --> Loader Class Initialized
INFO - 2023-02-10 05:46:44 --> Controller Class Initialized
INFO - 2023-02-10 05:46:44 --> Loader Class Initialized
INFO - 2023-02-10 05:46:44 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:44 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:44 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:44 --> Total execution time: 0.0135
INFO - 2023-02-10 05:46:44 --> Config Class Initialized
INFO - 2023-02-10 05:46:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:44 --> URI Class Initialized
INFO - 2023-02-10 05:46:44 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:44 --> Final output sent to browser
INFO - 2023-02-10 05:46:44 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:44 --> Total execution time: 0.0161
DEBUG - 2023-02-10 05:46:44 --> Total execution time: 0.0236
INFO - 2023-02-10 05:46:44 --> Router Class Initialized
INFO - 2023-02-10 05:46:44 --> Output Class Initialized
INFO - 2023-02-10 05:46:44 --> Security Class Initialized
INFO - 2023-02-10 05:46:44 --> Config Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:44 --> Hooks Class Initialized
INFO - 2023-02-10 05:46:44 --> Input Class Initialized
DEBUG - 2023-02-10 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:44 --> Language Class Initialized
INFO - 2023-02-10 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:44 --> URI Class Initialized
INFO - 2023-02-10 05:46:44 --> Loader Class Initialized
INFO - 2023-02-10 05:46:44 --> Router Class Initialized
INFO - 2023-02-10 05:46:44 --> Config Class Initialized
INFO - 2023-02-10 05:46:44 --> Controller Class Initialized
INFO - 2023-02-10 05:46:44 --> Output Class Initialized
INFO - 2023-02-10 05:46:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:44 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:44 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:44 --> Final output sent to browser
INFO - 2023-02-10 05:46:44 --> Input Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Total execution time: 0.0831
INFO - 2023-02-10 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:44 --> Language Class Initialized
INFO - 2023-02-10 05:46:44 --> URI Class Initialized
INFO - 2023-02-10 05:46:44 --> Loader Class Initialized
INFO - 2023-02-10 05:46:44 --> Router Class Initialized
INFO - 2023-02-10 05:46:44 --> Controller Class Initialized
INFO - 2023-02-10 05:46:44 --> Output Class Initialized
INFO - 2023-02-10 05:46:44 --> Config Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:44 --> Security Class Initialized
INFO - 2023-02-10 05:46:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:44 --> Input Class Initialized
DEBUG - 2023-02-10 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:44 --> Language Class Initialized
INFO - 2023-02-10 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:44 --> Loader Class Initialized
INFO - 2023-02-10 05:46:44 --> URI Class Initialized
INFO - 2023-02-10 05:46:44 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:44 --> Router Class Initialized
INFO - 2023-02-10 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:44 --> Output Class Initialized
INFO - 2023-02-10 05:46:44 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:44 --> Input Class Initialized
INFO - 2023-02-10 05:46:44 --> Language Class Initialized
INFO - 2023-02-10 05:46:44 --> Loader Class Initialized
INFO - 2023-02-10 05:46:44 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:44 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:44 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:44 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:44 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:44 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:44 --> Total execution time: 0.0195
INFO - 2023-02-10 05:46:44 --> Config Class Initialized
INFO - 2023-02-10 05:46:44 --> Final output sent to browser
INFO - 2023-02-10 05:46:44 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:44 --> Total execution time: 0.0643
INFO - 2023-02-10 05:46:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:44 --> Total execution time: 0.0609
DEBUG - 2023-02-10 05:46:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:44 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:44 --> URI Class Initialized
INFO - 2023-02-10 05:46:44 --> Router Class Initialized
INFO - 2023-02-10 05:46:45 --> Output Class Initialized
INFO - 2023-02-10 05:46:45 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:45 --> Input Class Initialized
INFO - 2023-02-10 05:46:45 --> Language Class Initialized
INFO - 2023-02-10 05:46:45 --> Loader Class Initialized
INFO - 2023-02-10 05:46:45 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:45 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:45 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:45 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:45 --> Model "Cluster_model" initialized
INFO - 2023-02-10 05:46:45 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:45 --> Total execution time: 0.0993
INFO - 2023-02-10 05:46:47 --> Config Class Initialized
INFO - 2023-02-10 05:46:47 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:47 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:47 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:47 --> URI Class Initialized
INFO - 2023-02-10 05:46:47 --> Router Class Initialized
INFO - 2023-02-10 05:46:47 --> Output Class Initialized
INFO - 2023-02-10 05:46:47 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:47 --> Input Class Initialized
INFO - 2023-02-10 05:46:47 --> Language Class Initialized
INFO - 2023-02-10 05:46:47 --> Loader Class Initialized
INFO - 2023-02-10 05:46:47 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:47 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:47 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:47 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:47 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:47 --> Total execution time: 0.0222
INFO - 2023-02-10 05:46:47 --> Config Class Initialized
INFO - 2023-02-10 05:46:47 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:47 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:47 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:47 --> URI Class Initialized
INFO - 2023-02-10 05:46:47 --> Router Class Initialized
INFO - 2023-02-10 05:46:47 --> Output Class Initialized
INFO - 2023-02-10 05:46:47 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:47 --> Input Class Initialized
INFO - 2023-02-10 05:46:47 --> Language Class Initialized
INFO - 2023-02-10 05:46:47 --> Loader Class Initialized
INFO - 2023-02-10 05:46:47 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:47 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:47 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:47 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:47 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:47 --> Total execution time: 0.0168
INFO - 2023-02-10 05:46:49 --> Config Class Initialized
INFO - 2023-02-10 05:46:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:49 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:49 --> URI Class Initialized
INFO - 2023-02-10 05:46:49 --> Router Class Initialized
INFO - 2023-02-10 05:46:49 --> Output Class Initialized
INFO - 2023-02-10 05:46:49 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:49 --> Input Class Initialized
INFO - 2023-02-10 05:46:49 --> Language Class Initialized
INFO - 2023-02-10 05:46:49 --> Loader Class Initialized
INFO - 2023-02-10 05:46:49 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:49 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:49 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:49 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:49 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:49 --> Total execution time: 0.0226
INFO - 2023-02-10 05:46:49 --> Config Class Initialized
INFO - 2023-02-10 05:46:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 05:46:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 05:46:49 --> Utf8 Class Initialized
INFO - 2023-02-10 05:46:49 --> URI Class Initialized
INFO - 2023-02-10 05:46:49 --> Router Class Initialized
INFO - 2023-02-10 05:46:49 --> Output Class Initialized
INFO - 2023-02-10 05:46:49 --> Security Class Initialized
DEBUG - 2023-02-10 05:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 05:46:49 --> Input Class Initialized
INFO - 2023-02-10 05:46:49 --> Language Class Initialized
INFO - 2023-02-10 05:46:49 --> Loader Class Initialized
INFO - 2023-02-10 05:46:49 --> Controller Class Initialized
DEBUG - 2023-02-10 05:46:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 05:46:49 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:49 --> Database Driver Class Initialized
INFO - 2023-02-10 05:46:49 --> Model "Login_model" initialized
INFO - 2023-02-10 05:46:49 --> Final output sent to browser
DEBUG - 2023-02-10 05:46:49 --> Total execution time: 0.0202
INFO - 2023-02-10 06:15:34 --> Config Class Initialized
INFO - 2023-02-10 06:15:34 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:34 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:34 --> URI Class Initialized
INFO - 2023-02-10 06:15:34 --> Router Class Initialized
INFO - 2023-02-10 06:15:34 --> Output Class Initialized
INFO - 2023-02-10 06:15:34 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:34 --> Input Class Initialized
INFO - 2023-02-10 06:15:34 --> Language Class Initialized
INFO - 2023-02-10 06:15:34 --> Loader Class Initialized
INFO - 2023-02-10 06:15:34 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:34 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:34 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:34 --> Total execution time: 0.0182
INFO - 2023-02-10 06:15:34 --> Config Class Initialized
INFO - 2023-02-10 06:15:34 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:34 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:34 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:34 --> URI Class Initialized
INFO - 2023-02-10 06:15:34 --> Router Class Initialized
INFO - 2023-02-10 06:15:34 --> Output Class Initialized
INFO - 2023-02-10 06:15:34 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:34 --> Input Class Initialized
INFO - 2023-02-10 06:15:34 --> Language Class Initialized
INFO - 2023-02-10 06:15:34 --> Loader Class Initialized
INFO - 2023-02-10 06:15:34 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:34 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:34 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:34 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:34 --> Total execution time: 0.0112
INFO - 2023-02-10 06:15:37 --> Config Class Initialized
INFO - 2023-02-10 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:37 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:37 --> URI Class Initialized
INFO - 2023-02-10 06:15:37 --> Router Class Initialized
INFO - 2023-02-10 06:15:37 --> Output Class Initialized
INFO - 2023-02-10 06:15:37 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:37 --> Input Class Initialized
INFO - 2023-02-10 06:15:37 --> Language Class Initialized
INFO - 2023-02-10 06:15:37 --> Loader Class Initialized
INFO - 2023-02-10 06:15:37 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:37 --> Model "Login_model" initialized
INFO - 2023-02-10 06:15:37 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:37 --> Total execution time: 0.0233
INFO - 2023-02-10 06:15:37 --> Config Class Initialized
INFO - 2023-02-10 06:15:37 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:37 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:37 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:37 --> URI Class Initialized
INFO - 2023-02-10 06:15:37 --> Router Class Initialized
INFO - 2023-02-10 06:15:37 --> Output Class Initialized
INFO - 2023-02-10 06:15:37 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:37 --> Input Class Initialized
INFO - 2023-02-10 06:15:37 --> Language Class Initialized
INFO - 2023-02-10 06:15:37 --> Loader Class Initialized
INFO - 2023-02-10 06:15:37 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:37 --> Model "Login_model" initialized
INFO - 2023-02-10 06:15:37 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:37 --> Total execution time: 0.0198
INFO - 2023-02-10 06:15:50 --> Config Class Initialized
INFO - 2023-02-10 06:15:50 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:50 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:50 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:50 --> URI Class Initialized
INFO - 2023-02-10 06:15:50 --> Router Class Initialized
INFO - 2023-02-10 06:15:50 --> Output Class Initialized
INFO - 2023-02-10 06:15:50 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:50 --> Input Class Initialized
INFO - 2023-02-10 06:15:50 --> Language Class Initialized
INFO - 2023-02-10 06:15:50 --> Loader Class Initialized
INFO - 2023-02-10 06:15:50 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:50 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:50 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:50 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:50 --> Total execution time: 0.0353
INFO - 2023-02-10 06:15:50 --> Config Class Initialized
INFO - 2023-02-10 06:15:50 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:50 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:50 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:50 --> URI Class Initialized
INFO - 2023-02-10 06:15:50 --> Router Class Initialized
INFO - 2023-02-10 06:15:50 --> Output Class Initialized
INFO - 2023-02-10 06:15:50 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:50 --> Input Class Initialized
INFO - 2023-02-10 06:15:50 --> Language Class Initialized
INFO - 2023-02-10 06:15:50 --> Loader Class Initialized
INFO - 2023-02-10 06:15:50 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:50 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:50 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:50 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:50 --> Total execution time: 0.0822
INFO - 2023-02-10 06:15:53 --> Config Class Initialized
INFO - 2023-02-10 06:15:53 --> Hooks Class Initialized
INFO - 2023-02-10 06:15:53 --> Config Class Initialized
DEBUG - 2023-02-10 06:15:53 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:53 --> Hooks Class Initialized
INFO - 2023-02-10 06:15:53 --> Utf8 Class Initialized
DEBUG - 2023-02-10 06:15:53 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:53 --> URI Class Initialized
INFO - 2023-02-10 06:15:53 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:53 --> Router Class Initialized
INFO - 2023-02-10 06:15:53 --> URI Class Initialized
INFO - 2023-02-10 06:15:53 --> Output Class Initialized
INFO - 2023-02-10 06:15:53 --> Router Class Initialized
INFO - 2023-02-10 06:15:53 --> Security Class Initialized
INFO - 2023-02-10 06:15:53 --> Output Class Initialized
DEBUG - 2023-02-10 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:53 --> Security Class Initialized
INFO - 2023-02-10 06:15:53 --> Input Class Initialized
DEBUG - 2023-02-10 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:53 --> Language Class Initialized
INFO - 2023-02-10 06:15:53 --> Input Class Initialized
INFO - 2023-02-10 06:15:53 --> Language Class Initialized
INFO - 2023-02-10 06:15:53 --> Loader Class Initialized
INFO - 2023-02-10 06:15:53 --> Loader Class Initialized
INFO - 2023-02-10 06:15:53 --> Controller Class Initialized
INFO - 2023-02-10 06:15:53 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:15:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:53 --> Final output sent to browser
INFO - 2023-02-10 06:15:53 --> Database Driver Class Initialized
DEBUG - 2023-02-10 06:15:53 --> Total execution time: 0.0041
INFO - 2023-02-10 06:15:53 --> Config Class Initialized
INFO - 2023-02-10 06:15:53 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:53 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:53 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:53 --> URI Class Initialized
INFO - 2023-02-10 06:15:53 --> Router Class Initialized
INFO - 2023-02-10 06:15:53 --> Output Class Initialized
INFO - 2023-02-10 06:15:53 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:53 --> Input Class Initialized
INFO - 2023-02-10 06:15:53 --> Language Class Initialized
INFO - 2023-02-10 06:15:53 --> Loader Class Initialized
INFO - 2023-02-10 06:15:53 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:53 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:53 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:53 --> Model "Login_model" initialized
INFO - 2023-02-10 06:15:53 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:53 --> Total execution time: 0.0155
INFO - 2023-02-10 06:15:53 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:53 --> Config Class Initialized
INFO - 2023-02-10 06:15:53 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:53 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:53 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:53 --> URI Class Initialized
INFO - 2023-02-10 06:15:53 --> Router Class Initialized
INFO - 2023-02-10 06:15:53 --> Output Class Initialized
INFO - 2023-02-10 06:15:53 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:53 --> Input Class Initialized
INFO - 2023-02-10 06:15:53 --> Language Class Initialized
INFO - 2023-02-10 06:15:53 --> Loader Class Initialized
INFO - 2023-02-10 06:15:53 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:53 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:53 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:53 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:53 --> Total execution time: 0.0192
INFO - 2023-02-10 06:15:53 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:53 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:53 --> Total execution time: 0.0644
INFO - 2023-02-10 06:15:57 --> Config Class Initialized
INFO - 2023-02-10 06:15:57 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:57 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:57 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:57 --> URI Class Initialized
INFO - 2023-02-10 06:15:57 --> Router Class Initialized
INFO - 2023-02-10 06:15:57 --> Output Class Initialized
INFO - 2023-02-10 06:15:57 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:57 --> Input Class Initialized
INFO - 2023-02-10 06:15:57 --> Language Class Initialized
INFO - 2023-02-10 06:15:57 --> Loader Class Initialized
INFO - 2023-02-10 06:15:57 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:57 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:57 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:57 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:57 --> Total execution time: 0.0159
INFO - 2023-02-10 06:15:57 --> Config Class Initialized
INFO - 2023-02-10 06:15:57 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:57 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:57 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:57 --> URI Class Initialized
INFO - 2023-02-10 06:15:57 --> Router Class Initialized
INFO - 2023-02-10 06:15:57 --> Output Class Initialized
INFO - 2023-02-10 06:15:57 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:57 --> Input Class Initialized
INFO - 2023-02-10 06:15:57 --> Language Class Initialized
INFO - 2023-02-10 06:15:57 --> Loader Class Initialized
INFO - 2023-02-10 06:15:57 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:57 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:57 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:57 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:57 --> Total execution time: 0.0135
INFO - 2023-02-10 06:15:59 --> Config Class Initialized
INFO - 2023-02-10 06:15:59 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:59 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:59 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:59 --> URI Class Initialized
INFO - 2023-02-10 06:15:59 --> Router Class Initialized
INFO - 2023-02-10 06:15:59 --> Output Class Initialized
INFO - 2023-02-10 06:15:59 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:59 --> Input Class Initialized
INFO - 2023-02-10 06:15:59 --> Language Class Initialized
INFO - 2023-02-10 06:15:59 --> Loader Class Initialized
INFO - 2023-02-10 06:15:59 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:59 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:59 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:59 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:59 --> Total execution time: 0.0470
INFO - 2023-02-10 06:15:59 --> Config Class Initialized
INFO - 2023-02-10 06:15:59 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:15:59 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:15:59 --> Utf8 Class Initialized
INFO - 2023-02-10 06:15:59 --> URI Class Initialized
INFO - 2023-02-10 06:15:59 --> Router Class Initialized
INFO - 2023-02-10 06:15:59 --> Output Class Initialized
INFO - 2023-02-10 06:15:59 --> Security Class Initialized
DEBUG - 2023-02-10 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:15:59 --> Input Class Initialized
INFO - 2023-02-10 06:15:59 --> Language Class Initialized
INFO - 2023-02-10 06:15:59 --> Loader Class Initialized
INFO - 2023-02-10 06:15:59 --> Controller Class Initialized
DEBUG - 2023-02-10 06:15:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:15:59 --> Database Driver Class Initialized
INFO - 2023-02-10 06:15:59 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:15:59 --> Final output sent to browser
DEBUG - 2023-02-10 06:15:59 --> Total execution time: 0.0337
INFO - 2023-02-10 06:16:01 --> Config Class Initialized
INFO - 2023-02-10 06:16:01 --> Config Class Initialized
INFO - 2023-02-10 06:16:01 --> Hooks Class Initialized
INFO - 2023-02-10 06:16:01 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:01 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:16:01 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:01 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:01 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:01 --> URI Class Initialized
INFO - 2023-02-10 06:16:01 --> URI Class Initialized
INFO - 2023-02-10 06:16:01 --> Router Class Initialized
INFO - 2023-02-10 06:16:01 --> Router Class Initialized
INFO - 2023-02-10 06:16:01 --> Output Class Initialized
INFO - 2023-02-10 06:16:01 --> Output Class Initialized
INFO - 2023-02-10 06:16:01 --> Security Class Initialized
INFO - 2023-02-10 06:16:01 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:01 --> Input Class Initialized
INFO - 2023-02-10 06:16:01 --> Input Class Initialized
INFO - 2023-02-10 06:16:01 --> Language Class Initialized
INFO - 2023-02-10 06:16:01 --> Language Class Initialized
INFO - 2023-02-10 06:16:01 --> Loader Class Initialized
INFO - 2023-02-10 06:16:01 --> Loader Class Initialized
INFO - 2023-02-10 06:16:01 --> Controller Class Initialized
INFO - 2023-02-10 06:16:01 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:01 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:01 --> Total execution time: 0.0039
INFO - 2023-02-10 06:16:01 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:01 --> Config Class Initialized
INFO - 2023-02-10 06:16:01 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:01 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:01 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:01 --> URI Class Initialized
INFO - 2023-02-10 06:16:01 --> Router Class Initialized
INFO - 2023-02-10 06:16:01 --> Output Class Initialized
INFO - 2023-02-10 06:16:01 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:01 --> Input Class Initialized
INFO - 2023-02-10 06:16:01 --> Language Class Initialized
INFO - 2023-02-10 06:16:01 --> Loader Class Initialized
INFO - 2023-02-10 06:16:01 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:01 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:01 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:01 --> Model "Login_model" initialized
INFO - 2023-02-10 06:16:01 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:01 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:01 --> Total execution time: 0.0161
INFO - 2023-02-10 06:16:01 --> Config Class Initialized
INFO - 2023-02-10 06:16:01 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:01 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:01 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:01 --> URI Class Initialized
INFO - 2023-02-10 06:16:01 --> Router Class Initialized
INFO - 2023-02-10 06:16:01 --> Output Class Initialized
INFO - 2023-02-10 06:16:01 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:01 --> Input Class Initialized
INFO - 2023-02-10 06:16:01 --> Language Class Initialized
INFO - 2023-02-10 06:16:01 --> Loader Class Initialized
INFO - 2023-02-10 06:16:01 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:01 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:01 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:01 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:01 --> Total execution time: 0.0175
INFO - 2023-02-10 06:16:01 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:01 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:01 --> Total execution time: 0.0532
INFO - 2023-02-10 06:16:15 --> Config Class Initialized
INFO - 2023-02-10 06:16:15 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:15 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:15 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:15 --> URI Class Initialized
INFO - 2023-02-10 06:16:15 --> Router Class Initialized
INFO - 2023-02-10 06:16:15 --> Output Class Initialized
INFO - 2023-02-10 06:16:15 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:15 --> Input Class Initialized
INFO - 2023-02-10 06:16:15 --> Language Class Initialized
INFO - 2023-02-10 06:16:15 --> Loader Class Initialized
INFO - 2023-02-10 06:16:15 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:15 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:15 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:15 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:15 --> Total execution time: 0.0352
INFO - 2023-02-10 06:16:15 --> Config Class Initialized
INFO - 2023-02-10 06:16:15 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:15 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:15 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:15 --> URI Class Initialized
INFO - 2023-02-10 06:16:15 --> Router Class Initialized
INFO - 2023-02-10 06:16:15 --> Output Class Initialized
INFO - 2023-02-10 06:16:15 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:15 --> Input Class Initialized
INFO - 2023-02-10 06:16:15 --> Language Class Initialized
INFO - 2023-02-10 06:16:15 --> Loader Class Initialized
INFO - 2023-02-10 06:16:15 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:15 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:15 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:15 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:15 --> Total execution time: 0.0351
INFO - 2023-02-10 06:16:19 --> Config Class Initialized
INFO - 2023-02-10 06:16:19 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:19 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:19 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:19 --> URI Class Initialized
INFO - 2023-02-10 06:16:19 --> Router Class Initialized
INFO - 2023-02-10 06:16:19 --> Output Class Initialized
INFO - 2023-02-10 06:16:19 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:19 --> Input Class Initialized
INFO - 2023-02-10 06:16:19 --> Language Class Initialized
INFO - 2023-02-10 06:16:19 --> Loader Class Initialized
INFO - 2023-02-10 06:16:19 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:19 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:19 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:19 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:19 --> Total execution time: 0.0147
INFO - 2023-02-10 06:16:19 --> Config Class Initialized
INFO - 2023-02-10 06:16:19 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:19 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:19 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:19 --> URI Class Initialized
INFO - 2023-02-10 06:16:19 --> Router Class Initialized
INFO - 2023-02-10 06:16:19 --> Output Class Initialized
INFO - 2023-02-10 06:16:19 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:19 --> Input Class Initialized
INFO - 2023-02-10 06:16:19 --> Language Class Initialized
INFO - 2023-02-10 06:16:19 --> Loader Class Initialized
INFO - 2023-02-10 06:16:19 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:19 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:19 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:19 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:19 --> Total execution time: 0.0153
INFO - 2023-02-10 06:16:22 --> Config Class Initialized
INFO - 2023-02-10 06:16:22 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:22 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:22 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:22 --> URI Class Initialized
INFO - 2023-02-10 06:16:22 --> Router Class Initialized
INFO - 2023-02-10 06:16:22 --> Output Class Initialized
INFO - 2023-02-10 06:16:22 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:22 --> Input Class Initialized
INFO - 2023-02-10 06:16:22 --> Language Class Initialized
INFO - 2023-02-10 06:16:22 --> Loader Class Initialized
INFO - 2023-02-10 06:16:22 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:22 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:22 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:22 --> Final output sent to browser
INFO - 2023-02-10 06:16:22 --> Config Class Initialized
DEBUG - 2023-02-10 06:16:22 --> Total execution time: 0.0821
INFO - 2023-02-10 06:16:22 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:22 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:22 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:22 --> URI Class Initialized
INFO - 2023-02-10 06:16:22 --> Router Class Initialized
INFO - 2023-02-10 06:16:22 --> Output Class Initialized
INFO - 2023-02-10 06:16:22 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:22 --> Input Class Initialized
INFO - 2023-02-10 06:16:22 --> Language Class Initialized
INFO - 2023-02-10 06:16:22 --> Loader Class Initialized
INFO - 2023-02-10 06:16:22 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:22 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:22 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:22 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:22 --> Total execution time: 0.0729
INFO - 2023-02-10 06:16:23 --> Config Class Initialized
INFO - 2023-02-10 06:16:23 --> Config Class Initialized
INFO - 2023-02-10 06:16:23 --> Hooks Class Initialized
INFO - 2023-02-10 06:16:23 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:16:23 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:23 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:23 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:23 --> URI Class Initialized
INFO - 2023-02-10 06:16:23 --> URI Class Initialized
INFO - 2023-02-10 06:16:23 --> Router Class Initialized
INFO - 2023-02-10 06:16:23 --> Router Class Initialized
INFO - 2023-02-10 06:16:23 --> Output Class Initialized
INFO - 2023-02-10 06:16:23 --> Output Class Initialized
INFO - 2023-02-10 06:16:23 --> Security Class Initialized
INFO - 2023-02-10 06:16:23 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:23 --> Input Class Initialized
INFO - 2023-02-10 06:16:23 --> Input Class Initialized
INFO - 2023-02-10 06:16:23 --> Language Class Initialized
INFO - 2023-02-10 06:16:23 --> Language Class Initialized
INFO - 2023-02-10 06:16:23 --> Loader Class Initialized
INFO - 2023-02-10 06:16:23 --> Loader Class Initialized
INFO - 2023-02-10 06:16:23 --> Controller Class Initialized
INFO - 2023-02-10 06:16:23 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:16:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:23 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:23 --> Total execution time: 0.0039
INFO - 2023-02-10 06:16:23 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:23 --> Config Class Initialized
INFO - 2023-02-10 06:16:23 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:23 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:23 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:23 --> URI Class Initialized
INFO - 2023-02-10 06:16:23 --> Router Class Initialized
INFO - 2023-02-10 06:16:23 --> Output Class Initialized
INFO - 2023-02-10 06:16:23 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:23 --> Input Class Initialized
INFO - 2023-02-10 06:16:23 --> Language Class Initialized
INFO - 2023-02-10 06:16:23 --> Loader Class Initialized
INFO - 2023-02-10 06:16:23 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:23 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:23 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:23 --> Model "Login_model" initialized
INFO - 2023-02-10 06:16:23 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:23 --> Total execution time: 0.0179
INFO - 2023-02-10 06:16:23 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:23 --> Config Class Initialized
INFO - 2023-02-10 06:16:23 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:23 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:23 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:23 --> URI Class Initialized
INFO - 2023-02-10 06:16:23 --> Router Class Initialized
INFO - 2023-02-10 06:16:23 --> Output Class Initialized
INFO - 2023-02-10 06:16:23 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:23 --> Input Class Initialized
INFO - 2023-02-10 06:16:23 --> Language Class Initialized
INFO - 2023-02-10 06:16:23 --> Loader Class Initialized
INFO - 2023-02-10 06:16:23 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:23 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:23 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:23 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:23 --> Total execution time: 0.0228
INFO - 2023-02-10 06:16:23 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:23 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:23 --> Total execution time: 0.0531
INFO - 2023-02-10 06:16:47 --> Config Class Initialized
INFO - 2023-02-10 06:16:47 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:47 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:47 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:47 --> URI Class Initialized
INFO - 2023-02-10 06:16:47 --> Router Class Initialized
INFO - 2023-02-10 06:16:47 --> Output Class Initialized
INFO - 2023-02-10 06:16:47 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:47 --> Input Class Initialized
INFO - 2023-02-10 06:16:47 --> Language Class Initialized
INFO - 2023-02-10 06:16:47 --> Loader Class Initialized
INFO - 2023-02-10 06:16:47 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:47 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:47 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:47 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:47 --> Total execution time: 0.0135
INFO - 2023-02-10 06:16:47 --> Config Class Initialized
INFO - 2023-02-10 06:16:47 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:47 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:47 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:47 --> URI Class Initialized
INFO - 2023-02-10 06:16:47 --> Router Class Initialized
INFO - 2023-02-10 06:16:47 --> Output Class Initialized
INFO - 2023-02-10 06:16:47 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:47 --> Input Class Initialized
INFO - 2023-02-10 06:16:47 --> Language Class Initialized
INFO - 2023-02-10 06:16:47 --> Loader Class Initialized
INFO - 2023-02-10 06:16:47 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:47 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:47 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:47 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:47 --> Total execution time: 0.0118
INFO - 2023-02-10 06:16:49 --> Config Class Initialized
INFO - 2023-02-10 06:16:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:49 --> URI Class Initialized
INFO - 2023-02-10 06:16:49 --> Router Class Initialized
INFO - 2023-02-10 06:16:49 --> Output Class Initialized
INFO - 2023-02-10 06:16:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:49 --> Input Class Initialized
INFO - 2023-02-10 06:16:49 --> Language Class Initialized
INFO - 2023-02-10 06:16:49 --> Loader Class Initialized
INFO - 2023-02-10 06:16:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:49 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:49 --> Total execution time: 0.0422
INFO - 2023-02-10 06:16:49 --> Config Class Initialized
INFO - 2023-02-10 06:16:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:49 --> URI Class Initialized
INFO - 2023-02-10 06:16:49 --> Router Class Initialized
INFO - 2023-02-10 06:16:49 --> Output Class Initialized
INFO - 2023-02-10 06:16:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:49 --> Input Class Initialized
INFO - 2023-02-10 06:16:49 --> Language Class Initialized
INFO - 2023-02-10 06:16:49 --> Loader Class Initialized
INFO - 2023-02-10 06:16:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:49 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:49 --> Total execution time: 0.0344
INFO - 2023-02-10 06:16:52 --> Config Class Initialized
INFO - 2023-02-10 06:16:52 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:52 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:52 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:52 --> URI Class Initialized
INFO - 2023-02-10 06:16:52 --> Router Class Initialized
INFO - 2023-02-10 06:16:52 --> Output Class Initialized
INFO - 2023-02-10 06:16:52 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:52 --> Input Class Initialized
INFO - 2023-02-10 06:16:52 --> Language Class Initialized
INFO - 2023-02-10 06:16:52 --> Loader Class Initialized
INFO - 2023-02-10 06:16:52 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:52 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:52 --> Total execution time: 0.0048
INFO - 2023-02-10 06:16:52 --> Config Class Initialized
INFO - 2023-02-10 06:16:52 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:52 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:52 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:52 --> URI Class Initialized
INFO - 2023-02-10 06:16:52 --> Router Class Initialized
INFO - 2023-02-10 06:16:52 --> Output Class Initialized
INFO - 2023-02-10 06:16:52 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:52 --> Input Class Initialized
INFO - 2023-02-10 06:16:52 --> Language Class Initialized
INFO - 2023-02-10 06:16:52 --> Loader Class Initialized
INFO - 2023-02-10 06:16:52 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:52 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:52 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:52 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:52 --> Total execution time: 0.0131
INFO - 2023-02-10 06:16:55 --> Config Class Initialized
INFO - 2023-02-10 06:16:55 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:55 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:55 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:55 --> URI Class Initialized
INFO - 2023-02-10 06:16:55 --> Router Class Initialized
INFO - 2023-02-10 06:16:55 --> Output Class Initialized
INFO - 2023-02-10 06:16:55 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:55 --> Input Class Initialized
INFO - 2023-02-10 06:16:55 --> Language Class Initialized
INFO - 2023-02-10 06:16:55 --> Loader Class Initialized
INFO - 2023-02-10 06:16:55 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:55 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:55 --> Total execution time: 0.0754
INFO - 2023-02-10 06:16:55 --> Config Class Initialized
INFO - 2023-02-10 06:16:55 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:55 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:55 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:55 --> URI Class Initialized
INFO - 2023-02-10 06:16:55 --> Router Class Initialized
INFO - 2023-02-10 06:16:55 --> Output Class Initialized
INFO - 2023-02-10 06:16:55 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:55 --> Input Class Initialized
INFO - 2023-02-10 06:16:55 --> Language Class Initialized
INFO - 2023-02-10 06:16:55 --> Loader Class Initialized
INFO - 2023-02-10 06:16:55 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:55 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:55 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:55 --> Total execution time: 0.0169
INFO - 2023-02-10 06:16:56 --> Config Class Initialized
INFO - 2023-02-10 06:16:56 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:56 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:56 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:56 --> URI Class Initialized
INFO - 2023-02-10 06:16:56 --> Router Class Initialized
INFO - 2023-02-10 06:16:56 --> Output Class Initialized
INFO - 2023-02-10 06:16:56 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:56 --> Input Class Initialized
INFO - 2023-02-10 06:16:56 --> Language Class Initialized
INFO - 2023-02-10 06:16:56 --> Loader Class Initialized
INFO - 2023-02-10 06:16:56 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:56 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:56 --> Total execution time: 0.0045
INFO - 2023-02-10 06:16:56 --> Config Class Initialized
INFO - 2023-02-10 06:16:56 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:56 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:56 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:56 --> URI Class Initialized
INFO - 2023-02-10 06:16:56 --> Router Class Initialized
INFO - 2023-02-10 06:16:56 --> Output Class Initialized
INFO - 2023-02-10 06:16:56 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:56 --> Input Class Initialized
INFO - 2023-02-10 06:16:56 --> Language Class Initialized
INFO - 2023-02-10 06:16:56 --> Loader Class Initialized
INFO - 2023-02-10 06:16:56 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:56 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:56 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:56 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:56 --> Total execution time: 0.0133
INFO - 2023-02-10 06:16:59 --> Config Class Initialized
INFO - 2023-02-10 06:16:59 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:59 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:59 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:59 --> URI Class Initialized
INFO - 2023-02-10 06:16:59 --> Router Class Initialized
INFO - 2023-02-10 06:16:59 --> Output Class Initialized
INFO - 2023-02-10 06:16:59 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:59 --> Input Class Initialized
INFO - 2023-02-10 06:16:59 --> Language Class Initialized
INFO - 2023-02-10 06:16:59 --> Loader Class Initialized
INFO - 2023-02-10 06:16:59 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:59 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:59 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:59 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:59 --> Total execution time: 0.0388
INFO - 2023-02-10 06:16:59 --> Config Class Initialized
INFO - 2023-02-10 06:16:59 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:16:59 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:16:59 --> Utf8 Class Initialized
INFO - 2023-02-10 06:16:59 --> URI Class Initialized
INFO - 2023-02-10 06:16:59 --> Router Class Initialized
INFO - 2023-02-10 06:16:59 --> Output Class Initialized
INFO - 2023-02-10 06:16:59 --> Security Class Initialized
DEBUG - 2023-02-10 06:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:16:59 --> Input Class Initialized
INFO - 2023-02-10 06:16:59 --> Language Class Initialized
INFO - 2023-02-10 06:16:59 --> Loader Class Initialized
INFO - 2023-02-10 06:16:59 --> Controller Class Initialized
DEBUG - 2023-02-10 06:16:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:16:59 --> Database Driver Class Initialized
INFO - 2023-02-10 06:16:59 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:16:59 --> Final output sent to browser
DEBUG - 2023-02-10 06:16:59 --> Total execution time: 0.0344
INFO - 2023-02-10 06:17:01 --> Config Class Initialized
INFO - 2023-02-10 06:17:01 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:17:01 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:17:01 --> Utf8 Class Initialized
INFO - 2023-02-10 06:17:01 --> URI Class Initialized
INFO - 2023-02-10 06:17:01 --> Router Class Initialized
INFO - 2023-02-10 06:17:01 --> Output Class Initialized
INFO - 2023-02-10 06:17:01 --> Security Class Initialized
DEBUG - 2023-02-10 06:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:17:01 --> Input Class Initialized
INFO - 2023-02-10 06:17:01 --> Language Class Initialized
INFO - 2023-02-10 06:17:01 --> Loader Class Initialized
INFO - 2023-02-10 06:17:01 --> Controller Class Initialized
DEBUG - 2023-02-10 06:17:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:17:01 --> Database Driver Class Initialized
INFO - 2023-02-10 06:17:01 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:17:01 --> Final output sent to browser
DEBUG - 2023-02-10 06:17:01 --> Total execution time: 0.0168
INFO - 2023-02-10 06:17:01 --> Config Class Initialized
INFO - 2023-02-10 06:17:01 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:17:01 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:17:01 --> Utf8 Class Initialized
INFO - 2023-02-10 06:17:01 --> URI Class Initialized
INFO - 2023-02-10 06:17:01 --> Router Class Initialized
INFO - 2023-02-10 06:17:01 --> Output Class Initialized
INFO - 2023-02-10 06:17:01 --> Security Class Initialized
DEBUG - 2023-02-10 06:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:17:01 --> Input Class Initialized
INFO - 2023-02-10 06:17:01 --> Language Class Initialized
INFO - 2023-02-10 06:17:01 --> Loader Class Initialized
INFO - 2023-02-10 06:17:01 --> Controller Class Initialized
DEBUG - 2023-02-10 06:17:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:17:01 --> Database Driver Class Initialized
INFO - 2023-02-10 06:17:01 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:17:01 --> Final output sent to browser
DEBUG - 2023-02-10 06:17:01 --> Total execution time: 0.0110
INFO - 2023-02-10 06:17:05 --> Config Class Initialized
INFO - 2023-02-10 06:17:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:17:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:17:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:17:05 --> URI Class Initialized
INFO - 2023-02-10 06:17:05 --> Router Class Initialized
INFO - 2023-02-10 06:17:05 --> Output Class Initialized
INFO - 2023-02-10 06:17:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:17:05 --> Input Class Initialized
INFO - 2023-02-10 06:17:05 --> Language Class Initialized
INFO - 2023-02-10 06:17:05 --> Loader Class Initialized
INFO - 2023-02-10 06:17:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:17:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:17:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:17:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:17:05 --> Model "Login_model" initialized
INFO - 2023-02-10 06:17:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:17:05 --> Total execution time: 0.0284
INFO - 2023-02-10 06:17:05 --> Config Class Initialized
INFO - 2023-02-10 06:17:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:17:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:17:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:17:05 --> URI Class Initialized
INFO - 2023-02-10 06:17:05 --> Router Class Initialized
INFO - 2023-02-10 06:17:05 --> Output Class Initialized
INFO - 2023-02-10 06:17:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:17:05 --> Input Class Initialized
INFO - 2023-02-10 06:17:05 --> Language Class Initialized
INFO - 2023-02-10 06:17:05 --> Loader Class Initialized
INFO - 2023-02-10 06:17:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:17:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:17:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:17:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:17:05 --> Model "Login_model" initialized
INFO - 2023-02-10 06:17:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:17:05 --> Total execution time: 0.0173
INFO - 2023-02-10 06:18:33 --> Config Class Initialized
INFO - 2023-02-10 06:18:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:18:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:18:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:18:33 --> URI Class Initialized
INFO - 2023-02-10 06:18:33 --> Router Class Initialized
INFO - 2023-02-10 06:18:33 --> Output Class Initialized
INFO - 2023-02-10 06:18:33 --> Security Class Initialized
DEBUG - 2023-02-10 06:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:18:33 --> Input Class Initialized
INFO - 2023-02-10 06:18:33 --> Language Class Initialized
INFO - 2023-02-10 06:18:33 --> Loader Class Initialized
INFO - 2023-02-10 06:18:33 --> Controller Class Initialized
DEBUG - 2023-02-10 06:18:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:18:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:18:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:18:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:18:33 --> Total execution time: 0.0196
INFO - 2023-02-10 06:18:33 --> Config Class Initialized
INFO - 2023-02-10 06:18:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:18:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:18:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:18:33 --> URI Class Initialized
INFO - 2023-02-10 06:18:33 --> Router Class Initialized
INFO - 2023-02-10 06:18:33 --> Output Class Initialized
INFO - 2023-02-10 06:18:33 --> Security Class Initialized
DEBUG - 2023-02-10 06:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:18:33 --> Input Class Initialized
INFO - 2023-02-10 06:18:33 --> Language Class Initialized
INFO - 2023-02-10 06:18:33 --> Loader Class Initialized
INFO - 2023-02-10 06:18:33 --> Controller Class Initialized
DEBUG - 2023-02-10 06:18:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:18:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:18:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:18:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:18:33 --> Total execution time: 0.0554
INFO - 2023-02-10 06:21:09 --> Config Class Initialized
INFO - 2023-02-10 06:21:09 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:21:09 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:21:09 --> Utf8 Class Initialized
INFO - 2023-02-10 06:21:09 --> URI Class Initialized
INFO - 2023-02-10 06:21:09 --> Router Class Initialized
INFO - 2023-02-10 06:21:09 --> Output Class Initialized
INFO - 2023-02-10 06:21:09 --> Security Class Initialized
DEBUG - 2023-02-10 06:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:21:09 --> Input Class Initialized
INFO - 2023-02-10 06:21:09 --> Language Class Initialized
INFO - 2023-02-10 06:21:09 --> Loader Class Initialized
INFO - 2023-02-10 06:21:09 --> Controller Class Initialized
DEBUG - 2023-02-10 06:21:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:21:09 --> Database Driver Class Initialized
INFO - 2023-02-10 06:21:09 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:21:09 --> Final output sent to browser
DEBUG - 2023-02-10 06:21:09 --> Total execution time: 0.0164
INFO - 2023-02-10 06:21:09 --> Config Class Initialized
INFO - 2023-02-10 06:21:09 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:21:09 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:21:09 --> Utf8 Class Initialized
INFO - 2023-02-10 06:21:09 --> URI Class Initialized
INFO - 2023-02-10 06:21:09 --> Router Class Initialized
INFO - 2023-02-10 06:21:09 --> Output Class Initialized
INFO - 2023-02-10 06:21:09 --> Security Class Initialized
DEBUG - 2023-02-10 06:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:21:09 --> Input Class Initialized
INFO - 2023-02-10 06:21:09 --> Language Class Initialized
INFO - 2023-02-10 06:21:09 --> Loader Class Initialized
INFO - 2023-02-10 06:21:09 --> Controller Class Initialized
DEBUG - 2023-02-10 06:21:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:21:09 --> Database Driver Class Initialized
INFO - 2023-02-10 06:21:09 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:21:09 --> Final output sent to browser
DEBUG - 2023-02-10 06:21:09 --> Total execution time: 0.0571
INFO - 2023-02-10 06:21:10 --> Config Class Initialized
INFO - 2023-02-10 06:21:10 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:21:10 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:21:10 --> Utf8 Class Initialized
INFO - 2023-02-10 06:21:10 --> URI Class Initialized
INFO - 2023-02-10 06:21:10 --> Router Class Initialized
INFO - 2023-02-10 06:21:10 --> Output Class Initialized
INFO - 2023-02-10 06:21:10 --> Security Class Initialized
DEBUG - 2023-02-10 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:21:10 --> Input Class Initialized
INFO - 2023-02-10 06:21:10 --> Language Class Initialized
INFO - 2023-02-10 06:21:10 --> Loader Class Initialized
INFO - 2023-02-10 06:21:10 --> Controller Class Initialized
DEBUG - 2023-02-10 06:21:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:21:10 --> Database Driver Class Initialized
INFO - 2023-02-10 06:21:10 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:21:10 --> Final output sent to browser
DEBUG - 2023-02-10 06:21:10 --> Total execution time: 0.0440
INFO - 2023-02-10 06:21:10 --> Config Class Initialized
INFO - 2023-02-10 06:21:10 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:21:10 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:21:10 --> Utf8 Class Initialized
INFO - 2023-02-10 06:21:10 --> URI Class Initialized
INFO - 2023-02-10 06:21:10 --> Router Class Initialized
INFO - 2023-02-10 06:21:10 --> Output Class Initialized
INFO - 2023-02-10 06:21:10 --> Security Class Initialized
DEBUG - 2023-02-10 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:21:10 --> Input Class Initialized
INFO - 2023-02-10 06:21:10 --> Language Class Initialized
INFO - 2023-02-10 06:21:10 --> Loader Class Initialized
INFO - 2023-02-10 06:21:10 --> Controller Class Initialized
DEBUG - 2023-02-10 06:21:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:21:10 --> Database Driver Class Initialized
INFO - 2023-02-10 06:21:10 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:21:10 --> Final output sent to browser
DEBUG - 2023-02-10 06:21:10 --> Total execution time: 0.0113
INFO - 2023-02-10 06:23:08 --> Config Class Initialized
INFO - 2023-02-10 06:23:08 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:08 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:08 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:08 --> URI Class Initialized
INFO - 2023-02-10 06:23:08 --> Router Class Initialized
INFO - 2023-02-10 06:23:08 --> Output Class Initialized
INFO - 2023-02-10 06:23:08 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:08 --> Input Class Initialized
INFO - 2023-02-10 06:23:08 --> Language Class Initialized
INFO - 2023-02-10 06:23:08 --> Loader Class Initialized
INFO - 2023-02-10 06:23:08 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:08 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:08 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:08 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:08 --> Total execution time: 0.0557
INFO - 2023-02-10 06:23:08 --> Config Class Initialized
INFO - 2023-02-10 06:23:09 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:09 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:09 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:09 --> URI Class Initialized
INFO - 2023-02-10 06:23:09 --> Router Class Initialized
INFO - 2023-02-10 06:23:09 --> Output Class Initialized
INFO - 2023-02-10 06:23:09 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:09 --> Input Class Initialized
INFO - 2023-02-10 06:23:09 --> Language Class Initialized
INFO - 2023-02-10 06:23:09 --> Loader Class Initialized
INFO - 2023-02-10 06:23:09 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:09 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:09 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:09 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:09 --> Total execution time: 0.0853
INFO - 2023-02-10 06:23:09 --> Config Class Initialized
INFO - 2023-02-10 06:23:09 --> Config Class Initialized
INFO - 2023-02-10 06:23:09 --> Hooks Class Initialized
INFO - 2023-02-10 06:23:09 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:09 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:23:09 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:09 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:09 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:09 --> URI Class Initialized
INFO - 2023-02-10 06:23:09 --> URI Class Initialized
INFO - 2023-02-10 06:23:09 --> Router Class Initialized
INFO - 2023-02-10 06:23:09 --> Router Class Initialized
INFO - 2023-02-10 06:23:09 --> Output Class Initialized
INFO - 2023-02-10 06:23:09 --> Output Class Initialized
INFO - 2023-02-10 06:23:09 --> Security Class Initialized
INFO - 2023-02-10 06:23:09 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:09 --> Input Class Initialized
INFO - 2023-02-10 06:23:09 --> Input Class Initialized
INFO - 2023-02-10 06:23:09 --> Language Class Initialized
INFO - 2023-02-10 06:23:09 --> Language Class Initialized
INFO - 2023-02-10 06:23:09 --> Loader Class Initialized
INFO - 2023-02-10 06:23:09 --> Loader Class Initialized
INFO - 2023-02-10 06:23:09 --> Controller Class Initialized
INFO - 2023-02-10 06:23:09 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:09 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:09 --> Total execution time: 0.0045
INFO - 2023-02-10 06:23:09 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:09 --> Config Class Initialized
INFO - 2023-02-10 06:23:09 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:09 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:09 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:09 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:09 --> URI Class Initialized
INFO - 2023-02-10 06:23:09 --> Router Class Initialized
INFO - 2023-02-10 06:23:09 --> Output Class Initialized
INFO - 2023-02-10 06:23:09 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:09 --> Input Class Initialized
INFO - 2023-02-10 06:23:09 --> Language Class Initialized
INFO - 2023-02-10 06:23:09 --> Loader Class Initialized
INFO - 2023-02-10 06:23:09 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:09 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:09 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:09 --> Total execution time: 0.0525
INFO - 2023-02-10 06:23:09 --> Config Class Initialized
INFO - 2023-02-10 06:23:09 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:09 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:09 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:09 --> URI Class Initialized
INFO - 2023-02-10 06:23:09 --> Router Class Initialized
INFO - 2023-02-10 06:23:09 --> Output Class Initialized
INFO - 2023-02-10 06:23:09 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:09 --> Input Class Initialized
INFO - 2023-02-10 06:23:09 --> Language Class Initialized
INFO - 2023-02-10 06:23:09 --> Loader Class Initialized
INFO - 2023-02-10 06:23:09 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:09 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:09 --> Model "Login_model" initialized
INFO - 2023-02-10 06:23:09 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:09 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:09 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:09 --> Final output sent to browser
INFO - 2023-02-10 06:23:09 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:09 --> Total execution time: 0.0654
DEBUG - 2023-02-10 06:23:09 --> Total execution time: 0.0185
INFO - 2023-02-10 06:23:12 --> Config Class Initialized
INFO - 2023-02-10 06:23:12 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:12 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:12 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:12 --> URI Class Initialized
INFO - 2023-02-10 06:23:12 --> Router Class Initialized
INFO - 2023-02-10 06:23:12 --> Output Class Initialized
INFO - 2023-02-10 06:23:12 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:12 --> Input Class Initialized
INFO - 2023-02-10 06:23:12 --> Language Class Initialized
INFO - 2023-02-10 06:23:12 --> Loader Class Initialized
INFO - 2023-02-10 06:23:12 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:12 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:12 --> Model "Login_model" initialized
INFO - 2023-02-10 06:23:12 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:12 --> Total execution time: 0.0366
INFO - 2023-02-10 06:23:12 --> Config Class Initialized
INFO - 2023-02-10 06:23:12 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:12 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:12 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:12 --> URI Class Initialized
INFO - 2023-02-10 06:23:12 --> Router Class Initialized
INFO - 2023-02-10 06:23:12 --> Output Class Initialized
INFO - 2023-02-10 06:23:12 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:12 --> Input Class Initialized
INFO - 2023-02-10 06:23:12 --> Language Class Initialized
INFO - 2023-02-10 06:23:12 --> Loader Class Initialized
INFO - 2023-02-10 06:23:12 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:12 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:12 --> Model "Login_model" initialized
INFO - 2023-02-10 06:23:12 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:12 --> Total execution time: 0.0337
INFO - 2023-02-10 06:23:14 --> Config Class Initialized
INFO - 2023-02-10 06:23:14 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:14 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:14 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:14 --> URI Class Initialized
INFO - 2023-02-10 06:23:14 --> Router Class Initialized
INFO - 2023-02-10 06:23:14 --> Output Class Initialized
INFO - 2023-02-10 06:23:14 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:14 --> Input Class Initialized
INFO - 2023-02-10 06:23:14 --> Language Class Initialized
INFO - 2023-02-10 06:23:14 --> Loader Class Initialized
INFO - 2023-02-10 06:23:14 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:14 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:14 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:14 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:14 --> Total execution time: 0.0139
INFO - 2023-02-10 06:23:14 --> Config Class Initialized
INFO - 2023-02-10 06:23:14 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:14 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:14 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:15 --> URI Class Initialized
INFO - 2023-02-10 06:23:15 --> Router Class Initialized
INFO - 2023-02-10 06:23:15 --> Output Class Initialized
INFO - 2023-02-10 06:23:15 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:15 --> Input Class Initialized
INFO - 2023-02-10 06:23:15 --> Language Class Initialized
INFO - 2023-02-10 06:23:15 --> Loader Class Initialized
INFO - 2023-02-10 06:23:15 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:15 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:15 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:15 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:15 --> Total execution time: 0.2661
INFO - 2023-02-10 06:23:18 --> Config Class Initialized
INFO - 2023-02-10 06:23:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:18 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:18 --> URI Class Initialized
INFO - 2023-02-10 06:23:18 --> Router Class Initialized
INFO - 2023-02-10 06:23:18 --> Output Class Initialized
INFO - 2023-02-10 06:23:18 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:18 --> Input Class Initialized
INFO - 2023-02-10 06:23:18 --> Language Class Initialized
INFO - 2023-02-10 06:23:18 --> Loader Class Initialized
INFO - 2023-02-10 06:23:18 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:18 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:18 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:18 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:18 --> Total execution time: 0.0412
INFO - 2023-02-10 06:23:18 --> Config Class Initialized
INFO - 2023-02-10 06:23:18 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:23:18 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:23:18 --> Utf8 Class Initialized
INFO - 2023-02-10 06:23:18 --> URI Class Initialized
INFO - 2023-02-10 06:23:18 --> Router Class Initialized
INFO - 2023-02-10 06:23:18 --> Output Class Initialized
INFO - 2023-02-10 06:23:18 --> Security Class Initialized
DEBUG - 2023-02-10 06:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:23:18 --> Input Class Initialized
INFO - 2023-02-10 06:23:18 --> Language Class Initialized
INFO - 2023-02-10 06:23:18 --> Loader Class Initialized
INFO - 2023-02-10 06:23:18 --> Controller Class Initialized
DEBUG - 2023-02-10 06:23:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:23:18 --> Database Driver Class Initialized
INFO - 2023-02-10 06:23:18 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:23:18 --> Final output sent to browser
DEBUG - 2023-02-10 06:23:18 --> Total execution time: 0.0356
INFO - 2023-02-10 06:26:05 --> Config Class Initialized
INFO - 2023-02-10 06:26:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:26:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:26:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:26:05 --> URI Class Initialized
INFO - 2023-02-10 06:26:05 --> Router Class Initialized
INFO - 2023-02-10 06:26:05 --> Output Class Initialized
INFO - 2023-02-10 06:26:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:26:05 --> Input Class Initialized
INFO - 2023-02-10 06:26:05 --> Language Class Initialized
INFO - 2023-02-10 06:26:05 --> Loader Class Initialized
INFO - 2023-02-10 06:26:05 --> Controller Class Initialized
INFO - 2023-02-10 06:26:05 --> Helper loaded: form_helper
INFO - 2023-02-10 06:26:05 --> Helper loaded: url_helper
DEBUG - 2023-02-10 06:26:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:26:05 --> Model "Change_model" initialized
INFO - 2023-02-10 06:26:05 --> Model "Grafana_model" initialized
INFO - 2023-02-10 06:26:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:26:05 --> Total execution time: 0.2141
INFO - 2023-02-10 06:26:05 --> Config Class Initialized
INFO - 2023-02-10 06:26:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:26:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:26:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:26:05 --> URI Class Initialized
INFO - 2023-02-10 06:26:05 --> Router Class Initialized
INFO - 2023-02-10 06:26:05 --> Output Class Initialized
INFO - 2023-02-10 06:26:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:26:05 --> Input Class Initialized
INFO - 2023-02-10 06:26:05 --> Language Class Initialized
INFO - 2023-02-10 06:26:05 --> Loader Class Initialized
INFO - 2023-02-10 06:26:05 --> Controller Class Initialized
INFO - 2023-02-10 06:26:05 --> Helper loaded: form_helper
INFO - 2023-02-10 06:26:05 --> Helper loaded: url_helper
DEBUG - 2023-02-10 06:26:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:26:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:26:05 --> Total execution time: 0.0040
INFO - 2023-02-10 06:26:05 --> Config Class Initialized
INFO - 2023-02-10 06:26:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:26:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:26:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:26:05 --> URI Class Initialized
INFO - 2023-02-10 06:26:05 --> Router Class Initialized
INFO - 2023-02-10 06:26:05 --> Output Class Initialized
INFO - 2023-02-10 06:26:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:26:05 --> Input Class Initialized
INFO - 2023-02-10 06:26:05 --> Language Class Initialized
INFO - 2023-02-10 06:26:05 --> Loader Class Initialized
INFO - 2023-02-10 06:26:05 --> Controller Class Initialized
INFO - 2023-02-10 06:26:05 --> Helper loaded: form_helper
INFO - 2023-02-10 06:26:05 --> Helper loaded: url_helper
DEBUG - 2023-02-10 06:26:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:26:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:26:05 --> Model "Login_model" initialized
INFO - 2023-02-10 06:26:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:26:05 --> Total execution time: 0.0145
INFO - 2023-02-10 06:26:05 --> Config Class Initialized
INFO - 2023-02-10 06:26:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:26:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:26:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:26:05 --> URI Class Initialized
INFO - 2023-02-10 06:26:05 --> Router Class Initialized
INFO - 2023-02-10 06:26:05 --> Output Class Initialized
INFO - 2023-02-10 06:26:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:26:05 --> Input Class Initialized
INFO - 2023-02-10 06:26:05 --> Language Class Initialized
INFO - 2023-02-10 06:26:05 --> Loader Class Initialized
INFO - 2023-02-10 06:26:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:26:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:26:05 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:26:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:26:05 --> Total execution time: 0.0555
INFO - 2023-02-10 06:26:05 --> Config Class Initialized
INFO - 2023-02-10 06:26:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:26:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:26:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:26:05 --> URI Class Initialized
INFO - 2023-02-10 06:26:05 --> Router Class Initialized
INFO - 2023-02-10 06:26:05 --> Output Class Initialized
INFO - 2023-02-10 06:26:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:26:05 --> Input Class Initialized
INFO - 2023-02-10 06:26:05 --> Language Class Initialized
INFO - 2023-02-10 06:26:05 --> Loader Class Initialized
INFO - 2023-02-10 06:26:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:26:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:26:05 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:26:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:26:05 --> Total execution time: 0.0142
INFO - 2023-02-10 06:26:05 --> Config Class Initialized
INFO - 2023-02-10 06:26:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:26:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:26:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:26:05 --> URI Class Initialized
INFO - 2023-02-10 06:26:05 --> Router Class Initialized
INFO - 2023-02-10 06:26:05 --> Output Class Initialized
INFO - 2023-02-10 06:26:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:26:05 --> Input Class Initialized
INFO - 2023-02-10 06:26:05 --> Language Class Initialized
INFO - 2023-02-10 06:26:05 --> Loader Class Initialized
INFO - 2023-02-10 06:26:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:26:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:26:05 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:26:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:26:05 --> Model "Login_model" initialized
INFO - 2023-02-10 06:26:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:26:05 --> Total execution time: 0.0732
INFO - 2023-02-10 06:26:05 --> Config Class Initialized
INFO - 2023-02-10 06:26:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:26:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:26:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:26:05 --> URI Class Initialized
INFO - 2023-02-10 06:26:05 --> Router Class Initialized
INFO - 2023-02-10 06:26:05 --> Output Class Initialized
INFO - 2023-02-10 06:26:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:26:05 --> Input Class Initialized
INFO - 2023-02-10 06:26:05 --> Language Class Initialized
INFO - 2023-02-10 06:26:05 --> Loader Class Initialized
INFO - 2023-02-10 06:26:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:26:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:26:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:26:05 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:26:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:26:05 --> Model "Login_model" initialized
INFO - 2023-02-10 06:26:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:26:05 --> Total execution time: 0.0739
INFO - 2023-02-10 06:27:44 --> Config Class Initialized
INFO - 2023-02-10 06:27:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:27:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:27:44 --> Utf8 Class Initialized
INFO - 2023-02-10 06:27:44 --> URI Class Initialized
INFO - 2023-02-10 06:27:44 --> Router Class Initialized
INFO - 2023-02-10 06:27:44 --> Output Class Initialized
INFO - 2023-02-10 06:27:44 --> Security Class Initialized
DEBUG - 2023-02-10 06:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:27:44 --> Input Class Initialized
INFO - 2023-02-10 06:27:44 --> Language Class Initialized
INFO - 2023-02-10 06:27:44 --> Loader Class Initialized
INFO - 2023-02-10 06:27:44 --> Controller Class Initialized
DEBUG - 2023-02-10 06:27:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:27:44 --> Database Driver Class Initialized
INFO - 2023-02-10 06:27:44 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:27:44 --> Final output sent to browser
DEBUG - 2023-02-10 06:27:44 --> Total execution time: 0.0245
INFO - 2023-02-10 06:27:44 --> Config Class Initialized
INFO - 2023-02-10 06:27:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:27:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:27:44 --> Utf8 Class Initialized
INFO - 2023-02-10 06:27:44 --> URI Class Initialized
INFO - 2023-02-10 06:27:44 --> Router Class Initialized
INFO - 2023-02-10 06:27:44 --> Output Class Initialized
INFO - 2023-02-10 06:27:44 --> Security Class Initialized
DEBUG - 2023-02-10 06:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:27:44 --> Input Class Initialized
INFO - 2023-02-10 06:27:44 --> Language Class Initialized
INFO - 2023-02-10 06:27:44 --> Loader Class Initialized
INFO - 2023-02-10 06:27:44 --> Controller Class Initialized
DEBUG - 2023-02-10 06:27:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:27:44 --> Database Driver Class Initialized
INFO - 2023-02-10 06:27:44 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:27:44 --> Final output sent to browser
DEBUG - 2023-02-10 06:27:44 --> Total execution time: 0.0618
INFO - 2023-02-10 06:27:46 --> Config Class Initialized
INFO - 2023-02-10 06:27:46 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:27:46 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:27:46 --> Utf8 Class Initialized
INFO - 2023-02-10 06:27:46 --> URI Class Initialized
INFO - 2023-02-10 06:27:46 --> Router Class Initialized
INFO - 2023-02-10 06:27:46 --> Output Class Initialized
INFO - 2023-02-10 06:27:46 --> Security Class Initialized
DEBUG - 2023-02-10 06:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:27:46 --> Input Class Initialized
INFO - 2023-02-10 06:27:46 --> Language Class Initialized
INFO - 2023-02-10 06:27:46 --> Loader Class Initialized
INFO - 2023-02-10 06:27:46 --> Controller Class Initialized
DEBUG - 2023-02-10 06:27:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:27:46 --> Database Driver Class Initialized
INFO - 2023-02-10 06:27:46 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:27:46 --> Final output sent to browser
DEBUG - 2023-02-10 06:27:46 --> Total execution time: 0.0323
INFO - 2023-02-10 06:27:46 --> Config Class Initialized
INFO - 2023-02-10 06:27:46 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:27:46 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:27:46 --> Utf8 Class Initialized
INFO - 2023-02-10 06:27:46 --> URI Class Initialized
INFO - 2023-02-10 06:27:46 --> Router Class Initialized
INFO - 2023-02-10 06:27:46 --> Output Class Initialized
INFO - 2023-02-10 06:27:46 --> Security Class Initialized
DEBUG - 2023-02-10 06:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:27:46 --> Input Class Initialized
INFO - 2023-02-10 06:27:46 --> Language Class Initialized
INFO - 2023-02-10 06:27:46 --> Loader Class Initialized
INFO - 2023-02-10 06:27:46 --> Controller Class Initialized
DEBUG - 2023-02-10 06:27:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:27:46 --> Database Driver Class Initialized
INFO - 2023-02-10 06:27:46 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:27:46 --> Final output sent to browser
DEBUG - 2023-02-10 06:27:46 --> Total execution time: 0.0599
INFO - 2023-02-10 06:27:57 --> Config Class Initialized
INFO - 2023-02-10 06:27:57 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:27:57 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:27:57 --> Utf8 Class Initialized
INFO - 2023-02-10 06:27:57 --> URI Class Initialized
INFO - 2023-02-10 06:27:57 --> Router Class Initialized
INFO - 2023-02-10 06:27:57 --> Output Class Initialized
INFO - 2023-02-10 06:27:57 --> Security Class Initialized
DEBUG - 2023-02-10 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:27:57 --> Input Class Initialized
INFO - 2023-02-10 06:27:57 --> Language Class Initialized
INFO - 2023-02-10 06:27:57 --> Loader Class Initialized
INFO - 2023-02-10 06:27:57 --> Controller Class Initialized
DEBUG - 2023-02-10 06:27:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:27:57 --> Database Driver Class Initialized
INFO - 2023-02-10 06:27:57 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:27:57 --> Final output sent to browser
DEBUG - 2023-02-10 06:27:57 --> Total execution time: 0.0191
INFO - 2023-02-10 06:27:57 --> Config Class Initialized
INFO - 2023-02-10 06:27:58 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:27:58 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:27:58 --> Utf8 Class Initialized
INFO - 2023-02-10 06:27:58 --> URI Class Initialized
INFO - 2023-02-10 06:27:58 --> Router Class Initialized
INFO - 2023-02-10 06:27:58 --> Output Class Initialized
INFO - 2023-02-10 06:27:58 --> Security Class Initialized
DEBUG - 2023-02-10 06:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:27:58 --> Input Class Initialized
INFO - 2023-02-10 06:27:58 --> Language Class Initialized
INFO - 2023-02-10 06:27:58 --> Loader Class Initialized
INFO - 2023-02-10 06:27:58 --> Controller Class Initialized
DEBUG - 2023-02-10 06:27:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:27:58 --> Database Driver Class Initialized
INFO - 2023-02-10 06:27:58 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:27:58 --> Final output sent to browser
DEBUG - 2023-02-10 06:27:58 --> Total execution time: 0.0553
INFO - 2023-02-10 06:28:05 --> Config Class Initialized
INFO - 2023-02-10 06:28:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:28:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:28:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:28:05 --> URI Class Initialized
INFO - 2023-02-10 06:28:05 --> Router Class Initialized
INFO - 2023-02-10 06:28:05 --> Output Class Initialized
INFO - 2023-02-10 06:28:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:28:05 --> Input Class Initialized
INFO - 2023-02-10 06:28:05 --> Language Class Initialized
INFO - 2023-02-10 06:28:05 --> Loader Class Initialized
INFO - 2023-02-10 06:28:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:28:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:28:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:28:05 --> Total execution time: 0.0448
INFO - 2023-02-10 06:28:05 --> Config Class Initialized
INFO - 2023-02-10 06:28:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:28:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:28:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:28:05 --> URI Class Initialized
INFO - 2023-02-10 06:28:05 --> Router Class Initialized
INFO - 2023-02-10 06:28:05 --> Output Class Initialized
INFO - 2023-02-10 06:28:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:28:05 --> Input Class Initialized
INFO - 2023-02-10 06:28:05 --> Language Class Initialized
INFO - 2023-02-10 06:28:05 --> Loader Class Initialized
INFO - 2023-02-10 06:28:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:28:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:28:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:05 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:28:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:28:05 --> Total execution time: 0.0517
INFO - 2023-02-10 06:28:05 --> Config Class Initialized
INFO - 2023-02-10 06:28:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:28:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:28:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:28:05 --> URI Class Initialized
INFO - 2023-02-10 06:28:05 --> Router Class Initialized
INFO - 2023-02-10 06:28:05 --> Output Class Initialized
INFO - 2023-02-10 06:28:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:28:05 --> Input Class Initialized
INFO - 2023-02-10 06:28:05 --> Language Class Initialized
INFO - 2023-02-10 06:28:05 --> Loader Class Initialized
INFO - 2023-02-10 06:28:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:28:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:28:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:05 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:28:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:28:05 --> Total execution time: 0.0174
INFO - 2023-02-10 06:28:05 --> Config Class Initialized
INFO - 2023-02-10 06:28:05 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:28:05 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:28:05 --> Utf8 Class Initialized
INFO - 2023-02-10 06:28:05 --> URI Class Initialized
INFO - 2023-02-10 06:28:05 --> Router Class Initialized
INFO - 2023-02-10 06:28:05 --> Output Class Initialized
INFO - 2023-02-10 06:28:05 --> Security Class Initialized
DEBUG - 2023-02-10 06:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:28:05 --> Input Class Initialized
INFO - 2023-02-10 06:28:05 --> Language Class Initialized
INFO - 2023-02-10 06:28:05 --> Loader Class Initialized
INFO - 2023-02-10 06:28:05 --> Controller Class Initialized
DEBUG - 2023-02-10 06:28:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:28:05 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:05 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:28:05 --> Final output sent to browser
DEBUG - 2023-02-10 06:28:05 --> Total execution time: 0.0170
INFO - 2023-02-10 06:28:08 --> Config Class Initialized
INFO - 2023-02-10 06:28:08 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:28:08 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:28:08 --> Utf8 Class Initialized
INFO - 2023-02-10 06:28:08 --> URI Class Initialized
INFO - 2023-02-10 06:28:08 --> Router Class Initialized
INFO - 2023-02-10 06:28:08 --> Output Class Initialized
INFO - 2023-02-10 06:28:08 --> Security Class Initialized
DEBUG - 2023-02-10 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:28:08 --> Input Class Initialized
INFO - 2023-02-10 06:28:08 --> Language Class Initialized
INFO - 2023-02-10 06:28:08 --> Loader Class Initialized
INFO - 2023-02-10 06:28:08 --> Controller Class Initialized
DEBUG - 2023-02-10 06:28:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:28:08 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:08 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:28:08 --> Final output sent to browser
DEBUG - 2023-02-10 06:28:08 --> Total execution time: 0.0157
INFO - 2023-02-10 06:28:08 --> Config Class Initialized
INFO - 2023-02-10 06:28:08 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:28:08 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:28:08 --> Utf8 Class Initialized
INFO - 2023-02-10 06:28:08 --> URI Class Initialized
INFO - 2023-02-10 06:28:08 --> Router Class Initialized
INFO - 2023-02-10 06:28:08 --> Output Class Initialized
INFO - 2023-02-10 06:28:08 --> Security Class Initialized
DEBUG - 2023-02-10 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:28:08 --> Input Class Initialized
INFO - 2023-02-10 06:28:08 --> Language Class Initialized
INFO - 2023-02-10 06:28:08 --> Loader Class Initialized
INFO - 2023-02-10 06:28:08 --> Controller Class Initialized
DEBUG - 2023-02-10 06:28:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:28:08 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:08 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:28:08 --> Final output sent to browser
DEBUG - 2023-02-10 06:28:08 --> Total execution time: 0.1306
INFO - 2023-02-10 06:28:12 --> Config Class Initialized
INFO - 2023-02-10 06:28:12 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:28:12 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:28:12 --> Utf8 Class Initialized
INFO - 2023-02-10 06:28:12 --> URI Class Initialized
INFO - 2023-02-10 06:28:12 --> Router Class Initialized
INFO - 2023-02-10 06:28:12 --> Output Class Initialized
INFO - 2023-02-10 06:28:12 --> Security Class Initialized
DEBUG - 2023-02-10 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:28:12 --> Input Class Initialized
INFO - 2023-02-10 06:28:12 --> Language Class Initialized
INFO - 2023-02-10 06:28:12 --> Loader Class Initialized
INFO - 2023-02-10 06:28:12 --> Controller Class Initialized
DEBUG - 2023-02-10 06:28:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:28:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:12 --> Model "Login_model" initialized
INFO - 2023-02-10 06:28:12 --> Final output sent to browser
DEBUG - 2023-02-10 06:28:12 --> Total execution time: 0.0352
INFO - 2023-02-10 06:28:12 --> Config Class Initialized
INFO - 2023-02-10 06:28:12 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:28:12 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:28:12 --> Utf8 Class Initialized
INFO - 2023-02-10 06:28:12 --> URI Class Initialized
INFO - 2023-02-10 06:28:12 --> Router Class Initialized
INFO - 2023-02-10 06:28:12 --> Output Class Initialized
INFO - 2023-02-10 06:28:12 --> Security Class Initialized
DEBUG - 2023-02-10 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:28:12 --> Input Class Initialized
INFO - 2023-02-10 06:28:12 --> Language Class Initialized
INFO - 2023-02-10 06:28:12 --> Loader Class Initialized
INFO - 2023-02-10 06:28:12 --> Controller Class Initialized
DEBUG - 2023-02-10 06:28:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:28:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:28:12 --> Model "Login_model" initialized
INFO - 2023-02-10 06:28:12 --> Final output sent to browser
DEBUG - 2023-02-10 06:28:12 --> Total execution time: 0.0640
INFO - 2023-02-10 06:30:12 --> Config Class Initialized
INFO - 2023-02-10 06:30:12 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:30:12 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:30:12 --> Utf8 Class Initialized
INFO - 2023-02-10 06:30:12 --> URI Class Initialized
INFO - 2023-02-10 06:30:12 --> Router Class Initialized
INFO - 2023-02-10 06:30:12 --> Output Class Initialized
INFO - 2023-02-10 06:30:12 --> Security Class Initialized
DEBUG - 2023-02-10 06:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:30:12 --> Input Class Initialized
INFO - 2023-02-10 06:30:12 --> Language Class Initialized
INFO - 2023-02-10 06:30:12 --> Loader Class Initialized
INFO - 2023-02-10 06:30:12 --> Controller Class Initialized
DEBUG - 2023-02-10 06:30:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:30:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:12 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:30:12 --> Final output sent to browser
DEBUG - 2023-02-10 06:30:12 --> Total execution time: 0.0155
INFO - 2023-02-10 06:30:12 --> Config Class Initialized
INFO - 2023-02-10 06:30:12 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:30:12 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:30:12 --> Utf8 Class Initialized
INFO - 2023-02-10 06:30:12 --> URI Class Initialized
INFO - 2023-02-10 06:30:12 --> Router Class Initialized
INFO - 2023-02-10 06:30:12 --> Output Class Initialized
INFO - 2023-02-10 06:30:12 --> Security Class Initialized
DEBUG - 2023-02-10 06:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:30:12 --> Input Class Initialized
INFO - 2023-02-10 06:30:12 --> Language Class Initialized
INFO - 2023-02-10 06:30:12 --> Loader Class Initialized
INFO - 2023-02-10 06:30:12 --> Controller Class Initialized
DEBUG - 2023-02-10 06:30:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:30:12 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:12 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:30:12 --> Final output sent to browser
DEBUG - 2023-02-10 06:30:12 --> Total execution time: 0.0568
INFO - 2023-02-10 06:30:13 --> Config Class Initialized
INFO - 2023-02-10 06:30:13 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:30:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:30:13 --> Utf8 Class Initialized
INFO - 2023-02-10 06:30:13 --> URI Class Initialized
INFO - 2023-02-10 06:30:13 --> Router Class Initialized
INFO - 2023-02-10 06:30:13 --> Output Class Initialized
INFO - 2023-02-10 06:30:13 --> Security Class Initialized
DEBUG - 2023-02-10 06:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:30:13 --> Input Class Initialized
INFO - 2023-02-10 06:30:13 --> Language Class Initialized
INFO - 2023-02-10 06:30:13 --> Loader Class Initialized
INFO - 2023-02-10 06:30:13 --> Controller Class Initialized
DEBUG - 2023-02-10 06:30:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:30:13 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:13 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:13 --> Model "Login_model" initialized
INFO - 2023-02-10 06:30:13 --> Final output sent to browser
DEBUG - 2023-02-10 06:30:13 --> Total execution time: 0.0281
INFO - 2023-02-10 06:30:13 --> Config Class Initialized
INFO - 2023-02-10 06:30:13 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:30:13 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:30:13 --> Utf8 Class Initialized
INFO - 2023-02-10 06:30:13 --> URI Class Initialized
INFO - 2023-02-10 06:30:13 --> Router Class Initialized
INFO - 2023-02-10 06:30:13 --> Output Class Initialized
INFO - 2023-02-10 06:30:13 --> Security Class Initialized
DEBUG - 2023-02-10 06:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:30:13 --> Input Class Initialized
INFO - 2023-02-10 06:30:13 --> Language Class Initialized
INFO - 2023-02-10 06:30:13 --> Loader Class Initialized
INFO - 2023-02-10 06:30:13 --> Controller Class Initialized
DEBUG - 2023-02-10 06:30:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:30:13 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:13 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:14 --> Model "Login_model" initialized
INFO - 2023-02-10 06:30:14 --> Final output sent to browser
DEBUG - 2023-02-10 06:30:14 --> Total execution time: 0.0191
INFO - 2023-02-10 06:30:22 --> Config Class Initialized
INFO - 2023-02-10 06:30:22 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:30:22 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:30:22 --> Utf8 Class Initialized
INFO - 2023-02-10 06:30:22 --> URI Class Initialized
INFO - 2023-02-10 06:30:22 --> Router Class Initialized
INFO - 2023-02-10 06:30:22 --> Output Class Initialized
INFO - 2023-02-10 06:30:22 --> Security Class Initialized
DEBUG - 2023-02-10 06:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:30:22 --> Input Class Initialized
INFO - 2023-02-10 06:30:22 --> Language Class Initialized
INFO - 2023-02-10 06:30:22 --> Loader Class Initialized
INFO - 2023-02-10 06:30:22 --> Controller Class Initialized
DEBUG - 2023-02-10 06:30:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:30:22 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:22 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:22 --> Model "Login_model" initialized
INFO - 2023-02-10 06:30:22 --> Final output sent to browser
DEBUG - 2023-02-10 06:30:22 --> Total execution time: 0.0273
INFO - 2023-02-10 06:30:22 --> Config Class Initialized
INFO - 2023-02-10 06:30:22 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:30:22 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:30:22 --> Utf8 Class Initialized
INFO - 2023-02-10 06:30:22 --> URI Class Initialized
INFO - 2023-02-10 06:30:22 --> Router Class Initialized
INFO - 2023-02-10 06:30:22 --> Output Class Initialized
INFO - 2023-02-10 06:30:22 --> Security Class Initialized
DEBUG - 2023-02-10 06:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:30:22 --> Input Class Initialized
INFO - 2023-02-10 06:30:22 --> Language Class Initialized
INFO - 2023-02-10 06:30:22 --> Loader Class Initialized
INFO - 2023-02-10 06:30:22 --> Controller Class Initialized
DEBUG - 2023-02-10 06:30:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:30:22 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:22 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:22 --> Model "Login_model" initialized
INFO - 2023-02-10 06:30:22 --> Final output sent to browser
DEBUG - 2023-02-10 06:30:22 --> Total execution time: 0.0650
INFO - 2023-02-10 06:30:23 --> Config Class Initialized
INFO - 2023-02-10 06:30:23 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:30:23 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:30:23 --> Utf8 Class Initialized
INFO - 2023-02-10 06:30:23 --> URI Class Initialized
INFO - 2023-02-10 06:30:23 --> Router Class Initialized
INFO - 2023-02-10 06:30:23 --> Output Class Initialized
INFO - 2023-02-10 06:30:23 --> Security Class Initialized
DEBUG - 2023-02-10 06:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:30:23 --> Input Class Initialized
INFO - 2023-02-10 06:30:23 --> Language Class Initialized
INFO - 2023-02-10 06:30:23 --> Loader Class Initialized
INFO - 2023-02-10 06:30:23 --> Controller Class Initialized
DEBUG - 2023-02-10 06:30:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:30:23 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:23 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:23 --> Model "Login_model" initialized
INFO - 2023-02-10 06:30:23 --> Final output sent to browser
DEBUG - 2023-02-10 06:30:23 --> Total execution time: 0.0247
INFO - 2023-02-10 06:30:23 --> Config Class Initialized
INFO - 2023-02-10 06:30:23 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:30:23 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:30:23 --> Utf8 Class Initialized
INFO - 2023-02-10 06:30:23 --> URI Class Initialized
INFO - 2023-02-10 06:30:23 --> Router Class Initialized
INFO - 2023-02-10 06:30:23 --> Output Class Initialized
INFO - 2023-02-10 06:30:23 --> Security Class Initialized
DEBUG - 2023-02-10 06:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:30:23 --> Input Class Initialized
INFO - 2023-02-10 06:30:23 --> Language Class Initialized
INFO - 2023-02-10 06:30:23 --> Loader Class Initialized
INFO - 2023-02-10 06:30:23 --> Controller Class Initialized
DEBUG - 2023-02-10 06:30:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:30:23 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:23 --> Database Driver Class Initialized
INFO - 2023-02-10 06:30:23 --> Model "Login_model" initialized
INFO - 2023-02-10 06:30:23 --> Final output sent to browser
DEBUG - 2023-02-10 06:30:23 --> Total execution time: 0.0195
INFO - 2023-02-10 06:31:37 --> Config Class Initialized
INFO - 2023-02-10 06:31:38 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:38 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:38 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:38 --> URI Class Initialized
INFO - 2023-02-10 06:31:38 --> Router Class Initialized
INFO - 2023-02-10 06:31:38 --> Output Class Initialized
INFO - 2023-02-10 06:31:38 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:38 --> Input Class Initialized
INFO - 2023-02-10 06:31:38 --> Language Class Initialized
INFO - 2023-02-10 06:31:38 --> Loader Class Initialized
INFO - 2023-02-10 06:31:38 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:38 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:38 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:38 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:38 --> Total execution time: 0.0700
INFO - 2023-02-10 06:31:38 --> Config Class Initialized
INFO - 2023-02-10 06:31:38 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:38 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:38 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:38 --> URI Class Initialized
INFO - 2023-02-10 06:31:38 --> Router Class Initialized
INFO - 2023-02-10 06:31:38 --> Output Class Initialized
INFO - 2023-02-10 06:31:38 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:38 --> Input Class Initialized
INFO - 2023-02-10 06:31:38 --> Language Class Initialized
INFO - 2023-02-10 06:31:38 --> Loader Class Initialized
INFO - 2023-02-10 06:31:38 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:38 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:38 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:38 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:38 --> Total execution time: 0.0812
INFO - 2023-02-10 06:31:40 --> Config Class Initialized
INFO - 2023-02-10 06:31:40 --> Hooks Class Initialized
INFO - 2023-02-10 06:31:40 --> Config Class Initialized
INFO - 2023-02-10 06:31:40 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:40 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:40 --> Utf8 Class Initialized
DEBUG - 2023-02-10 06:31:40 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:40 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:40 --> URI Class Initialized
INFO - 2023-02-10 06:31:40 --> URI Class Initialized
INFO - 2023-02-10 06:31:40 --> Router Class Initialized
INFO - 2023-02-10 06:31:40 --> Router Class Initialized
INFO - 2023-02-10 06:31:40 --> Output Class Initialized
INFO - 2023-02-10 06:31:40 --> Output Class Initialized
INFO - 2023-02-10 06:31:40 --> Security Class Initialized
INFO - 2023-02-10 06:31:40 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:40 --> Input Class Initialized
INFO - 2023-02-10 06:31:40 --> Input Class Initialized
INFO - 2023-02-10 06:31:40 --> Language Class Initialized
INFO - 2023-02-10 06:31:40 --> Language Class Initialized
INFO - 2023-02-10 06:31:40 --> Loader Class Initialized
INFO - 2023-02-10 06:31:40 --> Controller Class Initialized
INFO - 2023-02-10 06:31:40 --> Loader Class Initialized
DEBUG - 2023-02-10 06:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:40 --> Controller Class Initialized
INFO - 2023-02-10 06:31:40 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:31:40 --> Total execution time: 0.0048
INFO - 2023-02-10 06:31:40 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:40 --> Config Class Initialized
INFO - 2023-02-10 06:31:40 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:40 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:40 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:40 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:40 --> URI Class Initialized
INFO - 2023-02-10 06:31:40 --> Router Class Initialized
INFO - 2023-02-10 06:31:40 --> Output Class Initialized
INFO - 2023-02-10 06:31:40 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:40 --> Input Class Initialized
INFO - 2023-02-10 06:31:40 --> Language Class Initialized
INFO - 2023-02-10 06:31:40 --> Loader Class Initialized
INFO - 2023-02-10 06:31:40 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:40 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:40 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:40 --> Total execution time: 0.0519
INFO - 2023-02-10 06:31:40 --> Config Class Initialized
INFO - 2023-02-10 06:31:40 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:40 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:40 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:40 --> URI Class Initialized
INFO - 2023-02-10 06:31:40 --> Router Class Initialized
INFO - 2023-02-10 06:31:40 --> Output Class Initialized
INFO - 2023-02-10 06:31:40 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:40 --> Input Class Initialized
INFO - 2023-02-10 06:31:40 --> Language Class Initialized
INFO - 2023-02-10 06:31:40 --> Loader Class Initialized
INFO - 2023-02-10 06:31:40 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:40 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:40 --> Model "Login_model" initialized
INFO - 2023-02-10 06:31:40 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:40 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:40 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:40 --> Total execution time: 0.0158
INFO - 2023-02-10 06:31:40 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:40 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:40 --> Total execution time: 0.1055
INFO - 2023-02-10 06:31:43 --> Config Class Initialized
INFO - 2023-02-10 06:31:43 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:43 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:43 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:43 --> URI Class Initialized
INFO - 2023-02-10 06:31:43 --> Router Class Initialized
INFO - 2023-02-10 06:31:43 --> Output Class Initialized
INFO - 2023-02-10 06:31:43 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:43 --> Input Class Initialized
INFO - 2023-02-10 06:31:43 --> Language Class Initialized
INFO - 2023-02-10 06:31:43 --> Loader Class Initialized
INFO - 2023-02-10 06:31:43 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:43 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:43 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:43 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:43 --> Model "Login_model" initialized
INFO - 2023-02-10 06:31:43 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:43 --> Total execution time: 0.0385
INFO - 2023-02-10 06:31:43 --> Config Class Initialized
INFO - 2023-02-10 06:31:43 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:43 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:43 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:43 --> URI Class Initialized
INFO - 2023-02-10 06:31:43 --> Router Class Initialized
INFO - 2023-02-10 06:31:43 --> Output Class Initialized
INFO - 2023-02-10 06:31:43 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:43 --> Input Class Initialized
INFO - 2023-02-10 06:31:43 --> Language Class Initialized
INFO - 2023-02-10 06:31:43 --> Loader Class Initialized
INFO - 2023-02-10 06:31:43 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:43 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:43 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:43 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:43 --> Model "Login_model" initialized
INFO - 2023-02-10 06:31:43 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:43 --> Total execution time: 0.0812
INFO - 2023-02-10 06:31:49 --> Config Class Initialized
INFO - 2023-02-10 06:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:49 --> URI Class Initialized
INFO - 2023-02-10 06:31:49 --> Router Class Initialized
INFO - 2023-02-10 06:31:49 --> Output Class Initialized
INFO - 2023-02-10 06:31:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:49 --> Input Class Initialized
INFO - 2023-02-10 06:31:49 --> Language Class Initialized
INFO - 2023-02-10 06:31:49 --> Loader Class Initialized
INFO - 2023-02-10 06:31:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:49 --> Total execution time: 0.0385
INFO - 2023-02-10 06:31:49 --> Config Class Initialized
INFO - 2023-02-10 06:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:49 --> URI Class Initialized
INFO - 2023-02-10 06:31:49 --> Router Class Initialized
INFO - 2023-02-10 06:31:49 --> Output Class Initialized
INFO - 2023-02-10 06:31:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:49 --> Input Class Initialized
INFO - 2023-02-10 06:31:49 --> Language Class Initialized
INFO - 2023-02-10 06:31:49 --> Loader Class Initialized
INFO - 2023-02-10 06:31:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:49 --> Total execution time: 0.0798
INFO - 2023-02-10 06:31:49 --> Config Class Initialized
INFO - 2023-02-10 06:31:49 --> Hooks Class Initialized
INFO - 2023-02-10 06:31:49 --> Config Class Initialized
DEBUG - 2023-02-10 06:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:49 --> Hooks Class Initialized
INFO - 2023-02-10 06:31:49 --> Utf8 Class Initialized
DEBUG - 2023-02-10 06:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:49 --> URI Class Initialized
INFO - 2023-02-10 06:31:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:49 --> Router Class Initialized
INFO - 2023-02-10 06:31:49 --> URI Class Initialized
INFO - 2023-02-10 06:31:49 --> Output Class Initialized
INFO - 2023-02-10 06:31:49 --> Router Class Initialized
INFO - 2023-02-10 06:31:49 --> Output Class Initialized
INFO - 2023-02-10 06:31:49 --> Security Class Initialized
INFO - 2023-02-10 06:31:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:49 --> Input Class Initialized
INFO - 2023-02-10 06:31:49 --> Input Class Initialized
INFO - 2023-02-10 06:31:49 --> Language Class Initialized
INFO - 2023-02-10 06:31:49 --> Language Class Initialized
INFO - 2023-02-10 06:31:49 --> Loader Class Initialized
INFO - 2023-02-10 06:31:49 --> Loader Class Initialized
INFO - 2023-02-10 06:31:49 --> Controller Class Initialized
INFO - 2023-02-10 06:31:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:49 --> Final output sent to browser
INFO - 2023-02-10 06:31:49 --> Database Driver Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Total execution time: 0.0038
INFO - 2023-02-10 06:31:49 --> Config Class Initialized
INFO - 2023-02-10 06:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:49 --> URI Class Initialized
INFO - 2023-02-10 06:31:49 --> Router Class Initialized
INFO - 2023-02-10 06:31:49 --> Output Class Initialized
INFO - 2023-02-10 06:31:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:49 --> Input Class Initialized
INFO - 2023-02-10 06:31:49 --> Language Class Initialized
INFO - 2023-02-10 06:31:49 --> Loader Class Initialized
INFO - 2023-02-10 06:31:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:49 --> Model "Login_model" initialized
INFO - 2023-02-10 06:31:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:49 --> Total execution time: 0.0184
INFO - 2023-02-10 06:31:49 --> Config Class Initialized
INFO - 2023-02-10 06:31:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:31:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:31:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:31:49 --> URI Class Initialized
INFO - 2023-02-10 06:31:49 --> Router Class Initialized
INFO - 2023-02-10 06:31:49 --> Output Class Initialized
INFO - 2023-02-10 06:31:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:31:49 --> Input Class Initialized
INFO - 2023-02-10 06:31:49 --> Language Class Initialized
INFO - 2023-02-10 06:31:49 --> Loader Class Initialized
INFO - 2023-02-10 06:31:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:31:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:49 --> Total execution time: 0.0219
INFO - 2023-02-10 06:31:49 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:31:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:31:49 --> Total execution time: 0.0571
INFO - 2023-02-10 06:32:32 --> Config Class Initialized
INFO - 2023-02-10 06:32:32 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:32:32 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:32:32 --> Utf8 Class Initialized
INFO - 2023-02-10 06:32:32 --> URI Class Initialized
INFO - 2023-02-10 06:32:32 --> Router Class Initialized
INFO - 2023-02-10 06:32:32 --> Output Class Initialized
INFO - 2023-02-10 06:32:32 --> Security Class Initialized
DEBUG - 2023-02-10 06:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:32:32 --> Input Class Initialized
INFO - 2023-02-10 06:32:32 --> Language Class Initialized
INFO - 2023-02-10 06:32:32 --> Loader Class Initialized
INFO - 2023-02-10 06:32:32 --> Controller Class Initialized
DEBUG - 2023-02-10 06:32:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:32:32 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:32 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:32:33 --> Final output sent to browser
INFO - 2023-02-10 06:32:33 --> Config Class Initialized
INFO - 2023-02-10 06:32:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:32:33 --> Total execution time: 0.0505
DEBUG - 2023-02-10 06:32:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:32:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:32:33 --> URI Class Initialized
INFO - 2023-02-10 06:32:33 --> Router Class Initialized
INFO - 2023-02-10 06:32:33 --> Output Class Initialized
INFO - 2023-02-10 06:32:33 --> Security Class Initialized
DEBUG - 2023-02-10 06:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:32:33 --> Input Class Initialized
INFO - 2023-02-10 06:32:33 --> Language Class Initialized
INFO - 2023-02-10 06:32:33 --> Loader Class Initialized
INFO - 2023-02-10 06:32:33 --> Controller Class Initialized
DEBUG - 2023-02-10 06:32:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:32:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:32:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:32:33 --> Total execution time: 0.0834
INFO - 2023-02-10 06:32:35 --> Config Class Initialized
INFO - 2023-02-10 06:32:35 --> Config Class Initialized
INFO - 2023-02-10 06:32:35 --> Hooks Class Initialized
INFO - 2023-02-10 06:32:35 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:32:35 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:32:35 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:32:35 --> Utf8 Class Initialized
INFO - 2023-02-10 06:32:35 --> Utf8 Class Initialized
INFO - 2023-02-10 06:32:35 --> URI Class Initialized
INFO - 2023-02-10 06:32:35 --> URI Class Initialized
INFO - 2023-02-10 06:32:35 --> Router Class Initialized
INFO - 2023-02-10 06:32:35 --> Router Class Initialized
INFO - 2023-02-10 06:32:35 --> Output Class Initialized
INFO - 2023-02-10 06:32:35 --> Output Class Initialized
INFO - 2023-02-10 06:32:35 --> Security Class Initialized
INFO - 2023-02-10 06:32:35 --> Security Class Initialized
DEBUG - 2023-02-10 06:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:32:35 --> Input Class Initialized
INFO - 2023-02-10 06:32:35 --> Input Class Initialized
INFO - 2023-02-10 06:32:35 --> Language Class Initialized
INFO - 2023-02-10 06:32:35 --> Language Class Initialized
INFO - 2023-02-10 06:32:35 --> Loader Class Initialized
INFO - 2023-02-10 06:32:35 --> Loader Class Initialized
INFO - 2023-02-10 06:32:35 --> Controller Class Initialized
INFO - 2023-02-10 06:32:35 --> Controller Class Initialized
DEBUG - 2023-02-10 06:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:32:35 --> Final output sent to browser
DEBUG - 2023-02-10 06:32:35 --> Total execution time: 0.0042
INFO - 2023-02-10 06:32:35 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:35 --> Config Class Initialized
INFO - 2023-02-10 06:32:35 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:32:35 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:32:35 --> Utf8 Class Initialized
INFO - 2023-02-10 06:32:35 --> URI Class Initialized
INFO - 2023-02-10 06:32:35 --> Router Class Initialized
INFO - 2023-02-10 06:32:35 --> Output Class Initialized
INFO - 2023-02-10 06:32:35 --> Security Class Initialized
DEBUG - 2023-02-10 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:32:35 --> Input Class Initialized
INFO - 2023-02-10 06:32:35 --> Language Class Initialized
INFO - 2023-02-10 06:32:35 --> Loader Class Initialized
INFO - 2023-02-10 06:32:35 --> Controller Class Initialized
DEBUG - 2023-02-10 06:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:32:35 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:35 --> Model "Login_model" initialized
INFO - 2023-02-10 06:32:35 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:32:35 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:35 --> Final output sent to browser
DEBUG - 2023-02-10 06:32:35 --> Total execution time: 0.0241
INFO - 2023-02-10 06:32:35 --> Config Class Initialized
INFO - 2023-02-10 06:32:35 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:32:35 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:32:35 --> Utf8 Class Initialized
INFO - 2023-02-10 06:32:35 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:32:35 --> URI Class Initialized
INFO - 2023-02-10 06:32:35 --> Router Class Initialized
INFO - 2023-02-10 06:32:35 --> Output Class Initialized
INFO - 2023-02-10 06:32:35 --> Security Class Initialized
DEBUG - 2023-02-10 06:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:32:35 --> Input Class Initialized
INFO - 2023-02-10 06:32:35 --> Language Class Initialized
INFO - 2023-02-10 06:32:35 --> Loader Class Initialized
INFO - 2023-02-10 06:32:35 --> Controller Class Initialized
DEBUG - 2023-02-10 06:32:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:32:35 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:35 --> Final output sent to browser
DEBUG - 2023-02-10 06:32:35 --> Total execution time: 0.0244
INFO - 2023-02-10 06:32:35 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:32:35 --> Final output sent to browser
DEBUG - 2023-02-10 06:32:35 --> Total execution time: 0.0547
INFO - 2023-02-10 06:32:37 --> Config Class Initialized
INFO - 2023-02-10 06:32:37 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:32:37 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:32:37 --> Utf8 Class Initialized
INFO - 2023-02-10 06:32:37 --> URI Class Initialized
INFO - 2023-02-10 06:32:37 --> Router Class Initialized
INFO - 2023-02-10 06:32:37 --> Output Class Initialized
INFO - 2023-02-10 06:32:37 --> Security Class Initialized
DEBUG - 2023-02-10 06:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:32:37 --> Input Class Initialized
INFO - 2023-02-10 06:32:37 --> Language Class Initialized
INFO - 2023-02-10 06:32:37 --> Loader Class Initialized
INFO - 2023-02-10 06:32:37 --> Controller Class Initialized
DEBUG - 2023-02-10 06:32:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:32:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:37 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:32:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:37 --> Model "Login_model" initialized
INFO - 2023-02-10 06:32:37 --> Final output sent to browser
DEBUG - 2023-02-10 06:32:37 --> Total execution time: 0.0412
INFO - 2023-02-10 06:32:37 --> Config Class Initialized
INFO - 2023-02-10 06:32:37 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:32:37 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:32:37 --> Utf8 Class Initialized
INFO - 2023-02-10 06:32:37 --> URI Class Initialized
INFO - 2023-02-10 06:32:37 --> Router Class Initialized
INFO - 2023-02-10 06:32:37 --> Output Class Initialized
INFO - 2023-02-10 06:32:37 --> Security Class Initialized
DEBUG - 2023-02-10 06:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:32:37 --> Input Class Initialized
INFO - 2023-02-10 06:32:37 --> Language Class Initialized
INFO - 2023-02-10 06:32:37 --> Loader Class Initialized
INFO - 2023-02-10 06:32:37 --> Controller Class Initialized
DEBUG - 2023-02-10 06:32:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:32:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:37 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:32:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:32:37 --> Model "Login_model" initialized
INFO - 2023-02-10 06:32:37 --> Final output sent to browser
DEBUG - 2023-02-10 06:32:37 --> Total execution time: 0.0445
INFO - 2023-02-10 06:35:41 --> Config Class Initialized
INFO - 2023-02-10 06:35:41 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:41 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:41 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:41 --> URI Class Initialized
INFO - 2023-02-10 06:35:41 --> Router Class Initialized
INFO - 2023-02-10 06:35:41 --> Output Class Initialized
INFO - 2023-02-10 06:35:41 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:41 --> Input Class Initialized
INFO - 2023-02-10 06:35:41 --> Language Class Initialized
INFO - 2023-02-10 06:35:41 --> Loader Class Initialized
INFO - 2023-02-10 06:35:41 --> Controller Class Initialized
DEBUG - 2023-02-10 06:35:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:41 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:41 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:35:41 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:41 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:41 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:41 --> Total execution time: 0.0387
INFO - 2023-02-10 06:35:41 --> Config Class Initialized
INFO - 2023-02-10 06:35:41 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:41 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:41 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:41 --> URI Class Initialized
INFO - 2023-02-10 06:35:41 --> Router Class Initialized
INFO - 2023-02-10 06:35:41 --> Output Class Initialized
INFO - 2023-02-10 06:35:41 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:41 --> Input Class Initialized
INFO - 2023-02-10 06:35:41 --> Language Class Initialized
INFO - 2023-02-10 06:35:41 --> Loader Class Initialized
INFO - 2023-02-10 06:35:41 --> Controller Class Initialized
DEBUG - 2023-02-10 06:35:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:41 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:41 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:35:41 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:41 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:41 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:41 --> Total execution time: 0.0370
INFO - 2023-02-10 06:35:48 --> Config Class Initialized
INFO - 2023-02-10 06:35:48 --> Hooks Class Initialized
INFO - 2023-02-10 06:35:48 --> Config Class Initialized
INFO - 2023-02-10 06:35:48 --> Config Class Initialized
INFO - 2023-02-10 06:35:48 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:48 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:48 --> Hooks Class Initialized
INFO - 2023-02-10 06:35:48 --> Utf8 Class Initialized
DEBUG - 2023-02-10 06:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:35:48 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:48 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:48 --> URI Class Initialized
INFO - 2023-02-10 06:35:48 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:48 --> URI Class Initialized
INFO - 2023-02-10 06:35:48 --> URI Class Initialized
INFO - 2023-02-10 06:35:48 --> Router Class Initialized
INFO - 2023-02-10 06:35:48 --> Router Class Initialized
INFO - 2023-02-10 06:35:48 --> Router Class Initialized
INFO - 2023-02-10 06:35:48 --> Output Class Initialized
INFO - 2023-02-10 06:35:48 --> Output Class Initialized
INFO - 2023-02-10 06:35:48 --> Output Class Initialized
INFO - 2023-02-10 06:35:48 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:48 --> Input Class Initialized
INFO - 2023-02-10 06:35:48 --> Language Class Initialized
INFO - 2023-02-10 06:35:48 --> Security Class Initialized
INFO - 2023-02-10 06:35:48 --> Security Class Initialized
INFO - 2023-02-10 06:35:48 --> Loader Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:48 --> Controller Class Initialized
INFO - 2023-02-10 06:35:48 --> Input Class Initialized
INFO - 2023-02-10 06:35:48 --> Input Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:48 --> Language Class Initialized
INFO - 2023-02-10 06:35:48 --> Language Class Initialized
INFO - 2023-02-10 06:35:48 --> Loader Class Initialized
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:48 --> Controller Class Initialized
INFO - 2023-02-10 06:35:48 --> Loader Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:48 --> Controller Class Initialized
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:48 --> Final output sent to browser
INFO - 2023-02-10 06:35:48 --> Final output sent to browser
INFO - 2023-02-10 06:35:48 --> Model "Login_model" initialized
DEBUG - 2023-02-10 06:35:48 --> Total execution time: 0.0139
DEBUG - 2023-02-10 06:35:48 --> Total execution time: 0.0145
INFO - 2023-02-10 06:35:48 --> Config Class Initialized
INFO - 2023-02-10 06:35:48 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:48 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:48 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:48 --> URI Class Initialized
INFO - 2023-02-10 06:35:48 --> Router Class Initialized
INFO - 2023-02-10 06:35:48 --> Config Class Initialized
INFO - 2023-02-10 06:35:48 --> Final output sent to browser
INFO - 2023-02-10 06:35:48 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Total execution time: 0.0229
INFO - 2023-02-10 06:35:48 --> Output Class Initialized
INFO - 2023-02-10 06:35:48 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:48 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:48 --> Input Class Initialized
INFO - 2023-02-10 06:35:48 --> URI Class Initialized
INFO - 2023-02-10 06:35:48 --> Language Class Initialized
INFO - 2023-02-10 06:35:48 --> Config Class Initialized
INFO - 2023-02-10 06:35:48 --> Router Class Initialized
INFO - 2023-02-10 06:35:48 --> Hooks Class Initialized
INFO - 2023-02-10 06:35:48 --> Output Class Initialized
INFO - 2023-02-10 06:35:48 --> Loader Class Initialized
INFO - 2023-02-10 06:35:48 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:48 --> Input Class Initialized
INFO - 2023-02-10 06:35:48 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:48 --> Controller Class Initialized
INFO - 2023-02-10 06:35:48 --> Language Class Initialized
INFO - 2023-02-10 06:35:48 --> URI Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:48 --> Loader Class Initialized
INFO - 2023-02-10 06:35:48 --> Router Class Initialized
INFO - 2023-02-10 06:35:48 --> Final output sent to browser
INFO - 2023-02-10 06:35:48 --> Controller Class Initialized
INFO - 2023-02-10 06:35:48 --> Output Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:35:48 --> Total execution time: 0.0857
INFO - 2023-02-10 06:35:48 --> Security Class Initialized
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:48 --> Input Class Initialized
INFO - 2023-02-10 06:35:48 --> Language Class Initialized
INFO - 2023-02-10 06:35:48 --> Loader Class Initialized
INFO - 2023-02-10 06:35:48 --> Config Class Initialized
INFO - 2023-02-10 06:35:48 --> Controller Class Initialized
INFO - 2023-02-10 06:35:48 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:35:48 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:48 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:48 --> URI Class Initialized
INFO - 2023-02-10 06:35:48 --> Router Class Initialized
INFO - 2023-02-10 06:35:48 --> Output Class Initialized
INFO - 2023-02-10 06:35:48 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:48 --> Input Class Initialized
INFO - 2023-02-10 06:35:48 --> Language Class Initialized
INFO - 2023-02-10 06:35:48 --> Loader Class Initialized
INFO - 2023-02-10 06:35:48 --> Controller Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:48 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:48 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:48 --> Final output sent to browser
INFO - 2023-02-10 06:35:48 --> Model "Login_model" initialized
DEBUG - 2023-02-10 06:35:48 --> Total execution time: 0.0177
INFO - 2023-02-10 06:35:48 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:48 --> Total execution time: 0.1040
INFO - 2023-02-10 06:35:48 --> Config Class Initialized
INFO - 2023-02-10 06:35:48 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:48 --> Total execution time: 0.0681
INFO - 2023-02-10 06:35:48 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:48 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:48 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:48 --> URI Class Initialized
INFO - 2023-02-10 06:35:48 --> Router Class Initialized
INFO - 2023-02-10 06:35:48 --> Output Class Initialized
INFO - 2023-02-10 06:35:48 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:48 --> Input Class Initialized
INFO - 2023-02-10 06:35:48 --> Language Class Initialized
INFO - 2023-02-10 06:35:48 --> Loader Class Initialized
INFO - 2023-02-10 06:35:48 --> Controller Class Initialized
DEBUG - 2023-02-10 06:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:48 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:48 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:48 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:35:48 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:48 --> Total execution time: 0.1068
INFO - 2023-02-10 06:35:52 --> Config Class Initialized
INFO - 2023-02-10 06:35:52 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:52 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:52 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:52 --> URI Class Initialized
INFO - 2023-02-10 06:35:52 --> Router Class Initialized
INFO - 2023-02-10 06:35:52 --> Output Class Initialized
INFO - 2023-02-10 06:35:52 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:52 --> Input Class Initialized
INFO - 2023-02-10 06:35:52 --> Language Class Initialized
INFO - 2023-02-10 06:35:52 --> Loader Class Initialized
INFO - 2023-02-10 06:35:52 --> Controller Class Initialized
DEBUG - 2023-02-10 06:35:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:52 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:52 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:52 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:52 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:52 --> Total execution time: 0.0267
INFO - 2023-02-10 06:35:52 --> Config Class Initialized
INFO - 2023-02-10 06:35:52 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:52 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:52 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:52 --> URI Class Initialized
INFO - 2023-02-10 06:35:52 --> Router Class Initialized
INFO - 2023-02-10 06:35:52 --> Output Class Initialized
INFO - 2023-02-10 06:35:52 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:52 --> Input Class Initialized
INFO - 2023-02-10 06:35:52 --> Language Class Initialized
INFO - 2023-02-10 06:35:52 --> Loader Class Initialized
INFO - 2023-02-10 06:35:52 --> Controller Class Initialized
DEBUG - 2023-02-10 06:35:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:52 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:52 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:52 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:52 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:52 --> Total execution time: 0.0660
INFO - 2023-02-10 06:35:55 --> Config Class Initialized
INFO - 2023-02-10 06:35:55 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:55 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:55 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:55 --> URI Class Initialized
INFO - 2023-02-10 06:35:55 --> Router Class Initialized
INFO - 2023-02-10 06:35:55 --> Output Class Initialized
INFO - 2023-02-10 06:35:55 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:55 --> Input Class Initialized
INFO - 2023-02-10 06:35:55 --> Language Class Initialized
INFO - 2023-02-10 06:35:55 --> Loader Class Initialized
INFO - 2023-02-10 06:35:55 --> Controller Class Initialized
DEBUG - 2023-02-10 06:35:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:55 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:55 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:55 --> Total execution time: 0.0239
INFO - 2023-02-10 06:35:55 --> Config Class Initialized
INFO - 2023-02-10 06:35:55 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:35:55 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:35:55 --> Utf8 Class Initialized
INFO - 2023-02-10 06:35:55 --> URI Class Initialized
INFO - 2023-02-10 06:35:55 --> Router Class Initialized
INFO - 2023-02-10 06:35:55 --> Output Class Initialized
INFO - 2023-02-10 06:35:55 --> Security Class Initialized
DEBUG - 2023-02-10 06:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:35:55 --> Input Class Initialized
INFO - 2023-02-10 06:35:55 --> Language Class Initialized
INFO - 2023-02-10 06:35:55 --> Loader Class Initialized
INFO - 2023-02-10 06:35:55 --> Controller Class Initialized
DEBUG - 2023-02-10 06:35:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:35:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:35:55 --> Model "Login_model" initialized
INFO - 2023-02-10 06:35:55 --> Final output sent to browser
DEBUG - 2023-02-10 06:35:55 --> Total execution time: 0.0280
INFO - 2023-02-10 06:36:30 --> Config Class Initialized
INFO - 2023-02-10 06:36:30 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:36:30 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:36:30 --> Utf8 Class Initialized
INFO - 2023-02-10 06:36:30 --> URI Class Initialized
INFO - 2023-02-10 06:36:30 --> Router Class Initialized
INFO - 2023-02-10 06:36:30 --> Output Class Initialized
INFO - 2023-02-10 06:36:30 --> Security Class Initialized
DEBUG - 2023-02-10 06:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:36:30 --> Input Class Initialized
INFO - 2023-02-10 06:36:30 --> Language Class Initialized
INFO - 2023-02-10 06:36:30 --> Loader Class Initialized
INFO - 2023-02-10 06:36:30 --> Controller Class Initialized
DEBUG - 2023-02-10 06:36:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:36:30 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:30 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:30 --> Model "Login_model" initialized
INFO - 2023-02-10 06:36:30 --> Final output sent to browser
DEBUG - 2023-02-10 06:36:30 --> Total execution time: 0.0373
INFO - 2023-02-10 06:36:30 --> Config Class Initialized
INFO - 2023-02-10 06:36:30 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:36:30 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:36:30 --> Utf8 Class Initialized
INFO - 2023-02-10 06:36:30 --> URI Class Initialized
INFO - 2023-02-10 06:36:30 --> Router Class Initialized
INFO - 2023-02-10 06:36:30 --> Output Class Initialized
INFO - 2023-02-10 06:36:30 --> Security Class Initialized
DEBUG - 2023-02-10 06:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:36:30 --> Input Class Initialized
INFO - 2023-02-10 06:36:30 --> Language Class Initialized
INFO - 2023-02-10 06:36:30 --> Loader Class Initialized
INFO - 2023-02-10 06:36:30 --> Controller Class Initialized
DEBUG - 2023-02-10 06:36:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:36:30 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:30 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:30 --> Model "Login_model" initialized
INFO - 2023-02-10 06:36:30 --> Final output sent to browser
DEBUG - 2023-02-10 06:36:30 --> Total execution time: 0.0211
INFO - 2023-02-10 06:36:33 --> Config Class Initialized
INFO - 2023-02-10 06:36:33 --> Config Class Initialized
INFO - 2023-02-10 06:36:33 --> Hooks Class Initialized
INFO - 2023-02-10 06:36:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:36:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:36:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:36:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:36:33 --> URI Class Initialized
INFO - 2023-02-10 06:36:33 --> URI Class Initialized
INFO - 2023-02-10 06:36:33 --> Router Class Initialized
INFO - 2023-02-10 06:36:33 --> Router Class Initialized
INFO - 2023-02-10 06:36:33 --> Output Class Initialized
INFO - 2023-02-10 06:36:33 --> Output Class Initialized
INFO - 2023-02-10 06:36:33 --> Security Class Initialized
INFO - 2023-02-10 06:36:33 --> Security Class Initialized
DEBUG - 2023-02-10 06:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:36:33 --> Input Class Initialized
INFO - 2023-02-10 06:36:33 --> Input Class Initialized
INFO - 2023-02-10 06:36:33 --> Language Class Initialized
INFO - 2023-02-10 06:36:33 --> Language Class Initialized
INFO - 2023-02-10 06:36:33 --> Loader Class Initialized
INFO - 2023-02-10 06:36:33 --> Loader Class Initialized
INFO - 2023-02-10 06:36:33 --> Controller Class Initialized
INFO - 2023-02-10 06:36:33 --> Controller Class Initialized
DEBUG - 2023-02-10 06:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:36:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:36:33 --> Total execution time: 0.0049
INFO - 2023-02-10 06:36:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:33 --> Config Class Initialized
INFO - 2023-02-10 06:36:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:36:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:36:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:36:33 --> URI Class Initialized
INFO - 2023-02-10 06:36:33 --> Router Class Initialized
INFO - 2023-02-10 06:36:33 --> Output Class Initialized
INFO - 2023-02-10 06:36:33 --> Security Class Initialized
DEBUG - 2023-02-10 06:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:36:33 --> Input Class Initialized
INFO - 2023-02-10 06:36:33 --> Language Class Initialized
INFO - 2023-02-10 06:36:33 --> Loader Class Initialized
INFO - 2023-02-10 06:36:33 --> Controller Class Initialized
DEBUG - 2023-02-10 06:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:36:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:36:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:36:33 --> Total execution time: 0.0173
INFO - 2023-02-10 06:36:33 --> Model "Login_model" initialized
INFO - 2023-02-10 06:36:33 --> Config Class Initialized
INFO - 2023-02-10 06:36:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:36:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:36:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:36:33 --> URI Class Initialized
INFO - 2023-02-10 06:36:33 --> Router Class Initialized
INFO - 2023-02-10 06:36:33 --> Output Class Initialized
INFO - 2023-02-10 06:36:33 --> Security Class Initialized
DEBUG - 2023-02-10 06:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:36:33 --> Input Class Initialized
INFO - 2023-02-10 06:36:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:33 --> Language Class Initialized
INFO - 2023-02-10 06:36:33 --> Loader Class Initialized
INFO - 2023-02-10 06:36:33 --> Controller Class Initialized
DEBUG - 2023-02-10 06:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:36:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:36:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:36:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:36:33 --> Total execution time: 0.0231
INFO - 2023-02-10 06:36:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:36:33 --> Total execution time: 0.0151
INFO - 2023-02-10 06:36:35 --> Config Class Initialized
INFO - 2023-02-10 06:36:35 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:36:35 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:36:35 --> Utf8 Class Initialized
INFO - 2023-02-10 06:36:35 --> URI Class Initialized
INFO - 2023-02-10 06:36:35 --> Router Class Initialized
INFO - 2023-02-10 06:36:35 --> Output Class Initialized
INFO - 2023-02-10 06:36:35 --> Security Class Initialized
DEBUG - 2023-02-10 06:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:36:35 --> Input Class Initialized
INFO - 2023-02-10 06:36:35 --> Language Class Initialized
INFO - 2023-02-10 06:36:35 --> Loader Class Initialized
INFO - 2023-02-10 06:36:35 --> Controller Class Initialized
DEBUG - 2023-02-10 06:36:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:36:35 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:35 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:36:35 --> Final output sent to browser
DEBUG - 2023-02-10 06:36:35 --> Total execution time: 0.0356
INFO - 2023-02-10 06:36:35 --> Config Class Initialized
INFO - 2023-02-10 06:36:35 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:36:35 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:36:35 --> Utf8 Class Initialized
INFO - 2023-02-10 06:36:35 --> URI Class Initialized
INFO - 2023-02-10 06:36:35 --> Router Class Initialized
INFO - 2023-02-10 06:36:35 --> Output Class Initialized
INFO - 2023-02-10 06:36:35 --> Security Class Initialized
DEBUG - 2023-02-10 06:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:36:35 --> Input Class Initialized
INFO - 2023-02-10 06:36:35 --> Language Class Initialized
INFO - 2023-02-10 06:36:35 --> Loader Class Initialized
INFO - 2023-02-10 06:36:35 --> Controller Class Initialized
DEBUG - 2023-02-10 06:36:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:36:35 --> Database Driver Class Initialized
INFO - 2023-02-10 06:36:35 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:36:35 --> Final output sent to browser
DEBUG - 2023-02-10 06:36:35 --> Total execution time: 0.0356
INFO - 2023-02-10 06:37:55 --> Config Class Initialized
INFO - 2023-02-10 06:37:55 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:37:55 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:37:55 --> Utf8 Class Initialized
INFO - 2023-02-10 06:37:55 --> URI Class Initialized
INFO - 2023-02-10 06:37:55 --> Router Class Initialized
INFO - 2023-02-10 06:37:55 --> Output Class Initialized
INFO - 2023-02-10 06:37:55 --> Security Class Initialized
DEBUG - 2023-02-10 06:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:37:55 --> Input Class Initialized
INFO - 2023-02-10 06:37:55 --> Language Class Initialized
INFO - 2023-02-10 06:37:55 --> Loader Class Initialized
INFO - 2023-02-10 06:37:55 --> Controller Class Initialized
DEBUG - 2023-02-10 06:37:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:37:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:37:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:37:55 --> Model "Login_model" initialized
INFO - 2023-02-10 06:37:55 --> Final output sent to browser
DEBUG - 2023-02-10 06:37:55 --> Total execution time: 0.0251
INFO - 2023-02-10 06:37:55 --> Config Class Initialized
INFO - 2023-02-10 06:37:55 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:37:55 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:37:55 --> Utf8 Class Initialized
INFO - 2023-02-10 06:37:55 --> URI Class Initialized
INFO - 2023-02-10 06:37:55 --> Router Class Initialized
INFO - 2023-02-10 06:37:55 --> Output Class Initialized
INFO - 2023-02-10 06:37:55 --> Security Class Initialized
DEBUG - 2023-02-10 06:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:37:55 --> Input Class Initialized
INFO - 2023-02-10 06:37:55 --> Language Class Initialized
INFO - 2023-02-10 06:37:55 --> Loader Class Initialized
INFO - 2023-02-10 06:37:55 --> Controller Class Initialized
DEBUG - 2023-02-10 06:37:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:37:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:37:55 --> Database Driver Class Initialized
INFO - 2023-02-10 06:37:55 --> Model "Login_model" initialized
INFO - 2023-02-10 06:37:55 --> Final output sent to browser
DEBUG - 2023-02-10 06:37:55 --> Total execution time: 0.0194
INFO - 2023-02-10 06:47:49 --> Config Class Initialized
INFO - 2023-02-10 06:47:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:47:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:47:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:47:49 --> URI Class Initialized
INFO - 2023-02-10 06:47:49 --> Router Class Initialized
INFO - 2023-02-10 06:47:49 --> Output Class Initialized
INFO - 2023-02-10 06:47:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:47:49 --> Input Class Initialized
INFO - 2023-02-10 06:47:49 --> Language Class Initialized
INFO - 2023-02-10 06:47:49 --> Loader Class Initialized
INFO - 2023-02-10 06:47:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:47:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:47:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:49 --> Model "Login_model" initialized
INFO - 2023-02-10 06:47:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:47:49 --> Total execution time: 0.0238
INFO - 2023-02-10 06:47:49 --> Config Class Initialized
INFO - 2023-02-10 06:47:49 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:47:49 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:47:49 --> Utf8 Class Initialized
INFO - 2023-02-10 06:47:49 --> URI Class Initialized
INFO - 2023-02-10 06:47:49 --> Router Class Initialized
INFO - 2023-02-10 06:47:49 --> Output Class Initialized
INFO - 2023-02-10 06:47:49 --> Security Class Initialized
DEBUG - 2023-02-10 06:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:47:49 --> Input Class Initialized
INFO - 2023-02-10 06:47:49 --> Language Class Initialized
INFO - 2023-02-10 06:47:49 --> Loader Class Initialized
INFO - 2023-02-10 06:47:49 --> Controller Class Initialized
DEBUG - 2023-02-10 06:47:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:47:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:49 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:49 --> Model "Login_model" initialized
INFO - 2023-02-10 06:47:49 --> Final output sent to browser
DEBUG - 2023-02-10 06:47:49 --> Total execution time: 0.0196
INFO - 2023-02-10 06:47:51 --> Config Class Initialized
INFO - 2023-02-10 06:47:51 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:47:51 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:47:51 --> Utf8 Class Initialized
INFO - 2023-02-10 06:47:51 --> URI Class Initialized
INFO - 2023-02-10 06:47:51 --> Router Class Initialized
INFO - 2023-02-10 06:47:51 --> Output Class Initialized
INFO - 2023-02-10 06:47:51 --> Security Class Initialized
DEBUG - 2023-02-10 06:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:47:51 --> Input Class Initialized
INFO - 2023-02-10 06:47:51 --> Language Class Initialized
INFO - 2023-02-10 06:47:51 --> Loader Class Initialized
INFO - 2023-02-10 06:47:51 --> Controller Class Initialized
DEBUG - 2023-02-10 06:47:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:47:51 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:51 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:51 --> Model "Login_model" initialized
INFO - 2023-02-10 06:47:51 --> Final output sent to browser
DEBUG - 2023-02-10 06:47:51 --> Total execution time: 0.0725
INFO - 2023-02-10 06:47:51 --> Config Class Initialized
INFO - 2023-02-10 06:47:51 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:47:51 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:47:51 --> Utf8 Class Initialized
INFO - 2023-02-10 06:47:51 --> URI Class Initialized
INFO - 2023-02-10 06:47:51 --> Router Class Initialized
INFO - 2023-02-10 06:47:51 --> Output Class Initialized
INFO - 2023-02-10 06:47:51 --> Security Class Initialized
DEBUG - 2023-02-10 06:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:47:51 --> Input Class Initialized
INFO - 2023-02-10 06:47:51 --> Language Class Initialized
INFO - 2023-02-10 06:47:51 --> Loader Class Initialized
INFO - 2023-02-10 06:47:51 --> Controller Class Initialized
DEBUG - 2023-02-10 06:47:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:47:51 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:51 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:51 --> Model "Login_model" initialized
INFO - 2023-02-10 06:47:51 --> Final output sent to browser
DEBUG - 2023-02-10 06:47:51 --> Total execution time: 0.0529
INFO - 2023-02-10 06:47:54 --> Config Class Initialized
INFO - 2023-02-10 06:47:54 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:47:54 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:47:54 --> Utf8 Class Initialized
INFO - 2023-02-10 06:47:54 --> URI Class Initialized
INFO - 2023-02-10 06:47:54 --> Router Class Initialized
INFO - 2023-02-10 06:47:54 --> Output Class Initialized
INFO - 2023-02-10 06:47:54 --> Security Class Initialized
DEBUG - 2023-02-10 06:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:47:54 --> Input Class Initialized
INFO - 2023-02-10 06:47:54 --> Language Class Initialized
INFO - 2023-02-10 06:47:54 --> Loader Class Initialized
INFO - 2023-02-10 06:47:54 --> Controller Class Initialized
DEBUG - 2023-02-10 06:47:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:47:54 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:54 --> Database Driver Class Initialized
INFO - 2023-02-10 06:47:54 --> Model "Login_model" initialized
INFO - 2023-02-10 06:47:54 --> Final output sent to browser
DEBUG - 2023-02-10 06:47:54 --> Total execution time: 0.0353
INFO - 2023-02-10 06:54:33 --> Config Class Initialized
INFO - 2023-02-10 06:54:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:54:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:54:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:54:33 --> URI Class Initialized
INFO - 2023-02-10 06:54:33 --> Router Class Initialized
INFO - 2023-02-10 06:54:33 --> Output Class Initialized
INFO - 2023-02-10 06:54:33 --> Security Class Initialized
DEBUG - 2023-02-10 06:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:54:33 --> Input Class Initialized
INFO - 2023-02-10 06:54:33 --> Language Class Initialized
INFO - 2023-02-10 06:54:33 --> Loader Class Initialized
INFO - 2023-02-10 06:54:33 --> Controller Class Initialized
DEBUG - 2023-02-10 06:54:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:54:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:54:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:54:33 --> Total execution time: 0.0510
INFO - 2023-02-10 06:54:33 --> Config Class Initialized
INFO - 2023-02-10 06:54:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:54:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:54:33 --> Utf8 Class Initialized
INFO - 2023-02-10 06:54:33 --> URI Class Initialized
INFO - 2023-02-10 06:54:33 --> Router Class Initialized
INFO - 2023-02-10 06:54:33 --> Output Class Initialized
INFO - 2023-02-10 06:54:33 --> Security Class Initialized
DEBUG - 2023-02-10 06:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:54:33 --> Input Class Initialized
INFO - 2023-02-10 06:54:33 --> Language Class Initialized
INFO - 2023-02-10 06:54:33 --> Loader Class Initialized
INFO - 2023-02-10 06:54:33 --> Controller Class Initialized
DEBUG - 2023-02-10 06:54:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:54:33 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:54:33 --> Final output sent to browser
DEBUG - 2023-02-10 06:54:33 --> Total execution time: 0.0345
INFO - 2023-02-10 06:54:37 --> Config Class Initialized
INFO - 2023-02-10 06:54:37 --> Config Class Initialized
INFO - 2023-02-10 06:54:37 --> Hooks Class Initialized
INFO - 2023-02-10 06:54:37 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:54:37 --> UTF-8 Support Enabled
DEBUG - 2023-02-10 06:54:37 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:54:37 --> Utf8 Class Initialized
INFO - 2023-02-10 06:54:37 --> Utf8 Class Initialized
INFO - 2023-02-10 06:54:37 --> URI Class Initialized
INFO - 2023-02-10 06:54:37 --> URI Class Initialized
INFO - 2023-02-10 06:54:37 --> Router Class Initialized
INFO - 2023-02-10 06:54:37 --> Router Class Initialized
INFO - 2023-02-10 06:54:37 --> Output Class Initialized
INFO - 2023-02-10 06:54:37 --> Output Class Initialized
INFO - 2023-02-10 06:54:37 --> Security Class Initialized
INFO - 2023-02-10 06:54:37 --> Security Class Initialized
DEBUG - 2023-02-10 06:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-10 06:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:54:37 --> Input Class Initialized
INFO - 2023-02-10 06:54:37 --> Input Class Initialized
INFO - 2023-02-10 06:54:37 --> Language Class Initialized
INFO - 2023-02-10 06:54:37 --> Language Class Initialized
INFO - 2023-02-10 06:54:37 --> Loader Class Initialized
INFO - 2023-02-10 06:54:37 --> Loader Class Initialized
INFO - 2023-02-10 06:54:37 --> Controller Class Initialized
INFO - 2023-02-10 06:54:37 --> Controller Class Initialized
DEBUG - 2023-02-10 06:54:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-10 06:54:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:54:37 --> Final output sent to browser
DEBUG - 2023-02-10 06:54:37 --> Total execution time: 0.0059
INFO - 2023-02-10 06:54:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:37 --> Config Class Initialized
INFO - 2023-02-10 06:54:37 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:54:37 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:54:37 --> Utf8 Class Initialized
INFO - 2023-02-10 06:54:37 --> URI Class Initialized
INFO - 2023-02-10 06:54:37 --> Router Class Initialized
INFO - 2023-02-10 06:54:37 --> Output Class Initialized
INFO - 2023-02-10 06:54:37 --> Security Class Initialized
DEBUG - 2023-02-10 06:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:54:37 --> Input Class Initialized
INFO - 2023-02-10 06:54:37 --> Language Class Initialized
INFO - 2023-02-10 06:54:37 --> Loader Class Initialized
INFO - 2023-02-10 06:54:37 --> Controller Class Initialized
DEBUG - 2023-02-10 06:54:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:54:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:37 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:54:37 --> Final output sent to browser
DEBUG - 2023-02-10 06:54:37 --> Total execution time: 0.0173
INFO - 2023-02-10 06:54:37 --> Model "Login_model" initialized
INFO - 2023-02-10 06:54:37 --> Config Class Initialized
INFO - 2023-02-10 06:54:37 --> Hooks Class Initialized
INFO - 2023-02-10 06:54:37 --> Database Driver Class Initialized
DEBUG - 2023-02-10 06:54:37 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:54:37 --> Utf8 Class Initialized
INFO - 2023-02-10 06:54:37 --> URI Class Initialized
INFO - 2023-02-10 06:54:37 --> Router Class Initialized
INFO - 2023-02-10 06:54:37 --> Output Class Initialized
INFO - 2023-02-10 06:54:37 --> Security Class Initialized
DEBUG - 2023-02-10 06:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:54:37 --> Input Class Initialized
INFO - 2023-02-10 06:54:37 --> Language Class Initialized
INFO - 2023-02-10 06:54:37 --> Loader Class Initialized
INFO - 2023-02-10 06:54:37 --> Controller Class Initialized
DEBUG - 2023-02-10 06:54:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:54:37 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:37 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:54:37 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:54:37 --> Final output sent to browser
DEBUG - 2023-02-10 06:54:37 --> Total execution time: 0.0201
INFO - 2023-02-10 06:54:37 --> Final output sent to browser
DEBUG - 2023-02-10 06:54:37 --> Total execution time: 0.0128
INFO - 2023-02-10 06:54:44 --> Config Class Initialized
INFO - 2023-02-10 06:54:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:54:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:54:44 --> Utf8 Class Initialized
INFO - 2023-02-10 06:54:44 --> URI Class Initialized
INFO - 2023-02-10 06:54:44 --> Router Class Initialized
INFO - 2023-02-10 06:54:44 --> Output Class Initialized
INFO - 2023-02-10 06:54:44 --> Security Class Initialized
DEBUG - 2023-02-10 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:54:44 --> Input Class Initialized
INFO - 2023-02-10 06:54:44 --> Language Class Initialized
INFO - 2023-02-10 06:54:44 --> Loader Class Initialized
INFO - 2023-02-10 06:54:44 --> Controller Class Initialized
DEBUG - 2023-02-10 06:54:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:54:44 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:44 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:54:44 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:44 --> Model "Login_model" initialized
INFO - 2023-02-10 06:54:44 --> Final output sent to browser
DEBUG - 2023-02-10 06:54:44 --> Total execution time: 0.0362
INFO - 2023-02-10 06:54:44 --> Config Class Initialized
INFO - 2023-02-10 06:54:44 --> Hooks Class Initialized
DEBUG - 2023-02-10 06:54:44 --> UTF-8 Support Enabled
INFO - 2023-02-10 06:54:44 --> Utf8 Class Initialized
INFO - 2023-02-10 06:54:44 --> URI Class Initialized
INFO - 2023-02-10 06:54:44 --> Router Class Initialized
INFO - 2023-02-10 06:54:44 --> Output Class Initialized
INFO - 2023-02-10 06:54:44 --> Security Class Initialized
DEBUG - 2023-02-10 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 06:54:44 --> Input Class Initialized
INFO - 2023-02-10 06:54:44 --> Language Class Initialized
INFO - 2023-02-10 06:54:44 --> Loader Class Initialized
INFO - 2023-02-10 06:54:44 --> Controller Class Initialized
DEBUG - 2023-02-10 06:54:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 06:54:44 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:44 --> Model "Cluster_model" initialized
INFO - 2023-02-10 06:54:44 --> Database Driver Class Initialized
INFO - 2023-02-10 06:54:44 --> Model "Login_model" initialized
INFO - 2023-02-10 06:54:44 --> Final output sent to browser
DEBUG - 2023-02-10 06:54:44 --> Total execution time: 0.0318
INFO - 2023-02-10 08:12:31 --> Config Class Initialized
INFO - 2023-02-10 08:12:31 --> Hooks Class Initialized
DEBUG - 2023-02-10 08:12:31 --> UTF-8 Support Enabled
INFO - 2023-02-10 08:12:31 --> Utf8 Class Initialized
INFO - 2023-02-10 08:12:31 --> URI Class Initialized
INFO - 2023-02-10 08:12:31 --> Router Class Initialized
INFO - 2023-02-10 08:12:31 --> Output Class Initialized
INFO - 2023-02-10 08:12:31 --> Security Class Initialized
DEBUG - 2023-02-10 08:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 08:12:31 --> Input Class Initialized
INFO - 2023-02-10 08:12:31 --> Language Class Initialized
INFO - 2023-02-10 08:12:31 --> Loader Class Initialized
INFO - 2023-02-10 08:12:31 --> Controller Class Initialized
DEBUG - 2023-02-10 08:12:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 08:12:31 --> Database Driver Class Initialized
INFO - 2023-02-10 08:12:31 --> Model "Cluster_model" initialized
INFO - 2023-02-10 08:12:31 --> Final output sent to browser
DEBUG - 2023-02-10 08:12:31 --> Total execution time: 0.0397
INFO - 2023-02-10 08:12:31 --> Config Class Initialized
INFO - 2023-02-10 08:12:31 --> Hooks Class Initialized
DEBUG - 2023-02-10 08:12:31 --> UTF-8 Support Enabled
INFO - 2023-02-10 08:12:31 --> Utf8 Class Initialized
INFO - 2023-02-10 08:12:31 --> URI Class Initialized
INFO - 2023-02-10 08:12:31 --> Router Class Initialized
INFO - 2023-02-10 08:12:31 --> Output Class Initialized
INFO - 2023-02-10 08:12:31 --> Security Class Initialized
DEBUG - 2023-02-10 08:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 08:12:31 --> Input Class Initialized
INFO - 2023-02-10 08:12:31 --> Language Class Initialized
INFO - 2023-02-10 08:12:31 --> Loader Class Initialized
INFO - 2023-02-10 08:12:31 --> Controller Class Initialized
DEBUG - 2023-02-10 08:12:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 08:12:31 --> Database Driver Class Initialized
INFO - 2023-02-10 08:12:31 --> Model "Cluster_model" initialized
INFO - 2023-02-10 08:12:31 --> Final output sent to browser
DEBUG - 2023-02-10 08:12:31 --> Total execution time: 0.0771
INFO - 2023-02-10 08:12:32 --> Config Class Initialized
INFO - 2023-02-10 08:12:32 --> Hooks Class Initialized
DEBUG - 2023-02-10 08:12:32 --> UTF-8 Support Enabled
INFO - 2023-02-10 08:12:32 --> Utf8 Class Initialized
INFO - 2023-02-10 08:12:32 --> URI Class Initialized
INFO - 2023-02-10 08:12:32 --> Router Class Initialized
INFO - 2023-02-10 08:12:32 --> Output Class Initialized
INFO - 2023-02-10 08:12:32 --> Security Class Initialized
DEBUG - 2023-02-10 08:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 08:12:32 --> Input Class Initialized
INFO - 2023-02-10 08:12:32 --> Language Class Initialized
INFO - 2023-02-10 08:12:32 --> Loader Class Initialized
INFO - 2023-02-10 08:12:32 --> Controller Class Initialized
DEBUG - 2023-02-10 08:12:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 08:12:32 --> Database Driver Class Initialized
INFO - 2023-02-10 08:12:32 --> Model "Cluster_model" initialized
INFO - 2023-02-10 08:12:32 --> Final output sent to browser
DEBUG - 2023-02-10 08:12:32 --> Total execution time: 0.0158
INFO - 2023-02-10 08:12:32 --> Config Class Initialized
INFO - 2023-02-10 08:12:33 --> Hooks Class Initialized
DEBUG - 2023-02-10 08:12:33 --> UTF-8 Support Enabled
INFO - 2023-02-10 08:12:33 --> Utf8 Class Initialized
INFO - 2023-02-10 08:12:33 --> URI Class Initialized
INFO - 2023-02-10 08:12:33 --> Router Class Initialized
INFO - 2023-02-10 08:12:33 --> Output Class Initialized
INFO - 2023-02-10 08:12:33 --> Security Class Initialized
DEBUG - 2023-02-10 08:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 08:12:33 --> Input Class Initialized
INFO - 2023-02-10 08:12:33 --> Language Class Initialized
INFO - 2023-02-10 08:12:33 --> Loader Class Initialized
INFO - 2023-02-10 08:12:33 --> Controller Class Initialized
DEBUG - 2023-02-10 08:12:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 08:12:33 --> Database Driver Class Initialized
INFO - 2023-02-10 08:12:33 --> Model "Cluster_model" initialized
INFO - 2023-02-10 08:12:33 --> Final output sent to browser
DEBUG - 2023-02-10 08:12:33 --> Total execution time: 0.0568
INFO - 2023-02-10 08:12:38 --> Config Class Initialized
INFO - 2023-02-10 08:12:38 --> Hooks Class Initialized
DEBUG - 2023-02-10 08:12:38 --> UTF-8 Support Enabled
INFO - 2023-02-10 08:12:38 --> Utf8 Class Initialized
INFO - 2023-02-10 08:12:38 --> URI Class Initialized
INFO - 2023-02-10 08:12:38 --> Router Class Initialized
INFO - 2023-02-10 08:12:38 --> Output Class Initialized
INFO - 2023-02-10 08:12:38 --> Security Class Initialized
DEBUG - 2023-02-10 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 08:12:38 --> Input Class Initialized
INFO - 2023-02-10 08:12:38 --> Language Class Initialized
INFO - 2023-02-10 08:12:38 --> Loader Class Initialized
INFO - 2023-02-10 08:12:38 --> Controller Class Initialized
DEBUG - 2023-02-10 08:12:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 08:12:38 --> Database Driver Class Initialized
INFO - 2023-02-10 08:12:38 --> Model "Cluster_model" initialized
INFO - 2023-02-10 08:12:38 --> Final output sent to browser
DEBUG - 2023-02-10 08:12:38 --> Total execution time: 0.0159
INFO - 2023-02-10 08:12:38 --> Config Class Initialized
INFO - 2023-02-10 08:12:38 --> Hooks Class Initialized
DEBUG - 2023-02-10 08:12:38 --> UTF-8 Support Enabled
INFO - 2023-02-10 08:12:38 --> Utf8 Class Initialized
INFO - 2023-02-10 08:12:38 --> URI Class Initialized
INFO - 2023-02-10 08:12:38 --> Router Class Initialized
INFO - 2023-02-10 08:12:38 --> Output Class Initialized
INFO - 2023-02-10 08:12:38 --> Security Class Initialized
DEBUG - 2023-02-10 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-10 08:12:38 --> Input Class Initialized
INFO - 2023-02-10 08:12:38 --> Language Class Initialized
INFO - 2023-02-10 08:12:38 --> Loader Class Initialized
INFO - 2023-02-10 08:12:38 --> Controller Class Initialized
DEBUG - 2023-02-10 08:12:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-10 08:12:38 --> Database Driver Class Initialized
INFO - 2023-02-10 08:12:38 --> Model "Cluster_model" initialized
INFO - 2023-02-10 08:12:38 --> Final output sent to browser
DEBUG - 2023-02-10 08:12:38 --> Total execution time: 0.0530
