<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-25 07:11:31 --> Config Class Initialized
INFO - 2023-04-25 07:11:31 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:11:31 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:11:31 --> Utf8 Class Initialized
INFO - 2023-04-25 07:11:31 --> URI Class Initialized
INFO - 2023-04-25 07:11:31 --> Router Class Initialized
INFO - 2023-04-25 07:11:31 --> Output Class Initialized
INFO - 2023-04-25 07:11:31 --> Security Class Initialized
DEBUG - 2023-04-25 07:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:11:31 --> Input Class Initialized
INFO - 2023-04-25 07:11:31 --> Language Class Initialized
INFO - 2023-04-25 07:11:31 --> Loader Class Initialized
INFO - 2023-04-25 07:11:31 --> Controller Class Initialized
INFO - 2023-04-25 07:11:31 --> Helper loaded: form_helper
INFO - 2023-04-25 07:11:31 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:11:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:11:31 --> Model "Change_model" initialized
INFO - 2023-04-25 07:12:00 --> Config Class Initialized
INFO - 2023-04-25 07:12:00 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:12:00 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:12:00 --> Utf8 Class Initialized
INFO - 2023-04-25 07:12:00 --> URI Class Initialized
INFO - 2023-04-25 07:12:00 --> Router Class Initialized
INFO - 2023-04-25 07:12:00 --> Output Class Initialized
INFO - 2023-04-25 07:12:00 --> Security Class Initialized
DEBUG - 2023-04-25 07:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:12:00 --> Input Class Initialized
INFO - 2023-04-25 07:12:00 --> Language Class Initialized
INFO - 2023-04-25 07:12:00 --> Loader Class Initialized
INFO - 2023-04-25 07:12:00 --> Controller Class Initialized
INFO - 2023-04-25 07:12:00 --> Helper loaded: form_helper
INFO - 2023-04-25 07:12:00 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:12:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:12:00 --> Model "Change_model" initialized
INFO - 2023-04-25 07:12:31 --> Final output sent to browser
DEBUG - 2023-04-25 07:12:31 --> Total execution time: 60.0479
INFO - 2023-04-25 07:13:00 --> Final output sent to browser
DEBUG - 2023-04-25 07:13:00 --> Total execution time: 60.0079
INFO - 2023-04-25 07:13:56 --> Config Class Initialized
INFO - 2023-04-25 07:13:56 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:13:56 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:13:56 --> Utf8 Class Initialized
INFO - 2023-04-25 07:13:56 --> URI Class Initialized
INFO - 2023-04-25 07:13:56 --> Router Class Initialized
INFO - 2023-04-25 07:13:56 --> Output Class Initialized
INFO - 2023-04-25 07:13:56 --> Security Class Initialized
DEBUG - 2023-04-25 07:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:13:56 --> Input Class Initialized
INFO - 2023-04-25 07:13:56 --> Language Class Initialized
INFO - 2023-04-25 07:13:56 --> Loader Class Initialized
INFO - 2023-04-25 07:13:56 --> Controller Class Initialized
INFO - 2023-04-25 07:13:56 --> Helper loaded: form_helper
INFO - 2023-04-25 07:13:56 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:13:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:13:56 --> Model "Change_model" initialized
INFO - 2023-04-25 07:14:56 --> Final output sent to browser
DEBUG - 2023-04-25 07:14:56 --> Total execution time: 60.0172
INFO - 2023-04-25 07:15:13 --> Config Class Initialized
INFO - 2023-04-25 07:15:13 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:15:13 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:15:13 --> Utf8 Class Initialized
INFO - 2023-04-25 07:15:13 --> URI Class Initialized
INFO - 2023-04-25 07:15:13 --> Router Class Initialized
INFO - 2023-04-25 07:15:13 --> Output Class Initialized
INFO - 2023-04-25 07:15:13 --> Security Class Initialized
DEBUG - 2023-04-25 07:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:15:13 --> Input Class Initialized
INFO - 2023-04-25 07:15:13 --> Language Class Initialized
INFO - 2023-04-25 07:15:13 --> Loader Class Initialized
INFO - 2023-04-25 07:15:13 --> Controller Class Initialized
INFO - 2023-04-25 07:15:13 --> Helper loaded: form_helper
INFO - 2023-04-25 07:15:13 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:15:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:15:13 --> Model "Change_model" initialized
INFO - 2023-04-25 07:16:13 --> Final output sent to browser
DEBUG - 2023-04-25 07:16:13 --> Total execution time: 60.0060
INFO - 2023-04-25 07:30:24 --> Config Class Initialized
INFO - 2023-04-25 07:30:24 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:30:24 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:30:24 --> Utf8 Class Initialized
INFO - 2023-04-25 07:30:24 --> URI Class Initialized
INFO - 2023-04-25 07:30:24 --> Router Class Initialized
INFO - 2023-04-25 07:30:24 --> Output Class Initialized
INFO - 2023-04-25 07:30:24 --> Security Class Initialized
DEBUG - 2023-04-25 07:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:30:24 --> Input Class Initialized
INFO - 2023-04-25 07:30:24 --> Language Class Initialized
INFO - 2023-04-25 07:30:24 --> Loader Class Initialized
INFO - 2023-04-25 07:30:24 --> Controller Class Initialized
INFO - 2023-04-25 07:30:24 --> Helper loaded: form_helper
INFO - 2023-04-25 07:30:24 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:30:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:30:24 --> Model "Change_model" initialized
INFO - 2023-04-25 07:30:25 --> Config Class Initialized
INFO - 2023-04-25 07:30:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:30:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:30:25 --> Utf8 Class Initialized
INFO - 2023-04-25 07:30:25 --> URI Class Initialized
INFO - 2023-04-25 07:30:25 --> Router Class Initialized
INFO - 2023-04-25 07:30:25 --> Output Class Initialized
INFO - 2023-04-25 07:30:25 --> Security Class Initialized
DEBUG - 2023-04-25 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:30:25 --> Input Class Initialized
INFO - 2023-04-25 07:30:25 --> Language Class Initialized
INFO - 2023-04-25 07:30:25 --> Loader Class Initialized
INFO - 2023-04-25 07:30:25 --> Controller Class Initialized
INFO - 2023-04-25 07:30:25 --> Helper loaded: form_helper
INFO - 2023-04-25 07:30:25 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:30:25 --> Model "Change_model" initialized
INFO - 2023-04-25 07:30:25 --> Config Class Initialized
INFO - 2023-04-25 07:30:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:30:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:30:25 --> Utf8 Class Initialized
INFO - 2023-04-25 07:30:25 --> URI Class Initialized
INFO - 2023-04-25 07:30:25 --> Router Class Initialized
INFO - 2023-04-25 07:30:25 --> Output Class Initialized
INFO - 2023-04-25 07:30:25 --> Security Class Initialized
DEBUG - 2023-04-25 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:30:25 --> Input Class Initialized
INFO - 2023-04-25 07:30:25 --> Language Class Initialized
INFO - 2023-04-25 07:30:25 --> Loader Class Initialized
INFO - 2023-04-25 07:30:25 --> Controller Class Initialized
INFO - 2023-04-25 07:30:25 --> Helper loaded: form_helper
INFO - 2023-04-25 07:30:25 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:30:25 --> Model "Change_model" initialized
INFO - 2023-04-25 07:30:25 --> Config Class Initialized
INFO - 2023-04-25 07:30:25 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:30:25 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:30:25 --> Utf8 Class Initialized
INFO - 2023-04-25 07:30:25 --> URI Class Initialized
INFO - 2023-04-25 07:30:25 --> Router Class Initialized
INFO - 2023-04-25 07:30:25 --> Output Class Initialized
INFO - 2023-04-25 07:30:25 --> Security Class Initialized
DEBUG - 2023-04-25 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:30:25 --> Input Class Initialized
INFO - 2023-04-25 07:30:25 --> Language Class Initialized
INFO - 2023-04-25 07:30:25 --> Loader Class Initialized
INFO - 2023-04-25 07:30:25 --> Controller Class Initialized
INFO - 2023-04-25 07:30:25 --> Helper loaded: form_helper
INFO - 2023-04-25 07:30:25 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:30:25 --> Model "Change_model" initialized
INFO - 2023-04-25 07:31:24 --> Final output sent to browser
DEBUG - 2023-04-25 07:31:24 --> Total execution time: 60.0050
INFO - 2023-04-25 07:31:25 --> Final output sent to browser
DEBUG - 2023-04-25 07:31:25 --> Total execution time: 60.0039
INFO - 2023-04-25 07:31:25 --> Final output sent to browser
DEBUG - 2023-04-25 07:31:25 --> Total execution time: 60.0039
INFO - 2023-04-25 07:31:25 --> Final output sent to browser
DEBUG - 2023-04-25 07:31:25 --> Total execution time: 60.0042
INFO - 2023-04-25 07:35:13 --> Config Class Initialized
INFO - 2023-04-25 07:35:13 --> Hooks Class Initialized
DEBUG - 2023-04-25 07:35:13 --> UTF-8 Support Enabled
INFO - 2023-04-25 07:35:13 --> Utf8 Class Initialized
INFO - 2023-04-25 07:35:13 --> URI Class Initialized
INFO - 2023-04-25 07:35:13 --> Router Class Initialized
INFO - 2023-04-25 07:35:13 --> Output Class Initialized
INFO - 2023-04-25 07:35:13 --> Security Class Initialized
DEBUG - 2023-04-25 07:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 07:35:13 --> Input Class Initialized
INFO - 2023-04-25 07:35:13 --> Language Class Initialized
INFO - 2023-04-25 07:35:13 --> Loader Class Initialized
INFO - 2023-04-25 07:35:13 --> Controller Class Initialized
INFO - 2023-04-25 07:35:13 --> Helper loaded: form_helper
INFO - 2023-04-25 07:35:13 --> Helper loaded: url_helper
DEBUG - 2023-04-25 07:35:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 07:35:13 --> Model "Change_model" initialized
INFO - 2023-04-25 07:36:13 --> Final output sent to browser
DEBUG - 2023-04-25 07:36:13 --> Total execution time: 60.0070
INFO - 2023-04-25 08:02:44 --> Config Class Initialized
INFO - 2023-04-25 08:02:44 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:02:44 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:02:44 --> Utf8 Class Initialized
INFO - 2023-04-25 08:02:44 --> URI Class Initialized
INFO - 2023-04-25 08:02:44 --> Router Class Initialized
INFO - 2023-04-25 08:02:44 --> Output Class Initialized
INFO - 2023-04-25 08:02:44 --> Security Class Initialized
DEBUG - 2023-04-25 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:02:44 --> Input Class Initialized
INFO - 2023-04-25 08:02:44 --> Language Class Initialized
INFO - 2023-04-25 08:02:44 --> Loader Class Initialized
INFO - 2023-04-25 08:02:44 --> Controller Class Initialized
INFO - 2023-04-25 08:02:44 --> Helper loaded: form_helper
INFO - 2023-04-25 08:02:44 --> Helper loaded: url_helper
DEBUG - 2023-04-25 08:02:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 08:02:44 --> Model "Change_model" initialized
INFO - 2023-04-25 08:02:46 --> Config Class Initialized
INFO - 2023-04-25 08:02:46 --> Hooks Class Initialized
DEBUG - 2023-04-25 08:02:46 --> UTF-8 Support Enabled
INFO - 2023-04-25 08:02:46 --> Utf8 Class Initialized
INFO - 2023-04-25 08:02:46 --> URI Class Initialized
INFO - 2023-04-25 08:02:46 --> Router Class Initialized
INFO - 2023-04-25 08:02:46 --> Output Class Initialized
INFO - 2023-04-25 08:02:46 --> Security Class Initialized
DEBUG - 2023-04-25 08:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 08:02:46 --> Input Class Initialized
INFO - 2023-04-25 08:02:46 --> Language Class Initialized
INFO - 2023-04-25 08:02:46 --> Loader Class Initialized
INFO - 2023-04-25 08:02:46 --> Controller Class Initialized
INFO - 2023-04-25 08:02:46 --> Helper loaded: form_helper
INFO - 2023-04-25 08:02:46 --> Helper loaded: url_helper
DEBUG - 2023-04-25 08:02:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 08:02:46 --> Model "Change_model" initialized
INFO - 2023-04-25 08:03:44 --> Final output sent to browser
DEBUG - 2023-04-25 08:03:44 --> Total execution time: 60.0100
INFO - 2023-04-25 08:03:46 --> Final output sent to browser
DEBUG - 2023-04-25 08:03:46 --> Total execution time: 60.0088
INFO - 2023-04-25 09:26:18 --> Config Class Initialized
INFO - 2023-04-25 09:26:18 --> Hooks Class Initialized
DEBUG - 2023-04-25 09:26:18 --> UTF-8 Support Enabled
INFO - 2023-04-25 09:26:18 --> Utf8 Class Initialized
INFO - 2023-04-25 09:26:18 --> URI Class Initialized
INFO - 2023-04-25 09:26:18 --> Router Class Initialized
INFO - 2023-04-25 09:26:18 --> Output Class Initialized
INFO - 2023-04-25 09:26:18 --> Security Class Initialized
DEBUG - 2023-04-25 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 09:26:18 --> Input Class Initialized
INFO - 2023-04-25 09:26:18 --> Language Class Initialized
INFO - 2023-04-25 09:26:18 --> Loader Class Initialized
INFO - 2023-04-25 09:26:18 --> Controller Class Initialized
INFO - 2023-04-25 09:26:18 --> Helper loaded: form_helper
INFO - 2023-04-25 09:26:18 --> Helper loaded: url_helper
DEBUG - 2023-04-25 09:26:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 09:26:18 --> Model "Change_model" initialized
INFO - 2023-04-25 09:27:18 --> Final output sent to browser
DEBUG - 2023-04-25 09:27:18 --> Total execution time: 60.0061
INFO - 2023-04-25 09:57:09 --> Config Class Initialized
INFO - 2023-04-25 09:57:09 --> Hooks Class Initialized
DEBUG - 2023-04-25 09:57:09 --> UTF-8 Support Enabled
INFO - 2023-04-25 09:57:09 --> Utf8 Class Initialized
INFO - 2023-04-25 09:57:09 --> URI Class Initialized
INFO - 2023-04-25 09:57:09 --> Router Class Initialized
INFO - 2023-04-25 09:57:09 --> Output Class Initialized
INFO - 2023-04-25 09:57:09 --> Security Class Initialized
DEBUG - 2023-04-25 09:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 09:57:09 --> Input Class Initialized
INFO - 2023-04-25 09:57:09 --> Language Class Initialized
INFO - 2023-04-25 09:57:09 --> Loader Class Initialized
INFO - 2023-04-25 09:57:09 --> Controller Class Initialized
INFO - 2023-04-25 09:57:09 --> Helper loaded: form_helper
INFO - 2023-04-25 09:57:09 --> Helper loaded: url_helper
DEBUG - 2023-04-25 09:57:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 09:57:09 --> Model "Change_model" initialized
INFO - 2023-04-25 09:57:09 --> Final output sent to browser
DEBUG - 2023-04-25 09:57:09 --> Total execution time: 0.1074
INFO - 2023-04-25 10:08:08 --> Config Class Initialized
INFO - 2023-04-25 10:08:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:08 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:08 --> URI Class Initialized
INFO - 2023-04-25 10:08:08 --> Router Class Initialized
INFO - 2023-04-25 10:08:08 --> Output Class Initialized
INFO - 2023-04-25 10:08:08 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:08 --> Input Class Initialized
INFO - 2023-04-25 10:08:08 --> Language Class Initialized
INFO - 2023-04-25 10:08:08 --> Loader Class Initialized
INFO - 2023-04-25 10:08:08 --> Controller Class Initialized
INFO - 2023-04-25 10:08:08 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:08 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:08 --> Model "Change_model" initialized
INFO - 2023-04-25 10:08:08 --> Model "Grafana_model" initialized
INFO - 2023-04-25 10:08:08 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:08 --> Total execution time: 0.0563
INFO - 2023-04-25 10:08:08 --> Config Class Initialized
INFO - 2023-04-25 10:08:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:08 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:08 --> URI Class Initialized
INFO - 2023-04-25 10:08:08 --> Router Class Initialized
INFO - 2023-04-25 10:08:08 --> Output Class Initialized
INFO - 2023-04-25 10:08:08 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:08 --> Input Class Initialized
INFO - 2023-04-25 10:08:08 --> Language Class Initialized
INFO - 2023-04-25 10:08:08 --> Loader Class Initialized
INFO - 2023-04-25 10:08:08 --> Controller Class Initialized
INFO - 2023-04-25 10:08:08 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:08 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:08 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:08 --> Total execution time: 0.0434
INFO - 2023-04-25 10:08:08 --> Config Class Initialized
INFO - 2023-04-25 10:08:08 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:08 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:08 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:08 --> URI Class Initialized
INFO - 2023-04-25 10:08:08 --> Router Class Initialized
INFO - 2023-04-25 10:08:08 --> Output Class Initialized
INFO - 2023-04-25 10:08:08 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:08 --> Input Class Initialized
INFO - 2023-04-25 10:08:08 --> Language Class Initialized
INFO - 2023-04-25 10:08:08 --> Loader Class Initialized
INFO - 2023-04-25 10:08:08 --> Controller Class Initialized
INFO - 2023-04-25 10:08:08 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:08 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:08 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:08 --> Model "Login_model" initialized
INFO - 2023-04-25 10:08:08 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:08 --> Total execution time: 0.0305
INFO - 2023-04-25 10:08:14 --> Config Class Initialized
INFO - 2023-04-25 10:08:14 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:14 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:14 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:14 --> URI Class Initialized
INFO - 2023-04-25 10:08:14 --> Router Class Initialized
INFO - 2023-04-25 10:08:14 --> Output Class Initialized
INFO - 2023-04-25 10:08:14 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:14 --> Input Class Initialized
INFO - 2023-04-25 10:08:14 --> Language Class Initialized
INFO - 2023-04-25 10:08:14 --> Loader Class Initialized
INFO - 2023-04-25 10:08:14 --> Controller Class Initialized
INFO - 2023-04-25 10:08:14 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:14 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:14 --> Model "Change_model" initialized
INFO - 2023-04-25 10:08:14 --> Model "Grafana_model" initialized
INFO - 2023-04-25 10:08:14 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:14 --> Total execution time: 0.0338
INFO - 2023-04-25 10:08:14 --> Config Class Initialized
INFO - 2023-04-25 10:08:14 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:14 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:14 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:14 --> URI Class Initialized
INFO - 2023-04-25 10:08:14 --> Router Class Initialized
INFO - 2023-04-25 10:08:14 --> Output Class Initialized
INFO - 2023-04-25 10:08:14 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:14 --> Input Class Initialized
INFO - 2023-04-25 10:08:14 --> Language Class Initialized
INFO - 2023-04-25 10:08:14 --> Loader Class Initialized
INFO - 2023-04-25 10:08:14 --> Controller Class Initialized
INFO - 2023-04-25 10:08:14 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:14 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:14 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:14 --> Total execution time: 0.0017
INFO - 2023-04-25 10:08:14 --> Config Class Initialized
INFO - 2023-04-25 10:08:14 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:14 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:14 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:14 --> URI Class Initialized
INFO - 2023-04-25 10:08:14 --> Router Class Initialized
INFO - 2023-04-25 10:08:14 --> Output Class Initialized
INFO - 2023-04-25 10:08:14 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:14 --> Input Class Initialized
INFO - 2023-04-25 10:08:14 --> Language Class Initialized
INFO - 2023-04-25 10:08:14 --> Loader Class Initialized
INFO - 2023-04-25 10:08:14 --> Controller Class Initialized
INFO - 2023-04-25 10:08:14 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:14 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:14 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:14 --> Model "Login_model" initialized
INFO - 2023-04-25 10:08:14 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:14 --> Total execution time: 0.0166
INFO - 2023-04-25 10:08:28 --> Config Class Initialized
INFO - 2023-04-25 10:08:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:28 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:28 --> URI Class Initialized
INFO - 2023-04-25 10:08:28 --> Router Class Initialized
INFO - 2023-04-25 10:08:28 --> Output Class Initialized
INFO - 2023-04-25 10:08:28 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:28 --> Input Class Initialized
INFO - 2023-04-25 10:08:28 --> Language Class Initialized
INFO - 2023-04-25 10:08:28 --> Loader Class Initialized
INFO - 2023-04-25 10:08:28 --> Controller Class Initialized
INFO - 2023-04-25 10:08:28 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:28 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:28 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:28 --> Total execution time: 0.0052
INFO - 2023-04-25 10:08:28 --> Config Class Initialized
INFO - 2023-04-25 10:08:28 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:28 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:28 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:28 --> URI Class Initialized
INFO - 2023-04-25 10:08:28 --> Router Class Initialized
INFO - 2023-04-25 10:08:28 --> Output Class Initialized
INFO - 2023-04-25 10:08:28 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:28 --> Input Class Initialized
INFO - 2023-04-25 10:08:28 --> Language Class Initialized
INFO - 2023-04-25 10:08:28 --> Loader Class Initialized
INFO - 2023-04-25 10:08:28 --> Controller Class Initialized
INFO - 2023-04-25 10:08:28 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:28 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:28 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:28 --> Model "Login_model" initialized
INFO - 2023-04-25 10:08:28 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:28 --> Total execution time: 0.0323
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
INFO - 2023-04-25 10:08:33 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:33 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Model "Change_model" initialized
INFO - 2023-04-25 10:08:33 --> Model "Grafana_model" initialized
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0618
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
INFO - 2023-04-25 10:08:33 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:33 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0034
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
INFO - 2023-04-25 10:08:33 --> Helper loaded: form_helper
INFO - 2023-04-25 10:08:33 --> Helper loaded: url_helper
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:33 --> Model "Login_model" initialized
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0164
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:33 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0311
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:33 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0123
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:33 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:33 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0161
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0169
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Config Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
INFO - 2023-04-25 10:08:33 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-25 10:08:33 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> URI Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
INFO - 2023-04-25 10:08:33 --> Router Class Initialized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
INFO - 2023-04-25 10:08:33 --> Output Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:33 --> Security Class Initialized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Input Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
INFO - 2023-04-25 10:08:33 --> Language Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Loader Class Initialized
INFO - 2023-04-25 10:08:33 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:33 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:33 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:33 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:33 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0528
INFO - 2023-04-25 10:08:33 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:33 --> Total execution time: 0.0563
INFO - 2023-04-25 10:08:51 --> Config Class Initialized
INFO - 2023-04-25 10:08:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:51 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:51 --> URI Class Initialized
INFO - 2023-04-25 10:08:51 --> Router Class Initialized
INFO - 2023-04-25 10:08:51 --> Output Class Initialized
INFO - 2023-04-25 10:08:51 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:51 --> Input Class Initialized
INFO - 2023-04-25 10:08:51 --> Language Class Initialized
INFO - 2023-04-25 10:08:51 --> Loader Class Initialized
INFO - 2023-04-25 10:08:51 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:51 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:51 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:51 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:51 --> Total execution time: 0.0131
INFO - 2023-04-25 10:08:51 --> Config Class Initialized
INFO - 2023-04-25 10:08:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:51 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:51 --> URI Class Initialized
INFO - 2023-04-25 10:08:51 --> Router Class Initialized
INFO - 2023-04-25 10:08:51 --> Output Class Initialized
INFO - 2023-04-25 10:08:51 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:51 --> Input Class Initialized
INFO - 2023-04-25 10:08:51 --> Language Class Initialized
INFO - 2023-04-25 10:08:51 --> Loader Class Initialized
INFO - 2023-04-25 10:08:51 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:51 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:51 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:51 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:51 --> Total execution time: 0.0538
INFO - 2023-04-25 10:08:51 --> Config Class Initialized
INFO - 2023-04-25 10:08:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:51 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:51 --> URI Class Initialized
INFO - 2023-04-25 10:08:51 --> Router Class Initialized
INFO - 2023-04-25 10:08:51 --> Output Class Initialized
INFO - 2023-04-25 10:08:51 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:51 --> Input Class Initialized
INFO - 2023-04-25 10:08:51 --> Language Class Initialized
INFO - 2023-04-25 10:08:51 --> Loader Class Initialized
INFO - 2023-04-25 10:08:51 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:51 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:51 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:51 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:51 --> Total execution time: 0.0494
INFO - 2023-04-25 10:08:51 --> Config Class Initialized
INFO - 2023-04-25 10:08:51 --> Hooks Class Initialized
DEBUG - 2023-04-25 10:08:51 --> UTF-8 Support Enabled
INFO - 2023-04-25 10:08:51 --> Utf8 Class Initialized
INFO - 2023-04-25 10:08:51 --> URI Class Initialized
INFO - 2023-04-25 10:08:51 --> Router Class Initialized
INFO - 2023-04-25 10:08:51 --> Output Class Initialized
INFO - 2023-04-25 10:08:51 --> Security Class Initialized
DEBUG - 2023-04-25 10:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-25 10:08:51 --> Input Class Initialized
INFO - 2023-04-25 10:08:51 --> Language Class Initialized
INFO - 2023-04-25 10:08:51 --> Loader Class Initialized
INFO - 2023-04-25 10:08:51 --> Controller Class Initialized
DEBUG - 2023-04-25 10:08:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-25 10:08:51 --> Database Driver Class Initialized
INFO - 2023-04-25 10:08:51 --> Model "Cluster_model" initialized
INFO - 2023-04-25 10:08:51 --> Final output sent to browser
DEBUG - 2023-04-25 10:08:51 --> Total execution time: 0.0122
