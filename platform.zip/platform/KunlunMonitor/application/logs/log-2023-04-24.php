<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-24 01:47:11 --> Config Class Initialized
INFO - 2023-04-24 01:47:11 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:47:11 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:47:11 --> Utf8 Class Initialized
INFO - 2023-04-24 01:47:11 --> URI Class Initialized
INFO - 2023-04-24 01:47:11 --> Router Class Initialized
INFO - 2023-04-24 01:47:11 --> Output Class Initialized
INFO - 2023-04-24 01:47:11 --> Security Class Initialized
DEBUG - 2023-04-24 01:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:47:11 --> Input Class Initialized
INFO - 2023-04-24 01:47:11 --> Language Class Initialized
INFO - 2023-04-24 01:47:11 --> Loader Class Initialized
INFO - 2023-04-24 01:47:11 --> Controller Class Initialized
INFO - 2023-04-24 01:47:11 --> Helper loaded: form_helper
INFO - 2023-04-24 01:47:11 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:47:11 --> Model "Change_model" initialized
INFO - 2023-04-24 01:47:11 --> Model "Grafana_model" initialized
INFO - 2023-04-24 01:47:11 --> Final output sent to browser
DEBUG - 2023-04-24 01:47:11 --> Total execution time: 0.0834
INFO - 2023-04-24 01:47:11 --> Config Class Initialized
INFO - 2023-04-24 01:47:11 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:47:11 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:47:11 --> Utf8 Class Initialized
INFO - 2023-04-24 01:47:11 --> URI Class Initialized
INFO - 2023-04-24 01:47:11 --> Router Class Initialized
INFO - 2023-04-24 01:47:11 --> Output Class Initialized
INFO - 2023-04-24 01:47:11 --> Security Class Initialized
DEBUG - 2023-04-24 01:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:47:11 --> Input Class Initialized
INFO - 2023-04-24 01:47:11 --> Language Class Initialized
INFO - 2023-04-24 01:47:11 --> Loader Class Initialized
INFO - 2023-04-24 01:47:11 --> Controller Class Initialized
INFO - 2023-04-24 01:47:11 --> Helper loaded: form_helper
INFO - 2023-04-24 01:47:11 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:47:11 --> Final output sent to browser
DEBUG - 2023-04-24 01:47:11 --> Total execution time: 0.0047
INFO - 2023-04-24 01:47:11 --> Config Class Initialized
INFO - 2023-04-24 01:47:11 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:47:11 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:47:11 --> Utf8 Class Initialized
INFO - 2023-04-24 01:47:11 --> URI Class Initialized
INFO - 2023-04-24 01:47:11 --> Router Class Initialized
INFO - 2023-04-24 01:47:11 --> Output Class Initialized
INFO - 2023-04-24 01:47:11 --> Security Class Initialized
DEBUG - 2023-04-24 01:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:47:11 --> Input Class Initialized
INFO - 2023-04-24 01:47:11 --> Language Class Initialized
INFO - 2023-04-24 01:47:11 --> Loader Class Initialized
INFO - 2023-04-24 01:47:11 --> Controller Class Initialized
INFO - 2023-04-24 01:47:11 --> Helper loaded: form_helper
INFO - 2023-04-24 01:47:11 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:47:11 --> Database Driver Class Initialized
INFO - 2023-04-24 01:47:11 --> Model "Login_model" initialized
INFO - 2023-04-24 01:47:11 --> Final output sent to browser
DEBUG - 2023-04-24 01:47:11 --> Total execution time: 0.0209
INFO - 2023-04-24 01:47:11 --> Config Class Initialized
INFO - 2023-04-24 01:47:11 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:47:11 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:47:11 --> Utf8 Class Initialized
INFO - 2023-04-24 01:47:11 --> URI Class Initialized
INFO - 2023-04-24 01:47:11 --> Router Class Initialized
INFO - 2023-04-24 01:47:11 --> Output Class Initialized
INFO - 2023-04-24 01:47:11 --> Security Class Initialized
DEBUG - 2023-04-24 01:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:47:11 --> Input Class Initialized
INFO - 2023-04-24 01:47:11 --> Language Class Initialized
INFO - 2023-04-24 01:47:11 --> Loader Class Initialized
INFO - 2023-04-24 01:47:11 --> Controller Class Initialized
DEBUG - 2023-04-24 01:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:47:11 --> Database Driver Class Initialized
INFO - 2023-04-24 01:47:11 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:47:11 --> Final output sent to browser
DEBUG - 2023-04-24 01:47:11 --> Total execution time: 0.0186
INFO - 2023-04-24 01:47:11 --> Config Class Initialized
INFO - 2023-04-24 01:47:11 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:47:11 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:47:11 --> Utf8 Class Initialized
INFO - 2023-04-24 01:47:11 --> URI Class Initialized
INFO - 2023-04-24 01:47:11 --> Router Class Initialized
INFO - 2023-04-24 01:47:11 --> Output Class Initialized
INFO - 2023-04-24 01:47:11 --> Security Class Initialized
DEBUG - 2023-04-24 01:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:47:11 --> Input Class Initialized
INFO - 2023-04-24 01:47:11 --> Language Class Initialized
INFO - 2023-04-24 01:47:11 --> Loader Class Initialized
INFO - 2023-04-24 01:47:11 --> Controller Class Initialized
DEBUG - 2023-04-24 01:47:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:47:11 --> Database Driver Class Initialized
INFO - 2023-04-24 01:47:11 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:47:11 --> Final output sent to browser
DEBUG - 2023-04-24 01:47:11 --> Total execution time: 0.0162
INFO - 2023-04-24 01:48:20 --> Config Class Initialized
INFO - 2023-04-24 01:48:20 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:48:20 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:48:20 --> Utf8 Class Initialized
INFO - 2023-04-24 01:48:20 --> URI Class Initialized
INFO - 2023-04-24 01:48:20 --> Router Class Initialized
INFO - 2023-04-24 01:48:20 --> Output Class Initialized
INFO - 2023-04-24 01:48:20 --> Security Class Initialized
DEBUG - 2023-04-24 01:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:48:20 --> Input Class Initialized
INFO - 2023-04-24 01:48:20 --> Language Class Initialized
INFO - 2023-04-24 01:48:20 --> Loader Class Initialized
INFO - 2023-04-24 01:48:20 --> Controller Class Initialized
INFO - 2023-04-24 01:48:20 --> Helper loaded: form_helper
INFO - 2023-04-24 01:48:20 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:48:20 --> Model "Change_model" initialized
INFO - 2023-04-24 01:48:20 --> Model "Grafana_model" initialized
INFO - 2023-04-24 01:48:20 --> Final output sent to browser
DEBUG - 2023-04-24 01:48:20 --> Total execution time: 0.0462
INFO - 2023-04-24 01:48:20 --> Config Class Initialized
INFO - 2023-04-24 01:48:20 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:48:20 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:48:20 --> Utf8 Class Initialized
INFO - 2023-04-24 01:48:20 --> URI Class Initialized
INFO - 2023-04-24 01:48:20 --> Router Class Initialized
INFO - 2023-04-24 01:48:20 --> Output Class Initialized
INFO - 2023-04-24 01:48:20 --> Security Class Initialized
DEBUG - 2023-04-24 01:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:48:20 --> Input Class Initialized
INFO - 2023-04-24 01:48:20 --> Language Class Initialized
INFO - 2023-04-24 01:48:20 --> Loader Class Initialized
INFO - 2023-04-24 01:48:20 --> Controller Class Initialized
INFO - 2023-04-24 01:48:20 --> Helper loaded: form_helper
INFO - 2023-04-24 01:48:20 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:48:20 --> Final output sent to browser
DEBUG - 2023-04-24 01:48:20 --> Total execution time: 0.0414
INFO - 2023-04-24 01:48:20 --> Config Class Initialized
INFO - 2023-04-24 01:48:20 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:48:20 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:48:20 --> Utf8 Class Initialized
INFO - 2023-04-24 01:48:20 --> URI Class Initialized
INFO - 2023-04-24 01:48:20 --> Router Class Initialized
INFO - 2023-04-24 01:48:20 --> Output Class Initialized
INFO - 2023-04-24 01:48:20 --> Security Class Initialized
DEBUG - 2023-04-24 01:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:48:20 --> Input Class Initialized
INFO - 2023-04-24 01:48:20 --> Language Class Initialized
INFO - 2023-04-24 01:48:20 --> Loader Class Initialized
INFO - 2023-04-24 01:48:20 --> Controller Class Initialized
INFO - 2023-04-24 01:48:20 --> Helper loaded: form_helper
INFO - 2023-04-24 01:48:20 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:48:20 --> Database Driver Class Initialized
INFO - 2023-04-24 01:48:20 --> Model "Login_model" initialized
INFO - 2023-04-24 01:48:20 --> Final output sent to browser
DEBUG - 2023-04-24 01:48:20 --> Total execution time: 0.0276
INFO - 2023-04-24 01:48:20 --> Config Class Initialized
INFO - 2023-04-24 01:48:20 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:48:20 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:48:20 --> Utf8 Class Initialized
INFO - 2023-04-24 01:48:20 --> URI Class Initialized
INFO - 2023-04-24 01:48:20 --> Router Class Initialized
INFO - 2023-04-24 01:48:20 --> Output Class Initialized
INFO - 2023-04-24 01:48:20 --> Security Class Initialized
DEBUG - 2023-04-24 01:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:48:20 --> Input Class Initialized
INFO - 2023-04-24 01:48:20 --> Language Class Initialized
INFO - 2023-04-24 01:48:20 --> Loader Class Initialized
INFO - 2023-04-24 01:48:20 --> Controller Class Initialized
DEBUG - 2023-04-24 01:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:48:20 --> Database Driver Class Initialized
INFO - 2023-04-24 01:48:20 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:48:20 --> Final output sent to browser
DEBUG - 2023-04-24 01:48:20 --> Total execution time: 0.0168
INFO - 2023-04-24 01:48:20 --> Config Class Initialized
INFO - 2023-04-24 01:48:20 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:48:20 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:48:20 --> Utf8 Class Initialized
INFO - 2023-04-24 01:48:20 --> URI Class Initialized
INFO - 2023-04-24 01:48:20 --> Router Class Initialized
INFO - 2023-04-24 01:48:20 --> Output Class Initialized
INFO - 2023-04-24 01:48:20 --> Security Class Initialized
DEBUG - 2023-04-24 01:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:48:20 --> Input Class Initialized
INFO - 2023-04-24 01:48:20 --> Language Class Initialized
INFO - 2023-04-24 01:48:20 --> Loader Class Initialized
INFO - 2023-04-24 01:48:20 --> Controller Class Initialized
DEBUG - 2023-04-24 01:48:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:48:20 --> Database Driver Class Initialized
INFO - 2023-04-24 01:48:20 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:48:20 --> Final output sent to browser
DEBUG - 2023-04-24 01:48:20 --> Total execution time: 0.0204
INFO - 2023-04-24 01:52:43 --> Config Class Initialized
INFO - 2023-04-24 01:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:52:43 --> Utf8 Class Initialized
INFO - 2023-04-24 01:52:43 --> URI Class Initialized
INFO - 2023-04-24 01:52:43 --> Router Class Initialized
INFO - 2023-04-24 01:52:43 --> Output Class Initialized
INFO - 2023-04-24 01:52:43 --> Security Class Initialized
DEBUG - 2023-04-24 01:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:52:43 --> Input Class Initialized
INFO - 2023-04-24 01:52:43 --> Language Class Initialized
INFO - 2023-04-24 01:52:43 --> Loader Class Initialized
INFO - 2023-04-24 01:52:43 --> Controller Class Initialized
INFO - 2023-04-24 01:52:43 --> Helper loaded: form_helper
INFO - 2023-04-24 01:52:43 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:52:43 --> Model "Change_model" initialized
INFO - 2023-04-24 01:52:43 --> Model "Grafana_model" initialized
INFO - 2023-04-24 01:52:43 --> Final output sent to browser
DEBUG - 2023-04-24 01:52:43 --> Total execution time: 0.0311
INFO - 2023-04-24 01:52:43 --> Config Class Initialized
INFO - 2023-04-24 01:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:52:43 --> Utf8 Class Initialized
INFO - 2023-04-24 01:52:43 --> URI Class Initialized
INFO - 2023-04-24 01:52:43 --> Router Class Initialized
INFO - 2023-04-24 01:52:43 --> Output Class Initialized
INFO - 2023-04-24 01:52:43 --> Security Class Initialized
DEBUG - 2023-04-24 01:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:52:43 --> Input Class Initialized
INFO - 2023-04-24 01:52:43 --> Language Class Initialized
INFO - 2023-04-24 01:52:43 --> Loader Class Initialized
INFO - 2023-04-24 01:52:43 --> Controller Class Initialized
INFO - 2023-04-24 01:52:43 --> Helper loaded: form_helper
INFO - 2023-04-24 01:52:43 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:52:43 --> Final output sent to browser
DEBUG - 2023-04-24 01:52:43 --> Total execution time: 0.0029
INFO - 2023-04-24 01:52:43 --> Config Class Initialized
INFO - 2023-04-24 01:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:52:43 --> Utf8 Class Initialized
INFO - 2023-04-24 01:52:43 --> URI Class Initialized
INFO - 2023-04-24 01:52:43 --> Router Class Initialized
INFO - 2023-04-24 01:52:43 --> Output Class Initialized
INFO - 2023-04-24 01:52:43 --> Security Class Initialized
DEBUG - 2023-04-24 01:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:52:43 --> Input Class Initialized
INFO - 2023-04-24 01:52:43 --> Language Class Initialized
INFO - 2023-04-24 01:52:43 --> Loader Class Initialized
INFO - 2023-04-24 01:52:43 --> Controller Class Initialized
INFO - 2023-04-24 01:52:43 --> Helper loaded: form_helper
INFO - 2023-04-24 01:52:43 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:52:43 --> Database Driver Class Initialized
INFO - 2023-04-24 01:52:43 --> Model "Login_model" initialized
INFO - 2023-04-24 01:52:43 --> Final output sent to browser
DEBUG - 2023-04-24 01:52:43 --> Total execution time: 0.0214
INFO - 2023-04-24 01:52:43 --> Config Class Initialized
INFO - 2023-04-24 01:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:52:43 --> Utf8 Class Initialized
INFO - 2023-04-24 01:52:43 --> URI Class Initialized
INFO - 2023-04-24 01:52:43 --> Router Class Initialized
INFO - 2023-04-24 01:52:43 --> Output Class Initialized
INFO - 2023-04-24 01:52:43 --> Security Class Initialized
DEBUG - 2023-04-24 01:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:52:43 --> Input Class Initialized
INFO - 2023-04-24 01:52:43 --> Language Class Initialized
INFO - 2023-04-24 01:52:43 --> Loader Class Initialized
INFO - 2023-04-24 01:52:43 --> Controller Class Initialized
DEBUG - 2023-04-24 01:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:52:43 --> Database Driver Class Initialized
INFO - 2023-04-24 01:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:52:43 --> Final output sent to browser
DEBUG - 2023-04-24 01:52:43 --> Total execution time: 0.0157
INFO - 2023-04-24 01:52:43 --> Config Class Initialized
INFO - 2023-04-24 01:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:52:43 --> Utf8 Class Initialized
INFO - 2023-04-24 01:52:43 --> URI Class Initialized
INFO - 2023-04-24 01:52:43 --> Router Class Initialized
INFO - 2023-04-24 01:52:43 --> Output Class Initialized
INFO - 2023-04-24 01:52:43 --> Security Class Initialized
DEBUG - 2023-04-24 01:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:52:43 --> Input Class Initialized
INFO - 2023-04-24 01:52:43 --> Language Class Initialized
INFO - 2023-04-24 01:52:43 --> Loader Class Initialized
INFO - 2023-04-24 01:52:43 --> Controller Class Initialized
DEBUG - 2023-04-24 01:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:52:43 --> Database Driver Class Initialized
INFO - 2023-04-24 01:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:52:43 --> Final output sent to browser
DEBUG - 2023-04-24 01:52:43 --> Total execution time: 0.0170
INFO - 2023-04-24 01:55:57 --> Config Class Initialized
INFO - 2023-04-24 01:55:57 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:55:57 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:55:57 --> Utf8 Class Initialized
INFO - 2023-04-24 01:55:57 --> URI Class Initialized
INFO - 2023-04-24 01:55:57 --> Router Class Initialized
INFO - 2023-04-24 01:55:57 --> Output Class Initialized
INFO - 2023-04-24 01:55:57 --> Security Class Initialized
DEBUG - 2023-04-24 01:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:55:57 --> Input Class Initialized
INFO - 2023-04-24 01:55:57 --> Language Class Initialized
INFO - 2023-04-24 01:55:57 --> Loader Class Initialized
INFO - 2023-04-24 01:55:57 --> Controller Class Initialized
INFO - 2023-04-24 01:55:57 --> Helper loaded: form_helper
INFO - 2023-04-24 01:55:57 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:55:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:55:57 --> Model "Change_model" initialized
INFO - 2023-04-24 01:55:57 --> Model "Grafana_model" initialized
INFO - 2023-04-24 01:55:57 --> Final output sent to browser
DEBUG - 2023-04-24 01:55:57 --> Total execution time: 0.0343
INFO - 2023-04-24 01:55:57 --> Config Class Initialized
INFO - 2023-04-24 01:55:57 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:55:57 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:55:57 --> Utf8 Class Initialized
INFO - 2023-04-24 01:55:57 --> URI Class Initialized
INFO - 2023-04-24 01:55:57 --> Router Class Initialized
INFO - 2023-04-24 01:55:57 --> Output Class Initialized
INFO - 2023-04-24 01:55:57 --> Security Class Initialized
DEBUG - 2023-04-24 01:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:55:57 --> Input Class Initialized
INFO - 2023-04-24 01:55:57 --> Language Class Initialized
INFO - 2023-04-24 01:55:57 --> Loader Class Initialized
INFO - 2023-04-24 01:55:57 --> Controller Class Initialized
INFO - 2023-04-24 01:55:57 --> Helper loaded: form_helper
INFO - 2023-04-24 01:55:57 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:55:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:55:57 --> Final output sent to browser
DEBUG - 2023-04-24 01:55:57 --> Total execution time: 0.0424
INFO - 2023-04-24 01:55:57 --> Config Class Initialized
INFO - 2023-04-24 01:55:57 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:55:57 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:55:57 --> Utf8 Class Initialized
INFO - 2023-04-24 01:55:57 --> URI Class Initialized
INFO - 2023-04-24 01:55:57 --> Router Class Initialized
INFO - 2023-04-24 01:55:57 --> Output Class Initialized
INFO - 2023-04-24 01:55:57 --> Security Class Initialized
DEBUG - 2023-04-24 01:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:55:57 --> Input Class Initialized
INFO - 2023-04-24 01:55:57 --> Language Class Initialized
INFO - 2023-04-24 01:55:57 --> Loader Class Initialized
INFO - 2023-04-24 01:55:57 --> Controller Class Initialized
INFO - 2023-04-24 01:55:57 --> Helper loaded: form_helper
INFO - 2023-04-24 01:55:57 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:55:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:55:57 --> Database Driver Class Initialized
INFO - 2023-04-24 01:55:57 --> Model "Login_model" initialized
INFO - 2023-04-24 01:55:57 --> Final output sent to browser
DEBUG - 2023-04-24 01:55:57 --> Total execution time: 0.0205
INFO - 2023-04-24 01:55:57 --> Config Class Initialized
INFO - 2023-04-24 01:55:57 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:55:57 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:55:57 --> Utf8 Class Initialized
INFO - 2023-04-24 01:55:57 --> URI Class Initialized
INFO - 2023-04-24 01:55:57 --> Router Class Initialized
INFO - 2023-04-24 01:55:57 --> Output Class Initialized
INFO - 2023-04-24 01:55:57 --> Security Class Initialized
DEBUG - 2023-04-24 01:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:55:57 --> Input Class Initialized
INFO - 2023-04-24 01:55:57 --> Language Class Initialized
INFO - 2023-04-24 01:55:57 --> Loader Class Initialized
INFO - 2023-04-24 01:55:57 --> Controller Class Initialized
DEBUG - 2023-04-24 01:55:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:55:57 --> Database Driver Class Initialized
INFO - 2023-04-24 01:55:57 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:55:57 --> Final output sent to browser
DEBUG - 2023-04-24 01:55:57 --> Total execution time: 0.0832
INFO - 2023-04-24 01:55:57 --> Config Class Initialized
INFO - 2023-04-24 01:55:57 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:55:57 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:55:57 --> Utf8 Class Initialized
INFO - 2023-04-24 01:55:57 --> URI Class Initialized
INFO - 2023-04-24 01:55:57 --> Router Class Initialized
INFO - 2023-04-24 01:55:57 --> Output Class Initialized
INFO - 2023-04-24 01:55:57 --> Security Class Initialized
DEBUG - 2023-04-24 01:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:55:57 --> Input Class Initialized
INFO - 2023-04-24 01:55:57 --> Language Class Initialized
INFO - 2023-04-24 01:55:57 --> Loader Class Initialized
INFO - 2023-04-24 01:55:57 --> Controller Class Initialized
DEBUG - 2023-04-24 01:55:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:55:57 --> Database Driver Class Initialized
INFO - 2023-04-24 01:55:57 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:55:57 --> Final output sent to browser
DEBUG - 2023-04-24 01:55:57 --> Total execution time: 0.0165
INFO - 2023-04-24 01:56:37 --> Config Class Initialized
INFO - 2023-04-24 01:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:56:37 --> Utf8 Class Initialized
INFO - 2023-04-24 01:56:37 --> URI Class Initialized
INFO - 2023-04-24 01:56:37 --> Router Class Initialized
INFO - 2023-04-24 01:56:37 --> Output Class Initialized
INFO - 2023-04-24 01:56:37 --> Security Class Initialized
DEBUG - 2023-04-24 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:56:37 --> Input Class Initialized
INFO - 2023-04-24 01:56:37 --> Language Class Initialized
INFO - 2023-04-24 01:56:37 --> Loader Class Initialized
INFO - 2023-04-24 01:56:37 --> Controller Class Initialized
INFO - 2023-04-24 01:56:37 --> Helper loaded: form_helper
INFO - 2023-04-24 01:56:37 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:56:37 --> Model "Change_model" initialized
INFO - 2023-04-24 01:56:37 --> Model "Grafana_model" initialized
INFO - 2023-04-24 01:56:37 --> Final output sent to browser
DEBUG - 2023-04-24 01:56:37 --> Total execution time: 0.0678
INFO - 2023-04-24 01:56:37 --> Config Class Initialized
INFO - 2023-04-24 01:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:56:37 --> Utf8 Class Initialized
INFO - 2023-04-24 01:56:37 --> URI Class Initialized
INFO - 2023-04-24 01:56:37 --> Router Class Initialized
INFO - 2023-04-24 01:56:37 --> Output Class Initialized
INFO - 2023-04-24 01:56:37 --> Security Class Initialized
DEBUG - 2023-04-24 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:56:37 --> Input Class Initialized
INFO - 2023-04-24 01:56:37 --> Language Class Initialized
INFO - 2023-04-24 01:56:37 --> Loader Class Initialized
INFO - 2023-04-24 01:56:37 --> Controller Class Initialized
INFO - 2023-04-24 01:56:37 --> Helper loaded: form_helper
INFO - 2023-04-24 01:56:37 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:56:37 --> Final output sent to browser
DEBUG - 2023-04-24 01:56:37 --> Total execution time: 0.1262
INFO - 2023-04-24 01:56:37 --> Config Class Initialized
INFO - 2023-04-24 01:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:56:37 --> Utf8 Class Initialized
INFO - 2023-04-24 01:56:37 --> URI Class Initialized
INFO - 2023-04-24 01:56:37 --> Router Class Initialized
INFO - 2023-04-24 01:56:37 --> Output Class Initialized
INFO - 2023-04-24 01:56:37 --> Security Class Initialized
DEBUG - 2023-04-24 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:56:37 --> Input Class Initialized
INFO - 2023-04-24 01:56:37 --> Language Class Initialized
INFO - 2023-04-24 01:56:37 --> Loader Class Initialized
INFO - 2023-04-24 01:56:37 --> Controller Class Initialized
INFO - 2023-04-24 01:56:37 --> Helper loaded: form_helper
INFO - 2023-04-24 01:56:37 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:56:37 --> Database Driver Class Initialized
INFO - 2023-04-24 01:56:37 --> Model "Login_model" initialized
INFO - 2023-04-24 01:56:37 --> Final output sent to browser
DEBUG - 2023-04-24 01:56:37 --> Total execution time: 0.0181
INFO - 2023-04-24 01:56:37 --> Config Class Initialized
INFO - 2023-04-24 01:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:56:37 --> Utf8 Class Initialized
INFO - 2023-04-24 01:56:37 --> URI Class Initialized
INFO - 2023-04-24 01:56:37 --> Router Class Initialized
INFO - 2023-04-24 01:56:37 --> Output Class Initialized
INFO - 2023-04-24 01:56:37 --> Security Class Initialized
DEBUG - 2023-04-24 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:56:37 --> Input Class Initialized
INFO - 2023-04-24 01:56:37 --> Language Class Initialized
INFO - 2023-04-24 01:56:37 --> Loader Class Initialized
INFO - 2023-04-24 01:56:37 --> Controller Class Initialized
DEBUG - 2023-04-24 01:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:56:37 --> Database Driver Class Initialized
INFO - 2023-04-24 01:56:37 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:56:37 --> Final output sent to browser
DEBUG - 2023-04-24 01:56:37 --> Total execution time: 0.0148
INFO - 2023-04-24 01:56:37 --> Config Class Initialized
INFO - 2023-04-24 01:56:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:56:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:56:37 --> Utf8 Class Initialized
INFO - 2023-04-24 01:56:37 --> URI Class Initialized
INFO - 2023-04-24 01:56:37 --> Router Class Initialized
INFO - 2023-04-24 01:56:37 --> Output Class Initialized
INFO - 2023-04-24 01:56:37 --> Security Class Initialized
DEBUG - 2023-04-24 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:56:37 --> Input Class Initialized
INFO - 2023-04-24 01:56:37 --> Language Class Initialized
INFO - 2023-04-24 01:56:37 --> Loader Class Initialized
INFO - 2023-04-24 01:56:37 --> Controller Class Initialized
DEBUG - 2023-04-24 01:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:56:37 --> Database Driver Class Initialized
INFO - 2023-04-24 01:56:37 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:56:37 --> Final output sent to browser
DEBUG - 2023-04-24 01:56:37 --> Total execution time: 0.0177
INFO - 2023-04-24 01:58:53 --> Config Class Initialized
INFO - 2023-04-24 01:58:53 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:58:53 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:58:53 --> Utf8 Class Initialized
INFO - 2023-04-24 01:58:53 --> URI Class Initialized
INFO - 2023-04-24 01:58:53 --> Router Class Initialized
INFO - 2023-04-24 01:58:53 --> Output Class Initialized
INFO - 2023-04-24 01:58:53 --> Security Class Initialized
DEBUG - 2023-04-24 01:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:58:53 --> Input Class Initialized
INFO - 2023-04-24 01:58:53 --> Language Class Initialized
INFO - 2023-04-24 01:58:53 --> Loader Class Initialized
INFO - 2023-04-24 01:58:53 --> Controller Class Initialized
INFO - 2023-04-24 01:58:53 --> Helper loaded: form_helper
INFO - 2023-04-24 01:58:53 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:58:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:58:53 --> Model "Change_model" initialized
INFO - 2023-04-24 01:58:53 --> Model "Grafana_model" initialized
INFO - 2023-04-24 01:58:53 --> Final output sent to browser
DEBUG - 2023-04-24 01:58:53 --> Total execution time: 0.0273
INFO - 2023-04-24 01:58:53 --> Config Class Initialized
INFO - 2023-04-24 01:58:53 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:58:53 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:58:53 --> Utf8 Class Initialized
INFO - 2023-04-24 01:58:53 --> URI Class Initialized
INFO - 2023-04-24 01:58:53 --> Router Class Initialized
INFO - 2023-04-24 01:58:53 --> Output Class Initialized
INFO - 2023-04-24 01:58:53 --> Security Class Initialized
DEBUG - 2023-04-24 01:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:58:53 --> Input Class Initialized
INFO - 2023-04-24 01:58:53 --> Language Class Initialized
INFO - 2023-04-24 01:58:53 --> Loader Class Initialized
INFO - 2023-04-24 01:58:53 --> Controller Class Initialized
INFO - 2023-04-24 01:58:53 --> Helper loaded: form_helper
INFO - 2023-04-24 01:58:53 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:58:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:58:53 --> Final output sent to browser
DEBUG - 2023-04-24 01:58:53 --> Total execution time: 0.0455
INFO - 2023-04-24 01:58:53 --> Config Class Initialized
INFO - 2023-04-24 01:58:53 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:58:53 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:58:53 --> Utf8 Class Initialized
INFO - 2023-04-24 01:58:53 --> URI Class Initialized
INFO - 2023-04-24 01:58:53 --> Router Class Initialized
INFO - 2023-04-24 01:58:53 --> Output Class Initialized
INFO - 2023-04-24 01:58:53 --> Security Class Initialized
DEBUG - 2023-04-24 01:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:58:53 --> Input Class Initialized
INFO - 2023-04-24 01:58:53 --> Language Class Initialized
INFO - 2023-04-24 01:58:53 --> Loader Class Initialized
INFO - 2023-04-24 01:58:53 --> Controller Class Initialized
INFO - 2023-04-24 01:58:53 --> Helper loaded: form_helper
INFO - 2023-04-24 01:58:53 --> Helper loaded: url_helper
DEBUG - 2023-04-24 01:58:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:58:53 --> Database Driver Class Initialized
INFO - 2023-04-24 01:58:53 --> Model "Login_model" initialized
INFO - 2023-04-24 01:58:53 --> Final output sent to browser
DEBUG - 2023-04-24 01:58:53 --> Total execution time: 0.0166
INFO - 2023-04-24 01:58:53 --> Config Class Initialized
INFO - 2023-04-24 01:58:53 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:58:53 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:58:53 --> Utf8 Class Initialized
INFO - 2023-04-24 01:58:53 --> URI Class Initialized
INFO - 2023-04-24 01:58:53 --> Router Class Initialized
INFO - 2023-04-24 01:58:53 --> Output Class Initialized
INFO - 2023-04-24 01:58:53 --> Security Class Initialized
DEBUG - 2023-04-24 01:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:58:53 --> Input Class Initialized
INFO - 2023-04-24 01:58:53 --> Language Class Initialized
INFO - 2023-04-24 01:58:53 --> Loader Class Initialized
INFO - 2023-04-24 01:58:53 --> Controller Class Initialized
DEBUG - 2023-04-24 01:58:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:58:53 --> Database Driver Class Initialized
INFO - 2023-04-24 01:58:53 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:58:53 --> Final output sent to browser
DEBUG - 2023-04-24 01:58:53 --> Total execution time: 0.0152
INFO - 2023-04-24 01:58:53 --> Config Class Initialized
INFO - 2023-04-24 01:58:53 --> Hooks Class Initialized
DEBUG - 2023-04-24 01:58:53 --> UTF-8 Support Enabled
INFO - 2023-04-24 01:58:53 --> Utf8 Class Initialized
INFO - 2023-04-24 01:58:53 --> URI Class Initialized
INFO - 2023-04-24 01:58:53 --> Router Class Initialized
INFO - 2023-04-24 01:58:53 --> Output Class Initialized
INFO - 2023-04-24 01:58:53 --> Security Class Initialized
DEBUG - 2023-04-24 01:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 01:58:53 --> Input Class Initialized
INFO - 2023-04-24 01:58:53 --> Language Class Initialized
INFO - 2023-04-24 01:58:53 --> Loader Class Initialized
INFO - 2023-04-24 01:58:53 --> Controller Class Initialized
DEBUG - 2023-04-24 01:58:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 01:58:53 --> Database Driver Class Initialized
INFO - 2023-04-24 01:58:53 --> Model "Cluster_model" initialized
INFO - 2023-04-24 01:58:53 --> Final output sent to browser
DEBUG - 2023-04-24 01:58:53 --> Total execution time: 0.0128
INFO - 2023-04-24 02:01:02 --> Config Class Initialized
INFO - 2023-04-24 02:01:02 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:02 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:02 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:02 --> URI Class Initialized
INFO - 2023-04-24 02:01:02 --> Router Class Initialized
INFO - 2023-04-24 02:01:02 --> Output Class Initialized
INFO - 2023-04-24 02:01:02 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:02 --> Input Class Initialized
INFO - 2023-04-24 02:01:02 --> Language Class Initialized
INFO - 2023-04-24 02:01:02 --> Loader Class Initialized
INFO - 2023-04-24 02:01:02 --> Controller Class Initialized
INFO - 2023-04-24 02:01:02 --> Helper loaded: form_helper
INFO - 2023-04-24 02:01:02 --> Helper loaded: url_helper
DEBUG - 2023-04-24 02:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:02 --> Model "Change_model" initialized
INFO - 2023-04-24 02:01:02 --> Model "Grafana_model" initialized
INFO - 2023-04-24 02:01:02 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:02 --> Total execution time: 0.0316
INFO - 2023-04-24 02:01:02 --> Config Class Initialized
INFO - 2023-04-24 02:01:02 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:02 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:02 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:02 --> URI Class Initialized
INFO - 2023-04-24 02:01:02 --> Router Class Initialized
INFO - 2023-04-24 02:01:02 --> Output Class Initialized
INFO - 2023-04-24 02:01:02 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:02 --> Input Class Initialized
INFO - 2023-04-24 02:01:02 --> Language Class Initialized
INFO - 2023-04-24 02:01:02 --> Loader Class Initialized
INFO - 2023-04-24 02:01:02 --> Controller Class Initialized
INFO - 2023-04-24 02:01:02 --> Helper loaded: form_helper
INFO - 2023-04-24 02:01:02 --> Helper loaded: url_helper
DEBUG - 2023-04-24 02:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:02 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:02 --> Total execution time: 0.0024
INFO - 2023-04-24 02:01:02 --> Config Class Initialized
INFO - 2023-04-24 02:01:02 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:02 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:02 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:02 --> URI Class Initialized
INFO - 2023-04-24 02:01:02 --> Router Class Initialized
INFO - 2023-04-24 02:01:02 --> Output Class Initialized
INFO - 2023-04-24 02:01:02 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:02 --> Input Class Initialized
INFO - 2023-04-24 02:01:02 --> Language Class Initialized
INFO - 2023-04-24 02:01:02 --> Loader Class Initialized
INFO - 2023-04-24 02:01:02 --> Controller Class Initialized
INFO - 2023-04-24 02:01:02 --> Helper loaded: form_helper
INFO - 2023-04-24 02:01:02 --> Helper loaded: url_helper
DEBUG - 2023-04-24 02:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:02 --> Database Driver Class Initialized
INFO - 2023-04-24 02:01:02 --> Model "Login_model" initialized
INFO - 2023-04-24 02:01:02 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:02 --> Total execution time: 0.0777
INFO - 2023-04-24 02:01:02 --> Config Class Initialized
INFO - 2023-04-24 02:01:02 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:02 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:02 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:02 --> URI Class Initialized
INFO - 2023-04-24 02:01:02 --> Router Class Initialized
INFO - 2023-04-24 02:01:02 --> Output Class Initialized
INFO - 2023-04-24 02:01:02 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:02 --> Input Class Initialized
INFO - 2023-04-24 02:01:02 --> Language Class Initialized
INFO - 2023-04-24 02:01:02 --> Loader Class Initialized
INFO - 2023-04-24 02:01:02 --> Controller Class Initialized
DEBUG - 2023-04-24 02:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:02 --> Database Driver Class Initialized
INFO - 2023-04-24 02:01:02 --> Model "Cluster_model" initialized
INFO - 2023-04-24 02:01:02 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:02 --> Total execution time: 0.0181
INFO - 2023-04-24 02:01:02 --> Config Class Initialized
INFO - 2023-04-24 02:01:02 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:02 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:02 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:02 --> URI Class Initialized
INFO - 2023-04-24 02:01:02 --> Router Class Initialized
INFO - 2023-04-24 02:01:02 --> Output Class Initialized
INFO - 2023-04-24 02:01:02 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:02 --> Input Class Initialized
INFO - 2023-04-24 02:01:02 --> Language Class Initialized
INFO - 2023-04-24 02:01:02 --> Loader Class Initialized
INFO - 2023-04-24 02:01:02 --> Controller Class Initialized
DEBUG - 2023-04-24 02:01:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:02 --> Database Driver Class Initialized
INFO - 2023-04-24 02:01:02 --> Model "Cluster_model" initialized
INFO - 2023-04-24 02:01:02 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:02 --> Total execution time: 0.0151
INFO - 2023-04-24 02:01:23 --> Config Class Initialized
INFO - 2023-04-24 02:01:23 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:23 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:23 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:23 --> URI Class Initialized
INFO - 2023-04-24 02:01:23 --> Router Class Initialized
INFO - 2023-04-24 02:01:23 --> Output Class Initialized
INFO - 2023-04-24 02:01:23 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:23 --> Input Class Initialized
INFO - 2023-04-24 02:01:23 --> Language Class Initialized
INFO - 2023-04-24 02:01:23 --> Loader Class Initialized
INFO - 2023-04-24 02:01:23 --> Controller Class Initialized
INFO - 2023-04-24 02:01:23 --> Helper loaded: form_helper
INFO - 2023-04-24 02:01:23 --> Helper loaded: url_helper
DEBUG - 2023-04-24 02:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:23 --> Model "Change_model" initialized
INFO - 2023-04-24 02:01:23 --> Model "Grafana_model" initialized
INFO - 2023-04-24 02:01:23 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:23 --> Total execution time: 0.0281
INFO - 2023-04-24 02:01:23 --> Config Class Initialized
INFO - 2023-04-24 02:01:23 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:23 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:23 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:23 --> URI Class Initialized
INFO - 2023-04-24 02:01:23 --> Router Class Initialized
INFO - 2023-04-24 02:01:23 --> Output Class Initialized
INFO - 2023-04-24 02:01:23 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:23 --> Input Class Initialized
INFO - 2023-04-24 02:01:23 --> Language Class Initialized
INFO - 2023-04-24 02:01:23 --> Loader Class Initialized
INFO - 2023-04-24 02:01:23 --> Controller Class Initialized
INFO - 2023-04-24 02:01:23 --> Helper loaded: form_helper
INFO - 2023-04-24 02:01:23 --> Helper loaded: url_helper
DEBUG - 2023-04-24 02:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:23 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:23 --> Total execution time: 0.0033
INFO - 2023-04-24 02:01:23 --> Config Class Initialized
INFO - 2023-04-24 02:01:23 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:23 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:23 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:23 --> URI Class Initialized
INFO - 2023-04-24 02:01:23 --> Router Class Initialized
INFO - 2023-04-24 02:01:23 --> Output Class Initialized
INFO - 2023-04-24 02:01:23 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:23 --> Input Class Initialized
INFO - 2023-04-24 02:01:23 --> Language Class Initialized
INFO - 2023-04-24 02:01:23 --> Loader Class Initialized
INFO - 2023-04-24 02:01:23 --> Controller Class Initialized
INFO - 2023-04-24 02:01:23 --> Helper loaded: form_helper
INFO - 2023-04-24 02:01:23 --> Helper loaded: url_helper
DEBUG - 2023-04-24 02:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:23 --> Database Driver Class Initialized
INFO - 2023-04-24 02:01:23 --> Model "Login_model" initialized
INFO - 2023-04-24 02:01:23 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:23 --> Total execution time: 0.0153
INFO - 2023-04-24 02:01:23 --> Config Class Initialized
INFO - 2023-04-24 02:01:23 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:23 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:23 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:23 --> URI Class Initialized
INFO - 2023-04-24 02:01:23 --> Router Class Initialized
INFO - 2023-04-24 02:01:23 --> Output Class Initialized
INFO - 2023-04-24 02:01:23 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:23 --> Input Class Initialized
INFO - 2023-04-24 02:01:23 --> Language Class Initialized
INFO - 2023-04-24 02:01:23 --> Loader Class Initialized
INFO - 2023-04-24 02:01:23 --> Controller Class Initialized
DEBUG - 2023-04-24 02:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:23 --> Database Driver Class Initialized
INFO - 2023-04-24 02:01:23 --> Model "Cluster_model" initialized
INFO - 2023-04-24 02:01:23 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:23 --> Total execution time: 0.0140
INFO - 2023-04-24 02:01:23 --> Config Class Initialized
INFO - 2023-04-24 02:01:23 --> Hooks Class Initialized
DEBUG - 2023-04-24 02:01:23 --> UTF-8 Support Enabled
INFO - 2023-04-24 02:01:23 --> Utf8 Class Initialized
INFO - 2023-04-24 02:01:23 --> URI Class Initialized
INFO - 2023-04-24 02:01:23 --> Router Class Initialized
INFO - 2023-04-24 02:01:23 --> Output Class Initialized
INFO - 2023-04-24 02:01:23 --> Security Class Initialized
DEBUG - 2023-04-24 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 02:01:23 --> Input Class Initialized
INFO - 2023-04-24 02:01:23 --> Language Class Initialized
INFO - 2023-04-24 02:01:23 --> Loader Class Initialized
INFO - 2023-04-24 02:01:23 --> Controller Class Initialized
DEBUG - 2023-04-24 02:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 02:01:23 --> Database Driver Class Initialized
INFO - 2023-04-24 02:01:23 --> Model "Cluster_model" initialized
INFO - 2023-04-24 02:01:23 --> Final output sent to browser
DEBUG - 2023-04-24 02:01:23 --> Total execution time: 0.0299
INFO - 2023-04-24 03:09:21 --> Config Class Initialized
INFO - 2023-04-24 03:09:21 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:21 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:21 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:21 --> URI Class Initialized
INFO - 2023-04-24 03:09:21 --> Router Class Initialized
INFO - 2023-04-24 03:09:21 --> Output Class Initialized
INFO - 2023-04-24 03:09:21 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:21 --> Input Class Initialized
INFO - 2023-04-24 03:09:21 --> Language Class Initialized
INFO - 2023-04-24 03:09:21 --> Loader Class Initialized
INFO - 2023-04-24 03:09:21 --> Controller Class Initialized
INFO - 2023-04-24 03:09:21 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:21 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:21 --> Model "Change_model" initialized
INFO - 2023-04-24 03:09:21 --> Model "Grafana_model" initialized
INFO - 2023-04-24 03:09:21 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:21 --> Total execution time: 0.0337
INFO - 2023-04-24 03:09:21 --> Config Class Initialized
INFO - 2023-04-24 03:09:21 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:21 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:21 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:21 --> URI Class Initialized
INFO - 2023-04-24 03:09:21 --> Router Class Initialized
INFO - 2023-04-24 03:09:21 --> Output Class Initialized
INFO - 2023-04-24 03:09:21 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:21 --> Input Class Initialized
INFO - 2023-04-24 03:09:21 --> Language Class Initialized
INFO - 2023-04-24 03:09:21 --> Loader Class Initialized
INFO - 2023-04-24 03:09:21 --> Controller Class Initialized
INFO - 2023-04-24 03:09:21 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:21 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:21 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:21 --> Total execution time: 0.0428
INFO - 2023-04-24 03:09:21 --> Config Class Initialized
INFO - 2023-04-24 03:09:21 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:21 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:21 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:21 --> URI Class Initialized
INFO - 2023-04-24 03:09:21 --> Router Class Initialized
INFO - 2023-04-24 03:09:21 --> Output Class Initialized
INFO - 2023-04-24 03:09:21 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:21 --> Input Class Initialized
INFO - 2023-04-24 03:09:21 --> Language Class Initialized
INFO - 2023-04-24 03:09:21 --> Loader Class Initialized
INFO - 2023-04-24 03:09:21 --> Controller Class Initialized
INFO - 2023-04-24 03:09:21 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:21 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:21 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:21 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:21 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:21 --> Total execution time: 0.0567
INFO - 2023-04-24 03:09:29 --> Config Class Initialized
INFO - 2023-04-24 03:09:29 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:29 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:29 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:29 --> URI Class Initialized
INFO - 2023-04-24 03:09:29 --> Router Class Initialized
INFO - 2023-04-24 03:09:29 --> Output Class Initialized
INFO - 2023-04-24 03:09:29 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:29 --> Input Class Initialized
INFO - 2023-04-24 03:09:29 --> Language Class Initialized
INFO - 2023-04-24 03:09:29 --> Loader Class Initialized
INFO - 2023-04-24 03:09:29 --> Controller Class Initialized
INFO - 2023-04-24 03:09:29 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:29 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:29 --> Model "Change_model" initialized
INFO - 2023-04-24 03:09:29 --> Model "Grafana_model" initialized
INFO - 2023-04-24 03:09:29 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:29 --> Total execution time: 0.0309
INFO - 2023-04-24 03:09:29 --> Config Class Initialized
INFO - 2023-04-24 03:09:29 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:29 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:29 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:29 --> URI Class Initialized
INFO - 2023-04-24 03:09:29 --> Router Class Initialized
INFO - 2023-04-24 03:09:29 --> Output Class Initialized
INFO - 2023-04-24 03:09:29 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:29 --> Input Class Initialized
INFO - 2023-04-24 03:09:29 --> Language Class Initialized
INFO - 2023-04-24 03:09:29 --> Loader Class Initialized
INFO - 2023-04-24 03:09:29 --> Controller Class Initialized
INFO - 2023-04-24 03:09:29 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:29 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:29 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:29 --> Total execution time: 0.0040
INFO - 2023-04-24 03:09:29 --> Config Class Initialized
INFO - 2023-04-24 03:09:29 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:29 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:29 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:29 --> URI Class Initialized
INFO - 2023-04-24 03:09:29 --> Router Class Initialized
INFO - 2023-04-24 03:09:29 --> Output Class Initialized
INFO - 2023-04-24 03:09:29 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:29 --> Input Class Initialized
INFO - 2023-04-24 03:09:29 --> Language Class Initialized
INFO - 2023-04-24 03:09:29 --> Loader Class Initialized
INFO - 2023-04-24 03:09:29 --> Controller Class Initialized
INFO - 2023-04-24 03:09:29 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:29 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:29 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:29 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:29 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:29 --> Total execution time: 0.0122
INFO - 2023-04-24 03:09:37 --> Config Class Initialized
INFO - 2023-04-24 03:09:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:37 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:37 --> URI Class Initialized
INFO - 2023-04-24 03:09:37 --> Router Class Initialized
INFO - 2023-04-24 03:09:37 --> Output Class Initialized
INFO - 2023-04-24 03:09:37 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:37 --> Input Class Initialized
INFO - 2023-04-24 03:09:37 --> Language Class Initialized
INFO - 2023-04-24 03:09:37 --> Loader Class Initialized
INFO - 2023-04-24 03:09:37 --> Controller Class Initialized
INFO - 2023-04-24 03:09:37 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:37 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:37 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:37 --> Total execution time: 0.0046
INFO - 2023-04-24 03:09:37 --> Config Class Initialized
INFO - 2023-04-24 03:09:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:37 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:37 --> URI Class Initialized
INFO - 2023-04-24 03:09:37 --> Router Class Initialized
INFO - 2023-04-24 03:09:37 --> Output Class Initialized
INFO - 2023-04-24 03:09:37 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:37 --> Input Class Initialized
INFO - 2023-04-24 03:09:37 --> Language Class Initialized
INFO - 2023-04-24 03:09:37 --> Loader Class Initialized
INFO - 2023-04-24 03:09:37 --> Controller Class Initialized
INFO - 2023-04-24 03:09:37 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:37 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:37 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:37 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:37 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:37 --> Total execution time: 0.0266
INFO - 2023-04-24 03:09:41 --> Config Class Initialized
INFO - 2023-04-24 03:09:41 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:41 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:41 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:41 --> URI Class Initialized
INFO - 2023-04-24 03:09:41 --> Router Class Initialized
INFO - 2023-04-24 03:09:41 --> Output Class Initialized
INFO - 2023-04-24 03:09:41 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:41 --> Input Class Initialized
INFO - 2023-04-24 03:09:41 --> Language Class Initialized
INFO - 2023-04-24 03:09:41 --> Loader Class Initialized
INFO - 2023-04-24 03:09:41 --> Controller Class Initialized
INFO - 2023-04-24 03:09:41 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:41 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:41 --> Model "Change_model" initialized
INFO - 2023-04-24 03:09:41 --> Model "Grafana_model" initialized
INFO - 2023-04-24 03:09:41 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:41 --> Total execution time: 0.0263
INFO - 2023-04-24 03:09:41 --> Config Class Initialized
INFO - 2023-04-24 03:09:41 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:41 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:41 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:41 --> URI Class Initialized
INFO - 2023-04-24 03:09:41 --> Router Class Initialized
INFO - 2023-04-24 03:09:41 --> Output Class Initialized
INFO - 2023-04-24 03:09:41 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:41 --> Input Class Initialized
INFO - 2023-04-24 03:09:41 --> Language Class Initialized
INFO - 2023-04-24 03:09:41 --> Loader Class Initialized
INFO - 2023-04-24 03:09:41 --> Controller Class Initialized
INFO - 2023-04-24 03:09:41 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:41 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:41 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:41 --> Total execution time: 0.0028
INFO - 2023-04-24 03:09:41 --> Config Class Initialized
INFO - 2023-04-24 03:09:41 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:41 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:41 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:41 --> URI Class Initialized
INFO - 2023-04-24 03:09:41 --> Router Class Initialized
INFO - 2023-04-24 03:09:41 --> Output Class Initialized
INFO - 2023-04-24 03:09:41 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:41 --> Input Class Initialized
INFO - 2023-04-24 03:09:41 --> Language Class Initialized
INFO - 2023-04-24 03:09:41 --> Loader Class Initialized
INFO - 2023-04-24 03:09:41 --> Controller Class Initialized
INFO - 2023-04-24 03:09:41 --> Helper loaded: form_helper
INFO - 2023-04-24 03:09:41 --> Helper loaded: url_helper
DEBUG - 2023-04-24 03:09:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:41 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:41 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:41 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:41 --> Total execution time: 0.0192
INFO - 2023-04-24 03:09:41 --> Config Class Initialized
INFO - 2023-04-24 03:09:41 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:41 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:41 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:41 --> URI Class Initialized
INFO - 2023-04-24 03:09:41 --> Router Class Initialized
INFO - 2023-04-24 03:09:41 --> Output Class Initialized
INFO - 2023-04-24 03:09:41 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:41 --> Input Class Initialized
INFO - 2023-04-24 03:09:41 --> Language Class Initialized
INFO - 2023-04-24 03:09:41 --> Loader Class Initialized
INFO - 2023-04-24 03:09:41 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:41 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:41 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:41 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:41 --> Total execution time: 0.0165
INFO - 2023-04-24 03:09:41 --> Config Class Initialized
INFO - 2023-04-24 03:09:41 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:41 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:41 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:41 --> URI Class Initialized
INFO - 2023-04-24 03:09:41 --> Router Class Initialized
INFO - 2023-04-24 03:09:41 --> Output Class Initialized
INFO - 2023-04-24 03:09:41 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:41 --> Input Class Initialized
INFO - 2023-04-24 03:09:41 --> Language Class Initialized
INFO - 2023-04-24 03:09:41 --> Loader Class Initialized
INFO - 2023-04-24 03:09:41 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:41 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:41 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:41 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:41 --> Total execution time: 0.0934
INFO - 2023-04-24 03:09:42 --> Config Class Initialized
INFO - 2023-04-24 03:09:42 --> Config Class Initialized
INFO - 2023-04-24 03:09:42 --> Hooks Class Initialized
INFO - 2023-04-24 03:09:42 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 03:09:42 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:42 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:42 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:42 --> URI Class Initialized
INFO - 2023-04-24 03:09:42 --> URI Class Initialized
INFO - 2023-04-24 03:09:42 --> Router Class Initialized
INFO - 2023-04-24 03:09:42 --> Router Class Initialized
INFO - 2023-04-24 03:09:42 --> Output Class Initialized
INFO - 2023-04-24 03:09:42 --> Output Class Initialized
INFO - 2023-04-24 03:09:42 --> Security Class Initialized
INFO - 2023-04-24 03:09:42 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:42 --> Input Class Initialized
INFO - 2023-04-24 03:09:42 --> Language Class Initialized
DEBUG - 2023-04-24 03:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:42 --> Input Class Initialized
INFO - 2023-04-24 03:09:42 --> Loader Class Initialized
INFO - 2023-04-24 03:09:42 --> Language Class Initialized
INFO - 2023-04-24 03:09:42 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:42 --> Loader Class Initialized
INFO - 2023-04-24 03:09:42 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:42 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:42 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:42 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:42 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:42 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:42 --> Total execution time: 0.0557
INFO - 2023-04-24 03:09:42 --> Config Class Initialized
INFO - 2023-04-24 03:09:42 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:42 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:42 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:42 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:42 --> URI Class Initialized
INFO - 2023-04-24 03:09:42 --> Router Class Initialized
INFO - 2023-04-24 03:09:42 --> Output Class Initialized
INFO - 2023-04-24 03:09:42 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:42 --> Input Class Initialized
INFO - 2023-04-24 03:09:42 --> Language Class Initialized
INFO - 2023-04-24 03:09:42 --> Loader Class Initialized
INFO - 2023-04-24 03:09:42 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:42 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:42 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:42 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:42 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:42 --> Total execution time: 0.0514
INFO - 2023-04-24 03:09:42 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:42 --> Total execution time: 0.1399
INFO - 2023-04-24 03:09:42 --> Config Class Initialized
INFO - 2023-04-24 03:09:42 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:42 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:42 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:42 --> URI Class Initialized
INFO - 2023-04-24 03:09:42 --> Router Class Initialized
INFO - 2023-04-24 03:09:42 --> Output Class Initialized
INFO - 2023-04-24 03:09:42 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:42 --> Input Class Initialized
INFO - 2023-04-24 03:09:42 --> Language Class Initialized
INFO - 2023-04-24 03:09:42 --> Loader Class Initialized
INFO - 2023-04-24 03:09:42 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:42 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:42 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:42 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:42 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:42 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:42 --> Total execution time: 0.1038
INFO - 2023-04-24 03:09:52 --> Config Class Initialized
INFO - 2023-04-24 03:09:52 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:52 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:52 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:52 --> URI Class Initialized
INFO - 2023-04-24 03:09:52 --> Router Class Initialized
INFO - 2023-04-24 03:09:52 --> Output Class Initialized
INFO - 2023-04-24 03:09:52 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:52 --> Input Class Initialized
INFO - 2023-04-24 03:09:52 --> Language Class Initialized
INFO - 2023-04-24 03:09:52 --> Loader Class Initialized
INFO - 2023-04-24 03:09:52 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:52 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:52 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:52 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:52 --> Total execution time: 0.0229
INFO - 2023-04-24 03:09:52 --> Config Class Initialized
INFO - 2023-04-24 03:09:52 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:52 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:52 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:52 --> URI Class Initialized
INFO - 2023-04-24 03:09:52 --> Router Class Initialized
INFO - 2023-04-24 03:09:52 --> Output Class Initialized
INFO - 2023-04-24 03:09:52 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:52 --> Input Class Initialized
INFO - 2023-04-24 03:09:52 --> Language Class Initialized
INFO - 2023-04-24 03:09:52 --> Loader Class Initialized
INFO - 2023-04-24 03:09:52 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:52 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:52 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:52 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:52 --> Total execution time: 0.0603
INFO - 2023-04-24 03:09:53 --> Config Class Initialized
INFO - 2023-04-24 03:09:53 --> Config Class Initialized
INFO - 2023-04-24 03:09:53 --> Hooks Class Initialized
INFO - 2023-04-24 03:09:53 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:53 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 03:09:53 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:53 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:53 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:53 --> URI Class Initialized
INFO - 2023-04-24 03:09:53 --> URI Class Initialized
INFO - 2023-04-24 03:09:53 --> Router Class Initialized
INFO - 2023-04-24 03:09:53 --> Router Class Initialized
INFO - 2023-04-24 03:09:53 --> Output Class Initialized
INFO - 2023-04-24 03:09:53 --> Output Class Initialized
INFO - 2023-04-24 03:09:53 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:53 --> Security Class Initialized
INFO - 2023-04-24 03:09:53 --> Input Class Initialized
DEBUG - 2023-04-24 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:53 --> Language Class Initialized
INFO - 2023-04-24 03:09:53 --> Input Class Initialized
INFO - 2023-04-24 03:09:53 --> Language Class Initialized
INFO - 2023-04-24 03:09:53 --> Loader Class Initialized
INFO - 2023-04-24 03:09:53 --> Controller Class Initialized
INFO - 2023-04-24 03:09:53 --> Loader Class Initialized
DEBUG - 2023-04-24 03:09:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:53 --> Controller Class Initialized
INFO - 2023-04-24 03:09:53 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 03:09:53 --> Total execution time: 0.0047
INFO - 2023-04-24 03:09:53 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:53 --> Config Class Initialized
INFO - 2023-04-24 03:09:53 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:53 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:53 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:53 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:53 --> URI Class Initialized
INFO - 2023-04-24 03:09:53 --> Router Class Initialized
INFO - 2023-04-24 03:09:53 --> Output Class Initialized
INFO - 2023-04-24 03:09:53 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:53 --> Input Class Initialized
INFO - 2023-04-24 03:09:53 --> Language Class Initialized
INFO - 2023-04-24 03:09:53 --> Loader Class Initialized
INFO - 2023-04-24 03:09:53 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:53 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:53 --> Total execution time: 0.0511
INFO - 2023-04-24 03:09:53 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:53 --> Config Class Initialized
INFO - 2023-04-24 03:09:53 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:53 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:53 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:53 --> URI Class Initialized
INFO - 2023-04-24 03:09:53 --> Router Class Initialized
INFO - 2023-04-24 03:09:53 --> Output Class Initialized
INFO - 2023-04-24 03:09:53 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:53 --> Input Class Initialized
INFO - 2023-04-24 03:09:53 --> Language Class Initialized
INFO - 2023-04-24 03:09:53 --> Loader Class Initialized
INFO - 2023-04-24 03:09:53 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:53 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:53 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:53 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:53 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:53 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:53 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:53 --> Total execution time: 0.0157
INFO - 2023-04-24 03:09:53 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:53 --> Total execution time: 0.0654
INFO - 2023-04-24 03:09:55 --> Config Class Initialized
INFO - 2023-04-24 03:09:55 --> Config Class Initialized
INFO - 2023-04-24 03:09:55 --> Hooks Class Initialized
INFO - 2023-04-24 03:09:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 03:09:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:55 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:55 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:55 --> URI Class Initialized
INFO - 2023-04-24 03:09:55 --> URI Class Initialized
INFO - 2023-04-24 03:09:55 --> Router Class Initialized
INFO - 2023-04-24 03:09:55 --> Router Class Initialized
INFO - 2023-04-24 03:09:55 --> Output Class Initialized
INFO - 2023-04-24 03:09:55 --> Output Class Initialized
INFO - 2023-04-24 03:09:55 --> Security Class Initialized
INFO - 2023-04-24 03:09:55 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 03:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:55 --> Input Class Initialized
INFO - 2023-04-24 03:09:55 --> Input Class Initialized
INFO - 2023-04-24 03:09:55 --> Language Class Initialized
INFO - 2023-04-24 03:09:55 --> Language Class Initialized
INFO - 2023-04-24 03:09:55 --> Loader Class Initialized
INFO - 2023-04-24 03:09:55 --> Loader Class Initialized
INFO - 2023-04-24 03:09:55 --> Controller Class Initialized
INFO - 2023-04-24 03:09:55 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 03:09:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:55 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:55 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:55 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:55 --> Total execution time: 0.0186
INFO - 2023-04-24 03:09:55 --> Config Class Initialized
INFO - 2023-04-24 03:09:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:55 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:55 --> URI Class Initialized
INFO - 2023-04-24 03:09:55 --> Router Class Initialized
INFO - 2023-04-24 03:09:55 --> Output Class Initialized
INFO - 2023-04-24 03:09:55 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:55 --> Input Class Initialized
INFO - 2023-04-24 03:09:55 --> Language Class Initialized
INFO - 2023-04-24 03:09:55 --> Loader Class Initialized
INFO - 2023-04-24 03:09:55 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:55 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:55 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:55 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:55 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:55 --> Total execution time: 0.0345
INFO - 2023-04-24 03:09:55 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:55 --> Total execution time: 0.0967
INFO - 2023-04-24 03:09:55 --> Config Class Initialized
INFO - 2023-04-24 03:09:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:55 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:55 --> URI Class Initialized
INFO - 2023-04-24 03:09:55 --> Router Class Initialized
INFO - 2023-04-24 03:09:55 --> Output Class Initialized
INFO - 2023-04-24 03:09:55 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:55 --> Input Class Initialized
INFO - 2023-04-24 03:09:55 --> Language Class Initialized
INFO - 2023-04-24 03:09:55 --> Loader Class Initialized
INFO - 2023-04-24 03:09:55 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:55 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:55 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:55 --> Model "Login_model" initialized
INFO - 2023-04-24 03:09:55 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:55 --> Total execution time: 0.0674
INFO - 2023-04-24 03:09:57 --> Config Class Initialized
INFO - 2023-04-24 03:09:57 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:57 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:57 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:57 --> URI Class Initialized
INFO - 2023-04-24 03:09:57 --> Router Class Initialized
INFO - 2023-04-24 03:09:57 --> Output Class Initialized
INFO - 2023-04-24 03:09:57 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:57 --> Input Class Initialized
INFO - 2023-04-24 03:09:57 --> Language Class Initialized
INFO - 2023-04-24 03:09:57 --> Loader Class Initialized
INFO - 2023-04-24 03:09:57 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:57 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:57 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:57 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:57 --> Total execution time: 0.0135
INFO - 2023-04-24 03:09:57 --> Config Class Initialized
INFO - 2023-04-24 03:09:57 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:57 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:57 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:57 --> URI Class Initialized
INFO - 2023-04-24 03:09:57 --> Router Class Initialized
INFO - 2023-04-24 03:09:57 --> Output Class Initialized
INFO - 2023-04-24 03:09:57 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:57 --> Input Class Initialized
INFO - 2023-04-24 03:09:57 --> Language Class Initialized
INFO - 2023-04-24 03:09:57 --> Loader Class Initialized
INFO - 2023-04-24 03:09:57 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:57 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:57 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:57 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:57 --> Total execution time: 0.0529
INFO - 2023-04-24 03:09:57 --> Config Class Initialized
INFO - 2023-04-24 03:09:58 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:58 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:58 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:58 --> URI Class Initialized
INFO - 2023-04-24 03:09:58 --> Router Class Initialized
INFO - 2023-04-24 03:09:58 --> Output Class Initialized
INFO - 2023-04-24 03:09:58 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:58 --> Input Class Initialized
INFO - 2023-04-24 03:09:58 --> Language Class Initialized
INFO - 2023-04-24 03:09:58 --> Loader Class Initialized
INFO - 2023-04-24 03:09:58 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:58 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:58 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:58 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:58 --> Total execution time: 0.0502
INFO - 2023-04-24 03:09:58 --> Config Class Initialized
INFO - 2023-04-24 03:09:58 --> Hooks Class Initialized
DEBUG - 2023-04-24 03:09:58 --> UTF-8 Support Enabled
INFO - 2023-04-24 03:09:58 --> Utf8 Class Initialized
INFO - 2023-04-24 03:09:58 --> URI Class Initialized
INFO - 2023-04-24 03:09:58 --> Router Class Initialized
INFO - 2023-04-24 03:09:58 --> Output Class Initialized
INFO - 2023-04-24 03:09:58 --> Security Class Initialized
DEBUG - 2023-04-24 03:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 03:09:58 --> Input Class Initialized
INFO - 2023-04-24 03:09:58 --> Language Class Initialized
INFO - 2023-04-24 03:09:58 --> Loader Class Initialized
INFO - 2023-04-24 03:09:58 --> Controller Class Initialized
DEBUG - 2023-04-24 03:09:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 03:09:58 --> Database Driver Class Initialized
INFO - 2023-04-24 03:09:58 --> Model "Cluster_model" initialized
INFO - 2023-04-24 03:09:58 --> Final output sent to browser
DEBUG - 2023-04-24 03:09:58 --> Total execution time: 0.0525
INFO - 2023-04-24 09:31:55 --> Config Class Initialized
INFO - 2023-04-24 09:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:55 --> Utf8 Class Initialized
INFO - 2023-04-24 09:31:55 --> URI Class Initialized
INFO - 2023-04-24 09:31:55 --> Router Class Initialized
INFO - 2023-04-24 09:31:55 --> Output Class Initialized
INFO - 2023-04-24 09:31:55 --> Security Class Initialized
DEBUG - 2023-04-24 09:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:55 --> Input Class Initialized
INFO - 2023-04-24 09:31:55 --> Language Class Initialized
INFO - 2023-04-24 09:31:55 --> Loader Class Initialized
INFO - 2023-04-24 09:31:55 --> Controller Class Initialized
INFO - 2023-04-24 09:31:55 --> Helper loaded: form_helper
INFO - 2023-04-24 09:31:55 --> Helper loaded: url_helper
DEBUG - 2023-04-24 09:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:55 --> Model "Change_model" initialized
INFO - 2023-04-24 09:31:55 --> Model "Grafana_model" initialized
INFO - 2023-04-24 09:31:55 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:55 --> Total execution time: 0.0452
INFO - 2023-04-24 09:31:55 --> Config Class Initialized
INFO - 2023-04-24 09:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:55 --> Utf8 Class Initialized
INFO - 2023-04-24 09:31:55 --> URI Class Initialized
INFO - 2023-04-24 09:31:55 --> Router Class Initialized
INFO - 2023-04-24 09:31:55 --> Output Class Initialized
INFO - 2023-04-24 09:31:55 --> Security Class Initialized
DEBUG - 2023-04-24 09:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:55 --> Input Class Initialized
INFO - 2023-04-24 09:31:55 --> Language Class Initialized
INFO - 2023-04-24 09:31:55 --> Loader Class Initialized
INFO - 2023-04-24 09:31:55 --> Controller Class Initialized
INFO - 2023-04-24 09:31:55 --> Helper loaded: form_helper
INFO - 2023-04-24 09:31:55 --> Helper loaded: url_helper
DEBUG - 2023-04-24 09:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:55 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:55 --> Total execution time: 0.1301
INFO - 2023-04-24 09:31:55 --> Config Class Initialized
INFO - 2023-04-24 09:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:55 --> Utf8 Class Initialized
INFO - 2023-04-24 09:31:55 --> URI Class Initialized
INFO - 2023-04-24 09:31:55 --> Router Class Initialized
INFO - 2023-04-24 09:31:55 --> Output Class Initialized
INFO - 2023-04-24 09:31:55 --> Security Class Initialized
DEBUG - 2023-04-24 09:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:55 --> Input Class Initialized
INFO - 2023-04-24 09:31:55 --> Language Class Initialized
INFO - 2023-04-24 09:31:55 --> Loader Class Initialized
INFO - 2023-04-24 09:31:55 --> Controller Class Initialized
INFO - 2023-04-24 09:31:55 --> Helper loaded: form_helper
INFO - 2023-04-24 09:31:55 --> Helper loaded: url_helper
DEBUG - 2023-04-24 09:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:55 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:55 --> Model "Login_model" initialized
INFO - 2023-04-24 09:31:55 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:55 --> Total execution time: 0.0197
INFO - 2023-04-24 09:31:55 --> Config Class Initialized
INFO - 2023-04-24 09:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:55 --> Utf8 Class Initialized
INFO - 2023-04-24 09:31:55 --> URI Class Initialized
INFO - 2023-04-24 09:31:55 --> Router Class Initialized
INFO - 2023-04-24 09:31:55 --> Output Class Initialized
INFO - 2023-04-24 09:31:55 --> Security Class Initialized
DEBUG - 2023-04-24 09:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:55 --> Input Class Initialized
INFO - 2023-04-24 09:31:55 --> Language Class Initialized
INFO - 2023-04-24 09:31:55 --> Loader Class Initialized
INFO - 2023-04-24 09:31:55 --> Controller Class Initialized
DEBUG - 2023-04-24 09:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:55 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:31:55 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:55 --> Total execution time: 0.0582
INFO - 2023-04-24 09:31:55 --> Config Class Initialized
INFO - 2023-04-24 09:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:55 --> Utf8 Class Initialized
INFO - 2023-04-24 09:31:55 --> URI Class Initialized
INFO - 2023-04-24 09:31:55 --> Router Class Initialized
INFO - 2023-04-24 09:31:55 --> Output Class Initialized
INFO - 2023-04-24 09:31:55 --> Security Class Initialized
DEBUG - 2023-04-24 09:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:55 --> Input Class Initialized
INFO - 2023-04-24 09:31:55 --> Language Class Initialized
INFO - 2023-04-24 09:31:55 --> Loader Class Initialized
INFO - 2023-04-24 09:31:55 --> Controller Class Initialized
DEBUG - 2023-04-24 09:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:55 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:31:55 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:55 --> Total execution time: 0.0171
INFO - 2023-04-24 09:31:55 --> Config Class Initialized
INFO - 2023-04-24 09:31:55 --> Config Class Initialized
INFO - 2023-04-24 09:31:55 --> Hooks Class Initialized
INFO - 2023-04-24 09:31:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:31:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:56 --> Utf8 Class Initialized
DEBUG - 2023-04-24 09:31:56 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:56 --> URI Class Initialized
INFO - 2023-04-24 09:31:56 --> Utf8 Class Initialized
INFO - 2023-04-24 09:31:56 --> Router Class Initialized
INFO - 2023-04-24 09:31:56 --> URI Class Initialized
INFO - 2023-04-24 09:31:56 --> Output Class Initialized
INFO - 2023-04-24 09:31:56 --> Router Class Initialized
INFO - 2023-04-24 09:31:56 --> Output Class Initialized
INFO - 2023-04-24 09:31:56 --> Security Class Initialized
INFO - 2023-04-24 09:31:56 --> Security Class Initialized
DEBUG - 2023-04-24 09:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:56 --> Input Class Initialized
DEBUG - 2023-04-24 09:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:56 --> Language Class Initialized
INFO - 2023-04-24 09:31:56 --> Input Class Initialized
INFO - 2023-04-24 09:31:56 --> Language Class Initialized
INFO - 2023-04-24 09:31:56 --> Loader Class Initialized
INFO - 2023-04-24 09:31:56 --> Controller Class Initialized
DEBUG - 2023-04-24 09:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:56 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:56 --> Loader Class Initialized
INFO - 2023-04-24 09:31:56 --> Controller Class Initialized
DEBUG - 2023-04-24 09:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:56 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:56 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:31:56 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:31:56 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:56 --> Total execution time: 0.1020
INFO - 2023-04-24 09:31:56 --> Config Class Initialized
INFO - 2023-04-24 09:31:56 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:56 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:31:56 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:56 --> Utf8 Class Initialized
INFO - 2023-04-24 09:31:56 --> URI Class Initialized
INFO - 2023-04-24 09:31:56 --> Router Class Initialized
INFO - 2023-04-24 09:31:56 --> Output Class Initialized
INFO - 2023-04-24 09:31:56 --> Security Class Initialized
DEBUG - 2023-04-24 09:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:56 --> Input Class Initialized
INFO - 2023-04-24 09:31:56 --> Language Class Initialized
INFO - 2023-04-24 09:31:56 --> Loader Class Initialized
INFO - 2023-04-24 09:31:56 --> Controller Class Initialized
DEBUG - 2023-04-24 09:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:56 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:56 --> Model "Login_model" initialized
INFO - 2023-04-24 09:31:56 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:31:56 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:56 --> Total execution time: 0.0541
INFO - 2023-04-24 09:31:56 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:56 --> Total execution time: 0.1878
INFO - 2023-04-24 09:31:56 --> Config Class Initialized
INFO - 2023-04-24 09:31:56 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:31:56 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:31:56 --> Utf8 Class Initialized
INFO - 2023-04-24 09:31:56 --> URI Class Initialized
INFO - 2023-04-24 09:31:56 --> Router Class Initialized
INFO - 2023-04-24 09:31:56 --> Output Class Initialized
INFO - 2023-04-24 09:31:56 --> Security Class Initialized
DEBUG - 2023-04-24 09:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:31:56 --> Input Class Initialized
INFO - 2023-04-24 09:31:56 --> Language Class Initialized
INFO - 2023-04-24 09:31:56 --> Loader Class Initialized
INFO - 2023-04-24 09:31:56 --> Controller Class Initialized
DEBUG - 2023-04-24 09:31:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:31:56 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:56 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:31:56 --> Database Driver Class Initialized
INFO - 2023-04-24 09:31:56 --> Model "Login_model" initialized
INFO - 2023-04-24 09:31:56 --> Final output sent to browser
DEBUG - 2023-04-24 09:31:56 --> Total execution time: 0.1975
INFO - 2023-04-24 09:32:05 --> Config Class Initialized
INFO - 2023-04-24 09:32:05 --> Config Class Initialized
INFO - 2023-04-24 09:32:05 --> Hooks Class Initialized
INFO - 2023-04-24 09:32:05 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 09:32:05 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:32:05 --> Utf8 Class Initialized
INFO - 2023-04-24 09:32:05 --> Utf8 Class Initialized
INFO - 2023-04-24 09:32:05 --> URI Class Initialized
INFO - 2023-04-24 09:32:05 --> URI Class Initialized
INFO - 2023-04-24 09:32:05 --> Router Class Initialized
INFO - 2023-04-24 09:32:05 --> Router Class Initialized
INFO - 2023-04-24 09:32:05 --> Output Class Initialized
INFO - 2023-04-24 09:32:05 --> Security Class Initialized
INFO - 2023-04-24 09:32:05 --> Output Class Initialized
DEBUG - 2023-04-24 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:32:05 --> Security Class Initialized
INFO - 2023-04-24 09:32:05 --> Input Class Initialized
DEBUG - 2023-04-24 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:32:05 --> Language Class Initialized
INFO - 2023-04-24 09:32:05 --> Input Class Initialized
INFO - 2023-04-24 09:32:05 --> Language Class Initialized
INFO - 2023-04-24 09:32:05 --> Loader Class Initialized
INFO - 2023-04-24 09:32:05 --> Controller Class Initialized
INFO - 2023-04-24 09:32:05 --> Loader Class Initialized
INFO - 2023-04-24 09:32:05 --> Controller Class Initialized
DEBUG - 2023-04-24 09:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 09:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:32:05 --> Database Driver Class Initialized
INFO - 2023-04-24 09:32:05 --> Database Driver Class Initialized
INFO - 2023-04-24 09:32:05 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:32:05 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:32:05 --> Final output sent to browser
DEBUG - 2023-04-24 09:32:05 --> Total execution time: 0.0567
INFO - 2023-04-24 09:32:05 --> Database Driver Class Initialized
INFO - 2023-04-24 09:32:05 --> Config Class Initialized
INFO - 2023-04-24 09:32:05 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:32:05 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:32:05 --> Utf8 Class Initialized
INFO - 2023-04-24 09:32:05 --> URI Class Initialized
INFO - 2023-04-24 09:32:05 --> Router Class Initialized
INFO - 2023-04-24 09:32:05 --> Output Class Initialized
INFO - 2023-04-24 09:32:05 --> Security Class Initialized
DEBUG - 2023-04-24 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:32:05 --> Input Class Initialized
INFO - 2023-04-24 09:32:05 --> Language Class Initialized
INFO - 2023-04-24 09:32:05 --> Loader Class Initialized
INFO - 2023-04-24 09:32:05 --> Controller Class Initialized
DEBUG - 2023-04-24 09:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:32:05 --> Database Driver Class Initialized
INFO - 2023-04-24 09:32:05 --> Model "Login_model" initialized
INFO - 2023-04-24 09:32:05 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:32:05 --> Final output sent to browser
DEBUG - 2023-04-24 09:32:05 --> Total execution time: 0.0158
INFO - 2023-04-24 09:32:05 --> Final output sent to browser
DEBUG - 2023-04-24 09:32:05 --> Total execution time: 0.1220
INFO - 2023-04-24 09:32:05 --> Config Class Initialized
INFO - 2023-04-24 09:32:05 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:32:05 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:32:05 --> Utf8 Class Initialized
INFO - 2023-04-24 09:32:05 --> URI Class Initialized
INFO - 2023-04-24 09:32:05 --> Router Class Initialized
INFO - 2023-04-24 09:32:05 --> Output Class Initialized
INFO - 2023-04-24 09:32:05 --> Security Class Initialized
DEBUG - 2023-04-24 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:32:05 --> Input Class Initialized
INFO - 2023-04-24 09:32:05 --> Language Class Initialized
INFO - 2023-04-24 09:32:05 --> Loader Class Initialized
INFO - 2023-04-24 09:32:05 --> Controller Class Initialized
DEBUG - 2023-04-24 09:32:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:32:05 --> Database Driver Class Initialized
INFO - 2023-04-24 09:32:05 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:32:05 --> Database Driver Class Initialized
INFO - 2023-04-24 09:32:05 --> Model "Login_model" initialized
INFO - 2023-04-24 09:32:05 --> Final output sent to browser
DEBUG - 2023-04-24 09:32:05 --> Total execution time: 0.1176
INFO - 2023-04-24 09:34:37 --> Config Class Initialized
INFO - 2023-04-24 09:34:37 --> Config Class Initialized
INFO - 2023-04-24 09:34:37 --> Hooks Class Initialized
INFO - 2023-04-24 09:34:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:34:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 09:34:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:34:37 --> Utf8 Class Initialized
INFO - 2023-04-24 09:34:37 --> Utf8 Class Initialized
INFO - 2023-04-24 09:34:37 --> URI Class Initialized
INFO - 2023-04-24 09:34:37 --> URI Class Initialized
INFO - 2023-04-24 09:34:37 --> Router Class Initialized
INFO - 2023-04-24 09:34:37 --> Router Class Initialized
INFO - 2023-04-24 09:34:37 --> Output Class Initialized
INFO - 2023-04-24 09:34:37 --> Output Class Initialized
INFO - 2023-04-24 09:34:37 --> Security Class Initialized
INFO - 2023-04-24 09:34:37 --> Security Class Initialized
DEBUG - 2023-04-24 09:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:34:37 --> Input Class Initialized
INFO - 2023-04-24 09:34:37 --> Input Class Initialized
INFO - 2023-04-24 09:34:37 --> Language Class Initialized
INFO - 2023-04-24 09:34:37 --> Language Class Initialized
INFO - 2023-04-24 09:34:37 --> Loader Class Initialized
INFO - 2023-04-24 09:34:37 --> Controller Class Initialized
DEBUG - 2023-04-24 09:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:34:37 --> Database Driver Class Initialized
INFO - 2023-04-24 09:34:37 --> Loader Class Initialized
INFO - 2023-04-24 09:34:37 --> Controller Class Initialized
DEBUG - 2023-04-24 09:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:34:37 --> Database Driver Class Initialized
INFO - 2023-04-24 09:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:34:37 --> Final output sent to browser
INFO - 2023-04-24 09:34:37 --> Database Driver Class Initialized
DEBUG - 2023-04-24 09:34:37 --> Total execution time: 0.0349
INFO - 2023-04-24 09:34:37 --> Config Class Initialized
INFO - 2023-04-24 09:34:37 --> Model "Login_model" initialized
INFO - 2023-04-24 09:34:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:34:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:34:37 --> Utf8 Class Initialized
INFO - 2023-04-24 09:34:37 --> URI Class Initialized
INFO - 2023-04-24 09:34:37 --> Router Class Initialized
INFO - 2023-04-24 09:34:37 --> Output Class Initialized
INFO - 2023-04-24 09:34:37 --> Security Class Initialized
DEBUG - 2023-04-24 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:34:37 --> Input Class Initialized
INFO - 2023-04-24 09:34:37 --> Language Class Initialized
INFO - 2023-04-24 09:34:37 --> Loader Class Initialized
INFO - 2023-04-24 09:34:37 --> Controller Class Initialized
DEBUG - 2023-04-24 09:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:34:37 --> Database Driver Class Initialized
INFO - 2023-04-24 09:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:34:37 --> Final output sent to browser
DEBUG - 2023-04-24 09:34:37 --> Total execution time: 0.0949
INFO - 2023-04-24 09:34:37 --> Final output sent to browser
DEBUG - 2023-04-24 09:34:37 --> Total execution time: 0.2128
INFO - 2023-04-24 09:34:37 --> Config Class Initialized
INFO - 2023-04-24 09:34:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:34:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:34:37 --> Utf8 Class Initialized
INFO - 2023-04-24 09:34:37 --> URI Class Initialized
INFO - 2023-04-24 09:34:37 --> Router Class Initialized
INFO - 2023-04-24 09:34:37 --> Output Class Initialized
INFO - 2023-04-24 09:34:37 --> Security Class Initialized
DEBUG - 2023-04-24 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:34:37 --> Input Class Initialized
INFO - 2023-04-24 09:34:37 --> Language Class Initialized
INFO - 2023-04-24 09:34:37 --> Loader Class Initialized
INFO - 2023-04-24 09:34:37 --> Controller Class Initialized
DEBUG - 2023-04-24 09:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:34:37 --> Database Driver Class Initialized
INFO - 2023-04-24 09:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:34:37 --> Database Driver Class Initialized
INFO - 2023-04-24 09:34:37 --> Model "Login_model" initialized
INFO - 2023-04-24 09:34:37 --> Final output sent to browser
DEBUG - 2023-04-24 09:34:37 --> Total execution time: 0.1030
INFO - 2023-04-24 09:35:13 --> Config Class Initialized
INFO - 2023-04-24 09:35:13 --> Config Class Initialized
INFO - 2023-04-24 09:35:13 --> Hooks Class Initialized
INFO - 2023-04-24 09:35:13 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:35:13 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:35:13 --> Utf8 Class Initialized
DEBUG - 2023-04-24 09:35:13 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:35:13 --> Utf8 Class Initialized
INFO - 2023-04-24 09:35:13 --> URI Class Initialized
INFO - 2023-04-24 09:35:13 --> URI Class Initialized
INFO - 2023-04-24 09:35:13 --> Router Class Initialized
INFO - 2023-04-24 09:35:13 --> Router Class Initialized
INFO - 2023-04-24 09:35:13 --> Output Class Initialized
INFO - 2023-04-24 09:35:13 --> Output Class Initialized
INFO - 2023-04-24 09:35:13 --> Security Class Initialized
INFO - 2023-04-24 09:35:13 --> Security Class Initialized
DEBUG - 2023-04-24 09:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 09:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:35:13 --> Input Class Initialized
INFO - 2023-04-24 09:35:13 --> Input Class Initialized
INFO - 2023-04-24 09:35:13 --> Language Class Initialized
INFO - 2023-04-24 09:35:13 --> Language Class Initialized
INFO - 2023-04-24 09:35:13 --> Loader Class Initialized
INFO - 2023-04-24 09:35:13 --> Loader Class Initialized
INFO - 2023-04-24 09:35:13 --> Controller Class Initialized
INFO - 2023-04-24 09:35:13 --> Controller Class Initialized
DEBUG - 2023-04-24 09:35:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 09:35:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:35:13 --> Database Driver Class Initialized
INFO - 2023-04-24 09:35:13 --> Database Driver Class Initialized
INFO - 2023-04-24 09:35:13 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:35:13 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:35:13 --> Final output sent to browser
DEBUG - 2023-04-24 09:35:13 --> Total execution time: 0.1375
INFO - 2023-04-24 09:35:13 --> Config Class Initialized
INFO - 2023-04-24 09:35:13 --> Database Driver Class Initialized
INFO - 2023-04-24 09:35:14 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:35:14 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:35:14 --> Utf8 Class Initialized
INFO - 2023-04-24 09:35:14 --> URI Class Initialized
INFO - 2023-04-24 09:35:14 --> Router Class Initialized
INFO - 2023-04-24 09:35:14 --> Output Class Initialized
INFO - 2023-04-24 09:35:14 --> Security Class Initialized
DEBUG - 2023-04-24 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:35:14 --> Input Class Initialized
INFO - 2023-04-24 09:35:14 --> Language Class Initialized
INFO - 2023-04-24 09:35:14 --> Loader Class Initialized
INFO - 2023-04-24 09:35:14 --> Controller Class Initialized
DEBUG - 2023-04-24 09:35:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:35:14 --> Database Driver Class Initialized
INFO - 2023-04-24 09:35:14 --> Model "Login_model" initialized
INFO - 2023-04-24 09:35:14 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:35:14 --> Final output sent to browser
DEBUG - 2023-04-24 09:35:14 --> Total execution time: 0.0590
INFO - 2023-04-24 09:35:14 --> Final output sent to browser
DEBUG - 2023-04-24 09:35:14 --> Total execution time: 0.2433
INFO - 2023-04-24 09:35:14 --> Config Class Initialized
INFO - 2023-04-24 09:35:14 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:35:14 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:35:14 --> Utf8 Class Initialized
INFO - 2023-04-24 09:35:14 --> URI Class Initialized
INFO - 2023-04-24 09:35:14 --> Router Class Initialized
INFO - 2023-04-24 09:35:14 --> Output Class Initialized
INFO - 2023-04-24 09:35:14 --> Security Class Initialized
DEBUG - 2023-04-24 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:35:14 --> Input Class Initialized
INFO - 2023-04-24 09:35:14 --> Language Class Initialized
INFO - 2023-04-24 09:35:14 --> Loader Class Initialized
INFO - 2023-04-24 09:35:14 --> Controller Class Initialized
DEBUG - 2023-04-24 09:35:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:35:14 --> Database Driver Class Initialized
INFO - 2023-04-24 09:35:14 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:35:14 --> Database Driver Class Initialized
INFO - 2023-04-24 09:35:14 --> Model "Login_model" initialized
INFO - 2023-04-24 09:35:14 --> Final output sent to browser
DEBUG - 2023-04-24 09:35:14 --> Total execution time: 0.1267
INFO - 2023-04-24 09:36:55 --> Config Class Initialized
INFO - 2023-04-24 09:36:55 --> Config Class Initialized
INFO - 2023-04-24 09:36:55 --> Hooks Class Initialized
INFO - 2023-04-24 09:36:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:36:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:36:55 --> Utf8 Class Initialized
DEBUG - 2023-04-24 09:36:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:36:55 --> Utf8 Class Initialized
INFO - 2023-04-24 09:36:55 --> URI Class Initialized
INFO - 2023-04-24 09:36:55 --> Router Class Initialized
INFO - 2023-04-24 09:36:55 --> Output Class Initialized
INFO - 2023-04-24 09:36:55 --> URI Class Initialized
INFO - 2023-04-24 09:36:55 --> Router Class Initialized
INFO - 2023-04-24 09:36:55 --> Output Class Initialized
INFO - 2023-04-24 09:36:55 --> Security Class Initialized
DEBUG - 2023-04-24 09:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:36:55 --> Security Class Initialized
INFO - 2023-04-24 09:36:55 --> Input Class Initialized
DEBUG - 2023-04-24 09:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:36:55 --> Input Class Initialized
INFO - 2023-04-24 09:36:55 --> Language Class Initialized
INFO - 2023-04-24 09:36:55 --> Language Class Initialized
INFO - 2023-04-24 09:36:55 --> Loader Class Initialized
INFO - 2023-04-24 09:36:55 --> Controller Class Initialized
DEBUG - 2023-04-24 09:36:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:36:55 --> Loader Class Initialized
INFO - 2023-04-24 09:36:55 --> Controller Class Initialized
DEBUG - 2023-04-24 09:36:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:36:55 --> Database Driver Class Initialized
INFO - 2023-04-24 09:36:55 --> Database Driver Class Initialized
INFO - 2023-04-24 09:36:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:36:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:36:55 --> Final output sent to browser
INFO - 2023-04-24 09:36:55 --> Database Driver Class Initialized
DEBUG - 2023-04-24 09:36:55 --> Total execution time: 0.0799
INFO - 2023-04-24 09:36:55 --> Config Class Initialized
INFO - 2023-04-24 09:36:55 --> Model "Login_model" initialized
INFO - 2023-04-24 09:36:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:36:55 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:36:55 --> Utf8 Class Initialized
INFO - 2023-04-24 09:36:55 --> URI Class Initialized
INFO - 2023-04-24 09:36:55 --> Router Class Initialized
INFO - 2023-04-24 09:36:55 --> Output Class Initialized
INFO - 2023-04-24 09:36:55 --> Security Class Initialized
DEBUG - 2023-04-24 09:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:36:55 --> Input Class Initialized
INFO - 2023-04-24 09:36:55 --> Language Class Initialized
INFO - 2023-04-24 09:36:55 --> Loader Class Initialized
INFO - 2023-04-24 09:36:55 --> Controller Class Initialized
DEBUG - 2023-04-24 09:36:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:36:55 --> Database Driver Class Initialized
INFO - 2023-04-24 09:36:55 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:36:55 --> Final output sent to browser
DEBUG - 2023-04-24 09:36:55 --> Total execution time: 0.0630
INFO - 2023-04-24 09:36:56 --> Final output sent to browser
DEBUG - 2023-04-24 09:36:56 --> Total execution time: 0.2169
INFO - 2023-04-24 09:36:56 --> Config Class Initialized
INFO - 2023-04-24 09:36:56 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:36:56 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:36:56 --> Utf8 Class Initialized
INFO - 2023-04-24 09:36:56 --> URI Class Initialized
INFO - 2023-04-24 09:36:56 --> Router Class Initialized
INFO - 2023-04-24 09:36:56 --> Output Class Initialized
INFO - 2023-04-24 09:36:56 --> Security Class Initialized
DEBUG - 2023-04-24 09:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:36:56 --> Input Class Initialized
INFO - 2023-04-24 09:36:56 --> Language Class Initialized
INFO - 2023-04-24 09:36:56 --> Loader Class Initialized
INFO - 2023-04-24 09:36:56 --> Controller Class Initialized
DEBUG - 2023-04-24 09:36:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:36:56 --> Database Driver Class Initialized
INFO - 2023-04-24 09:36:56 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:36:56 --> Database Driver Class Initialized
INFO - 2023-04-24 09:36:56 --> Model "Login_model" initialized
INFO - 2023-04-24 09:36:56 --> Final output sent to browser
DEBUG - 2023-04-24 09:36:56 --> Total execution time: 0.1183
INFO - 2023-04-24 09:51:50 --> Config Class Initialized
INFO - 2023-04-24 09:51:50 --> Config Class Initialized
INFO - 2023-04-24 09:51:50 --> Hooks Class Initialized
INFO - 2023-04-24 09:51:50 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:51:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 09:51:50 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:51:50 --> Utf8 Class Initialized
INFO - 2023-04-24 09:51:50 --> Utf8 Class Initialized
INFO - 2023-04-24 09:51:50 --> URI Class Initialized
INFO - 2023-04-24 09:51:50 --> URI Class Initialized
INFO - 2023-04-24 09:51:50 --> Router Class Initialized
INFO - 2023-04-24 09:51:50 --> Router Class Initialized
INFO - 2023-04-24 09:51:50 --> Output Class Initialized
INFO - 2023-04-24 09:51:50 --> Output Class Initialized
INFO - 2023-04-24 09:51:50 --> Security Class Initialized
INFO - 2023-04-24 09:51:50 --> Security Class Initialized
DEBUG - 2023-04-24 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:51:50 --> Input Class Initialized
INFO - 2023-04-24 09:51:50 --> Language Class Initialized
DEBUG - 2023-04-24 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:51:50 --> Input Class Initialized
INFO - 2023-04-24 09:51:50 --> Language Class Initialized
INFO - 2023-04-24 09:51:50 --> Loader Class Initialized
INFO - 2023-04-24 09:51:50 --> Controller Class Initialized
DEBUG - 2023-04-24 09:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:51:50 --> Database Driver Class Initialized
INFO - 2023-04-24 09:51:50 --> Loader Class Initialized
INFO - 2023-04-24 09:51:50 --> Controller Class Initialized
DEBUG - 2023-04-24 09:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:51:50 --> Database Driver Class Initialized
INFO - 2023-04-24 09:51:50 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:51:50 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:51:50 --> Final output sent to browser
DEBUG - 2023-04-24 09:51:50 --> Total execution time: 0.0836
INFO - 2023-04-24 09:51:50 --> Database Driver Class Initialized
INFO - 2023-04-24 09:51:50 --> Config Class Initialized
INFO - 2023-04-24 09:51:50 --> Hooks Class Initialized
INFO - 2023-04-24 09:51:50 --> Model "Login_model" initialized
DEBUG - 2023-04-24 09:51:50 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:51:50 --> Utf8 Class Initialized
INFO - 2023-04-24 09:51:50 --> URI Class Initialized
INFO - 2023-04-24 09:51:50 --> Router Class Initialized
INFO - 2023-04-24 09:51:50 --> Output Class Initialized
INFO - 2023-04-24 09:51:50 --> Security Class Initialized
DEBUG - 2023-04-24 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:51:50 --> Input Class Initialized
INFO - 2023-04-24 09:51:50 --> Language Class Initialized
INFO - 2023-04-24 09:51:50 --> Loader Class Initialized
INFO - 2023-04-24 09:51:50 --> Controller Class Initialized
DEBUG - 2023-04-24 09:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:51:50 --> Database Driver Class Initialized
INFO - 2023-04-24 09:51:50 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:51:50 --> Final output sent to browser
DEBUG - 2023-04-24 09:51:50 --> Total execution time: 0.0218
INFO - 2023-04-24 09:51:50 --> Final output sent to browser
DEBUG - 2023-04-24 09:51:50 --> Total execution time: 0.2666
INFO - 2023-04-24 09:51:50 --> Config Class Initialized
INFO - 2023-04-24 09:51:50 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:51:50 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:51:50 --> Utf8 Class Initialized
INFO - 2023-04-24 09:51:50 --> URI Class Initialized
INFO - 2023-04-24 09:51:50 --> Router Class Initialized
INFO - 2023-04-24 09:51:50 --> Output Class Initialized
INFO - 2023-04-24 09:51:50 --> Security Class Initialized
DEBUG - 2023-04-24 09:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:51:50 --> Input Class Initialized
INFO - 2023-04-24 09:51:50 --> Language Class Initialized
INFO - 2023-04-24 09:51:50 --> Loader Class Initialized
INFO - 2023-04-24 09:51:50 --> Controller Class Initialized
DEBUG - 2023-04-24 09:51:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:51:50 --> Database Driver Class Initialized
INFO - 2023-04-24 09:51:50 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:51:50 --> Database Driver Class Initialized
INFO - 2023-04-24 09:51:50 --> Model "Login_model" initialized
INFO - 2023-04-24 09:51:50 --> Final output sent to browser
DEBUG - 2023-04-24 09:51:50 --> Total execution time: 0.0871
INFO - 2023-04-24 09:52:36 --> Config Class Initialized
INFO - 2023-04-24 09:52:36 --> Config Class Initialized
INFO - 2023-04-24 09:52:36 --> Hooks Class Initialized
INFO - 2023-04-24 09:52:36 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:52:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 09:52:36 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:52:36 --> Utf8 Class Initialized
INFO - 2023-04-24 09:52:36 --> Utf8 Class Initialized
INFO - 2023-04-24 09:52:36 --> URI Class Initialized
INFO - 2023-04-24 09:52:36 --> URI Class Initialized
INFO - 2023-04-24 09:52:36 --> Router Class Initialized
INFO - 2023-04-24 09:52:36 --> Router Class Initialized
INFO - 2023-04-24 09:52:36 --> Output Class Initialized
INFO - 2023-04-24 09:52:36 --> Output Class Initialized
INFO - 2023-04-24 09:52:36 --> Security Class Initialized
INFO - 2023-04-24 09:52:36 --> Security Class Initialized
DEBUG - 2023-04-24 09:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 09:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:52:36 --> Input Class Initialized
INFO - 2023-04-24 09:52:36 --> Input Class Initialized
INFO - 2023-04-24 09:52:36 --> Language Class Initialized
INFO - 2023-04-24 09:52:36 --> Language Class Initialized
INFO - 2023-04-24 09:52:36 --> Loader Class Initialized
INFO - 2023-04-24 09:52:36 --> Controller Class Initialized
DEBUG - 2023-04-24 09:52:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:52:36 --> Database Driver Class Initialized
INFO - 2023-04-24 09:52:36 --> Loader Class Initialized
INFO - 2023-04-24 09:52:36 --> Controller Class Initialized
DEBUG - 2023-04-24 09:52:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:52:36 --> Database Driver Class Initialized
INFO - 2023-04-24 09:52:36 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:52:36 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:52:36 --> Final output sent to browser
DEBUG - 2023-04-24 09:52:36 --> Total execution time: 0.1759
INFO - 2023-04-24 09:52:36 --> Database Driver Class Initialized
INFO - 2023-04-24 09:52:36 --> Config Class Initialized
INFO - 2023-04-24 09:52:36 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:52:36 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:52:36 --> Utf8 Class Initialized
INFO - 2023-04-24 09:52:36 --> URI Class Initialized
INFO - 2023-04-24 09:52:36 --> Router Class Initialized
INFO - 2023-04-24 09:52:36 --> Output Class Initialized
INFO - 2023-04-24 09:52:36 --> Security Class Initialized
DEBUG - 2023-04-24 09:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:52:36 --> Input Class Initialized
INFO - 2023-04-24 09:52:36 --> Language Class Initialized
INFO - 2023-04-24 09:52:36 --> Loader Class Initialized
INFO - 2023-04-24 09:52:36 --> Controller Class Initialized
DEBUG - 2023-04-24 09:52:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:52:36 --> Database Driver Class Initialized
INFO - 2023-04-24 09:52:36 --> Model "Login_model" initialized
INFO - 2023-04-24 09:52:36 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:52:36 --> Final output sent to browser
DEBUG - 2023-04-24 09:52:36 --> Total execution time: 0.0544
INFO - 2023-04-24 09:52:37 --> Final output sent to browser
DEBUG - 2023-04-24 09:52:37 --> Total execution time: 0.2876
INFO - 2023-04-24 09:52:37 --> Config Class Initialized
INFO - 2023-04-24 09:52:37 --> Hooks Class Initialized
DEBUG - 2023-04-24 09:52:37 --> UTF-8 Support Enabled
INFO - 2023-04-24 09:52:37 --> Utf8 Class Initialized
INFO - 2023-04-24 09:52:37 --> URI Class Initialized
INFO - 2023-04-24 09:52:37 --> Router Class Initialized
INFO - 2023-04-24 09:52:37 --> Output Class Initialized
INFO - 2023-04-24 09:52:37 --> Security Class Initialized
DEBUG - 2023-04-24 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 09:52:37 --> Input Class Initialized
INFO - 2023-04-24 09:52:37 --> Language Class Initialized
INFO - 2023-04-24 09:52:37 --> Loader Class Initialized
INFO - 2023-04-24 09:52:37 --> Controller Class Initialized
DEBUG - 2023-04-24 09:52:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 09:52:37 --> Database Driver Class Initialized
INFO - 2023-04-24 09:52:37 --> Model "Cluster_model" initialized
INFO - 2023-04-24 09:52:37 --> Database Driver Class Initialized
INFO - 2023-04-24 09:52:37 --> Model "Login_model" initialized
INFO - 2023-04-24 09:52:37 --> Final output sent to browser
DEBUG - 2023-04-24 09:52:37 --> Total execution time: 0.1084
INFO - 2023-04-24 10:02:46 --> Config Class Initialized
INFO - 2023-04-24 10:02:46 --> Hooks Class Initialized
INFO - 2023-04-24 10:02:46 --> Config Class Initialized
INFO - 2023-04-24 10:02:46 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:02:46 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:02:46 --> Utf8 Class Initialized
DEBUG - 2023-04-24 10:02:46 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:02:46 --> Utf8 Class Initialized
INFO - 2023-04-24 10:02:46 --> URI Class Initialized
INFO - 2023-04-24 10:02:46 --> URI Class Initialized
INFO - 2023-04-24 10:02:46 --> Router Class Initialized
INFO - 2023-04-24 10:02:46 --> Router Class Initialized
INFO - 2023-04-24 10:02:46 --> Output Class Initialized
INFO - 2023-04-24 10:02:46 --> Output Class Initialized
INFO - 2023-04-24 10:02:46 --> Security Class Initialized
INFO - 2023-04-24 10:02:46 --> Security Class Initialized
DEBUG - 2023-04-24 10:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:02:46 --> Input Class Initialized
INFO - 2023-04-24 10:02:46 --> Input Class Initialized
INFO - 2023-04-24 10:02:46 --> Language Class Initialized
INFO - 2023-04-24 10:02:46 --> Language Class Initialized
INFO - 2023-04-24 10:02:47 --> Loader Class Initialized
INFO - 2023-04-24 10:02:47 --> Controller Class Initialized
DEBUG - 2023-04-24 10:02:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:02:48 --> Database Driver Class Initialized
INFO - 2023-04-24 10:02:49 --> Loader Class Initialized
INFO - 2023-04-24 10:02:49 --> Controller Class Initialized
DEBUG - 2023-04-24 10:02:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:02:49 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:02:49 --> Database Driver Class Initialized
INFO - 2023-04-24 10:02:50 --> Database Driver Class Initialized
INFO - 2023-04-24 10:02:51 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:02:51 --> Model "Login_model" initialized
INFO - 2023-04-24 10:02:51 --> Final output sent to browser
DEBUG - 2023-04-24 10:02:51 --> Total execution time: 5.5031
INFO - 2023-04-24 10:02:51 --> Final output sent to browser
DEBUG - 2023-04-24 10:02:51 --> Total execution time: 5.5891
INFO - 2023-04-24 10:02:55 --> Config Class Initialized
INFO - 2023-04-24 10:02:55 --> Config Class Initialized
INFO - 2023-04-24 10:02:55 --> Hooks Class Initialized
INFO - 2023-04-24 10:02:55 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:02:56 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:02:56 --> Utf8 Class Initialized
DEBUG - 2023-04-24 10:02:56 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:02:56 --> Utf8 Class Initialized
INFO - 2023-04-24 10:02:56 --> URI Class Initialized
INFO - 2023-04-24 10:02:56 --> URI Class Initialized
INFO - 2023-04-24 10:02:56 --> Router Class Initialized
INFO - 2023-04-24 10:02:56 --> Router Class Initialized
INFO - 2023-04-24 10:02:56 --> Output Class Initialized
INFO - 2023-04-24 10:02:56 --> Output Class Initialized
INFO - 2023-04-24 10:02:56 --> Security Class Initialized
INFO - 2023-04-24 10:02:56 --> Security Class Initialized
DEBUG - 2023-04-24 10:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:02:56 --> Input Class Initialized
DEBUG - 2023-04-24 10:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:02:56 --> Input Class Initialized
INFO - 2023-04-24 10:02:56 --> Language Class Initialized
INFO - 2023-04-24 10:02:56 --> Language Class Initialized
INFO - 2023-04-24 10:02:56 --> Loader Class Initialized
INFO - 2023-04-24 10:02:56 --> Loader Class Initialized
INFO - 2023-04-24 10:02:56 --> Controller Class Initialized
INFO - 2023-04-24 10:02:56 --> Controller Class Initialized
DEBUG - 2023-04-24 10:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 10:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:02:57 --> Database Driver Class Initialized
INFO - 2023-04-24 10:02:57 --> Database Driver Class Initialized
INFO - 2023-04-24 10:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:02:58 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:02:59 --> Final output sent to browser
DEBUG - 2023-04-24 10:02:59 --> Total execution time: 3.8573
INFO - 2023-04-24 10:02:59 --> Database Driver Class Initialized
INFO - 2023-04-24 10:02:59 --> Model "Login_model" initialized
INFO - 2023-04-24 10:03:00 --> Final output sent to browser
DEBUG - 2023-04-24 10:03:00 --> Total execution time: 4.6172
INFO - 2023-04-24 10:03:02 --> Config Class Initialized
INFO - 2023-04-24 10:03:02 --> Hooks Class Initialized
INFO - 2023-04-24 10:03:02 --> Config Class Initialized
INFO - 2023-04-24 10:03:02 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:03:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 10:03:03 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:03:03 --> Utf8 Class Initialized
INFO - 2023-04-24 10:03:03 --> Utf8 Class Initialized
INFO - 2023-04-24 10:03:03 --> URI Class Initialized
INFO - 2023-04-24 10:03:03 --> URI Class Initialized
INFO - 2023-04-24 10:03:03 --> Router Class Initialized
INFO - 2023-04-24 10:03:03 --> Output Class Initialized
INFO - 2023-04-24 10:03:03 --> Router Class Initialized
INFO - 2023-04-24 10:03:03 --> Output Class Initialized
INFO - 2023-04-24 10:03:03 --> Security Class Initialized
INFO - 2023-04-24 10:03:03 --> Security Class Initialized
DEBUG - 2023-04-24 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:03:03 --> Input Class Initialized
DEBUG - 2023-04-24 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:03:03 --> Language Class Initialized
INFO - 2023-04-24 10:03:03 --> Input Class Initialized
INFO - 2023-04-24 10:03:03 --> Language Class Initialized
INFO - 2023-04-24 10:03:03 --> Loader Class Initialized
INFO - 2023-04-24 10:03:03 --> Loader Class Initialized
INFO - 2023-04-24 10:03:03 --> Controller Class Initialized
INFO - 2023-04-24 10:03:03 --> Controller Class Initialized
DEBUG - 2023-04-24 10:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 10:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:03:04 --> Database Driver Class Initialized
INFO - 2023-04-24 10:03:04 --> Database Driver Class Initialized
INFO - 2023-04-24 10:03:04 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:03:04 --> Database Driver Class Initialized
INFO - 2023-04-24 10:03:04 --> Model "Login_model" initialized
INFO - 2023-04-24 10:03:04 --> Final output sent to browser
DEBUG - 2023-04-24 10:03:04 --> Total execution time: 2.1163
INFO - 2023-04-24 10:03:05 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:03:05 --> Final output sent to browser
DEBUG - 2023-04-24 10:03:05 --> Total execution time: 2.2925
INFO - 2023-04-24 10:05:58 --> Config Class Initialized
INFO - 2023-04-24 10:05:58 --> Config Class Initialized
INFO - 2023-04-24 10:05:58 --> Hooks Class Initialized
INFO - 2023-04-24 10:05:58 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:05:58 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:05:58 --> Utf8 Class Initialized
DEBUG - 2023-04-24 10:05:58 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:05:58 --> Utf8 Class Initialized
INFO - 2023-04-24 10:05:58 --> URI Class Initialized
INFO - 2023-04-24 10:05:58 --> URI Class Initialized
INFO - 2023-04-24 10:05:58 --> Router Class Initialized
INFO - 2023-04-24 10:05:58 --> Router Class Initialized
INFO - 2023-04-24 10:05:58 --> Output Class Initialized
INFO - 2023-04-24 10:05:58 --> Output Class Initialized
INFO - 2023-04-24 10:05:58 --> Security Class Initialized
INFO - 2023-04-24 10:05:58 --> Security Class Initialized
DEBUG - 2023-04-24 10:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:05:59 --> Input Class Initialized
DEBUG - 2023-04-24 10:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:05:59 --> Input Class Initialized
INFO - 2023-04-24 10:05:59 --> Language Class Initialized
INFO - 2023-04-24 10:05:59 --> Language Class Initialized
INFO - 2023-04-24 10:05:59 --> Loader Class Initialized
INFO - 2023-04-24 10:05:59 --> Controller Class Initialized
DEBUG - 2023-04-24 10:05:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:06:00 --> Database Driver Class Initialized
INFO - 2023-04-24 10:06:01 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:06:01 --> Loader Class Initialized
INFO - 2023-04-24 10:06:01 --> Controller Class Initialized
DEBUG - 2023-04-24 10:06:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:06:01 --> Database Driver Class Initialized
INFO - 2023-04-24 10:06:02 --> Database Driver Class Initialized
INFO - 2023-04-24 10:06:02 --> Model "Login_model" initialized
INFO - 2023-04-24 10:06:02 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:06:02 --> Final output sent to browser
DEBUG - 2023-04-24 10:06:02 --> Total execution time: 4.2473
INFO - 2023-04-24 10:06:02 --> Final output sent to browser
DEBUG - 2023-04-24 10:06:02 --> Total execution time: 4.2371
INFO - 2023-04-24 10:06:02 --> Config Class Initialized
INFO - 2023-04-24 10:06:02 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:06:02 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:06:02 --> Utf8 Class Initialized
INFO - 2023-04-24 10:06:02 --> URI Class Initialized
INFO - 2023-04-24 10:06:02 --> Router Class Initialized
INFO - 2023-04-24 10:06:02 --> Output Class Initialized
INFO - 2023-04-24 10:06:02 --> Security Class Initialized
DEBUG - 2023-04-24 10:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:06:02 --> Input Class Initialized
INFO - 2023-04-24 10:06:02 --> Language Class Initialized
INFO - 2023-04-24 10:06:02 --> Loader Class Initialized
INFO - 2023-04-24 10:06:02 --> Controller Class Initialized
DEBUG - 2023-04-24 10:06:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:06:02 --> Database Driver Class Initialized
INFO - 2023-04-24 10:06:03 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:06:03 --> Database Driver Class Initialized
INFO - 2023-04-24 10:06:03 --> Model "Login_model" initialized
INFO - 2023-04-24 10:06:03 --> Final output sent to browser
DEBUG - 2023-04-24 10:06:03 --> Total execution time: 0.2579
INFO - 2023-04-24 10:06:04 --> Config Class Initialized
INFO - 2023-04-24 10:06:04 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:06:04 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:06:04 --> Utf8 Class Initialized
INFO - 2023-04-24 10:06:04 --> URI Class Initialized
INFO - 2023-04-24 10:06:04 --> Router Class Initialized
INFO - 2023-04-24 10:06:04 --> Output Class Initialized
INFO - 2023-04-24 10:06:04 --> Security Class Initialized
DEBUG - 2023-04-24 10:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:06:04 --> Input Class Initialized
INFO - 2023-04-24 10:06:04 --> Language Class Initialized
INFO - 2023-04-24 10:06:04 --> Loader Class Initialized
INFO - 2023-04-24 10:06:04 --> Controller Class Initialized
DEBUG - 2023-04-24 10:06:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:06:04 --> Database Driver Class Initialized
INFO - 2023-04-24 10:06:05 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:06:05 --> Final output sent to browser
DEBUG - 2023-04-24 10:06:05 --> Total execution time: 1.1704
INFO - 2023-04-24 10:07:30 --> Config Class Initialized
INFO - 2023-04-24 10:07:30 --> Config Class Initialized
INFO - 2023-04-24 10:07:30 --> Hooks Class Initialized
INFO - 2023-04-24 10:07:30 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:07:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 10:07:30 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:07:30 --> Utf8 Class Initialized
INFO - 2023-04-24 10:07:30 --> Utf8 Class Initialized
INFO - 2023-04-24 10:07:30 --> URI Class Initialized
INFO - 2023-04-24 10:07:30 --> URI Class Initialized
INFO - 2023-04-24 10:07:30 --> Router Class Initialized
INFO - 2023-04-24 10:07:30 --> Router Class Initialized
INFO - 2023-04-24 10:07:30 --> Output Class Initialized
INFO - 2023-04-24 10:07:30 --> Output Class Initialized
INFO - 2023-04-24 10:07:30 --> Security Class Initialized
INFO - 2023-04-24 10:07:30 --> Security Class Initialized
DEBUG - 2023-04-24 10:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:07:30 --> Input Class Initialized
INFO - 2023-04-24 10:07:30 --> Language Class Initialized
DEBUG - 2023-04-24 10:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:07:30 --> Input Class Initialized
INFO - 2023-04-24 10:07:30 --> Language Class Initialized
INFO - 2023-04-24 10:07:31 --> Loader Class Initialized
INFO - 2023-04-24 10:07:31 --> Loader Class Initialized
INFO - 2023-04-24 10:07:31 --> Controller Class Initialized
INFO - 2023-04-24 10:07:31 --> Controller Class Initialized
DEBUG - 2023-04-24 10:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 10:07:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:07:31 --> Database Driver Class Initialized
INFO - 2023-04-24 10:07:31 --> Database Driver Class Initialized
INFO - 2023-04-24 10:07:32 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:07:32 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:07:33 --> Final output sent to browser
DEBUG - 2023-04-24 10:07:33 --> Total execution time: 3.0963
INFO - 2023-04-24 10:07:33 --> Database Driver Class Initialized
INFO - 2023-04-24 10:07:33 --> Model "Login_model" initialized
INFO - 2023-04-24 10:07:33 --> Final output sent to browser
DEBUG - 2023-04-24 10:07:33 --> Total execution time: 3.8344
INFO - 2023-04-24 10:07:33 --> Config Class Initialized
INFO - 2023-04-24 10:07:33 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:07:33 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:07:33 --> Utf8 Class Initialized
INFO - 2023-04-24 10:07:33 --> URI Class Initialized
INFO - 2023-04-24 10:07:33 --> Router Class Initialized
INFO - 2023-04-24 10:07:33 --> Output Class Initialized
INFO - 2023-04-24 10:07:33 --> Security Class Initialized
DEBUG - 2023-04-24 10:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:07:33 --> Input Class Initialized
INFO - 2023-04-24 10:07:33 --> Language Class Initialized
INFO - 2023-04-24 10:07:33 --> Loader Class Initialized
INFO - 2023-04-24 10:07:33 --> Controller Class Initialized
DEBUG - 2023-04-24 10:07:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:07:34 --> Database Driver Class Initialized
INFO - 2023-04-24 10:07:34 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:07:34 --> Database Driver Class Initialized
INFO - 2023-04-24 10:07:34 --> Model "Login_model" initialized
INFO - 2023-04-24 10:07:34 --> Config Class Initialized
INFO - 2023-04-24 10:07:34 --> Final output sent to browser
DEBUG - 2023-04-24 10:07:34 --> Total execution time: 0.6575
INFO - 2023-04-24 10:07:34 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:07:34 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:07:34 --> Utf8 Class Initialized
INFO - 2023-04-24 10:07:34 --> URI Class Initialized
INFO - 2023-04-24 10:07:34 --> Router Class Initialized
INFO - 2023-04-24 10:07:34 --> Output Class Initialized
INFO - 2023-04-24 10:07:34 --> Security Class Initialized
DEBUG - 2023-04-24 10:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:07:34 --> Input Class Initialized
INFO - 2023-04-24 10:07:34 --> Language Class Initialized
INFO - 2023-04-24 10:07:34 --> Loader Class Initialized
INFO - 2023-04-24 10:07:34 --> Controller Class Initialized
DEBUG - 2023-04-24 10:07:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:07:35 --> Database Driver Class Initialized
INFO - 2023-04-24 10:07:36 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:07:36 --> Final output sent to browser
DEBUG - 2023-04-24 10:07:36 --> Total execution time: 1.6388
INFO - 2023-04-24 10:08:22 --> Config Class Initialized
INFO - 2023-04-24 10:08:22 --> Config Class Initialized
INFO - 2023-04-24 10:08:22 --> Hooks Class Initialized
INFO - 2023-04-24 10:08:22 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:08:22 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:08:22 --> Utf8 Class Initialized
DEBUG - 2023-04-24 10:08:22 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:08:22 --> Utf8 Class Initialized
INFO - 2023-04-24 10:08:22 --> URI Class Initialized
INFO - 2023-04-24 10:08:22 --> URI Class Initialized
INFO - 2023-04-24 10:08:22 --> Router Class Initialized
INFO - 2023-04-24 10:08:22 --> Router Class Initialized
INFO - 2023-04-24 10:08:22 --> Output Class Initialized
INFO - 2023-04-24 10:08:22 --> Output Class Initialized
INFO - 2023-04-24 10:08:22 --> Security Class Initialized
INFO - 2023-04-24 10:08:22 --> Security Class Initialized
DEBUG - 2023-04-24 10:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 10:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:08:22 --> Input Class Initialized
INFO - 2023-04-24 10:08:22 --> Input Class Initialized
INFO - 2023-04-24 10:08:22 --> Language Class Initialized
INFO - 2023-04-24 10:08:22 --> Language Class Initialized
INFO - 2023-04-24 10:08:23 --> Loader Class Initialized
INFO - 2023-04-24 10:08:23 --> Controller Class Initialized
DEBUG - 2023-04-24 10:08:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:08:24 --> Database Driver Class Initialized
INFO - 2023-04-24 10:08:25 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:08:25 --> Loader Class Initialized
INFO - 2023-04-24 10:08:25 --> Controller Class Initialized
DEBUG - 2023-04-24 10:08:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:08:25 --> Database Driver Class Initialized
INFO - 2023-04-24 10:08:26 --> Database Driver Class Initialized
INFO - 2023-04-24 10:08:26 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:08:26 --> Model "Login_model" initialized
INFO - 2023-04-24 10:08:26 --> Final output sent to browser
DEBUG - 2023-04-24 10:08:26 --> Total execution time: 4.2267
INFO - 2023-04-24 10:08:26 --> Final output sent to browser
DEBUG - 2023-04-24 10:08:26 --> Total execution time: 4.3735
INFO - 2023-04-24 10:08:26 --> Config Class Initialized
INFO - 2023-04-24 10:08:26 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:08:26 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:08:26 --> Utf8 Class Initialized
INFO - 2023-04-24 10:08:26 --> URI Class Initialized
INFO - 2023-04-24 10:08:26 --> Router Class Initialized
INFO - 2023-04-24 10:08:26 --> Output Class Initialized
INFO - 2023-04-24 10:08:26 --> Security Class Initialized
DEBUG - 2023-04-24 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:08:27 --> Input Class Initialized
INFO - 2023-04-24 10:08:27 --> Language Class Initialized
INFO - 2023-04-24 10:08:27 --> Loader Class Initialized
INFO - 2023-04-24 10:08:27 --> Controller Class Initialized
DEBUG - 2023-04-24 10:08:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:08:27 --> Database Driver Class Initialized
INFO - 2023-04-24 10:08:27 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:08:27 --> Database Driver Class Initialized
INFO - 2023-04-24 10:08:27 --> Model "Login_model" initialized
INFO - 2023-04-24 10:08:27 --> Final output sent to browser
DEBUG - 2023-04-24 10:08:27 --> Total execution time: 0.2836
INFO - 2023-04-24 10:08:28 --> Config Class Initialized
INFO - 2023-04-24 10:08:28 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:08:28 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:08:28 --> Utf8 Class Initialized
INFO - 2023-04-24 10:08:28 --> URI Class Initialized
INFO - 2023-04-24 10:08:28 --> Router Class Initialized
INFO - 2023-04-24 10:08:28 --> Output Class Initialized
INFO - 2023-04-24 10:08:28 --> Security Class Initialized
DEBUG - 2023-04-24 10:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:08:28 --> Input Class Initialized
INFO - 2023-04-24 10:08:28 --> Language Class Initialized
INFO - 2023-04-24 10:08:28 --> Loader Class Initialized
INFO - 2023-04-24 10:08:28 --> Controller Class Initialized
DEBUG - 2023-04-24 10:08:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:08:28 --> Database Driver Class Initialized
INFO - 2023-04-24 10:08:29 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:08:29 --> Final output sent to browser
DEBUG - 2023-04-24 10:08:29 --> Total execution time: 1.2002
INFO - 2023-04-24 10:17:16 --> Config Class Initialized
INFO - 2023-04-24 10:17:16 --> Config Class Initialized
INFO - 2023-04-24 10:17:16 --> Hooks Class Initialized
INFO - 2023-04-24 10:17:16 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:17:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 10:17:16 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:17:16 --> Utf8 Class Initialized
INFO - 2023-04-24 10:17:16 --> Utf8 Class Initialized
INFO - 2023-04-24 10:17:16 --> URI Class Initialized
INFO - 2023-04-24 10:17:16 --> URI Class Initialized
INFO - 2023-04-24 10:17:16 --> Router Class Initialized
INFO - 2023-04-24 10:17:16 --> Router Class Initialized
INFO - 2023-04-24 10:17:16 --> Output Class Initialized
INFO - 2023-04-24 10:17:16 --> Output Class Initialized
INFO - 2023-04-24 10:17:16 --> Security Class Initialized
DEBUG - 2023-04-24 10:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:17:16 --> Input Class Initialized
INFO - 2023-04-24 10:17:16 --> Security Class Initialized
INFO - 2023-04-24 10:17:16 --> Language Class Initialized
DEBUG - 2023-04-24 10:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:17:16 --> Input Class Initialized
INFO - 2023-04-24 10:17:16 --> Language Class Initialized
INFO - 2023-04-24 10:17:16 --> Loader Class Initialized
INFO - 2023-04-24 10:17:16 --> Controller Class Initialized
DEBUG - 2023-04-24 10:17:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:17:16 --> Database Driver Class Initialized
INFO - 2023-04-24 10:17:16 --> Loader Class Initialized
INFO - 2023-04-24 10:17:16 --> Controller Class Initialized
DEBUG - 2023-04-24 10:17:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:17:16 --> Database Driver Class Initialized
INFO - 2023-04-24 10:17:16 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:17:16 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:17:16 --> Final output sent to browser
DEBUG - 2023-04-24 10:17:16 --> Total execution time: 0.1172
INFO - 2023-04-24 10:17:16 --> Database Driver Class Initialized
INFO - 2023-04-24 10:17:16 --> Config Class Initialized
INFO - 2023-04-24 10:17:16 --> Model "Login_model" initialized
INFO - 2023-04-24 10:17:17 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:17:17 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:17:17 --> Utf8 Class Initialized
INFO - 2023-04-24 10:17:17 --> URI Class Initialized
INFO - 2023-04-24 10:17:17 --> Router Class Initialized
INFO - 2023-04-24 10:17:17 --> Output Class Initialized
INFO - 2023-04-24 10:17:17 --> Security Class Initialized
DEBUG - 2023-04-24 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:17:17 --> Input Class Initialized
INFO - 2023-04-24 10:17:17 --> Language Class Initialized
INFO - 2023-04-24 10:17:17 --> Loader Class Initialized
INFO - 2023-04-24 10:17:17 --> Controller Class Initialized
DEBUG - 2023-04-24 10:17:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:17:17 --> Database Driver Class Initialized
INFO - 2023-04-24 10:17:17 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:17:17 --> Final output sent to browser
DEBUG - 2023-04-24 10:17:17 --> Total execution time: 0.0671
INFO - 2023-04-24 10:17:17 --> Final output sent to browser
DEBUG - 2023-04-24 10:17:17 --> Total execution time: 0.2099
INFO - 2023-04-24 10:17:17 --> Config Class Initialized
INFO - 2023-04-24 10:17:17 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:17:17 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:17:17 --> Utf8 Class Initialized
INFO - 2023-04-24 10:17:17 --> URI Class Initialized
INFO - 2023-04-24 10:17:17 --> Router Class Initialized
INFO - 2023-04-24 10:17:17 --> Output Class Initialized
INFO - 2023-04-24 10:17:17 --> Security Class Initialized
DEBUG - 2023-04-24 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:17:17 --> Input Class Initialized
INFO - 2023-04-24 10:17:17 --> Language Class Initialized
INFO - 2023-04-24 10:17:17 --> Loader Class Initialized
INFO - 2023-04-24 10:17:17 --> Controller Class Initialized
DEBUG - 2023-04-24 10:17:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:17:17 --> Database Driver Class Initialized
INFO - 2023-04-24 10:17:17 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:17:17 --> Database Driver Class Initialized
INFO - 2023-04-24 10:17:17 --> Model "Login_model" initialized
INFO - 2023-04-24 10:17:17 --> Final output sent to browser
DEBUG - 2023-04-24 10:17:17 --> Total execution time: 0.1212
INFO - 2023-04-24 10:18:49 --> Config Class Initialized
INFO - 2023-04-24 10:18:49 --> Config Class Initialized
INFO - 2023-04-24 10:18:49 --> Hooks Class Initialized
INFO - 2023-04-24 10:18:49 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 10:18:49 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:18:49 --> Utf8 Class Initialized
INFO - 2023-04-24 10:18:49 --> Utf8 Class Initialized
INFO - 2023-04-24 10:18:49 --> URI Class Initialized
INFO - 2023-04-24 10:18:49 --> URI Class Initialized
INFO - 2023-04-24 10:18:49 --> Router Class Initialized
INFO - 2023-04-24 10:18:49 --> Router Class Initialized
INFO - 2023-04-24 10:18:49 --> Output Class Initialized
INFO - 2023-04-24 10:18:49 --> Output Class Initialized
INFO - 2023-04-24 10:18:49 --> Security Class Initialized
INFO - 2023-04-24 10:18:49 --> Security Class Initialized
DEBUG - 2023-04-24 10:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 10:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:18:49 --> Input Class Initialized
INFO - 2023-04-24 10:18:49 --> Input Class Initialized
INFO - 2023-04-24 10:18:49 --> Language Class Initialized
INFO - 2023-04-24 10:18:49 --> Language Class Initialized
INFO - 2023-04-24 10:18:49 --> Loader Class Initialized
INFO - 2023-04-24 10:18:49 --> Controller Class Initialized
DEBUG - 2023-04-24 10:18:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:18:49 --> Database Driver Class Initialized
INFO - 2023-04-24 10:18:49 --> Loader Class Initialized
INFO - 2023-04-24 10:18:49 --> Controller Class Initialized
DEBUG - 2023-04-24 10:18:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:18:49 --> Database Driver Class Initialized
INFO - 2023-04-24 10:18:49 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:18:49 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:18:49 --> Final output sent to browser
DEBUG - 2023-04-24 10:18:49 --> Total execution time: 0.0617
INFO - 2023-04-24 10:18:49 --> Database Driver Class Initialized
INFO - 2023-04-24 10:18:49 --> Config Class Initialized
INFO - 2023-04-24 10:18:49 --> Model "Login_model" initialized
INFO - 2023-04-24 10:18:49 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:18:49 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:18:49 --> Utf8 Class Initialized
INFO - 2023-04-24 10:18:49 --> URI Class Initialized
INFO - 2023-04-24 10:18:49 --> Router Class Initialized
INFO - 2023-04-24 10:18:49 --> Output Class Initialized
INFO - 2023-04-24 10:18:49 --> Security Class Initialized
DEBUG - 2023-04-24 10:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:18:49 --> Input Class Initialized
INFO - 2023-04-24 10:18:49 --> Language Class Initialized
INFO - 2023-04-24 10:18:49 --> Loader Class Initialized
INFO - 2023-04-24 10:18:49 --> Controller Class Initialized
DEBUG - 2023-04-24 10:18:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:18:49 --> Database Driver Class Initialized
INFO - 2023-04-24 10:18:49 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:18:49 --> Final output sent to browser
DEBUG - 2023-04-24 10:18:49 --> Total execution time: 0.0764
INFO - 2023-04-24 10:18:49 --> Final output sent to browser
DEBUG - 2023-04-24 10:18:49 --> Total execution time: 0.2753
INFO - 2023-04-24 10:18:49 --> Config Class Initialized
INFO - 2023-04-24 10:18:49 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:18:49 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:18:49 --> Utf8 Class Initialized
INFO - 2023-04-24 10:18:49 --> URI Class Initialized
INFO - 2023-04-24 10:18:49 --> Router Class Initialized
INFO - 2023-04-24 10:18:49 --> Output Class Initialized
INFO - 2023-04-24 10:18:49 --> Security Class Initialized
DEBUG - 2023-04-24 10:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:18:49 --> Input Class Initialized
INFO - 2023-04-24 10:18:49 --> Language Class Initialized
INFO - 2023-04-24 10:18:49 --> Loader Class Initialized
INFO - 2023-04-24 10:18:49 --> Controller Class Initialized
DEBUG - 2023-04-24 10:18:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:18:49 --> Database Driver Class Initialized
INFO - 2023-04-24 10:18:49 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:18:49 --> Database Driver Class Initialized
INFO - 2023-04-24 10:18:49 --> Model "Login_model" initialized
INFO - 2023-04-24 10:18:49 --> Final output sent to browser
DEBUG - 2023-04-24 10:18:49 --> Total execution time: 0.3488
INFO - 2023-04-24 10:20:16 --> Config Class Initialized
INFO - 2023-04-24 10:20:16 --> Config Class Initialized
INFO - 2023-04-24 10:20:16 --> Hooks Class Initialized
INFO - 2023-04-24 10:20:16 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:20:16 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 10:20:16 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:20:16 --> Utf8 Class Initialized
INFO - 2023-04-24 10:20:16 --> Utf8 Class Initialized
INFO - 2023-04-24 10:20:16 --> URI Class Initialized
INFO - 2023-04-24 10:20:16 --> URI Class Initialized
INFO - 2023-04-24 10:20:16 --> Router Class Initialized
INFO - 2023-04-24 10:20:16 --> Output Class Initialized
INFO - 2023-04-24 10:20:16 --> Router Class Initialized
INFO - 2023-04-24 10:20:16 --> Security Class Initialized
INFO - 2023-04-24 10:20:16 --> Output Class Initialized
INFO - 2023-04-24 10:20:16 --> Security Class Initialized
DEBUG - 2023-04-24 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:20:16 --> Input Class Initialized
DEBUG - 2023-04-24 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:20:16 --> Language Class Initialized
INFO - 2023-04-24 10:20:16 --> Input Class Initialized
INFO - 2023-04-24 10:20:16 --> Language Class Initialized
INFO - 2023-04-24 10:20:16 --> Loader Class Initialized
INFO - 2023-04-24 10:20:16 --> Loader Class Initialized
INFO - 2023-04-24 10:20:16 --> Controller Class Initialized
INFO - 2023-04-24 10:20:16 --> Controller Class Initialized
DEBUG - 2023-04-24 10:20:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 10:20:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:20:16 --> Database Driver Class Initialized
INFO - 2023-04-24 10:20:16 --> Database Driver Class Initialized
INFO - 2023-04-24 10:20:16 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:20:16 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:20:16 --> Final output sent to browser
DEBUG - 2023-04-24 10:20:16 --> Total execution time: 0.1267
INFO - 2023-04-24 10:20:16 --> Database Driver Class Initialized
INFO - 2023-04-24 10:20:16 --> Config Class Initialized
INFO - 2023-04-24 10:20:16 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:20:16 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:20:16 --> Utf8 Class Initialized
INFO - 2023-04-24 10:20:16 --> URI Class Initialized
INFO - 2023-04-24 10:20:16 --> Router Class Initialized
INFO - 2023-04-24 10:20:16 --> Output Class Initialized
INFO - 2023-04-24 10:20:16 --> Security Class Initialized
DEBUG - 2023-04-24 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:20:16 --> Input Class Initialized
INFO - 2023-04-24 10:20:16 --> Language Class Initialized
INFO - 2023-04-24 10:20:16 --> Loader Class Initialized
INFO - 2023-04-24 10:20:16 --> Controller Class Initialized
DEBUG - 2023-04-24 10:20:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:20:16 --> Database Driver Class Initialized
INFO - 2023-04-24 10:20:16 --> Model "Login_model" initialized
INFO - 2023-04-24 10:20:16 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:20:16 --> Final output sent to browser
DEBUG - 2023-04-24 10:20:16 --> Total execution time: 0.0528
INFO - 2023-04-24 10:20:17 --> Final output sent to browser
DEBUG - 2023-04-24 10:20:17 --> Total execution time: 0.2175
INFO - 2023-04-24 10:20:17 --> Config Class Initialized
INFO - 2023-04-24 10:20:17 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:20:17 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:20:17 --> Utf8 Class Initialized
INFO - 2023-04-24 10:20:17 --> URI Class Initialized
INFO - 2023-04-24 10:20:17 --> Router Class Initialized
INFO - 2023-04-24 10:20:17 --> Output Class Initialized
INFO - 2023-04-24 10:20:17 --> Security Class Initialized
DEBUG - 2023-04-24 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:20:17 --> Input Class Initialized
INFO - 2023-04-24 10:20:17 --> Language Class Initialized
INFO - 2023-04-24 10:20:17 --> Loader Class Initialized
INFO - 2023-04-24 10:20:17 --> Controller Class Initialized
DEBUG - 2023-04-24 10:20:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:20:17 --> Database Driver Class Initialized
INFO - 2023-04-24 10:20:17 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:20:17 --> Database Driver Class Initialized
INFO - 2023-04-24 10:20:17 --> Model "Login_model" initialized
INFO - 2023-04-24 10:20:17 --> Final output sent to browser
DEBUG - 2023-04-24 10:20:17 --> Total execution time: 0.1379
INFO - 2023-04-24 10:21:32 --> Config Class Initialized
INFO - 2023-04-24 10:21:32 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:32 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:32 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:32 --> URI Class Initialized
INFO - 2023-04-24 10:21:32 --> Router Class Initialized
INFO - 2023-04-24 10:21:32 --> Output Class Initialized
INFO - 2023-04-24 10:21:32 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:32 --> Input Class Initialized
INFO - 2023-04-24 10:21:32 --> Language Class Initialized
INFO - 2023-04-24 10:21:32 --> Loader Class Initialized
INFO - 2023-04-24 10:21:32 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:32 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:32 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:32 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:32 --> Total execution time: 0.1011
INFO - 2023-04-24 10:21:32 --> Config Class Initialized
INFO - 2023-04-24 10:21:32 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:32 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:32 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:32 --> URI Class Initialized
INFO - 2023-04-24 10:21:32 --> Router Class Initialized
INFO - 2023-04-24 10:21:32 --> Output Class Initialized
INFO - 2023-04-24 10:21:32 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:32 --> Input Class Initialized
INFO - 2023-04-24 10:21:32 --> Language Class Initialized
INFO - 2023-04-24 10:21:32 --> Loader Class Initialized
INFO - 2023-04-24 10:21:32 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:32 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:32 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:32 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:32 --> Total execution time: 0.0542
INFO - 2023-04-24 10:21:35 --> Config Class Initialized
INFO - 2023-04-24 10:21:35 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:35 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:35 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:35 --> URI Class Initialized
INFO - 2023-04-24 10:21:35 --> Router Class Initialized
INFO - 2023-04-24 10:21:35 --> Output Class Initialized
INFO - 2023-04-24 10:21:35 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:35 --> Input Class Initialized
INFO - 2023-04-24 10:21:35 --> Language Class Initialized
INFO - 2023-04-24 10:21:35 --> Loader Class Initialized
INFO - 2023-04-24 10:21:35 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:35 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:35 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:35 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:35 --> Total execution time: 0.0645
INFO - 2023-04-24 10:21:35 --> Config Class Initialized
INFO - 2023-04-24 10:21:35 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:35 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:35 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:35 --> URI Class Initialized
INFO - 2023-04-24 10:21:35 --> Router Class Initialized
INFO - 2023-04-24 10:21:35 --> Output Class Initialized
INFO - 2023-04-24 10:21:35 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:35 --> Input Class Initialized
INFO - 2023-04-24 10:21:35 --> Language Class Initialized
INFO - 2023-04-24 10:21:35 --> Loader Class Initialized
INFO - 2023-04-24 10:21:35 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:35 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:35 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:35 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:35 --> Total execution time: 0.0576
INFO - 2023-04-24 10:21:38 --> Config Class Initialized
INFO - 2023-04-24 10:21:38 --> Config Class Initialized
INFO - 2023-04-24 10:21:38 --> Hooks Class Initialized
INFO - 2023-04-24 10:21:38 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:38 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:38 --> Utf8 Class Initialized
DEBUG - 2023-04-24 10:21:38 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:38 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:38 --> URI Class Initialized
INFO - 2023-04-24 10:21:38 --> URI Class Initialized
INFO - 2023-04-24 10:21:38 --> Router Class Initialized
INFO - 2023-04-24 10:21:38 --> Router Class Initialized
INFO - 2023-04-24 10:21:38 --> Output Class Initialized
INFO - 2023-04-24 10:21:38 --> Output Class Initialized
INFO - 2023-04-24 10:21:38 --> Security Class Initialized
INFO - 2023-04-24 10:21:38 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 10:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:38 --> Input Class Initialized
INFO - 2023-04-24 10:21:38 --> Input Class Initialized
INFO - 2023-04-24 10:21:38 --> Language Class Initialized
INFO - 2023-04-24 10:21:38 --> Language Class Initialized
INFO - 2023-04-24 10:21:38 --> Loader Class Initialized
INFO - 2023-04-24 10:21:38 --> Loader Class Initialized
INFO - 2023-04-24 10:21:38 --> Controller Class Initialized
INFO - 2023-04-24 10:21:38 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-24 10:21:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:38 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:38 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:38 --> Total execution time: 0.0450
INFO - 2023-04-24 10:21:38 --> Config Class Initialized
INFO - 2023-04-24 10:21:38 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:38 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:38 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:38 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:38 --> URI Class Initialized
INFO - 2023-04-24 10:21:38 --> Router Class Initialized
INFO - 2023-04-24 10:21:38 --> Output Class Initialized
INFO - 2023-04-24 10:21:38 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:38 --> Input Class Initialized
INFO - 2023-04-24 10:21:38 --> Language Class Initialized
INFO - 2023-04-24 10:21:38 --> Loader Class Initialized
INFO - 2023-04-24 10:21:38 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:38 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:38 --> Model "Login_model" initialized
INFO - 2023-04-24 10:21:38 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:38 --> Total execution time: 0.1056
INFO - 2023-04-24 10:21:38 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:38 --> Config Class Initialized
INFO - 2023-04-24 10:21:38 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:38 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:38 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:38 --> URI Class Initialized
INFO - 2023-04-24 10:21:38 --> Router Class Initialized
INFO - 2023-04-24 10:21:38 --> Output Class Initialized
INFO - 2023-04-24 10:21:38 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:38 --> Input Class Initialized
INFO - 2023-04-24 10:21:38 --> Language Class Initialized
INFO - 2023-04-24 10:21:38 --> Loader Class Initialized
INFO - 2023-04-24 10:21:38 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:38 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:38 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:38 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:38 --> Total execution time: 0.0676
INFO - 2023-04-24 10:21:38 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:38 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:38 --> Total execution time: 0.0548
INFO - 2023-04-24 10:21:46 --> Config Class Initialized
INFO - 2023-04-24 10:21:46 --> Config Class Initialized
INFO - 2023-04-24 10:21:46 --> Hooks Class Initialized
INFO - 2023-04-24 10:21:46 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-24 10:21:46 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:46 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:46 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:46 --> URI Class Initialized
INFO - 2023-04-24 10:21:46 --> URI Class Initialized
INFO - 2023-04-24 10:21:46 --> Router Class Initialized
INFO - 2023-04-24 10:21:46 --> Router Class Initialized
INFO - 2023-04-24 10:21:46 --> Output Class Initialized
INFO - 2023-04-24 10:21:46 --> Output Class Initialized
INFO - 2023-04-24 10:21:46 --> Security Class Initialized
INFO - 2023-04-24 10:21:46 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-24 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:46 --> Input Class Initialized
INFO - 2023-04-24 10:21:46 --> Input Class Initialized
INFO - 2023-04-24 10:21:46 --> Language Class Initialized
INFO - 2023-04-24 10:21:46 --> Language Class Initialized
INFO - 2023-04-24 10:21:46 --> Loader Class Initialized
INFO - 2023-04-24 10:21:46 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:46 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:46 --> Loader Class Initialized
INFO - 2023-04-24 10:21:46 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:46 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:46 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:46 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:46 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:46 --> Total execution time: 0.1014
INFO - 2023-04-24 10:21:46 --> Config Class Initialized
INFO - 2023-04-24 10:21:46 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:46 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:46 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:46 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:46 --> URI Class Initialized
INFO - 2023-04-24 10:21:46 --> Router Class Initialized
INFO - 2023-04-24 10:21:46 --> Output Class Initialized
INFO - 2023-04-24 10:21:46 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:46 --> Input Class Initialized
INFO - 2023-04-24 10:21:46 --> Language Class Initialized
INFO - 2023-04-24 10:21:46 --> Loader Class Initialized
INFO - 2023-04-24 10:21:46 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:46 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:46 --> Model "Login_model" initialized
INFO - 2023-04-24 10:21:46 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:46 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:46 --> Total execution time: 0.0568
INFO - 2023-04-24 10:21:46 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:46 --> Total execution time: 0.1934
INFO - 2023-04-24 10:21:46 --> Config Class Initialized
INFO - 2023-04-24 10:21:46 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:46 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:46 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:46 --> URI Class Initialized
INFO - 2023-04-24 10:21:46 --> Router Class Initialized
INFO - 2023-04-24 10:21:46 --> Output Class Initialized
INFO - 2023-04-24 10:21:46 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:46 --> Input Class Initialized
INFO - 2023-04-24 10:21:46 --> Language Class Initialized
INFO - 2023-04-24 10:21:46 --> Loader Class Initialized
INFO - 2023-04-24 10:21:46 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:46 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:47 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:47 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:47 --> Model "Login_model" initialized
INFO - 2023-04-24 10:21:47 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:47 --> Total execution time: 0.2336
INFO - 2023-04-24 10:21:58 --> Config Class Initialized
INFO - 2023-04-24 10:21:58 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:58 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:58 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:58 --> URI Class Initialized
INFO - 2023-04-24 10:21:58 --> Router Class Initialized
INFO - 2023-04-24 10:21:58 --> Output Class Initialized
INFO - 2023-04-24 10:21:58 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:58 --> Input Class Initialized
INFO - 2023-04-24 10:21:58 --> Language Class Initialized
INFO - 2023-04-24 10:21:58 --> Loader Class Initialized
INFO - 2023-04-24 10:21:58 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:58 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:58 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:58 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:58 --> Total execution time: 0.0123
INFO - 2023-04-24 10:21:58 --> Config Class Initialized
INFO - 2023-04-24 10:21:58 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:58 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:58 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:58 --> URI Class Initialized
INFO - 2023-04-24 10:21:58 --> Router Class Initialized
INFO - 2023-04-24 10:21:58 --> Output Class Initialized
INFO - 2023-04-24 10:21:58 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:58 --> Input Class Initialized
INFO - 2023-04-24 10:21:58 --> Language Class Initialized
INFO - 2023-04-24 10:21:58 --> Loader Class Initialized
INFO - 2023-04-24 10:21:58 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:58 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:58 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:58 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:58 --> Total execution time: 0.0973
INFO - 2023-04-24 10:21:58 --> Config Class Initialized
INFO - 2023-04-24 10:21:58 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:58 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:58 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:58 --> URI Class Initialized
INFO - 2023-04-24 10:21:58 --> Router Class Initialized
INFO - 2023-04-24 10:21:58 --> Output Class Initialized
INFO - 2023-04-24 10:21:58 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:58 --> Input Class Initialized
INFO - 2023-04-24 10:21:58 --> Language Class Initialized
INFO - 2023-04-24 10:21:58 --> Loader Class Initialized
INFO - 2023-04-24 10:21:58 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:58 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:58 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:58 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:58 --> Total execution time: 0.0495
INFO - 2023-04-24 10:21:58 --> Config Class Initialized
INFO - 2023-04-24 10:21:58 --> Hooks Class Initialized
DEBUG - 2023-04-24 10:21:58 --> UTF-8 Support Enabled
INFO - 2023-04-24 10:21:58 --> Utf8 Class Initialized
INFO - 2023-04-24 10:21:58 --> URI Class Initialized
INFO - 2023-04-24 10:21:58 --> Router Class Initialized
INFO - 2023-04-24 10:21:58 --> Output Class Initialized
INFO - 2023-04-24 10:21:58 --> Security Class Initialized
DEBUG - 2023-04-24 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-24 10:21:58 --> Input Class Initialized
INFO - 2023-04-24 10:21:58 --> Language Class Initialized
INFO - 2023-04-24 10:21:58 --> Loader Class Initialized
INFO - 2023-04-24 10:21:58 --> Controller Class Initialized
DEBUG - 2023-04-24 10:21:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-24 10:21:58 --> Database Driver Class Initialized
INFO - 2023-04-24 10:21:58 --> Model "Cluster_model" initialized
INFO - 2023-04-24 10:21:58 --> Final output sent to browser
DEBUG - 2023-04-24 10:21:58 --> Total execution time: 0.0394
