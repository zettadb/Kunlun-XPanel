<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-01 02:07:17 --> Config Class Initialized
INFO - 2023-04-01 02:07:17 --> Hooks Class Initialized
DEBUG - 2023-04-01 02:07:17 --> UTF-8 Support Enabled
INFO - 2023-04-01 02:07:17 --> Utf8 Class Initialized
INFO - 2023-04-01 02:07:17 --> URI Class Initialized
INFO - 2023-04-01 02:07:17 --> Router Class Initialized
INFO - 2023-04-01 02:07:17 --> Output Class Initialized
INFO - 2023-04-01 02:07:17 --> Security Class Initialized
DEBUG - 2023-04-01 02:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 02:07:17 --> Input Class Initialized
INFO - 2023-04-01 02:07:17 --> Language Class Initialized
INFO - 2023-04-01 02:07:17 --> Loader Class Initialized
INFO - 2023-04-01 02:07:17 --> Controller Class Initialized
DEBUG - 2023-04-01 02:07:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-01 02:07:17 --> Database Driver Class Initialized
ERROR - 2023-04-01 02:07:27 --> Unable to connect to the database
INFO - 2023-04-01 02:07:27 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-01 02:20:52 --> Config Class Initialized
INFO - 2023-04-01 02:20:52 --> Hooks Class Initialized
DEBUG - 2023-04-01 02:20:52 --> UTF-8 Support Enabled
INFO - 2023-04-01 02:20:52 --> Utf8 Class Initialized
INFO - 2023-04-01 02:20:52 --> URI Class Initialized
INFO - 2023-04-01 02:20:52 --> Router Class Initialized
INFO - 2023-04-01 02:20:52 --> Output Class Initialized
INFO - 2023-04-01 02:20:52 --> Security Class Initialized
DEBUG - 2023-04-01 02:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 02:20:52 --> Input Class Initialized
INFO - 2023-04-01 02:20:52 --> Language Class Initialized
INFO - 2023-04-01 02:20:52 --> Loader Class Initialized
INFO - 2023-04-01 02:20:52 --> Controller Class Initialized
DEBUG - 2023-04-01 02:20:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-01 02:20:52 --> Database Driver Class Initialized
ERROR - 2023-04-01 02:21:03 --> Unable to connect to the database
INFO - 2023-04-01 02:21:03 --> Language file loaded: language/english/db_lang.php
INFO - 2023-04-01 02:21:25 --> Config Class Initialized
INFO - 2023-04-01 02:21:25 --> Hooks Class Initialized
DEBUG - 2023-04-01 02:21:25 --> UTF-8 Support Enabled
INFO - 2023-04-01 02:21:25 --> Utf8 Class Initialized
INFO - 2023-04-01 02:21:25 --> URI Class Initialized
INFO - 2023-04-01 02:21:25 --> Router Class Initialized
INFO - 2023-04-01 02:21:25 --> Output Class Initialized
INFO - 2023-04-01 02:21:26 --> Security Class Initialized
DEBUG - 2023-04-01 02:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 02:21:26 --> Input Class Initialized
INFO - 2023-04-01 02:21:26 --> Language Class Initialized
INFO - 2023-04-01 02:21:26 --> Loader Class Initialized
INFO - 2023-04-01 02:21:26 --> Controller Class Initialized
DEBUG - 2023-04-01 02:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-01 02:21:26 --> Database Driver Class Initialized
ERROR - 2023-04-01 02:21:36 --> Unable to connect to the database
INFO - 2023-04-01 02:21:36 --> Language file loaded: language/english/db_lang.php
