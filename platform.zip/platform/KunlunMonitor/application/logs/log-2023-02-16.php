<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-16 03:03:17 --> Config Class Initialized
INFO - 2023-02-16 03:03:17 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:03:17 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:03:17 --> Utf8 Class Initialized
INFO - 2023-02-16 03:03:17 --> URI Class Initialized
INFO - 2023-02-16 03:03:17 --> Router Class Initialized
INFO - 2023-02-16 03:03:17 --> Output Class Initialized
INFO - 2023-02-16 03:03:17 --> Security Class Initialized
DEBUG - 2023-02-16 03:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:03:17 --> Input Class Initialized
INFO - 2023-02-16 03:03:17 --> Language Class Initialized
INFO - 2023-02-16 03:03:17 --> Loader Class Initialized
INFO - 2023-02-16 03:03:17 --> Controller Class Initialized
INFO - 2023-02-16 03:03:17 --> Helper loaded: form_helper
INFO - 2023-02-16 03:03:17 --> Helper loaded: url_helper
DEBUG - 2023-02-16 03:03:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:03:17 --> Model "Change_model" initialized
INFO - 2023-02-16 03:03:18 --> Model "Grafana_model" initialized
INFO - 2023-02-16 03:03:18 --> Final output sent to browser
DEBUG - 2023-02-16 03:03:18 --> Total execution time: 1.2421
INFO - 2023-02-16 03:03:18 --> Config Class Initialized
INFO - 2023-02-16 03:03:18 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:03:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:03:18 --> Utf8 Class Initialized
INFO - 2023-02-16 03:03:18 --> URI Class Initialized
INFO - 2023-02-16 03:03:18 --> Router Class Initialized
INFO - 2023-02-16 03:03:18 --> Output Class Initialized
INFO - 2023-02-16 03:03:18 --> Security Class Initialized
DEBUG - 2023-02-16 03:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:03:18 --> Input Class Initialized
INFO - 2023-02-16 03:03:18 --> Language Class Initialized
INFO - 2023-02-16 03:03:18 --> Loader Class Initialized
INFO - 2023-02-16 03:03:18 --> Controller Class Initialized
INFO - 2023-02-16 03:03:18 --> Helper loaded: form_helper
INFO - 2023-02-16 03:03:18 --> Helper loaded: url_helper
DEBUG - 2023-02-16 03:03:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:03:18 --> Final output sent to browser
DEBUG - 2023-02-16 03:03:18 --> Total execution time: 0.0476
INFO - 2023-02-16 03:03:18 --> Config Class Initialized
INFO - 2023-02-16 03:03:18 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:03:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:03:18 --> Utf8 Class Initialized
INFO - 2023-02-16 03:03:18 --> URI Class Initialized
INFO - 2023-02-16 03:03:18 --> Router Class Initialized
INFO - 2023-02-16 03:03:18 --> Output Class Initialized
INFO - 2023-02-16 03:03:18 --> Security Class Initialized
DEBUG - 2023-02-16 03:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:03:18 --> Input Class Initialized
INFO - 2023-02-16 03:03:18 --> Language Class Initialized
INFO - 2023-02-16 03:03:18 --> Loader Class Initialized
INFO - 2023-02-16 03:03:18 --> Controller Class Initialized
INFO - 2023-02-16 03:03:18 --> Helper loaded: form_helper
INFO - 2023-02-16 03:03:18 --> Helper loaded: url_helper
DEBUG - 2023-02-16 03:03:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:03:18 --> Database Driver Class Initialized
INFO - 2023-02-16 03:03:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:03:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:03:20 --> Total execution time: 1.1978
INFO - 2023-02-16 03:03:20 --> Config Class Initialized
INFO - 2023-02-16 03:03:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:03:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:03:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:03:20 --> URI Class Initialized
INFO - 2023-02-16 03:03:20 --> Router Class Initialized
INFO - 2023-02-16 03:03:20 --> Output Class Initialized
INFO - 2023-02-16 03:03:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:03:20 --> Input Class Initialized
INFO - 2023-02-16 03:03:20 --> Language Class Initialized
INFO - 2023-02-16 03:03:20 --> Loader Class Initialized
INFO - 2023-02-16 03:03:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:03:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:03:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:03:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:03:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:03:20 --> Total execution time: 0.1333
INFO - 2023-02-16 03:03:20 --> Config Class Initialized
INFO - 2023-02-16 03:03:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:03:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:03:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:03:20 --> URI Class Initialized
INFO - 2023-02-16 03:03:20 --> Router Class Initialized
INFO - 2023-02-16 03:03:20 --> Output Class Initialized
INFO - 2023-02-16 03:03:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:03:20 --> Input Class Initialized
INFO - 2023-02-16 03:03:20 --> Language Class Initialized
INFO - 2023-02-16 03:03:20 --> Loader Class Initialized
INFO - 2023-02-16 03:03:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:03:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:03:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:03:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:03:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:03:20 --> Total execution time: 0.1500
INFO - 2023-02-16 03:03:20 --> Config Class Initialized
INFO - 2023-02-16 03:03:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:03:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:03:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:03:20 --> URI Class Initialized
INFO - 2023-02-16 03:03:20 --> Router Class Initialized
INFO - 2023-02-16 03:03:20 --> Output Class Initialized
INFO - 2023-02-16 03:03:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:03:20 --> Input Class Initialized
INFO - 2023-02-16 03:03:20 --> Language Class Initialized
INFO - 2023-02-16 03:03:20 --> Loader Class Initialized
INFO - 2023-02-16 03:03:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:03:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:03:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:03:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:03:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:03:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:03:21 --> Final output sent to browser
DEBUG - 2023-02-16 03:03:21 --> Total execution time: 0.4987
INFO - 2023-02-16 03:03:21 --> Config Class Initialized
INFO - 2023-02-16 03:03:21 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:03:21 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:03:21 --> Utf8 Class Initialized
INFO - 2023-02-16 03:03:21 --> URI Class Initialized
INFO - 2023-02-16 03:03:21 --> Router Class Initialized
INFO - 2023-02-16 03:03:21 --> Output Class Initialized
INFO - 2023-02-16 03:03:21 --> Security Class Initialized
DEBUG - 2023-02-16 03:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:03:21 --> Input Class Initialized
INFO - 2023-02-16 03:03:21 --> Language Class Initialized
INFO - 2023-02-16 03:03:21 --> Loader Class Initialized
INFO - 2023-02-16 03:03:21 --> Controller Class Initialized
DEBUG - 2023-02-16 03:03:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:03:21 --> Database Driver Class Initialized
INFO - 2023-02-16 03:03:21 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:03:21 --> Database Driver Class Initialized
INFO - 2023-02-16 03:03:21 --> Model "Login_model" initialized
INFO - 2023-02-16 03:03:21 --> Final output sent to browser
DEBUG - 2023-02-16 03:03:21 --> Total execution time: 0.5067
INFO - 2023-02-16 03:05:02 --> Config Class Initialized
INFO - 2023-02-16 03:05:02 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:05:02 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:05:02 --> Utf8 Class Initialized
INFO - 2023-02-16 03:05:02 --> URI Class Initialized
INFO - 2023-02-16 03:05:02 --> Router Class Initialized
INFO - 2023-02-16 03:05:02 --> Output Class Initialized
INFO - 2023-02-16 03:05:02 --> Security Class Initialized
DEBUG - 2023-02-16 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:05:02 --> Input Class Initialized
INFO - 2023-02-16 03:05:02 --> Language Class Initialized
INFO - 2023-02-16 03:05:02 --> Loader Class Initialized
INFO - 2023-02-16 03:05:02 --> Controller Class Initialized
DEBUG - 2023-02-16 03:05:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:05:02 --> Database Driver Class Initialized
INFO - 2023-02-16 03:05:02 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:05:02 --> Database Driver Class Initialized
INFO - 2023-02-16 03:05:02 --> Model "Login_model" initialized
INFO - 2023-02-16 03:05:02 --> Final output sent to browser
DEBUG - 2023-02-16 03:05:02 --> Total execution time: 0.1989
INFO - 2023-02-16 03:05:02 --> Config Class Initialized
INFO - 2023-02-16 03:05:02 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:05:02 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:05:02 --> Utf8 Class Initialized
INFO - 2023-02-16 03:05:02 --> URI Class Initialized
INFO - 2023-02-16 03:05:02 --> Router Class Initialized
INFO - 2023-02-16 03:05:02 --> Output Class Initialized
INFO - 2023-02-16 03:05:02 --> Security Class Initialized
DEBUG - 2023-02-16 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:05:02 --> Input Class Initialized
INFO - 2023-02-16 03:05:02 --> Language Class Initialized
INFO - 2023-02-16 03:05:02 --> Loader Class Initialized
INFO - 2023-02-16 03:05:02 --> Controller Class Initialized
DEBUG - 2023-02-16 03:05:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:05:02 --> Database Driver Class Initialized
INFO - 2023-02-16 03:05:02 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:05:02 --> Database Driver Class Initialized
INFO - 2023-02-16 03:05:02 --> Model "Login_model" initialized
INFO - 2023-02-16 03:05:02 --> Final output sent to browser
DEBUG - 2023-02-16 03:05:03 --> Total execution time: 0.0954
INFO - 2023-02-16 03:19:29 --> Config Class Initialized
INFO - 2023-02-16 03:19:29 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:29 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:29 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:29 --> URI Class Initialized
INFO - 2023-02-16 03:19:29 --> Router Class Initialized
INFO - 2023-02-16 03:19:29 --> Output Class Initialized
INFO - 2023-02-16 03:19:29 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:29 --> Input Class Initialized
INFO - 2023-02-16 03:19:29 --> Language Class Initialized
INFO - 2023-02-16 03:19:29 --> Loader Class Initialized
INFO - 2023-02-16 03:19:29 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:29 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:29 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:19:29 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:29 --> Model "Login_model" initialized
INFO - 2023-02-16 03:19:29 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:29 --> Total execution time: 0.1352
INFO - 2023-02-16 03:19:29 --> Config Class Initialized
INFO - 2023-02-16 03:19:29 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:29 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:29 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:29 --> URI Class Initialized
INFO - 2023-02-16 03:19:29 --> Router Class Initialized
INFO - 2023-02-16 03:19:29 --> Output Class Initialized
INFO - 2023-02-16 03:19:29 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:29 --> Input Class Initialized
INFO - 2023-02-16 03:19:29 --> Language Class Initialized
INFO - 2023-02-16 03:19:29 --> Loader Class Initialized
INFO - 2023-02-16 03:19:29 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:29 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:29 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:19:29 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:29 --> Model "Login_model" initialized
INFO - 2023-02-16 03:19:29 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:29 --> Total execution time: 0.0979
INFO - 2023-02-16 03:19:39 --> Config Class Initialized
INFO - 2023-02-16 03:19:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:39 --> URI Class Initialized
INFO - 2023-02-16 03:19:39 --> Router Class Initialized
INFO - 2023-02-16 03:19:39 --> Output Class Initialized
INFO - 2023-02-16 03:19:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:39 --> Input Class Initialized
INFO - 2023-02-16 03:19:39 --> Language Class Initialized
INFO - 2023-02-16 03:19:39 --> Loader Class Initialized
INFO - 2023-02-16 03:19:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:39 --> Total execution time: 0.0471
INFO - 2023-02-16 03:19:39 --> Config Class Initialized
INFO - 2023-02-16 03:19:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:39 --> URI Class Initialized
INFO - 2023-02-16 03:19:39 --> Router Class Initialized
INFO - 2023-02-16 03:19:39 --> Output Class Initialized
INFO - 2023-02-16 03:19:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:39 --> Input Class Initialized
INFO - 2023-02-16 03:19:39 --> Language Class Initialized
INFO - 2023-02-16 03:19:39 --> Loader Class Initialized
INFO - 2023-02-16 03:19:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:19:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:19:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:39 --> Total execution time: 0.0272
INFO - 2023-02-16 03:19:39 --> Config Class Initialized
INFO - 2023-02-16 03:19:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:39 --> URI Class Initialized
INFO - 2023-02-16 03:19:39 --> Router Class Initialized
INFO - 2023-02-16 03:19:39 --> Output Class Initialized
INFO - 2023-02-16 03:19:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:39 --> Input Class Initialized
INFO - 2023-02-16 03:19:39 --> Language Class Initialized
INFO - 2023-02-16 03:19:39 --> Loader Class Initialized
INFO - 2023-02-16 03:19:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:39 --> Total execution time: 0.0439
INFO - 2023-02-16 03:19:39 --> Config Class Initialized
INFO - 2023-02-16 03:19:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:39 --> URI Class Initialized
INFO - 2023-02-16 03:19:39 --> Router Class Initialized
INFO - 2023-02-16 03:19:39 --> Output Class Initialized
INFO - 2023-02-16 03:19:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:39 --> Input Class Initialized
INFO - 2023-02-16 03:19:39 --> Language Class Initialized
INFO - 2023-02-16 03:19:39 --> Loader Class Initialized
INFO - 2023-02-16 03:19:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:19:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:19:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:39 --> Total execution time: 0.0332
INFO - 2023-02-16 03:19:41 --> Config Class Initialized
INFO - 2023-02-16 03:19:41 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:41 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:41 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:41 --> URI Class Initialized
INFO - 2023-02-16 03:19:41 --> Router Class Initialized
INFO - 2023-02-16 03:19:41 --> Output Class Initialized
INFO - 2023-02-16 03:19:41 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:41 --> Input Class Initialized
INFO - 2023-02-16 03:19:41 --> Language Class Initialized
INFO - 2023-02-16 03:19:41 --> Loader Class Initialized
INFO - 2023-02-16 03:19:41 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:41 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:41 --> Total execution time: 0.0097
INFO - 2023-02-16 03:19:41 --> Config Class Initialized
INFO - 2023-02-16 03:19:41 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:41 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:41 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:41 --> URI Class Initialized
INFO - 2023-02-16 03:19:41 --> Router Class Initialized
INFO - 2023-02-16 03:19:41 --> Output Class Initialized
INFO - 2023-02-16 03:19:41 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:41 --> Input Class Initialized
INFO - 2023-02-16 03:19:41 --> Language Class Initialized
INFO - 2023-02-16 03:19:41 --> Loader Class Initialized
INFO - 2023-02-16 03:19:41 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:41 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:41 --> Model "Login_model" initialized
INFO - 2023-02-16 03:19:41 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:41 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:19:41 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:41 --> Total execution time: 0.0321
INFO - 2023-02-16 03:19:59 --> Config Class Initialized
INFO - 2023-02-16 03:19:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:59 --> URI Class Initialized
INFO - 2023-02-16 03:19:59 --> Router Class Initialized
INFO - 2023-02-16 03:19:59 --> Output Class Initialized
INFO - 2023-02-16 03:19:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:59 --> Input Class Initialized
INFO - 2023-02-16 03:19:59 --> Language Class Initialized
INFO - 2023-02-16 03:19:59 --> Loader Class Initialized
INFO - 2023-02-16 03:19:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:19:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:19:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:59 --> Total execution time: 0.2625
INFO - 2023-02-16 03:19:59 --> Config Class Initialized
INFO - 2023-02-16 03:19:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:19:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:19:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:19:59 --> URI Class Initialized
INFO - 2023-02-16 03:19:59 --> Router Class Initialized
INFO - 2023-02-16 03:19:59 --> Output Class Initialized
INFO - 2023-02-16 03:19:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:19:59 --> Input Class Initialized
INFO - 2023-02-16 03:19:59 --> Language Class Initialized
INFO - 2023-02-16 03:19:59 --> Loader Class Initialized
INFO - 2023-02-16 03:19:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:19:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:19:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:19:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:19:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:19:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:19:59 --> Total execution time: 0.0725
INFO - 2023-02-16 03:20:19 --> Config Class Initialized
INFO - 2023-02-16 03:20:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:20:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:20:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:20:19 --> URI Class Initialized
INFO - 2023-02-16 03:20:19 --> Router Class Initialized
INFO - 2023-02-16 03:20:19 --> Output Class Initialized
INFO - 2023-02-16 03:20:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:20:19 --> Input Class Initialized
INFO - 2023-02-16 03:20:19 --> Language Class Initialized
INFO - 2023-02-16 03:20:19 --> Loader Class Initialized
INFO - 2023-02-16 03:20:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:20:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:20:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:20:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:20:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:20:19 --> Total execution time: 0.0335
INFO - 2023-02-16 03:20:19 --> Config Class Initialized
INFO - 2023-02-16 03:20:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:20:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:20:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:20:19 --> URI Class Initialized
INFO - 2023-02-16 03:20:19 --> Router Class Initialized
INFO - 2023-02-16 03:20:19 --> Output Class Initialized
INFO - 2023-02-16 03:20:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:20:19 --> Input Class Initialized
INFO - 2023-02-16 03:20:19 --> Language Class Initialized
INFO - 2023-02-16 03:20:19 --> Loader Class Initialized
INFO - 2023-02-16 03:20:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:20:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:20:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:20:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:20:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:20:19 --> Total execution time: 0.0274
INFO - 2023-02-16 03:20:39 --> Config Class Initialized
INFO - 2023-02-16 03:20:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:20:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:20:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:20:39 --> URI Class Initialized
INFO - 2023-02-16 03:20:39 --> Router Class Initialized
INFO - 2023-02-16 03:20:39 --> Output Class Initialized
INFO - 2023-02-16 03:20:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:20:39 --> Input Class Initialized
INFO - 2023-02-16 03:20:39 --> Language Class Initialized
INFO - 2023-02-16 03:20:39 --> Loader Class Initialized
INFO - 2023-02-16 03:20:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:20:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:20:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:20:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:20:39 --> Total execution time: 0.2504
INFO - 2023-02-16 03:20:39 --> Config Class Initialized
INFO - 2023-02-16 03:20:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:20:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:20:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:20:39 --> URI Class Initialized
INFO - 2023-02-16 03:20:39 --> Router Class Initialized
INFO - 2023-02-16 03:20:39 --> Output Class Initialized
INFO - 2023-02-16 03:20:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:20:39 --> Input Class Initialized
INFO - 2023-02-16 03:20:39 --> Language Class Initialized
INFO - 2023-02-16 03:20:39 --> Loader Class Initialized
INFO - 2023-02-16 03:20:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:20:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:20:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:20:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:20:39 --> Total execution time: 0.1060
INFO - 2023-02-16 03:20:59 --> Config Class Initialized
INFO - 2023-02-16 03:20:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:20:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:20:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:20:59 --> URI Class Initialized
INFO - 2023-02-16 03:20:59 --> Router Class Initialized
INFO - 2023-02-16 03:20:59 --> Output Class Initialized
INFO - 2023-02-16 03:20:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:20:59 --> Input Class Initialized
INFO - 2023-02-16 03:20:59 --> Language Class Initialized
INFO - 2023-02-16 03:20:59 --> Loader Class Initialized
INFO - 2023-02-16 03:20:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:20:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:20:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:20:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:20:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:20:59 --> Total execution time: 0.0361
INFO - 2023-02-16 03:20:59 --> Config Class Initialized
INFO - 2023-02-16 03:20:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:20:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:20:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:20:59 --> URI Class Initialized
INFO - 2023-02-16 03:20:59 --> Router Class Initialized
INFO - 2023-02-16 03:20:59 --> Output Class Initialized
INFO - 2023-02-16 03:20:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:20:59 --> Input Class Initialized
INFO - 2023-02-16 03:20:59 --> Language Class Initialized
INFO - 2023-02-16 03:20:59 --> Loader Class Initialized
INFO - 2023-02-16 03:20:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:20:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:20:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:20:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:20:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:20:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:20:59 --> Total execution time: 0.0755
INFO - 2023-02-16 03:21:19 --> Config Class Initialized
INFO - 2023-02-16 03:21:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:21:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:21:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:21:19 --> URI Class Initialized
INFO - 2023-02-16 03:21:19 --> Router Class Initialized
INFO - 2023-02-16 03:21:19 --> Output Class Initialized
INFO - 2023-02-16 03:21:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:21:19 --> Input Class Initialized
INFO - 2023-02-16 03:21:19 --> Language Class Initialized
INFO - 2023-02-16 03:21:19 --> Loader Class Initialized
INFO - 2023-02-16 03:21:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:21:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:21:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:21:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:21:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:21:19 --> Total execution time: 0.0350
INFO - 2023-02-16 03:21:19 --> Config Class Initialized
INFO - 2023-02-16 03:21:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:21:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:21:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:21:19 --> URI Class Initialized
INFO - 2023-02-16 03:21:19 --> Router Class Initialized
INFO - 2023-02-16 03:21:19 --> Output Class Initialized
INFO - 2023-02-16 03:21:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:21:19 --> Input Class Initialized
INFO - 2023-02-16 03:21:19 --> Language Class Initialized
INFO - 2023-02-16 03:21:19 --> Loader Class Initialized
INFO - 2023-02-16 03:21:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:21:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:21:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:21:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:21:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:21:19 --> Total execution time: 0.0713
INFO - 2023-02-16 03:21:39 --> Config Class Initialized
INFO - 2023-02-16 03:21:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:21:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:21:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:21:39 --> URI Class Initialized
INFO - 2023-02-16 03:21:39 --> Router Class Initialized
INFO - 2023-02-16 03:21:39 --> Output Class Initialized
INFO - 2023-02-16 03:21:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:21:39 --> Input Class Initialized
INFO - 2023-02-16 03:21:39 --> Language Class Initialized
INFO - 2023-02-16 03:21:39 --> Loader Class Initialized
INFO - 2023-02-16 03:21:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:21:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:21:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:21:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:21:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:21:39 --> Total execution time: 0.0353
INFO - 2023-02-16 03:21:39 --> Config Class Initialized
INFO - 2023-02-16 03:21:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:21:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:21:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:21:39 --> URI Class Initialized
INFO - 2023-02-16 03:21:39 --> Router Class Initialized
INFO - 2023-02-16 03:21:39 --> Output Class Initialized
INFO - 2023-02-16 03:21:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:21:39 --> Input Class Initialized
INFO - 2023-02-16 03:21:39 --> Language Class Initialized
INFO - 2023-02-16 03:21:39 --> Loader Class Initialized
INFO - 2023-02-16 03:21:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:21:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:21:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:21:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:21:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:21:39 --> Total execution time: 0.0319
INFO - 2023-02-16 03:21:59 --> Config Class Initialized
INFO - 2023-02-16 03:21:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:21:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:21:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:21:59 --> URI Class Initialized
INFO - 2023-02-16 03:21:59 --> Router Class Initialized
INFO - 2023-02-16 03:21:59 --> Output Class Initialized
INFO - 2023-02-16 03:21:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:21:59 --> Input Class Initialized
INFO - 2023-02-16 03:21:59 --> Language Class Initialized
INFO - 2023-02-16 03:21:59 --> Loader Class Initialized
INFO - 2023-02-16 03:21:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:21:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:21:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:21:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:21:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:21:59 --> Total execution time: 0.0324
INFO - 2023-02-16 03:21:59 --> Config Class Initialized
INFO - 2023-02-16 03:21:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:21:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:21:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:21:59 --> URI Class Initialized
INFO - 2023-02-16 03:21:59 --> Router Class Initialized
INFO - 2023-02-16 03:21:59 --> Output Class Initialized
INFO - 2023-02-16 03:21:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:21:59 --> Input Class Initialized
INFO - 2023-02-16 03:21:59 --> Language Class Initialized
INFO - 2023-02-16 03:21:59 --> Loader Class Initialized
INFO - 2023-02-16 03:21:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:21:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:21:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:21:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:21:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:21:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:21:59 --> Total execution time: 0.0280
INFO - 2023-02-16 03:22:19 --> Config Class Initialized
INFO - 2023-02-16 03:22:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:22:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:22:19 --> URI Class Initialized
INFO - 2023-02-16 03:22:19 --> Router Class Initialized
INFO - 2023-02-16 03:22:19 --> Output Class Initialized
INFO - 2023-02-16 03:22:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:22:19 --> Input Class Initialized
INFO - 2023-02-16 03:22:19 --> Language Class Initialized
INFO - 2023-02-16 03:22:19 --> Loader Class Initialized
INFO - 2023-02-16 03:22:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:22:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:22:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:22:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:22:19 --> Total execution time: 0.0320
INFO - 2023-02-16 03:22:19 --> Config Class Initialized
INFO - 2023-02-16 03:22:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:22:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:22:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:22:19 --> URI Class Initialized
INFO - 2023-02-16 03:22:19 --> Router Class Initialized
INFO - 2023-02-16 03:22:19 --> Output Class Initialized
INFO - 2023-02-16 03:22:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:22:19 --> Input Class Initialized
INFO - 2023-02-16 03:22:19 --> Language Class Initialized
INFO - 2023-02-16 03:22:19 --> Loader Class Initialized
INFO - 2023-02-16 03:22:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:22:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:22:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:22:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:22:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:22:19 --> Total execution time: 0.0282
INFO - 2023-02-16 03:22:39 --> Config Class Initialized
INFO - 2023-02-16 03:22:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:22:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:22:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:22:39 --> URI Class Initialized
INFO - 2023-02-16 03:22:39 --> Router Class Initialized
INFO - 2023-02-16 03:22:39 --> Output Class Initialized
INFO - 2023-02-16 03:22:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:22:39 --> Input Class Initialized
INFO - 2023-02-16 03:22:39 --> Language Class Initialized
INFO - 2023-02-16 03:22:39 --> Loader Class Initialized
INFO - 2023-02-16 03:22:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:22:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:22:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:22:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:22:39 --> Total execution time: 0.0352
INFO - 2023-02-16 03:22:39 --> Config Class Initialized
INFO - 2023-02-16 03:22:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:22:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:22:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:22:39 --> URI Class Initialized
INFO - 2023-02-16 03:22:39 --> Router Class Initialized
INFO - 2023-02-16 03:22:39 --> Output Class Initialized
INFO - 2023-02-16 03:22:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:22:39 --> Input Class Initialized
INFO - 2023-02-16 03:22:39 --> Language Class Initialized
INFO - 2023-02-16 03:22:39 --> Loader Class Initialized
INFO - 2023-02-16 03:22:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:22:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:22:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:22:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:22:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:22:39 --> Total execution time: 0.0339
INFO - 2023-02-16 03:22:59 --> Config Class Initialized
INFO - 2023-02-16 03:22:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:22:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:22:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:22:59 --> URI Class Initialized
INFO - 2023-02-16 03:22:59 --> Router Class Initialized
INFO - 2023-02-16 03:22:59 --> Output Class Initialized
INFO - 2023-02-16 03:22:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:22:59 --> Input Class Initialized
INFO - 2023-02-16 03:22:59 --> Language Class Initialized
INFO - 2023-02-16 03:22:59 --> Loader Class Initialized
INFO - 2023-02-16 03:22:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:22:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:22:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:22:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:22:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:22:59 --> Total execution time: 0.0344
INFO - 2023-02-16 03:22:59 --> Config Class Initialized
INFO - 2023-02-16 03:22:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:22:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:22:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:22:59 --> URI Class Initialized
INFO - 2023-02-16 03:22:59 --> Router Class Initialized
INFO - 2023-02-16 03:22:59 --> Output Class Initialized
INFO - 2023-02-16 03:22:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:22:59 --> Input Class Initialized
INFO - 2023-02-16 03:22:59 --> Language Class Initialized
INFO - 2023-02-16 03:22:59 --> Loader Class Initialized
INFO - 2023-02-16 03:22:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:22:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:22:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:22:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:22:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:22:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:22:59 --> Total execution time: 0.0309
INFO - 2023-02-16 03:23:19 --> Config Class Initialized
INFO - 2023-02-16 03:23:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:23:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:23:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:23:19 --> URI Class Initialized
INFO - 2023-02-16 03:23:19 --> Router Class Initialized
INFO - 2023-02-16 03:23:19 --> Output Class Initialized
INFO - 2023-02-16 03:23:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:23:19 --> Input Class Initialized
INFO - 2023-02-16 03:23:19 --> Language Class Initialized
INFO - 2023-02-16 03:23:19 --> Loader Class Initialized
INFO - 2023-02-16 03:23:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:23:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:23:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:23:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:23:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:23:19 --> Total execution time: 0.0381
INFO - 2023-02-16 03:23:19 --> Config Class Initialized
INFO - 2023-02-16 03:23:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:23:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:23:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:23:19 --> URI Class Initialized
INFO - 2023-02-16 03:23:19 --> Router Class Initialized
INFO - 2023-02-16 03:23:19 --> Output Class Initialized
INFO - 2023-02-16 03:23:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:23:19 --> Input Class Initialized
INFO - 2023-02-16 03:23:19 --> Language Class Initialized
INFO - 2023-02-16 03:23:19 --> Loader Class Initialized
INFO - 2023-02-16 03:23:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:23:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:23:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:23:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:23:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:23:19 --> Total execution time: 0.0316
INFO - 2023-02-16 03:23:39 --> Config Class Initialized
INFO - 2023-02-16 03:23:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:23:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:23:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:23:39 --> URI Class Initialized
INFO - 2023-02-16 03:23:39 --> Router Class Initialized
INFO - 2023-02-16 03:23:39 --> Output Class Initialized
INFO - 2023-02-16 03:23:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:23:39 --> Input Class Initialized
INFO - 2023-02-16 03:23:39 --> Language Class Initialized
INFO - 2023-02-16 03:23:39 --> Loader Class Initialized
INFO - 2023-02-16 03:23:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:23:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:23:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:23:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:23:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:23:39 --> Total execution time: 0.0423
INFO - 2023-02-16 03:23:39 --> Config Class Initialized
INFO - 2023-02-16 03:23:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:23:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:23:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:23:39 --> URI Class Initialized
INFO - 2023-02-16 03:23:39 --> Router Class Initialized
INFO - 2023-02-16 03:23:39 --> Output Class Initialized
INFO - 2023-02-16 03:23:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:23:39 --> Input Class Initialized
INFO - 2023-02-16 03:23:39 --> Language Class Initialized
INFO - 2023-02-16 03:23:39 --> Loader Class Initialized
INFO - 2023-02-16 03:23:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:23:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:23:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:23:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:23:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:23:39 --> Total execution time: 0.0744
INFO - 2023-02-16 03:23:59 --> Config Class Initialized
INFO - 2023-02-16 03:23:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:23:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:23:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:23:59 --> URI Class Initialized
INFO - 2023-02-16 03:23:59 --> Router Class Initialized
INFO - 2023-02-16 03:23:59 --> Output Class Initialized
INFO - 2023-02-16 03:23:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:23:59 --> Input Class Initialized
INFO - 2023-02-16 03:23:59 --> Language Class Initialized
INFO - 2023-02-16 03:23:59 --> Loader Class Initialized
INFO - 2023-02-16 03:23:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:23:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:23:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:23:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:23:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:23:59 --> Total execution time: 0.0325
INFO - 2023-02-16 03:23:59 --> Config Class Initialized
INFO - 2023-02-16 03:23:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:23:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:23:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:23:59 --> URI Class Initialized
INFO - 2023-02-16 03:23:59 --> Router Class Initialized
INFO - 2023-02-16 03:23:59 --> Output Class Initialized
INFO - 2023-02-16 03:23:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:23:59 --> Input Class Initialized
INFO - 2023-02-16 03:23:59 --> Language Class Initialized
INFO - 2023-02-16 03:23:59 --> Loader Class Initialized
INFO - 2023-02-16 03:23:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:23:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:23:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:23:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:23:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:23:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:23:59 --> Total execution time: 0.0283
INFO - 2023-02-16 03:24:19 --> Config Class Initialized
INFO - 2023-02-16 03:24:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:24:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:24:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:24:19 --> URI Class Initialized
INFO - 2023-02-16 03:24:19 --> Router Class Initialized
INFO - 2023-02-16 03:24:19 --> Output Class Initialized
INFO - 2023-02-16 03:24:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:24:19 --> Input Class Initialized
INFO - 2023-02-16 03:24:19 --> Language Class Initialized
INFO - 2023-02-16 03:24:19 --> Loader Class Initialized
INFO - 2023-02-16 03:24:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:24:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:24:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:24:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:24:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:24:19 --> Total execution time: 0.0303
INFO - 2023-02-16 03:24:19 --> Config Class Initialized
INFO - 2023-02-16 03:24:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:24:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:24:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:24:19 --> URI Class Initialized
INFO - 2023-02-16 03:24:19 --> Router Class Initialized
INFO - 2023-02-16 03:24:19 --> Output Class Initialized
INFO - 2023-02-16 03:24:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:24:19 --> Input Class Initialized
INFO - 2023-02-16 03:24:19 --> Language Class Initialized
INFO - 2023-02-16 03:24:19 --> Loader Class Initialized
INFO - 2023-02-16 03:24:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:24:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:24:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:24:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:24:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:24:19 --> Total execution time: 0.0288
INFO - 2023-02-16 03:24:39 --> Config Class Initialized
INFO - 2023-02-16 03:24:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:24:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:24:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:24:39 --> URI Class Initialized
INFO - 2023-02-16 03:24:39 --> Router Class Initialized
INFO - 2023-02-16 03:24:39 --> Output Class Initialized
INFO - 2023-02-16 03:24:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:24:39 --> Input Class Initialized
INFO - 2023-02-16 03:24:39 --> Language Class Initialized
INFO - 2023-02-16 03:24:39 --> Loader Class Initialized
INFO - 2023-02-16 03:24:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:24:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:24:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:24:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:24:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:24:39 --> Total execution time: 0.0357
INFO - 2023-02-16 03:24:39 --> Config Class Initialized
INFO - 2023-02-16 03:24:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:24:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:24:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:24:39 --> URI Class Initialized
INFO - 2023-02-16 03:24:39 --> Router Class Initialized
INFO - 2023-02-16 03:24:39 --> Output Class Initialized
INFO - 2023-02-16 03:24:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:24:39 --> Input Class Initialized
INFO - 2023-02-16 03:24:39 --> Language Class Initialized
INFO - 2023-02-16 03:24:39 --> Loader Class Initialized
INFO - 2023-02-16 03:24:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:24:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:24:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:24:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:24:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:24:39 --> Total execution time: 0.0298
INFO - 2023-02-16 03:24:59 --> Config Class Initialized
INFO - 2023-02-16 03:24:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:24:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:24:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:24:59 --> URI Class Initialized
INFO - 2023-02-16 03:24:59 --> Router Class Initialized
INFO - 2023-02-16 03:24:59 --> Output Class Initialized
INFO - 2023-02-16 03:24:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:24:59 --> Input Class Initialized
INFO - 2023-02-16 03:24:59 --> Language Class Initialized
INFO - 2023-02-16 03:24:59 --> Loader Class Initialized
INFO - 2023-02-16 03:24:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:24:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:24:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:24:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:24:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:24:59 --> Total execution time: 0.0310
INFO - 2023-02-16 03:24:59 --> Config Class Initialized
INFO - 2023-02-16 03:24:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:24:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:24:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:24:59 --> URI Class Initialized
INFO - 2023-02-16 03:24:59 --> Router Class Initialized
INFO - 2023-02-16 03:24:59 --> Output Class Initialized
INFO - 2023-02-16 03:24:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:24:59 --> Input Class Initialized
INFO - 2023-02-16 03:24:59 --> Language Class Initialized
INFO - 2023-02-16 03:24:59 --> Loader Class Initialized
INFO - 2023-02-16 03:24:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:24:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:24:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:24:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:24:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:24:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:24:59 --> Total execution time: 0.0701
INFO - 2023-02-16 03:25:19 --> Config Class Initialized
INFO - 2023-02-16 03:25:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:25:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:25:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:25:19 --> URI Class Initialized
INFO - 2023-02-16 03:25:19 --> Router Class Initialized
INFO - 2023-02-16 03:25:19 --> Output Class Initialized
INFO - 2023-02-16 03:25:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:25:19 --> Input Class Initialized
INFO - 2023-02-16 03:25:19 --> Language Class Initialized
INFO - 2023-02-16 03:25:19 --> Loader Class Initialized
INFO - 2023-02-16 03:25:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:25:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:25:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:25:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:25:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:25:19 --> Total execution time: 0.0379
INFO - 2023-02-16 03:25:19 --> Config Class Initialized
INFO - 2023-02-16 03:25:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:25:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:25:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:25:19 --> URI Class Initialized
INFO - 2023-02-16 03:25:19 --> Router Class Initialized
INFO - 2023-02-16 03:25:19 --> Output Class Initialized
INFO - 2023-02-16 03:25:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:25:19 --> Input Class Initialized
INFO - 2023-02-16 03:25:19 --> Language Class Initialized
INFO - 2023-02-16 03:25:19 --> Loader Class Initialized
INFO - 2023-02-16 03:25:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:25:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:25:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:25:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:25:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:25:19 --> Total execution time: 0.0327
INFO - 2023-02-16 03:25:39 --> Config Class Initialized
INFO - 2023-02-16 03:25:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:25:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:25:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:25:39 --> URI Class Initialized
INFO - 2023-02-16 03:25:39 --> Router Class Initialized
INFO - 2023-02-16 03:25:39 --> Output Class Initialized
INFO - 2023-02-16 03:25:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:25:39 --> Input Class Initialized
INFO - 2023-02-16 03:25:39 --> Language Class Initialized
INFO - 2023-02-16 03:25:39 --> Loader Class Initialized
INFO - 2023-02-16 03:25:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:25:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:25:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:25:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:25:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:25:39 --> Total execution time: 0.0377
INFO - 2023-02-16 03:25:39 --> Config Class Initialized
INFO - 2023-02-16 03:25:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:25:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:25:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:25:39 --> URI Class Initialized
INFO - 2023-02-16 03:25:39 --> Router Class Initialized
INFO - 2023-02-16 03:25:39 --> Output Class Initialized
INFO - 2023-02-16 03:25:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:25:39 --> Input Class Initialized
INFO - 2023-02-16 03:25:39 --> Language Class Initialized
INFO - 2023-02-16 03:25:39 --> Loader Class Initialized
INFO - 2023-02-16 03:25:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:25:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:25:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:25:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:25:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:25:39 --> Total execution time: 0.0271
INFO - 2023-02-16 03:25:59 --> Config Class Initialized
INFO - 2023-02-16 03:25:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:25:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:25:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:25:59 --> URI Class Initialized
INFO - 2023-02-16 03:25:59 --> Router Class Initialized
INFO - 2023-02-16 03:25:59 --> Output Class Initialized
INFO - 2023-02-16 03:25:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:25:59 --> Input Class Initialized
INFO - 2023-02-16 03:25:59 --> Language Class Initialized
INFO - 2023-02-16 03:25:59 --> Loader Class Initialized
INFO - 2023-02-16 03:25:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:25:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:25:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:25:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:25:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:25:59 --> Total execution time: 0.0304
INFO - 2023-02-16 03:25:59 --> Config Class Initialized
INFO - 2023-02-16 03:25:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:25:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:25:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:25:59 --> URI Class Initialized
INFO - 2023-02-16 03:25:59 --> Router Class Initialized
INFO - 2023-02-16 03:25:59 --> Output Class Initialized
INFO - 2023-02-16 03:25:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:25:59 --> Input Class Initialized
INFO - 2023-02-16 03:25:59 --> Language Class Initialized
INFO - 2023-02-16 03:25:59 --> Loader Class Initialized
INFO - 2023-02-16 03:25:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:25:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:25:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:25:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:25:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:25:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:25:59 --> Total execution time: 0.0293
INFO - 2023-02-16 03:26:19 --> Config Class Initialized
INFO - 2023-02-16 03:26:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:26:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:26:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:26:19 --> URI Class Initialized
INFO - 2023-02-16 03:26:19 --> Router Class Initialized
INFO - 2023-02-16 03:26:19 --> Output Class Initialized
INFO - 2023-02-16 03:26:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:26:19 --> Input Class Initialized
INFO - 2023-02-16 03:26:19 --> Language Class Initialized
INFO - 2023-02-16 03:26:19 --> Loader Class Initialized
INFO - 2023-02-16 03:26:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:26:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:26:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:26:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:26:19 --> Total execution time: 0.0339
INFO - 2023-02-16 03:26:19 --> Config Class Initialized
INFO - 2023-02-16 03:26:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:26:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:26:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:26:19 --> URI Class Initialized
INFO - 2023-02-16 03:26:19 --> Router Class Initialized
INFO - 2023-02-16 03:26:19 --> Output Class Initialized
INFO - 2023-02-16 03:26:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:26:19 --> Input Class Initialized
INFO - 2023-02-16 03:26:19 --> Language Class Initialized
INFO - 2023-02-16 03:26:19 --> Loader Class Initialized
INFO - 2023-02-16 03:26:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:26:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:26:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:26:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:26:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:26:19 --> Total execution time: 0.0308
INFO - 2023-02-16 03:26:39 --> Config Class Initialized
INFO - 2023-02-16 03:26:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:26:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:26:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:26:39 --> URI Class Initialized
INFO - 2023-02-16 03:26:39 --> Router Class Initialized
INFO - 2023-02-16 03:26:39 --> Output Class Initialized
INFO - 2023-02-16 03:26:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:26:39 --> Input Class Initialized
INFO - 2023-02-16 03:26:39 --> Language Class Initialized
INFO - 2023-02-16 03:26:39 --> Loader Class Initialized
INFO - 2023-02-16 03:26:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:26:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:26:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:26:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:26:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:26:39 --> Total execution time: 0.0361
INFO - 2023-02-16 03:26:39 --> Config Class Initialized
INFO - 2023-02-16 03:26:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:26:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:26:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:26:39 --> URI Class Initialized
INFO - 2023-02-16 03:26:39 --> Router Class Initialized
INFO - 2023-02-16 03:26:39 --> Output Class Initialized
INFO - 2023-02-16 03:26:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:26:39 --> Input Class Initialized
INFO - 2023-02-16 03:26:39 --> Language Class Initialized
INFO - 2023-02-16 03:26:39 --> Loader Class Initialized
INFO - 2023-02-16 03:26:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:26:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:26:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:26:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:26:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:26:39 --> Total execution time: 0.0354
INFO - 2023-02-16 03:26:59 --> Config Class Initialized
INFO - 2023-02-16 03:26:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:26:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:26:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:26:59 --> URI Class Initialized
INFO - 2023-02-16 03:26:59 --> Router Class Initialized
INFO - 2023-02-16 03:26:59 --> Output Class Initialized
INFO - 2023-02-16 03:26:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:26:59 --> Input Class Initialized
INFO - 2023-02-16 03:26:59 --> Language Class Initialized
INFO - 2023-02-16 03:26:59 --> Loader Class Initialized
INFO - 2023-02-16 03:26:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:26:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:26:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:26:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:26:59 --> Total execution time: 0.0357
INFO - 2023-02-16 03:26:59 --> Config Class Initialized
INFO - 2023-02-16 03:26:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:26:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:26:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:26:59 --> URI Class Initialized
INFO - 2023-02-16 03:26:59 --> Router Class Initialized
INFO - 2023-02-16 03:26:59 --> Output Class Initialized
INFO - 2023-02-16 03:26:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:26:59 --> Input Class Initialized
INFO - 2023-02-16 03:26:59 --> Language Class Initialized
INFO - 2023-02-16 03:26:59 --> Loader Class Initialized
INFO - 2023-02-16 03:26:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:26:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:26:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:26:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:26:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:26:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:26:59 --> Total execution time: 0.0423
INFO - 2023-02-16 03:27:19 --> Config Class Initialized
INFO - 2023-02-16 03:27:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:27:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:27:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:27:19 --> URI Class Initialized
INFO - 2023-02-16 03:27:19 --> Router Class Initialized
INFO - 2023-02-16 03:27:19 --> Output Class Initialized
INFO - 2023-02-16 03:27:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:27:19 --> Input Class Initialized
INFO - 2023-02-16 03:27:19 --> Language Class Initialized
INFO - 2023-02-16 03:27:19 --> Loader Class Initialized
INFO - 2023-02-16 03:27:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:27:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:27:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:27:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:27:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:27:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:27:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:27:19 --> Total execution time: 0.0429
INFO - 2023-02-16 03:27:19 --> Config Class Initialized
INFO - 2023-02-16 03:27:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:27:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:27:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:27:19 --> URI Class Initialized
INFO - 2023-02-16 03:27:19 --> Router Class Initialized
INFO - 2023-02-16 03:27:19 --> Output Class Initialized
INFO - 2023-02-16 03:27:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:27:19 --> Input Class Initialized
INFO - 2023-02-16 03:27:19 --> Language Class Initialized
INFO - 2023-02-16 03:27:19 --> Loader Class Initialized
INFO - 2023-02-16 03:27:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:27:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:27:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:27:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:27:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:27:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:27:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:27:19 --> Total execution time: 0.0487
INFO - 2023-02-16 03:27:39 --> Config Class Initialized
INFO - 2023-02-16 03:27:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:27:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:27:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:27:39 --> URI Class Initialized
INFO - 2023-02-16 03:27:39 --> Router Class Initialized
INFO - 2023-02-16 03:27:39 --> Output Class Initialized
INFO - 2023-02-16 03:27:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:27:39 --> Input Class Initialized
INFO - 2023-02-16 03:27:39 --> Language Class Initialized
INFO - 2023-02-16 03:27:39 --> Loader Class Initialized
INFO - 2023-02-16 03:27:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:27:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:27:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:27:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:27:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:27:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:27:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:27:39 --> Total execution time: 0.0313
INFO - 2023-02-16 03:27:39 --> Config Class Initialized
INFO - 2023-02-16 03:27:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:27:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:27:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:27:39 --> URI Class Initialized
INFO - 2023-02-16 03:27:39 --> Router Class Initialized
INFO - 2023-02-16 03:27:39 --> Output Class Initialized
INFO - 2023-02-16 03:27:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:27:39 --> Input Class Initialized
INFO - 2023-02-16 03:27:39 --> Language Class Initialized
INFO - 2023-02-16 03:27:39 --> Loader Class Initialized
INFO - 2023-02-16 03:27:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:27:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:27:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:27:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:27:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:27:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:27:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:27:39 --> Total execution time: 0.0281
INFO - 2023-02-16 03:28:00 --> Config Class Initialized
INFO - 2023-02-16 03:28:00 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:28:00 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:28:00 --> Utf8 Class Initialized
INFO - 2023-02-16 03:28:00 --> URI Class Initialized
INFO - 2023-02-16 03:28:00 --> Router Class Initialized
INFO - 2023-02-16 03:28:00 --> Output Class Initialized
INFO - 2023-02-16 03:28:00 --> Security Class Initialized
DEBUG - 2023-02-16 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:28:00 --> Input Class Initialized
INFO - 2023-02-16 03:28:00 --> Language Class Initialized
INFO - 2023-02-16 03:28:00 --> Loader Class Initialized
INFO - 2023-02-16 03:28:00 --> Controller Class Initialized
DEBUG - 2023-02-16 03:28:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:28:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:28:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:28:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:28:00 --> Total execution time: 0.0353
INFO - 2023-02-16 03:28:00 --> Config Class Initialized
INFO - 2023-02-16 03:28:00 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:28:00 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:28:00 --> Utf8 Class Initialized
INFO - 2023-02-16 03:28:00 --> URI Class Initialized
INFO - 2023-02-16 03:28:00 --> Router Class Initialized
INFO - 2023-02-16 03:28:00 --> Output Class Initialized
INFO - 2023-02-16 03:28:00 --> Security Class Initialized
DEBUG - 2023-02-16 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:28:00 --> Input Class Initialized
INFO - 2023-02-16 03:28:00 --> Language Class Initialized
INFO - 2023-02-16 03:28:00 --> Loader Class Initialized
INFO - 2023-02-16 03:28:00 --> Controller Class Initialized
DEBUG - 2023-02-16 03:28:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:28:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:28:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:28:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:28:00 --> Total execution time: 0.0301
INFO - 2023-02-16 03:28:19 --> Config Class Initialized
INFO - 2023-02-16 03:28:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:28:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:28:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:28:19 --> URI Class Initialized
INFO - 2023-02-16 03:28:19 --> Router Class Initialized
INFO - 2023-02-16 03:28:19 --> Output Class Initialized
INFO - 2023-02-16 03:28:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:28:19 --> Input Class Initialized
INFO - 2023-02-16 03:28:19 --> Language Class Initialized
INFO - 2023-02-16 03:28:19 --> Loader Class Initialized
INFO - 2023-02-16 03:28:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:28:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:28:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:28:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:28:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:28:19 --> Total execution time: 0.0353
INFO - 2023-02-16 03:28:19 --> Config Class Initialized
INFO - 2023-02-16 03:28:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:28:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:28:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:28:19 --> URI Class Initialized
INFO - 2023-02-16 03:28:19 --> Router Class Initialized
INFO - 2023-02-16 03:28:19 --> Output Class Initialized
INFO - 2023-02-16 03:28:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:28:19 --> Input Class Initialized
INFO - 2023-02-16 03:28:19 --> Language Class Initialized
INFO - 2023-02-16 03:28:19 --> Loader Class Initialized
INFO - 2023-02-16 03:28:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:28:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:28:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:28:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:28:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:28:19 --> Total execution time: 0.0279
INFO - 2023-02-16 03:28:39 --> Config Class Initialized
INFO - 2023-02-16 03:28:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:28:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:28:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:28:39 --> URI Class Initialized
INFO - 2023-02-16 03:28:39 --> Router Class Initialized
INFO - 2023-02-16 03:28:39 --> Output Class Initialized
INFO - 2023-02-16 03:28:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:28:39 --> Input Class Initialized
INFO - 2023-02-16 03:28:39 --> Language Class Initialized
INFO - 2023-02-16 03:28:39 --> Loader Class Initialized
INFO - 2023-02-16 03:28:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:28:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:28:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:28:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:28:39 --> Total execution time: 0.0361
INFO - 2023-02-16 03:28:39 --> Config Class Initialized
INFO - 2023-02-16 03:28:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:28:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:28:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:28:39 --> URI Class Initialized
INFO - 2023-02-16 03:28:39 --> Router Class Initialized
INFO - 2023-02-16 03:28:39 --> Output Class Initialized
INFO - 2023-02-16 03:28:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:28:39 --> Input Class Initialized
INFO - 2023-02-16 03:28:39 --> Language Class Initialized
INFO - 2023-02-16 03:28:39 --> Loader Class Initialized
INFO - 2023-02-16 03:28:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:28:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:28:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:28:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:28:39 --> Total execution time: 0.0751
INFO - 2023-02-16 03:28:59 --> Config Class Initialized
INFO - 2023-02-16 03:28:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:28:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:28:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:28:59 --> URI Class Initialized
INFO - 2023-02-16 03:28:59 --> Router Class Initialized
INFO - 2023-02-16 03:28:59 --> Output Class Initialized
INFO - 2023-02-16 03:28:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:28:59 --> Input Class Initialized
INFO - 2023-02-16 03:28:59 --> Language Class Initialized
INFO - 2023-02-16 03:28:59 --> Loader Class Initialized
INFO - 2023-02-16 03:28:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:28:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:28:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:28:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:28:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:28:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:28:59 --> Total execution time: 0.0747
INFO - 2023-02-16 03:28:59 --> Config Class Initialized
INFO - 2023-02-16 03:28:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:28:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:28:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:28:59 --> URI Class Initialized
INFO - 2023-02-16 03:28:59 --> Router Class Initialized
INFO - 2023-02-16 03:28:59 --> Output Class Initialized
INFO - 2023-02-16 03:28:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:28:59 --> Input Class Initialized
INFO - 2023-02-16 03:28:59 --> Language Class Initialized
INFO - 2023-02-16 03:28:59 --> Loader Class Initialized
INFO - 2023-02-16 03:28:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:28:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:28:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:29:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:29:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:29:00 --> Total execution time: 0.0352
INFO - 2023-02-16 03:29:20 --> Config Class Initialized
INFO - 2023-02-16 03:29:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:29:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:29:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:29:20 --> URI Class Initialized
INFO - 2023-02-16 03:29:20 --> Router Class Initialized
INFO - 2023-02-16 03:29:20 --> Output Class Initialized
INFO - 2023-02-16 03:29:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:29:20 --> Input Class Initialized
INFO - 2023-02-16 03:29:20 --> Language Class Initialized
INFO - 2023-02-16 03:29:20 --> Loader Class Initialized
INFO - 2023-02-16 03:29:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:29:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:29:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:29:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:29:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:29:20 --> Total execution time: 0.0341
INFO - 2023-02-16 03:29:20 --> Config Class Initialized
INFO - 2023-02-16 03:29:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:29:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:29:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:29:20 --> URI Class Initialized
INFO - 2023-02-16 03:29:20 --> Router Class Initialized
INFO - 2023-02-16 03:29:20 --> Output Class Initialized
INFO - 2023-02-16 03:29:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:29:20 --> Input Class Initialized
INFO - 2023-02-16 03:29:20 --> Language Class Initialized
INFO - 2023-02-16 03:29:20 --> Loader Class Initialized
INFO - 2023-02-16 03:29:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:29:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:29:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:29:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:29:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:29:20 --> Total execution time: 0.0305
INFO - 2023-02-16 03:29:39 --> Config Class Initialized
INFO - 2023-02-16 03:29:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:29:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:29:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:29:39 --> URI Class Initialized
INFO - 2023-02-16 03:29:39 --> Router Class Initialized
INFO - 2023-02-16 03:29:39 --> Output Class Initialized
INFO - 2023-02-16 03:29:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:29:39 --> Input Class Initialized
INFO - 2023-02-16 03:29:39 --> Language Class Initialized
INFO - 2023-02-16 03:29:39 --> Loader Class Initialized
INFO - 2023-02-16 03:29:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:29:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:29:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:29:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:29:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:29:39 --> Total execution time: 0.0373
INFO - 2023-02-16 03:29:39 --> Config Class Initialized
INFO - 2023-02-16 03:29:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:29:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:29:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:29:39 --> URI Class Initialized
INFO - 2023-02-16 03:29:39 --> Router Class Initialized
INFO - 2023-02-16 03:29:39 --> Output Class Initialized
INFO - 2023-02-16 03:29:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:29:39 --> Input Class Initialized
INFO - 2023-02-16 03:29:39 --> Language Class Initialized
INFO - 2023-02-16 03:29:39 --> Loader Class Initialized
INFO - 2023-02-16 03:29:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:29:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:29:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:29:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:29:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:29:39 --> Total execution time: 0.0318
INFO - 2023-02-16 03:29:59 --> Config Class Initialized
INFO - 2023-02-16 03:29:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:29:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:29:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:29:59 --> URI Class Initialized
INFO - 2023-02-16 03:29:59 --> Router Class Initialized
INFO - 2023-02-16 03:29:59 --> Output Class Initialized
INFO - 2023-02-16 03:29:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:29:59 --> Input Class Initialized
INFO - 2023-02-16 03:29:59 --> Language Class Initialized
INFO - 2023-02-16 03:29:59 --> Loader Class Initialized
INFO - 2023-02-16 03:29:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:29:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:29:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:29:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:29:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:29:59 --> Total execution time: 0.0495
INFO - 2023-02-16 03:29:59 --> Config Class Initialized
INFO - 2023-02-16 03:29:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:29:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:29:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:29:59 --> URI Class Initialized
INFO - 2023-02-16 03:29:59 --> Router Class Initialized
INFO - 2023-02-16 03:29:59 --> Output Class Initialized
INFO - 2023-02-16 03:29:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:29:59 --> Input Class Initialized
INFO - 2023-02-16 03:29:59 --> Language Class Initialized
INFO - 2023-02-16 03:29:59 --> Loader Class Initialized
INFO - 2023-02-16 03:29:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:29:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:29:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:29:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:29:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:29:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:29:59 --> Total execution time: 0.0448
INFO - 2023-02-16 03:30:20 --> Config Class Initialized
INFO - 2023-02-16 03:30:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:30:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:30:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:30:20 --> URI Class Initialized
INFO - 2023-02-16 03:30:20 --> Router Class Initialized
INFO - 2023-02-16 03:30:20 --> Output Class Initialized
INFO - 2023-02-16 03:30:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:30:20 --> Input Class Initialized
INFO - 2023-02-16 03:30:20 --> Language Class Initialized
INFO - 2023-02-16 03:30:20 --> Loader Class Initialized
INFO - 2023-02-16 03:30:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:30:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:30:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:30:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:30:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:30:20 --> Total execution time: 0.4753
INFO - 2023-02-16 03:30:20 --> Config Class Initialized
INFO - 2023-02-16 03:30:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:30:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:30:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:30:20 --> URI Class Initialized
INFO - 2023-02-16 03:30:20 --> Router Class Initialized
INFO - 2023-02-16 03:30:20 --> Output Class Initialized
INFO - 2023-02-16 03:30:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:30:20 --> Input Class Initialized
INFO - 2023-02-16 03:30:20 --> Language Class Initialized
INFO - 2023-02-16 03:30:20 --> Loader Class Initialized
INFO - 2023-02-16 03:30:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:30:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:30:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:30:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:30:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:30:20 --> Total execution time: 0.4900
INFO - 2023-02-16 03:30:40 --> Config Class Initialized
INFO - 2023-02-16 03:30:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:30:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:30:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:30:40 --> URI Class Initialized
INFO - 2023-02-16 03:30:40 --> Router Class Initialized
INFO - 2023-02-16 03:30:40 --> Output Class Initialized
INFO - 2023-02-16 03:30:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:30:40 --> Input Class Initialized
INFO - 2023-02-16 03:30:40 --> Language Class Initialized
INFO - 2023-02-16 03:30:40 --> Loader Class Initialized
INFO - 2023-02-16 03:30:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:30:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:30:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:30:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:30:40 --> Total execution time: 0.0368
INFO - 2023-02-16 03:30:40 --> Config Class Initialized
INFO - 2023-02-16 03:30:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:30:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:30:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:30:40 --> URI Class Initialized
INFO - 2023-02-16 03:30:40 --> Router Class Initialized
INFO - 2023-02-16 03:30:40 --> Output Class Initialized
INFO - 2023-02-16 03:30:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:30:40 --> Input Class Initialized
INFO - 2023-02-16 03:30:40 --> Language Class Initialized
INFO - 2023-02-16 03:30:40 --> Loader Class Initialized
INFO - 2023-02-16 03:30:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:30:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:30:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:30:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:30:40 --> Total execution time: 0.0332
INFO - 2023-02-16 03:30:59 --> Config Class Initialized
INFO - 2023-02-16 03:30:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:30:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:30:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:30:59 --> URI Class Initialized
INFO - 2023-02-16 03:30:59 --> Router Class Initialized
INFO - 2023-02-16 03:30:59 --> Output Class Initialized
INFO - 2023-02-16 03:30:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:30:59 --> Input Class Initialized
INFO - 2023-02-16 03:30:59 --> Language Class Initialized
INFO - 2023-02-16 03:30:59 --> Loader Class Initialized
INFO - 2023-02-16 03:30:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:30:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:30:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:30:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:30:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:30:59 --> Total execution time: 0.0720
INFO - 2023-02-16 03:30:59 --> Config Class Initialized
INFO - 2023-02-16 03:30:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:30:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:30:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:30:59 --> URI Class Initialized
INFO - 2023-02-16 03:30:59 --> Router Class Initialized
INFO - 2023-02-16 03:30:59 --> Output Class Initialized
INFO - 2023-02-16 03:30:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:30:59 --> Input Class Initialized
INFO - 2023-02-16 03:30:59 --> Language Class Initialized
INFO - 2023-02-16 03:30:59 --> Loader Class Initialized
INFO - 2023-02-16 03:30:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:30:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:30:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:30:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:30:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:30:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:30:59 --> Total execution time: 0.0340
INFO - 2023-02-16 03:31:20 --> Config Class Initialized
INFO - 2023-02-16 03:31:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:31:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:31:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:31:20 --> URI Class Initialized
INFO - 2023-02-16 03:31:20 --> Router Class Initialized
INFO - 2023-02-16 03:31:20 --> Output Class Initialized
INFO - 2023-02-16 03:31:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:31:20 --> Input Class Initialized
INFO - 2023-02-16 03:31:20 --> Language Class Initialized
INFO - 2023-02-16 03:31:20 --> Loader Class Initialized
INFO - 2023-02-16 03:31:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:31:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:31:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:31:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:31:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:31:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:31:20 --> Total execution time: 0.0407
INFO - 2023-02-16 03:31:20 --> Config Class Initialized
INFO - 2023-02-16 03:31:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:31:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:31:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:31:20 --> URI Class Initialized
INFO - 2023-02-16 03:31:20 --> Router Class Initialized
INFO - 2023-02-16 03:31:20 --> Output Class Initialized
INFO - 2023-02-16 03:31:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:31:20 --> Input Class Initialized
INFO - 2023-02-16 03:31:20 --> Language Class Initialized
INFO - 2023-02-16 03:31:20 --> Loader Class Initialized
INFO - 2023-02-16 03:31:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:31:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:31:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:31:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:31:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:31:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:31:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:31:20 --> Total execution time: 0.0396
INFO - 2023-02-16 03:31:40 --> Config Class Initialized
INFO - 2023-02-16 03:31:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:31:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:31:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:31:40 --> URI Class Initialized
INFO - 2023-02-16 03:31:40 --> Router Class Initialized
INFO - 2023-02-16 03:31:40 --> Output Class Initialized
INFO - 2023-02-16 03:31:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:31:40 --> Input Class Initialized
INFO - 2023-02-16 03:31:40 --> Language Class Initialized
INFO - 2023-02-16 03:31:40 --> Loader Class Initialized
INFO - 2023-02-16 03:31:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:31:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:31:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:31:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:31:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:31:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:31:40 --> Total execution time: 0.0361
INFO - 2023-02-16 03:31:40 --> Config Class Initialized
INFO - 2023-02-16 03:31:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:31:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:31:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:31:40 --> URI Class Initialized
INFO - 2023-02-16 03:31:40 --> Router Class Initialized
INFO - 2023-02-16 03:31:40 --> Output Class Initialized
INFO - 2023-02-16 03:31:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:31:40 --> Input Class Initialized
INFO - 2023-02-16 03:31:40 --> Language Class Initialized
INFO - 2023-02-16 03:31:40 --> Loader Class Initialized
INFO - 2023-02-16 03:31:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:31:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:31:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:31:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:31:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:31:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:31:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:31:40 --> Total execution time: 0.0340
INFO - 2023-02-16 03:32:00 --> Config Class Initialized
INFO - 2023-02-16 03:32:00 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:32:00 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:32:00 --> Utf8 Class Initialized
INFO - 2023-02-16 03:32:00 --> URI Class Initialized
INFO - 2023-02-16 03:32:00 --> Router Class Initialized
INFO - 2023-02-16 03:32:00 --> Output Class Initialized
INFO - 2023-02-16 03:32:00 --> Security Class Initialized
DEBUG - 2023-02-16 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:32:00 --> Input Class Initialized
INFO - 2023-02-16 03:32:00 --> Language Class Initialized
INFO - 2023-02-16 03:32:00 --> Loader Class Initialized
INFO - 2023-02-16 03:32:00 --> Controller Class Initialized
DEBUG - 2023-02-16 03:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:32:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:32:00 --> Total execution time: 0.0409
INFO - 2023-02-16 03:32:00 --> Config Class Initialized
INFO - 2023-02-16 03:32:00 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:32:00 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:32:00 --> Utf8 Class Initialized
INFO - 2023-02-16 03:32:00 --> URI Class Initialized
INFO - 2023-02-16 03:32:00 --> Router Class Initialized
INFO - 2023-02-16 03:32:00 --> Output Class Initialized
INFO - 2023-02-16 03:32:00 --> Security Class Initialized
DEBUG - 2023-02-16 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:32:00 --> Input Class Initialized
INFO - 2023-02-16 03:32:00 --> Language Class Initialized
INFO - 2023-02-16 03:32:00 --> Loader Class Initialized
INFO - 2023-02-16 03:32:00 --> Controller Class Initialized
DEBUG - 2023-02-16 03:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:32:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:32:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:32:00 --> Total execution time: 0.0356
INFO - 2023-02-16 03:32:19 --> Config Class Initialized
INFO - 2023-02-16 03:32:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:32:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:32:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:32:19 --> URI Class Initialized
INFO - 2023-02-16 03:32:19 --> Router Class Initialized
INFO - 2023-02-16 03:32:19 --> Output Class Initialized
INFO - 2023-02-16 03:32:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:32:19 --> Input Class Initialized
INFO - 2023-02-16 03:32:19 --> Language Class Initialized
INFO - 2023-02-16 03:32:19 --> Loader Class Initialized
INFO - 2023-02-16 03:32:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:32:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:32:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:32:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:32:19 --> Total execution time: 0.0407
INFO - 2023-02-16 03:32:19 --> Config Class Initialized
INFO - 2023-02-16 03:32:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:32:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:32:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:32:19 --> URI Class Initialized
INFO - 2023-02-16 03:32:19 --> Router Class Initialized
INFO - 2023-02-16 03:32:19 --> Output Class Initialized
INFO - 2023-02-16 03:32:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:32:19 --> Input Class Initialized
INFO - 2023-02-16 03:32:19 --> Language Class Initialized
INFO - 2023-02-16 03:32:19 --> Loader Class Initialized
INFO - 2023-02-16 03:32:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:32:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:32:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:32:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:32:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:32:19 --> Total execution time: 0.0686
INFO - 2023-02-16 03:32:39 --> Config Class Initialized
INFO - 2023-02-16 03:32:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:32:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:32:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:32:39 --> URI Class Initialized
INFO - 2023-02-16 03:32:39 --> Router Class Initialized
INFO - 2023-02-16 03:32:39 --> Output Class Initialized
INFO - 2023-02-16 03:32:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:32:39 --> Input Class Initialized
INFO - 2023-02-16 03:32:39 --> Language Class Initialized
INFO - 2023-02-16 03:32:39 --> Loader Class Initialized
INFO - 2023-02-16 03:32:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:32:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:32:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:32:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:32:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:32:39 --> Total execution time: 0.0360
INFO - 2023-02-16 03:32:39 --> Config Class Initialized
INFO - 2023-02-16 03:32:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:32:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:32:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:32:39 --> URI Class Initialized
INFO - 2023-02-16 03:32:39 --> Router Class Initialized
INFO - 2023-02-16 03:32:39 --> Output Class Initialized
INFO - 2023-02-16 03:32:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:32:39 --> Input Class Initialized
INFO - 2023-02-16 03:32:39 --> Language Class Initialized
INFO - 2023-02-16 03:32:39 --> Loader Class Initialized
INFO - 2023-02-16 03:32:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:32:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:32:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:32:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:32:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:32:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:32:39 --> Total execution time: 0.0408
INFO - 2023-02-16 03:33:47 --> Config Class Initialized
INFO - 2023-02-16 03:33:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:33:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:33:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:33:47 --> URI Class Initialized
INFO - 2023-02-16 03:33:47 --> Router Class Initialized
INFO - 2023-02-16 03:33:47 --> Output Class Initialized
INFO - 2023-02-16 03:33:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:33:47 --> Input Class Initialized
INFO - 2023-02-16 03:33:47 --> Language Class Initialized
INFO - 2023-02-16 03:33:47 --> Loader Class Initialized
INFO - 2023-02-16 03:33:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:33:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:33:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:33:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:33:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:33:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:33:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:33:47 --> Total execution time: 0.0346
INFO - 2023-02-16 03:33:47 --> Config Class Initialized
INFO - 2023-02-16 03:33:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:33:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:33:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:33:47 --> URI Class Initialized
INFO - 2023-02-16 03:33:47 --> Router Class Initialized
INFO - 2023-02-16 03:33:47 --> Output Class Initialized
INFO - 2023-02-16 03:33:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:33:47 --> Input Class Initialized
INFO - 2023-02-16 03:33:47 --> Language Class Initialized
INFO - 2023-02-16 03:33:47 --> Loader Class Initialized
INFO - 2023-02-16 03:33:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:33:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:33:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:33:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:33:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:33:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:33:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:33:47 --> Total execution time: 0.0732
INFO - 2023-02-16 03:34:47 --> Config Class Initialized
INFO - 2023-02-16 03:34:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:34:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:34:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:34:47 --> URI Class Initialized
INFO - 2023-02-16 03:34:47 --> Router Class Initialized
INFO - 2023-02-16 03:34:47 --> Output Class Initialized
INFO - 2023-02-16 03:34:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:34:47 --> Input Class Initialized
INFO - 2023-02-16 03:34:47 --> Language Class Initialized
INFO - 2023-02-16 03:34:47 --> Loader Class Initialized
INFO - 2023-02-16 03:34:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:34:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:34:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:34:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:34:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:34:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:34:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:34:47 --> Total execution time: 0.0400
INFO - 2023-02-16 03:34:47 --> Config Class Initialized
INFO - 2023-02-16 03:34:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:34:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:34:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:34:47 --> URI Class Initialized
INFO - 2023-02-16 03:34:47 --> Router Class Initialized
INFO - 2023-02-16 03:34:47 --> Output Class Initialized
INFO - 2023-02-16 03:34:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:34:47 --> Input Class Initialized
INFO - 2023-02-16 03:34:47 --> Language Class Initialized
INFO - 2023-02-16 03:34:47 --> Loader Class Initialized
INFO - 2023-02-16 03:34:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:34:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:34:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:34:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:34:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:34:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:34:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:34:47 --> Total execution time: 0.0563
INFO - 2023-02-16 03:36:02 --> Config Class Initialized
INFO - 2023-02-16 03:36:02 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:36:02 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:36:02 --> Utf8 Class Initialized
INFO - 2023-02-16 03:36:02 --> URI Class Initialized
INFO - 2023-02-16 03:36:02 --> Router Class Initialized
INFO - 2023-02-16 03:36:02 --> Output Class Initialized
INFO - 2023-02-16 03:36:02 --> Security Class Initialized
DEBUG - 2023-02-16 03:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:36:02 --> Input Class Initialized
INFO - 2023-02-16 03:36:02 --> Language Class Initialized
INFO - 2023-02-16 03:36:02 --> Loader Class Initialized
INFO - 2023-02-16 03:36:02 --> Controller Class Initialized
DEBUG - 2023-02-16 03:36:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:36:02 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:02 --> Model "Login_model" initialized
INFO - 2023-02-16 03:36:02 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:02 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:36:02 --> Final output sent to browser
DEBUG - 2023-02-16 03:36:02 --> Total execution time: 0.0371
INFO - 2023-02-16 03:36:02 --> Config Class Initialized
INFO - 2023-02-16 03:36:02 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:36:02 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:36:02 --> Utf8 Class Initialized
INFO - 2023-02-16 03:36:02 --> URI Class Initialized
INFO - 2023-02-16 03:36:02 --> Router Class Initialized
INFO - 2023-02-16 03:36:02 --> Output Class Initialized
INFO - 2023-02-16 03:36:02 --> Security Class Initialized
DEBUG - 2023-02-16 03:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:36:02 --> Input Class Initialized
INFO - 2023-02-16 03:36:02 --> Language Class Initialized
INFO - 2023-02-16 03:36:02 --> Loader Class Initialized
INFO - 2023-02-16 03:36:02 --> Controller Class Initialized
DEBUG - 2023-02-16 03:36:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:36:02 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:02 --> Model "Login_model" initialized
INFO - 2023-02-16 03:36:02 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:02 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:36:02 --> Final output sent to browser
DEBUG - 2023-02-16 03:36:02 --> Total execution time: 0.0355
INFO - 2023-02-16 03:36:47 --> Config Class Initialized
INFO - 2023-02-16 03:36:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:36:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:36:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:36:47 --> URI Class Initialized
INFO - 2023-02-16 03:36:47 --> Router Class Initialized
INFO - 2023-02-16 03:36:47 --> Output Class Initialized
INFO - 2023-02-16 03:36:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:36:47 --> Input Class Initialized
INFO - 2023-02-16 03:36:47 --> Language Class Initialized
INFO - 2023-02-16 03:36:47 --> Loader Class Initialized
INFO - 2023-02-16 03:36:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:36:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:36:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:36:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:36:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:36:47 --> Total execution time: 0.0740
INFO - 2023-02-16 03:36:47 --> Config Class Initialized
INFO - 2023-02-16 03:36:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:36:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:36:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:36:47 --> URI Class Initialized
INFO - 2023-02-16 03:36:47 --> Router Class Initialized
INFO - 2023-02-16 03:36:47 --> Output Class Initialized
INFO - 2023-02-16 03:36:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:36:47 --> Input Class Initialized
INFO - 2023-02-16 03:36:47 --> Language Class Initialized
INFO - 2023-02-16 03:36:47 --> Loader Class Initialized
INFO - 2023-02-16 03:36:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:36:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:36:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:36:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:36:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:36:47 --> Total execution time: 0.0810
INFO - 2023-02-16 03:36:59 --> Config Class Initialized
INFO - 2023-02-16 03:36:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:36:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:36:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:36:59 --> URI Class Initialized
INFO - 2023-02-16 03:36:59 --> Router Class Initialized
INFO - 2023-02-16 03:36:59 --> Output Class Initialized
INFO - 2023-02-16 03:36:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:36:59 --> Input Class Initialized
INFO - 2023-02-16 03:36:59 --> Language Class Initialized
INFO - 2023-02-16 03:36:59 --> Loader Class Initialized
INFO - 2023-02-16 03:36:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:36:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:36:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:36:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:36:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:36:59 --> Total execution time: 0.0314
INFO - 2023-02-16 03:36:59 --> Config Class Initialized
INFO - 2023-02-16 03:36:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:36:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:36:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:36:59 --> URI Class Initialized
INFO - 2023-02-16 03:36:59 --> Router Class Initialized
INFO - 2023-02-16 03:36:59 --> Output Class Initialized
INFO - 2023-02-16 03:36:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:36:59 --> Input Class Initialized
INFO - 2023-02-16 03:36:59 --> Language Class Initialized
INFO - 2023-02-16 03:36:59 --> Loader Class Initialized
INFO - 2023-02-16 03:36:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:36:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:36:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:36:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:36:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:36:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:36:59 --> Total execution time: 0.0325
INFO - 2023-02-16 03:37:19 --> Config Class Initialized
INFO - 2023-02-16 03:37:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:37:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:37:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:37:19 --> URI Class Initialized
INFO - 2023-02-16 03:37:19 --> Router Class Initialized
INFO - 2023-02-16 03:37:19 --> Output Class Initialized
INFO - 2023-02-16 03:37:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:37:19 --> Input Class Initialized
INFO - 2023-02-16 03:37:19 --> Language Class Initialized
INFO - 2023-02-16 03:37:19 --> Loader Class Initialized
INFO - 2023-02-16 03:37:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:37:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:37:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:37:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:37:19 --> Total execution time: 0.0371
INFO - 2023-02-16 03:37:19 --> Config Class Initialized
INFO - 2023-02-16 03:37:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:37:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:37:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:37:19 --> URI Class Initialized
INFO - 2023-02-16 03:37:19 --> Router Class Initialized
INFO - 2023-02-16 03:37:19 --> Output Class Initialized
INFO - 2023-02-16 03:37:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:37:19 --> Input Class Initialized
INFO - 2023-02-16 03:37:19 --> Language Class Initialized
INFO - 2023-02-16 03:37:19 --> Loader Class Initialized
INFO - 2023-02-16 03:37:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:37:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:37:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:37:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:37:19 --> Total execution time: 0.0298
INFO - 2023-02-16 03:37:39 --> Config Class Initialized
INFO - 2023-02-16 03:37:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:37:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:37:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:37:39 --> URI Class Initialized
INFO - 2023-02-16 03:37:39 --> Router Class Initialized
INFO - 2023-02-16 03:37:39 --> Output Class Initialized
INFO - 2023-02-16 03:37:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:37:39 --> Input Class Initialized
INFO - 2023-02-16 03:37:39 --> Language Class Initialized
INFO - 2023-02-16 03:37:39 --> Loader Class Initialized
INFO - 2023-02-16 03:37:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:37:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:37:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:37:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:37:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:37:39 --> Total execution time: 0.0343
INFO - 2023-02-16 03:37:39 --> Config Class Initialized
INFO - 2023-02-16 03:37:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:37:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:37:39 --> Utf8 Class Initialized
INFO - 2023-02-16 03:37:39 --> URI Class Initialized
INFO - 2023-02-16 03:37:39 --> Router Class Initialized
INFO - 2023-02-16 03:37:39 --> Output Class Initialized
INFO - 2023-02-16 03:37:39 --> Security Class Initialized
DEBUG - 2023-02-16 03:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:37:39 --> Input Class Initialized
INFO - 2023-02-16 03:37:39 --> Language Class Initialized
INFO - 2023-02-16 03:37:39 --> Loader Class Initialized
INFO - 2023-02-16 03:37:39 --> Controller Class Initialized
DEBUG - 2023-02-16 03:37:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:37:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:39 --> Model "Login_model" initialized
INFO - 2023-02-16 03:37:39 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:37:39 --> Final output sent to browser
DEBUG - 2023-02-16 03:37:39 --> Total execution time: 0.0779
INFO - 2023-02-16 03:37:59 --> Config Class Initialized
INFO - 2023-02-16 03:37:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:37:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:37:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:37:59 --> URI Class Initialized
INFO - 2023-02-16 03:37:59 --> Router Class Initialized
INFO - 2023-02-16 03:37:59 --> Output Class Initialized
INFO - 2023-02-16 03:37:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:37:59 --> Input Class Initialized
INFO - 2023-02-16 03:37:59 --> Language Class Initialized
INFO - 2023-02-16 03:37:59 --> Loader Class Initialized
INFO - 2023-02-16 03:37:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:37:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:37:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:37:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:37:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:37:59 --> Total execution time: 0.0349
INFO - 2023-02-16 03:37:59 --> Config Class Initialized
INFO - 2023-02-16 03:37:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:37:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:37:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:37:59 --> URI Class Initialized
INFO - 2023-02-16 03:37:59 --> Router Class Initialized
INFO - 2023-02-16 03:37:59 --> Output Class Initialized
INFO - 2023-02-16 03:37:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:37:59 --> Input Class Initialized
INFO - 2023-02-16 03:37:59 --> Language Class Initialized
INFO - 2023-02-16 03:37:59 --> Loader Class Initialized
INFO - 2023-02-16 03:37:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:37:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:37:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:37:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:37:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:37:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:37:59 --> Total execution time: 0.0326
INFO - 2023-02-16 03:38:19 --> Config Class Initialized
INFO - 2023-02-16 03:38:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:38:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:38:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:38:19 --> URI Class Initialized
INFO - 2023-02-16 03:38:19 --> Router Class Initialized
INFO - 2023-02-16 03:38:19 --> Output Class Initialized
INFO - 2023-02-16 03:38:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:38:19 --> Input Class Initialized
INFO - 2023-02-16 03:38:19 --> Language Class Initialized
INFO - 2023-02-16 03:38:19 --> Loader Class Initialized
INFO - 2023-02-16 03:38:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:38:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:38:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:38:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:38:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:38:19 --> Total execution time: 0.0332
INFO - 2023-02-16 03:38:19 --> Config Class Initialized
INFO - 2023-02-16 03:38:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:38:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:38:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:38:19 --> URI Class Initialized
INFO - 2023-02-16 03:38:19 --> Router Class Initialized
INFO - 2023-02-16 03:38:19 --> Output Class Initialized
INFO - 2023-02-16 03:38:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:38:19 --> Input Class Initialized
INFO - 2023-02-16 03:38:19 --> Language Class Initialized
INFO - 2023-02-16 03:38:19 --> Loader Class Initialized
INFO - 2023-02-16 03:38:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:38:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:38:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:38:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:38:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:38:19 --> Total execution time: 0.0292
INFO - 2023-02-16 03:38:40 --> Config Class Initialized
INFO - 2023-02-16 03:38:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:38:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:38:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:38:40 --> URI Class Initialized
INFO - 2023-02-16 03:38:40 --> Router Class Initialized
INFO - 2023-02-16 03:38:40 --> Output Class Initialized
INFO - 2023-02-16 03:38:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:38:40 --> Input Class Initialized
INFO - 2023-02-16 03:38:40 --> Language Class Initialized
INFO - 2023-02-16 03:38:40 --> Loader Class Initialized
INFO - 2023-02-16 03:38:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:38:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:38:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:38:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:38:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:38:40 --> Total execution time: 0.0424
INFO - 2023-02-16 03:38:40 --> Config Class Initialized
INFO - 2023-02-16 03:38:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:38:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:38:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:38:40 --> URI Class Initialized
INFO - 2023-02-16 03:38:40 --> Router Class Initialized
INFO - 2023-02-16 03:38:40 --> Output Class Initialized
INFO - 2023-02-16 03:38:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:38:40 --> Input Class Initialized
INFO - 2023-02-16 03:38:40 --> Language Class Initialized
INFO - 2023-02-16 03:38:40 --> Loader Class Initialized
INFO - 2023-02-16 03:38:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:38:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:38:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:38:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:38:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:38:40 --> Total execution time: 0.0333
INFO - 2023-02-16 03:38:59 --> Config Class Initialized
INFO - 2023-02-16 03:38:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:38:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:38:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:38:59 --> URI Class Initialized
INFO - 2023-02-16 03:38:59 --> Router Class Initialized
INFO - 2023-02-16 03:38:59 --> Output Class Initialized
INFO - 2023-02-16 03:38:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:38:59 --> Input Class Initialized
INFO - 2023-02-16 03:38:59 --> Language Class Initialized
INFO - 2023-02-16 03:38:59 --> Loader Class Initialized
INFO - 2023-02-16 03:38:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:38:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:38:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:38:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:38:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:38:59 --> Total execution time: 0.0351
INFO - 2023-02-16 03:38:59 --> Config Class Initialized
INFO - 2023-02-16 03:38:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:38:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:38:59 --> Utf8 Class Initialized
INFO - 2023-02-16 03:38:59 --> URI Class Initialized
INFO - 2023-02-16 03:38:59 --> Router Class Initialized
INFO - 2023-02-16 03:38:59 --> Output Class Initialized
INFO - 2023-02-16 03:38:59 --> Security Class Initialized
DEBUG - 2023-02-16 03:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:38:59 --> Input Class Initialized
INFO - 2023-02-16 03:38:59 --> Language Class Initialized
INFO - 2023-02-16 03:38:59 --> Loader Class Initialized
INFO - 2023-02-16 03:38:59 --> Controller Class Initialized
DEBUG - 2023-02-16 03:38:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:38:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:59 --> Model "Login_model" initialized
INFO - 2023-02-16 03:38:59 --> Database Driver Class Initialized
INFO - 2023-02-16 03:38:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:38:59 --> Final output sent to browser
DEBUG - 2023-02-16 03:38:59 --> Total execution time: 0.0296
INFO - 2023-02-16 03:39:20 --> Config Class Initialized
INFO - 2023-02-16 03:39:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:39:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:39:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:39:20 --> URI Class Initialized
INFO - 2023-02-16 03:39:20 --> Router Class Initialized
INFO - 2023-02-16 03:39:20 --> Output Class Initialized
INFO - 2023-02-16 03:39:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:39:20 --> Input Class Initialized
INFO - 2023-02-16 03:39:20 --> Language Class Initialized
INFO - 2023-02-16 03:39:20 --> Loader Class Initialized
INFO - 2023-02-16 03:39:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:39:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:39:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:39:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:39:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:39:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:39:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:39:20 --> Total execution time: 0.0420
INFO - 2023-02-16 03:39:20 --> Config Class Initialized
INFO - 2023-02-16 03:39:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:39:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:39:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:39:20 --> URI Class Initialized
INFO - 2023-02-16 03:39:20 --> Router Class Initialized
INFO - 2023-02-16 03:39:20 --> Output Class Initialized
INFO - 2023-02-16 03:39:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:39:20 --> Input Class Initialized
INFO - 2023-02-16 03:39:20 --> Language Class Initialized
INFO - 2023-02-16 03:39:20 --> Loader Class Initialized
INFO - 2023-02-16 03:39:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:39:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:39:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:39:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:39:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:39:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:39:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:39:20 --> Total execution time: 0.0332
INFO - 2023-02-16 03:39:40 --> Config Class Initialized
INFO - 2023-02-16 03:39:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:39:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:39:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:39:40 --> URI Class Initialized
INFO - 2023-02-16 03:39:40 --> Router Class Initialized
INFO - 2023-02-16 03:39:40 --> Output Class Initialized
INFO - 2023-02-16 03:39:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:39:40 --> Input Class Initialized
INFO - 2023-02-16 03:39:40 --> Language Class Initialized
INFO - 2023-02-16 03:39:40 --> Loader Class Initialized
INFO - 2023-02-16 03:39:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:39:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:39:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:39:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:39:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:39:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:39:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:39:40 --> Total execution time: 0.0385
INFO - 2023-02-16 03:39:40 --> Config Class Initialized
INFO - 2023-02-16 03:39:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:39:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:39:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:39:40 --> URI Class Initialized
INFO - 2023-02-16 03:39:40 --> Router Class Initialized
INFO - 2023-02-16 03:39:40 --> Output Class Initialized
INFO - 2023-02-16 03:39:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:39:40 --> Input Class Initialized
INFO - 2023-02-16 03:39:40 --> Language Class Initialized
INFO - 2023-02-16 03:39:40 --> Loader Class Initialized
INFO - 2023-02-16 03:39:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:39:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:39:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:39:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:39:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:39:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:39:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:39:40 --> Total execution time: 0.0290
INFO - 2023-02-16 03:40:00 --> Config Class Initialized
INFO - 2023-02-16 03:40:00 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:40:00 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:40:00 --> Utf8 Class Initialized
INFO - 2023-02-16 03:40:00 --> URI Class Initialized
INFO - 2023-02-16 03:40:00 --> Router Class Initialized
INFO - 2023-02-16 03:40:00 --> Output Class Initialized
INFO - 2023-02-16 03:40:00 --> Security Class Initialized
DEBUG - 2023-02-16 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:40:00 --> Input Class Initialized
INFO - 2023-02-16 03:40:00 --> Language Class Initialized
INFO - 2023-02-16 03:40:00 --> Loader Class Initialized
INFO - 2023-02-16 03:40:00 --> Controller Class Initialized
DEBUG - 2023-02-16 03:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:40:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:40:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:40:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:40:00 --> Total execution time: 0.0368
INFO - 2023-02-16 03:40:00 --> Config Class Initialized
INFO - 2023-02-16 03:40:00 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:40:00 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:40:00 --> Utf8 Class Initialized
INFO - 2023-02-16 03:40:00 --> URI Class Initialized
INFO - 2023-02-16 03:40:00 --> Router Class Initialized
INFO - 2023-02-16 03:40:00 --> Output Class Initialized
INFO - 2023-02-16 03:40:00 --> Security Class Initialized
DEBUG - 2023-02-16 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:40:00 --> Input Class Initialized
INFO - 2023-02-16 03:40:00 --> Language Class Initialized
INFO - 2023-02-16 03:40:00 --> Loader Class Initialized
INFO - 2023-02-16 03:40:00 --> Controller Class Initialized
DEBUG - 2023-02-16 03:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:40:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:40:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:40:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:40:00 --> Total execution time: 0.0305
INFO - 2023-02-16 03:40:19 --> Config Class Initialized
INFO - 2023-02-16 03:40:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:40:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:40:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:40:19 --> URI Class Initialized
INFO - 2023-02-16 03:40:19 --> Router Class Initialized
INFO - 2023-02-16 03:40:19 --> Output Class Initialized
INFO - 2023-02-16 03:40:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:40:19 --> Input Class Initialized
INFO - 2023-02-16 03:40:19 --> Language Class Initialized
INFO - 2023-02-16 03:40:19 --> Loader Class Initialized
INFO - 2023-02-16 03:40:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:40:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:40:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:40:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:40:19 --> Total execution time: 0.0367
INFO - 2023-02-16 03:40:19 --> Config Class Initialized
INFO - 2023-02-16 03:40:19 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:40:19 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:40:19 --> Utf8 Class Initialized
INFO - 2023-02-16 03:40:19 --> URI Class Initialized
INFO - 2023-02-16 03:40:19 --> Router Class Initialized
INFO - 2023-02-16 03:40:19 --> Output Class Initialized
INFO - 2023-02-16 03:40:19 --> Security Class Initialized
DEBUG - 2023-02-16 03:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:40:19 --> Input Class Initialized
INFO - 2023-02-16 03:40:19 --> Language Class Initialized
INFO - 2023-02-16 03:40:19 --> Loader Class Initialized
INFO - 2023-02-16 03:40:19 --> Controller Class Initialized
DEBUG - 2023-02-16 03:40:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:40:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:19 --> Model "Login_model" initialized
INFO - 2023-02-16 03:40:19 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:19 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:40:19 --> Final output sent to browser
DEBUG - 2023-02-16 03:40:19 --> Total execution time: 0.0903
INFO - 2023-02-16 03:40:40 --> Config Class Initialized
INFO - 2023-02-16 03:40:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:40:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:40:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:40:40 --> URI Class Initialized
INFO - 2023-02-16 03:40:40 --> Router Class Initialized
INFO - 2023-02-16 03:40:40 --> Output Class Initialized
INFO - 2023-02-16 03:40:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:40:40 --> Input Class Initialized
INFO - 2023-02-16 03:40:40 --> Language Class Initialized
INFO - 2023-02-16 03:40:40 --> Loader Class Initialized
INFO - 2023-02-16 03:40:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:40:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:40:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:40:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:40:40 --> Total execution time: 0.0378
INFO - 2023-02-16 03:40:40 --> Config Class Initialized
INFO - 2023-02-16 03:40:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:40:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:40:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:40:40 --> URI Class Initialized
INFO - 2023-02-16 03:40:40 --> Router Class Initialized
INFO - 2023-02-16 03:40:40 --> Output Class Initialized
INFO - 2023-02-16 03:40:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:40:40 --> Input Class Initialized
INFO - 2023-02-16 03:40:40 --> Language Class Initialized
INFO - 2023-02-16 03:40:40 --> Loader Class Initialized
INFO - 2023-02-16 03:40:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:40:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:40:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:40:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:40:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:40:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:40:40 --> Total execution time: 0.0303
INFO - 2023-02-16 03:41:00 --> Config Class Initialized
INFO - 2023-02-16 03:41:00 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:41:00 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:41:00 --> Utf8 Class Initialized
INFO - 2023-02-16 03:41:00 --> URI Class Initialized
INFO - 2023-02-16 03:41:00 --> Router Class Initialized
INFO - 2023-02-16 03:41:00 --> Output Class Initialized
INFO - 2023-02-16 03:41:00 --> Security Class Initialized
DEBUG - 2023-02-16 03:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:41:00 --> Input Class Initialized
INFO - 2023-02-16 03:41:00 --> Language Class Initialized
INFO - 2023-02-16 03:41:00 --> Loader Class Initialized
INFO - 2023-02-16 03:41:00 --> Controller Class Initialized
DEBUG - 2023-02-16 03:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:41:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:41:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:41:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:41:00 --> Total execution time: 0.0350
INFO - 2023-02-16 03:41:00 --> Config Class Initialized
INFO - 2023-02-16 03:41:00 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:41:00 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:41:00 --> Utf8 Class Initialized
INFO - 2023-02-16 03:41:00 --> URI Class Initialized
INFO - 2023-02-16 03:41:00 --> Router Class Initialized
INFO - 2023-02-16 03:41:00 --> Output Class Initialized
INFO - 2023-02-16 03:41:00 --> Security Class Initialized
DEBUG - 2023-02-16 03:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:41:00 --> Input Class Initialized
INFO - 2023-02-16 03:41:00 --> Language Class Initialized
INFO - 2023-02-16 03:41:00 --> Loader Class Initialized
INFO - 2023-02-16 03:41:00 --> Controller Class Initialized
DEBUG - 2023-02-16 03:41:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:41:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:00 --> Model "Login_model" initialized
INFO - 2023-02-16 03:41:00 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:00 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:41:00 --> Final output sent to browser
DEBUG - 2023-02-16 03:41:00 --> Total execution time: 0.0333
INFO - 2023-02-16 03:41:20 --> Config Class Initialized
INFO - 2023-02-16 03:41:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:41:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:41:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:41:20 --> URI Class Initialized
INFO - 2023-02-16 03:41:20 --> Router Class Initialized
INFO - 2023-02-16 03:41:20 --> Output Class Initialized
INFO - 2023-02-16 03:41:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:41:20 --> Input Class Initialized
INFO - 2023-02-16 03:41:20 --> Language Class Initialized
INFO - 2023-02-16 03:41:20 --> Loader Class Initialized
INFO - 2023-02-16 03:41:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:41:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:41:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:41:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:41:20 --> Total execution time: 0.0444
INFO - 2023-02-16 03:41:20 --> Config Class Initialized
INFO - 2023-02-16 03:41:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:41:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:41:20 --> Utf8 Class Initialized
INFO - 2023-02-16 03:41:20 --> URI Class Initialized
INFO - 2023-02-16 03:41:20 --> Router Class Initialized
INFO - 2023-02-16 03:41:20 --> Output Class Initialized
INFO - 2023-02-16 03:41:20 --> Security Class Initialized
DEBUG - 2023-02-16 03:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:41:20 --> Input Class Initialized
INFO - 2023-02-16 03:41:20 --> Language Class Initialized
INFO - 2023-02-16 03:41:20 --> Loader Class Initialized
INFO - 2023-02-16 03:41:20 --> Controller Class Initialized
DEBUG - 2023-02-16 03:41:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:41:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:20 --> Model "Login_model" initialized
INFO - 2023-02-16 03:41:20 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:41:20 --> Final output sent to browser
DEBUG - 2023-02-16 03:41:20 --> Total execution time: 0.0364
INFO - 2023-02-16 03:41:40 --> Config Class Initialized
INFO - 2023-02-16 03:41:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:41:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:41:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:41:40 --> URI Class Initialized
INFO - 2023-02-16 03:41:40 --> Router Class Initialized
INFO - 2023-02-16 03:41:40 --> Output Class Initialized
INFO - 2023-02-16 03:41:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:41:40 --> Input Class Initialized
INFO - 2023-02-16 03:41:40 --> Language Class Initialized
INFO - 2023-02-16 03:41:40 --> Loader Class Initialized
INFO - 2023-02-16 03:41:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:41:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:41:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:41:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:41:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:41:40 --> Total execution time: 0.0433
INFO - 2023-02-16 03:41:40 --> Config Class Initialized
INFO - 2023-02-16 03:41:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:41:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:41:40 --> Utf8 Class Initialized
INFO - 2023-02-16 03:41:40 --> URI Class Initialized
INFO - 2023-02-16 03:41:40 --> Router Class Initialized
INFO - 2023-02-16 03:41:40 --> Output Class Initialized
INFO - 2023-02-16 03:41:40 --> Security Class Initialized
DEBUG - 2023-02-16 03:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:41:40 --> Input Class Initialized
INFO - 2023-02-16 03:41:40 --> Language Class Initialized
INFO - 2023-02-16 03:41:40 --> Loader Class Initialized
INFO - 2023-02-16 03:41:40 --> Controller Class Initialized
DEBUG - 2023-02-16 03:41:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:41:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:40 --> Model "Login_model" initialized
INFO - 2023-02-16 03:41:40 --> Database Driver Class Initialized
INFO - 2023-02-16 03:41:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:41:40 --> Final output sent to browser
DEBUG - 2023-02-16 03:41:40 --> Total execution time: 0.0350
INFO - 2023-02-16 03:42:47 --> Config Class Initialized
INFO - 2023-02-16 03:42:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:42:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:42:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:42:47 --> URI Class Initialized
INFO - 2023-02-16 03:42:47 --> Router Class Initialized
INFO - 2023-02-16 03:42:47 --> Output Class Initialized
INFO - 2023-02-16 03:42:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:42:47 --> Input Class Initialized
INFO - 2023-02-16 03:42:47 --> Language Class Initialized
INFO - 2023-02-16 03:42:47 --> Loader Class Initialized
INFO - 2023-02-16 03:42:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:42:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:42:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:42:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:42:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:42:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:42:48 --> Final output sent to browser
DEBUG - 2023-02-16 03:42:48 --> Total execution time: 0.4407
INFO - 2023-02-16 03:42:48 --> Config Class Initialized
INFO - 2023-02-16 03:42:48 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:42:48 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:42:48 --> Utf8 Class Initialized
INFO - 2023-02-16 03:42:48 --> URI Class Initialized
INFO - 2023-02-16 03:42:48 --> Router Class Initialized
INFO - 2023-02-16 03:42:48 --> Output Class Initialized
INFO - 2023-02-16 03:42:48 --> Security Class Initialized
DEBUG - 2023-02-16 03:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:42:48 --> Input Class Initialized
INFO - 2023-02-16 03:42:48 --> Language Class Initialized
INFO - 2023-02-16 03:42:48 --> Loader Class Initialized
INFO - 2023-02-16 03:42:48 --> Controller Class Initialized
DEBUG - 2023-02-16 03:42:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:42:48 --> Database Driver Class Initialized
INFO - 2023-02-16 03:42:48 --> Model "Login_model" initialized
INFO - 2023-02-16 03:42:48 --> Database Driver Class Initialized
INFO - 2023-02-16 03:42:48 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:42:48 --> Final output sent to browser
DEBUG - 2023-02-16 03:42:48 --> Total execution time: 0.3257
INFO - 2023-02-16 03:43:47 --> Config Class Initialized
INFO - 2023-02-16 03:43:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:43:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:43:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:43:47 --> URI Class Initialized
INFO - 2023-02-16 03:43:47 --> Router Class Initialized
INFO - 2023-02-16 03:43:47 --> Output Class Initialized
INFO - 2023-02-16 03:43:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:43:47 --> Input Class Initialized
INFO - 2023-02-16 03:43:47 --> Language Class Initialized
INFO - 2023-02-16 03:43:47 --> Loader Class Initialized
INFO - 2023-02-16 03:43:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:43:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:43:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:43:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:43:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:43:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:43:48 --> Final output sent to browser
DEBUG - 2023-02-16 03:43:48 --> Total execution time: 0.3325
INFO - 2023-02-16 03:43:48 --> Config Class Initialized
INFO - 2023-02-16 03:43:48 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:43:48 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:43:48 --> Utf8 Class Initialized
INFO - 2023-02-16 03:43:48 --> URI Class Initialized
INFO - 2023-02-16 03:43:48 --> Router Class Initialized
INFO - 2023-02-16 03:43:48 --> Output Class Initialized
INFO - 2023-02-16 03:43:48 --> Security Class Initialized
DEBUG - 2023-02-16 03:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:43:48 --> Input Class Initialized
INFO - 2023-02-16 03:43:48 --> Language Class Initialized
INFO - 2023-02-16 03:43:48 --> Loader Class Initialized
INFO - 2023-02-16 03:43:48 --> Controller Class Initialized
DEBUG - 2023-02-16 03:43:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:43:48 --> Database Driver Class Initialized
INFO - 2023-02-16 03:43:48 --> Model "Login_model" initialized
INFO - 2023-02-16 03:43:48 --> Database Driver Class Initialized
INFO - 2023-02-16 03:43:48 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:43:48 --> Final output sent to browser
DEBUG - 2023-02-16 03:43:48 --> Total execution time: 0.4156
INFO - 2023-02-16 03:44:47 --> Config Class Initialized
INFO - 2023-02-16 03:44:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:44:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:44:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:44:47 --> URI Class Initialized
INFO - 2023-02-16 03:44:47 --> Router Class Initialized
INFO - 2023-02-16 03:44:47 --> Output Class Initialized
INFO - 2023-02-16 03:44:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:44:47 --> Input Class Initialized
INFO - 2023-02-16 03:44:47 --> Language Class Initialized
INFO - 2023-02-16 03:44:47 --> Loader Class Initialized
INFO - 2023-02-16 03:44:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:44:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:44:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:44:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:44:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:44:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:44:48 --> Final output sent to browser
DEBUG - 2023-02-16 03:44:48 --> Total execution time: 0.3377
INFO - 2023-02-16 03:44:48 --> Config Class Initialized
INFO - 2023-02-16 03:44:48 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:44:48 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:44:48 --> Utf8 Class Initialized
INFO - 2023-02-16 03:44:48 --> URI Class Initialized
INFO - 2023-02-16 03:44:48 --> Router Class Initialized
INFO - 2023-02-16 03:44:48 --> Output Class Initialized
INFO - 2023-02-16 03:44:48 --> Security Class Initialized
DEBUG - 2023-02-16 03:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:44:48 --> Input Class Initialized
INFO - 2023-02-16 03:44:48 --> Language Class Initialized
INFO - 2023-02-16 03:44:48 --> Loader Class Initialized
INFO - 2023-02-16 03:44:48 --> Controller Class Initialized
DEBUG - 2023-02-16 03:44:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:44:48 --> Database Driver Class Initialized
INFO - 2023-02-16 03:44:48 --> Model "Login_model" initialized
INFO - 2023-02-16 03:44:48 --> Database Driver Class Initialized
INFO - 2023-02-16 03:44:48 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:44:48 --> Final output sent to browser
DEBUG - 2023-02-16 03:44:48 --> Total execution time: 0.3807
INFO - 2023-02-16 03:45:47 --> Config Class Initialized
INFO - 2023-02-16 03:45:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:45:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:45:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:45:47 --> URI Class Initialized
INFO - 2023-02-16 03:45:47 --> Router Class Initialized
INFO - 2023-02-16 03:45:47 --> Output Class Initialized
INFO - 2023-02-16 03:45:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:45:47 --> Input Class Initialized
INFO - 2023-02-16 03:45:47 --> Language Class Initialized
INFO - 2023-02-16 03:45:47 --> Loader Class Initialized
INFO - 2023-02-16 03:45:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:45:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:45:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:45:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:45:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:45:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:45:47 --> Total execution time: 0.0361
INFO - 2023-02-16 03:45:47 --> Config Class Initialized
INFO - 2023-02-16 03:45:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:45:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:45:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:45:47 --> URI Class Initialized
INFO - 2023-02-16 03:45:47 --> Router Class Initialized
INFO - 2023-02-16 03:45:47 --> Output Class Initialized
INFO - 2023-02-16 03:45:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:45:47 --> Input Class Initialized
INFO - 2023-02-16 03:45:47 --> Language Class Initialized
INFO - 2023-02-16 03:45:47 --> Loader Class Initialized
INFO - 2023-02-16 03:45:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:45:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:45:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:45:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:45:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:45:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:45:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:45:47 --> Total execution time: 0.0333
INFO - 2023-02-16 03:46:58 --> Config Class Initialized
INFO - 2023-02-16 03:46:58 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:46:58 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:46:58 --> Utf8 Class Initialized
INFO - 2023-02-16 03:46:58 --> URI Class Initialized
INFO - 2023-02-16 03:46:58 --> Router Class Initialized
INFO - 2023-02-16 03:46:58 --> Output Class Initialized
INFO - 2023-02-16 03:46:58 --> Security Class Initialized
DEBUG - 2023-02-16 03:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:46:58 --> Input Class Initialized
INFO - 2023-02-16 03:46:58 --> Language Class Initialized
INFO - 2023-02-16 03:46:58 --> Loader Class Initialized
INFO - 2023-02-16 03:46:58 --> Controller Class Initialized
DEBUG - 2023-02-16 03:46:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:46:58 --> Database Driver Class Initialized
INFO - 2023-02-16 03:46:58 --> Model "Login_model" initialized
INFO - 2023-02-16 03:46:58 --> Database Driver Class Initialized
INFO - 2023-02-16 03:46:58 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:46:58 --> Final output sent to browser
DEBUG - 2023-02-16 03:46:58 --> Total execution time: 0.0428
INFO - 2023-02-16 03:46:58 --> Config Class Initialized
INFO - 2023-02-16 03:46:58 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:46:58 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:46:58 --> Utf8 Class Initialized
INFO - 2023-02-16 03:46:58 --> URI Class Initialized
INFO - 2023-02-16 03:46:58 --> Router Class Initialized
INFO - 2023-02-16 03:46:58 --> Output Class Initialized
INFO - 2023-02-16 03:46:58 --> Security Class Initialized
DEBUG - 2023-02-16 03:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:46:58 --> Input Class Initialized
INFO - 2023-02-16 03:46:58 --> Language Class Initialized
INFO - 2023-02-16 03:46:58 --> Loader Class Initialized
INFO - 2023-02-16 03:46:58 --> Controller Class Initialized
DEBUG - 2023-02-16 03:46:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:46:58 --> Database Driver Class Initialized
INFO - 2023-02-16 03:46:58 --> Model "Login_model" initialized
INFO - 2023-02-16 03:46:58 --> Database Driver Class Initialized
INFO - 2023-02-16 03:46:58 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:46:58 --> Final output sent to browser
DEBUG - 2023-02-16 03:46:58 --> Total execution time: 0.0394
INFO - 2023-02-16 03:47:58 --> Config Class Initialized
INFO - 2023-02-16 03:47:58 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:47:58 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:47:58 --> Utf8 Class Initialized
INFO - 2023-02-16 03:47:58 --> URI Class Initialized
INFO - 2023-02-16 03:47:58 --> Router Class Initialized
INFO - 2023-02-16 03:47:58 --> Output Class Initialized
INFO - 2023-02-16 03:47:58 --> Security Class Initialized
DEBUG - 2023-02-16 03:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:47:58 --> Input Class Initialized
INFO - 2023-02-16 03:47:58 --> Language Class Initialized
INFO - 2023-02-16 03:47:58 --> Loader Class Initialized
INFO - 2023-02-16 03:47:58 --> Controller Class Initialized
DEBUG - 2023-02-16 03:47:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:47:58 --> Database Driver Class Initialized
ERROR - 2023-02-16 03:48:08 --> Unable to connect to the database
INFO - 2023-02-16 03:48:08 --> Model "Login_model" initialized
INFO - 2023-02-16 03:48:09 --> Database Driver Class Initialized
INFO - 2023-02-16 03:48:09 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:48:09 --> Final output sent to browser
DEBUG - 2023-02-16 03:48:09 --> Total execution time: 11.0433
INFO - 2023-02-16 03:48:09 --> Config Class Initialized
INFO - 2023-02-16 03:48:09 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:48:09 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:48:09 --> Utf8 Class Initialized
INFO - 2023-02-16 03:48:09 --> URI Class Initialized
INFO - 2023-02-16 03:48:09 --> Router Class Initialized
INFO - 2023-02-16 03:48:09 --> Output Class Initialized
INFO - 2023-02-16 03:48:09 --> Security Class Initialized
DEBUG - 2023-02-16 03:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:48:09 --> Input Class Initialized
INFO - 2023-02-16 03:48:09 --> Language Class Initialized
INFO - 2023-02-16 03:48:09 --> Loader Class Initialized
INFO - 2023-02-16 03:48:09 --> Controller Class Initialized
DEBUG - 2023-02-16 03:48:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:48:09 --> Database Driver Class Initialized
INFO - 2023-02-16 03:48:09 --> Model "Login_model" initialized
INFO - 2023-02-16 03:48:09 --> Database Driver Class Initialized
INFO - 2023-02-16 03:48:09 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:48:09 --> Final output sent to browser
DEBUG - 2023-02-16 03:48:09 --> Total execution time: 0.0295
INFO - 2023-02-16 03:48:49 --> Config Class Initialized
INFO - 2023-02-16 03:48:49 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:48:49 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:48:49 --> Utf8 Class Initialized
INFO - 2023-02-16 03:48:49 --> URI Class Initialized
INFO - 2023-02-16 03:48:49 --> Router Class Initialized
INFO - 2023-02-16 03:48:49 --> Output Class Initialized
INFO - 2023-02-16 03:48:49 --> Security Class Initialized
DEBUG - 2023-02-16 03:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:48:49 --> Input Class Initialized
INFO - 2023-02-16 03:48:49 --> Language Class Initialized
INFO - 2023-02-16 03:48:49 --> Loader Class Initialized
INFO - 2023-02-16 03:48:49 --> Controller Class Initialized
DEBUG - 2023-02-16 03:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:48:49 --> Database Driver Class Initialized
INFO - 2023-02-16 03:48:49 --> Model "Login_model" initialized
INFO - 2023-02-16 03:48:49 --> Database Driver Class Initialized
INFO - 2023-02-16 03:48:49 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:48:49 --> Final output sent to browser
DEBUG - 2023-02-16 03:48:49 --> Total execution time: 0.0334
INFO - 2023-02-16 03:48:49 --> Config Class Initialized
INFO - 2023-02-16 03:48:49 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:48:49 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:48:49 --> Utf8 Class Initialized
INFO - 2023-02-16 03:48:49 --> URI Class Initialized
INFO - 2023-02-16 03:48:49 --> Router Class Initialized
INFO - 2023-02-16 03:48:49 --> Output Class Initialized
INFO - 2023-02-16 03:48:49 --> Security Class Initialized
DEBUG - 2023-02-16 03:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:48:49 --> Input Class Initialized
INFO - 2023-02-16 03:48:49 --> Language Class Initialized
INFO - 2023-02-16 03:48:49 --> Loader Class Initialized
INFO - 2023-02-16 03:48:49 --> Controller Class Initialized
DEBUG - 2023-02-16 03:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:48:49 --> Database Driver Class Initialized
INFO - 2023-02-16 03:48:49 --> Model "Login_model" initialized
INFO - 2023-02-16 03:48:49 --> Database Driver Class Initialized
INFO - 2023-02-16 03:48:49 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:48:49 --> Final output sent to browser
DEBUG - 2023-02-16 03:48:49 --> Total execution time: 0.0549
INFO - 2023-02-16 03:49:54 --> Config Class Initialized
INFO - 2023-02-16 03:49:54 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:49:54 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:49:54 --> Utf8 Class Initialized
INFO - 2023-02-16 03:49:54 --> URI Class Initialized
INFO - 2023-02-16 03:49:54 --> Router Class Initialized
INFO - 2023-02-16 03:49:54 --> Output Class Initialized
INFO - 2023-02-16 03:49:54 --> Security Class Initialized
DEBUG - 2023-02-16 03:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:49:54 --> Input Class Initialized
INFO - 2023-02-16 03:49:54 --> Language Class Initialized
INFO - 2023-02-16 03:49:54 --> Loader Class Initialized
INFO - 2023-02-16 03:49:54 --> Controller Class Initialized
DEBUG - 2023-02-16 03:49:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:49:54 --> Database Driver Class Initialized
INFO - 2023-02-16 03:49:54 --> Model "Login_model" initialized
INFO - 2023-02-16 03:49:54 --> Database Driver Class Initialized
INFO - 2023-02-16 03:49:54 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:49:54 --> Final output sent to browser
DEBUG - 2023-02-16 03:49:54 --> Total execution time: 0.0402
INFO - 2023-02-16 03:49:54 --> Config Class Initialized
INFO - 2023-02-16 03:49:54 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:49:54 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:49:54 --> Utf8 Class Initialized
INFO - 2023-02-16 03:49:54 --> URI Class Initialized
INFO - 2023-02-16 03:49:54 --> Router Class Initialized
INFO - 2023-02-16 03:49:54 --> Output Class Initialized
INFO - 2023-02-16 03:49:54 --> Security Class Initialized
DEBUG - 2023-02-16 03:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:49:54 --> Input Class Initialized
INFO - 2023-02-16 03:49:54 --> Language Class Initialized
INFO - 2023-02-16 03:49:54 --> Loader Class Initialized
INFO - 2023-02-16 03:49:54 --> Controller Class Initialized
DEBUG - 2023-02-16 03:49:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:49:54 --> Database Driver Class Initialized
INFO - 2023-02-16 03:49:54 --> Model "Login_model" initialized
INFO - 2023-02-16 03:49:54 --> Database Driver Class Initialized
INFO - 2023-02-16 03:49:54 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:49:54 --> Final output sent to browser
DEBUG - 2023-02-16 03:49:54 --> Total execution time: 0.0399
INFO - 2023-02-16 03:50:54 --> Config Class Initialized
INFO - 2023-02-16 03:50:54 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:50:54 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:50:54 --> Utf8 Class Initialized
INFO - 2023-02-16 03:50:54 --> URI Class Initialized
INFO - 2023-02-16 03:50:54 --> Router Class Initialized
INFO - 2023-02-16 03:50:54 --> Output Class Initialized
INFO - 2023-02-16 03:50:54 --> Security Class Initialized
DEBUG - 2023-02-16 03:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:50:54 --> Input Class Initialized
INFO - 2023-02-16 03:50:54 --> Language Class Initialized
INFO - 2023-02-16 03:50:54 --> Loader Class Initialized
INFO - 2023-02-16 03:50:54 --> Controller Class Initialized
DEBUG - 2023-02-16 03:50:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:50:54 --> Database Driver Class Initialized
INFO - 2023-02-16 03:50:54 --> Model "Login_model" initialized
INFO - 2023-02-16 03:50:54 --> Database Driver Class Initialized
INFO - 2023-02-16 03:50:54 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:50:54 --> Final output sent to browser
DEBUG - 2023-02-16 03:50:54 --> Total execution time: 0.0362
INFO - 2023-02-16 03:50:54 --> Config Class Initialized
INFO - 2023-02-16 03:50:54 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:50:54 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:50:54 --> Utf8 Class Initialized
INFO - 2023-02-16 03:50:54 --> URI Class Initialized
INFO - 2023-02-16 03:50:54 --> Router Class Initialized
INFO - 2023-02-16 03:50:54 --> Output Class Initialized
INFO - 2023-02-16 03:50:54 --> Security Class Initialized
DEBUG - 2023-02-16 03:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:50:54 --> Input Class Initialized
INFO - 2023-02-16 03:50:54 --> Language Class Initialized
INFO - 2023-02-16 03:50:54 --> Loader Class Initialized
INFO - 2023-02-16 03:50:54 --> Controller Class Initialized
DEBUG - 2023-02-16 03:50:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:50:54 --> Database Driver Class Initialized
INFO - 2023-02-16 03:50:54 --> Model "Login_model" initialized
INFO - 2023-02-16 03:50:54 --> Database Driver Class Initialized
INFO - 2023-02-16 03:50:54 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:50:54 --> Final output sent to browser
DEBUG - 2023-02-16 03:50:54 --> Total execution time: 0.0820
INFO - 2023-02-16 03:51:55 --> Config Class Initialized
INFO - 2023-02-16 03:51:55 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:51:55 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:51:55 --> Utf8 Class Initialized
INFO - 2023-02-16 03:51:55 --> URI Class Initialized
INFO - 2023-02-16 03:51:55 --> Router Class Initialized
INFO - 2023-02-16 03:51:55 --> Output Class Initialized
INFO - 2023-02-16 03:51:55 --> Security Class Initialized
DEBUG - 2023-02-16 03:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:51:55 --> Input Class Initialized
INFO - 2023-02-16 03:51:55 --> Language Class Initialized
INFO - 2023-02-16 03:51:55 --> Loader Class Initialized
INFO - 2023-02-16 03:51:55 --> Controller Class Initialized
DEBUG - 2023-02-16 03:51:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:51:55 --> Database Driver Class Initialized
INFO - 2023-02-16 03:51:55 --> Model "Login_model" initialized
INFO - 2023-02-16 03:51:55 --> Database Driver Class Initialized
INFO - 2023-02-16 03:51:55 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:51:55 --> Final output sent to browser
DEBUG - 2023-02-16 03:51:55 --> Total execution time: 0.0338
INFO - 2023-02-16 03:51:55 --> Config Class Initialized
INFO - 2023-02-16 03:51:55 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:51:55 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:51:55 --> Utf8 Class Initialized
INFO - 2023-02-16 03:51:55 --> URI Class Initialized
INFO - 2023-02-16 03:51:55 --> Router Class Initialized
INFO - 2023-02-16 03:51:55 --> Output Class Initialized
INFO - 2023-02-16 03:51:55 --> Security Class Initialized
DEBUG - 2023-02-16 03:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:51:55 --> Input Class Initialized
INFO - 2023-02-16 03:51:55 --> Language Class Initialized
INFO - 2023-02-16 03:51:55 --> Loader Class Initialized
INFO - 2023-02-16 03:51:55 --> Controller Class Initialized
DEBUG - 2023-02-16 03:51:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:51:55 --> Database Driver Class Initialized
INFO - 2023-02-16 03:51:55 --> Model "Login_model" initialized
INFO - 2023-02-16 03:51:55 --> Database Driver Class Initialized
INFO - 2023-02-16 03:51:55 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:51:55 --> Final output sent to browser
DEBUG - 2023-02-16 03:51:55 --> Total execution time: 0.0760
INFO - 2023-02-16 03:53:13 --> Config Class Initialized
INFO - 2023-02-16 03:53:13 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:53:13 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:53:13 --> Utf8 Class Initialized
INFO - 2023-02-16 03:53:13 --> URI Class Initialized
INFO - 2023-02-16 03:53:13 --> Router Class Initialized
INFO - 2023-02-16 03:53:13 --> Output Class Initialized
INFO - 2023-02-16 03:53:13 --> Security Class Initialized
DEBUG - 2023-02-16 03:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:53:13 --> Input Class Initialized
INFO - 2023-02-16 03:53:13 --> Language Class Initialized
INFO - 2023-02-16 03:53:13 --> Loader Class Initialized
INFO - 2023-02-16 03:53:13 --> Controller Class Initialized
DEBUG - 2023-02-16 03:53:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:53:13 --> Database Driver Class Initialized
INFO - 2023-02-16 03:53:13 --> Model "Login_model" initialized
INFO - 2023-02-16 03:53:13 --> Database Driver Class Initialized
INFO - 2023-02-16 03:53:13 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:53:13 --> Final output sent to browser
DEBUG - 2023-02-16 03:53:13 --> Total execution time: 0.0385
INFO - 2023-02-16 03:53:13 --> Config Class Initialized
INFO - 2023-02-16 03:53:13 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:53:13 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:53:13 --> Utf8 Class Initialized
INFO - 2023-02-16 03:53:13 --> URI Class Initialized
INFO - 2023-02-16 03:53:13 --> Router Class Initialized
INFO - 2023-02-16 03:53:13 --> Output Class Initialized
INFO - 2023-02-16 03:53:13 --> Security Class Initialized
DEBUG - 2023-02-16 03:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:53:13 --> Input Class Initialized
INFO - 2023-02-16 03:53:13 --> Language Class Initialized
INFO - 2023-02-16 03:53:13 --> Loader Class Initialized
INFO - 2023-02-16 03:53:13 --> Controller Class Initialized
DEBUG - 2023-02-16 03:53:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:53:13 --> Database Driver Class Initialized
INFO - 2023-02-16 03:53:13 --> Model "Login_model" initialized
INFO - 2023-02-16 03:53:13 --> Database Driver Class Initialized
INFO - 2023-02-16 03:53:13 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:53:13 --> Final output sent to browser
DEBUG - 2023-02-16 03:53:13 --> Total execution time: 0.0303
INFO - 2023-02-16 03:53:47 --> Config Class Initialized
INFO - 2023-02-16 03:53:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:53:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:53:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:53:47 --> URI Class Initialized
INFO - 2023-02-16 03:53:47 --> Router Class Initialized
INFO - 2023-02-16 03:53:47 --> Output Class Initialized
INFO - 2023-02-16 03:53:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:53:47 --> Input Class Initialized
INFO - 2023-02-16 03:53:47 --> Language Class Initialized
INFO - 2023-02-16 03:53:47 --> Loader Class Initialized
INFO - 2023-02-16 03:53:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:53:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:53:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:53:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:53:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:53:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:53:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:53:47 --> Total execution time: 0.0365
INFO - 2023-02-16 03:53:47 --> Config Class Initialized
INFO - 2023-02-16 03:53:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:53:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:53:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:53:47 --> URI Class Initialized
INFO - 2023-02-16 03:53:47 --> Router Class Initialized
INFO - 2023-02-16 03:53:47 --> Output Class Initialized
INFO - 2023-02-16 03:53:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:53:47 --> Input Class Initialized
INFO - 2023-02-16 03:53:47 --> Language Class Initialized
INFO - 2023-02-16 03:53:47 --> Loader Class Initialized
INFO - 2023-02-16 03:53:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:53:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:53:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:53:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:53:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:53:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:53:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:53:47 --> Total execution time: 0.0325
INFO - 2023-02-16 03:54:47 --> Config Class Initialized
INFO - 2023-02-16 03:54:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:54:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:54:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:54:47 --> URI Class Initialized
INFO - 2023-02-16 03:54:47 --> Router Class Initialized
INFO - 2023-02-16 03:54:47 --> Output Class Initialized
INFO - 2023-02-16 03:54:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:54:47 --> Input Class Initialized
INFO - 2023-02-16 03:54:47 --> Language Class Initialized
INFO - 2023-02-16 03:54:47 --> Loader Class Initialized
INFO - 2023-02-16 03:54:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:54:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:54:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:54:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:54:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:54:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:54:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:54:47 --> Total execution time: 0.1208
INFO - 2023-02-16 03:54:47 --> Config Class Initialized
INFO - 2023-02-16 03:54:47 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:54:47 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:54:47 --> Utf8 Class Initialized
INFO - 2023-02-16 03:54:47 --> URI Class Initialized
INFO - 2023-02-16 03:54:47 --> Router Class Initialized
INFO - 2023-02-16 03:54:47 --> Output Class Initialized
INFO - 2023-02-16 03:54:47 --> Security Class Initialized
DEBUG - 2023-02-16 03:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:54:47 --> Input Class Initialized
INFO - 2023-02-16 03:54:47 --> Language Class Initialized
INFO - 2023-02-16 03:54:47 --> Loader Class Initialized
INFO - 2023-02-16 03:54:47 --> Controller Class Initialized
DEBUG - 2023-02-16 03:54:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:54:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:54:47 --> Model "Login_model" initialized
INFO - 2023-02-16 03:54:47 --> Database Driver Class Initialized
INFO - 2023-02-16 03:54:47 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:54:47 --> Final output sent to browser
DEBUG - 2023-02-16 03:54:47 --> Total execution time: 0.0373
INFO - 2023-02-16 03:55:16 --> Config Class Initialized
INFO - 2023-02-16 03:55:16 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:55:16 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:16 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:16 --> URI Class Initialized
INFO - 2023-02-16 03:55:16 --> Router Class Initialized
INFO - 2023-02-16 03:55:16 --> Output Class Initialized
INFO - 2023-02-16 03:55:16 --> Security Class Initialized
DEBUG - 2023-02-16 03:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:16 --> Input Class Initialized
INFO - 2023-02-16 03:55:16 --> Language Class Initialized
INFO - 2023-02-16 03:55:16 --> Loader Class Initialized
INFO - 2023-02-16 03:55:16 --> Controller Class Initialized
DEBUG - 2023-02-16 03:55:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:16 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:16 --> Model "Login_model" initialized
INFO - 2023-02-16 03:55:16 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:16 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:55:16 --> Final output sent to browser
DEBUG - 2023-02-16 03:55:16 --> Total execution time: 0.1501
INFO - 2023-02-16 03:55:16 --> Config Class Initialized
INFO - 2023-02-16 03:55:16 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:55:16 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:16 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:16 --> URI Class Initialized
INFO - 2023-02-16 03:55:16 --> Router Class Initialized
INFO - 2023-02-16 03:55:16 --> Output Class Initialized
INFO - 2023-02-16 03:55:16 --> Security Class Initialized
DEBUG - 2023-02-16 03:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:16 --> Input Class Initialized
INFO - 2023-02-16 03:55:16 --> Language Class Initialized
INFO - 2023-02-16 03:55:16 --> Loader Class Initialized
INFO - 2023-02-16 03:55:16 --> Controller Class Initialized
DEBUG - 2023-02-16 03:55:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:16 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:16 --> Model "Login_model" initialized
INFO - 2023-02-16 03:55:16 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:16 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:55:16 --> Final output sent to browser
DEBUG - 2023-02-16 03:55:16 --> Total execution time: 0.2132
INFO - 2023-02-16 03:55:18 --> Config Class Initialized
INFO - 2023-02-16 03:55:18 --> Config Class Initialized
INFO - 2023-02-16 03:55:18 --> Hooks Class Initialized
INFO - 2023-02-16 03:55:18 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2023-02-16 03:55:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:18 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:18 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:18 --> URI Class Initialized
INFO - 2023-02-16 03:55:18 --> URI Class Initialized
INFO - 2023-02-16 03:55:18 --> Router Class Initialized
INFO - 2023-02-16 03:55:18 --> Router Class Initialized
INFO - 2023-02-16 03:55:18 --> Output Class Initialized
INFO - 2023-02-16 03:55:18 --> Output Class Initialized
INFO - 2023-02-16 03:55:18 --> Security Class Initialized
INFO - 2023-02-16 03:55:18 --> Security Class Initialized
DEBUG - 2023-02-16 03:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-16 03:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:18 --> Input Class Initialized
INFO - 2023-02-16 03:55:18 --> Input Class Initialized
INFO - 2023-02-16 03:55:18 --> Language Class Initialized
INFO - 2023-02-16 03:55:18 --> Language Class Initialized
INFO - 2023-02-16 03:55:18 --> Loader Class Initialized
INFO - 2023-02-16 03:55:18 --> Loader Class Initialized
INFO - 2023-02-16 03:55:18 --> Controller Class Initialized
INFO - 2023-02-16 03:55:18 --> Controller Class Initialized
DEBUG - 2023-02-16 03:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-16 03:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:18 --> Final output sent to browser
INFO - 2023-02-16 03:55:18 --> Database Driver Class Initialized
DEBUG - 2023-02-16 03:55:18 --> Total execution time: 0.1247
INFO - 2023-02-16 03:55:18 --> Config Class Initialized
INFO - 2023-02-16 03:55:18 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:55:18 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:55:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:18 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:18 --> Final output sent to browser
INFO - 2023-02-16 03:55:18 --> URI Class Initialized
DEBUG - 2023-02-16 03:55:18 --> Total execution time: 0.2376
INFO - 2023-02-16 03:55:18 --> Router Class Initialized
INFO - 2023-02-16 03:55:18 --> Output Class Initialized
INFO - 2023-02-16 03:55:18 --> Security Class Initialized
INFO - 2023-02-16 03:55:18 --> Config Class Initialized
DEBUG - 2023-02-16 03:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:18 --> Hooks Class Initialized
INFO - 2023-02-16 03:55:18 --> Input Class Initialized
DEBUG - 2023-02-16 03:55:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:18 --> Language Class Initialized
INFO - 2023-02-16 03:55:18 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:18 --> Loader Class Initialized
INFO - 2023-02-16 03:55:18 --> URI Class Initialized
INFO - 2023-02-16 03:55:18 --> Controller Class Initialized
INFO - 2023-02-16 03:55:18 --> Router Class Initialized
DEBUG - 2023-02-16 03:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:18 --> Output Class Initialized
INFO - 2023-02-16 03:55:18 --> Security Class Initialized
INFO - 2023-02-16 03:55:18 --> Database Driver Class Initialized
DEBUG - 2023-02-16 03:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:18 --> Input Class Initialized
INFO - 2023-02-16 03:55:18 --> Language Class Initialized
INFO - 2023-02-16 03:55:18 --> Loader Class Initialized
INFO - 2023-02-16 03:55:18 --> Controller Class Initialized
DEBUG - 2023-02-16 03:55:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:18 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:18 --> Model "Login_model" initialized
INFO - 2023-02-16 03:55:18 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:55:18 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:18 --> Final output sent to browser
INFO - 2023-02-16 03:55:18 --> Model "Cluster_model" initialized
DEBUG - 2023-02-16 03:55:18 --> Total execution time: 0.1078
INFO - 2023-02-16 03:55:18 --> Final output sent to browser
DEBUG - 2023-02-16 03:55:18 --> Total execution time: 0.3008
INFO - 2023-02-16 03:55:21 --> Config Class Initialized
INFO - 2023-02-16 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:21 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:21 --> URI Class Initialized
INFO - 2023-02-16 03:55:21 --> Router Class Initialized
INFO - 2023-02-16 03:55:21 --> Output Class Initialized
INFO - 2023-02-16 03:55:21 --> Security Class Initialized
DEBUG - 2023-02-16 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:21 --> Input Class Initialized
INFO - 2023-02-16 03:55:21 --> Language Class Initialized
INFO - 2023-02-16 03:55:21 --> Loader Class Initialized
INFO - 2023-02-16 03:55:21 --> Controller Class Initialized
DEBUG - 2023-02-16 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:21 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:21 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:55:21 --> Final output sent to browser
INFO - 2023-02-16 03:55:21 --> Config Class Initialized
INFO - 2023-02-16 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:55:21 --> Total execution time: 0.2521
DEBUG - 2023-02-16 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:21 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:21 --> URI Class Initialized
INFO - 2023-02-16 03:55:21 --> Router Class Initialized
INFO - 2023-02-16 03:55:21 --> Output Class Initialized
INFO - 2023-02-16 03:55:21 --> Security Class Initialized
DEBUG - 2023-02-16 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:21 --> Input Class Initialized
INFO - 2023-02-16 03:55:21 --> Language Class Initialized
INFO - 2023-02-16 03:55:21 --> Loader Class Initialized
INFO - 2023-02-16 03:55:21 --> Controller Class Initialized
DEBUG - 2023-02-16 03:55:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:21 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:21 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:55:21 --> Final output sent to browser
DEBUG - 2023-02-16 03:55:22 --> Total execution time: 0.1561
INFO - 2023-02-16 03:55:25 --> Config Class Initialized
INFO - 2023-02-16 03:55:25 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:55:25 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:25 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:25 --> URI Class Initialized
INFO - 2023-02-16 03:55:25 --> Router Class Initialized
INFO - 2023-02-16 03:55:25 --> Output Class Initialized
INFO - 2023-02-16 03:55:25 --> Security Class Initialized
DEBUG - 2023-02-16 03:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:25 --> Input Class Initialized
INFO - 2023-02-16 03:55:25 --> Language Class Initialized
INFO - 2023-02-16 03:55:25 --> Loader Class Initialized
INFO - 2023-02-16 03:55:25 --> Controller Class Initialized
DEBUG - 2023-02-16 03:55:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:25 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:25 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:55:25 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:25 --> Model "Login_model" initialized
INFO - 2023-02-16 03:55:25 --> Final output sent to browser
DEBUG - 2023-02-16 03:55:25 --> Total execution time: 0.1276
INFO - 2023-02-16 03:55:25 --> Config Class Initialized
INFO - 2023-02-16 03:55:25 --> Hooks Class Initialized
DEBUG - 2023-02-16 03:55:25 --> UTF-8 Support Enabled
INFO - 2023-02-16 03:55:25 --> Utf8 Class Initialized
INFO - 2023-02-16 03:55:25 --> URI Class Initialized
INFO - 2023-02-16 03:55:25 --> Router Class Initialized
INFO - 2023-02-16 03:55:25 --> Output Class Initialized
INFO - 2023-02-16 03:55:25 --> Security Class Initialized
DEBUG - 2023-02-16 03:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 03:55:25 --> Input Class Initialized
INFO - 2023-02-16 03:55:25 --> Language Class Initialized
INFO - 2023-02-16 03:55:25 --> Loader Class Initialized
INFO - 2023-02-16 03:55:25 --> Controller Class Initialized
DEBUG - 2023-02-16 03:55:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 03:55:25 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:25 --> Model "Cluster_model" initialized
INFO - 2023-02-16 03:55:25 --> Database Driver Class Initialized
INFO - 2023-02-16 03:55:25 --> Model "Login_model" initialized
INFO - 2023-02-16 03:55:25 --> Final output sent to browser
DEBUG - 2023-02-16 03:55:25 --> Total execution time: 0.2293
INFO - 2023-02-16 04:21:35 --> Config Class Initialized
INFO - 2023-02-16 04:21:35 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:21:35 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:21:35 --> Utf8 Class Initialized
INFO - 2023-02-16 04:21:35 --> URI Class Initialized
INFO - 2023-02-16 04:21:35 --> Router Class Initialized
INFO - 2023-02-16 04:21:35 --> Output Class Initialized
INFO - 2023-02-16 04:21:35 --> Security Class Initialized
DEBUG - 2023-02-16 04:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:21:35 --> Input Class Initialized
INFO - 2023-02-16 04:21:35 --> Language Class Initialized
INFO - 2023-02-16 04:21:35 --> Loader Class Initialized
INFO - 2023-02-16 04:21:35 --> Controller Class Initialized
DEBUG - 2023-02-16 04:21:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:21:35 --> Database Driver Class Initialized
INFO - 2023-02-16 04:21:35 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:21:35 --> Database Driver Class Initialized
INFO - 2023-02-16 04:21:35 --> Model "Login_model" initialized
INFO - 2023-02-16 04:21:35 --> Final output sent to browser
DEBUG - 2023-02-16 04:21:35 --> Total execution time: 0.1372
INFO - 2023-02-16 04:21:35 --> Config Class Initialized
INFO - 2023-02-16 04:21:35 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:21:35 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:21:35 --> Utf8 Class Initialized
INFO - 2023-02-16 04:21:35 --> URI Class Initialized
INFO - 2023-02-16 04:21:35 --> Router Class Initialized
INFO - 2023-02-16 04:21:35 --> Output Class Initialized
INFO - 2023-02-16 04:21:35 --> Security Class Initialized
DEBUG - 2023-02-16 04:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:21:35 --> Input Class Initialized
INFO - 2023-02-16 04:21:35 --> Language Class Initialized
INFO - 2023-02-16 04:21:35 --> Loader Class Initialized
INFO - 2023-02-16 04:21:35 --> Controller Class Initialized
DEBUG - 2023-02-16 04:21:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:21:35 --> Database Driver Class Initialized
INFO - 2023-02-16 04:21:35 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:21:35 --> Database Driver Class Initialized
INFO - 2023-02-16 04:21:35 --> Model "Login_model" initialized
INFO - 2023-02-16 04:21:35 --> Final output sent to browser
DEBUG - 2023-02-16 04:21:35 --> Total execution time: 0.1002
INFO - 2023-02-16 04:31:13 --> Config Class Initialized
INFO - 2023-02-16 04:31:14 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:31:14 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:31:14 --> Utf8 Class Initialized
INFO - 2023-02-16 04:31:14 --> URI Class Initialized
INFO - 2023-02-16 04:31:14 --> Router Class Initialized
INFO - 2023-02-16 04:31:14 --> Output Class Initialized
INFO - 2023-02-16 04:31:14 --> Security Class Initialized
DEBUG - 2023-02-16 04:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:31:14 --> Input Class Initialized
INFO - 2023-02-16 04:31:14 --> Language Class Initialized
INFO - 2023-02-16 04:31:14 --> Loader Class Initialized
INFO - 2023-02-16 04:31:14 --> Controller Class Initialized
DEBUG - 2023-02-16 04:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:31:14 --> Database Driver Class Initialized
INFO - 2023-02-16 04:31:14 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:31:14 --> Database Driver Class Initialized
INFO - 2023-02-16 04:31:14 --> Model "Login_model" initialized
INFO - 2023-02-16 04:31:14 --> Final output sent to browser
DEBUG - 2023-02-16 04:31:14 --> Total execution time: 0.1413
INFO - 2023-02-16 04:31:14 --> Config Class Initialized
INFO - 2023-02-16 04:31:14 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:31:14 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:31:14 --> Utf8 Class Initialized
INFO - 2023-02-16 04:31:14 --> URI Class Initialized
INFO - 2023-02-16 04:31:14 --> Router Class Initialized
INFO - 2023-02-16 04:31:14 --> Output Class Initialized
INFO - 2023-02-16 04:31:14 --> Security Class Initialized
DEBUG - 2023-02-16 04:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:31:14 --> Input Class Initialized
INFO - 2023-02-16 04:31:14 --> Language Class Initialized
INFO - 2023-02-16 04:31:14 --> Loader Class Initialized
INFO - 2023-02-16 04:31:14 --> Controller Class Initialized
DEBUG - 2023-02-16 04:31:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:31:14 --> Database Driver Class Initialized
INFO - 2023-02-16 04:31:14 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:31:14 --> Database Driver Class Initialized
INFO - 2023-02-16 04:31:14 --> Model "Login_model" initialized
INFO - 2023-02-16 04:31:14 --> Final output sent to browser
DEBUG - 2023-02-16 04:31:14 --> Total execution time: 0.0938
INFO - 2023-02-16 04:40:52 --> Config Class Initialized
INFO - 2023-02-16 04:40:52 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:52 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:52 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:52 --> URI Class Initialized
INFO - 2023-02-16 04:40:52 --> Router Class Initialized
INFO - 2023-02-16 04:40:52 --> Output Class Initialized
INFO - 2023-02-16 04:40:52 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:52 --> Input Class Initialized
INFO - 2023-02-16 04:40:52 --> Language Class Initialized
INFO - 2023-02-16 04:40:52 --> Loader Class Initialized
INFO - 2023-02-16 04:40:52 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:52 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:52 --> Total execution time: 0.0299
INFO - 2023-02-16 04:40:52 --> Config Class Initialized
INFO - 2023-02-16 04:40:52 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:52 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:52 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:52 --> URI Class Initialized
INFO - 2023-02-16 04:40:52 --> Router Class Initialized
INFO - 2023-02-16 04:40:52 --> Output Class Initialized
INFO - 2023-02-16 04:40:52 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:52 --> Input Class Initialized
INFO - 2023-02-16 04:40:52 --> Language Class Initialized
INFO - 2023-02-16 04:40:52 --> Loader Class Initialized
INFO - 2023-02-16 04:40:52 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:52 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:52 --> Model "Login_model" initialized
INFO - 2023-02-16 04:40:52 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:52 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:40:52 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:52 --> Total execution time: 0.0259
INFO - 2023-02-16 04:40:52 --> Config Class Initialized
INFO - 2023-02-16 04:40:53 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:53 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:53 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:53 --> URI Class Initialized
INFO - 2023-02-16 04:40:53 --> Router Class Initialized
INFO - 2023-02-16 04:40:53 --> Output Class Initialized
INFO - 2023-02-16 04:40:53 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:53 --> Input Class Initialized
INFO - 2023-02-16 04:40:53 --> Language Class Initialized
INFO - 2023-02-16 04:40:53 --> Loader Class Initialized
INFO - 2023-02-16 04:40:53 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:53 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:53 --> Total execution time: 0.0527
INFO - 2023-02-16 04:40:53 --> Config Class Initialized
INFO - 2023-02-16 04:40:53 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:53 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:53 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:53 --> URI Class Initialized
INFO - 2023-02-16 04:40:53 --> Router Class Initialized
INFO - 2023-02-16 04:40:53 --> Output Class Initialized
INFO - 2023-02-16 04:40:53 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:53 --> Input Class Initialized
INFO - 2023-02-16 04:40:53 --> Language Class Initialized
INFO - 2023-02-16 04:40:53 --> Loader Class Initialized
INFO - 2023-02-16 04:40:53 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:53 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:53 --> Model "Login_model" initialized
INFO - 2023-02-16 04:40:53 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:53 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:40:53 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:53 --> Total execution time: 0.0376
INFO - 2023-02-16 04:40:54 --> Config Class Initialized
INFO - 2023-02-16 04:40:54 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:54 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:54 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:54 --> URI Class Initialized
INFO - 2023-02-16 04:40:54 --> Router Class Initialized
INFO - 2023-02-16 04:40:54 --> Output Class Initialized
INFO - 2023-02-16 04:40:54 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:54 --> Input Class Initialized
INFO - 2023-02-16 04:40:54 --> Language Class Initialized
INFO - 2023-02-16 04:40:54 --> Loader Class Initialized
INFO - 2023-02-16 04:40:54 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:54 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:54 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:40:54 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:54 --> Total execution time: 0.0181
INFO - 2023-02-16 04:40:54 --> Config Class Initialized
INFO - 2023-02-16 04:40:54 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:54 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:54 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:54 --> URI Class Initialized
INFO - 2023-02-16 04:40:54 --> Router Class Initialized
INFO - 2023-02-16 04:40:54 --> Output Class Initialized
INFO - 2023-02-16 04:40:54 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:54 --> Input Class Initialized
INFO - 2023-02-16 04:40:54 --> Language Class Initialized
INFO - 2023-02-16 04:40:54 --> Loader Class Initialized
INFO - 2023-02-16 04:40:54 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:54 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:54 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:40:54 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:54 --> Total execution time: 0.0574
INFO - 2023-02-16 04:40:56 --> Config Class Initialized
INFO - 2023-02-16 04:40:56 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:56 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:56 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:56 --> URI Class Initialized
INFO - 2023-02-16 04:40:56 --> Router Class Initialized
INFO - 2023-02-16 04:40:56 --> Output Class Initialized
INFO - 2023-02-16 04:40:56 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:56 --> Input Class Initialized
INFO - 2023-02-16 04:40:56 --> Language Class Initialized
INFO - 2023-02-16 04:40:56 --> Loader Class Initialized
INFO - 2023-02-16 04:40:56 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:56 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:56 --> Total execution time: 0.0057
INFO - 2023-02-16 04:40:56 --> Config Class Initialized
INFO - 2023-02-16 04:40:56 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:56 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:56 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:56 --> URI Class Initialized
INFO - 2023-02-16 04:40:56 --> Router Class Initialized
INFO - 2023-02-16 04:40:56 --> Output Class Initialized
INFO - 2023-02-16 04:40:56 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:56 --> Input Class Initialized
INFO - 2023-02-16 04:40:56 --> Language Class Initialized
INFO - 2023-02-16 04:40:56 --> Loader Class Initialized
INFO - 2023-02-16 04:40:56 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:56 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:57 --> Model "Login_model" initialized
INFO - 2023-02-16 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:57 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:40:57 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:57 --> Total execution time: 0.0295
INFO - 2023-02-16 04:40:57 --> Config Class Initialized
INFO - 2023-02-16 04:40:57 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:57 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:57 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:57 --> URI Class Initialized
INFO - 2023-02-16 04:40:57 --> Router Class Initialized
INFO - 2023-02-16 04:40:57 --> Output Class Initialized
INFO - 2023-02-16 04:40:57 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:57 --> Input Class Initialized
INFO - 2023-02-16 04:40:57 --> Language Class Initialized
INFO - 2023-02-16 04:40:57 --> Loader Class Initialized
INFO - 2023-02-16 04:40:57 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:57 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:57 --> Total execution time: 0.1478
INFO - 2023-02-16 04:40:57 --> Config Class Initialized
INFO - 2023-02-16 04:40:57 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:57 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:57 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:57 --> URI Class Initialized
INFO - 2023-02-16 04:40:57 --> Router Class Initialized
INFO - 2023-02-16 04:40:57 --> Output Class Initialized
INFO - 2023-02-16 04:40:57 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:57 --> Input Class Initialized
INFO - 2023-02-16 04:40:57 --> Language Class Initialized
INFO - 2023-02-16 04:40:57 --> Loader Class Initialized
INFO - 2023-02-16 04:40:57 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:57 --> Model "Login_model" initialized
INFO - 2023-02-16 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:57 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:40:57 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:57 --> Total execution time: 0.0215
INFO - 2023-02-16 04:40:57 --> Config Class Initialized
INFO - 2023-02-16 04:40:57 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:57 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:57 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:57 --> URI Class Initialized
INFO - 2023-02-16 04:40:57 --> Router Class Initialized
INFO - 2023-02-16 04:40:57 --> Output Class Initialized
INFO - 2023-02-16 04:40:57 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:57 --> Input Class Initialized
INFO - 2023-02-16 04:40:57 --> Language Class Initialized
INFO - 2023-02-16 04:40:57 --> Loader Class Initialized
INFO - 2023-02-16 04:40:57 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:57 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:57 --> Model "Login_model" initialized
INFO - 2023-02-16 04:40:57 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:57 --> Total execution time: 0.0518
INFO - 2023-02-16 04:40:57 --> Config Class Initialized
INFO - 2023-02-16 04:40:57 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:40:57 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:40:57 --> Utf8 Class Initialized
INFO - 2023-02-16 04:40:57 --> URI Class Initialized
INFO - 2023-02-16 04:40:57 --> Router Class Initialized
INFO - 2023-02-16 04:40:57 --> Output Class Initialized
INFO - 2023-02-16 04:40:57 --> Security Class Initialized
DEBUG - 2023-02-16 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:40:57 --> Input Class Initialized
INFO - 2023-02-16 04:40:57 --> Language Class Initialized
INFO - 2023-02-16 04:40:57 --> Loader Class Initialized
INFO - 2023-02-16 04:40:57 --> Controller Class Initialized
DEBUG - 2023-02-16 04:40:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:57 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:40:57 --> Database Driver Class Initialized
INFO - 2023-02-16 04:40:57 --> Model "Login_model" initialized
INFO - 2023-02-16 04:40:57 --> Final output sent to browser
DEBUG - 2023-02-16 04:40:57 --> Total execution time: 0.1239
INFO - 2023-02-16 04:41:02 --> Config Class Initialized
INFO - 2023-02-16 04:41:02 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:02 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:02 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:02 --> URI Class Initialized
INFO - 2023-02-16 04:41:02 --> Router Class Initialized
INFO - 2023-02-16 04:41:02 --> Output Class Initialized
INFO - 2023-02-16 04:41:02 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:02 --> Input Class Initialized
INFO - 2023-02-16 04:41:02 --> Language Class Initialized
INFO - 2023-02-16 04:41:02 --> Loader Class Initialized
INFO - 2023-02-16 04:41:02 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:02 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:02 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:03 --> Final output sent to browser
INFO - 2023-02-16 04:41:03 --> Config Class Initialized
DEBUG - 2023-02-16 04:41:03 --> Total execution time: 0.0517
INFO - 2023-02-16 04:41:03 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:03 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:03 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:03 --> URI Class Initialized
INFO - 2023-02-16 04:41:03 --> Router Class Initialized
INFO - 2023-02-16 04:41:03 --> Output Class Initialized
INFO - 2023-02-16 04:41:03 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:03 --> Input Class Initialized
INFO - 2023-02-16 04:41:03 --> Language Class Initialized
INFO - 2023-02-16 04:41:03 --> Loader Class Initialized
INFO - 2023-02-16 04:41:03 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:03 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:03 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:03 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:03 --> Total execution time: 0.0843
INFO - 2023-02-16 04:41:06 --> Config Class Initialized
INFO - 2023-02-16 04:41:06 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:06 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:06 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:06 --> URI Class Initialized
INFO - 2023-02-16 04:41:06 --> Router Class Initialized
INFO - 2023-02-16 04:41:06 --> Output Class Initialized
INFO - 2023-02-16 04:41:06 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:06 --> Input Class Initialized
INFO - 2023-02-16 04:41:06 --> Language Class Initialized
INFO - 2023-02-16 04:41:06 --> Loader Class Initialized
INFO - 2023-02-16 04:41:06 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:06 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:06 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:06 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:06 --> Model "Login_model" initialized
INFO - 2023-02-16 04:41:06 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:06 --> Total execution time: 0.0429
INFO - 2023-02-16 04:41:06 --> Config Class Initialized
INFO - 2023-02-16 04:41:06 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:06 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:06 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:06 --> URI Class Initialized
INFO - 2023-02-16 04:41:06 --> Router Class Initialized
INFO - 2023-02-16 04:41:06 --> Output Class Initialized
INFO - 2023-02-16 04:41:06 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:06 --> Input Class Initialized
INFO - 2023-02-16 04:41:06 --> Language Class Initialized
INFO - 2023-02-16 04:41:06 --> Loader Class Initialized
INFO - 2023-02-16 04:41:06 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:06 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:06 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:06 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:06 --> Model "Login_model" initialized
INFO - 2023-02-16 04:41:07 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:07 --> Total execution time: 0.0356
INFO - 2023-02-16 04:41:08 --> Config Class Initialized
INFO - 2023-02-16 04:41:08 --> Config Class Initialized
INFO - 2023-02-16 04:41:08 --> Hooks Class Initialized
INFO - 2023-02-16 04:41:08 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-02-16 04:41:08 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:08 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:08 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:08 --> URI Class Initialized
INFO - 2023-02-16 04:41:08 --> URI Class Initialized
INFO - 2023-02-16 04:41:08 --> Router Class Initialized
INFO - 2023-02-16 04:41:08 --> Router Class Initialized
INFO - 2023-02-16 04:41:08 --> Output Class Initialized
INFO - 2023-02-16 04:41:08 --> Output Class Initialized
INFO - 2023-02-16 04:41:08 --> Security Class Initialized
INFO - 2023-02-16 04:41:08 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-16 04:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:08 --> Input Class Initialized
INFO - 2023-02-16 04:41:08 --> Input Class Initialized
INFO - 2023-02-16 04:41:08 --> Language Class Initialized
INFO - 2023-02-16 04:41:08 --> Language Class Initialized
INFO - 2023-02-16 04:41:08 --> Loader Class Initialized
INFO - 2023-02-16 04:41:08 --> Loader Class Initialized
INFO - 2023-02-16 04:41:08 --> Controller Class Initialized
INFO - 2023-02-16 04:41:08 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-16 04:41:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:08 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:08 --> Total execution time: 0.0048
INFO - 2023-02-16 04:41:08 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:08 --> Config Class Initialized
INFO - 2023-02-16 04:41:08 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:08 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:08 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:08 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:08 --> URI Class Initialized
INFO - 2023-02-16 04:41:08 --> Router Class Initialized
INFO - 2023-02-16 04:41:08 --> Output Class Initialized
INFO - 2023-02-16 04:41:08 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:08 --> Input Class Initialized
INFO - 2023-02-16 04:41:08 --> Language Class Initialized
INFO - 2023-02-16 04:41:08 --> Loader Class Initialized
INFO - 2023-02-16 04:41:08 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:08 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:08 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:08 --> Total execution time: 0.0540
INFO - 2023-02-16 04:41:08 --> Config Class Initialized
INFO - 2023-02-16 04:41:08 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:08 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:08 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:08 --> URI Class Initialized
INFO - 2023-02-16 04:41:08 --> Router Class Initialized
INFO - 2023-02-16 04:41:08 --> Output Class Initialized
INFO - 2023-02-16 04:41:08 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:08 --> Input Class Initialized
INFO - 2023-02-16 04:41:08 --> Language Class Initialized
INFO - 2023-02-16 04:41:08 --> Loader Class Initialized
INFO - 2023-02-16 04:41:08 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:08 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:08 --> Model "Login_model" initialized
INFO - 2023-02-16 04:41:08 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:08 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:08 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:08 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:08 --> Total execution time: 0.0129
INFO - 2023-02-16 04:41:08 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:08 --> Total execution time: 0.0628
INFO - 2023-02-16 04:41:10 --> Config Class Initialized
INFO - 2023-02-16 04:41:10 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:10 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:10 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:10 --> URI Class Initialized
INFO - 2023-02-16 04:41:10 --> Router Class Initialized
INFO - 2023-02-16 04:41:10 --> Output Class Initialized
INFO - 2023-02-16 04:41:10 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:10 --> Input Class Initialized
INFO - 2023-02-16 04:41:10 --> Language Class Initialized
INFO - 2023-02-16 04:41:10 --> Loader Class Initialized
INFO - 2023-02-16 04:41:10 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:10 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:10 --> Total execution time: 0.0041
INFO - 2023-02-16 04:41:10 --> Config Class Initialized
INFO - 2023-02-16 04:41:10 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:10 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:10 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:10 --> URI Class Initialized
INFO - 2023-02-16 04:41:10 --> Router Class Initialized
INFO - 2023-02-16 04:41:10 --> Output Class Initialized
INFO - 2023-02-16 04:41:10 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:10 --> Input Class Initialized
INFO - 2023-02-16 04:41:10 --> Language Class Initialized
INFO - 2023-02-16 04:41:10 --> Loader Class Initialized
INFO - 2023-02-16 04:41:10 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:10 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:10 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:10 --> Model "Node_model" initialized
INFO - 2023-02-16 04:41:10 --> Model "Grafana_model" initialized
INFO - 2023-02-16 04:41:10 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:10 --> Total execution time: 0.0320
INFO - 2023-02-16 04:41:11 --> Config Class Initialized
INFO - 2023-02-16 04:41:11 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:11 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:11 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:11 --> URI Class Initialized
INFO - 2023-02-16 04:41:11 --> Router Class Initialized
INFO - 2023-02-16 04:41:11 --> Output Class Initialized
INFO - 2023-02-16 04:41:11 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:11 --> Input Class Initialized
INFO - 2023-02-16 04:41:11 --> Language Class Initialized
INFO - 2023-02-16 04:41:11 --> Loader Class Initialized
INFO - 2023-02-16 04:41:11 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:11 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:11 --> Total execution time: 0.0038
INFO - 2023-02-16 04:41:11 --> Config Class Initialized
INFO - 2023-02-16 04:41:11 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:11 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:11 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:11 --> URI Class Initialized
INFO - 2023-02-16 04:41:11 --> Router Class Initialized
INFO - 2023-02-16 04:41:11 --> Output Class Initialized
INFO - 2023-02-16 04:41:11 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:11 --> Input Class Initialized
INFO - 2023-02-16 04:41:11 --> Language Class Initialized
INFO - 2023-02-16 04:41:11 --> Loader Class Initialized
INFO - 2023-02-16 04:41:11 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:11 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:11 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:11 --> Model "Node_model" initialized
INFO - 2023-02-16 04:41:11 --> Model "Grafana_model" initialized
INFO - 2023-02-16 04:41:11 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:11 --> Total execution time: 0.0148
INFO - 2023-02-16 04:41:12 --> Config Class Initialized
INFO - 2023-02-16 04:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:12 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:12 --> URI Class Initialized
INFO - 2023-02-16 04:41:12 --> Router Class Initialized
INFO - 2023-02-16 04:41:12 --> Output Class Initialized
INFO - 2023-02-16 04:41:12 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:12 --> Input Class Initialized
INFO - 2023-02-16 04:41:12 --> Language Class Initialized
INFO - 2023-02-16 04:41:12 --> Loader Class Initialized
INFO - 2023-02-16 04:41:12 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:12 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:12 --> Total execution time: 0.0034
INFO - 2023-02-16 04:41:12 --> Config Class Initialized
INFO - 2023-02-16 04:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:12 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:12 --> URI Class Initialized
INFO - 2023-02-16 04:41:12 --> Router Class Initialized
INFO - 2023-02-16 04:41:12 --> Output Class Initialized
INFO - 2023-02-16 04:41:12 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:12 --> Input Class Initialized
INFO - 2023-02-16 04:41:12 --> Language Class Initialized
INFO - 2023-02-16 04:41:12 --> Loader Class Initialized
INFO - 2023-02-16 04:41:12 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:12 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:12 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:12 --> Model "Node_model" initialized
INFO - 2023-02-16 04:41:12 --> Model "Grafana_model" initialized
INFO - 2023-02-16 04:41:12 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:12 --> Total execution time: 0.0150
INFO - 2023-02-16 04:41:12 --> Config Class Initialized
INFO - 2023-02-16 04:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:12 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:12 --> URI Class Initialized
INFO - 2023-02-16 04:41:12 --> Router Class Initialized
INFO - 2023-02-16 04:41:12 --> Output Class Initialized
INFO - 2023-02-16 04:41:12 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:12 --> Input Class Initialized
INFO - 2023-02-16 04:41:12 --> Language Class Initialized
INFO - 2023-02-16 04:41:12 --> Loader Class Initialized
INFO - 2023-02-16 04:41:12 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:12 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:12 --> Total execution time: 0.0085
INFO - 2023-02-16 04:41:12 --> Config Class Initialized
INFO - 2023-02-16 04:41:12 --> Hooks Class Initialized
DEBUG - 2023-02-16 04:41:12 --> UTF-8 Support Enabled
INFO - 2023-02-16 04:41:12 --> Utf8 Class Initialized
INFO - 2023-02-16 04:41:12 --> URI Class Initialized
INFO - 2023-02-16 04:41:12 --> Router Class Initialized
INFO - 2023-02-16 04:41:12 --> Output Class Initialized
INFO - 2023-02-16 04:41:12 --> Security Class Initialized
DEBUG - 2023-02-16 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 04:41:12 --> Input Class Initialized
INFO - 2023-02-16 04:41:12 --> Language Class Initialized
INFO - 2023-02-16 04:41:12 --> Loader Class Initialized
INFO - 2023-02-16 04:41:12 --> Controller Class Initialized
DEBUG - 2023-02-16 04:41:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 04:41:12 --> Database Driver Class Initialized
INFO - 2023-02-16 04:41:12 --> Model "Cluster_model" initialized
INFO - 2023-02-16 04:41:12 --> Model "Node_model" initialized
INFO - 2023-02-16 04:41:12 --> Model "Grafana_model" initialized
INFO - 2023-02-16 04:41:12 --> Final output sent to browser
DEBUG - 2023-02-16 04:41:12 --> Total execution time: 0.0144
INFO - 2023-02-16 06:02:38 --> Config Class Initialized
INFO - 2023-02-16 06:02:38 --> Hooks Class Initialized
DEBUG - 2023-02-16 06:02:38 --> UTF-8 Support Enabled
INFO - 2023-02-16 06:02:38 --> Utf8 Class Initialized
INFO - 2023-02-16 06:02:38 --> URI Class Initialized
INFO - 2023-02-16 06:02:38 --> Router Class Initialized
INFO - 2023-02-16 06:02:38 --> Output Class Initialized
INFO - 2023-02-16 06:02:38 --> Security Class Initialized
DEBUG - 2023-02-16 06:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 06:02:38 --> Input Class Initialized
INFO - 2023-02-16 06:02:38 --> Language Class Initialized
INFO - 2023-02-16 06:02:38 --> Loader Class Initialized
INFO - 2023-02-16 06:02:38 --> Controller Class Initialized
DEBUG - 2023-02-16 06:02:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 06:02:38 --> Database Driver Class Initialized
INFO - 2023-02-16 06:02:38 --> Model "Cluster_model" initialized
INFO - 2023-02-16 06:02:38 --> Final output sent to browser
DEBUG - 2023-02-16 06:02:38 --> Total execution time: 0.0291
INFO - 2023-02-16 06:02:38 --> Config Class Initialized
INFO - 2023-02-16 06:02:38 --> Hooks Class Initialized
DEBUG - 2023-02-16 06:02:38 --> UTF-8 Support Enabled
INFO - 2023-02-16 06:02:38 --> Utf8 Class Initialized
INFO - 2023-02-16 06:02:38 --> URI Class Initialized
INFO - 2023-02-16 06:02:38 --> Router Class Initialized
INFO - 2023-02-16 06:02:38 --> Output Class Initialized
INFO - 2023-02-16 06:02:38 --> Security Class Initialized
DEBUG - 2023-02-16 06:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 06:02:38 --> Input Class Initialized
INFO - 2023-02-16 06:02:38 --> Language Class Initialized
INFO - 2023-02-16 06:02:38 --> Loader Class Initialized
INFO - 2023-02-16 06:02:38 --> Controller Class Initialized
DEBUG - 2023-02-16 06:02:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 06:02:38 --> Database Driver Class Initialized
INFO - 2023-02-16 06:02:38 --> Model "Cluster_model" initialized
INFO - 2023-02-16 06:02:38 --> Final output sent to browser
DEBUG - 2023-02-16 06:02:38 --> Total execution time: 0.0602
INFO - 2023-02-16 06:02:45 --> Config Class Initialized
INFO - 2023-02-16 06:02:45 --> Hooks Class Initialized
DEBUG - 2023-02-16 06:02:45 --> UTF-8 Support Enabled
INFO - 2023-02-16 06:02:45 --> Utf8 Class Initialized
INFO - 2023-02-16 06:02:45 --> URI Class Initialized
INFO - 2023-02-16 06:02:45 --> Router Class Initialized
INFO - 2023-02-16 06:02:45 --> Output Class Initialized
INFO - 2023-02-16 06:02:45 --> Security Class Initialized
DEBUG - 2023-02-16 06:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 06:02:45 --> Input Class Initialized
INFO - 2023-02-16 06:02:45 --> Language Class Initialized
INFO - 2023-02-16 06:02:45 --> Loader Class Initialized
INFO - 2023-02-16 06:02:45 --> Controller Class Initialized
DEBUG - 2023-02-16 06:02:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 06:02:45 --> Final output sent to browser
DEBUG - 2023-02-16 06:02:45 --> Total execution time: 0.0101
INFO - 2023-02-16 06:02:45 --> Config Class Initialized
INFO - 2023-02-16 06:02:45 --> Hooks Class Initialized
DEBUG - 2023-02-16 06:02:45 --> UTF-8 Support Enabled
INFO - 2023-02-16 06:02:45 --> Utf8 Class Initialized
INFO - 2023-02-16 06:02:45 --> URI Class Initialized
INFO - 2023-02-16 06:02:45 --> Router Class Initialized
INFO - 2023-02-16 06:02:45 --> Output Class Initialized
INFO - 2023-02-16 06:02:45 --> Security Class Initialized
DEBUG - 2023-02-16 06:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 06:02:45 --> Input Class Initialized
INFO - 2023-02-16 06:02:45 --> Language Class Initialized
INFO - 2023-02-16 06:02:45 --> Loader Class Initialized
INFO - 2023-02-16 06:02:45 --> Controller Class Initialized
DEBUG - 2023-02-16 06:02:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 06:02:45 --> Database Driver Class Initialized
INFO - 2023-02-16 06:02:45 --> Model "Login_model" initialized
INFO - 2023-02-16 06:02:45 --> Database Driver Class Initialized
INFO - 2023-02-16 06:02:45 --> Model "Cluster_model" initialized
INFO - 2023-02-16 06:02:45 --> Final output sent to browser
DEBUG - 2023-02-16 06:02:45 --> Total execution time: 0.0236
INFO - 2023-02-16 06:02:45 --> Config Class Initialized
INFO - 2023-02-16 06:02:45 --> Hooks Class Initialized
DEBUG - 2023-02-16 06:02:45 --> UTF-8 Support Enabled
INFO - 2023-02-16 06:02:45 --> Utf8 Class Initialized
INFO - 2023-02-16 06:02:45 --> URI Class Initialized
INFO - 2023-02-16 06:02:45 --> Router Class Initialized
INFO - 2023-02-16 06:02:45 --> Output Class Initialized
INFO - 2023-02-16 06:02:45 --> Security Class Initialized
DEBUG - 2023-02-16 06:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 06:02:45 --> Input Class Initialized
INFO - 2023-02-16 06:02:45 --> Language Class Initialized
INFO - 2023-02-16 06:02:45 --> Loader Class Initialized
INFO - 2023-02-16 06:02:45 --> Controller Class Initialized
DEBUG - 2023-02-16 06:02:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 06:02:45 --> Database Driver Class Initialized
INFO - 2023-02-16 06:02:45 --> Model "Cluster_model" initialized
INFO - 2023-02-16 06:02:45 --> Final output sent to browser
DEBUG - 2023-02-16 06:02:45 --> Total execution time: 0.0552
INFO - 2023-02-16 06:02:45 --> Config Class Initialized
INFO - 2023-02-16 06:02:45 --> Hooks Class Initialized
DEBUG - 2023-02-16 06:02:45 --> UTF-8 Support Enabled
INFO - 2023-02-16 06:02:45 --> Utf8 Class Initialized
INFO - 2023-02-16 06:02:45 --> URI Class Initialized
INFO - 2023-02-16 06:02:45 --> Router Class Initialized
INFO - 2023-02-16 06:02:45 --> Output Class Initialized
INFO - 2023-02-16 06:02:45 --> Security Class Initialized
DEBUG - 2023-02-16 06:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 06:02:45 --> Input Class Initialized
INFO - 2023-02-16 06:02:45 --> Language Class Initialized
INFO - 2023-02-16 06:02:45 --> Loader Class Initialized
INFO - 2023-02-16 06:02:45 --> Controller Class Initialized
DEBUG - 2023-02-16 06:02:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 06:02:45 --> Database Driver Class Initialized
INFO - 2023-02-16 06:02:45 --> Model "Cluster_model" initialized
INFO - 2023-02-16 06:02:45 --> Final output sent to browser
DEBUG - 2023-02-16 06:02:45 --> Total execution time: 0.0657
INFO - 2023-02-16 06:02:50 --> Config Class Initialized
INFO - 2023-02-16 06:02:50 --> Hooks Class Initialized
DEBUG - 2023-02-16 06:02:50 --> UTF-8 Support Enabled
INFO - 2023-02-16 06:02:50 --> Utf8 Class Initialized
INFO - 2023-02-16 06:02:50 --> URI Class Initialized
INFO - 2023-02-16 06:02:50 --> Router Class Initialized
INFO - 2023-02-16 06:02:50 --> Output Class Initialized
INFO - 2023-02-16 06:02:50 --> Security Class Initialized
DEBUG - 2023-02-16 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 06:02:50 --> Input Class Initialized
INFO - 2023-02-16 06:02:50 --> Language Class Initialized
INFO - 2023-02-16 06:02:50 --> Loader Class Initialized
INFO - 2023-02-16 06:02:50 --> Controller Class Initialized
DEBUG - 2023-02-16 06:02:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 06:02:50 --> Database Driver Class Initialized
INFO - 2023-02-16 06:02:50 --> Model "Cluster_model" initialized
INFO - 2023-02-16 06:02:50 --> Final output sent to browser
DEBUG - 2023-02-16 06:02:50 --> Total execution time: 0.0193
INFO - 2023-02-16 06:02:50 --> Config Class Initialized
INFO - 2023-02-16 06:02:50 --> Hooks Class Initialized
DEBUG - 2023-02-16 06:02:50 --> UTF-8 Support Enabled
INFO - 2023-02-16 06:02:50 --> Utf8 Class Initialized
INFO - 2023-02-16 06:02:50 --> URI Class Initialized
INFO - 2023-02-16 06:02:50 --> Router Class Initialized
INFO - 2023-02-16 06:02:50 --> Output Class Initialized
INFO - 2023-02-16 06:02:50 --> Security Class Initialized
DEBUG - 2023-02-16 06:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 06:02:50 --> Input Class Initialized
INFO - 2023-02-16 06:02:50 --> Language Class Initialized
INFO - 2023-02-16 06:02:50 --> Loader Class Initialized
INFO - 2023-02-16 06:02:50 --> Controller Class Initialized
DEBUG - 2023-02-16 06:02:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 06:02:50 --> Database Driver Class Initialized
INFO - 2023-02-16 06:02:50 --> Model "Cluster_model" initialized
INFO - 2023-02-16 06:02:50 --> Final output sent to browser
DEBUG - 2023-02-16 06:02:50 --> Total execution time: 0.0583
INFO - 2023-02-16 07:31:50 --> Config Class Initialized
INFO - 2023-02-16 07:31:50 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:31:50 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:31:50 --> Utf8 Class Initialized
INFO - 2023-02-16 07:31:50 --> URI Class Initialized
INFO - 2023-02-16 07:31:50 --> Router Class Initialized
INFO - 2023-02-16 07:31:50 --> Output Class Initialized
INFO - 2023-02-16 07:31:50 --> Security Class Initialized
DEBUG - 2023-02-16 07:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:31:50 --> Input Class Initialized
INFO - 2023-02-16 07:31:50 --> Language Class Initialized
INFO - 2023-02-16 07:31:50 --> Loader Class Initialized
INFO - 2023-02-16 07:31:50 --> Controller Class Initialized
DEBUG - 2023-02-16 07:31:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:31:50 --> Database Driver Class Initialized
INFO - 2023-02-16 07:31:51 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:31:51 --> Final output sent to browser
DEBUG - 2023-02-16 07:31:51 --> Total execution time: 1.1099
INFO - 2023-02-16 07:31:51 --> Config Class Initialized
INFO - 2023-02-16 07:31:51 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:31:51 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:31:51 --> Utf8 Class Initialized
INFO - 2023-02-16 07:31:51 --> URI Class Initialized
INFO - 2023-02-16 07:31:51 --> Router Class Initialized
INFO - 2023-02-16 07:31:51 --> Output Class Initialized
INFO - 2023-02-16 07:31:51 --> Security Class Initialized
DEBUG - 2023-02-16 07:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:31:51 --> Input Class Initialized
INFO - 2023-02-16 07:31:51 --> Language Class Initialized
INFO - 2023-02-16 07:31:51 --> Loader Class Initialized
INFO - 2023-02-16 07:31:51 --> Controller Class Initialized
DEBUG - 2023-02-16 07:31:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:31:51 --> Database Driver Class Initialized
INFO - 2023-02-16 07:31:51 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:31:51 --> Final output sent to browser
DEBUG - 2023-02-16 07:31:51 --> Total execution time: 0.0536
INFO - 2023-02-16 07:31:55 --> Config Class Initialized
INFO - 2023-02-16 07:31:55 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:31:55 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:31:55 --> Utf8 Class Initialized
INFO - 2023-02-16 07:31:55 --> URI Class Initialized
INFO - 2023-02-16 07:31:55 --> Router Class Initialized
INFO - 2023-02-16 07:31:55 --> Output Class Initialized
INFO - 2023-02-16 07:31:55 --> Security Class Initialized
DEBUG - 2023-02-16 07:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:31:55 --> Input Class Initialized
INFO - 2023-02-16 07:31:55 --> Language Class Initialized
INFO - 2023-02-16 07:31:55 --> Loader Class Initialized
INFO - 2023-02-16 07:31:55 --> Controller Class Initialized
DEBUG - 2023-02-16 07:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:31:55 --> Database Driver Class Initialized
INFO - 2023-02-16 07:31:55 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:31:55 --> Final output sent to browser
DEBUG - 2023-02-16 07:31:55 --> Total execution time: 0.1712
INFO - 2023-02-16 07:31:55 --> Config Class Initialized
INFO - 2023-02-16 07:31:55 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:31:55 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:31:55 --> Utf8 Class Initialized
INFO - 2023-02-16 07:31:55 --> URI Class Initialized
INFO - 2023-02-16 07:31:55 --> Router Class Initialized
INFO - 2023-02-16 07:31:55 --> Output Class Initialized
INFO - 2023-02-16 07:31:55 --> Security Class Initialized
DEBUG - 2023-02-16 07:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:31:55 --> Input Class Initialized
INFO - 2023-02-16 07:31:55 --> Language Class Initialized
INFO - 2023-02-16 07:31:55 --> Loader Class Initialized
INFO - 2023-02-16 07:31:55 --> Controller Class Initialized
DEBUG - 2023-02-16 07:31:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:31:55 --> Database Driver Class Initialized
INFO - 2023-02-16 07:31:55 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:31:55 --> Final output sent to browser
DEBUG - 2023-02-16 07:31:55 --> Total execution time: 0.0644
INFO - 2023-02-16 07:31:58 --> Config Class Initialized
INFO - 2023-02-16 07:31:58 --> Config Class Initialized
INFO - 2023-02-16 07:31:58 --> Hooks Class Initialized
INFO - 2023-02-16 07:31:58 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:31:58 --> Utf8 Class Initialized
DEBUG - 2023-02-16 07:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:31:58 --> URI Class Initialized
INFO - 2023-02-16 07:31:58 --> Utf8 Class Initialized
INFO - 2023-02-16 07:31:58 --> URI Class Initialized
INFO - 2023-02-16 07:31:58 --> Router Class Initialized
INFO - 2023-02-16 07:31:58 --> Router Class Initialized
INFO - 2023-02-16 07:31:58 --> Output Class Initialized
INFO - 2023-02-16 07:31:58 --> Output Class Initialized
INFO - 2023-02-16 07:31:58 --> Security Class Initialized
INFO - 2023-02-16 07:31:58 --> Security Class Initialized
DEBUG - 2023-02-16 07:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-16 07:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:31:58 --> Input Class Initialized
INFO - 2023-02-16 07:31:58 --> Input Class Initialized
INFO - 2023-02-16 07:31:58 --> Language Class Initialized
INFO - 2023-02-16 07:31:58 --> Language Class Initialized
INFO - 2023-02-16 07:31:58 --> Loader Class Initialized
INFO - 2023-02-16 07:31:58 --> Loader Class Initialized
INFO - 2023-02-16 07:31:58 --> Controller Class Initialized
INFO - 2023-02-16 07:31:58 --> Controller Class Initialized
DEBUG - 2023-02-16 07:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-16 07:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:31:58 --> Database Driver Class Initialized
INFO - 2023-02-16 07:31:58 --> Final output sent to browser
DEBUG - 2023-02-16 07:31:58 --> Total execution time: 0.0054
INFO - 2023-02-16 07:31:58 --> Config Class Initialized
INFO - 2023-02-16 07:31:58 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:31:58 --> Utf8 Class Initialized
INFO - 2023-02-16 07:31:58 --> URI Class Initialized
INFO - 2023-02-16 07:31:58 --> Router Class Initialized
INFO - 2023-02-16 07:31:58 --> Output Class Initialized
INFO - 2023-02-16 07:31:58 --> Security Class Initialized
DEBUG - 2023-02-16 07:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:31:58 --> Input Class Initialized
INFO - 2023-02-16 07:31:58 --> Language Class Initialized
INFO - 2023-02-16 07:31:58 --> Loader Class Initialized
INFO - 2023-02-16 07:31:58 --> Controller Class Initialized
DEBUG - 2023-02-16 07:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:31:58 --> Database Driver Class Initialized
INFO - 2023-02-16 07:31:58 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:31:58 --> Model "Login_model" initialized
INFO - 2023-02-16 07:31:58 --> Database Driver Class Initialized
INFO - 2023-02-16 07:31:58 --> Final output sent to browser
DEBUG - 2023-02-16 07:31:58 --> Total execution time: 0.0214
INFO - 2023-02-16 07:31:58 --> Config Class Initialized
INFO - 2023-02-16 07:31:58 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:31:58 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:31:58 --> Utf8 Class Initialized
INFO - 2023-02-16 07:31:58 --> URI Class Initialized
INFO - 2023-02-16 07:31:58 --> Router Class Initialized
INFO - 2023-02-16 07:31:58 --> Output Class Initialized
INFO - 2023-02-16 07:31:58 --> Security Class Initialized
DEBUG - 2023-02-16 07:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:31:58 --> Input Class Initialized
INFO - 2023-02-16 07:31:58 --> Language Class Initialized
INFO - 2023-02-16 07:31:58 --> Loader Class Initialized
INFO - 2023-02-16 07:31:58 --> Controller Class Initialized
DEBUG - 2023-02-16 07:31:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:31:58 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:31:58 --> Database Driver Class Initialized
INFO - 2023-02-16 07:31:58 --> Final output sent to browser
DEBUG - 2023-02-16 07:31:58 --> Total execution time: 0.0216
INFO - 2023-02-16 07:31:58 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:31:58 --> Final output sent to browser
DEBUG - 2023-02-16 07:31:58 --> Total execution time: 0.0566
INFO - 2023-02-16 07:38:41 --> Config Class Initialized
INFO - 2023-02-16 07:38:41 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:41 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:41 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:41 --> URI Class Initialized
INFO - 2023-02-16 07:38:41 --> Router Class Initialized
INFO - 2023-02-16 07:38:41 --> Output Class Initialized
INFO - 2023-02-16 07:38:41 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:41 --> Input Class Initialized
INFO - 2023-02-16 07:38:41 --> Language Class Initialized
INFO - 2023-02-16 07:38:41 --> Loader Class Initialized
INFO - 2023-02-16 07:38:41 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:41 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:41 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:41 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:41 --> Total execution time: 0.0479
INFO - 2023-02-16 07:38:41 --> Config Class Initialized
INFO - 2023-02-16 07:38:41 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:41 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:41 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:41 --> URI Class Initialized
INFO - 2023-02-16 07:38:41 --> Router Class Initialized
INFO - 2023-02-16 07:38:41 --> Output Class Initialized
INFO - 2023-02-16 07:38:41 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:41 --> Input Class Initialized
INFO - 2023-02-16 07:38:41 --> Language Class Initialized
INFO - 2023-02-16 07:38:41 --> Loader Class Initialized
INFO - 2023-02-16 07:38:41 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:41 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:41 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:41 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:41 --> Total execution time: 0.0482
INFO - 2023-02-16 07:38:44 --> Config Class Initialized
INFO - 2023-02-16 07:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:44 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:44 --> URI Class Initialized
INFO - 2023-02-16 07:38:44 --> Router Class Initialized
INFO - 2023-02-16 07:38:44 --> Output Class Initialized
INFO - 2023-02-16 07:38:44 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:44 --> Input Class Initialized
INFO - 2023-02-16 07:38:44 --> Language Class Initialized
INFO - 2023-02-16 07:38:44 --> Loader Class Initialized
INFO - 2023-02-16 07:38:44 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:44 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:44 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:44 --> Total execution time: 0.0335
INFO - 2023-02-16 07:38:44 --> Config Class Initialized
INFO - 2023-02-16 07:38:44 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:44 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:44 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:44 --> URI Class Initialized
INFO - 2023-02-16 07:38:44 --> Router Class Initialized
INFO - 2023-02-16 07:38:44 --> Output Class Initialized
INFO - 2023-02-16 07:38:44 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:44 --> Input Class Initialized
INFO - 2023-02-16 07:38:44 --> Language Class Initialized
INFO - 2023-02-16 07:38:44 --> Loader Class Initialized
INFO - 2023-02-16 07:38:44 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:44 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:44 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:44 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:44 --> Total execution time: 0.0597
INFO - 2023-02-16 07:38:51 --> Config Class Initialized
INFO - 2023-02-16 07:38:51 --> Config Class Initialized
INFO - 2023-02-16 07:38:51 --> Hooks Class Initialized
INFO - 2023-02-16 07:38:51 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:51 --> UTF-8 Support Enabled
DEBUG - 2023-02-16 07:38:51 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:51 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:51 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:51 --> URI Class Initialized
INFO - 2023-02-16 07:38:51 --> URI Class Initialized
INFO - 2023-02-16 07:38:51 --> Router Class Initialized
INFO - 2023-02-16 07:38:51 --> Router Class Initialized
INFO - 2023-02-16 07:38:51 --> Output Class Initialized
INFO - 2023-02-16 07:38:51 --> Output Class Initialized
INFO - 2023-02-16 07:38:51 --> Security Class Initialized
INFO - 2023-02-16 07:38:51 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-16 07:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:51 --> Input Class Initialized
INFO - 2023-02-16 07:38:51 --> Input Class Initialized
INFO - 2023-02-16 07:38:51 --> Language Class Initialized
INFO - 2023-02-16 07:38:51 --> Language Class Initialized
INFO - 2023-02-16 07:38:51 --> Loader Class Initialized
INFO - 2023-02-16 07:38:51 --> Loader Class Initialized
INFO - 2023-02-16 07:38:51 --> Controller Class Initialized
INFO - 2023-02-16 07:38:51 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-16 07:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:51 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:51 --> Total execution time: 0.0045
INFO - 2023-02-16 07:38:51 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:51 --> Config Class Initialized
INFO - 2023-02-16 07:38:51 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:51 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:51 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:51 --> URI Class Initialized
INFO - 2023-02-16 07:38:51 --> Router Class Initialized
INFO - 2023-02-16 07:38:51 --> Output Class Initialized
INFO - 2023-02-16 07:38:51 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:51 --> Input Class Initialized
INFO - 2023-02-16 07:38:51 --> Language Class Initialized
INFO - 2023-02-16 07:38:51 --> Loader Class Initialized
INFO - 2023-02-16 07:38:51 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:51 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:51 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:51 --> Model "Login_model" initialized
INFO - 2023-02-16 07:38:51 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:51 --> Total execution time: 0.0185
INFO - 2023-02-16 07:38:51 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:51 --> Config Class Initialized
INFO - 2023-02-16 07:38:51 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:51 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:51 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:51 --> URI Class Initialized
INFO - 2023-02-16 07:38:51 --> Router Class Initialized
INFO - 2023-02-16 07:38:51 --> Output Class Initialized
INFO - 2023-02-16 07:38:51 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:51 --> Input Class Initialized
INFO - 2023-02-16 07:38:51 --> Language Class Initialized
INFO - 2023-02-16 07:38:51 --> Loader Class Initialized
INFO - 2023-02-16 07:38:51 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:51 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:51 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:51 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:51 --> Total execution time: 0.0287
INFO - 2023-02-16 07:38:51 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:51 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:51 --> Total execution time: 0.0634
INFO - 2023-02-16 07:38:54 --> Config Class Initialized
INFO - 2023-02-16 07:38:54 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:54 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:54 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:54 --> URI Class Initialized
INFO - 2023-02-16 07:38:54 --> Router Class Initialized
INFO - 2023-02-16 07:38:54 --> Output Class Initialized
INFO - 2023-02-16 07:38:54 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:54 --> Input Class Initialized
INFO - 2023-02-16 07:38:54 --> Language Class Initialized
INFO - 2023-02-16 07:38:54 --> Loader Class Initialized
INFO - 2023-02-16 07:38:54 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:54 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:54 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:54 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:54 --> Model "Login_model" initialized
INFO - 2023-02-16 07:38:54 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:54 --> Total execution time: 0.0854
INFO - 2023-02-16 07:38:54 --> Config Class Initialized
INFO - 2023-02-16 07:38:54 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:38:54 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:38:54 --> Utf8 Class Initialized
INFO - 2023-02-16 07:38:54 --> URI Class Initialized
INFO - 2023-02-16 07:38:54 --> Router Class Initialized
INFO - 2023-02-16 07:38:54 --> Output Class Initialized
INFO - 2023-02-16 07:38:54 --> Security Class Initialized
DEBUG - 2023-02-16 07:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:38:54 --> Input Class Initialized
INFO - 2023-02-16 07:38:54 --> Language Class Initialized
INFO - 2023-02-16 07:38:54 --> Loader Class Initialized
INFO - 2023-02-16 07:38:54 --> Controller Class Initialized
DEBUG - 2023-02-16 07:38:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:38:54 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:54 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:38:54 --> Database Driver Class Initialized
INFO - 2023-02-16 07:38:54 --> Model "Login_model" initialized
INFO - 2023-02-16 07:38:54 --> Final output sent to browser
DEBUG - 2023-02-16 07:38:54 --> Total execution time: 0.0413
INFO - 2023-02-16 07:39:18 --> Config Class Initialized
INFO - 2023-02-16 07:39:18 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:18 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:18 --> URI Class Initialized
INFO - 2023-02-16 07:39:18 --> Router Class Initialized
INFO - 2023-02-16 07:39:18 --> Output Class Initialized
INFO - 2023-02-16 07:39:18 --> Security Class Initialized
DEBUG - 2023-02-16 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:18 --> Input Class Initialized
INFO - 2023-02-16 07:39:18 --> Language Class Initialized
INFO - 2023-02-16 07:39:18 --> Loader Class Initialized
INFO - 2023-02-16 07:39:18 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:18 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:18 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:18 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:18 --> Total execution time: 0.0147
INFO - 2023-02-16 07:39:18 --> Config Class Initialized
INFO - 2023-02-16 07:39:18 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:18 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:18 --> URI Class Initialized
INFO - 2023-02-16 07:39:18 --> Router Class Initialized
INFO - 2023-02-16 07:39:18 --> Output Class Initialized
INFO - 2023-02-16 07:39:18 --> Security Class Initialized
DEBUG - 2023-02-16 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:18 --> Input Class Initialized
INFO - 2023-02-16 07:39:18 --> Language Class Initialized
INFO - 2023-02-16 07:39:18 --> Loader Class Initialized
INFO - 2023-02-16 07:39:18 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:18 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:18 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:18 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:18 --> Total execution time: 0.0155
INFO - 2023-02-16 07:39:20 --> Config Class Initialized
INFO - 2023-02-16 07:39:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:20 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:20 --> URI Class Initialized
INFO - 2023-02-16 07:39:20 --> Router Class Initialized
INFO - 2023-02-16 07:39:20 --> Output Class Initialized
INFO - 2023-02-16 07:39:20 --> Security Class Initialized
DEBUG - 2023-02-16 07:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:20 --> Input Class Initialized
INFO - 2023-02-16 07:39:20 --> Language Class Initialized
INFO - 2023-02-16 07:39:20 --> Loader Class Initialized
INFO - 2023-02-16 07:39:20 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:20 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:20 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:20 --> Total execution time: 0.0426
INFO - 2023-02-16 07:39:20 --> Config Class Initialized
INFO - 2023-02-16 07:39:20 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:20 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:20 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:20 --> URI Class Initialized
INFO - 2023-02-16 07:39:20 --> Router Class Initialized
INFO - 2023-02-16 07:39:20 --> Output Class Initialized
INFO - 2023-02-16 07:39:20 --> Security Class Initialized
DEBUG - 2023-02-16 07:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:20 --> Input Class Initialized
INFO - 2023-02-16 07:39:20 --> Language Class Initialized
INFO - 2023-02-16 07:39:20 --> Loader Class Initialized
INFO - 2023-02-16 07:39:20 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:20 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:20 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:20 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:20 --> Total execution time: 0.0396
INFO - 2023-02-16 07:39:22 --> Config Class Initialized
INFO - 2023-02-16 07:39:22 --> Config Class Initialized
INFO - 2023-02-16 07:39:22 --> Hooks Class Initialized
INFO - 2023-02-16 07:39:22 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:22 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:22 --> Utf8 Class Initialized
DEBUG - 2023-02-16 07:39:22 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:22 --> URI Class Initialized
INFO - 2023-02-16 07:39:22 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:22 --> Router Class Initialized
INFO - 2023-02-16 07:39:22 --> URI Class Initialized
INFO - 2023-02-16 07:39:22 --> Output Class Initialized
INFO - 2023-02-16 07:39:22 --> Router Class Initialized
INFO - 2023-02-16 07:39:22 --> Security Class Initialized
INFO - 2023-02-16 07:39:22 --> Output Class Initialized
DEBUG - 2023-02-16 07:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:22 --> Security Class Initialized
INFO - 2023-02-16 07:39:22 --> Input Class Initialized
DEBUG - 2023-02-16 07:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:22 --> Input Class Initialized
INFO - 2023-02-16 07:39:22 --> Language Class Initialized
INFO - 2023-02-16 07:39:22 --> Language Class Initialized
INFO - 2023-02-16 07:39:22 --> Loader Class Initialized
INFO - 2023-02-16 07:39:22 --> Loader Class Initialized
INFO - 2023-02-16 07:39:22 --> Controller Class Initialized
INFO - 2023-02-16 07:39:22 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-16 07:39:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:22 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:22 --> Total execution time: 0.0045
INFO - 2023-02-16 07:39:22 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:22 --> Config Class Initialized
INFO - 2023-02-16 07:39:22 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:22 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:22 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:22 --> URI Class Initialized
INFO - 2023-02-16 07:39:22 --> Router Class Initialized
INFO - 2023-02-16 07:39:22 --> Output Class Initialized
INFO - 2023-02-16 07:39:22 --> Security Class Initialized
DEBUG - 2023-02-16 07:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:22 --> Input Class Initialized
INFO - 2023-02-16 07:39:22 --> Language Class Initialized
INFO - 2023-02-16 07:39:22 --> Loader Class Initialized
INFO - 2023-02-16 07:39:22 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:22 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:22 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:22 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:22 --> Total execution time: 0.0163
INFO - 2023-02-16 07:39:22 --> Model "Login_model" initialized
INFO - 2023-02-16 07:39:22 --> Config Class Initialized
INFO - 2023-02-16 07:39:22 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:22 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:22 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:22 --> URI Class Initialized
INFO - 2023-02-16 07:39:22 --> Router Class Initialized
INFO - 2023-02-16 07:39:22 --> Output Class Initialized
INFO - 2023-02-16 07:39:22 --> Security Class Initialized
INFO - 2023-02-16 07:39:22 --> Database Driver Class Initialized
DEBUG - 2023-02-16 07:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:22 --> Input Class Initialized
INFO - 2023-02-16 07:39:22 --> Language Class Initialized
INFO - 2023-02-16 07:39:22 --> Loader Class Initialized
INFO - 2023-02-16 07:39:22 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:22 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:22 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:22 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:22 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:22 --> Total execution time: 0.0230
INFO - 2023-02-16 07:39:22 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:22 --> Total execution time: 0.0130
INFO - 2023-02-16 07:39:26 --> Config Class Initialized
INFO - 2023-02-16 07:39:26 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:26 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:26 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:26 --> URI Class Initialized
INFO - 2023-02-16 07:39:26 --> Router Class Initialized
INFO - 2023-02-16 07:39:26 --> Output Class Initialized
INFO - 2023-02-16 07:39:26 --> Security Class Initialized
DEBUG - 2023-02-16 07:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:26 --> Input Class Initialized
INFO - 2023-02-16 07:39:26 --> Language Class Initialized
INFO - 2023-02-16 07:39:26 --> Loader Class Initialized
INFO - 2023-02-16 07:39:26 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:26 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:26 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:26 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:26 --> Model "Login_model" initialized
INFO - 2023-02-16 07:39:26 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:26 --> Total execution time: 0.0627
INFO - 2023-02-16 07:39:26 --> Config Class Initialized
INFO - 2023-02-16 07:39:26 --> Hooks Class Initialized
DEBUG - 2023-02-16 07:39:26 --> UTF-8 Support Enabled
INFO - 2023-02-16 07:39:26 --> Utf8 Class Initialized
INFO - 2023-02-16 07:39:26 --> URI Class Initialized
INFO - 2023-02-16 07:39:26 --> Router Class Initialized
INFO - 2023-02-16 07:39:26 --> Output Class Initialized
INFO - 2023-02-16 07:39:26 --> Security Class Initialized
DEBUG - 2023-02-16 07:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 07:39:26 --> Input Class Initialized
INFO - 2023-02-16 07:39:26 --> Language Class Initialized
INFO - 2023-02-16 07:39:26 --> Loader Class Initialized
INFO - 2023-02-16 07:39:26 --> Controller Class Initialized
DEBUG - 2023-02-16 07:39:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 07:39:26 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:26 --> Model "Cluster_model" initialized
INFO - 2023-02-16 07:39:26 --> Database Driver Class Initialized
INFO - 2023-02-16 07:39:26 --> Model "Login_model" initialized
INFO - 2023-02-16 07:39:26 --> Final output sent to browser
DEBUG - 2023-02-16 07:39:26 --> Total execution time: 0.0400
INFO - 2023-02-16 08:30:40 --> Config Class Initialized
INFO - 2023-02-16 08:30:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:30:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:30:40 --> Utf8 Class Initialized
INFO - 2023-02-16 08:30:40 --> URI Class Initialized
INFO - 2023-02-16 08:30:40 --> Router Class Initialized
INFO - 2023-02-16 08:30:40 --> Output Class Initialized
INFO - 2023-02-16 08:30:40 --> Security Class Initialized
DEBUG - 2023-02-16 08:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:30:40 --> Input Class Initialized
INFO - 2023-02-16 08:30:40 --> Language Class Initialized
INFO - 2023-02-16 08:30:40 --> Loader Class Initialized
INFO - 2023-02-16 08:30:40 --> Controller Class Initialized
DEBUG - 2023-02-16 08:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:30:40 --> Database Driver Class Initialized
INFO - 2023-02-16 08:30:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:30:40 --> Final output sent to browser
DEBUG - 2023-02-16 08:30:40 --> Total execution time: 0.0210
INFO - 2023-02-16 08:30:40 --> Config Class Initialized
INFO - 2023-02-16 08:30:40 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:30:40 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:30:40 --> Utf8 Class Initialized
INFO - 2023-02-16 08:30:40 --> URI Class Initialized
INFO - 2023-02-16 08:30:40 --> Router Class Initialized
INFO - 2023-02-16 08:30:40 --> Output Class Initialized
INFO - 2023-02-16 08:30:40 --> Security Class Initialized
DEBUG - 2023-02-16 08:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:30:40 --> Input Class Initialized
INFO - 2023-02-16 08:30:40 --> Language Class Initialized
INFO - 2023-02-16 08:30:40 --> Loader Class Initialized
INFO - 2023-02-16 08:30:40 --> Controller Class Initialized
DEBUG - 2023-02-16 08:30:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:30:40 --> Database Driver Class Initialized
INFO - 2023-02-16 08:30:40 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:30:40 --> Final output sent to browser
DEBUG - 2023-02-16 08:30:40 --> Total execution time: 0.1322
INFO - 2023-02-16 08:30:43 --> Config Class Initialized
INFO - 2023-02-16 08:30:43 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:30:43 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:30:43 --> Utf8 Class Initialized
INFO - 2023-02-16 08:30:43 --> URI Class Initialized
INFO - 2023-02-16 08:30:43 --> Router Class Initialized
INFO - 2023-02-16 08:30:43 --> Output Class Initialized
INFO - 2023-02-16 08:30:43 --> Security Class Initialized
DEBUG - 2023-02-16 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:30:43 --> Input Class Initialized
INFO - 2023-02-16 08:30:43 --> Language Class Initialized
INFO - 2023-02-16 08:30:43 --> Loader Class Initialized
INFO - 2023-02-16 08:30:43 --> Controller Class Initialized
DEBUG - 2023-02-16 08:30:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:30:43 --> Database Driver Class Initialized
INFO - 2023-02-16 08:30:43 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:30:43 --> Final output sent to browser
DEBUG - 2023-02-16 08:30:43 --> Total execution time: 0.1931
INFO - 2023-02-16 08:30:43 --> Config Class Initialized
INFO - 2023-02-16 08:30:43 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:30:43 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:30:43 --> Utf8 Class Initialized
INFO - 2023-02-16 08:30:43 --> URI Class Initialized
INFO - 2023-02-16 08:30:43 --> Router Class Initialized
INFO - 2023-02-16 08:30:43 --> Output Class Initialized
INFO - 2023-02-16 08:30:43 --> Security Class Initialized
DEBUG - 2023-02-16 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:30:43 --> Input Class Initialized
INFO - 2023-02-16 08:30:43 --> Language Class Initialized
INFO - 2023-02-16 08:30:43 --> Loader Class Initialized
INFO - 2023-02-16 08:30:43 --> Controller Class Initialized
DEBUG - 2023-02-16 08:30:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:30:43 --> Database Driver Class Initialized
INFO - 2023-02-16 08:30:43 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:30:43 --> Final output sent to browser
DEBUG - 2023-02-16 08:30:43 --> Total execution time: 0.1186
INFO - 2023-02-16 08:30:45 --> Config Class Initialized
INFO - 2023-02-16 08:30:45 --> Config Class Initialized
INFO - 2023-02-16 08:30:45 --> Hooks Class Initialized
INFO - 2023-02-16 08:30:45 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2023-02-16 08:30:45 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:30:45 --> Utf8 Class Initialized
INFO - 2023-02-16 08:30:45 --> Utf8 Class Initialized
INFO - 2023-02-16 08:30:45 --> URI Class Initialized
INFO - 2023-02-16 08:30:45 --> URI Class Initialized
INFO - 2023-02-16 08:30:45 --> Router Class Initialized
INFO - 2023-02-16 08:30:45 --> Router Class Initialized
INFO - 2023-02-16 08:30:45 --> Output Class Initialized
INFO - 2023-02-16 08:30:45 --> Output Class Initialized
INFO - 2023-02-16 08:30:45 --> Security Class Initialized
INFO - 2023-02-16 08:30:45 --> Security Class Initialized
DEBUG - 2023-02-16 08:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-16 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:30:45 --> Input Class Initialized
INFO - 2023-02-16 08:30:45 --> Input Class Initialized
INFO - 2023-02-16 08:30:45 --> Language Class Initialized
INFO - 2023-02-16 08:30:45 --> Language Class Initialized
INFO - 2023-02-16 08:30:45 --> Loader Class Initialized
INFO - 2023-02-16 08:30:45 --> Loader Class Initialized
INFO - 2023-02-16 08:30:45 --> Controller Class Initialized
INFO - 2023-02-16 08:30:45 --> Controller Class Initialized
DEBUG - 2023-02-16 08:30:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-16 08:30:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:30:45 --> Final output sent to browser
DEBUG - 2023-02-16 08:30:45 --> Total execution time: 0.0048
INFO - 2023-02-16 08:30:45 --> Database Driver Class Initialized
INFO - 2023-02-16 08:30:45 --> Config Class Initialized
INFO - 2023-02-16 08:30:45 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:30:45 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:30:45 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:30:45 --> Utf8 Class Initialized
INFO - 2023-02-16 08:30:45 --> URI Class Initialized
INFO - 2023-02-16 08:30:45 --> Router Class Initialized
INFO - 2023-02-16 08:30:45 --> Output Class Initialized
INFO - 2023-02-16 08:30:45 --> Security Class Initialized
DEBUG - 2023-02-16 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:30:45 --> Input Class Initialized
INFO - 2023-02-16 08:30:45 --> Language Class Initialized
INFO - 2023-02-16 08:30:45 --> Loader Class Initialized
INFO - 2023-02-16 08:30:45 --> Controller Class Initialized
DEBUG - 2023-02-16 08:30:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:30:45 --> Database Driver Class Initialized
INFO - 2023-02-16 08:30:45 --> Final output sent to browser
DEBUG - 2023-02-16 08:30:45 --> Total execution time: 0.0520
INFO - 2023-02-16 08:30:45 --> Config Class Initialized
INFO - 2023-02-16 08:30:45 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:30:45 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:30:45 --> Utf8 Class Initialized
INFO - 2023-02-16 08:30:45 --> URI Class Initialized
INFO - 2023-02-16 08:30:45 --> Router Class Initialized
INFO - 2023-02-16 08:30:45 --> Output Class Initialized
INFO - 2023-02-16 08:30:45 --> Security Class Initialized
DEBUG - 2023-02-16 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:30:45 --> Model "Login_model" initialized
INFO - 2023-02-16 08:30:45 --> Input Class Initialized
INFO - 2023-02-16 08:30:45 --> Language Class Initialized
INFO - 2023-02-16 08:30:45 --> Loader Class Initialized
INFO - 2023-02-16 08:30:45 --> Controller Class Initialized
DEBUG - 2023-02-16 08:30:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:30:45 --> Database Driver Class Initialized
INFO - 2023-02-16 08:30:45 --> Database Driver Class Initialized
INFO - 2023-02-16 08:30:45 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:30:45 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:30:45 --> Final output sent to browser
DEBUG - 2023-02-16 08:30:45 --> Total execution time: 0.0621
INFO - 2023-02-16 08:30:45 --> Final output sent to browser
DEBUG - 2023-02-16 08:30:46 --> Total execution time: 0.0194
INFO - 2023-02-16 08:38:49 --> Config Class Initialized
INFO - 2023-02-16 08:38:49 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:38:49 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:38:49 --> Utf8 Class Initialized
INFO - 2023-02-16 08:38:49 --> URI Class Initialized
INFO - 2023-02-16 08:38:49 --> Router Class Initialized
INFO - 2023-02-16 08:38:49 --> Output Class Initialized
INFO - 2023-02-16 08:38:49 --> Security Class Initialized
DEBUG - 2023-02-16 08:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:38:49 --> Input Class Initialized
INFO - 2023-02-16 08:38:49 --> Language Class Initialized
INFO - 2023-02-16 08:38:49 --> Loader Class Initialized
INFO - 2023-02-16 08:38:49 --> Controller Class Initialized
DEBUG - 2023-02-16 08:38:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:38:49 --> Database Driver Class Initialized
INFO - 2023-02-16 08:38:49 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:38:49 --> Final output sent to browser
DEBUG - 2023-02-16 08:38:49 --> Total execution time: 0.0191
INFO - 2023-02-16 08:38:49 --> Config Class Initialized
INFO - 2023-02-16 08:38:49 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:38:49 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:38:49 --> Utf8 Class Initialized
INFO - 2023-02-16 08:38:49 --> URI Class Initialized
INFO - 2023-02-16 08:38:49 --> Router Class Initialized
INFO - 2023-02-16 08:38:49 --> Output Class Initialized
INFO - 2023-02-16 08:38:49 --> Security Class Initialized
DEBUG - 2023-02-16 08:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:38:49 --> Input Class Initialized
INFO - 2023-02-16 08:38:49 --> Language Class Initialized
INFO - 2023-02-16 08:38:49 --> Loader Class Initialized
INFO - 2023-02-16 08:38:49 --> Controller Class Initialized
DEBUG - 2023-02-16 08:38:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:38:49 --> Database Driver Class Initialized
INFO - 2023-02-16 08:38:49 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:38:49 --> Final output sent to browser
DEBUG - 2023-02-16 08:38:49 --> Total execution time: 0.0540
INFO - 2023-02-16 08:38:51 --> Config Class Initialized
INFO - 2023-02-16 08:38:51 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:38:51 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:38:52 --> Utf8 Class Initialized
INFO - 2023-02-16 08:38:52 --> URI Class Initialized
INFO - 2023-02-16 08:38:52 --> Router Class Initialized
INFO - 2023-02-16 08:38:52 --> Output Class Initialized
INFO - 2023-02-16 08:38:52 --> Security Class Initialized
DEBUG - 2023-02-16 08:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:38:52 --> Input Class Initialized
INFO - 2023-02-16 08:38:52 --> Language Class Initialized
INFO - 2023-02-16 08:38:52 --> Loader Class Initialized
INFO - 2023-02-16 08:38:52 --> Controller Class Initialized
DEBUG - 2023-02-16 08:38:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:38:52 --> Database Driver Class Initialized
INFO - 2023-02-16 08:38:52 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:38:52 --> Final output sent to browser
DEBUG - 2023-02-16 08:38:52 --> Total execution time: 0.3712
INFO - 2023-02-16 08:38:52 --> Config Class Initialized
INFO - 2023-02-16 08:38:52 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:38:52 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:38:52 --> Utf8 Class Initialized
INFO - 2023-02-16 08:38:52 --> URI Class Initialized
INFO - 2023-02-16 08:38:52 --> Router Class Initialized
INFO - 2023-02-16 08:38:52 --> Output Class Initialized
INFO - 2023-02-16 08:38:52 --> Security Class Initialized
DEBUG - 2023-02-16 08:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:38:52 --> Input Class Initialized
INFO - 2023-02-16 08:38:52 --> Language Class Initialized
INFO - 2023-02-16 08:38:52 --> Loader Class Initialized
INFO - 2023-02-16 08:38:52 --> Controller Class Initialized
DEBUG - 2023-02-16 08:38:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:38:52 --> Database Driver Class Initialized
INFO - 2023-02-16 08:38:52 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:38:52 --> Final output sent to browser
DEBUG - 2023-02-16 08:38:52 --> Total execution time: 0.0822
INFO - 2023-02-16 08:38:59 --> Config Class Initialized
INFO - 2023-02-16 08:38:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:38:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:38:59 --> Utf8 Class Initialized
INFO - 2023-02-16 08:38:59 --> URI Class Initialized
INFO - 2023-02-16 08:38:59 --> Router Class Initialized
INFO - 2023-02-16 08:38:59 --> Output Class Initialized
INFO - 2023-02-16 08:38:59 --> Security Class Initialized
DEBUG - 2023-02-16 08:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:38:59 --> Input Class Initialized
INFO - 2023-02-16 08:38:59 --> Language Class Initialized
INFO - 2023-02-16 08:38:59 --> Loader Class Initialized
INFO - 2023-02-16 08:38:59 --> Controller Class Initialized
DEBUG - 2023-02-16 08:38:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:38:59 --> Database Driver Class Initialized
INFO - 2023-02-16 08:38:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:38:59 --> Database Driver Class Initialized
INFO - 2023-02-16 08:38:59 --> Model "Login_model" initialized
INFO - 2023-02-16 08:38:59 --> Final output sent to browser
DEBUG - 2023-02-16 08:38:59 --> Total execution time: 0.0430
INFO - 2023-02-16 08:38:59 --> Config Class Initialized
INFO - 2023-02-16 08:38:59 --> Hooks Class Initialized
DEBUG - 2023-02-16 08:38:59 --> UTF-8 Support Enabled
INFO - 2023-02-16 08:38:59 --> Utf8 Class Initialized
INFO - 2023-02-16 08:38:59 --> URI Class Initialized
INFO - 2023-02-16 08:38:59 --> Router Class Initialized
INFO - 2023-02-16 08:38:59 --> Output Class Initialized
INFO - 2023-02-16 08:38:59 --> Security Class Initialized
DEBUG - 2023-02-16 08:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 08:38:59 --> Input Class Initialized
INFO - 2023-02-16 08:38:59 --> Language Class Initialized
INFO - 2023-02-16 08:38:59 --> Loader Class Initialized
INFO - 2023-02-16 08:38:59 --> Controller Class Initialized
DEBUG - 2023-02-16 08:38:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 08:38:59 --> Database Driver Class Initialized
INFO - 2023-02-16 08:38:59 --> Model "Cluster_model" initialized
INFO - 2023-02-16 08:38:59 --> Database Driver Class Initialized
INFO - 2023-02-16 08:38:59 --> Model "Login_model" initialized
INFO - 2023-02-16 08:38:59 --> Final output sent to browser
DEBUG - 2023-02-16 08:38:59 --> Total execution time: 0.0876
INFO - 2023-02-16 09:25:57 --> Config Class Initialized
INFO - 2023-02-16 09:25:57 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:25:57 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:25:57 --> Utf8 Class Initialized
INFO - 2023-02-16 09:25:57 --> URI Class Initialized
INFO - 2023-02-16 09:25:57 --> Router Class Initialized
INFO - 2023-02-16 09:25:57 --> Output Class Initialized
INFO - 2023-02-16 09:25:57 --> Security Class Initialized
DEBUG - 2023-02-16 09:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:25:57 --> Input Class Initialized
INFO - 2023-02-16 09:25:57 --> Language Class Initialized
INFO - 2023-02-16 09:25:57 --> Loader Class Initialized
INFO - 2023-02-16 09:25:57 --> Controller Class Initialized
DEBUG - 2023-02-16 09:25:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:25:57 --> Database Driver Class Initialized
INFO - 2023-02-16 09:25:57 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:25:57 --> Final output sent to browser
DEBUG - 2023-02-16 09:25:57 --> Total execution time: 0.0568
INFO - 2023-02-16 09:25:57 --> Config Class Initialized
INFO - 2023-02-16 09:25:57 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:25:57 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:25:57 --> Utf8 Class Initialized
INFO - 2023-02-16 09:25:57 --> URI Class Initialized
INFO - 2023-02-16 09:25:57 --> Router Class Initialized
INFO - 2023-02-16 09:25:57 --> Output Class Initialized
INFO - 2023-02-16 09:25:57 --> Security Class Initialized
DEBUG - 2023-02-16 09:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:25:57 --> Input Class Initialized
INFO - 2023-02-16 09:25:57 --> Language Class Initialized
INFO - 2023-02-16 09:25:57 --> Loader Class Initialized
INFO - 2023-02-16 09:25:57 --> Controller Class Initialized
DEBUG - 2023-02-16 09:25:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:25:57 --> Database Driver Class Initialized
INFO - 2023-02-16 09:25:57 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:25:57 --> Final output sent to browser
DEBUG - 2023-02-16 09:25:57 --> Total execution time: 0.0824
INFO - 2023-02-16 09:26:15 --> Config Class Initialized
INFO - 2023-02-16 09:26:15 --> Config Class Initialized
INFO - 2023-02-16 09:26:15 --> Hooks Class Initialized
INFO - 2023-02-16 09:26:15 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-02-16 09:26:15 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:26:15 --> Utf8 Class Initialized
INFO - 2023-02-16 09:26:15 --> Utf8 Class Initialized
INFO - 2023-02-16 09:26:15 --> URI Class Initialized
INFO - 2023-02-16 09:26:15 --> URI Class Initialized
INFO - 2023-02-16 09:26:15 --> Router Class Initialized
INFO - 2023-02-16 09:26:15 --> Router Class Initialized
INFO - 2023-02-16 09:26:15 --> Output Class Initialized
INFO - 2023-02-16 09:26:15 --> Output Class Initialized
INFO - 2023-02-16 09:26:15 --> Security Class Initialized
INFO - 2023-02-16 09:26:15 --> Security Class Initialized
DEBUG - 2023-02-16 09:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-16 09:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:26:15 --> Input Class Initialized
INFO - 2023-02-16 09:26:15 --> Input Class Initialized
INFO - 2023-02-16 09:26:15 --> Language Class Initialized
INFO - 2023-02-16 09:26:15 --> Language Class Initialized
INFO - 2023-02-16 09:26:15 --> Loader Class Initialized
INFO - 2023-02-16 09:26:15 --> Loader Class Initialized
INFO - 2023-02-16 09:26:15 --> Controller Class Initialized
INFO - 2023-02-16 09:26:15 --> Controller Class Initialized
DEBUG - 2023-02-16 09:26:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-16 09:26:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:26:15 --> Final output sent to browser
DEBUG - 2023-02-16 09:26:15 --> Total execution time: 0.0453
INFO - 2023-02-16 09:26:15 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:15 --> Config Class Initialized
INFO - 2023-02-16 09:26:15 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:26:15 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:26:15 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:26:15 --> Utf8 Class Initialized
INFO - 2023-02-16 09:26:15 --> URI Class Initialized
INFO - 2023-02-16 09:26:15 --> Router Class Initialized
INFO - 2023-02-16 09:26:15 --> Output Class Initialized
INFO - 2023-02-16 09:26:15 --> Security Class Initialized
DEBUG - 2023-02-16 09:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:26:15 --> Input Class Initialized
INFO - 2023-02-16 09:26:15 --> Language Class Initialized
INFO - 2023-02-16 09:26:15 --> Loader Class Initialized
INFO - 2023-02-16 09:26:15 --> Controller Class Initialized
DEBUG - 2023-02-16 09:26:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:26:15 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:15 --> Final output sent to browser
DEBUG - 2023-02-16 09:26:15 --> Total execution time: 0.0772
INFO - 2023-02-16 09:26:15 --> Config Class Initialized
INFO - 2023-02-16 09:26:15 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:26:15 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:26:15 --> Utf8 Class Initialized
INFO - 2023-02-16 09:26:15 --> URI Class Initialized
INFO - 2023-02-16 09:26:15 --> Router Class Initialized
INFO - 2023-02-16 09:26:15 --> Output Class Initialized
INFO - 2023-02-16 09:26:15 --> Security Class Initialized
DEBUG - 2023-02-16 09:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:26:15 --> Input Class Initialized
INFO - 2023-02-16 09:26:15 --> Language Class Initialized
INFO - 2023-02-16 09:26:15 --> Loader Class Initialized
INFO - 2023-02-16 09:26:15 --> Controller Class Initialized
DEBUG - 2023-02-16 09:26:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:26:15 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:15 --> Model "Login_model" initialized
INFO - 2023-02-16 09:26:15 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:15 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:26:15 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:26:15 --> Final output sent to browser
DEBUG - 2023-02-16 09:26:15 --> Total execution time: 0.0124
INFO - 2023-02-16 09:26:15 --> Final output sent to browser
DEBUG - 2023-02-16 09:26:15 --> Total execution time: 0.0475
INFO - 2023-02-16 09:26:18 --> Config Class Initialized
INFO - 2023-02-16 09:26:18 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:26:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:26:18 --> Utf8 Class Initialized
INFO - 2023-02-16 09:26:18 --> URI Class Initialized
INFO - 2023-02-16 09:26:18 --> Router Class Initialized
INFO - 2023-02-16 09:26:18 --> Output Class Initialized
INFO - 2023-02-16 09:26:18 --> Security Class Initialized
DEBUG - 2023-02-16 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:26:18 --> Input Class Initialized
INFO - 2023-02-16 09:26:18 --> Language Class Initialized
INFO - 2023-02-16 09:26:18 --> Loader Class Initialized
INFO - 2023-02-16 09:26:18 --> Controller Class Initialized
DEBUG - 2023-02-16 09:26:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:26:18 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:18 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:26:18 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:18 --> Model "Login_model" initialized
INFO - 2023-02-16 09:26:18 --> Final output sent to browser
DEBUG - 2023-02-16 09:26:18 --> Total execution time: 0.0412
INFO - 2023-02-16 09:26:18 --> Config Class Initialized
INFO - 2023-02-16 09:26:18 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:26:18 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:26:18 --> Utf8 Class Initialized
INFO - 2023-02-16 09:26:18 --> URI Class Initialized
INFO - 2023-02-16 09:26:18 --> Router Class Initialized
INFO - 2023-02-16 09:26:18 --> Output Class Initialized
INFO - 2023-02-16 09:26:18 --> Security Class Initialized
DEBUG - 2023-02-16 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:26:18 --> Input Class Initialized
INFO - 2023-02-16 09:26:18 --> Language Class Initialized
INFO - 2023-02-16 09:26:18 --> Loader Class Initialized
INFO - 2023-02-16 09:26:18 --> Controller Class Initialized
DEBUG - 2023-02-16 09:26:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:26:18 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:18 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:26:18 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:18 --> Model "Login_model" initialized
INFO - 2023-02-16 09:26:18 --> Final output sent to browser
DEBUG - 2023-02-16 09:26:18 --> Total execution time: 0.0759
INFO - 2023-02-16 09:26:23 --> Config Class Initialized
INFO - 2023-02-16 09:26:23 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:26:23 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:26:23 --> Utf8 Class Initialized
INFO - 2023-02-16 09:26:23 --> URI Class Initialized
INFO - 2023-02-16 09:26:23 --> Router Class Initialized
INFO - 2023-02-16 09:26:23 --> Output Class Initialized
INFO - 2023-02-16 09:26:23 --> Security Class Initialized
DEBUG - 2023-02-16 09:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:26:23 --> Input Class Initialized
INFO - 2023-02-16 09:26:23 --> Language Class Initialized
INFO - 2023-02-16 09:26:23 --> Loader Class Initialized
INFO - 2023-02-16 09:26:23 --> Controller Class Initialized
DEBUG - 2023-02-16 09:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:26:23 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:23 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:26:23 --> Final output sent to browser
DEBUG - 2023-02-16 09:26:23 --> Total execution time: 0.0429
INFO - 2023-02-16 09:26:23 --> Config Class Initialized
INFO - 2023-02-16 09:26:23 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:26:23 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:26:23 --> Utf8 Class Initialized
INFO - 2023-02-16 09:26:23 --> URI Class Initialized
INFO - 2023-02-16 09:26:23 --> Router Class Initialized
INFO - 2023-02-16 09:26:23 --> Output Class Initialized
INFO - 2023-02-16 09:26:23 --> Security Class Initialized
DEBUG - 2023-02-16 09:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:26:23 --> Input Class Initialized
INFO - 2023-02-16 09:26:23 --> Language Class Initialized
INFO - 2023-02-16 09:26:23 --> Loader Class Initialized
INFO - 2023-02-16 09:26:23 --> Controller Class Initialized
DEBUG - 2023-02-16 09:26:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:26:23 --> Database Driver Class Initialized
INFO - 2023-02-16 09:26:23 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:26:23 --> Final output sent to browser
DEBUG - 2023-02-16 09:26:23 --> Total execution time: 0.0508
INFO - 2023-02-16 09:28:33 --> Config Class Initialized
INFO - 2023-02-16 09:28:33 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:33 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:33 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:33 --> URI Class Initialized
INFO - 2023-02-16 09:28:33 --> Router Class Initialized
INFO - 2023-02-16 09:28:33 --> Output Class Initialized
INFO - 2023-02-16 09:28:33 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:33 --> Input Class Initialized
INFO - 2023-02-16 09:28:33 --> Language Class Initialized
INFO - 2023-02-16 09:28:33 --> Loader Class Initialized
INFO - 2023-02-16 09:28:33 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:33 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:33 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:33 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:33 --> Total execution time: 0.0178
INFO - 2023-02-16 09:28:33 --> Config Class Initialized
INFO - 2023-02-16 09:28:33 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:33 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:33 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:33 --> URI Class Initialized
INFO - 2023-02-16 09:28:33 --> Router Class Initialized
INFO - 2023-02-16 09:28:33 --> Output Class Initialized
INFO - 2023-02-16 09:28:33 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:33 --> Input Class Initialized
INFO - 2023-02-16 09:28:33 --> Language Class Initialized
INFO - 2023-02-16 09:28:33 --> Loader Class Initialized
INFO - 2023-02-16 09:28:33 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:33 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:33 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:33 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:33 --> Total execution time: 0.0376
INFO - 2023-02-16 09:28:35 --> Config Class Initialized
INFO - 2023-02-16 09:28:35 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:35 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:35 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:35 --> URI Class Initialized
INFO - 2023-02-16 09:28:35 --> Router Class Initialized
INFO - 2023-02-16 09:28:35 --> Output Class Initialized
INFO - 2023-02-16 09:28:35 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:35 --> Input Class Initialized
INFO - 2023-02-16 09:28:35 --> Language Class Initialized
INFO - 2023-02-16 09:28:35 --> Loader Class Initialized
INFO - 2023-02-16 09:28:35 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:35 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:35 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:35 --> Final output sent to browser
INFO - 2023-02-16 09:28:35 --> Config Class Initialized
INFO - 2023-02-16 09:28:35 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:35 --> Total execution time: 0.0420
DEBUG - 2023-02-16 09:28:35 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:35 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:35 --> URI Class Initialized
INFO - 2023-02-16 09:28:35 --> Router Class Initialized
INFO - 2023-02-16 09:28:35 --> Output Class Initialized
INFO - 2023-02-16 09:28:35 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:35 --> Input Class Initialized
INFO - 2023-02-16 09:28:35 --> Language Class Initialized
INFO - 2023-02-16 09:28:35 --> Loader Class Initialized
INFO - 2023-02-16 09:28:35 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:35 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:35 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:35 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:35 --> Total execution time: 0.0802
INFO - 2023-02-16 09:28:39 --> Config Class Initialized
INFO - 2023-02-16 09:28:39 --> Config Class Initialized
INFO - 2023-02-16 09:28:39 --> Hooks Class Initialized
INFO - 2023-02-16 09:28:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:39 --> UTF-8 Support Enabled
DEBUG - 2023-02-16 09:28:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:39 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:39 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:39 --> URI Class Initialized
INFO - 2023-02-16 09:28:39 --> URI Class Initialized
INFO - 2023-02-16 09:28:39 --> Router Class Initialized
INFO - 2023-02-16 09:28:39 --> Router Class Initialized
INFO - 2023-02-16 09:28:39 --> Output Class Initialized
INFO - 2023-02-16 09:28:39 --> Output Class Initialized
INFO - 2023-02-16 09:28:39 --> Security Class Initialized
INFO - 2023-02-16 09:28:39 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-16 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:39 --> Input Class Initialized
INFO - 2023-02-16 09:28:39 --> Input Class Initialized
INFO - 2023-02-16 09:28:39 --> Language Class Initialized
INFO - 2023-02-16 09:28:39 --> Language Class Initialized
INFO - 2023-02-16 09:28:39 --> Loader Class Initialized
INFO - 2023-02-16 09:28:39 --> Loader Class Initialized
INFO - 2023-02-16 09:28:39 --> Controller Class Initialized
INFO - 2023-02-16 09:28:39 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-02-16 09:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:39 --> Final output sent to browser
INFO - 2023-02-16 09:28:39 --> Database Driver Class Initialized
DEBUG - 2023-02-16 09:28:39 --> Total execution time: 0.0177
INFO - 2023-02-16 09:28:39 --> Config Class Initialized
INFO - 2023-02-16 09:28:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:39 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:39 --> URI Class Initialized
INFO - 2023-02-16 09:28:39 --> Router Class Initialized
INFO - 2023-02-16 09:28:39 --> Output Class Initialized
INFO - 2023-02-16 09:28:39 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:39 --> Input Class Initialized
INFO - 2023-02-16 09:28:39 --> Language Class Initialized
INFO - 2023-02-16 09:28:39 --> Loader Class Initialized
INFO - 2023-02-16 09:28:39 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:39 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:39 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:39 --> Total execution time: 0.0327
INFO - 2023-02-16 09:28:39 --> Config Class Initialized
INFO - 2023-02-16 09:28:39 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:39 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:39 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:39 --> URI Class Initialized
INFO - 2023-02-16 09:28:39 --> Router Class Initialized
INFO - 2023-02-16 09:28:39 --> Model "Login_model" initialized
INFO - 2023-02-16 09:28:39 --> Output Class Initialized
INFO - 2023-02-16 09:28:39 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:39 --> Input Class Initialized
INFO - 2023-02-16 09:28:39 --> Language Class Initialized
INFO - 2023-02-16 09:28:39 --> Loader Class Initialized
INFO - 2023-02-16 09:28:39 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:39 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:39 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:39 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:39 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:39 --> Total execution time: 0.0250
INFO - 2023-02-16 09:28:39 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:39 --> Total execution time: 0.0136
INFO - 2023-02-16 09:28:42 --> Config Class Initialized
INFO - 2023-02-16 09:28:42 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:42 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:42 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:42 --> URI Class Initialized
INFO - 2023-02-16 09:28:42 --> Router Class Initialized
INFO - 2023-02-16 09:28:42 --> Output Class Initialized
INFO - 2023-02-16 09:28:42 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:42 --> Input Class Initialized
INFO - 2023-02-16 09:28:42 --> Language Class Initialized
INFO - 2023-02-16 09:28:42 --> Loader Class Initialized
INFO - 2023-02-16 09:28:42 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:42 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:42 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:42 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:42 --> Total execution time: 0.0463
INFO - 2023-02-16 09:28:42 --> Config Class Initialized
INFO - 2023-02-16 09:28:42 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:42 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:42 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:42 --> URI Class Initialized
INFO - 2023-02-16 09:28:42 --> Router Class Initialized
INFO - 2023-02-16 09:28:42 --> Output Class Initialized
INFO - 2023-02-16 09:28:42 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:42 --> Input Class Initialized
INFO - 2023-02-16 09:28:42 --> Language Class Initialized
INFO - 2023-02-16 09:28:42 --> Loader Class Initialized
INFO - 2023-02-16 09:28:42 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:42 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:42 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:42 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:42 --> Total execution time: 0.0385
INFO - 2023-02-16 09:28:44 --> Config Class Initialized
INFO - 2023-02-16 09:28:44 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:44 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:44 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:44 --> URI Class Initialized
INFO - 2023-02-16 09:28:44 --> Router Class Initialized
INFO - 2023-02-16 09:28:44 --> Output Class Initialized
INFO - 2023-02-16 09:28:44 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:44 --> Input Class Initialized
INFO - 2023-02-16 09:28:44 --> Language Class Initialized
INFO - 2023-02-16 09:28:44 --> Loader Class Initialized
INFO - 2023-02-16 09:28:44 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:44 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:44 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:44 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:44 --> Total execution time: 0.0496
INFO - 2023-02-16 09:28:44 --> Config Class Initialized
INFO - 2023-02-16 09:28:44 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:28:44 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:28:44 --> Utf8 Class Initialized
INFO - 2023-02-16 09:28:44 --> URI Class Initialized
INFO - 2023-02-16 09:28:44 --> Router Class Initialized
INFO - 2023-02-16 09:28:44 --> Output Class Initialized
INFO - 2023-02-16 09:28:44 --> Security Class Initialized
DEBUG - 2023-02-16 09:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:28:44 --> Input Class Initialized
INFO - 2023-02-16 09:28:44 --> Language Class Initialized
INFO - 2023-02-16 09:28:44 --> Loader Class Initialized
INFO - 2023-02-16 09:28:44 --> Controller Class Initialized
DEBUG - 2023-02-16 09:28:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:28:44 --> Database Driver Class Initialized
INFO - 2023-02-16 09:28:45 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:28:45 --> Final output sent to browser
DEBUG - 2023-02-16 09:28:45 --> Total execution time: 0.0965
INFO - 2023-02-16 09:34:02 --> Config Class Initialized
INFO - 2023-02-16 09:34:02 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:34:02 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:34:02 --> Utf8 Class Initialized
INFO - 2023-02-16 09:34:02 --> URI Class Initialized
INFO - 2023-02-16 09:34:02 --> Router Class Initialized
INFO - 2023-02-16 09:34:02 --> Output Class Initialized
INFO - 2023-02-16 09:34:02 --> Security Class Initialized
DEBUG - 2023-02-16 09:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:34:02 --> Input Class Initialized
INFO - 2023-02-16 09:34:02 --> Language Class Initialized
INFO - 2023-02-16 09:34:02 --> Loader Class Initialized
INFO - 2023-02-16 09:34:02 --> Controller Class Initialized
DEBUG - 2023-02-16 09:34:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:34:02 --> Database Driver Class Initialized
INFO - 2023-02-16 09:34:02 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:34:02 --> Final output sent to browser
DEBUG - 2023-02-16 09:34:02 --> Total execution time: 0.0495
INFO - 2023-02-16 09:34:02 --> Config Class Initialized
INFO - 2023-02-16 09:34:02 --> Hooks Class Initialized
DEBUG - 2023-02-16 09:34:02 --> UTF-8 Support Enabled
INFO - 2023-02-16 09:34:02 --> Utf8 Class Initialized
INFO - 2023-02-16 09:34:02 --> URI Class Initialized
INFO - 2023-02-16 09:34:02 --> Router Class Initialized
INFO - 2023-02-16 09:34:02 --> Output Class Initialized
INFO - 2023-02-16 09:34:02 --> Security Class Initialized
DEBUG - 2023-02-16 09:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-16 09:34:02 --> Input Class Initialized
INFO - 2023-02-16 09:34:02 --> Language Class Initialized
INFO - 2023-02-16 09:34:02 --> Loader Class Initialized
INFO - 2023-02-16 09:34:02 --> Controller Class Initialized
DEBUG - 2023-02-16 09:34:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-02-16 09:34:02 --> Database Driver Class Initialized
INFO - 2023-02-16 09:34:02 --> Model "Cluster_model" initialized
INFO - 2023-02-16 09:34:02 --> Final output sent to browser
DEBUG - 2023-02-16 09:34:02 --> Total execution time: 0.0902
