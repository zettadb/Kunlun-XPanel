<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-07 06:54:35 --> Config Class Initialized
INFO - 2022-12-07 06:54:35 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:35 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:35 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:35 --> URI Class Initialized
INFO - 2022-12-07 06:54:35 --> Router Class Initialized
INFO - 2022-12-07 06:54:35 --> Output Class Initialized
INFO - 2022-12-07 06:54:35 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:35 --> Input Class Initialized
INFO - 2022-12-07 06:54:35 --> Language Class Initialized
INFO - 2022-12-07 06:54:35 --> Loader Class Initialized
INFO - 2022-12-07 06:54:35 --> Controller Class Initialized
INFO - 2022-12-07 06:54:35 --> Helper loaded: form_helper
INFO - 2022-12-07 06:54:35 --> Helper loaded: url_helper
DEBUG - 2022-12-07 06:54:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:35 --> Model "Change_model" initialized
INFO - 2022-12-07 06:54:35 --> Model "Grafana_model" initialized
INFO - 2022-12-07 06:54:35 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:35 --> Total execution time: 0.0491
INFO - 2022-12-07 06:54:35 --> Config Class Initialized
INFO - 2022-12-07 06:54:35 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:35 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:35 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:35 --> URI Class Initialized
INFO - 2022-12-07 06:54:35 --> Router Class Initialized
INFO - 2022-12-07 06:54:35 --> Output Class Initialized
INFO - 2022-12-07 06:54:35 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:35 --> Input Class Initialized
INFO - 2022-12-07 06:54:35 --> Language Class Initialized
INFO - 2022-12-07 06:54:35 --> Loader Class Initialized
INFO - 2022-12-07 06:54:35 --> Controller Class Initialized
INFO - 2022-12-07 06:54:35 --> Helper loaded: form_helper
INFO - 2022-12-07 06:54:35 --> Helper loaded: url_helper
DEBUG - 2022-12-07 06:54:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:35 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:35 --> Total execution time: 0.0203
INFO - 2022-12-07 06:54:35 --> Config Class Initialized
INFO - 2022-12-07 06:54:35 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:35 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:35 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:35 --> URI Class Initialized
INFO - 2022-12-07 06:54:35 --> Router Class Initialized
INFO - 2022-12-07 06:54:35 --> Output Class Initialized
INFO - 2022-12-07 06:54:35 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:35 --> Input Class Initialized
INFO - 2022-12-07 06:54:35 --> Language Class Initialized
INFO - 2022-12-07 06:54:35 --> Loader Class Initialized
INFO - 2022-12-07 06:54:35 --> Controller Class Initialized
INFO - 2022-12-07 06:54:35 --> Helper loaded: form_helper
INFO - 2022-12-07 06:54:35 --> Helper loaded: url_helper
DEBUG - 2022-12-07 06:54:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:35 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:35 --> Model "Login_model" initialized
INFO - 2022-12-07 06:54:35 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:35 --> Total execution time: 0.0588
INFO - 2022-12-07 06:54:35 --> Config Class Initialized
INFO - 2022-12-07 06:54:35 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:35 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:35 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:35 --> URI Class Initialized
INFO - 2022-12-07 06:54:35 --> Router Class Initialized
INFO - 2022-12-07 06:54:35 --> Output Class Initialized
INFO - 2022-12-07 06:54:35 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:35 --> Input Class Initialized
INFO - 2022-12-07 06:54:35 --> Language Class Initialized
INFO - 2022-12-07 06:54:35 --> Loader Class Initialized
INFO - 2022-12-07 06:54:35 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:35 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:35 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:35 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:35 --> Total execution time: 0.0359
INFO - 2022-12-07 06:54:35 --> Config Class Initialized
INFO - 2022-12-07 06:54:35 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:35 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:35 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:35 --> URI Class Initialized
INFO - 2022-12-07 06:54:35 --> Router Class Initialized
INFO - 2022-12-07 06:54:35 --> Output Class Initialized
INFO - 2022-12-07 06:54:35 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:35 --> Input Class Initialized
INFO - 2022-12-07 06:54:35 --> Language Class Initialized
INFO - 2022-12-07 06:54:35 --> Loader Class Initialized
INFO - 2022-12-07 06:54:35 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:35 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:35 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:35 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:35 --> Total execution time: 0.0368
INFO - 2022-12-07 06:54:35 --> Config Class Initialized
INFO - 2022-12-07 06:54:35 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:35 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:35 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:35 --> URI Class Initialized
INFO - 2022-12-07 06:54:35 --> Router Class Initialized
INFO - 2022-12-07 06:54:35 --> Output Class Initialized
INFO - 2022-12-07 06:54:35 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:35 --> Input Class Initialized
INFO - 2022-12-07 06:54:35 --> Language Class Initialized
INFO - 2022-12-07 06:54:35 --> Loader Class Initialized
INFO - 2022-12-07 06:54:35 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:35 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:36 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:36 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:36 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:36 --> Total execution time: 0.0434
INFO - 2022-12-07 06:54:36 --> Config Class Initialized
INFO - 2022-12-07 06:54:36 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:36 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:36 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:36 --> URI Class Initialized
INFO - 2022-12-07 06:54:36 --> Router Class Initialized
INFO - 2022-12-07 06:54:36 --> Output Class Initialized
INFO - 2022-12-07 06:54:36 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:36 --> Input Class Initialized
INFO - 2022-12-07 06:54:36 --> Language Class Initialized
INFO - 2022-12-07 06:54:36 --> Loader Class Initialized
INFO - 2022-12-07 06:54:36 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:36 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:36 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:36 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:36 --> Total execution time: 0.0541
INFO - 2022-12-07 06:54:39 --> Config Class Initialized
INFO - 2022-12-07 06:54:39 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:39 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:39 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:39 --> URI Class Initialized
INFO - 2022-12-07 06:54:39 --> Router Class Initialized
INFO - 2022-12-07 06:54:39 --> Output Class Initialized
INFO - 2022-12-07 06:54:39 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:39 --> Input Class Initialized
INFO - 2022-12-07 06:54:39 --> Language Class Initialized
INFO - 2022-12-07 06:54:39 --> Loader Class Initialized
INFO - 2022-12-07 06:54:39 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:39 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:40 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:40 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:40 --> Total execution time: 1.1374
INFO - 2022-12-07 06:54:40 --> Config Class Initialized
INFO - 2022-12-07 06:54:40 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:40 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:40 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:40 --> URI Class Initialized
INFO - 2022-12-07 06:54:40 --> Router Class Initialized
INFO - 2022-12-07 06:54:40 --> Output Class Initialized
INFO - 2022-12-07 06:54:40 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:40 --> Input Class Initialized
INFO - 2022-12-07 06:54:40 --> Language Class Initialized
INFO - 2022-12-07 06:54:40 --> Loader Class Initialized
INFO - 2022-12-07 06:54:40 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:40 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:40 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:40 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:40 --> Total execution time: 0.1363
INFO - 2022-12-07 06:54:41 --> Config Class Initialized
INFO - 2022-12-07 06:54:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:41 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:41 --> URI Class Initialized
INFO - 2022-12-07 06:54:41 --> Router Class Initialized
INFO - 2022-12-07 06:54:41 --> Output Class Initialized
INFO - 2022-12-07 06:54:41 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:41 --> Input Class Initialized
INFO - 2022-12-07 06:54:41 --> Language Class Initialized
INFO - 2022-12-07 06:54:41 --> Loader Class Initialized
INFO - 2022-12-07 06:54:41 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:41 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:41 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:41 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:41 --> Total execution time: 0.1529
INFO - 2022-12-07 06:54:41 --> Config Class Initialized
INFO - 2022-12-07 06:54:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:41 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:41 --> URI Class Initialized
INFO - 2022-12-07 06:54:41 --> Router Class Initialized
INFO - 2022-12-07 06:54:41 --> Output Class Initialized
INFO - 2022-12-07 06:54:41 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:41 --> Input Class Initialized
INFO - 2022-12-07 06:54:41 --> Language Class Initialized
INFO - 2022-12-07 06:54:41 --> Loader Class Initialized
INFO - 2022-12-07 06:54:41 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:41 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:41 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:41 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:41 --> Total execution time: 0.1542
INFO - 2022-12-07 06:54:44 --> Config Class Initialized
INFO - 2022-12-07 06:54:44 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:44 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:44 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:44 --> URI Class Initialized
INFO - 2022-12-07 06:54:44 --> Router Class Initialized
INFO - 2022-12-07 06:54:44 --> Output Class Initialized
INFO - 2022-12-07 06:54:44 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:44 --> Input Class Initialized
INFO - 2022-12-07 06:54:44 --> Config Class Initialized
INFO - 2022-12-07 06:54:44 --> Hooks Class Initialized
INFO - 2022-12-07 06:54:44 --> Language Class Initialized
DEBUG - 2022-12-07 06:54:44 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:44 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:44 --> URI Class Initialized
INFO - 2022-12-07 06:54:44 --> Router Class Initialized
INFO - 2022-12-07 06:54:44 --> Loader Class Initialized
INFO - 2022-12-07 06:54:44 --> Controller Class Initialized
INFO - 2022-12-07 06:54:44 --> Output Class Initialized
DEBUG - 2022-12-07 06:54:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:44 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:44 --> Input Class Initialized
INFO - 2022-12-07 06:54:44 --> Language Class Initialized
INFO - 2022-12-07 06:54:44 --> Loader Class Initialized
INFO - 2022-12-07 06:54:44 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:44 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:44 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:44 --> Total execution time: 0.0192
INFO - 2022-12-07 06:54:44 --> Config Class Initialized
INFO - 2022-12-07 06:54:44 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:44 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:44 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:44 --> URI Class Initialized
INFO - 2022-12-07 06:54:44 --> Router Class Initialized
INFO - 2022-12-07 06:54:44 --> Output Class Initialized
INFO - 2022-12-07 06:54:44 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:44 --> Input Class Initialized
INFO - 2022-12-07 06:54:44 --> Language Class Initialized
INFO - 2022-12-07 06:54:44 --> Loader Class Initialized
INFO - 2022-12-07 06:54:44 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:44 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:44 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:44 --> Model "Login_model" initialized
INFO - 2022-12-07 06:54:44 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:44 --> Total execution time: 0.1609
INFO - 2022-12-07 06:54:44 --> Config Class Initialized
INFO - 2022-12-07 06:54:44 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:44 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:44 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:44 --> URI Class Initialized
INFO - 2022-12-07 06:54:44 --> Router Class Initialized
INFO - 2022-12-07 06:54:44 --> Output Class Initialized
INFO - 2022-12-07 06:54:44 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:44 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:44 --> Input Class Initialized
INFO - 2022-12-07 06:54:44 --> Language Class Initialized
INFO - 2022-12-07 06:54:44 --> Loader Class Initialized
INFO - 2022-12-07 06:54:44 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:44 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:44 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:44 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:54:44 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:44 --> Total execution time: 0.2627
INFO - 2022-12-07 06:54:44 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:44 --> Total execution time: 0.1693
INFO - 2022-12-07 06:54:47 --> Config Class Initialized
INFO - 2022-12-07 06:54:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:47 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:47 --> URI Class Initialized
INFO - 2022-12-07 06:54:47 --> Router Class Initialized
INFO - 2022-12-07 06:54:47 --> Output Class Initialized
INFO - 2022-12-07 06:54:47 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:47 --> Input Class Initialized
INFO - 2022-12-07 06:54:47 --> Language Class Initialized
INFO - 2022-12-07 06:54:47 --> Loader Class Initialized
INFO - 2022-12-07 06:54:47 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:47 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:47 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:47 --> Model "Login_model" initialized
INFO - 2022-12-07 06:54:47 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:47 --> Total execution time: 0.0426
INFO - 2022-12-07 06:54:47 --> Config Class Initialized
INFO - 2022-12-07 06:54:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:54:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:54:47 --> Utf8 Class Initialized
INFO - 2022-12-07 06:54:47 --> URI Class Initialized
INFO - 2022-12-07 06:54:47 --> Router Class Initialized
INFO - 2022-12-07 06:54:47 --> Output Class Initialized
INFO - 2022-12-07 06:54:47 --> Security Class Initialized
DEBUG - 2022-12-07 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:54:47 --> Input Class Initialized
INFO - 2022-12-07 06:54:47 --> Language Class Initialized
INFO - 2022-12-07 06:54:47 --> Loader Class Initialized
INFO - 2022-12-07 06:54:47 --> Controller Class Initialized
DEBUG - 2022-12-07 06:54:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:54:47 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:48 --> Database Driver Class Initialized
INFO - 2022-12-07 06:54:48 --> Model "Login_model" initialized
INFO - 2022-12-07 06:54:48 --> Final output sent to browser
DEBUG - 2022-12-07 06:54:48 --> Total execution time: 0.0604
INFO - 2022-12-07 06:55:18 --> Config Class Initialized
INFO - 2022-12-07 06:55:18 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:18 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:18 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:18 --> URI Class Initialized
INFO - 2022-12-07 06:55:18 --> Router Class Initialized
INFO - 2022-12-07 06:55:18 --> Output Class Initialized
INFO - 2022-12-07 06:55:18 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:18 --> Input Class Initialized
INFO - 2022-12-07 06:55:18 --> Language Class Initialized
INFO - 2022-12-07 06:55:18 --> Loader Class Initialized
INFO - 2022-12-07 06:55:18 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:18 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:18 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:18 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:18 --> Total execution time: 0.0704
INFO - 2022-12-07 06:55:18 --> Config Class Initialized
INFO - 2022-12-07 06:55:18 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:18 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:18 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:18 --> URI Class Initialized
INFO - 2022-12-07 06:55:18 --> Router Class Initialized
INFO - 2022-12-07 06:55:18 --> Output Class Initialized
INFO - 2022-12-07 06:55:18 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:18 --> Input Class Initialized
INFO - 2022-12-07 06:55:18 --> Language Class Initialized
INFO - 2022-12-07 06:55:18 --> Loader Class Initialized
INFO - 2022-12-07 06:55:18 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:18 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:18 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:18 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:18 --> Total execution time: 0.0516
INFO - 2022-12-07 06:55:20 --> Config Class Initialized
INFO - 2022-12-07 06:55:20 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:20 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:20 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:20 --> URI Class Initialized
INFO - 2022-12-07 06:55:20 --> Router Class Initialized
INFO - 2022-12-07 06:55:20 --> Output Class Initialized
INFO - 2022-12-07 06:55:20 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:20 --> Input Class Initialized
INFO - 2022-12-07 06:55:20 --> Language Class Initialized
INFO - 2022-12-07 06:55:20 --> Loader Class Initialized
INFO - 2022-12-07 06:55:20 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:20 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:20 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:20 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:20 --> Total execution time: 0.0567
INFO - 2022-12-07 06:55:20 --> Config Class Initialized
INFO - 2022-12-07 06:55:20 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:20 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:20 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:20 --> URI Class Initialized
INFO - 2022-12-07 06:55:20 --> Router Class Initialized
INFO - 2022-12-07 06:55:20 --> Output Class Initialized
INFO - 2022-12-07 06:55:20 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:20 --> Input Class Initialized
INFO - 2022-12-07 06:55:20 --> Language Class Initialized
INFO - 2022-12-07 06:55:21 --> Loader Class Initialized
INFO - 2022-12-07 06:55:21 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:21 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:21 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:21 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:21 --> Total execution time: 0.0570
INFO - 2022-12-07 06:55:25 --> Config Class Initialized
INFO - 2022-12-07 06:55:25 --> Hooks Class Initialized
INFO - 2022-12-07 06:55:25 --> Config Class Initialized
INFO - 2022-12-07 06:55:25 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:25 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:25 --> Utf8 Class Initialized
DEBUG - 2022-12-07 06:55:25 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:25 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:25 --> URI Class Initialized
INFO - 2022-12-07 06:55:25 --> URI Class Initialized
INFO - 2022-12-07 06:55:25 --> Router Class Initialized
INFO - 2022-12-07 06:55:25 --> Router Class Initialized
INFO - 2022-12-07 06:55:25 --> Output Class Initialized
INFO - 2022-12-07 06:55:25 --> Output Class Initialized
INFO - 2022-12-07 06:55:25 --> Security Class Initialized
INFO - 2022-12-07 06:55:25 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-07 06:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:25 --> Input Class Initialized
INFO - 2022-12-07 06:55:25 --> Input Class Initialized
INFO - 2022-12-07 06:55:25 --> Language Class Initialized
INFO - 2022-12-07 06:55:25 --> Language Class Initialized
INFO - 2022-12-07 06:55:25 --> Loader Class Initialized
INFO - 2022-12-07 06:55:25 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:25 --> Final output sent to browser
INFO - 2022-12-07 06:55:25 --> Loader Class Initialized
DEBUG - 2022-12-07 06:55:25 --> Total execution time: 0.0202
INFO - 2022-12-07 06:55:25 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:25 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:25 --> Config Class Initialized
INFO - 2022-12-07 06:55:25 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:25 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:25 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:25 --> URI Class Initialized
INFO - 2022-12-07 06:55:25 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:25 --> Router Class Initialized
INFO - 2022-12-07 06:55:25 --> Output Class Initialized
INFO - 2022-12-07 06:55:25 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:25 --> Total execution time: 0.0381
INFO - 2022-12-07 06:55:25 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:25 --> Input Class Initialized
INFO - 2022-12-07 06:55:25 --> Language Class Initialized
INFO - 2022-12-07 06:55:25 --> Loader Class Initialized
INFO - 2022-12-07 06:55:25 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:25 --> Config Class Initialized
INFO - 2022-12-07 06:55:25 --> Hooks Class Initialized
INFO - 2022-12-07 06:55:25 --> Database Driver Class Initialized
DEBUG - 2022-12-07 06:55:25 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:25 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:25 --> URI Class Initialized
INFO - 2022-12-07 06:55:25 --> Router Class Initialized
INFO - 2022-12-07 06:55:25 --> Output Class Initialized
INFO - 2022-12-07 06:55:25 --> Security Class Initialized
INFO - 2022-12-07 06:55:25 --> Model "Login_model" initialized
DEBUG - 2022-12-07 06:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:25 --> Input Class Initialized
INFO - 2022-12-07 06:55:25 --> Language Class Initialized
INFO - 2022-12-07 06:55:25 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:25 --> Loader Class Initialized
INFO - 2022-12-07 06:55:25 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:25 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:25 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:25 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:25 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:25 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:25 --> Total execution time: 0.0634
INFO - 2022-12-07 06:55:25 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:25 --> Total execution time: 0.0475
INFO - 2022-12-07 06:55:34 --> Config Class Initialized
INFO - 2022-12-07 06:55:34 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:34 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:34 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:34 --> URI Class Initialized
INFO - 2022-12-07 06:55:34 --> Router Class Initialized
INFO - 2022-12-07 06:55:34 --> Output Class Initialized
INFO - 2022-12-07 06:55:34 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:34 --> Input Class Initialized
INFO - 2022-12-07 06:55:34 --> Language Class Initialized
INFO - 2022-12-07 06:55:34 --> Loader Class Initialized
INFO - 2022-12-07 06:55:34 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:34 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:34 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:34 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:34 --> Total execution time: 0.0510
INFO - 2022-12-07 06:55:34 --> Config Class Initialized
INFO - 2022-12-07 06:55:34 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:34 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:34 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:34 --> URI Class Initialized
INFO - 2022-12-07 06:55:34 --> Router Class Initialized
INFO - 2022-12-07 06:55:34 --> Output Class Initialized
INFO - 2022-12-07 06:55:34 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:34 --> Input Class Initialized
INFO - 2022-12-07 06:55:34 --> Language Class Initialized
INFO - 2022-12-07 06:55:34 --> Loader Class Initialized
INFO - 2022-12-07 06:55:34 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:34 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:34 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:34 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:34 --> Total execution time: 0.0349
INFO - 2022-12-07 06:55:37 --> Config Class Initialized
INFO - 2022-12-07 06:55:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:37 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:37 --> URI Class Initialized
INFO - 2022-12-07 06:55:37 --> Router Class Initialized
INFO - 2022-12-07 06:55:37 --> Output Class Initialized
INFO - 2022-12-07 06:55:37 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:37 --> Input Class Initialized
INFO - 2022-12-07 06:55:37 --> Language Class Initialized
INFO - 2022-12-07 06:55:37 --> Loader Class Initialized
INFO - 2022-12-07 06:55:37 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:37 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:37 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:37 --> Total execution time: 0.0521
INFO - 2022-12-07 06:55:37 --> Config Class Initialized
INFO - 2022-12-07 06:55:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 06:55:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 06:55:37 --> Utf8 Class Initialized
INFO - 2022-12-07 06:55:37 --> URI Class Initialized
INFO - 2022-12-07 06:55:37 --> Router Class Initialized
INFO - 2022-12-07 06:55:37 --> Output Class Initialized
INFO - 2022-12-07 06:55:37 --> Security Class Initialized
DEBUG - 2022-12-07 06:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 06:55:37 --> Input Class Initialized
INFO - 2022-12-07 06:55:37 --> Language Class Initialized
INFO - 2022-12-07 06:55:37 --> Loader Class Initialized
INFO - 2022-12-07 06:55:37 --> Controller Class Initialized
DEBUG - 2022-12-07 06:55:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 06:55:37 --> Database Driver Class Initialized
INFO - 2022-12-07 06:55:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 06:55:37 --> Final output sent to browser
DEBUG - 2022-12-07 06:55:37 --> Total execution time: 0.0361
INFO - 2022-12-07 07:00:41 --> Config Class Initialized
INFO - 2022-12-07 07:00:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:00:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:00:41 --> Utf8 Class Initialized
INFO - 2022-12-07 07:00:41 --> URI Class Initialized
INFO - 2022-12-07 07:00:41 --> Router Class Initialized
INFO - 2022-12-07 07:00:41 --> Output Class Initialized
INFO - 2022-12-07 07:00:41 --> Security Class Initialized
DEBUG - 2022-12-07 07:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:00:41 --> Input Class Initialized
INFO - 2022-12-07 07:00:41 --> Language Class Initialized
INFO - 2022-12-07 07:00:41 --> Loader Class Initialized
INFO - 2022-12-07 07:00:41 --> Controller Class Initialized
DEBUG - 2022-12-07 07:00:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:00:41 --> Database Driver Class Initialized
INFO - 2022-12-07 07:00:41 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:00:41 --> Final output sent to browser
DEBUG - 2022-12-07 07:00:41 --> Total execution time: 0.0904
INFO - 2022-12-07 07:00:41 --> Config Class Initialized
INFO - 2022-12-07 07:00:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:00:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:00:41 --> Utf8 Class Initialized
INFO - 2022-12-07 07:00:41 --> URI Class Initialized
INFO - 2022-12-07 07:00:41 --> Router Class Initialized
INFO - 2022-12-07 07:00:41 --> Output Class Initialized
INFO - 2022-12-07 07:00:41 --> Security Class Initialized
DEBUG - 2022-12-07 07:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:00:41 --> Input Class Initialized
INFO - 2022-12-07 07:00:41 --> Language Class Initialized
INFO - 2022-12-07 07:00:41 --> Loader Class Initialized
INFO - 2022-12-07 07:00:41 --> Controller Class Initialized
DEBUG - 2022-12-07 07:00:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:00:41 --> Database Driver Class Initialized
INFO - 2022-12-07 07:00:41 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:00:41 --> Final output sent to browser
DEBUG - 2022-12-07 07:00:41 --> Total execution time: 0.0606
INFO - 2022-12-07 07:00:57 --> Config Class Initialized
INFO - 2022-12-07 07:00:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:00:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:00:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:00:57 --> URI Class Initialized
INFO - 2022-12-07 07:00:57 --> Router Class Initialized
INFO - 2022-12-07 07:00:57 --> Output Class Initialized
INFO - 2022-12-07 07:00:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:00:57 --> Input Class Initialized
INFO - 2022-12-07 07:00:57 --> Language Class Initialized
INFO - 2022-12-07 07:00:57 --> Loader Class Initialized
INFO - 2022-12-07 07:00:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:00:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:00:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:00:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:00:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:00:57 --> Total execution time: 0.0689
INFO - 2022-12-07 07:00:57 --> Config Class Initialized
INFO - 2022-12-07 07:00:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:00:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:00:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:00:57 --> URI Class Initialized
INFO - 2022-12-07 07:00:57 --> Router Class Initialized
INFO - 2022-12-07 07:00:57 --> Output Class Initialized
INFO - 2022-12-07 07:00:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:00:57 --> Input Class Initialized
INFO - 2022-12-07 07:00:57 --> Language Class Initialized
INFO - 2022-12-07 07:00:57 --> Loader Class Initialized
INFO - 2022-12-07 07:00:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:00:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:00:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:00:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:00:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:00:57 --> Total execution time: 0.0361
INFO - 2022-12-07 07:01:00 --> Config Class Initialized
INFO - 2022-12-07 07:01:00 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:00 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:00 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:00 --> URI Class Initialized
INFO - 2022-12-07 07:01:00 --> Router Class Initialized
INFO - 2022-12-07 07:01:00 --> Output Class Initialized
INFO - 2022-12-07 07:01:00 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:00 --> Input Class Initialized
INFO - 2022-12-07 07:01:00 --> Language Class Initialized
INFO - 2022-12-07 07:01:00 --> Loader Class Initialized
INFO - 2022-12-07 07:01:00 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:00 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:00 --> Total execution time: 0.0206
INFO - 2022-12-07 07:01:00 --> Config Class Initialized
INFO - 2022-12-07 07:01:00 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:00 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:00 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:00 --> URI Class Initialized
INFO - 2022-12-07 07:01:00 --> Router Class Initialized
INFO - 2022-12-07 07:01:00 --> Output Class Initialized
INFO - 2022-12-07 07:01:00 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:00 --> Input Class Initialized
INFO - 2022-12-07 07:01:00 --> Language Class Initialized
INFO - 2022-12-07 07:01:00 --> Loader Class Initialized
INFO - 2022-12-07 07:01:00 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:00 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:00 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:00 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:00 --> Total execution time: 0.0539
INFO - 2022-12-07 07:01:00 --> Config Class Initialized
INFO - 2022-12-07 07:01:00 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:00 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:00 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:00 --> URI Class Initialized
INFO - 2022-12-07 07:01:00 --> Router Class Initialized
INFO - 2022-12-07 07:01:00 --> Output Class Initialized
INFO - 2022-12-07 07:01:00 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:00 --> Input Class Initialized
INFO - 2022-12-07 07:01:00 --> Language Class Initialized
INFO - 2022-12-07 07:01:00 --> Loader Class Initialized
INFO - 2022-12-07 07:01:00 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:00 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:00 --> Total execution time: 0.0201
INFO - 2022-12-07 07:01:00 --> Config Class Initialized
INFO - 2022-12-07 07:01:00 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:00 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:00 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:00 --> URI Class Initialized
INFO - 2022-12-07 07:01:00 --> Router Class Initialized
INFO - 2022-12-07 07:01:00 --> Output Class Initialized
INFO - 2022-12-07 07:01:00 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:00 --> Input Class Initialized
INFO - 2022-12-07 07:01:00 --> Language Class Initialized
INFO - 2022-12-07 07:01:00 --> Loader Class Initialized
INFO - 2022-12-07 07:01:00 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:00 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:00 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:00 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:00 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:00 --> Total execution time: 0.0344
INFO - 2022-12-07 07:01:21 --> Config Class Initialized
INFO - 2022-12-07 07:01:21 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:21 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:21 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:21 --> URI Class Initialized
INFO - 2022-12-07 07:01:21 --> Router Class Initialized
INFO - 2022-12-07 07:01:21 --> Output Class Initialized
INFO - 2022-12-07 07:01:21 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:21 --> Input Class Initialized
INFO - 2022-12-07 07:01:21 --> Language Class Initialized
INFO - 2022-12-07 07:01:21 --> Loader Class Initialized
INFO - 2022-12-07 07:01:21 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:21 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:21 --> Total execution time: 0.0195
INFO - 2022-12-07 07:01:21 --> Config Class Initialized
INFO - 2022-12-07 07:01:21 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:21 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:21 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:21 --> URI Class Initialized
INFO - 2022-12-07 07:01:21 --> Router Class Initialized
INFO - 2022-12-07 07:01:21 --> Output Class Initialized
INFO - 2022-12-07 07:01:21 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:21 --> Input Class Initialized
INFO - 2022-12-07 07:01:21 --> Language Class Initialized
INFO - 2022-12-07 07:01:21 --> Loader Class Initialized
INFO - 2022-12-07 07:01:21 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:21 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:21 --> Model "Login_model" initialized
INFO - 2022-12-07 07:01:21 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:21 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:21 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:21 --> Total execution time: 0.0834
INFO - 2022-12-07 07:01:21 --> Config Class Initialized
INFO - 2022-12-07 07:01:21 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:21 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:21 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:21 --> URI Class Initialized
INFO - 2022-12-07 07:01:21 --> Router Class Initialized
INFO - 2022-12-07 07:01:21 --> Output Class Initialized
INFO - 2022-12-07 07:01:21 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:21 --> Input Class Initialized
INFO - 2022-12-07 07:01:21 --> Language Class Initialized
INFO - 2022-12-07 07:01:21 --> Loader Class Initialized
INFO - 2022-12-07 07:01:21 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:21 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:21 --> Total execution time: 0.0208
INFO - 2022-12-07 07:01:21 --> Config Class Initialized
INFO - 2022-12-07 07:01:21 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:21 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:21 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:21 --> URI Class Initialized
INFO - 2022-12-07 07:01:21 --> Router Class Initialized
INFO - 2022-12-07 07:01:21 --> Output Class Initialized
INFO - 2022-12-07 07:01:21 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:21 --> Input Class Initialized
INFO - 2022-12-07 07:01:21 --> Language Class Initialized
INFO - 2022-12-07 07:01:21 --> Loader Class Initialized
INFO - 2022-12-07 07:01:21 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:21 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:21 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:21 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:21 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:21 --> Total execution time: 0.1380
INFO - 2022-12-07 07:01:26 --> Config Class Initialized
INFO - 2022-12-07 07:01:26 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:26 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:26 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:26 --> URI Class Initialized
INFO - 2022-12-07 07:01:26 --> Router Class Initialized
INFO - 2022-12-07 07:01:26 --> Output Class Initialized
INFO - 2022-12-07 07:01:26 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:26 --> Input Class Initialized
INFO - 2022-12-07 07:01:26 --> Language Class Initialized
INFO - 2022-12-07 07:01:26 --> Loader Class Initialized
INFO - 2022-12-07 07:01:26 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:26 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:26 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:26 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:26 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:26 --> Total execution time: 0.0659
INFO - 2022-12-07 07:01:31 --> Config Class Initialized
INFO - 2022-12-07 07:01:31 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:31 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:31 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:31 --> URI Class Initialized
INFO - 2022-12-07 07:01:31 --> Router Class Initialized
INFO - 2022-12-07 07:01:31 --> Output Class Initialized
INFO - 2022-12-07 07:01:31 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:31 --> Input Class Initialized
INFO - 2022-12-07 07:01:31 --> Language Class Initialized
INFO - 2022-12-07 07:01:31 --> Loader Class Initialized
INFO - 2022-12-07 07:01:31 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:31 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:31 --> Total execution time: 0.0209
INFO - 2022-12-07 07:01:31 --> Config Class Initialized
INFO - 2022-12-07 07:01:31 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:31 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:31 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:31 --> URI Class Initialized
INFO - 2022-12-07 07:01:31 --> Router Class Initialized
INFO - 2022-12-07 07:01:31 --> Output Class Initialized
INFO - 2022-12-07 07:01:31 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:31 --> Input Class Initialized
INFO - 2022-12-07 07:01:31 --> Language Class Initialized
INFO - 2022-12-07 07:01:31 --> Loader Class Initialized
INFO - 2022-12-07 07:01:31 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:31 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:31 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:31 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:31 --> Total execution time: 0.0754
INFO - 2022-12-07 07:01:36 --> Config Class Initialized
INFO - 2022-12-07 07:01:36 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:36 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:36 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:36 --> URI Class Initialized
INFO - 2022-12-07 07:01:36 --> Router Class Initialized
INFO - 2022-12-07 07:01:36 --> Output Class Initialized
INFO - 2022-12-07 07:01:36 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:36 --> Input Class Initialized
INFO - 2022-12-07 07:01:36 --> Language Class Initialized
INFO - 2022-12-07 07:01:36 --> Loader Class Initialized
INFO - 2022-12-07 07:01:36 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:36 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:36 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:36 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:39 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:39 --> Total execution time: 3.3785
INFO - 2022-12-07 07:01:41 --> Config Class Initialized
INFO - 2022-12-07 07:01:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:41 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:41 --> URI Class Initialized
INFO - 2022-12-07 07:01:41 --> Router Class Initialized
INFO - 2022-12-07 07:01:41 --> Output Class Initialized
INFO - 2022-12-07 07:01:41 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:41 --> Input Class Initialized
INFO - 2022-12-07 07:01:41 --> Language Class Initialized
INFO - 2022-12-07 07:01:41 --> Loader Class Initialized
INFO - 2022-12-07 07:01:41 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:41 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:41 --> Total execution time: 0.0208
INFO - 2022-12-07 07:01:41 --> Config Class Initialized
INFO - 2022-12-07 07:01:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:41 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:41 --> URI Class Initialized
INFO - 2022-12-07 07:01:41 --> Router Class Initialized
INFO - 2022-12-07 07:01:41 --> Output Class Initialized
INFO - 2022-12-07 07:01:41 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:41 --> Input Class Initialized
INFO - 2022-12-07 07:01:41 --> Language Class Initialized
INFO - 2022-12-07 07:01:41 --> Loader Class Initialized
INFO - 2022-12-07 07:01:41 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:41 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:41 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:41 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:41 --> Total execution time: 0.0490
INFO - 2022-12-07 07:01:46 --> Config Class Initialized
INFO - 2022-12-07 07:01:46 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:46 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:46 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:46 --> URI Class Initialized
INFO - 2022-12-07 07:01:46 --> Router Class Initialized
INFO - 2022-12-07 07:01:46 --> Output Class Initialized
INFO - 2022-12-07 07:01:46 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:46 --> Input Class Initialized
INFO - 2022-12-07 07:01:46 --> Language Class Initialized
INFO - 2022-12-07 07:01:46 --> Loader Class Initialized
INFO - 2022-12-07 07:01:46 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:46 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:46 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:46 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:46 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:46 --> Total execution time: 0.0716
INFO - 2022-12-07 07:01:51 --> Config Class Initialized
INFO - 2022-12-07 07:01:51 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:51 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:51 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:51 --> URI Class Initialized
INFO - 2022-12-07 07:01:51 --> Router Class Initialized
INFO - 2022-12-07 07:01:51 --> Output Class Initialized
INFO - 2022-12-07 07:01:51 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:51 --> Input Class Initialized
INFO - 2022-12-07 07:01:51 --> Language Class Initialized
INFO - 2022-12-07 07:01:51 --> Loader Class Initialized
INFO - 2022-12-07 07:01:51 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:51 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:51 --> Total execution time: 0.0211
INFO - 2022-12-07 07:01:51 --> Config Class Initialized
INFO - 2022-12-07 07:01:51 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:51 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:51 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:51 --> URI Class Initialized
INFO - 2022-12-07 07:01:51 --> Router Class Initialized
INFO - 2022-12-07 07:01:51 --> Output Class Initialized
INFO - 2022-12-07 07:01:51 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:51 --> Input Class Initialized
INFO - 2022-12-07 07:01:51 --> Language Class Initialized
INFO - 2022-12-07 07:01:51 --> Loader Class Initialized
INFO - 2022-12-07 07:01:51 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:51 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:51 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:51 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:51 --> Total execution time: 0.0530
INFO - 2022-12-07 07:01:56 --> Config Class Initialized
INFO - 2022-12-07 07:01:56 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:01:56 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:01:56 --> Utf8 Class Initialized
INFO - 2022-12-07 07:01:56 --> URI Class Initialized
INFO - 2022-12-07 07:01:56 --> Router Class Initialized
INFO - 2022-12-07 07:01:56 --> Output Class Initialized
INFO - 2022-12-07 07:01:56 --> Security Class Initialized
DEBUG - 2022-12-07 07:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:01:56 --> Input Class Initialized
INFO - 2022-12-07 07:01:56 --> Language Class Initialized
INFO - 2022-12-07 07:01:56 --> Loader Class Initialized
INFO - 2022-12-07 07:01:56 --> Controller Class Initialized
DEBUG - 2022-12-07 07:01:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:01:56 --> Database Driver Class Initialized
INFO - 2022-12-07 07:01:56 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:01:56 --> Final output sent to browser
DEBUG - 2022-12-07 07:01:56 --> Total execution time: 0.0416
INFO - 2022-12-07 07:02:01 --> Config Class Initialized
INFO - 2022-12-07 07:02:01 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:02:01 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:02:01 --> Utf8 Class Initialized
INFO - 2022-12-07 07:02:01 --> URI Class Initialized
INFO - 2022-12-07 07:02:01 --> Router Class Initialized
INFO - 2022-12-07 07:02:01 --> Output Class Initialized
INFO - 2022-12-07 07:02:01 --> Security Class Initialized
DEBUG - 2022-12-07 07:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:02:01 --> Input Class Initialized
INFO - 2022-12-07 07:02:01 --> Language Class Initialized
INFO - 2022-12-07 07:02:01 --> Loader Class Initialized
INFO - 2022-12-07 07:02:01 --> Controller Class Initialized
DEBUG - 2022-12-07 07:02:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:02:01 --> Final output sent to browser
DEBUG - 2022-12-07 07:02:01 --> Total execution time: 0.0217
INFO - 2022-12-07 07:02:01 --> Config Class Initialized
INFO - 2022-12-07 07:02:01 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:02:01 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:02:01 --> Utf8 Class Initialized
INFO - 2022-12-07 07:02:01 --> URI Class Initialized
INFO - 2022-12-07 07:02:01 --> Router Class Initialized
INFO - 2022-12-07 07:02:01 --> Output Class Initialized
INFO - 2022-12-07 07:02:01 --> Security Class Initialized
DEBUG - 2022-12-07 07:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:02:01 --> Input Class Initialized
INFO - 2022-12-07 07:02:01 --> Language Class Initialized
INFO - 2022-12-07 07:02:01 --> Loader Class Initialized
INFO - 2022-12-07 07:02:01 --> Controller Class Initialized
DEBUG - 2022-12-07 07:02:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:02:01 --> Database Driver Class Initialized
INFO - 2022-12-07 07:02:01 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:02:01 --> Final output sent to browser
DEBUG - 2022-12-07 07:02:01 --> Total execution time: 0.0357
INFO - 2022-12-07 07:02:47 --> Config Class Initialized
INFO - 2022-12-07 07:02:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:02:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:02:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:02:47 --> URI Class Initialized
INFO - 2022-12-07 07:02:47 --> Router Class Initialized
INFO - 2022-12-07 07:02:47 --> Output Class Initialized
INFO - 2022-12-07 07:02:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:02:47 --> Input Class Initialized
INFO - 2022-12-07 07:02:47 --> Language Class Initialized
INFO - 2022-12-07 07:02:47 --> Loader Class Initialized
INFO - 2022-12-07 07:02:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:02:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:02:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:02:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:02:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:02:47 --> Total execution time: 0.0477
INFO - 2022-12-07 07:02:47 --> Config Class Initialized
INFO - 2022-12-07 07:02:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:02:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:02:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:02:47 --> URI Class Initialized
INFO - 2022-12-07 07:02:47 --> Router Class Initialized
INFO - 2022-12-07 07:02:47 --> Output Class Initialized
INFO - 2022-12-07 07:02:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:02:47 --> Input Class Initialized
INFO - 2022-12-07 07:02:47 --> Language Class Initialized
INFO - 2022-12-07 07:02:47 --> Loader Class Initialized
INFO - 2022-12-07 07:02:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:02:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:02:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:02:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:02:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:02:47 --> Total execution time: 0.0495
INFO - 2022-12-07 07:03:01 --> Config Class Initialized
INFO - 2022-12-07 07:03:01 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:01 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:01 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:01 --> URI Class Initialized
INFO - 2022-12-07 07:03:01 --> Router Class Initialized
INFO - 2022-12-07 07:03:01 --> Output Class Initialized
INFO - 2022-12-07 07:03:01 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:01 --> Input Class Initialized
INFO - 2022-12-07 07:03:01 --> Language Class Initialized
INFO - 2022-12-07 07:03:01 --> Loader Class Initialized
INFO - 2022-12-07 07:03:01 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:01 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:01 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:01 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:01 --> Total execution time: 0.0704
INFO - 2022-12-07 07:03:01 --> Config Class Initialized
INFO - 2022-12-07 07:03:01 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:01 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:01 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:01 --> URI Class Initialized
INFO - 2022-12-07 07:03:01 --> Router Class Initialized
INFO - 2022-12-07 07:03:01 --> Output Class Initialized
INFO - 2022-12-07 07:03:01 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:01 --> Input Class Initialized
INFO - 2022-12-07 07:03:01 --> Language Class Initialized
INFO - 2022-12-07 07:03:01 --> Loader Class Initialized
INFO - 2022-12-07 07:03:01 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:01 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:01 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:01 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:01 --> Total execution time: 0.0419
INFO - 2022-12-07 07:03:17 --> Config Class Initialized
INFO - 2022-12-07 07:03:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:17 --> URI Class Initialized
INFO - 2022-12-07 07:03:17 --> Router Class Initialized
INFO - 2022-12-07 07:03:17 --> Output Class Initialized
INFO - 2022-12-07 07:03:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:17 --> Input Class Initialized
INFO - 2022-12-07 07:03:17 --> Language Class Initialized
INFO - 2022-12-07 07:03:17 --> Loader Class Initialized
INFO - 2022-12-07 07:03:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:17 --> Total execution time: 0.0563
INFO - 2022-12-07 07:03:17 --> Config Class Initialized
INFO - 2022-12-07 07:03:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:17 --> URI Class Initialized
INFO - 2022-12-07 07:03:17 --> Router Class Initialized
INFO - 2022-12-07 07:03:17 --> Output Class Initialized
INFO - 2022-12-07 07:03:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:17 --> Input Class Initialized
INFO - 2022-12-07 07:03:17 --> Language Class Initialized
INFO - 2022-12-07 07:03:17 --> Loader Class Initialized
INFO - 2022-12-07 07:03:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:17 --> Total execution time: 0.0341
INFO - 2022-12-07 07:03:19 --> Config Class Initialized
INFO - 2022-12-07 07:03:19 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:19 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:19 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:19 --> URI Class Initialized
INFO - 2022-12-07 07:03:19 --> Router Class Initialized
INFO - 2022-12-07 07:03:19 --> Output Class Initialized
INFO - 2022-12-07 07:03:19 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:19 --> Input Class Initialized
INFO - 2022-12-07 07:03:19 --> Language Class Initialized
INFO - 2022-12-07 07:03:19 --> Loader Class Initialized
INFO - 2022-12-07 07:03:19 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:19 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:19 --> Total execution time: 0.0197
INFO - 2022-12-07 07:03:19 --> Config Class Initialized
INFO - 2022-12-07 07:03:19 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:19 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:19 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:19 --> URI Class Initialized
INFO - 2022-12-07 07:03:19 --> Router Class Initialized
INFO - 2022-12-07 07:03:19 --> Output Class Initialized
INFO - 2022-12-07 07:03:19 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:19 --> Input Class Initialized
INFO - 2022-12-07 07:03:19 --> Language Class Initialized
INFO - 2022-12-07 07:03:19 --> Loader Class Initialized
INFO - 2022-12-07 07:03:19 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:19 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:19 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:19 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:19 --> Total execution time: 0.0345
INFO - 2022-12-07 07:03:19 --> Config Class Initialized
INFO - 2022-12-07 07:03:19 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:19 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:19 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:19 --> URI Class Initialized
INFO - 2022-12-07 07:03:19 --> Router Class Initialized
INFO - 2022-12-07 07:03:19 --> Output Class Initialized
INFO - 2022-12-07 07:03:19 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:19 --> Input Class Initialized
INFO - 2022-12-07 07:03:19 --> Language Class Initialized
INFO - 2022-12-07 07:03:19 --> Loader Class Initialized
INFO - 2022-12-07 07:03:19 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:19 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:19 --> Total execution time: 0.0208
INFO - 2022-12-07 07:03:19 --> Config Class Initialized
INFO - 2022-12-07 07:03:19 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:19 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:19 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:19 --> URI Class Initialized
INFO - 2022-12-07 07:03:19 --> Router Class Initialized
INFO - 2022-12-07 07:03:19 --> Output Class Initialized
INFO - 2022-12-07 07:03:19 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:19 --> Input Class Initialized
INFO - 2022-12-07 07:03:19 --> Language Class Initialized
INFO - 2022-12-07 07:03:19 --> Loader Class Initialized
INFO - 2022-12-07 07:03:19 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:19 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:19 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:19 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:19 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:19 --> Total execution time: 0.0565
INFO - 2022-12-07 07:03:29 --> Config Class Initialized
INFO - 2022-12-07 07:03:29 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:29 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:29 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:29 --> URI Class Initialized
INFO - 2022-12-07 07:03:29 --> Router Class Initialized
INFO - 2022-12-07 07:03:29 --> Output Class Initialized
INFO - 2022-12-07 07:03:29 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:29 --> Input Class Initialized
INFO - 2022-12-07 07:03:29 --> Language Class Initialized
INFO - 2022-12-07 07:03:29 --> Loader Class Initialized
INFO - 2022-12-07 07:03:29 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:29 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:29 --> Total execution time: 0.0208
INFO - 2022-12-07 07:03:29 --> Config Class Initialized
INFO - 2022-12-07 07:03:29 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:29 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:29 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:29 --> URI Class Initialized
INFO - 2022-12-07 07:03:29 --> Router Class Initialized
INFO - 2022-12-07 07:03:29 --> Output Class Initialized
INFO - 2022-12-07 07:03:29 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:29 --> Input Class Initialized
INFO - 2022-12-07 07:03:29 --> Language Class Initialized
INFO - 2022-12-07 07:03:29 --> Loader Class Initialized
INFO - 2022-12-07 07:03:29 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:29 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:29 --> Model "Login_model" initialized
INFO - 2022-12-07 07:03:29 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:29 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:29 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:29 --> Total execution time: 0.0697
INFO - 2022-12-07 07:03:29 --> Config Class Initialized
INFO - 2022-12-07 07:03:29 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:29 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:29 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:29 --> URI Class Initialized
INFO - 2022-12-07 07:03:29 --> Router Class Initialized
INFO - 2022-12-07 07:03:29 --> Output Class Initialized
INFO - 2022-12-07 07:03:29 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:29 --> Input Class Initialized
INFO - 2022-12-07 07:03:29 --> Language Class Initialized
INFO - 2022-12-07 07:03:29 --> Loader Class Initialized
INFO - 2022-12-07 07:03:29 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:29 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:29 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:29 --> Total execution time: 0.0206
INFO - 2022-12-07 07:03:29 --> Config Class Initialized
INFO - 2022-12-07 07:03:29 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:29 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:29 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:29 --> URI Class Initialized
INFO - 2022-12-07 07:03:29 --> Router Class Initialized
INFO - 2022-12-07 07:03:29 --> Output Class Initialized
INFO - 2022-12-07 07:03:29 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:29 --> Input Class Initialized
INFO - 2022-12-07 07:03:29 --> Language Class Initialized
INFO - 2022-12-07 07:03:29 --> Loader Class Initialized
INFO - 2022-12-07 07:03:30 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:30 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:30 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:30 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:30 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:30 --> Total execution time: 0.3425
INFO - 2022-12-07 07:03:34 --> Config Class Initialized
INFO - 2022-12-07 07:03:34 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:34 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:34 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:34 --> URI Class Initialized
INFO - 2022-12-07 07:03:34 --> Router Class Initialized
INFO - 2022-12-07 07:03:34 --> Output Class Initialized
INFO - 2022-12-07 07:03:34 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:34 --> Input Class Initialized
INFO - 2022-12-07 07:03:34 --> Language Class Initialized
INFO - 2022-12-07 07:03:34 --> Loader Class Initialized
INFO - 2022-12-07 07:03:34 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:34 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:34 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:34 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:34 --> Total execution time: 0.0351
INFO - 2022-12-07 07:03:39 --> Config Class Initialized
INFO - 2022-12-07 07:03:39 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:39 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:39 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:39 --> URI Class Initialized
INFO - 2022-12-07 07:03:39 --> Router Class Initialized
INFO - 2022-12-07 07:03:39 --> Output Class Initialized
INFO - 2022-12-07 07:03:39 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:39 --> Input Class Initialized
INFO - 2022-12-07 07:03:39 --> Language Class Initialized
INFO - 2022-12-07 07:03:39 --> Loader Class Initialized
INFO - 2022-12-07 07:03:39 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:39 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:39 --> Total execution time: 0.0215
INFO - 2022-12-07 07:03:39 --> Config Class Initialized
INFO - 2022-12-07 07:03:39 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:39 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:39 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:39 --> URI Class Initialized
INFO - 2022-12-07 07:03:39 --> Router Class Initialized
INFO - 2022-12-07 07:03:39 --> Output Class Initialized
INFO - 2022-12-07 07:03:39 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:39 --> Input Class Initialized
INFO - 2022-12-07 07:03:39 --> Language Class Initialized
INFO - 2022-12-07 07:03:39 --> Loader Class Initialized
INFO - 2022-12-07 07:03:39 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:39 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:39 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:40 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:40 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:40 --> Total execution time: 0.0507
INFO - 2022-12-07 07:03:44 --> Config Class Initialized
INFO - 2022-12-07 07:03:44 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:44 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:44 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:44 --> URI Class Initialized
INFO - 2022-12-07 07:03:44 --> Router Class Initialized
INFO - 2022-12-07 07:03:44 --> Output Class Initialized
INFO - 2022-12-07 07:03:44 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:44 --> Input Class Initialized
INFO - 2022-12-07 07:03:44 --> Language Class Initialized
INFO - 2022-12-07 07:03:44 --> Loader Class Initialized
INFO - 2022-12-07 07:03:44 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:44 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:44 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:44 --> Total execution time: 0.0206
INFO - 2022-12-07 07:03:45 --> Config Class Initialized
INFO - 2022-12-07 07:03:45 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:45 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:45 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:45 --> URI Class Initialized
INFO - 2022-12-07 07:03:45 --> Router Class Initialized
INFO - 2022-12-07 07:03:45 --> Output Class Initialized
INFO - 2022-12-07 07:03:45 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:45 --> Input Class Initialized
INFO - 2022-12-07 07:03:45 --> Language Class Initialized
INFO - 2022-12-07 07:03:45 --> Loader Class Initialized
INFO - 2022-12-07 07:03:45 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:45 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:45 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:45 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:45 --> Total execution time: 0.1064
INFO - 2022-12-07 07:03:50 --> Config Class Initialized
INFO - 2022-12-07 07:03:50 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:50 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:50 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:50 --> URI Class Initialized
INFO - 2022-12-07 07:03:50 --> Router Class Initialized
INFO - 2022-12-07 07:03:50 --> Output Class Initialized
INFO - 2022-12-07 07:03:50 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:50 --> Input Class Initialized
INFO - 2022-12-07 07:03:50 --> Language Class Initialized
INFO - 2022-12-07 07:03:50 --> Loader Class Initialized
INFO - 2022-12-07 07:03:50 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:50 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:50 --> Total execution time: 0.0209
INFO - 2022-12-07 07:03:51 --> Config Class Initialized
INFO - 2022-12-07 07:03:51 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:51 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:51 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:51 --> URI Class Initialized
INFO - 2022-12-07 07:03:51 --> Router Class Initialized
INFO - 2022-12-07 07:03:51 --> Output Class Initialized
INFO - 2022-12-07 07:03:51 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:51 --> Input Class Initialized
INFO - 2022-12-07 07:03:51 --> Language Class Initialized
INFO - 2022-12-07 07:03:51 --> Loader Class Initialized
INFO - 2022-12-07 07:03:51 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:51 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:51 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:51 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:51 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:51 --> Total execution time: 0.4628
INFO - 2022-12-07 07:03:55 --> Config Class Initialized
INFO - 2022-12-07 07:03:55 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:03:55 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:03:55 --> Utf8 Class Initialized
INFO - 2022-12-07 07:03:55 --> URI Class Initialized
INFO - 2022-12-07 07:03:55 --> Router Class Initialized
INFO - 2022-12-07 07:03:55 --> Output Class Initialized
INFO - 2022-12-07 07:03:55 --> Security Class Initialized
DEBUG - 2022-12-07 07:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:03:55 --> Input Class Initialized
INFO - 2022-12-07 07:03:56 --> Language Class Initialized
INFO - 2022-12-07 07:03:56 --> Loader Class Initialized
INFO - 2022-12-07 07:03:56 --> Controller Class Initialized
DEBUG - 2022-12-07 07:03:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:03:56 --> Database Driver Class Initialized
INFO - 2022-12-07 07:03:56 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:03:56 --> Final output sent to browser
DEBUG - 2022-12-07 07:03:56 --> Total execution time: 0.0399
INFO - 2022-12-07 07:04:00 --> Config Class Initialized
INFO - 2022-12-07 07:04:00 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:00 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:00 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:00 --> URI Class Initialized
INFO - 2022-12-07 07:04:00 --> Router Class Initialized
INFO - 2022-12-07 07:04:00 --> Output Class Initialized
INFO - 2022-12-07 07:04:00 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:00 --> Input Class Initialized
INFO - 2022-12-07 07:04:01 --> Language Class Initialized
INFO - 2022-12-07 07:04:01 --> Loader Class Initialized
INFO - 2022-12-07 07:04:01 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:01 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:01 --> Total execution time: 0.0208
INFO - 2022-12-07 07:04:01 --> Config Class Initialized
INFO - 2022-12-07 07:04:01 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:01 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:01 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:01 --> URI Class Initialized
INFO - 2022-12-07 07:04:01 --> Router Class Initialized
INFO - 2022-12-07 07:04:01 --> Output Class Initialized
INFO - 2022-12-07 07:04:01 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:01 --> Input Class Initialized
INFO - 2022-12-07 07:04:01 --> Language Class Initialized
INFO - 2022-12-07 07:04:01 --> Loader Class Initialized
INFO - 2022-12-07 07:04:01 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:01 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:01 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:01 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:04 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:04 --> Total execution time: 3.7873
INFO - 2022-12-07 07:04:42 --> Config Class Initialized
INFO - 2022-12-07 07:04:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:42 --> URI Class Initialized
INFO - 2022-12-07 07:04:42 --> Router Class Initialized
INFO - 2022-12-07 07:04:42 --> Output Class Initialized
INFO - 2022-12-07 07:04:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:42 --> Input Class Initialized
INFO - 2022-12-07 07:04:42 --> Language Class Initialized
INFO - 2022-12-07 07:04:42 --> Loader Class Initialized
INFO - 2022-12-07 07:04:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:42 --> Total execution time: 0.0204
INFO - 2022-12-07 07:04:42 --> Config Class Initialized
INFO - 2022-12-07 07:04:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:42 --> URI Class Initialized
INFO - 2022-12-07 07:04:42 --> Router Class Initialized
INFO - 2022-12-07 07:04:42 --> Output Class Initialized
INFO - 2022-12-07 07:04:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:42 --> Input Class Initialized
INFO - 2022-12-07 07:04:42 --> Language Class Initialized
INFO - 2022-12-07 07:04:42 --> Loader Class Initialized
INFO - 2022-12-07 07:04:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:42 --> Model "Login_model" initialized
INFO - 2022-12-07 07:04:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:42 --> Model "Cluster_model" initialized
ERROR - 2022-12-07 07:04:42 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php 1048
ERROR - 2022-12-07 07:04:42 --> Severity: 8192 --> preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2022-12-07 07:04:42 --> Severity: 8192 --> mysqli::query(): Passing null to parameter #1 ($query) of type string is deprecated C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2022-12-07 07:04:42 --> Exception of type 'ValueError' occurred with Message: mysqli::query(): Argument #1 ($query) cannot be empty in File C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php at Line 307
 Backtrace 
#0 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\drivers\mysqli\mysqli_driver.php(307): mysqli->query('')
#1 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(791): CI_DB_mysqli_driver->_execute(NULL)
#2 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\database\DB_driver.php(654): CI_DB_driver->simple_query(NULL)
#3 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\models\Cluster_model.php(21): CI_DB_driver->query(NULL)
#4 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\controllers\user\Cluster.php(1271): Cluster_model->getList(NULL)
#5 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\system\core\CodeIgniter.php(532): Cluster->getEffectCluster()
#6 C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\index.php(289): require_once('C:\\Users\\abduin...')
#7 {main}
INFO - 2022-12-07 07:04:43 --> Config Class Initialized
INFO - 2022-12-07 07:04:43 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:43 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:43 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:43 --> URI Class Initialized
INFO - 2022-12-07 07:04:43 --> Router Class Initialized
INFO - 2022-12-07 07:04:43 --> Output Class Initialized
INFO - 2022-12-07 07:04:43 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:43 --> Input Class Initialized
INFO - 2022-12-07 07:04:43 --> Language Class Initialized
INFO - 2022-12-07 07:04:43 --> Loader Class Initialized
INFO - 2022-12-07 07:04:43 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:43 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:43 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:43 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:43 --> Total execution time: 0.1953
INFO - 2022-12-07 07:04:43 --> Config Class Initialized
INFO - 2022-12-07 07:04:43 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:43 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:43 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:43 --> URI Class Initialized
INFO - 2022-12-07 07:04:43 --> Router Class Initialized
INFO - 2022-12-07 07:04:43 --> Output Class Initialized
INFO - 2022-12-07 07:04:43 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:43 --> Input Class Initialized
INFO - 2022-12-07 07:04:43 --> Language Class Initialized
INFO - 2022-12-07 07:04:43 --> Loader Class Initialized
INFO - 2022-12-07 07:04:43 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:43 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:43 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:43 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:43 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:43 --> Total execution time: 0.0372
INFO - 2022-12-07 07:04:45 --> Config Class Initialized
INFO - 2022-12-07 07:04:45 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:45 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:45 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:45 --> URI Class Initialized
INFO - 2022-12-07 07:04:45 --> Router Class Initialized
INFO - 2022-12-07 07:04:45 --> Output Class Initialized
INFO - 2022-12-07 07:04:45 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:45 --> Input Class Initialized
INFO - 2022-12-07 07:04:45 --> Language Class Initialized
INFO - 2022-12-07 07:04:45 --> Loader Class Initialized
INFO - 2022-12-07 07:04:45 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:45 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:45 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:45 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:45 --> Total execution time: 0.0447
INFO - 2022-12-07 07:04:45 --> Config Class Initialized
INFO - 2022-12-07 07:04:45 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:45 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:45 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:45 --> URI Class Initialized
INFO - 2022-12-07 07:04:45 --> Router Class Initialized
INFO - 2022-12-07 07:04:45 --> Output Class Initialized
INFO - 2022-12-07 07:04:45 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:45 --> Input Class Initialized
INFO - 2022-12-07 07:04:45 --> Language Class Initialized
INFO - 2022-12-07 07:04:45 --> Loader Class Initialized
INFO - 2022-12-07 07:04:45 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:45 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:45 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:45 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:45 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:45 --> Total execution time: 0.0342
INFO - 2022-12-07 07:04:48 --> Config Class Initialized
INFO - 2022-12-07 07:04:48 --> Hooks Class Initialized
INFO - 2022-12-07 07:04:48 --> Config Class Initialized
INFO - 2022-12-07 07:04:48 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:48 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:48 --> Utf8 Class Initialized
DEBUG - 2022-12-07 07:04:48 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:48 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:48 --> URI Class Initialized
INFO - 2022-12-07 07:04:48 --> URI Class Initialized
INFO - 2022-12-07 07:04:48 --> Router Class Initialized
INFO - 2022-12-07 07:04:48 --> Router Class Initialized
INFO - 2022-12-07 07:04:48 --> Output Class Initialized
INFO - 2022-12-07 07:04:48 --> Output Class Initialized
INFO - 2022-12-07 07:04:48 --> Security Class Initialized
INFO - 2022-12-07 07:04:48 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:48 --> Input Class Initialized
DEBUG - 2022-12-07 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:48 --> Input Class Initialized
INFO - 2022-12-07 07:04:48 --> Language Class Initialized
INFO - 2022-12-07 07:04:48 --> Language Class Initialized
INFO - 2022-12-07 07:04:48 --> Loader Class Initialized
INFO - 2022-12-07 07:04:48 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:48 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:48 --> Total execution time: 0.0198
INFO - 2022-12-07 07:04:48 --> Loader Class Initialized
INFO - 2022-12-07 07:04:48 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:48 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:48 --> Config Class Initialized
INFO - 2022-12-07 07:04:48 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:48 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:48 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:48 --> URI Class Initialized
INFO - 2022-12-07 07:04:48 --> Router Class Initialized
INFO - 2022-12-07 07:04:48 --> Output Class Initialized
INFO - 2022-12-07 07:04:48 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:48 --> Input Class Initialized
INFO - 2022-12-07 07:04:48 --> Language Class Initialized
INFO - 2022-12-07 07:04:48 --> Loader Class Initialized
INFO - 2022-12-07 07:04:48 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:48 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:48 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:48 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:48 --> Total execution time: 0.0539
INFO - 2022-12-07 07:04:48 --> Config Class Initialized
INFO - 2022-12-07 07:04:48 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:48 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:48 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:48 --> URI Class Initialized
INFO - 2022-12-07 07:04:48 --> Router Class Initialized
INFO - 2022-12-07 07:04:48 --> Output Class Initialized
INFO - 2022-12-07 07:04:48 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:48 --> Input Class Initialized
INFO - 2022-12-07 07:04:48 --> Language Class Initialized
INFO - 2022-12-07 07:04:48 --> Loader Class Initialized
INFO - 2022-12-07 07:04:48 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:48 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:48 --> Model "Login_model" initialized
INFO - 2022-12-07 07:04:48 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:48 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:48 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:48 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:48 --> Total execution time: 0.0874
INFO - 2022-12-07 07:04:48 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:48 --> Total execution time: 0.0547
INFO - 2022-12-07 07:04:50 --> Config Class Initialized
INFO - 2022-12-07 07:04:50 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:50 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:50 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:50 --> URI Class Initialized
INFO - 2022-12-07 07:04:50 --> Router Class Initialized
INFO - 2022-12-07 07:04:50 --> Output Class Initialized
INFO - 2022-12-07 07:04:50 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:50 --> Input Class Initialized
INFO - 2022-12-07 07:04:50 --> Language Class Initialized
INFO - 2022-12-07 07:04:50 --> Loader Class Initialized
INFO - 2022-12-07 07:04:50 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:50 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:50 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:50 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:50 --> Total execution time: 0.0630
INFO - 2022-12-07 07:04:50 --> Config Class Initialized
INFO - 2022-12-07 07:04:50 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:50 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:50 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:50 --> URI Class Initialized
INFO - 2022-12-07 07:04:50 --> Router Class Initialized
INFO - 2022-12-07 07:04:50 --> Output Class Initialized
INFO - 2022-12-07 07:04:50 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:50 --> Input Class Initialized
INFO - 2022-12-07 07:04:50 --> Language Class Initialized
INFO - 2022-12-07 07:04:50 --> Loader Class Initialized
INFO - 2022-12-07 07:04:50 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:50 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:50 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:50 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:50 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:50 --> Total execution time: 0.0538
INFO - 2022-12-07 07:04:53 --> Config Class Initialized
INFO - 2022-12-07 07:04:53 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:53 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:53 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:53 --> URI Class Initialized
INFO - 2022-12-07 07:04:53 --> Router Class Initialized
INFO - 2022-12-07 07:04:53 --> Output Class Initialized
INFO - 2022-12-07 07:04:53 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:53 --> Input Class Initialized
INFO - 2022-12-07 07:04:53 --> Language Class Initialized
INFO - 2022-12-07 07:04:53 --> Loader Class Initialized
INFO - 2022-12-07 07:04:53 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:53 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:53 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:53 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:53 --> Total execution time: 0.0470
INFO - 2022-12-07 07:04:53 --> Config Class Initialized
INFO - 2022-12-07 07:04:53 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:04:53 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:04:53 --> Utf8 Class Initialized
INFO - 2022-12-07 07:04:53 --> URI Class Initialized
INFO - 2022-12-07 07:04:53 --> Router Class Initialized
INFO - 2022-12-07 07:04:53 --> Output Class Initialized
INFO - 2022-12-07 07:04:53 --> Security Class Initialized
DEBUG - 2022-12-07 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:04:53 --> Input Class Initialized
INFO - 2022-12-07 07:04:53 --> Language Class Initialized
INFO - 2022-12-07 07:04:53 --> Loader Class Initialized
INFO - 2022-12-07 07:04:53 --> Controller Class Initialized
DEBUG - 2022-12-07 07:04:53 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:04:53 --> Database Driver Class Initialized
INFO - 2022-12-07 07:04:53 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:04:53 --> Final output sent to browser
DEBUG - 2022-12-07 07:04:53 --> Total execution time: 0.0551
INFO - 2022-12-07 07:05:03 --> Config Class Initialized
INFO - 2022-12-07 07:05:03 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:03 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:03 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:03 --> URI Class Initialized
INFO - 2022-12-07 07:05:03 --> Router Class Initialized
INFO - 2022-12-07 07:05:03 --> Output Class Initialized
INFO - 2022-12-07 07:05:03 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:03 --> Input Class Initialized
INFO - 2022-12-07 07:05:03 --> Language Class Initialized
INFO - 2022-12-07 07:05:03 --> Loader Class Initialized
INFO - 2022-12-07 07:05:03 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:03 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:03 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:03 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:03 --> Total execution time: 0.0787
INFO - 2022-12-07 07:05:03 --> Config Class Initialized
INFO - 2022-12-07 07:05:03 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:03 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:03 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:03 --> URI Class Initialized
INFO - 2022-12-07 07:05:03 --> Router Class Initialized
INFO - 2022-12-07 07:05:03 --> Output Class Initialized
INFO - 2022-12-07 07:05:03 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:03 --> Input Class Initialized
INFO - 2022-12-07 07:05:03 --> Language Class Initialized
INFO - 2022-12-07 07:05:03 --> Loader Class Initialized
INFO - 2022-12-07 07:05:03 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:03 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:03 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:03 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:03 --> Total execution time: 0.0349
INFO - 2022-12-07 07:05:06 --> Config Class Initialized
INFO - 2022-12-07 07:05:06 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:06 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:06 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:06 --> Config Class Initialized
INFO - 2022-12-07 07:05:06 --> Hooks Class Initialized
INFO - 2022-12-07 07:05:06 --> URI Class Initialized
INFO - 2022-12-07 07:05:06 --> Router Class Initialized
DEBUG - 2022-12-07 07:05:06 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:06 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:06 --> Output Class Initialized
INFO - 2022-12-07 07:05:06 --> URI Class Initialized
INFO - 2022-12-07 07:05:06 --> Security Class Initialized
INFO - 2022-12-07 07:05:06 --> Router Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:06 --> Input Class Initialized
INFO - 2022-12-07 07:05:06 --> Language Class Initialized
INFO - 2022-12-07 07:05:06 --> Output Class Initialized
INFO - 2022-12-07 07:05:06 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:06 --> Input Class Initialized
INFO - 2022-12-07 07:05:06 --> Language Class Initialized
INFO - 2022-12-07 07:05:06 --> Loader Class Initialized
INFO - 2022-12-07 07:05:06 --> Loader Class Initialized
INFO - 2022-12-07 07:05:06 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:06 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:06 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:06 --> Total execution time: 0.0200
INFO - 2022-12-07 07:05:06 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:06 --> Config Class Initialized
INFO - 2022-12-07 07:05:06 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:06 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:06 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:06 --> URI Class Initialized
INFO - 2022-12-07 07:05:06 --> Router Class Initialized
INFO - 2022-12-07 07:05:06 --> Output Class Initialized
INFO - 2022-12-07 07:05:06 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:06 --> Input Class Initialized
INFO - 2022-12-07 07:05:06 --> Language Class Initialized
INFO - 2022-12-07 07:05:06 --> Loader Class Initialized
INFO - 2022-12-07 07:05:06 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:06 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:06 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:06 --> Model "Login_model" initialized
INFO - 2022-12-07 07:05:06 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:06 --> Total execution time: 0.0684
INFO - 2022-12-07 07:05:06 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:06 --> Config Class Initialized
INFO - 2022-12-07 07:05:06 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:06 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:06 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:06 --> URI Class Initialized
INFO - 2022-12-07 07:05:06 --> Router Class Initialized
INFO - 2022-12-07 07:05:06 --> Output Class Initialized
INFO - 2022-12-07 07:05:06 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:06 --> Input Class Initialized
INFO - 2022-12-07 07:05:06 --> Language Class Initialized
INFO - 2022-12-07 07:05:06 --> Loader Class Initialized
INFO - 2022-12-07 07:05:06 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:06 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:06 --> Final output sent to browser
INFO - 2022-12-07 07:05:06 --> Database Driver Class Initialized
DEBUG - 2022-12-07 07:05:06 --> Total execution time: 0.0607
INFO - 2022-12-07 07:05:06 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:06 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:06 --> Total execution time: 0.0546
INFO - 2022-12-07 07:05:23 --> Config Class Initialized
INFO - 2022-12-07 07:05:23 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:23 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:23 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:23 --> URI Class Initialized
INFO - 2022-12-07 07:05:23 --> Router Class Initialized
INFO - 2022-12-07 07:05:23 --> Output Class Initialized
INFO - 2022-12-07 07:05:23 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:23 --> Input Class Initialized
INFO - 2022-12-07 07:05:23 --> Language Class Initialized
INFO - 2022-12-07 07:05:23 --> Loader Class Initialized
INFO - 2022-12-07 07:05:23 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:24 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:24 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:24 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:24 --> Total execution time: 0.0432
INFO - 2022-12-07 07:05:24 --> Config Class Initialized
INFO - 2022-12-07 07:05:24 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:24 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:24 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:24 --> URI Class Initialized
INFO - 2022-12-07 07:05:24 --> Router Class Initialized
INFO - 2022-12-07 07:05:24 --> Output Class Initialized
INFO - 2022-12-07 07:05:24 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:24 --> Input Class Initialized
INFO - 2022-12-07 07:05:24 --> Language Class Initialized
INFO - 2022-12-07 07:05:24 --> Loader Class Initialized
INFO - 2022-12-07 07:05:24 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:24 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:24 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:24 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:24 --> Total execution time: 0.0603
INFO - 2022-12-07 07:05:27 --> Config Class Initialized
INFO - 2022-12-07 07:05:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:27 --> URI Class Initialized
INFO - 2022-12-07 07:05:27 --> Router Class Initialized
INFO - 2022-12-07 07:05:27 --> Output Class Initialized
INFO - 2022-12-07 07:05:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:27 --> Input Class Initialized
INFO - 2022-12-07 07:05:27 --> Language Class Initialized
INFO - 2022-12-07 07:05:27 --> Loader Class Initialized
INFO - 2022-12-07 07:05:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:27 --> Total execution time: 0.0549
INFO - 2022-12-07 07:05:27 --> Config Class Initialized
INFO - 2022-12-07 07:05:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:27 --> URI Class Initialized
INFO - 2022-12-07 07:05:27 --> Router Class Initialized
INFO - 2022-12-07 07:05:27 --> Output Class Initialized
INFO - 2022-12-07 07:05:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:27 --> Input Class Initialized
INFO - 2022-12-07 07:05:27 --> Language Class Initialized
INFO - 2022-12-07 07:05:27 --> Loader Class Initialized
INFO - 2022-12-07 07:05:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:27 --> Total execution time: 0.0320
INFO - 2022-12-07 07:05:34 --> Config Class Initialized
INFO - 2022-12-07 07:05:34 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:34 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:34 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:34 --> URI Class Initialized
INFO - 2022-12-07 07:05:34 --> Router Class Initialized
INFO - 2022-12-07 07:05:34 --> Output Class Initialized
INFO - 2022-12-07 07:05:34 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:34 --> Input Class Initialized
INFO - 2022-12-07 07:05:34 --> Language Class Initialized
INFO - 2022-12-07 07:05:34 --> Loader Class Initialized
INFO - 2022-12-07 07:05:34 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:34 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:34 --> Total execution time: 0.0188
INFO - 2022-12-07 07:05:34 --> Config Class Initialized
INFO - 2022-12-07 07:05:34 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:34 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:34 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:34 --> URI Class Initialized
INFO - 2022-12-07 07:05:34 --> Router Class Initialized
INFO - 2022-12-07 07:05:34 --> Output Class Initialized
INFO - 2022-12-07 07:05:34 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:34 --> Input Class Initialized
INFO - 2022-12-07 07:05:34 --> Language Class Initialized
INFO - 2022-12-07 07:05:34 --> Loader Class Initialized
INFO - 2022-12-07 07:05:34 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:34 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:34 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:34 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:34 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:34 --> Total execution time: 0.0554
INFO - 2022-12-07 07:05:40 --> Config Class Initialized
INFO - 2022-12-07 07:05:40 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:40 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:40 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:40 --> URI Class Initialized
INFO - 2022-12-07 07:05:40 --> Router Class Initialized
INFO - 2022-12-07 07:05:40 --> Output Class Initialized
INFO - 2022-12-07 07:05:40 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:40 --> Input Class Initialized
INFO - 2022-12-07 07:05:40 --> Language Class Initialized
INFO - 2022-12-07 07:05:40 --> Loader Class Initialized
INFO - 2022-12-07 07:05:40 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:40 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:40 --> Total execution time: 0.0185
INFO - 2022-12-07 07:05:40 --> Config Class Initialized
INFO - 2022-12-07 07:05:40 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:40 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:40 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:40 --> URI Class Initialized
INFO - 2022-12-07 07:05:40 --> Router Class Initialized
INFO - 2022-12-07 07:05:40 --> Output Class Initialized
INFO - 2022-12-07 07:05:40 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:40 --> Input Class Initialized
INFO - 2022-12-07 07:05:40 --> Language Class Initialized
INFO - 2022-12-07 07:05:40 --> Loader Class Initialized
INFO - 2022-12-07 07:05:40 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:40 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:40 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:40 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:40 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:40 --> Total execution time: 0.0337
INFO - 2022-12-07 07:05:41 --> Config Class Initialized
INFO - 2022-12-07 07:05:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:41 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:41 --> URI Class Initialized
INFO - 2022-12-07 07:05:41 --> Router Class Initialized
INFO - 2022-12-07 07:05:41 --> Output Class Initialized
INFO - 2022-12-07 07:05:41 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:41 --> Input Class Initialized
INFO - 2022-12-07 07:05:41 --> Language Class Initialized
INFO - 2022-12-07 07:05:41 --> Loader Class Initialized
INFO - 2022-12-07 07:05:41 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:41 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:41 --> Total execution time: 0.0215
INFO - 2022-12-07 07:05:41 --> Config Class Initialized
INFO - 2022-12-07 07:05:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:41 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:41 --> URI Class Initialized
INFO - 2022-12-07 07:05:41 --> Router Class Initialized
INFO - 2022-12-07 07:05:41 --> Output Class Initialized
INFO - 2022-12-07 07:05:41 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:41 --> Input Class Initialized
INFO - 2022-12-07 07:05:41 --> Language Class Initialized
INFO - 2022-12-07 07:05:41 --> Loader Class Initialized
INFO - 2022-12-07 07:05:41 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:41 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:41 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:41 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:41 --> Total execution time: 0.0615
INFO - 2022-12-07 07:05:48 --> Config Class Initialized
INFO - 2022-12-07 07:05:48 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:48 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:48 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:48 --> URI Class Initialized
INFO - 2022-12-07 07:05:48 --> Router Class Initialized
INFO - 2022-12-07 07:05:48 --> Output Class Initialized
INFO - 2022-12-07 07:05:48 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:48 --> Input Class Initialized
INFO - 2022-12-07 07:05:48 --> Language Class Initialized
INFO - 2022-12-07 07:05:48 --> Loader Class Initialized
INFO - 2022-12-07 07:05:48 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:48 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:48 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:48 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:48 --> Total execution time: 0.0682
INFO - 2022-12-07 07:05:48 --> Config Class Initialized
INFO - 2022-12-07 07:05:48 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:05:48 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:05:48 --> Utf8 Class Initialized
INFO - 2022-12-07 07:05:48 --> URI Class Initialized
INFO - 2022-12-07 07:05:48 --> Router Class Initialized
INFO - 2022-12-07 07:05:48 --> Output Class Initialized
INFO - 2022-12-07 07:05:48 --> Security Class Initialized
DEBUG - 2022-12-07 07:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:05:48 --> Input Class Initialized
INFO - 2022-12-07 07:05:48 --> Language Class Initialized
INFO - 2022-12-07 07:05:48 --> Loader Class Initialized
INFO - 2022-12-07 07:05:48 --> Controller Class Initialized
DEBUG - 2022-12-07 07:05:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:05:48 --> Database Driver Class Initialized
INFO - 2022-12-07 07:05:48 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:05:48 --> Final output sent to browser
DEBUG - 2022-12-07 07:05:48 --> Total execution time: 0.0391
INFO - 2022-12-07 07:08:05 --> Config Class Initialized
INFO - 2022-12-07 07:08:05 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:08:05 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:08:05 --> Utf8 Class Initialized
INFO - 2022-12-07 07:08:05 --> URI Class Initialized
INFO - 2022-12-07 07:08:05 --> Router Class Initialized
INFO - 2022-12-07 07:08:05 --> Output Class Initialized
INFO - 2022-12-07 07:08:05 --> Security Class Initialized
DEBUG - 2022-12-07 07:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:08:05 --> Input Class Initialized
INFO - 2022-12-07 07:08:05 --> Language Class Initialized
INFO - 2022-12-07 07:08:05 --> Loader Class Initialized
INFO - 2022-12-07 07:08:05 --> Controller Class Initialized
DEBUG - 2022-12-07 07:08:05 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:08:05 --> Database Driver Class Initialized
INFO - 2022-12-07 07:08:05 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:08:05 --> Final output sent to browser
DEBUG - 2022-12-07 07:08:05 --> Total execution time: 0.0512
INFO - 2022-12-07 07:08:05 --> Config Class Initialized
INFO - 2022-12-07 07:08:05 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:08:05 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:08:05 --> Utf8 Class Initialized
INFO - 2022-12-07 07:08:05 --> URI Class Initialized
INFO - 2022-12-07 07:08:05 --> Router Class Initialized
INFO - 2022-12-07 07:08:05 --> Output Class Initialized
INFO - 2022-12-07 07:08:05 --> Security Class Initialized
DEBUG - 2022-12-07 07:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:08:05 --> Input Class Initialized
INFO - 2022-12-07 07:08:05 --> Language Class Initialized
INFO - 2022-12-07 07:08:05 --> Loader Class Initialized
INFO - 2022-12-07 07:08:06 --> Controller Class Initialized
DEBUG - 2022-12-07 07:08:06 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:08:06 --> Database Driver Class Initialized
INFO - 2022-12-07 07:08:06 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:08:06 --> Final output sent to browser
DEBUG - 2022-12-07 07:08:06 --> Total execution time: 0.0546
INFO - 2022-12-07 07:08:11 --> Config Class Initialized
INFO - 2022-12-07 07:08:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:08:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:08:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:08:11 --> URI Class Initialized
INFO - 2022-12-07 07:08:11 --> Router Class Initialized
INFO - 2022-12-07 07:08:11 --> Output Class Initialized
INFO - 2022-12-07 07:08:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:08:11 --> Input Class Initialized
INFO - 2022-12-07 07:08:11 --> Language Class Initialized
INFO - 2022-12-07 07:08:11 --> Loader Class Initialized
INFO - 2022-12-07 07:08:11 --> Controller Class Initialized
DEBUG - 2022-12-07 07:08:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:08:11 --> Database Driver Class Initialized
INFO - 2022-12-07 07:08:11 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:08:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:08:11 --> Total execution time: 0.0367
INFO - 2022-12-07 07:08:11 --> Config Class Initialized
INFO - 2022-12-07 07:08:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:08:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:08:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:08:11 --> URI Class Initialized
INFO - 2022-12-07 07:08:11 --> Router Class Initialized
INFO - 2022-12-07 07:08:11 --> Output Class Initialized
INFO - 2022-12-07 07:08:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:08:11 --> Input Class Initialized
INFO - 2022-12-07 07:08:11 --> Language Class Initialized
INFO - 2022-12-07 07:08:11 --> Loader Class Initialized
INFO - 2022-12-07 07:08:11 --> Controller Class Initialized
DEBUG - 2022-12-07 07:08:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:08:11 --> Database Driver Class Initialized
INFO - 2022-12-07 07:08:11 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:08:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:08:11 --> Total execution time: 0.0341
INFO - 2022-12-07 07:09:56 --> Config Class Initialized
INFO - 2022-12-07 07:09:56 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:09:56 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:09:56 --> Utf8 Class Initialized
INFO - 2022-12-07 07:09:56 --> URI Class Initialized
INFO - 2022-12-07 07:09:56 --> Router Class Initialized
INFO - 2022-12-07 07:09:56 --> Output Class Initialized
INFO - 2022-12-07 07:09:56 --> Security Class Initialized
DEBUG - 2022-12-07 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:09:56 --> Input Class Initialized
INFO - 2022-12-07 07:09:56 --> Language Class Initialized
INFO - 2022-12-07 07:09:56 --> Loader Class Initialized
INFO - 2022-12-07 07:09:56 --> Controller Class Initialized
DEBUG - 2022-12-07 07:09:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:09:56 --> Database Driver Class Initialized
INFO - 2022-12-07 07:09:56 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:09:56 --> Final output sent to browser
DEBUG - 2022-12-07 07:09:56 --> Total execution time: 0.0497
INFO - 2022-12-07 07:09:56 --> Config Class Initialized
INFO - 2022-12-07 07:09:56 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:09:56 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:09:56 --> Utf8 Class Initialized
INFO - 2022-12-07 07:09:56 --> URI Class Initialized
INFO - 2022-12-07 07:09:56 --> Router Class Initialized
INFO - 2022-12-07 07:09:56 --> Output Class Initialized
INFO - 2022-12-07 07:09:56 --> Security Class Initialized
DEBUG - 2022-12-07 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:09:56 --> Input Class Initialized
INFO - 2022-12-07 07:09:56 --> Language Class Initialized
INFO - 2022-12-07 07:09:56 --> Loader Class Initialized
INFO - 2022-12-07 07:09:56 --> Controller Class Initialized
DEBUG - 2022-12-07 07:09:56 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:09:56 --> Database Driver Class Initialized
INFO - 2022-12-07 07:09:56 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:09:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:09:57 --> Total execution time: 0.2634
INFO - 2022-12-07 07:17:11 --> Config Class Initialized
INFO - 2022-12-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:17:11 --> URI Class Initialized
INFO - 2022-12-07 07:17:11 --> Router Class Initialized
INFO - 2022-12-07 07:17:11 --> Output Class Initialized
INFO - 2022-12-07 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:17:11 --> Input Class Initialized
INFO - 2022-12-07 07:17:11 --> Language Class Initialized
INFO - 2022-12-07 07:17:11 --> Loader Class Initialized
INFO - 2022-12-07 07:17:11 --> Controller Class Initialized
INFO - 2022-12-07 07:17:11 --> Helper loaded: form_helper
INFO - 2022-12-07 07:17:11 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:17:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:17:11 --> Model "Change_model" initialized
INFO - 2022-12-07 07:17:11 --> Model "Grafana_model" initialized
INFO - 2022-12-07 07:17:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:17:11 --> Total execution time: 0.0670
INFO - 2022-12-07 07:17:11 --> Config Class Initialized
INFO - 2022-12-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:17:11 --> URI Class Initialized
INFO - 2022-12-07 07:17:11 --> Router Class Initialized
INFO - 2022-12-07 07:17:11 --> Output Class Initialized
INFO - 2022-12-07 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:17:11 --> Input Class Initialized
INFO - 2022-12-07 07:17:11 --> Language Class Initialized
INFO - 2022-12-07 07:17:11 --> Loader Class Initialized
INFO - 2022-12-07 07:17:11 --> Controller Class Initialized
INFO - 2022-12-07 07:17:11 --> Helper loaded: form_helper
INFO - 2022-12-07 07:17:11 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:17:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:17:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:17:11 --> Total execution time: 0.0210
INFO - 2022-12-07 07:17:11 --> Config Class Initialized
INFO - 2022-12-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:17:11 --> URI Class Initialized
INFO - 2022-12-07 07:17:11 --> Router Class Initialized
INFO - 2022-12-07 07:17:11 --> Output Class Initialized
INFO - 2022-12-07 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:17:11 --> Input Class Initialized
INFO - 2022-12-07 07:17:11 --> Language Class Initialized
INFO - 2022-12-07 07:17:11 --> Loader Class Initialized
INFO - 2022-12-07 07:17:11 --> Controller Class Initialized
INFO - 2022-12-07 07:17:11 --> Helper loaded: form_helper
INFO - 2022-12-07 07:17:11 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:17:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:17:11 --> Database Driver Class Initialized
INFO - 2022-12-07 07:17:11 --> Model "Login_model" initialized
INFO - 2022-12-07 07:17:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:17:11 --> Total execution time: 0.1733
INFO - 2022-12-07 07:17:11 --> Config Class Initialized
INFO - 2022-12-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:17:11 --> URI Class Initialized
INFO - 2022-12-07 07:17:11 --> Router Class Initialized
INFO - 2022-12-07 07:17:11 --> Output Class Initialized
INFO - 2022-12-07 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:17:11 --> Input Class Initialized
INFO - 2022-12-07 07:17:11 --> Language Class Initialized
INFO - 2022-12-07 07:17:11 --> Loader Class Initialized
INFO - 2022-12-07 07:17:11 --> Controller Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:17:11 --> Database Driver Class Initialized
INFO - 2022-12-07 07:17:11 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:17:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:17:11 --> Total execution time: 0.0854
INFO - 2022-12-07 07:17:11 --> Config Class Initialized
INFO - 2022-12-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:17:11 --> URI Class Initialized
INFO - 2022-12-07 07:17:11 --> Router Class Initialized
INFO - 2022-12-07 07:17:11 --> Output Class Initialized
INFO - 2022-12-07 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:17:11 --> Input Class Initialized
INFO - 2022-12-07 07:17:11 --> Language Class Initialized
INFO - 2022-12-07 07:17:11 --> Loader Class Initialized
INFO - 2022-12-07 07:17:11 --> Controller Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:17:11 --> Database Driver Class Initialized
INFO - 2022-12-07 07:17:11 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:17:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:17:11 --> Total execution time: 0.0771
INFO - 2022-12-07 07:17:11 --> Config Class Initialized
INFO - 2022-12-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:17:11 --> URI Class Initialized
INFO - 2022-12-07 07:17:11 --> Router Class Initialized
INFO - 2022-12-07 07:17:11 --> Output Class Initialized
INFO - 2022-12-07 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:17:11 --> Input Class Initialized
INFO - 2022-12-07 07:17:11 --> Language Class Initialized
INFO - 2022-12-07 07:17:11 --> Loader Class Initialized
INFO - 2022-12-07 07:17:11 --> Controller Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:17:11 --> Database Driver Class Initialized
INFO - 2022-12-07 07:17:11 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:17:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:17:11 --> Total execution time: 0.0570
INFO - 2022-12-07 07:17:11 --> Config Class Initialized
INFO - 2022-12-07 07:17:11 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-07 07:17:11 --> URI Class Initialized
INFO - 2022-12-07 07:17:11 --> Router Class Initialized
INFO - 2022-12-07 07:17:11 --> Output Class Initialized
INFO - 2022-12-07 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:17:11 --> Input Class Initialized
INFO - 2022-12-07 07:17:11 --> Language Class Initialized
INFO - 2022-12-07 07:17:11 --> Loader Class Initialized
INFO - 2022-12-07 07:17:11 --> Controller Class Initialized
DEBUG - 2022-12-07 07:17:11 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:17:11 --> Database Driver Class Initialized
INFO - 2022-12-07 07:17:11 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:17:11 --> Final output sent to browser
DEBUG - 2022-12-07 07:17:11 --> Total execution time: 0.0533
INFO - 2022-12-07 07:34:10 --> Config Class Initialized
INFO - 2022-12-07 07:34:10 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:10 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:10 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:10 --> URI Class Initialized
INFO - 2022-12-07 07:34:10 --> Router Class Initialized
INFO - 2022-12-07 07:34:10 --> Output Class Initialized
INFO - 2022-12-07 07:34:10 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:10 --> Input Class Initialized
INFO - 2022-12-07 07:34:10 --> Language Class Initialized
INFO - 2022-12-07 07:34:10 --> Loader Class Initialized
INFO - 2022-12-07 07:34:10 --> Controller Class Initialized
INFO - 2022-12-07 07:34:10 --> Helper loaded: form_helper
INFO - 2022-12-07 07:34:10 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:34:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:10 --> Model "Change_model" initialized
INFO - 2022-12-07 07:34:10 --> Model "Grafana_model" initialized
INFO - 2022-12-07 07:34:10 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:10 --> Total execution time: 0.0759
INFO - 2022-12-07 07:34:10 --> Config Class Initialized
INFO - 2022-12-07 07:34:10 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:10 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:10 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:10 --> URI Class Initialized
INFO - 2022-12-07 07:34:10 --> Router Class Initialized
INFO - 2022-12-07 07:34:10 --> Output Class Initialized
INFO - 2022-12-07 07:34:10 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:10 --> Input Class Initialized
INFO - 2022-12-07 07:34:10 --> Language Class Initialized
INFO - 2022-12-07 07:34:10 --> Loader Class Initialized
INFO - 2022-12-07 07:34:10 --> Controller Class Initialized
INFO - 2022-12-07 07:34:10 --> Helper loaded: form_helper
INFO - 2022-12-07 07:34:10 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:34:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:10 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:10 --> Total execution time: 0.0208
INFO - 2022-12-07 07:34:10 --> Config Class Initialized
INFO - 2022-12-07 07:34:10 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:10 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:10 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:10 --> URI Class Initialized
INFO - 2022-12-07 07:34:10 --> Router Class Initialized
INFO - 2022-12-07 07:34:10 --> Output Class Initialized
INFO - 2022-12-07 07:34:10 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:10 --> Input Class Initialized
INFO - 2022-12-07 07:34:10 --> Language Class Initialized
INFO - 2022-12-07 07:34:10 --> Loader Class Initialized
INFO - 2022-12-07 07:34:10 --> Controller Class Initialized
INFO - 2022-12-07 07:34:10 --> Helper loaded: form_helper
INFO - 2022-12-07 07:34:10 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:34:10 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:10 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:10 --> Model "Login_model" initialized
INFO - 2022-12-07 07:34:10 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:10 --> Total execution time: 0.0343
INFO - 2022-12-07 07:34:18 --> Config Class Initialized
INFO - 2022-12-07 07:34:18 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:18 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:18 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:18 --> URI Class Initialized
INFO - 2022-12-07 07:34:18 --> Router Class Initialized
INFO - 2022-12-07 07:34:18 --> Output Class Initialized
INFO - 2022-12-07 07:34:18 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:18 --> Input Class Initialized
INFO - 2022-12-07 07:34:18 --> Language Class Initialized
INFO - 2022-12-07 07:34:18 --> Loader Class Initialized
INFO - 2022-12-07 07:34:18 --> Controller Class Initialized
INFO - 2022-12-07 07:34:18 --> Helper loaded: form_helper
INFO - 2022-12-07 07:34:18 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:34:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:18 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:18 --> Total execution time: 0.0193
INFO - 2022-12-07 07:34:18 --> Config Class Initialized
INFO - 2022-12-07 07:34:18 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:18 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:18 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:18 --> URI Class Initialized
INFO - 2022-12-07 07:34:18 --> Router Class Initialized
INFO - 2022-12-07 07:34:18 --> Output Class Initialized
INFO - 2022-12-07 07:34:18 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:18 --> Input Class Initialized
INFO - 2022-12-07 07:34:18 --> Language Class Initialized
INFO - 2022-12-07 07:34:18 --> Loader Class Initialized
INFO - 2022-12-07 07:34:18 --> Controller Class Initialized
INFO - 2022-12-07 07:34:18 --> Helper loaded: form_helper
INFO - 2022-12-07 07:34:18 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:34:18 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:18 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:18 --> Model "Login_model" initialized
INFO - 2022-12-07 07:34:18 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:18 --> Total execution time: 0.2472
INFO - 2022-12-07 07:34:23 --> Config Class Initialized
INFO - 2022-12-07 07:34:23 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:23 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:23 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:23 --> URI Class Initialized
INFO - 2022-12-07 07:34:23 --> Router Class Initialized
INFO - 2022-12-07 07:34:23 --> Output Class Initialized
INFO - 2022-12-07 07:34:23 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:23 --> Input Class Initialized
INFO - 2022-12-07 07:34:23 --> Language Class Initialized
INFO - 2022-12-07 07:34:23 --> Loader Class Initialized
INFO - 2022-12-07 07:34:23 --> Controller Class Initialized
INFO - 2022-12-07 07:34:23 --> Helper loaded: form_helper
INFO - 2022-12-07 07:34:23 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:34:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:23 --> Model "Change_model" initialized
INFO - 2022-12-07 07:34:23 --> Model "Grafana_model" initialized
INFO - 2022-12-07 07:34:23 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:23 --> Total execution time: 0.0625
INFO - 2022-12-07 07:34:23 --> Config Class Initialized
INFO - 2022-12-07 07:34:23 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:23 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:23 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:23 --> URI Class Initialized
INFO - 2022-12-07 07:34:23 --> Router Class Initialized
INFO - 2022-12-07 07:34:23 --> Output Class Initialized
INFO - 2022-12-07 07:34:23 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:23 --> Input Class Initialized
INFO - 2022-12-07 07:34:23 --> Language Class Initialized
INFO - 2022-12-07 07:34:23 --> Loader Class Initialized
INFO - 2022-12-07 07:34:23 --> Controller Class Initialized
INFO - 2022-12-07 07:34:23 --> Helper loaded: form_helper
INFO - 2022-12-07 07:34:23 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:34:23 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:23 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:23 --> Total execution time: 0.0212
INFO - 2022-12-07 07:34:23 --> Config Class Initialized
INFO - 2022-12-07 07:34:23 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:23 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:23 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:23 --> URI Class Initialized
INFO - 2022-12-07 07:34:23 --> Router Class Initialized
INFO - 2022-12-07 07:34:23 --> Output Class Initialized
INFO - 2022-12-07 07:34:23 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:24 --> Input Class Initialized
INFO - 2022-12-07 07:34:24 --> Language Class Initialized
INFO - 2022-12-07 07:34:24 --> Loader Class Initialized
INFO - 2022-12-07 07:34:24 --> Controller Class Initialized
INFO - 2022-12-07 07:34:24 --> Helper loaded: form_helper
INFO - 2022-12-07 07:34:24 --> Helper loaded: url_helper
DEBUG - 2022-12-07 07:34:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:24 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:24 --> Model "Login_model" initialized
INFO - 2022-12-07 07:34:24 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:24 --> Total execution time: 0.1618
INFO - 2022-12-07 07:34:24 --> Config Class Initialized
INFO - 2022-12-07 07:34:24 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:24 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:24 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:24 --> URI Class Initialized
INFO - 2022-12-07 07:34:24 --> Router Class Initialized
INFO - 2022-12-07 07:34:24 --> Output Class Initialized
INFO - 2022-12-07 07:34:24 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:24 --> Input Class Initialized
INFO - 2022-12-07 07:34:24 --> Language Class Initialized
INFO - 2022-12-07 07:34:24 --> Loader Class Initialized
INFO - 2022-12-07 07:34:24 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:24 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:24 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:24 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:24 --> Total execution time: 0.0807
INFO - 2022-12-07 07:34:24 --> Config Class Initialized
INFO - 2022-12-07 07:34:24 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:24 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:24 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:24 --> URI Class Initialized
INFO - 2022-12-07 07:34:24 --> Router Class Initialized
INFO - 2022-12-07 07:34:24 --> Output Class Initialized
INFO - 2022-12-07 07:34:24 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:24 --> Input Class Initialized
INFO - 2022-12-07 07:34:24 --> Language Class Initialized
INFO - 2022-12-07 07:34:24 --> Loader Class Initialized
INFO - 2022-12-07 07:34:24 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:24 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:24 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:24 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:24 --> Total execution time: 0.0516
INFO - 2022-12-07 07:34:24 --> Config Class Initialized
INFO - 2022-12-07 07:34:24 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:24 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:24 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:24 --> URI Class Initialized
INFO - 2022-12-07 07:34:24 --> Router Class Initialized
INFO - 2022-12-07 07:34:24 --> Output Class Initialized
INFO - 2022-12-07 07:34:24 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:24 --> Input Class Initialized
INFO - 2022-12-07 07:34:24 --> Language Class Initialized
INFO - 2022-12-07 07:34:24 --> Loader Class Initialized
INFO - 2022-12-07 07:34:24 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:24 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:24 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:24 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:24 --> Total execution time: 0.0993
INFO - 2022-12-07 07:34:24 --> Config Class Initialized
INFO - 2022-12-07 07:34:24 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:24 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:24 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:24 --> URI Class Initialized
INFO - 2022-12-07 07:34:24 --> Router Class Initialized
INFO - 2022-12-07 07:34:24 --> Output Class Initialized
INFO - 2022-12-07 07:34:24 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:24 --> Input Class Initialized
INFO - 2022-12-07 07:34:24 --> Language Class Initialized
INFO - 2022-12-07 07:34:24 --> Loader Class Initialized
INFO - 2022-12-07 07:34:24 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:24 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:24 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:24 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:24 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:24 --> Total execution time: 0.0374
INFO - 2022-12-07 07:34:27 --> Config Class Initialized
INFO - 2022-12-07 07:34:27 --> Config Class Initialized
INFO - 2022-12-07 07:34:27 --> Hooks Class Initialized
INFO - 2022-12-07 07:34:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-07 07:34:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:27 --> URI Class Initialized
INFO - 2022-12-07 07:34:27 --> URI Class Initialized
INFO - 2022-12-07 07:34:27 --> Router Class Initialized
INFO - 2022-12-07 07:34:27 --> Router Class Initialized
INFO - 2022-12-07 07:34:27 --> Output Class Initialized
INFO - 2022-12-07 07:34:27 --> Output Class Initialized
INFO - 2022-12-07 07:34:27 --> Security Class Initialized
INFO - 2022-12-07 07:34:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-07 07:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:27 --> Input Class Initialized
INFO - 2022-12-07 07:34:27 --> Input Class Initialized
INFO - 2022-12-07 07:34:27 --> Language Class Initialized
INFO - 2022-12-07 07:34:27 --> Language Class Initialized
INFO - 2022-12-07 07:34:27 --> Loader Class Initialized
INFO - 2022-12-07 07:34:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:27 --> Total execution time: 0.0200
INFO - 2022-12-07 07:34:27 --> Loader Class Initialized
INFO - 2022-12-07 07:34:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:27 --> Config Class Initialized
INFO - 2022-12-07 07:34:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:27 --> URI Class Initialized
INFO - 2022-12-07 07:34:27 --> Router Class Initialized
INFO - 2022-12-07 07:34:27 --> Output Class Initialized
INFO - 2022-12-07 07:34:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:27 --> Input Class Initialized
INFO - 2022-12-07 07:34:27 --> Language Class Initialized
INFO - 2022-12-07 07:34:27 --> Loader Class Initialized
INFO - 2022-12-07 07:34:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:27 --> Total execution time: 0.0541
INFO - 2022-12-07 07:34:27 --> Config Class Initialized
INFO - 2022-12-07 07:34:27 --> Hooks Class Initialized
INFO - 2022-12-07 07:34:27 --> Model "Login_model" initialized
DEBUG - 2022-12-07 07:34:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:27 --> URI Class Initialized
INFO - 2022-12-07 07:34:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:27 --> Router Class Initialized
INFO - 2022-12-07 07:34:27 --> Output Class Initialized
INFO - 2022-12-07 07:34:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:27 --> Input Class Initialized
INFO - 2022-12-07 07:34:27 --> Language Class Initialized
INFO - 2022-12-07 07:34:27 --> Loader Class Initialized
INFO - 2022-12-07 07:34:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:27 --> Total execution time: 0.0675
INFO - 2022-12-07 07:34:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:27 --> Total execution time: 0.0369
INFO - 2022-12-07 07:34:31 --> Config Class Initialized
INFO - 2022-12-07 07:34:31 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:31 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:31 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:31 --> URI Class Initialized
INFO - 2022-12-07 07:34:31 --> Router Class Initialized
INFO - 2022-12-07 07:34:31 --> Output Class Initialized
INFO - 2022-12-07 07:34:31 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:31 --> Input Class Initialized
INFO - 2022-12-07 07:34:31 --> Language Class Initialized
INFO - 2022-12-07 07:34:31 --> Loader Class Initialized
INFO - 2022-12-07 07:34:31 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:31 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:31 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:31 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:31 --> Total execution time: 0.0890
INFO - 2022-12-07 07:34:31 --> Config Class Initialized
INFO - 2022-12-07 07:34:31 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:31 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:31 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:31 --> URI Class Initialized
INFO - 2022-12-07 07:34:31 --> Router Class Initialized
INFO - 2022-12-07 07:34:31 --> Output Class Initialized
INFO - 2022-12-07 07:34:31 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:31 --> Input Class Initialized
INFO - 2022-12-07 07:34:31 --> Language Class Initialized
INFO - 2022-12-07 07:34:31 --> Loader Class Initialized
INFO - 2022-12-07 07:34:31 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:31 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:31 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:31 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:31 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:31 --> Total execution time: 0.0484
INFO - 2022-12-07 07:34:33 --> Config Class Initialized
INFO - 2022-12-07 07:34:33 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:33 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:33 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:33 --> URI Class Initialized
INFO - 2022-12-07 07:34:33 --> Router Class Initialized
INFO - 2022-12-07 07:34:33 --> Output Class Initialized
INFO - 2022-12-07 07:34:33 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:33 --> Input Class Initialized
INFO - 2022-12-07 07:34:33 --> Language Class Initialized
INFO - 2022-12-07 07:34:33 --> Loader Class Initialized
INFO - 2022-12-07 07:34:33 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:33 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:33 --> Total execution time: 0.0197
INFO - 2022-12-07 07:34:33 --> Config Class Initialized
INFO - 2022-12-07 07:34:33 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:33 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:33 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:33 --> URI Class Initialized
INFO - 2022-12-07 07:34:33 --> Router Class Initialized
INFO - 2022-12-07 07:34:33 --> Output Class Initialized
INFO - 2022-12-07 07:34:33 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:33 --> Input Class Initialized
INFO - 2022-12-07 07:34:33 --> Language Class Initialized
INFO - 2022-12-07 07:34:33 --> Loader Class Initialized
INFO - 2022-12-07 07:34:33 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:33 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:33 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:33 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:33 --> Total execution time: 0.0524
INFO - 2022-12-07 07:34:33 --> Config Class Initialized
INFO - 2022-12-07 07:34:33 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:33 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:33 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:33 --> URI Class Initialized
INFO - 2022-12-07 07:34:33 --> Router Class Initialized
INFO - 2022-12-07 07:34:33 --> Output Class Initialized
INFO - 2022-12-07 07:34:33 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:33 --> Input Class Initialized
INFO - 2022-12-07 07:34:33 --> Language Class Initialized
INFO - 2022-12-07 07:34:33 --> Loader Class Initialized
INFO - 2022-12-07 07:34:33 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:33 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:33 --> Total execution time: 0.0196
INFO - 2022-12-07 07:34:33 --> Config Class Initialized
INFO - 2022-12-07 07:34:33 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:33 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:33 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:33 --> URI Class Initialized
INFO - 2022-12-07 07:34:33 --> Router Class Initialized
INFO - 2022-12-07 07:34:33 --> Output Class Initialized
INFO - 2022-12-07 07:34:33 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:33 --> Input Class Initialized
INFO - 2022-12-07 07:34:33 --> Language Class Initialized
INFO - 2022-12-07 07:34:33 --> Loader Class Initialized
INFO - 2022-12-07 07:34:33 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:33 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:33 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:33 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:33 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:33 --> Total execution time: 0.0466
INFO - 2022-12-07 07:34:41 --> Config Class Initialized
INFO - 2022-12-07 07:34:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:41 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:41 --> URI Class Initialized
INFO - 2022-12-07 07:34:41 --> Router Class Initialized
INFO - 2022-12-07 07:34:41 --> Output Class Initialized
INFO - 2022-12-07 07:34:41 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:41 --> Input Class Initialized
INFO - 2022-12-07 07:34:41 --> Language Class Initialized
INFO - 2022-12-07 07:34:41 --> Loader Class Initialized
INFO - 2022-12-07 07:34:41 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:41 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:41 --> Total execution time: 0.0216
INFO - 2022-12-07 07:34:41 --> Config Class Initialized
INFO - 2022-12-07 07:34:41 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:41 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:41 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:41 --> URI Class Initialized
INFO - 2022-12-07 07:34:41 --> Router Class Initialized
INFO - 2022-12-07 07:34:41 --> Output Class Initialized
INFO - 2022-12-07 07:34:41 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:41 --> Input Class Initialized
INFO - 2022-12-07 07:34:41 --> Language Class Initialized
INFO - 2022-12-07 07:34:41 --> Loader Class Initialized
INFO - 2022-12-07 07:34:41 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:41 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:41 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:41 --> Model "Login_model" initialized
INFO - 2022-12-07 07:34:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:42 --> Total execution time: 0.2791
INFO - 2022-12-07 07:34:42 --> Config Class Initialized
INFO - 2022-12-07 07:34:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:42 --> URI Class Initialized
INFO - 2022-12-07 07:34:42 --> Router Class Initialized
INFO - 2022-12-07 07:34:42 --> Output Class Initialized
INFO - 2022-12-07 07:34:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:42 --> Input Class Initialized
INFO - 2022-12-07 07:34:42 --> Language Class Initialized
INFO - 2022-12-07 07:34:42 --> Loader Class Initialized
INFO - 2022-12-07 07:34:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:42 --> Total execution time: 0.0217
INFO - 2022-12-07 07:34:42 --> Config Class Initialized
INFO - 2022-12-07 07:34:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:42 --> URI Class Initialized
INFO - 2022-12-07 07:34:42 --> Router Class Initialized
INFO - 2022-12-07 07:34:42 --> Output Class Initialized
INFO - 2022-12-07 07:34:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:42 --> Input Class Initialized
INFO - 2022-12-07 07:34:42 --> Language Class Initialized
INFO - 2022-12-07 07:34:42 --> Loader Class Initialized
INFO - 2022-12-07 07:34:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:42 --> Total execution time: 0.1328
INFO - 2022-12-07 07:34:47 --> Config Class Initialized
INFO - 2022-12-07 07:34:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:47 --> URI Class Initialized
INFO - 2022-12-07 07:34:47 --> Router Class Initialized
INFO - 2022-12-07 07:34:47 --> Output Class Initialized
INFO - 2022-12-07 07:34:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:47 --> Input Class Initialized
INFO - 2022-12-07 07:34:47 --> Language Class Initialized
INFO - 2022-12-07 07:34:48 --> Loader Class Initialized
INFO - 2022-12-07 07:34:48 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:48 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:48 --> Total execution time: 0.0206
INFO - 2022-12-07 07:34:48 --> Config Class Initialized
INFO - 2022-12-07 07:34:48 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:48 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:48 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:48 --> URI Class Initialized
INFO - 2022-12-07 07:34:48 --> Router Class Initialized
INFO - 2022-12-07 07:34:48 --> Output Class Initialized
INFO - 2022-12-07 07:34:48 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:48 --> Input Class Initialized
INFO - 2022-12-07 07:34:48 --> Language Class Initialized
INFO - 2022-12-07 07:34:48 --> Loader Class Initialized
INFO - 2022-12-07 07:34:48 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:48 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:48 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:48 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:48 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:48 --> Total execution time: 0.0495
INFO - 2022-12-07 07:34:52 --> Config Class Initialized
INFO - 2022-12-07 07:34:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:52 --> URI Class Initialized
INFO - 2022-12-07 07:34:52 --> Router Class Initialized
INFO - 2022-12-07 07:34:52 --> Output Class Initialized
INFO - 2022-12-07 07:34:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:52 --> Input Class Initialized
INFO - 2022-12-07 07:34:52 --> Language Class Initialized
INFO - 2022-12-07 07:34:52 --> Loader Class Initialized
INFO - 2022-12-07 07:34:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:53 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:53 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:53 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:53 --> Total execution time: 0.3066
INFO - 2022-12-07 07:34:57 --> Config Class Initialized
INFO - 2022-12-07 07:34:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:57 --> URI Class Initialized
INFO - 2022-12-07 07:34:57 --> Router Class Initialized
INFO - 2022-12-07 07:34:57 --> Output Class Initialized
INFO - 2022-12-07 07:34:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:57 --> Input Class Initialized
INFO - 2022-12-07 07:34:57 --> Language Class Initialized
INFO - 2022-12-07 07:34:57 --> Loader Class Initialized
INFO - 2022-12-07 07:34:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:57 --> Total execution time: 0.0210
INFO - 2022-12-07 07:34:58 --> Config Class Initialized
INFO - 2022-12-07 07:34:58 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:34:58 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:34:58 --> Utf8 Class Initialized
INFO - 2022-12-07 07:34:58 --> URI Class Initialized
INFO - 2022-12-07 07:34:58 --> Router Class Initialized
INFO - 2022-12-07 07:34:58 --> Output Class Initialized
INFO - 2022-12-07 07:34:58 --> Security Class Initialized
DEBUG - 2022-12-07 07:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:34:58 --> Input Class Initialized
INFO - 2022-12-07 07:34:58 --> Language Class Initialized
INFO - 2022-12-07 07:34:58 --> Loader Class Initialized
INFO - 2022-12-07 07:34:58 --> Controller Class Initialized
DEBUG - 2022-12-07 07:34:58 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:34:58 --> Database Driver Class Initialized
INFO - 2022-12-07 07:34:58 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:34:58 --> Final output sent to browser
DEBUG - 2022-12-07 07:34:58 --> Total execution time: 0.0347
INFO - 2022-12-07 07:35:02 --> Config Class Initialized
INFO - 2022-12-07 07:35:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:02 --> URI Class Initialized
INFO - 2022-12-07 07:35:02 --> Router Class Initialized
INFO - 2022-12-07 07:35:03 --> Output Class Initialized
INFO - 2022-12-07 07:35:03 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:03 --> Input Class Initialized
INFO - 2022-12-07 07:35:03 --> Language Class Initialized
INFO - 2022-12-07 07:35:03 --> Loader Class Initialized
INFO - 2022-12-07 07:35:03 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:03 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:03 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:03 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:03 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:03 --> Total execution time: 0.0589
INFO - 2022-12-07 07:35:07 --> Config Class Initialized
INFO - 2022-12-07 07:35:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:07 --> URI Class Initialized
INFO - 2022-12-07 07:35:07 --> Router Class Initialized
INFO - 2022-12-07 07:35:07 --> Output Class Initialized
INFO - 2022-12-07 07:35:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:07 --> Input Class Initialized
INFO - 2022-12-07 07:35:07 --> Language Class Initialized
INFO - 2022-12-07 07:35:07 --> Loader Class Initialized
INFO - 2022-12-07 07:35:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:07 --> Total execution time: 0.0211
INFO - 2022-12-07 07:35:07 --> Config Class Initialized
INFO - 2022-12-07 07:35:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:07 --> URI Class Initialized
INFO - 2022-12-07 07:35:07 --> Router Class Initialized
INFO - 2022-12-07 07:35:07 --> Output Class Initialized
INFO - 2022-12-07 07:35:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:07 --> Input Class Initialized
INFO - 2022-12-07 07:35:07 --> Language Class Initialized
INFO - 2022-12-07 07:35:07 --> Loader Class Initialized
INFO - 2022-12-07 07:35:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:07 --> Total execution time: 0.0595
INFO - 2022-12-07 07:35:12 --> Config Class Initialized
INFO - 2022-12-07 07:35:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:12 --> URI Class Initialized
INFO - 2022-12-07 07:35:12 --> Router Class Initialized
INFO - 2022-12-07 07:35:12 --> Output Class Initialized
INFO - 2022-12-07 07:35:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:12 --> Input Class Initialized
INFO - 2022-12-07 07:35:12 --> Language Class Initialized
INFO - 2022-12-07 07:35:12 --> Loader Class Initialized
INFO - 2022-12-07 07:35:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:12 --> Total execution time: 0.0402
INFO - 2022-12-07 07:35:17 --> Config Class Initialized
INFO - 2022-12-07 07:35:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:17 --> URI Class Initialized
INFO - 2022-12-07 07:35:17 --> Router Class Initialized
INFO - 2022-12-07 07:35:17 --> Output Class Initialized
INFO - 2022-12-07 07:35:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:17 --> Input Class Initialized
INFO - 2022-12-07 07:35:17 --> Language Class Initialized
INFO - 2022-12-07 07:35:17 --> Loader Class Initialized
INFO - 2022-12-07 07:35:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:17 --> Total execution time: 0.0205
INFO - 2022-12-07 07:35:17 --> Config Class Initialized
INFO - 2022-12-07 07:35:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:17 --> URI Class Initialized
INFO - 2022-12-07 07:35:17 --> Router Class Initialized
INFO - 2022-12-07 07:35:17 --> Output Class Initialized
INFO - 2022-12-07 07:35:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:17 --> Input Class Initialized
INFO - 2022-12-07 07:35:17 --> Language Class Initialized
INFO - 2022-12-07 07:35:17 --> Loader Class Initialized
INFO - 2022-12-07 07:35:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:17 --> Total execution time: 0.8282
INFO - 2022-12-07 07:35:22 --> Config Class Initialized
INFO - 2022-12-07 07:35:22 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:22 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:22 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:22 --> URI Class Initialized
INFO - 2022-12-07 07:35:22 --> Router Class Initialized
INFO - 2022-12-07 07:35:22 --> Output Class Initialized
INFO - 2022-12-07 07:35:22 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:22 --> Input Class Initialized
INFO - 2022-12-07 07:35:22 --> Language Class Initialized
INFO - 2022-12-07 07:35:22 --> Loader Class Initialized
INFO - 2022-12-07 07:35:22 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:22 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:22 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:22 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:22 --> Total execution time: 0.0364
INFO - 2022-12-07 07:35:27 --> Config Class Initialized
INFO - 2022-12-07 07:35:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:27 --> URI Class Initialized
INFO - 2022-12-07 07:35:27 --> Router Class Initialized
INFO - 2022-12-07 07:35:27 --> Output Class Initialized
INFO - 2022-12-07 07:35:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:27 --> Input Class Initialized
INFO - 2022-12-07 07:35:27 --> Language Class Initialized
INFO - 2022-12-07 07:35:27 --> Loader Class Initialized
INFO - 2022-12-07 07:35:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:27 --> Total execution time: 0.0214
INFO - 2022-12-07 07:35:27 --> Config Class Initialized
INFO - 2022-12-07 07:35:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:27 --> URI Class Initialized
INFO - 2022-12-07 07:35:27 --> Router Class Initialized
INFO - 2022-12-07 07:35:27 --> Output Class Initialized
INFO - 2022-12-07 07:35:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:27 --> Input Class Initialized
INFO - 2022-12-07 07:35:27 --> Language Class Initialized
INFO - 2022-12-07 07:35:27 --> Loader Class Initialized
INFO - 2022-12-07 07:35:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:27 --> Total execution time: 0.0649
INFO - 2022-12-07 07:35:32 --> Config Class Initialized
INFO - 2022-12-07 07:35:32 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:32 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:32 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:32 --> URI Class Initialized
INFO - 2022-12-07 07:35:32 --> Router Class Initialized
INFO - 2022-12-07 07:35:32 --> Output Class Initialized
INFO - 2022-12-07 07:35:32 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:32 --> Input Class Initialized
INFO - 2022-12-07 07:35:32 --> Language Class Initialized
INFO - 2022-12-07 07:35:32 --> Loader Class Initialized
INFO - 2022-12-07 07:35:32 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:32 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:32 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:32 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:32 --> Total execution time: 0.0700
INFO - 2022-12-07 07:35:37 --> Config Class Initialized
INFO - 2022-12-07 07:35:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:37 --> URI Class Initialized
INFO - 2022-12-07 07:35:37 --> Router Class Initialized
INFO - 2022-12-07 07:35:37 --> Output Class Initialized
INFO - 2022-12-07 07:35:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:37 --> Input Class Initialized
INFO - 2022-12-07 07:35:37 --> Language Class Initialized
INFO - 2022-12-07 07:35:37 --> Loader Class Initialized
INFO - 2022-12-07 07:35:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:37 --> Total execution time: 0.0211
INFO - 2022-12-07 07:35:37 --> Config Class Initialized
INFO - 2022-12-07 07:35:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:37 --> URI Class Initialized
INFO - 2022-12-07 07:35:37 --> Router Class Initialized
INFO - 2022-12-07 07:35:37 --> Output Class Initialized
INFO - 2022-12-07 07:35:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:37 --> Input Class Initialized
INFO - 2022-12-07 07:35:37 --> Language Class Initialized
INFO - 2022-12-07 07:35:37 --> Loader Class Initialized
INFO - 2022-12-07 07:35:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:37 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:37 --> Total execution time: 0.0477
INFO - 2022-12-07 07:35:42 --> Config Class Initialized
INFO - 2022-12-07 07:35:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:42 --> URI Class Initialized
INFO - 2022-12-07 07:35:42 --> Router Class Initialized
INFO - 2022-12-07 07:35:42 --> Output Class Initialized
INFO - 2022-12-07 07:35:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:42 --> Input Class Initialized
INFO - 2022-12-07 07:35:42 --> Language Class Initialized
INFO - 2022-12-07 07:35:42 --> Loader Class Initialized
INFO - 2022-12-07 07:35:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:42 --> Total execution time: 0.0392
INFO - 2022-12-07 07:35:47 --> Config Class Initialized
INFO - 2022-12-07 07:35:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:47 --> URI Class Initialized
INFO - 2022-12-07 07:35:47 --> Router Class Initialized
INFO - 2022-12-07 07:35:47 --> Output Class Initialized
INFO - 2022-12-07 07:35:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:47 --> Input Class Initialized
INFO - 2022-12-07 07:35:47 --> Language Class Initialized
INFO - 2022-12-07 07:35:47 --> Loader Class Initialized
INFO - 2022-12-07 07:35:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:47 --> Total execution time: 0.0211
INFO - 2022-12-07 07:35:47 --> Config Class Initialized
INFO - 2022-12-07 07:35:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:47 --> URI Class Initialized
INFO - 2022-12-07 07:35:47 --> Router Class Initialized
INFO - 2022-12-07 07:35:47 --> Output Class Initialized
INFO - 2022-12-07 07:35:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:47 --> Input Class Initialized
INFO - 2022-12-07 07:35:47 --> Language Class Initialized
INFO - 2022-12-07 07:35:47 --> Loader Class Initialized
INFO - 2022-12-07 07:35:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:47 --> Total execution time: 0.0573
INFO - 2022-12-07 07:35:52 --> Config Class Initialized
INFO - 2022-12-07 07:35:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:52 --> URI Class Initialized
INFO - 2022-12-07 07:35:52 --> Router Class Initialized
INFO - 2022-12-07 07:35:52 --> Output Class Initialized
INFO - 2022-12-07 07:35:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:52 --> Input Class Initialized
INFO - 2022-12-07 07:35:52 --> Language Class Initialized
INFO - 2022-12-07 07:35:52 --> Loader Class Initialized
INFO - 2022-12-07 07:35:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:52 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:52 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:52 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:52 --> Total execution time: 0.0691
INFO - 2022-12-07 07:35:57 --> Config Class Initialized
INFO - 2022-12-07 07:35:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:57 --> URI Class Initialized
INFO - 2022-12-07 07:35:57 --> Router Class Initialized
INFO - 2022-12-07 07:35:57 --> Output Class Initialized
INFO - 2022-12-07 07:35:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:57 --> Input Class Initialized
INFO - 2022-12-07 07:35:57 --> Language Class Initialized
INFO - 2022-12-07 07:35:57 --> Loader Class Initialized
INFO - 2022-12-07 07:35:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:57 --> Total execution time: 0.0212
INFO - 2022-12-07 07:35:57 --> Config Class Initialized
INFO - 2022-12-07 07:35:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:35:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:35:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:35:57 --> URI Class Initialized
INFO - 2022-12-07 07:35:57 --> Router Class Initialized
INFO - 2022-12-07 07:35:57 --> Output Class Initialized
INFO - 2022-12-07 07:35:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:35:57 --> Input Class Initialized
INFO - 2022-12-07 07:35:57 --> Language Class Initialized
INFO - 2022-12-07 07:35:57 --> Loader Class Initialized
INFO - 2022-12-07 07:35:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:35:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:35:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:35:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:35:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:35:57 --> Total execution time: 0.0471
INFO - 2022-12-07 07:36:02 --> Config Class Initialized
INFO - 2022-12-07 07:36:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:02 --> URI Class Initialized
INFO - 2022-12-07 07:36:02 --> Router Class Initialized
INFO - 2022-12-07 07:36:02 --> Output Class Initialized
INFO - 2022-12-07 07:36:02 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:02 --> Input Class Initialized
INFO - 2022-12-07 07:36:02 --> Language Class Initialized
INFO - 2022-12-07 07:36:02 --> Loader Class Initialized
INFO - 2022-12-07 07:36:02 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:02 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:02 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:02 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:02 --> Total execution time: 0.0564
INFO - 2022-12-07 07:36:07 --> Config Class Initialized
INFO - 2022-12-07 07:36:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:07 --> URI Class Initialized
INFO - 2022-12-07 07:36:07 --> Router Class Initialized
INFO - 2022-12-07 07:36:07 --> Output Class Initialized
INFO - 2022-12-07 07:36:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:07 --> Input Class Initialized
INFO - 2022-12-07 07:36:07 --> Language Class Initialized
INFO - 2022-12-07 07:36:07 --> Loader Class Initialized
INFO - 2022-12-07 07:36:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:07 --> Total execution time: 0.0211
INFO - 2022-12-07 07:36:07 --> Config Class Initialized
INFO - 2022-12-07 07:36:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:07 --> URI Class Initialized
INFO - 2022-12-07 07:36:07 --> Router Class Initialized
INFO - 2022-12-07 07:36:07 --> Output Class Initialized
INFO - 2022-12-07 07:36:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:07 --> Input Class Initialized
INFO - 2022-12-07 07:36:07 --> Language Class Initialized
INFO - 2022-12-07 07:36:07 --> Loader Class Initialized
INFO - 2022-12-07 07:36:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:07 --> Total execution time: 0.0352
INFO - 2022-12-07 07:36:12 --> Config Class Initialized
INFO - 2022-12-07 07:36:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:12 --> URI Class Initialized
INFO - 2022-12-07 07:36:12 --> Router Class Initialized
INFO - 2022-12-07 07:36:12 --> Output Class Initialized
INFO - 2022-12-07 07:36:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:12 --> Input Class Initialized
INFO - 2022-12-07 07:36:12 --> Language Class Initialized
INFO - 2022-12-07 07:36:12 --> Loader Class Initialized
INFO - 2022-12-07 07:36:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:12 --> Total execution time: 0.2619
INFO - 2022-12-07 07:36:17 --> Config Class Initialized
INFO - 2022-12-07 07:36:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:17 --> URI Class Initialized
INFO - 2022-12-07 07:36:17 --> Router Class Initialized
INFO - 2022-12-07 07:36:17 --> Output Class Initialized
INFO - 2022-12-07 07:36:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:17 --> Input Class Initialized
INFO - 2022-12-07 07:36:17 --> Language Class Initialized
INFO - 2022-12-07 07:36:17 --> Loader Class Initialized
INFO - 2022-12-07 07:36:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:17 --> Total execution time: 0.0424
INFO - 2022-12-07 07:36:17 --> Config Class Initialized
INFO - 2022-12-07 07:36:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:17 --> URI Class Initialized
INFO - 2022-12-07 07:36:17 --> Router Class Initialized
INFO - 2022-12-07 07:36:17 --> Output Class Initialized
INFO - 2022-12-07 07:36:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:17 --> Input Class Initialized
INFO - 2022-12-07 07:36:17 --> Language Class Initialized
INFO - 2022-12-07 07:36:17 --> Loader Class Initialized
INFO - 2022-12-07 07:36:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:17 --> Total execution time: 0.1280
INFO - 2022-12-07 07:36:22 --> Config Class Initialized
INFO - 2022-12-07 07:36:22 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:22 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:22 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:22 --> URI Class Initialized
INFO - 2022-12-07 07:36:22 --> Router Class Initialized
INFO - 2022-12-07 07:36:22 --> Output Class Initialized
INFO - 2022-12-07 07:36:22 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:22 --> Input Class Initialized
INFO - 2022-12-07 07:36:22 --> Language Class Initialized
INFO - 2022-12-07 07:36:22 --> Loader Class Initialized
INFO - 2022-12-07 07:36:22 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:22 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:22 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:22 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:22 --> Total execution time: 0.0678
INFO - 2022-12-07 07:36:27 --> Config Class Initialized
INFO - 2022-12-07 07:36:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:27 --> URI Class Initialized
INFO - 2022-12-07 07:36:27 --> Router Class Initialized
INFO - 2022-12-07 07:36:27 --> Output Class Initialized
INFO - 2022-12-07 07:36:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:27 --> Input Class Initialized
INFO - 2022-12-07 07:36:27 --> Language Class Initialized
INFO - 2022-12-07 07:36:27 --> Loader Class Initialized
INFO - 2022-12-07 07:36:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:27 --> Total execution time: 0.0642
INFO - 2022-12-07 07:36:27 --> Config Class Initialized
INFO - 2022-12-07 07:36:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:27 --> URI Class Initialized
INFO - 2022-12-07 07:36:27 --> Router Class Initialized
INFO - 2022-12-07 07:36:27 --> Output Class Initialized
INFO - 2022-12-07 07:36:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:27 --> Input Class Initialized
INFO - 2022-12-07 07:36:27 --> Language Class Initialized
INFO - 2022-12-07 07:36:27 --> Loader Class Initialized
INFO - 2022-12-07 07:36:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:27 --> Total execution time: 0.3053
INFO - 2022-12-07 07:36:32 --> Config Class Initialized
INFO - 2022-12-07 07:36:32 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:32 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:32 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:32 --> URI Class Initialized
INFO - 2022-12-07 07:36:32 --> Router Class Initialized
INFO - 2022-12-07 07:36:32 --> Output Class Initialized
INFO - 2022-12-07 07:36:32 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:32 --> Input Class Initialized
INFO - 2022-12-07 07:36:32 --> Language Class Initialized
INFO - 2022-12-07 07:36:32 --> Loader Class Initialized
INFO - 2022-12-07 07:36:32 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:32 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:32 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:32 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:32 --> Total execution time: 0.0388
INFO - 2022-12-07 07:36:37 --> Config Class Initialized
INFO - 2022-12-07 07:36:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:37 --> URI Class Initialized
INFO - 2022-12-07 07:36:37 --> Router Class Initialized
INFO - 2022-12-07 07:36:37 --> Output Class Initialized
INFO - 2022-12-07 07:36:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:37 --> Input Class Initialized
INFO - 2022-12-07 07:36:37 --> Language Class Initialized
INFO - 2022-12-07 07:36:37 --> Loader Class Initialized
INFO - 2022-12-07 07:36:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:37 --> Total execution time: 0.0218
INFO - 2022-12-07 07:36:37 --> Config Class Initialized
INFO - 2022-12-07 07:36:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:37 --> URI Class Initialized
INFO - 2022-12-07 07:36:37 --> Router Class Initialized
INFO - 2022-12-07 07:36:37 --> Output Class Initialized
INFO - 2022-12-07 07:36:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:37 --> Input Class Initialized
INFO - 2022-12-07 07:36:37 --> Language Class Initialized
INFO - 2022-12-07 07:36:37 --> Loader Class Initialized
INFO - 2022-12-07 07:36:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:37 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:37 --> Total execution time: 0.0600
INFO - 2022-12-07 07:36:42 --> Config Class Initialized
INFO - 2022-12-07 07:36:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:42 --> URI Class Initialized
INFO - 2022-12-07 07:36:42 --> Router Class Initialized
INFO - 2022-12-07 07:36:42 --> Output Class Initialized
INFO - 2022-12-07 07:36:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:42 --> Input Class Initialized
INFO - 2022-12-07 07:36:42 --> Language Class Initialized
INFO - 2022-12-07 07:36:42 --> Loader Class Initialized
INFO - 2022-12-07 07:36:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:42 --> Total execution time: 0.0792
INFO - 2022-12-07 07:36:47 --> Config Class Initialized
INFO - 2022-12-07 07:36:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:47 --> URI Class Initialized
INFO - 2022-12-07 07:36:47 --> Router Class Initialized
INFO - 2022-12-07 07:36:47 --> Output Class Initialized
INFO - 2022-12-07 07:36:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:47 --> Input Class Initialized
INFO - 2022-12-07 07:36:47 --> Language Class Initialized
INFO - 2022-12-07 07:36:47 --> Loader Class Initialized
INFO - 2022-12-07 07:36:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:47 --> Total execution time: 0.0234
INFO - 2022-12-07 07:36:47 --> Config Class Initialized
INFO - 2022-12-07 07:36:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:47 --> URI Class Initialized
INFO - 2022-12-07 07:36:47 --> Router Class Initialized
INFO - 2022-12-07 07:36:47 --> Output Class Initialized
INFO - 2022-12-07 07:36:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:47 --> Input Class Initialized
INFO - 2022-12-07 07:36:47 --> Language Class Initialized
INFO - 2022-12-07 07:36:47 --> Loader Class Initialized
INFO - 2022-12-07 07:36:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:47 --> Total execution time: 0.0361
INFO - 2022-12-07 07:36:52 --> Config Class Initialized
INFO - 2022-12-07 07:36:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:52 --> URI Class Initialized
INFO - 2022-12-07 07:36:52 --> Router Class Initialized
INFO - 2022-12-07 07:36:52 --> Output Class Initialized
INFO - 2022-12-07 07:36:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:52 --> Input Class Initialized
INFO - 2022-12-07 07:36:52 --> Language Class Initialized
INFO - 2022-12-07 07:36:52 --> Loader Class Initialized
INFO - 2022-12-07 07:36:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:52 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:52 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:52 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:52 --> Total execution time: 0.0505
INFO - 2022-12-07 07:36:57 --> Config Class Initialized
INFO - 2022-12-07 07:36:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:57 --> URI Class Initialized
INFO - 2022-12-07 07:36:57 --> Router Class Initialized
INFO - 2022-12-07 07:36:57 --> Output Class Initialized
INFO - 2022-12-07 07:36:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:57 --> Input Class Initialized
INFO - 2022-12-07 07:36:57 --> Language Class Initialized
INFO - 2022-12-07 07:36:57 --> Loader Class Initialized
INFO - 2022-12-07 07:36:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:57 --> Total execution time: 0.0210
INFO - 2022-12-07 07:36:57 --> Config Class Initialized
INFO - 2022-12-07 07:36:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:36:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:36:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:36:57 --> URI Class Initialized
INFO - 2022-12-07 07:36:57 --> Router Class Initialized
INFO - 2022-12-07 07:36:57 --> Output Class Initialized
INFO - 2022-12-07 07:36:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:36:57 --> Input Class Initialized
INFO - 2022-12-07 07:36:57 --> Language Class Initialized
INFO - 2022-12-07 07:36:57 --> Loader Class Initialized
INFO - 2022-12-07 07:36:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:36:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:36:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:36:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:36:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:36:57 --> Total execution time: 0.0683
INFO - 2022-12-07 07:37:02 --> Config Class Initialized
INFO - 2022-12-07 07:37:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:02 --> URI Class Initialized
INFO - 2022-12-07 07:37:02 --> Router Class Initialized
INFO - 2022-12-07 07:37:02 --> Output Class Initialized
INFO - 2022-12-07 07:37:02 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:02 --> Input Class Initialized
INFO - 2022-12-07 07:37:02 --> Language Class Initialized
INFO - 2022-12-07 07:37:02 --> Loader Class Initialized
INFO - 2022-12-07 07:37:02 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:02 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:02 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:02 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:02 --> Total execution time: 0.0834
INFO - 2022-12-07 07:37:07 --> Config Class Initialized
INFO - 2022-12-07 07:37:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:07 --> URI Class Initialized
INFO - 2022-12-07 07:37:07 --> Router Class Initialized
INFO - 2022-12-07 07:37:07 --> Output Class Initialized
INFO - 2022-12-07 07:37:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:07 --> Input Class Initialized
INFO - 2022-12-07 07:37:07 --> Language Class Initialized
INFO - 2022-12-07 07:37:07 --> Loader Class Initialized
INFO - 2022-12-07 07:37:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:07 --> Total execution time: 0.0211
INFO - 2022-12-07 07:37:07 --> Config Class Initialized
INFO - 2022-12-07 07:37:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:07 --> URI Class Initialized
INFO - 2022-12-07 07:37:07 --> Router Class Initialized
INFO - 2022-12-07 07:37:07 --> Output Class Initialized
INFO - 2022-12-07 07:37:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:07 --> Input Class Initialized
INFO - 2022-12-07 07:37:07 --> Language Class Initialized
INFO - 2022-12-07 07:37:07 --> Loader Class Initialized
INFO - 2022-12-07 07:37:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:07 --> Total execution time: 0.0346
INFO - 2022-12-07 07:37:12 --> Config Class Initialized
INFO - 2022-12-07 07:37:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:12 --> URI Class Initialized
INFO - 2022-12-07 07:37:12 --> Router Class Initialized
INFO - 2022-12-07 07:37:12 --> Output Class Initialized
INFO - 2022-12-07 07:37:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:12 --> Input Class Initialized
INFO - 2022-12-07 07:37:12 --> Language Class Initialized
INFO - 2022-12-07 07:37:12 --> Loader Class Initialized
INFO - 2022-12-07 07:37:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:12 --> Total execution time: 0.0592
INFO - 2022-12-07 07:37:17 --> Config Class Initialized
INFO - 2022-12-07 07:37:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:17 --> URI Class Initialized
INFO - 2022-12-07 07:37:17 --> Router Class Initialized
INFO - 2022-12-07 07:37:17 --> Output Class Initialized
INFO - 2022-12-07 07:37:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:17 --> Input Class Initialized
INFO - 2022-12-07 07:37:17 --> Language Class Initialized
INFO - 2022-12-07 07:37:17 --> Loader Class Initialized
INFO - 2022-12-07 07:37:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:17 --> Total execution time: 0.0233
INFO - 2022-12-07 07:37:17 --> Config Class Initialized
INFO - 2022-12-07 07:37:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:17 --> URI Class Initialized
INFO - 2022-12-07 07:37:17 --> Router Class Initialized
INFO - 2022-12-07 07:37:17 --> Output Class Initialized
INFO - 2022-12-07 07:37:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:17 --> Input Class Initialized
INFO - 2022-12-07 07:37:17 --> Language Class Initialized
INFO - 2022-12-07 07:37:17 --> Loader Class Initialized
INFO - 2022-12-07 07:37:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:17 --> Total execution time: 0.0590
INFO - 2022-12-07 07:37:22 --> Config Class Initialized
INFO - 2022-12-07 07:37:22 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:22 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:22 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:22 --> URI Class Initialized
INFO - 2022-12-07 07:37:22 --> Router Class Initialized
INFO - 2022-12-07 07:37:22 --> Output Class Initialized
INFO - 2022-12-07 07:37:22 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:22 --> Input Class Initialized
INFO - 2022-12-07 07:37:22 --> Language Class Initialized
INFO - 2022-12-07 07:37:22 --> Loader Class Initialized
INFO - 2022-12-07 07:37:22 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:22 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:22 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:22 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:22 --> Total execution time: 0.0398
INFO - 2022-12-07 07:37:27 --> Config Class Initialized
INFO - 2022-12-07 07:37:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:27 --> URI Class Initialized
INFO - 2022-12-07 07:37:27 --> Router Class Initialized
INFO - 2022-12-07 07:37:27 --> Output Class Initialized
INFO - 2022-12-07 07:37:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:27 --> Input Class Initialized
INFO - 2022-12-07 07:37:27 --> Language Class Initialized
INFO - 2022-12-07 07:37:27 --> Loader Class Initialized
INFO - 2022-12-07 07:37:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:27 --> Total execution time: 0.0206
INFO - 2022-12-07 07:37:27 --> Config Class Initialized
INFO - 2022-12-07 07:37:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:27 --> URI Class Initialized
INFO - 2022-12-07 07:37:27 --> Router Class Initialized
INFO - 2022-12-07 07:37:27 --> Output Class Initialized
INFO - 2022-12-07 07:37:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:27 --> Input Class Initialized
INFO - 2022-12-07 07:37:27 --> Language Class Initialized
INFO - 2022-12-07 07:37:27 --> Loader Class Initialized
INFO - 2022-12-07 07:37:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:27 --> Total execution time: 0.0656
INFO - 2022-12-07 07:37:32 --> Config Class Initialized
INFO - 2022-12-07 07:37:32 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:32 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:32 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:32 --> URI Class Initialized
INFO - 2022-12-07 07:37:32 --> Router Class Initialized
INFO - 2022-12-07 07:37:32 --> Output Class Initialized
INFO - 2022-12-07 07:37:32 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:32 --> Input Class Initialized
INFO - 2022-12-07 07:37:32 --> Language Class Initialized
INFO - 2022-12-07 07:37:32 --> Loader Class Initialized
INFO - 2022-12-07 07:37:32 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:32 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:32 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:32 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:32 --> Total execution time: 0.0356
INFO - 2022-12-07 07:37:37 --> Config Class Initialized
INFO - 2022-12-07 07:37:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:37 --> URI Class Initialized
INFO - 2022-12-07 07:37:37 --> Router Class Initialized
INFO - 2022-12-07 07:37:37 --> Output Class Initialized
INFO - 2022-12-07 07:37:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:37 --> Input Class Initialized
INFO - 2022-12-07 07:37:37 --> Language Class Initialized
INFO - 2022-12-07 07:37:37 --> Loader Class Initialized
INFO - 2022-12-07 07:37:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:37 --> Total execution time: 0.0203
INFO - 2022-12-07 07:37:37 --> Config Class Initialized
INFO - 2022-12-07 07:37:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:37 --> URI Class Initialized
INFO - 2022-12-07 07:37:37 --> Router Class Initialized
INFO - 2022-12-07 07:37:37 --> Output Class Initialized
INFO - 2022-12-07 07:37:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:37 --> Input Class Initialized
INFO - 2022-12-07 07:37:37 --> Language Class Initialized
INFO - 2022-12-07 07:37:37 --> Loader Class Initialized
INFO - 2022-12-07 07:37:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:37 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:37 --> Total execution time: 0.0360
INFO - 2022-12-07 07:37:42 --> Config Class Initialized
INFO - 2022-12-07 07:37:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:42 --> URI Class Initialized
INFO - 2022-12-07 07:37:42 --> Router Class Initialized
INFO - 2022-12-07 07:37:42 --> Output Class Initialized
INFO - 2022-12-07 07:37:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:42 --> Input Class Initialized
INFO - 2022-12-07 07:37:42 --> Language Class Initialized
INFO - 2022-12-07 07:37:42 --> Loader Class Initialized
INFO - 2022-12-07 07:37:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:42 --> Total execution time: 0.0383
INFO - 2022-12-07 07:37:47 --> Config Class Initialized
INFO - 2022-12-07 07:37:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:47 --> URI Class Initialized
INFO - 2022-12-07 07:37:47 --> Router Class Initialized
INFO - 2022-12-07 07:37:47 --> Output Class Initialized
INFO - 2022-12-07 07:37:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:47 --> Input Class Initialized
INFO - 2022-12-07 07:37:47 --> Language Class Initialized
INFO - 2022-12-07 07:37:47 --> Loader Class Initialized
INFO - 2022-12-07 07:37:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:47 --> Total execution time: 0.0210
INFO - 2022-12-07 07:37:47 --> Config Class Initialized
INFO - 2022-12-07 07:37:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:47 --> URI Class Initialized
INFO - 2022-12-07 07:37:47 --> Router Class Initialized
INFO - 2022-12-07 07:37:47 --> Output Class Initialized
INFO - 2022-12-07 07:37:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:47 --> Input Class Initialized
INFO - 2022-12-07 07:37:47 --> Language Class Initialized
INFO - 2022-12-07 07:37:47 --> Loader Class Initialized
INFO - 2022-12-07 07:37:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:47 --> Total execution time: 0.0473
INFO - 2022-12-07 07:37:52 --> Config Class Initialized
INFO - 2022-12-07 07:37:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:52 --> URI Class Initialized
INFO - 2022-12-07 07:37:52 --> Router Class Initialized
INFO - 2022-12-07 07:37:52 --> Output Class Initialized
INFO - 2022-12-07 07:37:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:52 --> Input Class Initialized
INFO - 2022-12-07 07:37:52 --> Language Class Initialized
INFO - 2022-12-07 07:37:52 --> Loader Class Initialized
INFO - 2022-12-07 07:37:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:52 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:52 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:52 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:52 --> Total execution time: 0.0390
INFO - 2022-12-07 07:37:57 --> Config Class Initialized
INFO - 2022-12-07 07:37:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:57 --> URI Class Initialized
INFO - 2022-12-07 07:37:57 --> Router Class Initialized
INFO - 2022-12-07 07:37:57 --> Output Class Initialized
INFO - 2022-12-07 07:37:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:57 --> Input Class Initialized
INFO - 2022-12-07 07:37:57 --> Language Class Initialized
INFO - 2022-12-07 07:37:57 --> Loader Class Initialized
INFO - 2022-12-07 07:37:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:57 --> Total execution time: 0.0211
INFO - 2022-12-07 07:37:57 --> Config Class Initialized
INFO - 2022-12-07 07:37:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:37:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:37:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:37:57 --> URI Class Initialized
INFO - 2022-12-07 07:37:57 --> Router Class Initialized
INFO - 2022-12-07 07:37:57 --> Output Class Initialized
INFO - 2022-12-07 07:37:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:37:57 --> Input Class Initialized
INFO - 2022-12-07 07:37:57 --> Language Class Initialized
INFO - 2022-12-07 07:37:57 --> Loader Class Initialized
INFO - 2022-12-07 07:37:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:37:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:37:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:37:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:37:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:37:57 --> Total execution time: 0.0585
INFO - 2022-12-07 07:38:02 --> Config Class Initialized
INFO - 2022-12-07 07:38:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:02 --> URI Class Initialized
INFO - 2022-12-07 07:38:02 --> Router Class Initialized
INFO - 2022-12-07 07:38:02 --> Output Class Initialized
INFO - 2022-12-07 07:38:02 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:02 --> Input Class Initialized
INFO - 2022-12-07 07:38:02 --> Language Class Initialized
INFO - 2022-12-07 07:38:02 --> Loader Class Initialized
INFO - 2022-12-07 07:38:02 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:02 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:02 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:02 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:02 --> Total execution time: 0.0468
INFO - 2022-12-07 07:38:07 --> Config Class Initialized
INFO - 2022-12-07 07:38:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:07 --> URI Class Initialized
INFO - 2022-12-07 07:38:07 --> Router Class Initialized
INFO - 2022-12-07 07:38:07 --> Output Class Initialized
INFO - 2022-12-07 07:38:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:07 --> Input Class Initialized
INFO - 2022-12-07 07:38:07 --> Language Class Initialized
INFO - 2022-12-07 07:38:07 --> Loader Class Initialized
INFO - 2022-12-07 07:38:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:07 --> Total execution time: 0.0204
INFO - 2022-12-07 07:38:07 --> Config Class Initialized
INFO - 2022-12-07 07:38:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:07 --> URI Class Initialized
INFO - 2022-12-07 07:38:07 --> Router Class Initialized
INFO - 2022-12-07 07:38:07 --> Output Class Initialized
INFO - 2022-12-07 07:38:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:07 --> Input Class Initialized
INFO - 2022-12-07 07:38:07 --> Language Class Initialized
INFO - 2022-12-07 07:38:07 --> Loader Class Initialized
INFO - 2022-12-07 07:38:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:07 --> Total execution time: 0.0758
INFO - 2022-12-07 07:38:12 --> Config Class Initialized
INFO - 2022-12-07 07:38:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:12 --> URI Class Initialized
INFO - 2022-12-07 07:38:12 --> Router Class Initialized
INFO - 2022-12-07 07:38:12 --> Output Class Initialized
INFO - 2022-12-07 07:38:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:12 --> Input Class Initialized
INFO - 2022-12-07 07:38:12 --> Language Class Initialized
INFO - 2022-12-07 07:38:12 --> Loader Class Initialized
INFO - 2022-12-07 07:38:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:12 --> Total execution time: 0.0385
INFO - 2022-12-07 07:38:17 --> Config Class Initialized
INFO - 2022-12-07 07:38:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:17 --> URI Class Initialized
INFO - 2022-12-07 07:38:17 --> Router Class Initialized
INFO - 2022-12-07 07:38:17 --> Output Class Initialized
INFO - 2022-12-07 07:38:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:17 --> Input Class Initialized
INFO - 2022-12-07 07:38:17 --> Language Class Initialized
INFO - 2022-12-07 07:38:17 --> Loader Class Initialized
INFO - 2022-12-07 07:38:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:17 --> Total execution time: 0.0210
INFO - 2022-12-07 07:38:17 --> Config Class Initialized
INFO - 2022-12-07 07:38:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:17 --> URI Class Initialized
INFO - 2022-12-07 07:38:17 --> Router Class Initialized
INFO - 2022-12-07 07:38:17 --> Output Class Initialized
INFO - 2022-12-07 07:38:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:17 --> Input Class Initialized
INFO - 2022-12-07 07:38:17 --> Language Class Initialized
INFO - 2022-12-07 07:38:17 --> Loader Class Initialized
INFO - 2022-12-07 07:38:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:17 --> Total execution time: 0.0914
INFO - 2022-12-07 07:38:22 --> Config Class Initialized
INFO - 2022-12-07 07:38:22 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:22 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:22 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:22 --> URI Class Initialized
INFO - 2022-12-07 07:38:22 --> Router Class Initialized
INFO - 2022-12-07 07:38:22 --> Output Class Initialized
INFO - 2022-12-07 07:38:22 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:22 --> Input Class Initialized
INFO - 2022-12-07 07:38:22 --> Language Class Initialized
INFO - 2022-12-07 07:38:22 --> Loader Class Initialized
INFO - 2022-12-07 07:38:22 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:22 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:22 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:22 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:22 --> Total execution time: 0.0586
INFO - 2022-12-07 07:38:27 --> Config Class Initialized
INFO - 2022-12-07 07:38:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:27 --> URI Class Initialized
INFO - 2022-12-07 07:38:27 --> Router Class Initialized
INFO - 2022-12-07 07:38:27 --> Output Class Initialized
INFO - 2022-12-07 07:38:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:27 --> Input Class Initialized
INFO - 2022-12-07 07:38:27 --> Language Class Initialized
INFO - 2022-12-07 07:38:27 --> Loader Class Initialized
INFO - 2022-12-07 07:38:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:27 --> Total execution time: 0.0229
INFO - 2022-12-07 07:38:27 --> Config Class Initialized
INFO - 2022-12-07 07:38:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:27 --> URI Class Initialized
INFO - 2022-12-07 07:38:27 --> Router Class Initialized
INFO - 2022-12-07 07:38:27 --> Output Class Initialized
INFO - 2022-12-07 07:38:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:27 --> Input Class Initialized
INFO - 2022-12-07 07:38:27 --> Language Class Initialized
INFO - 2022-12-07 07:38:27 --> Loader Class Initialized
INFO - 2022-12-07 07:38:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:27 --> Total execution time: 0.0478
INFO - 2022-12-07 07:38:32 --> Config Class Initialized
INFO - 2022-12-07 07:38:32 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:32 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:32 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:32 --> URI Class Initialized
INFO - 2022-12-07 07:38:32 --> Router Class Initialized
INFO - 2022-12-07 07:38:32 --> Output Class Initialized
INFO - 2022-12-07 07:38:32 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:32 --> Input Class Initialized
INFO - 2022-12-07 07:38:32 --> Language Class Initialized
INFO - 2022-12-07 07:38:32 --> Loader Class Initialized
INFO - 2022-12-07 07:38:32 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:32 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:32 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:32 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:32 --> Total execution time: 0.0589
INFO - 2022-12-07 07:38:37 --> Config Class Initialized
INFO - 2022-12-07 07:38:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:37 --> URI Class Initialized
INFO - 2022-12-07 07:38:37 --> Router Class Initialized
INFO - 2022-12-07 07:38:37 --> Output Class Initialized
INFO - 2022-12-07 07:38:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:37 --> Input Class Initialized
INFO - 2022-12-07 07:38:37 --> Language Class Initialized
INFO - 2022-12-07 07:38:37 --> Loader Class Initialized
INFO - 2022-12-07 07:38:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:37 --> Total execution time: 0.0227
INFO - 2022-12-07 07:38:37 --> Config Class Initialized
INFO - 2022-12-07 07:38:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:37 --> URI Class Initialized
INFO - 2022-12-07 07:38:37 --> Router Class Initialized
INFO - 2022-12-07 07:38:37 --> Output Class Initialized
INFO - 2022-12-07 07:38:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:37 --> Input Class Initialized
INFO - 2022-12-07 07:38:37 --> Language Class Initialized
INFO - 2022-12-07 07:38:37 --> Loader Class Initialized
INFO - 2022-12-07 07:38:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:37 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:37 --> Total execution time: 0.0505
INFO - 2022-12-07 07:38:42 --> Config Class Initialized
INFO - 2022-12-07 07:38:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:42 --> URI Class Initialized
INFO - 2022-12-07 07:38:42 --> Router Class Initialized
INFO - 2022-12-07 07:38:42 --> Output Class Initialized
INFO - 2022-12-07 07:38:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:42 --> Input Class Initialized
INFO - 2022-12-07 07:38:42 --> Language Class Initialized
INFO - 2022-12-07 07:38:42 --> Loader Class Initialized
INFO - 2022-12-07 07:38:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:42 --> Total execution time: 0.0382
INFO - 2022-12-07 07:38:47 --> Config Class Initialized
INFO - 2022-12-07 07:38:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:47 --> URI Class Initialized
INFO - 2022-12-07 07:38:47 --> Router Class Initialized
INFO - 2022-12-07 07:38:47 --> Output Class Initialized
INFO - 2022-12-07 07:38:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:47 --> Input Class Initialized
INFO - 2022-12-07 07:38:47 --> Language Class Initialized
INFO - 2022-12-07 07:38:47 --> Loader Class Initialized
INFO - 2022-12-07 07:38:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:47 --> Total execution time: 0.0228
INFO - 2022-12-07 07:38:47 --> Config Class Initialized
INFO - 2022-12-07 07:38:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:47 --> URI Class Initialized
INFO - 2022-12-07 07:38:47 --> Router Class Initialized
INFO - 2022-12-07 07:38:47 --> Output Class Initialized
INFO - 2022-12-07 07:38:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:47 --> Input Class Initialized
INFO - 2022-12-07 07:38:47 --> Language Class Initialized
INFO - 2022-12-07 07:38:47 --> Loader Class Initialized
INFO - 2022-12-07 07:38:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:47 --> Total execution time: 0.0480
INFO - 2022-12-07 07:38:52 --> Config Class Initialized
INFO - 2022-12-07 07:38:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:52 --> URI Class Initialized
INFO - 2022-12-07 07:38:52 --> Router Class Initialized
INFO - 2022-12-07 07:38:52 --> Output Class Initialized
INFO - 2022-12-07 07:38:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:52 --> Input Class Initialized
INFO - 2022-12-07 07:38:52 --> Language Class Initialized
INFO - 2022-12-07 07:38:52 --> Loader Class Initialized
INFO - 2022-12-07 07:38:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:52 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:52 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:52 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:52 --> Total execution time: 0.0869
INFO - 2022-12-07 07:38:57 --> Config Class Initialized
INFO - 2022-12-07 07:38:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:57 --> URI Class Initialized
INFO - 2022-12-07 07:38:57 --> Router Class Initialized
INFO - 2022-12-07 07:38:57 --> Output Class Initialized
INFO - 2022-12-07 07:38:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:57 --> Input Class Initialized
INFO - 2022-12-07 07:38:57 --> Language Class Initialized
INFO - 2022-12-07 07:38:57 --> Loader Class Initialized
INFO - 2022-12-07 07:38:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:57 --> Total execution time: 0.0219
INFO - 2022-12-07 07:38:57 --> Config Class Initialized
INFO - 2022-12-07 07:38:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:38:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:38:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:38:57 --> URI Class Initialized
INFO - 2022-12-07 07:38:57 --> Router Class Initialized
INFO - 2022-12-07 07:38:57 --> Output Class Initialized
INFO - 2022-12-07 07:38:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:38:57 --> Input Class Initialized
INFO - 2022-12-07 07:38:57 --> Language Class Initialized
INFO - 2022-12-07 07:38:57 --> Loader Class Initialized
INFO - 2022-12-07 07:38:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:38:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:38:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:38:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:38:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:38:57 --> Total execution time: 0.0441
INFO - 2022-12-07 07:39:02 --> Config Class Initialized
INFO - 2022-12-07 07:39:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:02 --> URI Class Initialized
INFO - 2022-12-07 07:39:02 --> Router Class Initialized
INFO - 2022-12-07 07:39:02 --> Output Class Initialized
INFO - 2022-12-07 07:39:02 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:02 --> Input Class Initialized
INFO - 2022-12-07 07:39:02 --> Language Class Initialized
INFO - 2022-12-07 07:39:02 --> Loader Class Initialized
INFO - 2022-12-07 07:39:02 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:02 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:02 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:02 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:02 --> Total execution time: 0.0586
INFO - 2022-12-07 07:39:07 --> Config Class Initialized
INFO - 2022-12-07 07:39:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:07 --> URI Class Initialized
INFO - 2022-12-07 07:39:07 --> Router Class Initialized
INFO - 2022-12-07 07:39:07 --> Output Class Initialized
INFO - 2022-12-07 07:39:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:07 --> Input Class Initialized
INFO - 2022-12-07 07:39:07 --> Language Class Initialized
INFO - 2022-12-07 07:39:07 --> Loader Class Initialized
INFO - 2022-12-07 07:39:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:07 --> Total execution time: 0.0213
INFO - 2022-12-07 07:39:07 --> Config Class Initialized
INFO - 2022-12-07 07:39:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:07 --> URI Class Initialized
INFO - 2022-12-07 07:39:07 --> Router Class Initialized
INFO - 2022-12-07 07:39:07 --> Output Class Initialized
INFO - 2022-12-07 07:39:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:07 --> Input Class Initialized
INFO - 2022-12-07 07:39:07 --> Language Class Initialized
INFO - 2022-12-07 07:39:07 --> Loader Class Initialized
INFO - 2022-12-07 07:39:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:07 --> Total execution time: 0.0474
INFO - 2022-12-07 07:39:12 --> Config Class Initialized
INFO - 2022-12-07 07:39:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:12 --> URI Class Initialized
INFO - 2022-12-07 07:39:12 --> Router Class Initialized
INFO - 2022-12-07 07:39:12 --> Output Class Initialized
INFO - 2022-12-07 07:39:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:12 --> Input Class Initialized
INFO - 2022-12-07 07:39:12 --> Language Class Initialized
INFO - 2022-12-07 07:39:12 --> Loader Class Initialized
INFO - 2022-12-07 07:39:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:12 --> Total execution time: 0.0478
INFO - 2022-12-07 07:39:17 --> Config Class Initialized
INFO - 2022-12-07 07:39:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:17 --> URI Class Initialized
INFO - 2022-12-07 07:39:17 --> Router Class Initialized
INFO - 2022-12-07 07:39:17 --> Output Class Initialized
INFO - 2022-12-07 07:39:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:17 --> Input Class Initialized
INFO - 2022-12-07 07:39:17 --> Language Class Initialized
INFO - 2022-12-07 07:39:17 --> Loader Class Initialized
INFO - 2022-12-07 07:39:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:17 --> Total execution time: 0.0221
INFO - 2022-12-07 07:39:17 --> Config Class Initialized
INFO - 2022-12-07 07:39:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:17 --> URI Class Initialized
INFO - 2022-12-07 07:39:17 --> Router Class Initialized
INFO - 2022-12-07 07:39:17 --> Output Class Initialized
INFO - 2022-12-07 07:39:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:17 --> Input Class Initialized
INFO - 2022-12-07 07:39:17 --> Language Class Initialized
INFO - 2022-12-07 07:39:17 --> Loader Class Initialized
INFO - 2022-12-07 07:39:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:17 --> Total execution time: 0.0347
INFO - 2022-12-07 07:39:22 --> Config Class Initialized
INFO - 2022-12-07 07:39:22 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:22 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:22 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:22 --> URI Class Initialized
INFO - 2022-12-07 07:39:22 --> Router Class Initialized
INFO - 2022-12-07 07:39:22 --> Output Class Initialized
INFO - 2022-12-07 07:39:22 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:22 --> Input Class Initialized
INFO - 2022-12-07 07:39:22 --> Language Class Initialized
INFO - 2022-12-07 07:39:22 --> Loader Class Initialized
INFO - 2022-12-07 07:39:22 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:22 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:22 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:22 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:22 --> Total execution time: 0.1170
INFO - 2022-12-07 07:39:27 --> Config Class Initialized
INFO - 2022-12-07 07:39:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:27 --> URI Class Initialized
INFO - 2022-12-07 07:39:27 --> Router Class Initialized
INFO - 2022-12-07 07:39:27 --> Output Class Initialized
INFO - 2022-12-07 07:39:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:27 --> Input Class Initialized
INFO - 2022-12-07 07:39:27 --> Language Class Initialized
INFO - 2022-12-07 07:39:27 --> Loader Class Initialized
INFO - 2022-12-07 07:39:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:27 --> Total execution time: 0.0231
INFO - 2022-12-07 07:39:27 --> Config Class Initialized
INFO - 2022-12-07 07:39:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:27 --> URI Class Initialized
INFO - 2022-12-07 07:39:27 --> Router Class Initialized
INFO - 2022-12-07 07:39:27 --> Output Class Initialized
INFO - 2022-12-07 07:39:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:27 --> Input Class Initialized
INFO - 2022-12-07 07:39:27 --> Language Class Initialized
INFO - 2022-12-07 07:39:27 --> Loader Class Initialized
INFO - 2022-12-07 07:39:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:27 --> Total execution time: 0.0465
INFO - 2022-12-07 07:39:32 --> Config Class Initialized
INFO - 2022-12-07 07:39:32 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:32 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:32 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:32 --> URI Class Initialized
INFO - 2022-12-07 07:39:32 --> Router Class Initialized
INFO - 2022-12-07 07:39:32 --> Output Class Initialized
INFO - 2022-12-07 07:39:32 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:32 --> Input Class Initialized
INFO - 2022-12-07 07:39:32 --> Language Class Initialized
INFO - 2022-12-07 07:39:32 --> Loader Class Initialized
INFO - 2022-12-07 07:39:32 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:32 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:32 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:32 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:32 --> Total execution time: 0.0531
INFO - 2022-12-07 07:39:37 --> Config Class Initialized
INFO - 2022-12-07 07:39:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:37 --> URI Class Initialized
INFO - 2022-12-07 07:39:37 --> Router Class Initialized
INFO - 2022-12-07 07:39:37 --> Output Class Initialized
INFO - 2022-12-07 07:39:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:37 --> Input Class Initialized
INFO - 2022-12-07 07:39:37 --> Language Class Initialized
INFO - 2022-12-07 07:39:37 --> Loader Class Initialized
INFO - 2022-12-07 07:39:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:37 --> Total execution time: 0.0208
INFO - 2022-12-07 07:39:37 --> Config Class Initialized
INFO - 2022-12-07 07:39:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:37 --> URI Class Initialized
INFO - 2022-12-07 07:39:37 --> Router Class Initialized
INFO - 2022-12-07 07:39:37 --> Output Class Initialized
INFO - 2022-12-07 07:39:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:37 --> Input Class Initialized
INFO - 2022-12-07 07:39:37 --> Language Class Initialized
INFO - 2022-12-07 07:39:37 --> Loader Class Initialized
INFO - 2022-12-07 07:39:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:37 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:37 --> Total execution time: 0.0367
INFO - 2022-12-07 07:39:42 --> Config Class Initialized
INFO - 2022-12-07 07:39:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:42 --> URI Class Initialized
INFO - 2022-12-07 07:39:42 --> Router Class Initialized
INFO - 2022-12-07 07:39:42 --> Output Class Initialized
INFO - 2022-12-07 07:39:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:42 --> Input Class Initialized
INFO - 2022-12-07 07:39:42 --> Language Class Initialized
INFO - 2022-12-07 07:39:42 --> Loader Class Initialized
INFO - 2022-12-07 07:39:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:42 --> Total execution time: 0.0594
INFO - 2022-12-07 07:39:47 --> Config Class Initialized
INFO - 2022-12-07 07:39:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:47 --> URI Class Initialized
INFO - 2022-12-07 07:39:47 --> Router Class Initialized
INFO - 2022-12-07 07:39:47 --> Output Class Initialized
INFO - 2022-12-07 07:39:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:47 --> Input Class Initialized
INFO - 2022-12-07 07:39:47 --> Language Class Initialized
INFO - 2022-12-07 07:39:47 --> Loader Class Initialized
INFO - 2022-12-07 07:39:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:47 --> Total execution time: 0.0211
INFO - 2022-12-07 07:39:47 --> Config Class Initialized
INFO - 2022-12-07 07:39:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:47 --> URI Class Initialized
INFO - 2022-12-07 07:39:47 --> Router Class Initialized
INFO - 2022-12-07 07:39:47 --> Output Class Initialized
INFO - 2022-12-07 07:39:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:47 --> Input Class Initialized
INFO - 2022-12-07 07:39:47 --> Language Class Initialized
INFO - 2022-12-07 07:39:47 --> Loader Class Initialized
INFO - 2022-12-07 07:39:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:47 --> Total execution time: 0.0454
INFO - 2022-12-07 07:39:52 --> Config Class Initialized
INFO - 2022-12-07 07:39:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:52 --> URI Class Initialized
INFO - 2022-12-07 07:39:52 --> Router Class Initialized
INFO - 2022-12-07 07:39:52 --> Output Class Initialized
INFO - 2022-12-07 07:39:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:52 --> Input Class Initialized
INFO - 2022-12-07 07:39:52 --> Language Class Initialized
INFO - 2022-12-07 07:39:52 --> Loader Class Initialized
INFO - 2022-12-07 07:39:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:52 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:52 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:52 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:52 --> Total execution time: 0.0385
INFO - 2022-12-07 07:39:57 --> Config Class Initialized
INFO - 2022-12-07 07:39:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:57 --> URI Class Initialized
INFO - 2022-12-07 07:39:57 --> Router Class Initialized
INFO - 2022-12-07 07:39:57 --> Output Class Initialized
INFO - 2022-12-07 07:39:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:57 --> Input Class Initialized
INFO - 2022-12-07 07:39:57 --> Language Class Initialized
INFO - 2022-12-07 07:39:57 --> Loader Class Initialized
INFO - 2022-12-07 07:39:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:57 --> Total execution time: 0.0233
INFO - 2022-12-07 07:39:57 --> Config Class Initialized
INFO - 2022-12-07 07:39:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:39:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:39:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:39:57 --> URI Class Initialized
INFO - 2022-12-07 07:39:57 --> Router Class Initialized
INFO - 2022-12-07 07:39:57 --> Output Class Initialized
INFO - 2022-12-07 07:39:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:39:57 --> Input Class Initialized
INFO - 2022-12-07 07:39:57 --> Language Class Initialized
INFO - 2022-12-07 07:39:57 --> Loader Class Initialized
INFO - 2022-12-07 07:39:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:39:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:39:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:39:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:39:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:39:57 --> Total execution time: 0.0530
INFO - 2022-12-07 07:40:02 --> Config Class Initialized
INFO - 2022-12-07 07:40:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:02 --> URI Class Initialized
INFO - 2022-12-07 07:40:02 --> Router Class Initialized
INFO - 2022-12-07 07:40:02 --> Output Class Initialized
INFO - 2022-12-07 07:40:02 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:02 --> Input Class Initialized
INFO - 2022-12-07 07:40:02 --> Language Class Initialized
INFO - 2022-12-07 07:40:02 --> Loader Class Initialized
INFO - 2022-12-07 07:40:02 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:02 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:02 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:02 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:02 --> Total execution time: 0.0728
INFO - 2022-12-07 07:40:07 --> Config Class Initialized
INFO - 2022-12-07 07:40:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:07 --> URI Class Initialized
INFO - 2022-12-07 07:40:07 --> Router Class Initialized
INFO - 2022-12-07 07:40:07 --> Output Class Initialized
INFO - 2022-12-07 07:40:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:07 --> Input Class Initialized
INFO - 2022-12-07 07:40:07 --> Language Class Initialized
INFO - 2022-12-07 07:40:07 --> Loader Class Initialized
INFO - 2022-12-07 07:40:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:07 --> Total execution time: 0.0227
INFO - 2022-12-07 07:40:07 --> Config Class Initialized
INFO - 2022-12-07 07:40:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:07 --> URI Class Initialized
INFO - 2022-12-07 07:40:07 --> Router Class Initialized
INFO - 2022-12-07 07:40:07 --> Output Class Initialized
INFO - 2022-12-07 07:40:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:07 --> Input Class Initialized
INFO - 2022-12-07 07:40:07 --> Language Class Initialized
INFO - 2022-12-07 07:40:07 --> Loader Class Initialized
INFO - 2022-12-07 07:40:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:07 --> Total execution time: 0.0601
INFO - 2022-12-07 07:40:12 --> Config Class Initialized
INFO - 2022-12-07 07:40:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:12 --> URI Class Initialized
INFO - 2022-12-07 07:40:12 --> Router Class Initialized
INFO - 2022-12-07 07:40:12 --> Output Class Initialized
INFO - 2022-12-07 07:40:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:12 --> Input Class Initialized
INFO - 2022-12-07 07:40:12 --> Language Class Initialized
INFO - 2022-12-07 07:40:12 --> Loader Class Initialized
INFO - 2022-12-07 07:40:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:12 --> Total execution time: 0.0373
INFO - 2022-12-07 07:40:17 --> Config Class Initialized
INFO - 2022-12-07 07:40:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:17 --> URI Class Initialized
INFO - 2022-12-07 07:40:17 --> Router Class Initialized
INFO - 2022-12-07 07:40:17 --> Output Class Initialized
INFO - 2022-12-07 07:40:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:17 --> Input Class Initialized
INFO - 2022-12-07 07:40:17 --> Language Class Initialized
INFO - 2022-12-07 07:40:17 --> Loader Class Initialized
INFO - 2022-12-07 07:40:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:17 --> Total execution time: 0.0208
INFO - 2022-12-07 07:40:17 --> Config Class Initialized
INFO - 2022-12-07 07:40:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:17 --> URI Class Initialized
INFO - 2022-12-07 07:40:17 --> Router Class Initialized
INFO - 2022-12-07 07:40:17 --> Output Class Initialized
INFO - 2022-12-07 07:40:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:17 --> Input Class Initialized
INFO - 2022-12-07 07:40:17 --> Language Class Initialized
INFO - 2022-12-07 07:40:17 --> Loader Class Initialized
INFO - 2022-12-07 07:40:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:17 --> Total execution time: 0.0351
INFO - 2022-12-07 07:40:22 --> Config Class Initialized
INFO - 2022-12-07 07:40:22 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:22 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:22 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:22 --> URI Class Initialized
INFO - 2022-12-07 07:40:22 --> Router Class Initialized
INFO - 2022-12-07 07:40:22 --> Output Class Initialized
INFO - 2022-12-07 07:40:22 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:22 --> Input Class Initialized
INFO - 2022-12-07 07:40:22 --> Language Class Initialized
INFO - 2022-12-07 07:40:22 --> Loader Class Initialized
INFO - 2022-12-07 07:40:22 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:22 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:22 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:22 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:22 --> Total execution time: 0.0828
INFO - 2022-12-07 07:40:27 --> Config Class Initialized
INFO - 2022-12-07 07:40:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:27 --> URI Class Initialized
INFO - 2022-12-07 07:40:27 --> Router Class Initialized
INFO - 2022-12-07 07:40:27 --> Output Class Initialized
INFO - 2022-12-07 07:40:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:27 --> Input Class Initialized
INFO - 2022-12-07 07:40:27 --> Language Class Initialized
INFO - 2022-12-07 07:40:27 --> Loader Class Initialized
INFO - 2022-12-07 07:40:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:27 --> Total execution time: 0.0228
INFO - 2022-12-07 07:40:27 --> Config Class Initialized
INFO - 2022-12-07 07:40:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:27 --> URI Class Initialized
INFO - 2022-12-07 07:40:27 --> Router Class Initialized
INFO - 2022-12-07 07:40:27 --> Output Class Initialized
INFO - 2022-12-07 07:40:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:27 --> Input Class Initialized
INFO - 2022-12-07 07:40:27 --> Language Class Initialized
INFO - 2022-12-07 07:40:27 --> Loader Class Initialized
INFO - 2022-12-07 07:40:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:27 --> Total execution time: 0.0573
INFO - 2022-12-07 07:40:32 --> Config Class Initialized
INFO - 2022-12-07 07:40:32 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:32 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:32 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:32 --> URI Class Initialized
INFO - 2022-12-07 07:40:32 --> Router Class Initialized
INFO - 2022-12-07 07:40:32 --> Output Class Initialized
INFO - 2022-12-07 07:40:32 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:32 --> Input Class Initialized
INFO - 2022-12-07 07:40:32 --> Language Class Initialized
INFO - 2022-12-07 07:40:32 --> Loader Class Initialized
INFO - 2022-12-07 07:40:32 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:32 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:32 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:32 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:32 --> Total execution time: 0.0371
INFO - 2022-12-07 07:40:37 --> Config Class Initialized
INFO - 2022-12-07 07:40:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:37 --> URI Class Initialized
INFO - 2022-12-07 07:40:37 --> Router Class Initialized
INFO - 2022-12-07 07:40:37 --> Output Class Initialized
INFO - 2022-12-07 07:40:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:37 --> Input Class Initialized
INFO - 2022-12-07 07:40:37 --> Language Class Initialized
INFO - 2022-12-07 07:40:37 --> Loader Class Initialized
INFO - 2022-12-07 07:40:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:37 --> Total execution time: 0.0223
INFO - 2022-12-07 07:40:37 --> Config Class Initialized
INFO - 2022-12-07 07:40:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:37 --> URI Class Initialized
INFO - 2022-12-07 07:40:37 --> Router Class Initialized
INFO - 2022-12-07 07:40:37 --> Output Class Initialized
INFO - 2022-12-07 07:40:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:37 --> Input Class Initialized
INFO - 2022-12-07 07:40:37 --> Language Class Initialized
INFO - 2022-12-07 07:40:37 --> Loader Class Initialized
INFO - 2022-12-07 07:40:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:37 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:37 --> Total execution time: 0.0538
INFO - 2022-12-07 07:40:42 --> Config Class Initialized
INFO - 2022-12-07 07:40:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:42 --> URI Class Initialized
INFO - 2022-12-07 07:40:42 --> Router Class Initialized
INFO - 2022-12-07 07:40:42 --> Output Class Initialized
INFO - 2022-12-07 07:40:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:42 --> Input Class Initialized
INFO - 2022-12-07 07:40:42 --> Language Class Initialized
INFO - 2022-12-07 07:40:42 --> Loader Class Initialized
INFO - 2022-12-07 07:40:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:42 --> Total execution time: 0.1139
INFO - 2022-12-07 07:40:47 --> Config Class Initialized
INFO - 2022-12-07 07:40:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:47 --> URI Class Initialized
INFO - 2022-12-07 07:40:47 --> Router Class Initialized
INFO - 2022-12-07 07:40:47 --> Output Class Initialized
INFO - 2022-12-07 07:40:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:47 --> Input Class Initialized
INFO - 2022-12-07 07:40:47 --> Language Class Initialized
INFO - 2022-12-07 07:40:47 --> Loader Class Initialized
INFO - 2022-12-07 07:40:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:47 --> Total execution time: 0.0226
INFO - 2022-12-07 07:40:47 --> Config Class Initialized
INFO - 2022-12-07 07:40:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:47 --> URI Class Initialized
INFO - 2022-12-07 07:40:47 --> Router Class Initialized
INFO - 2022-12-07 07:40:47 --> Output Class Initialized
INFO - 2022-12-07 07:40:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:47 --> Input Class Initialized
INFO - 2022-12-07 07:40:47 --> Language Class Initialized
INFO - 2022-12-07 07:40:47 --> Loader Class Initialized
INFO - 2022-12-07 07:40:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:47 --> Total execution time: 0.0691
INFO - 2022-12-07 07:40:52 --> Config Class Initialized
INFO - 2022-12-07 07:40:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:52 --> URI Class Initialized
INFO - 2022-12-07 07:40:52 --> Router Class Initialized
INFO - 2022-12-07 07:40:52 --> Output Class Initialized
INFO - 2022-12-07 07:40:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:52 --> Input Class Initialized
INFO - 2022-12-07 07:40:52 --> Language Class Initialized
INFO - 2022-12-07 07:40:52 --> Loader Class Initialized
INFO - 2022-12-07 07:40:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:52 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:52 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:52 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:52 --> Total execution time: 0.0377
INFO - 2022-12-07 07:40:57 --> Config Class Initialized
INFO - 2022-12-07 07:40:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:57 --> URI Class Initialized
INFO - 2022-12-07 07:40:57 --> Router Class Initialized
INFO - 2022-12-07 07:40:57 --> Output Class Initialized
INFO - 2022-12-07 07:40:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:57 --> Input Class Initialized
INFO - 2022-12-07 07:40:57 --> Language Class Initialized
INFO - 2022-12-07 07:40:57 --> Loader Class Initialized
INFO - 2022-12-07 07:40:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:57 --> Total execution time: 0.0221
INFO - 2022-12-07 07:40:57 --> Config Class Initialized
INFO - 2022-12-07 07:40:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:40:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:40:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:40:57 --> URI Class Initialized
INFO - 2022-12-07 07:40:57 --> Router Class Initialized
INFO - 2022-12-07 07:40:57 --> Output Class Initialized
INFO - 2022-12-07 07:40:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:40:57 --> Input Class Initialized
INFO - 2022-12-07 07:40:57 --> Language Class Initialized
INFO - 2022-12-07 07:40:57 --> Loader Class Initialized
INFO - 2022-12-07 07:40:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:40:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:40:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:40:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:40:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:40:57 --> Total execution time: 0.0496
INFO - 2022-12-07 07:41:02 --> Config Class Initialized
INFO - 2022-12-07 07:41:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:02 --> URI Class Initialized
INFO - 2022-12-07 07:41:02 --> Router Class Initialized
INFO - 2022-12-07 07:41:02 --> Output Class Initialized
INFO - 2022-12-07 07:41:02 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:02 --> Input Class Initialized
INFO - 2022-12-07 07:41:02 --> Language Class Initialized
INFO - 2022-12-07 07:41:02 --> Loader Class Initialized
INFO - 2022-12-07 07:41:02 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:02 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:02 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:02 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:02 --> Total execution time: 0.0489
INFO - 2022-12-07 07:41:07 --> Config Class Initialized
INFO - 2022-12-07 07:41:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:07 --> URI Class Initialized
INFO - 2022-12-07 07:41:07 --> Router Class Initialized
INFO - 2022-12-07 07:41:07 --> Output Class Initialized
INFO - 2022-12-07 07:41:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:07 --> Input Class Initialized
INFO - 2022-12-07 07:41:07 --> Language Class Initialized
INFO - 2022-12-07 07:41:07 --> Loader Class Initialized
INFO - 2022-12-07 07:41:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:07 --> Total execution time: 0.0221
INFO - 2022-12-07 07:41:07 --> Config Class Initialized
INFO - 2022-12-07 07:41:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:07 --> URI Class Initialized
INFO - 2022-12-07 07:41:07 --> Router Class Initialized
INFO - 2022-12-07 07:41:07 --> Output Class Initialized
INFO - 2022-12-07 07:41:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:07 --> Input Class Initialized
INFO - 2022-12-07 07:41:07 --> Language Class Initialized
INFO - 2022-12-07 07:41:07 --> Loader Class Initialized
INFO - 2022-12-07 07:41:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:07 --> Total execution time: 0.0360
INFO - 2022-12-07 07:41:12 --> Config Class Initialized
INFO - 2022-12-07 07:41:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:12 --> URI Class Initialized
INFO - 2022-12-07 07:41:12 --> Router Class Initialized
INFO - 2022-12-07 07:41:12 --> Output Class Initialized
INFO - 2022-12-07 07:41:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:12 --> Input Class Initialized
INFO - 2022-12-07 07:41:12 --> Language Class Initialized
INFO - 2022-12-07 07:41:12 --> Loader Class Initialized
INFO - 2022-12-07 07:41:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:12 --> Total execution time: 0.0360
INFO - 2022-12-07 07:41:17 --> Config Class Initialized
INFO - 2022-12-07 07:41:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:17 --> URI Class Initialized
INFO - 2022-12-07 07:41:17 --> Router Class Initialized
INFO - 2022-12-07 07:41:17 --> Output Class Initialized
INFO - 2022-12-07 07:41:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:17 --> Input Class Initialized
INFO - 2022-12-07 07:41:17 --> Language Class Initialized
INFO - 2022-12-07 07:41:17 --> Loader Class Initialized
INFO - 2022-12-07 07:41:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:17 --> Total execution time: 0.0229
INFO - 2022-12-07 07:41:17 --> Config Class Initialized
INFO - 2022-12-07 07:41:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:17 --> URI Class Initialized
INFO - 2022-12-07 07:41:17 --> Router Class Initialized
INFO - 2022-12-07 07:41:17 --> Output Class Initialized
INFO - 2022-12-07 07:41:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:17 --> Input Class Initialized
INFO - 2022-12-07 07:41:17 --> Language Class Initialized
INFO - 2022-12-07 07:41:17 --> Loader Class Initialized
INFO - 2022-12-07 07:41:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:17 --> Total execution time: 0.0349
INFO - 2022-12-07 07:41:22 --> Config Class Initialized
INFO - 2022-12-07 07:41:22 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:22 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:22 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:22 --> URI Class Initialized
INFO - 2022-12-07 07:41:22 --> Router Class Initialized
INFO - 2022-12-07 07:41:22 --> Output Class Initialized
INFO - 2022-12-07 07:41:22 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:22 --> Input Class Initialized
INFO - 2022-12-07 07:41:22 --> Language Class Initialized
INFO - 2022-12-07 07:41:22 --> Loader Class Initialized
INFO - 2022-12-07 07:41:22 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:22 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:22 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:22 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:22 --> Total execution time: 0.0773
INFO - 2022-12-07 07:41:27 --> Config Class Initialized
INFO - 2022-12-07 07:41:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:27 --> URI Class Initialized
INFO - 2022-12-07 07:41:27 --> Router Class Initialized
INFO - 2022-12-07 07:41:27 --> Output Class Initialized
INFO - 2022-12-07 07:41:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:27 --> Input Class Initialized
INFO - 2022-12-07 07:41:27 --> Language Class Initialized
INFO - 2022-12-07 07:41:27 --> Loader Class Initialized
INFO - 2022-12-07 07:41:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:27 --> Total execution time: 0.0221
INFO - 2022-12-07 07:41:27 --> Config Class Initialized
INFO - 2022-12-07 07:41:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:27 --> URI Class Initialized
INFO - 2022-12-07 07:41:27 --> Router Class Initialized
INFO - 2022-12-07 07:41:27 --> Output Class Initialized
INFO - 2022-12-07 07:41:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:27 --> Input Class Initialized
INFO - 2022-12-07 07:41:27 --> Language Class Initialized
INFO - 2022-12-07 07:41:27 --> Loader Class Initialized
INFO - 2022-12-07 07:41:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:27 --> Total execution time: 0.0354
INFO - 2022-12-07 07:41:32 --> Config Class Initialized
INFO - 2022-12-07 07:41:32 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:32 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:32 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:32 --> URI Class Initialized
INFO - 2022-12-07 07:41:32 --> Router Class Initialized
INFO - 2022-12-07 07:41:32 --> Output Class Initialized
INFO - 2022-12-07 07:41:32 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:32 --> Input Class Initialized
INFO - 2022-12-07 07:41:32 --> Language Class Initialized
INFO - 2022-12-07 07:41:32 --> Loader Class Initialized
INFO - 2022-12-07 07:41:32 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:32 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:32 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:32 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:32 --> Total execution time: 0.0593
INFO - 2022-12-07 07:41:37 --> Config Class Initialized
INFO - 2022-12-07 07:41:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:37 --> URI Class Initialized
INFO - 2022-12-07 07:41:37 --> Router Class Initialized
INFO - 2022-12-07 07:41:37 --> Output Class Initialized
INFO - 2022-12-07 07:41:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:37 --> Input Class Initialized
INFO - 2022-12-07 07:41:37 --> Language Class Initialized
INFO - 2022-12-07 07:41:37 --> Loader Class Initialized
INFO - 2022-12-07 07:41:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:37 --> Total execution time: 0.0230
INFO - 2022-12-07 07:41:37 --> Config Class Initialized
INFO - 2022-12-07 07:41:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:37 --> URI Class Initialized
INFO - 2022-12-07 07:41:37 --> Router Class Initialized
INFO - 2022-12-07 07:41:37 --> Output Class Initialized
INFO - 2022-12-07 07:41:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:37 --> Input Class Initialized
INFO - 2022-12-07 07:41:37 --> Language Class Initialized
INFO - 2022-12-07 07:41:37 --> Loader Class Initialized
INFO - 2022-12-07 07:41:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:37 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:37 --> Total execution time: 0.0347
INFO - 2022-12-07 07:41:42 --> Config Class Initialized
INFO - 2022-12-07 07:41:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:42 --> URI Class Initialized
INFO - 2022-12-07 07:41:42 --> Router Class Initialized
INFO - 2022-12-07 07:41:42 --> Output Class Initialized
INFO - 2022-12-07 07:41:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:42 --> Input Class Initialized
INFO - 2022-12-07 07:41:42 --> Language Class Initialized
INFO - 2022-12-07 07:41:42 --> Loader Class Initialized
INFO - 2022-12-07 07:41:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:42 --> Total execution time: 0.0369
INFO - 2022-12-07 07:41:47 --> Config Class Initialized
INFO - 2022-12-07 07:41:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:47 --> URI Class Initialized
INFO - 2022-12-07 07:41:47 --> Router Class Initialized
INFO - 2022-12-07 07:41:47 --> Output Class Initialized
INFO - 2022-12-07 07:41:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:47 --> Input Class Initialized
INFO - 2022-12-07 07:41:47 --> Language Class Initialized
INFO - 2022-12-07 07:41:47 --> Loader Class Initialized
INFO - 2022-12-07 07:41:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:47 --> Total execution time: 0.0200
INFO - 2022-12-07 07:41:47 --> Config Class Initialized
INFO - 2022-12-07 07:41:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:47 --> URI Class Initialized
INFO - 2022-12-07 07:41:47 --> Router Class Initialized
INFO - 2022-12-07 07:41:47 --> Output Class Initialized
INFO - 2022-12-07 07:41:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:47 --> Input Class Initialized
INFO - 2022-12-07 07:41:47 --> Language Class Initialized
INFO - 2022-12-07 07:41:47 --> Loader Class Initialized
INFO - 2022-12-07 07:41:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:47 --> Total execution time: 0.0469
INFO - 2022-12-07 07:41:52 --> Config Class Initialized
INFO - 2022-12-07 07:41:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:52 --> URI Class Initialized
INFO - 2022-12-07 07:41:52 --> Router Class Initialized
INFO - 2022-12-07 07:41:52 --> Output Class Initialized
INFO - 2022-12-07 07:41:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:52 --> Input Class Initialized
INFO - 2022-12-07 07:41:52 --> Language Class Initialized
INFO - 2022-12-07 07:41:52 --> Loader Class Initialized
INFO - 2022-12-07 07:41:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:52 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:52 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:52 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:52 --> Total execution time: 0.0365
INFO - 2022-12-07 07:41:57 --> Config Class Initialized
INFO - 2022-12-07 07:41:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:57 --> URI Class Initialized
INFO - 2022-12-07 07:41:57 --> Router Class Initialized
INFO - 2022-12-07 07:41:57 --> Output Class Initialized
INFO - 2022-12-07 07:41:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:57 --> Input Class Initialized
INFO - 2022-12-07 07:41:57 --> Language Class Initialized
INFO - 2022-12-07 07:41:57 --> Loader Class Initialized
INFO - 2022-12-07 07:41:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:57 --> Total execution time: 0.0216
INFO - 2022-12-07 07:41:57 --> Config Class Initialized
INFO - 2022-12-07 07:41:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:41:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:41:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:41:57 --> URI Class Initialized
INFO - 2022-12-07 07:41:57 --> Router Class Initialized
INFO - 2022-12-07 07:41:57 --> Output Class Initialized
INFO - 2022-12-07 07:41:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:41:57 --> Input Class Initialized
INFO - 2022-12-07 07:41:57 --> Language Class Initialized
INFO - 2022-12-07 07:41:57 --> Loader Class Initialized
INFO - 2022-12-07 07:41:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:41:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:41:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:41:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:41:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:41:57 --> Total execution time: 0.0707
INFO - 2022-12-07 07:42:02 --> Config Class Initialized
INFO - 2022-12-07 07:42:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:02 --> URI Class Initialized
INFO - 2022-12-07 07:42:02 --> Router Class Initialized
INFO - 2022-12-07 07:42:02 --> Output Class Initialized
INFO - 2022-12-07 07:42:02 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:02 --> Input Class Initialized
INFO - 2022-12-07 07:42:02 --> Language Class Initialized
INFO - 2022-12-07 07:42:02 --> Loader Class Initialized
INFO - 2022-12-07 07:42:02 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:02 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:02 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:02 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:02 --> Total execution time: 0.0528
INFO - 2022-12-07 07:42:07 --> Config Class Initialized
INFO - 2022-12-07 07:42:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:07 --> URI Class Initialized
INFO - 2022-12-07 07:42:07 --> Router Class Initialized
INFO - 2022-12-07 07:42:07 --> Output Class Initialized
INFO - 2022-12-07 07:42:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:07 --> Input Class Initialized
INFO - 2022-12-07 07:42:07 --> Language Class Initialized
INFO - 2022-12-07 07:42:07 --> Loader Class Initialized
INFO - 2022-12-07 07:42:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:07 --> Total execution time: 0.0222
INFO - 2022-12-07 07:42:07 --> Config Class Initialized
INFO - 2022-12-07 07:42:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:07 --> URI Class Initialized
INFO - 2022-12-07 07:42:07 --> Router Class Initialized
INFO - 2022-12-07 07:42:07 --> Output Class Initialized
INFO - 2022-12-07 07:42:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:07 --> Input Class Initialized
INFO - 2022-12-07 07:42:07 --> Language Class Initialized
INFO - 2022-12-07 07:42:07 --> Loader Class Initialized
INFO - 2022-12-07 07:42:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:07 --> Total execution time: 0.0516
INFO - 2022-12-07 07:42:12 --> Config Class Initialized
INFO - 2022-12-07 07:42:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:12 --> URI Class Initialized
INFO - 2022-12-07 07:42:12 --> Router Class Initialized
INFO - 2022-12-07 07:42:12 --> Output Class Initialized
INFO - 2022-12-07 07:42:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:12 --> Input Class Initialized
INFO - 2022-12-07 07:42:12 --> Language Class Initialized
INFO - 2022-12-07 07:42:12 --> Loader Class Initialized
INFO - 2022-12-07 07:42:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:12 --> Total execution time: 0.0603
INFO - 2022-12-07 07:42:17 --> Config Class Initialized
INFO - 2022-12-07 07:42:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:17 --> URI Class Initialized
INFO - 2022-12-07 07:42:17 --> Router Class Initialized
INFO - 2022-12-07 07:42:17 --> Output Class Initialized
INFO - 2022-12-07 07:42:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:17 --> Input Class Initialized
INFO - 2022-12-07 07:42:17 --> Language Class Initialized
INFO - 2022-12-07 07:42:17 --> Loader Class Initialized
INFO - 2022-12-07 07:42:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:17 --> Total execution time: 0.0211
INFO - 2022-12-07 07:42:17 --> Config Class Initialized
INFO - 2022-12-07 07:42:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:17 --> URI Class Initialized
INFO - 2022-12-07 07:42:17 --> Router Class Initialized
INFO - 2022-12-07 07:42:17 --> Output Class Initialized
INFO - 2022-12-07 07:42:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:17 --> Input Class Initialized
INFO - 2022-12-07 07:42:17 --> Language Class Initialized
INFO - 2022-12-07 07:42:17 --> Loader Class Initialized
INFO - 2022-12-07 07:42:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:17 --> Total execution time: 0.0362
INFO - 2022-12-07 07:42:22 --> Config Class Initialized
INFO - 2022-12-07 07:42:22 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:22 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:22 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:22 --> URI Class Initialized
INFO - 2022-12-07 07:42:22 --> Router Class Initialized
INFO - 2022-12-07 07:42:22 --> Output Class Initialized
INFO - 2022-12-07 07:42:22 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:22 --> Input Class Initialized
INFO - 2022-12-07 07:42:22 --> Language Class Initialized
INFO - 2022-12-07 07:42:22 --> Loader Class Initialized
INFO - 2022-12-07 07:42:22 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:22 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:22 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:22 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:22 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:22 --> Total execution time: 0.0634
INFO - 2022-12-07 07:42:27 --> Config Class Initialized
INFO - 2022-12-07 07:42:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:27 --> URI Class Initialized
INFO - 2022-12-07 07:42:27 --> Router Class Initialized
INFO - 2022-12-07 07:42:27 --> Output Class Initialized
INFO - 2022-12-07 07:42:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:27 --> Input Class Initialized
INFO - 2022-12-07 07:42:27 --> Language Class Initialized
INFO - 2022-12-07 07:42:27 --> Loader Class Initialized
INFO - 2022-12-07 07:42:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:27 --> Total execution time: 0.0210
INFO - 2022-12-07 07:42:27 --> Config Class Initialized
INFO - 2022-12-07 07:42:27 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:27 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:27 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:27 --> URI Class Initialized
INFO - 2022-12-07 07:42:27 --> Router Class Initialized
INFO - 2022-12-07 07:42:27 --> Output Class Initialized
INFO - 2022-12-07 07:42:27 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:27 --> Input Class Initialized
INFO - 2022-12-07 07:42:27 --> Language Class Initialized
INFO - 2022-12-07 07:42:27 --> Loader Class Initialized
INFO - 2022-12-07 07:42:27 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:27 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:27 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:27 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:27 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:27 --> Total execution time: 0.0865
INFO - 2022-12-07 07:42:32 --> Config Class Initialized
INFO - 2022-12-07 07:42:32 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:32 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:32 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:32 --> URI Class Initialized
INFO - 2022-12-07 07:42:32 --> Router Class Initialized
INFO - 2022-12-07 07:42:32 --> Output Class Initialized
INFO - 2022-12-07 07:42:32 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:32 --> Input Class Initialized
INFO - 2022-12-07 07:42:32 --> Language Class Initialized
INFO - 2022-12-07 07:42:32 --> Loader Class Initialized
INFO - 2022-12-07 07:42:32 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:32 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:32 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:32 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:32 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:32 --> Total execution time: 0.0611
INFO - 2022-12-07 07:42:37 --> Config Class Initialized
INFO - 2022-12-07 07:42:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:37 --> URI Class Initialized
INFO - 2022-12-07 07:42:37 --> Router Class Initialized
INFO - 2022-12-07 07:42:37 --> Output Class Initialized
INFO - 2022-12-07 07:42:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:37 --> Input Class Initialized
INFO - 2022-12-07 07:42:37 --> Language Class Initialized
INFO - 2022-12-07 07:42:37 --> Loader Class Initialized
INFO - 2022-12-07 07:42:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:37 --> Total execution time: 0.0210
INFO - 2022-12-07 07:42:37 --> Config Class Initialized
INFO - 2022-12-07 07:42:37 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:37 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:37 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:37 --> URI Class Initialized
INFO - 2022-12-07 07:42:37 --> Router Class Initialized
INFO - 2022-12-07 07:42:37 --> Output Class Initialized
INFO - 2022-12-07 07:42:37 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:37 --> Input Class Initialized
INFO - 2022-12-07 07:42:37 --> Language Class Initialized
INFO - 2022-12-07 07:42:37 --> Loader Class Initialized
INFO - 2022-12-07 07:42:37 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:37 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:37 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:37 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:37 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:37 --> Total execution time: 0.0345
INFO - 2022-12-07 07:42:42 --> Config Class Initialized
INFO - 2022-12-07 07:42:42 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:42 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:42 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:42 --> URI Class Initialized
INFO - 2022-12-07 07:42:42 --> Router Class Initialized
INFO - 2022-12-07 07:42:42 --> Output Class Initialized
INFO - 2022-12-07 07:42:42 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:42 --> Input Class Initialized
INFO - 2022-12-07 07:42:42 --> Language Class Initialized
INFO - 2022-12-07 07:42:42 --> Loader Class Initialized
INFO - 2022-12-07 07:42:42 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:42 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:42 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:42 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:42 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:42 --> Total execution time: 0.0544
INFO - 2022-12-07 07:42:47 --> Config Class Initialized
INFO - 2022-12-07 07:42:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:47 --> URI Class Initialized
INFO - 2022-12-07 07:42:47 --> Router Class Initialized
INFO - 2022-12-07 07:42:47 --> Output Class Initialized
INFO - 2022-12-07 07:42:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:47 --> Input Class Initialized
INFO - 2022-12-07 07:42:47 --> Language Class Initialized
INFO - 2022-12-07 07:42:47 --> Loader Class Initialized
INFO - 2022-12-07 07:42:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:47 --> Total execution time: 0.0220
INFO - 2022-12-07 07:42:47 --> Config Class Initialized
INFO - 2022-12-07 07:42:47 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:47 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:47 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:47 --> URI Class Initialized
INFO - 2022-12-07 07:42:47 --> Router Class Initialized
INFO - 2022-12-07 07:42:47 --> Output Class Initialized
INFO - 2022-12-07 07:42:47 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:47 --> Input Class Initialized
INFO - 2022-12-07 07:42:47 --> Language Class Initialized
INFO - 2022-12-07 07:42:47 --> Loader Class Initialized
INFO - 2022-12-07 07:42:47 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:47 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:47 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:47 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:47 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:47 --> Total execution time: 0.0473
INFO - 2022-12-07 07:42:52 --> Config Class Initialized
INFO - 2022-12-07 07:42:52 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:52 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:52 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:52 --> URI Class Initialized
INFO - 2022-12-07 07:42:52 --> Router Class Initialized
INFO - 2022-12-07 07:42:52 --> Output Class Initialized
INFO - 2022-12-07 07:42:52 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:52 --> Input Class Initialized
INFO - 2022-12-07 07:42:52 --> Language Class Initialized
INFO - 2022-12-07 07:42:52 --> Loader Class Initialized
INFO - 2022-12-07 07:42:52 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:52 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:52 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:52 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:52 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:52 --> Total execution time: 0.0596
INFO - 2022-12-07 07:42:57 --> Config Class Initialized
INFO - 2022-12-07 07:42:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:57 --> URI Class Initialized
INFO - 2022-12-07 07:42:57 --> Router Class Initialized
INFO - 2022-12-07 07:42:57 --> Output Class Initialized
INFO - 2022-12-07 07:42:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:57 --> Input Class Initialized
INFO - 2022-12-07 07:42:57 --> Language Class Initialized
INFO - 2022-12-07 07:42:57 --> Loader Class Initialized
INFO - 2022-12-07 07:42:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:57 --> Total execution time: 0.0228
INFO - 2022-12-07 07:42:57 --> Config Class Initialized
INFO - 2022-12-07 07:42:57 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:42:57 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:42:57 --> Utf8 Class Initialized
INFO - 2022-12-07 07:42:57 --> URI Class Initialized
INFO - 2022-12-07 07:42:57 --> Router Class Initialized
INFO - 2022-12-07 07:42:57 --> Output Class Initialized
INFO - 2022-12-07 07:42:57 --> Security Class Initialized
DEBUG - 2022-12-07 07:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:42:57 --> Input Class Initialized
INFO - 2022-12-07 07:42:57 --> Language Class Initialized
INFO - 2022-12-07 07:42:57 --> Loader Class Initialized
INFO - 2022-12-07 07:42:57 --> Controller Class Initialized
DEBUG - 2022-12-07 07:42:57 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:42:57 --> Database Driver Class Initialized
INFO - 2022-12-07 07:42:57 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:42:57 --> Final output sent to browser
DEBUG - 2022-12-07 07:42:57 --> Total execution time: 0.0611
INFO - 2022-12-07 07:43:02 --> Config Class Initialized
INFO - 2022-12-07 07:43:02 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:43:02 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:43:02 --> Utf8 Class Initialized
INFO - 2022-12-07 07:43:02 --> URI Class Initialized
INFO - 2022-12-07 07:43:02 --> Router Class Initialized
INFO - 2022-12-07 07:43:02 --> Output Class Initialized
INFO - 2022-12-07 07:43:02 --> Security Class Initialized
DEBUG - 2022-12-07 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:43:02 --> Input Class Initialized
INFO - 2022-12-07 07:43:02 --> Language Class Initialized
INFO - 2022-12-07 07:43:02 --> Loader Class Initialized
INFO - 2022-12-07 07:43:02 --> Controller Class Initialized
DEBUG - 2022-12-07 07:43:02 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:43:02 --> Database Driver Class Initialized
INFO - 2022-12-07 07:43:02 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:43:02 --> Final output sent to browser
DEBUG - 2022-12-07 07:43:02 --> Total execution time: 0.0626
INFO - 2022-12-07 07:43:07 --> Config Class Initialized
INFO - 2022-12-07 07:43:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:43:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:43:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:43:07 --> URI Class Initialized
INFO - 2022-12-07 07:43:07 --> Router Class Initialized
INFO - 2022-12-07 07:43:07 --> Output Class Initialized
INFO - 2022-12-07 07:43:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:43:07 --> Input Class Initialized
INFO - 2022-12-07 07:43:07 --> Language Class Initialized
INFO - 2022-12-07 07:43:07 --> Loader Class Initialized
INFO - 2022-12-07 07:43:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:43:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:43:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:43:07 --> Total execution time: 0.0237
INFO - 2022-12-07 07:43:07 --> Config Class Initialized
INFO - 2022-12-07 07:43:07 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:43:07 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:43:07 --> Utf8 Class Initialized
INFO - 2022-12-07 07:43:07 --> URI Class Initialized
INFO - 2022-12-07 07:43:07 --> Router Class Initialized
INFO - 2022-12-07 07:43:07 --> Output Class Initialized
INFO - 2022-12-07 07:43:07 --> Security Class Initialized
DEBUG - 2022-12-07 07:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:43:07 --> Input Class Initialized
INFO - 2022-12-07 07:43:07 --> Language Class Initialized
INFO - 2022-12-07 07:43:07 --> Loader Class Initialized
INFO - 2022-12-07 07:43:07 --> Controller Class Initialized
DEBUG - 2022-12-07 07:43:07 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:43:07 --> Database Driver Class Initialized
INFO - 2022-12-07 07:43:07 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:43:07 --> Final output sent to browser
DEBUG - 2022-12-07 07:43:07 --> Total execution time: 0.0798
INFO - 2022-12-07 07:43:12 --> Config Class Initialized
INFO - 2022-12-07 07:43:12 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:43:12 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:43:12 --> Utf8 Class Initialized
INFO - 2022-12-07 07:43:12 --> URI Class Initialized
INFO - 2022-12-07 07:43:12 --> Router Class Initialized
INFO - 2022-12-07 07:43:12 --> Output Class Initialized
INFO - 2022-12-07 07:43:12 --> Security Class Initialized
DEBUG - 2022-12-07 07:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:43:12 --> Input Class Initialized
INFO - 2022-12-07 07:43:12 --> Language Class Initialized
INFO - 2022-12-07 07:43:12 --> Loader Class Initialized
INFO - 2022-12-07 07:43:12 --> Controller Class Initialized
DEBUG - 2022-12-07 07:43:12 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:43:12 --> Database Driver Class Initialized
INFO - 2022-12-07 07:43:12 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:43:12 --> Final output sent to browser
DEBUG - 2022-12-07 07:43:12 --> Total execution time: 0.0696
INFO - 2022-12-07 07:43:17 --> Config Class Initialized
INFO - 2022-12-07 07:43:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:43:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:43:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:43:17 --> URI Class Initialized
INFO - 2022-12-07 07:43:17 --> Router Class Initialized
INFO - 2022-12-07 07:43:17 --> Output Class Initialized
INFO - 2022-12-07 07:43:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:43:17 --> Input Class Initialized
INFO - 2022-12-07 07:43:17 --> Language Class Initialized
INFO - 2022-12-07 07:43:17 --> Loader Class Initialized
INFO - 2022-12-07 07:43:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:43:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:43:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:43:17 --> Total execution time: 0.0227
INFO - 2022-12-07 07:43:17 --> Config Class Initialized
INFO - 2022-12-07 07:43:17 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:43:17 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:43:17 --> Utf8 Class Initialized
INFO - 2022-12-07 07:43:17 --> URI Class Initialized
INFO - 2022-12-07 07:43:17 --> Router Class Initialized
INFO - 2022-12-07 07:43:17 --> Output Class Initialized
INFO - 2022-12-07 07:43:17 --> Security Class Initialized
DEBUG - 2022-12-07 07:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:43:17 --> Input Class Initialized
INFO - 2022-12-07 07:43:17 --> Language Class Initialized
INFO - 2022-12-07 07:43:17 --> Loader Class Initialized
INFO - 2022-12-07 07:43:17 --> Controller Class Initialized
DEBUG - 2022-12-07 07:43:17 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:43:17 --> Database Driver Class Initialized
INFO - 2022-12-07 07:43:17 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:43:17 --> Final output sent to browser
DEBUG - 2022-12-07 07:43:17 --> Total execution time: 0.0550
INFO - 2022-12-07 07:43:20 --> Config Class Initialized
INFO - 2022-12-07 07:43:20 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:43:20 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:43:20 --> Utf8 Class Initialized
INFO - 2022-12-07 07:43:20 --> URI Class Initialized
INFO - 2022-12-07 07:43:20 --> Router Class Initialized
INFO - 2022-12-07 07:43:20 --> Output Class Initialized
INFO - 2022-12-07 07:43:20 --> Security Class Initialized
DEBUG - 2022-12-07 07:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:43:20 --> Input Class Initialized
INFO - 2022-12-07 07:43:20 --> Language Class Initialized
INFO - 2022-12-07 07:43:20 --> Loader Class Initialized
INFO - 2022-12-07 07:43:20 --> Controller Class Initialized
DEBUG - 2022-12-07 07:43:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:43:20 --> Database Driver Class Initialized
INFO - 2022-12-07 07:43:20 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:43:20 --> Database Driver Class Initialized
INFO - 2022-12-07 07:43:20 --> Model "Login_model" initialized
INFO - 2022-12-07 07:43:20 --> Final output sent to browser
DEBUG - 2022-12-07 07:43:20 --> Total execution time: 0.2860
INFO - 2022-12-07 07:43:20 --> Config Class Initialized
INFO - 2022-12-07 07:43:20 --> Hooks Class Initialized
DEBUG - 2022-12-07 07:43:20 --> UTF-8 Support Enabled
INFO - 2022-12-07 07:43:20 --> Utf8 Class Initialized
INFO - 2022-12-07 07:43:20 --> URI Class Initialized
INFO - 2022-12-07 07:43:20 --> Router Class Initialized
INFO - 2022-12-07 07:43:20 --> Output Class Initialized
INFO - 2022-12-07 07:43:20 --> Security Class Initialized
DEBUG - 2022-12-07 07:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-07 07:43:20 --> Input Class Initialized
INFO - 2022-12-07 07:43:20 --> Language Class Initialized
INFO - 2022-12-07 07:43:20 --> Loader Class Initialized
INFO - 2022-12-07 07:43:20 --> Controller Class Initialized
DEBUG - 2022-12-07 07:43:20 --> Config file loaded: C:\Users\abduinzhu\Documents\github\kunlun\KunlunMonitor\application\config/myconfig.php
INFO - 2022-12-07 07:43:20 --> Database Driver Class Initialized
INFO - 2022-12-07 07:43:20 --> Model "Cluster_model" initialized
INFO - 2022-12-07 07:43:20 --> Database Driver Class Initialized
INFO - 2022-12-07 07:43:20 --> Model "Login_model" initialized
INFO - 2022-12-07 07:43:20 --> Final output sent to browser
DEBUG - 2022-12-07 07:43:20 --> Total execution time: 0.2563
