<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-27 05:45:11 --> Config Class Initialized
INFO - 2023-04-27 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:11 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:11 --> URI Class Initialized
INFO - 2023-04-27 05:45:11 --> Router Class Initialized
INFO - 2023-04-27 05:45:11 --> Output Class Initialized
INFO - 2023-04-27 05:45:11 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:11 --> Input Class Initialized
INFO - 2023-04-27 05:45:11 --> Language Class Initialized
INFO - 2023-04-27 05:45:11 --> Loader Class Initialized
INFO - 2023-04-27 05:45:11 --> Controller Class Initialized
INFO - 2023-04-27 05:45:11 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:11 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:11 --> Model "Change_model" initialized
INFO - 2023-04-27 05:45:11 --> Model "Grafana_model" initialized
INFO - 2023-04-27 05:45:11 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:11 --> Total execution time: 0.0862
INFO - 2023-04-27 05:45:11 --> Config Class Initialized
INFO - 2023-04-27 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:11 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:11 --> URI Class Initialized
INFO - 2023-04-27 05:45:11 --> Router Class Initialized
INFO - 2023-04-27 05:45:11 --> Output Class Initialized
INFO - 2023-04-27 05:45:11 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:11 --> Input Class Initialized
INFO - 2023-04-27 05:45:11 --> Language Class Initialized
INFO - 2023-04-27 05:45:11 --> Loader Class Initialized
INFO - 2023-04-27 05:45:11 --> Controller Class Initialized
INFO - 2023-04-27 05:45:11 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:11 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:11 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:11 --> Total execution time: 0.0034
INFO - 2023-04-27 05:45:11 --> Config Class Initialized
INFO - 2023-04-27 05:45:11 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:11 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:11 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:11 --> URI Class Initialized
INFO - 2023-04-27 05:45:11 --> Router Class Initialized
INFO - 2023-04-27 05:45:11 --> Output Class Initialized
INFO - 2023-04-27 05:45:11 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:11 --> Input Class Initialized
INFO - 2023-04-27 05:45:11 --> Language Class Initialized
INFO - 2023-04-27 05:45:11 --> Loader Class Initialized
INFO - 2023-04-27 05:45:11 --> Controller Class Initialized
INFO - 2023-04-27 05:45:11 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:11 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:11 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:11 --> Model "Login_model" initialized
INFO - 2023-04-27 05:45:11 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:11 --> Total execution time: 0.0639
INFO - 2023-04-27 05:45:16 --> Config Class Initialized
INFO - 2023-04-27 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:16 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:16 --> URI Class Initialized
INFO - 2023-04-27 05:45:16 --> Router Class Initialized
INFO - 2023-04-27 05:45:16 --> Output Class Initialized
INFO - 2023-04-27 05:45:16 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:16 --> Input Class Initialized
INFO - 2023-04-27 05:45:16 --> Language Class Initialized
INFO - 2023-04-27 05:45:16 --> Loader Class Initialized
INFO - 2023-04-27 05:45:16 --> Controller Class Initialized
INFO - 2023-04-27 05:45:16 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:16 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:16 --> Model "Change_model" initialized
INFO - 2023-04-27 05:45:16 --> Model "Grafana_model" initialized
INFO - 2023-04-27 05:45:16 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:16 --> Total execution time: 0.0377
INFO - 2023-04-27 05:45:16 --> Config Class Initialized
INFO - 2023-04-27 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:16 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:16 --> URI Class Initialized
INFO - 2023-04-27 05:45:16 --> Router Class Initialized
INFO - 2023-04-27 05:45:16 --> Output Class Initialized
INFO - 2023-04-27 05:45:16 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:16 --> Input Class Initialized
INFO - 2023-04-27 05:45:16 --> Language Class Initialized
INFO - 2023-04-27 05:45:16 --> Loader Class Initialized
INFO - 2023-04-27 05:45:16 --> Controller Class Initialized
INFO - 2023-04-27 05:45:16 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:16 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:16 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:16 --> Total execution time: 0.0020
INFO - 2023-04-27 05:45:16 --> Config Class Initialized
INFO - 2023-04-27 05:45:16 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:16 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:16 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:16 --> URI Class Initialized
INFO - 2023-04-27 05:45:16 --> Router Class Initialized
INFO - 2023-04-27 05:45:16 --> Output Class Initialized
INFO - 2023-04-27 05:45:16 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:16 --> Input Class Initialized
INFO - 2023-04-27 05:45:16 --> Language Class Initialized
INFO - 2023-04-27 05:45:16 --> Loader Class Initialized
INFO - 2023-04-27 05:45:16 --> Controller Class Initialized
INFO - 2023-04-27 05:45:16 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:16 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:16 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:16 --> Model "Login_model" initialized
INFO - 2023-04-27 05:45:16 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:16 --> Total execution time: 0.0146
INFO - 2023-04-27 05:45:26 --> Config Class Initialized
INFO - 2023-04-27 05:45:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:26 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:26 --> URI Class Initialized
INFO - 2023-04-27 05:45:26 --> Router Class Initialized
INFO - 2023-04-27 05:45:26 --> Output Class Initialized
INFO - 2023-04-27 05:45:26 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:26 --> Input Class Initialized
INFO - 2023-04-27 05:45:26 --> Language Class Initialized
INFO - 2023-04-27 05:45:26 --> Loader Class Initialized
INFO - 2023-04-27 05:45:26 --> Controller Class Initialized
INFO - 2023-04-27 05:45:26 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:26 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:26 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:26 --> Total execution time: 0.0041
INFO - 2023-04-27 05:45:26 --> Config Class Initialized
INFO - 2023-04-27 05:45:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:26 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:26 --> URI Class Initialized
INFO - 2023-04-27 05:45:26 --> Router Class Initialized
INFO - 2023-04-27 05:45:26 --> Output Class Initialized
INFO - 2023-04-27 05:45:26 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:26 --> Input Class Initialized
INFO - 2023-04-27 05:45:26 --> Language Class Initialized
INFO - 2023-04-27 05:45:26 --> Loader Class Initialized
INFO - 2023-04-27 05:45:26 --> Controller Class Initialized
INFO - 2023-04-27 05:45:26 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:26 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:26 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:26 --> Model "Login_model" initialized
INFO - 2023-04-27 05:45:26 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:26 --> Total execution time: 0.0242
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
INFO - 2023-04-27 05:45:31 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:31 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Model "Change_model" initialized
INFO - 2023-04-27 05:45:31 --> Model "Grafana_model" initialized
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0335
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
INFO - 2023-04-27 05:45:31 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:31 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0023
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
INFO - 2023-04-27 05:45:31 --> Helper loaded: form_helper
INFO - 2023-04-27 05:45:31 --> Helper loaded: url_helper
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:31 --> Model "Login_model" initialized
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0213
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:31 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0346
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:31 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0146
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:31 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:31 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0164
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0179
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Config Class Initialized
INFO - 2023-04-27 05:45:31 --> Hooks Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
DEBUG - 2023-04-27 05:45:31 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
INFO - 2023-04-27 05:45:31 --> Utf8 Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:31 --> URI Class Initialized
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Router Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
INFO - 2023-04-27 05:45:31 --> Output Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Security Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Input Class Initialized
INFO - 2023-04-27 05:45:31 --> Language Class Initialized
INFO - 2023-04-27 05:45:31 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:31 --> Loader Class Initialized
INFO - 2023-04-27 05:45:31 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:31 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:31 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:31 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0910
INFO - 2023-04-27 05:45:31 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:31 --> Total execution time: 0.0512
INFO - 2023-04-27 05:45:33 --> Config Class Initialized
INFO - 2023-04-27 05:45:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:33 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:33 --> URI Class Initialized
INFO - 2023-04-27 05:45:33 --> Router Class Initialized
INFO - 2023-04-27 05:45:33 --> Output Class Initialized
INFO - 2023-04-27 05:45:33 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:33 --> Input Class Initialized
INFO - 2023-04-27 05:45:33 --> Language Class Initialized
INFO - 2023-04-27 05:45:33 --> Loader Class Initialized
INFO - 2023-04-27 05:45:33 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:33 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:33 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:33 --> Total execution time: 0.0097
INFO - 2023-04-27 05:45:33 --> Config Class Initialized
INFO - 2023-04-27 05:45:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:33 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:33 --> URI Class Initialized
INFO - 2023-04-27 05:45:33 --> Router Class Initialized
INFO - 2023-04-27 05:45:33 --> Output Class Initialized
INFO - 2023-04-27 05:45:33 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:33 --> Input Class Initialized
INFO - 2023-04-27 05:45:33 --> Language Class Initialized
INFO - 2023-04-27 05:45:33 --> Loader Class Initialized
INFO - 2023-04-27 05:45:33 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:33 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:33 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:33 --> Total execution time: 0.0555
INFO - 2023-04-27 05:45:33 --> Config Class Initialized
INFO - 2023-04-27 05:45:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:33 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:33 --> URI Class Initialized
INFO - 2023-04-27 05:45:33 --> Router Class Initialized
INFO - 2023-04-27 05:45:33 --> Output Class Initialized
INFO - 2023-04-27 05:45:33 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:33 --> Input Class Initialized
INFO - 2023-04-27 05:45:33 --> Language Class Initialized
INFO - 2023-04-27 05:45:33 --> Loader Class Initialized
INFO - 2023-04-27 05:45:33 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:33 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:33 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:33 --> Total execution time: 0.0548
INFO - 2023-04-27 05:45:33 --> Config Class Initialized
INFO - 2023-04-27 05:45:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:33 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:33 --> URI Class Initialized
INFO - 2023-04-27 05:45:33 --> Router Class Initialized
INFO - 2023-04-27 05:45:33 --> Output Class Initialized
INFO - 2023-04-27 05:45:33 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:33 --> Input Class Initialized
INFO - 2023-04-27 05:45:33 --> Language Class Initialized
INFO - 2023-04-27 05:45:33 --> Loader Class Initialized
INFO - 2023-04-27 05:45:33 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:33 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:33 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:33 --> Total execution time: 0.0548
INFO - 2023-04-27 05:45:57 --> Config Class Initialized
INFO - 2023-04-27 05:45:57 --> Config Class Initialized
INFO - 2023-04-27 05:45:57 --> Hooks Class Initialized
INFO - 2023-04-27 05:45:57 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:57 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 05:45:57 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:57 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:57 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:57 --> URI Class Initialized
INFO - 2023-04-27 05:45:57 --> URI Class Initialized
INFO - 2023-04-27 05:45:57 --> Router Class Initialized
INFO - 2023-04-27 05:45:57 --> Router Class Initialized
INFO - 2023-04-27 05:45:57 --> Output Class Initialized
INFO - 2023-04-27 05:45:57 --> Output Class Initialized
INFO - 2023-04-27 05:45:57 --> Security Class Initialized
INFO - 2023-04-27 05:45:57 --> Security Class Initialized
DEBUG - 2023-04-27 05:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:57 --> Input Class Initialized
DEBUG - 2023-04-27 05:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:57 --> Language Class Initialized
INFO - 2023-04-27 05:45:57 --> Input Class Initialized
INFO - 2023-04-27 05:45:57 --> Language Class Initialized
INFO - 2023-04-27 05:45:57 --> Loader Class Initialized
INFO - 2023-04-27 05:45:57 --> Loader Class Initialized
INFO - 2023-04-27 05:45:57 --> Controller Class Initialized
INFO - 2023-04-27 05:45:57 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 05:45:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:57 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:57 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:57 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:57 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:57 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:57 --> Total execution time: 0.0197
INFO - 2023-04-27 05:45:57 --> Final output sent to browser
INFO - 2023-04-27 05:45:57 --> Config Class Initialized
INFO - 2023-04-27 05:45:58 --> Hooks Class Initialized
DEBUG - 2023-04-27 05:45:58 --> Total execution time: 0.0382
DEBUG - 2023-04-27 05:45:58 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:58 --> Config Class Initialized
INFO - 2023-04-27 05:45:58 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:58 --> Hooks Class Initialized
INFO - 2023-04-27 05:45:58 --> URI Class Initialized
DEBUG - 2023-04-27 05:45:58 --> UTF-8 Support Enabled
INFO - 2023-04-27 05:45:58 --> Router Class Initialized
INFO - 2023-04-27 05:45:58 --> Utf8 Class Initialized
INFO - 2023-04-27 05:45:58 --> Output Class Initialized
INFO - 2023-04-27 05:45:58 --> Security Class Initialized
INFO - 2023-04-27 05:45:58 --> URI Class Initialized
DEBUG - 2023-04-27 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:58 --> Router Class Initialized
INFO - 2023-04-27 05:45:58 --> Input Class Initialized
INFO - 2023-04-27 05:45:58 --> Language Class Initialized
INFO - 2023-04-27 05:45:58 --> Output Class Initialized
INFO - 2023-04-27 05:45:58 --> Security Class Initialized
INFO - 2023-04-27 05:45:58 --> Loader Class Initialized
DEBUG - 2023-04-27 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 05:45:58 --> Controller Class Initialized
INFO - 2023-04-27 05:45:58 --> Input Class Initialized
DEBUG - 2023-04-27 05:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:58 --> Language Class Initialized
INFO - 2023-04-27 05:45:58 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:58 --> Loader Class Initialized
INFO - 2023-04-27 05:45:58 --> Controller Class Initialized
DEBUG - 2023-04-27 05:45:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 05:45:58 --> Database Driver Class Initialized
INFO - 2023-04-27 05:45:58 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:58 --> Model "Cluster_model" initialized
INFO - 2023-04-27 05:45:58 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:58 --> Total execution time: 0.5010
INFO - 2023-04-27 05:45:58 --> Final output sent to browser
DEBUG - 2023-04-27 05:45:58 --> Total execution time: 0.3323
INFO - 2023-04-27 06:08:12 --> Config Class Initialized
INFO - 2023-04-27 06:08:12 --> Hooks Class Initialized
INFO - 2023-04-27 06:08:12 --> Config Class Initialized
DEBUG - 2023-04-27 06:08:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:08:12 --> Hooks Class Initialized
INFO - 2023-04-27 06:08:12 --> Utf8 Class Initialized
INFO - 2023-04-27 06:08:12 --> URI Class Initialized
DEBUG - 2023-04-27 06:08:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:08:12 --> Utf8 Class Initialized
INFO - 2023-04-27 06:08:12 --> Router Class Initialized
INFO - 2023-04-27 06:08:12 --> URI Class Initialized
INFO - 2023-04-27 06:08:12 --> Router Class Initialized
INFO - 2023-04-27 06:08:12 --> Output Class Initialized
INFO - 2023-04-27 06:08:12 --> Output Class Initialized
INFO - 2023-04-27 06:08:12 --> Security Class Initialized
INFO - 2023-04-27 06:08:12 --> Security Class Initialized
DEBUG - 2023-04-27 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:08:12 --> Input Class Initialized
DEBUG - 2023-04-27 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:08:12 --> Language Class Initialized
INFO - 2023-04-27 06:08:12 --> Input Class Initialized
INFO - 2023-04-27 06:08:12 --> Language Class Initialized
INFO - 2023-04-27 06:08:12 --> Loader Class Initialized
INFO - 2023-04-27 06:08:12 --> Loader Class Initialized
INFO - 2023-04-27 06:08:12 --> Controller Class Initialized
INFO - 2023-04-27 06:08:12 --> Controller Class Initialized
DEBUG - 2023-04-27 06:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:08:12 --> Database Driver Class Initialized
INFO - 2023-04-27 06:08:12 --> Database Driver Class Initialized
INFO - 2023-04-27 06:08:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:08:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:08:12 --> Final output sent to browser
DEBUG - 2023-04-27 06:08:12 --> Total execution time: 0.0671
INFO - 2023-04-27 06:08:12 --> Final output sent to browser
DEBUG - 2023-04-27 06:08:12 --> Total execution time: 0.0281
INFO - 2023-04-27 06:08:12 --> Config Class Initialized
INFO - 2023-04-27 06:08:12 --> Config Class Initialized
INFO - 2023-04-27 06:08:12 --> Hooks Class Initialized
INFO - 2023-04-27 06:08:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:08:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:08:12 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:08:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:08:12 --> URI Class Initialized
INFO - 2023-04-27 06:08:12 --> Utf8 Class Initialized
INFO - 2023-04-27 06:08:12 --> Router Class Initialized
INFO - 2023-04-27 06:08:12 --> URI Class Initialized
INFO - 2023-04-27 06:08:12 --> Output Class Initialized
INFO - 2023-04-27 06:08:12 --> Router Class Initialized
INFO - 2023-04-27 06:08:12 --> Security Class Initialized
INFO - 2023-04-27 06:08:12 --> Output Class Initialized
DEBUG - 2023-04-27 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:08:12 --> Security Class Initialized
INFO - 2023-04-27 06:08:12 --> Input Class Initialized
DEBUG - 2023-04-27 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:08:12 --> Language Class Initialized
INFO - 2023-04-27 06:08:12 --> Input Class Initialized
INFO - 2023-04-27 06:08:12 --> Loader Class Initialized
INFO - 2023-04-27 06:08:12 --> Language Class Initialized
INFO - 2023-04-27 06:08:12 --> Controller Class Initialized
DEBUG - 2023-04-27 06:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:08:12 --> Loader Class Initialized
INFO - 2023-04-27 06:08:12 --> Controller Class Initialized
INFO - 2023-04-27 06:08:12 --> Database Driver Class Initialized
DEBUG - 2023-04-27 06:08:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:08:12 --> Database Driver Class Initialized
INFO - 2023-04-27 06:08:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:08:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:08:12 --> Final output sent to browser
DEBUG - 2023-04-27 06:08:12 --> Total execution time: 0.1824
INFO - 2023-04-27 06:08:12 --> Final output sent to browser
DEBUG - 2023-04-27 06:08:12 --> Total execution time: 0.1853
INFO - 2023-04-27 06:09:00 --> Config Class Initialized
INFO - 2023-04-27 06:09:00 --> Config Class Initialized
INFO - 2023-04-27 06:09:00 --> Hooks Class Initialized
INFO - 2023-04-27 06:09:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:09:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:09:00 --> Utf8 Class Initialized
INFO - 2023-04-27 06:09:00 --> Utf8 Class Initialized
INFO - 2023-04-27 06:09:00 --> URI Class Initialized
INFO - 2023-04-27 06:09:00 --> URI Class Initialized
INFO - 2023-04-27 06:09:00 --> Router Class Initialized
INFO - 2023-04-27 06:09:00 --> Router Class Initialized
INFO - 2023-04-27 06:09:00 --> Output Class Initialized
INFO - 2023-04-27 06:09:00 --> Output Class Initialized
INFO - 2023-04-27 06:09:00 --> Security Class Initialized
INFO - 2023-04-27 06:09:00 --> Security Class Initialized
DEBUG - 2023-04-27 06:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:09:00 --> Input Class Initialized
INFO - 2023-04-27 06:09:00 --> Input Class Initialized
INFO - 2023-04-27 06:09:00 --> Language Class Initialized
INFO - 2023-04-27 06:09:00 --> Language Class Initialized
INFO - 2023-04-27 06:09:00 --> Loader Class Initialized
INFO - 2023-04-27 06:09:00 --> Loader Class Initialized
INFO - 2023-04-27 06:09:00 --> Controller Class Initialized
INFO - 2023-04-27 06:09:00 --> Controller Class Initialized
DEBUG - 2023-04-27 06:09:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:09:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:09:00 --> Database Driver Class Initialized
INFO - 2023-04-27 06:09:00 --> Database Driver Class Initialized
INFO - 2023-04-27 06:09:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:09:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:09:00 --> Final output sent to browser
DEBUG - 2023-04-27 06:09:00 --> Total execution time: 0.0360
INFO - 2023-04-27 06:09:00 --> Config Class Initialized
INFO - 2023-04-27 06:09:00 --> Hooks Class Initialized
INFO - 2023-04-27 06:09:00 --> Final output sent to browser
DEBUG - 2023-04-27 06:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:09:00 --> Total execution time: 0.0867
INFO - 2023-04-27 06:09:00 --> Utf8 Class Initialized
INFO - 2023-04-27 06:09:00 --> URI Class Initialized
INFO - 2023-04-27 06:09:00 --> Router Class Initialized
INFO - 2023-04-27 06:09:00 --> Output Class Initialized
INFO - 2023-04-27 06:09:00 --> Security Class Initialized
DEBUG - 2023-04-27 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:09:00 --> Input Class Initialized
INFO - 2023-04-27 06:09:00 --> Config Class Initialized
INFO - 2023-04-27 06:09:00 --> Language Class Initialized
INFO - 2023-04-27 06:09:00 --> Hooks Class Initialized
INFO - 2023-04-27 06:09:00 --> Loader Class Initialized
DEBUG - 2023-04-27 06:09:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:09:00 --> Utf8 Class Initialized
INFO - 2023-04-27 06:09:00 --> Controller Class Initialized
INFO - 2023-04-27 06:09:00 --> URI Class Initialized
DEBUG - 2023-04-27 06:09:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:09:00 --> Router Class Initialized
INFO - 2023-04-27 06:09:00 --> Database Driver Class Initialized
INFO - 2023-04-27 06:09:00 --> Output Class Initialized
INFO - 2023-04-27 06:09:00 --> Security Class Initialized
DEBUG - 2023-04-27 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:09:00 --> Input Class Initialized
INFO - 2023-04-27 06:09:00 --> Language Class Initialized
INFO - 2023-04-27 06:09:00 --> Loader Class Initialized
INFO - 2023-04-27 06:09:00 --> Controller Class Initialized
DEBUG - 2023-04-27 06:09:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:09:00 --> Database Driver Class Initialized
INFO - 2023-04-27 06:09:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:09:00 --> Final output sent to browser
INFO - 2023-04-27 06:09:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:09:00 --> Final output sent to browser
DEBUG - 2023-04-27 06:09:00 --> Total execution time: 0.1770
DEBUG - 2023-04-27 06:09:00 --> Total execution time: 0.0736
INFO - 2023-04-27 06:09:51 --> Config Class Initialized
INFO - 2023-04-27 06:09:51 --> Hooks Class Initialized
INFO - 2023-04-27 06:09:51 --> Config Class Initialized
DEBUG - 2023-04-27 06:09:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:09:51 --> Hooks Class Initialized
INFO - 2023-04-27 06:09:51 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:09:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:09:51 --> URI Class Initialized
INFO - 2023-04-27 06:09:51 --> Utf8 Class Initialized
INFO - 2023-04-27 06:09:51 --> Router Class Initialized
INFO - 2023-04-27 06:09:51 --> URI Class Initialized
INFO - 2023-04-27 06:09:51 --> Output Class Initialized
INFO - 2023-04-27 06:09:51 --> Router Class Initialized
INFO - 2023-04-27 06:09:51 --> Security Class Initialized
INFO - 2023-04-27 06:09:51 --> Output Class Initialized
DEBUG - 2023-04-27 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:09:51 --> Security Class Initialized
INFO - 2023-04-27 06:09:51 --> Input Class Initialized
DEBUG - 2023-04-27 06:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:09:51 --> Language Class Initialized
INFO - 2023-04-27 06:09:51 --> Input Class Initialized
INFO - 2023-04-27 06:09:51 --> Language Class Initialized
INFO - 2023-04-27 06:09:51 --> Loader Class Initialized
INFO - 2023-04-27 06:09:51 --> Loader Class Initialized
INFO - 2023-04-27 06:09:51 --> Controller Class Initialized
INFO - 2023-04-27 06:09:51 --> Controller Class Initialized
DEBUG - 2023-04-27 06:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:09:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:09:51 --> Database Driver Class Initialized
INFO - 2023-04-27 06:09:51 --> Database Driver Class Initialized
INFO - 2023-04-27 06:09:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:09:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:09:51 --> Final output sent to browser
DEBUG - 2023-04-27 06:09:51 --> Total execution time: 0.1278
INFO - 2023-04-27 06:09:51 --> Final output sent to browser
DEBUG - 2023-04-27 06:09:51 --> Total execution time: 0.1360
INFO - 2023-04-27 06:09:51 --> Config Class Initialized
INFO - 2023-04-27 06:09:51 --> Config Class Initialized
INFO - 2023-04-27 06:09:51 --> Hooks Class Initialized
INFO - 2023-04-27 06:09:52 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:09:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:09:52 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:09:52 --> Utf8 Class Initialized
INFO - 2023-04-27 06:09:52 --> Utf8 Class Initialized
INFO - 2023-04-27 06:09:52 --> URI Class Initialized
INFO - 2023-04-27 06:09:52 --> URI Class Initialized
INFO - 2023-04-27 06:09:52 --> Router Class Initialized
INFO - 2023-04-27 06:09:52 --> Router Class Initialized
INFO - 2023-04-27 06:09:52 --> Output Class Initialized
INFO - 2023-04-27 06:09:52 --> Output Class Initialized
INFO - 2023-04-27 06:09:52 --> Security Class Initialized
INFO - 2023-04-27 06:09:52 --> Security Class Initialized
DEBUG - 2023-04-27 06:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:09:52 --> Input Class Initialized
INFO - 2023-04-27 06:09:52 --> Input Class Initialized
INFO - 2023-04-27 06:09:52 --> Language Class Initialized
INFO - 2023-04-27 06:09:52 --> Language Class Initialized
INFO - 2023-04-27 06:09:52 --> Loader Class Initialized
INFO - 2023-04-27 06:09:52 --> Loader Class Initialized
INFO - 2023-04-27 06:09:52 --> Controller Class Initialized
INFO - 2023-04-27 06:09:52 --> Controller Class Initialized
DEBUG - 2023-04-27 06:09:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:09:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:09:52 --> Database Driver Class Initialized
INFO - 2023-04-27 06:09:52 --> Database Driver Class Initialized
INFO - 2023-04-27 06:09:52 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:09:52 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:09:52 --> Final output sent to browser
DEBUG - 2023-04-27 06:09:52 --> Total execution time: 0.1043
INFO - 2023-04-27 06:09:52 --> Final output sent to browser
DEBUG - 2023-04-27 06:09:52 --> Total execution time: 0.1057
INFO - 2023-04-27 06:10:10 --> Config Class Initialized
INFO - 2023-04-27 06:10:10 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:10:10 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:10:10 --> Utf8 Class Initialized
INFO - 2023-04-27 06:10:10 --> URI Class Initialized
INFO - 2023-04-27 06:10:10 --> Router Class Initialized
INFO - 2023-04-27 06:10:10 --> Output Class Initialized
INFO - 2023-04-27 06:10:10 --> Security Class Initialized
DEBUG - 2023-04-27 06:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:10:10 --> Input Class Initialized
INFO - 2023-04-27 06:10:10 --> Language Class Initialized
INFO - 2023-04-27 06:10:10 --> Loader Class Initialized
INFO - 2023-04-27 06:10:10 --> Controller Class Initialized
DEBUG - 2023-04-27 06:10:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:10:10 --> Database Driver Class Initialized
INFO - 2023-04-27 06:10:10 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:10:10 --> Final output sent to browser
DEBUG - 2023-04-27 06:10:10 --> Total execution time: 0.0146
INFO - 2023-04-27 06:10:10 --> Config Class Initialized
INFO - 2023-04-27 06:10:10 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:10:10 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:10:10 --> Utf8 Class Initialized
INFO - 2023-04-27 06:10:10 --> URI Class Initialized
INFO - 2023-04-27 06:10:10 --> Router Class Initialized
INFO - 2023-04-27 06:10:10 --> Output Class Initialized
INFO - 2023-04-27 06:10:10 --> Security Class Initialized
DEBUG - 2023-04-27 06:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:10:10 --> Input Class Initialized
INFO - 2023-04-27 06:10:10 --> Language Class Initialized
INFO - 2023-04-27 06:10:10 --> Loader Class Initialized
INFO - 2023-04-27 06:10:10 --> Controller Class Initialized
DEBUG - 2023-04-27 06:10:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:10:10 --> Database Driver Class Initialized
INFO - 2023-04-27 06:10:10 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:10:10 --> Final output sent to browser
DEBUG - 2023-04-27 06:10:10 --> Total execution time: 0.0550
INFO - 2023-04-27 06:10:10 --> Config Class Initialized
INFO - 2023-04-27 06:10:10 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:10:10 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:10:10 --> Utf8 Class Initialized
INFO - 2023-04-27 06:10:10 --> URI Class Initialized
INFO - 2023-04-27 06:10:10 --> Router Class Initialized
INFO - 2023-04-27 06:10:10 --> Output Class Initialized
INFO - 2023-04-27 06:10:10 --> Security Class Initialized
DEBUG - 2023-04-27 06:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:10:10 --> Input Class Initialized
INFO - 2023-04-27 06:10:10 --> Language Class Initialized
INFO - 2023-04-27 06:10:10 --> Loader Class Initialized
INFO - 2023-04-27 06:10:10 --> Controller Class Initialized
DEBUG - 2023-04-27 06:10:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:10:10 --> Database Driver Class Initialized
INFO - 2023-04-27 06:10:10 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:10:10 --> Final output sent to browser
DEBUG - 2023-04-27 06:10:10 --> Total execution time: 0.0508
INFO - 2023-04-27 06:10:10 --> Config Class Initialized
INFO - 2023-04-27 06:10:10 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:10:10 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:10:10 --> Utf8 Class Initialized
INFO - 2023-04-27 06:10:10 --> URI Class Initialized
INFO - 2023-04-27 06:10:10 --> Router Class Initialized
INFO - 2023-04-27 06:10:10 --> Output Class Initialized
INFO - 2023-04-27 06:10:10 --> Security Class Initialized
DEBUG - 2023-04-27 06:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:10:10 --> Input Class Initialized
INFO - 2023-04-27 06:10:10 --> Language Class Initialized
INFO - 2023-04-27 06:10:10 --> Loader Class Initialized
INFO - 2023-04-27 06:10:10 --> Controller Class Initialized
DEBUG - 2023-04-27 06:10:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:10:10 --> Database Driver Class Initialized
INFO - 2023-04-27 06:10:10 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:10:10 --> Final output sent to browser
DEBUG - 2023-04-27 06:10:10 --> Total execution time: 0.0523
INFO - 2023-04-27 06:11:11 --> Config Class Initialized
INFO - 2023-04-27 06:11:11 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:11:11 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:11:11 --> Utf8 Class Initialized
INFO - 2023-04-27 06:11:11 --> URI Class Initialized
INFO - 2023-04-27 06:11:11 --> Router Class Initialized
INFO - 2023-04-27 06:11:11 --> Output Class Initialized
INFO - 2023-04-27 06:11:11 --> Security Class Initialized
DEBUG - 2023-04-27 06:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:11:11 --> Input Class Initialized
INFO - 2023-04-27 06:11:11 --> Language Class Initialized
INFO - 2023-04-27 06:11:11 --> Loader Class Initialized
INFO - 2023-04-27 06:11:11 --> Controller Class Initialized
DEBUG - 2023-04-27 06:11:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:11:11 --> Database Driver Class Initialized
INFO - 2023-04-27 06:11:11 --> Config Class Initialized
INFO - 2023-04-27 06:11:11 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:11:11 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:11:11 --> Utf8 Class Initialized
INFO - 2023-04-27 06:11:11 --> URI Class Initialized
INFO - 2023-04-27 06:11:11 --> Router Class Initialized
INFO - 2023-04-27 06:11:11 --> Output Class Initialized
INFO - 2023-04-27 06:11:11 --> Security Class Initialized
DEBUG - 2023-04-27 06:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:11:11 --> Input Class Initialized
INFO - 2023-04-27 06:11:11 --> Language Class Initialized
INFO - 2023-04-27 06:11:11 --> Loader Class Initialized
INFO - 2023-04-27 06:11:11 --> Controller Class Initialized
DEBUG - 2023-04-27 06:11:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:11:11 --> Database Driver Class Initialized
INFO - 2023-04-27 06:11:11 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:11:11 --> Final output sent to browser
INFO - 2023-04-27 06:11:11 --> Model "Cluster_model" initialized
DEBUG - 2023-04-27 06:11:11 --> Total execution time: 0.0255
INFO - 2023-04-27 06:11:11 --> Final output sent to browser
DEBUG - 2023-04-27 06:11:11 --> Total execution time: 0.0198
INFO - 2023-04-27 06:11:11 --> Config Class Initialized
INFO - 2023-04-27 06:11:11 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:11:11 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:11:11 --> Utf8 Class Initialized
INFO - 2023-04-27 06:11:11 --> URI Class Initialized
INFO - 2023-04-27 06:11:11 --> Router Class Initialized
INFO - 2023-04-27 06:11:11 --> Output Class Initialized
INFO - 2023-04-27 06:11:11 --> Config Class Initialized
INFO - 2023-04-27 06:11:11 --> Security Class Initialized
INFO - 2023-04-27 06:11:11 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:11:11 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:11:11 --> Input Class Initialized
INFO - 2023-04-27 06:11:11 --> Utf8 Class Initialized
INFO - 2023-04-27 06:11:11 --> URI Class Initialized
INFO - 2023-04-27 06:11:11 --> Language Class Initialized
INFO - 2023-04-27 06:11:11 --> Router Class Initialized
INFO - 2023-04-27 06:11:11 --> Output Class Initialized
INFO - 2023-04-27 06:11:11 --> Loader Class Initialized
INFO - 2023-04-27 06:11:11 --> Security Class Initialized
INFO - 2023-04-27 06:11:11 --> Controller Class Initialized
DEBUG - 2023-04-27 06:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:11:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:11:11 --> Input Class Initialized
INFO - 2023-04-27 06:11:11 --> Language Class Initialized
INFO - 2023-04-27 06:11:11 --> Database Driver Class Initialized
INFO - 2023-04-27 06:11:11 --> Loader Class Initialized
INFO - 2023-04-27 06:11:11 --> Controller Class Initialized
DEBUG - 2023-04-27 06:11:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:11:11 --> Database Driver Class Initialized
INFO - 2023-04-27 06:11:11 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:11:11 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:11:11 --> Final output sent to browser
DEBUG - 2023-04-27 06:11:11 --> Total execution time: 0.0206
INFO - 2023-04-27 06:11:11 --> Final output sent to browser
DEBUG - 2023-04-27 06:11:11 --> Total execution time: 0.0176
INFO - 2023-04-27 06:11:24 --> Config Class Initialized
INFO - 2023-04-27 06:11:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:11:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:11:24 --> Utf8 Class Initialized
INFO - 2023-04-27 06:11:24 --> URI Class Initialized
INFO - 2023-04-27 06:11:24 --> Router Class Initialized
INFO - 2023-04-27 06:11:24 --> Output Class Initialized
INFO - 2023-04-27 06:11:24 --> Security Class Initialized
DEBUG - 2023-04-27 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:11:24 --> Input Class Initialized
INFO - 2023-04-27 06:11:24 --> Language Class Initialized
INFO - 2023-04-27 06:11:24 --> Loader Class Initialized
INFO - 2023-04-27 06:11:24 --> Controller Class Initialized
DEBUG - 2023-04-27 06:11:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:11:24 --> Database Driver Class Initialized
INFO - 2023-04-27 06:11:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:11:24 --> Final output sent to browser
DEBUG - 2023-04-27 06:11:24 --> Total execution time: 0.0120
INFO - 2023-04-27 06:11:24 --> Config Class Initialized
INFO - 2023-04-27 06:11:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:11:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:11:24 --> Utf8 Class Initialized
INFO - 2023-04-27 06:11:24 --> URI Class Initialized
INFO - 2023-04-27 06:11:24 --> Router Class Initialized
INFO - 2023-04-27 06:11:24 --> Output Class Initialized
INFO - 2023-04-27 06:11:24 --> Security Class Initialized
DEBUG - 2023-04-27 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:11:24 --> Input Class Initialized
INFO - 2023-04-27 06:11:24 --> Language Class Initialized
INFO - 2023-04-27 06:11:24 --> Loader Class Initialized
INFO - 2023-04-27 06:11:24 --> Controller Class Initialized
DEBUG - 2023-04-27 06:11:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:11:24 --> Database Driver Class Initialized
INFO - 2023-04-27 06:11:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:11:24 --> Final output sent to browser
DEBUG - 2023-04-27 06:11:24 --> Total execution time: 0.0124
INFO - 2023-04-27 06:11:24 --> Config Class Initialized
INFO - 2023-04-27 06:11:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:11:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:11:24 --> Utf8 Class Initialized
INFO - 2023-04-27 06:11:24 --> URI Class Initialized
INFO - 2023-04-27 06:11:24 --> Router Class Initialized
INFO - 2023-04-27 06:11:24 --> Output Class Initialized
INFO - 2023-04-27 06:11:24 --> Security Class Initialized
DEBUG - 2023-04-27 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:11:24 --> Input Class Initialized
INFO - 2023-04-27 06:11:24 --> Language Class Initialized
INFO - 2023-04-27 06:11:24 --> Loader Class Initialized
INFO - 2023-04-27 06:11:24 --> Controller Class Initialized
DEBUG - 2023-04-27 06:11:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:11:24 --> Database Driver Class Initialized
INFO - 2023-04-27 06:11:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:11:24 --> Final output sent to browser
DEBUG - 2023-04-27 06:11:24 --> Total execution time: 0.0548
INFO - 2023-04-27 06:11:24 --> Config Class Initialized
INFO - 2023-04-27 06:11:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:11:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:11:24 --> Utf8 Class Initialized
INFO - 2023-04-27 06:11:24 --> URI Class Initialized
INFO - 2023-04-27 06:11:24 --> Router Class Initialized
INFO - 2023-04-27 06:11:24 --> Output Class Initialized
INFO - 2023-04-27 06:11:24 --> Security Class Initialized
DEBUG - 2023-04-27 06:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:11:24 --> Input Class Initialized
INFO - 2023-04-27 06:11:24 --> Language Class Initialized
INFO - 2023-04-27 06:11:24 --> Loader Class Initialized
INFO - 2023-04-27 06:11:24 --> Controller Class Initialized
DEBUG - 2023-04-27 06:11:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:11:25 --> Database Driver Class Initialized
INFO - 2023-04-27 06:11:25 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:11:25 --> Final output sent to browser
DEBUG - 2023-04-27 06:11:25 --> Total execution time: 0.0129
INFO - 2023-04-27 06:12:13 --> Config Class Initialized
INFO - 2023-04-27 06:12:13 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:12:13 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:12:13 --> Utf8 Class Initialized
INFO - 2023-04-27 06:12:13 --> URI Class Initialized
INFO - 2023-04-27 06:12:13 --> Router Class Initialized
INFO - 2023-04-27 06:12:13 --> Output Class Initialized
INFO - 2023-04-27 06:12:13 --> Security Class Initialized
DEBUG - 2023-04-27 06:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:12:13 --> Input Class Initialized
INFO - 2023-04-27 06:12:13 --> Language Class Initialized
INFO - 2023-04-27 06:12:13 --> Loader Class Initialized
INFO - 2023-04-27 06:12:13 --> Controller Class Initialized
DEBUG - 2023-04-27 06:12:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:12:13 --> Database Driver Class Initialized
INFO - 2023-04-27 06:12:13 --> Config Class Initialized
INFO - 2023-04-27 06:12:13 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:12:13 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:12:13 --> Utf8 Class Initialized
INFO - 2023-04-27 06:12:13 --> URI Class Initialized
INFO - 2023-04-27 06:12:13 --> Router Class Initialized
INFO - 2023-04-27 06:12:13 --> Output Class Initialized
INFO - 2023-04-27 06:12:13 --> Security Class Initialized
DEBUG - 2023-04-27 06:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:12:13 --> Input Class Initialized
INFO - 2023-04-27 06:12:13 --> Language Class Initialized
INFO - 2023-04-27 06:12:13 --> Loader Class Initialized
INFO - 2023-04-27 06:12:13 --> Controller Class Initialized
DEBUG - 2023-04-27 06:12:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:12:13 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:12:13 --> Database Driver Class Initialized
INFO - 2023-04-27 06:12:13 --> Final output sent to browser
DEBUG - 2023-04-27 06:12:13 --> Total execution time: 0.0263
INFO - 2023-04-27 06:12:13 --> Config Class Initialized
INFO - 2023-04-27 06:12:13 --> Hooks Class Initialized
INFO - 2023-04-27 06:12:14 --> Model "Cluster_model" initialized
DEBUG - 2023-04-27 06:12:14 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:12:14 --> Utf8 Class Initialized
INFO - 2023-04-27 06:12:14 --> URI Class Initialized
INFO - 2023-04-27 06:12:14 --> Router Class Initialized
INFO - 2023-04-27 06:12:14 --> Output Class Initialized
INFO - 2023-04-27 06:12:14 --> Security Class Initialized
INFO - 2023-04-27 06:12:14 --> Final output sent to browser
DEBUG - 2023-04-27 06:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:12:14 --> Total execution time: 0.0182
INFO - 2023-04-27 06:12:14 --> Input Class Initialized
INFO - 2023-04-27 06:12:14 --> Language Class Initialized
INFO - 2023-04-27 06:12:14 --> Loader Class Initialized
INFO - 2023-04-27 06:12:14 --> Controller Class Initialized
DEBUG - 2023-04-27 06:12:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:12:14 --> Database Driver Class Initialized
INFO - 2023-04-27 06:12:14 --> Config Class Initialized
INFO - 2023-04-27 06:12:14 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:12:14 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:12:14 --> Utf8 Class Initialized
INFO - 2023-04-27 06:12:14 --> URI Class Initialized
INFO - 2023-04-27 06:12:14 --> Router Class Initialized
INFO - 2023-04-27 06:12:14 --> Output Class Initialized
INFO - 2023-04-27 06:12:14 --> Security Class Initialized
DEBUG - 2023-04-27 06:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:12:14 --> Input Class Initialized
INFO - 2023-04-27 06:12:14 --> Language Class Initialized
INFO - 2023-04-27 06:12:14 --> Loader Class Initialized
INFO - 2023-04-27 06:12:14 --> Controller Class Initialized
DEBUG - 2023-04-27 06:12:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:12:14 --> Database Driver Class Initialized
INFO - 2023-04-27 06:12:14 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:12:14 --> Final output sent to browser
INFO - 2023-04-27 06:12:14 --> Model "Cluster_model" initialized
DEBUG - 2023-04-27 06:12:14 --> Total execution time: 0.0223
INFO - 2023-04-27 06:12:14 --> Final output sent to browser
DEBUG - 2023-04-27 06:12:14 --> Total execution time: 0.0562
INFO - 2023-04-27 06:12:17 --> Config Class Initialized
INFO - 2023-04-27 06:12:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:12:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:12:17 --> Utf8 Class Initialized
INFO - 2023-04-27 06:12:17 --> URI Class Initialized
INFO - 2023-04-27 06:12:17 --> Router Class Initialized
INFO - 2023-04-27 06:12:17 --> Output Class Initialized
INFO - 2023-04-27 06:12:17 --> Security Class Initialized
DEBUG - 2023-04-27 06:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:12:17 --> Input Class Initialized
INFO - 2023-04-27 06:12:17 --> Language Class Initialized
INFO - 2023-04-27 06:12:17 --> Loader Class Initialized
INFO - 2023-04-27 06:12:17 --> Controller Class Initialized
DEBUG - 2023-04-27 06:12:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:12:17 --> Database Driver Class Initialized
INFO - 2023-04-27 06:12:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:12:17 --> Final output sent to browser
DEBUG - 2023-04-27 06:12:17 --> Total execution time: 0.0242
INFO - 2023-04-27 06:12:17 --> Config Class Initialized
INFO - 2023-04-27 06:12:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:12:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:12:17 --> Utf8 Class Initialized
INFO - 2023-04-27 06:12:17 --> URI Class Initialized
INFO - 2023-04-27 06:12:17 --> Router Class Initialized
INFO - 2023-04-27 06:12:17 --> Output Class Initialized
INFO - 2023-04-27 06:12:17 --> Security Class Initialized
DEBUG - 2023-04-27 06:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:12:17 --> Input Class Initialized
INFO - 2023-04-27 06:12:17 --> Language Class Initialized
INFO - 2023-04-27 06:12:17 --> Loader Class Initialized
INFO - 2023-04-27 06:12:17 --> Controller Class Initialized
DEBUG - 2023-04-27 06:12:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:12:17 --> Database Driver Class Initialized
INFO - 2023-04-27 06:12:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:12:17 --> Final output sent to browser
DEBUG - 2023-04-27 06:12:17 --> Total execution time: 0.0584
INFO - 2023-04-27 06:12:17 --> Config Class Initialized
INFO - 2023-04-27 06:12:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:12:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:12:17 --> Utf8 Class Initialized
INFO - 2023-04-27 06:12:17 --> URI Class Initialized
INFO - 2023-04-27 06:12:17 --> Router Class Initialized
INFO - 2023-04-27 06:12:17 --> Output Class Initialized
INFO - 2023-04-27 06:12:17 --> Security Class Initialized
DEBUG - 2023-04-27 06:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:12:17 --> Input Class Initialized
INFO - 2023-04-27 06:12:17 --> Language Class Initialized
INFO - 2023-04-27 06:12:17 --> Loader Class Initialized
INFO - 2023-04-27 06:12:17 --> Controller Class Initialized
DEBUG - 2023-04-27 06:12:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:12:17 --> Database Driver Class Initialized
INFO - 2023-04-27 06:12:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:12:17 --> Final output sent to browser
DEBUG - 2023-04-27 06:12:17 --> Total execution time: 0.0551
INFO - 2023-04-27 06:12:17 --> Config Class Initialized
INFO - 2023-04-27 06:12:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:12:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:12:17 --> Utf8 Class Initialized
INFO - 2023-04-27 06:12:17 --> URI Class Initialized
INFO - 2023-04-27 06:12:17 --> Router Class Initialized
INFO - 2023-04-27 06:12:17 --> Output Class Initialized
INFO - 2023-04-27 06:12:17 --> Security Class Initialized
DEBUG - 2023-04-27 06:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:12:17 --> Input Class Initialized
INFO - 2023-04-27 06:12:17 --> Language Class Initialized
INFO - 2023-04-27 06:12:17 --> Loader Class Initialized
INFO - 2023-04-27 06:12:17 --> Controller Class Initialized
DEBUG - 2023-04-27 06:12:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:12:17 --> Database Driver Class Initialized
INFO - 2023-04-27 06:12:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:12:17 --> Final output sent to browser
DEBUG - 2023-04-27 06:12:17 --> Total execution time: 0.0382
INFO - 2023-04-27 06:15:00 --> Config Class Initialized
INFO - 2023-04-27 06:15:00 --> Config Class Initialized
INFO - 2023-04-27 06:15:01 --> Hooks Class Initialized
INFO - 2023-04-27 06:15:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:15:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:15:01 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:15:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:15:01 --> URI Class Initialized
INFO - 2023-04-27 06:15:01 --> Utf8 Class Initialized
INFO - 2023-04-27 06:15:01 --> Router Class Initialized
INFO - 2023-04-27 06:15:01 --> URI Class Initialized
INFO - 2023-04-27 06:15:01 --> Output Class Initialized
INFO - 2023-04-27 06:15:01 --> Router Class Initialized
INFO - 2023-04-27 06:15:01 --> Security Class Initialized
INFO - 2023-04-27 06:15:01 --> Output Class Initialized
DEBUG - 2023-04-27 06:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:15:01 --> Security Class Initialized
INFO - 2023-04-27 06:15:01 --> Input Class Initialized
INFO - 2023-04-27 06:15:01 --> Language Class Initialized
DEBUG - 2023-04-27 06:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:15:01 --> Input Class Initialized
INFO - 2023-04-27 06:15:01 --> Loader Class Initialized
INFO - 2023-04-27 06:15:01 --> Language Class Initialized
INFO - 2023-04-27 06:15:01 --> Controller Class Initialized
INFO - 2023-04-27 06:15:01 --> Loader Class Initialized
DEBUG - 2023-04-27 06:15:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:15:01 --> Controller Class Initialized
DEBUG - 2023-04-27 06:15:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:15:01 --> Database Driver Class Initialized
INFO - 2023-04-27 06:15:01 --> Database Driver Class Initialized
INFO - 2023-04-27 06:15:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:15:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:15:01 --> Final output sent to browser
DEBUG - 2023-04-27 06:15:01 --> Total execution time: 0.1780
INFO - 2023-04-27 06:15:01 --> Final output sent to browser
DEBUG - 2023-04-27 06:15:01 --> Total execution time: 0.1801
INFO - 2023-04-27 06:15:01 --> Config Class Initialized
INFO - 2023-04-27 06:15:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:15:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:15:01 --> Utf8 Class Initialized
INFO - 2023-04-27 06:15:01 --> Config Class Initialized
INFO - 2023-04-27 06:15:01 --> URI Class Initialized
INFO - 2023-04-27 06:15:01 --> Hooks Class Initialized
INFO - 2023-04-27 06:15:01 --> Router Class Initialized
INFO - 2023-04-27 06:15:01 --> Output Class Initialized
DEBUG - 2023-04-27 06:15:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:15:01 --> Security Class Initialized
INFO - 2023-04-27 06:15:01 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:15:01 --> Input Class Initialized
INFO - 2023-04-27 06:15:01 --> Language Class Initialized
INFO - 2023-04-27 06:15:01 --> URI Class Initialized
INFO - 2023-04-27 06:15:01 --> Loader Class Initialized
INFO - 2023-04-27 06:15:01 --> Controller Class Initialized
INFO - 2023-04-27 06:15:01 --> Router Class Initialized
DEBUG - 2023-04-27 06:15:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:15:01 --> Output Class Initialized
INFO - 2023-04-27 06:15:01 --> Security Class Initialized
INFO - 2023-04-27 06:15:01 --> Database Driver Class Initialized
DEBUG - 2023-04-27 06:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:15:01 --> Input Class Initialized
INFO - 2023-04-27 06:15:01 --> Language Class Initialized
INFO - 2023-04-27 06:15:01 --> Loader Class Initialized
INFO - 2023-04-27 06:15:01 --> Controller Class Initialized
DEBUG - 2023-04-27 06:15:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:15:01 --> Database Driver Class Initialized
INFO - 2023-04-27 06:15:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:15:01 --> Final output sent to browser
DEBUG - 2023-04-27 06:15:01 --> Total execution time: 0.0159
INFO - 2023-04-27 06:15:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:15:01 --> Final output sent to browser
DEBUG - 2023-04-27 06:15:01 --> Total execution time: 0.0586
INFO - 2023-04-27 06:15:06 --> Config Class Initialized
INFO - 2023-04-27 06:15:06 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:15:06 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:15:06 --> Utf8 Class Initialized
INFO - 2023-04-27 06:15:06 --> URI Class Initialized
INFO - 2023-04-27 06:15:06 --> Router Class Initialized
INFO - 2023-04-27 06:15:06 --> Output Class Initialized
INFO - 2023-04-27 06:15:06 --> Security Class Initialized
DEBUG - 2023-04-27 06:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:15:06 --> Input Class Initialized
INFO - 2023-04-27 06:15:06 --> Language Class Initialized
INFO - 2023-04-27 06:15:06 --> Loader Class Initialized
INFO - 2023-04-27 06:15:06 --> Controller Class Initialized
DEBUG - 2023-04-27 06:15:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:15:06 --> Database Driver Class Initialized
INFO - 2023-04-27 06:15:06 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:15:06 --> Final output sent to browser
DEBUG - 2023-04-27 06:15:06 --> Total execution time: 0.0130
INFO - 2023-04-27 06:15:06 --> Config Class Initialized
INFO - 2023-04-27 06:15:06 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:15:06 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:15:06 --> Utf8 Class Initialized
INFO - 2023-04-27 06:15:06 --> URI Class Initialized
INFO - 2023-04-27 06:15:06 --> Router Class Initialized
INFO - 2023-04-27 06:15:06 --> Output Class Initialized
INFO - 2023-04-27 06:15:06 --> Security Class Initialized
DEBUG - 2023-04-27 06:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:15:06 --> Input Class Initialized
INFO - 2023-04-27 06:15:06 --> Language Class Initialized
INFO - 2023-04-27 06:15:06 --> Loader Class Initialized
INFO - 2023-04-27 06:15:06 --> Controller Class Initialized
DEBUG - 2023-04-27 06:15:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:15:06 --> Database Driver Class Initialized
INFO - 2023-04-27 06:15:06 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:15:06 --> Final output sent to browser
DEBUG - 2023-04-27 06:15:06 --> Total execution time: 0.0108
INFO - 2023-04-27 06:15:06 --> Config Class Initialized
INFO - 2023-04-27 06:15:06 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:15:06 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:15:06 --> Utf8 Class Initialized
INFO - 2023-04-27 06:15:06 --> URI Class Initialized
INFO - 2023-04-27 06:15:06 --> Router Class Initialized
INFO - 2023-04-27 06:15:06 --> Output Class Initialized
INFO - 2023-04-27 06:15:06 --> Security Class Initialized
DEBUG - 2023-04-27 06:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:15:06 --> Input Class Initialized
INFO - 2023-04-27 06:15:06 --> Language Class Initialized
INFO - 2023-04-27 06:15:06 --> Loader Class Initialized
INFO - 2023-04-27 06:15:06 --> Controller Class Initialized
DEBUG - 2023-04-27 06:15:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:15:06 --> Database Driver Class Initialized
INFO - 2023-04-27 06:15:06 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:15:06 --> Final output sent to browser
DEBUG - 2023-04-27 06:15:06 --> Total execution time: 0.0567
INFO - 2023-04-27 06:15:06 --> Config Class Initialized
INFO - 2023-04-27 06:15:06 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:15:06 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:15:06 --> Utf8 Class Initialized
INFO - 2023-04-27 06:15:06 --> URI Class Initialized
INFO - 2023-04-27 06:15:06 --> Router Class Initialized
INFO - 2023-04-27 06:15:06 --> Output Class Initialized
INFO - 2023-04-27 06:15:06 --> Security Class Initialized
DEBUG - 2023-04-27 06:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:15:06 --> Input Class Initialized
INFO - 2023-04-27 06:15:06 --> Language Class Initialized
INFO - 2023-04-27 06:15:06 --> Loader Class Initialized
INFO - 2023-04-27 06:15:06 --> Controller Class Initialized
DEBUG - 2023-04-27 06:15:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:15:06 --> Database Driver Class Initialized
INFO - 2023-04-27 06:15:06 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:15:06 --> Final output sent to browser
DEBUG - 2023-04-27 06:15:06 --> Total execution time: 0.0111
INFO - 2023-04-27 06:17:29 --> Config Class Initialized
INFO - 2023-04-27 06:17:29 --> Config Class Initialized
INFO - 2023-04-27 06:17:29 --> Hooks Class Initialized
INFO - 2023-04-27 06:17:29 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:17:29 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:17:29 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:29 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:29 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:29 --> URI Class Initialized
INFO - 2023-04-27 06:17:29 --> URI Class Initialized
INFO - 2023-04-27 06:17:29 --> Router Class Initialized
INFO - 2023-04-27 06:17:29 --> Router Class Initialized
INFO - 2023-04-27 06:17:29 --> Output Class Initialized
INFO - 2023-04-27 06:17:29 --> Output Class Initialized
INFO - 2023-04-27 06:17:29 --> Security Class Initialized
INFO - 2023-04-27 06:17:29 --> Security Class Initialized
DEBUG - 2023-04-27 06:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:29 --> Input Class Initialized
INFO - 2023-04-27 06:17:29 --> Input Class Initialized
INFO - 2023-04-27 06:17:29 --> Language Class Initialized
INFO - 2023-04-27 06:17:29 --> Language Class Initialized
INFO - 2023-04-27 06:17:29 --> Loader Class Initialized
INFO - 2023-04-27 06:17:29 --> Controller Class Initialized
INFO - 2023-04-27 06:17:29 --> Loader Class Initialized
DEBUG - 2023-04-27 06:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:29 --> Controller Class Initialized
DEBUG - 2023-04-27 06:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:29 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:29 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:29 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:29 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:29 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:29 --> Total execution time: 0.0632
INFO - 2023-04-27 06:17:29 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:29 --> Total execution time: 0.0670
INFO - 2023-04-27 06:17:29 --> Config Class Initialized
INFO - 2023-04-27 06:17:29 --> Hooks Class Initialized
INFO - 2023-04-27 06:17:29 --> Config Class Initialized
DEBUG - 2023-04-27 06:17:29 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:29 --> Hooks Class Initialized
INFO - 2023-04-27 06:17:29 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:17:29 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:29 --> URI Class Initialized
INFO - 2023-04-27 06:17:29 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:29 --> URI Class Initialized
INFO - 2023-04-27 06:17:29 --> Router Class Initialized
INFO - 2023-04-27 06:17:29 --> Router Class Initialized
INFO - 2023-04-27 06:17:29 --> Output Class Initialized
INFO - 2023-04-27 06:17:29 --> Output Class Initialized
INFO - 2023-04-27 06:17:29 --> Security Class Initialized
INFO - 2023-04-27 06:17:29 --> Security Class Initialized
DEBUG - 2023-04-27 06:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:29 --> Input Class Initialized
INFO - 2023-04-27 06:17:29 --> Input Class Initialized
INFO - 2023-04-27 06:17:29 --> Language Class Initialized
INFO - 2023-04-27 06:17:29 --> Language Class Initialized
INFO - 2023-04-27 06:17:29 --> Loader Class Initialized
INFO - 2023-04-27 06:17:29 --> Loader Class Initialized
INFO - 2023-04-27 06:17:29 --> Controller Class Initialized
INFO - 2023-04-27 06:17:29 --> Controller Class Initialized
DEBUG - 2023-04-27 06:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:29 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:29 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:29 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:29 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:29 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:29 --> Total execution time: 0.0392
INFO - 2023-04-27 06:17:29 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:29 --> Total execution time: 0.0507
INFO - 2023-04-27 06:17:40 --> Config Class Initialized
INFO - 2023-04-27 06:17:40 --> Config Class Initialized
INFO - 2023-04-27 06:17:40 --> Hooks Class Initialized
INFO - 2023-04-27 06:17:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:17:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:17:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:40 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:40 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:40 --> URI Class Initialized
INFO - 2023-04-27 06:17:40 --> URI Class Initialized
INFO - 2023-04-27 06:17:40 --> Router Class Initialized
INFO - 2023-04-27 06:17:40 --> Router Class Initialized
INFO - 2023-04-27 06:17:40 --> Output Class Initialized
INFO - 2023-04-27 06:17:40 --> Output Class Initialized
INFO - 2023-04-27 06:17:40 --> Security Class Initialized
INFO - 2023-04-27 06:17:40 --> Security Class Initialized
DEBUG - 2023-04-27 06:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:40 --> Input Class Initialized
INFO - 2023-04-27 06:17:40 --> Input Class Initialized
INFO - 2023-04-27 06:17:40 --> Language Class Initialized
INFO - 2023-04-27 06:17:40 --> Language Class Initialized
INFO - 2023-04-27 06:17:40 --> Loader Class Initialized
INFO - 2023-04-27 06:17:40 --> Loader Class Initialized
INFO - 2023-04-27 06:17:40 --> Controller Class Initialized
INFO - 2023-04-27 06:17:40 --> Controller Class Initialized
DEBUG - 2023-04-27 06:17:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:17:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:40 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:40 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:40 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:40 --> Total execution time: 0.0639
INFO - 2023-04-27 06:17:40 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:40 --> Total execution time: 0.0663
INFO - 2023-04-27 06:17:40 --> Config Class Initialized
INFO - 2023-04-27 06:17:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:17:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:40 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:40 --> URI Class Initialized
INFO - 2023-04-27 06:17:40 --> Config Class Initialized
INFO - 2023-04-27 06:17:40 --> Router Class Initialized
INFO - 2023-04-27 06:17:40 --> Hooks Class Initialized
INFO - 2023-04-27 06:17:40 --> Output Class Initialized
DEBUG - 2023-04-27 06:17:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:40 --> Security Class Initialized
INFO - 2023-04-27 06:17:40 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:40 --> URI Class Initialized
INFO - 2023-04-27 06:17:40 --> Input Class Initialized
INFO - 2023-04-27 06:17:40 --> Language Class Initialized
INFO - 2023-04-27 06:17:40 --> Router Class Initialized
INFO - 2023-04-27 06:17:40 --> Loader Class Initialized
INFO - 2023-04-27 06:17:40 --> Controller Class Initialized
INFO - 2023-04-27 06:17:40 --> Output Class Initialized
DEBUG - 2023-04-27 06:17:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:40 --> Security Class Initialized
DEBUG - 2023-04-27 06:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:40 --> Input Class Initialized
INFO - 2023-04-27 06:17:40 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:40 --> Language Class Initialized
INFO - 2023-04-27 06:17:40 --> Loader Class Initialized
INFO - 2023-04-27 06:17:40 --> Controller Class Initialized
DEBUG - 2023-04-27 06:17:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:40 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:40 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:40 --> Total execution time: 0.0287
INFO - 2023-04-27 06:17:40 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:40 --> Total execution time: 0.0189
INFO - 2023-04-27 06:17:45 --> Config Class Initialized
INFO - 2023-04-27 06:17:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:17:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:45 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:45 --> URI Class Initialized
INFO - 2023-04-27 06:17:45 --> Router Class Initialized
INFO - 2023-04-27 06:17:45 --> Output Class Initialized
INFO - 2023-04-27 06:17:45 --> Security Class Initialized
DEBUG - 2023-04-27 06:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:45 --> Input Class Initialized
INFO - 2023-04-27 06:17:45 --> Language Class Initialized
INFO - 2023-04-27 06:17:45 --> Loader Class Initialized
INFO - 2023-04-27 06:17:45 --> Controller Class Initialized
DEBUG - 2023-04-27 06:17:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:45 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:45 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:45 --> Total execution time: 0.0159
INFO - 2023-04-27 06:17:45 --> Config Class Initialized
INFO - 2023-04-27 06:17:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:17:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:45 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:45 --> URI Class Initialized
INFO - 2023-04-27 06:17:45 --> Router Class Initialized
INFO - 2023-04-27 06:17:45 --> Output Class Initialized
INFO - 2023-04-27 06:17:45 --> Security Class Initialized
DEBUG - 2023-04-27 06:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:45 --> Input Class Initialized
INFO - 2023-04-27 06:17:45 --> Language Class Initialized
INFO - 2023-04-27 06:17:45 --> Loader Class Initialized
INFO - 2023-04-27 06:17:45 --> Controller Class Initialized
DEBUG - 2023-04-27 06:17:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:45 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:45 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:45 --> Total execution time: 0.0118
INFO - 2023-04-27 06:17:46 --> Config Class Initialized
INFO - 2023-04-27 06:17:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:17:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:46 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:46 --> URI Class Initialized
INFO - 2023-04-27 06:17:46 --> Router Class Initialized
INFO - 2023-04-27 06:17:46 --> Output Class Initialized
INFO - 2023-04-27 06:17:46 --> Security Class Initialized
DEBUG - 2023-04-27 06:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:46 --> Input Class Initialized
INFO - 2023-04-27 06:17:46 --> Language Class Initialized
INFO - 2023-04-27 06:17:46 --> Loader Class Initialized
INFO - 2023-04-27 06:17:46 --> Controller Class Initialized
DEBUG - 2023-04-27 06:17:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:46 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:46 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:46 --> Total execution time: 0.0498
INFO - 2023-04-27 06:17:46 --> Config Class Initialized
INFO - 2023-04-27 06:17:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:17:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:17:46 --> Utf8 Class Initialized
INFO - 2023-04-27 06:17:46 --> URI Class Initialized
INFO - 2023-04-27 06:17:46 --> Router Class Initialized
INFO - 2023-04-27 06:17:46 --> Output Class Initialized
INFO - 2023-04-27 06:17:46 --> Security Class Initialized
DEBUG - 2023-04-27 06:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:17:46 --> Input Class Initialized
INFO - 2023-04-27 06:17:46 --> Language Class Initialized
INFO - 2023-04-27 06:17:46 --> Loader Class Initialized
INFO - 2023-04-27 06:17:46 --> Controller Class Initialized
DEBUG - 2023-04-27 06:17:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:17:46 --> Database Driver Class Initialized
INFO - 2023-04-27 06:17:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:17:46 --> Final output sent to browser
DEBUG - 2023-04-27 06:17:46 --> Total execution time: 0.0113
INFO - 2023-04-27 06:18:23 --> Config Class Initialized
INFO - 2023-04-27 06:18:23 --> Config Class Initialized
INFO - 2023-04-27 06:18:23 --> Hooks Class Initialized
INFO - 2023-04-27 06:18:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:18:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:18:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:18:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:18:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:18:23 --> URI Class Initialized
INFO - 2023-04-27 06:18:23 --> URI Class Initialized
INFO - 2023-04-27 06:18:23 --> Router Class Initialized
INFO - 2023-04-27 06:18:23 --> Router Class Initialized
INFO - 2023-04-27 06:18:23 --> Output Class Initialized
INFO - 2023-04-27 06:18:23 --> Output Class Initialized
INFO - 2023-04-27 06:18:23 --> Security Class Initialized
INFO - 2023-04-27 06:18:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:18:23 --> Input Class Initialized
INFO - 2023-04-27 06:18:23 --> Input Class Initialized
INFO - 2023-04-27 06:18:23 --> Language Class Initialized
INFO - 2023-04-27 06:18:23 --> Language Class Initialized
INFO - 2023-04-27 06:18:23 --> Loader Class Initialized
INFO - 2023-04-27 06:18:23 --> Loader Class Initialized
INFO - 2023-04-27 06:18:23 --> Controller Class Initialized
INFO - 2023-04-27 06:18:23 --> Controller Class Initialized
DEBUG - 2023-04-27 06:18:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:18:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:18:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:18:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:18:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:18:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:18:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:18:23 --> Total execution time: 0.0568
INFO - 2023-04-27 06:18:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:18:23 --> Total execution time: 0.0589
INFO - 2023-04-27 06:18:23 --> Config Class Initialized
INFO - 2023-04-27 06:18:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:18:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:18:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:18:23 --> URI Class Initialized
INFO - 2023-04-27 06:18:23 --> Router Class Initialized
INFO - 2023-04-27 06:18:23 --> Output Class Initialized
INFO - 2023-04-27 06:18:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:18:23 --> Input Class Initialized
INFO - 2023-04-27 06:18:23 --> Language Class Initialized
INFO - 2023-04-27 06:18:23 --> Loader Class Initialized
INFO - 2023-04-27 06:18:23 --> Config Class Initialized
INFO - 2023-04-27 06:18:23 --> Controller Class Initialized
INFO - 2023-04-27 06:18:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:18:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:18:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:18:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:18:23 --> URI Class Initialized
INFO - 2023-04-27 06:18:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:18:23 --> Router Class Initialized
INFO - 2023-04-27 06:18:23 --> Output Class Initialized
INFO - 2023-04-27 06:18:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:18:23 --> Input Class Initialized
INFO - 2023-04-27 06:18:23 --> Language Class Initialized
INFO - 2023-04-27 06:18:23 --> Loader Class Initialized
INFO - 2023-04-27 06:18:23 --> Controller Class Initialized
DEBUG - 2023-04-27 06:18:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:18:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:18:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:18:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:18:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:18:23 --> Total execution time: 0.0148
INFO - 2023-04-27 06:18:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:18:23 --> Total execution time: 0.0149
INFO - 2023-04-27 06:19:16 --> Config Class Initialized
INFO - 2023-04-27 06:19:16 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:16 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:16 --> Config Class Initialized
INFO - 2023-04-27 06:19:17 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:17 --> URI Class Initialized
INFO - 2023-04-27 06:19:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:17 --> Router Class Initialized
INFO - 2023-04-27 06:19:17 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:17 --> URI Class Initialized
INFO - 2023-04-27 06:19:17 --> Output Class Initialized
INFO - 2023-04-27 06:19:17 --> Router Class Initialized
INFO - 2023-04-27 06:19:17 --> Security Class Initialized
INFO - 2023-04-27 06:19:17 --> Output Class Initialized
DEBUG - 2023-04-27 06:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:17 --> Input Class Initialized
INFO - 2023-04-27 06:19:17 --> Security Class Initialized
INFO - 2023-04-27 06:19:17 --> Language Class Initialized
DEBUG - 2023-04-27 06:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:17 --> Input Class Initialized
INFO - 2023-04-27 06:19:17 --> Loader Class Initialized
INFO - 2023-04-27 06:19:17 --> Language Class Initialized
INFO - 2023-04-27 06:19:17 --> Controller Class Initialized
INFO - 2023-04-27 06:19:17 --> Loader Class Initialized
DEBUG - 2023-04-27 06:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:17 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:17 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:17 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:17 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:17 --> Total execution time: 0.0735
INFO - 2023-04-27 06:19:17 --> Config Class Initialized
INFO - 2023-04-27 06:19:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:17 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:17 --> URI Class Initialized
INFO - 2023-04-27 06:19:17 --> Router Class Initialized
INFO - 2023-04-27 06:19:17 --> Output Class Initialized
INFO - 2023-04-27 06:19:17 --> Security Class Initialized
INFO - 2023-04-27 06:19:17 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:17 --> Total execution time: 0.0861
DEBUG - 2023-04-27 06:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:17 --> Input Class Initialized
INFO - 2023-04-27 06:19:17 --> Language Class Initialized
INFO - 2023-04-27 06:19:17 --> Loader Class Initialized
INFO - 2023-04-27 06:19:17 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:17 --> Config Class Initialized
INFO - 2023-04-27 06:19:17 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:17 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:17 --> URI Class Initialized
INFO - 2023-04-27 06:19:17 --> Router Class Initialized
INFO - 2023-04-27 06:19:17 --> Output Class Initialized
INFO - 2023-04-27 06:19:17 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:17 --> Input Class Initialized
INFO - 2023-04-27 06:19:17 --> Language Class Initialized
INFO - 2023-04-27 06:19:17 --> Loader Class Initialized
INFO - 2023-04-27 06:19:17 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:17 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:17 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:17 --> Total execution time: 0.0146
INFO - 2023-04-27 06:19:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:17 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:17 --> Total execution time: 0.0613
INFO - 2023-04-27 06:19:23 --> Config Class Initialized
INFO - 2023-04-27 06:19:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:23 --> URI Class Initialized
INFO - 2023-04-27 06:19:23 --> Router Class Initialized
INFO - 2023-04-27 06:19:23 --> Output Class Initialized
INFO - 2023-04-27 06:19:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:23 --> Input Class Initialized
INFO - 2023-04-27 06:19:23 --> Language Class Initialized
INFO - 2023-04-27 06:19:23 --> Loader Class Initialized
INFO - 2023-04-27 06:19:23 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:23 --> Total execution time: 0.0153
INFO - 2023-04-27 06:19:23 --> Config Class Initialized
INFO - 2023-04-27 06:19:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:23 --> URI Class Initialized
INFO - 2023-04-27 06:19:23 --> Router Class Initialized
INFO - 2023-04-27 06:19:23 --> Output Class Initialized
INFO - 2023-04-27 06:19:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:23 --> Input Class Initialized
INFO - 2023-04-27 06:19:23 --> Language Class Initialized
INFO - 2023-04-27 06:19:23 --> Loader Class Initialized
INFO - 2023-04-27 06:19:23 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:23 --> Total execution time: 0.0602
INFO - 2023-04-27 06:19:23 --> Config Class Initialized
INFO - 2023-04-27 06:19:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:23 --> URI Class Initialized
INFO - 2023-04-27 06:19:23 --> Router Class Initialized
INFO - 2023-04-27 06:19:23 --> Output Class Initialized
INFO - 2023-04-27 06:19:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:23 --> Input Class Initialized
INFO - 2023-04-27 06:19:23 --> Language Class Initialized
INFO - 2023-04-27 06:19:23 --> Loader Class Initialized
INFO - 2023-04-27 06:19:23 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:23 --> Total execution time: 0.0624
INFO - 2023-04-27 06:19:23 --> Config Class Initialized
INFO - 2023-04-27 06:19:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:23 --> URI Class Initialized
INFO - 2023-04-27 06:19:23 --> Router Class Initialized
INFO - 2023-04-27 06:19:23 --> Output Class Initialized
INFO - 2023-04-27 06:19:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:23 --> Input Class Initialized
INFO - 2023-04-27 06:19:23 --> Language Class Initialized
INFO - 2023-04-27 06:19:23 --> Loader Class Initialized
INFO - 2023-04-27 06:19:23 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:23 --> Total execution time: 0.0113
INFO - 2023-04-27 06:19:54 --> Config Class Initialized
INFO - 2023-04-27 06:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:54 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:54 --> URI Class Initialized
INFO - 2023-04-27 06:19:54 --> Router Class Initialized
INFO - 2023-04-27 06:19:54 --> Output Class Initialized
INFO - 2023-04-27 06:19:54 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:54 --> Input Class Initialized
INFO - 2023-04-27 06:19:54 --> Language Class Initialized
INFO - 2023-04-27 06:19:54 --> Loader Class Initialized
INFO - 2023-04-27 06:19:54 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:54 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:54 --> Config Class Initialized
INFO - 2023-04-27 06:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:54 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:54 --> URI Class Initialized
INFO - 2023-04-27 06:19:54 --> Router Class Initialized
INFO - 2023-04-27 06:19:54 --> Output Class Initialized
INFO - 2023-04-27 06:19:54 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:54 --> Input Class Initialized
INFO - 2023-04-27 06:19:54 --> Language Class Initialized
INFO - 2023-04-27 06:19:54 --> Loader Class Initialized
INFO - 2023-04-27 06:19:54 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:54 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:54 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:54 --> Total execution time: 0.0583
INFO - 2023-04-27 06:19:54 --> Config Class Initialized
INFO - 2023-04-27 06:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:54 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:54 --> URI Class Initialized
INFO - 2023-04-27 06:19:54 --> Router Class Initialized
INFO - 2023-04-27 06:19:54 --> Output Class Initialized
INFO - 2023-04-27 06:19:54 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:54 --> Input Class Initialized
INFO - 2023-04-27 06:19:54 --> Language Class Initialized
INFO - 2023-04-27 06:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:54 --> Loader Class Initialized
INFO - 2023-04-27 06:19:54 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:54 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:54 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:54 --> Total execution time: 0.0541
INFO - 2023-04-27 06:19:54 --> Config Class Initialized
INFO - 2023-04-27 06:19:54 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:54 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:54 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:54 --> URI Class Initialized
INFO - 2023-04-27 06:19:54 --> Router Class Initialized
INFO - 2023-04-27 06:19:54 --> Output Class Initialized
INFO - 2023-04-27 06:19:54 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:54 --> Input Class Initialized
INFO - 2023-04-27 06:19:54 --> Language Class Initialized
INFO - 2023-04-27 06:19:54 --> Loader Class Initialized
INFO - 2023-04-27 06:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:54 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:54 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:54 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:54 --> Total execution time: 0.0156
INFO - 2023-04-27 06:19:54 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:54 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:54 --> Total execution time: 0.0570
INFO - 2023-04-27 06:19:57 --> Config Class Initialized
INFO - 2023-04-27 06:19:57 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:57 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:57 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:57 --> URI Class Initialized
INFO - 2023-04-27 06:19:57 --> Router Class Initialized
INFO - 2023-04-27 06:19:57 --> Output Class Initialized
INFO - 2023-04-27 06:19:57 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:57 --> Input Class Initialized
INFO - 2023-04-27 06:19:57 --> Language Class Initialized
INFO - 2023-04-27 06:19:57 --> Loader Class Initialized
INFO - 2023-04-27 06:19:57 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:57 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:57 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:57 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:57 --> Total execution time: 0.0213
INFO - 2023-04-27 06:19:57 --> Config Class Initialized
INFO - 2023-04-27 06:19:57 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:57 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:57 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:57 --> URI Class Initialized
INFO - 2023-04-27 06:19:57 --> Router Class Initialized
INFO - 2023-04-27 06:19:57 --> Output Class Initialized
INFO - 2023-04-27 06:19:57 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:57 --> Input Class Initialized
INFO - 2023-04-27 06:19:57 --> Language Class Initialized
INFO - 2023-04-27 06:19:57 --> Loader Class Initialized
INFO - 2023-04-27 06:19:57 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:57 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:57 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:57 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:57 --> Total execution time: 0.0226
INFO - 2023-04-27 06:19:57 --> Config Class Initialized
INFO - 2023-04-27 06:19:57 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:57 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:57 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:57 --> URI Class Initialized
INFO - 2023-04-27 06:19:57 --> Router Class Initialized
INFO - 2023-04-27 06:19:57 --> Output Class Initialized
INFO - 2023-04-27 06:19:57 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:57 --> Input Class Initialized
INFO - 2023-04-27 06:19:57 --> Language Class Initialized
INFO - 2023-04-27 06:19:57 --> Loader Class Initialized
INFO - 2023-04-27 06:19:57 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:57 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:57 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:57 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:57 --> Total execution time: 0.0632
INFO - 2023-04-27 06:19:57 --> Config Class Initialized
INFO - 2023-04-27 06:19:57 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:19:57 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:19:57 --> Utf8 Class Initialized
INFO - 2023-04-27 06:19:57 --> URI Class Initialized
INFO - 2023-04-27 06:19:57 --> Router Class Initialized
INFO - 2023-04-27 06:19:57 --> Output Class Initialized
INFO - 2023-04-27 06:19:57 --> Security Class Initialized
DEBUG - 2023-04-27 06:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:19:57 --> Input Class Initialized
INFO - 2023-04-27 06:19:57 --> Language Class Initialized
INFO - 2023-04-27 06:19:57 --> Loader Class Initialized
INFO - 2023-04-27 06:19:57 --> Controller Class Initialized
DEBUG - 2023-04-27 06:19:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:19:57 --> Database Driver Class Initialized
INFO - 2023-04-27 06:19:57 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:19:57 --> Final output sent to browser
DEBUG - 2023-04-27 06:19:57 --> Total execution time: 0.0163
INFO - 2023-04-27 06:20:15 --> Config Class Initialized
INFO - 2023-04-27 06:20:15 --> Config Class Initialized
INFO - 2023-04-27 06:20:15 --> Hooks Class Initialized
INFO - 2023-04-27 06:20:15 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:20:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:20:15 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:20:15 --> Utf8 Class Initialized
INFO - 2023-04-27 06:20:15 --> Utf8 Class Initialized
INFO - 2023-04-27 06:20:15 --> URI Class Initialized
INFO - 2023-04-27 06:20:15 --> URI Class Initialized
INFO - 2023-04-27 06:20:15 --> Router Class Initialized
INFO - 2023-04-27 06:20:15 --> Router Class Initialized
INFO - 2023-04-27 06:20:15 --> Output Class Initialized
INFO - 2023-04-27 06:20:15 --> Output Class Initialized
INFO - 2023-04-27 06:20:15 --> Security Class Initialized
INFO - 2023-04-27 06:20:15 --> Security Class Initialized
DEBUG - 2023-04-27 06:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:20:15 --> Input Class Initialized
INFO - 2023-04-27 06:20:15 --> Input Class Initialized
INFO - 2023-04-27 06:20:15 --> Language Class Initialized
INFO - 2023-04-27 06:20:15 --> Language Class Initialized
INFO - 2023-04-27 06:20:15 --> Loader Class Initialized
INFO - 2023-04-27 06:20:15 --> Loader Class Initialized
INFO - 2023-04-27 06:20:15 --> Controller Class Initialized
INFO - 2023-04-27 06:20:15 --> Controller Class Initialized
DEBUG - 2023-04-27 06:20:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:20:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:20:15 --> Database Driver Class Initialized
INFO - 2023-04-27 06:20:15 --> Database Driver Class Initialized
INFO - 2023-04-27 06:20:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:20:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:20:15 --> Final output sent to browser
DEBUG - 2023-04-27 06:20:15 --> Total execution time: 0.1066
INFO - 2023-04-27 06:20:15 --> Config Class Initialized
INFO - 2023-04-27 06:20:15 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:20:15 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:20:15 --> Utf8 Class Initialized
INFO - 2023-04-27 06:20:15 --> URI Class Initialized
INFO - 2023-04-27 06:20:15 --> Router Class Initialized
INFO - 2023-04-27 06:20:15 --> Output Class Initialized
INFO - 2023-04-27 06:20:15 --> Security Class Initialized
DEBUG - 2023-04-27 06:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:20:15 --> Final output sent to browser
INFO - 2023-04-27 06:20:15 --> Input Class Initialized
DEBUG - 2023-04-27 06:20:15 --> Total execution time: 0.1087
INFO - 2023-04-27 06:20:15 --> Language Class Initialized
INFO - 2023-04-27 06:20:15 --> Loader Class Initialized
INFO - 2023-04-27 06:20:15 --> Controller Class Initialized
DEBUG - 2023-04-27 06:20:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:20:15 --> Database Driver Class Initialized
INFO - 2023-04-27 06:20:15 --> Config Class Initialized
INFO - 2023-04-27 06:20:15 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:20:15 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:20:15 --> Utf8 Class Initialized
INFO - 2023-04-27 06:20:15 --> URI Class Initialized
INFO - 2023-04-27 06:20:15 --> Router Class Initialized
INFO - 2023-04-27 06:20:15 --> Output Class Initialized
INFO - 2023-04-27 06:20:15 --> Security Class Initialized
DEBUG - 2023-04-27 06:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:20:15 --> Input Class Initialized
INFO - 2023-04-27 06:20:15 --> Language Class Initialized
INFO - 2023-04-27 06:20:15 --> Loader Class Initialized
INFO - 2023-04-27 06:20:15 --> Controller Class Initialized
DEBUG - 2023-04-27 06:20:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:20:15 --> Database Driver Class Initialized
INFO - 2023-04-27 06:20:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:20:15 --> Final output sent to browser
DEBUG - 2023-04-27 06:20:15 --> Total execution time: 0.0157
INFO - 2023-04-27 06:20:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:20:15 --> Final output sent to browser
DEBUG - 2023-04-27 06:20:15 --> Total execution time: 0.0640
INFO - 2023-04-27 06:20:33 --> Config Class Initialized
INFO - 2023-04-27 06:20:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:20:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:20:33 --> Utf8 Class Initialized
INFO - 2023-04-27 06:20:33 --> URI Class Initialized
INFO - 2023-04-27 06:20:33 --> Router Class Initialized
INFO - 2023-04-27 06:20:33 --> Output Class Initialized
INFO - 2023-04-27 06:20:33 --> Security Class Initialized
DEBUG - 2023-04-27 06:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:20:33 --> Input Class Initialized
INFO - 2023-04-27 06:20:33 --> Language Class Initialized
INFO - 2023-04-27 06:20:33 --> Loader Class Initialized
INFO - 2023-04-27 06:20:33 --> Controller Class Initialized
DEBUG - 2023-04-27 06:20:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:20:33 --> Database Driver Class Initialized
INFO - 2023-04-27 06:20:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:20:33 --> Final output sent to browser
DEBUG - 2023-04-27 06:20:33 --> Total execution time: 0.0118
INFO - 2023-04-27 06:20:33 --> Config Class Initialized
INFO - 2023-04-27 06:20:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:20:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:20:33 --> Utf8 Class Initialized
INFO - 2023-04-27 06:20:33 --> URI Class Initialized
INFO - 2023-04-27 06:20:33 --> Router Class Initialized
INFO - 2023-04-27 06:20:33 --> Output Class Initialized
INFO - 2023-04-27 06:20:33 --> Security Class Initialized
DEBUG - 2023-04-27 06:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:20:33 --> Input Class Initialized
INFO - 2023-04-27 06:20:33 --> Language Class Initialized
INFO - 2023-04-27 06:20:33 --> Loader Class Initialized
INFO - 2023-04-27 06:20:33 --> Controller Class Initialized
DEBUG - 2023-04-27 06:20:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:20:33 --> Database Driver Class Initialized
INFO - 2023-04-27 06:20:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:20:33 --> Final output sent to browser
DEBUG - 2023-04-27 06:20:33 --> Total execution time: 0.0123
INFO - 2023-04-27 06:20:33 --> Config Class Initialized
INFO - 2023-04-27 06:20:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:20:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:20:33 --> Utf8 Class Initialized
INFO - 2023-04-27 06:20:33 --> URI Class Initialized
INFO - 2023-04-27 06:20:33 --> Router Class Initialized
INFO - 2023-04-27 06:20:33 --> Output Class Initialized
INFO - 2023-04-27 06:20:33 --> Security Class Initialized
DEBUG - 2023-04-27 06:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:20:33 --> Input Class Initialized
INFO - 2023-04-27 06:20:33 --> Language Class Initialized
INFO - 2023-04-27 06:20:33 --> Loader Class Initialized
INFO - 2023-04-27 06:20:33 --> Controller Class Initialized
DEBUG - 2023-04-27 06:20:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:20:33 --> Database Driver Class Initialized
INFO - 2023-04-27 06:20:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:20:33 --> Final output sent to browser
DEBUG - 2023-04-27 06:20:33 --> Total execution time: 0.0545
INFO - 2023-04-27 06:20:33 --> Config Class Initialized
INFO - 2023-04-27 06:20:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:20:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:20:33 --> Utf8 Class Initialized
INFO - 2023-04-27 06:20:33 --> URI Class Initialized
INFO - 2023-04-27 06:20:33 --> Router Class Initialized
INFO - 2023-04-27 06:20:33 --> Output Class Initialized
INFO - 2023-04-27 06:20:33 --> Security Class Initialized
DEBUG - 2023-04-27 06:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:20:33 --> Input Class Initialized
INFO - 2023-04-27 06:20:33 --> Language Class Initialized
INFO - 2023-04-27 06:20:33 --> Loader Class Initialized
INFO - 2023-04-27 06:20:33 --> Controller Class Initialized
DEBUG - 2023-04-27 06:20:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:20:33 --> Database Driver Class Initialized
INFO - 2023-04-27 06:20:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:20:33 --> Final output sent to browser
DEBUG - 2023-04-27 06:20:33 --> Total execution time: 0.0111
INFO - 2023-04-27 06:21:23 --> Config Class Initialized
INFO - 2023-04-27 06:21:23 --> Config Class Initialized
INFO - 2023-04-27 06:21:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:21:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:21:23 --> Hooks Class Initialized
INFO - 2023-04-27 06:21:23 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:21:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:21:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:21:23 --> URI Class Initialized
INFO - 2023-04-27 06:21:23 --> URI Class Initialized
INFO - 2023-04-27 06:21:23 --> Router Class Initialized
INFO - 2023-04-27 06:21:23 --> Router Class Initialized
INFO - 2023-04-27 06:21:23 --> Output Class Initialized
INFO - 2023-04-27 06:21:23 --> Output Class Initialized
INFO - 2023-04-27 06:21:23 --> Security Class Initialized
INFO - 2023-04-27 06:21:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:21:23 --> Input Class Initialized
DEBUG - 2023-04-27 06:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:21:23 --> Language Class Initialized
INFO - 2023-04-27 06:21:23 --> Input Class Initialized
INFO - 2023-04-27 06:21:23 --> Language Class Initialized
INFO - 2023-04-27 06:21:23 --> Loader Class Initialized
INFO - 2023-04-27 06:21:23 --> Loader Class Initialized
INFO - 2023-04-27 06:21:23 --> Controller Class Initialized
INFO - 2023-04-27 06:21:23 --> Controller Class Initialized
DEBUG - 2023-04-27 06:21:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:21:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:21:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:21:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:21:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:21:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:21:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:21:23 --> Total execution time: 0.1404
INFO - 2023-04-27 06:21:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:21:23 --> Total execution time: 0.1414
INFO - 2023-04-27 06:21:23 --> Config Class Initialized
INFO - 2023-04-27 06:21:23 --> Config Class Initialized
INFO - 2023-04-27 06:21:23 --> Hooks Class Initialized
INFO - 2023-04-27 06:21:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:21:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:21:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:21:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:21:23 --> Utf8 Class Initialized
INFO - 2023-04-27 06:21:23 --> URI Class Initialized
INFO - 2023-04-27 06:21:23 --> URI Class Initialized
INFO - 2023-04-27 06:21:23 --> Router Class Initialized
INFO - 2023-04-27 06:21:23 --> Router Class Initialized
INFO - 2023-04-27 06:21:23 --> Output Class Initialized
INFO - 2023-04-27 06:21:23 --> Output Class Initialized
INFO - 2023-04-27 06:21:23 --> Security Class Initialized
INFO - 2023-04-27 06:21:23 --> Security Class Initialized
DEBUG - 2023-04-27 06:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:21:23 --> Input Class Initialized
INFO - 2023-04-27 06:21:23 --> Input Class Initialized
INFO - 2023-04-27 06:21:23 --> Language Class Initialized
INFO - 2023-04-27 06:21:23 --> Language Class Initialized
INFO - 2023-04-27 06:21:23 --> Loader Class Initialized
INFO - 2023-04-27 06:21:23 --> Loader Class Initialized
INFO - 2023-04-27 06:21:23 --> Controller Class Initialized
INFO - 2023-04-27 06:21:23 --> Controller Class Initialized
DEBUG - 2023-04-27 06:21:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:21:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:21:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:21:23 --> Database Driver Class Initialized
INFO - 2023-04-27 06:21:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:21:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:21:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:21:23 --> Total execution time: 0.0156
INFO - 2023-04-27 06:21:23 --> Final output sent to browser
DEBUG - 2023-04-27 06:21:23 --> Total execution time: 0.0180
INFO - 2023-04-27 06:21:26 --> Config Class Initialized
INFO - 2023-04-27 06:21:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:21:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:21:26 --> Utf8 Class Initialized
INFO - 2023-04-27 06:21:26 --> URI Class Initialized
INFO - 2023-04-27 06:21:26 --> Router Class Initialized
INFO - 2023-04-27 06:21:26 --> Output Class Initialized
INFO - 2023-04-27 06:21:26 --> Security Class Initialized
DEBUG - 2023-04-27 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:21:26 --> Input Class Initialized
INFO - 2023-04-27 06:21:26 --> Language Class Initialized
INFO - 2023-04-27 06:21:26 --> Loader Class Initialized
INFO - 2023-04-27 06:21:26 --> Controller Class Initialized
DEBUG - 2023-04-27 06:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:21:26 --> Database Driver Class Initialized
INFO - 2023-04-27 06:21:26 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:21:26 --> Final output sent to browser
DEBUG - 2023-04-27 06:21:26 --> Total execution time: 0.0136
INFO - 2023-04-27 06:21:26 --> Config Class Initialized
INFO - 2023-04-27 06:21:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:21:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:21:26 --> Utf8 Class Initialized
INFO - 2023-04-27 06:21:26 --> URI Class Initialized
INFO - 2023-04-27 06:21:26 --> Router Class Initialized
INFO - 2023-04-27 06:21:26 --> Output Class Initialized
INFO - 2023-04-27 06:21:26 --> Security Class Initialized
DEBUG - 2023-04-27 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:21:26 --> Input Class Initialized
INFO - 2023-04-27 06:21:26 --> Language Class Initialized
INFO - 2023-04-27 06:21:26 --> Loader Class Initialized
INFO - 2023-04-27 06:21:26 --> Controller Class Initialized
DEBUG - 2023-04-27 06:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:21:26 --> Database Driver Class Initialized
INFO - 2023-04-27 06:21:26 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:21:26 --> Final output sent to browser
DEBUG - 2023-04-27 06:21:26 --> Total execution time: 0.0110
INFO - 2023-04-27 06:21:26 --> Config Class Initialized
INFO - 2023-04-27 06:21:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:21:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:21:26 --> Utf8 Class Initialized
INFO - 2023-04-27 06:21:26 --> URI Class Initialized
INFO - 2023-04-27 06:21:26 --> Router Class Initialized
INFO - 2023-04-27 06:21:26 --> Output Class Initialized
INFO - 2023-04-27 06:21:26 --> Security Class Initialized
DEBUG - 2023-04-27 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:21:26 --> Input Class Initialized
INFO - 2023-04-27 06:21:26 --> Language Class Initialized
INFO - 2023-04-27 06:21:26 --> Loader Class Initialized
INFO - 2023-04-27 06:21:26 --> Controller Class Initialized
DEBUG - 2023-04-27 06:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:21:26 --> Database Driver Class Initialized
INFO - 2023-04-27 06:21:26 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:21:26 --> Final output sent to browser
DEBUG - 2023-04-27 06:21:26 --> Total execution time: 0.0539
INFO - 2023-04-27 06:21:26 --> Config Class Initialized
INFO - 2023-04-27 06:21:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:21:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:21:26 --> Utf8 Class Initialized
INFO - 2023-04-27 06:21:26 --> URI Class Initialized
INFO - 2023-04-27 06:21:26 --> Router Class Initialized
INFO - 2023-04-27 06:21:26 --> Output Class Initialized
INFO - 2023-04-27 06:21:26 --> Security Class Initialized
DEBUG - 2023-04-27 06:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:21:26 --> Input Class Initialized
INFO - 2023-04-27 06:21:26 --> Language Class Initialized
INFO - 2023-04-27 06:21:26 --> Loader Class Initialized
INFO - 2023-04-27 06:21:26 --> Controller Class Initialized
DEBUG - 2023-04-27 06:21:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:21:26 --> Database Driver Class Initialized
INFO - 2023-04-27 06:21:26 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:21:26 --> Final output sent to browser
DEBUG - 2023-04-27 06:21:26 --> Total execution time: 0.0109
INFO - 2023-04-27 06:51:47 --> Config Class Initialized
INFO - 2023-04-27 06:51:47 --> Config Class Initialized
INFO - 2023-04-27 06:51:47 --> Hooks Class Initialized
INFO - 2023-04-27 06:51:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:51:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:51:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:51:47 --> Utf8 Class Initialized
INFO - 2023-04-27 06:51:47 --> Utf8 Class Initialized
INFO - 2023-04-27 06:51:47 --> URI Class Initialized
INFO - 2023-04-27 06:51:47 --> URI Class Initialized
INFO - 2023-04-27 06:51:47 --> Router Class Initialized
INFO - 2023-04-27 06:51:47 --> Router Class Initialized
INFO - 2023-04-27 06:51:47 --> Output Class Initialized
INFO - 2023-04-27 06:51:47 --> Output Class Initialized
INFO - 2023-04-27 06:51:47 --> Security Class Initialized
INFO - 2023-04-27 06:51:47 --> Security Class Initialized
DEBUG - 2023-04-27 06:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:51:47 --> Input Class Initialized
INFO - 2023-04-27 06:51:47 --> Input Class Initialized
INFO - 2023-04-27 06:51:47 --> Language Class Initialized
INFO - 2023-04-27 06:51:47 --> Language Class Initialized
INFO - 2023-04-27 06:51:47 --> Loader Class Initialized
INFO - 2023-04-27 06:51:47 --> Loader Class Initialized
INFO - 2023-04-27 06:51:47 --> Controller Class Initialized
INFO - 2023-04-27 06:51:47 --> Controller Class Initialized
DEBUG - 2023-04-27 06:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:51:47 --> Database Driver Class Initialized
INFO - 2023-04-27 06:51:47 --> Database Driver Class Initialized
INFO - 2023-04-27 06:51:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:51:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:51:47 --> Final output sent to browser
DEBUG - 2023-04-27 06:51:47 --> Total execution time: 0.0331
INFO - 2023-04-27 06:51:47 --> Final output sent to browser
INFO - 2023-04-27 06:51:47 --> Config Class Initialized
INFO - 2023-04-27 06:51:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:51:47 --> Total execution time: 0.0379
DEBUG - 2023-04-27 06:51:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:51:47 --> Utf8 Class Initialized
INFO - 2023-04-27 06:51:47 --> URI Class Initialized
INFO - 2023-04-27 06:51:47 --> Router Class Initialized
INFO - 2023-04-27 06:51:47 --> Output Class Initialized
INFO - 2023-04-27 06:51:47 --> Security Class Initialized
DEBUG - 2023-04-27 06:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:51:47 --> Input Class Initialized
INFO - 2023-04-27 06:51:47 --> Language Class Initialized
INFO - 2023-04-27 06:51:47 --> Loader Class Initialized
INFO - 2023-04-27 06:51:47 --> Controller Class Initialized
INFO - 2023-04-27 06:51:47 --> Config Class Initialized
DEBUG - 2023-04-27 06:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:51:47 --> Hooks Class Initialized
INFO - 2023-04-27 06:51:47 --> Database Driver Class Initialized
DEBUG - 2023-04-27 06:51:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:51:47 --> Utf8 Class Initialized
INFO - 2023-04-27 06:51:47 --> URI Class Initialized
INFO - 2023-04-27 06:51:47 --> Router Class Initialized
INFO - 2023-04-27 06:51:47 --> Output Class Initialized
INFO - 2023-04-27 06:51:47 --> Security Class Initialized
DEBUG - 2023-04-27 06:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:51:47 --> Input Class Initialized
INFO - 2023-04-27 06:51:47 --> Language Class Initialized
INFO - 2023-04-27 06:51:47 --> Loader Class Initialized
INFO - 2023-04-27 06:51:47 --> Controller Class Initialized
DEBUG - 2023-04-27 06:51:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:51:47 --> Database Driver Class Initialized
INFO - 2023-04-27 06:51:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:51:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:51:47 --> Final output sent to browser
DEBUG - 2023-04-27 06:51:47 --> Total execution time: 0.0496
INFO - 2023-04-27 06:51:47 --> Final output sent to browser
DEBUG - 2023-04-27 06:51:47 --> Total execution time: 0.0141
INFO - 2023-04-27 06:52:10 --> Config Class Initialized
INFO - 2023-04-27 06:52:10 --> Config Class Initialized
INFO - 2023-04-27 06:52:10 --> Hooks Class Initialized
INFO - 2023-04-27 06:52:10 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:52:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:52:10 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:52:10 --> Utf8 Class Initialized
INFO - 2023-04-27 06:52:10 --> Utf8 Class Initialized
INFO - 2023-04-27 06:52:10 --> URI Class Initialized
INFO - 2023-04-27 06:52:10 --> URI Class Initialized
INFO - 2023-04-27 06:52:10 --> Router Class Initialized
INFO - 2023-04-27 06:52:10 --> Router Class Initialized
INFO - 2023-04-27 06:52:10 --> Output Class Initialized
INFO - 2023-04-27 06:52:10 --> Output Class Initialized
INFO - 2023-04-27 06:52:10 --> Security Class Initialized
INFO - 2023-04-27 06:52:10 --> Security Class Initialized
DEBUG - 2023-04-27 06:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:52:10 --> Input Class Initialized
INFO - 2023-04-27 06:52:10 --> Input Class Initialized
INFO - 2023-04-27 06:52:10 --> Language Class Initialized
INFO - 2023-04-27 06:52:10 --> Language Class Initialized
INFO - 2023-04-27 06:52:10 --> Loader Class Initialized
INFO - 2023-04-27 06:52:10 --> Loader Class Initialized
INFO - 2023-04-27 06:52:10 --> Controller Class Initialized
INFO - 2023-04-27 06:52:10 --> Controller Class Initialized
DEBUG - 2023-04-27 06:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:52:10 --> Database Driver Class Initialized
INFO - 2023-04-27 06:52:10 --> Database Driver Class Initialized
INFO - 2023-04-27 06:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:52:10 --> Final output sent to browser
DEBUG - 2023-04-27 06:52:10 --> Total execution time: 0.0601
INFO - 2023-04-27 06:52:10 --> Config Class Initialized
INFO - 2023-04-27 06:52:10 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:52:10 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:52:10 --> Final output sent to browser
INFO - 2023-04-27 06:52:10 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:52:10 --> Total execution time: 0.0629
INFO - 2023-04-27 06:52:10 --> URI Class Initialized
INFO - 2023-04-27 06:52:10 --> Router Class Initialized
INFO - 2023-04-27 06:52:10 --> Output Class Initialized
INFO - 2023-04-27 06:52:10 --> Security Class Initialized
DEBUG - 2023-04-27 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:52:10 --> Input Class Initialized
INFO - 2023-04-27 06:52:10 --> Language Class Initialized
INFO - 2023-04-27 06:52:10 --> Loader Class Initialized
INFO - 2023-04-27 06:52:10 --> Config Class Initialized
INFO - 2023-04-27 06:52:10 --> Hooks Class Initialized
INFO - 2023-04-27 06:52:10 --> Controller Class Initialized
DEBUG - 2023-04-27 06:52:10 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:52:10 --> Utf8 Class Initialized
INFO - 2023-04-27 06:52:10 --> Database Driver Class Initialized
INFO - 2023-04-27 06:52:10 --> URI Class Initialized
INFO - 2023-04-27 06:52:10 --> Router Class Initialized
INFO - 2023-04-27 06:52:10 --> Output Class Initialized
INFO - 2023-04-27 06:52:10 --> Security Class Initialized
DEBUG - 2023-04-27 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:52:10 --> Input Class Initialized
INFO - 2023-04-27 06:52:10 --> Language Class Initialized
INFO - 2023-04-27 06:52:10 --> Loader Class Initialized
INFO - 2023-04-27 06:52:10 --> Controller Class Initialized
DEBUG - 2023-04-27 06:52:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:52:10 --> Database Driver Class Initialized
INFO - 2023-04-27 06:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:52:10 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:52:10 --> Final output sent to browser
DEBUG - 2023-04-27 06:52:10 --> Total execution time: 0.0589
INFO - 2023-04-27 06:52:10 --> Final output sent to browser
DEBUG - 2023-04-27 06:52:10 --> Total execution time: 0.0578
INFO - 2023-04-27 06:52:43 --> Config Class Initialized
INFO - 2023-04-27 06:52:43 --> Config Class Initialized
INFO - 2023-04-27 06:52:43 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:52:43 --> Utf8 Class Initialized
INFO - 2023-04-27 06:52:43 --> URI Class Initialized
INFO - 2023-04-27 06:52:43 --> Hooks Class Initialized
INFO - 2023-04-27 06:52:43 --> Router Class Initialized
DEBUG - 2023-04-27 06:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:52:43 --> Output Class Initialized
INFO - 2023-04-27 06:52:43 --> Security Class Initialized
INFO - 2023-04-27 06:52:43 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:52:43 --> Input Class Initialized
INFO - 2023-04-27 06:52:43 --> Language Class Initialized
INFO - 2023-04-27 06:52:43 --> URI Class Initialized
INFO - 2023-04-27 06:52:43 --> Loader Class Initialized
INFO - 2023-04-27 06:52:43 --> Router Class Initialized
INFO - 2023-04-27 06:52:43 --> Controller Class Initialized
DEBUG - 2023-04-27 06:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:52:43 --> Output Class Initialized
INFO - 2023-04-27 06:52:43 --> Database Driver Class Initialized
INFO - 2023-04-27 06:52:43 --> Security Class Initialized
DEBUG - 2023-04-27 06:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:52:43 --> Input Class Initialized
INFO - 2023-04-27 06:52:43 --> Language Class Initialized
INFO - 2023-04-27 06:52:43 --> Loader Class Initialized
INFO - 2023-04-27 06:52:43 --> Controller Class Initialized
DEBUG - 2023-04-27 06:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:52:43 --> Database Driver Class Initialized
INFO - 2023-04-27 06:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:52:43 --> Final output sent to browser
INFO - 2023-04-27 06:52:43 --> Final output sent to browser
DEBUG - 2023-04-27 06:52:43 --> Total execution time: 0.0254
DEBUG - 2023-04-27 06:52:43 --> Total execution time: 0.0222
INFO - 2023-04-27 06:52:43 --> Config Class Initialized
INFO - 2023-04-27 06:52:43 --> Hooks Class Initialized
INFO - 2023-04-27 06:52:43 --> Config Class Initialized
DEBUG - 2023-04-27 06:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:52:43 --> Utf8 Class Initialized
INFO - 2023-04-27 06:52:43 --> URI Class Initialized
INFO - 2023-04-27 06:52:43 --> Router Class Initialized
INFO - 2023-04-27 06:52:43 --> Hooks Class Initialized
INFO - 2023-04-27 06:52:43 --> Output Class Initialized
DEBUG - 2023-04-27 06:52:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:52:43 --> Utf8 Class Initialized
INFO - 2023-04-27 06:52:43 --> URI Class Initialized
INFO - 2023-04-27 06:52:43 --> Security Class Initialized
INFO - 2023-04-27 06:52:43 --> Router Class Initialized
DEBUG - 2023-04-27 06:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:52:43 --> Output Class Initialized
INFO - 2023-04-27 06:52:43 --> Input Class Initialized
INFO - 2023-04-27 06:52:43 --> Security Class Initialized
INFO - 2023-04-27 06:52:43 --> Language Class Initialized
DEBUG - 2023-04-27 06:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:52:43 --> Loader Class Initialized
INFO - 2023-04-27 06:52:43 --> Input Class Initialized
INFO - 2023-04-27 06:52:43 --> Controller Class Initialized
INFO - 2023-04-27 06:52:43 --> Language Class Initialized
DEBUG - 2023-04-27 06:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:52:43 --> Loader Class Initialized
INFO - 2023-04-27 06:52:43 --> Database Driver Class Initialized
INFO - 2023-04-27 06:52:43 --> Controller Class Initialized
DEBUG - 2023-04-27 06:52:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:52:43 --> Database Driver Class Initialized
INFO - 2023-04-27 06:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:52:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:52:43 --> Final output sent to browser
DEBUG - 2023-04-27 06:52:43 --> Total execution time: 0.0142
INFO - 2023-04-27 06:52:43 --> Final output sent to browser
DEBUG - 2023-04-27 06:52:43 --> Total execution time: 0.0171
INFO - 2023-04-27 06:54:07 --> Config Class Initialized
INFO - 2023-04-27 06:54:07 --> Config Class Initialized
INFO - 2023-04-27 06:54:07 --> Hooks Class Initialized
INFO - 2023-04-27 06:54:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:54:07 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:54:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:07 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:07 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:07 --> URI Class Initialized
INFO - 2023-04-27 06:54:07 --> URI Class Initialized
INFO - 2023-04-27 06:54:07 --> Router Class Initialized
INFO - 2023-04-27 06:54:07 --> Router Class Initialized
INFO - 2023-04-27 06:54:07 --> Output Class Initialized
INFO - 2023-04-27 06:54:07 --> Output Class Initialized
INFO - 2023-04-27 06:54:07 --> Security Class Initialized
INFO - 2023-04-27 06:54:07 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:07 --> Input Class Initialized
INFO - 2023-04-27 06:54:07 --> Input Class Initialized
INFO - 2023-04-27 06:54:07 --> Language Class Initialized
INFO - 2023-04-27 06:54:07 --> Language Class Initialized
INFO - 2023-04-27 06:54:07 --> Loader Class Initialized
INFO - 2023-04-27 06:54:07 --> Loader Class Initialized
INFO - 2023-04-27 06:54:07 --> Controller Class Initialized
INFO - 2023-04-27 06:54:07 --> Controller Class Initialized
DEBUG - 2023-04-27 06:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:07 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:07 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:07 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:07 --> Total execution time: 0.0610
INFO - 2023-04-27 06:54:07 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:07 --> Total execution time: 0.0631
INFO - 2023-04-27 06:54:07 --> Config Class Initialized
INFO - 2023-04-27 06:54:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:54:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:07 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:07 --> URI Class Initialized
INFO - 2023-04-27 06:54:07 --> Router Class Initialized
INFO - 2023-04-27 06:54:07 --> Output Class Initialized
INFO - 2023-04-27 06:54:07 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:07 --> Input Class Initialized
INFO - 2023-04-27 06:54:07 --> Config Class Initialized
INFO - 2023-04-27 06:54:07 --> Language Class Initialized
INFO - 2023-04-27 06:54:07 --> Hooks Class Initialized
INFO - 2023-04-27 06:54:07 --> Loader Class Initialized
DEBUG - 2023-04-27 06:54:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:07 --> Controller Class Initialized
INFO - 2023-04-27 06:54:07 --> Utf8 Class Initialized
DEBUG - 2023-04-27 06:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:07 --> URI Class Initialized
INFO - 2023-04-27 06:54:07 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:07 --> Router Class Initialized
INFO - 2023-04-27 06:54:07 --> Output Class Initialized
INFO - 2023-04-27 06:54:07 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:07 --> Input Class Initialized
INFO - 2023-04-27 06:54:07 --> Language Class Initialized
INFO - 2023-04-27 06:54:07 --> Loader Class Initialized
INFO - 2023-04-27 06:54:07 --> Controller Class Initialized
DEBUG - 2023-04-27 06:54:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:07 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:07 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:07 --> Total execution time: 0.0151
INFO - 2023-04-27 06:54:07 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:07 --> Total execution time: 0.0171
INFO - 2023-04-27 06:54:25 --> Config Class Initialized
INFO - 2023-04-27 06:54:25 --> Config Class Initialized
INFO - 2023-04-27 06:54:25 --> Hooks Class Initialized
INFO - 2023-04-27 06:54:25 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:54:25 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:54:25 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:25 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:25 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:25 --> URI Class Initialized
INFO - 2023-04-27 06:54:25 --> URI Class Initialized
INFO - 2023-04-27 06:54:25 --> Router Class Initialized
INFO - 2023-04-27 06:54:25 --> Router Class Initialized
INFO - 2023-04-27 06:54:25 --> Output Class Initialized
INFO - 2023-04-27 06:54:25 --> Output Class Initialized
INFO - 2023-04-27 06:54:25 --> Security Class Initialized
INFO - 2023-04-27 06:54:25 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:25 --> Input Class Initialized
INFO - 2023-04-27 06:54:25 --> Input Class Initialized
INFO - 2023-04-27 06:54:25 --> Language Class Initialized
INFO - 2023-04-27 06:54:25 --> Language Class Initialized
INFO - 2023-04-27 06:54:25 --> Loader Class Initialized
INFO - 2023-04-27 06:54:25 --> Loader Class Initialized
INFO - 2023-04-27 06:54:25 --> Controller Class Initialized
INFO - 2023-04-27 06:54:25 --> Controller Class Initialized
DEBUG - 2023-04-27 06:54:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:54:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:25 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:25 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:25 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:25 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:25 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:25 --> Total execution time: 0.0595
INFO - 2023-04-27 06:54:25 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:25 --> Total execution time: 0.0613
INFO - 2023-04-27 06:54:25 --> Config Class Initialized
INFO - 2023-04-27 06:54:25 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:54:25 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:25 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:25 --> URI Class Initialized
INFO - 2023-04-27 06:54:25 --> Router Class Initialized
INFO - 2023-04-27 06:54:25 --> Output Class Initialized
INFO - 2023-04-27 06:54:25 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:25 --> Config Class Initialized
INFO - 2023-04-27 06:54:25 --> Input Class Initialized
INFO - 2023-04-27 06:54:25 --> Hooks Class Initialized
INFO - 2023-04-27 06:54:25 --> Language Class Initialized
DEBUG - 2023-04-27 06:54:25 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:25 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:25 --> Loader Class Initialized
INFO - 2023-04-27 06:54:25 --> URI Class Initialized
INFO - 2023-04-27 06:54:25 --> Controller Class Initialized
INFO - 2023-04-27 06:54:25 --> Router Class Initialized
DEBUG - 2023-04-27 06:54:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:25 --> Output Class Initialized
INFO - 2023-04-27 06:54:25 --> Security Class Initialized
INFO - 2023-04-27 06:54:25 --> Database Driver Class Initialized
DEBUG - 2023-04-27 06:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:25 --> Input Class Initialized
INFO - 2023-04-27 06:54:25 --> Language Class Initialized
INFO - 2023-04-27 06:54:25 --> Loader Class Initialized
INFO - 2023-04-27 06:54:25 --> Controller Class Initialized
DEBUG - 2023-04-27 06:54:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:25 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:25 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:25 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:25 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:25 --> Total execution time: 0.0162
INFO - 2023-04-27 06:54:25 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:25 --> Total execution time: 0.0164
INFO - 2023-04-27 06:54:47 --> Config Class Initialized
INFO - 2023-04-27 06:54:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:54:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:47 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:47 --> URI Class Initialized
INFO - 2023-04-27 06:54:47 --> Router Class Initialized
INFO - 2023-04-27 06:54:47 --> Output Class Initialized
INFO - 2023-04-27 06:54:47 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:47 --> Input Class Initialized
INFO - 2023-04-27 06:54:47 --> Language Class Initialized
INFO - 2023-04-27 06:54:47 --> Loader Class Initialized
INFO - 2023-04-27 06:54:47 --> Controller Class Initialized
DEBUG - 2023-04-27 06:54:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:47 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:47 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:47 --> Total execution time: 0.0154
INFO - 2023-04-27 06:54:47 --> Config Class Initialized
INFO - 2023-04-27 06:54:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:54:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:47 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:47 --> URI Class Initialized
INFO - 2023-04-27 06:54:47 --> Router Class Initialized
INFO - 2023-04-27 06:54:47 --> Output Class Initialized
INFO - 2023-04-27 06:54:47 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:47 --> Input Class Initialized
INFO - 2023-04-27 06:54:47 --> Language Class Initialized
INFO - 2023-04-27 06:54:47 --> Loader Class Initialized
INFO - 2023-04-27 06:54:47 --> Controller Class Initialized
DEBUG - 2023-04-27 06:54:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:47 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:47 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:47 --> Total execution time: 0.0105
INFO - 2023-04-27 06:54:47 --> Config Class Initialized
INFO - 2023-04-27 06:54:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:54:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:47 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:47 --> URI Class Initialized
INFO - 2023-04-27 06:54:47 --> Router Class Initialized
INFO - 2023-04-27 06:54:47 --> Output Class Initialized
INFO - 2023-04-27 06:54:47 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:47 --> Input Class Initialized
INFO - 2023-04-27 06:54:47 --> Language Class Initialized
INFO - 2023-04-27 06:54:47 --> Loader Class Initialized
INFO - 2023-04-27 06:54:47 --> Controller Class Initialized
DEBUG - 2023-04-27 06:54:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:47 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:47 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:47 --> Total execution time: 0.0529
INFO - 2023-04-27 06:54:47 --> Config Class Initialized
INFO - 2023-04-27 06:54:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:54:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:54:47 --> Utf8 Class Initialized
INFO - 2023-04-27 06:54:47 --> URI Class Initialized
INFO - 2023-04-27 06:54:47 --> Router Class Initialized
INFO - 2023-04-27 06:54:47 --> Output Class Initialized
INFO - 2023-04-27 06:54:47 --> Security Class Initialized
DEBUG - 2023-04-27 06:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:54:47 --> Input Class Initialized
INFO - 2023-04-27 06:54:47 --> Language Class Initialized
INFO - 2023-04-27 06:54:47 --> Loader Class Initialized
INFO - 2023-04-27 06:54:47 --> Controller Class Initialized
DEBUG - 2023-04-27 06:54:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:54:47 --> Database Driver Class Initialized
INFO - 2023-04-27 06:54:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:54:47 --> Final output sent to browser
DEBUG - 2023-04-27 06:54:47 --> Total execution time: 0.0108
INFO - 2023-04-27 06:55:01 --> Config Class Initialized
INFO - 2023-04-27 06:55:01 --> Config Class Initialized
INFO - 2023-04-27 06:55:01 --> Hooks Class Initialized
INFO - 2023-04-27 06:55:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:55:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:55:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:55:01 --> Utf8 Class Initialized
INFO - 2023-04-27 06:55:01 --> Utf8 Class Initialized
INFO - 2023-04-27 06:55:01 --> URI Class Initialized
INFO - 2023-04-27 06:55:01 --> URI Class Initialized
INFO - 2023-04-27 06:55:01 --> Router Class Initialized
INFO - 2023-04-27 06:55:01 --> Router Class Initialized
INFO - 2023-04-27 06:55:01 --> Output Class Initialized
INFO - 2023-04-27 06:55:01 --> Output Class Initialized
INFO - 2023-04-27 06:55:01 --> Security Class Initialized
INFO - 2023-04-27 06:55:01 --> Security Class Initialized
DEBUG - 2023-04-27 06:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 06:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:55:01 --> Input Class Initialized
INFO - 2023-04-27 06:55:01 --> Input Class Initialized
INFO - 2023-04-27 06:55:01 --> Language Class Initialized
INFO - 2023-04-27 06:55:01 --> Language Class Initialized
INFO - 2023-04-27 06:55:01 --> Loader Class Initialized
INFO - 2023-04-27 06:55:01 --> Loader Class Initialized
INFO - 2023-04-27 06:55:01 --> Controller Class Initialized
INFO - 2023-04-27 06:55:01 --> Controller Class Initialized
DEBUG - 2023-04-27 06:55:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 06:55:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:55:01 --> Database Driver Class Initialized
INFO - 2023-04-27 06:55:01 --> Database Driver Class Initialized
INFO - 2023-04-27 06:55:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:55:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:55:01 --> Final output sent to browser
INFO - 2023-04-27 06:55:01 --> Final output sent to browser
DEBUG - 2023-04-27 06:55:01 --> Total execution time: 0.1373
DEBUG - 2023-04-27 06:55:01 --> Total execution time: 0.1377
INFO - 2023-04-27 06:55:01 --> Config Class Initialized
INFO - 2023-04-27 06:55:01 --> Config Class Initialized
INFO - 2023-04-27 06:55:01 --> Hooks Class Initialized
INFO - 2023-04-27 06:55:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:55:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 06:55:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:55:01 --> Utf8 Class Initialized
INFO - 2023-04-27 06:55:01 --> Utf8 Class Initialized
INFO - 2023-04-27 06:55:01 --> URI Class Initialized
INFO - 2023-04-27 06:55:01 --> URI Class Initialized
INFO - 2023-04-27 06:55:01 --> Router Class Initialized
INFO - 2023-04-27 06:55:01 --> Output Class Initialized
INFO - 2023-04-27 06:55:01 --> Router Class Initialized
INFO - 2023-04-27 06:55:01 --> Security Class Initialized
INFO - 2023-04-27 06:55:01 --> Output Class Initialized
DEBUG - 2023-04-27 06:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:55:01 --> Security Class Initialized
INFO - 2023-04-27 06:55:01 --> Input Class Initialized
DEBUG - 2023-04-27 06:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:55:01 --> Language Class Initialized
INFO - 2023-04-27 06:55:01 --> Input Class Initialized
INFO - 2023-04-27 06:55:01 --> Language Class Initialized
INFO - 2023-04-27 06:55:01 --> Loader Class Initialized
INFO - 2023-04-27 06:55:01 --> Controller Class Initialized
INFO - 2023-04-27 06:55:01 --> Loader Class Initialized
DEBUG - 2023-04-27 06:55:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:55:01 --> Controller Class Initialized
INFO - 2023-04-27 06:55:01 --> Database Driver Class Initialized
DEBUG - 2023-04-27 06:55:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:55:01 --> Database Driver Class Initialized
INFO - 2023-04-27 06:55:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:55:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:55:01 --> Final output sent to browser
DEBUG - 2023-04-27 06:55:01 --> Total execution time: 0.0122
INFO - 2023-04-27 06:55:01 --> Final output sent to browser
DEBUG - 2023-04-27 06:55:01 --> Total execution time: 0.0140
INFO - 2023-04-27 06:55:03 --> Config Class Initialized
INFO - 2023-04-27 06:55:03 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:55:03 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:55:03 --> Utf8 Class Initialized
INFO - 2023-04-27 06:55:03 --> URI Class Initialized
INFO - 2023-04-27 06:55:03 --> Router Class Initialized
INFO - 2023-04-27 06:55:03 --> Output Class Initialized
INFO - 2023-04-27 06:55:03 --> Security Class Initialized
DEBUG - 2023-04-27 06:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:55:03 --> Input Class Initialized
INFO - 2023-04-27 06:55:03 --> Language Class Initialized
INFO - 2023-04-27 06:55:03 --> Loader Class Initialized
INFO - 2023-04-27 06:55:03 --> Controller Class Initialized
DEBUG - 2023-04-27 06:55:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:55:03 --> Database Driver Class Initialized
INFO - 2023-04-27 06:55:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:55:03 --> Final output sent to browser
DEBUG - 2023-04-27 06:55:03 --> Total execution time: 0.0255
INFO - 2023-04-27 06:55:03 --> Config Class Initialized
INFO - 2023-04-27 06:55:03 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:55:03 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:55:03 --> Utf8 Class Initialized
INFO - 2023-04-27 06:55:03 --> URI Class Initialized
INFO - 2023-04-27 06:55:03 --> Router Class Initialized
INFO - 2023-04-27 06:55:03 --> Output Class Initialized
INFO - 2023-04-27 06:55:03 --> Security Class Initialized
DEBUG - 2023-04-27 06:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:55:03 --> Input Class Initialized
INFO - 2023-04-27 06:55:03 --> Language Class Initialized
INFO - 2023-04-27 06:55:03 --> Loader Class Initialized
INFO - 2023-04-27 06:55:03 --> Controller Class Initialized
DEBUG - 2023-04-27 06:55:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:55:03 --> Database Driver Class Initialized
INFO - 2023-04-27 06:55:04 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:55:04 --> Final output sent to browser
DEBUG - 2023-04-27 06:55:04 --> Total execution time: 0.0501
INFO - 2023-04-27 06:55:04 --> Config Class Initialized
INFO - 2023-04-27 06:55:04 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:55:04 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:55:04 --> Utf8 Class Initialized
INFO - 2023-04-27 06:55:04 --> URI Class Initialized
INFO - 2023-04-27 06:55:04 --> Router Class Initialized
INFO - 2023-04-27 06:55:04 --> Output Class Initialized
INFO - 2023-04-27 06:55:04 --> Security Class Initialized
DEBUG - 2023-04-27 06:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:55:04 --> Input Class Initialized
INFO - 2023-04-27 06:55:04 --> Language Class Initialized
INFO - 2023-04-27 06:55:04 --> Loader Class Initialized
INFO - 2023-04-27 06:55:04 --> Controller Class Initialized
DEBUG - 2023-04-27 06:55:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:55:04 --> Database Driver Class Initialized
INFO - 2023-04-27 06:55:04 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:55:04 --> Final output sent to browser
DEBUG - 2023-04-27 06:55:04 --> Total execution time: 0.0190
INFO - 2023-04-27 06:55:04 --> Config Class Initialized
INFO - 2023-04-27 06:55:04 --> Hooks Class Initialized
DEBUG - 2023-04-27 06:55:04 --> UTF-8 Support Enabled
INFO - 2023-04-27 06:55:04 --> Utf8 Class Initialized
INFO - 2023-04-27 06:55:04 --> URI Class Initialized
INFO - 2023-04-27 06:55:04 --> Router Class Initialized
INFO - 2023-04-27 06:55:04 --> Output Class Initialized
INFO - 2023-04-27 06:55:04 --> Security Class Initialized
DEBUG - 2023-04-27 06:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 06:55:04 --> Input Class Initialized
INFO - 2023-04-27 06:55:04 --> Language Class Initialized
INFO - 2023-04-27 06:55:04 --> Loader Class Initialized
INFO - 2023-04-27 06:55:04 --> Controller Class Initialized
DEBUG - 2023-04-27 06:55:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 06:55:04 --> Database Driver Class Initialized
INFO - 2023-04-27 06:55:04 --> Model "Cluster_model" initialized
INFO - 2023-04-27 06:55:04 --> Final output sent to browser
DEBUG - 2023-04-27 06:55:04 --> Total execution time: 0.0114
INFO - 2023-04-27 07:09:17 --> Config Class Initialized
INFO - 2023-04-27 07:09:17 --> Config Class Initialized
INFO - 2023-04-27 07:09:17 --> Hooks Class Initialized
INFO - 2023-04-27 07:09:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:09:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:17 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:17 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:17 --> URI Class Initialized
INFO - 2023-04-27 07:09:17 --> URI Class Initialized
INFO - 2023-04-27 07:09:17 --> Router Class Initialized
INFO - 2023-04-27 07:09:17 --> Router Class Initialized
INFO - 2023-04-27 07:09:17 --> Output Class Initialized
INFO - 2023-04-27 07:09:17 --> Output Class Initialized
INFO - 2023-04-27 07:09:17 --> Security Class Initialized
INFO - 2023-04-27 07:09:17 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:17 --> Input Class Initialized
INFO - 2023-04-27 07:09:17 --> Input Class Initialized
INFO - 2023-04-27 07:09:17 --> Language Class Initialized
INFO - 2023-04-27 07:09:17 --> Language Class Initialized
INFO - 2023-04-27 07:09:17 --> Loader Class Initialized
INFO - 2023-04-27 07:09:17 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:17 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:17 --> Loader Class Initialized
INFO - 2023-04-27 07:09:17 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:17 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:17 --> Total execution time: 0.0078
INFO - 2023-04-27 07:09:17 --> Config Class Initialized
INFO - 2023-04-27 07:09:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:17 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:17 --> URI Class Initialized
INFO - 2023-04-27 07:09:17 --> Router Class Initialized
INFO - 2023-04-27 07:09:17 --> Output Class Initialized
INFO - 2023-04-27 07:09:17 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:17 --> Input Class Initialized
INFO - 2023-04-27 07:09:17 --> Language Class Initialized
INFO - 2023-04-27 07:09:17 --> Loader Class Initialized
INFO - 2023-04-27 07:09:17 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:17 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:17 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:17 --> Total execution time: 0.0571
INFO - 2023-04-27 07:09:17 --> Config Class Initialized
INFO - 2023-04-27 07:09:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:17 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:17 --> URI Class Initialized
INFO - 2023-04-27 07:09:17 --> Model "Login_model" initialized
INFO - 2023-04-27 07:09:17 --> Router Class Initialized
INFO - 2023-04-27 07:09:17 --> Output Class Initialized
INFO - 2023-04-27 07:09:17 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:17 --> Input Class Initialized
INFO - 2023-04-27 07:09:17 --> Language Class Initialized
INFO - 2023-04-27 07:09:17 --> Loader Class Initialized
INFO - 2023-04-27 07:09:17 --> Controller Class Initialized
INFO - 2023-04-27 07:09:17 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:09:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:17 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:17 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:17 --> Total execution time: 0.1254
INFO - 2023-04-27 07:09:17 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:17 --> Total execution time: 0.0811
INFO - 2023-04-27 07:09:19 --> Config Class Initialized
INFO - 2023-04-27 07:09:19 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:19 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:19 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:19 --> URI Class Initialized
INFO - 2023-04-27 07:09:19 --> Router Class Initialized
INFO - 2023-04-27 07:09:19 --> Output Class Initialized
INFO - 2023-04-27 07:09:19 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:19 --> Input Class Initialized
INFO - 2023-04-27 07:09:19 --> Language Class Initialized
INFO - 2023-04-27 07:09:19 --> Loader Class Initialized
INFO - 2023-04-27 07:09:19 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:19 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:19 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:19 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:19 --> Total execution time: 0.0153
INFO - 2023-04-27 07:09:19 --> Config Class Initialized
INFO - 2023-04-27 07:09:19 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:19 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:19 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:19 --> URI Class Initialized
INFO - 2023-04-27 07:09:19 --> Router Class Initialized
INFO - 2023-04-27 07:09:19 --> Output Class Initialized
INFO - 2023-04-27 07:09:19 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:19 --> Input Class Initialized
INFO - 2023-04-27 07:09:19 --> Language Class Initialized
INFO - 2023-04-27 07:09:19 --> Loader Class Initialized
INFO - 2023-04-27 07:09:19 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:19 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:19 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:19 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:19 --> Total execution time: 0.0503
INFO - 2023-04-27 07:09:21 --> Config Class Initialized
INFO - 2023-04-27 07:09:21 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:21 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:21 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:21 --> URI Class Initialized
INFO - 2023-04-27 07:09:21 --> Router Class Initialized
INFO - 2023-04-27 07:09:21 --> Output Class Initialized
INFO - 2023-04-27 07:09:21 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:21 --> Input Class Initialized
INFO - 2023-04-27 07:09:21 --> Language Class Initialized
INFO - 2023-04-27 07:09:21 --> Loader Class Initialized
INFO - 2023-04-27 07:09:21 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:21 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:21 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:21 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:21 --> Total execution time: 0.2071
INFO - 2023-04-27 07:09:21 --> Config Class Initialized
INFO - 2023-04-27 07:09:21 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:21 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:21 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:21 --> URI Class Initialized
INFO - 2023-04-27 07:09:21 --> Router Class Initialized
INFO - 2023-04-27 07:09:21 --> Output Class Initialized
INFO - 2023-04-27 07:09:21 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:21 --> Input Class Initialized
INFO - 2023-04-27 07:09:21 --> Language Class Initialized
INFO - 2023-04-27 07:09:21 --> Loader Class Initialized
INFO - 2023-04-27 07:09:21 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:21 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:21 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:21 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:21 --> Total execution time: 0.0542
INFO - 2023-04-27 07:09:27 --> Config Class Initialized
INFO - 2023-04-27 07:09:27 --> Config Class Initialized
INFO - 2023-04-27 07:09:27 --> Hooks Class Initialized
INFO - 2023-04-27 07:09:27 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:27 --> Utf8 Class Initialized
DEBUG - 2023-04-27 07:09:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:27 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:27 --> URI Class Initialized
INFO - 2023-04-27 07:09:27 --> URI Class Initialized
INFO - 2023-04-27 07:09:27 --> Router Class Initialized
INFO - 2023-04-27 07:09:27 --> Router Class Initialized
INFO - 2023-04-27 07:09:27 --> Output Class Initialized
INFO - 2023-04-27 07:09:27 --> Output Class Initialized
INFO - 2023-04-27 07:09:27 --> Security Class Initialized
INFO - 2023-04-27 07:09:27 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:27 --> Input Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:27 --> Language Class Initialized
INFO - 2023-04-27 07:09:27 --> Input Class Initialized
INFO - 2023-04-27 07:09:27 --> Language Class Initialized
INFO - 2023-04-27 07:09:27 --> Loader Class Initialized
INFO - 2023-04-27 07:09:27 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:27 --> Loader Class Initialized
INFO - 2023-04-27 07:09:27 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:27 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:27 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:27 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:27 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:27 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:27 --> Total execution time: 0.0156
INFO - 2023-04-27 07:09:27 --> Final output sent to browser
INFO - 2023-04-27 07:09:27 --> Config Class Initialized
INFO - 2023-04-27 07:09:27 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Total execution time: 0.0178
DEBUG - 2023-04-27 07:09:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:27 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:27 --> URI Class Initialized
INFO - 2023-04-27 07:09:27 --> Router Class Initialized
INFO - 2023-04-27 07:09:27 --> Output Class Initialized
INFO - 2023-04-27 07:09:27 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:27 --> Input Class Initialized
INFO - 2023-04-27 07:09:27 --> Config Class Initialized
INFO - 2023-04-27 07:09:27 --> Language Class Initialized
INFO - 2023-04-27 07:09:27 --> Hooks Class Initialized
INFO - 2023-04-27 07:09:27 --> Loader Class Initialized
DEBUG - 2023-04-27 07:09:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:27 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:27 --> URI Class Initialized
INFO - 2023-04-27 07:09:27 --> Controller Class Initialized
INFO - 2023-04-27 07:09:27 --> Router Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:27 --> Output Class Initialized
INFO - 2023-04-27 07:09:27 --> Security Class Initialized
INFO - 2023-04-27 07:09:27 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:27 --> Input Class Initialized
INFO - 2023-04-27 07:09:27 --> Language Class Initialized
INFO - 2023-04-27 07:09:27 --> Loader Class Initialized
INFO - 2023-04-27 07:09:27 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:27 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:27 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:27 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:27 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:27 --> Total execution time: 0.1370
INFO - 2023-04-27 07:09:27 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:27 --> Total execution time: 0.0964
INFO - 2023-04-27 07:09:29 --> Config Class Initialized
INFO - 2023-04-27 07:09:29 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:29 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:29 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:29 --> URI Class Initialized
INFO - 2023-04-27 07:09:29 --> Router Class Initialized
INFO - 2023-04-27 07:09:29 --> Output Class Initialized
INFO - 2023-04-27 07:09:29 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:29 --> Input Class Initialized
INFO - 2023-04-27 07:09:29 --> Language Class Initialized
INFO - 2023-04-27 07:09:29 --> Loader Class Initialized
INFO - 2023-04-27 07:09:29 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:29 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:29 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:29 --> Model "Login_model" initialized
INFO - 2023-04-27 07:09:29 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:29 --> Total execution time: 0.0262
INFO - 2023-04-27 07:09:29 --> Config Class Initialized
INFO - 2023-04-27 07:09:29 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:29 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:29 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:29 --> URI Class Initialized
INFO - 2023-04-27 07:09:29 --> Router Class Initialized
INFO - 2023-04-27 07:09:29 --> Output Class Initialized
INFO - 2023-04-27 07:09:29 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:29 --> Input Class Initialized
INFO - 2023-04-27 07:09:29 --> Language Class Initialized
INFO - 2023-04-27 07:09:29 --> Loader Class Initialized
INFO - 2023-04-27 07:09:29 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:29 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:30 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:30 --> Model "Login_model" initialized
INFO - 2023-04-27 07:09:30 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:30 --> Total execution time: 0.0616
INFO - 2023-04-27 07:09:33 --> Config Class Initialized
INFO - 2023-04-27 07:09:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:33 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:33 --> URI Class Initialized
INFO - 2023-04-27 07:09:33 --> Router Class Initialized
INFO - 2023-04-27 07:09:33 --> Output Class Initialized
INFO - 2023-04-27 07:09:33 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:33 --> Input Class Initialized
INFO - 2023-04-27 07:09:33 --> Language Class Initialized
INFO - 2023-04-27 07:09:33 --> Loader Class Initialized
INFO - 2023-04-27 07:09:33 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:33 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:33 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:33 --> Model "Login_model" initialized
INFO - 2023-04-27 07:09:33 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:33 --> Total execution time: 0.1229
INFO - 2023-04-27 07:09:38 --> Config Class Initialized
INFO - 2023-04-27 07:09:38 --> Config Class Initialized
INFO - 2023-04-27 07:09:38 --> Hooks Class Initialized
INFO - 2023-04-27 07:09:38 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:09:38 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:38 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:38 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:38 --> URI Class Initialized
INFO - 2023-04-27 07:09:38 --> URI Class Initialized
INFO - 2023-04-27 07:09:38 --> Router Class Initialized
INFO - 2023-04-27 07:09:38 --> Router Class Initialized
INFO - 2023-04-27 07:09:38 --> Output Class Initialized
INFO - 2023-04-27 07:09:38 --> Output Class Initialized
INFO - 2023-04-27 07:09:38 --> Security Class Initialized
INFO - 2023-04-27 07:09:38 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:38 --> Input Class Initialized
INFO - 2023-04-27 07:09:38 --> Input Class Initialized
INFO - 2023-04-27 07:09:38 --> Language Class Initialized
INFO - 2023-04-27 07:09:38 --> Language Class Initialized
INFO - 2023-04-27 07:09:38 --> Loader Class Initialized
INFO - 2023-04-27 07:09:38 --> Loader Class Initialized
INFO - 2023-04-27 07:09:38 --> Controller Class Initialized
INFO - 2023-04-27 07:09:38 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:09:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:38 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:38 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:38 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:38 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:38 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:38 --> Total execution time: 0.0456
INFO - 2023-04-27 07:09:38 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:38 --> Total execution time: 0.0461
INFO - 2023-04-27 07:09:38 --> Config Class Initialized
INFO - 2023-04-27 07:09:38 --> Config Class Initialized
INFO - 2023-04-27 07:09:38 --> Hooks Class Initialized
INFO - 2023-04-27 07:09:38 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:09:38 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:38 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:38 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:38 --> URI Class Initialized
INFO - 2023-04-27 07:09:38 --> URI Class Initialized
INFO - 2023-04-27 07:09:38 --> Router Class Initialized
INFO - 2023-04-27 07:09:38 --> Router Class Initialized
INFO - 2023-04-27 07:09:38 --> Output Class Initialized
INFO - 2023-04-27 07:09:38 --> Output Class Initialized
INFO - 2023-04-27 07:09:38 --> Security Class Initialized
INFO - 2023-04-27 07:09:38 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:38 --> Input Class Initialized
INFO - 2023-04-27 07:09:38 --> Input Class Initialized
INFO - 2023-04-27 07:09:38 --> Language Class Initialized
INFO - 2023-04-27 07:09:38 --> Language Class Initialized
INFO - 2023-04-27 07:09:38 --> Loader Class Initialized
INFO - 2023-04-27 07:09:38 --> Loader Class Initialized
INFO - 2023-04-27 07:09:38 --> Controller Class Initialized
INFO - 2023-04-27 07:09:38 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:09:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:38 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:38 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:38 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:38 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:38 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:38 --> Total execution time: 0.0125
INFO - 2023-04-27 07:09:38 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:38 --> Total execution time: 0.0130
INFO - 2023-04-27 07:09:41 --> Config Class Initialized
INFO - 2023-04-27 07:09:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:41 --> URI Class Initialized
INFO - 2023-04-27 07:09:41 --> Router Class Initialized
INFO - 2023-04-27 07:09:41 --> Output Class Initialized
INFO - 2023-04-27 07:09:41 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:41 --> Input Class Initialized
INFO - 2023-04-27 07:09:41 --> Language Class Initialized
INFO - 2023-04-27 07:09:41 --> Loader Class Initialized
INFO - 2023-04-27 07:09:41 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:41 --> Total execution time: 0.0132
INFO - 2023-04-27 07:09:41 --> Config Class Initialized
INFO - 2023-04-27 07:09:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:41 --> URI Class Initialized
INFO - 2023-04-27 07:09:41 --> Router Class Initialized
INFO - 2023-04-27 07:09:41 --> Output Class Initialized
INFO - 2023-04-27 07:09:41 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:41 --> Input Class Initialized
INFO - 2023-04-27 07:09:41 --> Language Class Initialized
INFO - 2023-04-27 07:09:41 --> Loader Class Initialized
INFO - 2023-04-27 07:09:41 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:41 --> Total execution time: 0.0587
INFO - 2023-04-27 07:09:41 --> Config Class Initialized
INFO - 2023-04-27 07:09:42 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:42 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:42 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:42 --> URI Class Initialized
INFO - 2023-04-27 07:09:42 --> Router Class Initialized
INFO - 2023-04-27 07:09:42 --> Output Class Initialized
INFO - 2023-04-27 07:09:42 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:42 --> Input Class Initialized
INFO - 2023-04-27 07:09:42 --> Language Class Initialized
INFO - 2023-04-27 07:09:42 --> Loader Class Initialized
INFO - 2023-04-27 07:09:42 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:42 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:42 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:42 --> Total execution time: 0.0432
INFO - 2023-04-27 07:09:42 --> Config Class Initialized
INFO - 2023-04-27 07:09:42 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:09:42 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:09:42 --> Utf8 Class Initialized
INFO - 2023-04-27 07:09:42 --> URI Class Initialized
INFO - 2023-04-27 07:09:42 --> Router Class Initialized
INFO - 2023-04-27 07:09:42 --> Output Class Initialized
INFO - 2023-04-27 07:09:42 --> Security Class Initialized
DEBUG - 2023-04-27 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:09:42 --> Input Class Initialized
INFO - 2023-04-27 07:09:42 --> Language Class Initialized
INFO - 2023-04-27 07:09:42 --> Loader Class Initialized
INFO - 2023-04-27 07:09:42 --> Controller Class Initialized
DEBUG - 2023-04-27 07:09:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:09:42 --> Database Driver Class Initialized
INFO - 2023-04-27 07:09:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:09:42 --> Final output sent to browser
DEBUG - 2023-04-27 07:09:42 --> Total execution time: 0.0947
INFO - 2023-04-27 07:15:24 --> Config Class Initialized
INFO - 2023-04-27 07:15:24 --> Config Class Initialized
INFO - 2023-04-27 07:15:24 --> Hooks Class Initialized
INFO - 2023-04-27 07:15:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:15:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:15:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:15:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:15:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:15:24 --> URI Class Initialized
INFO - 2023-04-27 07:15:24 --> URI Class Initialized
INFO - 2023-04-27 07:15:24 --> Router Class Initialized
INFO - 2023-04-27 07:15:24 --> Router Class Initialized
INFO - 2023-04-27 07:15:24 --> Output Class Initialized
INFO - 2023-04-27 07:15:24 --> Output Class Initialized
INFO - 2023-04-27 07:15:24 --> Security Class Initialized
INFO - 2023-04-27 07:15:24 --> Security Class Initialized
DEBUG - 2023-04-27 07:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:15:24 --> Input Class Initialized
INFO - 2023-04-27 07:15:24 --> Input Class Initialized
INFO - 2023-04-27 07:15:24 --> Language Class Initialized
INFO - 2023-04-27 07:15:24 --> Language Class Initialized
INFO - 2023-04-27 07:15:24 --> Loader Class Initialized
INFO - 2023-04-27 07:15:24 --> Controller Class Initialized
INFO - 2023-04-27 07:15:24 --> Loader Class Initialized
DEBUG - 2023-04-27 07:15:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:15:24 --> Controller Class Initialized
DEBUG - 2023-04-27 07:15:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:15:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:15:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:15:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:15:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:15:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:15:24 --> Total execution time: 0.0158
INFO - 2023-04-27 07:15:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:15:24 --> Total execution time: 0.0180
INFO - 2023-04-27 07:15:24 --> Config Class Initialized
INFO - 2023-04-27 07:15:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:15:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:15:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:15:24 --> URI Class Initialized
INFO - 2023-04-27 07:15:24 --> Router Class Initialized
INFO - 2023-04-27 07:15:24 --> Output Class Initialized
INFO - 2023-04-27 07:15:24 --> Security Class Initialized
INFO - 2023-04-27 07:15:24 --> Config Class Initialized
DEBUG - 2023-04-27 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:15:24 --> Hooks Class Initialized
INFO - 2023-04-27 07:15:24 --> Input Class Initialized
INFO - 2023-04-27 07:15:24 --> Language Class Initialized
DEBUG - 2023-04-27 07:15:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:15:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:15:24 --> Loader Class Initialized
INFO - 2023-04-27 07:15:24 --> URI Class Initialized
INFO - 2023-04-27 07:15:24 --> Controller Class Initialized
INFO - 2023-04-27 07:15:24 --> Router Class Initialized
INFO - 2023-04-27 07:15:24 --> Output Class Initialized
INFO - 2023-04-27 07:15:24 --> Security Class Initialized
DEBUG - 2023-04-27 07:15:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:15:24 --> Input Class Initialized
INFO - 2023-04-27 07:15:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:15:24 --> Language Class Initialized
INFO - 2023-04-27 07:15:24 --> Loader Class Initialized
INFO - 2023-04-27 07:15:24 --> Controller Class Initialized
DEBUG - 2023-04-27 07:15:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:15:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:15:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:15:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:15:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:15:24 --> Total execution time: 0.0143
INFO - 2023-04-27 07:15:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:15:25 --> Total execution time: 0.0153
INFO - 2023-04-27 07:15:51 --> Config Class Initialized
INFO - 2023-04-27 07:15:51 --> Config Class Initialized
INFO - 2023-04-27 07:15:51 --> Hooks Class Initialized
INFO - 2023-04-27 07:15:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:15:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:15:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:15:51 --> Utf8 Class Initialized
INFO - 2023-04-27 07:15:51 --> Utf8 Class Initialized
INFO - 2023-04-27 07:15:51 --> URI Class Initialized
INFO - 2023-04-27 07:15:51 --> URI Class Initialized
INFO - 2023-04-27 07:15:51 --> Router Class Initialized
INFO - 2023-04-27 07:15:51 --> Router Class Initialized
INFO - 2023-04-27 07:15:51 --> Output Class Initialized
INFO - 2023-04-27 07:15:51 --> Output Class Initialized
INFO - 2023-04-27 07:15:51 --> Security Class Initialized
INFO - 2023-04-27 07:15:51 --> Security Class Initialized
DEBUG - 2023-04-27 07:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:15:51 --> Input Class Initialized
INFO - 2023-04-27 07:15:51 --> Language Class Initialized
INFO - 2023-04-27 07:15:51 --> Input Class Initialized
INFO - 2023-04-27 07:15:51 --> Language Class Initialized
INFO - 2023-04-27 07:15:51 --> Loader Class Initialized
INFO - 2023-04-27 07:15:51 --> Loader Class Initialized
INFO - 2023-04-27 07:15:51 --> Controller Class Initialized
INFO - 2023-04-27 07:15:51 --> Controller Class Initialized
DEBUG - 2023-04-27 07:15:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:15:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:15:51 --> Database Driver Class Initialized
INFO - 2023-04-27 07:15:51 --> Database Driver Class Initialized
INFO - 2023-04-27 07:15:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:15:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:15:51 --> Final output sent to browser
DEBUG - 2023-04-27 07:15:51 --> Total execution time: 0.0576
INFO - 2023-04-27 07:15:51 --> Final output sent to browser
INFO - 2023-04-27 07:15:51 --> Config Class Initialized
INFO - 2023-04-27 07:15:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:15:51 --> Total execution time: 0.0615
DEBUG - 2023-04-27 07:15:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:15:51 --> Utf8 Class Initialized
INFO - 2023-04-27 07:15:51 --> URI Class Initialized
INFO - 2023-04-27 07:15:51 --> Router Class Initialized
INFO - 2023-04-27 07:15:51 --> Output Class Initialized
INFO - 2023-04-27 07:15:51 --> Security Class Initialized
DEBUG - 2023-04-27 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:15:51 --> Input Class Initialized
INFO - 2023-04-27 07:15:51 --> Language Class Initialized
INFO - 2023-04-27 07:15:51 --> Loader Class Initialized
INFO - 2023-04-27 07:15:51 --> Controller Class Initialized
DEBUG - 2023-04-27 07:15:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:15:51 --> Database Driver Class Initialized
INFO - 2023-04-27 07:15:51 --> Config Class Initialized
INFO - 2023-04-27 07:15:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:15:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:15:51 --> Utf8 Class Initialized
INFO - 2023-04-27 07:15:51 --> URI Class Initialized
INFO - 2023-04-27 07:15:51 --> Router Class Initialized
INFO - 2023-04-27 07:15:51 --> Output Class Initialized
INFO - 2023-04-27 07:15:51 --> Security Class Initialized
DEBUG - 2023-04-27 07:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:15:51 --> Input Class Initialized
INFO - 2023-04-27 07:15:51 --> Language Class Initialized
INFO - 2023-04-27 07:15:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:15:51 --> Loader Class Initialized
INFO - 2023-04-27 07:15:51 --> Controller Class Initialized
DEBUG - 2023-04-27 07:15:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:15:51 --> Database Driver Class Initialized
INFO - 2023-04-27 07:15:51 --> Final output sent to browser
DEBUG - 2023-04-27 07:15:51 --> Total execution time: 0.0555
INFO - 2023-04-27 07:15:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:15:51 --> Final output sent to browser
DEBUG - 2023-04-27 07:15:51 --> Total execution time: 0.0618
INFO - 2023-04-27 07:16:41 --> Config Class Initialized
INFO - 2023-04-27 07:16:41 --> Config Class Initialized
INFO - 2023-04-27 07:16:41 --> Hooks Class Initialized
INFO - 2023-04-27 07:16:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:16:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:16:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:16:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:16:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:16:41 --> URI Class Initialized
INFO - 2023-04-27 07:16:41 --> URI Class Initialized
INFO - 2023-04-27 07:16:41 --> Router Class Initialized
INFO - 2023-04-27 07:16:41 --> Output Class Initialized
INFO - 2023-04-27 07:16:41 --> Router Class Initialized
INFO - 2023-04-27 07:16:41 --> Security Class Initialized
INFO - 2023-04-27 07:16:41 --> Output Class Initialized
DEBUG - 2023-04-27 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:16:41 --> Security Class Initialized
INFO - 2023-04-27 07:16:41 --> Input Class Initialized
DEBUG - 2023-04-27 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:16:41 --> Language Class Initialized
INFO - 2023-04-27 07:16:41 --> Input Class Initialized
INFO - 2023-04-27 07:16:41 --> Language Class Initialized
INFO - 2023-04-27 07:16:41 --> Loader Class Initialized
INFO - 2023-04-27 07:16:41 --> Loader Class Initialized
INFO - 2023-04-27 07:16:41 --> Controller Class Initialized
INFO - 2023-04-27 07:16:41 --> Controller Class Initialized
DEBUG - 2023-04-27 07:16:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:16:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:16:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:16:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:16:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:16:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:16:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:16:41 --> Total execution time: 0.1475
INFO - 2023-04-27 07:16:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:16:41 --> Total execution time: 0.1501
INFO - 2023-04-27 07:16:41 --> Config Class Initialized
INFO - 2023-04-27 07:16:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:16:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:16:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:16:41 --> URI Class Initialized
INFO - 2023-04-27 07:16:41 --> Router Class Initialized
INFO - 2023-04-27 07:16:41 --> Output Class Initialized
INFO - 2023-04-27 07:16:41 --> Config Class Initialized
INFO - 2023-04-27 07:16:41 --> Security Class Initialized
INFO - 2023-04-27 07:16:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:16:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:16:41 --> Input Class Initialized
INFO - 2023-04-27 07:16:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:16:41 --> Language Class Initialized
INFO - 2023-04-27 07:16:41 --> URI Class Initialized
INFO - 2023-04-27 07:16:41 --> Loader Class Initialized
INFO - 2023-04-27 07:16:41 --> Router Class Initialized
INFO - 2023-04-27 07:16:41 --> Controller Class Initialized
INFO - 2023-04-27 07:16:41 --> Output Class Initialized
DEBUG - 2023-04-27 07:16:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:16:41 --> Security Class Initialized
DEBUG - 2023-04-27 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:16:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:16:41 --> Input Class Initialized
INFO - 2023-04-27 07:16:41 --> Language Class Initialized
INFO - 2023-04-27 07:16:41 --> Loader Class Initialized
INFO - 2023-04-27 07:16:41 --> Controller Class Initialized
DEBUG - 2023-04-27 07:16:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:16:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:16:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:16:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:16:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:16:41 --> Total execution time: 0.0331
INFO - 2023-04-27 07:16:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:16:41 --> Total execution time: 0.0379
INFO - 2023-04-27 07:17:08 --> Config Class Initialized
INFO - 2023-04-27 07:17:08 --> Config Class Initialized
INFO - 2023-04-27 07:17:08 --> Hooks Class Initialized
INFO - 2023-04-27 07:17:08 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:17:08 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:17:08 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:08 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:08 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:08 --> URI Class Initialized
INFO - 2023-04-27 07:17:08 --> URI Class Initialized
INFO - 2023-04-27 07:17:08 --> Router Class Initialized
INFO - 2023-04-27 07:17:08 --> Router Class Initialized
INFO - 2023-04-27 07:17:08 --> Output Class Initialized
INFO - 2023-04-27 07:17:08 --> Output Class Initialized
INFO - 2023-04-27 07:17:08 --> Security Class Initialized
INFO - 2023-04-27 07:17:08 --> Security Class Initialized
DEBUG - 2023-04-27 07:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:08 --> Input Class Initialized
INFO - 2023-04-27 07:17:08 --> Input Class Initialized
INFO - 2023-04-27 07:17:08 --> Language Class Initialized
INFO - 2023-04-27 07:17:08 --> Language Class Initialized
INFO - 2023-04-27 07:17:08 --> Loader Class Initialized
INFO - 2023-04-27 07:17:08 --> Loader Class Initialized
INFO - 2023-04-27 07:17:08 --> Controller Class Initialized
INFO - 2023-04-27 07:17:08 --> Controller Class Initialized
DEBUG - 2023-04-27 07:17:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:17:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:08 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:08 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:08 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:08 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:08 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:08 --> Total execution time: 0.0309
INFO - 2023-04-27 07:17:08 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:08 --> Total execution time: 0.0328
INFO - 2023-04-27 07:17:08 --> Config Class Initialized
INFO - 2023-04-27 07:17:08 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:17:08 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:08 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:08 --> URI Class Initialized
INFO - 2023-04-27 07:17:08 --> Router Class Initialized
INFO - 2023-04-27 07:17:08 --> Output Class Initialized
INFO - 2023-04-27 07:17:08 --> Security Class Initialized
DEBUG - 2023-04-27 07:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:08 --> Input Class Initialized
INFO - 2023-04-27 07:17:08 --> Config Class Initialized
INFO - 2023-04-27 07:17:08 --> Language Class Initialized
INFO - 2023-04-27 07:17:08 --> Hooks Class Initialized
INFO - 2023-04-27 07:17:08 --> Loader Class Initialized
DEBUG - 2023-04-27 07:17:08 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:08 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:08 --> Controller Class Initialized
INFO - 2023-04-27 07:17:08 --> URI Class Initialized
DEBUG - 2023-04-27 07:17:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:08 --> Router Class Initialized
INFO - 2023-04-27 07:17:08 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:08 --> Output Class Initialized
INFO - 2023-04-27 07:17:08 --> Security Class Initialized
DEBUG - 2023-04-27 07:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:08 --> Input Class Initialized
INFO - 2023-04-27 07:17:08 --> Language Class Initialized
INFO - 2023-04-27 07:17:08 --> Loader Class Initialized
INFO - 2023-04-27 07:17:08 --> Controller Class Initialized
DEBUG - 2023-04-27 07:17:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:08 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:08 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:08 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:08 --> Total execution time: 0.0126
INFO - 2023-04-27 07:17:08 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:08 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:08 --> Total execution time: 0.0147
INFO - 2023-04-27 07:17:24 --> Config Class Initialized
INFO - 2023-04-27 07:17:24 --> Config Class Initialized
INFO - 2023-04-27 07:17:24 --> Hooks Class Initialized
INFO - 2023-04-27 07:17:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:17:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:24 --> Utf8 Class Initialized
DEBUG - 2023-04-27 07:17:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:24 --> URI Class Initialized
INFO - 2023-04-27 07:17:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:24 --> URI Class Initialized
INFO - 2023-04-27 07:17:24 --> Router Class Initialized
INFO - 2023-04-27 07:17:24 --> Output Class Initialized
INFO - 2023-04-27 07:17:24 --> Security Class Initialized
INFO - 2023-04-27 07:17:24 --> Router Class Initialized
INFO - 2023-04-27 07:17:24 --> Output Class Initialized
INFO - 2023-04-27 07:17:24 --> Security Class Initialized
DEBUG - 2023-04-27 07:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:24 --> Input Class Initialized
DEBUG - 2023-04-27 07:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:24 --> Language Class Initialized
INFO - 2023-04-27 07:17:24 --> Input Class Initialized
INFO - 2023-04-27 07:17:24 --> Language Class Initialized
INFO - 2023-04-27 07:17:24 --> Loader Class Initialized
INFO - 2023-04-27 07:17:24 --> Loader Class Initialized
INFO - 2023-04-27 07:17:24 --> Controller Class Initialized
INFO - 2023-04-27 07:17:24 --> Controller Class Initialized
DEBUG - 2023-04-27 07:17:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:17:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:24 --> Total execution time: 0.0592
INFO - 2023-04-27 07:17:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:24 --> Total execution time: 0.0617
INFO - 2023-04-27 07:17:24 --> Config Class Initialized
INFO - 2023-04-27 07:17:24 --> Hooks Class Initialized
INFO - 2023-04-27 07:17:24 --> Config Class Initialized
DEBUG - 2023-04-27 07:17:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:24 --> Hooks Class Initialized
INFO - 2023-04-27 07:17:24 --> URI Class Initialized
DEBUG - 2023-04-27 07:17:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:24 --> Router Class Initialized
INFO - 2023-04-27 07:17:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:24 --> Output Class Initialized
INFO - 2023-04-27 07:17:24 --> URI Class Initialized
INFO - 2023-04-27 07:17:24 --> Security Class Initialized
INFO - 2023-04-27 07:17:24 --> Router Class Initialized
DEBUG - 2023-04-27 07:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:24 --> Output Class Initialized
INFO - 2023-04-27 07:17:24 --> Input Class Initialized
INFO - 2023-04-27 07:17:24 --> Security Class Initialized
INFO - 2023-04-27 07:17:24 --> Language Class Initialized
DEBUG - 2023-04-27 07:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:24 --> Loader Class Initialized
INFO - 2023-04-27 07:17:24 --> Input Class Initialized
INFO - 2023-04-27 07:17:24 --> Controller Class Initialized
INFO - 2023-04-27 07:17:24 --> Language Class Initialized
DEBUG - 2023-04-27 07:17:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:24 --> Loader Class Initialized
INFO - 2023-04-27 07:17:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:24 --> Controller Class Initialized
DEBUG - 2023-04-27 07:17:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:24 --> Total execution time: 0.1188
INFO - 2023-04-27 07:17:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:24 --> Total execution time: 0.1049
INFO - 2023-04-27 07:17:29 --> Config Class Initialized
INFO - 2023-04-27 07:17:29 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:17:29 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:29 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:29 --> URI Class Initialized
INFO - 2023-04-27 07:17:29 --> Router Class Initialized
INFO - 2023-04-27 07:17:29 --> Output Class Initialized
INFO - 2023-04-27 07:17:29 --> Security Class Initialized
DEBUG - 2023-04-27 07:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:29 --> Input Class Initialized
INFO - 2023-04-27 07:17:29 --> Language Class Initialized
INFO - 2023-04-27 07:17:29 --> Loader Class Initialized
INFO - 2023-04-27 07:17:29 --> Controller Class Initialized
DEBUG - 2023-04-27 07:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:29 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:29 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:29 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:29 --> Total execution time: 0.0145
INFO - 2023-04-27 07:17:29 --> Config Class Initialized
INFO - 2023-04-27 07:17:29 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:17:29 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:29 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:29 --> URI Class Initialized
INFO - 2023-04-27 07:17:29 --> Router Class Initialized
INFO - 2023-04-27 07:17:29 --> Output Class Initialized
INFO - 2023-04-27 07:17:29 --> Security Class Initialized
DEBUG - 2023-04-27 07:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:29 --> Input Class Initialized
INFO - 2023-04-27 07:17:29 --> Language Class Initialized
INFO - 2023-04-27 07:17:29 --> Loader Class Initialized
INFO - 2023-04-27 07:17:29 --> Controller Class Initialized
DEBUG - 2023-04-27 07:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:29 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:29 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:29 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:29 --> Total execution time: 0.0129
INFO - 2023-04-27 07:17:29 --> Config Class Initialized
INFO - 2023-04-27 07:17:30 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:17:30 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:30 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:30 --> URI Class Initialized
INFO - 2023-04-27 07:17:30 --> Router Class Initialized
INFO - 2023-04-27 07:17:30 --> Output Class Initialized
INFO - 2023-04-27 07:17:30 --> Security Class Initialized
DEBUG - 2023-04-27 07:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:30 --> Input Class Initialized
INFO - 2023-04-27 07:17:30 --> Language Class Initialized
INFO - 2023-04-27 07:17:30 --> Loader Class Initialized
INFO - 2023-04-27 07:17:30 --> Controller Class Initialized
DEBUG - 2023-04-27 07:17:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:30 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:30 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:30 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:30 --> Total execution time: 0.0506
INFO - 2023-04-27 07:17:30 --> Config Class Initialized
INFO - 2023-04-27 07:17:30 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:17:30 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:17:30 --> Utf8 Class Initialized
INFO - 2023-04-27 07:17:30 --> URI Class Initialized
INFO - 2023-04-27 07:17:30 --> Router Class Initialized
INFO - 2023-04-27 07:17:30 --> Output Class Initialized
INFO - 2023-04-27 07:17:30 --> Security Class Initialized
DEBUG - 2023-04-27 07:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:17:30 --> Input Class Initialized
INFO - 2023-04-27 07:17:30 --> Language Class Initialized
INFO - 2023-04-27 07:17:30 --> Loader Class Initialized
INFO - 2023-04-27 07:17:30 --> Controller Class Initialized
DEBUG - 2023-04-27 07:17:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:17:30 --> Database Driver Class Initialized
INFO - 2023-04-27 07:17:30 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:17:30 --> Final output sent to browser
DEBUG - 2023-04-27 07:17:30 --> Total execution time: 0.0566
INFO - 2023-04-27 07:18:18 --> Config Class Initialized
INFO - 2023-04-27 07:18:18 --> Config Class Initialized
INFO - 2023-04-27 07:18:18 --> Hooks Class Initialized
INFO - 2023-04-27 07:18:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:18:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:18:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:18:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:18:18 --> URI Class Initialized
INFO - 2023-04-27 07:18:18 --> URI Class Initialized
INFO - 2023-04-27 07:18:18 --> Router Class Initialized
INFO - 2023-04-27 07:18:18 --> Router Class Initialized
INFO - 2023-04-27 07:18:18 --> Output Class Initialized
INFO - 2023-04-27 07:18:18 --> Output Class Initialized
INFO - 2023-04-27 07:18:18 --> Security Class Initialized
INFO - 2023-04-27 07:18:18 --> Security Class Initialized
DEBUG - 2023-04-27 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:18:18 --> Input Class Initialized
INFO - 2023-04-27 07:18:18 --> Input Class Initialized
INFO - 2023-04-27 07:18:18 --> Language Class Initialized
INFO - 2023-04-27 07:18:18 --> Language Class Initialized
INFO - 2023-04-27 07:18:18 --> Loader Class Initialized
INFO - 2023-04-27 07:18:18 --> Loader Class Initialized
INFO - 2023-04-27 07:18:18 --> Controller Class Initialized
INFO - 2023-04-27 07:18:18 --> Controller Class Initialized
DEBUG - 2023-04-27 07:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:18:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:18:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:18:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:18:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:18:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:18:18 --> Total execution time: 0.0198
INFO - 2023-04-27 07:18:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:18:18 --> Total execution time: 0.0226
INFO - 2023-04-27 07:18:18 --> Config Class Initialized
INFO - 2023-04-27 07:18:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:18:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:18:18 --> Config Class Initialized
INFO - 2023-04-27 07:18:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:18:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:18:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:18:18 --> URI Class Initialized
INFO - 2023-04-27 07:18:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:18:18 --> Router Class Initialized
INFO - 2023-04-27 07:18:18 --> URI Class Initialized
INFO - 2023-04-27 07:18:18 --> Output Class Initialized
INFO - 2023-04-27 07:18:18 --> Security Class Initialized
INFO - 2023-04-27 07:18:18 --> Router Class Initialized
DEBUG - 2023-04-27 07:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:18:18 --> Output Class Initialized
INFO - 2023-04-27 07:18:18 --> Input Class Initialized
INFO - 2023-04-27 07:18:18 --> Security Class Initialized
INFO - 2023-04-27 07:18:18 --> Language Class Initialized
DEBUG - 2023-04-27 07:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:18:18 --> Loader Class Initialized
INFO - 2023-04-27 07:18:18 --> Input Class Initialized
INFO - 2023-04-27 07:18:18 --> Language Class Initialized
INFO - 2023-04-27 07:18:18 --> Controller Class Initialized
INFO - 2023-04-27 07:18:18 --> Loader Class Initialized
INFO - 2023-04-27 07:18:18 --> Controller Class Initialized
DEBUG - 2023-04-27 07:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:18:18 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:18:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:18:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:18:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:18:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:18:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:18:18 --> Total execution time: 0.0961
INFO - 2023-04-27 07:18:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:18:18 --> Total execution time: 0.1012
INFO - 2023-04-27 07:18:24 --> Config Class Initialized
INFO - 2023-04-27 07:18:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:18:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:18:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:18:24 --> URI Class Initialized
INFO - 2023-04-27 07:18:24 --> Router Class Initialized
INFO - 2023-04-27 07:18:24 --> Output Class Initialized
INFO - 2023-04-27 07:18:24 --> Security Class Initialized
DEBUG - 2023-04-27 07:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:18:24 --> Input Class Initialized
INFO - 2023-04-27 07:18:24 --> Language Class Initialized
INFO - 2023-04-27 07:18:24 --> Loader Class Initialized
INFO - 2023-04-27 07:18:24 --> Controller Class Initialized
DEBUG - 2023-04-27 07:18:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:18:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:18:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:18:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:18:24 --> Total execution time: 0.0148
INFO - 2023-04-27 07:18:24 --> Config Class Initialized
INFO - 2023-04-27 07:18:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:18:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:18:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:18:24 --> URI Class Initialized
INFO - 2023-04-27 07:18:24 --> Router Class Initialized
INFO - 2023-04-27 07:18:24 --> Output Class Initialized
INFO - 2023-04-27 07:18:24 --> Security Class Initialized
DEBUG - 2023-04-27 07:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:18:24 --> Input Class Initialized
INFO - 2023-04-27 07:18:24 --> Language Class Initialized
INFO - 2023-04-27 07:18:24 --> Loader Class Initialized
INFO - 2023-04-27 07:18:24 --> Controller Class Initialized
DEBUG - 2023-04-27 07:18:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:18:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:18:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:18:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:18:24 --> Total execution time: 0.0116
INFO - 2023-04-27 07:18:24 --> Config Class Initialized
INFO - 2023-04-27 07:18:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:18:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:18:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:18:24 --> URI Class Initialized
INFO - 2023-04-27 07:18:24 --> Router Class Initialized
INFO - 2023-04-27 07:18:24 --> Output Class Initialized
INFO - 2023-04-27 07:18:24 --> Security Class Initialized
DEBUG - 2023-04-27 07:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:18:24 --> Input Class Initialized
INFO - 2023-04-27 07:18:24 --> Language Class Initialized
INFO - 2023-04-27 07:18:24 --> Loader Class Initialized
INFO - 2023-04-27 07:18:24 --> Controller Class Initialized
DEBUG - 2023-04-27 07:18:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:18:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:18:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:18:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:18:24 --> Total execution time: 0.0535
INFO - 2023-04-27 07:18:24 --> Config Class Initialized
INFO - 2023-04-27 07:18:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:18:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:18:24 --> Utf8 Class Initialized
INFO - 2023-04-27 07:18:24 --> URI Class Initialized
INFO - 2023-04-27 07:18:24 --> Router Class Initialized
INFO - 2023-04-27 07:18:24 --> Output Class Initialized
INFO - 2023-04-27 07:18:24 --> Security Class Initialized
DEBUG - 2023-04-27 07:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:18:24 --> Input Class Initialized
INFO - 2023-04-27 07:18:24 --> Language Class Initialized
INFO - 2023-04-27 07:18:24 --> Loader Class Initialized
INFO - 2023-04-27 07:18:24 --> Controller Class Initialized
DEBUG - 2023-04-27 07:18:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:18:24 --> Database Driver Class Initialized
INFO - 2023-04-27 07:18:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:18:24 --> Final output sent to browser
DEBUG - 2023-04-27 07:18:24 --> Total execution time: 0.0113
INFO - 2023-04-27 07:19:41 --> Config Class Initialized
INFO - 2023-04-27 07:19:41 --> Hooks Class Initialized
INFO - 2023-04-27 07:19:41 --> Config Class Initialized
INFO - 2023-04-27 07:19:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:19:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:19:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:19:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:19:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:19:41 --> URI Class Initialized
INFO - 2023-04-27 07:19:41 --> URI Class Initialized
INFO - 2023-04-27 07:19:41 --> Router Class Initialized
INFO - 2023-04-27 07:19:41 --> Router Class Initialized
INFO - 2023-04-27 07:19:41 --> Output Class Initialized
INFO - 2023-04-27 07:19:41 --> Output Class Initialized
INFO - 2023-04-27 07:19:41 --> Security Class Initialized
INFO - 2023-04-27 07:19:41 --> Security Class Initialized
DEBUG - 2023-04-27 07:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:19:41 --> Input Class Initialized
INFO - 2023-04-27 07:19:41 --> Input Class Initialized
INFO - 2023-04-27 07:19:41 --> Language Class Initialized
INFO - 2023-04-27 07:19:41 --> Language Class Initialized
INFO - 2023-04-27 07:19:41 --> Loader Class Initialized
INFO - 2023-04-27 07:19:41 --> Loader Class Initialized
INFO - 2023-04-27 07:19:41 --> Controller Class Initialized
INFO - 2023-04-27 07:19:41 --> Controller Class Initialized
DEBUG - 2023-04-27 07:19:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:19:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:19:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:19:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:19:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:19:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:19:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:19:41 --> Total execution time: 0.0606
INFO - 2023-04-27 07:19:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:19:41 --> Total execution time: 0.0638
INFO - 2023-04-27 07:19:41 --> Config Class Initialized
INFO - 2023-04-27 07:19:41 --> Config Class Initialized
INFO - 2023-04-27 07:19:41 --> Hooks Class Initialized
INFO - 2023-04-27 07:19:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:19:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:19:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:19:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:19:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:19:41 --> URI Class Initialized
INFO - 2023-04-27 07:19:41 --> URI Class Initialized
INFO - 2023-04-27 07:19:41 --> Router Class Initialized
INFO - 2023-04-27 07:19:41 --> Router Class Initialized
INFO - 2023-04-27 07:19:41 --> Output Class Initialized
INFO - 2023-04-27 07:19:41 --> Output Class Initialized
INFO - 2023-04-27 07:19:41 --> Security Class Initialized
INFO - 2023-04-27 07:19:41 --> Security Class Initialized
DEBUG - 2023-04-27 07:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:19:41 --> Input Class Initialized
INFO - 2023-04-27 07:19:41 --> Input Class Initialized
INFO - 2023-04-27 07:19:41 --> Language Class Initialized
INFO - 2023-04-27 07:19:41 --> Language Class Initialized
INFO - 2023-04-27 07:19:41 --> Loader Class Initialized
INFO - 2023-04-27 07:19:41 --> Loader Class Initialized
INFO - 2023-04-27 07:19:41 --> Controller Class Initialized
INFO - 2023-04-27 07:19:41 --> Controller Class Initialized
DEBUG - 2023-04-27 07:19:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:19:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:19:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:19:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:19:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:19:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:19:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:19:41 --> Total execution time: 0.0133
INFO - 2023-04-27 07:19:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:19:41 --> Total execution time: 0.0194
INFO - 2023-04-27 07:19:45 --> Config Class Initialized
INFO - 2023-04-27 07:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:19:45 --> Utf8 Class Initialized
INFO - 2023-04-27 07:19:45 --> URI Class Initialized
INFO - 2023-04-27 07:19:45 --> Router Class Initialized
INFO - 2023-04-27 07:19:45 --> Output Class Initialized
INFO - 2023-04-27 07:19:45 --> Security Class Initialized
DEBUG - 2023-04-27 07:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:19:45 --> Input Class Initialized
INFO - 2023-04-27 07:19:45 --> Language Class Initialized
INFO - 2023-04-27 07:19:45 --> Loader Class Initialized
INFO - 2023-04-27 07:19:45 --> Controller Class Initialized
DEBUG - 2023-04-27 07:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:19:45 --> Database Driver Class Initialized
INFO - 2023-04-27 07:19:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:19:45 --> Final output sent to browser
DEBUG - 2023-04-27 07:19:45 --> Total execution time: 0.0143
INFO - 2023-04-27 07:19:45 --> Config Class Initialized
INFO - 2023-04-27 07:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:19:45 --> Utf8 Class Initialized
INFO - 2023-04-27 07:19:45 --> URI Class Initialized
INFO - 2023-04-27 07:19:45 --> Router Class Initialized
INFO - 2023-04-27 07:19:45 --> Output Class Initialized
INFO - 2023-04-27 07:19:45 --> Security Class Initialized
DEBUG - 2023-04-27 07:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:19:45 --> Input Class Initialized
INFO - 2023-04-27 07:19:45 --> Language Class Initialized
INFO - 2023-04-27 07:19:45 --> Loader Class Initialized
INFO - 2023-04-27 07:19:45 --> Controller Class Initialized
DEBUG - 2023-04-27 07:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:19:45 --> Database Driver Class Initialized
INFO - 2023-04-27 07:19:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:19:45 --> Final output sent to browser
DEBUG - 2023-04-27 07:19:45 --> Total execution time: 0.0114
INFO - 2023-04-27 07:19:45 --> Config Class Initialized
INFO - 2023-04-27 07:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:19:45 --> Utf8 Class Initialized
INFO - 2023-04-27 07:19:45 --> URI Class Initialized
INFO - 2023-04-27 07:19:45 --> Router Class Initialized
INFO - 2023-04-27 07:19:45 --> Output Class Initialized
INFO - 2023-04-27 07:19:45 --> Security Class Initialized
DEBUG - 2023-04-27 07:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:19:45 --> Input Class Initialized
INFO - 2023-04-27 07:19:45 --> Language Class Initialized
INFO - 2023-04-27 07:19:45 --> Loader Class Initialized
INFO - 2023-04-27 07:19:45 --> Controller Class Initialized
DEBUG - 2023-04-27 07:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:19:45 --> Database Driver Class Initialized
INFO - 2023-04-27 07:19:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:19:45 --> Final output sent to browser
DEBUG - 2023-04-27 07:19:45 --> Total execution time: 0.0551
INFO - 2023-04-27 07:19:45 --> Config Class Initialized
INFO - 2023-04-27 07:19:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:19:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:19:45 --> Utf8 Class Initialized
INFO - 2023-04-27 07:19:45 --> URI Class Initialized
INFO - 2023-04-27 07:19:45 --> Router Class Initialized
INFO - 2023-04-27 07:19:45 --> Output Class Initialized
INFO - 2023-04-27 07:19:45 --> Security Class Initialized
DEBUG - 2023-04-27 07:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:19:45 --> Input Class Initialized
INFO - 2023-04-27 07:19:45 --> Language Class Initialized
INFO - 2023-04-27 07:19:45 --> Loader Class Initialized
INFO - 2023-04-27 07:19:45 --> Controller Class Initialized
DEBUG - 2023-04-27 07:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:19:45 --> Database Driver Class Initialized
INFO - 2023-04-27 07:19:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:19:45 --> Final output sent to browser
DEBUG - 2023-04-27 07:19:45 --> Total execution time: 0.0103
INFO - 2023-04-27 07:27:46 --> Config Class Initialized
INFO - 2023-04-27 07:27:46 --> Hooks Class Initialized
INFO - 2023-04-27 07:27:46 --> Config Class Initialized
DEBUG - 2023-04-27 07:27:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:27:46 --> Hooks Class Initialized
INFO - 2023-04-27 07:27:46 --> Utf8 Class Initialized
DEBUG - 2023-04-27 07:27:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:27:46 --> URI Class Initialized
INFO - 2023-04-27 07:27:46 --> Utf8 Class Initialized
INFO - 2023-04-27 07:27:46 --> URI Class Initialized
INFO - 2023-04-27 07:27:46 --> Router Class Initialized
INFO - 2023-04-27 07:27:46 --> Router Class Initialized
INFO - 2023-04-27 07:27:46 --> Output Class Initialized
INFO - 2023-04-27 07:27:46 --> Output Class Initialized
INFO - 2023-04-27 07:27:46 --> Security Class Initialized
INFO - 2023-04-27 07:27:46 --> Security Class Initialized
DEBUG - 2023-04-27 07:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:27:46 --> Input Class Initialized
INFO - 2023-04-27 07:27:46 --> Input Class Initialized
INFO - 2023-04-27 07:27:46 --> Language Class Initialized
INFO - 2023-04-27 07:27:46 --> Language Class Initialized
INFO - 2023-04-27 07:27:46 --> Loader Class Initialized
INFO - 2023-04-27 07:27:46 --> Loader Class Initialized
INFO - 2023-04-27 07:27:46 --> Controller Class Initialized
INFO - 2023-04-27 07:27:46 --> Controller Class Initialized
DEBUG - 2023-04-27 07:27:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:27:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:27:46 --> Database Driver Class Initialized
INFO - 2023-04-27 07:27:46 --> Database Driver Class Initialized
INFO - 2023-04-27 07:27:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:27:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:27:46 --> Final output sent to browser
DEBUG - 2023-04-27 07:27:46 --> Total execution time: 0.0217
INFO - 2023-04-27 07:27:46 --> Final output sent to browser
INFO - 2023-04-27 07:27:46 --> Config Class Initialized
DEBUG - 2023-04-27 07:27:46 --> Total execution time: 0.0252
INFO - 2023-04-27 07:27:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:27:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:27:46 --> Utf8 Class Initialized
INFO - 2023-04-27 07:27:46 --> URI Class Initialized
INFO - 2023-04-27 07:27:46 --> Router Class Initialized
INFO - 2023-04-27 07:27:46 --> Output Class Initialized
INFO - 2023-04-27 07:27:46 --> Security Class Initialized
DEBUG - 2023-04-27 07:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:27:46 --> Input Class Initialized
INFO - 2023-04-27 07:27:46 --> Language Class Initialized
INFO - 2023-04-27 07:27:46 --> Loader Class Initialized
INFO - 2023-04-27 07:27:46 --> Config Class Initialized
INFO - 2023-04-27 07:27:46 --> Controller Class Initialized
INFO - 2023-04-27 07:27:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:27:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:27:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:27:46 --> Utf8 Class Initialized
INFO - 2023-04-27 07:27:46 --> Database Driver Class Initialized
INFO - 2023-04-27 07:27:46 --> URI Class Initialized
INFO - 2023-04-27 07:27:46 --> Router Class Initialized
INFO - 2023-04-27 07:27:46 --> Output Class Initialized
INFO - 2023-04-27 07:27:46 --> Security Class Initialized
DEBUG - 2023-04-27 07:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:27:46 --> Input Class Initialized
INFO - 2023-04-27 07:27:46 --> Language Class Initialized
INFO - 2023-04-27 07:27:46 --> Loader Class Initialized
INFO - 2023-04-27 07:27:46 --> Controller Class Initialized
DEBUG - 2023-04-27 07:27:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:27:46 --> Database Driver Class Initialized
INFO - 2023-04-27 07:27:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:27:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:27:46 --> Final output sent to browser
DEBUG - 2023-04-27 07:27:46 --> Total execution time: 0.0407
INFO - 2023-04-27 07:27:46 --> Final output sent to browser
DEBUG - 2023-04-27 07:27:46 --> Total execution time: 0.0161
INFO - 2023-04-27 07:34:18 --> Config Class Initialized
INFO - 2023-04-27 07:34:18 --> Config Class Initialized
INFO - 2023-04-27 07:34:18 --> Hooks Class Initialized
INFO - 2023-04-27 07:34:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:34:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:18 --> URI Class Initialized
INFO - 2023-04-27 07:34:18 --> Router Class Initialized
DEBUG - 2023-04-27 07:34:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:18 --> Output Class Initialized
INFO - 2023-04-27 07:34:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:18 --> Security Class Initialized
INFO - 2023-04-27 07:34:18 --> URI Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:34:18 --> Input Class Initialized
INFO - 2023-04-27 07:34:18 --> Language Class Initialized
INFO - 2023-04-27 07:34:18 --> Router Class Initialized
INFO - 2023-04-27 07:34:18 --> Output Class Initialized
INFO - 2023-04-27 07:34:18 --> Loader Class Initialized
INFO - 2023-04-27 07:34:18 --> Security Class Initialized
INFO - 2023-04-27 07:34:18 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:18 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:34:18 --> Input Class Initialized
INFO - 2023-04-27 07:34:18 --> Language Class Initialized
INFO - 2023-04-27 07:34:18 --> Loader Class Initialized
INFO - 2023-04-27 07:34:18 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:18 --> Total execution time: 0.0597
INFO - 2023-04-27 07:34:18 --> Final output sent to browser
INFO - 2023-04-27 07:34:18 --> Config Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Total execution time: 0.0626
INFO - 2023-04-27 07:34:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:34:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:18 --> URI Class Initialized
INFO - 2023-04-27 07:34:18 --> Router Class Initialized
INFO - 2023-04-27 07:34:18 --> Output Class Initialized
INFO - 2023-04-27 07:34:18 --> Security Class Initialized
INFO - 2023-04-27 07:34:18 --> Config Class Initialized
INFO - 2023-04-27 07:34:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:34:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:18 --> Input Class Initialized
INFO - 2023-04-27 07:34:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:18 --> Language Class Initialized
INFO - 2023-04-27 07:34:18 --> URI Class Initialized
INFO - 2023-04-27 07:34:18 --> Loader Class Initialized
INFO - 2023-04-27 07:34:18 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:18 --> Router Class Initialized
INFO - 2023-04-27 07:34:18 --> Output Class Initialized
INFO - 2023-04-27 07:34:18 --> Security Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:34:18 --> Input Class Initialized
INFO - 2023-04-27 07:34:18 --> Language Class Initialized
INFO - 2023-04-27 07:34:18 --> Loader Class Initialized
INFO - 2023-04-27 07:34:18 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:18 --> Total execution time: 0.0913
INFO - 2023-04-27 07:34:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:18 --> Total execution time: 0.0528
INFO - 2023-04-27 07:34:37 --> Config Class Initialized
INFO - 2023-04-27 07:34:37 --> Config Class Initialized
INFO - 2023-04-27 07:34:37 --> Hooks Class Initialized
INFO - 2023-04-27 07:34:37 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:34:37 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:37 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:37 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:37 --> URI Class Initialized
INFO - 2023-04-27 07:34:37 --> URI Class Initialized
INFO - 2023-04-27 07:34:37 --> Router Class Initialized
INFO - 2023-04-27 07:34:37 --> Router Class Initialized
INFO - 2023-04-27 07:34:37 --> Output Class Initialized
INFO - 2023-04-27 07:34:37 --> Output Class Initialized
INFO - 2023-04-27 07:34:37 --> Security Class Initialized
INFO - 2023-04-27 07:34:37 --> Security Class Initialized
DEBUG - 2023-04-27 07:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:34:37 --> Input Class Initialized
INFO - 2023-04-27 07:34:37 --> Input Class Initialized
INFO - 2023-04-27 07:34:37 --> Language Class Initialized
INFO - 2023-04-27 07:34:37 --> Language Class Initialized
INFO - 2023-04-27 07:34:37 --> Loader Class Initialized
INFO - 2023-04-27 07:34:37 --> Loader Class Initialized
INFO - 2023-04-27 07:34:37 --> Controller Class Initialized
INFO - 2023-04-27 07:34:37 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:37 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:37 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:37 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:37 --> Total execution time: 0.0600
INFO - 2023-04-27 07:34:37 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:37 --> Total execution time: 0.0603
INFO - 2023-04-27 07:34:37 --> Config Class Initialized
INFO - 2023-04-27 07:34:37 --> Config Class Initialized
INFO - 2023-04-27 07:34:37 --> Hooks Class Initialized
INFO - 2023-04-27 07:34:37 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:34:37 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:37 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:37 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:37 --> URI Class Initialized
INFO - 2023-04-27 07:34:37 --> URI Class Initialized
INFO - 2023-04-27 07:34:37 --> Router Class Initialized
INFO - 2023-04-27 07:34:37 --> Router Class Initialized
INFO - 2023-04-27 07:34:37 --> Output Class Initialized
INFO - 2023-04-27 07:34:37 --> Output Class Initialized
INFO - 2023-04-27 07:34:37 --> Security Class Initialized
INFO - 2023-04-27 07:34:37 --> Security Class Initialized
DEBUG - 2023-04-27 07:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:34:37 --> Input Class Initialized
INFO - 2023-04-27 07:34:37 --> Input Class Initialized
INFO - 2023-04-27 07:34:37 --> Language Class Initialized
INFO - 2023-04-27 07:34:37 --> Language Class Initialized
INFO - 2023-04-27 07:34:37 --> Loader Class Initialized
INFO - 2023-04-27 07:34:37 --> Loader Class Initialized
INFO - 2023-04-27 07:34:37 --> Controller Class Initialized
INFO - 2023-04-27 07:34:37 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:37 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:37 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:37 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:37 --> Total execution time: 0.0135
INFO - 2023-04-27 07:34:37 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:37 --> Total execution time: 0.0158
INFO - 2023-04-27 07:34:50 --> Config Class Initialized
INFO - 2023-04-27 07:34:50 --> Config Class Initialized
INFO - 2023-04-27 07:34:50 --> Hooks Class Initialized
INFO - 2023-04-27 07:34:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:34:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:34:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:50 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:50 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:50 --> URI Class Initialized
INFO - 2023-04-27 07:34:50 --> URI Class Initialized
INFO - 2023-04-27 07:34:50 --> Router Class Initialized
INFO - 2023-04-27 07:34:50 --> Router Class Initialized
INFO - 2023-04-27 07:34:50 --> Output Class Initialized
INFO - 2023-04-27 07:34:50 --> Output Class Initialized
INFO - 2023-04-27 07:34:50 --> Security Class Initialized
INFO - 2023-04-27 07:34:50 --> Security Class Initialized
DEBUG - 2023-04-27 07:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:34:50 --> Input Class Initialized
INFO - 2023-04-27 07:34:50 --> Input Class Initialized
INFO - 2023-04-27 07:34:50 --> Language Class Initialized
INFO - 2023-04-27 07:34:50 --> Language Class Initialized
INFO - 2023-04-27 07:34:50 --> Loader Class Initialized
INFO - 2023-04-27 07:34:50 --> Loader Class Initialized
INFO - 2023-04-27 07:34:50 --> Controller Class Initialized
INFO - 2023-04-27 07:34:50 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:50 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:50 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:50 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:50 --> Total execution time: 0.0599
INFO - 2023-04-27 07:34:50 --> Config Class Initialized
INFO - 2023-04-27 07:34:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:34:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:50 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:50 --> URI Class Initialized
INFO - 2023-04-27 07:34:50 --> Router Class Initialized
INFO - 2023-04-27 07:34:50 --> Output Class Initialized
INFO - 2023-04-27 07:34:50 --> Security Class Initialized
DEBUG - 2023-04-27 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:34:50 --> Input Class Initialized
INFO - 2023-04-27 07:34:50 --> Language Class Initialized
INFO - 2023-04-27 07:34:50 --> Loader Class Initialized
INFO - 2023-04-27 07:34:50 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:50 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:50 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:50 --> Total execution time: 0.0663
INFO - 2023-04-27 07:34:50 --> Config Class Initialized
INFO - 2023-04-27 07:34:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:34:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:34:50 --> Utf8 Class Initialized
INFO - 2023-04-27 07:34:50 --> URI Class Initialized
INFO - 2023-04-27 07:34:50 --> Router Class Initialized
INFO - 2023-04-27 07:34:50 --> Output Class Initialized
INFO - 2023-04-27 07:34:50 --> Security Class Initialized
DEBUG - 2023-04-27 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:34:50 --> Input Class Initialized
INFO - 2023-04-27 07:34:50 --> Language Class Initialized
INFO - 2023-04-27 07:34:50 --> Loader Class Initialized
INFO - 2023-04-27 07:34:50 --> Controller Class Initialized
DEBUG - 2023-04-27 07:34:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:34:50 --> Database Driver Class Initialized
INFO - 2023-04-27 07:34:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:50 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:50 --> Total execution time: 0.0181
INFO - 2023-04-27 07:34:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:34:50 --> Final output sent to browser
DEBUG - 2023-04-27 07:34:50 --> Total execution time: 0.0587
INFO - 2023-04-27 07:35:15 --> Config Class Initialized
INFO - 2023-04-27 07:35:15 --> Hooks Class Initialized
INFO - 2023-04-27 07:35:15 --> Config Class Initialized
DEBUG - 2023-04-27 07:35:15 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:35:15 --> Hooks Class Initialized
INFO - 2023-04-27 07:35:15 --> Utf8 Class Initialized
DEBUG - 2023-04-27 07:35:15 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:35:15 --> Utf8 Class Initialized
INFO - 2023-04-27 07:35:15 --> URI Class Initialized
INFO - 2023-04-27 07:35:15 --> URI Class Initialized
INFO - 2023-04-27 07:35:15 --> Router Class Initialized
INFO - 2023-04-27 07:35:15 --> Router Class Initialized
INFO - 2023-04-27 07:35:15 --> Output Class Initialized
INFO - 2023-04-27 07:35:15 --> Output Class Initialized
INFO - 2023-04-27 07:35:15 --> Security Class Initialized
INFO - 2023-04-27 07:35:15 --> Security Class Initialized
DEBUG - 2023-04-27 07:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:35:15 --> Input Class Initialized
INFO - 2023-04-27 07:35:15 --> Input Class Initialized
INFO - 2023-04-27 07:35:15 --> Language Class Initialized
INFO - 2023-04-27 07:35:15 --> Language Class Initialized
INFO - 2023-04-27 07:35:15 --> Loader Class Initialized
INFO - 2023-04-27 07:35:15 --> Loader Class Initialized
INFO - 2023-04-27 07:35:15 --> Controller Class Initialized
INFO - 2023-04-27 07:35:15 --> Controller Class Initialized
DEBUG - 2023-04-27 07:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:35:15 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:35:15 --> Database Driver Class Initialized
INFO - 2023-04-27 07:35:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:35:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:35:15 --> Final output sent to browser
DEBUG - 2023-04-27 07:35:15 --> Total execution time: 0.0212
INFO - 2023-04-27 07:35:15 --> Final output sent to browser
DEBUG - 2023-04-27 07:35:15 --> Total execution time: 0.0244
INFO - 2023-04-27 07:35:15 --> Config Class Initialized
INFO - 2023-04-27 07:35:15 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:35:15 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:35:15 --> Utf8 Class Initialized
INFO - 2023-04-27 07:35:15 --> URI Class Initialized
INFO - 2023-04-27 07:35:15 --> Router Class Initialized
INFO - 2023-04-27 07:35:15 --> Output Class Initialized
INFO - 2023-04-27 07:35:15 --> Security Class Initialized
DEBUG - 2023-04-27 07:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:35:15 --> Input Class Initialized
INFO - 2023-04-27 07:35:15 --> Language Class Initialized
INFO - 2023-04-27 07:35:15 --> Config Class Initialized
INFO - 2023-04-27 07:35:15 --> Loader Class Initialized
INFO - 2023-04-27 07:35:15 --> Hooks Class Initialized
INFO - 2023-04-27 07:35:15 --> Controller Class Initialized
DEBUG - 2023-04-27 07:35:15 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:35:15 --> Utf8 Class Initialized
INFO - 2023-04-27 07:35:15 --> Database Driver Class Initialized
INFO - 2023-04-27 07:35:15 --> URI Class Initialized
INFO - 2023-04-27 07:35:15 --> Router Class Initialized
INFO - 2023-04-27 07:35:15 --> Output Class Initialized
INFO - 2023-04-27 07:35:15 --> Security Class Initialized
DEBUG - 2023-04-27 07:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:35:15 --> Input Class Initialized
INFO - 2023-04-27 07:35:15 --> Language Class Initialized
INFO - 2023-04-27 07:35:15 --> Loader Class Initialized
INFO - 2023-04-27 07:35:15 --> Controller Class Initialized
DEBUG - 2023-04-27 07:35:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:35:15 --> Database Driver Class Initialized
INFO - 2023-04-27 07:35:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:35:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:35:15 --> Final output sent to browser
DEBUG - 2023-04-27 07:35:15 --> Total execution time: 0.0220
INFO - 2023-04-27 07:35:15 --> Final output sent to browser
DEBUG - 2023-04-27 07:35:15 --> Total execution time: 0.0201
INFO - 2023-04-27 07:35:28 --> Config Class Initialized
INFO - 2023-04-27 07:35:28 --> Hooks Class Initialized
INFO - 2023-04-27 07:35:28 --> Config Class Initialized
INFO - 2023-04-27 07:35:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:35:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:35:28 --> Utf8 Class Initialized
INFO - 2023-04-27 07:35:28 --> Utf8 Class Initialized
INFO - 2023-04-27 07:35:28 --> URI Class Initialized
INFO - 2023-04-27 07:35:28 --> URI Class Initialized
INFO - 2023-04-27 07:35:28 --> Router Class Initialized
INFO - 2023-04-27 07:35:28 --> Router Class Initialized
INFO - 2023-04-27 07:35:28 --> Output Class Initialized
INFO - 2023-04-27 07:35:28 --> Output Class Initialized
INFO - 2023-04-27 07:35:28 --> Security Class Initialized
INFO - 2023-04-27 07:35:28 --> Security Class Initialized
DEBUG - 2023-04-27 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:35:28 --> Input Class Initialized
DEBUG - 2023-04-27 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:35:28 --> Input Class Initialized
INFO - 2023-04-27 07:35:28 --> Language Class Initialized
INFO - 2023-04-27 07:35:28 --> Language Class Initialized
INFO - 2023-04-27 07:35:28 --> Loader Class Initialized
INFO - 2023-04-27 07:35:28 --> Loader Class Initialized
INFO - 2023-04-27 07:35:28 --> Controller Class Initialized
INFO - 2023-04-27 07:35:28 --> Controller Class Initialized
DEBUG - 2023-04-27 07:35:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:35:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:35:28 --> Database Driver Class Initialized
INFO - 2023-04-27 07:35:28 --> Database Driver Class Initialized
INFO - 2023-04-27 07:35:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:35:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:35:28 --> Final output sent to browser
INFO - 2023-04-27 07:35:28 --> Final output sent to browser
DEBUG - 2023-04-27 07:35:28 --> Total execution time: 0.0588
DEBUG - 2023-04-27 07:35:28 --> Total execution time: 0.0634
INFO - 2023-04-27 07:35:28 --> Config Class Initialized
INFO - 2023-04-27 07:35:28 --> Config Class Initialized
INFO - 2023-04-27 07:35:28 --> Hooks Class Initialized
INFO - 2023-04-27 07:35:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:35:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:35:28 --> Utf8 Class Initialized
DEBUG - 2023-04-27 07:35:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:35:28 --> URI Class Initialized
INFO - 2023-04-27 07:35:28 --> Utf8 Class Initialized
INFO - 2023-04-27 07:35:28 --> Router Class Initialized
INFO - 2023-04-27 07:35:28 --> Output Class Initialized
INFO - 2023-04-27 07:35:28 --> URI Class Initialized
INFO - 2023-04-27 07:35:28 --> Security Class Initialized
DEBUG - 2023-04-27 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:35:28 --> Router Class Initialized
INFO - 2023-04-27 07:35:28 --> Input Class Initialized
INFO - 2023-04-27 07:35:28 --> Output Class Initialized
INFO - 2023-04-27 07:35:28 --> Language Class Initialized
INFO - 2023-04-27 07:35:28 --> Security Class Initialized
INFO - 2023-04-27 07:35:28 --> Loader Class Initialized
DEBUG - 2023-04-27 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:35:28 --> Controller Class Initialized
INFO - 2023-04-27 07:35:28 --> Input Class Initialized
DEBUG - 2023-04-27 07:35:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:35:28 --> Language Class Initialized
INFO - 2023-04-27 07:35:28 --> Database Driver Class Initialized
INFO - 2023-04-27 07:35:28 --> Loader Class Initialized
INFO - 2023-04-27 07:35:28 --> Controller Class Initialized
DEBUG - 2023-04-27 07:35:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:35:28 --> Database Driver Class Initialized
INFO - 2023-04-27 07:35:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:35:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:35:28 --> Final output sent to browser
DEBUG - 2023-04-27 07:35:28 --> Total execution time: 0.0167
INFO - 2023-04-27 07:35:28 --> Final output sent to browser
DEBUG - 2023-04-27 07:35:28 --> Total execution time: 0.0203
INFO - 2023-04-27 07:36:42 --> Config Class Initialized
INFO - 2023-04-27 07:36:42 --> Config Class Initialized
INFO - 2023-04-27 07:36:42 --> Hooks Class Initialized
INFO - 2023-04-27 07:36:42 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:36:42 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:36:42 --> Utf8 Class Initialized
INFO - 2023-04-27 07:36:42 --> Utf8 Class Initialized
INFO - 2023-04-27 07:36:42 --> URI Class Initialized
INFO - 2023-04-27 07:36:42 --> URI Class Initialized
INFO - 2023-04-27 07:36:42 --> Router Class Initialized
INFO - 2023-04-27 07:36:42 --> Router Class Initialized
INFO - 2023-04-27 07:36:42 --> Output Class Initialized
INFO - 2023-04-27 07:36:42 --> Output Class Initialized
INFO - 2023-04-27 07:36:42 --> Security Class Initialized
INFO - 2023-04-27 07:36:42 --> Security Class Initialized
DEBUG - 2023-04-27 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:36:42 --> Input Class Initialized
INFO - 2023-04-27 07:36:42 --> Input Class Initialized
INFO - 2023-04-27 07:36:42 --> Language Class Initialized
INFO - 2023-04-27 07:36:42 --> Language Class Initialized
INFO - 2023-04-27 07:36:42 --> Loader Class Initialized
INFO - 2023-04-27 07:36:42 --> Loader Class Initialized
INFO - 2023-04-27 07:36:42 --> Controller Class Initialized
INFO - 2023-04-27 07:36:42 --> Controller Class Initialized
DEBUG - 2023-04-27 07:36:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:36:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:36:42 --> Database Driver Class Initialized
INFO - 2023-04-27 07:36:42 --> Database Driver Class Initialized
INFO - 2023-04-27 07:36:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:36:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:36:42 --> Final output sent to browser
DEBUG - 2023-04-27 07:36:42 --> Total execution time: 0.0599
INFO - 2023-04-27 07:36:42 --> Config Class Initialized
INFO - 2023-04-27 07:36:42 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:36:42 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:36:42 --> Utf8 Class Initialized
INFO - 2023-04-27 07:36:42 --> URI Class Initialized
INFO - 2023-04-27 07:36:42 --> Router Class Initialized
INFO - 2023-04-27 07:36:42 --> Output Class Initialized
INFO - 2023-04-27 07:36:42 --> Security Class Initialized
DEBUG - 2023-04-27 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:36:42 --> Final output sent to browser
INFO - 2023-04-27 07:36:42 --> Input Class Initialized
DEBUG - 2023-04-27 07:36:42 --> Total execution time: 0.0639
INFO - 2023-04-27 07:36:42 --> Language Class Initialized
INFO - 2023-04-27 07:36:42 --> Loader Class Initialized
INFO - 2023-04-27 07:36:42 --> Controller Class Initialized
DEBUG - 2023-04-27 07:36:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:36:42 --> Database Driver Class Initialized
INFO - 2023-04-27 07:36:42 --> Config Class Initialized
INFO - 2023-04-27 07:36:42 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:36:42 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:36:42 --> Utf8 Class Initialized
INFO - 2023-04-27 07:36:42 --> URI Class Initialized
INFO - 2023-04-27 07:36:42 --> Router Class Initialized
INFO - 2023-04-27 07:36:42 --> Output Class Initialized
INFO - 2023-04-27 07:36:42 --> Security Class Initialized
DEBUG - 2023-04-27 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:36:42 --> Input Class Initialized
INFO - 2023-04-27 07:36:42 --> Language Class Initialized
INFO - 2023-04-27 07:36:42 --> Loader Class Initialized
INFO - 2023-04-27 07:36:42 --> Controller Class Initialized
DEBUG - 2023-04-27 07:36:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:36:42 --> Database Driver Class Initialized
INFO - 2023-04-27 07:36:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:36:42 --> Final output sent to browser
DEBUG - 2023-04-27 07:36:42 --> Total execution time: 0.0133
INFO - 2023-04-27 07:36:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:36:43 --> Final output sent to browser
DEBUG - 2023-04-27 07:36:43 --> Total execution time: 0.0574
INFO - 2023-04-27 07:38:30 --> Config Class Initialized
INFO - 2023-04-27 07:38:30 --> Config Class Initialized
INFO - 2023-04-27 07:38:30 --> Hooks Class Initialized
INFO - 2023-04-27 07:38:30 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:38:30 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:38:30 --> Utf8 Class Initialized
INFO - 2023-04-27 07:38:30 --> Utf8 Class Initialized
INFO - 2023-04-27 07:38:30 --> URI Class Initialized
INFO - 2023-04-27 07:38:30 --> URI Class Initialized
INFO - 2023-04-27 07:38:30 --> Router Class Initialized
INFO - 2023-04-27 07:38:30 --> Router Class Initialized
INFO - 2023-04-27 07:38:30 --> Output Class Initialized
INFO - 2023-04-27 07:38:30 --> Output Class Initialized
INFO - 2023-04-27 07:38:30 --> Security Class Initialized
INFO - 2023-04-27 07:38:30 --> Security Class Initialized
DEBUG - 2023-04-27 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:38:30 --> Input Class Initialized
INFO - 2023-04-27 07:38:30 --> Input Class Initialized
INFO - 2023-04-27 07:38:30 --> Language Class Initialized
INFO - 2023-04-27 07:38:30 --> Language Class Initialized
INFO - 2023-04-27 07:38:30 --> Loader Class Initialized
INFO - 2023-04-27 07:38:30 --> Loader Class Initialized
INFO - 2023-04-27 07:38:30 --> Controller Class Initialized
DEBUG - 2023-04-27 07:38:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:38:30 --> Controller Class Initialized
DEBUG - 2023-04-27 07:38:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:38:30 --> Database Driver Class Initialized
INFO - 2023-04-27 07:38:30 --> Database Driver Class Initialized
INFO - 2023-04-27 07:38:30 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:38:30 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:38:30 --> Final output sent to browser
DEBUG - 2023-04-27 07:38:30 --> Total execution time: 0.1360
INFO - 2023-04-27 07:38:30 --> Config Class Initialized
INFO - 2023-04-27 07:38:30 --> Final output sent to browser
INFO - 2023-04-27 07:38:30 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:38:30 --> Total execution time: 0.1442
DEBUG - 2023-04-27 07:38:30 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:38:30 --> Config Class Initialized
INFO - 2023-04-27 07:38:30 --> Utf8 Class Initialized
INFO - 2023-04-27 07:38:30 --> Hooks Class Initialized
INFO - 2023-04-27 07:38:30 --> URI Class Initialized
INFO - 2023-04-27 07:38:30 --> Router Class Initialized
DEBUG - 2023-04-27 07:38:30 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:38:30 --> Output Class Initialized
INFO - 2023-04-27 07:38:30 --> Security Class Initialized
DEBUG - 2023-04-27 07:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:38:30 --> Utf8 Class Initialized
INFO - 2023-04-27 07:38:30 --> Input Class Initialized
INFO - 2023-04-27 07:38:30 --> URI Class Initialized
INFO - 2023-04-27 07:38:30 --> Language Class Initialized
INFO - 2023-04-27 07:38:30 --> Router Class Initialized
INFO - 2023-04-27 07:38:30 --> Output Class Initialized
INFO - 2023-04-27 07:38:30 --> Loader Class Initialized
INFO - 2023-04-27 07:38:30 --> Security Class Initialized
INFO - 2023-04-27 07:38:30 --> Controller Class Initialized
DEBUG - 2023-04-27 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:38:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:38:30 --> Input Class Initialized
INFO - 2023-04-27 07:38:30 --> Language Class Initialized
INFO - 2023-04-27 07:38:30 --> Database Driver Class Initialized
INFO - 2023-04-27 07:38:30 --> Loader Class Initialized
INFO - 2023-04-27 07:38:30 --> Controller Class Initialized
DEBUG - 2023-04-27 07:38:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:38:30 --> Database Driver Class Initialized
INFO - 2023-04-27 07:38:30 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:38:30 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:38:30 --> Final output sent to browser
DEBUG - 2023-04-27 07:38:30 --> Total execution time: 0.3392
INFO - 2023-04-27 07:38:30 --> Final output sent to browser
DEBUG - 2023-04-27 07:38:30 --> Total execution time: 0.1610
INFO - 2023-04-27 07:40:50 --> Config Class Initialized
INFO - 2023-04-27 07:40:51 --> Config Class Initialized
INFO - 2023-04-27 07:40:51 --> Hooks Class Initialized
INFO - 2023-04-27 07:40:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:40:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:40:51 --> Utf8 Class Initialized
INFO - 2023-04-27 07:40:51 --> Utf8 Class Initialized
INFO - 2023-04-27 07:40:51 --> URI Class Initialized
INFO - 2023-04-27 07:40:51 --> URI Class Initialized
INFO - 2023-04-27 07:40:51 --> Router Class Initialized
INFO - 2023-04-27 07:40:51 --> Router Class Initialized
INFO - 2023-04-27 07:40:51 --> Output Class Initialized
INFO - 2023-04-27 07:40:51 --> Output Class Initialized
INFO - 2023-04-27 07:40:51 --> Security Class Initialized
INFO - 2023-04-27 07:40:51 --> Security Class Initialized
DEBUG - 2023-04-27 07:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:40:51 --> Input Class Initialized
INFO - 2023-04-27 07:40:51 --> Input Class Initialized
INFO - 2023-04-27 07:40:51 --> Language Class Initialized
INFO - 2023-04-27 07:40:51 --> Language Class Initialized
INFO - 2023-04-27 07:40:51 --> Loader Class Initialized
INFO - 2023-04-27 07:40:51 --> Loader Class Initialized
INFO - 2023-04-27 07:40:51 --> Controller Class Initialized
INFO - 2023-04-27 07:40:51 --> Controller Class Initialized
DEBUG - 2023-04-27 07:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:40:51 --> Database Driver Class Initialized
INFO - 2023-04-27 07:40:51 --> Database Driver Class Initialized
INFO - 2023-04-27 07:40:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:40:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:40:51 --> Final output sent to browser
DEBUG - 2023-04-27 07:40:51 --> Total execution time: 0.0894
INFO - 2023-04-27 07:40:51 --> Config Class Initialized
INFO - 2023-04-27 07:40:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:40:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:40:51 --> Utf8 Class Initialized
INFO - 2023-04-27 07:40:51 --> URI Class Initialized
INFO - 2023-04-27 07:40:51 --> Router Class Initialized
INFO - 2023-04-27 07:40:51 --> Output Class Initialized
INFO - 2023-04-27 07:40:51 --> Security Class Initialized
DEBUG - 2023-04-27 07:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:40:51 --> Input Class Initialized
INFO - 2023-04-27 07:40:51 --> Language Class Initialized
INFO - 2023-04-27 07:40:51 --> Loader Class Initialized
INFO - 2023-04-27 07:40:51 --> Controller Class Initialized
DEBUG - 2023-04-27 07:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:40:51 --> Database Driver Class Initialized
INFO - 2023-04-27 07:40:51 --> Final output sent to browser
DEBUG - 2023-04-27 07:40:51 --> Total execution time: 0.0982
INFO - 2023-04-27 07:40:51 --> Config Class Initialized
INFO - 2023-04-27 07:40:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:40:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:40:51 --> Utf8 Class Initialized
INFO - 2023-04-27 07:40:51 --> URI Class Initialized
INFO - 2023-04-27 07:40:51 --> Router Class Initialized
INFO - 2023-04-27 07:40:51 --> Output Class Initialized
INFO - 2023-04-27 07:40:51 --> Security Class Initialized
DEBUG - 2023-04-27 07:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:40:51 --> Input Class Initialized
INFO - 2023-04-27 07:40:51 --> Language Class Initialized
INFO - 2023-04-27 07:40:51 --> Loader Class Initialized
INFO - 2023-04-27 07:40:51 --> Controller Class Initialized
DEBUG - 2023-04-27 07:40:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:40:51 --> Database Driver Class Initialized
INFO - 2023-04-27 07:40:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:40:51 --> Final output sent to browser
DEBUG - 2023-04-27 07:40:51 --> Total execution time: 0.0245
INFO - 2023-04-27 07:40:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:40:51 --> Final output sent to browser
DEBUG - 2023-04-27 07:40:51 --> Total execution time: 0.0792
INFO - 2023-04-27 07:41:22 --> Config Class Initialized
INFO - 2023-04-27 07:41:22 --> Config Class Initialized
INFO - 2023-04-27 07:41:22 --> Hooks Class Initialized
INFO - 2023-04-27 07:41:22 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:41:22 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:41:22 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:22 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:22 --> URI Class Initialized
INFO - 2023-04-27 07:41:22 --> URI Class Initialized
INFO - 2023-04-27 07:41:22 --> Router Class Initialized
INFO - 2023-04-27 07:41:22 --> Output Class Initialized
INFO - 2023-04-27 07:41:22 --> Security Class Initialized
DEBUG - 2023-04-27 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:22 --> Input Class Initialized
INFO - 2023-04-27 07:41:22 --> Language Class Initialized
INFO - 2023-04-27 07:41:22 --> Loader Class Initialized
INFO - 2023-04-27 07:41:22 --> Controller Class Initialized
DEBUG - 2023-04-27 07:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:22 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:22 --> Router Class Initialized
INFO - 2023-04-27 07:41:22 --> Output Class Initialized
INFO - 2023-04-27 07:41:22 --> Security Class Initialized
DEBUG - 2023-04-27 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:22 --> Input Class Initialized
INFO - 2023-04-27 07:41:22 --> Language Class Initialized
INFO - 2023-04-27 07:41:22 --> Loader Class Initialized
INFO - 2023-04-27 07:41:22 --> Controller Class Initialized
DEBUG - 2023-04-27 07:41:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:22 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:23 --> Final output sent to browser
INFO - 2023-04-27 07:41:23 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:23 --> Total execution time: 0.0694
DEBUG - 2023-04-27 07:41:23 --> Total execution time: 0.0712
INFO - 2023-04-27 07:41:23 --> Config Class Initialized
INFO - 2023-04-27 07:41:23 --> Config Class Initialized
INFO - 2023-04-27 07:41:23 --> Hooks Class Initialized
INFO - 2023-04-27 07:41:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:41:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:41:23 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:23 --> URI Class Initialized
INFO - 2023-04-27 07:41:23 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:23 --> Router Class Initialized
INFO - 2023-04-27 07:41:23 --> URI Class Initialized
INFO - 2023-04-27 07:41:23 --> Output Class Initialized
INFO - 2023-04-27 07:41:23 --> Router Class Initialized
INFO - 2023-04-27 07:41:23 --> Security Class Initialized
DEBUG - 2023-04-27 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:23 --> Input Class Initialized
INFO - 2023-04-27 07:41:23 --> Language Class Initialized
INFO - 2023-04-27 07:41:23 --> Output Class Initialized
INFO - 2023-04-27 07:41:23 --> Security Class Initialized
DEBUG - 2023-04-27 07:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:23 --> Input Class Initialized
INFO - 2023-04-27 07:41:23 --> Language Class Initialized
INFO - 2023-04-27 07:41:23 --> Loader Class Initialized
INFO - 2023-04-27 07:41:23 --> Loader Class Initialized
INFO - 2023-04-27 07:41:23 --> Controller Class Initialized
INFO - 2023-04-27 07:41:23 --> Controller Class Initialized
DEBUG - 2023-04-27 07:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:41:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:23 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:23 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:23 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:23 --> Total execution time: 0.0216
INFO - 2023-04-27 07:41:23 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:23 --> Total execution time: 0.0276
INFO - 2023-04-27 07:41:35 --> Config Class Initialized
INFO - 2023-04-27 07:41:35 --> Config Class Initialized
INFO - 2023-04-27 07:41:35 --> Hooks Class Initialized
INFO - 2023-04-27 07:41:35 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:41:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:41:35 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:41:35 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:35 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:35 --> URI Class Initialized
INFO - 2023-04-27 07:41:35 --> URI Class Initialized
INFO - 2023-04-27 07:41:35 --> Router Class Initialized
INFO - 2023-04-27 07:41:35 --> Router Class Initialized
INFO - 2023-04-27 07:41:35 --> Output Class Initialized
INFO - 2023-04-27 07:41:35 --> Output Class Initialized
INFO - 2023-04-27 07:41:35 --> Security Class Initialized
INFO - 2023-04-27 07:41:35 --> Security Class Initialized
DEBUG - 2023-04-27 07:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:35 --> Input Class Initialized
INFO - 2023-04-27 07:41:35 --> Input Class Initialized
INFO - 2023-04-27 07:41:35 --> Language Class Initialized
INFO - 2023-04-27 07:41:35 --> Language Class Initialized
INFO - 2023-04-27 07:41:35 --> Loader Class Initialized
INFO - 2023-04-27 07:41:35 --> Loader Class Initialized
INFO - 2023-04-27 07:41:35 --> Controller Class Initialized
INFO - 2023-04-27 07:41:35 --> Controller Class Initialized
DEBUG - 2023-04-27 07:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:35 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:35 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:35 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:35 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:35 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:35 --> Total execution time: 0.0979
INFO - 2023-04-27 07:41:35 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:35 --> Total execution time: 0.0979
INFO - 2023-04-27 07:41:35 --> Config Class Initialized
INFO - 2023-04-27 07:41:35 --> Config Class Initialized
INFO - 2023-04-27 07:41:35 --> Hooks Class Initialized
INFO - 2023-04-27 07:41:35 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:41:35 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:41:35 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:41:35 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:35 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:35 --> URI Class Initialized
INFO - 2023-04-27 07:41:35 --> URI Class Initialized
INFO - 2023-04-27 07:41:35 --> Router Class Initialized
INFO - 2023-04-27 07:41:35 --> Router Class Initialized
INFO - 2023-04-27 07:41:35 --> Output Class Initialized
INFO - 2023-04-27 07:41:35 --> Output Class Initialized
INFO - 2023-04-27 07:41:35 --> Security Class Initialized
INFO - 2023-04-27 07:41:35 --> Security Class Initialized
DEBUG - 2023-04-27 07:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:35 --> Input Class Initialized
INFO - 2023-04-27 07:41:35 --> Input Class Initialized
INFO - 2023-04-27 07:41:35 --> Language Class Initialized
INFO - 2023-04-27 07:41:35 --> Language Class Initialized
INFO - 2023-04-27 07:41:35 --> Loader Class Initialized
INFO - 2023-04-27 07:41:35 --> Loader Class Initialized
INFO - 2023-04-27 07:41:35 --> Controller Class Initialized
INFO - 2023-04-27 07:41:35 --> Controller Class Initialized
DEBUG - 2023-04-27 07:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:41:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:35 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:35 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:35 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:35 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:35 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:35 --> Total execution time: 0.0154
INFO - 2023-04-27 07:41:35 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:35 --> Total execution time: 0.0192
INFO - 2023-04-27 07:41:46 --> Config Class Initialized
INFO - 2023-04-27 07:41:46 --> Config Class Initialized
INFO - 2023-04-27 07:41:46 --> Hooks Class Initialized
INFO - 2023-04-27 07:41:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:41:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:41:46 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:46 --> URI Class Initialized
DEBUG - 2023-04-27 07:41:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:41:46 --> Router Class Initialized
INFO - 2023-04-27 07:41:46 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:46 --> Output Class Initialized
INFO - 2023-04-27 07:41:46 --> URI Class Initialized
INFO - 2023-04-27 07:41:46 --> Security Class Initialized
INFO - 2023-04-27 07:41:46 --> Router Class Initialized
DEBUG - 2023-04-27 07:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:46 --> Output Class Initialized
INFO - 2023-04-27 07:41:46 --> Input Class Initialized
INFO - 2023-04-27 07:41:46 --> Security Class Initialized
INFO - 2023-04-27 07:41:46 --> Language Class Initialized
DEBUG - 2023-04-27 07:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:46 --> Input Class Initialized
INFO - 2023-04-27 07:41:46 --> Loader Class Initialized
INFO - 2023-04-27 07:41:46 --> Language Class Initialized
INFO - 2023-04-27 07:41:46 --> Controller Class Initialized
INFO - 2023-04-27 07:41:46 --> Loader Class Initialized
DEBUG - 2023-04-27 07:41:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:46 --> Controller Class Initialized
INFO - 2023-04-27 07:41:46 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:41:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:46 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:46 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:46 --> Total execution time: 0.0623
INFO - 2023-04-27 07:41:46 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:46 --> Total execution time: 0.0646
INFO - 2023-04-27 07:41:46 --> Config Class Initialized
INFO - 2023-04-27 07:41:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:41:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:41:46 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:46 --> URI Class Initialized
INFO - 2023-04-27 07:41:46 --> Router Class Initialized
INFO - 2023-04-27 07:41:46 --> Output Class Initialized
INFO - 2023-04-27 07:41:46 --> Config Class Initialized
INFO - 2023-04-27 07:41:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:41:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:41:46 --> Utf8 Class Initialized
INFO - 2023-04-27 07:41:46 --> URI Class Initialized
INFO - 2023-04-27 07:41:46 --> Router Class Initialized
INFO - 2023-04-27 07:41:46 --> Output Class Initialized
INFO - 2023-04-27 07:41:46 --> Security Class Initialized
DEBUG - 2023-04-27 07:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:46 --> Security Class Initialized
INFO - 2023-04-27 07:41:46 --> Input Class Initialized
DEBUG - 2023-04-27 07:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:41:46 --> Input Class Initialized
INFO - 2023-04-27 07:41:46 --> Language Class Initialized
INFO - 2023-04-27 07:41:46 --> Language Class Initialized
INFO - 2023-04-27 07:41:46 --> Loader Class Initialized
INFO - 2023-04-27 07:41:46 --> Controller Class Initialized
DEBUG - 2023-04-27 07:41:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:46 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:46 --> Loader Class Initialized
INFO - 2023-04-27 07:41:46 --> Controller Class Initialized
DEBUG - 2023-04-27 07:41:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:41:46 --> Database Driver Class Initialized
INFO - 2023-04-27 07:41:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:41:46 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:46 --> Total execution time: 0.0340
INFO - 2023-04-27 07:41:46 --> Final output sent to browser
DEBUG - 2023-04-27 07:41:46 --> Total execution time: 0.0337
INFO - 2023-04-27 07:42:52 --> Config Class Initialized
INFO - 2023-04-27 07:42:52 --> Config Class Initialized
INFO - 2023-04-27 07:42:52 --> Hooks Class Initialized
INFO - 2023-04-27 07:42:52 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:42:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:42:52 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:42:52 --> Utf8 Class Initialized
INFO - 2023-04-27 07:42:52 --> Utf8 Class Initialized
INFO - 2023-04-27 07:42:52 --> URI Class Initialized
INFO - 2023-04-27 07:42:52 --> URI Class Initialized
INFO - 2023-04-27 07:42:52 --> Router Class Initialized
INFO - 2023-04-27 07:42:52 --> Router Class Initialized
INFO - 2023-04-27 07:42:52 --> Output Class Initialized
INFO - 2023-04-27 07:42:52 --> Output Class Initialized
INFO - 2023-04-27 07:42:52 --> Security Class Initialized
INFO - 2023-04-27 07:42:52 --> Security Class Initialized
DEBUG - 2023-04-27 07:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:42:52 --> Input Class Initialized
INFO - 2023-04-27 07:42:52 --> Input Class Initialized
INFO - 2023-04-27 07:42:52 --> Language Class Initialized
INFO - 2023-04-27 07:42:52 --> Language Class Initialized
INFO - 2023-04-27 07:42:52 --> Loader Class Initialized
INFO - 2023-04-27 07:42:52 --> Loader Class Initialized
INFO - 2023-04-27 07:42:52 --> Controller Class Initialized
INFO - 2023-04-27 07:42:52 --> Controller Class Initialized
DEBUG - 2023-04-27 07:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:42:52 --> Database Driver Class Initialized
INFO - 2023-04-27 07:42:52 --> Database Driver Class Initialized
INFO - 2023-04-27 07:42:52 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:42:52 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:42:52 --> Final output sent to browser
DEBUG - 2023-04-27 07:42:52 --> Total execution time: 0.0624
INFO - 2023-04-27 07:42:52 --> Final output sent to browser
DEBUG - 2023-04-27 07:42:52 --> Total execution time: 0.0646
INFO - 2023-04-27 07:42:52 --> Config Class Initialized
INFO - 2023-04-27 07:42:52 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:42:52 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:42:52 --> Utf8 Class Initialized
INFO - 2023-04-27 07:42:52 --> URI Class Initialized
INFO - 2023-04-27 07:42:52 --> Router Class Initialized
INFO - 2023-04-27 07:42:52 --> Config Class Initialized
INFO - 2023-04-27 07:42:52 --> Output Class Initialized
INFO - 2023-04-27 07:42:52 --> Hooks Class Initialized
INFO - 2023-04-27 07:42:52 --> Security Class Initialized
DEBUG - 2023-04-27 07:42:52 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:42:52 --> Utf8 Class Initialized
INFO - 2023-04-27 07:42:52 --> Input Class Initialized
INFO - 2023-04-27 07:42:52 --> URI Class Initialized
INFO - 2023-04-27 07:42:52 --> Language Class Initialized
INFO - 2023-04-27 07:42:52 --> Router Class Initialized
INFO - 2023-04-27 07:42:52 --> Loader Class Initialized
INFO - 2023-04-27 07:42:52 --> Output Class Initialized
INFO - 2023-04-27 07:42:52 --> Controller Class Initialized
INFO - 2023-04-27 07:42:52 --> Security Class Initialized
DEBUG - 2023-04-27 07:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:42:52 --> Input Class Initialized
INFO - 2023-04-27 07:42:52 --> Database Driver Class Initialized
INFO - 2023-04-27 07:42:52 --> Language Class Initialized
INFO - 2023-04-27 07:42:52 --> Loader Class Initialized
INFO - 2023-04-27 07:42:52 --> Controller Class Initialized
DEBUG - 2023-04-27 07:42:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:42:52 --> Database Driver Class Initialized
INFO - 2023-04-27 07:42:52 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:42:52 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:42:52 --> Final output sent to browser
DEBUG - 2023-04-27 07:42:52 --> Total execution time: 0.0130
INFO - 2023-04-27 07:42:52 --> Final output sent to browser
DEBUG - 2023-04-27 07:42:52 --> Total execution time: 0.0131
INFO - 2023-04-27 07:48:07 --> Config Class Initialized
INFO - 2023-04-27 07:48:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:48:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:48:07 --> Utf8 Class Initialized
INFO - 2023-04-27 07:48:07 --> URI Class Initialized
INFO - 2023-04-27 07:48:07 --> Router Class Initialized
INFO - 2023-04-27 07:48:07 --> Output Class Initialized
INFO - 2023-04-27 07:48:07 --> Security Class Initialized
DEBUG - 2023-04-27 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:48:07 --> Input Class Initialized
INFO - 2023-04-27 07:48:07 --> Language Class Initialized
INFO - 2023-04-27 07:48:07 --> Loader Class Initialized
INFO - 2023-04-27 07:48:07 --> Controller Class Initialized
DEBUG - 2023-04-27 07:48:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:48:07 --> Database Driver Class Initialized
INFO - 2023-04-27 07:48:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:48:07 --> Final output sent to browser
DEBUG - 2023-04-27 07:48:07 --> Total execution time: 0.0154
INFO - 2023-04-27 07:48:07 --> Config Class Initialized
INFO - 2023-04-27 07:48:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:48:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:48:07 --> Utf8 Class Initialized
INFO - 2023-04-27 07:48:07 --> URI Class Initialized
INFO - 2023-04-27 07:48:07 --> Router Class Initialized
INFO - 2023-04-27 07:48:07 --> Output Class Initialized
INFO - 2023-04-27 07:48:07 --> Security Class Initialized
DEBUG - 2023-04-27 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:48:07 --> Input Class Initialized
INFO - 2023-04-27 07:48:07 --> Language Class Initialized
INFO - 2023-04-27 07:48:07 --> Loader Class Initialized
INFO - 2023-04-27 07:48:07 --> Controller Class Initialized
DEBUG - 2023-04-27 07:48:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:48:07 --> Database Driver Class Initialized
INFO - 2023-04-27 07:48:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:48:07 --> Final output sent to browser
DEBUG - 2023-04-27 07:48:07 --> Total execution time: 0.0556
INFO - 2023-04-27 07:48:07 --> Config Class Initialized
INFO - 2023-04-27 07:48:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:48:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:48:07 --> Utf8 Class Initialized
INFO - 2023-04-27 07:48:07 --> URI Class Initialized
INFO - 2023-04-27 07:48:07 --> Router Class Initialized
INFO - 2023-04-27 07:48:07 --> Output Class Initialized
INFO - 2023-04-27 07:48:07 --> Security Class Initialized
DEBUG - 2023-04-27 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:48:07 --> Input Class Initialized
INFO - 2023-04-27 07:48:07 --> Language Class Initialized
INFO - 2023-04-27 07:48:07 --> Loader Class Initialized
INFO - 2023-04-27 07:48:07 --> Controller Class Initialized
DEBUG - 2023-04-27 07:48:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:48:07 --> Database Driver Class Initialized
INFO - 2023-04-27 07:48:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:48:07 --> Final output sent to browser
DEBUG - 2023-04-27 07:48:07 --> Total execution time: 0.0529
INFO - 2023-04-27 07:48:07 --> Config Class Initialized
INFO - 2023-04-27 07:48:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:48:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:48:07 --> Utf8 Class Initialized
INFO - 2023-04-27 07:48:07 --> URI Class Initialized
INFO - 2023-04-27 07:48:07 --> Router Class Initialized
INFO - 2023-04-27 07:48:07 --> Output Class Initialized
INFO - 2023-04-27 07:48:07 --> Security Class Initialized
DEBUG - 2023-04-27 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:48:07 --> Input Class Initialized
INFO - 2023-04-27 07:48:07 --> Language Class Initialized
INFO - 2023-04-27 07:48:07 --> Loader Class Initialized
INFO - 2023-04-27 07:48:07 --> Controller Class Initialized
DEBUG - 2023-04-27 07:48:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:48:07 --> Database Driver Class Initialized
INFO - 2023-04-27 07:48:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:48:07 --> Final output sent to browser
DEBUG - 2023-04-27 07:48:07 --> Total execution time: 0.0532
INFO - 2023-04-27 07:50:02 --> Config Class Initialized
INFO - 2023-04-27 07:50:02 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:50:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:50:02 --> Utf8 Class Initialized
INFO - 2023-04-27 07:50:02 --> URI Class Initialized
INFO - 2023-04-27 07:50:02 --> Router Class Initialized
INFO - 2023-04-27 07:50:02 --> Output Class Initialized
INFO - 2023-04-27 07:50:02 --> Security Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:50:02 --> Input Class Initialized
INFO - 2023-04-27 07:50:02 --> Config Class Initialized
INFO - 2023-04-27 07:50:02 --> Hooks Class Initialized
INFO - 2023-04-27 07:50:02 --> Language Class Initialized
DEBUG - 2023-04-27 07:50:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:50:02 --> Utf8 Class Initialized
INFO - 2023-04-27 07:50:02 --> Loader Class Initialized
INFO - 2023-04-27 07:50:02 --> URI Class Initialized
INFO - 2023-04-27 07:50:02 --> Controller Class Initialized
INFO - 2023-04-27 07:50:02 --> Router Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:50:02 --> Output Class Initialized
INFO - 2023-04-27 07:50:02 --> Security Class Initialized
INFO - 2023-04-27 07:50:02 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:50:02 --> Input Class Initialized
INFO - 2023-04-27 07:50:02 --> Language Class Initialized
INFO - 2023-04-27 07:50:02 --> Loader Class Initialized
INFO - 2023-04-27 07:50:02 --> Controller Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:50:02 --> Database Driver Class Initialized
INFO - 2023-04-27 07:50:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:50:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:50:02 --> Final output sent to browser
DEBUG - 2023-04-27 07:50:02 --> Total execution time: 0.1547
INFO - 2023-04-27 07:50:02 --> Final output sent to browser
INFO - 2023-04-27 07:50:02 --> Config Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Total execution time: 0.1577
INFO - 2023-04-27 07:50:02 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:50:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:50:02 --> Utf8 Class Initialized
INFO - 2023-04-27 07:50:02 --> URI Class Initialized
INFO - 2023-04-27 07:50:02 --> Router Class Initialized
INFO - 2023-04-27 07:50:02 --> Output Class Initialized
INFO - 2023-04-27 07:50:02 --> Security Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:50:02 --> Config Class Initialized
INFO - 2023-04-27 07:50:02 --> Hooks Class Initialized
INFO - 2023-04-27 07:50:02 --> Input Class Initialized
DEBUG - 2023-04-27 07:50:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:50:02 --> Language Class Initialized
INFO - 2023-04-27 07:50:02 --> Utf8 Class Initialized
INFO - 2023-04-27 07:50:02 --> Loader Class Initialized
INFO - 2023-04-27 07:50:02 --> URI Class Initialized
INFO - 2023-04-27 07:50:02 --> Controller Class Initialized
INFO - 2023-04-27 07:50:02 --> Router Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:50:02 --> Output Class Initialized
INFO - 2023-04-27 07:50:02 --> Security Class Initialized
INFO - 2023-04-27 07:50:02 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:50:02 --> Input Class Initialized
INFO - 2023-04-27 07:50:02 --> Language Class Initialized
INFO - 2023-04-27 07:50:02 --> Loader Class Initialized
INFO - 2023-04-27 07:50:02 --> Controller Class Initialized
DEBUG - 2023-04-27 07:50:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:50:02 --> Database Driver Class Initialized
INFO - 2023-04-27 07:50:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:50:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:50:02 --> Final output sent to browser
DEBUG - 2023-04-27 07:50:02 --> Total execution time: 0.0918
INFO - 2023-04-27 07:50:02 --> Final output sent to browser
DEBUG - 2023-04-27 07:50:02 --> Total execution time: 0.0539
INFO - 2023-04-27 07:50:05 --> Config Class Initialized
INFO - 2023-04-27 07:50:05 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:50:05 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:50:05 --> Utf8 Class Initialized
INFO - 2023-04-27 07:50:05 --> URI Class Initialized
INFO - 2023-04-27 07:50:05 --> Router Class Initialized
INFO - 2023-04-27 07:50:05 --> Output Class Initialized
INFO - 2023-04-27 07:50:05 --> Security Class Initialized
DEBUG - 2023-04-27 07:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:50:05 --> Input Class Initialized
INFO - 2023-04-27 07:50:05 --> Language Class Initialized
INFO - 2023-04-27 07:50:05 --> Loader Class Initialized
INFO - 2023-04-27 07:50:05 --> Controller Class Initialized
DEBUG - 2023-04-27 07:50:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:50:05 --> Database Driver Class Initialized
INFO - 2023-04-27 07:50:05 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:50:05 --> Final output sent to browser
DEBUG - 2023-04-27 07:50:05 --> Total execution time: 0.0122
INFO - 2023-04-27 07:50:05 --> Config Class Initialized
INFO - 2023-04-27 07:50:05 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:50:05 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:50:05 --> Utf8 Class Initialized
INFO - 2023-04-27 07:50:05 --> URI Class Initialized
INFO - 2023-04-27 07:50:05 --> Router Class Initialized
INFO - 2023-04-27 07:50:05 --> Output Class Initialized
INFO - 2023-04-27 07:50:05 --> Security Class Initialized
DEBUG - 2023-04-27 07:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:50:05 --> Input Class Initialized
INFO - 2023-04-27 07:50:05 --> Language Class Initialized
INFO - 2023-04-27 07:50:05 --> Loader Class Initialized
INFO - 2023-04-27 07:50:05 --> Controller Class Initialized
DEBUG - 2023-04-27 07:50:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:50:05 --> Database Driver Class Initialized
INFO - 2023-04-27 07:50:05 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:50:05 --> Final output sent to browser
DEBUG - 2023-04-27 07:50:05 --> Total execution time: 0.0539
INFO - 2023-04-27 07:50:05 --> Config Class Initialized
INFO - 2023-04-27 07:50:05 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:50:05 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:50:05 --> Utf8 Class Initialized
INFO - 2023-04-27 07:50:05 --> URI Class Initialized
INFO - 2023-04-27 07:50:05 --> Router Class Initialized
INFO - 2023-04-27 07:50:05 --> Output Class Initialized
INFO - 2023-04-27 07:50:05 --> Security Class Initialized
DEBUG - 2023-04-27 07:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:50:05 --> Input Class Initialized
INFO - 2023-04-27 07:50:05 --> Language Class Initialized
INFO - 2023-04-27 07:50:05 --> Loader Class Initialized
INFO - 2023-04-27 07:50:05 --> Controller Class Initialized
DEBUG - 2023-04-27 07:50:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:50:05 --> Database Driver Class Initialized
INFO - 2023-04-27 07:50:05 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:50:05 --> Final output sent to browser
DEBUG - 2023-04-27 07:50:05 --> Total execution time: 0.0543
INFO - 2023-04-27 07:50:05 --> Config Class Initialized
INFO - 2023-04-27 07:50:05 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:50:05 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:50:05 --> Utf8 Class Initialized
INFO - 2023-04-27 07:50:05 --> URI Class Initialized
INFO - 2023-04-27 07:50:05 --> Router Class Initialized
INFO - 2023-04-27 07:50:05 --> Output Class Initialized
INFO - 2023-04-27 07:50:05 --> Security Class Initialized
DEBUG - 2023-04-27 07:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:50:05 --> Input Class Initialized
INFO - 2023-04-27 07:50:05 --> Language Class Initialized
INFO - 2023-04-27 07:50:05 --> Loader Class Initialized
INFO - 2023-04-27 07:50:05 --> Controller Class Initialized
DEBUG - 2023-04-27 07:50:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:50:05 --> Database Driver Class Initialized
INFO - 2023-04-27 07:50:05 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:50:05 --> Final output sent to browser
DEBUG - 2023-04-27 07:50:05 --> Total execution time: 0.0105
INFO - 2023-04-27 07:51:18 --> Config Class Initialized
INFO - 2023-04-27 07:51:18 --> Config Class Initialized
INFO - 2023-04-27 07:51:18 --> Hooks Class Initialized
INFO - 2023-04-27 07:51:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:51:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:18 --> URI Class Initialized
INFO - 2023-04-27 07:51:18 --> URI Class Initialized
INFO - 2023-04-27 07:51:18 --> Router Class Initialized
INFO - 2023-04-27 07:51:18 --> Router Class Initialized
INFO - 2023-04-27 07:51:18 --> Output Class Initialized
INFO - 2023-04-27 07:51:18 --> Output Class Initialized
INFO - 2023-04-27 07:51:18 --> Security Class Initialized
INFO - 2023-04-27 07:51:18 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:18 --> Input Class Initialized
INFO - 2023-04-27 07:51:18 --> Input Class Initialized
INFO - 2023-04-27 07:51:18 --> Language Class Initialized
INFO - 2023-04-27 07:51:18 --> Language Class Initialized
INFO - 2023-04-27 07:51:18 --> Loader Class Initialized
INFO - 2023-04-27 07:51:18 --> Loader Class Initialized
INFO - 2023-04-27 07:51:18 --> Controller Class Initialized
INFO - 2023-04-27 07:51:18 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:51:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:18 --> Total execution time: 0.0152
INFO - 2023-04-27 07:51:18 --> Final output sent to browser
INFO - 2023-04-27 07:51:18 --> Config Class Initialized
INFO - 2023-04-27 07:51:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:18 --> Total execution time: 0.0170
DEBUG - 2023-04-27 07:51:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:18 --> URI Class Initialized
INFO - 2023-04-27 07:51:18 --> Router Class Initialized
INFO - 2023-04-27 07:51:18 --> Output Class Initialized
INFO - 2023-04-27 07:51:18 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:18 --> Input Class Initialized
INFO - 2023-04-27 07:51:18 --> Language Class Initialized
INFO - 2023-04-27 07:51:18 --> Loader Class Initialized
INFO - 2023-04-27 07:51:18 --> Config Class Initialized
INFO - 2023-04-27 07:51:18 --> Controller Class Initialized
INFO - 2023-04-27 07:51:18 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:51:18 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:18 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:18 --> URI Class Initialized
INFO - 2023-04-27 07:51:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:18 --> Router Class Initialized
INFO - 2023-04-27 07:51:18 --> Output Class Initialized
INFO - 2023-04-27 07:51:18 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:18 --> Input Class Initialized
INFO - 2023-04-27 07:51:18 --> Language Class Initialized
INFO - 2023-04-27 07:51:18 --> Loader Class Initialized
INFO - 2023-04-27 07:51:18 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:18 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:18 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:18 --> Total execution time: 0.0533
INFO - 2023-04-27 07:51:18 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:18 --> Total execution time: 0.0136
INFO - 2023-04-27 07:51:23 --> Config Class Initialized
INFO - 2023-04-27 07:51:23 --> Config Class Initialized
INFO - 2023-04-27 07:51:23 --> Hooks Class Initialized
INFO - 2023-04-27 07:51:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:51:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:23 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:23 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:23 --> URI Class Initialized
INFO - 2023-04-27 07:51:23 --> URI Class Initialized
INFO - 2023-04-27 07:51:23 --> Router Class Initialized
INFO - 2023-04-27 07:51:23 --> Router Class Initialized
INFO - 2023-04-27 07:51:23 --> Output Class Initialized
INFO - 2023-04-27 07:51:23 --> Security Class Initialized
INFO - 2023-04-27 07:51:23 --> Output Class Initialized
DEBUG - 2023-04-27 07:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:23 --> Security Class Initialized
INFO - 2023-04-27 07:51:23 --> Input Class Initialized
DEBUG - 2023-04-27 07:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:23 --> Language Class Initialized
INFO - 2023-04-27 07:51:23 --> Loader Class Initialized
INFO - 2023-04-27 07:51:23 --> Controller Class Initialized
INFO - 2023-04-27 07:51:23 --> Input Class Initialized
DEBUG - 2023-04-27 07:51:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:23 --> Language Class Initialized
INFO - 2023-04-27 07:51:23 --> Loader Class Initialized
INFO - 2023-04-27 07:51:23 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:23 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:23 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:23 --> Final output sent to browser
INFO - 2023-04-27 07:51:23 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:23 --> Total execution time: 0.1045
DEBUG - 2023-04-27 07:51:23 --> Total execution time: 0.1048
INFO - 2023-04-27 07:51:26 --> Config Class Initialized
INFO - 2023-04-27 07:51:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:26 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:26 --> URI Class Initialized
INFO - 2023-04-27 07:51:26 --> Router Class Initialized
INFO - 2023-04-27 07:51:26 --> Output Class Initialized
INFO - 2023-04-27 07:51:26 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:26 --> Input Class Initialized
INFO - 2023-04-27 07:51:26 --> Language Class Initialized
INFO - 2023-04-27 07:51:26 --> Loader Class Initialized
INFO - 2023-04-27 07:51:26 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:26 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:26 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:26 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:26 --> Total execution time: 0.0154
INFO - 2023-04-27 07:51:26 --> Config Class Initialized
INFO - 2023-04-27 07:51:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:26 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:26 --> URI Class Initialized
INFO - 2023-04-27 07:51:26 --> Router Class Initialized
INFO - 2023-04-27 07:51:26 --> Output Class Initialized
INFO - 2023-04-27 07:51:26 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:26 --> Input Class Initialized
INFO - 2023-04-27 07:51:26 --> Language Class Initialized
INFO - 2023-04-27 07:51:26 --> Loader Class Initialized
INFO - 2023-04-27 07:51:26 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:26 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:26 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:26 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:26 --> Total execution time: 0.0524
INFO - 2023-04-27 07:51:28 --> Config Class Initialized
INFO - 2023-04-27 07:51:28 --> Config Class Initialized
INFO - 2023-04-27 07:51:28 --> Hooks Class Initialized
INFO - 2023-04-27 07:51:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:51:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:28 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:28 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:28 --> URI Class Initialized
INFO - 2023-04-27 07:51:28 --> URI Class Initialized
INFO - 2023-04-27 07:51:28 --> Router Class Initialized
INFO - 2023-04-27 07:51:28 --> Router Class Initialized
INFO - 2023-04-27 07:51:28 --> Output Class Initialized
INFO - 2023-04-27 07:51:28 --> Output Class Initialized
INFO - 2023-04-27 07:51:28 --> Security Class Initialized
INFO - 2023-04-27 07:51:28 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:28 --> Input Class Initialized
INFO - 2023-04-27 07:51:28 --> Input Class Initialized
INFO - 2023-04-27 07:51:28 --> Language Class Initialized
INFO - 2023-04-27 07:51:28 --> Language Class Initialized
INFO - 2023-04-27 07:51:28 --> Loader Class Initialized
INFO - 2023-04-27 07:51:28 --> Loader Class Initialized
INFO - 2023-04-27 07:51:28 --> Controller Class Initialized
INFO - 2023-04-27 07:51:28 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:51:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:28 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:28 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:28 --> Total execution time: 0.0455
INFO - 2023-04-27 07:51:28 --> Config Class Initialized
INFO - 2023-04-27 07:51:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:28 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:28 --> URI Class Initialized
INFO - 2023-04-27 07:51:28 --> Router Class Initialized
INFO - 2023-04-27 07:51:28 --> Output Class Initialized
INFO - 2023-04-27 07:51:28 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:28 --> Input Class Initialized
INFO - 2023-04-27 07:51:28 --> Language Class Initialized
INFO - 2023-04-27 07:51:28 --> Loader Class Initialized
INFO - 2023-04-27 07:51:28 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:28 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:28 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:28 --> Total execution time: 0.0910
INFO - 2023-04-27 07:51:28 --> Config Class Initialized
INFO - 2023-04-27 07:51:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:28 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:28 --> URI Class Initialized
INFO - 2023-04-27 07:51:28 --> Router Class Initialized
INFO - 2023-04-27 07:51:28 --> Output Class Initialized
INFO - 2023-04-27 07:51:28 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:28 --> Input Class Initialized
INFO - 2023-04-27 07:51:28 --> Language Class Initialized
INFO - 2023-04-27 07:51:28 --> Loader Class Initialized
INFO - 2023-04-27 07:51:28 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:28 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:28 --> Model "Login_model" initialized
INFO - 2023-04-27 07:51:28 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:28 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:28 --> Total execution time: 0.0122
INFO - 2023-04-27 07:51:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:28 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:28 --> Total execution time: 0.1027
INFO - 2023-04-27 07:51:30 --> Config Class Initialized
INFO - 2023-04-27 07:51:30 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:30 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:30 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:30 --> URI Class Initialized
INFO - 2023-04-27 07:51:30 --> Router Class Initialized
INFO - 2023-04-27 07:51:30 --> Output Class Initialized
INFO - 2023-04-27 07:51:30 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:30 --> Input Class Initialized
INFO - 2023-04-27 07:51:30 --> Language Class Initialized
INFO - 2023-04-27 07:51:30 --> Loader Class Initialized
INFO - 2023-04-27 07:51:30 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:30 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:30 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:30 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:30 --> Total execution time: 0.0144
INFO - 2023-04-27 07:51:32 --> Config Class Initialized
INFO - 2023-04-27 07:51:32 --> Config Class Initialized
INFO - 2023-04-27 07:51:32 --> Hooks Class Initialized
INFO - 2023-04-27 07:51:32 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:51:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:32 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:32 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:32 --> URI Class Initialized
INFO - 2023-04-27 07:51:32 --> URI Class Initialized
INFO - 2023-04-27 07:51:32 --> Router Class Initialized
INFO - 2023-04-27 07:51:32 --> Router Class Initialized
INFO - 2023-04-27 07:51:32 --> Output Class Initialized
INFO - 2023-04-27 07:51:32 --> Output Class Initialized
INFO - 2023-04-27 07:51:32 --> Security Class Initialized
INFO - 2023-04-27 07:51:32 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:32 --> Input Class Initialized
INFO - 2023-04-27 07:51:32 --> Input Class Initialized
INFO - 2023-04-27 07:51:32 --> Language Class Initialized
INFO - 2023-04-27 07:51:32 --> Language Class Initialized
INFO - 2023-04-27 07:51:32 --> Loader Class Initialized
INFO - 2023-04-27 07:51:32 --> Loader Class Initialized
INFO - 2023-04-27 07:51:32 --> Controller Class Initialized
INFO - 2023-04-27 07:51:32 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:32 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:32 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:32 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:32 --> Total execution time: 0.0197
INFO - 2023-04-27 07:51:32 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:32 --> Total execution time: 0.0214
INFO - 2023-04-27 07:51:32 --> Config Class Initialized
INFO - 2023-04-27 07:51:32 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:32 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:32 --> URI Class Initialized
INFO - 2023-04-27 07:51:32 --> Router Class Initialized
INFO - 2023-04-27 07:51:32 --> Output Class Initialized
INFO - 2023-04-27 07:51:32 --> Config Class Initialized
INFO - 2023-04-27 07:51:32 --> Security Class Initialized
INFO - 2023-04-27 07:51:32 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:51:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:32 --> Input Class Initialized
INFO - 2023-04-27 07:51:32 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:32 --> Language Class Initialized
INFO - 2023-04-27 07:51:32 --> URI Class Initialized
INFO - 2023-04-27 07:51:32 --> Loader Class Initialized
INFO - 2023-04-27 07:51:32 --> Router Class Initialized
INFO - 2023-04-27 07:51:32 --> Controller Class Initialized
INFO - 2023-04-27 07:51:32 --> Output Class Initialized
DEBUG - 2023-04-27 07:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:32 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:32 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:32 --> Input Class Initialized
INFO - 2023-04-27 07:51:32 --> Language Class Initialized
INFO - 2023-04-27 07:51:32 --> Loader Class Initialized
INFO - 2023-04-27 07:51:32 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:32 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:32 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:32 --> Total execution time: 0.0124
INFO - 2023-04-27 07:51:32 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:32 --> Total execution time: 0.0141
INFO - 2023-04-27 07:51:36 --> Config Class Initialized
INFO - 2023-04-27 07:51:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:36 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:36 --> URI Class Initialized
INFO - 2023-04-27 07:51:36 --> Router Class Initialized
INFO - 2023-04-27 07:51:36 --> Output Class Initialized
INFO - 2023-04-27 07:51:36 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:36 --> Input Class Initialized
INFO - 2023-04-27 07:51:36 --> Language Class Initialized
INFO - 2023-04-27 07:51:36 --> Loader Class Initialized
INFO - 2023-04-27 07:51:36 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:36 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:36 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:36 --> Total execution time: 0.0957
INFO - 2023-04-27 07:51:36 --> Config Class Initialized
INFO - 2023-04-27 07:51:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:36 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:36 --> URI Class Initialized
INFO - 2023-04-27 07:51:36 --> Router Class Initialized
INFO - 2023-04-27 07:51:36 --> Output Class Initialized
INFO - 2023-04-27 07:51:36 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:36 --> Input Class Initialized
INFO - 2023-04-27 07:51:36 --> Language Class Initialized
INFO - 2023-04-27 07:51:36 --> Loader Class Initialized
INFO - 2023-04-27 07:51:36 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:36 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:36 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:36 --> Model "Login_model" initialized
INFO - 2023-04-27 07:51:36 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:36 --> Total execution time: 0.0312
INFO - 2023-04-27 07:51:36 --> Config Class Initialized
INFO - 2023-04-27 07:51:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:36 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:36 --> URI Class Initialized
INFO - 2023-04-27 07:51:36 --> Router Class Initialized
INFO - 2023-04-27 07:51:36 --> Output Class Initialized
INFO - 2023-04-27 07:51:36 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:36 --> Input Class Initialized
INFO - 2023-04-27 07:51:36 --> Language Class Initialized
INFO - 2023-04-27 07:51:36 --> Loader Class Initialized
INFO - 2023-04-27 07:51:36 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:36 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:36 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:36 --> Total execution time: 0.0263
INFO - 2023-04-27 07:51:36 --> Config Class Initialized
INFO - 2023-04-27 07:51:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:36 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:36 --> URI Class Initialized
INFO - 2023-04-27 07:51:36 --> Router Class Initialized
INFO - 2023-04-27 07:51:36 --> Output Class Initialized
INFO - 2023-04-27 07:51:36 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:36 --> Input Class Initialized
INFO - 2023-04-27 07:51:36 --> Language Class Initialized
INFO - 2023-04-27 07:51:36 --> Loader Class Initialized
INFO - 2023-04-27 07:51:36 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:36 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:36 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:36 --> Total execution time: 0.0537
INFO - 2023-04-27 07:51:41 --> Config Class Initialized
INFO - 2023-04-27 07:51:41 --> Config Class Initialized
INFO - 2023-04-27 07:51:41 --> Hooks Class Initialized
INFO - 2023-04-27 07:51:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:51:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:41 --> URI Class Initialized
INFO - 2023-04-27 07:51:41 --> URI Class Initialized
INFO - 2023-04-27 07:51:41 --> Router Class Initialized
INFO - 2023-04-27 07:51:41 --> Router Class Initialized
INFO - 2023-04-27 07:51:41 --> Output Class Initialized
INFO - 2023-04-27 07:51:41 --> Output Class Initialized
INFO - 2023-04-27 07:51:41 --> Security Class Initialized
INFO - 2023-04-27 07:51:41 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:41 --> Input Class Initialized
INFO - 2023-04-27 07:51:41 --> Input Class Initialized
INFO - 2023-04-27 07:51:41 --> Language Class Initialized
INFO - 2023-04-27 07:51:41 --> Language Class Initialized
INFO - 2023-04-27 07:51:41 --> Loader Class Initialized
INFO - 2023-04-27 07:51:41 --> Loader Class Initialized
INFO - 2023-04-27 07:51:41 --> Controller Class Initialized
INFO - 2023-04-27 07:51:41 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:41 --> Total execution time: 0.0224
INFO - 2023-04-27 07:51:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:41 --> Total execution time: 0.0242
INFO - 2023-04-27 07:51:41 --> Config Class Initialized
INFO - 2023-04-27 07:51:41 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:41 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:41 --> URI Class Initialized
INFO - 2023-04-27 07:51:41 --> Config Class Initialized
INFO - 2023-04-27 07:51:41 --> Router Class Initialized
INFO - 2023-04-27 07:51:41 --> Hooks Class Initialized
INFO - 2023-04-27 07:51:41 --> Output Class Initialized
INFO - 2023-04-27 07:51:41 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:41 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:41 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:41 --> Input Class Initialized
INFO - 2023-04-27 07:51:41 --> URI Class Initialized
INFO - 2023-04-27 07:51:41 --> Language Class Initialized
INFO - 2023-04-27 07:51:41 --> Router Class Initialized
INFO - 2023-04-27 07:51:41 --> Loader Class Initialized
INFO - 2023-04-27 07:51:41 --> Output Class Initialized
INFO - 2023-04-27 07:51:41 --> Controller Class Initialized
INFO - 2023-04-27 07:51:41 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:41 --> Input Class Initialized
INFO - 2023-04-27 07:51:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:41 --> Language Class Initialized
INFO - 2023-04-27 07:51:41 --> Loader Class Initialized
INFO - 2023-04-27 07:51:41 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:41 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:41 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:41 --> Total execution time: 0.0182
INFO - 2023-04-27 07:51:41 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:41 --> Total execution time: 0.0195
INFO - 2023-04-27 07:51:43 --> Config Class Initialized
INFO - 2023-04-27 07:51:43 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:43 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:43 --> URI Class Initialized
INFO - 2023-04-27 07:51:43 --> Router Class Initialized
INFO - 2023-04-27 07:51:43 --> Output Class Initialized
INFO - 2023-04-27 07:51:43 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:43 --> Input Class Initialized
INFO - 2023-04-27 07:51:43 --> Language Class Initialized
INFO - 2023-04-27 07:51:43 --> Loader Class Initialized
INFO - 2023-04-27 07:51:43 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:43 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:43 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:43 --> Total execution time: 0.0139
INFO - 2023-04-27 07:51:43 --> Config Class Initialized
INFO - 2023-04-27 07:51:43 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:43 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:43 --> URI Class Initialized
INFO - 2023-04-27 07:51:43 --> Router Class Initialized
INFO - 2023-04-27 07:51:43 --> Output Class Initialized
INFO - 2023-04-27 07:51:43 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:43 --> Input Class Initialized
INFO - 2023-04-27 07:51:43 --> Language Class Initialized
INFO - 2023-04-27 07:51:43 --> Loader Class Initialized
INFO - 2023-04-27 07:51:43 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:43 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:43 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:43 --> Total execution time: 0.0142
INFO - 2023-04-27 07:51:43 --> Config Class Initialized
INFO - 2023-04-27 07:51:43 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:43 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:43 --> URI Class Initialized
INFO - 2023-04-27 07:51:43 --> Router Class Initialized
INFO - 2023-04-27 07:51:43 --> Output Class Initialized
INFO - 2023-04-27 07:51:43 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:43 --> Input Class Initialized
INFO - 2023-04-27 07:51:43 --> Language Class Initialized
INFO - 2023-04-27 07:51:43 --> Loader Class Initialized
INFO - 2023-04-27 07:51:43 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:43 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:43 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:43 --> Total execution time: 0.0490
INFO - 2023-04-27 07:51:43 --> Config Class Initialized
INFO - 2023-04-27 07:51:44 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:51:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:51:44 --> Utf8 Class Initialized
INFO - 2023-04-27 07:51:44 --> URI Class Initialized
INFO - 2023-04-27 07:51:44 --> Router Class Initialized
INFO - 2023-04-27 07:51:44 --> Output Class Initialized
INFO - 2023-04-27 07:51:44 --> Security Class Initialized
DEBUG - 2023-04-27 07:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:51:44 --> Input Class Initialized
INFO - 2023-04-27 07:51:44 --> Language Class Initialized
INFO - 2023-04-27 07:51:44 --> Loader Class Initialized
INFO - 2023-04-27 07:51:44 --> Controller Class Initialized
DEBUG - 2023-04-27 07:51:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:51:44 --> Database Driver Class Initialized
INFO - 2023-04-27 07:51:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:51:44 --> Final output sent to browser
DEBUG - 2023-04-27 07:51:44 --> Total execution time: 0.0526
INFO - 2023-04-27 07:53:44 --> Config Class Initialized
INFO - 2023-04-27 07:53:44 --> Config Class Initialized
INFO - 2023-04-27 07:53:44 --> Hooks Class Initialized
INFO - 2023-04-27 07:53:44 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:53:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:53:44 --> Utf8 Class Initialized
INFO - 2023-04-27 07:53:44 --> Utf8 Class Initialized
INFO - 2023-04-27 07:53:44 --> URI Class Initialized
INFO - 2023-04-27 07:53:44 --> URI Class Initialized
INFO - 2023-04-27 07:53:44 --> Router Class Initialized
INFO - 2023-04-27 07:53:44 --> Router Class Initialized
INFO - 2023-04-27 07:53:44 --> Output Class Initialized
INFO - 2023-04-27 07:53:44 --> Output Class Initialized
INFO - 2023-04-27 07:53:44 --> Security Class Initialized
INFO - 2023-04-27 07:53:44 --> Security Class Initialized
DEBUG - 2023-04-27 07:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:53:44 --> Input Class Initialized
INFO - 2023-04-27 07:53:44 --> Input Class Initialized
INFO - 2023-04-27 07:53:44 --> Language Class Initialized
INFO - 2023-04-27 07:53:44 --> Language Class Initialized
INFO - 2023-04-27 07:53:44 --> Loader Class Initialized
INFO - 2023-04-27 07:53:44 --> Loader Class Initialized
INFO - 2023-04-27 07:53:44 --> Controller Class Initialized
INFO - 2023-04-27 07:53:44 --> Controller Class Initialized
DEBUG - 2023-04-27 07:53:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:53:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:53:44 --> Database Driver Class Initialized
INFO - 2023-04-27 07:53:44 --> Database Driver Class Initialized
INFO - 2023-04-27 07:53:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:53:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:53:44 --> Final output sent to browser
DEBUG - 2023-04-27 07:53:44 --> Total execution time: 0.0138
INFO - 2023-04-27 07:53:44 --> Final output sent to browser
DEBUG - 2023-04-27 07:53:44 --> Total execution time: 0.0154
INFO - 2023-04-27 07:53:44 --> Config Class Initialized
INFO - 2023-04-27 07:53:44 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:53:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:53:44 --> Utf8 Class Initialized
INFO - 2023-04-27 07:53:44 --> URI Class Initialized
INFO - 2023-04-27 07:53:44 --> Router Class Initialized
INFO - 2023-04-27 07:53:44 --> Config Class Initialized
INFO - 2023-04-27 07:53:44 --> Hooks Class Initialized
INFO - 2023-04-27 07:53:44 --> Output Class Initialized
DEBUG - 2023-04-27 07:53:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:53:44 --> Security Class Initialized
INFO - 2023-04-27 07:53:44 --> Utf8 Class Initialized
DEBUG - 2023-04-27 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:53:44 --> URI Class Initialized
INFO - 2023-04-27 07:53:44 --> Input Class Initialized
INFO - 2023-04-27 07:53:44 --> Router Class Initialized
INFO - 2023-04-27 07:53:44 --> Language Class Initialized
INFO - 2023-04-27 07:53:44 --> Output Class Initialized
INFO - 2023-04-27 07:53:44 --> Loader Class Initialized
INFO - 2023-04-27 07:53:44 --> Security Class Initialized
INFO - 2023-04-27 07:53:44 --> Controller Class Initialized
DEBUG - 2023-04-27 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:53:44 --> Input Class Initialized
DEBUG - 2023-04-27 07:53:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:53:44 --> Language Class Initialized
INFO - 2023-04-27 07:53:44 --> Database Driver Class Initialized
INFO - 2023-04-27 07:53:44 --> Loader Class Initialized
INFO - 2023-04-27 07:53:44 --> Controller Class Initialized
DEBUG - 2023-04-27 07:53:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:53:44 --> Database Driver Class Initialized
INFO - 2023-04-27 07:53:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:53:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:53:44 --> Final output sent to browser
INFO - 2023-04-27 07:53:44 --> Final output sent to browser
DEBUG - 2023-04-27 07:53:44 --> Total execution time: 0.0545
DEBUG - 2023-04-27 07:53:44 --> Total execution time: 0.0970
INFO - 2023-04-27 07:53:45 --> Config Class Initialized
INFO - 2023-04-27 07:53:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:53:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:53:45 --> Utf8 Class Initialized
INFO - 2023-04-27 07:53:45 --> URI Class Initialized
INFO - 2023-04-27 07:53:45 --> Router Class Initialized
INFO - 2023-04-27 07:53:45 --> Output Class Initialized
INFO - 2023-04-27 07:53:45 --> Security Class Initialized
DEBUG - 2023-04-27 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:53:45 --> Input Class Initialized
INFO - 2023-04-27 07:53:45 --> Language Class Initialized
INFO - 2023-04-27 07:53:45 --> Loader Class Initialized
INFO - 2023-04-27 07:53:45 --> Controller Class Initialized
DEBUG - 2023-04-27 07:53:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:53:45 --> Database Driver Class Initialized
INFO - 2023-04-27 07:53:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:53:45 --> Final output sent to browser
DEBUG - 2023-04-27 07:53:45 --> Total execution time: 0.0119
INFO - 2023-04-27 07:53:45 --> Config Class Initialized
INFO - 2023-04-27 07:53:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:53:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:53:45 --> Utf8 Class Initialized
INFO - 2023-04-27 07:53:45 --> URI Class Initialized
INFO - 2023-04-27 07:53:45 --> Router Class Initialized
INFO - 2023-04-27 07:53:45 --> Output Class Initialized
INFO - 2023-04-27 07:53:45 --> Security Class Initialized
DEBUG - 2023-04-27 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:53:45 --> Input Class Initialized
INFO - 2023-04-27 07:53:45 --> Language Class Initialized
INFO - 2023-04-27 07:53:45 --> Loader Class Initialized
INFO - 2023-04-27 07:53:45 --> Controller Class Initialized
DEBUG - 2023-04-27 07:53:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:53:45 --> Database Driver Class Initialized
INFO - 2023-04-27 07:53:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:53:45 --> Final output sent to browser
DEBUG - 2023-04-27 07:53:45 --> Total execution time: 0.0123
INFO - 2023-04-27 07:53:45 --> Config Class Initialized
INFO - 2023-04-27 07:53:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:53:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:53:45 --> Utf8 Class Initialized
INFO - 2023-04-27 07:53:45 --> URI Class Initialized
INFO - 2023-04-27 07:53:45 --> Router Class Initialized
INFO - 2023-04-27 07:53:45 --> Output Class Initialized
INFO - 2023-04-27 07:53:45 --> Security Class Initialized
DEBUG - 2023-04-27 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:53:45 --> Input Class Initialized
INFO - 2023-04-27 07:53:45 --> Language Class Initialized
INFO - 2023-04-27 07:53:45 --> Loader Class Initialized
INFO - 2023-04-27 07:53:45 --> Controller Class Initialized
DEBUG - 2023-04-27 07:53:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:53:45 --> Database Driver Class Initialized
INFO - 2023-04-27 07:53:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:53:45 --> Final output sent to browser
DEBUG - 2023-04-27 07:53:45 --> Total execution time: 0.0531
INFO - 2023-04-27 07:53:45 --> Config Class Initialized
INFO - 2023-04-27 07:53:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:53:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:53:45 --> Utf8 Class Initialized
INFO - 2023-04-27 07:53:45 --> URI Class Initialized
INFO - 2023-04-27 07:53:45 --> Router Class Initialized
INFO - 2023-04-27 07:53:45 --> Output Class Initialized
INFO - 2023-04-27 07:53:45 --> Security Class Initialized
DEBUG - 2023-04-27 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:53:45 --> Input Class Initialized
INFO - 2023-04-27 07:53:45 --> Language Class Initialized
INFO - 2023-04-27 07:53:45 --> Loader Class Initialized
INFO - 2023-04-27 07:53:45 --> Controller Class Initialized
DEBUG - 2023-04-27 07:53:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:53:45 --> Database Driver Class Initialized
INFO - 2023-04-27 07:53:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:53:45 --> Final output sent to browser
DEBUG - 2023-04-27 07:53:45 --> Total execution time: 0.0116
INFO - 2023-04-27 07:54:40 --> Config Class Initialized
INFO - 2023-04-27 07:54:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:54:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:54:40 --> Utf8 Class Initialized
INFO - 2023-04-27 07:54:40 --> URI Class Initialized
INFO - 2023-04-27 07:54:40 --> Router Class Initialized
INFO - 2023-04-27 07:54:40 --> Output Class Initialized
INFO - 2023-04-27 07:54:40 --> Security Class Initialized
DEBUG - 2023-04-27 07:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:54:40 --> Input Class Initialized
INFO - 2023-04-27 07:54:40 --> Language Class Initialized
INFO - 2023-04-27 07:54:40 --> Loader Class Initialized
INFO - 2023-04-27 07:54:40 --> Controller Class Initialized
DEBUG - 2023-04-27 07:54:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:54:40 --> Database Driver Class Initialized
INFO - 2023-04-27 07:54:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:54:40 --> Final output sent to browser
DEBUG - 2023-04-27 07:54:40 --> Total execution time: 0.0149
INFO - 2023-04-27 07:54:40 --> Config Class Initialized
INFO - 2023-04-27 07:54:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:54:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:54:40 --> Utf8 Class Initialized
INFO - 2023-04-27 07:54:40 --> URI Class Initialized
INFO - 2023-04-27 07:54:40 --> Router Class Initialized
INFO - 2023-04-27 07:54:40 --> Output Class Initialized
INFO - 2023-04-27 07:54:40 --> Security Class Initialized
DEBUG - 2023-04-27 07:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:54:40 --> Input Class Initialized
INFO - 2023-04-27 07:54:40 --> Language Class Initialized
INFO - 2023-04-27 07:54:40 --> Loader Class Initialized
INFO - 2023-04-27 07:54:40 --> Controller Class Initialized
DEBUG - 2023-04-27 07:54:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:54:40 --> Database Driver Class Initialized
INFO - 2023-04-27 07:54:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:54:40 --> Final output sent to browser
DEBUG - 2023-04-27 07:54:40 --> Total execution time: 0.0115
INFO - 2023-04-27 07:54:40 --> Config Class Initialized
INFO - 2023-04-27 07:54:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:54:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:54:40 --> Utf8 Class Initialized
INFO - 2023-04-27 07:54:40 --> URI Class Initialized
INFO - 2023-04-27 07:54:40 --> Router Class Initialized
INFO - 2023-04-27 07:54:40 --> Output Class Initialized
INFO - 2023-04-27 07:54:40 --> Security Class Initialized
DEBUG - 2023-04-27 07:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:54:40 --> Input Class Initialized
INFO - 2023-04-27 07:54:40 --> Language Class Initialized
INFO - 2023-04-27 07:54:40 --> Loader Class Initialized
INFO - 2023-04-27 07:54:40 --> Controller Class Initialized
DEBUG - 2023-04-27 07:54:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:54:40 --> Database Driver Class Initialized
INFO - 2023-04-27 07:54:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:54:40 --> Final output sent to browser
DEBUG - 2023-04-27 07:54:40 --> Total execution time: 0.0109
INFO - 2023-04-27 07:54:40 --> Config Class Initialized
INFO - 2023-04-27 07:54:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:54:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:54:40 --> Utf8 Class Initialized
INFO - 2023-04-27 07:54:40 --> URI Class Initialized
INFO - 2023-04-27 07:54:40 --> Router Class Initialized
INFO - 2023-04-27 07:54:40 --> Output Class Initialized
INFO - 2023-04-27 07:54:40 --> Security Class Initialized
DEBUG - 2023-04-27 07:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:54:40 --> Input Class Initialized
INFO - 2023-04-27 07:54:40 --> Language Class Initialized
INFO - 2023-04-27 07:54:40 --> Loader Class Initialized
INFO - 2023-04-27 07:54:40 --> Controller Class Initialized
DEBUG - 2023-04-27 07:54:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:54:40 --> Database Driver Class Initialized
INFO - 2023-04-27 07:54:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:54:40 --> Final output sent to browser
DEBUG - 2023-04-27 07:54:40 --> Total execution time: 0.0114
INFO - 2023-04-27 07:58:00 --> Config Class Initialized
INFO - 2023-04-27 07:58:00 --> Config Class Initialized
INFO - 2023-04-27 07:58:00 --> Hooks Class Initialized
INFO - 2023-04-27 07:58:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:58:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:58:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:58:00 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:00 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:00 --> URI Class Initialized
INFO - 2023-04-27 07:58:00 --> URI Class Initialized
INFO - 2023-04-27 07:58:00 --> Router Class Initialized
INFO - 2023-04-27 07:58:00 --> Router Class Initialized
INFO - 2023-04-27 07:58:00 --> Output Class Initialized
INFO - 2023-04-27 07:58:00 --> Output Class Initialized
INFO - 2023-04-27 07:58:00 --> Security Class Initialized
INFO - 2023-04-27 07:58:00 --> Security Class Initialized
DEBUG - 2023-04-27 07:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 07:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:00 --> Input Class Initialized
INFO - 2023-04-27 07:58:00 --> Input Class Initialized
INFO - 2023-04-27 07:58:00 --> Language Class Initialized
INFO - 2023-04-27 07:58:00 --> Language Class Initialized
INFO - 2023-04-27 07:58:00 --> Loader Class Initialized
INFO - 2023-04-27 07:58:00 --> Loader Class Initialized
INFO - 2023-04-27 07:58:00 --> Controller Class Initialized
INFO - 2023-04-27 07:58:00 --> Controller Class Initialized
DEBUG - 2023-04-27 07:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 07:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:00 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:00 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:00 --> Final output sent to browser
DEBUG - 2023-04-27 07:58:00 --> Total execution time: 0.0343
INFO - 2023-04-27 07:58:00 --> Final output sent to browser
INFO - 2023-04-27 07:58:00 --> Config Class Initialized
DEBUG - 2023-04-27 07:58:00 --> Total execution time: 0.0712
INFO - 2023-04-27 07:58:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:58:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:58:00 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:00 --> URI Class Initialized
INFO - 2023-04-27 07:58:00 --> Router Class Initialized
INFO - 2023-04-27 07:58:00 --> Output Class Initialized
INFO - 2023-04-27 07:58:00 --> Security Class Initialized
DEBUG - 2023-04-27 07:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:00 --> Input Class Initialized
INFO - 2023-04-27 07:58:00 --> Language Class Initialized
INFO - 2023-04-27 07:58:00 --> Config Class Initialized
INFO - 2023-04-27 07:58:00 --> Loader Class Initialized
INFO - 2023-04-27 07:58:00 --> Hooks Class Initialized
INFO - 2023-04-27 07:58:00 --> Controller Class Initialized
DEBUG - 2023-04-27 07:58:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 07:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:00 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:00 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:00 --> URI Class Initialized
INFO - 2023-04-27 07:58:00 --> Router Class Initialized
INFO - 2023-04-27 07:58:00 --> Output Class Initialized
INFO - 2023-04-27 07:58:00 --> Security Class Initialized
DEBUG - 2023-04-27 07:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:00 --> Input Class Initialized
INFO - 2023-04-27 07:58:00 --> Language Class Initialized
INFO - 2023-04-27 07:58:00 --> Loader Class Initialized
INFO - 2023-04-27 07:58:00 --> Controller Class Initialized
DEBUG - 2023-04-27 07:58:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:00 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:00 --> Final output sent to browser
DEBUG - 2023-04-27 07:58:00 --> Total execution time: 0.0576
INFO - 2023-04-27 07:58:00 --> Final output sent to browser
DEBUG - 2023-04-27 07:58:00 --> Total execution time: 0.0187
INFO - 2023-04-27 07:58:05 --> Config Class Initialized
INFO - 2023-04-27 07:58:05 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:58:05 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:58:05 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:05 --> URI Class Initialized
INFO - 2023-04-27 07:58:05 --> Router Class Initialized
INFO - 2023-04-27 07:58:05 --> Output Class Initialized
INFO - 2023-04-27 07:58:05 --> Security Class Initialized
DEBUG - 2023-04-27 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:05 --> Input Class Initialized
INFO - 2023-04-27 07:58:05 --> Language Class Initialized
INFO - 2023-04-27 07:58:05 --> Loader Class Initialized
INFO - 2023-04-27 07:58:05 --> Controller Class Initialized
DEBUG - 2023-04-27 07:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:05 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:05 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:05 --> Final output sent to browser
DEBUG - 2023-04-27 07:58:05 --> Total execution time: 0.0221
INFO - 2023-04-27 07:58:05 --> Config Class Initialized
INFO - 2023-04-27 07:58:05 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:58:05 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:58:05 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:05 --> URI Class Initialized
INFO - 2023-04-27 07:58:05 --> Router Class Initialized
INFO - 2023-04-27 07:58:05 --> Output Class Initialized
INFO - 2023-04-27 07:58:05 --> Security Class Initialized
DEBUG - 2023-04-27 07:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:05 --> Input Class Initialized
INFO - 2023-04-27 07:58:05 --> Language Class Initialized
INFO - 2023-04-27 07:58:05 --> Loader Class Initialized
INFO - 2023-04-27 07:58:05 --> Controller Class Initialized
DEBUG - 2023-04-27 07:58:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:05 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:05 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:05 --> Final output sent to browser
DEBUG - 2023-04-27 07:58:05 --> Total execution time: 0.0608
INFO - 2023-04-27 07:58:06 --> Config Class Initialized
INFO - 2023-04-27 07:58:06 --> Config Class Initialized
INFO - 2023-04-27 07:58:06 --> Hooks Class Initialized
INFO - 2023-04-27 07:58:06 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:58:06 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:58:06 --> Utf8 Class Initialized
DEBUG - 2023-04-27 07:58:06 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:58:06 --> URI Class Initialized
INFO - 2023-04-27 07:58:06 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:06 --> Router Class Initialized
INFO - 2023-04-27 07:58:06 --> URI Class Initialized
INFO - 2023-04-27 07:58:06 --> Output Class Initialized
INFO - 2023-04-27 07:58:06 --> Router Class Initialized
INFO - 2023-04-27 07:58:06 --> Security Class Initialized
INFO - 2023-04-27 07:58:06 --> Output Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:06 --> Security Class Initialized
INFO - 2023-04-27 07:58:06 --> Input Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:06 --> Language Class Initialized
INFO - 2023-04-27 07:58:06 --> Input Class Initialized
INFO - 2023-04-27 07:58:06 --> Language Class Initialized
INFO - 2023-04-27 07:58:06 --> Loader Class Initialized
INFO - 2023-04-27 07:58:06 --> Loader Class Initialized
INFO - 2023-04-27 07:58:06 --> Controller Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:06 --> Controller Class Initialized
INFO - 2023-04-27 07:58:06 --> Database Driver Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:06 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:06 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:06 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:06 --> Final output sent to browser
DEBUG - 2023-04-27 07:58:06 --> Total execution time: 0.0220
INFO - 2023-04-27 07:58:06 --> Config Class Initialized
INFO - 2023-04-27 07:58:06 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:58:06 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:58:06 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:06 --> Final output sent to browser
INFO - 2023-04-27 07:58:06 --> URI Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Total execution time: 0.0244
INFO - 2023-04-27 07:58:06 --> Router Class Initialized
INFO - 2023-04-27 07:58:06 --> Output Class Initialized
INFO - 2023-04-27 07:58:06 --> Security Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:06 --> Input Class Initialized
INFO - 2023-04-27 07:58:06 --> Language Class Initialized
INFO - 2023-04-27 07:58:06 --> Loader Class Initialized
INFO - 2023-04-27 07:58:06 --> Controller Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:06 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:06 --> Config Class Initialized
INFO - 2023-04-27 07:58:06 --> Hooks Class Initialized
DEBUG - 2023-04-27 07:58:06 --> UTF-8 Support Enabled
INFO - 2023-04-27 07:58:06 --> Utf8 Class Initialized
INFO - 2023-04-27 07:58:06 --> URI Class Initialized
INFO - 2023-04-27 07:58:06 --> Router Class Initialized
INFO - 2023-04-27 07:58:06 --> Output Class Initialized
INFO - 2023-04-27 07:58:06 --> Security Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 07:58:06 --> Input Class Initialized
INFO - 2023-04-27 07:58:06 --> Language Class Initialized
INFO - 2023-04-27 07:58:06 --> Loader Class Initialized
INFO - 2023-04-27 07:58:06 --> Controller Class Initialized
DEBUG - 2023-04-27 07:58:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 07:58:06 --> Database Driver Class Initialized
INFO - 2023-04-27 07:58:06 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:06 --> Model "Cluster_model" initialized
INFO - 2023-04-27 07:58:06 --> Final output sent to browser
DEBUG - 2023-04-27 07:58:06 --> Total execution time: 0.0179
INFO - 2023-04-27 07:58:06 --> Final output sent to browser
DEBUG - 2023-04-27 07:58:06 --> Total execution time: 0.0208
INFO - 2023-04-27 08:04:12 --> Config Class Initialized
INFO - 2023-04-27 08:04:12 --> Config Class Initialized
INFO - 2023-04-27 08:04:12 --> Hooks Class Initialized
INFO - 2023-04-27 08:04:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:04:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:04:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:04:12 --> Utf8 Class Initialized
INFO - 2023-04-27 08:04:12 --> Utf8 Class Initialized
INFO - 2023-04-27 08:04:12 --> URI Class Initialized
INFO - 2023-04-27 08:04:12 --> URI Class Initialized
INFO - 2023-04-27 08:04:12 --> Router Class Initialized
INFO - 2023-04-27 08:04:12 --> Router Class Initialized
INFO - 2023-04-27 08:04:12 --> Output Class Initialized
INFO - 2023-04-27 08:04:12 --> Output Class Initialized
INFO - 2023-04-27 08:04:12 --> Security Class Initialized
INFO - 2023-04-27 08:04:12 --> Security Class Initialized
DEBUG - 2023-04-27 08:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:04:12 --> Input Class Initialized
INFO - 2023-04-27 08:04:12 --> Input Class Initialized
INFO - 2023-04-27 08:04:12 --> Language Class Initialized
INFO - 2023-04-27 08:04:12 --> Language Class Initialized
INFO - 2023-04-27 08:04:12 --> Loader Class Initialized
INFO - 2023-04-27 08:04:12 --> Loader Class Initialized
INFO - 2023-04-27 08:04:12 --> Controller Class Initialized
INFO - 2023-04-27 08:04:12 --> Controller Class Initialized
DEBUG - 2023-04-27 08:04:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:04:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:04:12 --> Database Driver Class Initialized
INFO - 2023-04-27 08:04:12 --> Database Driver Class Initialized
INFO - 2023-04-27 08:04:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:04:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:04:12 --> Final output sent to browser
DEBUG - 2023-04-27 08:04:12 --> Total execution time: 0.1040
INFO - 2023-04-27 08:04:12 --> Config Class Initialized
INFO - 2023-04-27 08:04:12 --> Final output sent to browser
INFO - 2023-04-27 08:04:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:04:12 --> Total execution time: 0.1082
DEBUG - 2023-04-27 08:04:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:04:12 --> Utf8 Class Initialized
INFO - 2023-04-27 08:04:12 --> URI Class Initialized
INFO - 2023-04-27 08:04:12 --> Router Class Initialized
INFO - 2023-04-27 08:04:12 --> Output Class Initialized
INFO - 2023-04-27 08:04:12 --> Security Class Initialized
INFO - 2023-04-27 08:04:12 --> Config Class Initialized
INFO - 2023-04-27 08:04:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:04:12 --> Input Class Initialized
DEBUG - 2023-04-27 08:04:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:04:12 --> Language Class Initialized
INFO - 2023-04-27 08:04:12 --> Utf8 Class Initialized
INFO - 2023-04-27 08:04:12 --> URI Class Initialized
INFO - 2023-04-27 08:04:12 --> Loader Class Initialized
INFO - 2023-04-27 08:04:12 --> Router Class Initialized
INFO - 2023-04-27 08:04:12 --> Controller Class Initialized
INFO - 2023-04-27 08:04:12 --> Output Class Initialized
DEBUG - 2023-04-27 08:04:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:04:12 --> Security Class Initialized
INFO - 2023-04-27 08:04:12 --> Database Driver Class Initialized
DEBUG - 2023-04-27 08:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:04:12 --> Input Class Initialized
INFO - 2023-04-27 08:04:12 --> Language Class Initialized
INFO - 2023-04-27 08:04:12 --> Loader Class Initialized
INFO - 2023-04-27 08:04:12 --> Controller Class Initialized
DEBUG - 2023-04-27 08:04:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:04:12 --> Database Driver Class Initialized
INFO - 2023-04-27 08:04:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:04:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:04:12 --> Final output sent to browser
DEBUG - 2023-04-27 08:04:12 --> Total execution time: 0.0968
INFO - 2023-04-27 08:04:12 --> Final output sent to browser
DEBUG - 2023-04-27 08:04:12 --> Total execution time: 0.0567
INFO - 2023-04-27 08:07:00 --> Config Class Initialized
INFO - 2023-04-27 08:07:00 --> Config Class Initialized
INFO - 2023-04-27 08:07:00 --> Hooks Class Initialized
INFO - 2023-04-27 08:07:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:07:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:07:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:07:00 --> Utf8 Class Initialized
INFO - 2023-04-27 08:07:00 --> Utf8 Class Initialized
INFO - 2023-04-27 08:07:00 --> URI Class Initialized
INFO - 2023-04-27 08:07:00 --> Router Class Initialized
INFO - 2023-04-27 08:07:00 --> Output Class Initialized
INFO - 2023-04-27 08:07:00 --> URI Class Initialized
INFO - 2023-04-27 08:07:00 --> Security Class Initialized
DEBUG - 2023-04-27 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:07:00 --> Input Class Initialized
INFO - 2023-04-27 08:07:00 --> Router Class Initialized
INFO - 2023-04-27 08:07:00 --> Language Class Initialized
INFO - 2023-04-27 08:07:00 --> Output Class Initialized
INFO - 2023-04-27 08:07:00 --> Security Class Initialized
INFO - 2023-04-27 08:07:00 --> Loader Class Initialized
DEBUG - 2023-04-27 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:07:00 --> Controller Class Initialized
INFO - 2023-04-27 08:07:00 --> Input Class Initialized
INFO - 2023-04-27 08:07:00 --> Language Class Initialized
DEBUG - 2023-04-27 08:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:07:00 --> Loader Class Initialized
INFO - 2023-04-27 08:07:00 --> Database Driver Class Initialized
INFO - 2023-04-27 08:07:00 --> Controller Class Initialized
DEBUG - 2023-04-27 08:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:07:00 --> Database Driver Class Initialized
INFO - 2023-04-27 08:07:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:07:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:07:00 --> Final output sent to browser
DEBUG - 2023-04-27 08:07:00 --> Total execution time: 0.0223
INFO - 2023-04-27 08:07:00 --> Final output sent to browser
DEBUG - 2023-04-27 08:07:00 --> Total execution time: 0.0226
INFO - 2023-04-27 08:07:00 --> Config Class Initialized
INFO - 2023-04-27 08:07:00 --> Config Class Initialized
INFO - 2023-04-27 08:07:00 --> Hooks Class Initialized
INFO - 2023-04-27 08:07:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:07:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:07:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:07:00 --> Utf8 Class Initialized
INFO - 2023-04-27 08:07:00 --> Utf8 Class Initialized
INFO - 2023-04-27 08:07:00 --> URI Class Initialized
INFO - 2023-04-27 08:07:00 --> URI Class Initialized
INFO - 2023-04-27 08:07:00 --> Router Class Initialized
INFO - 2023-04-27 08:07:00 --> Output Class Initialized
INFO - 2023-04-27 08:07:00 --> Router Class Initialized
INFO - 2023-04-27 08:07:00 --> Security Class Initialized
INFO - 2023-04-27 08:07:00 --> Output Class Initialized
DEBUG - 2023-04-27 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:07:00 --> Security Class Initialized
INFO - 2023-04-27 08:07:00 --> Input Class Initialized
DEBUG - 2023-04-27 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:07:00 --> Language Class Initialized
INFO - 2023-04-27 08:07:00 --> Input Class Initialized
INFO - 2023-04-27 08:07:00 --> Language Class Initialized
INFO - 2023-04-27 08:07:00 --> Loader Class Initialized
INFO - 2023-04-27 08:07:00 --> Loader Class Initialized
INFO - 2023-04-27 08:07:00 --> Controller Class Initialized
INFO - 2023-04-27 08:07:00 --> Controller Class Initialized
DEBUG - 2023-04-27 08:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:07:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:07:00 --> Database Driver Class Initialized
INFO - 2023-04-27 08:07:00 --> Database Driver Class Initialized
INFO - 2023-04-27 08:07:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:07:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:07:00 --> Final output sent to browser
DEBUG - 2023-04-27 08:07:00 --> Total execution time: 0.0578
INFO - 2023-04-27 08:07:00 --> Final output sent to browser
DEBUG - 2023-04-27 08:07:00 --> Total execution time: 0.0593
INFO - 2023-04-27 08:13:46 --> Config Class Initialized
INFO - 2023-04-27 08:13:46 --> Config Class Initialized
INFO - 2023-04-27 08:13:46 --> Hooks Class Initialized
INFO - 2023-04-27 08:13:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:13:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:13:46 --> Utf8 Class Initialized
INFO - 2023-04-27 08:13:46 --> Utf8 Class Initialized
INFO - 2023-04-27 08:13:46 --> URI Class Initialized
INFO - 2023-04-27 08:13:46 --> URI Class Initialized
INFO - 2023-04-27 08:13:46 --> Router Class Initialized
INFO - 2023-04-27 08:13:46 --> Router Class Initialized
INFO - 2023-04-27 08:13:46 --> Output Class Initialized
INFO - 2023-04-27 08:13:46 --> Output Class Initialized
INFO - 2023-04-27 08:13:46 --> Security Class Initialized
INFO - 2023-04-27 08:13:46 --> Security Class Initialized
DEBUG - 2023-04-27 08:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:13:46 --> Input Class Initialized
INFO - 2023-04-27 08:13:46 --> Input Class Initialized
INFO - 2023-04-27 08:13:46 --> Language Class Initialized
INFO - 2023-04-27 08:13:46 --> Language Class Initialized
INFO - 2023-04-27 08:13:46 --> Loader Class Initialized
INFO - 2023-04-27 08:13:46 --> Loader Class Initialized
INFO - 2023-04-27 08:13:46 --> Controller Class Initialized
INFO - 2023-04-27 08:13:46 --> Controller Class Initialized
DEBUG - 2023-04-27 08:13:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:13:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:13:46 --> Database Driver Class Initialized
INFO - 2023-04-27 08:13:46 --> Database Driver Class Initialized
INFO - 2023-04-27 08:13:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:13:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:13:46 --> Final output sent to browser
DEBUG - 2023-04-27 08:13:46 --> Total execution time: 0.0635
INFO - 2023-04-27 08:13:46 --> Final output sent to browser
DEBUG - 2023-04-27 08:13:46 --> Total execution time: 0.0644
INFO - 2023-04-27 08:13:46 --> Config Class Initialized
INFO - 2023-04-27 08:13:46 --> Config Class Initialized
INFO - 2023-04-27 08:13:46 --> Hooks Class Initialized
INFO - 2023-04-27 08:13:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:13:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:13:46 --> Utf8 Class Initialized
INFO - 2023-04-27 08:13:46 --> Utf8 Class Initialized
INFO - 2023-04-27 08:13:46 --> URI Class Initialized
INFO - 2023-04-27 08:13:46 --> URI Class Initialized
INFO - 2023-04-27 08:13:46 --> Router Class Initialized
INFO - 2023-04-27 08:13:46 --> Router Class Initialized
INFO - 2023-04-27 08:13:46 --> Output Class Initialized
INFO - 2023-04-27 08:13:46 --> Output Class Initialized
INFO - 2023-04-27 08:13:46 --> Security Class Initialized
INFO - 2023-04-27 08:13:46 --> Security Class Initialized
DEBUG - 2023-04-27 08:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:13:46 --> Input Class Initialized
INFO - 2023-04-27 08:13:46 --> Input Class Initialized
INFO - 2023-04-27 08:13:46 --> Language Class Initialized
INFO - 2023-04-27 08:13:46 --> Language Class Initialized
INFO - 2023-04-27 08:13:46 --> Loader Class Initialized
INFO - 2023-04-27 08:13:46 --> Loader Class Initialized
INFO - 2023-04-27 08:13:46 --> Controller Class Initialized
INFO - 2023-04-27 08:13:46 --> Controller Class Initialized
DEBUG - 2023-04-27 08:13:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:13:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:13:46 --> Database Driver Class Initialized
INFO - 2023-04-27 08:13:46 --> Database Driver Class Initialized
INFO - 2023-04-27 08:13:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:13:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:13:46 --> Final output sent to browser
DEBUG - 2023-04-27 08:13:46 --> Total execution time: 0.0231
INFO - 2023-04-27 08:13:46 --> Final output sent to browser
DEBUG - 2023-04-27 08:13:46 --> Total execution time: 0.0260
INFO - 2023-04-27 08:14:39 --> Config Class Initialized
INFO - 2023-04-27 08:14:39 --> Config Class Initialized
INFO - 2023-04-27 08:14:39 --> Hooks Class Initialized
INFO - 2023-04-27 08:14:39 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:14:39 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:14:39 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:14:39 --> Utf8 Class Initialized
INFO - 2023-04-27 08:14:39 --> Utf8 Class Initialized
INFO - 2023-04-27 08:14:39 --> URI Class Initialized
INFO - 2023-04-27 08:14:39 --> URI Class Initialized
INFO - 2023-04-27 08:14:39 --> Router Class Initialized
INFO - 2023-04-27 08:14:39 --> Router Class Initialized
INFO - 2023-04-27 08:14:39 --> Output Class Initialized
INFO - 2023-04-27 08:14:39 --> Output Class Initialized
INFO - 2023-04-27 08:14:39 --> Security Class Initialized
INFO - 2023-04-27 08:14:39 --> Security Class Initialized
DEBUG - 2023-04-27 08:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:14:39 --> Input Class Initialized
INFO - 2023-04-27 08:14:39 --> Input Class Initialized
INFO - 2023-04-27 08:14:39 --> Language Class Initialized
INFO - 2023-04-27 08:14:39 --> Language Class Initialized
INFO - 2023-04-27 08:14:39 --> Loader Class Initialized
INFO - 2023-04-27 08:14:39 --> Loader Class Initialized
INFO - 2023-04-27 08:14:39 --> Controller Class Initialized
INFO - 2023-04-27 08:14:39 --> Controller Class Initialized
DEBUG - 2023-04-27 08:14:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:14:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:14:39 --> Database Driver Class Initialized
INFO - 2023-04-27 08:14:39 --> Database Driver Class Initialized
INFO - 2023-04-27 08:14:39 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:14:39 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:14:39 --> Final output sent to browser
DEBUG - 2023-04-27 08:14:39 --> Total execution time: 0.0555
INFO - 2023-04-27 08:14:39 --> Config Class Initialized
INFO - 2023-04-27 08:14:39 --> Final output sent to browser
INFO - 2023-04-27 08:14:39 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:14:39 --> Total execution time: 0.0590
DEBUG - 2023-04-27 08:14:39 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:14:39 --> Utf8 Class Initialized
INFO - 2023-04-27 08:14:39 --> URI Class Initialized
INFO - 2023-04-27 08:14:39 --> Router Class Initialized
INFO - 2023-04-27 08:14:39 --> Output Class Initialized
INFO - 2023-04-27 08:14:39 --> Security Class Initialized
INFO - 2023-04-27 08:14:39 --> Config Class Initialized
INFO - 2023-04-27 08:14:39 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:14:39 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:14:39 --> Input Class Initialized
INFO - 2023-04-27 08:14:39 --> Utf8 Class Initialized
INFO - 2023-04-27 08:14:39 --> Language Class Initialized
INFO - 2023-04-27 08:14:39 --> URI Class Initialized
INFO - 2023-04-27 08:14:39 --> Loader Class Initialized
INFO - 2023-04-27 08:14:39 --> Router Class Initialized
INFO - 2023-04-27 08:14:39 --> Controller Class Initialized
INFO - 2023-04-27 08:14:39 --> Output Class Initialized
DEBUG - 2023-04-27 08:14:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:14:39 --> Security Class Initialized
DEBUG - 2023-04-27 08:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:14:39 --> Database Driver Class Initialized
INFO - 2023-04-27 08:14:39 --> Input Class Initialized
INFO - 2023-04-27 08:14:39 --> Language Class Initialized
INFO - 2023-04-27 08:14:39 --> Loader Class Initialized
INFO - 2023-04-27 08:14:39 --> Controller Class Initialized
DEBUG - 2023-04-27 08:14:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:14:39 --> Database Driver Class Initialized
INFO - 2023-04-27 08:14:39 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:14:39 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:14:39 --> Final output sent to browser
DEBUG - 2023-04-27 08:14:39 --> Total execution time: 0.0993
INFO - 2023-04-27 08:14:39 --> Final output sent to browser
DEBUG - 2023-04-27 08:14:39 --> Total execution time: 0.0579
INFO - 2023-04-27 08:15:12 --> Config Class Initialized
INFO - 2023-04-27 08:15:12 --> Config Class Initialized
INFO - 2023-04-27 08:15:12 --> Hooks Class Initialized
INFO - 2023-04-27 08:15:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:15:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:15:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:15:12 --> Utf8 Class Initialized
INFO - 2023-04-27 08:15:12 --> Utf8 Class Initialized
INFO - 2023-04-27 08:15:12 --> URI Class Initialized
INFO - 2023-04-27 08:15:12 --> URI Class Initialized
INFO - 2023-04-27 08:15:12 --> Router Class Initialized
INFO - 2023-04-27 08:15:12 --> Router Class Initialized
INFO - 2023-04-27 08:15:12 --> Output Class Initialized
INFO - 2023-04-27 08:15:12 --> Output Class Initialized
INFO - 2023-04-27 08:15:12 --> Security Class Initialized
INFO - 2023-04-27 08:15:12 --> Security Class Initialized
DEBUG - 2023-04-27 08:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:15:12 --> Input Class Initialized
INFO - 2023-04-27 08:15:12 --> Input Class Initialized
INFO - 2023-04-27 08:15:12 --> Language Class Initialized
INFO - 2023-04-27 08:15:12 --> Language Class Initialized
INFO - 2023-04-27 08:15:12 --> Loader Class Initialized
INFO - 2023-04-27 08:15:12 --> Loader Class Initialized
INFO - 2023-04-27 08:15:12 --> Controller Class Initialized
INFO - 2023-04-27 08:15:12 --> Controller Class Initialized
DEBUG - 2023-04-27 08:15:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:15:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:15:12 --> Database Driver Class Initialized
INFO - 2023-04-27 08:15:12 --> Database Driver Class Initialized
INFO - 2023-04-27 08:15:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:15:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:15:12 --> Final output sent to browser
INFO - 2023-04-27 08:15:12 --> Final output sent to browser
DEBUG - 2023-04-27 08:15:12 --> Total execution time: 0.1023
DEBUG - 2023-04-27 08:15:12 --> Total execution time: 0.1023
INFO - 2023-04-27 08:15:12 --> Config Class Initialized
INFO - 2023-04-27 08:15:12 --> Config Class Initialized
INFO - 2023-04-27 08:15:12 --> Hooks Class Initialized
INFO - 2023-04-27 08:15:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:15:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:15:13 --> Utf8 Class Initialized
DEBUG - 2023-04-27 08:15:13 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:15:13 --> Utf8 Class Initialized
INFO - 2023-04-27 08:15:13 --> URI Class Initialized
INFO - 2023-04-27 08:15:13 --> URI Class Initialized
INFO - 2023-04-27 08:15:13 --> Router Class Initialized
INFO - 2023-04-27 08:15:13 --> Router Class Initialized
INFO - 2023-04-27 08:15:13 --> Output Class Initialized
INFO - 2023-04-27 08:15:13 --> Output Class Initialized
INFO - 2023-04-27 08:15:13 --> Security Class Initialized
INFO - 2023-04-27 08:15:13 --> Security Class Initialized
DEBUG - 2023-04-27 08:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:15:13 --> Input Class Initialized
INFO - 2023-04-27 08:15:13 --> Input Class Initialized
INFO - 2023-04-27 08:15:13 --> Language Class Initialized
INFO - 2023-04-27 08:15:13 --> Language Class Initialized
INFO - 2023-04-27 08:15:13 --> Loader Class Initialized
INFO - 2023-04-27 08:15:13 --> Loader Class Initialized
INFO - 2023-04-27 08:15:13 --> Controller Class Initialized
INFO - 2023-04-27 08:15:13 --> Controller Class Initialized
DEBUG - 2023-04-27 08:15:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:15:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:15:13 --> Database Driver Class Initialized
INFO - 2023-04-27 08:15:13 --> Database Driver Class Initialized
INFO - 2023-04-27 08:15:13 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:15:13 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:15:13 --> Final output sent to browser
DEBUG - 2023-04-27 08:15:13 --> Total execution time: 0.0647
INFO - 2023-04-27 08:15:13 --> Final output sent to browser
DEBUG - 2023-04-27 08:15:13 --> Total execution time: 0.0676
INFO - 2023-04-27 08:18:36 --> Config Class Initialized
INFO - 2023-04-27 08:18:36 --> Config Class Initialized
INFO - 2023-04-27 08:18:36 --> Hooks Class Initialized
INFO - 2023-04-27 08:18:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:18:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:18:36 --> Utf8 Class Initialized
INFO - 2023-04-27 08:18:36 --> Utf8 Class Initialized
INFO - 2023-04-27 08:18:36 --> URI Class Initialized
INFO - 2023-04-27 08:18:36 --> URI Class Initialized
INFO - 2023-04-27 08:18:36 --> Router Class Initialized
INFO - 2023-04-27 08:18:36 --> Router Class Initialized
INFO - 2023-04-27 08:18:36 --> Output Class Initialized
INFO - 2023-04-27 08:18:36 --> Output Class Initialized
INFO - 2023-04-27 08:18:36 --> Security Class Initialized
INFO - 2023-04-27 08:18:36 --> Security Class Initialized
DEBUG - 2023-04-27 08:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:18:36 --> Input Class Initialized
INFO - 2023-04-27 08:18:36 --> Input Class Initialized
INFO - 2023-04-27 08:18:36 --> Language Class Initialized
INFO - 2023-04-27 08:18:36 --> Language Class Initialized
INFO - 2023-04-27 08:18:36 --> Loader Class Initialized
INFO - 2023-04-27 08:18:36 --> Loader Class Initialized
INFO - 2023-04-27 08:18:36 --> Controller Class Initialized
INFO - 2023-04-27 08:18:36 --> Controller Class Initialized
DEBUG - 2023-04-27 08:18:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:18:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:18:36 --> Database Driver Class Initialized
INFO - 2023-04-27 08:18:36 --> Database Driver Class Initialized
INFO - 2023-04-27 08:18:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:18:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:18:37 --> Final output sent to browser
DEBUG - 2023-04-27 08:18:37 --> Total execution time: 0.0643
INFO - 2023-04-27 08:18:37 --> Final output sent to browser
DEBUG - 2023-04-27 08:18:37 --> Total execution time: 0.0661
INFO - 2023-04-27 08:18:37 --> Config Class Initialized
INFO - 2023-04-27 08:18:37 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:18:37 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:18:37 --> Utf8 Class Initialized
INFO - 2023-04-27 08:18:37 --> URI Class Initialized
INFO - 2023-04-27 08:18:37 --> Router Class Initialized
INFO - 2023-04-27 08:18:37 --> Config Class Initialized
INFO - 2023-04-27 08:18:37 --> Hooks Class Initialized
INFO - 2023-04-27 08:18:37 --> Output Class Initialized
DEBUG - 2023-04-27 08:18:37 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:18:37 --> Security Class Initialized
INFO - 2023-04-27 08:18:37 --> Utf8 Class Initialized
DEBUG - 2023-04-27 08:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:18:37 --> URI Class Initialized
INFO - 2023-04-27 08:18:37 --> Input Class Initialized
INFO - 2023-04-27 08:18:37 --> Router Class Initialized
INFO - 2023-04-27 08:18:37 --> Language Class Initialized
INFO - 2023-04-27 08:18:37 --> Output Class Initialized
INFO - 2023-04-27 08:18:37 --> Loader Class Initialized
INFO - 2023-04-27 08:18:37 --> Security Class Initialized
INFO - 2023-04-27 08:18:37 --> Controller Class Initialized
DEBUG - 2023-04-27 08:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:18:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:18:37 --> Input Class Initialized
INFO - 2023-04-27 08:18:37 --> Language Class Initialized
INFO - 2023-04-27 08:18:37 --> Database Driver Class Initialized
INFO - 2023-04-27 08:18:37 --> Loader Class Initialized
INFO - 2023-04-27 08:18:37 --> Controller Class Initialized
DEBUG - 2023-04-27 08:18:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:18:37 --> Database Driver Class Initialized
INFO - 2023-04-27 08:18:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:18:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:18:37 --> Final output sent to browser
DEBUG - 2023-04-27 08:18:37 --> Total execution time: 0.0962
INFO - 2023-04-27 08:18:37 --> Final output sent to browser
DEBUG - 2023-04-27 08:18:37 --> Total execution time: 0.0567
INFO - 2023-04-27 08:19:42 --> Config Class Initialized
INFO - 2023-04-27 08:19:42 --> Config Class Initialized
INFO - 2023-04-27 08:19:42 --> Hooks Class Initialized
INFO - 2023-04-27 08:19:42 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:19:42 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:19:42 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:19:42 --> Utf8 Class Initialized
INFO - 2023-04-27 08:19:42 --> Utf8 Class Initialized
INFO - 2023-04-27 08:19:42 --> URI Class Initialized
INFO - 2023-04-27 08:19:42 --> URI Class Initialized
INFO - 2023-04-27 08:19:42 --> Router Class Initialized
INFO - 2023-04-27 08:19:42 --> Router Class Initialized
INFO - 2023-04-27 08:19:42 --> Output Class Initialized
INFO - 2023-04-27 08:19:42 --> Output Class Initialized
INFO - 2023-04-27 08:19:42 --> Security Class Initialized
INFO - 2023-04-27 08:19:42 --> Security Class Initialized
DEBUG - 2023-04-27 08:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:19:42 --> Input Class Initialized
INFO - 2023-04-27 08:19:42 --> Input Class Initialized
INFO - 2023-04-27 08:19:42 --> Language Class Initialized
INFO - 2023-04-27 08:19:42 --> Language Class Initialized
INFO - 2023-04-27 08:19:42 --> Loader Class Initialized
INFO - 2023-04-27 08:19:42 --> Loader Class Initialized
INFO - 2023-04-27 08:19:42 --> Controller Class Initialized
INFO - 2023-04-27 08:19:42 --> Controller Class Initialized
DEBUG - 2023-04-27 08:19:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:19:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:19:42 --> Database Driver Class Initialized
INFO - 2023-04-27 08:19:42 --> Database Driver Class Initialized
INFO - 2023-04-27 08:19:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:19:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:19:42 --> Final output sent to browser
DEBUG - 2023-04-27 08:19:42 --> Total execution time: 0.0590
INFO - 2023-04-27 08:19:42 --> Final output sent to browser
DEBUG - 2023-04-27 08:19:42 --> Total execution time: 0.0608
INFO - 2023-04-27 08:19:42 --> Config Class Initialized
INFO - 2023-04-27 08:19:42 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:19:42 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:19:42 --> Utf8 Class Initialized
INFO - 2023-04-27 08:19:42 --> URI Class Initialized
INFO - 2023-04-27 08:19:42 --> Config Class Initialized
INFO - 2023-04-27 08:19:42 --> Hooks Class Initialized
INFO - 2023-04-27 08:19:42 --> Router Class Initialized
DEBUG - 2023-04-27 08:19:42 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:19:42 --> Output Class Initialized
INFO - 2023-04-27 08:19:42 --> Utf8 Class Initialized
INFO - 2023-04-27 08:19:42 --> Security Class Initialized
INFO - 2023-04-27 08:19:42 --> URI Class Initialized
DEBUG - 2023-04-27 08:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:19:42 --> Router Class Initialized
INFO - 2023-04-27 08:19:42 --> Input Class Initialized
INFO - 2023-04-27 08:19:42 --> Output Class Initialized
INFO - 2023-04-27 08:19:42 --> Language Class Initialized
INFO - 2023-04-27 08:19:42 --> Security Class Initialized
INFO - 2023-04-27 08:19:42 --> Loader Class Initialized
DEBUG - 2023-04-27 08:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:19:42 --> Controller Class Initialized
INFO - 2023-04-27 08:19:42 --> Input Class Initialized
DEBUG - 2023-04-27 08:19:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:19:42 --> Language Class Initialized
INFO - 2023-04-27 08:19:42 --> Database Driver Class Initialized
INFO - 2023-04-27 08:19:42 --> Loader Class Initialized
INFO - 2023-04-27 08:19:42 --> Controller Class Initialized
DEBUG - 2023-04-27 08:19:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:19:42 --> Database Driver Class Initialized
INFO - 2023-04-27 08:19:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:19:42 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:19:42 --> Final output sent to browser
DEBUG - 2023-04-27 08:19:42 --> Total execution time: 0.0581
INFO - 2023-04-27 08:19:42 --> Final output sent to browser
DEBUG - 2023-04-27 08:19:42 --> Total execution time: 0.0599
INFO - 2023-04-27 08:20:44 --> Config Class Initialized
INFO - 2023-04-27 08:20:44 --> Config Class Initialized
INFO - 2023-04-27 08:20:44 --> Hooks Class Initialized
INFO - 2023-04-27 08:20:44 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:20:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:20:44 --> Utf8 Class Initialized
DEBUG - 2023-04-27 08:20:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:20:44 --> URI Class Initialized
INFO - 2023-04-27 08:20:44 --> Utf8 Class Initialized
INFO - 2023-04-27 08:20:44 --> Router Class Initialized
INFO - 2023-04-27 08:20:44 --> URI Class Initialized
INFO - 2023-04-27 08:20:44 --> Output Class Initialized
INFO - 2023-04-27 08:20:44 --> Router Class Initialized
INFO - 2023-04-27 08:20:44 --> Security Class Initialized
INFO - 2023-04-27 08:20:44 --> Output Class Initialized
DEBUG - 2023-04-27 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:20:44 --> Security Class Initialized
INFO - 2023-04-27 08:20:44 --> Input Class Initialized
DEBUG - 2023-04-27 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:20:44 --> Language Class Initialized
INFO - 2023-04-27 08:20:44 --> Input Class Initialized
INFO - 2023-04-27 08:20:44 --> Language Class Initialized
INFO - 2023-04-27 08:20:44 --> Loader Class Initialized
INFO - 2023-04-27 08:20:44 --> Loader Class Initialized
INFO - 2023-04-27 08:20:44 --> Controller Class Initialized
INFO - 2023-04-27 08:20:44 --> Controller Class Initialized
DEBUG - 2023-04-27 08:20:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:20:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:20:44 --> Database Driver Class Initialized
INFO - 2023-04-27 08:20:44 --> Database Driver Class Initialized
INFO - 2023-04-27 08:20:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:20:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:20:44 --> Final output sent to browser
DEBUG - 2023-04-27 08:20:44 --> Total execution time: 0.0578
INFO - 2023-04-27 08:20:44 --> Config Class Initialized
INFO - 2023-04-27 08:20:44 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:20:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:20:44 --> Final output sent to browser
INFO - 2023-04-27 08:20:44 --> Utf8 Class Initialized
DEBUG - 2023-04-27 08:20:44 --> Total execution time: 0.0606
INFO - 2023-04-27 08:20:44 --> URI Class Initialized
INFO - 2023-04-27 08:20:44 --> Router Class Initialized
INFO - 2023-04-27 08:20:44 --> Output Class Initialized
INFO - 2023-04-27 08:20:44 --> Security Class Initialized
DEBUG - 2023-04-27 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:20:44 --> Input Class Initialized
INFO - 2023-04-27 08:20:44 --> Language Class Initialized
INFO - 2023-04-27 08:20:44 --> Loader Class Initialized
INFO - 2023-04-27 08:20:44 --> Controller Class Initialized
DEBUG - 2023-04-27 08:20:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:20:44 --> Config Class Initialized
INFO - 2023-04-27 08:20:44 --> Hooks Class Initialized
INFO - 2023-04-27 08:20:44 --> Database Driver Class Initialized
DEBUG - 2023-04-27 08:20:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:20:44 --> Utf8 Class Initialized
INFO - 2023-04-27 08:20:44 --> URI Class Initialized
INFO - 2023-04-27 08:20:44 --> Router Class Initialized
INFO - 2023-04-27 08:20:44 --> Output Class Initialized
INFO - 2023-04-27 08:20:44 --> Security Class Initialized
DEBUG - 2023-04-27 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:20:44 --> Input Class Initialized
INFO - 2023-04-27 08:20:44 --> Language Class Initialized
INFO - 2023-04-27 08:20:44 --> Loader Class Initialized
INFO - 2023-04-27 08:20:44 --> Controller Class Initialized
DEBUG - 2023-04-27 08:20:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:20:44 --> Database Driver Class Initialized
INFO - 2023-04-27 08:20:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:20:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:20:44 --> Final output sent to browser
DEBUG - 2023-04-27 08:20:44 --> Total execution time: 0.0142
INFO - 2023-04-27 08:20:44 --> Final output sent to browser
DEBUG - 2023-04-27 08:20:44 --> Total execution time: 0.0146
INFO - 2023-04-27 08:22:00 --> Config Class Initialized
INFO - 2023-04-27 08:22:00 --> Config Class Initialized
INFO - 2023-04-27 08:22:00 --> Hooks Class Initialized
INFO - 2023-04-27 08:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:22:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:22:00 --> Utf8 Class Initialized
INFO - 2023-04-27 08:22:00 --> Utf8 Class Initialized
INFO - 2023-04-27 08:22:00 --> URI Class Initialized
INFO - 2023-04-27 08:22:00 --> URI Class Initialized
INFO - 2023-04-27 08:22:00 --> Router Class Initialized
INFO - 2023-04-27 08:22:00 --> Router Class Initialized
INFO - 2023-04-27 08:22:00 --> Output Class Initialized
INFO - 2023-04-27 08:22:00 --> Output Class Initialized
INFO - 2023-04-27 08:22:00 --> Security Class Initialized
INFO - 2023-04-27 08:22:00 --> Security Class Initialized
DEBUG - 2023-04-27 08:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:22:00 --> Input Class Initialized
INFO - 2023-04-27 08:22:00 --> Input Class Initialized
INFO - 2023-04-27 08:22:00 --> Language Class Initialized
INFO - 2023-04-27 08:22:00 --> Language Class Initialized
INFO - 2023-04-27 08:22:00 --> Loader Class Initialized
INFO - 2023-04-27 08:22:00 --> Loader Class Initialized
INFO - 2023-04-27 08:22:00 --> Controller Class Initialized
INFO - 2023-04-27 08:22:00 --> Controller Class Initialized
DEBUG - 2023-04-27 08:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:22:00 --> Database Driver Class Initialized
INFO - 2023-04-27 08:22:00 --> Database Driver Class Initialized
INFO - 2023-04-27 08:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:22:00 --> Final output sent to browser
DEBUG - 2023-04-27 08:22:00 --> Total execution time: 0.0175
INFO - 2023-04-27 08:22:00 --> Final output sent to browser
DEBUG - 2023-04-27 08:22:00 --> Total execution time: 0.0192
INFO - 2023-04-27 08:22:00 --> Config Class Initialized
INFO - 2023-04-27 08:22:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:22:00 --> Utf8 Class Initialized
INFO - 2023-04-27 08:22:00 --> URI Class Initialized
INFO - 2023-04-27 08:22:00 --> Router Class Initialized
INFO - 2023-04-27 08:22:00 --> Output Class Initialized
INFO - 2023-04-27 08:22:00 --> Security Class Initialized
INFO - 2023-04-27 08:22:00 --> Config Class Initialized
DEBUG - 2023-04-27 08:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:22:00 --> Hooks Class Initialized
INFO - 2023-04-27 08:22:00 --> Input Class Initialized
DEBUG - 2023-04-27 08:22:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:22:00 --> Language Class Initialized
INFO - 2023-04-27 08:22:00 --> Utf8 Class Initialized
INFO - 2023-04-27 08:22:00 --> Loader Class Initialized
INFO - 2023-04-27 08:22:00 --> URI Class Initialized
INFO - 2023-04-27 08:22:00 --> Controller Class Initialized
INFO - 2023-04-27 08:22:00 --> Router Class Initialized
DEBUG - 2023-04-27 08:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:22:00 --> Output Class Initialized
INFO - 2023-04-27 08:22:00 --> Database Driver Class Initialized
INFO - 2023-04-27 08:22:00 --> Security Class Initialized
DEBUG - 2023-04-27 08:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:22:00 --> Input Class Initialized
INFO - 2023-04-27 08:22:00 --> Language Class Initialized
INFO - 2023-04-27 08:22:00 --> Loader Class Initialized
INFO - 2023-04-27 08:22:00 --> Controller Class Initialized
DEBUG - 2023-04-27 08:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:22:00 --> Database Driver Class Initialized
INFO - 2023-04-27 08:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:22:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:22:00 --> Final output sent to browser
DEBUG - 2023-04-27 08:22:00 --> Total execution time: 0.0138
INFO - 2023-04-27 08:22:00 --> Final output sent to browser
DEBUG - 2023-04-27 08:22:00 --> Total execution time: 0.0158
INFO - 2023-04-27 08:44:59 --> Config Class Initialized
INFO - 2023-04-27 08:44:59 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:44:59 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:44:59 --> Utf8 Class Initialized
INFO - 2023-04-27 08:44:59 --> URI Class Initialized
INFO - 2023-04-27 08:44:59 --> Router Class Initialized
INFO - 2023-04-27 08:44:59 --> Output Class Initialized
INFO - 2023-04-27 08:44:59 --> Security Class Initialized
DEBUG - 2023-04-27 08:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:44:59 --> Input Class Initialized
INFO - 2023-04-27 08:44:59 --> Language Class Initialized
INFO - 2023-04-27 08:44:59 --> Loader Class Initialized
INFO - 2023-04-27 08:44:59 --> Controller Class Initialized
DEBUG - 2023-04-27 08:44:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:44:59 --> Database Driver Class Initialized
INFO - 2023-04-27 08:44:59 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:44:59 --> Final output sent to browser
DEBUG - 2023-04-27 08:44:59 --> Total execution time: 0.0165
INFO - 2023-04-27 08:44:59 --> Config Class Initialized
INFO - 2023-04-27 08:44:59 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:44:59 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:44:59 --> Utf8 Class Initialized
INFO - 2023-04-27 08:44:59 --> URI Class Initialized
INFO - 2023-04-27 08:44:59 --> Router Class Initialized
INFO - 2023-04-27 08:44:59 --> Output Class Initialized
INFO - 2023-04-27 08:44:59 --> Security Class Initialized
DEBUG - 2023-04-27 08:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:44:59 --> Input Class Initialized
INFO - 2023-04-27 08:44:59 --> Language Class Initialized
INFO - 2023-04-27 08:44:59 --> Loader Class Initialized
INFO - 2023-04-27 08:44:59 --> Controller Class Initialized
DEBUG - 2023-04-27 08:44:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:44:59 --> Database Driver Class Initialized
INFO - 2023-04-27 08:44:59 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:44:59 --> Final output sent to browser
DEBUG - 2023-04-27 08:44:59 --> Total execution time: 0.0564
INFO - 2023-04-27 08:45:02 --> Config Class Initialized
INFO - 2023-04-27 08:45:02 --> Config Class Initialized
INFO - 2023-04-27 08:45:02 --> Hooks Class Initialized
INFO - 2023-04-27 08:45:02 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:45:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:45:02 --> Utf8 Class Initialized
DEBUG - 2023-04-27 08:45:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:45:02 --> URI Class Initialized
INFO - 2023-04-27 08:45:02 --> Utf8 Class Initialized
INFO - 2023-04-27 08:45:02 --> Router Class Initialized
INFO - 2023-04-27 08:45:02 --> URI Class Initialized
INFO - 2023-04-27 08:45:02 --> Router Class Initialized
INFO - 2023-04-27 08:45:02 --> Output Class Initialized
INFO - 2023-04-27 08:45:02 --> Output Class Initialized
INFO - 2023-04-27 08:45:02 --> Security Class Initialized
INFO - 2023-04-27 08:45:02 --> Security Class Initialized
DEBUG - 2023-04-27 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:45:02 --> Input Class Initialized
INFO - 2023-04-27 08:45:02 --> Language Class Initialized
DEBUG - 2023-04-27 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:45:02 --> Input Class Initialized
INFO - 2023-04-27 08:45:02 --> Loader Class Initialized
INFO - 2023-04-27 08:45:02 --> Language Class Initialized
INFO - 2023-04-27 08:45:02 --> Loader Class Initialized
INFO - 2023-04-27 08:45:02 --> Controller Class Initialized
INFO - 2023-04-27 08:45:02 --> Controller Class Initialized
DEBUG - 2023-04-27 08:45:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:45:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:45:02 --> Database Driver Class Initialized
INFO - 2023-04-27 08:45:02 --> Database Driver Class Initialized
INFO - 2023-04-27 08:45:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:45:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:45:02 --> Final output sent to browser
DEBUG - 2023-04-27 08:45:02 --> Total execution time: 0.0181
INFO - 2023-04-27 08:45:02 --> Final output sent to browser
INFO - 2023-04-27 08:45:02 --> Config Class Initialized
INFO - 2023-04-27 08:45:02 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:45:02 --> Total execution time: 0.0197
DEBUG - 2023-04-27 08:45:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:45:02 --> Utf8 Class Initialized
INFO - 2023-04-27 08:45:02 --> URI Class Initialized
INFO - 2023-04-27 08:45:02 --> Router Class Initialized
INFO - 2023-04-27 08:45:02 --> Output Class Initialized
INFO - 2023-04-27 08:45:02 --> Security Class Initialized
DEBUG - 2023-04-27 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:45:02 --> Input Class Initialized
INFO - 2023-04-27 08:45:02 --> Language Class Initialized
INFO - 2023-04-27 08:45:02 --> Loader Class Initialized
INFO - 2023-04-27 08:45:02 --> Controller Class Initialized
DEBUG - 2023-04-27 08:45:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:45:02 --> Config Class Initialized
INFO - 2023-04-27 08:45:02 --> Hooks Class Initialized
INFO - 2023-04-27 08:45:02 --> Database Driver Class Initialized
DEBUG - 2023-04-27 08:45:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:45:02 --> Utf8 Class Initialized
INFO - 2023-04-27 08:45:02 --> URI Class Initialized
INFO - 2023-04-27 08:45:02 --> Router Class Initialized
INFO - 2023-04-27 08:45:02 --> Output Class Initialized
INFO - 2023-04-27 08:45:02 --> Security Class Initialized
DEBUG - 2023-04-27 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:45:02 --> Input Class Initialized
INFO - 2023-04-27 08:45:02 --> Language Class Initialized
INFO - 2023-04-27 08:45:02 --> Loader Class Initialized
INFO - 2023-04-27 08:45:02 --> Controller Class Initialized
DEBUG - 2023-04-27 08:45:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:45:02 --> Database Driver Class Initialized
INFO - 2023-04-27 08:45:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:45:02 --> Final output sent to browser
DEBUG - 2023-04-27 08:45:02 --> Total execution time: 0.0524
INFO - 2023-04-27 08:45:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:45:02 --> Final output sent to browser
DEBUG - 2023-04-27 08:45:02 --> Total execution time: 0.0540
INFO - 2023-04-27 08:46:01 --> Config Class Initialized
INFO - 2023-04-27 08:46:01 --> Config Class Initialized
INFO - 2023-04-27 08:46:01 --> Hooks Class Initialized
INFO - 2023-04-27 08:46:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:46:01 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 08:46:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:46:01 --> Utf8 Class Initialized
INFO - 2023-04-27 08:46:01 --> Utf8 Class Initialized
INFO - 2023-04-27 08:46:01 --> URI Class Initialized
INFO - 2023-04-27 08:46:01 --> URI Class Initialized
INFO - 2023-04-27 08:46:01 --> Router Class Initialized
INFO - 2023-04-27 08:46:01 --> Router Class Initialized
INFO - 2023-04-27 08:46:01 --> Output Class Initialized
INFO - 2023-04-27 08:46:01 --> Output Class Initialized
INFO - 2023-04-27 08:46:01 --> Security Class Initialized
INFO - 2023-04-27 08:46:01 --> Security Class Initialized
DEBUG - 2023-04-27 08:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 08:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:46:01 --> Input Class Initialized
INFO - 2023-04-27 08:46:01 --> Input Class Initialized
INFO - 2023-04-27 08:46:01 --> Language Class Initialized
INFO - 2023-04-27 08:46:01 --> Language Class Initialized
INFO - 2023-04-27 08:46:01 --> Loader Class Initialized
INFO - 2023-04-27 08:46:01 --> Loader Class Initialized
INFO - 2023-04-27 08:46:01 --> Controller Class Initialized
INFO - 2023-04-27 08:46:01 --> Controller Class Initialized
DEBUG - 2023-04-27 08:46:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:46:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:46:01 --> Database Driver Class Initialized
INFO - 2023-04-27 08:46:01 --> Database Driver Class Initialized
INFO - 2023-04-27 08:46:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:46:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:46:02 --> Final output sent to browser
DEBUG - 2023-04-27 08:46:02 --> Total execution time: 0.0639
INFO - 2023-04-27 08:46:02 --> Final output sent to browser
DEBUG - 2023-04-27 08:46:02 --> Total execution time: 0.0665
INFO - 2023-04-27 08:46:02 --> Config Class Initialized
INFO - 2023-04-27 08:46:02 --> Hooks Class Initialized
DEBUG - 2023-04-27 08:46:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:46:02 --> Utf8 Class Initialized
INFO - 2023-04-27 08:46:02 --> URI Class Initialized
INFO - 2023-04-27 08:46:02 --> Router Class Initialized
INFO - 2023-04-27 08:46:02 --> Output Class Initialized
INFO - 2023-04-27 08:46:02 --> Security Class Initialized
DEBUG - 2023-04-27 08:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:46:02 --> Input Class Initialized
INFO - 2023-04-27 08:46:02 --> Language Class Initialized
INFO - 2023-04-27 08:46:02 --> Config Class Initialized
INFO - 2023-04-27 08:46:02 --> Loader Class Initialized
INFO - 2023-04-27 08:46:02 --> Hooks Class Initialized
INFO - 2023-04-27 08:46:02 --> Controller Class Initialized
DEBUG - 2023-04-27 08:46:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 08:46:02 --> UTF-8 Support Enabled
INFO - 2023-04-27 08:46:02 --> Utf8 Class Initialized
INFO - 2023-04-27 08:46:02 --> Database Driver Class Initialized
INFO - 2023-04-27 08:46:02 --> URI Class Initialized
INFO - 2023-04-27 08:46:02 --> Router Class Initialized
INFO - 2023-04-27 08:46:02 --> Output Class Initialized
INFO - 2023-04-27 08:46:02 --> Security Class Initialized
DEBUG - 2023-04-27 08:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 08:46:02 --> Input Class Initialized
INFO - 2023-04-27 08:46:02 --> Language Class Initialized
INFO - 2023-04-27 08:46:02 --> Loader Class Initialized
INFO - 2023-04-27 08:46:02 --> Controller Class Initialized
DEBUG - 2023-04-27 08:46:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 08:46:02 --> Database Driver Class Initialized
INFO - 2023-04-27 08:46:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:46:02 --> Model "Cluster_model" initialized
INFO - 2023-04-27 08:46:02 --> Final output sent to browser
DEBUG - 2023-04-27 08:46:02 --> Total execution time: 0.0167
INFO - 2023-04-27 08:46:02 --> Final output sent to browser
DEBUG - 2023-04-27 08:46:02 --> Total execution time: 0.0182
INFO - 2023-04-27 09:09:22 --> Config Class Initialized
INFO - 2023-04-27 09:09:22 --> Config Class Initialized
INFO - 2023-04-27 09:09:22 --> Hooks Class Initialized
INFO - 2023-04-27 09:09:22 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:09:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:09:22 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:09:22 --> Utf8 Class Initialized
INFO - 2023-04-27 09:09:22 --> Utf8 Class Initialized
INFO - 2023-04-27 09:09:22 --> URI Class Initialized
INFO - 2023-04-27 09:09:22 --> URI Class Initialized
INFO - 2023-04-27 09:09:22 --> Router Class Initialized
INFO - 2023-04-27 09:09:22 --> Output Class Initialized
INFO - 2023-04-27 09:09:22 --> Router Class Initialized
INFO - 2023-04-27 09:09:22 --> Security Class Initialized
INFO - 2023-04-27 09:09:22 --> Output Class Initialized
DEBUG - 2023-04-27 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:09:22 --> Security Class Initialized
INFO - 2023-04-27 09:09:22 --> Input Class Initialized
DEBUG - 2023-04-27 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:09:22 --> Language Class Initialized
INFO - 2023-04-27 09:09:22 --> Input Class Initialized
INFO - 2023-04-27 09:09:22 --> Language Class Initialized
INFO - 2023-04-27 09:09:22 --> Loader Class Initialized
INFO - 2023-04-27 09:09:22 --> Loader Class Initialized
INFO - 2023-04-27 09:09:22 --> Controller Class Initialized
INFO - 2023-04-27 09:09:22 --> Controller Class Initialized
DEBUG - 2023-04-27 09:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:09:22 --> Database Driver Class Initialized
INFO - 2023-04-27 09:09:22 --> Database Driver Class Initialized
INFO - 2023-04-27 09:09:22 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:09:22 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:09:22 --> Final output sent to browser
DEBUG - 2023-04-27 09:09:22 --> Total execution time: 0.0639
INFO - 2023-04-27 09:09:22 --> Final output sent to browser
DEBUG - 2023-04-27 09:09:22 --> Total execution time: 0.0657
INFO - 2023-04-27 09:09:22 --> Config Class Initialized
INFO - 2023-04-27 09:09:22 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:09:22 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:09:22 --> Utf8 Class Initialized
INFO - 2023-04-27 09:09:22 --> URI Class Initialized
INFO - 2023-04-27 09:09:22 --> Router Class Initialized
INFO - 2023-04-27 09:09:22 --> Output Class Initialized
INFO - 2023-04-27 09:09:22 --> Security Class Initialized
INFO - 2023-04-27 09:09:22 --> Config Class Initialized
DEBUG - 2023-04-27 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:09:22 --> Hooks Class Initialized
INFO - 2023-04-27 09:09:22 --> Input Class Initialized
DEBUG - 2023-04-27 09:09:22 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:09:22 --> Language Class Initialized
INFO - 2023-04-27 09:09:22 --> Utf8 Class Initialized
INFO - 2023-04-27 09:09:22 --> Loader Class Initialized
INFO - 2023-04-27 09:09:22 --> URI Class Initialized
INFO - 2023-04-27 09:09:22 --> Controller Class Initialized
INFO - 2023-04-27 09:09:22 --> Router Class Initialized
DEBUG - 2023-04-27 09:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:09:22 --> Output Class Initialized
INFO - 2023-04-27 09:09:22 --> Security Class Initialized
INFO - 2023-04-27 09:09:22 --> Database Driver Class Initialized
DEBUG - 2023-04-27 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:09:22 --> Input Class Initialized
INFO - 2023-04-27 09:09:22 --> Language Class Initialized
INFO - 2023-04-27 09:09:22 --> Loader Class Initialized
INFO - 2023-04-27 09:09:22 --> Controller Class Initialized
DEBUG - 2023-04-27 09:09:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:09:22 --> Database Driver Class Initialized
INFO - 2023-04-27 09:09:22 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:09:22 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:09:22 --> Final output sent to browser
DEBUG - 2023-04-27 09:09:22 --> Total execution time: 0.0146
INFO - 2023-04-27 09:09:22 --> Final output sent to browser
DEBUG - 2023-04-27 09:09:22 --> Total execution time: 0.0164
INFO - 2023-04-27 09:10:16 --> Config Class Initialized
INFO - 2023-04-27 09:10:16 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:10:16 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:10:16 --> Utf8 Class Initialized
INFO - 2023-04-27 09:10:16 --> URI Class Initialized
INFO - 2023-04-27 09:10:16 --> Router Class Initialized
INFO - 2023-04-27 09:10:16 --> Output Class Initialized
INFO - 2023-04-27 09:10:16 --> Security Class Initialized
DEBUG - 2023-04-27 09:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:10:16 --> Input Class Initialized
INFO - 2023-04-27 09:10:16 --> Language Class Initialized
INFO - 2023-04-27 09:10:16 --> Loader Class Initialized
INFO - 2023-04-27 09:10:16 --> Controller Class Initialized
DEBUG - 2023-04-27 09:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:10:16 --> Database Driver Class Initialized
INFO - 2023-04-27 09:10:16 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:10:16 --> Final output sent to browser
DEBUG - 2023-04-27 09:10:16 --> Total execution time: 0.0146
INFO - 2023-04-27 09:10:16 --> Config Class Initialized
INFO - 2023-04-27 09:10:16 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:10:16 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:10:16 --> Utf8 Class Initialized
INFO - 2023-04-27 09:10:16 --> URI Class Initialized
INFO - 2023-04-27 09:10:16 --> Router Class Initialized
INFO - 2023-04-27 09:10:16 --> Output Class Initialized
INFO - 2023-04-27 09:10:16 --> Security Class Initialized
DEBUG - 2023-04-27 09:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:10:16 --> Input Class Initialized
INFO - 2023-04-27 09:10:16 --> Language Class Initialized
INFO - 2023-04-27 09:10:16 --> Loader Class Initialized
INFO - 2023-04-27 09:10:16 --> Controller Class Initialized
DEBUG - 2023-04-27 09:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:10:16 --> Database Driver Class Initialized
INFO - 2023-04-27 09:10:16 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:10:16 --> Final output sent to browser
DEBUG - 2023-04-27 09:10:16 --> Total execution time: 0.0517
INFO - 2023-04-27 09:10:16 --> Config Class Initialized
INFO - 2023-04-27 09:10:16 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:10:16 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:10:16 --> Utf8 Class Initialized
INFO - 2023-04-27 09:10:16 --> URI Class Initialized
INFO - 2023-04-27 09:10:16 --> Router Class Initialized
INFO - 2023-04-27 09:10:16 --> Output Class Initialized
INFO - 2023-04-27 09:10:16 --> Security Class Initialized
DEBUG - 2023-04-27 09:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:10:16 --> Input Class Initialized
INFO - 2023-04-27 09:10:16 --> Language Class Initialized
INFO - 2023-04-27 09:10:16 --> Loader Class Initialized
INFO - 2023-04-27 09:10:16 --> Controller Class Initialized
DEBUG - 2023-04-27 09:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:10:16 --> Database Driver Class Initialized
INFO - 2023-04-27 09:10:16 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:10:16 --> Final output sent to browser
DEBUG - 2023-04-27 09:10:16 --> Total execution time: 0.0544
INFO - 2023-04-27 09:10:16 --> Config Class Initialized
INFO - 2023-04-27 09:10:16 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:10:16 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:10:16 --> Utf8 Class Initialized
INFO - 2023-04-27 09:10:16 --> URI Class Initialized
INFO - 2023-04-27 09:10:16 --> Router Class Initialized
INFO - 2023-04-27 09:10:16 --> Output Class Initialized
INFO - 2023-04-27 09:10:16 --> Security Class Initialized
DEBUG - 2023-04-27 09:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:10:16 --> Input Class Initialized
INFO - 2023-04-27 09:10:16 --> Language Class Initialized
INFO - 2023-04-27 09:10:16 --> Loader Class Initialized
INFO - 2023-04-27 09:10:16 --> Controller Class Initialized
DEBUG - 2023-04-27 09:10:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:10:16 --> Database Driver Class Initialized
INFO - 2023-04-27 09:10:16 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:10:16 --> Final output sent to browser
DEBUG - 2023-04-27 09:10:16 --> Total execution time: 0.0124
INFO - 2023-04-27 09:11:20 --> Config Class Initialized
INFO - 2023-04-27 09:11:20 --> Config Class Initialized
INFO - 2023-04-27 09:11:20 --> Hooks Class Initialized
INFO - 2023-04-27 09:11:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:11:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:11:20 --> Utf8 Class Initialized
INFO - 2023-04-27 09:11:20 --> Utf8 Class Initialized
INFO - 2023-04-27 09:11:20 --> URI Class Initialized
INFO - 2023-04-27 09:11:20 --> URI Class Initialized
INFO - 2023-04-27 09:11:20 --> Router Class Initialized
INFO - 2023-04-27 09:11:20 --> Router Class Initialized
INFO - 2023-04-27 09:11:20 --> Output Class Initialized
INFO - 2023-04-27 09:11:20 --> Output Class Initialized
INFO - 2023-04-27 09:11:20 --> Security Class Initialized
INFO - 2023-04-27 09:11:20 --> Security Class Initialized
DEBUG - 2023-04-27 09:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 09:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:11:20 --> Input Class Initialized
INFO - 2023-04-27 09:11:20 --> Input Class Initialized
INFO - 2023-04-27 09:11:20 --> Language Class Initialized
INFO - 2023-04-27 09:11:20 --> Language Class Initialized
INFO - 2023-04-27 09:11:20 --> Loader Class Initialized
INFO - 2023-04-27 09:11:20 --> Loader Class Initialized
INFO - 2023-04-27 09:11:20 --> Controller Class Initialized
INFO - 2023-04-27 09:11:20 --> Controller Class Initialized
DEBUG - 2023-04-27 09:11:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:11:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:11:20 --> Database Driver Class Initialized
INFO - 2023-04-27 09:11:20 --> Database Driver Class Initialized
INFO - 2023-04-27 09:11:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:11:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:11:20 --> Final output sent to browser
DEBUG - 2023-04-27 09:11:20 --> Total execution time: 0.0549
INFO - 2023-04-27 09:11:20 --> Config Class Initialized
INFO - 2023-04-27 09:11:20 --> Hooks Class Initialized
INFO - 2023-04-27 09:11:20 --> Final output sent to browser
DEBUG - 2023-04-27 09:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:11:20 --> Total execution time: 0.0576
INFO - 2023-04-27 09:11:20 --> Utf8 Class Initialized
INFO - 2023-04-27 09:11:20 --> URI Class Initialized
INFO - 2023-04-27 09:11:20 --> Router Class Initialized
INFO - 2023-04-27 09:11:20 --> Output Class Initialized
INFO - 2023-04-27 09:11:20 --> Security Class Initialized
DEBUG - 2023-04-27 09:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:11:20 --> Input Class Initialized
INFO - 2023-04-27 09:11:20 --> Language Class Initialized
INFO - 2023-04-27 09:11:20 --> Loader Class Initialized
INFO - 2023-04-27 09:11:20 --> Controller Class Initialized
DEBUG - 2023-04-27 09:11:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:11:20 --> Config Class Initialized
INFO - 2023-04-27 09:11:20 --> Database Driver Class Initialized
INFO - 2023-04-27 09:11:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:11:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:11:20 --> Utf8 Class Initialized
INFO - 2023-04-27 09:11:20 --> URI Class Initialized
INFO - 2023-04-27 09:11:20 --> Router Class Initialized
INFO - 2023-04-27 09:11:20 --> Output Class Initialized
INFO - 2023-04-27 09:11:20 --> Security Class Initialized
DEBUG - 2023-04-27 09:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:11:20 --> Input Class Initialized
INFO - 2023-04-27 09:11:20 --> Language Class Initialized
INFO - 2023-04-27 09:11:20 --> Loader Class Initialized
INFO - 2023-04-27 09:11:20 --> Controller Class Initialized
DEBUG - 2023-04-27 09:11:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:11:20 --> Database Driver Class Initialized
INFO - 2023-04-27 09:11:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:11:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:11:20 --> Final output sent to browser
DEBUG - 2023-04-27 09:11:20 --> Total execution time: 0.0149
INFO - 2023-04-27 09:11:20 --> Final output sent to browser
DEBUG - 2023-04-27 09:11:20 --> Total execution time: 0.0154
INFO - 2023-04-27 09:27:40 --> Config Class Initialized
INFO - 2023-04-27 09:27:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:40 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:40 --> URI Class Initialized
INFO - 2023-04-27 09:27:40 --> Router Class Initialized
INFO - 2023-04-27 09:27:40 --> Output Class Initialized
INFO - 2023-04-27 09:27:40 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:40 --> Input Class Initialized
INFO - 2023-04-27 09:27:40 --> Language Class Initialized
INFO - 2023-04-27 09:27:40 --> Loader Class Initialized
INFO - 2023-04-27 09:27:40 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:40 --> Database Driver Class Initialized
INFO - 2023-04-27 09:27:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:27:40 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:40 --> Total execution time: 0.0308
INFO - 2023-04-27 09:27:40 --> Config Class Initialized
INFO - 2023-04-27 09:27:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:40 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:40 --> URI Class Initialized
INFO - 2023-04-27 09:27:40 --> Router Class Initialized
INFO - 2023-04-27 09:27:40 --> Output Class Initialized
INFO - 2023-04-27 09:27:40 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:40 --> Input Class Initialized
INFO - 2023-04-27 09:27:40 --> Language Class Initialized
INFO - 2023-04-27 09:27:40 --> Loader Class Initialized
INFO - 2023-04-27 09:27:40 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:40 --> Database Driver Class Initialized
INFO - 2023-04-27 09:27:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:27:40 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:40 --> Total execution time: 0.0602
INFO - 2023-04-27 09:27:45 --> Config Class Initialized
INFO - 2023-04-27 09:27:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:45 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:45 --> URI Class Initialized
INFO - 2023-04-27 09:27:45 --> Router Class Initialized
INFO - 2023-04-27 09:27:45 --> Output Class Initialized
INFO - 2023-04-27 09:27:45 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:45 --> Input Class Initialized
INFO - 2023-04-27 09:27:45 --> Language Class Initialized
INFO - 2023-04-27 09:27:45 --> Loader Class Initialized
INFO - 2023-04-27 09:27:45 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:45 --> Database Driver Class Initialized
INFO - 2023-04-27 09:27:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:27:45 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:45 --> Total execution time: 0.0190
INFO - 2023-04-27 09:27:45 --> Config Class Initialized
INFO - 2023-04-27 09:27:45 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:45 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:45 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:45 --> URI Class Initialized
INFO - 2023-04-27 09:27:45 --> Router Class Initialized
INFO - 2023-04-27 09:27:45 --> Output Class Initialized
INFO - 2023-04-27 09:27:45 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:45 --> Input Class Initialized
INFO - 2023-04-27 09:27:45 --> Language Class Initialized
INFO - 2023-04-27 09:27:45 --> Loader Class Initialized
INFO - 2023-04-27 09:27:45 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:45 --> Database Driver Class Initialized
INFO - 2023-04-27 09:27:45 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:27:45 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:45 --> Total execution time: 0.0551
INFO - 2023-04-27 09:27:47 --> Config Class Initialized
INFO - 2023-04-27 09:27:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:47 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:47 --> URI Class Initialized
INFO - 2023-04-27 09:27:47 --> Router Class Initialized
INFO - 2023-04-27 09:27:47 --> Output Class Initialized
INFO - 2023-04-27 09:27:47 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:47 --> Input Class Initialized
INFO - 2023-04-27 09:27:47 --> Language Class Initialized
INFO - 2023-04-27 09:27:47 --> Loader Class Initialized
INFO - 2023-04-27 09:27:47 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:47 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:47 --> Total execution time: 0.0470
INFO - 2023-04-27 09:27:47 --> Config Class Initialized
INFO - 2023-04-27 09:27:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:47 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:47 --> URI Class Initialized
INFO - 2023-04-27 09:27:47 --> Router Class Initialized
INFO - 2023-04-27 09:27:47 --> Output Class Initialized
INFO - 2023-04-27 09:27:47 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:47 --> Input Class Initialized
INFO - 2023-04-27 09:27:47 --> Language Class Initialized
INFO - 2023-04-27 09:27:47 --> Loader Class Initialized
INFO - 2023-04-27 09:27:47 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:47 --> Database Driver Class Initialized
INFO - 2023-04-27 09:27:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:27:47 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:47 --> Total execution time: 0.0615
INFO - 2023-04-27 09:27:49 --> Config Class Initialized
INFO - 2023-04-27 09:27:49 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:49 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:49 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:49 --> URI Class Initialized
INFO - 2023-04-27 09:27:49 --> Router Class Initialized
INFO - 2023-04-27 09:27:49 --> Output Class Initialized
INFO - 2023-04-27 09:27:49 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:49 --> Input Class Initialized
INFO - 2023-04-27 09:27:49 --> Language Class Initialized
INFO - 2023-04-27 09:27:49 --> Loader Class Initialized
INFO - 2023-04-27 09:27:49 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:49 --> Database Driver Class Initialized
INFO - 2023-04-27 09:27:49 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:27:49 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:49 --> Total execution time: 0.0247
INFO - 2023-04-27 09:27:49 --> Config Class Initialized
INFO - 2023-04-27 09:27:49 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:49 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:49 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:49 --> URI Class Initialized
INFO - 2023-04-27 09:27:49 --> Router Class Initialized
INFO - 2023-04-27 09:27:49 --> Output Class Initialized
INFO - 2023-04-27 09:27:49 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:49 --> Input Class Initialized
INFO - 2023-04-27 09:27:49 --> Language Class Initialized
INFO - 2023-04-27 09:27:49 --> Loader Class Initialized
INFO - 2023-04-27 09:27:49 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:49 --> Database Driver Class Initialized
INFO - 2023-04-27 09:27:49 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:27:49 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:49 --> Total execution time: 0.0666
INFO - 2023-04-27 09:27:50 --> Config Class Initialized
INFO - 2023-04-27 09:27:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:27:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:27:50 --> Utf8 Class Initialized
INFO - 2023-04-27 09:27:50 --> URI Class Initialized
INFO - 2023-04-27 09:27:50 --> Router Class Initialized
INFO - 2023-04-27 09:27:50 --> Output Class Initialized
INFO - 2023-04-27 09:27:50 --> Security Class Initialized
DEBUG - 2023-04-27 09:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:27:50 --> Input Class Initialized
INFO - 2023-04-27 09:27:50 --> Language Class Initialized
INFO - 2023-04-27 09:27:50 --> Loader Class Initialized
INFO - 2023-04-27 09:27:50 --> Controller Class Initialized
DEBUG - 2023-04-27 09:27:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:27:50 --> Database Driver Class Initialized
INFO - 2023-04-27 09:27:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:27:50 --> Final output sent to browser
DEBUG - 2023-04-27 09:27:50 --> Total execution time: 0.0174
INFO - 2023-04-27 09:28:01 --> Config Class Initialized
INFO - 2023-04-27 09:28:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:28:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:28:01 --> Utf8 Class Initialized
INFO - 2023-04-27 09:28:01 --> URI Class Initialized
INFO - 2023-04-27 09:28:01 --> Router Class Initialized
INFO - 2023-04-27 09:28:01 --> Output Class Initialized
INFO - 2023-04-27 09:28:01 --> Security Class Initialized
DEBUG - 2023-04-27 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:28:01 --> Input Class Initialized
INFO - 2023-04-27 09:28:01 --> Language Class Initialized
INFO - 2023-04-27 09:28:01 --> Loader Class Initialized
INFO - 2023-04-27 09:28:01 --> Controller Class Initialized
DEBUG - 2023-04-27 09:28:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:28:01 --> Database Driver Class Initialized
INFO - 2023-04-27 09:28:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:28:01 --> Final output sent to browser
DEBUG - 2023-04-27 09:28:01 --> Total execution time: 0.0189
INFO - 2023-04-27 09:28:01 --> Config Class Initialized
INFO - 2023-04-27 09:28:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:28:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:28:01 --> Utf8 Class Initialized
INFO - 2023-04-27 09:28:01 --> URI Class Initialized
INFO - 2023-04-27 09:28:01 --> Router Class Initialized
INFO - 2023-04-27 09:28:01 --> Output Class Initialized
INFO - 2023-04-27 09:28:01 --> Security Class Initialized
DEBUG - 2023-04-27 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:28:01 --> Input Class Initialized
INFO - 2023-04-27 09:28:01 --> Language Class Initialized
INFO - 2023-04-27 09:28:01 --> Loader Class Initialized
INFO - 2023-04-27 09:28:01 --> Controller Class Initialized
DEBUG - 2023-04-27 09:28:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:28:01 --> Database Driver Class Initialized
INFO - 2023-04-27 09:28:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:28:01 --> Final output sent to browser
DEBUG - 2023-04-27 09:28:01 --> Total execution time: 0.1040
INFO - 2023-04-27 09:28:12 --> Config Class Initialized
INFO - 2023-04-27 09:28:13 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:28:13 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:28:13 --> Utf8 Class Initialized
INFO - 2023-04-27 09:28:13 --> URI Class Initialized
INFO - 2023-04-27 09:28:13 --> Router Class Initialized
INFO - 2023-04-27 09:28:13 --> Output Class Initialized
INFO - 2023-04-27 09:28:13 --> Security Class Initialized
DEBUG - 2023-04-27 09:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:28:13 --> Input Class Initialized
INFO - 2023-04-27 09:28:13 --> Language Class Initialized
INFO - 2023-04-27 09:28:13 --> Loader Class Initialized
INFO - 2023-04-27 09:28:13 --> Controller Class Initialized
DEBUG - 2023-04-27 09:28:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:28:13 --> Database Driver Class Initialized
INFO - 2023-04-27 09:28:13 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:28:13 --> Final output sent to browser
DEBUG - 2023-04-27 09:28:13 --> Total execution time: 0.1032
INFO - 2023-04-27 09:28:13 --> Config Class Initialized
INFO - 2023-04-27 09:28:13 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:28:13 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:28:13 --> Utf8 Class Initialized
INFO - 2023-04-27 09:28:13 --> URI Class Initialized
INFO - 2023-04-27 09:28:13 --> Router Class Initialized
INFO - 2023-04-27 09:28:13 --> Output Class Initialized
INFO - 2023-04-27 09:28:13 --> Security Class Initialized
DEBUG - 2023-04-27 09:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:28:13 --> Input Class Initialized
INFO - 2023-04-27 09:28:13 --> Language Class Initialized
INFO - 2023-04-27 09:28:13 --> Loader Class Initialized
INFO - 2023-04-27 09:28:13 --> Controller Class Initialized
DEBUG - 2023-04-27 09:28:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:28:13 --> Database Driver Class Initialized
INFO - 2023-04-27 09:28:13 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:28:13 --> Final output sent to browser
DEBUG - 2023-04-27 09:28:13 --> Total execution time: 0.0998
INFO - 2023-04-27 09:28:17 --> Config Class Initialized
INFO - 2023-04-27 09:28:17 --> Config Class Initialized
INFO - 2023-04-27 09:28:17 --> Hooks Class Initialized
INFO - 2023-04-27 09:28:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:28:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:28:17 --> Utf8 Class Initialized
INFO - 2023-04-27 09:28:17 --> Utf8 Class Initialized
INFO - 2023-04-27 09:28:17 --> URI Class Initialized
INFO - 2023-04-27 09:28:17 --> URI Class Initialized
INFO - 2023-04-27 09:28:17 --> Router Class Initialized
INFO - 2023-04-27 09:28:17 --> Router Class Initialized
INFO - 2023-04-27 09:28:17 --> Output Class Initialized
INFO - 2023-04-27 09:28:17 --> Output Class Initialized
INFO - 2023-04-27 09:28:17 --> Security Class Initialized
INFO - 2023-04-27 09:28:17 --> Security Class Initialized
DEBUG - 2023-04-27 09:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 09:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:28:17 --> Input Class Initialized
INFO - 2023-04-27 09:28:17 --> Input Class Initialized
INFO - 2023-04-27 09:28:17 --> Language Class Initialized
INFO - 2023-04-27 09:28:17 --> Language Class Initialized
INFO - 2023-04-27 09:28:17 --> Loader Class Initialized
INFO - 2023-04-27 09:28:17 --> Controller Class Initialized
INFO - 2023-04-27 09:28:17 --> Loader Class Initialized
DEBUG - 2023-04-27 09:28:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:28:17 --> Controller Class Initialized
DEBUG - 2023-04-27 09:28:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:28:17 --> Database Driver Class Initialized
INFO - 2023-04-27 09:28:17 --> Database Driver Class Initialized
INFO - 2023-04-27 09:28:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:28:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:28:17 --> Final output sent to browser
INFO - 2023-04-27 09:28:17 --> Final output sent to browser
DEBUG - 2023-04-27 09:28:17 --> Total execution time: 0.0330
DEBUG - 2023-04-27 09:28:17 --> Total execution time: 0.0331
INFO - 2023-04-27 09:28:17 --> Config Class Initialized
INFO - 2023-04-27 09:28:17 --> Config Class Initialized
INFO - 2023-04-27 09:28:17 --> Hooks Class Initialized
INFO - 2023-04-27 09:28:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:28:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:28:17 --> Utf8 Class Initialized
INFO - 2023-04-27 09:28:17 --> Utf8 Class Initialized
INFO - 2023-04-27 09:28:17 --> URI Class Initialized
INFO - 2023-04-27 09:28:17 --> URI Class Initialized
INFO - 2023-04-27 09:28:17 --> Router Class Initialized
INFO - 2023-04-27 09:28:17 --> Router Class Initialized
INFO - 2023-04-27 09:28:17 --> Output Class Initialized
INFO - 2023-04-27 09:28:17 --> Output Class Initialized
INFO - 2023-04-27 09:28:17 --> Security Class Initialized
INFO - 2023-04-27 09:28:17 --> Security Class Initialized
DEBUG - 2023-04-27 09:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 09:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:28:17 --> Input Class Initialized
INFO - 2023-04-27 09:28:17 --> Input Class Initialized
INFO - 2023-04-27 09:28:17 --> Language Class Initialized
INFO - 2023-04-27 09:28:17 --> Language Class Initialized
INFO - 2023-04-27 09:28:17 --> Loader Class Initialized
INFO - 2023-04-27 09:28:17 --> Loader Class Initialized
INFO - 2023-04-27 09:28:17 --> Controller Class Initialized
INFO - 2023-04-27 09:28:17 --> Controller Class Initialized
DEBUG - 2023-04-27 09:28:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:28:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:28:17 --> Database Driver Class Initialized
INFO - 2023-04-27 09:28:17 --> Database Driver Class Initialized
INFO - 2023-04-27 09:28:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:28:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:28:17 --> Final output sent to browser
DEBUG - 2023-04-27 09:28:17 --> Total execution time: 0.0643
INFO - 2023-04-27 09:28:17 --> Final output sent to browser
DEBUG - 2023-04-27 09:28:17 --> Total execution time: 0.0670
INFO - 2023-04-27 09:46:12 --> Config Class Initialized
INFO - 2023-04-27 09:46:12 --> Config Class Initialized
INFO - 2023-04-27 09:46:12 --> Hooks Class Initialized
INFO - 2023-04-27 09:46:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:46:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:46:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:46:12 --> Utf8 Class Initialized
INFO - 2023-04-27 09:46:12 --> Utf8 Class Initialized
INFO - 2023-04-27 09:46:12 --> URI Class Initialized
INFO - 2023-04-27 09:46:12 --> URI Class Initialized
INFO - 2023-04-27 09:46:12 --> Router Class Initialized
INFO - 2023-04-27 09:46:12 --> Router Class Initialized
INFO - 2023-04-27 09:46:12 --> Output Class Initialized
INFO - 2023-04-27 09:46:12 --> Output Class Initialized
INFO - 2023-04-27 09:46:12 --> Security Class Initialized
INFO - 2023-04-27 09:46:12 --> Security Class Initialized
DEBUG - 2023-04-27 09:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 09:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:46:12 --> Input Class Initialized
INFO - 2023-04-27 09:46:12 --> Input Class Initialized
INFO - 2023-04-27 09:46:12 --> Language Class Initialized
INFO - 2023-04-27 09:46:12 --> Language Class Initialized
INFO - 2023-04-27 09:46:12 --> Loader Class Initialized
INFO - 2023-04-27 09:46:12 --> Loader Class Initialized
INFO - 2023-04-27 09:46:12 --> Controller Class Initialized
INFO - 2023-04-27 09:46:12 --> Controller Class Initialized
DEBUG - 2023-04-27 09:46:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:46:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:46:12 --> Database Driver Class Initialized
INFO - 2023-04-27 09:46:12 --> Database Driver Class Initialized
INFO - 2023-04-27 09:46:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:46:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:46:12 --> Final output sent to browser
DEBUG - 2023-04-27 09:46:12 --> Total execution time: 0.0211
INFO - 2023-04-27 09:46:12 --> Config Class Initialized
INFO - 2023-04-27 09:46:12 --> Final output sent to browser
DEBUG - 2023-04-27 09:46:12 --> Total execution time: 0.0288
INFO - 2023-04-27 09:46:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:46:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:46:12 --> Utf8 Class Initialized
INFO - 2023-04-27 09:46:12 --> URI Class Initialized
INFO - 2023-04-27 09:46:12 --> Router Class Initialized
INFO - 2023-04-27 09:46:12 --> Config Class Initialized
INFO - 2023-04-27 09:46:12 --> Hooks Class Initialized
INFO - 2023-04-27 09:46:12 --> Output Class Initialized
DEBUG - 2023-04-27 09:46:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:46:12 --> Security Class Initialized
INFO - 2023-04-27 09:46:12 --> Utf8 Class Initialized
DEBUG - 2023-04-27 09:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:46:12 --> URI Class Initialized
INFO - 2023-04-27 09:46:12 --> Input Class Initialized
INFO - 2023-04-27 09:46:12 --> Language Class Initialized
INFO - 2023-04-27 09:46:12 --> Router Class Initialized
INFO - 2023-04-27 09:46:12 --> Loader Class Initialized
INFO - 2023-04-27 09:46:12 --> Output Class Initialized
INFO - 2023-04-27 09:46:12 --> Controller Class Initialized
INFO - 2023-04-27 09:46:12 --> Security Class Initialized
DEBUG - 2023-04-27 09:46:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:46:12 --> Database Driver Class Initialized
INFO - 2023-04-27 09:46:12 --> Input Class Initialized
INFO - 2023-04-27 09:46:12 --> Language Class Initialized
INFO - 2023-04-27 09:46:12 --> Loader Class Initialized
INFO - 2023-04-27 09:46:12 --> Controller Class Initialized
DEBUG - 2023-04-27 09:46:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:46:12 --> Database Driver Class Initialized
INFO - 2023-04-27 09:46:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:46:12 --> Final output sent to browser
DEBUG - 2023-04-27 09:46:12 --> Total execution time: 0.1729
INFO - 2023-04-27 09:46:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:46:12 --> Final output sent to browser
DEBUG - 2023-04-27 09:46:12 --> Total execution time: 0.1781
INFO - 2023-04-27 09:47:23 --> Config Class Initialized
INFO - 2023-04-27 09:47:23 --> Config Class Initialized
INFO - 2023-04-27 09:47:23 --> Hooks Class Initialized
INFO - 2023-04-27 09:47:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:47:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:47:23 --> Utf8 Class Initialized
INFO - 2023-04-27 09:47:23 --> Utf8 Class Initialized
INFO - 2023-04-27 09:47:23 --> URI Class Initialized
INFO - 2023-04-27 09:47:23 --> URI Class Initialized
INFO - 2023-04-27 09:47:23 --> Router Class Initialized
INFO - 2023-04-27 09:47:23 --> Router Class Initialized
INFO - 2023-04-27 09:47:23 --> Output Class Initialized
INFO - 2023-04-27 09:47:23 --> Output Class Initialized
INFO - 2023-04-27 09:47:23 --> Security Class Initialized
INFO - 2023-04-27 09:47:23 --> Security Class Initialized
DEBUG - 2023-04-27 09:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 09:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:47:23 --> Input Class Initialized
INFO - 2023-04-27 09:47:23 --> Input Class Initialized
INFO - 2023-04-27 09:47:23 --> Language Class Initialized
INFO - 2023-04-27 09:47:23 --> Language Class Initialized
INFO - 2023-04-27 09:47:23 --> Loader Class Initialized
INFO - 2023-04-27 09:47:23 --> Loader Class Initialized
INFO - 2023-04-27 09:47:23 --> Controller Class Initialized
INFO - 2023-04-27 09:47:23 --> Controller Class Initialized
DEBUG - 2023-04-27 09:47:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:47:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:47:23 --> Database Driver Class Initialized
INFO - 2023-04-27 09:47:23 --> Database Driver Class Initialized
INFO - 2023-04-27 09:47:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:47:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:47:23 --> Final output sent to browser
DEBUG - 2023-04-27 09:47:23 --> Total execution time: 0.1362
INFO - 2023-04-27 09:47:23 --> Final output sent to browser
DEBUG - 2023-04-27 09:47:23 --> Total execution time: 0.1380
INFO - 2023-04-27 09:47:23 --> Config Class Initialized
INFO - 2023-04-27 09:47:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:47:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:47:23 --> Utf8 Class Initialized
INFO - 2023-04-27 09:47:23 --> URI Class Initialized
INFO - 2023-04-27 09:47:23 --> Config Class Initialized
INFO - 2023-04-27 09:47:23 --> Router Class Initialized
INFO - 2023-04-27 09:47:23 --> Hooks Class Initialized
INFO - 2023-04-27 09:47:23 --> Output Class Initialized
DEBUG - 2023-04-27 09:47:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:47:23 --> Security Class Initialized
INFO - 2023-04-27 09:47:23 --> Utf8 Class Initialized
DEBUG - 2023-04-27 09:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:47:23 --> URI Class Initialized
INFO - 2023-04-27 09:47:23 --> Input Class Initialized
INFO - 2023-04-27 09:47:23 --> Router Class Initialized
INFO - 2023-04-27 09:47:23 --> Language Class Initialized
INFO - 2023-04-27 09:47:23 --> Output Class Initialized
INFO - 2023-04-27 09:47:23 --> Loader Class Initialized
INFO - 2023-04-27 09:47:23 --> Security Class Initialized
INFO - 2023-04-27 09:47:23 --> Controller Class Initialized
DEBUG - 2023-04-27 09:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 09:47:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:47:23 --> Input Class Initialized
INFO - 2023-04-27 09:47:23 --> Language Class Initialized
INFO - 2023-04-27 09:47:23 --> Database Driver Class Initialized
INFO - 2023-04-27 09:47:23 --> Loader Class Initialized
INFO - 2023-04-27 09:47:23 --> Controller Class Initialized
DEBUG - 2023-04-27 09:47:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:47:23 --> Database Driver Class Initialized
INFO - 2023-04-27 09:47:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:47:23 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:47:23 --> Final output sent to browser
DEBUG - 2023-04-27 09:47:23 --> Total execution time: 0.0600
INFO - 2023-04-27 09:47:23 --> Final output sent to browser
DEBUG - 2023-04-27 09:47:23 --> Total execution time: 0.0659
INFO - 2023-04-27 09:48:27 --> Config Class Initialized
INFO - 2023-04-27 09:48:27 --> Hooks Class Initialized
INFO - 2023-04-27 09:48:27 --> Config Class Initialized
DEBUG - 2023-04-27 09:48:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:48:27 --> Hooks Class Initialized
INFO - 2023-04-27 09:48:27 --> Utf8 Class Initialized
DEBUG - 2023-04-27 09:48:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:48:27 --> URI Class Initialized
INFO - 2023-04-27 09:48:27 --> Utf8 Class Initialized
INFO - 2023-04-27 09:48:27 --> URI Class Initialized
INFO - 2023-04-27 09:48:27 --> Router Class Initialized
INFO - 2023-04-27 09:48:27 --> Output Class Initialized
INFO - 2023-04-27 09:48:27 --> Router Class Initialized
INFO - 2023-04-27 09:48:27 --> Security Class Initialized
INFO - 2023-04-27 09:48:27 --> Output Class Initialized
DEBUG - 2023-04-27 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:48:27 --> Security Class Initialized
INFO - 2023-04-27 09:48:27 --> Input Class Initialized
DEBUG - 2023-04-27 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:48:27 --> Language Class Initialized
INFO - 2023-04-27 09:48:27 --> Input Class Initialized
INFO - 2023-04-27 09:48:27 --> Language Class Initialized
INFO - 2023-04-27 09:48:27 --> Loader Class Initialized
INFO - 2023-04-27 09:48:27 --> Controller Class Initialized
INFO - 2023-04-27 09:48:27 --> Loader Class Initialized
DEBUG - 2023-04-27 09:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:48:27 --> Controller Class Initialized
INFO - 2023-04-27 09:48:27 --> Database Driver Class Initialized
DEBUG - 2023-04-27 09:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:48:27 --> Database Driver Class Initialized
INFO - 2023-04-27 09:48:27 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:48:27 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:48:27 --> Final output sent to browser
DEBUG - 2023-04-27 09:48:27 --> Total execution time: 0.0278
INFO - 2023-04-27 09:48:27 --> Config Class Initialized
INFO - 2023-04-27 09:48:27 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:48:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:48:27 --> Utf8 Class Initialized
INFO - 2023-04-27 09:48:27 --> URI Class Initialized
INFO - 2023-04-27 09:48:27 --> Router Class Initialized
INFO - 2023-04-27 09:48:27 --> Output Class Initialized
INFO - 2023-04-27 09:48:27 --> Security Class Initialized
DEBUG - 2023-04-27 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:48:27 --> Input Class Initialized
INFO - 2023-04-27 09:48:27 --> Language Class Initialized
INFO - 2023-04-27 09:48:27 --> Loader Class Initialized
INFO - 2023-04-27 09:48:27 --> Controller Class Initialized
DEBUG - 2023-04-27 09:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:48:27 --> Database Driver Class Initialized
INFO - 2023-04-27 09:48:27 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:48:27 --> Final output sent to browser
DEBUG - 2023-04-27 09:48:27 --> Total execution time: 0.0944
INFO - 2023-04-27 09:48:27 --> Final output sent to browser
DEBUG - 2023-04-27 09:48:27 --> Total execution time: 0.2417
INFO - 2023-04-27 09:48:27 --> Config Class Initialized
INFO - 2023-04-27 09:48:27 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:48:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:48:27 --> Utf8 Class Initialized
INFO - 2023-04-27 09:48:27 --> URI Class Initialized
INFO - 2023-04-27 09:48:27 --> Router Class Initialized
INFO - 2023-04-27 09:48:27 --> Output Class Initialized
INFO - 2023-04-27 09:48:27 --> Security Class Initialized
DEBUG - 2023-04-27 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:48:27 --> Input Class Initialized
INFO - 2023-04-27 09:48:27 --> Language Class Initialized
INFO - 2023-04-27 09:48:27 --> Loader Class Initialized
INFO - 2023-04-27 09:48:27 --> Controller Class Initialized
DEBUG - 2023-04-27 09:48:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:48:27 --> Database Driver Class Initialized
INFO - 2023-04-27 09:48:27 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:48:27 --> Final output sent to browser
DEBUG - 2023-04-27 09:48:27 --> Total execution time: 0.0187
INFO - 2023-04-27 09:50:12 --> Config Class Initialized
INFO - 2023-04-27 09:50:12 --> Config Class Initialized
INFO - 2023-04-27 09:50:12 --> Hooks Class Initialized
INFO - 2023-04-27 09:50:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:50:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:50:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:50:12 --> Utf8 Class Initialized
INFO - 2023-04-27 09:50:12 --> Utf8 Class Initialized
INFO - 2023-04-27 09:50:12 --> URI Class Initialized
INFO - 2023-04-27 09:50:12 --> URI Class Initialized
INFO - 2023-04-27 09:50:12 --> Router Class Initialized
INFO - 2023-04-27 09:50:12 --> Router Class Initialized
INFO - 2023-04-27 09:50:12 --> Output Class Initialized
INFO - 2023-04-27 09:50:12 --> Output Class Initialized
INFO - 2023-04-27 09:50:12 --> Security Class Initialized
INFO - 2023-04-27 09:50:12 --> Security Class Initialized
DEBUG - 2023-04-27 09:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:50:12 --> Input Class Initialized
INFO - 2023-04-27 09:50:12 --> Language Class Initialized
INFO - 2023-04-27 09:50:12 --> Loader Class Initialized
INFO - 2023-04-27 09:50:12 --> Controller Class Initialized
DEBUG - 2023-04-27 09:50:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:50:12 --> Input Class Initialized
INFO - 2023-04-27 09:50:12 --> Database Driver Class Initialized
INFO - 2023-04-27 09:50:12 --> Language Class Initialized
INFO - 2023-04-27 09:50:12 --> Loader Class Initialized
INFO - 2023-04-27 09:50:12 --> Controller Class Initialized
DEBUG - 2023-04-27 09:50:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:50:12 --> Database Driver Class Initialized
INFO - 2023-04-27 09:50:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:50:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:50:12 --> Final output sent to browser
DEBUG - 2023-04-27 09:50:12 --> Total execution time: 0.0627
INFO - 2023-04-27 09:50:12 --> Final output sent to browser
DEBUG - 2023-04-27 09:50:12 --> Total execution time: 0.0631
INFO - 2023-04-27 09:50:12 --> Config Class Initialized
INFO - 2023-04-27 09:50:12 --> Config Class Initialized
INFO - 2023-04-27 09:50:12 --> Hooks Class Initialized
INFO - 2023-04-27 09:50:12 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:50:12 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:50:12 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:50:12 --> Utf8 Class Initialized
INFO - 2023-04-27 09:50:12 --> Utf8 Class Initialized
INFO - 2023-04-27 09:50:12 --> URI Class Initialized
INFO - 2023-04-27 09:50:12 --> URI Class Initialized
INFO - 2023-04-27 09:50:12 --> Router Class Initialized
INFO - 2023-04-27 09:50:12 --> Router Class Initialized
INFO - 2023-04-27 09:50:12 --> Output Class Initialized
INFO - 2023-04-27 09:50:12 --> Output Class Initialized
INFO - 2023-04-27 09:50:12 --> Security Class Initialized
INFO - 2023-04-27 09:50:12 --> Security Class Initialized
DEBUG - 2023-04-27 09:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 09:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:50:12 --> Input Class Initialized
INFO - 2023-04-27 09:50:12 --> Input Class Initialized
INFO - 2023-04-27 09:50:12 --> Language Class Initialized
INFO - 2023-04-27 09:50:12 --> Language Class Initialized
INFO - 2023-04-27 09:50:12 --> Loader Class Initialized
INFO - 2023-04-27 09:50:12 --> Loader Class Initialized
INFO - 2023-04-27 09:50:12 --> Controller Class Initialized
INFO - 2023-04-27 09:50:12 --> Controller Class Initialized
DEBUG - 2023-04-27 09:50:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:50:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:50:12 --> Database Driver Class Initialized
INFO - 2023-04-27 09:50:12 --> Database Driver Class Initialized
INFO - 2023-04-27 09:50:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:50:12 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:50:12 --> Final output sent to browser
DEBUG - 2023-04-27 09:50:12 --> Total execution time: 0.0154
INFO - 2023-04-27 09:50:12 --> Final output sent to browser
DEBUG - 2023-04-27 09:50:12 --> Total execution time: 0.0205
INFO - 2023-04-27 09:50:40 --> Config Class Initialized
INFO - 2023-04-27 09:50:40 --> Config Class Initialized
INFO - 2023-04-27 09:50:40 --> Hooks Class Initialized
INFO - 2023-04-27 09:50:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:50:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:50:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:50:40 --> Utf8 Class Initialized
INFO - 2023-04-27 09:50:40 --> Utf8 Class Initialized
INFO - 2023-04-27 09:50:40 --> URI Class Initialized
INFO - 2023-04-27 09:50:40 --> URI Class Initialized
INFO - 2023-04-27 09:50:40 --> Router Class Initialized
INFO - 2023-04-27 09:50:40 --> Router Class Initialized
INFO - 2023-04-27 09:50:40 --> Output Class Initialized
INFO - 2023-04-27 09:50:40 --> Output Class Initialized
INFO - 2023-04-27 09:50:40 --> Security Class Initialized
INFO - 2023-04-27 09:50:40 --> Security Class Initialized
DEBUG - 2023-04-27 09:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:50:40 --> Input Class Initialized
INFO - 2023-04-27 09:50:40 --> Input Class Initialized
INFO - 2023-04-27 09:50:40 --> Language Class Initialized
INFO - 2023-04-27 09:50:40 --> Language Class Initialized
INFO - 2023-04-27 09:50:40 --> Loader Class Initialized
INFO - 2023-04-27 09:50:40 --> Loader Class Initialized
INFO - 2023-04-27 09:50:40 --> Controller Class Initialized
INFO - 2023-04-27 09:50:40 --> Controller Class Initialized
DEBUG - 2023-04-27 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-27 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-27 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:50:40 --> Final output sent to browser
DEBUG - 2023-04-27 09:50:40 --> Total execution time: 0.0593
INFO - 2023-04-27 09:50:40 --> Config Class Initialized
INFO - 2023-04-27 09:50:40 --> Hooks Class Initialized
INFO - 2023-04-27 09:50:40 --> Final output sent to browser
DEBUG - 2023-04-27 09:50:40 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 09:50:40 --> Total execution time: 0.0618
INFO - 2023-04-27 09:50:40 --> Utf8 Class Initialized
INFO - 2023-04-27 09:50:40 --> URI Class Initialized
INFO - 2023-04-27 09:50:40 --> Router Class Initialized
INFO - 2023-04-27 09:50:40 --> Output Class Initialized
INFO - 2023-04-27 09:50:40 --> Security Class Initialized
DEBUG - 2023-04-27 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:50:40 --> Input Class Initialized
INFO - 2023-04-27 09:50:40 --> Language Class Initialized
INFO - 2023-04-27 09:50:40 --> Loader Class Initialized
INFO - 2023-04-27 09:50:40 --> Config Class Initialized
INFO - 2023-04-27 09:50:40 --> Controller Class Initialized
INFO - 2023-04-27 09:50:40 --> Hooks Class Initialized
DEBUG - 2023-04-27 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 09:50:40 --> UTF-8 Support Enabled
INFO - 2023-04-27 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-27 09:50:40 --> Utf8 Class Initialized
INFO - 2023-04-27 09:50:40 --> URI Class Initialized
INFO - 2023-04-27 09:50:40 --> Router Class Initialized
INFO - 2023-04-27 09:50:40 --> Output Class Initialized
INFO - 2023-04-27 09:50:40 --> Security Class Initialized
DEBUG - 2023-04-27 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 09:50:40 --> Input Class Initialized
INFO - 2023-04-27 09:50:40 --> Language Class Initialized
INFO - 2023-04-27 09:50:40 --> Loader Class Initialized
INFO - 2023-04-27 09:50:40 --> Controller Class Initialized
DEBUG - 2023-04-27 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 09:50:40 --> Database Driver Class Initialized
INFO - 2023-04-27 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-04-27 09:50:40 --> Final output sent to browser
DEBUG - 2023-04-27 09:50:40 --> Total execution time: 0.0162
INFO - 2023-04-27 09:50:40 --> Final output sent to browser
DEBUG - 2023-04-27 09:50:41 --> Total execution time: 0.0203
INFO - 2023-04-27 10:02:56 --> Config Class Initialized
INFO - 2023-04-27 10:02:56 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:02:56 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:02:56 --> Utf8 Class Initialized
INFO - 2023-04-27 10:02:56 --> URI Class Initialized
INFO - 2023-04-27 10:02:56 --> Router Class Initialized
INFO - 2023-04-27 10:02:56 --> Output Class Initialized
INFO - 2023-04-27 10:02:56 --> Security Class Initialized
DEBUG - 2023-04-27 10:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:02:56 --> Input Class Initialized
INFO - 2023-04-27 10:02:56 --> Language Class Initialized
INFO - 2023-04-27 10:02:56 --> Loader Class Initialized
INFO - 2023-04-27 10:02:56 --> Controller Class Initialized
DEBUG - 2023-04-27 10:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:02:56 --> Database Driver Class Initialized
INFO - 2023-04-27 10:02:56 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:02:56 --> Final output sent to browser
DEBUG - 2023-04-27 10:02:56 --> Total execution time: 0.0146
INFO - 2023-04-27 10:02:56 --> Config Class Initialized
INFO - 2023-04-27 10:02:56 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:02:56 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:02:56 --> Utf8 Class Initialized
INFO - 2023-04-27 10:02:56 --> URI Class Initialized
INFO - 2023-04-27 10:02:56 --> Router Class Initialized
INFO - 2023-04-27 10:02:56 --> Output Class Initialized
INFO - 2023-04-27 10:02:56 --> Security Class Initialized
DEBUG - 2023-04-27 10:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:02:56 --> Input Class Initialized
INFO - 2023-04-27 10:02:56 --> Language Class Initialized
INFO - 2023-04-27 10:02:56 --> Loader Class Initialized
INFO - 2023-04-27 10:02:56 --> Controller Class Initialized
DEBUG - 2023-04-27 10:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:02:56 --> Database Driver Class Initialized
INFO - 2023-04-27 10:02:56 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:02:56 --> Final output sent to browser
DEBUG - 2023-04-27 10:02:56 --> Total execution time: 0.0577
INFO - 2023-04-27 10:02:56 --> Config Class Initialized
INFO - 2023-04-27 10:02:56 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:02:56 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:02:56 --> Utf8 Class Initialized
INFO - 2023-04-27 10:02:56 --> URI Class Initialized
INFO - 2023-04-27 10:02:56 --> Router Class Initialized
INFO - 2023-04-27 10:02:56 --> Output Class Initialized
INFO - 2023-04-27 10:02:56 --> Security Class Initialized
DEBUG - 2023-04-27 10:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:02:56 --> Input Class Initialized
INFO - 2023-04-27 10:02:56 --> Language Class Initialized
INFO - 2023-04-27 10:02:56 --> Loader Class Initialized
INFO - 2023-04-27 10:02:56 --> Controller Class Initialized
DEBUG - 2023-04-27 10:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:02:56 --> Database Driver Class Initialized
INFO - 2023-04-27 10:02:56 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:02:56 --> Final output sent to browser
DEBUG - 2023-04-27 10:02:56 --> Total execution time: 0.0551
INFO - 2023-04-27 10:02:56 --> Config Class Initialized
INFO - 2023-04-27 10:02:56 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:02:56 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:02:56 --> Utf8 Class Initialized
INFO - 2023-04-27 10:02:56 --> URI Class Initialized
INFO - 2023-04-27 10:02:56 --> Router Class Initialized
INFO - 2023-04-27 10:02:56 --> Output Class Initialized
INFO - 2023-04-27 10:02:56 --> Security Class Initialized
DEBUG - 2023-04-27 10:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:02:56 --> Input Class Initialized
INFO - 2023-04-27 10:02:56 --> Language Class Initialized
INFO - 2023-04-27 10:02:56 --> Loader Class Initialized
INFO - 2023-04-27 10:02:56 --> Controller Class Initialized
DEBUG - 2023-04-27 10:02:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:02:56 --> Database Driver Class Initialized
INFO - 2023-04-27 10:02:56 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:02:56 --> Final output sent to browser
DEBUG - 2023-04-27 10:02:56 --> Total execution time: 0.1358
INFO - 2023-04-27 10:04:14 --> Config Class Initialized
INFO - 2023-04-27 10:04:14 --> Config Class Initialized
INFO - 2023-04-27 10:04:14 --> Hooks Class Initialized
INFO - 2023-04-27 10:04:14 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:04:14 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:04:14 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:04:14 --> Utf8 Class Initialized
INFO - 2023-04-27 10:04:14 --> Utf8 Class Initialized
INFO - 2023-04-27 10:04:14 --> URI Class Initialized
INFO - 2023-04-27 10:04:14 --> URI Class Initialized
INFO - 2023-04-27 10:04:14 --> Router Class Initialized
INFO - 2023-04-27 10:04:14 --> Router Class Initialized
INFO - 2023-04-27 10:04:14 --> Output Class Initialized
INFO - 2023-04-27 10:04:14 --> Output Class Initialized
INFO - 2023-04-27 10:04:14 --> Security Class Initialized
INFO - 2023-04-27 10:04:14 --> Security Class Initialized
DEBUG - 2023-04-27 10:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:04:14 --> Input Class Initialized
INFO - 2023-04-27 10:04:14 --> Input Class Initialized
INFO - 2023-04-27 10:04:14 --> Language Class Initialized
INFO - 2023-04-27 10:04:14 --> Language Class Initialized
INFO - 2023-04-27 10:04:14 --> Loader Class Initialized
INFO - 2023-04-27 10:04:14 --> Loader Class Initialized
INFO - 2023-04-27 10:04:14 --> Controller Class Initialized
INFO - 2023-04-27 10:04:14 --> Controller Class Initialized
DEBUG - 2023-04-27 10:04:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:04:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:04:14 --> Database Driver Class Initialized
INFO - 2023-04-27 10:04:14 --> Database Driver Class Initialized
INFO - 2023-04-27 10:04:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:04:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:04:15 --> Final output sent to browser
DEBUG - 2023-04-27 10:04:15 --> Total execution time: 0.0236
INFO - 2023-04-27 10:04:15 --> Config Class Initialized
INFO - 2023-04-27 10:04:15 --> Final output sent to browser
INFO - 2023-04-27 10:04:15 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:04:15 --> Total execution time: 0.0267
DEBUG - 2023-04-27 10:04:15 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:04:15 --> Utf8 Class Initialized
INFO - 2023-04-27 10:04:15 --> URI Class Initialized
INFO - 2023-04-27 10:04:15 --> Router Class Initialized
INFO - 2023-04-27 10:04:15 --> Output Class Initialized
INFO - 2023-04-27 10:04:15 --> Security Class Initialized
INFO - 2023-04-27 10:04:15 --> Config Class Initialized
INFO - 2023-04-27 10:04:15 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:04:15 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:04:15 --> Utf8 Class Initialized
INFO - 2023-04-27 10:04:15 --> Input Class Initialized
INFO - 2023-04-27 10:04:15 --> URI Class Initialized
INFO - 2023-04-27 10:04:15 --> Language Class Initialized
INFO - 2023-04-27 10:04:15 --> Router Class Initialized
INFO - 2023-04-27 10:04:15 --> Output Class Initialized
INFO - 2023-04-27 10:04:15 --> Loader Class Initialized
INFO - 2023-04-27 10:04:15 --> Security Class Initialized
INFO - 2023-04-27 10:04:15 --> Controller Class Initialized
DEBUG - 2023-04-27 10:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:04:15 --> Input Class Initialized
INFO - 2023-04-27 10:04:15 --> Database Driver Class Initialized
INFO - 2023-04-27 10:04:15 --> Language Class Initialized
INFO - 2023-04-27 10:04:15 --> Loader Class Initialized
INFO - 2023-04-27 10:04:15 --> Controller Class Initialized
DEBUG - 2023-04-27 10:04:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:04:15 --> Database Driver Class Initialized
INFO - 2023-04-27 10:04:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:04:15 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:04:15 --> Final output sent to browser
DEBUG - 2023-04-27 10:04:15 --> Total execution time: 0.0999
INFO - 2023-04-27 10:04:15 --> Final output sent to browser
DEBUG - 2023-04-27 10:04:15 --> Total execution time: 0.0633
INFO - 2023-04-27 10:04:20 --> Config Class Initialized
INFO - 2023-04-27 10:04:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:04:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:04:20 --> Utf8 Class Initialized
INFO - 2023-04-27 10:04:20 --> URI Class Initialized
INFO - 2023-04-27 10:04:20 --> Router Class Initialized
INFO - 2023-04-27 10:04:20 --> Output Class Initialized
INFO - 2023-04-27 10:04:20 --> Security Class Initialized
DEBUG - 2023-04-27 10:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:04:20 --> Input Class Initialized
INFO - 2023-04-27 10:04:20 --> Language Class Initialized
INFO - 2023-04-27 10:04:20 --> Loader Class Initialized
INFO - 2023-04-27 10:04:20 --> Controller Class Initialized
DEBUG - 2023-04-27 10:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:04:20 --> Database Driver Class Initialized
INFO - 2023-04-27 10:04:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:04:20 --> Final output sent to browser
DEBUG - 2023-04-27 10:04:20 --> Total execution time: 0.0210
INFO - 2023-04-27 10:04:20 --> Config Class Initialized
INFO - 2023-04-27 10:04:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:04:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:04:20 --> Utf8 Class Initialized
INFO - 2023-04-27 10:04:20 --> URI Class Initialized
INFO - 2023-04-27 10:04:20 --> Router Class Initialized
INFO - 2023-04-27 10:04:20 --> Output Class Initialized
INFO - 2023-04-27 10:04:20 --> Security Class Initialized
DEBUG - 2023-04-27 10:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:04:20 --> Input Class Initialized
INFO - 2023-04-27 10:04:20 --> Language Class Initialized
INFO - 2023-04-27 10:04:20 --> Loader Class Initialized
INFO - 2023-04-27 10:04:20 --> Controller Class Initialized
DEBUG - 2023-04-27 10:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:04:20 --> Database Driver Class Initialized
INFO - 2023-04-27 10:04:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:04:20 --> Final output sent to browser
DEBUG - 2023-04-27 10:04:20 --> Total execution time: 0.2277
INFO - 2023-04-27 10:04:20 --> Config Class Initialized
INFO - 2023-04-27 10:04:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:04:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:04:20 --> Utf8 Class Initialized
INFO - 2023-04-27 10:04:20 --> URI Class Initialized
INFO - 2023-04-27 10:04:20 --> Router Class Initialized
INFO - 2023-04-27 10:04:20 --> Output Class Initialized
INFO - 2023-04-27 10:04:20 --> Security Class Initialized
DEBUG - 2023-04-27 10:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:04:20 --> Input Class Initialized
INFO - 2023-04-27 10:04:20 --> Language Class Initialized
INFO - 2023-04-27 10:04:20 --> Loader Class Initialized
INFO - 2023-04-27 10:04:20 --> Controller Class Initialized
DEBUG - 2023-04-27 10:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:04:20 --> Database Driver Class Initialized
INFO - 2023-04-27 10:04:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:04:20 --> Final output sent to browser
DEBUG - 2023-04-27 10:04:20 --> Total execution time: 0.0553
INFO - 2023-04-27 10:04:20 --> Config Class Initialized
INFO - 2023-04-27 10:04:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:04:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:04:20 --> Utf8 Class Initialized
INFO - 2023-04-27 10:04:20 --> URI Class Initialized
INFO - 2023-04-27 10:04:20 --> Router Class Initialized
INFO - 2023-04-27 10:04:20 --> Output Class Initialized
INFO - 2023-04-27 10:04:20 --> Security Class Initialized
DEBUG - 2023-04-27 10:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:04:20 --> Input Class Initialized
INFO - 2023-04-27 10:04:20 --> Language Class Initialized
INFO - 2023-04-27 10:04:20 --> Loader Class Initialized
INFO - 2023-04-27 10:04:20 --> Controller Class Initialized
DEBUG - 2023-04-27 10:04:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:04:20 --> Database Driver Class Initialized
INFO - 2023-04-27 10:04:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:04:20 --> Final output sent to browser
DEBUG - 2023-04-27 10:04:20 --> Total execution time: 0.0568
INFO - 2023-04-27 10:06:21 --> Config Class Initialized
INFO - 2023-04-27 10:06:21 --> Config Class Initialized
INFO - 2023-04-27 10:06:21 --> Hooks Class Initialized
INFO - 2023-04-27 10:06:21 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:06:21 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:06:21 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:06:21 --> Utf8 Class Initialized
INFO - 2023-04-27 10:06:21 --> URI Class Initialized
INFO - 2023-04-27 10:06:21 --> Utf8 Class Initialized
INFO - 2023-04-27 10:06:21 --> Router Class Initialized
INFO - 2023-04-27 10:06:21 --> URI Class Initialized
INFO - 2023-04-27 10:06:21 --> Output Class Initialized
INFO - 2023-04-27 10:06:21 --> Router Class Initialized
INFO - 2023-04-27 10:06:21 --> Security Class Initialized
INFO - 2023-04-27 10:06:21 --> Output Class Initialized
DEBUG - 2023-04-27 10:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:06:21 --> Input Class Initialized
INFO - 2023-04-27 10:06:21 --> Security Class Initialized
INFO - 2023-04-27 10:06:21 --> Language Class Initialized
DEBUG - 2023-04-27 10:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:06:21 --> Loader Class Initialized
INFO - 2023-04-27 10:06:21 --> Input Class Initialized
INFO - 2023-04-27 10:06:21 --> Controller Class Initialized
INFO - 2023-04-27 10:06:21 --> Language Class Initialized
DEBUG - 2023-04-27 10:06:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:06:21 --> Database Driver Class Initialized
INFO - 2023-04-27 10:06:21 --> Loader Class Initialized
INFO - 2023-04-27 10:06:21 --> Controller Class Initialized
DEBUG - 2023-04-27 10:06:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:06:21 --> Database Driver Class Initialized
INFO - 2023-04-27 10:06:22 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:06:22 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:06:22 --> Final output sent to browser
INFO - 2023-04-27 10:06:22 --> Final output sent to browser
DEBUG - 2023-04-27 10:06:22 --> Total execution time: 0.1431
DEBUG - 2023-04-27 10:06:22 --> Total execution time: 0.1453
INFO - 2023-04-27 10:06:22 --> Config Class Initialized
INFO - 2023-04-27 10:06:22 --> Config Class Initialized
INFO - 2023-04-27 10:06:22 --> Hooks Class Initialized
INFO - 2023-04-27 10:06:22 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:06:22 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:06:22 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:06:22 --> Utf8 Class Initialized
INFO - 2023-04-27 10:06:22 --> Utf8 Class Initialized
INFO - 2023-04-27 10:06:22 --> URI Class Initialized
INFO - 2023-04-27 10:06:22 --> URI Class Initialized
INFO - 2023-04-27 10:06:22 --> Router Class Initialized
INFO - 2023-04-27 10:06:22 --> Router Class Initialized
INFO - 2023-04-27 10:06:22 --> Output Class Initialized
INFO - 2023-04-27 10:06:22 --> Output Class Initialized
INFO - 2023-04-27 10:06:22 --> Security Class Initialized
INFO - 2023-04-27 10:06:22 --> Security Class Initialized
DEBUG - 2023-04-27 10:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:06:22 --> Input Class Initialized
INFO - 2023-04-27 10:06:22 --> Input Class Initialized
INFO - 2023-04-27 10:06:22 --> Language Class Initialized
INFO - 2023-04-27 10:06:22 --> Language Class Initialized
INFO - 2023-04-27 10:06:22 --> Loader Class Initialized
INFO - 2023-04-27 10:06:22 --> Loader Class Initialized
INFO - 2023-04-27 10:06:22 --> Controller Class Initialized
INFO - 2023-04-27 10:06:22 --> Controller Class Initialized
DEBUG - 2023-04-27 10:06:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:06:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:06:22 --> Database Driver Class Initialized
INFO - 2023-04-27 10:06:22 --> Database Driver Class Initialized
INFO - 2023-04-27 10:06:22 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:06:22 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:06:22 --> Final output sent to browser
DEBUG - 2023-04-27 10:06:22 --> Total execution time: 0.0155
INFO - 2023-04-27 10:06:22 --> Final output sent to browser
DEBUG - 2023-04-27 10:06:22 --> Total execution time: 0.0192
INFO - 2023-04-27 10:06:28 --> Config Class Initialized
INFO - 2023-04-27 10:06:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:06:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:06:28 --> Utf8 Class Initialized
INFO - 2023-04-27 10:06:28 --> URI Class Initialized
INFO - 2023-04-27 10:06:28 --> Router Class Initialized
INFO - 2023-04-27 10:06:28 --> Output Class Initialized
INFO - 2023-04-27 10:06:28 --> Security Class Initialized
DEBUG - 2023-04-27 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:06:28 --> Input Class Initialized
INFO - 2023-04-27 10:06:28 --> Language Class Initialized
INFO - 2023-04-27 10:06:28 --> Loader Class Initialized
INFO - 2023-04-27 10:06:28 --> Controller Class Initialized
DEBUG - 2023-04-27 10:06:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:06:28 --> Database Driver Class Initialized
INFO - 2023-04-27 10:06:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:06:28 --> Final output sent to browser
DEBUG - 2023-04-27 10:06:28 --> Total execution time: 0.0192
INFO - 2023-04-27 10:06:28 --> Config Class Initialized
INFO - 2023-04-27 10:06:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:06:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:06:28 --> Utf8 Class Initialized
INFO - 2023-04-27 10:06:28 --> URI Class Initialized
INFO - 2023-04-27 10:06:28 --> Router Class Initialized
INFO - 2023-04-27 10:06:28 --> Output Class Initialized
INFO - 2023-04-27 10:06:28 --> Security Class Initialized
DEBUG - 2023-04-27 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:06:28 --> Input Class Initialized
INFO - 2023-04-27 10:06:28 --> Language Class Initialized
INFO - 2023-04-27 10:06:28 --> Loader Class Initialized
INFO - 2023-04-27 10:06:28 --> Controller Class Initialized
DEBUG - 2023-04-27 10:06:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:06:28 --> Database Driver Class Initialized
INFO - 2023-04-27 10:06:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:06:28 --> Final output sent to browser
DEBUG - 2023-04-27 10:06:28 --> Total execution time: 0.0125
INFO - 2023-04-27 10:06:28 --> Config Class Initialized
INFO - 2023-04-27 10:06:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:06:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:06:28 --> Utf8 Class Initialized
INFO - 2023-04-27 10:06:28 --> URI Class Initialized
INFO - 2023-04-27 10:06:28 --> Router Class Initialized
INFO - 2023-04-27 10:06:28 --> Output Class Initialized
INFO - 2023-04-27 10:06:28 --> Security Class Initialized
DEBUG - 2023-04-27 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:06:28 --> Input Class Initialized
INFO - 2023-04-27 10:06:28 --> Language Class Initialized
INFO - 2023-04-27 10:06:28 --> Loader Class Initialized
INFO - 2023-04-27 10:06:28 --> Controller Class Initialized
DEBUG - 2023-04-27 10:06:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:06:28 --> Database Driver Class Initialized
INFO - 2023-04-27 10:06:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:06:28 --> Final output sent to browser
DEBUG - 2023-04-27 10:06:28 --> Total execution time: 0.0588
INFO - 2023-04-27 10:06:28 --> Config Class Initialized
INFO - 2023-04-27 10:06:28 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:06:28 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:06:28 --> Utf8 Class Initialized
INFO - 2023-04-27 10:06:28 --> URI Class Initialized
INFO - 2023-04-27 10:06:28 --> Router Class Initialized
INFO - 2023-04-27 10:06:28 --> Output Class Initialized
INFO - 2023-04-27 10:06:28 --> Security Class Initialized
DEBUG - 2023-04-27 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:06:28 --> Input Class Initialized
INFO - 2023-04-27 10:06:28 --> Language Class Initialized
INFO - 2023-04-27 10:06:28 --> Loader Class Initialized
INFO - 2023-04-27 10:06:28 --> Controller Class Initialized
DEBUG - 2023-04-27 10:06:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:06:28 --> Database Driver Class Initialized
INFO - 2023-04-27 10:06:28 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:06:28 --> Final output sent to browser
DEBUG - 2023-04-27 10:06:28 --> Total execution time: 0.0117
INFO - 2023-04-27 10:07:55 --> Config Class Initialized
INFO - 2023-04-27 10:07:55 --> Config Class Initialized
INFO - 2023-04-27 10:07:55 --> Hooks Class Initialized
INFO - 2023-04-27 10:07:55 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:07:55 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:07:55 --> Utf8 Class Initialized
INFO - 2023-04-27 10:07:55 --> Utf8 Class Initialized
INFO - 2023-04-27 10:07:55 --> URI Class Initialized
INFO - 2023-04-27 10:07:55 --> URI Class Initialized
INFO - 2023-04-27 10:07:55 --> Router Class Initialized
INFO - 2023-04-27 10:07:55 --> Router Class Initialized
INFO - 2023-04-27 10:07:55 --> Output Class Initialized
INFO - 2023-04-27 10:07:55 --> Output Class Initialized
INFO - 2023-04-27 10:07:55 --> Security Class Initialized
INFO - 2023-04-27 10:07:55 --> Security Class Initialized
DEBUG - 2023-04-27 10:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:07:55 --> Input Class Initialized
INFO - 2023-04-27 10:07:55 --> Input Class Initialized
INFO - 2023-04-27 10:07:55 --> Language Class Initialized
INFO - 2023-04-27 10:07:55 --> Language Class Initialized
INFO - 2023-04-27 10:07:55 --> Loader Class Initialized
INFO - 2023-04-27 10:07:55 --> Loader Class Initialized
INFO - 2023-04-27 10:07:55 --> Controller Class Initialized
INFO - 2023-04-27 10:07:55 --> Controller Class Initialized
DEBUG - 2023-04-27 10:07:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:07:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:07:55 --> Database Driver Class Initialized
INFO - 2023-04-27 10:07:55 --> Database Driver Class Initialized
INFO - 2023-04-27 10:07:55 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:07:55 --> Final output sent to browser
DEBUG - 2023-04-27 10:07:55 --> Total execution time: 0.1284
INFO - 2023-04-27 10:07:55 --> Config Class Initialized
INFO - 2023-04-27 10:07:55 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:07:55 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:07:55 --> Utf8 Class Initialized
INFO - 2023-04-27 10:07:55 --> URI Class Initialized
INFO - 2023-04-27 10:07:55 --> Router Class Initialized
INFO - 2023-04-27 10:07:55 --> Output Class Initialized
INFO - 2023-04-27 10:07:55 --> Security Class Initialized
DEBUG - 2023-04-27 10:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:07:55 --> Input Class Initialized
INFO - 2023-04-27 10:07:55 --> Language Class Initialized
INFO - 2023-04-27 10:07:55 --> Loader Class Initialized
INFO - 2023-04-27 10:07:55 --> Controller Class Initialized
DEBUG - 2023-04-27 10:07:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:07:55 --> Database Driver Class Initialized
INFO - 2023-04-27 10:07:55 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:07:55 --> Final output sent to browser
DEBUG - 2023-04-27 10:07:55 --> Total execution time: 0.0179
INFO - 2023-04-27 10:07:56 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:07:56 --> Final output sent to browser
DEBUG - 2023-04-27 10:07:56 --> Total execution time: 1.0914
INFO - 2023-04-27 10:07:56 --> Config Class Initialized
INFO - 2023-04-27 10:07:56 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:07:56 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:07:56 --> Utf8 Class Initialized
INFO - 2023-04-27 10:07:56 --> URI Class Initialized
INFO - 2023-04-27 10:07:56 --> Router Class Initialized
INFO - 2023-04-27 10:07:56 --> Output Class Initialized
INFO - 2023-04-27 10:07:56 --> Security Class Initialized
DEBUG - 2023-04-27 10:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:07:56 --> Input Class Initialized
INFO - 2023-04-27 10:07:56 --> Language Class Initialized
INFO - 2023-04-27 10:07:56 --> Loader Class Initialized
INFO - 2023-04-27 10:07:56 --> Controller Class Initialized
DEBUG - 2023-04-27 10:07:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:07:56 --> Database Driver Class Initialized
INFO - 2023-04-27 10:07:56 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:07:56 --> Final output sent to browser
DEBUG - 2023-04-27 10:07:56 --> Total execution time: 0.0153
INFO - 2023-04-27 10:10:23 --> Config Class Initialized
INFO - 2023-04-27 10:10:24 --> Config Class Initialized
INFO - 2023-04-27 10:10:24 --> Hooks Class Initialized
INFO - 2023-04-27 10:10:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:10:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:10:24 --> Utf8 Class Initialized
INFO - 2023-04-27 10:10:24 --> Utf8 Class Initialized
INFO - 2023-04-27 10:10:24 --> URI Class Initialized
INFO - 2023-04-27 10:10:24 --> URI Class Initialized
INFO - 2023-04-27 10:10:24 --> Router Class Initialized
INFO - 2023-04-27 10:10:24 --> Router Class Initialized
INFO - 2023-04-27 10:10:24 --> Output Class Initialized
INFO - 2023-04-27 10:10:24 --> Output Class Initialized
INFO - 2023-04-27 10:10:24 --> Security Class Initialized
INFO - 2023-04-27 10:10:24 --> Security Class Initialized
DEBUG - 2023-04-27 10:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:10:24 --> Input Class Initialized
INFO - 2023-04-27 10:10:24 --> Input Class Initialized
INFO - 2023-04-27 10:10:24 --> Language Class Initialized
INFO - 2023-04-27 10:10:24 --> Language Class Initialized
INFO - 2023-04-27 10:10:24 --> Loader Class Initialized
INFO - 2023-04-27 10:10:24 --> Loader Class Initialized
INFO - 2023-04-27 10:10:24 --> Controller Class Initialized
INFO - 2023-04-27 10:10:24 --> Controller Class Initialized
DEBUG - 2023-04-27 10:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:10:24 --> Database Driver Class Initialized
INFO - 2023-04-27 10:10:24 --> Database Driver Class Initialized
INFO - 2023-04-27 10:10:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:10:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:10:24 --> Final output sent to browser
DEBUG - 2023-04-27 10:10:24 --> Total execution time: 0.2152
INFO - 2023-04-27 10:10:24 --> Final output sent to browser
INFO - 2023-04-27 10:10:24 --> Config Class Initialized
INFO - 2023-04-27 10:10:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:10:24 --> Total execution time: 0.2144
DEBUG - 2023-04-27 10:10:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:10:24 --> Utf8 Class Initialized
INFO - 2023-04-27 10:10:24 --> URI Class Initialized
INFO - 2023-04-27 10:10:24 --> Router Class Initialized
INFO - 2023-04-27 10:10:24 --> Output Class Initialized
INFO - 2023-04-27 10:10:24 --> Security Class Initialized
DEBUG - 2023-04-27 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:10:24 --> Input Class Initialized
INFO - 2023-04-27 10:10:24 --> Language Class Initialized
INFO - 2023-04-27 10:10:24 --> Loader Class Initialized
INFO - 2023-04-27 10:10:24 --> Controller Class Initialized
INFO - 2023-04-27 10:10:24 --> Config Class Initialized
DEBUG - 2023-04-27 10:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:10:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:10:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:10:24 --> Utf8 Class Initialized
INFO - 2023-04-27 10:10:24 --> Database Driver Class Initialized
INFO - 2023-04-27 10:10:24 --> URI Class Initialized
INFO - 2023-04-27 10:10:24 --> Router Class Initialized
INFO - 2023-04-27 10:10:24 --> Output Class Initialized
INFO - 2023-04-27 10:10:24 --> Security Class Initialized
DEBUG - 2023-04-27 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:10:24 --> Input Class Initialized
INFO - 2023-04-27 10:10:24 --> Language Class Initialized
INFO - 2023-04-27 10:10:24 --> Loader Class Initialized
INFO - 2023-04-27 10:10:24 --> Controller Class Initialized
DEBUG - 2023-04-27 10:10:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:10:24 --> Database Driver Class Initialized
INFO - 2023-04-27 10:10:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:10:24 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:10:24 --> Final output sent to browser
DEBUG - 2023-04-27 10:10:24 --> Total execution time: 0.1001
INFO - 2023-04-27 10:10:24 --> Final output sent to browser
DEBUG - 2023-04-27 10:10:24 --> Total execution time: 0.0609
INFO - 2023-04-27 10:10:25 --> Config Class Initialized
INFO - 2023-04-27 10:10:25 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:10:25 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:10:25 --> Utf8 Class Initialized
INFO - 2023-04-27 10:10:25 --> URI Class Initialized
INFO - 2023-04-27 10:10:25 --> Router Class Initialized
INFO - 2023-04-27 10:10:25 --> Output Class Initialized
INFO - 2023-04-27 10:10:25 --> Security Class Initialized
DEBUG - 2023-04-27 10:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:10:25 --> Input Class Initialized
INFO - 2023-04-27 10:10:25 --> Language Class Initialized
INFO - 2023-04-27 10:10:25 --> Loader Class Initialized
INFO - 2023-04-27 10:10:25 --> Controller Class Initialized
DEBUG - 2023-04-27 10:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:10:25 --> Database Driver Class Initialized
INFO - 2023-04-27 10:10:25 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:10:25 --> Final output sent to browser
DEBUG - 2023-04-27 10:10:25 --> Total execution time: 0.0859
INFO - 2023-04-27 10:10:25 --> Config Class Initialized
INFO - 2023-04-27 10:10:25 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:10:25 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:10:25 --> Utf8 Class Initialized
INFO - 2023-04-27 10:10:25 --> URI Class Initialized
INFO - 2023-04-27 10:10:25 --> Router Class Initialized
INFO - 2023-04-27 10:10:25 --> Output Class Initialized
INFO - 2023-04-27 10:10:25 --> Security Class Initialized
DEBUG - 2023-04-27 10:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:10:25 --> Input Class Initialized
INFO - 2023-04-27 10:10:25 --> Language Class Initialized
INFO - 2023-04-27 10:10:25 --> Loader Class Initialized
INFO - 2023-04-27 10:10:25 --> Controller Class Initialized
DEBUG - 2023-04-27 10:10:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:10:25 --> Database Driver Class Initialized
INFO - 2023-04-27 10:10:25 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:10:25 --> Final output sent to browser
DEBUG - 2023-04-27 10:10:25 --> Total execution time: 0.0707
INFO - 2023-04-27 10:10:25 --> Config Class Initialized
INFO - 2023-04-27 10:10:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:10:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:10:26 --> Utf8 Class Initialized
INFO - 2023-04-27 10:10:26 --> URI Class Initialized
INFO - 2023-04-27 10:10:26 --> Router Class Initialized
INFO - 2023-04-27 10:10:26 --> Output Class Initialized
INFO - 2023-04-27 10:10:26 --> Security Class Initialized
DEBUG - 2023-04-27 10:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:10:26 --> Input Class Initialized
INFO - 2023-04-27 10:10:26 --> Language Class Initialized
INFO - 2023-04-27 10:10:26 --> Loader Class Initialized
INFO - 2023-04-27 10:10:26 --> Controller Class Initialized
DEBUG - 2023-04-27 10:10:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:10:26 --> Database Driver Class Initialized
INFO - 2023-04-27 10:10:26 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:10:26 --> Final output sent to browser
DEBUG - 2023-04-27 10:10:26 --> Total execution time: 0.0625
INFO - 2023-04-27 10:10:26 --> Config Class Initialized
INFO - 2023-04-27 10:10:26 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:10:26 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:10:26 --> Utf8 Class Initialized
INFO - 2023-04-27 10:10:26 --> URI Class Initialized
INFO - 2023-04-27 10:10:26 --> Router Class Initialized
INFO - 2023-04-27 10:10:26 --> Output Class Initialized
INFO - 2023-04-27 10:10:26 --> Security Class Initialized
DEBUG - 2023-04-27 10:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:10:26 --> Input Class Initialized
INFO - 2023-04-27 10:10:26 --> Language Class Initialized
INFO - 2023-04-27 10:10:26 --> Loader Class Initialized
INFO - 2023-04-27 10:10:26 --> Controller Class Initialized
DEBUG - 2023-04-27 10:10:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:10:26 --> Database Driver Class Initialized
INFO - 2023-04-27 10:10:26 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:10:26 --> Final output sent to browser
DEBUG - 2023-04-27 10:10:26 --> Total execution time: 0.0340
INFO - 2023-04-27 10:13:07 --> Config Class Initialized
INFO - 2023-04-27 10:13:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:13:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:13:07 --> Utf8 Class Initialized
INFO - 2023-04-27 10:13:07 --> URI Class Initialized
INFO - 2023-04-27 10:13:07 --> Router Class Initialized
INFO - 2023-04-27 10:13:07 --> Output Class Initialized
INFO - 2023-04-27 10:13:07 --> Security Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:13:07 --> Input Class Initialized
INFO - 2023-04-27 10:13:07 --> Language Class Initialized
INFO - 2023-04-27 10:13:07 --> Loader Class Initialized
INFO - 2023-04-27 10:13:07 --> Controller Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:13:07 --> Database Driver Class Initialized
INFO - 2023-04-27 10:13:07 --> Config Class Initialized
INFO - 2023-04-27 10:13:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:13:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:13:07 --> Utf8 Class Initialized
INFO - 2023-04-27 10:13:07 --> URI Class Initialized
INFO - 2023-04-27 10:13:07 --> Router Class Initialized
INFO - 2023-04-27 10:13:07 --> Output Class Initialized
INFO - 2023-04-27 10:13:07 --> Security Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:13:07 --> Input Class Initialized
INFO - 2023-04-27 10:13:07 --> Language Class Initialized
INFO - 2023-04-27 10:13:07 --> Loader Class Initialized
INFO - 2023-04-27 10:13:07 --> Controller Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:13:07 --> Database Driver Class Initialized
INFO - 2023-04-27 10:13:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:13:07 --> Final output sent to browser
DEBUG - 2023-04-27 10:13:07 --> Total execution time: 0.1090
INFO - 2023-04-27 10:13:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:13:07 --> Config Class Initialized
INFO - 2023-04-27 10:13:07 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:13:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:13:07 --> Final output sent to browser
INFO - 2023-04-27 10:13:07 --> Utf8 Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Total execution time: 0.1602
INFO - 2023-04-27 10:13:07 --> URI Class Initialized
INFO - 2023-04-27 10:13:07 --> Router Class Initialized
INFO - 2023-04-27 10:13:07 --> Output Class Initialized
INFO - 2023-04-27 10:13:07 --> Security Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:13:07 --> Config Class Initialized
INFO - 2023-04-27 10:13:07 --> Hooks Class Initialized
INFO - 2023-04-27 10:13:07 --> Input Class Initialized
INFO - 2023-04-27 10:13:07 --> Language Class Initialized
DEBUG - 2023-04-27 10:13:07 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:13:07 --> Utf8 Class Initialized
INFO - 2023-04-27 10:13:07 --> Loader Class Initialized
INFO - 2023-04-27 10:13:07 --> URI Class Initialized
INFO - 2023-04-27 10:13:07 --> Controller Class Initialized
INFO - 2023-04-27 10:13:07 --> Router Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:13:07 --> Output Class Initialized
INFO - 2023-04-27 10:13:07 --> Database Driver Class Initialized
INFO - 2023-04-27 10:13:07 --> Security Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:13:07 --> Input Class Initialized
INFO - 2023-04-27 10:13:07 --> Language Class Initialized
INFO - 2023-04-27 10:13:07 --> Loader Class Initialized
INFO - 2023-04-27 10:13:07 --> Controller Class Initialized
DEBUG - 2023-04-27 10:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:13:07 --> Database Driver Class Initialized
INFO - 2023-04-27 10:13:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:13:07 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:13:07 --> Final output sent to browser
INFO - 2023-04-27 10:13:07 --> Final output sent to browser
DEBUG - 2023-04-27 10:13:07 --> Total execution time: 0.0579
DEBUG - 2023-04-27 10:13:07 --> Total execution time: 0.1046
INFO - 2023-04-27 10:17:32 --> Config Class Initialized
INFO - 2023-04-27 10:17:32 --> Config Class Initialized
INFO - 2023-04-27 10:17:32 --> Hooks Class Initialized
INFO - 2023-04-27 10:17:32 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:17:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:17:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:17:32 --> Utf8 Class Initialized
INFO - 2023-04-27 10:17:32 --> Utf8 Class Initialized
INFO - 2023-04-27 10:17:32 --> URI Class Initialized
INFO - 2023-04-27 10:17:32 --> URI Class Initialized
INFO - 2023-04-27 10:17:32 --> Router Class Initialized
INFO - 2023-04-27 10:17:32 --> Router Class Initialized
INFO - 2023-04-27 10:17:32 --> Output Class Initialized
INFO - 2023-04-27 10:17:32 --> Output Class Initialized
INFO - 2023-04-27 10:17:32 --> Security Class Initialized
INFO - 2023-04-27 10:17:32 --> Security Class Initialized
DEBUG - 2023-04-27 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:17:32 --> Input Class Initialized
INFO - 2023-04-27 10:17:32 --> Language Class Initialized
DEBUG - 2023-04-27 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:17:32 --> Input Class Initialized
INFO - 2023-04-27 10:17:32 --> Language Class Initialized
INFO - 2023-04-27 10:17:32 --> Loader Class Initialized
INFO - 2023-04-27 10:17:32 --> Controller Class Initialized
INFO - 2023-04-27 10:17:32 --> Loader Class Initialized
DEBUG - 2023-04-27 10:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:17:32 --> Controller Class Initialized
DEBUG - 2023-04-27 10:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:17:32 --> Database Driver Class Initialized
INFO - 2023-04-27 10:17:32 --> Database Driver Class Initialized
INFO - 2023-04-27 10:17:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:17:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:17:32 --> Final output sent to browser
DEBUG - 2023-04-27 10:17:32 --> Total execution time: 0.0668
INFO - 2023-04-27 10:17:32 --> Final output sent to browser
DEBUG - 2023-04-27 10:17:32 --> Total execution time: 0.0686
INFO - 2023-04-27 10:17:32 --> Config Class Initialized
INFO - 2023-04-27 10:17:32 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:17:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:17:32 --> Utf8 Class Initialized
INFO - 2023-04-27 10:17:32 --> URI Class Initialized
INFO - 2023-04-27 10:17:32 --> Config Class Initialized
INFO - 2023-04-27 10:17:32 --> Hooks Class Initialized
INFO - 2023-04-27 10:17:32 --> Router Class Initialized
DEBUG - 2023-04-27 10:17:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:17:32 --> Output Class Initialized
INFO - 2023-04-27 10:17:32 --> Utf8 Class Initialized
INFO - 2023-04-27 10:17:32 --> Security Class Initialized
INFO - 2023-04-27 10:17:32 --> URI Class Initialized
DEBUG - 2023-04-27 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:17:32 --> Router Class Initialized
INFO - 2023-04-27 10:17:32 --> Input Class Initialized
INFO - 2023-04-27 10:17:32 --> Output Class Initialized
INFO - 2023-04-27 10:17:32 --> Language Class Initialized
INFO - 2023-04-27 10:17:32 --> Security Class Initialized
DEBUG - 2023-04-27 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:17:32 --> Loader Class Initialized
INFO - 2023-04-27 10:17:32 --> Input Class Initialized
INFO - 2023-04-27 10:17:32 --> Controller Class Initialized
INFO - 2023-04-27 10:17:32 --> Language Class Initialized
DEBUG - 2023-04-27 10:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:17:32 --> Loader Class Initialized
INFO - 2023-04-27 10:17:32 --> Controller Class Initialized
DEBUG - 2023-04-27 10:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:17:32 --> Database Driver Class Initialized
INFO - 2023-04-27 10:17:32 --> Database Driver Class Initialized
INFO - 2023-04-27 10:17:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:17:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:17:32 --> Final output sent to browser
DEBUG - 2023-04-27 10:17:32 --> Total execution time: 0.1367
INFO - 2023-04-27 10:17:32 --> Final output sent to browser
DEBUG - 2023-04-27 10:17:32 --> Total execution time: 0.0997
INFO - 2023-04-27 10:27:32 --> Config Class Initialized
INFO - 2023-04-27 10:27:32 --> Config Class Initialized
INFO - 2023-04-27 10:27:32 --> Hooks Class Initialized
INFO - 2023-04-27 10:27:32 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:27:32 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:27:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:27:32 --> Utf8 Class Initialized
INFO - 2023-04-27 10:27:32 --> Utf8 Class Initialized
INFO - 2023-04-27 10:27:32 --> URI Class Initialized
INFO - 2023-04-27 10:27:32 --> URI Class Initialized
INFO - 2023-04-27 10:27:32 --> Router Class Initialized
INFO - 2023-04-27 10:27:32 --> Router Class Initialized
INFO - 2023-04-27 10:27:32 --> Output Class Initialized
INFO - 2023-04-27 10:27:32 --> Output Class Initialized
INFO - 2023-04-27 10:27:32 --> Security Class Initialized
INFO - 2023-04-27 10:27:32 --> Security Class Initialized
DEBUG - 2023-04-27 10:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:27:32 --> Input Class Initialized
INFO - 2023-04-27 10:27:32 --> Input Class Initialized
INFO - 2023-04-27 10:27:32 --> Language Class Initialized
INFO - 2023-04-27 10:27:32 --> Language Class Initialized
INFO - 2023-04-27 10:27:32 --> Loader Class Initialized
INFO - 2023-04-27 10:27:32 --> Loader Class Initialized
INFO - 2023-04-27 10:27:32 --> Controller Class Initialized
INFO - 2023-04-27 10:27:32 --> Controller Class Initialized
DEBUG - 2023-04-27 10:27:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:27:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:27:32 --> Database Driver Class Initialized
INFO - 2023-04-27 10:27:32 --> Database Driver Class Initialized
INFO - 2023-04-27 10:27:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:27:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:27:32 --> Final output sent to browser
DEBUG - 2023-04-27 10:27:32 --> Total execution time: 0.1216
INFO - 2023-04-27 10:27:32 --> Final output sent to browser
DEBUG - 2023-04-27 10:27:32 --> Total execution time: 0.1216
INFO - 2023-04-27 10:27:32 --> Config Class Initialized
INFO - 2023-04-27 10:27:32 --> Hooks Class Initialized
INFO - 2023-04-27 10:27:32 --> Config Class Initialized
DEBUG - 2023-04-27 10:27:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:27:32 --> Hooks Class Initialized
INFO - 2023-04-27 10:27:32 --> Utf8 Class Initialized
INFO - 2023-04-27 10:27:32 --> URI Class Initialized
DEBUG - 2023-04-27 10:27:32 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:27:32 --> Utf8 Class Initialized
INFO - 2023-04-27 10:27:32 --> Router Class Initialized
INFO - 2023-04-27 10:27:32 --> URI Class Initialized
INFO - 2023-04-27 10:27:32 --> Output Class Initialized
INFO - 2023-04-27 10:27:32 --> Router Class Initialized
INFO - 2023-04-27 10:27:32 --> Security Class Initialized
INFO - 2023-04-27 10:27:32 --> Output Class Initialized
DEBUG - 2023-04-27 10:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:27:32 --> Security Class Initialized
INFO - 2023-04-27 10:27:32 --> Input Class Initialized
DEBUG - 2023-04-27 10:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:27:32 --> Language Class Initialized
INFO - 2023-04-27 10:27:32 --> Input Class Initialized
INFO - 2023-04-27 10:27:32 --> Language Class Initialized
INFO - 2023-04-27 10:27:32 --> Loader Class Initialized
INFO - 2023-04-27 10:27:32 --> Loader Class Initialized
INFO - 2023-04-27 10:27:32 --> Controller Class Initialized
INFO - 2023-04-27 10:27:32 --> Controller Class Initialized
DEBUG - 2023-04-27 10:27:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:27:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:27:32 --> Database Driver Class Initialized
INFO - 2023-04-27 10:27:32 --> Database Driver Class Initialized
INFO - 2023-04-27 10:27:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:27:32 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:27:32 --> Final output sent to browser
DEBUG - 2023-04-27 10:27:32 --> Total execution time: 0.0269
INFO - 2023-04-27 10:27:32 --> Final output sent to browser
DEBUG - 2023-04-27 10:27:32 --> Total execution time: 0.0357
INFO - 2023-04-27 10:27:36 --> Config Class Initialized
INFO - 2023-04-27 10:27:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:27:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:27:36 --> Utf8 Class Initialized
INFO - 2023-04-27 10:27:36 --> URI Class Initialized
INFO - 2023-04-27 10:27:36 --> Router Class Initialized
INFO - 2023-04-27 10:27:36 --> Output Class Initialized
INFO - 2023-04-27 10:27:36 --> Security Class Initialized
DEBUG - 2023-04-27 10:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:27:36 --> Input Class Initialized
INFO - 2023-04-27 10:27:36 --> Language Class Initialized
INFO - 2023-04-27 10:27:36 --> Loader Class Initialized
INFO - 2023-04-27 10:27:36 --> Controller Class Initialized
DEBUG - 2023-04-27 10:27:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:27:36 --> Database Driver Class Initialized
INFO - 2023-04-27 10:27:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:27:36 --> Final output sent to browser
DEBUG - 2023-04-27 10:27:36 --> Total execution time: 0.1196
INFO - 2023-04-27 10:27:36 --> Config Class Initialized
INFO - 2023-04-27 10:27:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:27:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:27:36 --> Utf8 Class Initialized
INFO - 2023-04-27 10:27:36 --> URI Class Initialized
INFO - 2023-04-27 10:27:36 --> Router Class Initialized
INFO - 2023-04-27 10:27:36 --> Output Class Initialized
INFO - 2023-04-27 10:27:36 --> Security Class Initialized
DEBUG - 2023-04-27 10:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:27:36 --> Input Class Initialized
INFO - 2023-04-27 10:27:36 --> Language Class Initialized
INFO - 2023-04-27 10:27:36 --> Loader Class Initialized
INFO - 2023-04-27 10:27:36 --> Controller Class Initialized
DEBUG - 2023-04-27 10:27:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:27:36 --> Database Driver Class Initialized
INFO - 2023-04-27 10:27:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:27:36 --> Final output sent to browser
DEBUG - 2023-04-27 10:27:36 --> Total execution time: 0.0686
INFO - 2023-04-27 10:27:36 --> Config Class Initialized
INFO - 2023-04-27 10:27:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:27:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:27:36 --> Utf8 Class Initialized
INFO - 2023-04-27 10:27:36 --> URI Class Initialized
INFO - 2023-04-27 10:27:36 --> Router Class Initialized
INFO - 2023-04-27 10:27:36 --> Output Class Initialized
INFO - 2023-04-27 10:27:36 --> Security Class Initialized
DEBUG - 2023-04-27 10:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:27:36 --> Input Class Initialized
INFO - 2023-04-27 10:27:36 --> Language Class Initialized
INFO - 2023-04-27 10:27:36 --> Loader Class Initialized
INFO - 2023-04-27 10:27:36 --> Controller Class Initialized
DEBUG - 2023-04-27 10:27:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:27:36 --> Database Driver Class Initialized
INFO - 2023-04-27 10:27:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:27:36 --> Final output sent to browser
DEBUG - 2023-04-27 10:27:36 --> Total execution time: 0.1371
INFO - 2023-04-27 10:27:36 --> Config Class Initialized
INFO - 2023-04-27 10:27:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:27:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:27:36 --> Utf8 Class Initialized
INFO - 2023-04-27 10:27:36 --> URI Class Initialized
INFO - 2023-04-27 10:27:36 --> Router Class Initialized
INFO - 2023-04-27 10:27:36 --> Output Class Initialized
INFO - 2023-04-27 10:27:36 --> Security Class Initialized
DEBUG - 2023-04-27 10:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:27:36 --> Input Class Initialized
INFO - 2023-04-27 10:27:36 --> Language Class Initialized
INFO - 2023-04-27 10:27:36 --> Loader Class Initialized
INFO - 2023-04-27 10:27:36 --> Controller Class Initialized
DEBUG - 2023-04-27 10:27:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:27:36 --> Database Driver Class Initialized
INFO - 2023-04-27 10:27:37 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:27:37 --> Final output sent to browser
DEBUG - 2023-04-27 10:27:37 --> Total execution time: 0.0581
INFO - 2023-04-27 10:28:34 --> Config Class Initialized
INFO - 2023-04-27 10:28:34 --> Config Class Initialized
INFO - 2023-04-27 10:28:34 --> Hooks Class Initialized
INFO - 2023-04-27 10:28:34 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:28:34 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:28:34 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:28:34 --> Utf8 Class Initialized
INFO - 2023-04-27 10:28:34 --> Utf8 Class Initialized
INFO - 2023-04-27 10:28:34 --> URI Class Initialized
INFO - 2023-04-27 10:28:34 --> URI Class Initialized
INFO - 2023-04-27 10:28:34 --> Router Class Initialized
INFO - 2023-04-27 10:28:34 --> Router Class Initialized
INFO - 2023-04-27 10:28:34 --> Output Class Initialized
INFO - 2023-04-27 10:28:34 --> Output Class Initialized
INFO - 2023-04-27 10:28:34 --> Security Class Initialized
INFO - 2023-04-27 10:28:34 --> Security Class Initialized
DEBUG - 2023-04-27 10:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:28:34 --> Input Class Initialized
INFO - 2023-04-27 10:28:34 --> Input Class Initialized
INFO - 2023-04-27 10:28:34 --> Language Class Initialized
INFO - 2023-04-27 10:28:34 --> Language Class Initialized
INFO - 2023-04-27 10:28:34 --> Loader Class Initialized
INFO - 2023-04-27 10:28:34 --> Loader Class Initialized
INFO - 2023-04-27 10:28:34 --> Controller Class Initialized
INFO - 2023-04-27 10:28:34 --> Controller Class Initialized
DEBUG - 2023-04-27 10:28:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:28:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:28:34 --> Database Driver Class Initialized
INFO - 2023-04-27 10:28:34 --> Database Driver Class Initialized
INFO - 2023-04-27 10:28:34 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:28:34 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:28:34 --> Final output sent to browser
DEBUG - 2023-04-27 10:28:34 --> Total execution time: 0.0295
INFO - 2023-04-27 10:28:34 --> Config Class Initialized
INFO - 2023-04-27 10:28:34 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:28:34 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:28:34 --> Utf8 Class Initialized
INFO - 2023-04-27 10:28:34 --> URI Class Initialized
INFO - 2023-04-27 10:28:34 --> Router Class Initialized
INFO - 2023-04-27 10:28:34 --> Output Class Initialized
INFO - 2023-04-27 10:28:34 --> Security Class Initialized
DEBUG - 2023-04-27 10:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:28:34 --> Input Class Initialized
INFO - 2023-04-27 10:28:34 --> Language Class Initialized
INFO - 2023-04-27 10:28:34 --> Loader Class Initialized
INFO - 2023-04-27 10:28:34 --> Controller Class Initialized
DEBUG - 2023-04-27 10:28:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:28:34 --> Database Driver Class Initialized
INFO - 2023-04-27 10:28:34 --> Final output sent to browser
DEBUG - 2023-04-27 10:28:34 --> Total execution time: 0.0468
INFO - 2023-04-27 10:28:34 --> Config Class Initialized
INFO - 2023-04-27 10:28:34 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:28:34 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:28:34 --> Utf8 Class Initialized
INFO - 2023-04-27 10:28:34 --> URI Class Initialized
INFO - 2023-04-27 10:28:34 --> Router Class Initialized
INFO - 2023-04-27 10:28:34 --> Output Class Initialized
INFO - 2023-04-27 10:28:34 --> Security Class Initialized
DEBUG - 2023-04-27 10:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:28:34 --> Input Class Initialized
INFO - 2023-04-27 10:28:34 --> Language Class Initialized
INFO - 2023-04-27 10:28:34 --> Loader Class Initialized
INFO - 2023-04-27 10:28:34 --> Controller Class Initialized
DEBUG - 2023-04-27 10:28:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:28:34 --> Database Driver Class Initialized
INFO - 2023-04-27 10:28:34 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:28:34 --> Final output sent to browser
DEBUG - 2023-04-27 10:28:34 --> Total execution time: 0.0436
INFO - 2023-04-27 10:28:34 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:28:34 --> Final output sent to browser
DEBUG - 2023-04-27 10:28:34 --> Total execution time: 0.0778
INFO - 2023-04-27 10:28:43 --> Config Class Initialized
INFO - 2023-04-27 10:28:43 --> Hooks Class Initialized
INFO - 2023-04-27 10:28:43 --> Config Class Initialized
DEBUG - 2023-04-27 10:28:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:28:43 --> Utf8 Class Initialized
INFO - 2023-04-27 10:28:43 --> Hooks Class Initialized
INFO - 2023-04-27 10:28:43 --> URI Class Initialized
DEBUG - 2023-04-27 10:28:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:28:43 --> Router Class Initialized
INFO - 2023-04-27 10:28:43 --> Utf8 Class Initialized
INFO - 2023-04-27 10:28:43 --> Output Class Initialized
INFO - 2023-04-27 10:28:43 --> URI Class Initialized
INFO - 2023-04-27 10:28:43 --> Security Class Initialized
INFO - 2023-04-27 10:28:43 --> Router Class Initialized
DEBUG - 2023-04-27 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:28:43 --> Output Class Initialized
INFO - 2023-04-27 10:28:43 --> Input Class Initialized
INFO - 2023-04-27 10:28:43 --> Language Class Initialized
INFO - 2023-04-27 10:28:43 --> Security Class Initialized
INFO - 2023-04-27 10:28:43 --> Loader Class Initialized
DEBUG - 2023-04-27 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:28:43 --> Controller Class Initialized
INFO - 2023-04-27 10:28:43 --> Input Class Initialized
DEBUG - 2023-04-27 10:28:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:28:43 --> Language Class Initialized
INFO - 2023-04-27 10:28:43 --> Database Driver Class Initialized
INFO - 2023-04-27 10:28:43 --> Loader Class Initialized
INFO - 2023-04-27 10:28:43 --> Controller Class Initialized
DEBUG - 2023-04-27 10:28:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:28:43 --> Database Driver Class Initialized
INFO - 2023-04-27 10:28:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:28:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:28:43 --> Final output sent to browser
DEBUG - 2023-04-27 10:28:43 --> Total execution time: 0.0811
INFO - 2023-04-27 10:28:43 --> Final output sent to browser
DEBUG - 2023-04-27 10:28:43 --> Total execution time: 0.1209
INFO - 2023-04-27 10:28:43 --> Config Class Initialized
INFO - 2023-04-27 10:28:43 --> Hooks Class Initialized
INFO - 2023-04-27 10:28:43 --> Config Class Initialized
INFO - 2023-04-27 10:28:43 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:28:43 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:28:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:28:43 --> Utf8 Class Initialized
INFO - 2023-04-27 10:28:43 --> Utf8 Class Initialized
INFO - 2023-04-27 10:28:43 --> URI Class Initialized
INFO - 2023-04-27 10:28:43 --> Router Class Initialized
INFO - 2023-04-27 10:28:43 --> Output Class Initialized
INFO - 2023-04-27 10:28:43 --> URI Class Initialized
INFO - 2023-04-27 10:28:43 --> Security Class Initialized
INFO - 2023-04-27 10:28:43 --> Router Class Initialized
DEBUG - 2023-04-27 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:28:43 --> Output Class Initialized
INFO - 2023-04-27 10:28:43 --> Input Class Initialized
INFO - 2023-04-27 10:28:43 --> Security Class Initialized
INFO - 2023-04-27 10:28:43 --> Language Class Initialized
DEBUG - 2023-04-27 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:28:43 --> Input Class Initialized
INFO - 2023-04-27 10:28:43 --> Loader Class Initialized
INFO - 2023-04-27 10:28:43 --> Language Class Initialized
INFO - 2023-04-27 10:28:43 --> Controller Class Initialized
INFO - 2023-04-27 10:28:43 --> Loader Class Initialized
DEBUG - 2023-04-27 10:28:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:28:43 --> Controller Class Initialized
DEBUG - 2023-04-27 10:28:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:28:43 --> Database Driver Class Initialized
INFO - 2023-04-27 10:28:43 --> Database Driver Class Initialized
INFO - 2023-04-27 10:28:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:28:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:28:43 --> Final output sent to browser
DEBUG - 2023-04-27 10:28:43 --> Total execution time: 0.0647
INFO - 2023-04-27 10:28:43 --> Final output sent to browser
DEBUG - 2023-04-27 10:28:43 --> Total execution time: 0.0804
INFO - 2023-04-27 10:34:33 --> Config Class Initialized
INFO - 2023-04-27 10:34:33 --> Config Class Initialized
INFO - 2023-04-27 10:34:33 --> Hooks Class Initialized
INFO - 2023-04-27 10:34:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:34:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:34:33 --> Utf8 Class Initialized
DEBUG - 2023-04-27 10:34:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:34:33 --> Utf8 Class Initialized
INFO - 2023-04-27 10:34:33 --> URI Class Initialized
INFO - 2023-04-27 10:34:33 --> URI Class Initialized
INFO - 2023-04-27 10:34:33 --> Router Class Initialized
INFO - 2023-04-27 10:34:33 --> Router Class Initialized
INFO - 2023-04-27 10:34:33 --> Output Class Initialized
INFO - 2023-04-27 10:34:33 --> Output Class Initialized
INFO - 2023-04-27 10:34:33 --> Security Class Initialized
INFO - 2023-04-27 10:34:33 --> Security Class Initialized
DEBUG - 2023-04-27 10:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:34:33 --> Input Class Initialized
INFO - 2023-04-27 10:34:33 --> Input Class Initialized
INFO - 2023-04-27 10:34:33 --> Language Class Initialized
INFO - 2023-04-27 10:34:33 --> Language Class Initialized
INFO - 2023-04-27 10:34:33 --> Loader Class Initialized
INFO - 2023-04-27 10:34:33 --> Loader Class Initialized
INFO - 2023-04-27 10:34:33 --> Controller Class Initialized
INFO - 2023-04-27 10:34:33 --> Controller Class Initialized
DEBUG - 2023-04-27 10:34:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:34:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:34:33 --> Database Driver Class Initialized
INFO - 2023-04-27 10:34:33 --> Database Driver Class Initialized
INFO - 2023-04-27 10:34:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:34:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:34:33 --> Final output sent to browser
DEBUG - 2023-04-27 10:34:33 --> Total execution time: 0.0979
INFO - 2023-04-27 10:34:33 --> Config Class Initialized
INFO - 2023-04-27 10:34:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:34:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:34:33 --> Utf8 Class Initialized
INFO - 2023-04-27 10:34:33 --> URI Class Initialized
INFO - 2023-04-27 10:34:33 --> Router Class Initialized
INFO - 2023-04-27 10:34:33 --> Output Class Initialized
INFO - 2023-04-27 10:34:33 --> Security Class Initialized
DEBUG - 2023-04-27 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:34:33 --> Input Class Initialized
INFO - 2023-04-27 10:34:33 --> Language Class Initialized
INFO - 2023-04-27 10:34:33 --> Loader Class Initialized
INFO - 2023-04-27 10:34:33 --> Controller Class Initialized
DEBUG - 2023-04-27 10:34:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:34:33 --> Database Driver Class Initialized
INFO - 2023-04-27 10:34:33 --> Final output sent to browser
DEBUG - 2023-04-27 10:34:33 --> Total execution time: 0.1433
INFO - 2023-04-27 10:34:33 --> Config Class Initialized
INFO - 2023-04-27 10:34:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:34:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:34:33 --> Utf8 Class Initialized
INFO - 2023-04-27 10:34:33 --> URI Class Initialized
INFO - 2023-04-27 10:34:33 --> Router Class Initialized
INFO - 2023-04-27 10:34:33 --> Output Class Initialized
INFO - 2023-04-27 10:34:33 --> Security Class Initialized
DEBUG - 2023-04-27 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:34:33 --> Input Class Initialized
INFO - 2023-04-27 10:34:33 --> Language Class Initialized
INFO - 2023-04-27 10:34:33 --> Loader Class Initialized
INFO - 2023-04-27 10:34:33 --> Controller Class Initialized
DEBUG - 2023-04-27 10:34:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:34:33 --> Database Driver Class Initialized
INFO - 2023-04-27 10:34:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:34:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:34:33 --> Final output sent to browser
INFO - 2023-04-27 10:34:33 --> Final output sent to browser
DEBUG - 2023-04-27 10:34:33 --> Total execution time: 0.0742
DEBUG - 2023-04-27 10:34:33 --> Total execution time: 0.0581
INFO - 2023-04-27 10:34:36 --> Config Class Initialized
INFO - 2023-04-27 10:34:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:34:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:34:36 --> Utf8 Class Initialized
INFO - 2023-04-27 10:34:36 --> URI Class Initialized
INFO - 2023-04-27 10:34:36 --> Router Class Initialized
INFO - 2023-04-27 10:34:36 --> Output Class Initialized
INFO - 2023-04-27 10:34:36 --> Security Class Initialized
DEBUG - 2023-04-27 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:34:36 --> Input Class Initialized
INFO - 2023-04-27 10:34:36 --> Language Class Initialized
INFO - 2023-04-27 10:34:36 --> Loader Class Initialized
INFO - 2023-04-27 10:34:36 --> Controller Class Initialized
DEBUG - 2023-04-27 10:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:34:36 --> Database Driver Class Initialized
INFO - 2023-04-27 10:34:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:34:36 --> Final output sent to browser
DEBUG - 2023-04-27 10:34:36 --> Total execution time: 0.0315
INFO - 2023-04-27 10:34:36 --> Config Class Initialized
INFO - 2023-04-27 10:34:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:34:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:34:36 --> Utf8 Class Initialized
INFO - 2023-04-27 10:34:36 --> URI Class Initialized
INFO - 2023-04-27 10:34:36 --> Router Class Initialized
INFO - 2023-04-27 10:34:36 --> Output Class Initialized
INFO - 2023-04-27 10:34:36 --> Security Class Initialized
DEBUG - 2023-04-27 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:34:36 --> Input Class Initialized
INFO - 2023-04-27 10:34:36 --> Language Class Initialized
INFO - 2023-04-27 10:34:36 --> Loader Class Initialized
INFO - 2023-04-27 10:34:36 --> Controller Class Initialized
DEBUG - 2023-04-27 10:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:34:36 --> Database Driver Class Initialized
INFO - 2023-04-27 10:34:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:34:36 --> Final output sent to browser
DEBUG - 2023-04-27 10:34:36 --> Total execution time: 0.1024
INFO - 2023-04-27 10:34:36 --> Config Class Initialized
INFO - 2023-04-27 10:34:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:34:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:34:36 --> Utf8 Class Initialized
INFO - 2023-04-27 10:34:36 --> URI Class Initialized
INFO - 2023-04-27 10:34:36 --> Router Class Initialized
INFO - 2023-04-27 10:34:36 --> Output Class Initialized
INFO - 2023-04-27 10:34:36 --> Security Class Initialized
DEBUG - 2023-04-27 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:34:36 --> Input Class Initialized
INFO - 2023-04-27 10:34:36 --> Language Class Initialized
INFO - 2023-04-27 10:34:36 --> Loader Class Initialized
INFO - 2023-04-27 10:34:36 --> Controller Class Initialized
DEBUG - 2023-04-27 10:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:34:36 --> Database Driver Class Initialized
INFO - 2023-04-27 10:34:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:34:36 --> Final output sent to browser
DEBUG - 2023-04-27 10:34:36 --> Total execution time: 0.0845
INFO - 2023-04-27 10:34:36 --> Config Class Initialized
INFO - 2023-04-27 10:34:36 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:34:36 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:34:36 --> Utf8 Class Initialized
INFO - 2023-04-27 10:34:36 --> URI Class Initialized
INFO - 2023-04-27 10:34:36 --> Router Class Initialized
INFO - 2023-04-27 10:34:36 --> Output Class Initialized
INFO - 2023-04-27 10:34:36 --> Security Class Initialized
DEBUG - 2023-04-27 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:34:36 --> Input Class Initialized
INFO - 2023-04-27 10:34:36 --> Language Class Initialized
INFO - 2023-04-27 10:34:36 --> Loader Class Initialized
INFO - 2023-04-27 10:34:36 --> Controller Class Initialized
DEBUG - 2023-04-27 10:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:34:36 --> Database Driver Class Initialized
INFO - 2023-04-27 10:34:36 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:34:36 --> Final output sent to browser
DEBUG - 2023-04-27 10:34:36 --> Total execution time: 0.0170
INFO - 2023-04-27 10:35:17 --> Config Class Initialized
INFO - 2023-04-27 10:35:17 --> Config Class Initialized
INFO - 2023-04-27 10:35:17 --> Hooks Class Initialized
INFO - 2023-04-27 10:35:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:35:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:35:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:17 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:17 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:17 --> URI Class Initialized
INFO - 2023-04-27 10:35:17 --> URI Class Initialized
INFO - 2023-04-27 10:35:17 --> Router Class Initialized
INFO - 2023-04-27 10:35:17 --> Router Class Initialized
INFO - 2023-04-27 10:35:17 --> Output Class Initialized
INFO - 2023-04-27 10:35:17 --> Output Class Initialized
INFO - 2023-04-27 10:35:17 --> Security Class Initialized
INFO - 2023-04-27 10:35:17 --> Security Class Initialized
DEBUG - 2023-04-27 10:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:17 --> Input Class Initialized
INFO - 2023-04-27 10:35:17 --> Input Class Initialized
INFO - 2023-04-27 10:35:17 --> Language Class Initialized
INFO - 2023-04-27 10:35:17 --> Language Class Initialized
INFO - 2023-04-27 10:35:17 --> Loader Class Initialized
INFO - 2023-04-27 10:35:17 --> Loader Class Initialized
INFO - 2023-04-27 10:35:17 --> Controller Class Initialized
INFO - 2023-04-27 10:35:17 --> Controller Class Initialized
DEBUG - 2023-04-27 10:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:17 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:17 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:17 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:17 --> Total execution time: 0.0297
INFO - 2023-04-27 10:35:17 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:17 --> Total execution time: 0.0341
INFO - 2023-04-27 10:35:17 --> Config Class Initialized
INFO - 2023-04-27 10:35:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:35:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:17 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:17 --> URI Class Initialized
INFO - 2023-04-27 10:35:17 --> Router Class Initialized
INFO - 2023-04-27 10:35:17 --> Output Class Initialized
INFO - 2023-04-27 10:35:17 --> Security Class Initialized
INFO - 2023-04-27 10:35:17 --> Config Class Initialized
DEBUG - 2023-04-27 10:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:17 --> Hooks Class Initialized
INFO - 2023-04-27 10:35:17 --> Input Class Initialized
INFO - 2023-04-27 10:35:17 --> Language Class Initialized
DEBUG - 2023-04-27 10:35:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:17 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:17 --> Loader Class Initialized
INFO - 2023-04-27 10:35:17 --> URI Class Initialized
INFO - 2023-04-27 10:35:17 --> Controller Class Initialized
INFO - 2023-04-27 10:35:17 --> Router Class Initialized
DEBUG - 2023-04-27 10:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:17 --> Output Class Initialized
INFO - 2023-04-27 10:35:17 --> Security Class Initialized
DEBUG - 2023-04-27 10:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:17 --> Input Class Initialized
INFO - 2023-04-27 10:35:17 --> Language Class Initialized
INFO - 2023-04-27 10:35:17 --> Loader Class Initialized
INFO - 2023-04-27 10:35:17 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:17 --> Controller Class Initialized
DEBUG - 2023-04-27 10:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:17 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:17 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:17 --> Total execution time: 0.0400
INFO - 2023-04-27 10:35:17 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:17 --> Total execution time: 0.0386
INFO - 2023-04-27 10:35:48 --> Config Class Initialized
INFO - 2023-04-27 10:35:48 --> Config Class Initialized
INFO - 2023-04-27 10:35:48 --> Hooks Class Initialized
INFO - 2023-04-27 10:35:48 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:35:48 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:48 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:48 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:48 --> URI Class Initialized
INFO - 2023-04-27 10:35:48 --> URI Class Initialized
INFO - 2023-04-27 10:35:48 --> Router Class Initialized
INFO - 2023-04-27 10:35:48 --> Router Class Initialized
INFO - 2023-04-27 10:35:48 --> Output Class Initialized
INFO - 2023-04-27 10:35:48 --> Output Class Initialized
INFO - 2023-04-27 10:35:48 --> Security Class Initialized
INFO - 2023-04-27 10:35:48 --> Security Class Initialized
DEBUG - 2023-04-27 10:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:48 --> Input Class Initialized
INFO - 2023-04-27 10:35:48 --> Input Class Initialized
INFO - 2023-04-27 10:35:48 --> Language Class Initialized
INFO - 2023-04-27 10:35:48 --> Language Class Initialized
INFO - 2023-04-27 10:35:48 --> Loader Class Initialized
INFO - 2023-04-27 10:35:48 --> Loader Class Initialized
INFO - 2023-04-27 10:35:48 --> Controller Class Initialized
INFO - 2023-04-27 10:35:48 --> Controller Class Initialized
DEBUG - 2023-04-27 10:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:35:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:48 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:48 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:48 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:48 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:48 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:49 --> Total execution time: 0.0852
INFO - 2023-04-27 10:35:49 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:49 --> Total execution time: 0.1310
INFO - 2023-04-27 10:35:49 --> Config Class Initialized
INFO - 2023-04-27 10:35:49 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:49 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:49 --> URI Class Initialized
INFO - 2023-04-27 10:35:49 --> Config Class Initialized
INFO - 2023-04-27 10:35:49 --> Hooks Class Initialized
INFO - 2023-04-27 10:35:49 --> Router Class Initialized
DEBUG - 2023-04-27 10:35:49 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:49 --> Output Class Initialized
INFO - 2023-04-27 10:35:49 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:49 --> Security Class Initialized
INFO - 2023-04-27 10:35:49 --> URI Class Initialized
INFO - 2023-04-27 10:35:49 --> Router Class Initialized
DEBUG - 2023-04-27 10:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:49 --> Output Class Initialized
INFO - 2023-04-27 10:35:49 --> Input Class Initialized
INFO - 2023-04-27 10:35:49 --> Security Class Initialized
INFO - 2023-04-27 10:35:49 --> Language Class Initialized
DEBUG - 2023-04-27 10:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:49 --> Input Class Initialized
INFO - 2023-04-27 10:35:49 --> Loader Class Initialized
INFO - 2023-04-27 10:35:49 --> Language Class Initialized
INFO - 2023-04-27 10:35:49 --> Controller Class Initialized
INFO - 2023-04-27 10:35:49 --> Loader Class Initialized
DEBUG - 2023-04-27 10:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:49 --> Controller Class Initialized
DEBUG - 2023-04-27 10:35:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:49 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:49 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:49 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:49 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:49 --> Total execution time: 0.0300
INFO - 2023-04-27 10:35:49 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:49 --> Total execution time: 0.0277
INFO - 2023-04-27 10:35:51 --> Config Class Initialized
INFO - 2023-04-27 10:35:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:35:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:51 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:51 --> URI Class Initialized
INFO - 2023-04-27 10:35:51 --> Router Class Initialized
INFO - 2023-04-27 10:35:51 --> Output Class Initialized
INFO - 2023-04-27 10:35:51 --> Security Class Initialized
DEBUG - 2023-04-27 10:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:51 --> Input Class Initialized
INFO - 2023-04-27 10:35:51 --> Language Class Initialized
INFO - 2023-04-27 10:35:51 --> Loader Class Initialized
INFO - 2023-04-27 10:35:51 --> Controller Class Initialized
DEBUG - 2023-04-27 10:35:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:51 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:51 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:51 --> Total execution time: 0.0178
INFO - 2023-04-27 10:35:51 --> Config Class Initialized
INFO - 2023-04-27 10:35:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:35:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:51 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:51 --> URI Class Initialized
INFO - 2023-04-27 10:35:51 --> Router Class Initialized
INFO - 2023-04-27 10:35:51 --> Output Class Initialized
INFO - 2023-04-27 10:35:51 --> Security Class Initialized
DEBUG - 2023-04-27 10:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:51 --> Input Class Initialized
INFO - 2023-04-27 10:35:51 --> Language Class Initialized
INFO - 2023-04-27 10:35:51 --> Loader Class Initialized
INFO - 2023-04-27 10:35:51 --> Controller Class Initialized
DEBUG - 2023-04-27 10:35:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:51 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:51 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:51 --> Total execution time: 0.0153
INFO - 2023-04-27 10:35:51 --> Config Class Initialized
INFO - 2023-04-27 10:35:52 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:35:52 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:52 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:52 --> URI Class Initialized
INFO - 2023-04-27 10:35:52 --> Router Class Initialized
INFO - 2023-04-27 10:35:52 --> Output Class Initialized
INFO - 2023-04-27 10:35:52 --> Security Class Initialized
DEBUG - 2023-04-27 10:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:52 --> Input Class Initialized
INFO - 2023-04-27 10:35:52 --> Language Class Initialized
INFO - 2023-04-27 10:35:52 --> Loader Class Initialized
INFO - 2023-04-27 10:35:52 --> Controller Class Initialized
DEBUG - 2023-04-27 10:35:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:52 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:52 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:52 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:52 --> Total execution time: 0.0512
INFO - 2023-04-27 10:35:52 --> Config Class Initialized
INFO - 2023-04-27 10:35:52 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:35:52 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:35:52 --> Utf8 Class Initialized
INFO - 2023-04-27 10:35:52 --> URI Class Initialized
INFO - 2023-04-27 10:35:52 --> Router Class Initialized
INFO - 2023-04-27 10:35:52 --> Output Class Initialized
INFO - 2023-04-27 10:35:52 --> Security Class Initialized
DEBUG - 2023-04-27 10:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:35:52 --> Input Class Initialized
INFO - 2023-04-27 10:35:52 --> Language Class Initialized
INFO - 2023-04-27 10:35:52 --> Loader Class Initialized
INFO - 2023-04-27 10:35:52 --> Controller Class Initialized
DEBUG - 2023-04-27 10:35:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:35:52 --> Database Driver Class Initialized
INFO - 2023-04-27 10:35:52 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:35:52 --> Final output sent to browser
DEBUG - 2023-04-27 10:35:52 --> Total execution time: 0.0179
INFO - 2023-04-27 10:36:33 --> Config Class Initialized
INFO - 2023-04-27 10:36:33 --> Config Class Initialized
INFO - 2023-04-27 10:36:33 --> Hooks Class Initialized
INFO - 2023-04-27 10:36:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:36:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:33 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:33 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:33 --> URI Class Initialized
INFO - 2023-04-27 10:36:33 --> URI Class Initialized
INFO - 2023-04-27 10:36:33 --> Router Class Initialized
INFO - 2023-04-27 10:36:33 --> Output Class Initialized
INFO - 2023-04-27 10:36:33 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:33 --> Input Class Initialized
INFO - 2023-04-27 10:36:33 --> Language Class Initialized
INFO - 2023-04-27 10:36:33 --> Router Class Initialized
INFO - 2023-04-27 10:36:33 --> Loader Class Initialized
INFO - 2023-04-27 10:36:33 --> Output Class Initialized
INFO - 2023-04-27 10:36:33 --> Controller Class Initialized
INFO - 2023-04-27 10:36:33 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:33 --> Input Class Initialized
INFO - 2023-04-27 10:36:33 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:33 --> Language Class Initialized
INFO - 2023-04-27 10:36:33 --> Loader Class Initialized
INFO - 2023-04-27 10:36:33 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:33 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:33 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:33 --> Total execution time: 0.1972
INFO - 2023-04-27 10:36:33 --> Config Class Initialized
INFO - 2023-04-27 10:36:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:33 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:33 --> URI Class Initialized
INFO - 2023-04-27 10:36:33 --> Router Class Initialized
INFO - 2023-04-27 10:36:33 --> Output Class Initialized
INFO - 2023-04-27 10:36:33 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:33 --> Input Class Initialized
INFO - 2023-04-27 10:36:33 --> Language Class Initialized
INFO - 2023-04-27 10:36:33 --> Loader Class Initialized
INFO - 2023-04-27 10:36:33 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:33 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:33 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:33 --> Total execution time: 0.2385
INFO - 2023-04-27 10:36:33 --> Config Class Initialized
INFO - 2023-04-27 10:36:33 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:33 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:33 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:33 --> URI Class Initialized
INFO - 2023-04-27 10:36:33 --> Router Class Initialized
INFO - 2023-04-27 10:36:33 --> Output Class Initialized
INFO - 2023-04-27 10:36:33 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:33 --> Input Class Initialized
INFO - 2023-04-27 10:36:33 --> Language Class Initialized
INFO - 2023-04-27 10:36:33 --> Loader Class Initialized
INFO - 2023-04-27 10:36:33 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:33 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:33 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:33 --> Total execution time: 0.0209
INFO - 2023-04-27 10:36:33 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:33 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:33 --> Total execution time: 0.0598
INFO - 2023-04-27 10:36:43 --> Config Class Initialized
INFO - 2023-04-27 10:36:43 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:43 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:43 --> URI Class Initialized
INFO - 2023-04-27 10:36:43 --> Router Class Initialized
INFO - 2023-04-27 10:36:43 --> Output Class Initialized
INFO - 2023-04-27 10:36:43 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:43 --> Input Class Initialized
INFO - 2023-04-27 10:36:43 --> Language Class Initialized
INFO - 2023-04-27 10:36:43 --> Loader Class Initialized
INFO - 2023-04-27 10:36:43 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:43 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:43 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:43 --> Total execution time: 0.1717
INFO - 2023-04-27 10:36:43 --> Config Class Initialized
INFO - 2023-04-27 10:36:43 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:43 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:43 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:43 --> URI Class Initialized
INFO - 2023-04-27 10:36:43 --> Router Class Initialized
INFO - 2023-04-27 10:36:43 --> Output Class Initialized
INFO - 2023-04-27 10:36:43 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:43 --> Input Class Initialized
INFO - 2023-04-27 10:36:43 --> Language Class Initialized
INFO - 2023-04-27 10:36:43 --> Loader Class Initialized
INFO - 2023-04-27 10:36:43 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:43 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:43 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:43 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:43 --> Model "Login_model" initialized
INFO - 2023-04-27 10:36:43 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:43 --> Total execution time: 0.0286
INFO - 2023-04-27 10:36:44 --> Config Class Initialized
INFO - 2023-04-27 10:36:44 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:44 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:44 --> URI Class Initialized
INFO - 2023-04-27 10:36:44 --> Router Class Initialized
INFO - 2023-04-27 10:36:44 --> Output Class Initialized
INFO - 2023-04-27 10:36:44 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:44 --> Input Class Initialized
INFO - 2023-04-27 10:36:44 --> Language Class Initialized
INFO - 2023-04-27 10:36:44 --> Loader Class Initialized
INFO - 2023-04-27 10:36:44 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:44 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:44 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:44 --> Total execution time: 0.0309
INFO - 2023-04-27 10:36:44 --> Config Class Initialized
INFO - 2023-04-27 10:36:44 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:44 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:44 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:44 --> URI Class Initialized
INFO - 2023-04-27 10:36:44 --> Router Class Initialized
INFO - 2023-04-27 10:36:44 --> Output Class Initialized
INFO - 2023-04-27 10:36:44 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:44 --> Input Class Initialized
INFO - 2023-04-27 10:36:44 --> Language Class Initialized
INFO - 2023-04-27 10:36:44 --> Loader Class Initialized
INFO - 2023-04-27 10:36:44 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:44 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:44 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:44 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:44 --> Total execution time: 0.0693
INFO - 2023-04-27 10:36:46 --> Config Class Initialized
INFO - 2023-04-27 10:36:46 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:46 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:46 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:46 --> URI Class Initialized
INFO - 2023-04-27 10:36:46 --> Router Class Initialized
INFO - 2023-04-27 10:36:46 --> Output Class Initialized
INFO - 2023-04-27 10:36:46 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:46 --> Input Class Initialized
INFO - 2023-04-27 10:36:46 --> Language Class Initialized
INFO - 2023-04-27 10:36:46 --> Loader Class Initialized
INFO - 2023-04-27 10:36:46 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:46 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:46 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:46 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:46 --> Model "Login_model" initialized
INFO - 2023-04-27 10:36:46 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:46 --> Total execution time: 0.0343
INFO - 2023-04-27 10:36:47 --> Config Class Initialized
INFO - 2023-04-27 10:36:47 --> Config Class Initialized
INFO - 2023-04-27 10:36:47 --> Hooks Class Initialized
INFO - 2023-04-27 10:36:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:47 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:36:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:47 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:47 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:47 --> URI Class Initialized
INFO - 2023-04-27 10:36:47 --> URI Class Initialized
INFO - 2023-04-27 10:36:47 --> Router Class Initialized
INFO - 2023-04-27 10:36:47 --> Router Class Initialized
INFO - 2023-04-27 10:36:47 --> Output Class Initialized
INFO - 2023-04-27 10:36:47 --> Output Class Initialized
INFO - 2023-04-27 10:36:47 --> Security Class Initialized
INFO - 2023-04-27 10:36:47 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:47 --> Input Class Initialized
INFO - 2023-04-27 10:36:47 --> Input Class Initialized
INFO - 2023-04-27 10:36:47 --> Language Class Initialized
INFO - 2023-04-27 10:36:47 --> Language Class Initialized
INFO - 2023-04-27 10:36:47 --> Loader Class Initialized
INFO - 2023-04-27 10:36:47 --> Loader Class Initialized
INFO - 2023-04-27 10:36:47 --> Controller Class Initialized
INFO - 2023-04-27 10:36:47 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:36:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:47 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:47 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:47 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:47 --> Total execution time: 0.0181
INFO - 2023-04-27 10:36:47 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:47 --> Total execution time: 0.0195
INFO - 2023-04-27 10:36:47 --> Config Class Initialized
INFO - 2023-04-27 10:36:47 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:47 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:47 --> URI Class Initialized
INFO - 2023-04-27 10:36:47 --> Config Class Initialized
INFO - 2023-04-27 10:36:47 --> Router Class Initialized
INFO - 2023-04-27 10:36:47 --> Hooks Class Initialized
INFO - 2023-04-27 10:36:47 --> Output Class Initialized
DEBUG - 2023-04-27 10:36:47 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:47 --> Security Class Initialized
INFO - 2023-04-27 10:36:47 --> Utf8 Class Initialized
DEBUG - 2023-04-27 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:47 --> URI Class Initialized
INFO - 2023-04-27 10:36:47 --> Input Class Initialized
INFO - 2023-04-27 10:36:47 --> Router Class Initialized
INFO - 2023-04-27 10:36:47 --> Language Class Initialized
INFO - 2023-04-27 10:36:47 --> Output Class Initialized
INFO - 2023-04-27 10:36:47 --> Loader Class Initialized
INFO - 2023-04-27 10:36:47 --> Security Class Initialized
INFO - 2023-04-27 10:36:47 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:36:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:47 --> Input Class Initialized
INFO - 2023-04-27 10:36:47 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:47 --> Language Class Initialized
INFO - 2023-04-27 10:36:47 --> Loader Class Initialized
INFO - 2023-04-27 10:36:47 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:47 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:47 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:47 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:47 --> Total execution time: 0.0206
INFO - 2023-04-27 10:36:47 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:47 --> Total execution time: 0.0220
INFO - 2023-04-27 10:36:51 --> Config Class Initialized
INFO - 2023-04-27 10:36:51 --> Config Class Initialized
INFO - 2023-04-27 10:36:51 --> Hooks Class Initialized
INFO - 2023-04-27 10:36:51 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:36:51 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:51 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:51 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:51 --> URI Class Initialized
INFO - 2023-04-27 10:36:51 --> URI Class Initialized
INFO - 2023-04-27 10:36:51 --> Router Class Initialized
INFO - 2023-04-27 10:36:51 --> Router Class Initialized
INFO - 2023-04-27 10:36:51 --> Output Class Initialized
INFO - 2023-04-27 10:36:51 --> Output Class Initialized
INFO - 2023-04-27 10:36:51 --> Security Class Initialized
INFO - 2023-04-27 10:36:51 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:51 --> Input Class Initialized
DEBUG - 2023-04-27 10:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:51 --> Language Class Initialized
INFO - 2023-04-27 10:36:51 --> Input Class Initialized
INFO - 2023-04-27 10:36:51 --> Loader Class Initialized
INFO - 2023-04-27 10:36:51 --> Language Class Initialized
INFO - 2023-04-27 10:36:51 --> Controller Class Initialized
INFO - 2023-04-27 10:36:51 --> Loader Class Initialized
DEBUG - 2023-04-27 10:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:51 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:51 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:51 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:51 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:51 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:51 --> Total execution time: 0.0280
INFO - 2023-04-27 10:36:51 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:51 --> Total execution time: 0.0346
INFO - 2023-04-27 10:36:56 --> Config Class Initialized
INFO - 2023-04-27 10:36:56 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:56 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:56 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:56 --> URI Class Initialized
INFO - 2023-04-27 10:36:56 --> Router Class Initialized
INFO - 2023-04-27 10:36:56 --> Output Class Initialized
INFO - 2023-04-27 10:36:56 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:56 --> Input Class Initialized
INFO - 2023-04-27 10:36:56 --> Language Class Initialized
INFO - 2023-04-27 10:36:56 --> Loader Class Initialized
INFO - 2023-04-27 10:36:56 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:56 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:56 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:56 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:56 --> Total execution time: 0.0338
INFO - 2023-04-27 10:36:56 --> Config Class Initialized
INFO - 2023-04-27 10:36:56 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:56 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:56 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:56 --> URI Class Initialized
INFO - 2023-04-27 10:36:56 --> Router Class Initialized
INFO - 2023-04-27 10:36:56 --> Output Class Initialized
INFO - 2023-04-27 10:36:56 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:56 --> Input Class Initialized
INFO - 2023-04-27 10:36:56 --> Language Class Initialized
INFO - 2023-04-27 10:36:56 --> Loader Class Initialized
INFO - 2023-04-27 10:36:56 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:56 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:56 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:56 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:56 --> Total execution time: 0.0146
INFO - 2023-04-27 10:36:58 --> Config Class Initialized
INFO - 2023-04-27 10:36:58 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:58 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:58 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:58 --> URI Class Initialized
INFO - 2023-04-27 10:36:58 --> Router Class Initialized
INFO - 2023-04-27 10:36:58 --> Output Class Initialized
INFO - 2023-04-27 10:36:58 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:58 --> Input Class Initialized
INFO - 2023-04-27 10:36:58 --> Language Class Initialized
INFO - 2023-04-27 10:36:58 --> Loader Class Initialized
INFO - 2023-04-27 10:36:58 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:58 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:58 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:58 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:58 --> Total execution time: 0.0288
INFO - 2023-04-27 10:36:58 --> Config Class Initialized
INFO - 2023-04-27 10:36:58 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:36:58 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:36:58 --> Utf8 Class Initialized
INFO - 2023-04-27 10:36:58 --> URI Class Initialized
INFO - 2023-04-27 10:36:58 --> Router Class Initialized
INFO - 2023-04-27 10:36:58 --> Output Class Initialized
INFO - 2023-04-27 10:36:58 --> Security Class Initialized
DEBUG - 2023-04-27 10:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:36:58 --> Input Class Initialized
INFO - 2023-04-27 10:36:58 --> Language Class Initialized
INFO - 2023-04-27 10:36:58 --> Loader Class Initialized
INFO - 2023-04-27 10:36:58 --> Controller Class Initialized
DEBUG - 2023-04-27 10:36:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:36:58 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:58 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:36:58 --> Database Driver Class Initialized
INFO - 2023-04-27 10:36:58 --> Model "Login_model" initialized
INFO - 2023-04-27 10:36:58 --> Final output sent to browser
DEBUG - 2023-04-27 10:36:58 --> Total execution time: 0.0201
INFO - 2023-04-27 10:37:00 --> Config Class Initialized
INFO - 2023-04-27 10:37:00 --> Config Class Initialized
INFO - 2023-04-27 10:37:00 --> Hooks Class Initialized
INFO - 2023-04-27 10:37:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:00 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:37:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:00 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:00 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:00 --> URI Class Initialized
INFO - 2023-04-27 10:37:00 --> URI Class Initialized
INFO - 2023-04-27 10:37:00 --> Router Class Initialized
INFO - 2023-04-27 10:37:00 --> Router Class Initialized
INFO - 2023-04-27 10:37:00 --> Output Class Initialized
INFO - 2023-04-27 10:37:00 --> Output Class Initialized
INFO - 2023-04-27 10:37:00 --> Security Class Initialized
INFO - 2023-04-27 10:37:00 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:00 --> Input Class Initialized
INFO - 2023-04-27 10:37:00 --> Input Class Initialized
INFO - 2023-04-27 10:37:00 --> Language Class Initialized
INFO - 2023-04-27 10:37:00 --> Loader Class Initialized
INFO - 2023-04-27 10:37:00 --> Language Class Initialized
INFO - 2023-04-27 10:37:00 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:00 --> Loader Class Initialized
INFO - 2023-04-27 10:37:00 --> Controller Class Initialized
INFO - 2023-04-27 10:37:00 --> Database Driver Class Initialized
DEBUG - 2023-04-27 10:37:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:00 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:00 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:00 --> Total execution time: 0.0294
INFO - 2023-04-27 10:37:00 --> Final output sent to browser
INFO - 2023-04-27 10:37:00 --> Config Class Initialized
DEBUG - 2023-04-27 10:37:00 --> Total execution time: 0.0321
INFO - 2023-04-27 10:37:00 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:00 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:00 --> URI Class Initialized
INFO - 2023-04-27 10:37:00 --> Router Class Initialized
INFO - 2023-04-27 10:37:00 --> Output Class Initialized
INFO - 2023-04-27 10:37:00 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:00 --> Input Class Initialized
INFO - 2023-04-27 10:37:00 --> Config Class Initialized
INFO - 2023-04-27 10:37:00 --> Language Class Initialized
INFO - 2023-04-27 10:37:00 --> Hooks Class Initialized
INFO - 2023-04-27 10:37:00 --> Loader Class Initialized
DEBUG - 2023-04-27 10:37:00 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:00 --> Controller Class Initialized
INFO - 2023-04-27 10:37:00 --> Utf8 Class Initialized
DEBUG - 2023-04-27 10:37:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:00 --> URI Class Initialized
INFO - 2023-04-27 10:37:00 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:00 --> Router Class Initialized
INFO - 2023-04-27 10:37:00 --> Output Class Initialized
INFO - 2023-04-27 10:37:00 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:00 --> Input Class Initialized
INFO - 2023-04-27 10:37:00 --> Language Class Initialized
INFO - 2023-04-27 10:37:00 --> Loader Class Initialized
INFO - 2023-04-27 10:37:00 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:00 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:00 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:00 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:00 --> Total execution time: 0.0293
INFO - 2023-04-27 10:37:00 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:00 --> Total execution time: 0.0297
INFO - 2023-04-27 10:37:03 --> Config Class Initialized
INFO - 2023-04-27 10:37:03 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:03 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:03 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:03 --> URI Class Initialized
INFO - 2023-04-27 10:37:03 --> Router Class Initialized
INFO - 2023-04-27 10:37:03 --> Output Class Initialized
INFO - 2023-04-27 10:37:03 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:03 --> Input Class Initialized
INFO - 2023-04-27 10:37:03 --> Language Class Initialized
INFO - 2023-04-27 10:37:03 --> Loader Class Initialized
INFO - 2023-04-27 10:37:03 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:03 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:03 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:03 --> Total execution time: 0.0308
INFO - 2023-04-27 10:37:03 --> Config Class Initialized
INFO - 2023-04-27 10:37:03 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:03 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:03 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:03 --> URI Class Initialized
INFO - 2023-04-27 10:37:03 --> Router Class Initialized
INFO - 2023-04-27 10:37:03 --> Output Class Initialized
INFO - 2023-04-27 10:37:03 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:03 --> Input Class Initialized
INFO - 2023-04-27 10:37:03 --> Language Class Initialized
INFO - 2023-04-27 10:37:03 --> Loader Class Initialized
INFO - 2023-04-27 10:37:03 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:03 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:03 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:03 --> Total execution time: 0.0375
INFO - 2023-04-27 10:37:03 --> Config Class Initialized
INFO - 2023-04-27 10:37:03 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:03 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:03 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:03 --> URI Class Initialized
INFO - 2023-04-27 10:37:03 --> Router Class Initialized
INFO - 2023-04-27 10:37:03 --> Output Class Initialized
INFO - 2023-04-27 10:37:03 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:03 --> Input Class Initialized
INFO - 2023-04-27 10:37:03 --> Language Class Initialized
INFO - 2023-04-27 10:37:03 --> Loader Class Initialized
INFO - 2023-04-27 10:37:03 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:03 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:03 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:03 --> Total execution time: 0.0762
INFO - 2023-04-27 10:37:03 --> Config Class Initialized
INFO - 2023-04-27 10:37:03 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:03 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:03 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:03 --> URI Class Initialized
INFO - 2023-04-27 10:37:03 --> Router Class Initialized
INFO - 2023-04-27 10:37:03 --> Output Class Initialized
INFO - 2023-04-27 10:37:03 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:03 --> Input Class Initialized
INFO - 2023-04-27 10:37:03 --> Language Class Initialized
INFO - 2023-04-27 10:37:03 --> Loader Class Initialized
INFO - 2023-04-27 10:37:03 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:03 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:03 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:03 --> Total execution time: 0.0268
INFO - 2023-04-27 10:37:50 --> Config Class Initialized
INFO - 2023-04-27 10:37:50 --> Config Class Initialized
INFO - 2023-04-27 10:37:50 --> Hooks Class Initialized
INFO - 2023-04-27 10:37:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:37:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:50 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:50 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:50 --> URI Class Initialized
INFO - 2023-04-27 10:37:50 --> URI Class Initialized
INFO - 2023-04-27 10:37:50 --> Router Class Initialized
INFO - 2023-04-27 10:37:50 --> Router Class Initialized
INFO - 2023-04-27 10:37:50 --> Output Class Initialized
INFO - 2023-04-27 10:37:50 --> Output Class Initialized
INFO - 2023-04-27 10:37:50 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:50 --> Security Class Initialized
INFO - 2023-04-27 10:37:50 --> Input Class Initialized
DEBUG - 2023-04-27 10:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:50 --> Language Class Initialized
INFO - 2023-04-27 10:37:50 --> Input Class Initialized
INFO - 2023-04-27 10:37:50 --> Language Class Initialized
INFO - 2023-04-27 10:37:50 --> Loader Class Initialized
INFO - 2023-04-27 10:37:50 --> Loader Class Initialized
INFO - 2023-04-27 10:37:50 --> Controller Class Initialized
INFO - 2023-04-27 10:37:50 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:37:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:50 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:50 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:50 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:50 --> Total execution time: 0.1497
INFO - 2023-04-27 10:37:50 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:50 --> Total execution time: 0.1528
INFO - 2023-04-27 10:37:50 --> Config Class Initialized
INFO - 2023-04-27 10:37:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:50 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:50 --> URI Class Initialized
INFO - 2023-04-27 10:37:50 --> Router Class Initialized
INFO - 2023-04-27 10:37:50 --> Output Class Initialized
INFO - 2023-04-27 10:37:50 --> Config Class Initialized
INFO - 2023-04-27 10:37:50 --> Security Class Initialized
INFO - 2023-04-27 10:37:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:37:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:50 --> Input Class Initialized
INFO - 2023-04-27 10:37:50 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:50 --> Language Class Initialized
INFO - 2023-04-27 10:37:50 --> URI Class Initialized
INFO - 2023-04-27 10:37:50 --> Router Class Initialized
INFO - 2023-04-27 10:37:50 --> Loader Class Initialized
INFO - 2023-04-27 10:37:50 --> Output Class Initialized
INFO - 2023-04-27 10:37:50 --> Security Class Initialized
INFO - 2023-04-27 10:37:50 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:50 --> Input Class Initialized
INFO - 2023-04-27 10:37:50 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:50 --> Language Class Initialized
INFO - 2023-04-27 10:37:50 --> Loader Class Initialized
INFO - 2023-04-27 10:37:50 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:50 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:50 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:50 --> Total execution time: 0.0198
INFO - 2023-04-27 10:37:50 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:50 --> Total execution time: 0.0238
INFO - 2023-04-27 10:37:57 --> Config Class Initialized
INFO - 2023-04-27 10:37:57 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:57 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:57 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:57 --> URI Class Initialized
INFO - 2023-04-27 10:37:57 --> Router Class Initialized
INFO - 2023-04-27 10:37:57 --> Output Class Initialized
INFO - 2023-04-27 10:37:57 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:57 --> Input Class Initialized
INFO - 2023-04-27 10:37:57 --> Language Class Initialized
INFO - 2023-04-27 10:37:57 --> Loader Class Initialized
INFO - 2023-04-27 10:37:57 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:57 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:57 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:57 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:57 --> Total execution time: 0.0177
INFO - 2023-04-27 10:37:57 --> Config Class Initialized
INFO - 2023-04-27 10:37:57 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:57 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:57 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:57 --> URI Class Initialized
INFO - 2023-04-27 10:37:57 --> Router Class Initialized
INFO - 2023-04-27 10:37:57 --> Output Class Initialized
INFO - 2023-04-27 10:37:57 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:57 --> Input Class Initialized
INFO - 2023-04-27 10:37:57 --> Language Class Initialized
INFO - 2023-04-27 10:37:57 --> Loader Class Initialized
INFO - 2023-04-27 10:37:57 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:57 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:57 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:57 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:57 --> Model "Login_model" initialized
INFO - 2023-04-27 10:37:57 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:57 --> Total execution time: 0.0686
INFO - 2023-04-27 10:37:58 --> Config Class Initialized
INFO - 2023-04-27 10:37:58 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:58 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:58 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:58 --> URI Class Initialized
INFO - 2023-04-27 10:37:58 --> Router Class Initialized
INFO - 2023-04-27 10:37:58 --> Output Class Initialized
INFO - 2023-04-27 10:37:58 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:58 --> Input Class Initialized
INFO - 2023-04-27 10:37:58 --> Language Class Initialized
INFO - 2023-04-27 10:37:58 --> Loader Class Initialized
INFO - 2023-04-27 10:37:58 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:58 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:58 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:58 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:58 --> Total execution time: 0.0173
INFO - 2023-04-27 10:37:58 --> Config Class Initialized
INFO - 2023-04-27 10:37:58 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:37:58 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:37:58 --> Utf8 Class Initialized
INFO - 2023-04-27 10:37:58 --> URI Class Initialized
INFO - 2023-04-27 10:37:58 --> Router Class Initialized
INFO - 2023-04-27 10:37:58 --> Output Class Initialized
INFO - 2023-04-27 10:37:58 --> Security Class Initialized
DEBUG - 2023-04-27 10:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:37:58 --> Input Class Initialized
INFO - 2023-04-27 10:37:58 --> Language Class Initialized
INFO - 2023-04-27 10:37:58 --> Loader Class Initialized
INFO - 2023-04-27 10:37:58 --> Controller Class Initialized
DEBUG - 2023-04-27 10:37:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:37:58 --> Database Driver Class Initialized
INFO - 2023-04-27 10:37:58 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:37:58 --> Final output sent to browser
DEBUG - 2023-04-27 10:37:58 --> Total execution time: 0.0171
INFO - 2023-04-27 10:38:01 --> Config Class Initialized
INFO - 2023-04-27 10:38:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:38:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:38:01 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:01 --> URI Class Initialized
INFO - 2023-04-27 10:38:01 --> Router Class Initialized
INFO - 2023-04-27 10:38:01 --> Output Class Initialized
INFO - 2023-04-27 10:38:01 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:01 --> Input Class Initialized
INFO - 2023-04-27 10:38:01 --> Language Class Initialized
INFO - 2023-04-27 10:38:01 --> Loader Class Initialized
INFO - 2023-04-27 10:38:01 --> Controller Class Initialized
DEBUG - 2023-04-27 10:38:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:01 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:01 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:01 --> Total execution time: 0.0157
INFO - 2023-04-27 10:38:01 --> Config Class Initialized
INFO - 2023-04-27 10:38:01 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:38:01 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:38:01 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:01 --> URI Class Initialized
INFO - 2023-04-27 10:38:01 --> Router Class Initialized
INFO - 2023-04-27 10:38:01 --> Output Class Initialized
INFO - 2023-04-27 10:38:01 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:01 --> Input Class Initialized
INFO - 2023-04-27 10:38:01 --> Language Class Initialized
INFO - 2023-04-27 10:38:01 --> Loader Class Initialized
INFO - 2023-04-27 10:38:01 --> Controller Class Initialized
DEBUG - 2023-04-27 10:38:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:01 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:01 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:01 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:01 --> Total execution time: 0.0581
INFO - 2023-04-27 10:38:03 --> Config Class Initialized
INFO - 2023-04-27 10:38:03 --> Hooks Class Initialized
INFO - 2023-04-27 10:38:03 --> Config Class Initialized
DEBUG - 2023-04-27 10:38:03 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:38:03 --> Hooks Class Initialized
INFO - 2023-04-27 10:38:03 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:03 --> URI Class Initialized
INFO - 2023-04-27 10:38:03 --> Router Class Initialized
INFO - 2023-04-27 10:38:03 --> Output Class Initialized
INFO - 2023-04-27 10:38:03 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:03 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:03 --> Input Class Initialized
INFO - 2023-04-27 10:38:03 --> URI Class Initialized
INFO - 2023-04-27 10:38:03 --> Language Class Initialized
INFO - 2023-04-27 10:38:03 --> Router Class Initialized
INFO - 2023-04-27 10:38:03 --> Loader Class Initialized
INFO - 2023-04-27 10:38:03 --> Output Class Initialized
INFO - 2023-04-27 10:38:03 --> Controller Class Initialized
INFO - 2023-04-27 10:38:03 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:03 --> Input Class Initialized
INFO - 2023-04-27 10:38:03 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:03 --> Language Class Initialized
INFO - 2023-04-27 10:38:03 --> Loader Class Initialized
INFO - 2023-04-27 10:38:03 --> Controller Class Initialized
DEBUG - 2023-04-27 10:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:03 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:03 --> Final output sent to browser
INFO - 2023-04-27 10:38:03 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:03 --> Total execution time: 0.0216
DEBUG - 2023-04-27 10:38:03 --> Total execution time: 0.0228
INFO - 2023-04-27 10:38:03 --> Config Class Initialized
INFO - 2023-04-27 10:38:03 --> Config Class Initialized
INFO - 2023-04-27 10:38:03 --> Hooks Class Initialized
INFO - 2023-04-27 10:38:03 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:38:03 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:38:03 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:03 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:03 --> URI Class Initialized
INFO - 2023-04-27 10:38:03 --> URI Class Initialized
INFO - 2023-04-27 10:38:03 --> Router Class Initialized
INFO - 2023-04-27 10:38:03 --> Router Class Initialized
INFO - 2023-04-27 10:38:03 --> Output Class Initialized
INFO - 2023-04-27 10:38:03 --> Output Class Initialized
INFO - 2023-04-27 10:38:03 --> Security Class Initialized
INFO - 2023-04-27 10:38:03 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:03 --> Input Class Initialized
INFO - 2023-04-27 10:38:03 --> Input Class Initialized
INFO - 2023-04-27 10:38:03 --> Language Class Initialized
INFO - 2023-04-27 10:38:03 --> Language Class Initialized
INFO - 2023-04-27 10:38:03 --> Loader Class Initialized
INFO - 2023-04-27 10:38:03 --> Controller Class Initialized
INFO - 2023-04-27 10:38:03 --> Loader Class Initialized
DEBUG - 2023-04-27 10:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:03 --> Controller Class Initialized
DEBUG - 2023-04-27 10:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:03 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:03 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:03 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:03 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:03 --> Total execution time: 0.0192
INFO - 2023-04-27 10:38:03 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:03 --> Total execution time: 0.0223
INFO - 2023-04-27 10:38:09 --> Config Class Initialized
INFO - 2023-04-27 10:38:09 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:38:09 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:38:09 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:09 --> URI Class Initialized
INFO - 2023-04-27 10:38:09 --> Router Class Initialized
INFO - 2023-04-27 10:38:09 --> Output Class Initialized
INFO - 2023-04-27 10:38:09 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:09 --> Input Class Initialized
INFO - 2023-04-27 10:38:09 --> Language Class Initialized
INFO - 2023-04-27 10:38:09 --> Loader Class Initialized
INFO - 2023-04-27 10:38:09 --> Controller Class Initialized
DEBUG - 2023-04-27 10:38:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:09 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:09 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:09 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:09 --> Total execution time: 0.0141
INFO - 2023-04-27 10:38:09 --> Config Class Initialized
INFO - 2023-04-27 10:38:09 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:38:09 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:38:09 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:09 --> URI Class Initialized
INFO - 2023-04-27 10:38:09 --> Router Class Initialized
INFO - 2023-04-27 10:38:09 --> Output Class Initialized
INFO - 2023-04-27 10:38:09 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:09 --> Input Class Initialized
INFO - 2023-04-27 10:38:09 --> Language Class Initialized
INFO - 2023-04-27 10:38:09 --> Loader Class Initialized
INFO - 2023-04-27 10:38:09 --> Controller Class Initialized
DEBUG - 2023-04-27 10:38:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:09 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:09 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:09 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:09 --> Total execution time: 0.0127
INFO - 2023-04-27 10:38:09 --> Config Class Initialized
INFO - 2023-04-27 10:38:09 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:38:09 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:38:09 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:09 --> URI Class Initialized
INFO - 2023-04-27 10:38:09 --> Router Class Initialized
INFO - 2023-04-27 10:38:09 --> Output Class Initialized
INFO - 2023-04-27 10:38:09 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:09 --> Input Class Initialized
INFO - 2023-04-27 10:38:09 --> Language Class Initialized
INFO - 2023-04-27 10:38:09 --> Loader Class Initialized
INFO - 2023-04-27 10:38:09 --> Controller Class Initialized
DEBUG - 2023-04-27 10:38:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:09 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:09 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:09 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:09 --> Total execution time: 0.0526
INFO - 2023-04-27 10:38:09 --> Config Class Initialized
INFO - 2023-04-27 10:38:09 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:38:09 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:38:09 --> Utf8 Class Initialized
INFO - 2023-04-27 10:38:09 --> URI Class Initialized
INFO - 2023-04-27 10:38:09 --> Router Class Initialized
INFO - 2023-04-27 10:38:09 --> Output Class Initialized
INFO - 2023-04-27 10:38:09 --> Security Class Initialized
DEBUG - 2023-04-27 10:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:38:09 --> Input Class Initialized
INFO - 2023-04-27 10:38:09 --> Language Class Initialized
INFO - 2023-04-27 10:38:09 --> Loader Class Initialized
INFO - 2023-04-27 10:38:09 --> Controller Class Initialized
DEBUG - 2023-04-27 10:38:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:38:09 --> Database Driver Class Initialized
INFO - 2023-04-27 10:38:09 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:38:09 --> Final output sent to browser
DEBUG - 2023-04-27 10:38:09 --> Total execution time: 0.0137
INFO - 2023-04-27 10:46:50 --> Config Class Initialized
INFO - 2023-04-27 10:46:50 --> Config Class Initialized
INFO - 2023-04-27 10:46:50 --> Hooks Class Initialized
INFO - 2023-04-27 10:46:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:46:50 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:46:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:46:50 --> Utf8 Class Initialized
INFO - 2023-04-27 10:46:50 --> Utf8 Class Initialized
INFO - 2023-04-27 10:46:50 --> URI Class Initialized
INFO - 2023-04-27 10:46:50 --> URI Class Initialized
INFO - 2023-04-27 10:46:50 --> Router Class Initialized
INFO - 2023-04-27 10:46:50 --> Router Class Initialized
INFO - 2023-04-27 10:46:50 --> Output Class Initialized
INFO - 2023-04-27 10:46:50 --> Output Class Initialized
INFO - 2023-04-27 10:46:50 --> Security Class Initialized
INFO - 2023-04-27 10:46:50 --> Security Class Initialized
DEBUG - 2023-04-27 10:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:46:50 --> Input Class Initialized
INFO - 2023-04-27 10:46:50 --> Input Class Initialized
INFO - 2023-04-27 10:46:50 --> Language Class Initialized
INFO - 2023-04-27 10:46:50 --> Language Class Initialized
INFO - 2023-04-27 10:46:50 --> Loader Class Initialized
INFO - 2023-04-27 10:46:50 --> Loader Class Initialized
INFO - 2023-04-27 10:46:50 --> Controller Class Initialized
INFO - 2023-04-27 10:46:50 --> Controller Class Initialized
DEBUG - 2023-04-27 10:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:46:50 --> Database Driver Class Initialized
INFO - 2023-04-27 10:46:50 --> Database Driver Class Initialized
INFO - 2023-04-27 10:46:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:46:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:46:50 --> Final output sent to browser
DEBUG - 2023-04-27 10:46:50 --> Total execution time: 0.0179
INFO - 2023-04-27 10:46:50 --> Final output sent to browser
DEBUG - 2023-04-27 10:46:50 --> Total execution time: 0.0207
INFO - 2023-04-27 10:46:50 --> Config Class Initialized
INFO - 2023-04-27 10:46:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:46:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:46:50 --> Utf8 Class Initialized
INFO - 2023-04-27 10:46:50 --> URI Class Initialized
INFO - 2023-04-27 10:46:50 --> Router Class Initialized
INFO - 2023-04-27 10:46:50 --> Output Class Initialized
INFO - 2023-04-27 10:46:50 --> Config Class Initialized
INFO - 2023-04-27 10:46:50 --> Security Class Initialized
INFO - 2023-04-27 10:46:50 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:46:50 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:46:50 --> Input Class Initialized
INFO - 2023-04-27 10:46:50 --> Utf8 Class Initialized
INFO - 2023-04-27 10:46:50 --> Language Class Initialized
INFO - 2023-04-27 10:46:50 --> URI Class Initialized
INFO - 2023-04-27 10:46:50 --> Loader Class Initialized
INFO - 2023-04-27 10:46:50 --> Router Class Initialized
INFO - 2023-04-27 10:46:50 --> Controller Class Initialized
INFO - 2023-04-27 10:46:50 --> Output Class Initialized
DEBUG - 2023-04-27 10:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:46:50 --> Security Class Initialized
INFO - 2023-04-27 10:46:50 --> Database Driver Class Initialized
DEBUG - 2023-04-27 10:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:46:50 --> Input Class Initialized
INFO - 2023-04-27 10:46:50 --> Language Class Initialized
INFO - 2023-04-27 10:46:50 --> Loader Class Initialized
INFO - 2023-04-27 10:46:50 --> Controller Class Initialized
DEBUG - 2023-04-27 10:46:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:46:50 --> Database Driver Class Initialized
INFO - 2023-04-27 10:46:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:46:50 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:46:50 --> Final output sent to browser
DEBUG - 2023-04-27 10:46:50 --> Total execution time: 0.0140
INFO - 2023-04-27 10:46:50 --> Final output sent to browser
DEBUG - 2023-04-27 10:46:50 --> Total execution time: 0.0146
INFO - 2023-04-27 10:47:17 --> Config Class Initialized
INFO - 2023-04-27 10:47:17 --> Config Class Initialized
INFO - 2023-04-27 10:47:17 --> Hooks Class Initialized
INFO - 2023-04-27 10:47:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:47:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:47:17 --> Utf8 Class Initialized
DEBUG - 2023-04-27 10:47:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:47:17 --> URI Class Initialized
INFO - 2023-04-27 10:47:17 --> Utf8 Class Initialized
INFO - 2023-04-27 10:47:17 --> URI Class Initialized
INFO - 2023-04-27 10:47:17 --> Router Class Initialized
INFO - 2023-04-27 10:47:17 --> Router Class Initialized
INFO - 2023-04-27 10:47:17 --> Output Class Initialized
INFO - 2023-04-27 10:47:17 --> Output Class Initialized
INFO - 2023-04-27 10:47:17 --> Security Class Initialized
INFO - 2023-04-27 10:47:17 --> Security Class Initialized
DEBUG - 2023-04-27 10:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-04-27 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:47:17 --> Input Class Initialized
INFO - 2023-04-27 10:47:17 --> Input Class Initialized
INFO - 2023-04-27 10:47:17 --> Language Class Initialized
INFO - 2023-04-27 10:47:17 --> Language Class Initialized
INFO - 2023-04-27 10:47:17 --> Loader Class Initialized
INFO - 2023-04-27 10:47:17 --> Loader Class Initialized
INFO - 2023-04-27 10:47:17 --> Controller Class Initialized
INFO - 2023-04-27 10:47:17 --> Controller Class Initialized
DEBUG - 2023-04-27 10:47:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:47:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:47:17 --> Database Driver Class Initialized
INFO - 2023-04-27 10:47:17 --> Database Driver Class Initialized
INFO - 2023-04-27 10:47:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:47:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:47:17 --> Final output sent to browser
DEBUG - 2023-04-27 10:47:17 --> Total execution time: 0.1349
INFO - 2023-04-27 10:47:17 --> Config Class Initialized
INFO - 2023-04-27 10:47:17 --> Final output sent to browser
INFO - 2023-04-27 10:47:17 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:47:17 --> Total execution time: 0.1388
DEBUG - 2023-04-27 10:47:17 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:47:17 --> Utf8 Class Initialized
INFO - 2023-04-27 10:47:17 --> URI Class Initialized
INFO - 2023-04-27 10:47:17 --> Router Class Initialized
INFO - 2023-04-27 10:47:17 --> Config Class Initialized
INFO - 2023-04-27 10:47:17 --> Output Class Initialized
INFO - 2023-04-27 10:47:17 --> Hooks Class Initialized
INFO - 2023-04-27 10:47:17 --> Security Class Initialized
DEBUG - 2023-04-27 10:47:17 --> UTF-8 Support Enabled
DEBUG - 2023-04-27 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:47:17 --> Utf8 Class Initialized
INFO - 2023-04-27 10:47:17 --> Input Class Initialized
INFO - 2023-04-27 10:47:17 --> URI Class Initialized
INFO - 2023-04-27 10:47:17 --> Language Class Initialized
INFO - 2023-04-27 10:47:17 --> Router Class Initialized
INFO - 2023-04-27 10:47:17 --> Loader Class Initialized
INFO - 2023-04-27 10:47:17 --> Output Class Initialized
INFO - 2023-04-27 10:47:17 --> Controller Class Initialized
INFO - 2023-04-27 10:47:17 --> Security Class Initialized
DEBUG - 2023-04-27 10:47:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-04-27 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:47:17 --> Input Class Initialized
INFO - 2023-04-27 10:47:17 --> Database Driver Class Initialized
INFO - 2023-04-27 10:47:17 --> Language Class Initialized
INFO - 2023-04-27 10:47:17 --> Loader Class Initialized
INFO - 2023-04-27 10:47:17 --> Controller Class Initialized
DEBUG - 2023-04-27 10:47:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:47:17 --> Database Driver Class Initialized
INFO - 2023-04-27 10:47:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:47:17 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:47:17 --> Final output sent to browser
DEBUG - 2023-04-27 10:47:17 --> Total execution time: 0.0558
INFO - 2023-04-27 10:47:17 --> Final output sent to browser
DEBUG - 2023-04-27 10:47:17 --> Total execution time: 0.0133
INFO - 2023-04-27 10:47:20 --> Config Class Initialized
INFO - 2023-04-27 10:47:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:47:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:47:20 --> Utf8 Class Initialized
INFO - 2023-04-27 10:47:20 --> URI Class Initialized
INFO - 2023-04-27 10:47:20 --> Router Class Initialized
INFO - 2023-04-27 10:47:20 --> Output Class Initialized
INFO - 2023-04-27 10:47:20 --> Security Class Initialized
DEBUG - 2023-04-27 10:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:47:20 --> Input Class Initialized
INFO - 2023-04-27 10:47:20 --> Language Class Initialized
INFO - 2023-04-27 10:47:20 --> Loader Class Initialized
INFO - 2023-04-27 10:47:20 --> Controller Class Initialized
DEBUG - 2023-04-27 10:47:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:47:20 --> Database Driver Class Initialized
INFO - 2023-04-27 10:47:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:47:20 --> Final output sent to browser
DEBUG - 2023-04-27 10:47:20 --> Total execution time: 0.0146
INFO - 2023-04-27 10:47:20 --> Config Class Initialized
INFO - 2023-04-27 10:47:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:47:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:47:20 --> Utf8 Class Initialized
INFO - 2023-04-27 10:47:20 --> URI Class Initialized
INFO - 2023-04-27 10:47:20 --> Router Class Initialized
INFO - 2023-04-27 10:47:20 --> Output Class Initialized
INFO - 2023-04-27 10:47:20 --> Security Class Initialized
DEBUG - 2023-04-27 10:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:47:20 --> Input Class Initialized
INFO - 2023-04-27 10:47:20 --> Language Class Initialized
INFO - 2023-04-27 10:47:20 --> Loader Class Initialized
INFO - 2023-04-27 10:47:20 --> Controller Class Initialized
DEBUG - 2023-04-27 10:47:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:47:20 --> Database Driver Class Initialized
INFO - 2023-04-27 10:47:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:47:20 --> Final output sent to browser
DEBUG - 2023-04-27 10:47:20 --> Total execution time: 0.0125
INFO - 2023-04-27 10:47:20 --> Config Class Initialized
INFO - 2023-04-27 10:47:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:47:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:47:20 --> Utf8 Class Initialized
INFO - 2023-04-27 10:47:20 --> URI Class Initialized
INFO - 2023-04-27 10:47:20 --> Router Class Initialized
INFO - 2023-04-27 10:47:20 --> Output Class Initialized
INFO - 2023-04-27 10:47:20 --> Security Class Initialized
DEBUG - 2023-04-27 10:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:47:20 --> Input Class Initialized
INFO - 2023-04-27 10:47:20 --> Language Class Initialized
INFO - 2023-04-27 10:47:20 --> Loader Class Initialized
INFO - 2023-04-27 10:47:20 --> Controller Class Initialized
DEBUG - 2023-04-27 10:47:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:47:20 --> Database Driver Class Initialized
INFO - 2023-04-27 10:47:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:47:20 --> Final output sent to browser
DEBUG - 2023-04-27 10:47:20 --> Total execution time: 0.0530
INFO - 2023-04-27 10:47:20 --> Config Class Initialized
INFO - 2023-04-27 10:47:20 --> Hooks Class Initialized
DEBUG - 2023-04-27 10:47:20 --> UTF-8 Support Enabled
INFO - 2023-04-27 10:47:20 --> Utf8 Class Initialized
INFO - 2023-04-27 10:47:20 --> URI Class Initialized
INFO - 2023-04-27 10:47:20 --> Router Class Initialized
INFO - 2023-04-27 10:47:20 --> Output Class Initialized
INFO - 2023-04-27 10:47:20 --> Security Class Initialized
DEBUG - 2023-04-27 10:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 10:47:20 --> Input Class Initialized
INFO - 2023-04-27 10:47:20 --> Language Class Initialized
INFO - 2023-04-27 10:47:20 --> Loader Class Initialized
INFO - 2023-04-27 10:47:20 --> Controller Class Initialized
DEBUG - 2023-04-27 10:47:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 10:47:20 --> Database Driver Class Initialized
INFO - 2023-04-27 10:47:20 --> Model "Cluster_model" initialized
INFO - 2023-04-27 10:47:20 --> Final output sent to browser
DEBUG - 2023-04-27 10:47:20 --> Total execution time: 0.0109
INFO - 2023-04-27 12:50:23 --> Config Class Initialized
INFO - 2023-04-27 12:50:23 --> Hooks Class Initialized
DEBUG - 2023-04-27 12:50:23 --> UTF-8 Support Enabled
INFO - 2023-04-27 12:50:23 --> Utf8 Class Initialized
INFO - 2023-04-27 12:50:23 --> URI Class Initialized
INFO - 2023-04-27 12:50:23 --> Router Class Initialized
INFO - 2023-04-27 12:50:23 --> Output Class Initialized
INFO - 2023-04-27 12:50:23 --> Security Class Initialized
DEBUG - 2023-04-27 12:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 12:50:23 --> Input Class Initialized
INFO - 2023-04-27 12:50:23 --> Language Class Initialized
INFO - 2023-04-27 12:50:23 --> Loader Class Initialized
INFO - 2023-04-27 12:50:23 --> Controller Class Initialized
DEBUG - 2023-04-27 12:50:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 12:50:23 --> Database Driver Class Initialized
INFO - 2023-04-27 12:50:24 --> Config Class Initialized
INFO - 2023-04-27 12:50:24 --> Hooks Class Initialized
DEBUG - 2023-04-27 12:50:24 --> UTF-8 Support Enabled
INFO - 2023-04-27 12:50:24 --> Utf8 Class Initialized
INFO - 2023-04-27 12:50:24 --> URI Class Initialized
INFO - 2023-04-27 12:50:24 --> Router Class Initialized
INFO - 2023-04-27 12:50:24 --> Output Class Initialized
INFO - 2023-04-27 12:50:24 --> Security Class Initialized
DEBUG - 2023-04-27 12:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 12:50:24 --> Input Class Initialized
INFO - 2023-04-27 12:50:24 --> Language Class Initialized
INFO - 2023-04-27 12:50:24 --> Loader Class Initialized
INFO - 2023-04-27 12:50:24 --> Controller Class Initialized
DEBUG - 2023-04-27 12:50:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 12:50:24 --> Database Driver Class Initialized
INFO - 2023-04-27 12:50:24 --> Config Class Initialized
INFO - 2023-04-27 12:50:25 --> Hooks Class Initialized
DEBUG - 2023-04-27 12:50:25 --> UTF-8 Support Enabled
INFO - 2023-04-27 12:50:25 --> Utf8 Class Initialized
INFO - 2023-04-27 12:50:25 --> URI Class Initialized
INFO - 2023-04-27 12:50:25 --> Router Class Initialized
INFO - 2023-04-27 12:50:25 --> Output Class Initialized
INFO - 2023-04-27 12:50:25 --> Security Class Initialized
DEBUG - 2023-04-27 12:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 12:50:25 --> Input Class Initialized
INFO - 2023-04-27 12:50:25 --> Language Class Initialized
INFO - 2023-04-27 12:50:25 --> Loader Class Initialized
INFO - 2023-04-27 12:50:25 --> Controller Class Initialized
DEBUG - 2023-04-27 12:50:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 12:50:25 --> Database Driver Class Initialized
INFO - 2023-04-27 12:50:25 --> Config Class Initialized
INFO - 2023-04-27 12:50:25 --> Hooks Class Initialized
DEBUG - 2023-04-27 12:50:25 --> UTF-8 Support Enabled
INFO - 2023-04-27 12:50:25 --> Utf8 Class Initialized
INFO - 2023-04-27 12:50:25 --> URI Class Initialized
INFO - 2023-04-27 12:50:25 --> Router Class Initialized
INFO - 2023-04-27 12:50:25 --> Output Class Initialized
INFO - 2023-04-27 12:50:25 --> Security Class Initialized
DEBUG - 2023-04-27 12:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 12:50:25 --> Input Class Initialized
INFO - 2023-04-27 12:50:25 --> Language Class Initialized
INFO - 2023-04-27 12:50:25 --> Loader Class Initialized
INFO - 2023-04-27 12:50:25 --> Controller Class Initialized
DEBUG - 2023-04-27 12:50:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 12:50:25 --> Database Driver Class Initialized
INFO - 2023-04-27 12:50:26 --> Config Class Initialized
INFO - 2023-04-27 12:50:27 --> Hooks Class Initialized
DEBUG - 2023-04-27 12:50:27 --> UTF-8 Support Enabled
INFO - 2023-04-27 12:50:27 --> Utf8 Class Initialized
INFO - 2023-04-27 12:50:27 --> URI Class Initialized
INFO - 2023-04-27 12:50:27 --> Router Class Initialized
INFO - 2023-04-27 12:50:27 --> Output Class Initialized
INFO - 2023-04-27 12:50:27 --> Security Class Initialized
DEBUG - 2023-04-27 12:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-27 12:50:27 --> Input Class Initialized
INFO - 2023-04-27 12:50:27 --> Language Class Initialized
INFO - 2023-04-27 12:50:27 --> Loader Class Initialized
INFO - 2023-04-27 12:50:27 --> Controller Class Initialized
DEBUG - 2023-04-27 12:50:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-04-27 12:50:27 --> Database Driver Class Initialized
ERROR - 2023-04-27 12:50:33 --> Unable to connect to the database
INFO - 2023-04-27 12:50:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-27 12:50:34 --> Unable to connect to the database
INFO - 2023-04-27 12:50:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-27 12:50:35 --> Unable to connect to the database
INFO - 2023-04-27 12:50:35 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-27 12:50:35 --> Unable to connect to the database
INFO - 2023-04-27 12:50:35 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-04-27 12:50:37 --> Unable to connect to the database
INFO - 2023-04-27 12:50:37 --> Language file loaded: language/english/db_lang.php
