<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-10 01:37:44 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-10 01:37:44 --> Config Class Initialized
INFO - 2023-03-10 01:37:44 --> Hooks Class Initialized
INFO - 2023-03-10 01:37:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:44 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 01:37:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:44 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:44 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:44 --> URI Class Initialized
INFO - 2023-03-10 01:37:44 --> URI Class Initialized
INFO - 2023-03-10 01:37:44 --> Router Class Initialized
INFO - 2023-03-10 01:37:44 --> Router Class Initialized
INFO - 2023-03-10 01:37:44 --> Output Class Initialized
INFO - 2023-03-10 01:37:44 --> Output Class Initialized
INFO - 2023-03-10 01:37:44 --> Security Class Initialized
INFO - 2023-03-10 01:37:44 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 01:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:44 --> Input Class Initialized
INFO - 2023-03-10 01:37:44 --> Input Class Initialized
INFO - 2023-03-10 01:37:44 --> Language Class Initialized
INFO - 2023-03-10 01:37:44 --> Language Class Initialized
INFO - 2023-03-10 01:37:44 --> Loader Class Initialized
INFO - 2023-03-10 01:37:44 --> Loader Class Initialized
INFO - 2023-03-10 01:37:44 --> Controller Class Initialized
INFO - 2023-03-10 01:37:44 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 01:37:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:44 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:44 --> Total execution time: 0.0062
INFO - 2023-03-10 01:37:44 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:44 --> Config Class Initialized
INFO - 2023-03-10 01:37:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:44 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:44 --> URI Class Initialized
INFO - 2023-03-10 01:37:44 --> Router Class Initialized
INFO - 2023-03-10 01:37:44 --> Output Class Initialized
INFO - 2023-03-10 01:37:44 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:44 --> Input Class Initialized
INFO - 2023-03-10 01:37:44 --> Language Class Initialized
INFO - 2023-03-10 01:37:44 --> Loader Class Initialized
INFO - 2023-03-10 01:37:44 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:44 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:44 --> Model "Login_model" initialized
INFO - 2023-03-10 01:37:44 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:44 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:44 --> Total execution time: 0.1186
INFO - 2023-03-10 01:37:44 --> Config Class Initialized
INFO - 2023-03-10 01:37:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:44 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:44 --> URI Class Initialized
INFO - 2023-03-10 01:37:44 --> Router Class Initialized
INFO - 2023-03-10 01:37:44 --> Output Class Initialized
INFO - 2023-03-10 01:37:44 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:44 --> Input Class Initialized
INFO - 2023-03-10 01:37:44 --> Language Class Initialized
INFO - 2023-03-10 01:37:44 --> Loader Class Initialized
INFO - 2023-03-10 01:37:44 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:44 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:44 --> Final output sent to browser
INFO - 2023-03-10 01:37:44 --> Model "Cluster_model" initialized
DEBUG - 2023-03-10 01:37:44 --> Total execution time: 0.0757
INFO - 2023-03-10 01:37:44 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:44 --> Total execution time: 0.0478
INFO - 2023-03-10 01:37:47 --> Config Class Initialized
INFO - 2023-03-10 01:37:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:47 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:47 --> URI Class Initialized
INFO - 2023-03-10 01:37:47 --> Router Class Initialized
INFO - 2023-03-10 01:37:47 --> Output Class Initialized
INFO - 2023-03-10 01:37:47 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:47 --> Input Class Initialized
INFO - 2023-03-10 01:37:47 --> Language Class Initialized
INFO - 2023-03-10 01:37:47 --> Loader Class Initialized
INFO - 2023-03-10 01:37:47 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:47 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:47 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:47 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:47 --> Model "Login_model" initialized
INFO - 2023-03-10 01:37:47 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:47 --> Total execution time: 0.1306
INFO - 2023-03-10 01:37:47 --> Config Class Initialized
INFO - 2023-03-10 01:37:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:47 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:47 --> URI Class Initialized
INFO - 2023-03-10 01:37:47 --> Router Class Initialized
INFO - 2023-03-10 01:37:47 --> Output Class Initialized
INFO - 2023-03-10 01:37:47 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:47 --> Input Class Initialized
INFO - 2023-03-10 01:37:47 --> Language Class Initialized
INFO - 2023-03-10 01:37:47 --> Loader Class Initialized
INFO - 2023-03-10 01:37:47 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:47 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:47 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:47 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:47 --> Model "Login_model" initialized
INFO - 2023-03-10 01:37:47 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:47 --> Total execution time: 0.1318
INFO - 2023-03-10 01:37:50 --> Config Class Initialized
INFO - 2023-03-10 01:37:50 --> Hooks Class Initialized
INFO - 2023-03-10 01:37:50 --> Config Class Initialized
DEBUG - 2023-03-10 01:37:50 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:50 --> Hooks Class Initialized
INFO - 2023-03-10 01:37:50 --> Utf8 Class Initialized
DEBUG - 2023-03-10 01:37:50 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:50 --> URI Class Initialized
INFO - 2023-03-10 01:37:50 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:50 --> Router Class Initialized
INFO - 2023-03-10 01:37:50 --> URI Class Initialized
INFO - 2023-03-10 01:37:50 --> Output Class Initialized
INFO - 2023-03-10 01:37:50 --> Router Class Initialized
INFO - 2023-03-10 01:37:50 --> Security Class Initialized
INFO - 2023-03-10 01:37:50 --> Output Class Initialized
DEBUG - 2023-03-10 01:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:50 --> Security Class Initialized
INFO - 2023-03-10 01:37:50 --> Input Class Initialized
DEBUG - 2023-03-10 01:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:50 --> Language Class Initialized
INFO - 2023-03-10 01:37:50 --> Input Class Initialized
INFO - 2023-03-10 01:37:50 --> Language Class Initialized
INFO - 2023-03-10 01:37:50 --> Loader Class Initialized
INFO - 2023-03-10 01:37:50 --> Loader Class Initialized
INFO - 2023-03-10 01:37:50 --> Controller Class Initialized
INFO - 2023-03-10 01:37:50 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 01:37:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:50 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:50 --> Total execution time: 0.0049
INFO - 2023-03-10 01:37:50 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:50 --> Config Class Initialized
INFO - 2023-03-10 01:37:50 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:50 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:50 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:50 --> URI Class Initialized
INFO - 2023-03-10 01:37:50 --> Router Class Initialized
INFO - 2023-03-10 01:37:50 --> Output Class Initialized
INFO - 2023-03-10 01:37:50 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:50 --> Input Class Initialized
INFO - 2023-03-10 01:37:50 --> Language Class Initialized
INFO - 2023-03-10 01:37:50 --> Loader Class Initialized
INFO - 2023-03-10 01:37:50 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:50 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:50 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:50 --> Model "Login_model" initialized
INFO - 2023-03-10 01:37:50 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:50 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:50 --> Total execution time: 0.0206
INFO - 2023-03-10 01:37:50 --> Config Class Initialized
INFO - 2023-03-10 01:37:50 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:50 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:50 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:50 --> URI Class Initialized
INFO - 2023-03-10 01:37:50 --> Router Class Initialized
INFO - 2023-03-10 01:37:50 --> Output Class Initialized
INFO - 2023-03-10 01:37:50 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:50 --> Input Class Initialized
INFO - 2023-03-10 01:37:50 --> Language Class Initialized
INFO - 2023-03-10 01:37:50 --> Loader Class Initialized
INFO - 2023-03-10 01:37:50 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:50 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:50 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:50 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:50 --> Total execution time: 0.0226
INFO - 2023-03-10 01:37:50 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:50 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:50 --> Total execution time: 0.0527
INFO - 2023-03-10 01:37:56 --> Config Class Initialized
INFO - 2023-03-10 01:37:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:56 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:56 --> URI Class Initialized
INFO - 2023-03-10 01:37:56 --> Router Class Initialized
INFO - 2023-03-10 01:37:56 --> Output Class Initialized
INFO - 2023-03-10 01:37:56 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:56 --> Input Class Initialized
INFO - 2023-03-10 01:37:56 --> Language Class Initialized
INFO - 2023-03-10 01:37:56 --> Loader Class Initialized
INFO - 2023-03-10 01:37:56 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:56 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:56 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:56 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:56 --> Model "Login_model" initialized
INFO - 2023-03-10 01:37:56 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:56 --> Total execution time: 0.0435
INFO - 2023-03-10 01:37:56 --> Config Class Initialized
INFO - 2023-03-10 01:37:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:37:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:37:56 --> Utf8 Class Initialized
INFO - 2023-03-10 01:37:56 --> URI Class Initialized
INFO - 2023-03-10 01:37:56 --> Router Class Initialized
INFO - 2023-03-10 01:37:56 --> Output Class Initialized
INFO - 2023-03-10 01:37:56 --> Security Class Initialized
DEBUG - 2023-03-10 01:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:37:56 --> Input Class Initialized
INFO - 2023-03-10 01:37:56 --> Language Class Initialized
INFO - 2023-03-10 01:37:56 --> Loader Class Initialized
INFO - 2023-03-10 01:37:56 --> Controller Class Initialized
DEBUG - 2023-03-10 01:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:37:56 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:56 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:37:56 --> Database Driver Class Initialized
INFO - 2023-03-10 01:37:56 --> Model "Login_model" initialized
INFO - 2023-03-10 01:37:56 --> Final output sent to browser
DEBUG - 2023-03-10 01:37:56 --> Total execution time: 0.0381
INFO - 2023-03-10 01:38:00 --> Config Class Initialized
INFO - 2023-03-10 01:38:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:38:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:38:00 --> Utf8 Class Initialized
INFO - 2023-03-10 01:38:00 --> URI Class Initialized
INFO - 2023-03-10 01:38:00 --> Router Class Initialized
INFO - 2023-03-10 01:38:00 --> Output Class Initialized
INFO - 2023-03-10 01:38:00 --> Security Class Initialized
DEBUG - 2023-03-10 01:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:38:00 --> Input Class Initialized
INFO - 2023-03-10 01:38:00 --> Language Class Initialized
INFO - 2023-03-10 01:38:00 --> Loader Class Initialized
INFO - 2023-03-10 01:38:00 --> Controller Class Initialized
DEBUG - 2023-03-10 01:38:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:38:00 --> Database Driver Class Initialized
INFO - 2023-03-10 01:38:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:38:00 --> Final output sent to browser
DEBUG - 2023-03-10 01:38:00 --> Total execution time: 0.0534
INFO - 2023-03-10 01:38:00 --> Config Class Initialized
INFO - 2023-03-10 01:38:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:38:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:38:00 --> Utf8 Class Initialized
INFO - 2023-03-10 01:38:00 --> URI Class Initialized
INFO - 2023-03-10 01:38:00 --> Router Class Initialized
INFO - 2023-03-10 01:38:00 --> Output Class Initialized
INFO - 2023-03-10 01:38:00 --> Security Class Initialized
DEBUG - 2023-03-10 01:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:38:00 --> Input Class Initialized
INFO - 2023-03-10 01:38:00 --> Language Class Initialized
INFO - 2023-03-10 01:38:00 --> Loader Class Initialized
INFO - 2023-03-10 01:38:00 --> Controller Class Initialized
DEBUG - 2023-03-10 01:38:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:38:00 --> Database Driver Class Initialized
INFO - 2023-03-10 01:38:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:38:00 --> Final output sent to browser
DEBUG - 2023-03-10 01:38:00 --> Total execution time: 0.0537
INFO - 2023-03-10 01:38:03 --> Config Class Initialized
INFO - 2023-03-10 01:38:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:38:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:38:03 --> Utf8 Class Initialized
INFO - 2023-03-10 01:38:03 --> URI Class Initialized
INFO - 2023-03-10 01:38:03 --> Router Class Initialized
INFO - 2023-03-10 01:38:03 --> Output Class Initialized
INFO - 2023-03-10 01:38:03 --> Security Class Initialized
DEBUG - 2023-03-10 01:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:38:03 --> Input Class Initialized
INFO - 2023-03-10 01:38:03 --> Language Class Initialized
INFO - 2023-03-10 01:38:03 --> Loader Class Initialized
INFO - 2023-03-10 01:38:03 --> Controller Class Initialized
DEBUG - 2023-03-10 01:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:38:03 --> Database Driver Class Initialized
INFO - 2023-03-10 01:38:03 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:38:03 --> Final output sent to browser
DEBUG - 2023-03-10 01:38:03 --> Total execution time: 0.2472
INFO - 2023-03-10 01:38:03 --> Config Class Initialized
INFO - 2023-03-10 01:38:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:38:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:38:03 --> Utf8 Class Initialized
INFO - 2023-03-10 01:38:03 --> URI Class Initialized
INFO - 2023-03-10 01:38:03 --> Router Class Initialized
INFO - 2023-03-10 01:38:03 --> Output Class Initialized
INFO - 2023-03-10 01:38:03 --> Security Class Initialized
DEBUG - 2023-03-10 01:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:38:03 --> Input Class Initialized
INFO - 2023-03-10 01:38:03 --> Language Class Initialized
INFO - 2023-03-10 01:38:03 --> Loader Class Initialized
INFO - 2023-03-10 01:38:03 --> Controller Class Initialized
DEBUG - 2023-03-10 01:38:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:38:03 --> Database Driver Class Initialized
INFO - 2023-03-10 01:38:03 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:38:03 --> Final output sent to browser
DEBUG - 2023-03-10 01:38:03 --> Total execution time: 0.0507
INFO - 2023-03-10 01:38:07 --> Config Class Initialized
INFO - 2023-03-10 01:38:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:38:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:38:08 --> Utf8 Class Initialized
INFO - 2023-03-10 01:38:08 --> URI Class Initialized
INFO - 2023-03-10 01:38:08 --> Router Class Initialized
INFO - 2023-03-10 01:38:08 --> Output Class Initialized
INFO - 2023-03-10 01:38:08 --> Security Class Initialized
DEBUG - 2023-03-10 01:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:38:08 --> Input Class Initialized
INFO - 2023-03-10 01:38:08 --> Language Class Initialized
INFO - 2023-03-10 01:38:08 --> Loader Class Initialized
INFO - 2023-03-10 01:38:08 --> Controller Class Initialized
DEBUG - 2023-03-10 01:38:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:38:08 --> Database Driver Class Initialized
INFO - 2023-03-10 01:38:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:38:08 --> Final output sent to browser
DEBUG - 2023-03-10 01:38:08 --> Total execution time: 0.0585
INFO - 2023-03-10 01:38:08 --> Config Class Initialized
INFO - 2023-03-10 01:38:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 01:38:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 01:38:08 --> Utf8 Class Initialized
INFO - 2023-03-10 01:38:08 --> URI Class Initialized
INFO - 2023-03-10 01:38:08 --> Router Class Initialized
INFO - 2023-03-10 01:38:08 --> Output Class Initialized
INFO - 2023-03-10 01:38:08 --> Security Class Initialized
DEBUG - 2023-03-10 01:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 01:38:08 --> Input Class Initialized
INFO - 2023-03-10 01:38:08 --> Language Class Initialized
INFO - 2023-03-10 01:38:08 --> Loader Class Initialized
INFO - 2023-03-10 01:38:08 --> Controller Class Initialized
DEBUG - 2023-03-10 01:38:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 01:38:08 --> Database Driver Class Initialized
INFO - 2023-03-10 01:38:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 01:38:08 --> Final output sent to browser
DEBUG - 2023-03-10 01:38:08 --> Total execution time: 0.0642
INFO - 2023-03-10 02:01:07 --> Config Class Initialized
INFO - 2023-03-10 02:01:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:01:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:01:07 --> Utf8 Class Initialized
INFO - 2023-03-10 02:01:07 --> URI Class Initialized
INFO - 2023-03-10 02:01:07 --> Router Class Initialized
INFO - 2023-03-10 02:01:07 --> Output Class Initialized
INFO - 2023-03-10 02:01:07 --> Security Class Initialized
DEBUG - 2023-03-10 02:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:01:07 --> Input Class Initialized
INFO - 2023-03-10 02:01:07 --> Language Class Initialized
INFO - 2023-03-10 02:01:07 --> Loader Class Initialized
INFO - 2023-03-10 02:01:07 --> Controller Class Initialized
DEBUG - 2023-03-10 02:01:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:01:07 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:01:07 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:07 --> Model "Login_model" initialized
INFO - 2023-03-10 02:01:07 --> Final output sent to browser
DEBUG - 2023-03-10 02:01:07 --> Total execution time: 0.1287
INFO - 2023-03-10 02:01:07 --> Config Class Initialized
INFO - 2023-03-10 02:01:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:01:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:01:07 --> Utf8 Class Initialized
INFO - 2023-03-10 02:01:07 --> URI Class Initialized
INFO - 2023-03-10 02:01:07 --> Router Class Initialized
INFO - 2023-03-10 02:01:07 --> Output Class Initialized
INFO - 2023-03-10 02:01:07 --> Security Class Initialized
DEBUG - 2023-03-10 02:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:01:07 --> Input Class Initialized
INFO - 2023-03-10 02:01:07 --> Language Class Initialized
INFO - 2023-03-10 02:01:07 --> Loader Class Initialized
INFO - 2023-03-10 02:01:07 --> Controller Class Initialized
DEBUG - 2023-03-10 02:01:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:01:07 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:01:07 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:07 --> Model "Login_model" initialized
INFO - 2023-03-10 02:01:08 --> Final output sent to browser
DEBUG - 2023-03-10 02:01:08 --> Total execution time: 0.0429
INFO - 2023-03-10 02:01:21 --> Config Class Initialized
INFO - 2023-03-10 02:01:21 --> Config Class Initialized
INFO - 2023-03-10 02:01:21 --> Hooks Class Initialized
INFO - 2023-03-10 02:01:21 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:01:21 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:01:21 --> Utf8 Class Initialized
DEBUG - 2023-03-10 02:01:21 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:01:21 --> URI Class Initialized
INFO - 2023-03-10 02:01:21 --> Utf8 Class Initialized
INFO - 2023-03-10 02:01:21 --> Router Class Initialized
INFO - 2023-03-10 02:01:21 --> URI Class Initialized
INFO - 2023-03-10 02:01:21 --> Output Class Initialized
INFO - 2023-03-10 02:01:21 --> Security Class Initialized
INFO - 2023-03-10 02:01:21 --> Router Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:01:21 --> Output Class Initialized
INFO - 2023-03-10 02:01:21 --> Input Class Initialized
INFO - 2023-03-10 02:01:21 --> Security Class Initialized
INFO - 2023-03-10 02:01:21 --> Language Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:01:21 --> Input Class Initialized
INFO - 2023-03-10 02:01:21 --> Loader Class Initialized
INFO - 2023-03-10 02:01:21 --> Language Class Initialized
INFO - 2023-03-10 02:01:21 --> Controller Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:01:21 --> Final output sent to browser
INFO - 2023-03-10 02:01:21 --> Loader Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Total execution time: 0.0180
INFO - 2023-03-10 02:01:21 --> Controller Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:01:21 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:21 --> Config Class Initialized
INFO - 2023-03-10 02:01:21 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:01:21 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:01:21 --> Utf8 Class Initialized
INFO - 2023-03-10 02:01:21 --> URI Class Initialized
INFO - 2023-03-10 02:01:21 --> Router Class Initialized
INFO - 2023-03-10 02:01:21 --> Output Class Initialized
INFO - 2023-03-10 02:01:21 --> Security Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:01:21 --> Input Class Initialized
INFO - 2023-03-10 02:01:21 --> Language Class Initialized
INFO - 2023-03-10 02:01:21 --> Loader Class Initialized
INFO - 2023-03-10 02:01:21 --> Controller Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:01:21 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:21 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:01:21 --> Model "Login_model" initialized
INFO - 2023-03-10 02:01:21 --> Final output sent to browser
DEBUG - 2023-03-10 02:01:21 --> Total execution time: 0.0311
INFO - 2023-03-10 02:01:21 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:21 --> Config Class Initialized
INFO - 2023-03-10 02:01:21 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:01:21 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:01:21 --> Utf8 Class Initialized
INFO - 2023-03-10 02:01:21 --> URI Class Initialized
INFO - 2023-03-10 02:01:21 --> Router Class Initialized
INFO - 2023-03-10 02:01:21 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:01:21 --> Output Class Initialized
INFO - 2023-03-10 02:01:21 --> Security Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:01:21 --> Input Class Initialized
INFO - 2023-03-10 02:01:21 --> Language Class Initialized
INFO - 2023-03-10 02:01:21 --> Loader Class Initialized
INFO - 2023-03-10 02:01:21 --> Controller Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:01:21 --> Final output sent to browser
INFO - 2023-03-10 02:01:21 --> Database Driver Class Initialized
DEBUG - 2023-03-10 02:01:21 --> Total execution time: 0.0482
INFO - 2023-03-10 02:01:21 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:01:22 --> Final output sent to browser
DEBUG - 2023-03-10 02:01:22 --> Total execution time: 0.2763
INFO - 2023-03-10 02:01:23 --> Config Class Initialized
INFO - 2023-03-10 02:01:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:01:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:01:23 --> Utf8 Class Initialized
INFO - 2023-03-10 02:01:23 --> URI Class Initialized
INFO - 2023-03-10 02:01:23 --> Router Class Initialized
INFO - 2023-03-10 02:01:23 --> Output Class Initialized
INFO - 2023-03-10 02:01:23 --> Security Class Initialized
DEBUG - 2023-03-10 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:01:23 --> Input Class Initialized
INFO - 2023-03-10 02:01:23 --> Language Class Initialized
INFO - 2023-03-10 02:01:23 --> Loader Class Initialized
INFO - 2023-03-10 02:01:23 --> Controller Class Initialized
DEBUG - 2023-03-10 02:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:01:23 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:01:23 --> Final output sent to browser
DEBUG - 2023-03-10 02:01:23 --> Total execution time: 0.0485
INFO - 2023-03-10 02:01:23 --> Config Class Initialized
INFO - 2023-03-10 02:01:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:01:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:01:23 --> Utf8 Class Initialized
INFO - 2023-03-10 02:01:23 --> URI Class Initialized
INFO - 2023-03-10 02:01:23 --> Router Class Initialized
INFO - 2023-03-10 02:01:23 --> Output Class Initialized
INFO - 2023-03-10 02:01:23 --> Security Class Initialized
DEBUG - 2023-03-10 02:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:01:23 --> Input Class Initialized
INFO - 2023-03-10 02:01:23 --> Language Class Initialized
INFO - 2023-03-10 02:01:23 --> Loader Class Initialized
INFO - 2023-03-10 02:01:23 --> Controller Class Initialized
DEBUG - 2023-03-10 02:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:01:23 --> Database Driver Class Initialized
INFO - 2023-03-10 02:01:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:01:23 --> Final output sent to browser
DEBUG - 2023-03-10 02:01:23 --> Total execution time: 0.0910
INFO - 2023-03-10 02:03:08 --> Config Class Initialized
INFO - 2023-03-10 02:03:08 --> Config Class Initialized
INFO - 2023-03-10 02:03:08 --> Hooks Class Initialized
INFO - 2023-03-10 02:03:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:03:08 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 02:03:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:03:08 --> Utf8 Class Initialized
INFO - 2023-03-10 02:03:08 --> Utf8 Class Initialized
INFO - 2023-03-10 02:03:08 --> URI Class Initialized
INFO - 2023-03-10 02:03:08 --> URI Class Initialized
INFO - 2023-03-10 02:03:08 --> Router Class Initialized
INFO - 2023-03-10 02:03:08 --> Router Class Initialized
INFO - 2023-03-10 02:03:08 --> Output Class Initialized
INFO - 2023-03-10 02:03:08 --> Output Class Initialized
INFO - 2023-03-10 02:03:08 --> Security Class Initialized
INFO - 2023-03-10 02:03:08 --> Security Class Initialized
DEBUG - 2023-03-10 02:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 02:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:03:08 --> Input Class Initialized
INFO - 2023-03-10 02:03:08 --> Input Class Initialized
INFO - 2023-03-10 02:03:08 --> Language Class Initialized
INFO - 2023-03-10 02:03:08 --> Language Class Initialized
INFO - 2023-03-10 02:03:08 --> Loader Class Initialized
INFO - 2023-03-10 02:03:08 --> Loader Class Initialized
INFO - 2023-03-10 02:03:08 --> Controller Class Initialized
INFO - 2023-03-10 02:03:08 --> Controller Class Initialized
DEBUG - 2023-03-10 02:03:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 02:03:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:03:08 --> Final output sent to browser
DEBUG - 2023-03-10 02:03:08 --> Total execution time: 0.0052
INFO - 2023-03-10 02:03:08 --> Database Driver Class Initialized
INFO - 2023-03-10 02:03:08 --> Config Class Initialized
INFO - 2023-03-10 02:03:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:03:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:03:08 --> Utf8 Class Initialized
INFO - 2023-03-10 02:03:08 --> URI Class Initialized
INFO - 2023-03-10 02:03:08 --> Router Class Initialized
INFO - 2023-03-10 02:03:08 --> Output Class Initialized
INFO - 2023-03-10 02:03:08 --> Security Class Initialized
DEBUG - 2023-03-10 02:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:03:08 --> Input Class Initialized
INFO - 2023-03-10 02:03:08 --> Language Class Initialized
INFO - 2023-03-10 02:03:08 --> Loader Class Initialized
INFO - 2023-03-10 02:03:08 --> Controller Class Initialized
DEBUG - 2023-03-10 02:03:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:03:08 --> Database Driver Class Initialized
INFO - 2023-03-10 02:03:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:03:08 --> Model "Login_model" initialized
INFO - 2023-03-10 02:03:08 --> Final output sent to browser
DEBUG - 2023-03-10 02:03:08 --> Total execution time: 0.0181
INFO - 2023-03-10 02:03:08 --> Database Driver Class Initialized
INFO - 2023-03-10 02:03:08 --> Config Class Initialized
INFO - 2023-03-10 02:03:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:03:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:03:08 --> Utf8 Class Initialized
INFO - 2023-03-10 02:03:08 --> URI Class Initialized
INFO - 2023-03-10 02:03:08 --> Router Class Initialized
INFO - 2023-03-10 02:03:08 --> Output Class Initialized
INFO - 2023-03-10 02:03:08 --> Security Class Initialized
DEBUG - 2023-03-10 02:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:03:08 --> Input Class Initialized
INFO - 2023-03-10 02:03:08 --> Language Class Initialized
INFO - 2023-03-10 02:03:08 --> Loader Class Initialized
INFO - 2023-03-10 02:03:08 --> Controller Class Initialized
DEBUG - 2023-03-10 02:03:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:03:08 --> Database Driver Class Initialized
INFO - 2023-03-10 02:03:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:03:08 --> Final output sent to browser
DEBUG - 2023-03-10 02:03:08 --> Total execution time: 0.0222
INFO - 2023-03-10 02:03:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:03:08 --> Final output sent to browser
DEBUG - 2023-03-10 02:03:08 --> Total execution time: 0.0132
INFO - 2023-03-10 02:03:11 --> Config Class Initialized
INFO - 2023-03-10 02:03:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:03:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:03:11 --> Utf8 Class Initialized
INFO - 2023-03-10 02:03:11 --> URI Class Initialized
INFO - 2023-03-10 02:03:11 --> Router Class Initialized
INFO - 2023-03-10 02:03:11 --> Output Class Initialized
INFO - 2023-03-10 02:03:11 --> Security Class Initialized
DEBUG - 2023-03-10 02:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:03:11 --> Input Class Initialized
INFO - 2023-03-10 02:03:11 --> Language Class Initialized
INFO - 2023-03-10 02:03:11 --> Loader Class Initialized
INFO - 2023-03-10 02:03:11 --> Controller Class Initialized
DEBUG - 2023-03-10 02:03:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:03:11 --> Database Driver Class Initialized
INFO - 2023-03-10 02:03:11 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:03:11 --> Database Driver Class Initialized
INFO - 2023-03-10 02:03:11 --> Model "Login_model" initialized
INFO - 2023-03-10 02:03:11 --> Final output sent to browser
DEBUG - 2023-03-10 02:03:11 --> Total execution time: 0.0473
INFO - 2023-03-10 02:03:11 --> Config Class Initialized
INFO - 2023-03-10 02:03:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 02:03:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 02:03:11 --> Utf8 Class Initialized
INFO - 2023-03-10 02:03:11 --> URI Class Initialized
INFO - 2023-03-10 02:03:11 --> Router Class Initialized
INFO - 2023-03-10 02:03:11 --> Output Class Initialized
INFO - 2023-03-10 02:03:11 --> Security Class Initialized
DEBUG - 2023-03-10 02:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 02:03:11 --> Input Class Initialized
INFO - 2023-03-10 02:03:11 --> Language Class Initialized
INFO - 2023-03-10 02:03:11 --> Loader Class Initialized
INFO - 2023-03-10 02:03:11 --> Controller Class Initialized
DEBUG - 2023-03-10 02:03:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 02:03:11 --> Database Driver Class Initialized
INFO - 2023-03-10 02:03:11 --> Model "Cluster_model" initialized
INFO - 2023-03-10 02:03:11 --> Database Driver Class Initialized
INFO - 2023-03-10 02:03:11 --> Model "Login_model" initialized
INFO - 2023-03-10 02:03:11 --> Final output sent to browser
DEBUG - 2023-03-10 02:03:11 --> Total execution time: 0.0502
INFO - 2023-03-10 03:02:55 --> Config Class Initialized
INFO - 2023-03-10 03:02:55 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:02:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:02:55 --> Utf8 Class Initialized
INFO - 2023-03-10 03:02:55 --> URI Class Initialized
INFO - 2023-03-10 03:02:55 --> Router Class Initialized
INFO - 2023-03-10 03:02:55 --> Output Class Initialized
INFO - 2023-03-10 03:02:55 --> Security Class Initialized
DEBUG - 2023-03-10 03:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:02:55 --> Input Class Initialized
INFO - 2023-03-10 03:02:55 --> Language Class Initialized
INFO - 2023-03-10 03:02:55 --> Loader Class Initialized
INFO - 2023-03-10 03:02:55 --> Controller Class Initialized
INFO - 2023-03-10 03:02:55 --> Helper loaded: form_helper
INFO - 2023-03-10 03:02:55 --> Helper loaded: url_helper
DEBUG - 2023-03-10 03:02:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:02:55 --> Model "Change_model" initialized
INFO - 2023-03-10 03:02:56 --> Model "Grafana_model" initialized
INFO - 2023-03-10 03:02:56 --> Final output sent to browser
DEBUG - 2023-03-10 03:02:56 --> Total execution time: 0.6317
INFO - 2023-03-10 03:02:56 --> Config Class Initialized
INFO - 2023-03-10 03:02:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:02:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:02:57 --> Utf8 Class Initialized
INFO - 2023-03-10 03:02:57 --> URI Class Initialized
INFO - 2023-03-10 03:02:57 --> Router Class Initialized
INFO - 2023-03-10 03:02:57 --> Output Class Initialized
INFO - 2023-03-10 03:02:57 --> Security Class Initialized
DEBUG - 2023-03-10 03:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:02:57 --> Input Class Initialized
INFO - 2023-03-10 03:02:57 --> Language Class Initialized
INFO - 2023-03-10 03:02:57 --> Loader Class Initialized
INFO - 2023-03-10 03:02:57 --> Controller Class Initialized
INFO - 2023-03-10 03:02:57 --> Helper loaded: form_helper
INFO - 2023-03-10 03:02:57 --> Helper loaded: url_helper
DEBUG - 2023-03-10 03:02:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:02:58 --> Final output sent to browser
DEBUG - 2023-03-10 03:02:58 --> Total execution time: 1.2599
INFO - 2023-03-10 03:02:58 --> Config Class Initialized
INFO - 2023-03-10 03:02:58 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:02:58 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:02:58 --> Utf8 Class Initialized
INFO - 2023-03-10 03:02:58 --> URI Class Initialized
INFO - 2023-03-10 03:02:58 --> Router Class Initialized
INFO - 2023-03-10 03:02:58 --> Output Class Initialized
INFO - 2023-03-10 03:02:58 --> Security Class Initialized
DEBUG - 2023-03-10 03:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:02:58 --> Input Class Initialized
INFO - 2023-03-10 03:02:58 --> Language Class Initialized
INFO - 2023-03-10 03:02:59 --> Loader Class Initialized
INFO - 2023-03-10 03:02:59 --> Controller Class Initialized
INFO - 2023-03-10 03:02:59 --> Helper loaded: form_helper
INFO - 2023-03-10 03:02:59 --> Helper loaded: url_helper
DEBUG - 2023-03-10 03:02:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:02:59 --> Database Driver Class Initialized
INFO - 2023-03-10 03:02:59 --> Model "Login_model" initialized
INFO - 2023-03-10 03:03:00 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:00 --> Total execution time: 1.7134
INFO - 2023-03-10 03:03:00 --> Config Class Initialized
INFO - 2023-03-10 03:03:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:00 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:00 --> URI Class Initialized
INFO - 2023-03-10 03:03:00 --> Router Class Initialized
INFO - 2023-03-10 03:03:00 --> Output Class Initialized
INFO - 2023-03-10 03:03:00 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:00 --> Input Class Initialized
INFO - 2023-03-10 03:03:01 --> Language Class Initialized
INFO - 2023-03-10 03:03:01 --> Loader Class Initialized
INFO - 2023-03-10 03:03:02 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:02 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:03 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:03 --> Total execution time: 3.2158
INFO - 2023-03-10 03:03:03 --> Config Class Initialized
INFO - 2023-03-10 03:03:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:03 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:03 --> URI Class Initialized
INFO - 2023-03-10 03:03:04 --> Router Class Initialized
INFO - 2023-03-10 03:03:04 --> Output Class Initialized
INFO - 2023-03-10 03:03:04 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:04 --> Input Class Initialized
INFO - 2023-03-10 03:03:04 --> Language Class Initialized
INFO - 2023-03-10 03:03:04 --> Loader Class Initialized
INFO - 2023-03-10 03:03:04 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:04 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:04 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:04 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:04 --> Total execution time: 0.7026
INFO - 2023-03-10 03:03:04 --> Config Class Initialized
INFO - 2023-03-10 03:03:04 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:04 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:04 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:04 --> URI Class Initialized
INFO - 2023-03-10 03:03:05 --> Router Class Initialized
INFO - 2023-03-10 03:03:05 --> Output Class Initialized
INFO - 2023-03-10 03:03:05 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:05 --> Input Class Initialized
INFO - 2023-03-10 03:03:05 --> Language Class Initialized
INFO - 2023-03-10 03:03:05 --> Loader Class Initialized
INFO - 2023-03-10 03:03:05 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:05 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:05 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:05 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:05 --> Model "Login_model" initialized
INFO - 2023-03-10 03:03:05 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:05 --> Total execution time: 0.9525
INFO - 2023-03-10 03:03:05 --> Config Class Initialized
INFO - 2023-03-10 03:03:05 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:05 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:05 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:05 --> URI Class Initialized
INFO - 2023-03-10 03:03:05 --> Router Class Initialized
INFO - 2023-03-10 03:03:05 --> Output Class Initialized
INFO - 2023-03-10 03:03:05 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:05 --> Input Class Initialized
INFO - 2023-03-10 03:03:05 --> Language Class Initialized
INFO - 2023-03-10 03:03:05 --> Loader Class Initialized
INFO - 2023-03-10 03:03:05 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:05 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:05 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:05 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:05 --> Model "Login_model" initialized
INFO - 2023-03-10 03:03:05 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:06 --> Total execution time: 0.3270
INFO - 2023-03-10 03:03:09 --> Config Class Initialized
INFO - 2023-03-10 03:03:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:10 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:10 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:10 --> URI Class Initialized
INFO - 2023-03-10 03:03:10 --> Router Class Initialized
INFO - 2023-03-10 03:03:10 --> Output Class Initialized
INFO - 2023-03-10 03:03:10 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:10 --> Input Class Initialized
INFO - 2023-03-10 03:03:10 --> Language Class Initialized
INFO - 2023-03-10 03:03:10 --> Loader Class Initialized
INFO - 2023-03-10 03:03:10 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:10 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:10 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:11 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:11 --> Total execution time: 1.1081
INFO - 2023-03-10 03:03:11 --> Config Class Initialized
INFO - 2023-03-10 03:03:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:11 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:11 --> URI Class Initialized
INFO - 2023-03-10 03:03:11 --> Router Class Initialized
INFO - 2023-03-10 03:03:11 --> Output Class Initialized
INFO - 2023-03-10 03:03:11 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:11 --> Input Class Initialized
INFO - 2023-03-10 03:03:11 --> Language Class Initialized
INFO - 2023-03-10 03:03:11 --> Loader Class Initialized
INFO - 2023-03-10 03:03:11 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:11 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:11 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:11 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:11 --> Total execution time: 0.1357
INFO - 2023-03-10 03:03:13 --> Config Class Initialized
INFO - 2023-03-10 03:03:13 --> Config Class Initialized
INFO - 2023-03-10 03:03:14 --> Hooks Class Initialized
INFO - 2023-03-10 03:03:14 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:14 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 03:03:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:14 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:14 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:14 --> URI Class Initialized
INFO - 2023-03-10 03:03:14 --> URI Class Initialized
INFO - 2023-03-10 03:03:14 --> Router Class Initialized
INFO - 2023-03-10 03:03:14 --> Router Class Initialized
INFO - 2023-03-10 03:03:14 --> Output Class Initialized
INFO - 2023-03-10 03:03:14 --> Output Class Initialized
INFO - 2023-03-10 03:03:14 --> Security Class Initialized
INFO - 2023-03-10 03:03:14 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 03:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:15 --> Input Class Initialized
INFO - 2023-03-10 03:03:15 --> Input Class Initialized
INFO - 2023-03-10 03:03:15 --> Language Class Initialized
INFO - 2023-03-10 03:03:15 --> Language Class Initialized
INFO - 2023-03-10 03:03:15 --> Loader Class Initialized
INFO - 2023-03-10 03:03:15 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:15 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:15 --> Loader Class Initialized
INFO - 2023-03-10 03:03:15 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:15 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:15 --> Total execution time: 1.1369
INFO - 2023-03-10 03:03:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:15 --> Config Class Initialized
INFO - 2023-03-10 03:03:15 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:15 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:15 --> URI Class Initialized
INFO - 2023-03-10 03:03:15 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:15 --> Total execution time: 1.1895
INFO - 2023-03-10 03:03:15 --> Router Class Initialized
INFO - 2023-03-10 03:03:15 --> Output Class Initialized
INFO - 2023-03-10 03:03:15 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:15 --> Input Class Initialized
INFO - 2023-03-10 03:03:15 --> Language Class Initialized
INFO - 2023-03-10 03:03:15 --> Loader Class Initialized
INFO - 2023-03-10 03:03:15 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:15 --> Config Class Initialized
INFO - 2023-03-10 03:03:15 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:15 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:15 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:15 --> URI Class Initialized
INFO - 2023-03-10 03:03:15 --> Router Class Initialized
INFO - 2023-03-10 03:03:15 --> Output Class Initialized
INFO - 2023-03-10 03:03:15 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:15 --> Input Class Initialized
INFO - 2023-03-10 03:03:15 --> Language Class Initialized
INFO - 2023-03-10 03:03:15 --> Loader Class Initialized
INFO - 2023-03-10 03:03:15 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:15 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:15 --> Model "Login_model" initialized
INFO - 2023-03-10 03:03:15 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:15 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:15 --> Total execution time: 0.0320
INFO - 2023-03-10 03:03:15 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:15 --> Total execution time: 0.0828
INFO - 2023-03-10 03:03:34 --> Config Class Initialized
INFO - 2023-03-10 03:03:34 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:34 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:34 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:34 --> URI Class Initialized
INFO - 2023-03-10 03:03:34 --> Router Class Initialized
INFO - 2023-03-10 03:03:34 --> Output Class Initialized
INFO - 2023-03-10 03:03:34 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:34 --> Input Class Initialized
INFO - 2023-03-10 03:03:34 --> Language Class Initialized
INFO - 2023-03-10 03:03:34 --> Loader Class Initialized
INFO - 2023-03-10 03:03:34 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:34 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:34 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:34 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:34 --> Model "Login_model" initialized
INFO - 2023-03-10 03:03:34 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:34 --> Total execution time: 0.2421
INFO - 2023-03-10 03:03:34 --> Config Class Initialized
INFO - 2023-03-10 03:03:34 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:03:35 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:03:35 --> Utf8 Class Initialized
INFO - 2023-03-10 03:03:35 --> URI Class Initialized
INFO - 2023-03-10 03:03:35 --> Router Class Initialized
INFO - 2023-03-10 03:03:35 --> Output Class Initialized
INFO - 2023-03-10 03:03:35 --> Security Class Initialized
DEBUG - 2023-03-10 03:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:03:35 --> Input Class Initialized
INFO - 2023-03-10 03:03:35 --> Language Class Initialized
INFO - 2023-03-10 03:03:35 --> Loader Class Initialized
INFO - 2023-03-10 03:03:35 --> Controller Class Initialized
DEBUG - 2023-03-10 03:03:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:03:35 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:35 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:03:35 --> Database Driver Class Initialized
INFO - 2023-03-10 03:03:35 --> Model "Login_model" initialized
INFO - 2023-03-10 03:03:35 --> Final output sent to browser
DEBUG - 2023-03-10 03:03:35 --> Total execution time: 0.4718
INFO - 2023-03-10 03:06:07 --> Config Class Initialized
INFO - 2023-03-10 03:06:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:06:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:06:07 --> Utf8 Class Initialized
INFO - 2023-03-10 03:06:07 --> URI Class Initialized
INFO - 2023-03-10 03:06:07 --> Router Class Initialized
INFO - 2023-03-10 03:06:07 --> Output Class Initialized
INFO - 2023-03-10 03:06:07 --> Security Class Initialized
DEBUG - 2023-03-10 03:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:06:07 --> Input Class Initialized
INFO - 2023-03-10 03:06:07 --> Language Class Initialized
INFO - 2023-03-10 03:06:07 --> Loader Class Initialized
INFO - 2023-03-10 03:06:07 --> Controller Class Initialized
DEBUG - 2023-03-10 03:06:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:06:07 --> Final output sent to browser
DEBUG - 2023-03-10 03:06:07 --> Total execution time: 0.2864
INFO - 2023-03-10 03:06:07 --> Config Class Initialized
INFO - 2023-03-10 03:06:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:06:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:06:07 --> Utf8 Class Initialized
INFO - 2023-03-10 03:06:07 --> URI Class Initialized
INFO - 2023-03-10 03:06:08 --> Router Class Initialized
INFO - 2023-03-10 03:06:08 --> Output Class Initialized
INFO - 2023-03-10 03:06:08 --> Security Class Initialized
DEBUG - 2023-03-10 03:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:06:08 --> Input Class Initialized
INFO - 2023-03-10 03:06:08 --> Language Class Initialized
INFO - 2023-03-10 03:06:08 --> Loader Class Initialized
INFO - 2023-03-10 03:06:08 --> Controller Class Initialized
DEBUG - 2023-03-10 03:06:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:06:08 --> Database Driver Class Initialized
INFO - 2023-03-10 03:06:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:06:08 --> Final output sent to browser
DEBUG - 2023-03-10 03:06:08 --> Total execution time: 0.7402
INFO - 2023-03-10 03:06:08 --> Config Class Initialized
INFO - 2023-03-10 03:06:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:06:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:06:08 --> Utf8 Class Initialized
INFO - 2023-03-10 03:06:08 --> URI Class Initialized
INFO - 2023-03-10 03:06:08 --> Router Class Initialized
INFO - 2023-03-10 03:06:08 --> Output Class Initialized
INFO - 2023-03-10 03:06:08 --> Security Class Initialized
DEBUG - 2023-03-10 03:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:06:08 --> Input Class Initialized
INFO - 2023-03-10 03:06:08 --> Language Class Initialized
INFO - 2023-03-10 03:06:08 --> Loader Class Initialized
INFO - 2023-03-10 03:06:08 --> Controller Class Initialized
DEBUG - 2023-03-10 03:06:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:06:08 --> Final output sent to browser
DEBUG - 2023-03-10 03:06:08 --> Total execution time: 0.0820
INFO - 2023-03-10 03:06:08 --> Config Class Initialized
INFO - 2023-03-10 03:06:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:06:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:06:08 --> Utf8 Class Initialized
INFO - 2023-03-10 03:06:08 --> URI Class Initialized
INFO - 2023-03-10 03:06:08 --> Router Class Initialized
INFO - 2023-03-10 03:06:09 --> Output Class Initialized
INFO - 2023-03-10 03:06:09 --> Security Class Initialized
DEBUG - 2023-03-10 03:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:06:09 --> Input Class Initialized
INFO - 2023-03-10 03:06:09 --> Language Class Initialized
INFO - 2023-03-10 03:06:09 --> Loader Class Initialized
INFO - 2023-03-10 03:06:09 --> Controller Class Initialized
DEBUG - 2023-03-10 03:06:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:06:09 --> Database Driver Class Initialized
INFO - 2023-03-10 03:06:09 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:06:09 --> Final output sent to browser
DEBUG - 2023-03-10 03:06:09 --> Total execution time: 0.6637
INFO - 2023-03-10 03:09:48 --> Config Class Initialized
INFO - 2023-03-10 03:09:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:09:48 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:09:48 --> Utf8 Class Initialized
INFO - 2023-03-10 03:09:48 --> URI Class Initialized
INFO - 2023-03-10 03:09:48 --> Router Class Initialized
INFO - 2023-03-10 03:09:48 --> Output Class Initialized
INFO - 2023-03-10 03:09:48 --> Security Class Initialized
DEBUG - 2023-03-10 03:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:09:48 --> Input Class Initialized
INFO - 2023-03-10 03:09:48 --> Language Class Initialized
INFO - 2023-03-10 03:09:48 --> Loader Class Initialized
INFO - 2023-03-10 03:09:48 --> Controller Class Initialized
DEBUG - 2023-03-10 03:09:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:09:48 --> Database Driver Class Initialized
INFO - 2023-03-10 03:09:48 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:09:48 --> Database Driver Class Initialized
INFO - 2023-03-10 03:09:48 --> Model "Login_model" initialized
INFO - 2023-03-10 03:09:48 --> Final output sent to browser
DEBUG - 2023-03-10 03:09:48 --> Total execution time: 0.0541
INFO - 2023-03-10 03:09:48 --> Config Class Initialized
INFO - 2023-03-10 03:09:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:09:48 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:09:48 --> Utf8 Class Initialized
INFO - 2023-03-10 03:09:48 --> URI Class Initialized
INFO - 2023-03-10 03:09:48 --> Router Class Initialized
INFO - 2023-03-10 03:09:48 --> Output Class Initialized
INFO - 2023-03-10 03:09:48 --> Security Class Initialized
DEBUG - 2023-03-10 03:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:09:48 --> Input Class Initialized
INFO - 2023-03-10 03:09:48 --> Language Class Initialized
INFO - 2023-03-10 03:09:48 --> Loader Class Initialized
INFO - 2023-03-10 03:09:48 --> Controller Class Initialized
DEBUG - 2023-03-10 03:09:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:09:48 --> Database Driver Class Initialized
INFO - 2023-03-10 03:09:48 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:09:48 --> Database Driver Class Initialized
INFO - 2023-03-10 03:09:48 --> Model "Login_model" initialized
INFO - 2023-03-10 03:09:48 --> Final output sent to browser
DEBUG - 2023-03-10 03:09:48 --> Total execution time: 0.5687
INFO - 2023-03-10 03:19:32 --> Config Class Initialized
INFO - 2023-03-10 03:19:32 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:19:32 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:19:32 --> Utf8 Class Initialized
INFO - 2023-03-10 03:19:32 --> URI Class Initialized
INFO - 2023-03-10 03:19:32 --> Router Class Initialized
INFO - 2023-03-10 03:19:32 --> Output Class Initialized
INFO - 2023-03-10 03:19:32 --> Security Class Initialized
DEBUG - 2023-03-10 03:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:19:32 --> Input Class Initialized
INFO - 2023-03-10 03:19:32 --> Language Class Initialized
INFO - 2023-03-10 03:19:32 --> Loader Class Initialized
INFO - 2023-03-10 03:19:32 --> Controller Class Initialized
DEBUG - 2023-03-10 03:19:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:19:32 --> Database Driver Class Initialized
INFO - 2023-03-10 03:19:32 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:19:32 --> Final output sent to browser
DEBUG - 2023-03-10 03:19:32 --> Total execution time: 0.1138
INFO - 2023-03-10 03:19:32 --> Config Class Initialized
INFO - 2023-03-10 03:19:32 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:19:32 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:19:32 --> Utf8 Class Initialized
INFO - 2023-03-10 03:19:32 --> URI Class Initialized
INFO - 2023-03-10 03:19:32 --> Router Class Initialized
INFO - 2023-03-10 03:19:32 --> Output Class Initialized
INFO - 2023-03-10 03:19:32 --> Security Class Initialized
DEBUG - 2023-03-10 03:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:19:32 --> Input Class Initialized
INFO - 2023-03-10 03:19:32 --> Language Class Initialized
INFO - 2023-03-10 03:19:32 --> Loader Class Initialized
INFO - 2023-03-10 03:19:32 --> Controller Class Initialized
DEBUG - 2023-03-10 03:19:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:19:32 --> Database Driver Class Initialized
INFO - 2023-03-10 03:19:32 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:19:32 --> Final output sent to browser
DEBUG - 2023-03-10 03:19:32 --> Total execution time: 0.1213
INFO - 2023-03-10 03:19:35 --> Config Class Initialized
INFO - 2023-03-10 03:19:35 --> Config Class Initialized
INFO - 2023-03-10 03:19:35 --> Hooks Class Initialized
INFO - 2023-03-10 03:19:35 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:19:35 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 03:19:35 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:19:35 --> Utf8 Class Initialized
INFO - 2023-03-10 03:19:35 --> Utf8 Class Initialized
INFO - 2023-03-10 03:19:35 --> URI Class Initialized
INFO - 2023-03-10 03:19:35 --> URI Class Initialized
INFO - 2023-03-10 03:19:35 --> Router Class Initialized
INFO - 2023-03-10 03:19:35 --> Router Class Initialized
INFO - 2023-03-10 03:19:35 --> Output Class Initialized
INFO - 2023-03-10 03:19:35 --> Output Class Initialized
INFO - 2023-03-10 03:19:35 --> Security Class Initialized
INFO - 2023-03-10 03:19:35 --> Security Class Initialized
DEBUG - 2023-03-10 03:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 03:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:19:35 --> Input Class Initialized
INFO - 2023-03-10 03:19:35 --> Input Class Initialized
INFO - 2023-03-10 03:19:35 --> Language Class Initialized
INFO - 2023-03-10 03:19:35 --> Language Class Initialized
INFO - 2023-03-10 03:19:35 --> Loader Class Initialized
INFO - 2023-03-10 03:19:35 --> Loader Class Initialized
INFO - 2023-03-10 03:19:35 --> Controller Class Initialized
INFO - 2023-03-10 03:19:35 --> Controller Class Initialized
DEBUG - 2023-03-10 03:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 03:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:19:35 --> Final output sent to browser
DEBUG - 2023-03-10 03:19:35 --> Total execution time: 0.0060
INFO - 2023-03-10 03:19:35 --> Database Driver Class Initialized
INFO - 2023-03-10 03:19:35 --> Config Class Initialized
INFO - 2023-03-10 03:19:35 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:19:35 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:19:35 --> Utf8 Class Initialized
INFO - 2023-03-10 03:19:35 --> URI Class Initialized
INFO - 2023-03-10 03:19:35 --> Router Class Initialized
INFO - 2023-03-10 03:19:35 --> Output Class Initialized
INFO - 2023-03-10 03:19:35 --> Security Class Initialized
DEBUG - 2023-03-10 03:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:19:35 --> Input Class Initialized
INFO - 2023-03-10 03:19:35 --> Language Class Initialized
INFO - 2023-03-10 03:19:35 --> Loader Class Initialized
INFO - 2023-03-10 03:19:35 --> Controller Class Initialized
DEBUG - 2023-03-10 03:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:19:35 --> Database Driver Class Initialized
INFO - 2023-03-10 03:19:35 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:19:35 --> Model "Login_model" initialized
INFO - 2023-03-10 03:19:35 --> Database Driver Class Initialized
INFO - 2023-03-10 03:19:35 --> Final output sent to browser
DEBUG - 2023-03-10 03:19:35 --> Total execution time: 0.0304
INFO - 2023-03-10 03:19:35 --> Config Class Initialized
INFO - 2023-03-10 03:19:35 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:19:35 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:19:35 --> Utf8 Class Initialized
INFO - 2023-03-10 03:19:35 --> URI Class Initialized
INFO - 2023-03-10 03:19:35 --> Router Class Initialized
INFO - 2023-03-10 03:19:35 --> Output Class Initialized
INFO - 2023-03-10 03:19:35 --> Security Class Initialized
DEBUG - 2023-03-10 03:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:19:35 --> Input Class Initialized
INFO - 2023-03-10 03:19:35 --> Language Class Initialized
INFO - 2023-03-10 03:19:35 --> Loader Class Initialized
INFO - 2023-03-10 03:19:35 --> Controller Class Initialized
DEBUG - 2023-03-10 03:19:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:19:35 --> Database Driver Class Initialized
INFO - 2023-03-10 03:19:35 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:19:35 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:19:35 --> Final output sent to browser
DEBUG - 2023-03-10 03:19:35 --> Total execution time: 0.0369
INFO - 2023-03-10 03:19:35 --> Final output sent to browser
DEBUG - 2023-03-10 03:19:35 --> Total execution time: 0.0257
INFO - 2023-03-10 03:20:39 --> Config Class Initialized
INFO - 2023-03-10 03:20:39 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:20:39 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:20:39 --> Utf8 Class Initialized
INFO - 2023-03-10 03:20:39 --> URI Class Initialized
INFO - 2023-03-10 03:20:39 --> Router Class Initialized
INFO - 2023-03-10 03:20:39 --> Output Class Initialized
INFO - 2023-03-10 03:20:39 --> Security Class Initialized
DEBUG - 2023-03-10 03:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:20:39 --> Input Class Initialized
INFO - 2023-03-10 03:20:39 --> Language Class Initialized
INFO - 2023-03-10 03:20:39 --> Loader Class Initialized
INFO - 2023-03-10 03:20:39 --> Controller Class Initialized
DEBUG - 2023-03-10 03:20:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:20:39 --> Database Driver Class Initialized
INFO - 2023-03-10 03:20:39 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:20:40 --> Final output sent to browser
DEBUG - 2023-03-10 03:20:40 --> Total execution time: 0.4192
INFO - 2023-03-10 03:20:40 --> Config Class Initialized
INFO - 2023-03-10 03:20:40 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:20:40 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:20:40 --> Utf8 Class Initialized
INFO - 2023-03-10 03:20:40 --> URI Class Initialized
INFO - 2023-03-10 03:20:40 --> Router Class Initialized
INFO - 2023-03-10 03:20:40 --> Output Class Initialized
INFO - 2023-03-10 03:20:40 --> Security Class Initialized
DEBUG - 2023-03-10 03:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:20:40 --> Input Class Initialized
INFO - 2023-03-10 03:20:40 --> Language Class Initialized
INFO - 2023-03-10 03:20:40 --> Loader Class Initialized
INFO - 2023-03-10 03:20:40 --> Controller Class Initialized
DEBUG - 2023-03-10 03:20:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:20:40 --> Database Driver Class Initialized
INFO - 2023-03-10 03:20:40 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:20:40 --> Final output sent to browser
DEBUG - 2023-03-10 03:20:40 --> Total execution time: 0.5681
INFO - 2023-03-10 03:20:43 --> Config Class Initialized
INFO - 2023-03-10 03:20:43 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:20:43 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:20:43 --> Utf8 Class Initialized
INFO - 2023-03-10 03:20:43 --> URI Class Initialized
INFO - 2023-03-10 03:20:43 --> Router Class Initialized
INFO - 2023-03-10 03:20:43 --> Output Class Initialized
INFO - 2023-03-10 03:20:43 --> Security Class Initialized
DEBUG - 2023-03-10 03:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:20:43 --> Input Class Initialized
INFO - 2023-03-10 03:20:43 --> Language Class Initialized
INFO - 2023-03-10 03:20:43 --> Loader Class Initialized
INFO - 2023-03-10 03:20:43 --> Controller Class Initialized
DEBUG - 2023-03-10 03:20:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:20:43 --> Database Driver Class Initialized
INFO - 2023-03-10 03:20:43 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:20:43 --> Database Driver Class Initialized
INFO - 2023-03-10 03:20:43 --> Model "Login_model" initialized
INFO - 2023-03-10 03:20:43 --> Final output sent to browser
DEBUG - 2023-03-10 03:20:43 --> Total execution time: 0.3428
INFO - 2023-03-10 03:20:43 --> Config Class Initialized
INFO - 2023-03-10 03:20:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 03:20:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 03:20:44 --> Utf8 Class Initialized
INFO - 2023-03-10 03:20:44 --> URI Class Initialized
INFO - 2023-03-10 03:20:44 --> Router Class Initialized
INFO - 2023-03-10 03:20:44 --> Output Class Initialized
INFO - 2023-03-10 03:20:44 --> Security Class Initialized
DEBUG - 2023-03-10 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 03:20:44 --> Input Class Initialized
INFO - 2023-03-10 03:20:44 --> Language Class Initialized
INFO - 2023-03-10 03:20:44 --> Loader Class Initialized
INFO - 2023-03-10 03:20:44 --> Controller Class Initialized
DEBUG - 2023-03-10 03:20:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 03:20:44 --> Database Driver Class Initialized
INFO - 2023-03-10 03:20:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 03:20:44 --> Database Driver Class Initialized
INFO - 2023-03-10 03:20:44 --> Model "Login_model" initialized
INFO - 2023-03-10 03:20:44 --> Final output sent to browser
DEBUG - 2023-03-10 03:20:44 --> Total execution time: 0.3748
INFO - 2023-03-10 05:59:07 --> Config Class Initialized
INFO - 2023-03-10 05:59:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 05:59:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 05:59:07 --> Utf8 Class Initialized
INFO - 2023-03-10 05:59:07 --> URI Class Initialized
INFO - 2023-03-10 05:59:07 --> Router Class Initialized
INFO - 2023-03-10 05:59:07 --> Output Class Initialized
INFO - 2023-03-10 05:59:07 --> Security Class Initialized
DEBUG - 2023-03-10 05:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 05:59:07 --> Input Class Initialized
INFO - 2023-03-10 05:59:07 --> Language Class Initialized
INFO - 2023-03-10 05:59:07 --> Loader Class Initialized
INFO - 2023-03-10 05:59:07 --> Controller Class Initialized
DEBUG - 2023-03-10 05:59:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 05:59:07 --> Database Driver Class Initialized
INFO - 2023-03-10 05:59:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 05:59:07 --> Final output sent to browser
DEBUG - 2023-03-10 05:59:07 --> Total execution time: 0.0463
INFO - 2023-03-10 05:59:07 --> Config Class Initialized
INFO - 2023-03-10 05:59:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 05:59:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 05:59:07 --> Utf8 Class Initialized
INFO - 2023-03-10 05:59:07 --> URI Class Initialized
INFO - 2023-03-10 05:59:07 --> Router Class Initialized
INFO - 2023-03-10 05:59:07 --> Output Class Initialized
INFO - 2023-03-10 05:59:07 --> Security Class Initialized
DEBUG - 2023-03-10 05:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 05:59:07 --> Input Class Initialized
INFO - 2023-03-10 05:59:07 --> Language Class Initialized
INFO - 2023-03-10 05:59:07 --> Loader Class Initialized
INFO - 2023-03-10 05:59:07 --> Controller Class Initialized
DEBUG - 2023-03-10 05:59:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 05:59:07 --> Database Driver Class Initialized
INFO - 2023-03-10 05:59:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 05:59:07 --> Final output sent to browser
DEBUG - 2023-03-10 05:59:07 --> Total execution time: 0.0635
INFO - 2023-03-10 06:14:23 --> Config Class Initialized
INFO - 2023-03-10 06:14:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:14:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:14:23 --> Utf8 Class Initialized
INFO - 2023-03-10 06:14:23 --> URI Class Initialized
INFO - 2023-03-10 06:14:23 --> Router Class Initialized
INFO - 2023-03-10 06:14:23 --> Output Class Initialized
INFO - 2023-03-10 06:14:23 --> Security Class Initialized
DEBUG - 2023-03-10 06:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:14:23 --> Input Class Initialized
INFO - 2023-03-10 06:14:23 --> Language Class Initialized
INFO - 2023-03-10 06:14:23 --> Loader Class Initialized
INFO - 2023-03-10 06:14:23 --> Controller Class Initialized
DEBUG - 2023-03-10 06:14:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:14:23 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:14:23 --> Final output sent to browser
DEBUG - 2023-03-10 06:14:23 --> Total execution time: 0.1317
INFO - 2023-03-10 06:14:23 --> Config Class Initialized
INFO - 2023-03-10 06:14:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:14:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:14:23 --> Utf8 Class Initialized
INFO - 2023-03-10 06:14:23 --> URI Class Initialized
INFO - 2023-03-10 06:14:23 --> Router Class Initialized
INFO - 2023-03-10 06:14:23 --> Output Class Initialized
INFO - 2023-03-10 06:14:23 --> Security Class Initialized
DEBUG - 2023-03-10 06:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:14:23 --> Input Class Initialized
INFO - 2023-03-10 06:14:23 --> Language Class Initialized
INFO - 2023-03-10 06:14:23 --> Loader Class Initialized
INFO - 2023-03-10 06:14:23 --> Controller Class Initialized
DEBUG - 2023-03-10 06:14:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:14:23 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:14:23 --> Final output sent to browser
DEBUG - 2023-03-10 06:14:23 --> Total execution time: 0.0404
INFO - 2023-03-10 06:14:28 --> Config Class Initialized
INFO - 2023-03-10 06:14:28 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:14:28 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:14:28 --> Utf8 Class Initialized
INFO - 2023-03-10 06:14:28 --> URI Class Initialized
INFO - 2023-03-10 06:14:28 --> Router Class Initialized
INFO - 2023-03-10 06:14:28 --> Output Class Initialized
INFO - 2023-03-10 06:14:28 --> Security Class Initialized
DEBUG - 2023-03-10 06:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:14:28 --> Input Class Initialized
INFO - 2023-03-10 06:14:28 --> Language Class Initialized
INFO - 2023-03-10 06:14:28 --> Loader Class Initialized
INFO - 2023-03-10 06:14:28 --> Controller Class Initialized
DEBUG - 2023-03-10 06:14:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:14:28 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:28 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:14:28 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:28 --> Model "Login_model" initialized
INFO - 2023-03-10 06:14:28 --> Final output sent to browser
DEBUG - 2023-03-10 06:14:28 --> Total execution time: 0.0441
INFO - 2023-03-10 06:14:28 --> Config Class Initialized
INFO - 2023-03-10 06:14:28 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:14:28 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:14:28 --> Utf8 Class Initialized
INFO - 2023-03-10 06:14:28 --> URI Class Initialized
INFO - 2023-03-10 06:14:28 --> Router Class Initialized
INFO - 2023-03-10 06:14:28 --> Output Class Initialized
INFO - 2023-03-10 06:14:28 --> Security Class Initialized
DEBUG - 2023-03-10 06:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:14:28 --> Input Class Initialized
INFO - 2023-03-10 06:14:28 --> Language Class Initialized
INFO - 2023-03-10 06:14:28 --> Loader Class Initialized
INFO - 2023-03-10 06:14:28 --> Controller Class Initialized
DEBUG - 2023-03-10 06:14:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:14:28 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:28 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:14:28 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:28 --> Model "Login_model" initialized
INFO - 2023-03-10 06:14:28 --> Final output sent to browser
DEBUG - 2023-03-10 06:14:28 --> Total execution time: 0.1182
INFO - 2023-03-10 06:14:40 --> Config Class Initialized
INFO - 2023-03-10 06:14:40 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:14:40 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:14:40 --> Utf8 Class Initialized
INFO - 2023-03-10 06:14:40 --> URI Class Initialized
INFO - 2023-03-10 06:14:40 --> Router Class Initialized
INFO - 2023-03-10 06:14:40 --> Output Class Initialized
INFO - 2023-03-10 06:14:40 --> Security Class Initialized
DEBUG - 2023-03-10 06:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:14:40 --> Input Class Initialized
INFO - 2023-03-10 06:14:40 --> Language Class Initialized
INFO - 2023-03-10 06:14:40 --> Loader Class Initialized
INFO - 2023-03-10 06:14:40 --> Controller Class Initialized
DEBUG - 2023-03-10 06:14:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:14:40 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:40 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:14:40 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:40 --> Model "Login_model" initialized
INFO - 2023-03-10 06:14:40 --> Final output sent to browser
DEBUG - 2023-03-10 06:14:40 --> Total execution time: 0.2537
INFO - 2023-03-10 06:14:40 --> Config Class Initialized
INFO - 2023-03-10 06:14:40 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:14:40 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:14:40 --> Utf8 Class Initialized
INFO - 2023-03-10 06:14:40 --> URI Class Initialized
INFO - 2023-03-10 06:14:40 --> Router Class Initialized
INFO - 2023-03-10 06:14:40 --> Output Class Initialized
INFO - 2023-03-10 06:14:40 --> Security Class Initialized
DEBUG - 2023-03-10 06:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:14:40 --> Input Class Initialized
INFO - 2023-03-10 06:14:40 --> Language Class Initialized
INFO - 2023-03-10 06:14:40 --> Loader Class Initialized
INFO - 2023-03-10 06:14:40 --> Controller Class Initialized
DEBUG - 2023-03-10 06:14:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:14:40 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:40 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:14:40 --> Database Driver Class Initialized
INFO - 2023-03-10 06:14:41 --> Model "Login_model" initialized
INFO - 2023-03-10 06:14:41 --> Final output sent to browser
DEBUG - 2023-03-10 06:14:41 --> Total execution time: 0.0403
INFO - 2023-03-10 06:17:27 --> Config Class Initialized
INFO - 2023-03-10 06:17:27 --> Config Class Initialized
INFO - 2023-03-10 06:17:27 --> Hooks Class Initialized
INFO - 2023-03-10 06:17:27 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:17:27 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 06:17:27 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:17:27 --> Utf8 Class Initialized
INFO - 2023-03-10 06:17:27 --> Utf8 Class Initialized
INFO - 2023-03-10 06:17:27 --> URI Class Initialized
INFO - 2023-03-10 06:17:27 --> URI Class Initialized
INFO - 2023-03-10 06:17:27 --> Router Class Initialized
INFO - 2023-03-10 06:17:27 --> Router Class Initialized
INFO - 2023-03-10 06:17:27 --> Output Class Initialized
INFO - 2023-03-10 06:17:27 --> Output Class Initialized
INFO - 2023-03-10 06:17:27 --> Security Class Initialized
INFO - 2023-03-10 06:17:27 --> Security Class Initialized
DEBUG - 2023-03-10 06:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 06:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:17:27 --> Input Class Initialized
INFO - 2023-03-10 06:17:27 --> Input Class Initialized
INFO - 2023-03-10 06:17:27 --> Language Class Initialized
INFO - 2023-03-10 06:17:27 --> Language Class Initialized
INFO - 2023-03-10 06:17:27 --> Loader Class Initialized
INFO - 2023-03-10 06:17:27 --> Loader Class Initialized
INFO - 2023-03-10 06:17:27 --> Controller Class Initialized
INFO - 2023-03-10 06:17:27 --> Controller Class Initialized
DEBUG - 2023-03-10 06:17:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 06:17:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:17:27 --> Final output sent to browser
INFO - 2023-03-10 06:17:27 --> Database Driver Class Initialized
DEBUG - 2023-03-10 06:17:27 --> Total execution time: 0.0047
INFO - 2023-03-10 06:17:27 --> Config Class Initialized
INFO - 2023-03-10 06:17:27 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:17:27 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:17:27 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:17:27 --> Utf8 Class Initialized
INFO - 2023-03-10 06:17:27 --> URI Class Initialized
INFO - 2023-03-10 06:17:27 --> Router Class Initialized
INFO - 2023-03-10 06:17:27 --> Output Class Initialized
INFO - 2023-03-10 06:17:27 --> Security Class Initialized
DEBUG - 2023-03-10 06:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:17:27 --> Input Class Initialized
INFO - 2023-03-10 06:17:27 --> Language Class Initialized
INFO - 2023-03-10 06:17:27 --> Loader Class Initialized
INFO - 2023-03-10 06:17:27 --> Controller Class Initialized
DEBUG - 2023-03-10 06:17:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:17:27 --> Database Driver Class Initialized
INFO - 2023-03-10 06:17:27 --> Final output sent to browser
DEBUG - 2023-03-10 06:17:27 --> Total execution time: 0.0535
INFO - 2023-03-10 06:17:27 --> Config Class Initialized
INFO - 2023-03-10 06:17:27 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:17:27 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:17:27 --> Utf8 Class Initialized
INFO - 2023-03-10 06:17:27 --> URI Class Initialized
INFO - 2023-03-10 06:17:27 --> Router Class Initialized
INFO - 2023-03-10 06:17:27 --> Output Class Initialized
INFO - 2023-03-10 06:17:27 --> Security Class Initialized
DEBUG - 2023-03-10 06:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:17:27 --> Input Class Initialized
INFO - 2023-03-10 06:17:27 --> Language Class Initialized
INFO - 2023-03-10 06:17:27 --> Loader Class Initialized
INFO - 2023-03-10 06:17:27 --> Controller Class Initialized
DEBUG - 2023-03-10 06:17:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:17:27 --> Database Driver Class Initialized
INFO - 2023-03-10 06:17:27 --> Model "Login_model" initialized
INFO - 2023-03-10 06:17:27 --> Database Driver Class Initialized
INFO - 2023-03-10 06:17:27 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:17:27 --> Final output sent to browser
DEBUG - 2023-03-10 06:17:27 --> Total execution time: 0.0186
INFO - 2023-03-10 06:17:27 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:17:27 --> Final output sent to browser
DEBUG - 2023-03-10 06:17:27 --> Total execution time: 0.1103
INFO - 2023-03-10 06:17:30 --> Config Class Initialized
INFO - 2023-03-10 06:17:30 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:17:30 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:17:30 --> Utf8 Class Initialized
INFO - 2023-03-10 06:17:30 --> URI Class Initialized
INFO - 2023-03-10 06:17:30 --> Router Class Initialized
INFO - 2023-03-10 06:17:30 --> Output Class Initialized
INFO - 2023-03-10 06:17:30 --> Security Class Initialized
DEBUG - 2023-03-10 06:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:17:30 --> Input Class Initialized
INFO - 2023-03-10 06:17:30 --> Language Class Initialized
INFO - 2023-03-10 06:17:30 --> Loader Class Initialized
INFO - 2023-03-10 06:17:30 --> Controller Class Initialized
DEBUG - 2023-03-10 06:17:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:17:30 --> Database Driver Class Initialized
INFO - 2023-03-10 06:17:30 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:17:30 --> Final output sent to browser
DEBUG - 2023-03-10 06:17:30 --> Total execution time: 0.2301
INFO - 2023-03-10 06:17:30 --> Config Class Initialized
INFO - 2023-03-10 06:17:30 --> Hooks Class Initialized
DEBUG - 2023-03-10 06:17:30 --> UTF-8 Support Enabled
INFO - 2023-03-10 06:17:30 --> Utf8 Class Initialized
INFO - 2023-03-10 06:17:30 --> URI Class Initialized
INFO - 2023-03-10 06:17:30 --> Router Class Initialized
INFO - 2023-03-10 06:17:30 --> Output Class Initialized
INFO - 2023-03-10 06:17:30 --> Security Class Initialized
DEBUG - 2023-03-10 06:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 06:17:30 --> Input Class Initialized
INFO - 2023-03-10 06:17:30 --> Language Class Initialized
INFO - 2023-03-10 06:17:30 --> Loader Class Initialized
INFO - 2023-03-10 06:17:30 --> Controller Class Initialized
DEBUG - 2023-03-10 06:17:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 06:17:30 --> Database Driver Class Initialized
INFO - 2023-03-10 06:17:30 --> Model "Cluster_model" initialized
INFO - 2023-03-10 06:17:30 --> Final output sent to browser
DEBUG - 2023-03-10 06:17:30 --> Total execution time: 0.0531
INFO - 2023-03-10 07:21:45 --> Config Class Initialized
INFO - 2023-03-10 07:21:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:45 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:45 --> URI Class Initialized
INFO - 2023-03-10 07:21:45 --> Router Class Initialized
INFO - 2023-03-10 07:21:45 --> Output Class Initialized
INFO - 2023-03-10 07:21:45 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:45 --> Input Class Initialized
INFO - 2023-03-10 07:21:45 --> Language Class Initialized
INFO - 2023-03-10 07:21:45 --> Loader Class Initialized
INFO - 2023-03-10 07:21:45 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:45 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:45 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:45 --> Total execution time: 0.0191
INFO - 2023-03-10 07:21:45 --> Config Class Initialized
INFO - 2023-03-10 07:21:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:45 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:45 --> URI Class Initialized
INFO - 2023-03-10 07:21:45 --> Router Class Initialized
INFO - 2023-03-10 07:21:45 --> Output Class Initialized
INFO - 2023-03-10 07:21:45 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:45 --> Input Class Initialized
INFO - 2023-03-10 07:21:45 --> Language Class Initialized
INFO - 2023-03-10 07:21:45 --> Loader Class Initialized
INFO - 2023-03-10 07:21:45 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:45 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:45 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:45 --> Total execution time: 0.0948
INFO - 2023-03-10 07:21:48 --> Config Class Initialized
INFO - 2023-03-10 07:21:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:48 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:48 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:48 --> URI Class Initialized
INFO - 2023-03-10 07:21:48 --> Router Class Initialized
INFO - 2023-03-10 07:21:48 --> Output Class Initialized
INFO - 2023-03-10 07:21:48 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:48 --> Input Class Initialized
INFO - 2023-03-10 07:21:48 --> Language Class Initialized
INFO - 2023-03-10 07:21:48 --> Loader Class Initialized
INFO - 2023-03-10 07:21:48 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:48 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:48 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:48 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:48 --> Total execution time: 0.0466
INFO - 2023-03-10 07:21:48 --> Config Class Initialized
INFO - 2023-03-10 07:21:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:48 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:48 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:48 --> URI Class Initialized
INFO - 2023-03-10 07:21:48 --> Router Class Initialized
INFO - 2023-03-10 07:21:48 --> Output Class Initialized
INFO - 2023-03-10 07:21:48 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:48 --> Input Class Initialized
INFO - 2023-03-10 07:21:48 --> Language Class Initialized
INFO - 2023-03-10 07:21:48 --> Loader Class Initialized
INFO - 2023-03-10 07:21:48 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:48 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:48 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:48 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:48 --> Total execution time: 0.0787
INFO - 2023-03-10 07:21:50 --> Config Class Initialized
INFO - 2023-03-10 07:21:50 --> Config Class Initialized
INFO - 2023-03-10 07:21:50 --> Hooks Class Initialized
INFO - 2023-03-10 07:21:50 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:50 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 07:21:50 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:50 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:51 --> URI Class Initialized
INFO - 2023-03-10 07:21:51 --> Router Class Initialized
INFO - 2023-03-10 07:21:51 --> Output Class Initialized
INFO - 2023-03-10 07:21:51 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:51 --> Input Class Initialized
INFO - 2023-03-10 07:21:51 --> Language Class Initialized
INFO - 2023-03-10 07:21:51 --> Loader Class Initialized
INFO - 2023-03-10 07:21:51 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:51 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:51 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:51 --> URI Class Initialized
INFO - 2023-03-10 07:21:51 --> Router Class Initialized
INFO - 2023-03-10 07:21:51 --> Output Class Initialized
INFO - 2023-03-10 07:21:51 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:51 --> Input Class Initialized
INFO - 2023-03-10 07:21:51 --> Language Class Initialized
INFO - 2023-03-10 07:21:51 --> Loader Class Initialized
INFO - 2023-03-10 07:21:51 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:51 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:51 --> Total execution time: 0.0740
INFO - 2023-03-10 07:21:51 --> Config Class Initialized
INFO - 2023-03-10 07:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:51 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:51 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:51 --> URI Class Initialized
INFO - 2023-03-10 07:21:51 --> Router Class Initialized
INFO - 2023-03-10 07:21:51 --> Output Class Initialized
INFO - 2023-03-10 07:21:51 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:51 --> Input Class Initialized
INFO - 2023-03-10 07:21:51 --> Language Class Initialized
INFO - 2023-03-10 07:21:51 --> Loader Class Initialized
INFO - 2023-03-10 07:21:51 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:51 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:51 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:51 --> Total execution time: 0.1038
INFO - 2023-03-10 07:21:51 --> Config Class Initialized
INFO - 2023-03-10 07:21:51 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:51 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:51 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:51 --> URI Class Initialized
INFO - 2023-03-10 07:21:51 --> Router Class Initialized
INFO - 2023-03-10 07:21:51 --> Output Class Initialized
INFO - 2023-03-10 07:21:51 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:51 --> Input Class Initialized
INFO - 2023-03-10 07:21:51 --> Language Class Initialized
INFO - 2023-03-10 07:21:51 --> Loader Class Initialized
INFO - 2023-03-10 07:21:51 --> Model "Login_model" initialized
INFO - 2023-03-10 07:21:51 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:51 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:51 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:51 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:51 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:51 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:51 --> Total execution time: 0.0215
INFO - 2023-03-10 07:21:51 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:51 --> Total execution time: 0.0174
INFO - 2023-03-10 07:21:53 --> Config Class Initialized
INFO - 2023-03-10 07:21:53 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:53 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:53 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:53 --> URI Class Initialized
INFO - 2023-03-10 07:21:53 --> Router Class Initialized
INFO - 2023-03-10 07:21:53 --> Output Class Initialized
INFO - 2023-03-10 07:21:53 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:53 --> Input Class Initialized
INFO - 2023-03-10 07:21:53 --> Language Class Initialized
INFO - 2023-03-10 07:21:53 --> Loader Class Initialized
INFO - 2023-03-10 07:21:53 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:53 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:54 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:54 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:54 --> Model "Login_model" initialized
INFO - 2023-03-10 07:21:54 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:54 --> Total execution time: 0.0399
INFO - 2023-03-10 07:21:54 --> Config Class Initialized
INFO - 2023-03-10 07:21:54 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:54 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:54 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:54 --> URI Class Initialized
INFO - 2023-03-10 07:21:54 --> Router Class Initialized
INFO - 2023-03-10 07:21:54 --> Output Class Initialized
INFO - 2023-03-10 07:21:54 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:54 --> Input Class Initialized
INFO - 2023-03-10 07:21:54 --> Language Class Initialized
INFO - 2023-03-10 07:21:54 --> Loader Class Initialized
INFO - 2023-03-10 07:21:54 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:54 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:54 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:54 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:54 --> Model "Login_model" initialized
INFO - 2023-03-10 07:21:54 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:54 --> Total execution time: 0.1220
INFO - 2023-03-10 07:21:59 --> Config Class Initialized
INFO - 2023-03-10 07:21:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:59 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:59 --> URI Class Initialized
INFO - 2023-03-10 07:21:59 --> Router Class Initialized
INFO - 2023-03-10 07:21:59 --> Output Class Initialized
INFO - 2023-03-10 07:21:59 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:59 --> Input Class Initialized
INFO - 2023-03-10 07:21:59 --> Language Class Initialized
INFO - 2023-03-10 07:21:59 --> Loader Class Initialized
INFO - 2023-03-10 07:21:59 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:59 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:59 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:59 --> Total execution time: 0.0156
INFO - 2023-03-10 07:21:59 --> Config Class Initialized
INFO - 2023-03-10 07:21:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:21:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:21:59 --> Utf8 Class Initialized
INFO - 2023-03-10 07:21:59 --> URI Class Initialized
INFO - 2023-03-10 07:21:59 --> Router Class Initialized
INFO - 2023-03-10 07:21:59 --> Output Class Initialized
INFO - 2023-03-10 07:21:59 --> Security Class Initialized
DEBUG - 2023-03-10 07:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:21:59 --> Input Class Initialized
INFO - 2023-03-10 07:21:59 --> Language Class Initialized
INFO - 2023-03-10 07:21:59 --> Loader Class Initialized
INFO - 2023-03-10 07:21:59 --> Controller Class Initialized
DEBUG - 2023-03-10 07:21:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:21:59 --> Database Driver Class Initialized
INFO - 2023-03-10 07:21:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:21:59 --> Final output sent to browser
DEBUG - 2023-03-10 07:21:59 --> Total execution time: 0.0526
INFO - 2023-03-10 07:22:01 --> Config Class Initialized
INFO - 2023-03-10 07:22:01 --> Config Class Initialized
INFO - 2023-03-10 07:22:01 --> Hooks Class Initialized
INFO - 2023-03-10 07:22:01 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:01 --> Utf8 Class Initialized
DEBUG - 2023-03-10 07:22:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:01 --> URI Class Initialized
INFO - 2023-03-10 07:22:01 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:01 --> Router Class Initialized
INFO - 2023-03-10 07:22:01 --> URI Class Initialized
INFO - 2023-03-10 07:22:01 --> Output Class Initialized
INFO - 2023-03-10 07:22:01 --> Router Class Initialized
INFO - 2023-03-10 07:22:01 --> Security Class Initialized
INFO - 2023-03-10 07:22:01 --> Output Class Initialized
DEBUG - 2023-03-10 07:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:01 --> Security Class Initialized
INFO - 2023-03-10 07:22:01 --> Input Class Initialized
DEBUG - 2023-03-10 07:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:01 --> Language Class Initialized
INFO - 2023-03-10 07:22:01 --> Input Class Initialized
INFO - 2023-03-10 07:22:01 --> Language Class Initialized
INFO - 2023-03-10 07:22:01 --> Loader Class Initialized
INFO - 2023-03-10 07:22:01 --> Loader Class Initialized
INFO - 2023-03-10 07:22:01 --> Controller Class Initialized
INFO - 2023-03-10 07:22:01 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 07:22:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:01 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:01 --> Total execution time: 0.0317
INFO - 2023-03-10 07:22:01 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:01 --> Config Class Initialized
INFO - 2023-03-10 07:22:01 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:01 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:01 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:01 --> URI Class Initialized
INFO - 2023-03-10 07:22:01 --> Router Class Initialized
INFO - 2023-03-10 07:22:01 --> Final output sent to browser
INFO - 2023-03-10 07:22:01 --> Output Class Initialized
DEBUG - 2023-03-10 07:22:01 --> Total execution time: 0.0457
INFO - 2023-03-10 07:22:01 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:01 --> Input Class Initialized
INFO - 2023-03-10 07:22:01 --> Config Class Initialized
INFO - 2023-03-10 07:22:01 --> Language Class Initialized
INFO - 2023-03-10 07:22:01 --> Hooks Class Initialized
INFO - 2023-03-10 07:22:01 --> Loader Class Initialized
DEBUG - 2023-03-10 07:22:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:01 --> Controller Class Initialized
INFO - 2023-03-10 07:22:01 --> Utf8 Class Initialized
DEBUG - 2023-03-10 07:22:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:01 --> URI Class Initialized
INFO - 2023-03-10 07:22:01 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:01 --> Router Class Initialized
INFO - 2023-03-10 07:22:01 --> Output Class Initialized
INFO - 2023-03-10 07:22:01 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:01 --> Input Class Initialized
INFO - 2023-03-10 07:22:01 --> Language Class Initialized
INFO - 2023-03-10 07:22:01 --> Loader Class Initialized
INFO - 2023-03-10 07:22:01 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:01 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:01 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:01 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:01 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:01 --> Total execution time: 0.0491
INFO - 2023-03-10 07:22:01 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:01 --> Total execution time: 0.0239
INFO - 2023-03-10 07:22:05 --> Config Class Initialized
INFO - 2023-03-10 07:22:05 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:05 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:05 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:05 --> URI Class Initialized
INFO - 2023-03-10 07:22:05 --> Router Class Initialized
INFO - 2023-03-10 07:22:05 --> Output Class Initialized
INFO - 2023-03-10 07:22:05 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:05 --> Input Class Initialized
INFO - 2023-03-10 07:22:05 --> Language Class Initialized
INFO - 2023-03-10 07:22:05 --> Loader Class Initialized
INFO - 2023-03-10 07:22:05 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:05 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:05 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:05 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:05 --> Total execution time: 0.0202
INFO - 2023-03-10 07:22:05 --> Config Class Initialized
INFO - 2023-03-10 07:22:05 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:05 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:05 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:05 --> URI Class Initialized
INFO - 2023-03-10 07:22:05 --> Router Class Initialized
INFO - 2023-03-10 07:22:05 --> Output Class Initialized
INFO - 2023-03-10 07:22:05 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:05 --> Input Class Initialized
INFO - 2023-03-10 07:22:05 --> Language Class Initialized
INFO - 2023-03-10 07:22:05 --> Loader Class Initialized
INFO - 2023-03-10 07:22:05 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:05 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:05 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:05 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:05 --> Total execution time: 0.1054
INFO - 2023-03-10 07:22:08 --> Config Class Initialized
INFO - 2023-03-10 07:22:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:08 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:08 --> URI Class Initialized
INFO - 2023-03-10 07:22:08 --> Router Class Initialized
INFO - 2023-03-10 07:22:08 --> Output Class Initialized
INFO - 2023-03-10 07:22:08 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:08 --> Input Class Initialized
INFO - 2023-03-10 07:22:08 --> Language Class Initialized
INFO - 2023-03-10 07:22:08 --> Loader Class Initialized
INFO - 2023-03-10 07:22:08 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:08 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:08 --> Total execution time: 0.0055
INFO - 2023-03-10 07:22:08 --> Config Class Initialized
INFO - 2023-03-10 07:22:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:08 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:08 --> URI Class Initialized
INFO - 2023-03-10 07:22:08 --> Router Class Initialized
INFO - 2023-03-10 07:22:08 --> Output Class Initialized
INFO - 2023-03-10 07:22:08 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:08 --> Input Class Initialized
INFO - 2023-03-10 07:22:08 --> Language Class Initialized
INFO - 2023-03-10 07:22:08 --> Loader Class Initialized
INFO - 2023-03-10 07:22:08 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:08 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:08 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:08 --> Total execution time: 0.0128
INFO - 2023-03-10 07:22:11 --> Config Class Initialized
INFO - 2023-03-10 07:22:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:11 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:11 --> URI Class Initialized
INFO - 2023-03-10 07:22:11 --> Router Class Initialized
INFO - 2023-03-10 07:22:11 --> Output Class Initialized
INFO - 2023-03-10 07:22:11 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:11 --> Input Class Initialized
INFO - 2023-03-10 07:22:11 --> Language Class Initialized
INFO - 2023-03-10 07:22:11 --> Loader Class Initialized
INFO - 2023-03-10 07:22:11 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:11 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:11 --> Total execution time: 0.0041
INFO - 2023-03-10 07:22:11 --> Config Class Initialized
INFO - 2023-03-10 07:22:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:11 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:11 --> URI Class Initialized
INFO - 2023-03-10 07:22:11 --> Router Class Initialized
INFO - 2023-03-10 07:22:11 --> Output Class Initialized
INFO - 2023-03-10 07:22:11 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:11 --> Input Class Initialized
INFO - 2023-03-10 07:22:11 --> Language Class Initialized
INFO - 2023-03-10 07:22:11 --> Loader Class Initialized
INFO - 2023-03-10 07:22:11 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:11 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:11 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:11 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:11 --> Total execution time: 0.0111
INFO - 2023-03-10 07:22:15 --> Config Class Initialized
INFO - 2023-03-10 07:22:15 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:15 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:15 --> URI Class Initialized
INFO - 2023-03-10 07:22:15 --> Router Class Initialized
INFO - 2023-03-10 07:22:15 --> Output Class Initialized
INFO - 2023-03-10 07:22:15 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:15 --> Input Class Initialized
INFO - 2023-03-10 07:22:15 --> Language Class Initialized
INFO - 2023-03-10 07:22:15 --> Loader Class Initialized
INFO - 2023-03-10 07:22:15 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:15 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:15 --> Config Class Initialized
INFO - 2023-03-10 07:22:15 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:15 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:15 --> URI Class Initialized
INFO - 2023-03-10 07:22:15 --> Router Class Initialized
INFO - 2023-03-10 07:22:15 --> Output Class Initialized
INFO - 2023-03-10 07:22:15 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:15 --> Input Class Initialized
INFO - 2023-03-10 07:22:15 --> Language Class Initialized
INFO - 2023-03-10 07:22:15 --> Loader Class Initialized
INFO - 2023-03-10 07:22:15 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:15 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:16 --> Config Class Initialized
INFO - 2023-03-10 07:22:16 --> Config Class Initialized
INFO - 2023-03-10 07:22:16 --> Hooks Class Initialized
INFO - 2023-03-10 07:22:16 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 07:22:16 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:16 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:16 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:16 --> URI Class Initialized
INFO - 2023-03-10 07:22:16 --> URI Class Initialized
INFO - 2023-03-10 07:22:16 --> Router Class Initialized
INFO - 2023-03-10 07:22:16 --> Router Class Initialized
INFO - 2023-03-10 07:22:16 --> Output Class Initialized
INFO - 2023-03-10 07:22:16 --> Output Class Initialized
INFO - 2023-03-10 07:22:16 --> Security Class Initialized
INFO - 2023-03-10 07:22:16 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:16 --> Input Class Initialized
INFO - 2023-03-10 07:22:16 --> Input Class Initialized
INFO - 2023-03-10 07:22:16 --> Language Class Initialized
INFO - 2023-03-10 07:22:16 --> Language Class Initialized
INFO - 2023-03-10 07:22:16 --> Loader Class Initialized
INFO - 2023-03-10 07:22:16 --> Loader Class Initialized
INFO - 2023-03-10 07:22:16 --> Controller Class Initialized
INFO - 2023-03-10 07:22:16 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 07:22:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:16 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:16 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:16 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:16 --> Total execution time: 0.0174
INFO - 2023-03-10 07:22:16 --> Config Class Initialized
INFO - 2023-03-10 07:22:16 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:22:16 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:22:16 --> Utf8 Class Initialized
INFO - 2023-03-10 07:22:16 --> URI Class Initialized
INFO - 2023-03-10 07:22:16 --> Router Class Initialized
INFO - 2023-03-10 07:22:16 --> Output Class Initialized
INFO - 2023-03-10 07:22:16 --> Security Class Initialized
DEBUG - 2023-03-10 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:22:16 --> Input Class Initialized
INFO - 2023-03-10 07:22:16 --> Language Class Initialized
INFO - 2023-03-10 07:22:16 --> Loader Class Initialized
INFO - 2023-03-10 07:22:16 --> Controller Class Initialized
DEBUG - 2023-03-10 07:22:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:22:16 --> Database Driver Class Initialized
INFO - 2023-03-10 07:22:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:22:16 --> Final output sent to browser
DEBUG - 2023-03-10 07:22:16 --> Total execution time: 0.0518
INFO - 2023-03-10 07:28:45 --> Config Class Initialized
INFO - 2023-03-10 07:28:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:28:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:28:45 --> Utf8 Class Initialized
INFO - 2023-03-10 07:28:45 --> URI Class Initialized
INFO - 2023-03-10 07:28:45 --> Router Class Initialized
INFO - 2023-03-10 07:28:45 --> Output Class Initialized
INFO - 2023-03-10 07:28:45 --> Security Class Initialized
DEBUG - 2023-03-10 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:28:45 --> Input Class Initialized
INFO - 2023-03-10 07:28:45 --> Language Class Initialized
INFO - 2023-03-10 07:28:45 --> Loader Class Initialized
INFO - 2023-03-10 07:28:45 --> Controller Class Initialized
DEBUG - 2023-03-10 07:28:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:28:45 --> Final output sent to browser
DEBUG - 2023-03-10 07:28:45 --> Total execution time: 0.0037
INFO - 2023-03-10 07:28:45 --> Config Class Initialized
INFO - 2023-03-10 07:28:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:28:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:28:45 --> Utf8 Class Initialized
INFO - 2023-03-10 07:28:45 --> URI Class Initialized
INFO - 2023-03-10 07:28:45 --> Router Class Initialized
INFO - 2023-03-10 07:28:45 --> Output Class Initialized
INFO - 2023-03-10 07:28:45 --> Security Class Initialized
DEBUG - 2023-03-10 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:28:45 --> Input Class Initialized
INFO - 2023-03-10 07:28:45 --> Language Class Initialized
INFO - 2023-03-10 07:28:45 --> Loader Class Initialized
INFO - 2023-03-10 07:28:45 --> Controller Class Initialized
DEBUG - 2023-03-10 07:28:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:28:45 --> Database Driver Class Initialized
INFO - 2023-03-10 07:28:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:28:45 --> Final output sent to browser
DEBUG - 2023-03-10 07:28:45 --> Total execution time: 0.0108
INFO - 2023-03-10 07:28:46 --> Config Class Initialized
INFO - 2023-03-10 07:28:46 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:28:46 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:28:46 --> Utf8 Class Initialized
INFO - 2023-03-10 07:28:46 --> URI Class Initialized
INFO - 2023-03-10 07:28:46 --> Router Class Initialized
INFO - 2023-03-10 07:28:46 --> Output Class Initialized
INFO - 2023-03-10 07:28:46 --> Security Class Initialized
DEBUG - 2023-03-10 07:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:28:46 --> Input Class Initialized
INFO - 2023-03-10 07:28:46 --> Language Class Initialized
INFO - 2023-03-10 07:28:46 --> Loader Class Initialized
INFO - 2023-03-10 07:28:46 --> Controller Class Initialized
DEBUG - 2023-03-10 07:28:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:28:46 --> Database Driver Class Initialized
INFO - 2023-03-10 07:28:46 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:28:46 --> Final output sent to browser
DEBUG - 2023-03-10 07:28:46 --> Total execution time: 0.0130
INFO - 2023-03-10 07:28:46 --> Config Class Initialized
INFO - 2023-03-10 07:28:46 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:28:46 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:28:46 --> Utf8 Class Initialized
INFO - 2023-03-10 07:28:46 --> URI Class Initialized
INFO - 2023-03-10 07:28:46 --> Router Class Initialized
INFO - 2023-03-10 07:28:46 --> Output Class Initialized
INFO - 2023-03-10 07:28:46 --> Security Class Initialized
DEBUG - 2023-03-10 07:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:28:46 --> Input Class Initialized
INFO - 2023-03-10 07:28:46 --> Language Class Initialized
INFO - 2023-03-10 07:28:46 --> Loader Class Initialized
INFO - 2023-03-10 07:28:46 --> Controller Class Initialized
DEBUG - 2023-03-10 07:28:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:28:46 --> Database Driver Class Initialized
INFO - 2023-03-10 07:28:46 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:28:46 --> Final output sent to browser
DEBUG - 2023-03-10 07:28:46 --> Total execution time: 0.0539
INFO - 2023-03-10 07:28:49 --> Config Class Initialized
INFO - 2023-03-10 07:28:49 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:28:49 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:28:49 --> Utf8 Class Initialized
INFO - 2023-03-10 07:28:49 --> URI Class Initialized
INFO - 2023-03-10 07:28:49 --> Router Class Initialized
INFO - 2023-03-10 07:28:49 --> Output Class Initialized
INFO - 2023-03-10 07:28:49 --> Security Class Initialized
DEBUG - 2023-03-10 07:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:28:49 --> Input Class Initialized
INFO - 2023-03-10 07:28:49 --> Language Class Initialized
INFO - 2023-03-10 07:28:49 --> Loader Class Initialized
INFO - 2023-03-10 07:28:49 --> Controller Class Initialized
DEBUG - 2023-03-10 07:28:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:28:49 --> Database Driver Class Initialized
INFO - 2023-03-10 07:28:49 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:28:49 --> Final output sent to browser
DEBUG - 2023-03-10 07:28:49 --> Total execution time: 0.0167
INFO - 2023-03-10 07:28:49 --> Config Class Initialized
INFO - 2023-03-10 07:28:49 --> Hooks Class Initialized
DEBUG - 2023-03-10 07:28:49 --> UTF-8 Support Enabled
INFO - 2023-03-10 07:28:49 --> Utf8 Class Initialized
INFO - 2023-03-10 07:28:49 --> URI Class Initialized
INFO - 2023-03-10 07:28:49 --> Router Class Initialized
INFO - 2023-03-10 07:28:49 --> Output Class Initialized
INFO - 2023-03-10 07:28:49 --> Security Class Initialized
DEBUG - 2023-03-10 07:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 07:28:49 --> Input Class Initialized
INFO - 2023-03-10 07:28:49 --> Language Class Initialized
INFO - 2023-03-10 07:28:49 --> Loader Class Initialized
INFO - 2023-03-10 07:28:49 --> Controller Class Initialized
DEBUG - 2023-03-10 07:28:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 07:28:49 --> Database Driver Class Initialized
INFO - 2023-03-10 07:28:49 --> Model "Cluster_model" initialized
INFO - 2023-03-10 07:28:49 --> Final output sent to browser
DEBUG - 2023-03-10 07:28:49 --> Total execution time: 0.0583
INFO - 2023-03-10 08:36:02 --> Config Class Initialized
INFO - 2023-03-10 08:36:02 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:36:02 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:36:02 --> Utf8 Class Initialized
INFO - 2023-03-10 08:36:02 --> URI Class Initialized
INFO - 2023-03-10 08:36:02 --> Router Class Initialized
INFO - 2023-03-10 08:36:02 --> Output Class Initialized
INFO - 2023-03-10 08:36:02 --> Security Class Initialized
DEBUG - 2023-03-10 08:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:36:02 --> Input Class Initialized
INFO - 2023-03-10 08:36:02 --> Language Class Initialized
INFO - 2023-03-10 08:36:02 --> Loader Class Initialized
INFO - 2023-03-10 08:36:02 --> Controller Class Initialized
DEBUG - 2023-03-10 08:36:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:36:02 --> Database Driver Class Initialized
INFO - 2023-03-10 08:36:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:36:02 --> Database Driver Class Initialized
INFO - 2023-03-10 08:36:02 --> Model "Login_model" initialized
INFO - 2023-03-10 08:36:02 --> Final output sent to browser
DEBUG - 2023-03-10 08:36:02 --> Total execution time: 0.1152
INFO - 2023-03-10 08:36:02 --> Config Class Initialized
INFO - 2023-03-10 08:36:02 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:36:02 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:36:02 --> Utf8 Class Initialized
INFO - 2023-03-10 08:36:02 --> URI Class Initialized
INFO - 2023-03-10 08:36:02 --> Router Class Initialized
INFO - 2023-03-10 08:36:02 --> Output Class Initialized
INFO - 2023-03-10 08:36:02 --> Security Class Initialized
DEBUG - 2023-03-10 08:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:36:02 --> Input Class Initialized
INFO - 2023-03-10 08:36:02 --> Language Class Initialized
INFO - 2023-03-10 08:36:02 --> Loader Class Initialized
INFO - 2023-03-10 08:36:02 --> Controller Class Initialized
DEBUG - 2023-03-10 08:36:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:36:02 --> Database Driver Class Initialized
INFO - 2023-03-10 08:36:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:36:02 --> Database Driver Class Initialized
INFO - 2023-03-10 08:36:02 --> Model "Login_model" initialized
INFO - 2023-03-10 08:36:02 --> Final output sent to browser
DEBUG - 2023-03-10 08:36:02 --> Total execution time: 0.0328
INFO - 2023-03-10 08:36:06 --> Config Class Initialized
INFO - 2023-03-10 08:36:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:36:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:36:06 --> Utf8 Class Initialized
INFO - 2023-03-10 08:36:06 --> URI Class Initialized
INFO - 2023-03-10 08:36:06 --> Router Class Initialized
INFO - 2023-03-10 08:36:06 --> Output Class Initialized
INFO - 2023-03-10 08:36:06 --> Security Class Initialized
DEBUG - 2023-03-10 08:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:36:06 --> Input Class Initialized
INFO - 2023-03-10 08:36:06 --> Language Class Initialized
INFO - 2023-03-10 08:36:06 --> Loader Class Initialized
INFO - 2023-03-10 08:36:06 --> Controller Class Initialized
DEBUG - 2023-03-10 08:36:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:36:06 --> Database Driver Class Initialized
INFO - 2023-03-10 08:36:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:36:06 --> Final output sent to browser
DEBUG - 2023-03-10 08:36:06 --> Total execution time: 0.0179
INFO - 2023-03-10 08:36:06 --> Config Class Initialized
INFO - 2023-03-10 08:36:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:36:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:36:06 --> Utf8 Class Initialized
INFO - 2023-03-10 08:36:06 --> URI Class Initialized
INFO - 2023-03-10 08:36:06 --> Router Class Initialized
INFO - 2023-03-10 08:36:06 --> Output Class Initialized
INFO - 2023-03-10 08:36:06 --> Security Class Initialized
DEBUG - 2023-03-10 08:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:36:06 --> Input Class Initialized
INFO - 2023-03-10 08:36:06 --> Language Class Initialized
INFO - 2023-03-10 08:36:06 --> Loader Class Initialized
INFO - 2023-03-10 08:36:06 --> Controller Class Initialized
DEBUG - 2023-03-10 08:36:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:36:06 --> Database Driver Class Initialized
INFO - 2023-03-10 08:36:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:36:06 --> Final output sent to browser
DEBUG - 2023-03-10 08:36:06 --> Total execution time: 0.0515
INFO - 2023-03-10 08:58:21 --> Config Class Initialized
INFO - 2023-03-10 08:58:21 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:58:21 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:58:21 --> Utf8 Class Initialized
INFO - 2023-03-10 08:58:21 --> URI Class Initialized
INFO - 2023-03-10 08:58:21 --> Router Class Initialized
INFO - 2023-03-10 08:58:21 --> Output Class Initialized
INFO - 2023-03-10 08:58:21 --> Security Class Initialized
DEBUG - 2023-03-10 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:58:21 --> Input Class Initialized
INFO - 2023-03-10 08:58:21 --> Language Class Initialized
INFO - 2023-03-10 08:58:21 --> Loader Class Initialized
INFO - 2023-03-10 08:58:21 --> Controller Class Initialized
INFO - 2023-03-10 08:58:21 --> Helper loaded: form_helper
INFO - 2023-03-10 08:58:21 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:58:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:58:21 --> Model "Change_model" initialized
INFO - 2023-03-10 08:58:21 --> Model "Grafana_model" initialized
INFO - 2023-03-10 08:58:21 --> Final output sent to browser
DEBUG - 2023-03-10 08:58:21 --> Total execution time: 0.0265
INFO - 2023-03-10 08:58:21 --> Config Class Initialized
INFO - 2023-03-10 08:58:21 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:58:21 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:58:21 --> Utf8 Class Initialized
INFO - 2023-03-10 08:58:21 --> URI Class Initialized
INFO - 2023-03-10 08:58:21 --> Router Class Initialized
INFO - 2023-03-10 08:58:21 --> Output Class Initialized
INFO - 2023-03-10 08:58:21 --> Security Class Initialized
DEBUG - 2023-03-10 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:58:21 --> Input Class Initialized
INFO - 2023-03-10 08:58:21 --> Language Class Initialized
INFO - 2023-03-10 08:58:21 --> Loader Class Initialized
INFO - 2023-03-10 08:58:21 --> Controller Class Initialized
INFO - 2023-03-10 08:58:21 --> Helper loaded: form_helper
INFO - 2023-03-10 08:58:21 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:58:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:58:21 --> Final output sent to browser
DEBUG - 2023-03-10 08:58:21 --> Total execution time: 0.0426
INFO - 2023-03-10 08:58:21 --> Config Class Initialized
INFO - 2023-03-10 08:58:21 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:58:21 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:58:21 --> Utf8 Class Initialized
INFO - 2023-03-10 08:58:21 --> URI Class Initialized
INFO - 2023-03-10 08:58:21 --> Router Class Initialized
INFO - 2023-03-10 08:58:21 --> Output Class Initialized
INFO - 2023-03-10 08:58:21 --> Security Class Initialized
DEBUG - 2023-03-10 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:58:21 --> Input Class Initialized
INFO - 2023-03-10 08:58:21 --> Language Class Initialized
INFO - 2023-03-10 08:58:21 --> Loader Class Initialized
INFO - 2023-03-10 08:58:21 --> Controller Class Initialized
INFO - 2023-03-10 08:58:21 --> Helper loaded: form_helper
INFO - 2023-03-10 08:58:21 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:58:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:58:21 --> Database Driver Class Initialized
INFO - 2023-03-10 08:58:21 --> Model "Login_model" initialized
INFO - 2023-03-10 08:58:21 --> Final output sent to browser
DEBUG - 2023-03-10 08:58:21 --> Total execution time: 0.0127
INFO - 2023-03-10 08:58:31 --> Config Class Initialized
INFO - 2023-03-10 08:58:31 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:58:31 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:58:31 --> Utf8 Class Initialized
INFO - 2023-03-10 08:58:31 --> URI Class Initialized
INFO - 2023-03-10 08:58:31 --> Router Class Initialized
INFO - 2023-03-10 08:58:31 --> Output Class Initialized
INFO - 2023-03-10 08:58:31 --> Security Class Initialized
DEBUG - 2023-03-10 08:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:58:31 --> Input Class Initialized
INFO - 2023-03-10 08:58:31 --> Language Class Initialized
INFO - 2023-03-10 08:58:31 --> Loader Class Initialized
INFO - 2023-03-10 08:58:31 --> Controller Class Initialized
INFO - 2023-03-10 08:58:31 --> Helper loaded: form_helper
INFO - 2023-03-10 08:58:31 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:58:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:58:31 --> Model "Change_model" initialized
INFO - 2023-03-10 08:58:31 --> Model "Grafana_model" initialized
INFO - 2023-03-10 08:58:31 --> Final output sent to browser
DEBUG - 2023-03-10 08:58:31 --> Total execution time: 0.0238
INFO - 2023-03-10 08:58:31 --> Config Class Initialized
INFO - 2023-03-10 08:58:31 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:58:31 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:58:31 --> Utf8 Class Initialized
INFO - 2023-03-10 08:58:31 --> URI Class Initialized
INFO - 2023-03-10 08:58:31 --> Router Class Initialized
INFO - 2023-03-10 08:58:31 --> Output Class Initialized
INFO - 2023-03-10 08:58:31 --> Security Class Initialized
DEBUG - 2023-03-10 08:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:58:31 --> Input Class Initialized
INFO - 2023-03-10 08:58:31 --> Language Class Initialized
INFO - 2023-03-10 08:58:31 --> Loader Class Initialized
INFO - 2023-03-10 08:58:31 --> Controller Class Initialized
INFO - 2023-03-10 08:58:31 --> Helper loaded: form_helper
INFO - 2023-03-10 08:58:31 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:58:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:58:31 --> Final output sent to browser
DEBUG - 2023-03-10 08:58:31 --> Total execution time: 0.0018
INFO - 2023-03-10 08:58:31 --> Config Class Initialized
INFO - 2023-03-10 08:58:31 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:58:31 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:58:31 --> Utf8 Class Initialized
INFO - 2023-03-10 08:58:31 --> URI Class Initialized
INFO - 2023-03-10 08:58:31 --> Router Class Initialized
INFO - 2023-03-10 08:58:31 --> Output Class Initialized
INFO - 2023-03-10 08:58:31 --> Security Class Initialized
DEBUG - 2023-03-10 08:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:58:31 --> Input Class Initialized
INFO - 2023-03-10 08:58:31 --> Language Class Initialized
INFO - 2023-03-10 08:58:31 --> Loader Class Initialized
INFO - 2023-03-10 08:58:31 --> Controller Class Initialized
INFO - 2023-03-10 08:58:31 --> Helper loaded: form_helper
INFO - 2023-03-10 08:58:31 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:58:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:58:31 --> Database Driver Class Initialized
INFO - 2023-03-10 08:58:31 --> Model "Login_model" initialized
INFO - 2023-03-10 08:58:31 --> Final output sent to browser
DEBUG - 2023-03-10 08:58:31 --> Total execution time: 0.0130
INFO - 2023-03-10 08:59:01 --> Config Class Initialized
INFO - 2023-03-10 08:59:01 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:01 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:01 --> URI Class Initialized
INFO - 2023-03-10 08:59:01 --> Router Class Initialized
INFO - 2023-03-10 08:59:01 --> Output Class Initialized
INFO - 2023-03-10 08:59:01 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:01 --> Input Class Initialized
INFO - 2023-03-10 08:59:01 --> Language Class Initialized
INFO - 2023-03-10 08:59:01 --> Loader Class Initialized
INFO - 2023-03-10 08:59:01 --> Controller Class Initialized
INFO - 2023-03-10 08:59:01 --> Helper loaded: form_helper
INFO - 2023-03-10 08:59:01 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:59:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:01 --> Model "Change_model" initialized
INFO - 2023-03-10 08:59:01 --> Model "Grafana_model" initialized
INFO - 2023-03-10 08:59:01 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:01 --> Total execution time: 0.0245
INFO - 2023-03-10 08:59:01 --> Config Class Initialized
INFO - 2023-03-10 08:59:01 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:01 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:01 --> URI Class Initialized
INFO - 2023-03-10 08:59:01 --> Router Class Initialized
INFO - 2023-03-10 08:59:01 --> Output Class Initialized
INFO - 2023-03-10 08:59:01 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:01 --> Input Class Initialized
INFO - 2023-03-10 08:59:01 --> Language Class Initialized
INFO - 2023-03-10 08:59:01 --> Loader Class Initialized
INFO - 2023-03-10 08:59:01 --> Controller Class Initialized
INFO - 2023-03-10 08:59:01 --> Helper loaded: form_helper
INFO - 2023-03-10 08:59:01 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:59:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:01 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:01 --> Total execution time: 0.0020
INFO - 2023-03-10 08:59:01 --> Config Class Initialized
INFO - 2023-03-10 08:59:01 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:01 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:01 --> URI Class Initialized
INFO - 2023-03-10 08:59:01 --> Router Class Initialized
INFO - 2023-03-10 08:59:01 --> Output Class Initialized
INFO - 2023-03-10 08:59:01 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:01 --> Input Class Initialized
INFO - 2023-03-10 08:59:01 --> Language Class Initialized
INFO - 2023-03-10 08:59:01 --> Loader Class Initialized
INFO - 2023-03-10 08:59:01 --> Controller Class Initialized
INFO - 2023-03-10 08:59:01 --> Helper loaded: form_helper
INFO - 2023-03-10 08:59:01 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:59:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:01 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:01 --> Model "Login_model" initialized
INFO - 2023-03-10 08:59:01 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:01 --> Total execution time: 0.0107
INFO - 2023-03-10 08:59:22 --> Config Class Initialized
INFO - 2023-03-10 08:59:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:22 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:22 --> URI Class Initialized
INFO - 2023-03-10 08:59:22 --> Router Class Initialized
INFO - 2023-03-10 08:59:22 --> Output Class Initialized
INFO - 2023-03-10 08:59:22 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:22 --> Input Class Initialized
INFO - 2023-03-10 08:59:22 --> Language Class Initialized
INFO - 2023-03-10 08:59:22 --> Loader Class Initialized
INFO - 2023-03-10 08:59:22 --> Controller Class Initialized
INFO - 2023-03-10 08:59:22 --> Helper loaded: form_helper
INFO - 2023-03-10 08:59:22 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:59:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:22 --> Model "Change_model" initialized
INFO - 2023-03-10 08:59:22 --> Model "Grafana_model" initialized
INFO - 2023-03-10 08:59:22 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:22 --> Total execution time: 0.0244
INFO - 2023-03-10 08:59:22 --> Config Class Initialized
INFO - 2023-03-10 08:59:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:22 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:22 --> URI Class Initialized
INFO - 2023-03-10 08:59:22 --> Router Class Initialized
INFO - 2023-03-10 08:59:22 --> Output Class Initialized
INFO - 2023-03-10 08:59:22 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:22 --> Input Class Initialized
INFO - 2023-03-10 08:59:22 --> Language Class Initialized
INFO - 2023-03-10 08:59:22 --> Loader Class Initialized
INFO - 2023-03-10 08:59:22 --> Controller Class Initialized
INFO - 2023-03-10 08:59:22 --> Helper loaded: form_helper
INFO - 2023-03-10 08:59:22 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:59:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:22 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:22 --> Total execution time: 0.0017
INFO - 2023-03-10 08:59:22 --> Config Class Initialized
INFO - 2023-03-10 08:59:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:22 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:22 --> URI Class Initialized
INFO - 2023-03-10 08:59:22 --> Router Class Initialized
INFO - 2023-03-10 08:59:22 --> Output Class Initialized
INFO - 2023-03-10 08:59:22 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:22 --> Input Class Initialized
INFO - 2023-03-10 08:59:22 --> Language Class Initialized
INFO - 2023-03-10 08:59:22 --> Loader Class Initialized
INFO - 2023-03-10 08:59:22 --> Controller Class Initialized
INFO - 2023-03-10 08:59:22 --> Helper loaded: form_helper
INFO - 2023-03-10 08:59:22 --> Helper loaded: url_helper
DEBUG - 2023-03-10 08:59:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:22 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:22 --> Model "Login_model" initialized
INFO - 2023-03-10 08:59:22 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:22 --> Total execution time: 0.0134
INFO - 2023-03-10 08:59:22 --> Config Class Initialized
INFO - 2023-03-10 08:59:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:22 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:22 --> URI Class Initialized
INFO - 2023-03-10 08:59:22 --> Router Class Initialized
INFO - 2023-03-10 08:59:22 --> Output Class Initialized
INFO - 2023-03-10 08:59:22 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:22 --> Input Class Initialized
INFO - 2023-03-10 08:59:22 --> Language Class Initialized
INFO - 2023-03-10 08:59:22 --> Loader Class Initialized
INFO - 2023-03-10 08:59:22 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:22 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:22 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:22 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:22 --> Total execution time: 0.0131
INFO - 2023-03-10 08:59:22 --> Config Class Initialized
INFO - 2023-03-10 08:59:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:22 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:22 --> URI Class Initialized
INFO - 2023-03-10 08:59:22 --> Router Class Initialized
INFO - 2023-03-10 08:59:22 --> Output Class Initialized
INFO - 2023-03-10 08:59:22 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:22 --> Input Class Initialized
INFO - 2023-03-10 08:59:22 --> Language Class Initialized
INFO - 2023-03-10 08:59:22 --> Loader Class Initialized
INFO - 2023-03-10 08:59:22 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:22 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:22 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:22 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:22 --> Total execution time: 0.0163
INFO - 2023-03-10 08:59:22 --> Config Class Initialized
INFO - 2023-03-10 08:59:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:23 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:23 --> URI Class Initialized
INFO - 2023-03-10 08:59:23 --> Router Class Initialized
INFO - 2023-03-10 08:59:23 --> Output Class Initialized
INFO - 2023-03-10 08:59:23 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:23 --> Input Class Initialized
INFO - 2023-03-10 08:59:23 --> Language Class Initialized
INFO - 2023-03-10 08:59:23 --> Loader Class Initialized
INFO - 2023-03-10 08:59:23 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:23 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:23 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:23 --> Model "Login_model" initialized
INFO - 2023-03-10 08:59:23 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:23 --> Total execution time: 0.1161
INFO - 2023-03-10 08:59:23 --> Config Class Initialized
INFO - 2023-03-10 08:59:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:23 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:23 --> URI Class Initialized
INFO - 2023-03-10 08:59:23 --> Router Class Initialized
INFO - 2023-03-10 08:59:23 --> Output Class Initialized
INFO - 2023-03-10 08:59:23 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:23 --> Input Class Initialized
INFO - 2023-03-10 08:59:23 --> Language Class Initialized
INFO - 2023-03-10 08:59:23 --> Loader Class Initialized
INFO - 2023-03-10 08:59:23 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:23 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:23 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:23 --> Model "Login_model" initialized
INFO - 2023-03-10 08:59:23 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:23 --> Total execution time: 0.1158
INFO - 2023-03-10 08:59:27 --> Config Class Initialized
INFO - 2023-03-10 08:59:27 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:27 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:27 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:27 --> URI Class Initialized
INFO - 2023-03-10 08:59:27 --> Router Class Initialized
INFO - 2023-03-10 08:59:27 --> Output Class Initialized
INFO - 2023-03-10 08:59:27 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:27 --> Input Class Initialized
INFO - 2023-03-10 08:59:27 --> Language Class Initialized
INFO - 2023-03-10 08:59:27 --> Loader Class Initialized
INFO - 2023-03-10 08:59:27 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:27 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:27 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:27 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:27 --> Total execution time: 0.0475
INFO - 2023-03-10 08:59:27 --> Config Class Initialized
INFO - 2023-03-10 08:59:27 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:27 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:27 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:27 --> URI Class Initialized
INFO - 2023-03-10 08:59:27 --> Router Class Initialized
INFO - 2023-03-10 08:59:27 --> Output Class Initialized
INFO - 2023-03-10 08:59:27 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:27 --> Input Class Initialized
INFO - 2023-03-10 08:59:27 --> Language Class Initialized
INFO - 2023-03-10 08:59:27 --> Loader Class Initialized
INFO - 2023-03-10 08:59:27 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:27 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:27 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:27 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:27 --> Total execution time: 0.0113
INFO - 2023-03-10 08:59:28 --> Config Class Initialized
INFO - 2023-03-10 08:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:28 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:28 --> URI Class Initialized
INFO - 2023-03-10 08:59:28 --> Router Class Initialized
INFO - 2023-03-10 08:59:28 --> Output Class Initialized
INFO - 2023-03-10 08:59:28 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:28 --> Input Class Initialized
INFO - 2023-03-10 08:59:28 --> Language Class Initialized
INFO - 2023-03-10 08:59:28 --> Loader Class Initialized
INFO - 2023-03-10 08:59:28 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:28 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:28 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:28 --> Model "Login_model" initialized
INFO - 2023-03-10 08:59:28 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:28 --> Total execution time: 0.0262
INFO - 2023-03-10 08:59:28 --> Config Class Initialized
INFO - 2023-03-10 08:59:28 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:28 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:28 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:28 --> URI Class Initialized
INFO - 2023-03-10 08:59:28 --> Router Class Initialized
INFO - 2023-03-10 08:59:28 --> Output Class Initialized
INFO - 2023-03-10 08:59:28 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:28 --> Input Class Initialized
INFO - 2023-03-10 08:59:28 --> Language Class Initialized
INFO - 2023-03-10 08:59:28 --> Loader Class Initialized
INFO - 2023-03-10 08:59:28 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:28 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:28 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:29 --> Model "Login_model" initialized
INFO - 2023-03-10 08:59:29 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:29 --> Total execution time: 0.0622
INFO - 2023-03-10 08:59:48 --> Config Class Initialized
INFO - 2023-03-10 08:59:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:48 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:48 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:48 --> URI Class Initialized
INFO - 2023-03-10 08:59:48 --> Router Class Initialized
INFO - 2023-03-10 08:59:48 --> Output Class Initialized
INFO - 2023-03-10 08:59:48 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:48 --> Input Class Initialized
INFO - 2023-03-10 08:59:48 --> Language Class Initialized
INFO - 2023-03-10 08:59:48 --> Loader Class Initialized
INFO - 2023-03-10 08:59:48 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:48 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:48 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:48 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:48 --> Total execution time: 0.0678
INFO - 2023-03-10 08:59:48 --> Config Class Initialized
INFO - 2023-03-10 08:59:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:48 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:48 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:48 --> URI Class Initialized
INFO - 2023-03-10 08:59:48 --> Router Class Initialized
INFO - 2023-03-10 08:59:48 --> Output Class Initialized
INFO - 2023-03-10 08:59:48 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:48 --> Input Class Initialized
INFO - 2023-03-10 08:59:48 --> Language Class Initialized
INFO - 2023-03-10 08:59:48 --> Loader Class Initialized
INFO - 2023-03-10 08:59:48 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:48 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:48 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:48 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:48 --> Total execution time: 0.0457
INFO - 2023-03-10 08:59:52 --> Config Class Initialized
INFO - 2023-03-10 08:59:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:52 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:52 --> URI Class Initialized
INFO - 2023-03-10 08:59:52 --> Router Class Initialized
INFO - 2023-03-10 08:59:52 --> Output Class Initialized
INFO - 2023-03-10 08:59:52 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:52 --> Input Class Initialized
INFO - 2023-03-10 08:59:52 --> Language Class Initialized
INFO - 2023-03-10 08:59:52 --> Loader Class Initialized
INFO - 2023-03-10 08:59:52 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:52 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:52 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:52 --> Model "Login_model" initialized
INFO - 2023-03-10 08:59:52 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:52 --> Total execution time: 0.0364
INFO - 2023-03-10 08:59:52 --> Config Class Initialized
INFO - 2023-03-10 08:59:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:52 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:52 --> URI Class Initialized
INFO - 2023-03-10 08:59:52 --> Router Class Initialized
INFO - 2023-03-10 08:59:52 --> Output Class Initialized
INFO - 2023-03-10 08:59:52 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:52 --> Input Class Initialized
INFO - 2023-03-10 08:59:52 --> Language Class Initialized
INFO - 2023-03-10 08:59:52 --> Loader Class Initialized
INFO - 2023-03-10 08:59:52 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:52 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:52 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:52 --> Model "Login_model" initialized
INFO - 2023-03-10 08:59:52 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:52 --> Total execution time: 0.0321
INFO - 2023-03-10 08:59:55 --> Config Class Initialized
INFO - 2023-03-10 08:59:55 --> Config Class Initialized
INFO - 2023-03-10 08:59:55 --> Hooks Class Initialized
INFO - 2023-03-10 08:59:55 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:55 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 08:59:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:55 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:55 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:55 --> URI Class Initialized
INFO - 2023-03-10 08:59:55 --> URI Class Initialized
INFO - 2023-03-10 08:59:55 --> Router Class Initialized
INFO - 2023-03-10 08:59:55 --> Router Class Initialized
INFO - 2023-03-10 08:59:55 --> Output Class Initialized
INFO - 2023-03-10 08:59:55 --> Output Class Initialized
INFO - 2023-03-10 08:59:55 --> Security Class Initialized
INFO - 2023-03-10 08:59:55 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:55 --> Input Class Initialized
INFO - 2023-03-10 08:59:55 --> Input Class Initialized
INFO - 2023-03-10 08:59:55 --> Language Class Initialized
INFO - 2023-03-10 08:59:55 --> Language Class Initialized
INFO - 2023-03-10 08:59:55 --> Loader Class Initialized
INFO - 2023-03-10 08:59:55 --> Loader Class Initialized
INFO - 2023-03-10 08:59:55 --> Controller Class Initialized
INFO - 2023-03-10 08:59:55 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 08:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:55 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:55 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:55 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:55 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:55 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:55 --> Total execution time: 0.0158
INFO - 2023-03-10 08:59:55 --> Config Class Initialized
INFO - 2023-03-10 08:59:55 --> Hooks Class Initialized
INFO - 2023-03-10 08:59:55 --> Config Class Initialized
DEBUG - 2023-03-10 08:59:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:55 --> Hooks Class Initialized
INFO - 2023-03-10 08:59:55 --> Utf8 Class Initialized
DEBUG - 2023-03-10 08:59:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:55 --> URI Class Initialized
INFO - 2023-03-10 08:59:55 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:55 --> Router Class Initialized
INFO - 2023-03-10 08:59:55 --> Output Class Initialized
INFO - 2023-03-10 08:59:55 --> URI Class Initialized
INFO - 2023-03-10 08:59:55 --> Security Class Initialized
INFO - 2023-03-10 08:59:55 --> Router Class Initialized
DEBUG - 2023-03-10 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:55 --> Input Class Initialized
INFO - 2023-03-10 08:59:55 --> Output Class Initialized
INFO - 2023-03-10 08:59:55 --> Language Class Initialized
INFO - 2023-03-10 08:59:55 --> Security Class Initialized
INFO - 2023-03-10 08:59:55 --> Loader Class Initialized
DEBUG - 2023-03-10 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:55 --> Controller Class Initialized
INFO - 2023-03-10 08:59:55 --> Input Class Initialized
DEBUG - 2023-03-10 08:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:55 --> Language Class Initialized
INFO - 2023-03-10 08:59:55 --> Loader Class Initialized
INFO - 2023-03-10 08:59:55 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:55 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:55 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:55 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:55 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:55 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:55 --> Total execution time: 0.1770
INFO - 2023-03-10 08:59:56 --> Config Class Initialized
INFO - 2023-03-10 08:59:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:56 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:56 --> URI Class Initialized
INFO - 2023-03-10 08:59:56 --> Router Class Initialized
INFO - 2023-03-10 08:59:56 --> Output Class Initialized
INFO - 2023-03-10 08:59:56 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:56 --> Input Class Initialized
INFO - 2023-03-10 08:59:56 --> Language Class Initialized
INFO - 2023-03-10 08:59:56 --> Loader Class Initialized
INFO - 2023-03-10 08:59:56 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:56 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:56 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:56 --> Config Class Initialized
INFO - 2023-03-10 08:59:56 --> Config Class Initialized
INFO - 2023-03-10 08:59:56 --> Hooks Class Initialized
INFO - 2023-03-10 08:59:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:56 --> Utf8 Class Initialized
DEBUG - 2023-03-10 08:59:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:56 --> URI Class Initialized
INFO - 2023-03-10 08:59:56 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:56 --> Router Class Initialized
INFO - 2023-03-10 08:59:56 --> URI Class Initialized
INFO - 2023-03-10 08:59:56 --> Output Class Initialized
INFO - 2023-03-10 08:59:56 --> Router Class Initialized
INFO - 2023-03-10 08:59:56 --> Security Class Initialized
INFO - 2023-03-10 08:59:56 --> Output Class Initialized
DEBUG - 2023-03-10 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:56 --> Security Class Initialized
INFO - 2023-03-10 08:59:56 --> Input Class Initialized
DEBUG - 2023-03-10 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:56 --> Language Class Initialized
INFO - 2023-03-10 08:59:56 --> Input Class Initialized
INFO - 2023-03-10 08:59:56 --> Language Class Initialized
INFO - 2023-03-10 08:59:56 --> Loader Class Initialized
INFO - 2023-03-10 08:59:56 --> Loader Class Initialized
INFO - 2023-03-10 08:59:56 --> Controller Class Initialized
INFO - 2023-03-10 08:59:56 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 08:59:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:56 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:56 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:56 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:56 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:56 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:56 --> Total execution time: 0.0155
INFO - 2023-03-10 08:59:56 --> Config Class Initialized
INFO - 2023-03-10 08:59:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:56 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:56 --> URI Class Initialized
INFO - 2023-03-10 08:59:56 --> Router Class Initialized
INFO - 2023-03-10 08:59:56 --> Output Class Initialized
INFO - 2023-03-10 08:59:56 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:56 --> Input Class Initialized
INFO - 2023-03-10 08:59:56 --> Language Class Initialized
INFO - 2023-03-10 08:59:56 --> Loader Class Initialized
INFO - 2023-03-10 08:59:56 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:56 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:56 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:57 --> Config Class Initialized
INFO - 2023-03-10 08:59:57 --> Config Class Initialized
INFO - 2023-03-10 08:59:57 --> Hooks Class Initialized
INFO - 2023-03-10 08:59:57 --> Hooks Class Initialized
DEBUG - 2023-03-10 08:59:57 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 08:59:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 08:59:57 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:57 --> Utf8 Class Initialized
INFO - 2023-03-10 08:59:57 --> URI Class Initialized
INFO - 2023-03-10 08:59:57 --> URI Class Initialized
INFO - 2023-03-10 08:59:57 --> Router Class Initialized
INFO - 2023-03-10 08:59:57 --> Router Class Initialized
INFO - 2023-03-10 08:59:57 --> Output Class Initialized
INFO - 2023-03-10 08:59:57 --> Output Class Initialized
INFO - 2023-03-10 08:59:57 --> Security Class Initialized
INFO - 2023-03-10 08:59:57 --> Security Class Initialized
DEBUG - 2023-03-10 08:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 08:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 08:59:57 --> Input Class Initialized
INFO - 2023-03-10 08:59:57 --> Input Class Initialized
INFO - 2023-03-10 08:59:57 --> Language Class Initialized
INFO - 2023-03-10 08:59:57 --> Language Class Initialized
INFO - 2023-03-10 08:59:57 --> Loader Class Initialized
INFO - 2023-03-10 08:59:57 --> Loader Class Initialized
INFO - 2023-03-10 08:59:57 --> Controller Class Initialized
INFO - 2023-03-10 08:59:57 --> Controller Class Initialized
DEBUG - 2023-03-10 08:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 08:59:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 08:59:57 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:57 --> Database Driver Class Initialized
INFO - 2023-03-10 08:59:57 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:57 --> Model "Cluster_model" initialized
INFO - 2023-03-10 08:59:57 --> Final output sent to browser
DEBUG - 2023-03-10 08:59:57 --> Total execution time: 0.0752
INFO - 2023-03-10 09:01:22 --> Config Class Initialized
INFO - 2023-03-10 09:01:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:22 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:22 --> URI Class Initialized
INFO - 2023-03-10 09:01:22 --> Router Class Initialized
INFO - 2023-03-10 09:01:22 --> Output Class Initialized
INFO - 2023-03-10 09:01:22 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:22 --> Input Class Initialized
INFO - 2023-03-10 09:01:22 --> Language Class Initialized
INFO - 2023-03-10 09:01:22 --> Loader Class Initialized
INFO - 2023-03-10 09:01:22 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:22 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:22 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:22 --> Config Class Initialized
INFO - 2023-03-10 09:01:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:22 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:22 --> URI Class Initialized
INFO - 2023-03-10 09:01:22 --> Router Class Initialized
INFO - 2023-03-10 09:01:22 --> Output Class Initialized
INFO - 2023-03-10 09:01:22 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:22 --> Input Class Initialized
INFO - 2023-03-10 09:01:22 --> Language Class Initialized
INFO - 2023-03-10 09:01:22 --> Loader Class Initialized
INFO - 2023-03-10 09:01:22 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:22 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:22 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:23 --> Config Class Initialized
INFO - 2023-03-10 09:01:23 --> Config Class Initialized
INFO - 2023-03-10 09:01:23 --> Hooks Class Initialized
INFO - 2023-03-10 09:01:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:23 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:01:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:23 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:23 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:23 --> URI Class Initialized
INFO - 2023-03-10 09:01:23 --> URI Class Initialized
INFO - 2023-03-10 09:01:23 --> Router Class Initialized
INFO - 2023-03-10 09:01:23 --> Router Class Initialized
INFO - 2023-03-10 09:01:23 --> Output Class Initialized
INFO - 2023-03-10 09:01:23 --> Output Class Initialized
INFO - 2023-03-10 09:01:23 --> Security Class Initialized
INFO - 2023-03-10 09:01:23 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:23 --> Input Class Initialized
INFO - 2023-03-10 09:01:23 --> Input Class Initialized
INFO - 2023-03-10 09:01:23 --> Language Class Initialized
INFO - 2023-03-10 09:01:23 --> Language Class Initialized
INFO - 2023-03-10 09:01:23 --> Loader Class Initialized
INFO - 2023-03-10 09:01:23 --> Loader Class Initialized
INFO - 2023-03-10 09:01:23 --> Controller Class Initialized
INFO - 2023-03-10 09:01:23 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:23 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:23 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:23 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:23 --> Total execution time: 0.0151
INFO - 2023-03-10 09:01:23 --> Config Class Initialized
INFO - 2023-03-10 09:01:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:23 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:23 --> URI Class Initialized
INFO - 2023-03-10 09:01:23 --> Router Class Initialized
INFO - 2023-03-10 09:01:23 --> Output Class Initialized
INFO - 2023-03-10 09:01:23 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:23 --> Input Class Initialized
INFO - 2023-03-10 09:01:23 --> Language Class Initialized
INFO - 2023-03-10 09:01:23 --> Loader Class Initialized
INFO - 2023-03-10 09:01:23 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:23 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:23 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:23 --> Total execution time: 0.0120
INFO - 2023-03-10 09:01:23 --> Config Class Initialized
INFO - 2023-03-10 09:01:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:23 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:23 --> URI Class Initialized
INFO - 2023-03-10 09:01:23 --> Router Class Initialized
INFO - 2023-03-10 09:01:23 --> Output Class Initialized
INFO - 2023-03-10 09:01:23 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:23 --> Input Class Initialized
INFO - 2023-03-10 09:01:23 --> Language Class Initialized
INFO - 2023-03-10 09:01:23 --> Loader Class Initialized
INFO - 2023-03-10 09:01:23 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:23 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:23 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:26 --> Config Class Initialized
INFO - 2023-03-10 09:01:26 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:26 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:26 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:26 --> URI Class Initialized
INFO - 2023-03-10 09:01:26 --> Router Class Initialized
INFO - 2023-03-10 09:01:26 --> Output Class Initialized
INFO - 2023-03-10 09:01:26 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:26 --> Input Class Initialized
INFO - 2023-03-10 09:01:26 --> Language Class Initialized
INFO - 2023-03-10 09:01:26 --> Loader Class Initialized
INFO - 2023-03-10 09:01:26 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:26 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:26 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:26 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:26 --> Total execution time: 0.0180
INFO - 2023-03-10 09:01:26 --> Config Class Initialized
INFO - 2023-03-10 09:01:26 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:26 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:26 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:26 --> URI Class Initialized
INFO - 2023-03-10 09:01:26 --> Router Class Initialized
INFO - 2023-03-10 09:01:26 --> Output Class Initialized
INFO - 2023-03-10 09:01:26 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:26 --> Input Class Initialized
INFO - 2023-03-10 09:01:26 --> Language Class Initialized
INFO - 2023-03-10 09:01:26 --> Loader Class Initialized
INFO - 2023-03-10 09:01:26 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:26 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:26 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:26 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:26 --> Total execution time: 0.0551
INFO - 2023-03-10 09:01:29 --> Config Class Initialized
INFO - 2023-03-10 09:01:29 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:29 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:29 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:29 --> URI Class Initialized
INFO - 2023-03-10 09:01:29 --> Router Class Initialized
INFO - 2023-03-10 09:01:29 --> Output Class Initialized
INFO - 2023-03-10 09:01:29 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:29 --> Input Class Initialized
INFO - 2023-03-10 09:01:29 --> Language Class Initialized
INFO - 2023-03-10 09:01:29 --> Loader Class Initialized
INFO - 2023-03-10 09:01:29 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:29 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:29 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:29 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:29 --> Model "Login_model" initialized
INFO - 2023-03-10 09:01:29 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:29 --> Total execution time: 0.1224
INFO - 2023-03-10 09:01:29 --> Config Class Initialized
INFO - 2023-03-10 09:01:29 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:29 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:29 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:29 --> URI Class Initialized
INFO - 2023-03-10 09:01:29 --> Router Class Initialized
INFO - 2023-03-10 09:01:29 --> Output Class Initialized
INFO - 2023-03-10 09:01:29 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:29 --> Input Class Initialized
INFO - 2023-03-10 09:01:29 --> Language Class Initialized
INFO - 2023-03-10 09:01:29 --> Loader Class Initialized
INFO - 2023-03-10 09:01:29 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:29 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:29 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:29 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:29 --> Model "Login_model" initialized
INFO - 2023-03-10 09:01:29 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:29 --> Total execution time: 0.0326
INFO - 2023-03-10 09:01:55 --> Config Class Initialized
INFO - 2023-03-10 09:01:55 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:55 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:55 --> URI Class Initialized
INFO - 2023-03-10 09:01:55 --> Router Class Initialized
INFO - 2023-03-10 09:01:55 --> Output Class Initialized
INFO - 2023-03-10 09:01:55 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:55 --> Input Class Initialized
INFO - 2023-03-10 09:01:55 --> Language Class Initialized
INFO - 2023-03-10 09:01:55 --> Loader Class Initialized
INFO - 2023-03-10 09:01:55 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:55 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:55 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:55 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:55 --> Model "Login_model" initialized
INFO - 2023-03-10 09:01:55 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:55 --> Total execution time: 0.0358
INFO - 2023-03-10 09:01:55 --> Config Class Initialized
INFO - 2023-03-10 09:01:55 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:55 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:55 --> URI Class Initialized
INFO - 2023-03-10 09:01:55 --> Router Class Initialized
INFO - 2023-03-10 09:01:55 --> Output Class Initialized
INFO - 2023-03-10 09:01:55 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:55 --> Input Class Initialized
INFO - 2023-03-10 09:01:55 --> Language Class Initialized
INFO - 2023-03-10 09:01:55 --> Loader Class Initialized
INFO - 2023-03-10 09:01:55 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:55 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:55 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:55 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:55 --> Model "Login_model" initialized
INFO - 2023-03-10 09:01:55 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:55 --> Total execution time: 0.0374
INFO - 2023-03-10 09:01:59 --> Config Class Initialized
INFO - 2023-03-10 09:01:59 --> Config Class Initialized
INFO - 2023-03-10 09:01:59 --> Hooks Class Initialized
INFO - 2023-03-10 09:01:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:01:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:59 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:59 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:59 --> URI Class Initialized
INFO - 2023-03-10 09:01:59 --> URI Class Initialized
INFO - 2023-03-10 09:01:59 --> Router Class Initialized
INFO - 2023-03-10 09:01:59 --> Router Class Initialized
INFO - 2023-03-10 09:01:59 --> Output Class Initialized
INFO - 2023-03-10 09:01:59 --> Output Class Initialized
INFO - 2023-03-10 09:01:59 --> Security Class Initialized
INFO - 2023-03-10 09:01:59 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:59 --> Input Class Initialized
INFO - 2023-03-10 09:01:59 --> Input Class Initialized
INFO - 2023-03-10 09:01:59 --> Language Class Initialized
INFO - 2023-03-10 09:01:59 --> Language Class Initialized
INFO - 2023-03-10 09:01:59 --> Loader Class Initialized
INFO - 2023-03-10 09:01:59 --> Loader Class Initialized
INFO - 2023-03-10 09:01:59 --> Controller Class Initialized
INFO - 2023-03-10 09:01:59 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:59 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:59 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:59 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:59 --> Total execution time: 0.0173
INFO - 2023-03-10 09:01:59 --> Config Class Initialized
INFO - 2023-03-10 09:01:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:59 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:59 --> URI Class Initialized
INFO - 2023-03-10 09:01:59 --> Router Class Initialized
INFO - 2023-03-10 09:01:59 --> Output Class Initialized
INFO - 2023-03-10 09:01:59 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:59 --> Input Class Initialized
INFO - 2023-03-10 09:01:59 --> Language Class Initialized
INFO - 2023-03-10 09:01:59 --> Loader Class Initialized
INFO - 2023-03-10 09:01:59 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:59 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:01:59 --> Final output sent to browser
DEBUG - 2023-03-10 09:01:59 --> Total execution time: 0.0489
INFO - 2023-03-10 09:01:59 --> Config Class Initialized
INFO - 2023-03-10 09:01:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:01:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:01:59 --> Utf8 Class Initialized
INFO - 2023-03-10 09:01:59 --> URI Class Initialized
INFO - 2023-03-10 09:01:59 --> Router Class Initialized
INFO - 2023-03-10 09:01:59 --> Output Class Initialized
INFO - 2023-03-10 09:01:59 --> Security Class Initialized
DEBUG - 2023-03-10 09:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:01:59 --> Input Class Initialized
INFO - 2023-03-10 09:01:59 --> Language Class Initialized
INFO - 2023-03-10 09:01:59 --> Loader Class Initialized
INFO - 2023-03-10 09:01:59 --> Controller Class Initialized
DEBUG - 2023-03-10 09:01:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:01:59 --> Database Driver Class Initialized
INFO - 2023-03-10 09:01:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:00 --> Config Class Initialized
INFO - 2023-03-10 09:02:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:00 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:00 --> URI Class Initialized
INFO - 2023-03-10 09:02:00 --> Router Class Initialized
INFO - 2023-03-10 09:02:00 --> Output Class Initialized
INFO - 2023-03-10 09:02:00 --> Security Class Initialized
DEBUG - 2023-03-10 09:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:00 --> Input Class Initialized
INFO - 2023-03-10 09:02:00 --> Language Class Initialized
INFO - 2023-03-10 09:02:00 --> Loader Class Initialized
INFO - 2023-03-10 09:02:00 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:00 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:00 --> Config Class Initialized
INFO - 2023-03-10 09:02:00 --> Config Class Initialized
INFO - 2023-03-10 09:02:00 --> Hooks Class Initialized
INFO - 2023-03-10 09:02:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:00 --> Utf8 Class Initialized
DEBUG - 2023-03-10 09:02:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:00 --> URI Class Initialized
INFO - 2023-03-10 09:02:00 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:00 --> Router Class Initialized
INFO - 2023-03-10 09:02:00 --> URI Class Initialized
INFO - 2023-03-10 09:02:00 --> Output Class Initialized
INFO - 2023-03-10 09:02:00 --> Router Class Initialized
INFO - 2023-03-10 09:02:00 --> Security Class Initialized
INFO - 2023-03-10 09:02:00 --> Output Class Initialized
DEBUG - 2023-03-10 09:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:00 --> Input Class Initialized
INFO - 2023-03-10 09:02:00 --> Security Class Initialized
INFO - 2023-03-10 09:02:00 --> Language Class Initialized
DEBUG - 2023-03-10 09:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:00 --> Loader Class Initialized
INFO - 2023-03-10 09:02:00 --> Input Class Initialized
INFO - 2023-03-10 09:02:00 --> Controller Class Initialized
INFO - 2023-03-10 09:02:00 --> Language Class Initialized
DEBUG - 2023-03-10 09:02:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:00 --> Loader Class Initialized
INFO - 2023-03-10 09:02:00 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:00 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:00 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:00 --> Final output sent to browser
DEBUG - 2023-03-10 09:02:00 --> Total execution time: 0.0165
INFO - 2023-03-10 09:02:00 --> Config Class Initialized
INFO - 2023-03-10 09:02:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:00 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:00 --> URI Class Initialized
INFO - 2023-03-10 09:02:00 --> Router Class Initialized
INFO - 2023-03-10 09:02:00 --> Output Class Initialized
INFO - 2023-03-10 09:02:00 --> Security Class Initialized
DEBUG - 2023-03-10 09:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:00 --> Input Class Initialized
INFO - 2023-03-10 09:02:00 --> Language Class Initialized
INFO - 2023-03-10 09:02:00 --> Loader Class Initialized
INFO - 2023-03-10 09:02:00 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:00 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:14 --> Config Class Initialized
INFO - 2023-03-10 09:02:14 --> Config Class Initialized
INFO - 2023-03-10 09:02:14 --> Hooks Class Initialized
INFO - 2023-03-10 09:02:14 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:14 --> Utf8 Class Initialized
DEBUG - 2023-03-10 09:02:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:14 --> URI Class Initialized
INFO - 2023-03-10 09:02:14 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:14 --> URI Class Initialized
INFO - 2023-03-10 09:02:14 --> Router Class Initialized
INFO - 2023-03-10 09:02:14 --> Router Class Initialized
INFO - 2023-03-10 09:02:14 --> Output Class Initialized
INFO - 2023-03-10 09:02:14 --> Output Class Initialized
INFO - 2023-03-10 09:02:14 --> Security Class Initialized
INFO - 2023-03-10 09:02:14 --> Security Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:14 --> Input Class Initialized
INFO - 2023-03-10 09:02:14 --> Input Class Initialized
INFO - 2023-03-10 09:02:14 --> Language Class Initialized
INFO - 2023-03-10 09:02:14 --> Language Class Initialized
INFO - 2023-03-10 09:02:14 --> Loader Class Initialized
INFO - 2023-03-10 09:02:14 --> Loader Class Initialized
INFO - 2023-03-10 09:02:14 --> Controller Class Initialized
INFO - 2023-03-10 09:02:14 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:02:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:14 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:14 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:14 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:14 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:14 --> Final output sent to browser
DEBUG - 2023-03-10 09:02:14 --> Total execution time: 0.0153
INFO - 2023-03-10 09:02:14 --> Config Class Initialized
INFO - 2023-03-10 09:02:14 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:14 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:14 --> URI Class Initialized
INFO - 2023-03-10 09:02:14 --> Router Class Initialized
INFO - 2023-03-10 09:02:14 --> Output Class Initialized
INFO - 2023-03-10 09:02:14 --> Security Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:14 --> Input Class Initialized
INFO - 2023-03-10 09:02:14 --> Language Class Initialized
INFO - 2023-03-10 09:02:14 --> Loader Class Initialized
INFO - 2023-03-10 09:02:14 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:14 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:14 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:14 --> Final output sent to browser
DEBUG - 2023-03-10 09:02:14 --> Total execution time: 0.0120
INFO - 2023-03-10 09:02:14 --> Config Class Initialized
INFO - 2023-03-10 09:02:14 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:14 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:14 --> URI Class Initialized
INFO - 2023-03-10 09:02:14 --> Router Class Initialized
INFO - 2023-03-10 09:02:14 --> Output Class Initialized
INFO - 2023-03-10 09:02:14 --> Security Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:14 --> Input Class Initialized
INFO - 2023-03-10 09:02:14 --> Language Class Initialized
INFO - 2023-03-10 09:02:14 --> Loader Class Initialized
INFO - 2023-03-10 09:02:14 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:14 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:14 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:14 --> Config Class Initialized
INFO - 2023-03-10 09:02:14 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:14 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:14 --> URI Class Initialized
INFO - 2023-03-10 09:02:14 --> Router Class Initialized
INFO - 2023-03-10 09:02:14 --> Output Class Initialized
INFO - 2023-03-10 09:02:14 --> Security Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:14 --> Input Class Initialized
INFO - 2023-03-10 09:02:14 --> Language Class Initialized
INFO - 2023-03-10 09:02:14 --> Loader Class Initialized
INFO - 2023-03-10 09:02:14 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:14 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:14 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:14 --> Config Class Initialized
INFO - 2023-03-10 09:02:14 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:14 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:14 --> URI Class Initialized
INFO - 2023-03-10 09:02:14 --> Router Class Initialized
INFO - 2023-03-10 09:02:14 --> Output Class Initialized
INFO - 2023-03-10 09:02:14 --> Security Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:14 --> Input Class Initialized
INFO - 2023-03-10 09:02:14 --> Language Class Initialized
INFO - 2023-03-10 09:02:14 --> Loader Class Initialized
INFO - 2023-03-10 09:02:14 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:14 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:14 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:15 --> Config Class Initialized
INFO - 2023-03-10 09:02:15 --> Config Class Initialized
INFO - 2023-03-10 09:02:15 --> Hooks Class Initialized
INFO - 2023-03-10 09:02:15 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:02:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:15 --> Utf8 Class Initialized
DEBUG - 2023-03-10 09:02:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:02:15 --> Utf8 Class Initialized
INFO - 2023-03-10 09:02:15 --> URI Class Initialized
INFO - 2023-03-10 09:02:15 --> URI Class Initialized
INFO - 2023-03-10 09:02:15 --> Router Class Initialized
INFO - 2023-03-10 09:02:15 --> Router Class Initialized
INFO - 2023-03-10 09:02:15 --> Output Class Initialized
INFO - 2023-03-10 09:02:15 --> Output Class Initialized
INFO - 2023-03-10 09:02:15 --> Security Class Initialized
INFO - 2023-03-10 09:02:15 --> Security Class Initialized
DEBUG - 2023-03-10 09:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:02:15 --> Input Class Initialized
INFO - 2023-03-10 09:02:15 --> Input Class Initialized
INFO - 2023-03-10 09:02:15 --> Language Class Initialized
INFO - 2023-03-10 09:02:15 --> Language Class Initialized
INFO - 2023-03-10 09:02:15 --> Loader Class Initialized
INFO - 2023-03-10 09:02:15 --> Loader Class Initialized
INFO - 2023-03-10 09:02:15 --> Controller Class Initialized
INFO - 2023-03-10 09:02:15 --> Controller Class Initialized
DEBUG - 2023-03-10 09:02:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:02:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:02:15 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:15 --> Database Driver Class Initialized
INFO - 2023-03-10 09:02:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:02:15 --> Final output sent to browser
DEBUG - 2023-03-10 09:02:15 --> Total execution time: 0.0528
INFO - 2023-03-10 09:03:08 --> Config Class Initialized
INFO - 2023-03-10 09:03:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:08 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:08 --> URI Class Initialized
INFO - 2023-03-10 09:03:08 --> Router Class Initialized
INFO - 2023-03-10 09:03:08 --> Output Class Initialized
INFO - 2023-03-10 09:03:08 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:08 --> Input Class Initialized
INFO - 2023-03-10 09:03:08 --> Language Class Initialized
INFO - 2023-03-10 09:03:08 --> Loader Class Initialized
INFO - 2023-03-10 09:03:08 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:08 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:08 --> Config Class Initialized
INFO - 2023-03-10 09:03:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:08 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:08 --> URI Class Initialized
INFO - 2023-03-10 09:03:08 --> Router Class Initialized
INFO - 2023-03-10 09:03:08 --> Output Class Initialized
INFO - 2023-03-10 09:03:08 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:08 --> Input Class Initialized
INFO - 2023-03-10 09:03:08 --> Language Class Initialized
INFO - 2023-03-10 09:03:08 --> Loader Class Initialized
INFO - 2023-03-10 09:03:08 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:08 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:12 --> Config Class Initialized
INFO - 2023-03-10 09:03:12 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:12 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:12 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:12 --> URI Class Initialized
INFO - 2023-03-10 09:03:12 --> Router Class Initialized
INFO - 2023-03-10 09:03:12 --> Output Class Initialized
INFO - 2023-03-10 09:03:12 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:12 --> Input Class Initialized
INFO - 2023-03-10 09:03:12 --> Language Class Initialized
INFO - 2023-03-10 09:03:12 --> Loader Class Initialized
INFO - 2023-03-10 09:03:12 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:12 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:12 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:12 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:12 --> Model "Login_model" initialized
INFO - 2023-03-10 09:03:12 --> Final output sent to browser
DEBUG - 2023-03-10 09:03:12 --> Total execution time: 0.0511
INFO - 2023-03-10 09:03:12 --> Config Class Initialized
INFO - 2023-03-10 09:03:12 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:12 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:12 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:12 --> URI Class Initialized
INFO - 2023-03-10 09:03:12 --> Router Class Initialized
INFO - 2023-03-10 09:03:12 --> Output Class Initialized
INFO - 2023-03-10 09:03:12 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:12 --> Input Class Initialized
INFO - 2023-03-10 09:03:12 --> Language Class Initialized
INFO - 2023-03-10 09:03:12 --> Loader Class Initialized
INFO - 2023-03-10 09:03:12 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:12 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:12 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:12 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:12 --> Model "Login_model" initialized
INFO - 2023-03-10 09:03:12 --> Final output sent to browser
DEBUG - 2023-03-10 09:03:12 --> Total execution time: 0.0853
INFO - 2023-03-10 09:03:16 --> Config Class Initialized
INFO - 2023-03-10 09:03:16 --> Config Class Initialized
INFO - 2023-03-10 09:03:16 --> Hooks Class Initialized
INFO - 2023-03-10 09:03:16 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:03:16 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:16 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:16 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:16 --> URI Class Initialized
INFO - 2023-03-10 09:03:16 --> URI Class Initialized
INFO - 2023-03-10 09:03:16 --> Router Class Initialized
INFO - 2023-03-10 09:03:16 --> Router Class Initialized
INFO - 2023-03-10 09:03:16 --> Output Class Initialized
INFO - 2023-03-10 09:03:16 --> Output Class Initialized
INFO - 2023-03-10 09:03:16 --> Security Class Initialized
INFO - 2023-03-10 09:03:16 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:16 --> Input Class Initialized
INFO - 2023-03-10 09:03:16 --> Input Class Initialized
INFO - 2023-03-10 09:03:16 --> Language Class Initialized
INFO - 2023-03-10 09:03:16 --> Language Class Initialized
INFO - 2023-03-10 09:03:16 --> Loader Class Initialized
INFO - 2023-03-10 09:03:16 --> Loader Class Initialized
INFO - 2023-03-10 09:03:16 --> Controller Class Initialized
INFO - 2023-03-10 09:03:16 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:16 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:16 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:16 --> Final output sent to browser
DEBUG - 2023-03-10 09:03:16 --> Total execution time: 0.0397
INFO - 2023-03-10 09:03:16 --> Config Class Initialized
INFO - 2023-03-10 09:03:16 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:16 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:16 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:16 --> URI Class Initialized
INFO - 2023-03-10 09:03:16 --> Router Class Initialized
INFO - 2023-03-10 09:03:16 --> Output Class Initialized
INFO - 2023-03-10 09:03:16 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:16 --> Input Class Initialized
INFO - 2023-03-10 09:03:16 --> Language Class Initialized
INFO - 2023-03-10 09:03:16 --> Loader Class Initialized
INFO - 2023-03-10 09:03:16 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:16 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:16 --> Config Class Initialized
INFO - 2023-03-10 09:03:16 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:16 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:16 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:16 --> URI Class Initialized
INFO - 2023-03-10 09:03:16 --> Router Class Initialized
INFO - 2023-03-10 09:03:16 --> Output Class Initialized
INFO - 2023-03-10 09:03:16 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:16 --> Input Class Initialized
INFO - 2023-03-10 09:03:16 --> Language Class Initialized
INFO - 2023-03-10 09:03:16 --> Loader Class Initialized
INFO - 2023-03-10 09:03:16 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:16 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:16 --> Final output sent to browser
DEBUG - 2023-03-10 09:03:16 --> Total execution time: 0.0963
INFO - 2023-03-10 09:03:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:43 --> Config Class Initialized
INFO - 2023-03-10 09:03:43 --> Config Class Initialized
INFO - 2023-03-10 09:03:43 --> Hooks Class Initialized
INFO - 2023-03-10 09:03:43 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:43 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:03:43 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:43 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:43 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:43 --> URI Class Initialized
INFO - 2023-03-10 09:03:43 --> URI Class Initialized
INFO - 2023-03-10 09:03:43 --> Router Class Initialized
INFO - 2023-03-10 09:03:43 --> Router Class Initialized
INFO - 2023-03-10 09:03:43 --> Output Class Initialized
INFO - 2023-03-10 09:03:43 --> Output Class Initialized
INFO - 2023-03-10 09:03:43 --> Security Class Initialized
INFO - 2023-03-10 09:03:43 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:43 --> Input Class Initialized
INFO - 2023-03-10 09:03:43 --> Input Class Initialized
INFO - 2023-03-10 09:03:43 --> Language Class Initialized
INFO - 2023-03-10 09:03:43 --> Language Class Initialized
INFO - 2023-03-10 09:03:43 --> Loader Class Initialized
INFO - 2023-03-10 09:03:43 --> Loader Class Initialized
INFO - 2023-03-10 09:03:43 --> Controller Class Initialized
INFO - 2023-03-10 09:03:43 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:03:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:43 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:43 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:43 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:43 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:43 --> Final output sent to browser
DEBUG - 2023-03-10 09:03:43 --> Total execution time: 0.0150
INFO - 2023-03-10 09:03:43 --> Config Class Initialized
INFO - 2023-03-10 09:03:43 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:43 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:43 --> Config Class Initialized
INFO - 2023-03-10 09:03:43 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:43 --> Hooks Class Initialized
INFO - 2023-03-10 09:03:43 --> URI Class Initialized
DEBUG - 2023-03-10 09:03:43 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:43 --> Router Class Initialized
INFO - 2023-03-10 09:03:43 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:43 --> Output Class Initialized
INFO - 2023-03-10 09:03:43 --> URI Class Initialized
INFO - 2023-03-10 09:03:43 --> Security Class Initialized
INFO - 2023-03-10 09:03:43 --> Router Class Initialized
DEBUG - 2023-03-10 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:43 --> Output Class Initialized
INFO - 2023-03-10 09:03:43 --> Input Class Initialized
INFO - 2023-03-10 09:03:43 --> Security Class Initialized
INFO - 2023-03-10 09:03:43 --> Language Class Initialized
DEBUG - 2023-03-10 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:43 --> Loader Class Initialized
INFO - 2023-03-10 09:03:43 --> Input Class Initialized
INFO - 2023-03-10 09:03:43 --> Controller Class Initialized
INFO - 2023-03-10 09:03:43 --> Language Class Initialized
DEBUG - 2023-03-10 09:03:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:43 --> Loader Class Initialized
INFO - 2023-03-10 09:03:43 --> Controller Class Initialized
INFO - 2023-03-10 09:03:43 --> Database Driver Class Initialized
DEBUG - 2023-03-10 09:03:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:43 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:43 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:43 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:43 --> Final output sent to browser
DEBUG - 2023-03-10 09:03:43 --> Total execution time: 0.1790
INFO - 2023-03-10 09:03:44 --> Config Class Initialized
INFO - 2023-03-10 09:03:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:44 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:44 --> URI Class Initialized
INFO - 2023-03-10 09:03:44 --> Router Class Initialized
INFO - 2023-03-10 09:03:44 --> Output Class Initialized
INFO - 2023-03-10 09:03:44 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:44 --> Input Class Initialized
INFO - 2023-03-10 09:03:44 --> Language Class Initialized
INFO - 2023-03-10 09:03:44 --> Loader Class Initialized
INFO - 2023-03-10 09:03:44 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:44 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:44 --> Config Class Initialized
INFO - 2023-03-10 09:03:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:44 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:44 --> URI Class Initialized
INFO - 2023-03-10 09:03:44 --> Router Class Initialized
INFO - 2023-03-10 09:03:44 --> Output Class Initialized
INFO - 2023-03-10 09:03:44 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:44 --> Input Class Initialized
INFO - 2023-03-10 09:03:44 --> Language Class Initialized
INFO - 2023-03-10 09:03:44 --> Loader Class Initialized
INFO - 2023-03-10 09:03:44 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:44 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:44 --> Config Class Initialized
INFO - 2023-03-10 09:03:44 --> Hooks Class Initialized
INFO - 2023-03-10 09:03:44 --> Config Class Initialized
DEBUG - 2023-03-10 09:03:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:44 --> Hooks Class Initialized
INFO - 2023-03-10 09:03:44 --> Utf8 Class Initialized
DEBUG - 2023-03-10 09:03:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:44 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:44 --> URI Class Initialized
INFO - 2023-03-10 09:03:44 --> URI Class Initialized
INFO - 2023-03-10 09:03:44 --> Router Class Initialized
INFO - 2023-03-10 09:03:44 --> Router Class Initialized
INFO - 2023-03-10 09:03:44 --> Output Class Initialized
INFO - 2023-03-10 09:03:44 --> Output Class Initialized
INFO - 2023-03-10 09:03:44 --> Security Class Initialized
INFO - 2023-03-10 09:03:44 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:44 --> Input Class Initialized
INFO - 2023-03-10 09:03:44 --> Input Class Initialized
INFO - 2023-03-10 09:03:44 --> Language Class Initialized
INFO - 2023-03-10 09:03:44 --> Language Class Initialized
INFO - 2023-03-10 09:03:44 --> Loader Class Initialized
INFO - 2023-03-10 09:03:44 --> Loader Class Initialized
INFO - 2023-03-10 09:03:44 --> Controller Class Initialized
INFO - 2023-03-10 09:03:44 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:03:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:44 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:44 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:44 --> Final output sent to browser
DEBUG - 2023-03-10 09:03:44 --> Total execution time: 0.0166
INFO - 2023-03-10 09:03:45 --> Config Class Initialized
INFO - 2023-03-10 09:03:45 --> Config Class Initialized
INFO - 2023-03-10 09:03:45 --> Hooks Class Initialized
INFO - 2023-03-10 09:03:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:03:45 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:03:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:03:45 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:45 --> Utf8 Class Initialized
INFO - 2023-03-10 09:03:45 --> URI Class Initialized
INFO - 2023-03-10 09:03:45 --> URI Class Initialized
INFO - 2023-03-10 09:03:45 --> Router Class Initialized
INFO - 2023-03-10 09:03:45 --> Router Class Initialized
INFO - 2023-03-10 09:03:45 --> Output Class Initialized
INFO - 2023-03-10 09:03:45 --> Output Class Initialized
INFO - 2023-03-10 09:03:45 --> Security Class Initialized
INFO - 2023-03-10 09:03:45 --> Security Class Initialized
DEBUG - 2023-03-10 09:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:03:45 --> Input Class Initialized
INFO - 2023-03-10 09:03:45 --> Input Class Initialized
INFO - 2023-03-10 09:03:45 --> Language Class Initialized
INFO - 2023-03-10 09:03:45 --> Language Class Initialized
INFO - 2023-03-10 09:03:45 --> Loader Class Initialized
INFO - 2023-03-10 09:03:45 --> Loader Class Initialized
INFO - 2023-03-10 09:03:45 --> Controller Class Initialized
INFO - 2023-03-10 09:03:45 --> Controller Class Initialized
DEBUG - 2023-03-10 09:03:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:03:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:03:45 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:45 --> Database Driver Class Initialized
INFO - 2023-03-10 09:03:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:03:45 --> Final output sent to browser
DEBUG - 2023-03-10 09:03:45 --> Total execution time: 0.0303
INFO - 2023-03-10 09:09:36 --> Config Class Initialized
INFO - 2023-03-10 09:09:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:09:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:09:36 --> Utf8 Class Initialized
INFO - 2023-03-10 09:09:36 --> URI Class Initialized
INFO - 2023-03-10 09:09:36 --> Router Class Initialized
INFO - 2023-03-10 09:09:36 --> Output Class Initialized
INFO - 2023-03-10 09:09:36 --> Security Class Initialized
DEBUG - 2023-03-10 09:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:09:36 --> Input Class Initialized
INFO - 2023-03-10 09:09:36 --> Language Class Initialized
INFO - 2023-03-10 09:09:36 --> Loader Class Initialized
INFO - 2023-03-10 09:09:36 --> Controller Class Initialized
DEBUG - 2023-03-10 09:09:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:09:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:09:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:09:37 --> Config Class Initialized
INFO - 2023-03-10 09:09:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:09:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:09:37 --> Utf8 Class Initialized
INFO - 2023-03-10 09:09:37 --> URI Class Initialized
INFO - 2023-03-10 09:09:37 --> Router Class Initialized
INFO - 2023-03-10 09:09:37 --> Output Class Initialized
INFO - 2023-03-10 09:09:37 --> Security Class Initialized
DEBUG - 2023-03-10 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:09:37 --> Input Class Initialized
INFO - 2023-03-10 09:09:37 --> Language Class Initialized
INFO - 2023-03-10 09:09:37 --> Loader Class Initialized
INFO - 2023-03-10 09:09:37 --> Controller Class Initialized
DEBUG - 2023-03-10 09:09:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:09:37 --> Database Driver Class Initialized
INFO - 2023-03-10 09:09:37 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:15:09 --> Config Class Initialized
INFO - 2023-03-10 09:15:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:15:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:15:09 --> Utf8 Class Initialized
INFO - 2023-03-10 09:15:09 --> URI Class Initialized
INFO - 2023-03-10 09:15:09 --> Router Class Initialized
INFO - 2023-03-10 09:15:09 --> Output Class Initialized
INFO - 2023-03-10 09:15:09 --> Security Class Initialized
DEBUG - 2023-03-10 09:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:15:09 --> Input Class Initialized
INFO - 2023-03-10 09:15:09 --> Language Class Initialized
INFO - 2023-03-10 09:15:09 --> Loader Class Initialized
INFO - 2023-03-10 09:15:09 --> Controller Class Initialized
DEBUG - 2023-03-10 09:15:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:15:09 --> Database Driver Class Initialized
INFO - 2023-03-10 09:15:09 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:15:09 --> Database Driver Class Initialized
INFO - 2023-03-10 09:15:09 --> Model "Login_model" initialized
INFO - 2023-03-10 09:15:09 --> Final output sent to browser
DEBUG - 2023-03-10 09:15:09 --> Total execution time: 0.1694
INFO - 2023-03-10 09:15:09 --> Config Class Initialized
INFO - 2023-03-10 09:15:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:15:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:15:09 --> Utf8 Class Initialized
INFO - 2023-03-10 09:15:09 --> URI Class Initialized
INFO - 2023-03-10 09:15:09 --> Router Class Initialized
INFO - 2023-03-10 09:15:09 --> Output Class Initialized
INFO - 2023-03-10 09:15:09 --> Security Class Initialized
DEBUG - 2023-03-10 09:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:15:09 --> Input Class Initialized
INFO - 2023-03-10 09:15:09 --> Language Class Initialized
INFO - 2023-03-10 09:15:09 --> Loader Class Initialized
INFO - 2023-03-10 09:15:09 --> Controller Class Initialized
DEBUG - 2023-03-10 09:15:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:15:09 --> Database Driver Class Initialized
INFO - 2023-03-10 09:15:09 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:15:09 --> Database Driver Class Initialized
INFO - 2023-03-10 09:15:09 --> Model "Login_model" initialized
INFO - 2023-03-10 09:15:09 --> Final output sent to browser
DEBUG - 2023-03-10 09:15:09 --> Total execution time: 0.0801
INFO - 2023-03-10 09:17:51 --> Config Class Initialized
INFO - 2023-03-10 09:17:51 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:17:51 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:17:51 --> Utf8 Class Initialized
INFO - 2023-03-10 09:17:51 --> URI Class Initialized
INFO - 2023-03-10 09:17:51 --> Router Class Initialized
INFO - 2023-03-10 09:17:51 --> Output Class Initialized
INFO - 2023-03-10 09:17:51 --> Security Class Initialized
DEBUG - 2023-03-10 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:17:51 --> Input Class Initialized
INFO - 2023-03-10 09:17:51 --> Language Class Initialized
INFO - 2023-03-10 09:17:51 --> Loader Class Initialized
INFO - 2023-03-10 09:17:51 --> Controller Class Initialized
DEBUG - 2023-03-10 09:17:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:17:51 --> Database Driver Class Initialized
INFO - 2023-03-10 09:17:51 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:17:51 --> Final output sent to browser
DEBUG - 2023-03-10 09:17:51 --> Total execution time: 0.0242
INFO - 2023-03-10 09:17:51 --> Config Class Initialized
INFO - 2023-03-10 09:17:51 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:17:51 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:17:51 --> Utf8 Class Initialized
INFO - 2023-03-10 09:17:51 --> URI Class Initialized
INFO - 2023-03-10 09:17:51 --> Router Class Initialized
INFO - 2023-03-10 09:17:51 --> Output Class Initialized
INFO - 2023-03-10 09:17:51 --> Security Class Initialized
DEBUG - 2023-03-10 09:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:17:51 --> Input Class Initialized
INFO - 2023-03-10 09:17:51 --> Language Class Initialized
INFO - 2023-03-10 09:17:51 --> Loader Class Initialized
INFO - 2023-03-10 09:17:51 --> Controller Class Initialized
DEBUG - 2023-03-10 09:17:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:17:51 --> Database Driver Class Initialized
INFO - 2023-03-10 09:17:51 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:17:51 --> Final output sent to browser
DEBUG - 2023-03-10 09:17:51 --> Total execution time: 0.0570
INFO - 2023-03-10 09:18:07 --> Config Class Initialized
INFO - 2023-03-10 09:18:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:07 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:07 --> URI Class Initialized
INFO - 2023-03-10 09:18:07 --> Router Class Initialized
INFO - 2023-03-10 09:18:07 --> Output Class Initialized
INFO - 2023-03-10 09:18:07 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:07 --> Input Class Initialized
INFO - 2023-03-10 09:18:07 --> Language Class Initialized
INFO - 2023-03-10 09:18:07 --> Loader Class Initialized
INFO - 2023-03-10 09:18:07 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:07 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:07 --> Total execution time: 0.0041
INFO - 2023-03-10 09:18:07 --> Config Class Initialized
INFO - 2023-03-10 09:18:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:07 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:07 --> URI Class Initialized
INFO - 2023-03-10 09:18:07 --> Router Class Initialized
INFO - 2023-03-10 09:18:07 --> Output Class Initialized
INFO - 2023-03-10 09:18:07 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:07 --> Input Class Initialized
INFO - 2023-03-10 09:18:07 --> Language Class Initialized
INFO - 2023-03-10 09:18:07 --> Loader Class Initialized
INFO - 2023-03-10 09:18:07 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:07 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:07 --> Total execution time: 0.0522
INFO - 2023-03-10 09:18:09 --> Config Class Initialized
INFO - 2023-03-10 09:18:09 --> Config Class Initialized
INFO - 2023-03-10 09:18:09 --> Hooks Class Initialized
INFO - 2023-03-10 09:18:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:09 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:18:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:09 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:09 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:09 --> URI Class Initialized
INFO - 2023-03-10 09:18:09 --> URI Class Initialized
INFO - 2023-03-10 09:18:09 --> Router Class Initialized
INFO - 2023-03-10 09:18:09 --> Router Class Initialized
INFO - 2023-03-10 09:18:09 --> Output Class Initialized
INFO - 2023-03-10 09:18:09 --> Output Class Initialized
INFO - 2023-03-10 09:18:09 --> Security Class Initialized
INFO - 2023-03-10 09:18:09 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:09 --> Input Class Initialized
INFO - 2023-03-10 09:18:09 --> Input Class Initialized
INFO - 2023-03-10 09:18:09 --> Language Class Initialized
INFO - 2023-03-10 09:18:09 --> Language Class Initialized
INFO - 2023-03-10 09:18:09 --> Loader Class Initialized
INFO - 2023-03-10 09:18:09 --> Loader Class Initialized
INFO - 2023-03-10 09:18:09 --> Controller Class Initialized
INFO - 2023-03-10 09:18:09 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:18:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:09 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:09 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:09 --> Total execution time: 0.0428
INFO - 2023-03-10 09:18:09 --> Config Class Initialized
INFO - 2023-03-10 09:18:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:09 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:09 --> URI Class Initialized
INFO - 2023-03-10 09:18:09 --> Router Class Initialized
INFO - 2023-03-10 09:18:09 --> Output Class Initialized
INFO - 2023-03-10 09:18:09 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:09 --> Input Class Initialized
INFO - 2023-03-10 09:18:09 --> Language Class Initialized
INFO - 2023-03-10 09:18:09 --> Loader Class Initialized
INFO - 2023-03-10 09:18:09 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:09 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:09 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:09 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:09 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:09 --> Total execution time: 0.0582
INFO - 2023-03-10 09:18:09 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:09 --> Total execution time: 0.0158
INFO - 2023-03-10 09:18:33 --> Config Class Initialized
INFO - 2023-03-10 09:18:33 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:33 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:33 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:33 --> URI Class Initialized
INFO - 2023-03-10 09:18:33 --> Router Class Initialized
INFO - 2023-03-10 09:18:33 --> Output Class Initialized
INFO - 2023-03-10 09:18:33 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:33 --> Input Class Initialized
INFO - 2023-03-10 09:18:33 --> Language Class Initialized
INFO - 2023-03-10 09:18:33 --> Loader Class Initialized
INFO - 2023-03-10 09:18:33 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:33 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:33 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:33 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:33 --> Total execution time: 0.0546
INFO - 2023-03-10 09:18:33 --> Config Class Initialized
INFO - 2023-03-10 09:18:33 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:33 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:33 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:33 --> URI Class Initialized
INFO - 2023-03-10 09:18:33 --> Router Class Initialized
INFO - 2023-03-10 09:18:33 --> Output Class Initialized
INFO - 2023-03-10 09:18:33 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:33 --> Input Class Initialized
INFO - 2023-03-10 09:18:33 --> Language Class Initialized
INFO - 2023-03-10 09:18:33 --> Loader Class Initialized
INFO - 2023-03-10 09:18:33 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:33 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:33 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:33 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:33 --> Total execution time: 0.0615
INFO - 2023-03-10 09:18:47 --> Config Class Initialized
INFO - 2023-03-10 09:18:47 --> Config Class Initialized
INFO - 2023-03-10 09:18:47 --> Hooks Class Initialized
INFO - 2023-03-10 09:18:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:18:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:47 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:47 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:47 --> URI Class Initialized
INFO - 2023-03-10 09:18:47 --> URI Class Initialized
INFO - 2023-03-10 09:18:47 --> Router Class Initialized
INFO - 2023-03-10 09:18:47 --> Router Class Initialized
INFO - 2023-03-10 09:18:47 --> Output Class Initialized
INFO - 2023-03-10 09:18:47 --> Output Class Initialized
INFO - 2023-03-10 09:18:47 --> Security Class Initialized
INFO - 2023-03-10 09:18:47 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:47 --> Input Class Initialized
INFO - 2023-03-10 09:18:47 --> Input Class Initialized
INFO - 2023-03-10 09:18:47 --> Language Class Initialized
INFO - 2023-03-10 09:18:47 --> Language Class Initialized
INFO - 2023-03-10 09:18:47 --> Loader Class Initialized
INFO - 2023-03-10 09:18:47 --> Loader Class Initialized
INFO - 2023-03-10 09:18:47 --> Controller Class Initialized
INFO - 2023-03-10 09:18:47 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:18:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:47 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:47 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:47 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:47 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:47 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:47 --> Total execution time: 0.0205
INFO - 2023-03-10 09:18:47 --> Config Class Initialized
INFO - 2023-03-10 09:18:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:47 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:47 --> URI Class Initialized
INFO - 2023-03-10 09:18:47 --> Router Class Initialized
INFO - 2023-03-10 09:18:47 --> Output Class Initialized
INFO - 2023-03-10 09:18:47 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:47 --> Input Class Initialized
INFO - 2023-03-10 09:18:47 --> Language Class Initialized
INFO - 2023-03-10 09:18:47 --> Loader Class Initialized
INFO - 2023-03-10 09:18:47 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:47 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:47 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:47 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:47 --> Total execution time: 0.0956
INFO - 2023-03-10 09:18:47 --> Config Class Initialized
INFO - 2023-03-10 09:18:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:47 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:47 --> URI Class Initialized
INFO - 2023-03-10 09:18:47 --> Router Class Initialized
INFO - 2023-03-10 09:18:47 --> Output Class Initialized
INFO - 2023-03-10 09:18:47 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:47 --> Input Class Initialized
INFO - 2023-03-10 09:18:47 --> Language Class Initialized
INFO - 2023-03-10 09:18:47 --> Loader Class Initialized
INFO - 2023-03-10 09:18:47 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:47 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:47 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:58 --> Config Class Initialized
INFO - 2023-03-10 09:18:58 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:58 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:58 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:58 --> URI Class Initialized
INFO - 2023-03-10 09:18:58 --> Router Class Initialized
INFO - 2023-03-10 09:18:58 --> Output Class Initialized
INFO - 2023-03-10 09:18:58 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:58 --> Input Class Initialized
INFO - 2023-03-10 09:18:58 --> Language Class Initialized
INFO - 2023-03-10 09:18:58 --> Loader Class Initialized
INFO - 2023-03-10 09:18:58 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:58 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:58 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:58 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:58 --> Total execution time: 0.0194
INFO - 2023-03-10 09:18:58 --> Config Class Initialized
INFO - 2023-03-10 09:18:58 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:18:58 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:18:58 --> Utf8 Class Initialized
INFO - 2023-03-10 09:18:58 --> URI Class Initialized
INFO - 2023-03-10 09:18:58 --> Router Class Initialized
INFO - 2023-03-10 09:18:58 --> Output Class Initialized
INFO - 2023-03-10 09:18:58 --> Security Class Initialized
DEBUG - 2023-03-10 09:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:18:58 --> Input Class Initialized
INFO - 2023-03-10 09:18:58 --> Language Class Initialized
INFO - 2023-03-10 09:18:58 --> Loader Class Initialized
INFO - 2023-03-10 09:18:58 --> Controller Class Initialized
DEBUG - 2023-03-10 09:18:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:18:58 --> Database Driver Class Initialized
INFO - 2023-03-10 09:18:58 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:18:58 --> Final output sent to browser
DEBUG - 2023-03-10 09:18:58 --> Total execution time: 0.0602
INFO - 2023-03-10 09:19:00 --> Config Class Initialized
INFO - 2023-03-10 09:19:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:00 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:00 --> URI Class Initialized
INFO - 2023-03-10 09:19:00 --> Router Class Initialized
INFO - 2023-03-10 09:19:00 --> Output Class Initialized
INFO - 2023-03-10 09:19:00 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:00 --> Input Class Initialized
INFO - 2023-03-10 09:19:00 --> Language Class Initialized
INFO - 2023-03-10 09:19:00 --> Loader Class Initialized
INFO - 2023-03-10 09:19:00 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:00 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:00 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:00 --> Total execution time: 0.1096
INFO - 2023-03-10 09:19:00 --> Config Class Initialized
INFO - 2023-03-10 09:19:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:00 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:00 --> URI Class Initialized
INFO - 2023-03-10 09:19:00 --> Router Class Initialized
INFO - 2023-03-10 09:19:00 --> Output Class Initialized
INFO - 2023-03-10 09:19:00 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:00 --> Input Class Initialized
INFO - 2023-03-10 09:19:00 --> Language Class Initialized
INFO - 2023-03-10 09:19:00 --> Loader Class Initialized
INFO - 2023-03-10 09:19:00 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:00 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:00 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:00 --> Total execution time: 0.0531
INFO - 2023-03-10 09:19:03 --> Config Class Initialized
INFO - 2023-03-10 09:19:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:03 --> URI Class Initialized
INFO - 2023-03-10 09:19:03 --> Router Class Initialized
INFO - 2023-03-10 09:19:03 --> Output Class Initialized
INFO - 2023-03-10 09:19:03 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:03 --> Input Class Initialized
INFO - 2023-03-10 09:19:03 --> Language Class Initialized
INFO - 2023-03-10 09:19:03 --> Loader Class Initialized
INFO - 2023-03-10 09:19:03 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:03 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:03 --> Total execution time: 0.0061
INFO - 2023-03-10 09:19:03 --> Config Class Initialized
INFO - 2023-03-10 09:19:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:03 --> URI Class Initialized
INFO - 2023-03-10 09:19:03 --> Router Class Initialized
INFO - 2023-03-10 09:19:03 --> Output Class Initialized
INFO - 2023-03-10 09:19:03 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:03 --> Input Class Initialized
INFO - 2023-03-10 09:19:03 --> Language Class Initialized
INFO - 2023-03-10 09:19:03 --> Loader Class Initialized
INFO - 2023-03-10 09:19:03 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:03 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:03 --> Model "Login_model" initialized
INFO - 2023-03-10 09:19:03 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:03 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:03 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:03 --> Total execution time: 0.1087
INFO - 2023-03-10 09:19:03 --> Config Class Initialized
INFO - 2023-03-10 09:19:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:03 --> URI Class Initialized
INFO - 2023-03-10 09:19:03 --> Router Class Initialized
INFO - 2023-03-10 09:19:03 --> Output Class Initialized
INFO - 2023-03-10 09:19:03 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:03 --> Input Class Initialized
INFO - 2023-03-10 09:19:03 --> Language Class Initialized
INFO - 2023-03-10 09:19:03 --> Loader Class Initialized
INFO - 2023-03-10 09:19:03 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:03 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:03 --> Total execution time: 0.0427
INFO - 2023-03-10 09:19:03 --> Config Class Initialized
INFO - 2023-03-10 09:19:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:03 --> URI Class Initialized
INFO - 2023-03-10 09:19:03 --> Router Class Initialized
INFO - 2023-03-10 09:19:03 --> Output Class Initialized
INFO - 2023-03-10 09:19:03 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:03 --> Input Class Initialized
INFO - 2023-03-10 09:19:03 --> Language Class Initialized
INFO - 2023-03-10 09:19:03 --> Loader Class Initialized
INFO - 2023-03-10 09:19:03 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:03 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:03 --> Model "Login_model" initialized
INFO - 2023-03-10 09:19:03 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:03 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:03 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:03 --> Total execution time: 0.0259
INFO - 2023-03-10 09:19:06 --> Config Class Initialized
INFO - 2023-03-10 09:19:06 --> Config Class Initialized
INFO - 2023-03-10 09:19:06 --> Hooks Class Initialized
INFO - 2023-03-10 09:19:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:19:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:06 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:06 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:06 --> URI Class Initialized
INFO - 2023-03-10 09:19:06 --> URI Class Initialized
INFO - 2023-03-10 09:19:06 --> Router Class Initialized
INFO - 2023-03-10 09:19:06 --> Router Class Initialized
INFO - 2023-03-10 09:19:06 --> Output Class Initialized
INFO - 2023-03-10 09:19:06 --> Output Class Initialized
INFO - 2023-03-10 09:19:06 --> Security Class Initialized
INFO - 2023-03-10 09:19:06 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:06 --> Input Class Initialized
INFO - 2023-03-10 09:19:06 --> Input Class Initialized
INFO - 2023-03-10 09:19:06 --> Language Class Initialized
INFO - 2023-03-10 09:19:06 --> Language Class Initialized
INFO - 2023-03-10 09:19:06 --> Loader Class Initialized
INFO - 2023-03-10 09:19:06 --> Loader Class Initialized
INFO - 2023-03-10 09:19:06 --> Controller Class Initialized
INFO - 2023-03-10 09:19:06 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:19:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:06 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:06 --> Total execution time: 0.0319
INFO - 2023-03-10 09:19:06 --> Config Class Initialized
INFO - 2023-03-10 09:19:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:06 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:06 --> URI Class Initialized
INFO - 2023-03-10 09:19:06 --> Router Class Initialized
INFO - 2023-03-10 09:19:06 --> Output Class Initialized
INFO - 2023-03-10 09:19:06 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:06 --> Input Class Initialized
INFO - 2023-03-10 09:19:06 --> Language Class Initialized
INFO - 2023-03-10 09:19:06 --> Loader Class Initialized
INFO - 2023-03-10 09:19:06 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:06 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:06 --> Total execution time: 0.0504
INFO - 2023-03-10 09:19:06 --> Config Class Initialized
INFO - 2023-03-10 09:19:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:06 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:06 --> URI Class Initialized
INFO - 2023-03-10 09:19:06 --> Router Class Initialized
INFO - 2023-03-10 09:19:06 --> Output Class Initialized
INFO - 2023-03-10 09:19:06 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:06 --> Input Class Initialized
INFO - 2023-03-10 09:19:06 --> Language Class Initialized
INFO - 2023-03-10 09:19:06 --> Loader Class Initialized
INFO - 2023-03-10 09:19:06 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:07 --> Config Class Initialized
INFO - 2023-03-10 09:19:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:07 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:07 --> URI Class Initialized
INFO - 2023-03-10 09:19:07 --> Router Class Initialized
INFO - 2023-03-10 09:19:07 --> Output Class Initialized
INFO - 2023-03-10 09:19:07 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:07 --> Input Class Initialized
INFO - 2023-03-10 09:19:07 --> Language Class Initialized
INFO - 2023-03-10 09:19:07 --> Loader Class Initialized
INFO - 2023-03-10 09:19:07 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:07 --> Config Class Initialized
INFO - 2023-03-10 09:19:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:07 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:07 --> URI Class Initialized
INFO - 2023-03-10 09:19:07 --> Router Class Initialized
INFO - 2023-03-10 09:19:07 --> Output Class Initialized
INFO - 2023-03-10 09:19:07 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:07 --> Input Class Initialized
INFO - 2023-03-10 09:19:07 --> Language Class Initialized
INFO - 2023-03-10 09:19:07 --> Loader Class Initialized
INFO - 2023-03-10 09:19:07 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:08 --> Config Class Initialized
INFO - 2023-03-10 09:19:08 --> Config Class Initialized
INFO - 2023-03-10 09:19:08 --> Hooks Class Initialized
INFO - 2023-03-10 09:19:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:08 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:19:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:08 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:08 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:08 --> URI Class Initialized
INFO - 2023-03-10 09:19:08 --> URI Class Initialized
INFO - 2023-03-10 09:19:08 --> Router Class Initialized
INFO - 2023-03-10 09:19:08 --> Router Class Initialized
INFO - 2023-03-10 09:19:08 --> Output Class Initialized
INFO - 2023-03-10 09:19:08 --> Output Class Initialized
INFO - 2023-03-10 09:19:08 --> Security Class Initialized
INFO - 2023-03-10 09:19:08 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:08 --> Input Class Initialized
INFO - 2023-03-10 09:19:08 --> Input Class Initialized
INFO - 2023-03-10 09:19:08 --> Language Class Initialized
INFO - 2023-03-10 09:19:08 --> Language Class Initialized
INFO - 2023-03-10 09:19:08 --> Loader Class Initialized
INFO - 2023-03-10 09:19:08 --> Loader Class Initialized
INFO - 2023-03-10 09:19:08 --> Controller Class Initialized
INFO - 2023-03-10 09:19:08 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:19:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:08 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:08 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:08 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:08 --> Total execution time: 0.0135
INFO - 2023-03-10 09:19:08 --> Config Class Initialized
INFO - 2023-03-10 09:19:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:08 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:08 --> URI Class Initialized
INFO - 2023-03-10 09:19:08 --> Router Class Initialized
INFO - 2023-03-10 09:19:08 --> Output Class Initialized
INFO - 2023-03-10 09:19:08 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:08 --> Input Class Initialized
INFO - 2023-03-10 09:19:08 --> Language Class Initialized
INFO - 2023-03-10 09:19:08 --> Loader Class Initialized
INFO - 2023-03-10 09:19:08 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:08 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:08 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:08 --> Total execution time: 0.0150
INFO - 2023-03-10 09:19:08 --> Config Class Initialized
INFO - 2023-03-10 09:19:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:08 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:08 --> URI Class Initialized
INFO - 2023-03-10 09:19:08 --> Router Class Initialized
INFO - 2023-03-10 09:19:08 --> Output Class Initialized
INFO - 2023-03-10 09:19:08 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:08 --> Input Class Initialized
INFO - 2023-03-10 09:19:08 --> Language Class Initialized
INFO - 2023-03-10 09:19:08 --> Loader Class Initialized
INFO - 2023-03-10 09:19:08 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:08 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:08 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:08 --> Total execution time: 0.0138
INFO - 2023-03-10 09:19:09 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:11 --> Config Class Initialized
INFO - 2023-03-10 09:19:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:11 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:11 --> URI Class Initialized
INFO - 2023-03-10 09:19:11 --> Router Class Initialized
INFO - 2023-03-10 09:19:11 --> Output Class Initialized
INFO - 2023-03-10 09:19:11 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:11 --> Input Class Initialized
INFO - 2023-03-10 09:19:11 --> Language Class Initialized
INFO - 2023-03-10 09:19:11 --> Loader Class Initialized
INFO - 2023-03-10 09:19:11 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:11 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:11 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:11 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:11 --> Total execution time: 0.0920
INFO - 2023-03-10 09:19:45 --> Config Class Initialized
INFO - 2023-03-10 09:19:45 --> Config Class Initialized
INFO - 2023-03-10 09:19:45 --> Hooks Class Initialized
INFO - 2023-03-10 09:19:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:45 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:19:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:45 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:45 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:45 --> URI Class Initialized
INFO - 2023-03-10 09:19:45 --> URI Class Initialized
INFO - 2023-03-10 09:19:45 --> Router Class Initialized
INFO - 2023-03-10 09:19:45 --> Router Class Initialized
INFO - 2023-03-10 09:19:45 --> Output Class Initialized
INFO - 2023-03-10 09:19:45 --> Output Class Initialized
INFO - 2023-03-10 09:19:45 --> Security Class Initialized
INFO - 2023-03-10 09:19:45 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:45 --> Input Class Initialized
INFO - 2023-03-10 09:19:45 --> Input Class Initialized
INFO - 2023-03-10 09:19:45 --> Language Class Initialized
INFO - 2023-03-10 09:19:45 --> Language Class Initialized
INFO - 2023-03-10 09:19:45 --> Loader Class Initialized
INFO - 2023-03-10 09:19:45 --> Loader Class Initialized
INFO - 2023-03-10 09:19:45 --> Controller Class Initialized
INFO - 2023-03-10 09:19:45 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:45 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:45 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:45 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:45 --> Total execution time: 0.0160
INFO - 2023-03-10 09:19:45 --> Config Class Initialized
INFO - 2023-03-10 09:19:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:45 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:45 --> URI Class Initialized
INFO - 2023-03-10 09:19:45 --> Router Class Initialized
INFO - 2023-03-10 09:19:45 --> Output Class Initialized
INFO - 2023-03-10 09:19:45 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:45 --> Input Class Initialized
INFO - 2023-03-10 09:19:45 --> Language Class Initialized
INFO - 2023-03-10 09:19:45 --> Loader Class Initialized
INFO - 2023-03-10 09:19:45 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:45 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:45 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:45 --> Total execution time: 0.0090
INFO - 2023-03-10 09:19:45 --> Config Class Initialized
INFO - 2023-03-10 09:19:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:45 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:45 --> URI Class Initialized
INFO - 2023-03-10 09:19:45 --> Router Class Initialized
INFO - 2023-03-10 09:19:45 --> Output Class Initialized
INFO - 2023-03-10 09:19:45 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:45 --> Input Class Initialized
INFO - 2023-03-10 09:19:45 --> Language Class Initialized
INFO - 2023-03-10 09:19:45 --> Loader Class Initialized
INFO - 2023-03-10 09:19:45 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:45 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:45 --> Config Class Initialized
INFO - 2023-03-10 09:19:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:45 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:45 --> URI Class Initialized
INFO - 2023-03-10 09:19:45 --> Router Class Initialized
INFO - 2023-03-10 09:19:45 --> Output Class Initialized
INFO - 2023-03-10 09:19:45 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:45 --> Input Class Initialized
INFO - 2023-03-10 09:19:45 --> Language Class Initialized
INFO - 2023-03-10 09:19:45 --> Loader Class Initialized
INFO - 2023-03-10 09:19:45 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:45 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:45 --> Config Class Initialized
INFO - 2023-03-10 09:19:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:45 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:45 --> URI Class Initialized
INFO - 2023-03-10 09:19:45 --> Router Class Initialized
INFO - 2023-03-10 09:19:45 --> Output Class Initialized
INFO - 2023-03-10 09:19:45 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:45 --> Input Class Initialized
INFO - 2023-03-10 09:19:45 --> Language Class Initialized
INFO - 2023-03-10 09:19:45 --> Loader Class Initialized
INFO - 2023-03-10 09:19:45 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:45 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:46 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:46 --> Config Class Initialized
INFO - 2023-03-10 09:19:46 --> Config Class Initialized
INFO - 2023-03-10 09:19:46 --> Hooks Class Initialized
INFO - 2023-03-10 09:19:46 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:46 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:19:46 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:46 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:46 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:46 --> URI Class Initialized
INFO - 2023-03-10 09:19:46 --> URI Class Initialized
INFO - 2023-03-10 09:19:46 --> Router Class Initialized
INFO - 2023-03-10 09:19:46 --> Router Class Initialized
INFO - 2023-03-10 09:19:46 --> Output Class Initialized
INFO - 2023-03-10 09:19:46 --> Output Class Initialized
INFO - 2023-03-10 09:19:46 --> Security Class Initialized
INFO - 2023-03-10 09:19:46 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:46 --> Input Class Initialized
INFO - 2023-03-10 09:19:46 --> Input Class Initialized
INFO - 2023-03-10 09:19:46 --> Language Class Initialized
INFO - 2023-03-10 09:19:46 --> Language Class Initialized
INFO - 2023-03-10 09:19:46 --> Loader Class Initialized
INFO - 2023-03-10 09:19:46 --> Loader Class Initialized
INFO - 2023-03-10 09:19:46 --> Controller Class Initialized
INFO - 2023-03-10 09:19:46 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:19:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:46 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:46 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:46 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:46 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:46 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:46 --> Total execution time: 0.0139
INFO - 2023-03-10 09:19:47 --> Config Class Initialized
INFO - 2023-03-10 09:19:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:47 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:47 --> URI Class Initialized
INFO - 2023-03-10 09:19:47 --> Router Class Initialized
INFO - 2023-03-10 09:19:47 --> Output Class Initialized
INFO - 2023-03-10 09:19:47 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:47 --> Input Class Initialized
INFO - 2023-03-10 09:19:47 --> Language Class Initialized
INFO - 2023-03-10 09:19:47 --> Loader Class Initialized
INFO - 2023-03-10 09:19:47 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:47 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:47 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:47 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:47 --> Total execution time: 0.0144
INFO - 2023-03-10 09:19:47 --> Config Class Initialized
INFO - 2023-03-10 09:19:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:47 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:47 --> URI Class Initialized
INFO - 2023-03-10 09:19:47 --> Router Class Initialized
INFO - 2023-03-10 09:19:47 --> Output Class Initialized
INFO - 2023-03-10 09:19:47 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:47 --> Input Class Initialized
INFO - 2023-03-10 09:19:47 --> Language Class Initialized
INFO - 2023-03-10 09:19:47 --> Loader Class Initialized
INFO - 2023-03-10 09:19:47 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:47 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:47 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:47 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:47 --> Total execution time: 0.0119
INFO - 2023-03-10 09:19:48 --> Config Class Initialized
INFO - 2023-03-10 09:19:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:48 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:48 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:48 --> URI Class Initialized
INFO - 2023-03-10 09:19:48 --> Router Class Initialized
INFO - 2023-03-10 09:19:48 --> Output Class Initialized
INFO - 2023-03-10 09:19:48 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:48 --> Input Class Initialized
INFO - 2023-03-10 09:19:48 --> Language Class Initialized
INFO - 2023-03-10 09:19:48 --> Loader Class Initialized
INFO - 2023-03-10 09:19:48 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:48 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:48 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:48 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:48 --> Total execution time: 0.0168
INFO - 2023-03-10 09:19:48 --> Config Class Initialized
INFO - 2023-03-10 09:19:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:49 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:49 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:49 --> URI Class Initialized
INFO - 2023-03-10 09:19:49 --> Router Class Initialized
INFO - 2023-03-10 09:19:49 --> Output Class Initialized
INFO - 2023-03-10 09:19:49 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:49 --> Input Class Initialized
INFO - 2023-03-10 09:19:49 --> Language Class Initialized
INFO - 2023-03-10 09:19:49 --> Loader Class Initialized
INFO - 2023-03-10 09:19:49 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:49 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:49 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:49 --> Config Class Initialized
INFO - 2023-03-10 09:19:49 --> Config Class Initialized
INFO - 2023-03-10 09:19:49 --> Hooks Class Initialized
INFO - 2023-03-10 09:19:49 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:19:49 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:49 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:49 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:49 --> URI Class Initialized
INFO - 2023-03-10 09:19:49 --> URI Class Initialized
INFO - 2023-03-10 09:19:49 --> Router Class Initialized
INFO - 2023-03-10 09:19:49 --> Router Class Initialized
INFO - 2023-03-10 09:19:49 --> Output Class Initialized
INFO - 2023-03-10 09:19:49 --> Output Class Initialized
INFO - 2023-03-10 09:19:49 --> Security Class Initialized
INFO - 2023-03-10 09:19:49 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:49 --> Input Class Initialized
INFO - 2023-03-10 09:19:49 --> Input Class Initialized
INFO - 2023-03-10 09:19:49 --> Language Class Initialized
INFO - 2023-03-10 09:19:49 --> Language Class Initialized
INFO - 2023-03-10 09:19:49 --> Loader Class Initialized
INFO - 2023-03-10 09:19:49 --> Loader Class Initialized
INFO - 2023-03-10 09:19:49 --> Controller Class Initialized
INFO - 2023-03-10 09:19:49 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:19:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:49 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:49 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:49 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:49 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:49 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:49 --> Total execution time: 0.0151
INFO - 2023-03-10 09:19:51 --> Config Class Initialized
INFO - 2023-03-10 09:19:51 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:51 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:51 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:51 --> URI Class Initialized
INFO - 2023-03-10 09:19:51 --> Router Class Initialized
INFO - 2023-03-10 09:19:51 --> Output Class Initialized
INFO - 2023-03-10 09:19:51 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:51 --> Input Class Initialized
INFO - 2023-03-10 09:19:51 --> Language Class Initialized
INFO - 2023-03-10 09:19:51 --> Loader Class Initialized
INFO - 2023-03-10 09:19:51 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:51 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:51 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:51 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:51 --> Total execution time: 0.0328
INFO - 2023-03-10 09:19:53 --> Config Class Initialized
INFO - 2023-03-10 09:19:53 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:53 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:53 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:53 --> URI Class Initialized
INFO - 2023-03-10 09:19:53 --> Router Class Initialized
INFO - 2023-03-10 09:19:53 --> Output Class Initialized
INFO - 2023-03-10 09:19:53 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:53 --> Input Class Initialized
INFO - 2023-03-10 09:19:53 --> Language Class Initialized
INFO - 2023-03-10 09:19:53 --> Loader Class Initialized
INFO - 2023-03-10 09:19:53 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:53 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:53 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:53 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:53 --> Total execution time: 0.0167
INFO - 2023-03-10 09:19:53 --> Config Class Initialized
INFO - 2023-03-10 09:19:53 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:53 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:53 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:53 --> URI Class Initialized
INFO - 2023-03-10 09:19:53 --> Router Class Initialized
INFO - 2023-03-10 09:19:53 --> Output Class Initialized
INFO - 2023-03-10 09:19:53 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:53 --> Input Class Initialized
INFO - 2023-03-10 09:19:53 --> Language Class Initialized
INFO - 2023-03-10 09:19:53 --> Loader Class Initialized
INFO - 2023-03-10 09:19:53 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:53 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:53 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:53 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:53 --> Total execution time: 0.0127
INFO - 2023-03-10 09:19:53 --> Config Class Initialized
INFO - 2023-03-10 09:19:53 --> Config Class Initialized
INFO - 2023-03-10 09:19:53 --> Hooks Class Initialized
INFO - 2023-03-10 09:19:53 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:53 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:19:53 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:53 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:53 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:53 --> URI Class Initialized
INFO - 2023-03-10 09:19:53 --> URI Class Initialized
INFO - 2023-03-10 09:19:53 --> Router Class Initialized
INFO - 2023-03-10 09:19:53 --> Output Class Initialized
INFO - 2023-03-10 09:19:53 --> Router Class Initialized
INFO - 2023-03-10 09:19:53 --> Security Class Initialized
INFO - 2023-03-10 09:19:53 --> Output Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:53 --> Security Class Initialized
INFO - 2023-03-10 09:19:53 --> Input Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:53 --> Language Class Initialized
INFO - 2023-03-10 09:19:53 --> Input Class Initialized
INFO - 2023-03-10 09:19:53 --> Language Class Initialized
INFO - 2023-03-10 09:19:53 --> Loader Class Initialized
INFO - 2023-03-10 09:19:53 --> Loader Class Initialized
INFO - 2023-03-10 09:19:53 --> Controller Class Initialized
INFO - 2023-03-10 09:19:53 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:53 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:53 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:53 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:53 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:53 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:53 --> Total execution time: 0.0151
INFO - 2023-03-10 09:19:53 --> Config Class Initialized
INFO - 2023-03-10 09:19:53 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:53 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:53 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:53 --> URI Class Initialized
INFO - 2023-03-10 09:19:53 --> Router Class Initialized
INFO - 2023-03-10 09:19:53 --> Output Class Initialized
INFO - 2023-03-10 09:19:53 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:53 --> Input Class Initialized
INFO - 2023-03-10 09:19:53 --> Language Class Initialized
INFO - 2023-03-10 09:19:53 --> Loader Class Initialized
INFO - 2023-03-10 09:19:53 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:53 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:53 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:53 --> Final output sent to browser
DEBUG - 2023-03-10 09:19:53 --> Total execution time: 0.0099
INFO - 2023-03-10 09:19:53 --> Config Class Initialized
INFO - 2023-03-10 09:19:53 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:53 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:53 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:53 --> URI Class Initialized
INFO - 2023-03-10 09:19:53 --> Router Class Initialized
INFO - 2023-03-10 09:19:53 --> Output Class Initialized
INFO - 2023-03-10 09:19:53 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:53 --> Input Class Initialized
INFO - 2023-03-10 09:19:53 --> Language Class Initialized
INFO - 2023-03-10 09:19:53 --> Loader Class Initialized
INFO - 2023-03-10 09:19:53 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:53 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:53 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:54 --> Config Class Initialized
INFO - 2023-03-10 09:19:54 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:54 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:54 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:54 --> URI Class Initialized
INFO - 2023-03-10 09:19:54 --> Router Class Initialized
INFO - 2023-03-10 09:19:54 --> Output Class Initialized
INFO - 2023-03-10 09:19:54 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:54 --> Input Class Initialized
INFO - 2023-03-10 09:19:54 --> Language Class Initialized
INFO - 2023-03-10 09:19:54 --> Loader Class Initialized
INFO - 2023-03-10 09:19:54 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:54 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:54 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:19:54 --> Config Class Initialized
INFO - 2023-03-10 09:19:54 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:19:54 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:19:54 --> Utf8 Class Initialized
INFO - 2023-03-10 09:19:54 --> URI Class Initialized
INFO - 2023-03-10 09:19:54 --> Router Class Initialized
INFO - 2023-03-10 09:19:54 --> Output Class Initialized
INFO - 2023-03-10 09:19:54 --> Security Class Initialized
DEBUG - 2023-03-10 09:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:19:54 --> Input Class Initialized
INFO - 2023-03-10 09:19:54 --> Language Class Initialized
INFO - 2023-03-10 09:19:54 --> Loader Class Initialized
INFO - 2023-03-10 09:19:54 --> Controller Class Initialized
DEBUG - 2023-03-10 09:19:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:19:54 --> Database Driver Class Initialized
INFO - 2023-03-10 09:19:54 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:20:20 --> Config Class Initialized
INFO - 2023-03-10 09:20:20 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:20:20 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:20:20 --> Utf8 Class Initialized
INFO - 2023-03-10 09:20:20 --> URI Class Initialized
INFO - 2023-03-10 09:20:20 --> Router Class Initialized
INFO - 2023-03-10 09:20:20 --> Output Class Initialized
INFO - 2023-03-10 09:20:20 --> Security Class Initialized
DEBUG - 2023-03-10 09:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:20:20 --> Input Class Initialized
INFO - 2023-03-10 09:20:20 --> Language Class Initialized
INFO - 2023-03-10 09:20:20 --> Loader Class Initialized
INFO - 2023-03-10 09:20:20 --> Controller Class Initialized
DEBUG - 2023-03-10 09:20:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:20:20 --> Database Driver Class Initialized
INFO - 2023-03-10 09:20:20 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:20:20 --> Final output sent to browser
DEBUG - 2023-03-10 09:20:20 --> Total execution time: 0.0158
INFO - 2023-03-10 09:20:20 --> Config Class Initialized
INFO - 2023-03-10 09:20:20 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:20:20 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:20:20 --> Utf8 Class Initialized
INFO - 2023-03-10 09:20:20 --> URI Class Initialized
INFO - 2023-03-10 09:20:20 --> Router Class Initialized
INFO - 2023-03-10 09:20:20 --> Output Class Initialized
INFO - 2023-03-10 09:20:20 --> Security Class Initialized
DEBUG - 2023-03-10 09:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:20:20 --> Input Class Initialized
INFO - 2023-03-10 09:20:20 --> Language Class Initialized
INFO - 2023-03-10 09:20:20 --> Loader Class Initialized
INFO - 2023-03-10 09:20:20 --> Controller Class Initialized
DEBUG - 2023-03-10 09:20:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:20:20 --> Database Driver Class Initialized
INFO - 2023-03-10 09:20:20 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:20:20 --> Final output sent to browser
DEBUG - 2023-03-10 09:20:20 --> Total execution time: 0.0131
INFO - 2023-03-10 09:23:07 --> Config Class Initialized
INFO - 2023-03-10 09:23:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:23:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:23:07 --> Utf8 Class Initialized
INFO - 2023-03-10 09:23:07 --> URI Class Initialized
INFO - 2023-03-10 09:23:07 --> Router Class Initialized
INFO - 2023-03-10 09:23:07 --> Output Class Initialized
INFO - 2023-03-10 09:23:07 --> Security Class Initialized
DEBUG - 2023-03-10 09:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:23:07 --> Input Class Initialized
INFO - 2023-03-10 09:23:07 --> Language Class Initialized
INFO - 2023-03-10 09:23:07 --> Loader Class Initialized
INFO - 2023-03-10 09:23:07 --> Controller Class Initialized
DEBUG - 2023-03-10 09:23:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:23:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:23:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:23:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:23:07 --> Model "Login_model" initialized
INFO - 2023-03-10 09:23:07 --> Final output sent to browser
DEBUG - 2023-03-10 09:23:07 --> Total execution time: 0.1443
INFO - 2023-03-10 09:23:07 --> Config Class Initialized
INFO - 2023-03-10 09:23:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:23:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:23:07 --> Utf8 Class Initialized
INFO - 2023-03-10 09:23:07 --> URI Class Initialized
INFO - 2023-03-10 09:23:07 --> Router Class Initialized
INFO - 2023-03-10 09:23:07 --> Output Class Initialized
INFO - 2023-03-10 09:23:07 --> Security Class Initialized
DEBUG - 2023-03-10 09:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:23:07 --> Input Class Initialized
INFO - 2023-03-10 09:23:07 --> Language Class Initialized
INFO - 2023-03-10 09:23:07 --> Loader Class Initialized
INFO - 2023-03-10 09:23:07 --> Controller Class Initialized
DEBUG - 2023-03-10 09:23:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:23:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:23:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:23:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:23:07 --> Model "Login_model" initialized
INFO - 2023-03-10 09:23:07 --> Final output sent to browser
DEBUG - 2023-03-10 09:23:07 --> Total execution time: 0.0567
INFO - 2023-03-10 09:23:11 --> Config Class Initialized
INFO - 2023-03-10 09:23:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:23:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:23:11 --> Utf8 Class Initialized
INFO - 2023-03-10 09:23:11 --> URI Class Initialized
INFO - 2023-03-10 09:23:11 --> Router Class Initialized
INFO - 2023-03-10 09:23:11 --> Output Class Initialized
INFO - 2023-03-10 09:23:11 --> Security Class Initialized
DEBUG - 2023-03-10 09:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:23:11 --> Input Class Initialized
INFO - 2023-03-10 09:23:11 --> Language Class Initialized
INFO - 2023-03-10 09:23:11 --> Loader Class Initialized
INFO - 2023-03-10 09:23:11 --> Controller Class Initialized
DEBUG - 2023-03-10 09:23:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:23:11 --> Database Driver Class Initialized
INFO - 2023-03-10 09:23:11 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:23:11 --> Final output sent to browser
DEBUG - 2023-03-10 09:23:11 --> Total execution time: 0.0187
INFO - 2023-03-10 09:23:11 --> Config Class Initialized
INFO - 2023-03-10 09:23:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:23:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:23:11 --> Utf8 Class Initialized
INFO - 2023-03-10 09:23:11 --> URI Class Initialized
INFO - 2023-03-10 09:23:11 --> Router Class Initialized
INFO - 2023-03-10 09:23:11 --> Output Class Initialized
INFO - 2023-03-10 09:23:11 --> Security Class Initialized
DEBUG - 2023-03-10 09:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:23:11 --> Input Class Initialized
INFO - 2023-03-10 09:23:11 --> Language Class Initialized
INFO - 2023-03-10 09:23:11 --> Loader Class Initialized
INFO - 2023-03-10 09:23:11 --> Controller Class Initialized
DEBUG - 2023-03-10 09:23:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:23:11 --> Database Driver Class Initialized
INFO - 2023-03-10 09:23:11 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:23:11 --> Final output sent to browser
DEBUG - 2023-03-10 09:23:11 --> Total execution time: 0.0519
INFO - 2023-03-10 09:24:26 --> Config Class Initialized
INFO - 2023-03-10 09:24:26 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:24:26 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:24:26 --> Utf8 Class Initialized
INFO - 2023-03-10 09:24:26 --> URI Class Initialized
INFO - 2023-03-10 09:24:26 --> Router Class Initialized
INFO - 2023-03-10 09:24:26 --> Output Class Initialized
INFO - 2023-03-10 09:24:26 --> Security Class Initialized
DEBUG - 2023-03-10 09:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:24:26 --> Input Class Initialized
INFO - 2023-03-10 09:24:26 --> Language Class Initialized
INFO - 2023-03-10 09:24:26 --> Loader Class Initialized
INFO - 2023-03-10 09:24:26 --> Controller Class Initialized
DEBUG - 2023-03-10 09:24:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:24:26 --> Database Driver Class Initialized
INFO - 2023-03-10 09:24:26 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:24:26 --> Final output sent to browser
DEBUG - 2023-03-10 09:24:26 --> Total execution time: 0.0528
INFO - 2023-03-10 09:24:26 --> Config Class Initialized
INFO - 2023-03-10 09:24:26 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:24:26 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:24:26 --> Utf8 Class Initialized
INFO - 2023-03-10 09:24:26 --> URI Class Initialized
INFO - 2023-03-10 09:24:26 --> Router Class Initialized
INFO - 2023-03-10 09:24:26 --> Output Class Initialized
INFO - 2023-03-10 09:24:26 --> Security Class Initialized
DEBUG - 2023-03-10 09:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:24:26 --> Input Class Initialized
INFO - 2023-03-10 09:24:26 --> Language Class Initialized
INFO - 2023-03-10 09:24:26 --> Loader Class Initialized
INFO - 2023-03-10 09:24:26 --> Controller Class Initialized
DEBUG - 2023-03-10 09:24:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:24:26 --> Database Driver Class Initialized
INFO - 2023-03-10 09:24:26 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:24:26 --> Final output sent to browser
DEBUG - 2023-03-10 09:24:26 --> Total execution time: 0.0173
INFO - 2023-03-10 09:25:59 --> Config Class Initialized
INFO - 2023-03-10 09:25:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:25:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:25:59 --> Utf8 Class Initialized
INFO - 2023-03-10 09:25:59 --> URI Class Initialized
INFO - 2023-03-10 09:25:59 --> Router Class Initialized
INFO - 2023-03-10 09:25:59 --> Output Class Initialized
INFO - 2023-03-10 09:25:59 --> Security Class Initialized
DEBUG - 2023-03-10 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:25:59 --> Input Class Initialized
INFO - 2023-03-10 09:25:59 --> Language Class Initialized
INFO - 2023-03-10 09:25:59 --> Loader Class Initialized
INFO - 2023-03-10 09:25:59 --> Controller Class Initialized
DEBUG - 2023-03-10 09:25:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:25:59 --> Database Driver Class Initialized
INFO - 2023-03-10 09:25:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:25:59 --> Final output sent to browser
DEBUG - 2023-03-10 09:25:59 --> Total execution time: 0.0469
INFO - 2023-03-10 09:25:59 --> Config Class Initialized
INFO - 2023-03-10 09:25:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:25:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:25:59 --> Utf8 Class Initialized
INFO - 2023-03-10 09:25:59 --> URI Class Initialized
INFO - 2023-03-10 09:25:59 --> Router Class Initialized
INFO - 2023-03-10 09:25:59 --> Output Class Initialized
INFO - 2023-03-10 09:25:59 --> Security Class Initialized
DEBUG - 2023-03-10 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:25:59 --> Input Class Initialized
INFO - 2023-03-10 09:25:59 --> Language Class Initialized
INFO - 2023-03-10 09:25:59 --> Loader Class Initialized
INFO - 2023-03-10 09:25:59 --> Controller Class Initialized
DEBUG - 2023-03-10 09:25:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:25:59 --> Database Driver Class Initialized
INFO - 2023-03-10 09:25:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:25:59 --> Final output sent to browser
DEBUG - 2023-03-10 09:25:59 --> Total execution time: 0.0147
INFO - 2023-03-10 09:26:03 --> Config Class Initialized
INFO - 2023-03-10 09:26:03 --> Config Class Initialized
INFO - 2023-03-10 09:26:03 --> Hooks Class Initialized
INFO - 2023-03-10 09:26:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:03 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:26:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:03 --> URI Class Initialized
INFO - 2023-03-10 09:26:03 --> URI Class Initialized
INFO - 2023-03-10 09:26:03 --> Router Class Initialized
INFO - 2023-03-10 09:26:03 --> Output Class Initialized
INFO - 2023-03-10 09:26:03 --> Router Class Initialized
INFO - 2023-03-10 09:26:03 --> Security Class Initialized
INFO - 2023-03-10 09:26:03 --> Output Class Initialized
DEBUG - 2023-03-10 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:03 --> Security Class Initialized
INFO - 2023-03-10 09:26:03 --> Input Class Initialized
DEBUG - 2023-03-10 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:03 --> Language Class Initialized
INFO - 2023-03-10 09:26:03 --> Input Class Initialized
INFO - 2023-03-10 09:26:03 --> Language Class Initialized
INFO - 2023-03-10 09:26:03 --> Loader Class Initialized
INFO - 2023-03-10 09:26:03 --> Loader Class Initialized
INFO - 2023-03-10 09:26:03 --> Controller Class Initialized
INFO - 2023-03-10 09:26:03 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:26:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:03 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:03 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:03 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:03 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:03 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:03 --> Total execution time: 0.0179
INFO - 2023-03-10 09:26:03 --> Config Class Initialized
INFO - 2023-03-10 09:26:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:03 --> URI Class Initialized
INFO - 2023-03-10 09:26:03 --> Router Class Initialized
INFO - 2023-03-10 09:26:03 --> Output Class Initialized
INFO - 2023-03-10 09:26:03 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:03 --> Input Class Initialized
INFO - 2023-03-10 09:26:03 --> Language Class Initialized
INFO - 2023-03-10 09:26:03 --> Loader Class Initialized
INFO - 2023-03-10 09:26:03 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:03 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:03 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:04 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:04 --> Total execution time: 0.1350
INFO - 2023-03-10 09:26:04 --> Config Class Initialized
INFO - 2023-03-10 09:26:04 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:04 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:04 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:04 --> URI Class Initialized
INFO - 2023-03-10 09:26:04 --> Router Class Initialized
INFO - 2023-03-10 09:26:04 --> Output Class Initialized
INFO - 2023-03-10 09:26:04 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:04 --> Input Class Initialized
INFO - 2023-03-10 09:26:04 --> Language Class Initialized
INFO - 2023-03-10 09:26:04 --> Loader Class Initialized
INFO - 2023-03-10 09:26:04 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:04 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:04 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:06 --> Config Class Initialized
INFO - 2023-03-10 09:26:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:06 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:06 --> URI Class Initialized
INFO - 2023-03-10 09:26:06 --> Router Class Initialized
INFO - 2023-03-10 09:26:06 --> Output Class Initialized
INFO - 2023-03-10 09:26:06 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:06 --> Input Class Initialized
INFO - 2023-03-10 09:26:06 --> Language Class Initialized
INFO - 2023-03-10 09:26:06 --> Loader Class Initialized
INFO - 2023-03-10 09:26:06 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:06 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:06 --> Total execution time: 0.0231
INFO - 2023-03-10 09:26:06 --> Config Class Initialized
INFO - 2023-03-10 09:26:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:06 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:06 --> URI Class Initialized
INFO - 2023-03-10 09:26:06 --> Router Class Initialized
INFO - 2023-03-10 09:26:06 --> Output Class Initialized
INFO - 2023-03-10 09:26:06 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:06 --> Input Class Initialized
INFO - 2023-03-10 09:26:06 --> Language Class Initialized
INFO - 2023-03-10 09:26:06 --> Loader Class Initialized
INFO - 2023-03-10 09:26:06 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:06 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:06 --> Total execution time: 0.0184
INFO - 2023-03-10 09:26:36 --> Config Class Initialized
INFO - 2023-03-10 09:26:36 --> Config Class Initialized
INFO - 2023-03-10 09:26:36 --> Hooks Class Initialized
INFO - 2023-03-10 09:26:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:36 --> Utf8 Class Initialized
DEBUG - 2023-03-10 09:26:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:36 --> URI Class Initialized
INFO - 2023-03-10 09:26:36 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:36 --> Router Class Initialized
INFO - 2023-03-10 09:26:36 --> URI Class Initialized
INFO - 2023-03-10 09:26:36 --> Output Class Initialized
INFO - 2023-03-10 09:26:36 --> Router Class Initialized
INFO - 2023-03-10 09:26:36 --> Security Class Initialized
INFO - 2023-03-10 09:26:36 --> Output Class Initialized
DEBUG - 2023-03-10 09:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:36 --> Security Class Initialized
INFO - 2023-03-10 09:26:36 --> Input Class Initialized
DEBUG - 2023-03-10 09:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:36 --> Language Class Initialized
INFO - 2023-03-10 09:26:36 --> Input Class Initialized
INFO - 2023-03-10 09:26:36 --> Language Class Initialized
INFO - 2023-03-10 09:26:36 --> Loader Class Initialized
INFO - 2023-03-10 09:26:36 --> Controller Class Initialized
INFO - 2023-03-10 09:26:36 --> Loader Class Initialized
DEBUG - 2023-03-10 09:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:36 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:36 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:36 --> Total execution time: 0.0189
INFO - 2023-03-10 09:26:36 --> Config Class Initialized
INFO - 2023-03-10 09:26:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:36 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:36 --> URI Class Initialized
INFO - 2023-03-10 09:26:36 --> Router Class Initialized
INFO - 2023-03-10 09:26:36 --> Output Class Initialized
INFO - 2023-03-10 09:26:36 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:36 --> Input Class Initialized
INFO - 2023-03-10 09:26:36 --> Language Class Initialized
INFO - 2023-03-10 09:26:36 --> Loader Class Initialized
INFO - 2023-03-10 09:26:36 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:36 --> Config Class Initialized
INFO - 2023-03-10 09:26:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:36 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:36 --> URI Class Initialized
INFO - 2023-03-10 09:26:36 --> Router Class Initialized
INFO - 2023-03-10 09:26:36 --> Output Class Initialized
INFO - 2023-03-10 09:26:36 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:36 --> Input Class Initialized
INFO - 2023-03-10 09:26:36 --> Language Class Initialized
INFO - 2023-03-10 09:26:36 --> Loader Class Initialized
INFO - 2023-03-10 09:26:36 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:36 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:36 --> Total execution time: 0.1259
INFO - 2023-03-10 09:26:37 --> Config Class Initialized
INFO - 2023-03-10 09:26:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:37 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:37 --> URI Class Initialized
INFO - 2023-03-10 09:26:37 --> Router Class Initialized
INFO - 2023-03-10 09:26:37 --> Output Class Initialized
INFO - 2023-03-10 09:26:37 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:37 --> Input Class Initialized
INFO - 2023-03-10 09:26:37 --> Language Class Initialized
INFO - 2023-03-10 09:26:37 --> Loader Class Initialized
INFO - 2023-03-10 09:26:37 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:37 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:37 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:37 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:37 --> Total execution time: 0.0155
INFO - 2023-03-10 09:26:37 --> Config Class Initialized
INFO - 2023-03-10 09:26:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:37 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:37 --> URI Class Initialized
INFO - 2023-03-10 09:26:37 --> Router Class Initialized
INFO - 2023-03-10 09:26:37 --> Output Class Initialized
INFO - 2023-03-10 09:26:37 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:37 --> Input Class Initialized
INFO - 2023-03-10 09:26:37 --> Language Class Initialized
INFO - 2023-03-10 09:26:37 --> Loader Class Initialized
INFO - 2023-03-10 09:26:37 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:37 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:37 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:37 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:37 --> Total execution time: 0.0185
INFO - 2023-03-10 09:26:38 --> Config Class Initialized
INFO - 2023-03-10 09:26:38 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:38 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:38 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:38 --> URI Class Initialized
INFO - 2023-03-10 09:26:38 --> Router Class Initialized
INFO - 2023-03-10 09:26:38 --> Output Class Initialized
INFO - 2023-03-10 09:26:38 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:38 --> Input Class Initialized
INFO - 2023-03-10 09:26:38 --> Language Class Initialized
INFO - 2023-03-10 09:26:38 --> Loader Class Initialized
INFO - 2023-03-10 09:26:38 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:38 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:38 --> Total execution time: 0.0442
INFO - 2023-03-10 09:26:38 --> Config Class Initialized
INFO - 2023-03-10 09:26:38 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:38 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:38 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:38 --> URI Class Initialized
INFO - 2023-03-10 09:26:38 --> Router Class Initialized
INFO - 2023-03-10 09:26:38 --> Output Class Initialized
INFO - 2023-03-10 09:26:38 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:38 --> Input Class Initialized
INFO - 2023-03-10 09:26:38 --> Language Class Initialized
INFO - 2023-03-10 09:26:38 --> Loader Class Initialized
INFO - 2023-03-10 09:26:38 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:38 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:38 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:38 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:38 --> Total execution time: 0.0991
INFO - 2023-03-10 09:26:44 --> Config Class Initialized
INFO - 2023-03-10 09:26:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:44 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:44 --> URI Class Initialized
INFO - 2023-03-10 09:26:44 --> Router Class Initialized
INFO - 2023-03-10 09:26:44 --> Output Class Initialized
INFO - 2023-03-10 09:26:44 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:44 --> Input Class Initialized
INFO - 2023-03-10 09:26:44 --> Language Class Initialized
INFO - 2023-03-10 09:26:44 --> Loader Class Initialized
INFO - 2023-03-10 09:26:44 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:44 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:44 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:44 --> Total execution time: 0.0199
INFO - 2023-03-10 09:26:44 --> Config Class Initialized
INFO - 2023-03-10 09:26:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:26:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:26:44 --> Utf8 Class Initialized
INFO - 2023-03-10 09:26:44 --> URI Class Initialized
INFO - 2023-03-10 09:26:44 --> Router Class Initialized
INFO - 2023-03-10 09:26:44 --> Output Class Initialized
INFO - 2023-03-10 09:26:44 --> Security Class Initialized
DEBUG - 2023-03-10 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:26:44 --> Input Class Initialized
INFO - 2023-03-10 09:26:44 --> Language Class Initialized
INFO - 2023-03-10 09:26:44 --> Loader Class Initialized
INFO - 2023-03-10 09:26:44 --> Controller Class Initialized
DEBUG - 2023-03-10 09:26:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:26:44 --> Database Driver Class Initialized
INFO - 2023-03-10 09:26:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:26:44 --> Final output sent to browser
DEBUG - 2023-03-10 09:26:44 --> Total execution time: 0.0155
INFO - 2023-03-10 09:27:21 --> Config Class Initialized
INFO - 2023-03-10 09:27:21 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:27:21 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:27:21 --> Utf8 Class Initialized
INFO - 2023-03-10 09:27:21 --> URI Class Initialized
INFO - 2023-03-10 09:27:21 --> Router Class Initialized
INFO - 2023-03-10 09:27:21 --> Output Class Initialized
INFO - 2023-03-10 09:27:21 --> Security Class Initialized
DEBUG - 2023-03-10 09:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:27:21 --> Input Class Initialized
INFO - 2023-03-10 09:27:21 --> Language Class Initialized
ERROR - 2023-03-10 09:27:21 --> 404 Page Not Found: user/Cluster/SchemaList
INFO - 2023-03-10 09:29:52 --> Config Class Initialized
INFO - 2023-03-10 09:29:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:29:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:29:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:29:52 --> URI Class Initialized
INFO - 2023-03-10 09:29:52 --> Router Class Initialized
INFO - 2023-03-10 09:29:52 --> Output Class Initialized
INFO - 2023-03-10 09:29:52 --> Security Class Initialized
DEBUG - 2023-03-10 09:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:29:52 --> Input Class Initialized
INFO - 2023-03-10 09:29:52 --> Language Class Initialized
INFO - 2023-03-10 09:29:52 --> Loader Class Initialized
INFO - 2023-03-10 09:29:52 --> Controller Class Initialized
DEBUG - 2023-03-10 09:29:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:29:52 --> Database Driver Class Initialized
INFO - 2023-03-10 09:29:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:29:52 --> Database Driver Class Initialized
INFO - 2023-03-10 09:29:52 --> Model "Login_model" initialized
INFO - 2023-03-10 09:29:52 --> Final output sent to browser
DEBUG - 2023-03-10 09:29:52 --> Total execution time: 0.1828
INFO - 2023-03-10 09:29:52 --> Config Class Initialized
INFO - 2023-03-10 09:29:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:29:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:29:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:29:52 --> URI Class Initialized
INFO - 2023-03-10 09:29:52 --> Router Class Initialized
INFO - 2023-03-10 09:29:52 --> Output Class Initialized
INFO - 2023-03-10 09:29:52 --> Security Class Initialized
DEBUG - 2023-03-10 09:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:29:52 --> Input Class Initialized
INFO - 2023-03-10 09:29:52 --> Language Class Initialized
INFO - 2023-03-10 09:29:52 --> Loader Class Initialized
INFO - 2023-03-10 09:29:52 --> Controller Class Initialized
DEBUG - 2023-03-10 09:29:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:29:52 --> Database Driver Class Initialized
INFO - 2023-03-10 09:29:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:29:52 --> Database Driver Class Initialized
INFO - 2023-03-10 09:29:52 --> Model "Login_model" initialized
INFO - 2023-03-10 09:29:52 --> Final output sent to browser
DEBUG - 2023-03-10 09:29:52 --> Total execution time: 0.1214
INFO - 2023-03-10 09:29:56 --> Config Class Initialized
INFO - 2023-03-10 09:29:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:29:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:29:56 --> Utf8 Class Initialized
INFO - 2023-03-10 09:29:56 --> URI Class Initialized
INFO - 2023-03-10 09:29:56 --> Router Class Initialized
INFO - 2023-03-10 09:29:56 --> Output Class Initialized
INFO - 2023-03-10 09:29:56 --> Security Class Initialized
DEBUG - 2023-03-10 09:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:29:56 --> Input Class Initialized
INFO - 2023-03-10 09:29:56 --> Language Class Initialized
INFO - 2023-03-10 09:29:56 --> Loader Class Initialized
INFO - 2023-03-10 09:29:56 --> Controller Class Initialized
DEBUG - 2023-03-10 09:29:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:29:56 --> Final output sent to browser
DEBUG - 2023-03-10 09:29:56 --> Total execution time: 0.0076
INFO - 2023-03-10 09:29:56 --> Config Class Initialized
INFO - 2023-03-10 09:29:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:29:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:29:56 --> Utf8 Class Initialized
INFO - 2023-03-10 09:29:56 --> URI Class Initialized
INFO - 2023-03-10 09:29:56 --> Router Class Initialized
INFO - 2023-03-10 09:29:57 --> Output Class Initialized
INFO - 2023-03-10 09:29:57 --> Security Class Initialized
DEBUG - 2023-03-10 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:29:57 --> Input Class Initialized
INFO - 2023-03-10 09:29:57 --> Language Class Initialized
INFO - 2023-03-10 09:29:57 --> Loader Class Initialized
INFO - 2023-03-10 09:29:57 --> Controller Class Initialized
DEBUG - 2023-03-10 09:29:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:29:57 --> Final output sent to browser
DEBUG - 2023-03-10 09:29:57 --> Total execution time: 0.0027
INFO - 2023-03-10 09:31:57 --> Config Class Initialized
INFO - 2023-03-10 09:31:57 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:31:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:31:57 --> Utf8 Class Initialized
INFO - 2023-03-10 09:31:57 --> URI Class Initialized
INFO - 2023-03-10 09:31:57 --> Router Class Initialized
INFO - 2023-03-10 09:31:57 --> Output Class Initialized
INFO - 2023-03-10 09:31:57 --> Security Class Initialized
DEBUG - 2023-03-10 09:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:31:57 --> Input Class Initialized
INFO - 2023-03-10 09:31:57 --> Language Class Initialized
INFO - 2023-03-10 09:31:57 --> Loader Class Initialized
INFO - 2023-03-10 09:31:57 --> Controller Class Initialized
DEBUG - 2023-03-10 09:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:31:57 --> Database Driver Class Initialized
INFO - 2023-03-10 09:31:57 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:31:57 --> Final output sent to browser
DEBUG - 2023-03-10 09:31:57 --> Total execution time: 0.0408
INFO - 2023-03-10 09:31:57 --> Config Class Initialized
INFO - 2023-03-10 09:31:57 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:31:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:31:57 --> Utf8 Class Initialized
INFO - 2023-03-10 09:31:57 --> URI Class Initialized
INFO - 2023-03-10 09:31:57 --> Router Class Initialized
INFO - 2023-03-10 09:31:57 --> Output Class Initialized
INFO - 2023-03-10 09:31:57 --> Security Class Initialized
DEBUG - 2023-03-10 09:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:31:57 --> Input Class Initialized
INFO - 2023-03-10 09:31:57 --> Language Class Initialized
INFO - 2023-03-10 09:31:57 --> Loader Class Initialized
INFO - 2023-03-10 09:31:57 --> Controller Class Initialized
DEBUG - 2023-03-10 09:31:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:31:57 --> Database Driver Class Initialized
INFO - 2023-03-10 09:31:57 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:31:57 --> Final output sent to browser
DEBUG - 2023-03-10 09:31:57 --> Total execution time: 0.0524
INFO - 2023-03-10 09:32:00 --> Config Class Initialized
INFO - 2023-03-10 09:32:00 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:32:00 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:32:00 --> Utf8 Class Initialized
INFO - 2023-03-10 09:32:00 --> URI Class Initialized
INFO - 2023-03-10 09:32:00 --> Router Class Initialized
INFO - 2023-03-10 09:32:00 --> Output Class Initialized
INFO - 2023-03-10 09:32:00 --> Security Class Initialized
DEBUG - 2023-03-10 09:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:32:00 --> Input Class Initialized
INFO - 2023-03-10 09:32:00 --> Language Class Initialized
INFO - 2023-03-10 09:32:00 --> Loader Class Initialized
INFO - 2023-03-10 09:32:00 --> Controller Class Initialized
DEBUG - 2023-03-10 09:32:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:32:00 --> Database Driver Class Initialized
INFO - 2023-03-10 09:32:00 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:32:01 --> Database Driver Class Initialized
INFO - 2023-03-10 09:32:01 --> Model "Login_model" initialized
INFO - 2023-03-10 09:32:01 --> Final output sent to browser
DEBUG - 2023-03-10 09:32:01 --> Total execution time: 0.0461
INFO - 2023-03-10 09:32:01 --> Config Class Initialized
INFO - 2023-03-10 09:32:01 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:32:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:32:01 --> Utf8 Class Initialized
INFO - 2023-03-10 09:32:01 --> URI Class Initialized
INFO - 2023-03-10 09:32:01 --> Router Class Initialized
INFO - 2023-03-10 09:32:01 --> Output Class Initialized
INFO - 2023-03-10 09:32:01 --> Security Class Initialized
DEBUG - 2023-03-10 09:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:32:01 --> Input Class Initialized
INFO - 2023-03-10 09:32:01 --> Language Class Initialized
INFO - 2023-03-10 09:32:01 --> Loader Class Initialized
INFO - 2023-03-10 09:32:01 --> Controller Class Initialized
DEBUG - 2023-03-10 09:32:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:32:01 --> Database Driver Class Initialized
INFO - 2023-03-10 09:32:01 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:32:01 --> Database Driver Class Initialized
INFO - 2023-03-10 09:32:01 --> Model "Login_model" initialized
INFO - 2023-03-10 09:32:01 --> Final output sent to browser
DEBUG - 2023-03-10 09:32:01 --> Total execution time: 0.0350
INFO - 2023-03-10 09:32:03 --> Config Class Initialized
INFO - 2023-03-10 09:32:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:32:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:32:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:32:03 --> URI Class Initialized
INFO - 2023-03-10 09:32:03 --> Router Class Initialized
INFO - 2023-03-10 09:32:03 --> Output Class Initialized
INFO - 2023-03-10 09:32:03 --> Security Class Initialized
DEBUG - 2023-03-10 09:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:32:03 --> Input Class Initialized
INFO - 2023-03-10 09:32:03 --> Language Class Initialized
INFO - 2023-03-10 09:32:03 --> Loader Class Initialized
INFO - 2023-03-10 09:32:03 --> Controller Class Initialized
DEBUG - 2023-03-10 09:32:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:32:03 --> Final output sent to browser
DEBUG - 2023-03-10 09:32:03 --> Total execution time: 0.0056
INFO - 2023-03-10 09:32:03 --> Config Class Initialized
INFO - 2023-03-10 09:32:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:32:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:32:03 --> Utf8 Class Initialized
INFO - 2023-03-10 09:32:03 --> URI Class Initialized
INFO - 2023-03-10 09:32:03 --> Router Class Initialized
INFO - 2023-03-10 09:32:03 --> Output Class Initialized
INFO - 2023-03-10 09:32:03 --> Security Class Initialized
DEBUG - 2023-03-10 09:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:32:03 --> Input Class Initialized
INFO - 2023-03-10 09:32:03 --> Language Class Initialized
INFO - 2023-03-10 09:32:03 --> Loader Class Initialized
INFO - 2023-03-10 09:32:03 --> Controller Class Initialized
DEBUG - 2023-03-10 09:32:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:32:03 --> Final output sent to browser
DEBUG - 2023-03-10 09:32:03 --> Total execution time: 0.0026
INFO - 2023-03-10 09:32:41 --> Config Class Initialized
INFO - 2023-03-10 09:32:41 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:32:41 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:32:41 --> Utf8 Class Initialized
INFO - 2023-03-10 09:32:41 --> URI Class Initialized
INFO - 2023-03-10 09:32:41 --> Router Class Initialized
INFO - 2023-03-10 09:32:41 --> Output Class Initialized
INFO - 2023-03-10 09:32:41 --> Security Class Initialized
DEBUG - 2023-03-10 09:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:32:41 --> Input Class Initialized
INFO - 2023-03-10 09:32:41 --> Language Class Initialized
INFO - 2023-03-10 09:32:41 --> Loader Class Initialized
INFO - 2023-03-10 09:32:41 --> Controller Class Initialized
DEBUG - 2023-03-10 09:32:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:32:41 --> Final output sent to browser
DEBUG - 2023-03-10 09:32:41 --> Total execution time: 0.1013
INFO - 2023-03-10 09:32:41 --> Config Class Initialized
INFO - 2023-03-10 09:32:41 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:32:41 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:32:41 --> Utf8 Class Initialized
INFO - 2023-03-10 09:32:41 --> URI Class Initialized
INFO - 2023-03-10 09:32:41 --> Router Class Initialized
INFO - 2023-03-10 09:32:41 --> Output Class Initialized
INFO - 2023-03-10 09:32:41 --> Security Class Initialized
DEBUG - 2023-03-10 09:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:32:41 --> Input Class Initialized
INFO - 2023-03-10 09:32:41 --> Language Class Initialized
ERROR - 2023-03-10 09:32:41 --> 404 Page Not Found: Faviconico/index
INFO - 2023-03-10 09:32:46 --> Config Class Initialized
INFO - 2023-03-10 09:32:46 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:32:46 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:32:46 --> Utf8 Class Initialized
INFO - 2023-03-10 09:32:46 --> URI Class Initialized
INFO - 2023-03-10 09:32:46 --> Router Class Initialized
INFO - 2023-03-10 09:32:46 --> Output Class Initialized
INFO - 2023-03-10 09:32:46 --> Security Class Initialized
DEBUG - 2023-03-10 09:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:32:46 --> Input Class Initialized
INFO - 2023-03-10 09:32:46 --> Language Class Initialized
INFO - 2023-03-10 09:32:46 --> Loader Class Initialized
INFO - 2023-03-10 09:32:46 --> Controller Class Initialized
DEBUG - 2023-03-10 09:32:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:32:46 --> Final output sent to browser
DEBUG - 2023-03-10 09:32:46 --> Total execution time: 0.0447
INFO - 2023-03-10 09:33:02 --> Config Class Initialized
INFO - 2023-03-10 09:33:02 --> Config Class Initialized
INFO - 2023-03-10 09:33:02 --> Hooks Class Initialized
INFO - 2023-03-10 09:33:02 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:33:02 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:33:02 --> Utf8 Class Initialized
INFO - 2023-03-10 09:33:02 --> Utf8 Class Initialized
INFO - 2023-03-10 09:33:02 --> URI Class Initialized
INFO - 2023-03-10 09:33:02 --> URI Class Initialized
INFO - 2023-03-10 09:33:02 --> Router Class Initialized
INFO - 2023-03-10 09:33:02 --> Router Class Initialized
INFO - 2023-03-10 09:33:02 --> Output Class Initialized
INFO - 2023-03-10 09:33:02 --> Output Class Initialized
INFO - 2023-03-10 09:33:02 --> Security Class Initialized
INFO - 2023-03-10 09:33:02 --> Security Class Initialized
DEBUG - 2023-03-10 09:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:33:02 --> Input Class Initialized
DEBUG - 2023-03-10 09:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:33:02 --> Language Class Initialized
INFO - 2023-03-10 09:33:02 --> Input Class Initialized
INFO - 2023-03-10 09:33:02 --> Language Class Initialized
INFO - 2023-03-10 09:33:02 --> Loader Class Initialized
INFO - 2023-03-10 09:33:02 --> Loader Class Initialized
INFO - 2023-03-10 09:33:02 --> Controller Class Initialized
INFO - 2023-03-10 09:33:02 --> Controller Class Initialized
DEBUG - 2023-03-10 09:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:33:02 --> Database Driver Class Initialized
INFO - 2023-03-10 09:33:02 --> Database Driver Class Initialized
INFO - 2023-03-10 09:33:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:33:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:33:02 --> Final output sent to browser
DEBUG - 2023-03-10 09:33:02 --> Total execution time: 0.0699
INFO - 2023-03-10 09:33:02 --> Config Class Initialized
INFO - 2023-03-10 09:33:02 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:33:02 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:33:02 --> Utf8 Class Initialized
INFO - 2023-03-10 09:33:02 --> URI Class Initialized
INFO - 2023-03-10 09:33:02 --> Router Class Initialized
INFO - 2023-03-10 09:33:02 --> Output Class Initialized
INFO - 2023-03-10 09:33:02 --> Security Class Initialized
DEBUG - 2023-03-10 09:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:33:02 --> Input Class Initialized
INFO - 2023-03-10 09:33:02 --> Language Class Initialized
INFO - 2023-03-10 09:33:02 --> Loader Class Initialized
INFO - 2023-03-10 09:33:02 --> Controller Class Initialized
DEBUG - 2023-03-10 09:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:33:02 --> Database Driver Class Initialized
INFO - 2023-03-10 09:33:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:33:02 --> Final output sent to browser
DEBUG - 2023-03-10 09:33:02 --> Total execution time: 0.0498
INFO - 2023-03-10 09:33:02 --> Config Class Initialized
INFO - 2023-03-10 09:33:02 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:33:02 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:33:02 --> Utf8 Class Initialized
INFO - 2023-03-10 09:33:02 --> URI Class Initialized
INFO - 2023-03-10 09:33:02 --> Router Class Initialized
INFO - 2023-03-10 09:33:02 --> Output Class Initialized
INFO - 2023-03-10 09:33:02 --> Security Class Initialized
DEBUG - 2023-03-10 09:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:33:02 --> Input Class Initialized
INFO - 2023-03-10 09:33:02 --> Language Class Initialized
INFO - 2023-03-10 09:33:02 --> Loader Class Initialized
INFO - 2023-03-10 09:33:02 --> Controller Class Initialized
DEBUG - 2023-03-10 09:33:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:33:02 --> Database Driver Class Initialized
INFO - 2023-03-10 09:33:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:33:06 --> Config Class Initialized
INFO - 2023-03-10 09:33:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:33:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:33:06 --> Utf8 Class Initialized
INFO - 2023-03-10 09:33:06 --> URI Class Initialized
INFO - 2023-03-10 09:33:06 --> Router Class Initialized
INFO - 2023-03-10 09:33:06 --> Output Class Initialized
INFO - 2023-03-10 09:33:06 --> Security Class Initialized
DEBUG - 2023-03-10 09:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:33:06 --> Input Class Initialized
INFO - 2023-03-10 09:33:06 --> Language Class Initialized
INFO - 2023-03-10 09:33:06 --> Loader Class Initialized
INFO - 2023-03-10 09:33:06 --> Controller Class Initialized
DEBUG - 2023-03-10 09:33:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:33:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:33:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:33:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:33:06 --> Model "Login_model" initialized
INFO - 2023-03-10 09:33:06 --> Final output sent to browser
DEBUG - 2023-03-10 09:33:06 --> Total execution time: 0.1018
INFO - 2023-03-10 09:33:06 --> Config Class Initialized
INFO - 2023-03-10 09:33:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:33:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:33:06 --> Utf8 Class Initialized
INFO - 2023-03-10 09:33:06 --> URI Class Initialized
INFO - 2023-03-10 09:33:06 --> Router Class Initialized
INFO - 2023-03-10 09:33:06 --> Output Class Initialized
INFO - 2023-03-10 09:33:06 --> Security Class Initialized
DEBUG - 2023-03-10 09:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:33:06 --> Input Class Initialized
INFO - 2023-03-10 09:33:06 --> Language Class Initialized
INFO - 2023-03-10 09:33:06 --> Loader Class Initialized
INFO - 2023-03-10 09:33:06 --> Controller Class Initialized
DEBUG - 2023-03-10 09:33:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:33:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:33:06 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:33:06 --> Database Driver Class Initialized
INFO - 2023-03-10 09:33:06 --> Model "Login_model" initialized
INFO - 2023-03-10 09:33:06 --> Final output sent to browser
DEBUG - 2023-03-10 09:33:06 --> Total execution time: 0.0660
INFO - 2023-03-10 09:33:09 --> Config Class Initialized
INFO - 2023-03-10 09:33:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:33:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:33:09 --> Utf8 Class Initialized
INFO - 2023-03-10 09:33:09 --> URI Class Initialized
INFO - 2023-03-10 09:33:09 --> Router Class Initialized
INFO - 2023-03-10 09:33:09 --> Output Class Initialized
INFO - 2023-03-10 09:33:09 --> Security Class Initialized
DEBUG - 2023-03-10 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:33:09 --> Input Class Initialized
INFO - 2023-03-10 09:33:09 --> Language Class Initialized
INFO - 2023-03-10 09:33:09 --> Loader Class Initialized
INFO - 2023-03-10 09:33:09 --> Controller Class Initialized
DEBUG - 2023-03-10 09:33:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:33:09 --> Final output sent to browser
DEBUG - 2023-03-10 09:33:09 --> Total execution time: 0.0087
INFO - 2023-03-10 09:33:09 --> Config Class Initialized
INFO - 2023-03-10 09:33:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:33:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:33:09 --> Utf8 Class Initialized
INFO - 2023-03-10 09:33:09 --> URI Class Initialized
INFO - 2023-03-10 09:33:09 --> Router Class Initialized
INFO - 2023-03-10 09:33:09 --> Output Class Initialized
INFO - 2023-03-10 09:33:09 --> Security Class Initialized
DEBUG - 2023-03-10 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:33:09 --> Input Class Initialized
INFO - 2023-03-10 09:33:09 --> Language Class Initialized
INFO - 2023-03-10 09:33:09 --> Loader Class Initialized
INFO - 2023-03-10 09:33:09 --> Controller Class Initialized
DEBUG - 2023-03-10 09:33:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:33:09 --> Final output sent to browser
DEBUG - 2023-03-10 09:33:09 --> Total execution time: 0.0038
INFO - 2023-03-10 09:34:07 --> Config Class Initialized
INFO - 2023-03-10 09:34:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:07 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:07 --> URI Class Initialized
INFO - 2023-03-10 09:34:07 --> Router Class Initialized
INFO - 2023-03-10 09:34:07 --> Output Class Initialized
INFO - 2023-03-10 09:34:07 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:07 --> Input Class Initialized
INFO - 2023-03-10 09:34:07 --> Language Class Initialized
INFO - 2023-03-10 09:34:07 --> Loader Class Initialized
INFO - 2023-03-10 09:34:07 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:34:07 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:34:07 --> Database Driver Class Initialized
INFO - 2023-03-10 09:34:07 --> Model "Login_model" initialized
INFO - 2023-03-10 09:34:07 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:07 --> Total execution time: 0.1460
INFO - 2023-03-10 09:34:08 --> Config Class Initialized
INFO - 2023-03-10 09:34:08 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:08 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:08 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:08 --> URI Class Initialized
INFO - 2023-03-10 09:34:08 --> Router Class Initialized
INFO - 2023-03-10 09:34:08 --> Output Class Initialized
INFO - 2023-03-10 09:34:08 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:08 --> Input Class Initialized
INFO - 2023-03-10 09:34:08 --> Language Class Initialized
INFO - 2023-03-10 09:34:08 --> Loader Class Initialized
INFO - 2023-03-10 09:34:08 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:08 --> Database Driver Class Initialized
INFO - 2023-03-10 09:34:08 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:34:08 --> Database Driver Class Initialized
INFO - 2023-03-10 09:34:08 --> Model "Login_model" initialized
INFO - 2023-03-10 09:34:08 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:08 --> Total execution time: 0.2444
INFO - 2023-03-10 09:34:13 --> Config Class Initialized
INFO - 2023-03-10 09:34:13 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:13 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:13 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:13 --> URI Class Initialized
INFO - 2023-03-10 09:34:13 --> Router Class Initialized
INFO - 2023-03-10 09:34:13 --> Output Class Initialized
INFO - 2023-03-10 09:34:13 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:13 --> Input Class Initialized
INFO - 2023-03-10 09:34:13 --> Language Class Initialized
INFO - 2023-03-10 09:34:13 --> Loader Class Initialized
INFO - 2023-03-10 09:34:13 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:13 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:13 --> Total execution time: 0.0164
INFO - 2023-03-10 09:34:13 --> Config Class Initialized
INFO - 2023-03-10 09:34:13 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:13 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:13 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:13 --> URI Class Initialized
INFO - 2023-03-10 09:34:13 --> Router Class Initialized
INFO - 2023-03-10 09:34:13 --> Output Class Initialized
INFO - 2023-03-10 09:34:13 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:13 --> Input Class Initialized
INFO - 2023-03-10 09:34:13 --> Language Class Initialized
INFO - 2023-03-10 09:34:13 --> Loader Class Initialized
INFO - 2023-03-10 09:34:13 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:13 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:13 --> Total execution time: 0.0146
INFO - 2023-03-10 09:34:36 --> Config Class Initialized
INFO - 2023-03-10 09:34:36 --> Config Class Initialized
INFO - 2023-03-10 09:34:36 --> Hooks Class Initialized
INFO - 2023-03-10 09:34:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:34:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:36 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:36 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:36 --> URI Class Initialized
INFO - 2023-03-10 09:34:36 --> URI Class Initialized
INFO - 2023-03-10 09:34:36 --> Router Class Initialized
INFO - 2023-03-10 09:34:36 --> Router Class Initialized
INFO - 2023-03-10 09:34:36 --> Output Class Initialized
INFO - 2023-03-10 09:34:36 --> Output Class Initialized
INFO - 2023-03-10 09:34:36 --> Security Class Initialized
INFO - 2023-03-10 09:34:36 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:36 --> Input Class Initialized
INFO - 2023-03-10 09:34:36 --> Input Class Initialized
INFO - 2023-03-10 09:34:36 --> Language Class Initialized
INFO - 2023-03-10 09:34:36 --> Language Class Initialized
INFO - 2023-03-10 09:34:36 --> Loader Class Initialized
INFO - 2023-03-10 09:34:36 --> Loader Class Initialized
INFO - 2023-03-10 09:34:36 --> Controller Class Initialized
INFO - 2023-03-10 09:34:36 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:34:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:34:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:34:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:34:36 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:36 --> Total execution time: 0.0171
INFO - 2023-03-10 09:34:36 --> Config Class Initialized
INFO - 2023-03-10 09:34:36 --> Config Class Initialized
INFO - 2023-03-10 09:34:36 --> Hooks Class Initialized
INFO - 2023-03-10 09:34:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:34:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:36 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:36 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:36 --> URI Class Initialized
INFO - 2023-03-10 09:34:36 --> URI Class Initialized
INFO - 2023-03-10 09:34:36 --> Router Class Initialized
INFO - 2023-03-10 09:34:36 --> Router Class Initialized
INFO - 2023-03-10 09:34:36 --> Output Class Initialized
INFO - 2023-03-10 09:34:36 --> Output Class Initialized
INFO - 2023-03-10 09:34:36 --> Security Class Initialized
INFO - 2023-03-10 09:34:36 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:36 --> Input Class Initialized
INFO - 2023-03-10 09:34:36 --> Input Class Initialized
INFO - 2023-03-10 09:34:36 --> Language Class Initialized
INFO - 2023-03-10 09:34:36 --> Language Class Initialized
INFO - 2023-03-10 09:34:36 --> Loader Class Initialized
INFO - 2023-03-10 09:34:36 --> Loader Class Initialized
INFO - 2023-03-10 09:34:36 --> Controller Class Initialized
INFO - 2023-03-10 09:34:36 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:34:36 --> Database Driver Class Initialized
INFO - 2023-03-10 09:34:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:34:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:34:36 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:36 --> Total execution time: 0.1021
INFO - 2023-03-10 09:34:37 --> Config Class Initialized
INFO - 2023-03-10 09:34:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:37 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:37 --> URI Class Initialized
INFO - 2023-03-10 09:34:37 --> Router Class Initialized
INFO - 2023-03-10 09:34:37 --> Output Class Initialized
INFO - 2023-03-10 09:34:37 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:37 --> Input Class Initialized
INFO - 2023-03-10 09:34:37 --> Language Class Initialized
INFO - 2023-03-10 09:34:37 --> Loader Class Initialized
INFO - 2023-03-10 09:34:37 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:37 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:37 --> Total execution time: 0.0520
INFO - 2023-03-10 09:34:37 --> Config Class Initialized
INFO - 2023-03-10 09:34:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:37 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:37 --> URI Class Initialized
INFO - 2023-03-10 09:34:37 --> Router Class Initialized
INFO - 2023-03-10 09:34:37 --> Output Class Initialized
INFO - 2023-03-10 09:34:37 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:37 --> Input Class Initialized
INFO - 2023-03-10 09:34:37 --> Language Class Initialized
INFO - 2023-03-10 09:34:37 --> Loader Class Initialized
INFO - 2023-03-10 09:34:37 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:37 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:37 --> Total execution time: 0.0089
INFO - 2023-03-10 09:34:48 --> Config Class Initialized
INFO - 2023-03-10 09:34:48 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:34:48 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:34:48 --> Utf8 Class Initialized
INFO - 2023-03-10 09:34:48 --> URI Class Initialized
INFO - 2023-03-10 09:34:48 --> Router Class Initialized
INFO - 2023-03-10 09:34:48 --> Output Class Initialized
INFO - 2023-03-10 09:34:48 --> Security Class Initialized
DEBUG - 2023-03-10 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:34:48 --> Input Class Initialized
INFO - 2023-03-10 09:34:48 --> Language Class Initialized
INFO - 2023-03-10 09:34:48 --> Loader Class Initialized
INFO - 2023-03-10 09:34:48 --> Controller Class Initialized
DEBUG - 2023-03-10 09:34:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:34:48 --> Final output sent to browser
DEBUG - 2023-03-10 09:34:48 --> Total execution time: 0.0121
INFO - 2023-03-10 09:37:25 --> Config Class Initialized
INFO - 2023-03-10 09:37:25 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:37:25 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:37:25 --> Utf8 Class Initialized
INFO - 2023-03-10 09:37:25 --> URI Class Initialized
INFO - 2023-03-10 09:37:25 --> Router Class Initialized
INFO - 2023-03-10 09:37:25 --> Output Class Initialized
INFO - 2023-03-10 09:37:25 --> Security Class Initialized
DEBUG - 2023-03-10 09:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:37:25 --> Input Class Initialized
INFO - 2023-03-10 09:37:25 --> Language Class Initialized
INFO - 2023-03-10 09:37:25 --> Loader Class Initialized
INFO - 2023-03-10 09:37:25 --> Controller Class Initialized
DEBUG - 2023-03-10 09:37:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:37:54 --> Config Class Initialized
INFO - 2023-03-10 09:37:54 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:37:54 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:37:54 --> Utf8 Class Initialized
INFO - 2023-03-10 09:37:54 --> URI Class Initialized
INFO - 2023-03-10 09:37:54 --> Router Class Initialized
INFO - 2023-03-10 09:37:54 --> Output Class Initialized
INFO - 2023-03-10 09:37:54 --> Security Class Initialized
DEBUG - 2023-03-10 09:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:37:54 --> Input Class Initialized
INFO - 2023-03-10 09:37:54 --> Language Class Initialized
INFO - 2023-03-10 09:37:54 --> Loader Class Initialized
INFO - 2023-03-10 09:37:54 --> Controller Class Initialized
DEBUG - 2023-03-10 09:37:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:37:54 --> Final output sent to browser
DEBUG - 2023-03-10 09:37:54 --> Total execution time: 0.0166
INFO - 2023-03-10 09:38:30 --> Config Class Initialized
INFO - 2023-03-10 09:38:30 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:38:30 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:38:30 --> Utf8 Class Initialized
INFO - 2023-03-10 09:38:30 --> URI Class Initialized
INFO - 2023-03-10 09:38:30 --> Router Class Initialized
INFO - 2023-03-10 09:38:30 --> Output Class Initialized
INFO - 2023-03-10 09:38:30 --> Security Class Initialized
DEBUG - 2023-03-10 09:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:38:30 --> Input Class Initialized
INFO - 2023-03-10 09:38:30 --> Language Class Initialized
INFO - 2023-03-10 09:38:30 --> Loader Class Initialized
INFO - 2023-03-10 09:38:30 --> Controller Class Initialized
DEBUG - 2023-03-10 09:38:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:38:30 --> Final output sent to browser
DEBUG - 2023-03-10 09:38:30 --> Total execution time: 0.0728
INFO - 2023-03-10 09:38:31 --> Config Class Initialized
INFO - 2023-03-10 09:38:31 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:38:31 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:38:31 --> Utf8 Class Initialized
INFO - 2023-03-10 09:38:31 --> URI Class Initialized
INFO - 2023-03-10 09:38:31 --> Router Class Initialized
INFO - 2023-03-10 09:38:31 --> Output Class Initialized
INFO - 2023-03-10 09:38:31 --> Security Class Initialized
DEBUG - 2023-03-10 09:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:38:31 --> Input Class Initialized
INFO - 2023-03-10 09:38:31 --> Language Class Initialized
INFO - 2023-03-10 09:38:31 --> Loader Class Initialized
INFO - 2023-03-10 09:38:31 --> Controller Class Initialized
DEBUG - 2023-03-10 09:38:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:38:32 --> Final output sent to browser
DEBUG - 2023-03-10 09:38:32 --> Total execution time: 0.0541
INFO - 2023-03-10 09:39:13 --> Config Class Initialized
INFO - 2023-03-10 09:39:13 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:39:13 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:39:13 --> Utf8 Class Initialized
INFO - 2023-03-10 09:39:13 --> URI Class Initialized
INFO - 2023-03-10 09:39:13 --> Router Class Initialized
INFO - 2023-03-10 09:39:13 --> Output Class Initialized
INFO - 2023-03-10 09:39:13 --> Security Class Initialized
DEBUG - 2023-03-10 09:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:39:13 --> Input Class Initialized
INFO - 2023-03-10 09:39:13 --> Language Class Initialized
INFO - 2023-03-10 09:39:13 --> Loader Class Initialized
INFO - 2023-03-10 09:39:13 --> Controller Class Initialized
DEBUG - 2023-03-10 09:39:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:39:13 --> Final output sent to browser
DEBUG - 2023-03-10 09:39:13 --> Total execution time: 0.0511
INFO - 2023-03-10 09:39:15 --> Config Class Initialized
INFO - 2023-03-10 09:39:15 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:39:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:39:15 --> Utf8 Class Initialized
INFO - 2023-03-10 09:39:15 --> URI Class Initialized
INFO - 2023-03-10 09:39:15 --> Router Class Initialized
INFO - 2023-03-10 09:39:15 --> Output Class Initialized
INFO - 2023-03-10 09:39:15 --> Security Class Initialized
DEBUG - 2023-03-10 09:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:39:15 --> Input Class Initialized
INFO - 2023-03-10 09:39:15 --> Language Class Initialized
INFO - 2023-03-10 09:39:15 --> Loader Class Initialized
INFO - 2023-03-10 09:39:15 --> Controller Class Initialized
DEBUG - 2023-03-10 09:39:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:39:15 --> Final output sent to browser
DEBUG - 2023-03-10 09:39:15 --> Total execution time: 0.0488
INFO - 2023-03-10 09:39:17 --> Config Class Initialized
INFO - 2023-03-10 09:39:17 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:39:17 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:39:17 --> Utf8 Class Initialized
INFO - 2023-03-10 09:39:17 --> URI Class Initialized
INFO - 2023-03-10 09:39:17 --> Router Class Initialized
INFO - 2023-03-10 09:39:17 --> Output Class Initialized
INFO - 2023-03-10 09:39:17 --> Security Class Initialized
DEBUG - 2023-03-10 09:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:39:17 --> Input Class Initialized
INFO - 2023-03-10 09:39:17 --> Language Class Initialized
INFO - 2023-03-10 09:39:17 --> Loader Class Initialized
INFO - 2023-03-10 09:39:17 --> Controller Class Initialized
DEBUG - 2023-03-10 09:39:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:39:17 --> Final output sent to browser
DEBUG - 2023-03-10 09:39:17 --> Total execution time: 0.0508
INFO - 2023-03-10 09:39:51 --> Config Class Initialized
INFO - 2023-03-10 09:39:51 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:39:51 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:39:51 --> Utf8 Class Initialized
INFO - 2023-03-10 09:39:51 --> URI Class Initialized
INFO - 2023-03-10 09:39:51 --> Router Class Initialized
INFO - 2023-03-10 09:39:51 --> Output Class Initialized
INFO - 2023-03-10 09:39:51 --> Security Class Initialized
DEBUG - 2023-03-10 09:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:39:51 --> Input Class Initialized
INFO - 2023-03-10 09:39:51 --> Language Class Initialized
INFO - 2023-03-10 09:39:51 --> Loader Class Initialized
INFO - 2023-03-10 09:39:51 --> Controller Class Initialized
DEBUG - 2023-03-10 09:39:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:39:51 --> Final output sent to browser
DEBUG - 2023-03-10 09:39:51 --> Total execution time: 0.0527
INFO - 2023-03-10 09:40:25 --> Config Class Initialized
INFO - 2023-03-10 09:40:25 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:40:25 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:40:25 --> Utf8 Class Initialized
INFO - 2023-03-10 09:40:25 --> URI Class Initialized
INFO - 2023-03-10 09:40:25 --> Router Class Initialized
INFO - 2023-03-10 09:40:25 --> Output Class Initialized
INFO - 2023-03-10 09:40:25 --> Security Class Initialized
DEBUG - 2023-03-10 09:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:40:25 --> Input Class Initialized
INFO - 2023-03-10 09:40:25 --> Language Class Initialized
INFO - 2023-03-10 09:40:25 --> Loader Class Initialized
INFO - 2023-03-10 09:40:25 --> Controller Class Initialized
DEBUG - 2023-03-10 09:40:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:40:25 --> Final output sent to browser
DEBUG - 2023-03-10 09:40:25 --> Total execution time: 0.1146
INFO - 2023-03-10 09:40:53 --> Config Class Initialized
INFO - 2023-03-10 09:40:53 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:40:53 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:40:53 --> Utf8 Class Initialized
INFO - 2023-03-10 09:40:53 --> URI Class Initialized
INFO - 2023-03-10 09:40:53 --> Router Class Initialized
INFO - 2023-03-10 09:40:53 --> Output Class Initialized
INFO - 2023-03-10 09:40:53 --> Security Class Initialized
DEBUG - 2023-03-10 09:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:40:53 --> Input Class Initialized
INFO - 2023-03-10 09:40:53 --> Language Class Initialized
INFO - 2023-03-10 09:40:53 --> Loader Class Initialized
INFO - 2023-03-10 09:40:53 --> Controller Class Initialized
DEBUG - 2023-03-10 09:40:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:40:53 --> Final output sent to browser
DEBUG - 2023-03-10 09:40:53 --> Total execution time: 0.1081
INFO - 2023-03-10 09:41:11 --> Config Class Initialized
INFO - 2023-03-10 09:41:11 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:41:11 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:41:11 --> Utf8 Class Initialized
INFO - 2023-03-10 09:41:11 --> URI Class Initialized
INFO - 2023-03-10 09:41:11 --> Router Class Initialized
INFO - 2023-03-10 09:41:11 --> Output Class Initialized
INFO - 2023-03-10 09:41:11 --> Security Class Initialized
DEBUG - 2023-03-10 09:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:41:11 --> Input Class Initialized
INFO - 2023-03-10 09:41:11 --> Language Class Initialized
INFO - 2023-03-10 09:41:11 --> Loader Class Initialized
INFO - 2023-03-10 09:41:11 --> Controller Class Initialized
DEBUG - 2023-03-10 09:41:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:41:11 --> Final output sent to browser
DEBUG - 2023-03-10 09:41:11 --> Total execution time: 0.1000
INFO - 2023-03-10 09:43:57 --> Config Class Initialized
INFO - 2023-03-10 09:43:57 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:43:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:43:57 --> Utf8 Class Initialized
INFO - 2023-03-10 09:43:57 --> URI Class Initialized
INFO - 2023-03-10 09:43:57 --> Router Class Initialized
INFO - 2023-03-10 09:43:57 --> Output Class Initialized
INFO - 2023-03-10 09:43:57 --> Security Class Initialized
DEBUG - 2023-03-10 09:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:43:57 --> Input Class Initialized
INFO - 2023-03-10 09:43:57 --> Language Class Initialized
INFO - 2023-03-10 09:43:57 --> Loader Class Initialized
INFO - 2023-03-10 09:43:57 --> Controller Class Initialized
DEBUG - 2023-03-10 09:43:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:43:58 --> Final output sent to browser
DEBUG - 2023-03-10 09:43:58 --> Total execution time: 0.1107
INFO - 2023-03-10 09:48:49 --> Config Class Initialized
INFO - 2023-03-10 09:48:49 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:48:49 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:48:49 --> Utf8 Class Initialized
INFO - 2023-03-10 09:48:49 --> URI Class Initialized
INFO - 2023-03-10 09:48:49 --> Router Class Initialized
INFO - 2023-03-10 09:48:49 --> Output Class Initialized
INFO - 2023-03-10 09:48:49 --> Security Class Initialized
DEBUG - 2023-03-10 09:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:48:49 --> Input Class Initialized
INFO - 2023-03-10 09:48:49 --> Language Class Initialized
INFO - 2023-03-10 09:48:49 --> Loader Class Initialized
INFO - 2023-03-10 09:48:49 --> Controller Class Initialized
DEBUG - 2023-03-10 09:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:48:49 --> Database Driver Class Initialized
INFO - 2023-03-10 09:48:49 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:48:49 --> Database Driver Class Initialized
INFO - 2023-03-10 09:48:49 --> Model "Login_model" initialized
INFO - 2023-03-10 09:48:49 --> Final output sent to browser
DEBUG - 2023-03-10 09:48:49 --> Total execution time: 0.1217
INFO - 2023-03-10 09:48:49 --> Config Class Initialized
INFO - 2023-03-10 09:48:49 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:48:49 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:48:49 --> Utf8 Class Initialized
INFO - 2023-03-10 09:48:49 --> URI Class Initialized
INFO - 2023-03-10 09:48:49 --> Router Class Initialized
INFO - 2023-03-10 09:48:49 --> Output Class Initialized
INFO - 2023-03-10 09:48:49 --> Security Class Initialized
DEBUG - 2023-03-10 09:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:48:49 --> Input Class Initialized
INFO - 2023-03-10 09:48:49 --> Language Class Initialized
INFO - 2023-03-10 09:48:49 --> Loader Class Initialized
INFO - 2023-03-10 09:48:49 --> Controller Class Initialized
DEBUG - 2023-03-10 09:48:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:48:49 --> Database Driver Class Initialized
INFO - 2023-03-10 09:48:49 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:48:49 --> Database Driver Class Initialized
INFO - 2023-03-10 09:48:49 --> Model "Login_model" initialized
INFO - 2023-03-10 09:48:49 --> Final output sent to browser
DEBUG - 2023-03-10 09:48:49 --> Total execution time: 0.1127
INFO - 2023-03-10 09:48:52 --> Config Class Initialized
INFO - 2023-03-10 09:48:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:48:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:48:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:48:52 --> URI Class Initialized
INFO - 2023-03-10 09:48:52 --> Router Class Initialized
INFO - 2023-03-10 09:48:52 --> Output Class Initialized
INFO - 2023-03-10 09:48:52 --> Security Class Initialized
DEBUG - 2023-03-10 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:48:52 --> Input Class Initialized
INFO - 2023-03-10 09:48:52 --> Language Class Initialized
INFO - 2023-03-10 09:48:52 --> Loader Class Initialized
INFO - 2023-03-10 09:48:52 --> Controller Class Initialized
DEBUG - 2023-03-10 09:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:48:52 --> Final output sent to browser
DEBUG - 2023-03-10 09:48:52 --> Total execution time: 0.0599
INFO - 2023-03-10 09:48:52 --> Config Class Initialized
INFO - 2023-03-10 09:48:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:48:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:48:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:48:52 --> URI Class Initialized
INFO - 2023-03-10 09:48:52 --> Router Class Initialized
INFO - 2023-03-10 09:48:52 --> Output Class Initialized
INFO - 2023-03-10 09:48:52 --> Security Class Initialized
DEBUG - 2023-03-10 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:48:52 --> Input Class Initialized
INFO - 2023-03-10 09:48:52 --> Language Class Initialized
INFO - 2023-03-10 09:48:52 --> Loader Class Initialized
INFO - 2023-03-10 09:48:52 --> Controller Class Initialized
DEBUG - 2023-03-10 09:48:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:48:52 --> Final output sent to browser
DEBUG - 2023-03-10 09:48:52 --> Total execution time: 0.0522
INFO - 2023-03-10 09:50:25 --> Config Class Initialized
INFO - 2023-03-10 09:50:25 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:25 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:25 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:25 --> URI Class Initialized
INFO - 2023-03-10 09:50:25 --> Router Class Initialized
INFO - 2023-03-10 09:50:25 --> Output Class Initialized
INFO - 2023-03-10 09:50:25 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:25 --> Input Class Initialized
INFO - 2023-03-10 09:50:25 --> Language Class Initialized
INFO - 2023-03-10 09:50:25 --> Loader Class Initialized
INFO - 2023-03-10 09:50:25 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:25 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:25 --> Total execution time: 0.0563
INFO - 2023-03-10 09:50:25 --> Config Class Initialized
INFO - 2023-03-10 09:50:25 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:25 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:25 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:25 --> URI Class Initialized
INFO - 2023-03-10 09:50:25 --> Router Class Initialized
INFO - 2023-03-10 09:50:25 --> Output Class Initialized
INFO - 2023-03-10 09:50:25 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:25 --> Input Class Initialized
INFO - 2023-03-10 09:50:25 --> Language Class Initialized
INFO - 2023-03-10 09:50:25 --> Loader Class Initialized
INFO - 2023-03-10 09:50:25 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:25 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:25 --> Total execution time: 0.0576
INFO - 2023-03-10 09:50:29 --> Config Class Initialized
INFO - 2023-03-10 09:50:29 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:29 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:29 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:29 --> URI Class Initialized
INFO - 2023-03-10 09:50:29 --> Router Class Initialized
INFO - 2023-03-10 09:50:29 --> Output Class Initialized
INFO - 2023-03-10 09:50:29 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:29 --> Input Class Initialized
INFO - 2023-03-10 09:50:29 --> Language Class Initialized
INFO - 2023-03-10 09:50:29 --> Loader Class Initialized
INFO - 2023-03-10 09:50:29 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:30 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:30 --> Total execution time: 0.0608
INFO - 2023-03-10 09:50:30 --> Config Class Initialized
INFO - 2023-03-10 09:50:30 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:30 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:30 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:30 --> URI Class Initialized
INFO - 2023-03-10 09:50:30 --> Router Class Initialized
INFO - 2023-03-10 09:50:30 --> Output Class Initialized
INFO - 2023-03-10 09:50:30 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:30 --> Input Class Initialized
INFO - 2023-03-10 09:50:30 --> Language Class Initialized
INFO - 2023-03-10 09:50:30 --> Loader Class Initialized
INFO - 2023-03-10 09:50:30 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:30 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:30 --> Total execution time: 0.0542
INFO - 2023-03-10 09:50:32 --> Config Class Initialized
INFO - 2023-03-10 09:50:32 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:32 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:32 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:32 --> URI Class Initialized
INFO - 2023-03-10 09:50:32 --> Router Class Initialized
INFO - 2023-03-10 09:50:32 --> Output Class Initialized
INFO - 2023-03-10 09:50:32 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:32 --> Input Class Initialized
INFO - 2023-03-10 09:50:32 --> Language Class Initialized
INFO - 2023-03-10 09:50:32 --> Loader Class Initialized
INFO - 2023-03-10 09:50:32 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:32 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:32 --> Total execution time: 0.0968
INFO - 2023-03-10 09:50:32 --> Config Class Initialized
INFO - 2023-03-10 09:50:32 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:32 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:32 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:32 --> URI Class Initialized
INFO - 2023-03-10 09:50:32 --> Router Class Initialized
INFO - 2023-03-10 09:50:32 --> Output Class Initialized
INFO - 2023-03-10 09:50:32 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:32 --> Input Class Initialized
INFO - 2023-03-10 09:50:32 --> Language Class Initialized
INFO - 2023-03-10 09:50:32 --> Loader Class Initialized
INFO - 2023-03-10 09:50:32 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:32 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:32 --> Total execution time: 0.0590
INFO - 2023-03-10 09:50:39 --> Config Class Initialized
INFO - 2023-03-10 09:50:39 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:40 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:40 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:40 --> URI Class Initialized
INFO - 2023-03-10 09:50:40 --> Router Class Initialized
INFO - 2023-03-10 09:50:40 --> Output Class Initialized
INFO - 2023-03-10 09:50:40 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:40 --> Input Class Initialized
INFO - 2023-03-10 09:50:40 --> Language Class Initialized
INFO - 2023-03-10 09:50:40 --> Loader Class Initialized
INFO - 2023-03-10 09:50:40 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:40 --> Database Driver Class Initialized
INFO - 2023-03-10 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:50:40 --> Database Driver Class Initialized
INFO - 2023-03-10 09:50:40 --> Model "Login_model" initialized
INFO - 2023-03-10 09:50:40 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:40 --> Total execution time: 0.1584
INFO - 2023-03-10 09:50:40 --> Config Class Initialized
INFO - 2023-03-10 09:50:40 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:40 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:40 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:40 --> URI Class Initialized
INFO - 2023-03-10 09:50:40 --> Router Class Initialized
INFO - 2023-03-10 09:50:40 --> Output Class Initialized
INFO - 2023-03-10 09:50:40 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:40 --> Input Class Initialized
INFO - 2023-03-10 09:50:40 --> Language Class Initialized
INFO - 2023-03-10 09:50:40 --> Loader Class Initialized
INFO - 2023-03-10 09:50:40 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:40 --> Database Driver Class Initialized
INFO - 2023-03-10 09:50:40 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:50:40 --> Database Driver Class Initialized
INFO - 2023-03-10 09:50:40 --> Model "Login_model" initialized
INFO - 2023-03-10 09:50:40 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:40 --> Total execution time: 0.0590
INFO - 2023-03-10 09:50:52 --> Config Class Initialized
INFO - 2023-03-10 09:50:52 --> Config Class Initialized
INFO - 2023-03-10 09:50:52 --> Hooks Class Initialized
INFO - 2023-03-10 09:50:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 09:50:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:52 --> URI Class Initialized
INFO - 2023-03-10 09:50:52 --> URI Class Initialized
INFO - 2023-03-10 09:50:52 --> Router Class Initialized
INFO - 2023-03-10 09:50:52 --> Router Class Initialized
INFO - 2023-03-10 09:50:52 --> Output Class Initialized
INFO - 2023-03-10 09:50:52 --> Output Class Initialized
INFO - 2023-03-10 09:50:52 --> Security Class Initialized
INFO - 2023-03-10 09:50:52 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 09:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:52 --> Input Class Initialized
INFO - 2023-03-10 09:50:52 --> Input Class Initialized
INFO - 2023-03-10 09:50:52 --> Language Class Initialized
INFO - 2023-03-10 09:50:52 --> Language Class Initialized
INFO - 2023-03-10 09:50:52 --> Loader Class Initialized
INFO - 2023-03-10 09:50:52 --> Loader Class Initialized
INFO - 2023-03-10 09:50:52 --> Controller Class Initialized
INFO - 2023-03-10 09:50:52 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 09:50:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:52 --> Database Driver Class Initialized
INFO - 2023-03-10 09:50:52 --> Database Driver Class Initialized
INFO - 2023-03-10 09:50:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:50:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:50:52 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:52 --> Total execution time: 0.0169
INFO - 2023-03-10 09:50:52 --> Config Class Initialized
INFO - 2023-03-10 09:50:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:52 --> Config Class Initialized
INFO - 2023-03-10 09:50:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:52 --> Hooks Class Initialized
INFO - 2023-03-10 09:50:52 --> URI Class Initialized
DEBUG - 2023-03-10 09:50:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:52 --> Router Class Initialized
INFO - 2023-03-10 09:50:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:52 --> Output Class Initialized
INFO - 2023-03-10 09:50:52 --> URI Class Initialized
INFO - 2023-03-10 09:50:52 --> Security Class Initialized
INFO - 2023-03-10 09:50:52 --> Router Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:52 --> Output Class Initialized
INFO - 2023-03-10 09:50:52 --> Input Class Initialized
INFO - 2023-03-10 09:50:52 --> Security Class Initialized
INFO - 2023-03-10 09:50:52 --> Language Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:52 --> Input Class Initialized
INFO - 2023-03-10 09:50:52 --> Loader Class Initialized
INFO - 2023-03-10 09:50:52 --> Language Class Initialized
INFO - 2023-03-10 09:50:52 --> Controller Class Initialized
INFO - 2023-03-10 09:50:52 --> Loader Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:52 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:52 --> Database Driver Class Initialized
INFO - 2023-03-10 09:50:52 --> Database Driver Class Initialized
INFO - 2023-03-10 09:50:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:50:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:50:52 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:52 --> Total execution time: 0.1769
INFO - 2023-03-10 09:50:52 --> Config Class Initialized
INFO - 2023-03-10 09:50:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:52 --> URI Class Initialized
INFO - 2023-03-10 09:50:52 --> Router Class Initialized
INFO - 2023-03-10 09:50:52 --> Output Class Initialized
INFO - 2023-03-10 09:50:52 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:52 --> Input Class Initialized
INFO - 2023-03-10 09:50:52 --> Language Class Initialized
INFO - 2023-03-10 09:50:52 --> Loader Class Initialized
INFO - 2023-03-10 09:50:52 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:52 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:52 --> Total execution time: 0.0565
INFO - 2023-03-10 09:50:52 --> Config Class Initialized
INFO - 2023-03-10 09:50:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:50:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:50:52 --> Utf8 Class Initialized
INFO - 2023-03-10 09:50:52 --> URI Class Initialized
INFO - 2023-03-10 09:50:52 --> Router Class Initialized
INFO - 2023-03-10 09:50:52 --> Output Class Initialized
INFO - 2023-03-10 09:50:52 --> Security Class Initialized
DEBUG - 2023-03-10 09:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:50:53 --> Input Class Initialized
INFO - 2023-03-10 09:50:53 --> Language Class Initialized
INFO - 2023-03-10 09:50:53 --> Loader Class Initialized
INFO - 2023-03-10 09:50:53 --> Controller Class Initialized
DEBUG - 2023-03-10 09:50:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:50:53 --> Final output sent to browser
DEBUG - 2023-03-10 09:50:53 --> Total execution time: 0.1016
INFO - 2023-03-10 09:51:39 --> Config Class Initialized
INFO - 2023-03-10 09:51:39 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:51:39 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:51:39 --> Utf8 Class Initialized
INFO - 2023-03-10 09:51:39 --> URI Class Initialized
INFO - 2023-03-10 09:51:39 --> Router Class Initialized
INFO - 2023-03-10 09:51:39 --> Output Class Initialized
INFO - 2023-03-10 09:51:39 --> Security Class Initialized
DEBUG - 2023-03-10 09:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:51:39 --> Input Class Initialized
INFO - 2023-03-10 09:51:39 --> Language Class Initialized
INFO - 2023-03-10 09:51:39 --> Loader Class Initialized
INFO - 2023-03-10 09:51:39 --> Controller Class Initialized
DEBUG - 2023-03-10 09:51:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:51:39 --> Final output sent to browser
DEBUG - 2023-03-10 09:51:39 --> Total execution time: 0.0577
INFO - 2023-03-10 09:51:39 --> Config Class Initialized
INFO - 2023-03-10 09:51:39 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:51:39 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:51:39 --> Utf8 Class Initialized
INFO - 2023-03-10 09:51:39 --> URI Class Initialized
INFO - 2023-03-10 09:51:39 --> Router Class Initialized
INFO - 2023-03-10 09:51:39 --> Output Class Initialized
INFO - 2023-03-10 09:51:39 --> Security Class Initialized
DEBUG - 2023-03-10 09:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:51:39 --> Input Class Initialized
INFO - 2023-03-10 09:51:39 --> Language Class Initialized
INFO - 2023-03-10 09:51:39 --> Loader Class Initialized
INFO - 2023-03-10 09:51:39 --> Controller Class Initialized
DEBUG - 2023-03-10 09:51:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:51:39 --> Final output sent to browser
DEBUG - 2023-03-10 09:51:39 --> Total execution time: 0.0641
INFO - 2023-03-10 09:51:55 --> Config Class Initialized
INFO - 2023-03-10 09:51:55 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:51:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:51:55 --> Utf8 Class Initialized
INFO - 2023-03-10 09:51:55 --> URI Class Initialized
INFO - 2023-03-10 09:51:55 --> Router Class Initialized
INFO - 2023-03-10 09:51:55 --> Output Class Initialized
INFO - 2023-03-10 09:51:55 --> Security Class Initialized
DEBUG - 2023-03-10 09:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:51:55 --> Input Class Initialized
INFO - 2023-03-10 09:51:55 --> Language Class Initialized
INFO - 2023-03-10 09:51:55 --> Loader Class Initialized
INFO - 2023-03-10 09:51:55 --> Controller Class Initialized
DEBUG - 2023-03-10 09:51:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:51:55 --> Final output sent to browser
DEBUG - 2023-03-10 09:51:55 --> Total execution time: 0.0518
INFO - 2023-03-10 09:51:55 --> Config Class Initialized
INFO - 2023-03-10 09:51:55 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:51:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:51:55 --> Utf8 Class Initialized
INFO - 2023-03-10 09:51:55 --> URI Class Initialized
INFO - 2023-03-10 09:51:55 --> Router Class Initialized
INFO - 2023-03-10 09:51:55 --> Output Class Initialized
INFO - 2023-03-10 09:51:55 --> Security Class Initialized
DEBUG - 2023-03-10 09:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:51:55 --> Input Class Initialized
INFO - 2023-03-10 09:51:55 --> Language Class Initialized
INFO - 2023-03-10 09:51:55 --> Loader Class Initialized
INFO - 2023-03-10 09:51:55 --> Controller Class Initialized
DEBUG - 2023-03-10 09:51:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:51:55 --> Final output sent to browser
DEBUG - 2023-03-10 09:51:55 --> Total execution time: 0.0700
INFO - 2023-03-10 09:52:24 --> Config Class Initialized
INFO - 2023-03-10 09:52:24 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:52:24 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:52:24 --> Utf8 Class Initialized
INFO - 2023-03-10 09:52:24 --> URI Class Initialized
INFO - 2023-03-10 09:52:24 --> Router Class Initialized
INFO - 2023-03-10 09:52:24 --> Output Class Initialized
INFO - 2023-03-10 09:52:24 --> Security Class Initialized
DEBUG - 2023-03-10 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:52:24 --> Input Class Initialized
INFO - 2023-03-10 09:52:24 --> Language Class Initialized
INFO - 2023-03-10 09:52:24 --> Loader Class Initialized
INFO - 2023-03-10 09:52:24 --> Controller Class Initialized
DEBUG - 2023-03-10 09:52:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:52:24 --> Final output sent to browser
DEBUG - 2023-03-10 09:52:24 --> Total execution time: 0.0958
INFO - 2023-03-10 09:52:24 --> Config Class Initialized
INFO - 2023-03-10 09:52:24 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:52:24 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:52:24 --> Utf8 Class Initialized
INFO - 2023-03-10 09:52:24 --> URI Class Initialized
INFO - 2023-03-10 09:52:24 --> Router Class Initialized
INFO - 2023-03-10 09:52:24 --> Output Class Initialized
INFO - 2023-03-10 09:52:24 --> Security Class Initialized
DEBUG - 2023-03-10 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:52:24 --> Input Class Initialized
INFO - 2023-03-10 09:52:24 --> Language Class Initialized
INFO - 2023-03-10 09:52:24 --> Loader Class Initialized
INFO - 2023-03-10 09:52:24 --> Controller Class Initialized
DEBUG - 2023-03-10 09:52:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:52:24 --> Final output sent to browser
DEBUG - 2023-03-10 09:52:24 --> Total execution time: 0.0605
INFO - 2023-03-10 09:52:26 --> Config Class Initialized
INFO - 2023-03-10 09:52:26 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:52:26 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:52:26 --> Utf8 Class Initialized
INFO - 2023-03-10 09:52:26 --> URI Class Initialized
INFO - 2023-03-10 09:52:26 --> Router Class Initialized
INFO - 2023-03-10 09:52:26 --> Output Class Initialized
INFO - 2023-03-10 09:52:26 --> Security Class Initialized
DEBUG - 2023-03-10 09:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:52:26 --> Input Class Initialized
INFO - 2023-03-10 09:52:26 --> Language Class Initialized
INFO - 2023-03-10 09:52:26 --> Loader Class Initialized
INFO - 2023-03-10 09:52:26 --> Controller Class Initialized
DEBUG - 2023-03-10 09:52:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:52:26 --> Final output sent to browser
DEBUG - 2023-03-10 09:52:26 --> Total execution time: 0.0046
INFO - 2023-03-10 09:52:26 --> Config Class Initialized
INFO - 2023-03-10 09:52:26 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:52:26 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:52:26 --> Utf8 Class Initialized
INFO - 2023-03-10 09:52:26 --> URI Class Initialized
INFO - 2023-03-10 09:52:26 --> Router Class Initialized
INFO - 2023-03-10 09:52:26 --> Output Class Initialized
INFO - 2023-03-10 09:52:26 --> Security Class Initialized
DEBUG - 2023-03-10 09:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:52:26 --> Input Class Initialized
INFO - 2023-03-10 09:52:26 --> Language Class Initialized
INFO - 2023-03-10 09:52:26 --> Loader Class Initialized
INFO - 2023-03-10 09:52:26 --> Controller Class Initialized
DEBUG - 2023-03-10 09:52:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:52:26 --> Database Driver Class Initialized
INFO - 2023-03-10 09:52:26 --> Model "Cluster_model" initialized
INFO - 2023-03-10 09:52:26 --> Final output sent to browser
DEBUG - 2023-03-10 09:52:26 --> Total execution time: 0.0511
INFO - 2023-03-10 09:57:25 --> Config Class Initialized
INFO - 2023-03-10 09:57:25 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:57:25 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:57:25 --> Utf8 Class Initialized
INFO - 2023-03-10 09:57:25 --> URI Class Initialized
INFO - 2023-03-10 09:57:25 --> Router Class Initialized
INFO - 2023-03-10 09:57:25 --> Output Class Initialized
INFO - 2023-03-10 09:57:25 --> Security Class Initialized
DEBUG - 2023-03-10 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:57:25 --> Input Class Initialized
INFO - 2023-03-10 09:57:25 --> Language Class Initialized
INFO - 2023-03-10 09:57:25 --> Loader Class Initialized
INFO - 2023-03-10 09:57:25 --> Controller Class Initialized
DEBUG - 2023-03-10 09:57:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:57:25 --> Final output sent to browser
DEBUG - 2023-03-10 09:57:25 --> Total execution time: 0.1064
INFO - 2023-03-10 09:59:42 --> Config Class Initialized
INFO - 2023-03-10 09:59:42 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:59:42 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:59:42 --> Utf8 Class Initialized
INFO - 2023-03-10 09:59:42 --> URI Class Initialized
INFO - 2023-03-10 09:59:42 --> Router Class Initialized
INFO - 2023-03-10 09:59:42 --> Output Class Initialized
INFO - 2023-03-10 09:59:42 --> Security Class Initialized
DEBUG - 2023-03-10 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:59:42 --> Input Class Initialized
INFO - 2023-03-10 09:59:42 --> Language Class Initialized
INFO - 2023-03-10 09:59:42 --> Loader Class Initialized
INFO - 2023-03-10 09:59:42 --> Controller Class Initialized
DEBUG - 2023-03-10 09:59:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:59:42 --> Final output sent to browser
DEBUG - 2023-03-10 09:59:42 --> Total execution time: 0.3252
INFO - 2023-03-10 09:59:42 --> Config Class Initialized
INFO - 2023-03-10 09:59:42 --> Hooks Class Initialized
DEBUG - 2023-03-10 09:59:42 --> UTF-8 Support Enabled
INFO - 2023-03-10 09:59:42 --> Utf8 Class Initialized
INFO - 2023-03-10 09:59:42 --> URI Class Initialized
INFO - 2023-03-10 09:59:42 --> Router Class Initialized
INFO - 2023-03-10 09:59:42 --> Output Class Initialized
INFO - 2023-03-10 09:59:42 --> Security Class Initialized
DEBUG - 2023-03-10 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 09:59:42 --> Input Class Initialized
INFO - 2023-03-10 09:59:42 --> Language Class Initialized
INFO - 2023-03-10 09:59:42 --> Loader Class Initialized
INFO - 2023-03-10 09:59:42 --> Controller Class Initialized
DEBUG - 2023-03-10 09:59:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 09:59:42 --> Final output sent to browser
DEBUG - 2023-03-10 09:59:42 --> Total execution time: 0.2632
INFO - 2023-03-10 10:00:47 --> Config Class Initialized
INFO - 2023-03-10 10:00:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:00:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:00:47 --> Utf8 Class Initialized
INFO - 2023-03-10 10:00:47 --> URI Class Initialized
INFO - 2023-03-10 10:00:47 --> Router Class Initialized
INFO - 2023-03-10 10:00:47 --> Output Class Initialized
INFO - 2023-03-10 10:00:47 --> Security Class Initialized
DEBUG - 2023-03-10 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:00:47 --> Input Class Initialized
INFO - 2023-03-10 10:00:47 --> Language Class Initialized
INFO - 2023-03-10 10:00:47 --> Loader Class Initialized
INFO - 2023-03-10 10:00:47 --> Controller Class Initialized
DEBUG - 2023-03-10 10:00:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:00:47 --> Final output sent to browser
DEBUG - 2023-03-10 10:00:47 --> Total execution time: 0.0918
INFO - 2023-03-10 10:00:47 --> Config Class Initialized
INFO - 2023-03-10 10:00:47 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:00:47 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:00:47 --> Utf8 Class Initialized
INFO - 2023-03-10 10:00:47 --> URI Class Initialized
INFO - 2023-03-10 10:00:47 --> Router Class Initialized
INFO - 2023-03-10 10:00:47 --> Output Class Initialized
INFO - 2023-03-10 10:00:47 --> Security Class Initialized
DEBUG - 2023-03-10 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:00:47 --> Input Class Initialized
INFO - 2023-03-10 10:00:47 --> Language Class Initialized
INFO - 2023-03-10 10:00:47 --> Loader Class Initialized
INFO - 2023-03-10 10:00:47 --> Controller Class Initialized
DEBUG - 2023-03-10 10:00:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:00:47 --> Final output sent to browser
DEBUG - 2023-03-10 10:00:47 --> Total execution time: 0.0476
INFO - 2023-03-10 10:01:57 --> Config Class Initialized
INFO - 2023-03-10 10:01:57 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:01:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:01:57 --> Utf8 Class Initialized
INFO - 2023-03-10 10:01:57 --> URI Class Initialized
INFO - 2023-03-10 10:01:57 --> Router Class Initialized
INFO - 2023-03-10 10:01:57 --> Output Class Initialized
INFO - 2023-03-10 10:01:57 --> Security Class Initialized
DEBUG - 2023-03-10 10:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:01:57 --> Input Class Initialized
INFO - 2023-03-10 10:01:57 --> Language Class Initialized
INFO - 2023-03-10 10:01:57 --> Loader Class Initialized
INFO - 2023-03-10 10:01:57 --> Controller Class Initialized
DEBUG - 2023-03-10 10:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:01:57 --> Final output sent to browser
DEBUG - 2023-03-10 10:01:57 --> Total execution time: 0.1064
INFO - 2023-03-10 10:01:57 --> Config Class Initialized
INFO - 2023-03-10 10:01:57 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:01:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:01:57 --> Utf8 Class Initialized
INFO - 2023-03-10 10:01:57 --> URI Class Initialized
INFO - 2023-03-10 10:01:57 --> Router Class Initialized
INFO - 2023-03-10 10:01:57 --> Output Class Initialized
INFO - 2023-03-10 10:01:57 --> Security Class Initialized
DEBUG - 2023-03-10 10:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:01:57 --> Input Class Initialized
INFO - 2023-03-10 10:01:57 --> Language Class Initialized
INFO - 2023-03-10 10:01:57 --> Loader Class Initialized
INFO - 2023-03-10 10:01:57 --> Controller Class Initialized
DEBUG - 2023-03-10 10:01:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:01:57 --> Final output sent to browser
DEBUG - 2023-03-10 10:01:57 --> Total execution time: 0.0549
INFO - 2023-03-10 10:02:36 --> Config Class Initialized
INFO - 2023-03-10 10:02:36 --> Config Class Initialized
INFO - 2023-03-10 10:02:36 --> Hooks Class Initialized
INFO - 2023-03-10 10:02:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:36 --> Utf8 Class Initialized
DEBUG - 2023-03-10 10:02:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:36 --> URI Class Initialized
INFO - 2023-03-10 10:02:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:36 --> URI Class Initialized
INFO - 2023-03-10 10:02:36 --> Router Class Initialized
INFO - 2023-03-10 10:02:36 --> Router Class Initialized
INFO - 2023-03-10 10:02:36 --> Output Class Initialized
INFO - 2023-03-10 10:02:36 --> Output Class Initialized
INFO - 2023-03-10 10:02:36 --> Security Class Initialized
INFO - 2023-03-10 10:02:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 10:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:36 --> Input Class Initialized
INFO - 2023-03-10 10:02:36 --> Input Class Initialized
INFO - 2023-03-10 10:02:36 --> Language Class Initialized
INFO - 2023-03-10 10:02:36 --> Language Class Initialized
INFO - 2023-03-10 10:02:36 --> Loader Class Initialized
INFO - 2023-03-10 10:02:36 --> Loader Class Initialized
INFO - 2023-03-10 10:02:36 --> Controller Class Initialized
INFO - 2023-03-10 10:02:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 10:02:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:36 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:36 --> Total execution time: 0.0152
INFO - 2023-03-10 10:02:36 --> Config Class Initialized
INFO - 2023-03-10 10:02:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:36 --> URI Class Initialized
INFO - 2023-03-10 10:02:36 --> Router Class Initialized
INFO - 2023-03-10 10:02:36 --> Output Class Initialized
INFO - 2023-03-10 10:02:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:36 --> Input Class Initialized
INFO - 2023-03-10 10:02:36 --> Language Class Initialized
INFO - 2023-03-10 10:02:36 --> Loader Class Initialized
INFO - 2023-03-10 10:02:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:36 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:36 --> Total execution time: 0.0501
INFO - 2023-03-10 10:02:36 --> Config Class Initialized
INFO - 2023-03-10 10:02:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:36 --> URI Class Initialized
INFO - 2023-03-10 10:02:36 --> Router Class Initialized
INFO - 2023-03-10 10:02:36 --> Output Class Initialized
INFO - 2023-03-10 10:02:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:36 --> Input Class Initialized
INFO - 2023-03-10 10:02:36 --> Language Class Initialized
INFO - 2023-03-10 10:02:36 --> Loader Class Initialized
INFO - 2023-03-10 10:02:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:37 --> Config Class Initialized
INFO - 2023-03-10 10:02:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:37 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:37 --> URI Class Initialized
INFO - 2023-03-10 10:02:37 --> Router Class Initialized
INFO - 2023-03-10 10:02:37 --> Output Class Initialized
INFO - 2023-03-10 10:02:37 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:37 --> Input Class Initialized
INFO - 2023-03-10 10:02:37 --> Language Class Initialized
INFO - 2023-03-10 10:02:37 --> Loader Class Initialized
INFO - 2023-03-10 10:02:37 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:37 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:37 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:37 --> Config Class Initialized
INFO - 2023-03-10 10:02:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:37 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:37 --> URI Class Initialized
INFO - 2023-03-10 10:02:37 --> Router Class Initialized
INFO - 2023-03-10 10:02:37 --> Output Class Initialized
INFO - 2023-03-10 10:02:37 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:37 --> Input Class Initialized
INFO - 2023-03-10 10:02:37 --> Language Class Initialized
INFO - 2023-03-10 10:02:37 --> Loader Class Initialized
INFO - 2023-03-10 10:02:37 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:37 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:37 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:37 --> Config Class Initialized
INFO - 2023-03-10 10:02:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:37 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:37 --> URI Class Initialized
INFO - 2023-03-10 10:02:37 --> Router Class Initialized
INFO - 2023-03-10 10:02:37 --> Output Class Initialized
INFO - 2023-03-10 10:02:37 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:37 --> Input Class Initialized
INFO - 2023-03-10 10:02:37 --> Language Class Initialized
INFO - 2023-03-10 10:02:37 --> Loader Class Initialized
INFO - 2023-03-10 10:02:37 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:37 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:37 --> Total execution time: 0.0731
INFO - 2023-03-10 10:02:37 --> Config Class Initialized
INFO - 2023-03-10 10:02:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:37 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:37 --> URI Class Initialized
INFO - 2023-03-10 10:02:37 --> Router Class Initialized
INFO - 2023-03-10 10:02:37 --> Output Class Initialized
INFO - 2023-03-10 10:02:37 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:37 --> Input Class Initialized
INFO - 2023-03-10 10:02:37 --> Language Class Initialized
INFO - 2023-03-10 10:02:37 --> Loader Class Initialized
INFO - 2023-03-10 10:02:37 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:37 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:37 --> Total execution time: 0.0488
INFO - 2023-03-10 10:02:41 --> Config Class Initialized
INFO - 2023-03-10 10:02:41 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:41 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:41 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:41 --> URI Class Initialized
INFO - 2023-03-10 10:02:41 --> Router Class Initialized
INFO - 2023-03-10 10:02:41 --> Output Class Initialized
INFO - 2023-03-10 10:02:41 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:41 --> Input Class Initialized
INFO - 2023-03-10 10:02:41 --> Language Class Initialized
INFO - 2023-03-10 10:02:41 --> Loader Class Initialized
INFO - 2023-03-10 10:02:41 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:41 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:41 --> Total execution time: 0.0594
INFO - 2023-03-10 10:02:41 --> Config Class Initialized
INFO - 2023-03-10 10:02:41 --> Config Class Initialized
INFO - 2023-03-10 10:02:41 --> Hooks Class Initialized
INFO - 2023-03-10 10:02:41 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:41 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 10:02:41 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:41 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:41 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:41 --> URI Class Initialized
INFO - 2023-03-10 10:02:41 --> URI Class Initialized
INFO - 2023-03-10 10:02:41 --> Router Class Initialized
INFO - 2023-03-10 10:02:41 --> Router Class Initialized
INFO - 2023-03-10 10:02:41 --> Output Class Initialized
INFO - 2023-03-10 10:02:41 --> Output Class Initialized
INFO - 2023-03-10 10:02:41 --> Security Class Initialized
INFO - 2023-03-10 10:02:41 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 10:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:41 --> Input Class Initialized
INFO - 2023-03-10 10:02:41 --> Input Class Initialized
INFO - 2023-03-10 10:02:41 --> Language Class Initialized
INFO - 2023-03-10 10:02:41 --> Language Class Initialized
INFO - 2023-03-10 10:02:41 --> Loader Class Initialized
INFO - 2023-03-10 10:02:41 --> Loader Class Initialized
INFO - 2023-03-10 10:02:41 --> Controller Class Initialized
INFO - 2023-03-10 10:02:41 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 10:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:41 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:41 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:41 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:41 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:41 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:41 --> Total execution time: 0.0158
INFO - 2023-03-10 10:02:41 --> Config Class Initialized
INFO - 2023-03-10 10:02:41 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:41 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:41 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:41 --> URI Class Initialized
INFO - 2023-03-10 10:02:41 --> Router Class Initialized
INFO - 2023-03-10 10:02:41 --> Output Class Initialized
INFO - 2023-03-10 10:02:41 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:41 --> Input Class Initialized
INFO - 2023-03-10 10:02:41 --> Language Class Initialized
INFO - 2023-03-10 10:02:41 --> Loader Class Initialized
INFO - 2023-03-10 10:02:41 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:41 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:41 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:41 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:41 --> Total execution time: 0.0121
INFO - 2023-03-10 10:02:41 --> Config Class Initialized
INFO - 2023-03-10 10:02:41 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:41 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:41 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:41 --> URI Class Initialized
INFO - 2023-03-10 10:02:41 --> Router Class Initialized
INFO - 2023-03-10 10:02:41 --> Output Class Initialized
INFO - 2023-03-10 10:02:41 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:41 --> Input Class Initialized
INFO - 2023-03-10 10:02:41 --> Language Class Initialized
INFO - 2023-03-10 10:02:41 --> Loader Class Initialized
INFO - 2023-03-10 10:02:41 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:41 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:41 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:43 --> Config Class Initialized
INFO - 2023-03-10 10:02:43 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:43 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:43 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:43 --> URI Class Initialized
INFO - 2023-03-10 10:02:43 --> Router Class Initialized
INFO - 2023-03-10 10:02:43 --> Output Class Initialized
INFO - 2023-03-10 10:02:43 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:43 --> Input Class Initialized
INFO - 2023-03-10 10:02:43 --> Language Class Initialized
INFO - 2023-03-10 10:02:43 --> Loader Class Initialized
INFO - 2023-03-10 10:02:43 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:43 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:43 --> Total execution time: 0.0590
INFO - 2023-03-10 10:02:43 --> Config Class Initialized
INFO - 2023-03-10 10:02:43 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:43 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:43 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:43 --> URI Class Initialized
INFO - 2023-03-10 10:02:43 --> Router Class Initialized
INFO - 2023-03-10 10:02:43 --> Output Class Initialized
INFO - 2023-03-10 10:02:43 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:43 --> Input Class Initialized
INFO - 2023-03-10 10:02:43 --> Language Class Initialized
INFO - 2023-03-10 10:02:43 --> Loader Class Initialized
INFO - 2023-03-10 10:02:43 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:43 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:43 --> Total execution time: 0.0593
INFO - 2023-03-10 10:02:45 --> Config Class Initialized
INFO - 2023-03-10 10:02:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:45 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:45 --> URI Class Initialized
INFO - 2023-03-10 10:02:45 --> Router Class Initialized
INFO - 2023-03-10 10:02:45 --> Output Class Initialized
INFO - 2023-03-10 10:02:45 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:45 --> Input Class Initialized
INFO - 2023-03-10 10:02:45 --> Language Class Initialized
INFO - 2023-03-10 10:02:45 --> Loader Class Initialized
INFO - 2023-03-10 10:02:45 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:45 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:45 --> Total execution time: 0.0052
INFO - 2023-03-10 10:02:45 --> Config Class Initialized
INFO - 2023-03-10 10:02:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:45 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:45 --> URI Class Initialized
INFO - 2023-03-10 10:02:45 --> Router Class Initialized
INFO - 2023-03-10 10:02:45 --> Output Class Initialized
INFO - 2023-03-10 10:02:45 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:45 --> Input Class Initialized
INFO - 2023-03-10 10:02:45 --> Language Class Initialized
INFO - 2023-03-10 10:02:45 --> Loader Class Initialized
INFO - 2023-03-10 10:02:45 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:45 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:45 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:45 --> Total execution time: 0.0138
INFO - 2023-03-10 10:02:59 --> Config Class Initialized
INFO - 2023-03-10 10:02:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:59 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:59 --> URI Class Initialized
INFO - 2023-03-10 10:02:59 --> Router Class Initialized
INFO - 2023-03-10 10:02:59 --> Output Class Initialized
INFO - 2023-03-10 10:02:59 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:59 --> Input Class Initialized
INFO - 2023-03-10 10:02:59 --> Language Class Initialized
INFO - 2023-03-10 10:02:59 --> Loader Class Initialized
INFO - 2023-03-10 10:02:59 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:59 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:59 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:59 --> Model "Login_model" initialized
INFO - 2023-03-10 10:02:59 --> Final output sent to browser
DEBUG - 2023-03-10 10:02:59 --> Total execution time: 0.1374
INFO - 2023-03-10 10:02:59 --> Config Class Initialized
INFO - 2023-03-10 10:02:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:02:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:02:59 --> Utf8 Class Initialized
INFO - 2023-03-10 10:02:59 --> URI Class Initialized
INFO - 2023-03-10 10:02:59 --> Router Class Initialized
INFO - 2023-03-10 10:02:59 --> Output Class Initialized
INFO - 2023-03-10 10:02:59 --> Security Class Initialized
DEBUG - 2023-03-10 10:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:02:59 --> Input Class Initialized
INFO - 2023-03-10 10:02:59 --> Language Class Initialized
INFO - 2023-03-10 10:02:59 --> Loader Class Initialized
INFO - 2023-03-10 10:02:59 --> Controller Class Initialized
DEBUG - 2023-03-10 10:02:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:02:59 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:02:59 --> Database Driver Class Initialized
INFO - 2023-03-10 10:02:59 --> Model "Login_model" initialized
INFO - 2023-03-10 10:03:00 --> Final output sent to browser
DEBUG - 2023-03-10 10:03:00 --> Total execution time: 0.0342
INFO - 2023-03-10 10:03:03 --> Config Class Initialized
INFO - 2023-03-10 10:03:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:03:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:03:03 --> Utf8 Class Initialized
INFO - 2023-03-10 10:03:03 --> URI Class Initialized
INFO - 2023-03-10 10:03:03 --> Router Class Initialized
INFO - 2023-03-10 10:03:03 --> Output Class Initialized
INFO - 2023-03-10 10:03:03 --> Security Class Initialized
DEBUG - 2023-03-10 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:03:03 --> Input Class Initialized
INFO - 2023-03-10 10:03:03 --> Language Class Initialized
INFO - 2023-03-10 10:03:03 --> Loader Class Initialized
INFO - 2023-03-10 10:03:03 --> Controller Class Initialized
DEBUG - 2023-03-10 10:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:03:03 --> Final output sent to browser
DEBUG - 2023-03-10 10:03:03 --> Total execution time: 0.0592
INFO - 2023-03-10 10:03:03 --> Config Class Initialized
INFO - 2023-03-10 10:03:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:03:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:03:03 --> Utf8 Class Initialized
INFO - 2023-03-10 10:03:03 --> URI Class Initialized
INFO - 2023-03-10 10:03:03 --> Router Class Initialized
INFO - 2023-03-10 10:03:03 --> Output Class Initialized
INFO - 2023-03-10 10:03:03 --> Security Class Initialized
DEBUG - 2023-03-10 10:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:03:03 --> Input Class Initialized
INFO - 2023-03-10 10:03:03 --> Language Class Initialized
INFO - 2023-03-10 10:03:03 --> Loader Class Initialized
INFO - 2023-03-10 10:03:03 --> Controller Class Initialized
DEBUG - 2023-03-10 10:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:03:03 --> Final output sent to browser
DEBUG - 2023-03-10 10:03:03 --> Total execution time: 0.0543
INFO - 2023-03-10 10:03:42 --> Config Class Initialized
INFO - 2023-03-10 10:03:42 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:03:42 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:03:42 --> Utf8 Class Initialized
INFO - 2023-03-10 10:03:42 --> URI Class Initialized
INFO - 2023-03-10 10:03:42 --> Router Class Initialized
INFO - 2023-03-10 10:03:42 --> Output Class Initialized
INFO - 2023-03-10 10:03:42 --> Security Class Initialized
DEBUG - 2023-03-10 10:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:03:42 --> Input Class Initialized
INFO - 2023-03-10 10:03:42 --> Language Class Initialized
INFO - 2023-03-10 10:03:42 --> Loader Class Initialized
INFO - 2023-03-10 10:03:42 --> Controller Class Initialized
DEBUG - 2023-03-10 10:03:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:03:42 --> Final output sent to browser
DEBUG - 2023-03-10 10:03:42 --> Total execution time: 0.0994
INFO - 2023-03-10 10:03:42 --> Config Class Initialized
INFO - 2023-03-10 10:03:42 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:03:42 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:03:42 --> Utf8 Class Initialized
INFO - 2023-03-10 10:03:42 --> URI Class Initialized
INFO - 2023-03-10 10:03:42 --> Router Class Initialized
INFO - 2023-03-10 10:03:42 --> Output Class Initialized
INFO - 2023-03-10 10:03:42 --> Security Class Initialized
DEBUG - 2023-03-10 10:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:03:42 --> Input Class Initialized
INFO - 2023-03-10 10:03:42 --> Language Class Initialized
INFO - 2023-03-10 10:03:42 --> Loader Class Initialized
INFO - 2023-03-10 10:03:42 --> Controller Class Initialized
DEBUG - 2023-03-10 10:03:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:03:42 --> Final output sent to browser
DEBUG - 2023-03-10 10:03:42 --> Total execution time: 0.0590
INFO - 2023-03-10 10:07:44 --> Config Class Initialized
INFO - 2023-03-10 10:07:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:07:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:07:44 --> Utf8 Class Initialized
INFO - 2023-03-10 10:07:44 --> URI Class Initialized
INFO - 2023-03-10 10:07:44 --> Router Class Initialized
INFO - 2023-03-10 10:07:44 --> Output Class Initialized
INFO - 2023-03-10 10:07:44 --> Security Class Initialized
DEBUG - 2023-03-10 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:07:44 --> Input Class Initialized
INFO - 2023-03-10 10:07:44 --> Language Class Initialized
INFO - 2023-03-10 10:07:44 --> Loader Class Initialized
INFO - 2023-03-10 10:07:44 --> Controller Class Initialized
DEBUG - 2023-03-10 10:07:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:07:44 --> Database Driver Class Initialized
INFO - 2023-03-10 10:07:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:07:44 --> Database Driver Class Initialized
INFO - 2023-03-10 10:07:44 --> Model "Login_model" initialized
INFO - 2023-03-10 10:07:44 --> Final output sent to browser
DEBUG - 2023-03-10 10:07:44 --> Total execution time: 0.1409
INFO - 2023-03-10 10:07:44 --> Config Class Initialized
INFO - 2023-03-10 10:07:44 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:07:44 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:07:44 --> Utf8 Class Initialized
INFO - 2023-03-10 10:07:44 --> URI Class Initialized
INFO - 2023-03-10 10:07:44 --> Router Class Initialized
INFO - 2023-03-10 10:07:44 --> Output Class Initialized
INFO - 2023-03-10 10:07:44 --> Security Class Initialized
DEBUG - 2023-03-10 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:07:44 --> Input Class Initialized
INFO - 2023-03-10 10:07:44 --> Language Class Initialized
INFO - 2023-03-10 10:07:44 --> Loader Class Initialized
INFO - 2023-03-10 10:07:44 --> Controller Class Initialized
DEBUG - 2023-03-10 10:07:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:07:44 --> Database Driver Class Initialized
INFO - 2023-03-10 10:07:44 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:07:44 --> Database Driver Class Initialized
INFO - 2023-03-10 10:07:44 --> Model "Login_model" initialized
INFO - 2023-03-10 10:07:44 --> Final output sent to browser
DEBUG - 2023-03-10 10:07:44 --> Total execution time: 0.0415
INFO - 2023-03-10 10:08:03 --> Config Class Initialized
INFO - 2023-03-10 10:08:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:03 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:03 --> URI Class Initialized
INFO - 2023-03-10 10:08:03 --> Router Class Initialized
INFO - 2023-03-10 10:08:03 --> Output Class Initialized
INFO - 2023-03-10 10:08:03 --> Security Class Initialized
DEBUG - 2023-03-10 10:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:03 --> Input Class Initialized
INFO - 2023-03-10 10:08:03 --> Language Class Initialized
INFO - 2023-03-10 10:08:03 --> Loader Class Initialized
INFO - 2023-03-10 10:08:03 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:03 --> Final output sent to browser
DEBUG - 2023-03-10 10:08:03 --> Total execution time: 0.1037
INFO - 2023-03-10 10:08:03 --> Config Class Initialized
INFO - 2023-03-10 10:08:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:03 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:03 --> URI Class Initialized
INFO - 2023-03-10 10:08:03 --> Router Class Initialized
INFO - 2023-03-10 10:08:03 --> Output Class Initialized
INFO - 2023-03-10 10:08:03 --> Security Class Initialized
DEBUG - 2023-03-10 10:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:03 --> Input Class Initialized
INFO - 2023-03-10 10:08:03 --> Language Class Initialized
INFO - 2023-03-10 10:08:03 --> Loader Class Initialized
INFO - 2023-03-10 10:08:03 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:03 --> Final output sent to browser
DEBUG - 2023-03-10 10:08:03 --> Total execution time: 0.0614
INFO - 2023-03-10 10:08:45 --> Config Class Initialized
INFO - 2023-03-10 10:08:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:45 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:45 --> URI Class Initialized
INFO - 2023-03-10 10:08:45 --> Router Class Initialized
INFO - 2023-03-10 10:08:45 --> Output Class Initialized
INFO - 2023-03-10 10:08:45 --> Security Class Initialized
DEBUG - 2023-03-10 10:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:45 --> Input Class Initialized
INFO - 2023-03-10 10:08:45 --> Language Class Initialized
INFO - 2023-03-10 10:08:45 --> Loader Class Initialized
INFO - 2023-03-10 10:08:45 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:45 --> Database Driver Class Initialized
INFO - 2023-03-10 10:08:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:08:45 --> Config Class Initialized
INFO - 2023-03-10 10:08:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:45 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:45 --> URI Class Initialized
INFO - 2023-03-10 10:08:45 --> Router Class Initialized
INFO - 2023-03-10 10:08:45 --> Output Class Initialized
INFO - 2023-03-10 10:08:45 --> Security Class Initialized
DEBUG - 2023-03-10 10:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:45 --> Input Class Initialized
INFO - 2023-03-10 10:08:45 --> Language Class Initialized
INFO - 2023-03-10 10:08:45 --> Loader Class Initialized
INFO - 2023-03-10 10:08:45 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:45 --> Database Driver Class Initialized
INFO - 2023-03-10 10:08:45 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:08:52 --> Config Class Initialized
INFO - 2023-03-10 10:08:52 --> Hooks Class Initialized
INFO - 2023-03-10 10:08:52 --> Config Class Initialized
INFO - 2023-03-10 10:08:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:52 --> Utf8 Class Initialized
DEBUG - 2023-03-10 10:08:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:52 --> URI Class Initialized
INFO - 2023-03-10 10:08:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:52 --> Router Class Initialized
INFO - 2023-03-10 10:08:52 --> URI Class Initialized
INFO - 2023-03-10 10:08:52 --> Output Class Initialized
INFO - 2023-03-10 10:08:52 --> Security Class Initialized
INFO - 2023-03-10 10:08:52 --> Router Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:52 --> Output Class Initialized
INFO - 2023-03-10 10:08:52 --> Input Class Initialized
INFO - 2023-03-10 10:08:52 --> Security Class Initialized
INFO - 2023-03-10 10:08:52 --> Language Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:52 --> Input Class Initialized
INFO - 2023-03-10 10:08:52 --> Loader Class Initialized
INFO - 2023-03-10 10:08:52 --> Language Class Initialized
INFO - 2023-03-10 10:08:52 --> Controller Class Initialized
INFO - 2023-03-10 10:08:52 --> Loader Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:08:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:08:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:08:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:08:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:08:52 --> Total execution time: 0.0155
INFO - 2023-03-10 10:08:52 --> Config Class Initialized
INFO - 2023-03-10 10:08:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:52 --> URI Class Initialized
INFO - 2023-03-10 10:08:52 --> Router Class Initialized
INFO - 2023-03-10 10:08:52 --> Output Class Initialized
INFO - 2023-03-10 10:08:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:52 --> Input Class Initialized
INFO - 2023-03-10 10:08:52 --> Language Class Initialized
INFO - 2023-03-10 10:08:52 --> Loader Class Initialized
INFO - 2023-03-10 10:08:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:08:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:08:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:08:52 --> Total execution time: 0.0119
INFO - 2023-03-10 10:08:52 --> Config Class Initialized
INFO - 2023-03-10 10:08:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:52 --> URI Class Initialized
INFO - 2023-03-10 10:08:52 --> Router Class Initialized
INFO - 2023-03-10 10:08:52 --> Output Class Initialized
INFO - 2023-03-10 10:08:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:52 --> Input Class Initialized
INFO - 2023-03-10 10:08:52 --> Language Class Initialized
INFO - 2023-03-10 10:08:52 --> Loader Class Initialized
INFO - 2023-03-10 10:08:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:08:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:08:52 --> Config Class Initialized
INFO - 2023-03-10 10:08:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:52 --> URI Class Initialized
INFO - 2023-03-10 10:08:52 --> Router Class Initialized
INFO - 2023-03-10 10:08:52 --> Output Class Initialized
INFO - 2023-03-10 10:08:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:52 --> Input Class Initialized
INFO - 2023-03-10 10:08:52 --> Language Class Initialized
INFO - 2023-03-10 10:08:52 --> Loader Class Initialized
INFO - 2023-03-10 10:08:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:08:52 --> Total execution time: 0.0698
INFO - 2023-03-10 10:08:52 --> Config Class Initialized
INFO - 2023-03-10 10:08:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:08:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:08:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:08:52 --> URI Class Initialized
INFO - 2023-03-10 10:08:52 --> Router Class Initialized
INFO - 2023-03-10 10:08:52 --> Output Class Initialized
INFO - 2023-03-10 10:08:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:08:52 --> Input Class Initialized
INFO - 2023-03-10 10:08:52 --> Language Class Initialized
INFO - 2023-03-10 10:08:52 --> Loader Class Initialized
INFO - 2023-03-10 10:08:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:08:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:08:53 --> Final output sent to browser
DEBUG - 2023-03-10 10:08:53 --> Total execution time: 0.0803
INFO - 2023-03-10 10:09:56 --> Config Class Initialized
INFO - 2023-03-10 10:09:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:09:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:09:56 --> Utf8 Class Initialized
INFO - 2023-03-10 10:09:56 --> URI Class Initialized
INFO - 2023-03-10 10:09:56 --> Router Class Initialized
INFO - 2023-03-10 10:09:56 --> Output Class Initialized
INFO - 2023-03-10 10:09:56 --> Security Class Initialized
DEBUG - 2023-03-10 10:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:09:56 --> Input Class Initialized
INFO - 2023-03-10 10:09:56 --> Language Class Initialized
INFO - 2023-03-10 10:09:56 --> Loader Class Initialized
INFO - 2023-03-10 10:09:56 --> Controller Class Initialized
DEBUG - 2023-03-10 10:09:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:09:56 --> Database Driver Class Initialized
INFO - 2023-03-10 10:09:56 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:09:56 --> Database Driver Class Initialized
INFO - 2023-03-10 10:09:56 --> Model "Login_model" initialized
INFO - 2023-03-10 10:09:56 --> Final output sent to browser
DEBUG - 2023-03-10 10:09:56 --> Total execution time: 0.0838
INFO - 2023-03-10 10:09:56 --> Config Class Initialized
INFO - 2023-03-10 10:09:56 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:09:56 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:09:56 --> Utf8 Class Initialized
INFO - 2023-03-10 10:09:56 --> URI Class Initialized
INFO - 2023-03-10 10:09:56 --> Router Class Initialized
INFO - 2023-03-10 10:09:56 --> Output Class Initialized
INFO - 2023-03-10 10:09:56 --> Security Class Initialized
DEBUG - 2023-03-10 10:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:09:56 --> Input Class Initialized
INFO - 2023-03-10 10:09:56 --> Language Class Initialized
INFO - 2023-03-10 10:09:56 --> Loader Class Initialized
INFO - 2023-03-10 10:09:56 --> Controller Class Initialized
DEBUG - 2023-03-10 10:09:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:09:56 --> Database Driver Class Initialized
INFO - 2023-03-10 10:09:56 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:09:56 --> Database Driver Class Initialized
INFO - 2023-03-10 10:09:56 --> Model "Login_model" initialized
INFO - 2023-03-10 10:09:56 --> Final output sent to browser
DEBUG - 2023-03-10 10:09:56 --> Total execution time: 0.0379
INFO - 2023-03-10 10:10:03 --> Config Class Initialized
INFO - 2023-03-10 10:10:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:10:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:10:03 --> Utf8 Class Initialized
INFO - 2023-03-10 10:10:03 --> URI Class Initialized
INFO - 2023-03-10 10:10:03 --> Router Class Initialized
INFO - 2023-03-10 10:10:03 --> Output Class Initialized
INFO - 2023-03-10 10:10:03 --> Security Class Initialized
DEBUG - 2023-03-10 10:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:10:03 --> Input Class Initialized
INFO - 2023-03-10 10:10:03 --> Language Class Initialized
INFO - 2023-03-10 10:10:03 --> Loader Class Initialized
INFO - 2023-03-10 10:10:03 --> Controller Class Initialized
DEBUG - 2023-03-10 10:10:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:10:03 --> Final output sent to browser
DEBUG - 2023-03-10 10:10:03 --> Total execution time: 0.0576
INFO - 2023-03-10 10:10:03 --> Config Class Initialized
INFO - 2023-03-10 10:10:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:10:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:10:03 --> Utf8 Class Initialized
INFO - 2023-03-10 10:10:03 --> URI Class Initialized
INFO - 2023-03-10 10:10:03 --> Router Class Initialized
INFO - 2023-03-10 10:10:03 --> Output Class Initialized
INFO - 2023-03-10 10:10:03 --> Security Class Initialized
DEBUG - 2023-03-10 10:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:10:03 --> Input Class Initialized
INFO - 2023-03-10 10:10:03 --> Language Class Initialized
INFO - 2023-03-10 10:10:03 --> Loader Class Initialized
INFO - 2023-03-10 10:10:03 --> Controller Class Initialized
DEBUG - 2023-03-10 10:10:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:10:03 --> Final output sent to browser
DEBUG - 2023-03-10 10:10:03 --> Total execution time: 0.0646
INFO - 2023-03-10 10:12:04 --> Config Class Initialized
INFO - 2023-03-10 10:12:04 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:04 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:04 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:04 --> URI Class Initialized
INFO - 2023-03-10 10:12:04 --> Router Class Initialized
INFO - 2023-03-10 10:12:04 --> Output Class Initialized
INFO - 2023-03-10 10:12:04 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:04 --> Input Class Initialized
INFO - 2023-03-10 10:12:04 --> Language Class Initialized
INFO - 2023-03-10 10:12:04 --> Loader Class Initialized
INFO - 2023-03-10 10:12:04 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:04 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:04 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:04 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:04 --> Model "Login_model" initialized
INFO - 2023-03-10 10:12:04 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:04 --> Total execution time: 0.0985
INFO - 2023-03-10 10:12:04 --> Config Class Initialized
INFO - 2023-03-10 10:12:04 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:04 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:04 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:04 --> URI Class Initialized
INFO - 2023-03-10 10:12:04 --> Router Class Initialized
INFO - 2023-03-10 10:12:04 --> Output Class Initialized
INFO - 2023-03-10 10:12:04 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:04 --> Input Class Initialized
INFO - 2023-03-10 10:12:04 --> Language Class Initialized
INFO - 2023-03-10 10:12:04 --> Loader Class Initialized
INFO - 2023-03-10 10:12:04 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:04 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:04 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:04 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:04 --> Model "Login_model" initialized
INFO - 2023-03-10 10:12:04 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:04 --> Total execution time: 0.0611
INFO - 2023-03-10 10:12:09 --> Config Class Initialized
INFO - 2023-03-10 10:12:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:09 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:09 --> URI Class Initialized
INFO - 2023-03-10 10:12:09 --> Router Class Initialized
INFO - 2023-03-10 10:12:09 --> Output Class Initialized
INFO - 2023-03-10 10:12:09 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:09 --> Input Class Initialized
INFO - 2023-03-10 10:12:09 --> Language Class Initialized
INFO - 2023-03-10 10:12:09 --> Loader Class Initialized
INFO - 2023-03-10 10:12:09 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:09 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:09 --> Total execution time: 0.0824
INFO - 2023-03-10 10:12:09 --> Config Class Initialized
INFO - 2023-03-10 10:12:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:09 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:09 --> URI Class Initialized
INFO - 2023-03-10 10:12:09 --> Router Class Initialized
INFO - 2023-03-10 10:12:09 --> Output Class Initialized
INFO - 2023-03-10 10:12:09 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:09 --> Input Class Initialized
INFO - 2023-03-10 10:12:09 --> Language Class Initialized
INFO - 2023-03-10 10:12:09 --> Loader Class Initialized
INFO - 2023-03-10 10:12:09 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:09 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:09 --> Total execution time: 0.0643
INFO - 2023-03-10 10:12:15 --> Config Class Initialized
INFO - 2023-03-10 10:12:15 --> Config Class Initialized
INFO - 2023-03-10 10:12:15 --> Hooks Class Initialized
INFO - 2023-03-10 10:12:15 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 10:12:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:15 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:15 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:15 --> URI Class Initialized
INFO - 2023-03-10 10:12:15 --> URI Class Initialized
INFO - 2023-03-10 10:12:15 --> Router Class Initialized
INFO - 2023-03-10 10:12:15 --> Router Class Initialized
INFO - 2023-03-10 10:12:15 --> Output Class Initialized
INFO - 2023-03-10 10:12:15 --> Output Class Initialized
INFO - 2023-03-10 10:12:15 --> Security Class Initialized
INFO - 2023-03-10 10:12:15 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 10:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:15 --> Input Class Initialized
INFO - 2023-03-10 10:12:15 --> Input Class Initialized
INFO - 2023-03-10 10:12:15 --> Language Class Initialized
INFO - 2023-03-10 10:12:15 --> Language Class Initialized
INFO - 2023-03-10 10:12:15 --> Loader Class Initialized
INFO - 2023-03-10 10:12:15 --> Loader Class Initialized
INFO - 2023-03-10 10:12:15 --> Controller Class Initialized
INFO - 2023-03-10 10:12:15 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 10:12:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:15 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:15 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:15 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:15 --> Total execution time: 0.0277
INFO - 2023-03-10 10:12:15 --> Config Class Initialized
INFO - 2023-03-10 10:12:15 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:15 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:15 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:15 --> URI Class Initialized
INFO - 2023-03-10 10:12:15 --> Router Class Initialized
INFO - 2023-03-10 10:12:15 --> Output Class Initialized
INFO - 2023-03-10 10:12:15 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:15 --> Input Class Initialized
INFO - 2023-03-10 10:12:15 --> Language Class Initialized
INFO - 2023-03-10 10:12:15 --> Loader Class Initialized
INFO - 2023-03-10 10:12:15 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:15 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:15 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:16 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:16 --> Total execution time: 0.0708
INFO - 2023-03-10 10:12:16 --> Config Class Initialized
INFO - 2023-03-10 10:12:16 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:16 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:16 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:16 --> URI Class Initialized
INFO - 2023-03-10 10:12:16 --> Router Class Initialized
INFO - 2023-03-10 10:12:16 --> Output Class Initialized
INFO - 2023-03-10 10:12:16 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:16 --> Input Class Initialized
INFO - 2023-03-10 10:12:16 --> Language Class Initialized
INFO - 2023-03-10 10:12:16 --> Loader Class Initialized
INFO - 2023-03-10 10:12:16 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:16 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:19 --> Config Class Initialized
INFO - 2023-03-10 10:12:19 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:19 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:19 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:19 --> URI Class Initialized
INFO - 2023-03-10 10:12:19 --> Router Class Initialized
INFO - 2023-03-10 10:12:19 --> Output Class Initialized
INFO - 2023-03-10 10:12:19 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:19 --> Input Class Initialized
INFO - 2023-03-10 10:12:19 --> Language Class Initialized
INFO - 2023-03-10 10:12:19 --> Loader Class Initialized
INFO - 2023-03-10 10:12:19 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:19 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:19 --> Total execution time: 0.1435
INFO - 2023-03-10 10:12:19 --> Config Class Initialized
INFO - 2023-03-10 10:12:19 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:19 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:19 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:19 --> URI Class Initialized
INFO - 2023-03-10 10:12:19 --> Router Class Initialized
INFO - 2023-03-10 10:12:19 --> Output Class Initialized
INFO - 2023-03-10 10:12:19 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:19 --> Input Class Initialized
INFO - 2023-03-10 10:12:19 --> Language Class Initialized
INFO - 2023-03-10 10:12:19 --> Loader Class Initialized
INFO - 2023-03-10 10:12:19 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:19 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:19 --> Total execution time: 0.1423
INFO - 2023-03-10 10:12:37 --> Config Class Initialized
INFO - 2023-03-10 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:37 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:37 --> URI Class Initialized
INFO - 2023-03-10 10:12:37 --> Router Class Initialized
INFO - 2023-03-10 10:12:37 --> Output Class Initialized
INFO - 2023-03-10 10:12:37 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:37 --> Input Class Initialized
INFO - 2023-03-10 10:12:37 --> Language Class Initialized
INFO - 2023-03-10 10:12:37 --> Loader Class Initialized
INFO - 2023-03-10 10:12:37 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:37 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:37 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:37 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:37 --> Total execution time: 0.0267
INFO - 2023-03-10 10:12:37 --> Config Class Initialized
INFO - 2023-03-10 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:37 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:37 --> URI Class Initialized
INFO - 2023-03-10 10:12:37 --> Router Class Initialized
INFO - 2023-03-10 10:12:37 --> Output Class Initialized
INFO - 2023-03-10 10:12:37 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:37 --> Input Class Initialized
INFO - 2023-03-10 10:12:37 --> Language Class Initialized
INFO - 2023-03-10 10:12:37 --> Loader Class Initialized
INFO - 2023-03-10 10:12:37 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:37 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:37 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:37 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:37 --> Total execution time: 0.0574
INFO - 2023-03-10 10:12:39 --> Config Class Initialized
INFO - 2023-03-10 10:12:39 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:39 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:39 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:39 --> URI Class Initialized
INFO - 2023-03-10 10:12:39 --> Router Class Initialized
INFO - 2023-03-10 10:12:39 --> Output Class Initialized
INFO - 2023-03-10 10:12:39 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:39 --> Input Class Initialized
INFO - 2023-03-10 10:12:39 --> Language Class Initialized
INFO - 2023-03-10 10:12:39 --> Loader Class Initialized
INFO - 2023-03-10 10:12:39 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:39 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:39 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:39 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:39 --> Total execution time: 0.1045
INFO - 2023-03-10 10:12:39 --> Config Class Initialized
INFO - 2023-03-10 10:12:39 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:39 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:39 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:39 --> URI Class Initialized
INFO - 2023-03-10 10:12:39 --> Router Class Initialized
INFO - 2023-03-10 10:12:39 --> Output Class Initialized
INFO - 2023-03-10 10:12:39 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:39 --> Input Class Initialized
INFO - 2023-03-10 10:12:39 --> Language Class Initialized
INFO - 2023-03-10 10:12:39 --> Loader Class Initialized
INFO - 2023-03-10 10:12:39 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:39 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:39 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:39 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:39 --> Total execution time: 0.1205
INFO - 2023-03-10 10:12:43 --> Config Class Initialized
INFO - 2023-03-10 10:12:43 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:43 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:43 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:43 --> URI Class Initialized
INFO - 2023-03-10 10:12:43 --> Router Class Initialized
INFO - 2023-03-10 10:12:43 --> Output Class Initialized
INFO - 2023-03-10 10:12:43 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:43 --> Input Class Initialized
INFO - 2023-03-10 10:12:43 --> Language Class Initialized
INFO - 2023-03-10 10:12:43 --> Loader Class Initialized
INFO - 2023-03-10 10:12:43 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:43 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:43 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:43 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:43 --> Model "Login_model" initialized
INFO - 2023-03-10 10:12:43 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:43 --> Total execution time: 0.0549
INFO - 2023-03-10 10:12:43 --> Config Class Initialized
INFO - 2023-03-10 10:12:43 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:43 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:43 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:43 --> URI Class Initialized
INFO - 2023-03-10 10:12:43 --> Router Class Initialized
INFO - 2023-03-10 10:12:43 --> Output Class Initialized
INFO - 2023-03-10 10:12:43 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:43 --> Input Class Initialized
INFO - 2023-03-10 10:12:43 --> Language Class Initialized
INFO - 2023-03-10 10:12:43 --> Loader Class Initialized
INFO - 2023-03-10 10:12:43 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:43 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:43 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:43 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:43 --> Model "Login_model" initialized
INFO - 2023-03-10 10:12:43 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:43 --> Total execution time: 0.0498
INFO - 2023-03-10 10:12:46 --> Config Class Initialized
INFO - 2023-03-10 10:12:46 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:46 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:46 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:46 --> URI Class Initialized
INFO - 2023-03-10 10:12:46 --> Router Class Initialized
INFO - 2023-03-10 10:12:46 --> Output Class Initialized
INFO - 2023-03-10 10:12:46 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:46 --> Input Class Initialized
INFO - 2023-03-10 10:12:46 --> Language Class Initialized
INFO - 2023-03-10 10:12:46 --> Loader Class Initialized
INFO - 2023-03-10 10:12:46 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:46 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:46 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:46 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:46 --> Total execution time: 0.0858
INFO - 2023-03-10 10:12:46 --> Config Class Initialized
INFO - 2023-03-10 10:12:46 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:46 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:46 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:46 --> URI Class Initialized
INFO - 2023-03-10 10:12:46 --> Router Class Initialized
INFO - 2023-03-10 10:12:46 --> Output Class Initialized
INFO - 2023-03-10 10:12:46 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:46 --> Input Class Initialized
INFO - 2023-03-10 10:12:46 --> Language Class Initialized
INFO - 2023-03-10 10:12:46 --> Loader Class Initialized
INFO - 2023-03-10 10:12:46 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:46 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:46 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:46 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:46 --> Total execution time: 0.0758
INFO - 2023-03-10 10:12:50 --> Config Class Initialized
INFO - 2023-03-10 10:12:50 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:50 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:50 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:50 --> URI Class Initialized
INFO - 2023-03-10 10:12:50 --> Router Class Initialized
INFO - 2023-03-10 10:12:50 --> Output Class Initialized
INFO - 2023-03-10 10:12:50 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:50 --> Input Class Initialized
INFO - 2023-03-10 10:12:50 --> Language Class Initialized
INFO - 2023-03-10 10:12:50 --> Loader Class Initialized
INFO - 2023-03-10 10:12:50 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:50 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:50 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:50 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:50 --> Model "Login_model" initialized
INFO - 2023-03-10 10:12:50 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:50 --> Total execution time: 0.0569
INFO - 2023-03-10 10:12:50 --> Config Class Initialized
INFO - 2023-03-10 10:12:50 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:50 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:50 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:50 --> URI Class Initialized
INFO - 2023-03-10 10:12:50 --> Router Class Initialized
INFO - 2023-03-10 10:12:50 --> Output Class Initialized
INFO - 2023-03-10 10:12:50 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:50 --> Input Class Initialized
INFO - 2023-03-10 10:12:50 --> Language Class Initialized
INFO - 2023-03-10 10:12:50 --> Loader Class Initialized
INFO - 2023-03-10 10:12:50 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:50 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:50 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:50 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:50 --> Model "Login_model" initialized
INFO - 2023-03-10 10:12:50 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:50 --> Total execution time: 0.0571
INFO - 2023-03-10 10:12:52 --> Config Class Initialized
INFO - 2023-03-10 10:12:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:52 --> URI Class Initialized
INFO - 2023-03-10 10:12:52 --> Router Class Initialized
INFO - 2023-03-10 10:12:52 --> Output Class Initialized
INFO - 2023-03-10 10:12:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:52 --> Input Class Initialized
INFO - 2023-03-10 10:12:52 --> Language Class Initialized
INFO - 2023-03-10 10:12:52 --> Loader Class Initialized
INFO - 2023-03-10 10:12:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:52 --> Total execution time: 0.0048
INFO - 2023-03-10 10:12:52 --> Config Class Initialized
INFO - 2023-03-10 10:12:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:52 --> URI Class Initialized
INFO - 2023-03-10 10:12:52 --> Router Class Initialized
INFO - 2023-03-10 10:12:52 --> Output Class Initialized
INFO - 2023-03-10 10:12:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:52 --> Input Class Initialized
INFO - 2023-03-10 10:12:52 --> Language Class Initialized
INFO - 2023-03-10 10:12:52 --> Loader Class Initialized
INFO - 2023-03-10 10:12:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:52 --> Model "Login_model" initialized
INFO - 2023-03-10 10:12:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:52 --> Total execution time: 0.0234
INFO - 2023-03-10 10:12:52 --> Config Class Initialized
INFO - 2023-03-10 10:12:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:52 --> URI Class Initialized
INFO - 2023-03-10 10:12:52 --> Router Class Initialized
INFO - 2023-03-10 10:12:52 --> Output Class Initialized
INFO - 2023-03-10 10:12:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:52 --> Input Class Initialized
INFO - 2023-03-10 10:12:52 --> Language Class Initialized
INFO - 2023-03-10 10:12:52 --> Loader Class Initialized
INFO - 2023-03-10 10:12:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:52 --> Total execution time: 0.0428
INFO - 2023-03-10 10:12:52 --> Config Class Initialized
INFO - 2023-03-10 10:12:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:52 --> URI Class Initialized
INFO - 2023-03-10 10:12:52 --> Router Class Initialized
INFO - 2023-03-10 10:12:52 --> Output Class Initialized
INFO - 2023-03-10 10:12:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:52 --> Input Class Initialized
INFO - 2023-03-10 10:12:52 --> Language Class Initialized
INFO - 2023-03-10 10:12:52 --> Loader Class Initialized
INFO - 2023-03-10 10:12:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:52 --> Model "Login_model" initialized
INFO - 2023-03-10 10:12:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:52 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:52 --> Total execution time: 0.0257
INFO - 2023-03-10 10:12:54 --> Config Class Initialized
INFO - 2023-03-10 10:12:54 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:54 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:54 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:54 --> URI Class Initialized
INFO - 2023-03-10 10:12:54 --> Router Class Initialized
INFO - 2023-03-10 10:12:54 --> Output Class Initialized
INFO - 2023-03-10 10:12:54 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:54 --> Input Class Initialized
INFO - 2023-03-10 10:12:54 --> Language Class Initialized
INFO - 2023-03-10 10:12:54 --> Loader Class Initialized
INFO - 2023-03-10 10:12:54 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:54 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:54 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:54 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:54 --> Total execution time: 0.0210
INFO - 2023-03-10 10:12:54 --> Config Class Initialized
INFO - 2023-03-10 10:12:54 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:54 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:54 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:54 --> URI Class Initialized
INFO - 2023-03-10 10:12:54 --> Router Class Initialized
INFO - 2023-03-10 10:12:54 --> Output Class Initialized
INFO - 2023-03-10 10:12:54 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:54 --> Input Class Initialized
INFO - 2023-03-10 10:12:54 --> Language Class Initialized
INFO - 2023-03-10 10:12:54 --> Loader Class Initialized
INFO - 2023-03-10 10:12:54 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:54 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:54 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:54 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:54 --> Total execution time: 0.0583
INFO - 2023-03-10 10:12:57 --> Config Class Initialized
INFO - 2023-03-10 10:12:57 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:57 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:57 --> URI Class Initialized
INFO - 2023-03-10 10:12:57 --> Router Class Initialized
INFO - 2023-03-10 10:12:57 --> Output Class Initialized
INFO - 2023-03-10 10:12:57 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:57 --> Input Class Initialized
INFO - 2023-03-10 10:12:57 --> Language Class Initialized
INFO - 2023-03-10 10:12:57 --> Loader Class Initialized
INFO - 2023-03-10 10:12:57 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:57 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:57 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:57 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:57 --> Total execution time: 0.0214
INFO - 2023-03-10 10:12:57 --> Config Class Initialized
INFO - 2023-03-10 10:12:57 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:12:57 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:12:57 --> Utf8 Class Initialized
INFO - 2023-03-10 10:12:57 --> URI Class Initialized
INFO - 2023-03-10 10:12:57 --> Router Class Initialized
INFO - 2023-03-10 10:12:57 --> Output Class Initialized
INFO - 2023-03-10 10:12:57 --> Security Class Initialized
DEBUG - 2023-03-10 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:12:57 --> Input Class Initialized
INFO - 2023-03-10 10:12:57 --> Language Class Initialized
INFO - 2023-03-10 10:12:57 --> Loader Class Initialized
INFO - 2023-03-10 10:12:57 --> Controller Class Initialized
DEBUG - 2023-03-10 10:12:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:12:57 --> Database Driver Class Initialized
INFO - 2023-03-10 10:12:57 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:12:57 --> Final output sent to browser
DEBUG - 2023-03-10 10:12:57 --> Total execution time: 0.0168
INFO - 2023-03-10 10:13:02 --> Config Class Initialized
INFO - 2023-03-10 10:13:02 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:13:02 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:13:02 --> Utf8 Class Initialized
INFO - 2023-03-10 10:13:02 --> URI Class Initialized
INFO - 2023-03-10 10:13:02 --> Router Class Initialized
INFO - 2023-03-10 10:13:02 --> Output Class Initialized
INFO - 2023-03-10 10:13:02 --> Security Class Initialized
DEBUG - 2023-03-10 10:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:13:02 --> Input Class Initialized
INFO - 2023-03-10 10:13:02 --> Language Class Initialized
INFO - 2023-03-10 10:13:02 --> Loader Class Initialized
INFO - 2023-03-10 10:13:02 --> Controller Class Initialized
DEBUG - 2023-03-10 10:13:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:13:02 --> Database Driver Class Initialized
INFO - 2023-03-10 10:13:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:13:02 --> Final output sent to browser
DEBUG - 2023-03-10 10:13:02 --> Total execution time: 0.0564
INFO - 2023-03-10 10:13:02 --> Config Class Initialized
INFO - 2023-03-10 10:13:02 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:13:02 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:13:02 --> Utf8 Class Initialized
INFO - 2023-03-10 10:13:02 --> URI Class Initialized
INFO - 2023-03-10 10:13:02 --> Router Class Initialized
INFO - 2023-03-10 10:13:02 --> Output Class Initialized
INFO - 2023-03-10 10:13:02 --> Security Class Initialized
DEBUG - 2023-03-10 10:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:13:02 --> Input Class Initialized
INFO - 2023-03-10 10:13:02 --> Language Class Initialized
INFO - 2023-03-10 10:13:02 --> Loader Class Initialized
INFO - 2023-03-10 10:13:02 --> Controller Class Initialized
DEBUG - 2023-03-10 10:13:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:13:02 --> Database Driver Class Initialized
INFO - 2023-03-10 10:13:02 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:13:02 --> Final output sent to browser
DEBUG - 2023-03-10 10:13:02 --> Total execution time: 0.0552
INFO - 2023-03-10 10:13:04 --> Config Class Initialized
INFO - 2023-03-10 10:13:04 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:13:04 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:13:04 --> Utf8 Class Initialized
INFO - 2023-03-10 10:13:04 --> URI Class Initialized
INFO - 2023-03-10 10:13:04 --> Router Class Initialized
INFO - 2023-03-10 10:13:04 --> Output Class Initialized
INFO - 2023-03-10 10:13:04 --> Security Class Initialized
DEBUG - 2023-03-10 10:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:13:04 --> Input Class Initialized
INFO - 2023-03-10 10:13:04 --> Language Class Initialized
INFO - 2023-03-10 10:13:04 --> Loader Class Initialized
INFO - 2023-03-10 10:13:04 --> Controller Class Initialized
DEBUG - 2023-03-10 10:13:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:13:04 --> Database Driver Class Initialized
INFO - 2023-03-10 10:13:05 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:13:05 --> Database Driver Class Initialized
INFO - 2023-03-10 10:13:05 --> Model "Login_model" initialized
INFO - 2023-03-10 10:13:05 --> Final output sent to browser
DEBUG - 2023-03-10 10:13:05 --> Total execution time: 0.0558
INFO - 2023-03-10 10:13:05 --> Config Class Initialized
INFO - 2023-03-10 10:13:05 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:13:05 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:13:05 --> Utf8 Class Initialized
INFO - 2023-03-10 10:13:05 --> URI Class Initialized
INFO - 2023-03-10 10:13:05 --> Router Class Initialized
INFO - 2023-03-10 10:13:05 --> Output Class Initialized
INFO - 2023-03-10 10:13:05 --> Security Class Initialized
DEBUG - 2023-03-10 10:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:13:05 --> Input Class Initialized
INFO - 2023-03-10 10:13:05 --> Language Class Initialized
INFO - 2023-03-10 10:13:05 --> Loader Class Initialized
INFO - 2023-03-10 10:13:05 --> Controller Class Initialized
DEBUG - 2023-03-10 10:13:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:13:05 --> Database Driver Class Initialized
INFO - 2023-03-10 10:13:05 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:13:05 --> Database Driver Class Initialized
INFO - 2023-03-10 10:13:05 --> Model "Login_model" initialized
INFO - 2023-03-10 10:13:05 --> Final output sent to browser
DEBUG - 2023-03-10 10:13:05 --> Total execution time: 0.1418
INFO - 2023-03-10 10:13:07 --> Config Class Initialized
INFO - 2023-03-10 10:13:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:13:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:13:07 --> Utf8 Class Initialized
INFO - 2023-03-10 10:13:07 --> URI Class Initialized
INFO - 2023-03-10 10:13:07 --> Router Class Initialized
INFO - 2023-03-10 10:13:07 --> Output Class Initialized
INFO - 2023-03-10 10:13:07 --> Security Class Initialized
DEBUG - 2023-03-10 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:13:07 --> Input Class Initialized
INFO - 2023-03-10 10:13:07 --> Language Class Initialized
INFO - 2023-03-10 10:13:07 --> Loader Class Initialized
INFO - 2023-03-10 10:13:07 --> Controller Class Initialized
DEBUG - 2023-03-10 10:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:13:07 --> Final output sent to browser
DEBUG - 2023-03-10 10:13:07 --> Total execution time: 0.0745
INFO - 2023-03-10 10:13:07 --> Config Class Initialized
INFO - 2023-03-10 10:13:07 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:13:07 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:13:07 --> Utf8 Class Initialized
INFO - 2023-03-10 10:13:07 --> URI Class Initialized
INFO - 2023-03-10 10:13:07 --> Router Class Initialized
INFO - 2023-03-10 10:13:07 --> Output Class Initialized
INFO - 2023-03-10 10:13:07 --> Security Class Initialized
DEBUG - 2023-03-10 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:13:07 --> Input Class Initialized
INFO - 2023-03-10 10:13:07 --> Language Class Initialized
INFO - 2023-03-10 10:13:07 --> Loader Class Initialized
INFO - 2023-03-10 10:13:07 --> Controller Class Initialized
DEBUG - 2023-03-10 10:13:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:13:08 --> Final output sent to browser
DEBUG - 2023-03-10 10:13:08 --> Total execution time: 0.0664
INFO - 2023-03-10 10:16:59 --> Config Class Initialized
INFO - 2023-03-10 10:16:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:16:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:16:59 --> Utf8 Class Initialized
INFO - 2023-03-10 10:16:59 --> URI Class Initialized
INFO - 2023-03-10 10:16:59 --> Router Class Initialized
INFO - 2023-03-10 10:16:59 --> Output Class Initialized
INFO - 2023-03-10 10:16:59 --> Security Class Initialized
DEBUG - 2023-03-10 10:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:16:59 --> Input Class Initialized
INFO - 2023-03-10 10:16:59 --> Language Class Initialized
INFO - 2023-03-10 10:16:59 --> Loader Class Initialized
INFO - 2023-03-10 10:16:59 --> Controller Class Initialized
DEBUG - 2023-03-10 10:16:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:16:59 --> Database Driver Class Initialized
INFO - 2023-03-10 10:16:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:16:59 --> Database Driver Class Initialized
INFO - 2023-03-10 10:16:59 --> Model "Login_model" initialized
INFO - 2023-03-10 10:16:59 --> Final output sent to browser
DEBUG - 2023-03-10 10:16:59 --> Total execution time: 0.1198
INFO - 2023-03-10 10:16:59 --> Config Class Initialized
INFO - 2023-03-10 10:16:59 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:16:59 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:16:59 --> Utf8 Class Initialized
INFO - 2023-03-10 10:16:59 --> URI Class Initialized
INFO - 2023-03-10 10:16:59 --> Router Class Initialized
INFO - 2023-03-10 10:16:59 --> Output Class Initialized
INFO - 2023-03-10 10:16:59 --> Security Class Initialized
DEBUG - 2023-03-10 10:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:16:59 --> Input Class Initialized
INFO - 2023-03-10 10:16:59 --> Language Class Initialized
INFO - 2023-03-10 10:16:59 --> Loader Class Initialized
INFO - 2023-03-10 10:16:59 --> Controller Class Initialized
DEBUG - 2023-03-10 10:16:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:16:59 --> Database Driver Class Initialized
INFO - 2023-03-10 10:16:59 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:16:59 --> Database Driver Class Initialized
INFO - 2023-03-10 10:16:59 --> Model "Login_model" initialized
INFO - 2023-03-10 10:16:59 --> Final output sent to browser
DEBUG - 2023-03-10 10:16:59 --> Total execution time: 0.0338
INFO - 2023-03-10 10:17:01 --> Config Class Initialized
INFO - 2023-03-10 10:17:01 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:17:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:17:01 --> Utf8 Class Initialized
INFO - 2023-03-10 10:17:01 --> URI Class Initialized
INFO - 2023-03-10 10:17:01 --> Router Class Initialized
INFO - 2023-03-10 10:17:01 --> Output Class Initialized
INFO - 2023-03-10 10:17:01 --> Security Class Initialized
DEBUG - 2023-03-10 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:17:01 --> Input Class Initialized
INFO - 2023-03-10 10:17:01 --> Language Class Initialized
INFO - 2023-03-10 10:17:01 --> Loader Class Initialized
INFO - 2023-03-10 10:17:01 --> Controller Class Initialized
DEBUG - 2023-03-10 10:17:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:17:01 --> Database Driver Class Initialized
INFO - 2023-03-10 10:17:01 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:17:01 --> Final output sent to browser
DEBUG - 2023-03-10 10:17:01 --> Total execution time: 0.0168
INFO - 2023-03-10 10:17:01 --> Config Class Initialized
INFO - 2023-03-10 10:17:01 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:17:01 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:17:01 --> Utf8 Class Initialized
INFO - 2023-03-10 10:17:01 --> URI Class Initialized
INFO - 2023-03-10 10:17:01 --> Router Class Initialized
INFO - 2023-03-10 10:17:01 --> Output Class Initialized
INFO - 2023-03-10 10:17:01 --> Security Class Initialized
DEBUG - 2023-03-10 10:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:17:01 --> Input Class Initialized
INFO - 2023-03-10 10:17:01 --> Language Class Initialized
INFO - 2023-03-10 10:17:01 --> Loader Class Initialized
INFO - 2023-03-10 10:17:01 --> Controller Class Initialized
DEBUG - 2023-03-10 10:17:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:17:01 --> Database Driver Class Initialized
INFO - 2023-03-10 10:17:01 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:17:01 --> Final output sent to browser
DEBUG - 2023-03-10 10:17:01 --> Total execution time: 0.0123
INFO - 2023-03-10 10:17:03 --> Config Class Initialized
INFO - 2023-03-10 10:17:03 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:17:03 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:17:03 --> Utf8 Class Initialized
INFO - 2023-03-10 10:17:03 --> URI Class Initialized
INFO - 2023-03-10 10:17:03 --> Router Class Initialized
INFO - 2023-03-10 10:17:03 --> Output Class Initialized
INFO - 2023-03-10 10:17:03 --> Security Class Initialized
DEBUG - 2023-03-10 10:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:17:03 --> Input Class Initialized
INFO - 2023-03-10 10:17:03 --> Language Class Initialized
INFO - 2023-03-10 10:17:03 --> Loader Class Initialized
INFO - 2023-03-10 10:17:03 --> Controller Class Initialized
DEBUG - 2023-03-10 10:17:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:17:03 --> Database Driver Class Initialized
INFO - 2023-03-10 10:17:03 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:17:03 --> Database Driver Class Initialized
INFO - 2023-03-10 10:17:03 --> Model "Login_model" initialized
INFO - 2023-03-10 10:17:03 --> Final output sent to browser
DEBUG - 2023-03-10 10:17:03 --> Total execution time: 0.0390
INFO - 2023-03-10 10:17:06 --> Config Class Initialized
INFO - 2023-03-10 10:17:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:17:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:17:06 --> Utf8 Class Initialized
INFO - 2023-03-10 10:17:06 --> URI Class Initialized
INFO - 2023-03-10 10:17:06 --> Router Class Initialized
INFO - 2023-03-10 10:17:06 --> Output Class Initialized
INFO - 2023-03-10 10:17:06 --> Security Class Initialized
DEBUG - 2023-03-10 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:17:06 --> Input Class Initialized
INFO - 2023-03-10 10:17:06 --> Language Class Initialized
INFO - 2023-03-10 10:17:06 --> Loader Class Initialized
INFO - 2023-03-10 10:17:06 --> Controller Class Initialized
DEBUG - 2023-03-10 10:17:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:17:06 --> Final output sent to browser
DEBUG - 2023-03-10 10:17:06 --> Total execution time: 0.0550
INFO - 2023-03-10 10:17:06 --> Config Class Initialized
INFO - 2023-03-10 10:17:06 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:17:06 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:17:06 --> Utf8 Class Initialized
INFO - 2023-03-10 10:17:06 --> URI Class Initialized
INFO - 2023-03-10 10:17:06 --> Router Class Initialized
INFO - 2023-03-10 10:17:06 --> Output Class Initialized
INFO - 2023-03-10 10:17:06 --> Security Class Initialized
DEBUG - 2023-03-10 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:17:06 --> Input Class Initialized
INFO - 2023-03-10 10:17:06 --> Language Class Initialized
INFO - 2023-03-10 10:17:06 --> Loader Class Initialized
INFO - 2023-03-10 10:17:06 --> Controller Class Initialized
DEBUG - 2023-03-10 10:17:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:17:06 --> Final output sent to browser
DEBUG - 2023-03-10 10:17:06 --> Total execution time: 0.0517
INFO - 2023-03-10 10:28:32 --> Config Class Initialized
INFO - 2023-03-10 10:28:32 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:28:32 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:32 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:32 --> URI Class Initialized
INFO - 2023-03-10 10:28:32 --> Router Class Initialized
INFO - 2023-03-10 10:28:32 --> Output Class Initialized
INFO - 2023-03-10 10:28:32 --> Security Class Initialized
DEBUG - 2023-03-10 10:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:32 --> Input Class Initialized
INFO - 2023-03-10 10:28:32 --> Language Class Initialized
INFO - 2023-03-10 10:28:32 --> Loader Class Initialized
INFO - 2023-03-10 10:28:32 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:32 --> Database Driver Class Initialized
INFO - 2023-03-10 10:28:32 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:28:32 --> Config Class Initialized
INFO - 2023-03-10 10:28:32 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:28:32 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:32 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:32 --> URI Class Initialized
INFO - 2023-03-10 10:28:32 --> Router Class Initialized
INFO - 2023-03-10 10:28:32 --> Output Class Initialized
INFO - 2023-03-10 10:28:32 --> Security Class Initialized
DEBUG - 2023-03-10 10:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:32 --> Input Class Initialized
INFO - 2023-03-10 10:28:32 --> Language Class Initialized
INFO - 2023-03-10 10:28:32 --> Loader Class Initialized
INFO - 2023-03-10 10:28:32 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:32 --> Database Driver Class Initialized
INFO - 2023-03-10 10:28:32 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:28:33 --> Config Class Initialized
INFO - 2023-03-10 10:28:33 --> Hooks Class Initialized
INFO - 2023-03-10 10:28:33 --> Config Class Initialized
DEBUG - 2023-03-10 10:28:33 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:33 --> Hooks Class Initialized
INFO - 2023-03-10 10:28:33 --> Utf8 Class Initialized
DEBUG - 2023-03-10 10:28:33 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:33 --> URI Class Initialized
INFO - 2023-03-10 10:28:33 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:33 --> Router Class Initialized
INFO - 2023-03-10 10:28:33 --> URI Class Initialized
INFO - 2023-03-10 10:28:33 --> Output Class Initialized
INFO - 2023-03-10 10:28:33 --> Router Class Initialized
INFO - 2023-03-10 10:28:33 --> Security Class Initialized
INFO - 2023-03-10 10:28:33 --> Output Class Initialized
DEBUG - 2023-03-10 10:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:33 --> Security Class Initialized
INFO - 2023-03-10 10:28:33 --> Input Class Initialized
DEBUG - 2023-03-10 10:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:33 --> Language Class Initialized
INFO - 2023-03-10 10:28:33 --> Input Class Initialized
INFO - 2023-03-10 10:28:33 --> Language Class Initialized
INFO - 2023-03-10 10:28:33 --> Loader Class Initialized
INFO - 2023-03-10 10:28:33 --> Loader Class Initialized
INFO - 2023-03-10 10:28:33 --> Controller Class Initialized
INFO - 2023-03-10 10:28:33 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 10:28:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:33 --> Database Driver Class Initialized
INFO - 2023-03-10 10:28:33 --> Database Driver Class Initialized
INFO - 2023-03-10 10:28:33 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:28:33 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:28:33 --> Final output sent to browser
DEBUG - 2023-03-10 10:28:33 --> Total execution time: 0.0159
INFO - 2023-03-10 10:28:33 --> Config Class Initialized
INFO - 2023-03-10 10:28:33 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:28:33 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:33 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:33 --> URI Class Initialized
INFO - 2023-03-10 10:28:33 --> Router Class Initialized
INFO - 2023-03-10 10:28:33 --> Output Class Initialized
INFO - 2023-03-10 10:28:33 --> Security Class Initialized
DEBUG - 2023-03-10 10:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:33 --> Input Class Initialized
INFO - 2023-03-10 10:28:33 --> Language Class Initialized
INFO - 2023-03-10 10:28:33 --> Loader Class Initialized
INFO - 2023-03-10 10:28:33 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:33 --> Database Driver Class Initialized
INFO - 2023-03-10 10:28:33 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:28:33 --> Config Class Initialized
INFO - 2023-03-10 10:28:33 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:28:33 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:33 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:33 --> URI Class Initialized
INFO - 2023-03-10 10:28:33 --> Router Class Initialized
INFO - 2023-03-10 10:28:33 --> Final output sent to browser
INFO - 2023-03-10 10:28:33 --> Output Class Initialized
DEBUG - 2023-03-10 10:28:33 --> Total execution time: 0.0525
INFO - 2023-03-10 10:28:33 --> Security Class Initialized
DEBUG - 2023-03-10 10:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:33 --> Input Class Initialized
INFO - 2023-03-10 10:28:33 --> Language Class Initialized
INFO - 2023-03-10 10:28:33 --> Loader Class Initialized
INFO - 2023-03-10 10:28:33 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:33 --> Database Driver Class Initialized
INFO - 2023-03-10 10:28:33 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:28:36 --> Config Class Initialized
INFO - 2023-03-10 10:28:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:28:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:36 --> URI Class Initialized
INFO - 2023-03-10 10:28:36 --> Router Class Initialized
INFO - 2023-03-10 10:28:36 --> Output Class Initialized
INFO - 2023-03-10 10:28:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:36 --> Input Class Initialized
INFO - 2023-03-10 10:28:36 --> Language Class Initialized
INFO - 2023-03-10 10:28:36 --> Loader Class Initialized
INFO - 2023-03-10 10:28:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:28:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:28:36 --> Config Class Initialized
INFO - 2023-03-10 10:28:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:28:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:36 --> URI Class Initialized
INFO - 2023-03-10 10:28:36 --> Router Class Initialized
INFO - 2023-03-10 10:28:36 --> Output Class Initialized
INFO - 2023-03-10 10:28:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:36 --> Input Class Initialized
INFO - 2023-03-10 10:28:36 --> Language Class Initialized
INFO - 2023-03-10 10:28:36 --> Loader Class Initialized
INFO - 2023-03-10 10:28:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:28:36 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:28:45 --> Config Class Initialized
INFO - 2023-03-10 10:28:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:28:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:45 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:45 --> URI Class Initialized
INFO - 2023-03-10 10:28:45 --> Router Class Initialized
INFO - 2023-03-10 10:28:45 --> Output Class Initialized
INFO - 2023-03-10 10:28:45 --> Security Class Initialized
DEBUG - 2023-03-10 10:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:45 --> Input Class Initialized
INFO - 2023-03-10 10:28:45 --> Language Class Initialized
INFO - 2023-03-10 10:28:45 --> Loader Class Initialized
INFO - 2023-03-10 10:28:45 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:45 --> Final output sent to browser
DEBUG - 2023-03-10 10:28:45 --> Total execution time: 0.1031
INFO - 2023-03-10 10:28:45 --> Config Class Initialized
INFO - 2023-03-10 10:28:45 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:28:45 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:28:45 --> Utf8 Class Initialized
INFO - 2023-03-10 10:28:45 --> URI Class Initialized
INFO - 2023-03-10 10:28:45 --> Router Class Initialized
INFO - 2023-03-10 10:28:45 --> Output Class Initialized
INFO - 2023-03-10 10:28:45 --> Security Class Initialized
DEBUG - 2023-03-10 10:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:28:45 --> Input Class Initialized
INFO - 2023-03-10 10:28:45 --> Language Class Initialized
INFO - 2023-03-10 10:28:45 --> Loader Class Initialized
INFO - 2023-03-10 10:28:45 --> Controller Class Initialized
DEBUG - 2023-03-10 10:28:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:28:45 --> Final output sent to browser
DEBUG - 2023-03-10 10:28:45 --> Total execution time: 0.0980
INFO - 2023-03-10 10:29:34 --> Config Class Initialized
INFO - 2023-03-10 10:29:34 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:29:34 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:29:34 --> Utf8 Class Initialized
INFO - 2023-03-10 10:29:34 --> URI Class Initialized
INFO - 2023-03-10 10:29:34 --> Router Class Initialized
INFO - 2023-03-10 10:29:34 --> Output Class Initialized
INFO - 2023-03-10 10:29:34 --> Security Class Initialized
DEBUG - 2023-03-10 10:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:29:34 --> Input Class Initialized
INFO - 2023-03-10 10:29:34 --> Language Class Initialized
INFO - 2023-03-10 10:29:34 --> Loader Class Initialized
INFO - 2023-03-10 10:29:34 --> Controller Class Initialized
DEBUG - 2023-03-10 10:29:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:29:34 --> Database Driver Class Initialized
INFO - 2023-03-10 10:29:34 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:29:34 --> Database Driver Class Initialized
INFO - 2023-03-10 10:29:34 --> Model "Login_model" initialized
INFO - 2023-03-10 10:29:34 --> Final output sent to browser
DEBUG - 2023-03-10 10:29:34 --> Total execution time: 0.1606
INFO - 2023-03-10 10:29:34 --> Config Class Initialized
INFO - 2023-03-10 10:29:34 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:29:34 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:29:34 --> Utf8 Class Initialized
INFO - 2023-03-10 10:29:34 --> URI Class Initialized
INFO - 2023-03-10 10:29:34 --> Router Class Initialized
INFO - 2023-03-10 10:29:34 --> Output Class Initialized
INFO - 2023-03-10 10:29:34 --> Security Class Initialized
DEBUG - 2023-03-10 10:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:29:34 --> Input Class Initialized
INFO - 2023-03-10 10:29:34 --> Language Class Initialized
INFO - 2023-03-10 10:29:34 --> Loader Class Initialized
INFO - 2023-03-10 10:29:34 --> Controller Class Initialized
DEBUG - 2023-03-10 10:29:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:29:34 --> Database Driver Class Initialized
INFO - 2023-03-10 10:29:34 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:29:34 --> Database Driver Class Initialized
INFO - 2023-03-10 10:29:34 --> Model "Login_model" initialized
INFO - 2023-03-10 10:29:34 --> Final output sent to browser
DEBUG - 2023-03-10 10:29:34 --> Total execution time: 0.0786
INFO - 2023-03-10 10:29:38 --> Config Class Initialized
INFO - 2023-03-10 10:29:38 --> Config Class Initialized
INFO - 2023-03-10 10:29:38 --> Hooks Class Initialized
INFO - 2023-03-10 10:29:38 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2023-03-10 10:29:38 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:29:38 --> Utf8 Class Initialized
INFO - 2023-03-10 10:29:38 --> Utf8 Class Initialized
INFO - 2023-03-10 10:29:38 --> URI Class Initialized
INFO - 2023-03-10 10:29:38 --> URI Class Initialized
INFO - 2023-03-10 10:29:38 --> Router Class Initialized
INFO - 2023-03-10 10:29:38 --> Router Class Initialized
INFO - 2023-03-10 10:29:38 --> Output Class Initialized
INFO - 2023-03-10 10:29:38 --> Output Class Initialized
INFO - 2023-03-10 10:29:38 --> Security Class Initialized
INFO - 2023-03-10 10:29:38 --> Security Class Initialized
DEBUG - 2023-03-10 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-03-10 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:29:38 --> Input Class Initialized
INFO - 2023-03-10 10:29:38 --> Input Class Initialized
INFO - 2023-03-10 10:29:38 --> Language Class Initialized
INFO - 2023-03-10 10:29:38 --> Language Class Initialized
INFO - 2023-03-10 10:29:38 --> Loader Class Initialized
INFO - 2023-03-10 10:29:38 --> Loader Class Initialized
INFO - 2023-03-10 10:29:38 --> Controller Class Initialized
INFO - 2023-03-10 10:29:38 --> Controller Class Initialized
DEBUG - 2023-03-10 10:29:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-03-10 10:29:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:29:38 --> Database Driver Class Initialized
INFO - 2023-03-10 10:29:38 --> Database Driver Class Initialized
INFO - 2023-03-10 10:29:38 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:29:38 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:29:38 --> Final output sent to browser
DEBUG - 2023-03-10 10:29:38 --> Total execution time: 0.0176
INFO - 2023-03-10 10:29:38 --> Config Class Initialized
INFO - 2023-03-10 10:29:38 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:29:38 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:29:38 --> Utf8 Class Initialized
INFO - 2023-03-10 10:29:38 --> URI Class Initialized
INFO - 2023-03-10 10:29:38 --> Router Class Initialized
INFO - 2023-03-10 10:29:38 --> Output Class Initialized
INFO - 2023-03-10 10:29:38 --> Security Class Initialized
DEBUG - 2023-03-10 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:29:38 --> Input Class Initialized
INFO - 2023-03-10 10:29:38 --> Language Class Initialized
INFO - 2023-03-10 10:29:38 --> Loader Class Initialized
INFO - 2023-03-10 10:29:38 --> Controller Class Initialized
DEBUG - 2023-03-10 10:29:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:29:38 --> Database Driver Class Initialized
INFO - 2023-03-10 10:29:38 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:29:38 --> Final output sent to browser
DEBUG - 2023-03-10 10:29:38 --> Total execution time: 0.0107
INFO - 2023-03-10 10:29:38 --> Config Class Initialized
INFO - 2023-03-10 10:29:38 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:29:38 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:29:38 --> Utf8 Class Initialized
INFO - 2023-03-10 10:29:38 --> URI Class Initialized
INFO - 2023-03-10 10:29:38 --> Router Class Initialized
INFO - 2023-03-10 10:29:38 --> Output Class Initialized
INFO - 2023-03-10 10:29:38 --> Security Class Initialized
DEBUG - 2023-03-10 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:29:38 --> Input Class Initialized
INFO - 2023-03-10 10:29:38 --> Language Class Initialized
INFO - 2023-03-10 10:29:38 --> Loader Class Initialized
INFO - 2023-03-10 10:29:38 --> Controller Class Initialized
DEBUG - 2023-03-10 10:29:38 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:29:38 --> Database Driver Class Initialized
INFO - 2023-03-10 10:29:38 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:29:39 --> Config Class Initialized
INFO - 2023-03-10 10:29:39 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:29:39 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:29:39 --> Utf8 Class Initialized
INFO - 2023-03-10 10:29:39 --> URI Class Initialized
INFO - 2023-03-10 10:29:39 --> Router Class Initialized
INFO - 2023-03-10 10:29:39 --> Output Class Initialized
INFO - 2023-03-10 10:29:39 --> Security Class Initialized
DEBUG - 2023-03-10 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:29:39 --> Input Class Initialized
INFO - 2023-03-10 10:29:39 --> Language Class Initialized
INFO - 2023-03-10 10:29:39 --> Loader Class Initialized
INFO - 2023-03-10 10:29:39 --> Controller Class Initialized
DEBUG - 2023-03-10 10:29:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:29:39 --> Final output sent to browser
DEBUG - 2023-03-10 10:29:39 --> Total execution time: 0.0531
INFO - 2023-03-10 10:29:39 --> Config Class Initialized
INFO - 2023-03-10 10:29:39 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:29:39 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:29:39 --> Utf8 Class Initialized
INFO - 2023-03-10 10:29:39 --> URI Class Initialized
INFO - 2023-03-10 10:29:39 --> Router Class Initialized
INFO - 2023-03-10 10:29:39 --> Output Class Initialized
INFO - 2023-03-10 10:29:39 --> Security Class Initialized
DEBUG - 2023-03-10 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:29:39 --> Input Class Initialized
INFO - 2023-03-10 10:29:39 --> Language Class Initialized
INFO - 2023-03-10 10:29:39 --> Loader Class Initialized
INFO - 2023-03-10 10:29:39 --> Controller Class Initialized
DEBUG - 2023-03-10 10:29:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:29:39 --> Final output sent to browser
DEBUG - 2023-03-10 10:29:39 --> Total execution time: 0.0516
INFO - 2023-03-10 10:30:09 --> Config Class Initialized
INFO - 2023-03-10 10:30:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:30:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:30:09 --> Utf8 Class Initialized
INFO - 2023-03-10 10:30:09 --> URI Class Initialized
INFO - 2023-03-10 10:30:09 --> Router Class Initialized
INFO - 2023-03-10 10:30:09 --> Output Class Initialized
INFO - 2023-03-10 10:30:09 --> Security Class Initialized
DEBUG - 2023-03-10 10:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:30:09 --> Input Class Initialized
INFO - 2023-03-10 10:30:09 --> Language Class Initialized
INFO - 2023-03-10 10:30:09 --> Loader Class Initialized
INFO - 2023-03-10 10:30:09 --> Controller Class Initialized
DEBUG - 2023-03-10 10:30:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:30:09 --> Database Driver Class Initialized
INFO - 2023-03-10 10:30:09 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:30:09 --> Database Driver Class Initialized
INFO - 2023-03-10 10:30:09 --> Model "Login_model" initialized
INFO - 2023-03-10 10:30:09 --> Final output sent to browser
DEBUG - 2023-03-10 10:30:09 --> Total execution time: 0.0423
INFO - 2023-03-10 10:30:09 --> Config Class Initialized
INFO - 2023-03-10 10:30:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:30:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:30:09 --> Utf8 Class Initialized
INFO - 2023-03-10 10:30:09 --> URI Class Initialized
INFO - 2023-03-10 10:30:09 --> Router Class Initialized
INFO - 2023-03-10 10:30:09 --> Output Class Initialized
INFO - 2023-03-10 10:30:09 --> Security Class Initialized
DEBUG - 2023-03-10 10:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:30:09 --> Input Class Initialized
INFO - 2023-03-10 10:30:09 --> Language Class Initialized
INFO - 2023-03-10 10:30:09 --> Loader Class Initialized
INFO - 2023-03-10 10:30:09 --> Controller Class Initialized
DEBUG - 2023-03-10 10:30:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:30:09 --> Database Driver Class Initialized
INFO - 2023-03-10 10:30:09 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:30:09 --> Database Driver Class Initialized
INFO - 2023-03-10 10:30:09 --> Model "Login_model" initialized
INFO - 2023-03-10 10:30:09 --> Final output sent to browser
DEBUG - 2023-03-10 10:30:09 --> Total execution time: 0.0465
INFO - 2023-03-10 10:30:14 --> Config Class Initialized
INFO - 2023-03-10 10:30:14 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:30:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:30:14 --> Utf8 Class Initialized
INFO - 2023-03-10 10:30:14 --> URI Class Initialized
INFO - 2023-03-10 10:30:14 --> Router Class Initialized
INFO - 2023-03-10 10:30:14 --> Output Class Initialized
INFO - 2023-03-10 10:30:14 --> Security Class Initialized
DEBUG - 2023-03-10 10:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:30:14 --> Input Class Initialized
INFO - 2023-03-10 10:30:14 --> Language Class Initialized
INFO - 2023-03-10 10:30:14 --> Loader Class Initialized
INFO - 2023-03-10 10:30:14 --> Controller Class Initialized
DEBUG - 2023-03-10 10:30:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:30:14 --> Final output sent to browser
DEBUG - 2023-03-10 10:30:14 --> Total execution time: 0.1639
INFO - 2023-03-10 10:30:14 --> Config Class Initialized
INFO - 2023-03-10 10:30:14 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:30:14 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:30:14 --> Utf8 Class Initialized
INFO - 2023-03-10 10:30:14 --> URI Class Initialized
INFO - 2023-03-10 10:30:14 --> Router Class Initialized
INFO - 2023-03-10 10:30:14 --> Output Class Initialized
INFO - 2023-03-10 10:30:14 --> Security Class Initialized
DEBUG - 2023-03-10 10:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:30:14 --> Input Class Initialized
INFO - 2023-03-10 10:30:14 --> Language Class Initialized
INFO - 2023-03-10 10:30:14 --> Loader Class Initialized
INFO - 2023-03-10 10:30:14 --> Controller Class Initialized
DEBUG - 2023-03-10 10:30:14 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:30:14 --> Final output sent to browser
DEBUG - 2023-03-10 10:30:14 --> Total execution time: 0.1537
INFO - 2023-03-10 10:31:16 --> Config Class Initialized
INFO - 2023-03-10 10:31:16 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:31:16 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:31:16 --> Utf8 Class Initialized
INFO - 2023-03-10 10:31:16 --> URI Class Initialized
INFO - 2023-03-10 10:31:16 --> Router Class Initialized
INFO - 2023-03-10 10:31:16 --> Output Class Initialized
INFO - 2023-03-10 10:31:16 --> Security Class Initialized
DEBUG - 2023-03-10 10:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:31:16 --> Input Class Initialized
INFO - 2023-03-10 10:31:16 --> Language Class Initialized
INFO - 2023-03-10 10:31:16 --> Loader Class Initialized
INFO - 2023-03-10 10:31:16 --> Controller Class Initialized
DEBUG - 2023-03-10 10:31:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:31:16 --> Database Driver Class Initialized
INFO - 2023-03-10 10:31:16 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:31:17 --> Config Class Initialized
INFO - 2023-03-10 10:31:17 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:31:17 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:31:17 --> Utf8 Class Initialized
INFO - 2023-03-10 10:31:17 --> URI Class Initialized
INFO - 2023-03-10 10:31:17 --> Router Class Initialized
INFO - 2023-03-10 10:31:17 --> Output Class Initialized
INFO - 2023-03-10 10:31:17 --> Security Class Initialized
DEBUG - 2023-03-10 10:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:31:17 --> Input Class Initialized
INFO - 2023-03-10 10:31:17 --> Language Class Initialized
INFO - 2023-03-10 10:31:17 --> Loader Class Initialized
INFO - 2023-03-10 10:31:17 --> Controller Class Initialized
DEBUG - 2023-03-10 10:31:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:31:17 --> Database Driver Class Initialized
INFO - 2023-03-10 10:31:17 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:31:19 --> Config Class Initialized
INFO - 2023-03-10 10:31:19 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:31:19 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:31:19 --> Utf8 Class Initialized
INFO - 2023-03-10 10:31:19 --> URI Class Initialized
INFO - 2023-03-10 10:31:19 --> Router Class Initialized
INFO - 2023-03-10 10:31:19 --> Output Class Initialized
INFO - 2023-03-10 10:31:19 --> Security Class Initialized
DEBUG - 2023-03-10 10:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:31:19 --> Input Class Initialized
INFO - 2023-03-10 10:31:19 --> Language Class Initialized
INFO - 2023-03-10 10:31:19 --> Loader Class Initialized
INFO - 2023-03-10 10:31:19 --> Controller Class Initialized
DEBUG - 2023-03-10 10:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:31:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:31:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:31:19 --> Model "Login_model" initialized
INFO - 2023-03-10 10:31:19 --> Final output sent to browser
DEBUG - 2023-03-10 10:31:19 --> Total execution time: 0.0302
INFO - 2023-03-10 10:31:19 --> Config Class Initialized
INFO - 2023-03-10 10:31:19 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:31:19 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:31:19 --> Utf8 Class Initialized
INFO - 2023-03-10 10:31:19 --> URI Class Initialized
INFO - 2023-03-10 10:31:19 --> Router Class Initialized
INFO - 2023-03-10 10:31:19 --> Output Class Initialized
INFO - 2023-03-10 10:31:19 --> Security Class Initialized
DEBUG - 2023-03-10 10:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:31:19 --> Input Class Initialized
INFO - 2023-03-10 10:31:19 --> Language Class Initialized
INFO - 2023-03-10 10:31:19 --> Loader Class Initialized
INFO - 2023-03-10 10:31:19 --> Controller Class Initialized
DEBUG - 2023-03-10 10:31:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:31:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:31:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:31:19 --> Model "Login_model" initialized
INFO - 2023-03-10 10:31:19 --> Final output sent to browser
DEBUG - 2023-03-10 10:31:19 --> Total execution time: 0.0610
INFO - 2023-03-10 10:32:52 --> Config Class Initialized
INFO - 2023-03-10 10:32:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:32:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:32:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:32:52 --> URI Class Initialized
INFO - 2023-03-10 10:32:52 --> Router Class Initialized
INFO - 2023-03-10 10:32:52 --> Output Class Initialized
INFO - 2023-03-10 10:32:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:32:52 --> Input Class Initialized
INFO - 2023-03-10 10:32:52 --> Language Class Initialized
INFO - 2023-03-10 10:32:52 --> Loader Class Initialized
INFO - 2023-03-10 10:32:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:32:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:32:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:32:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:32:52 --> Model "Login_model" initialized
INFO - 2023-03-10 10:32:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:32:52 --> Total execution time: 0.0806
INFO - 2023-03-10 10:32:52 --> Config Class Initialized
INFO - 2023-03-10 10:32:52 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:32:52 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:32:52 --> Utf8 Class Initialized
INFO - 2023-03-10 10:32:52 --> URI Class Initialized
INFO - 2023-03-10 10:32:52 --> Router Class Initialized
INFO - 2023-03-10 10:32:52 --> Output Class Initialized
INFO - 2023-03-10 10:32:52 --> Security Class Initialized
DEBUG - 2023-03-10 10:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:32:52 --> Input Class Initialized
INFO - 2023-03-10 10:32:52 --> Language Class Initialized
INFO - 2023-03-10 10:32:52 --> Loader Class Initialized
INFO - 2023-03-10 10:32:52 --> Controller Class Initialized
DEBUG - 2023-03-10 10:32:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:32:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:32:52 --> Database Driver Class Initialized
INFO - 2023-03-10 10:32:52 --> Model "Login_model" initialized
INFO - 2023-03-10 10:32:52 --> Final output sent to browser
DEBUG - 2023-03-10 10:32:52 --> Total execution time: 0.0217
INFO - 2023-03-10 10:33:55 --> Config Class Initialized
INFO - 2023-03-10 10:33:55 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:33:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:33:55 --> Utf8 Class Initialized
INFO - 2023-03-10 10:33:55 --> URI Class Initialized
INFO - 2023-03-10 10:33:55 --> Router Class Initialized
INFO - 2023-03-10 10:33:55 --> Output Class Initialized
INFO - 2023-03-10 10:33:55 --> Security Class Initialized
DEBUG - 2023-03-10 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:33:55 --> Input Class Initialized
INFO - 2023-03-10 10:33:55 --> Language Class Initialized
INFO - 2023-03-10 10:33:55 --> Loader Class Initialized
INFO - 2023-03-10 10:33:55 --> Controller Class Initialized
DEBUG - 2023-03-10 10:33:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:33:55 --> Database Driver Class Initialized
INFO - 2023-03-10 10:33:55 --> Database Driver Class Initialized
INFO - 2023-03-10 10:33:55 --> Model "Login_model" initialized
INFO - 2023-03-10 10:33:55 --> Final output sent to browser
DEBUG - 2023-03-10 10:33:55 --> Total execution time: 0.0231
INFO - 2023-03-10 10:33:55 --> Config Class Initialized
INFO - 2023-03-10 10:33:55 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:33:55 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:33:55 --> Utf8 Class Initialized
INFO - 2023-03-10 10:33:55 --> URI Class Initialized
INFO - 2023-03-10 10:33:55 --> Router Class Initialized
INFO - 2023-03-10 10:33:55 --> Output Class Initialized
INFO - 2023-03-10 10:33:55 --> Security Class Initialized
DEBUG - 2023-03-10 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:33:55 --> Input Class Initialized
INFO - 2023-03-10 10:33:55 --> Language Class Initialized
INFO - 2023-03-10 10:33:55 --> Loader Class Initialized
INFO - 2023-03-10 10:33:55 --> Controller Class Initialized
DEBUG - 2023-03-10 10:33:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:33:55 --> Database Driver Class Initialized
INFO - 2023-03-10 10:33:55 --> Database Driver Class Initialized
INFO - 2023-03-10 10:33:55 --> Model "Login_model" initialized
INFO - 2023-03-10 10:33:55 --> Final output sent to browser
DEBUG - 2023-03-10 10:33:55 --> Total execution time: 0.0193
INFO - 2023-03-10 10:34:10 --> Config Class Initialized
INFO - 2023-03-10 10:34:10 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:34:10 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:34:10 --> Utf8 Class Initialized
INFO - 2023-03-10 10:34:10 --> URI Class Initialized
INFO - 2023-03-10 10:34:10 --> Router Class Initialized
INFO - 2023-03-10 10:34:10 --> Output Class Initialized
INFO - 2023-03-10 10:34:10 --> Security Class Initialized
DEBUG - 2023-03-10 10:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:34:10 --> Input Class Initialized
INFO - 2023-03-10 10:34:10 --> Language Class Initialized
INFO - 2023-03-10 10:34:10 --> Loader Class Initialized
INFO - 2023-03-10 10:34:10 --> Controller Class Initialized
DEBUG - 2023-03-10 10:34:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:34:10 --> Database Driver Class Initialized
INFO - 2023-03-10 10:34:10 --> Database Driver Class Initialized
INFO - 2023-03-10 10:34:10 --> Model "Login_model" initialized
INFO - 2023-03-10 10:34:10 --> Final output sent to browser
DEBUG - 2023-03-10 10:34:10 --> Total execution time: 0.1148
INFO - 2023-03-10 10:34:10 --> Config Class Initialized
INFO - 2023-03-10 10:34:10 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:34:10 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:34:10 --> Utf8 Class Initialized
INFO - 2023-03-10 10:34:10 --> URI Class Initialized
INFO - 2023-03-10 10:34:10 --> Router Class Initialized
INFO - 2023-03-10 10:34:10 --> Output Class Initialized
INFO - 2023-03-10 10:34:10 --> Security Class Initialized
DEBUG - 2023-03-10 10:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:34:10 --> Input Class Initialized
INFO - 2023-03-10 10:34:10 --> Language Class Initialized
INFO - 2023-03-10 10:34:10 --> Loader Class Initialized
INFO - 2023-03-10 10:34:10 --> Controller Class Initialized
DEBUG - 2023-03-10 10:34:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:34:10 --> Database Driver Class Initialized
INFO - 2023-03-10 10:34:10 --> Database Driver Class Initialized
INFO - 2023-03-10 10:34:10 --> Model "Login_model" initialized
INFO - 2023-03-10 10:34:10 --> Final output sent to browser
DEBUG - 2023-03-10 10:34:10 --> Total execution time: 0.0403
INFO - 2023-03-10 10:37:09 --> Config Class Initialized
INFO - 2023-03-10 10:37:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:09 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:09 --> URI Class Initialized
INFO - 2023-03-10 10:37:09 --> Router Class Initialized
INFO - 2023-03-10 10:37:09 --> Output Class Initialized
INFO - 2023-03-10 10:37:09 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:09 --> Input Class Initialized
INFO - 2023-03-10 10:37:09 --> Language Class Initialized
INFO - 2023-03-10 10:37:09 --> Loader Class Initialized
INFO - 2023-03-10 10:37:09 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:09 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:09 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:09 --> Total execution time: 0.0139
INFO - 2023-03-10 10:37:09 --> Config Class Initialized
INFO - 2023-03-10 10:37:09 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:09 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:09 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:09 --> URI Class Initialized
INFO - 2023-03-10 10:37:09 --> Router Class Initialized
INFO - 2023-03-10 10:37:09 --> Output Class Initialized
INFO - 2023-03-10 10:37:09 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:09 --> Input Class Initialized
INFO - 2023-03-10 10:37:09 --> Language Class Initialized
INFO - 2023-03-10 10:37:09 --> Loader Class Initialized
INFO - 2023-03-10 10:37:09 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:09 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:09 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:09 --> Model "Login_model" initialized
INFO - 2023-03-10 10:37:09 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:09 --> Total execution time: 0.0172
INFO - 2023-03-10 10:37:19 --> Config Class Initialized
INFO - 2023-03-10 10:37:19 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:19 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:19 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:19 --> URI Class Initialized
INFO - 2023-03-10 10:37:19 --> Router Class Initialized
INFO - 2023-03-10 10:37:19 --> Output Class Initialized
INFO - 2023-03-10 10:37:19 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:19 --> Input Class Initialized
INFO - 2023-03-10 10:37:19 --> Language Class Initialized
INFO - 2023-03-10 10:37:19 --> Loader Class Initialized
INFO - 2023-03-10 10:37:19 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:19 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:19 --> Total execution time: 0.0152
INFO - 2023-03-10 10:37:19 --> Config Class Initialized
INFO - 2023-03-10 10:37:19 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:19 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:19 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:19 --> URI Class Initialized
INFO - 2023-03-10 10:37:19 --> Router Class Initialized
INFO - 2023-03-10 10:37:19 --> Output Class Initialized
INFO - 2023-03-10 10:37:19 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:19 --> Input Class Initialized
INFO - 2023-03-10 10:37:19 --> Language Class Initialized
INFO - 2023-03-10 10:37:19 --> Loader Class Initialized
INFO - 2023-03-10 10:37:19 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:19 --> Model "Login_model" initialized
INFO - 2023-03-10 10:37:19 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:19 --> Total execution time: 0.0202
INFO - 2023-03-10 10:37:19 --> Config Class Initialized
INFO - 2023-03-10 10:37:19 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:19 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:19 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:19 --> URI Class Initialized
INFO - 2023-03-10 10:37:19 --> Router Class Initialized
INFO - 2023-03-10 10:37:19 --> Output Class Initialized
INFO - 2023-03-10 10:37:19 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:19 --> Input Class Initialized
INFO - 2023-03-10 10:37:19 --> Language Class Initialized
INFO - 2023-03-10 10:37:19 --> Loader Class Initialized
INFO - 2023-03-10 10:37:19 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:19 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:19 --> Total execution time: 0.0092
INFO - 2023-03-10 10:37:19 --> Config Class Initialized
INFO - 2023-03-10 10:37:19 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:19 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:19 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:19 --> URI Class Initialized
INFO - 2023-03-10 10:37:19 --> Router Class Initialized
INFO - 2023-03-10 10:37:19 --> Output Class Initialized
INFO - 2023-03-10 10:37:19 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:19 --> Input Class Initialized
INFO - 2023-03-10 10:37:19 --> Language Class Initialized
INFO - 2023-03-10 10:37:19 --> Loader Class Initialized
INFO - 2023-03-10 10:37:19 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:19 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:19 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:19 --> Total execution time: 0.0131
INFO - 2023-03-10 10:37:22 --> Config Class Initialized
INFO - 2023-03-10 10:37:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:22 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:22 --> URI Class Initialized
INFO - 2023-03-10 10:37:22 --> Router Class Initialized
INFO - 2023-03-10 10:37:22 --> Output Class Initialized
INFO - 2023-03-10 10:37:22 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:22 --> Input Class Initialized
INFO - 2023-03-10 10:37:22 --> Language Class Initialized
INFO - 2023-03-10 10:37:22 --> Loader Class Initialized
INFO - 2023-03-10 10:37:22 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:22 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:22 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:22 --> Model "Login_model" initialized
INFO - 2023-03-10 10:37:22 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:22 --> Total execution time: 0.0215
INFO - 2023-03-10 10:37:22 --> Config Class Initialized
INFO - 2023-03-10 10:37:22 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:22 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:22 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:22 --> URI Class Initialized
INFO - 2023-03-10 10:37:22 --> Router Class Initialized
INFO - 2023-03-10 10:37:22 --> Output Class Initialized
INFO - 2023-03-10 10:37:22 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:22 --> Input Class Initialized
INFO - 2023-03-10 10:37:22 --> Language Class Initialized
INFO - 2023-03-10 10:37:22 --> Loader Class Initialized
INFO - 2023-03-10 10:37:22 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:22 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:22 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:22 --> Total execution time: 0.0098
INFO - 2023-03-10 10:37:23 --> Config Class Initialized
INFO - 2023-03-10 10:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:23 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:23 --> URI Class Initialized
INFO - 2023-03-10 10:37:23 --> Router Class Initialized
INFO - 2023-03-10 10:37:23 --> Output Class Initialized
INFO - 2023-03-10 10:37:23 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:23 --> Input Class Initialized
INFO - 2023-03-10 10:37:23 --> Language Class Initialized
INFO - 2023-03-10 10:37:23 --> Loader Class Initialized
INFO - 2023-03-10 10:37:23 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:23 --> Model "Login_model" initialized
INFO - 2023-03-10 10:37:23 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:23 --> Total execution time: 0.0213
INFO - 2023-03-10 10:37:23 --> Config Class Initialized
INFO - 2023-03-10 10:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:23 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:23 --> URI Class Initialized
INFO - 2023-03-10 10:37:23 --> Router Class Initialized
INFO - 2023-03-10 10:37:23 --> Output Class Initialized
INFO - 2023-03-10 10:37:23 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:23 --> Input Class Initialized
INFO - 2023-03-10 10:37:23 --> Language Class Initialized
INFO - 2023-03-10 10:37:23 --> Loader Class Initialized
INFO - 2023-03-10 10:37:23 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:23 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:23 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:23 --> Total execution time: 0.0105
INFO - 2023-03-10 10:37:36 --> Config Class Initialized
INFO - 2023-03-10 10:37:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:36 --> URI Class Initialized
INFO - 2023-03-10 10:37:36 --> Router Class Initialized
INFO - 2023-03-10 10:37:36 --> Output Class Initialized
INFO - 2023-03-10 10:37:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:36 --> Input Class Initialized
INFO - 2023-03-10 10:37:36 --> Language Class Initialized
INFO - 2023-03-10 10:37:36 --> Loader Class Initialized
INFO - 2023-03-10 10:37:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:36 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:36 --> Total execution time: 0.0135
INFO - 2023-03-10 10:37:36 --> Config Class Initialized
INFO - 2023-03-10 10:37:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:36 --> URI Class Initialized
INFO - 2023-03-10 10:37:36 --> Router Class Initialized
INFO - 2023-03-10 10:37:36 --> Output Class Initialized
INFO - 2023-03-10 10:37:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:36 --> Input Class Initialized
INFO - 2023-03-10 10:37:36 --> Language Class Initialized
INFO - 2023-03-10 10:37:36 --> Loader Class Initialized
INFO - 2023-03-10 10:37:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:36 --> Model "Login_model" initialized
INFO - 2023-03-10 10:37:36 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:36 --> Total execution time: 0.0211
INFO - 2023-03-10 10:37:36 --> Config Class Initialized
INFO - 2023-03-10 10:37:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:36 --> URI Class Initialized
INFO - 2023-03-10 10:37:36 --> Router Class Initialized
INFO - 2023-03-10 10:37:36 --> Output Class Initialized
INFO - 2023-03-10 10:37:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:36 --> Input Class Initialized
INFO - 2023-03-10 10:37:36 --> Language Class Initialized
INFO - 2023-03-10 10:37:36 --> Loader Class Initialized
INFO - 2023-03-10 10:37:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:36 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:36 --> Total execution time: 0.0084
INFO - 2023-03-10 10:37:36 --> Config Class Initialized
INFO - 2023-03-10 10:37:36 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:37:36 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:37:36 --> Utf8 Class Initialized
INFO - 2023-03-10 10:37:36 --> URI Class Initialized
INFO - 2023-03-10 10:37:36 --> Router Class Initialized
INFO - 2023-03-10 10:37:36 --> Output Class Initialized
INFO - 2023-03-10 10:37:36 --> Security Class Initialized
DEBUG - 2023-03-10 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:37:36 --> Input Class Initialized
INFO - 2023-03-10 10:37:36 --> Language Class Initialized
INFO - 2023-03-10 10:37:36 --> Loader Class Initialized
INFO - 2023-03-10 10:37:36 --> Controller Class Initialized
DEBUG - 2023-03-10 10:37:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:37:36 --> Database Driver Class Initialized
INFO - 2023-03-10 10:37:36 --> Final output sent to browser
DEBUG - 2023-03-10 10:37:36 --> Total execution time: 0.0102
INFO - 2023-03-10 10:41:17 --> Config Class Initialized
INFO - 2023-03-10 10:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:41:17 --> Utf8 Class Initialized
INFO - 2023-03-10 10:41:17 --> URI Class Initialized
INFO - 2023-03-10 10:41:17 --> Router Class Initialized
INFO - 2023-03-10 10:41:17 --> Output Class Initialized
INFO - 2023-03-10 10:41:17 --> Security Class Initialized
DEBUG - 2023-03-10 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:41:17 --> Input Class Initialized
INFO - 2023-03-10 10:41:17 --> Language Class Initialized
INFO - 2023-03-10 10:41:17 --> Loader Class Initialized
INFO - 2023-03-10 10:41:17 --> Controller Class Initialized
DEBUG - 2023-03-10 10:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:41:17 --> Database Driver Class Initialized
INFO - 2023-03-10 10:41:17 --> Database Driver Class Initialized
INFO - 2023-03-10 10:41:17 --> Model "Login_model" initialized
INFO - 2023-03-10 10:41:17 --> Final output sent to browser
DEBUG - 2023-03-10 10:41:17 --> Total execution time: 0.0743
INFO - 2023-03-10 10:41:17 --> Config Class Initialized
INFO - 2023-03-10 10:41:17 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:41:17 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:41:17 --> Utf8 Class Initialized
INFO - 2023-03-10 10:41:17 --> URI Class Initialized
INFO - 2023-03-10 10:41:17 --> Router Class Initialized
INFO - 2023-03-10 10:41:17 --> Output Class Initialized
INFO - 2023-03-10 10:41:17 --> Security Class Initialized
DEBUG - 2023-03-10 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:41:17 --> Input Class Initialized
INFO - 2023-03-10 10:41:17 --> Language Class Initialized
INFO - 2023-03-10 10:41:17 --> Loader Class Initialized
INFO - 2023-03-10 10:41:17 --> Controller Class Initialized
DEBUG - 2023-03-10 10:41:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:41:17 --> Database Driver Class Initialized
INFO - 2023-03-10 10:41:17 --> Database Driver Class Initialized
INFO - 2023-03-10 10:41:17 --> Model "Login_model" initialized
INFO - 2023-03-10 10:41:17 --> Final output sent to browser
DEBUG - 2023-03-10 10:41:17 --> Total execution time: 0.0240
INFO - 2023-03-10 10:44:12 --> Config Class Initialized
INFO - 2023-03-10 10:44:12 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:44:12 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:44:12 --> Utf8 Class Initialized
INFO - 2023-03-10 10:44:12 --> URI Class Initialized
INFO - 2023-03-10 10:44:12 --> Router Class Initialized
INFO - 2023-03-10 10:44:12 --> Output Class Initialized
INFO - 2023-03-10 10:44:12 --> Security Class Initialized
DEBUG - 2023-03-10 10:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:44:12 --> Input Class Initialized
INFO - 2023-03-10 10:44:12 --> Language Class Initialized
INFO - 2023-03-10 10:44:12 --> Loader Class Initialized
INFO - 2023-03-10 10:44:12 --> Controller Class Initialized
DEBUG - 2023-03-10 10:44:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:44:12 --> Database Driver Class Initialized
INFO - 2023-03-10 10:44:12 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:44:12 --> Final output sent to browser
DEBUG - 2023-03-10 10:44:12 --> Total execution time: 0.0241
INFO - 2023-03-10 10:44:12 --> Config Class Initialized
INFO - 2023-03-10 10:44:12 --> Hooks Class Initialized
DEBUG - 2023-03-10 10:44:12 --> UTF-8 Support Enabled
INFO - 2023-03-10 10:44:12 --> Utf8 Class Initialized
INFO - 2023-03-10 10:44:12 --> URI Class Initialized
INFO - 2023-03-10 10:44:12 --> Router Class Initialized
INFO - 2023-03-10 10:44:12 --> Output Class Initialized
INFO - 2023-03-10 10:44:12 --> Security Class Initialized
DEBUG - 2023-03-10 10:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 10:44:12 --> Input Class Initialized
INFO - 2023-03-10 10:44:12 --> Language Class Initialized
INFO - 2023-03-10 10:44:12 --> Loader Class Initialized
INFO - 2023-03-10 10:44:12 --> Controller Class Initialized
DEBUG - 2023-03-10 10:44:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-10 10:44:12 --> Database Driver Class Initialized
INFO - 2023-03-10 10:44:12 --> Model "Cluster_model" initialized
INFO - 2023-03-10 10:44:12 --> Final output sent to browser
DEBUG - 2023-03-10 10:44:12 --> Total execution time: 0.0123
INFO - 2023-03-10 12:32:17 --> Config Class Initialized
INFO - 2023-03-10 12:32:17 --> Hooks Class Initialized
DEBUG - 2023-03-10 12:32:18 --> UTF-8 Support Enabled
INFO - 2023-03-10 12:32:18 --> Utf8 Class Initialized
INFO - 2023-03-10 12:32:20 --> URI Class Initialized
INFO - 2023-03-10 12:32:20 --> Router Class Initialized
INFO - 2023-03-10 12:32:20 --> Output Class Initialized
INFO - 2023-03-10 12:32:20 --> Security Class Initialized
DEBUG - 2023-03-10 12:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-10 12:32:20 --> Input Class Initialized
INFO - 2023-03-10 12:32:20 --> Language Class Initialized
ERROR - 2023-03-10 12:32:20 --> 404 Page Not Found: Faviconico/index
