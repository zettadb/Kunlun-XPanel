<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-07 01:56:23 --> Config Class Initialized
INFO - 2023-03-07 01:56:23 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:23 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:23 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:23 --> URI Class Initialized
INFO - 2023-03-07 01:56:23 --> Router Class Initialized
INFO - 2023-03-07 01:56:23 --> Output Class Initialized
INFO - 2023-03-07 01:56:23 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:23 --> Input Class Initialized
INFO - 2023-03-07 01:56:23 --> Language Class Initialized
INFO - 2023-03-07 01:56:23 --> Loader Class Initialized
INFO - 2023-03-07 01:56:23 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:23 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:23 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:23 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:23 --> Model "Login_model" initialized
INFO - 2023-03-07 01:56:23 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:23 --> Total execution time: 0.1707
INFO - 2023-03-07 01:56:23 --> Config Class Initialized
INFO - 2023-03-07 01:56:23 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:23 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:23 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:23 --> URI Class Initialized
INFO - 2023-03-07 01:56:23 --> Router Class Initialized
INFO - 2023-03-07 01:56:23 --> Output Class Initialized
INFO - 2023-03-07 01:56:23 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:23 --> Input Class Initialized
INFO - 2023-03-07 01:56:23 --> Language Class Initialized
INFO - 2023-03-07 01:56:23 --> Loader Class Initialized
INFO - 2023-03-07 01:56:23 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:23 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:23 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:23 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:23 --> Model "Login_model" initialized
INFO - 2023-03-07 01:56:23 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:23 --> Total execution time: 0.0373
INFO - 2023-03-07 01:56:30 --> Config Class Initialized
INFO - 2023-03-07 01:56:30 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:30 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:30 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:30 --> URI Class Initialized
INFO - 2023-03-07 01:56:30 --> Router Class Initialized
INFO - 2023-03-07 01:56:30 --> Output Class Initialized
INFO - 2023-03-07 01:56:30 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:30 --> Input Class Initialized
INFO - 2023-03-07 01:56:30 --> Language Class Initialized
INFO - 2023-03-07 01:56:30 --> Loader Class Initialized
INFO - 2023-03-07 01:56:30 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:30 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:30 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:30 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:30 --> Total execution time: 0.0740
INFO - 2023-03-07 01:56:30 --> Config Class Initialized
INFO - 2023-03-07 01:56:30 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:30 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:30 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:30 --> URI Class Initialized
INFO - 2023-03-07 01:56:30 --> Router Class Initialized
INFO - 2023-03-07 01:56:30 --> Output Class Initialized
INFO - 2023-03-07 01:56:30 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:30 --> Input Class Initialized
INFO - 2023-03-07 01:56:30 --> Language Class Initialized
INFO - 2023-03-07 01:56:30 --> Loader Class Initialized
INFO - 2023-03-07 01:56:30 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:30 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:30 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:30 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:30 --> Total execution time: 0.0693
INFO - 2023-03-07 01:56:37 --> Config Class Initialized
INFO - 2023-03-07 01:56:37 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:37 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:37 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:37 --> URI Class Initialized
INFO - 2023-03-07 01:56:37 --> Router Class Initialized
INFO - 2023-03-07 01:56:37 --> Output Class Initialized
INFO - 2023-03-07 01:56:37 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:37 --> Input Class Initialized
INFO - 2023-03-07 01:56:37 --> Language Class Initialized
INFO - 2023-03-07 01:56:37 --> Loader Class Initialized
INFO - 2023-03-07 01:56:37 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:37 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:37 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:37 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:37 --> Total execution time: 0.0198
INFO - 2023-03-07 01:56:37 --> Config Class Initialized
INFO - 2023-03-07 01:56:37 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:37 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:37 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:37 --> URI Class Initialized
INFO - 2023-03-07 01:56:37 --> Router Class Initialized
INFO - 2023-03-07 01:56:37 --> Output Class Initialized
INFO - 2023-03-07 01:56:37 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:37 --> Input Class Initialized
INFO - 2023-03-07 01:56:37 --> Language Class Initialized
INFO - 2023-03-07 01:56:37 --> Loader Class Initialized
INFO - 2023-03-07 01:56:37 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:37 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:37 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:37 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:37 --> Total execution time: 0.0111
INFO - 2023-03-07 01:56:40 --> Config Class Initialized
INFO - 2023-03-07 01:56:40 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:40 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:40 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:40 --> URI Class Initialized
INFO - 2023-03-07 01:56:40 --> Router Class Initialized
INFO - 2023-03-07 01:56:40 --> Output Class Initialized
INFO - 2023-03-07 01:56:40 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:40 --> Input Class Initialized
INFO - 2023-03-07 01:56:40 --> Language Class Initialized
INFO - 2023-03-07 01:56:40 --> Loader Class Initialized
INFO - 2023-03-07 01:56:40 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:40 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:40 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:40 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:40 --> Total execution time: 0.0853
INFO - 2023-03-07 01:56:40 --> Config Class Initialized
INFO - 2023-03-07 01:56:40 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:40 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:40 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:40 --> URI Class Initialized
INFO - 2023-03-07 01:56:40 --> Router Class Initialized
INFO - 2023-03-07 01:56:40 --> Output Class Initialized
INFO - 2023-03-07 01:56:40 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:40 --> Input Class Initialized
INFO - 2023-03-07 01:56:40 --> Language Class Initialized
INFO - 2023-03-07 01:56:40 --> Loader Class Initialized
INFO - 2023-03-07 01:56:40 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:40 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:40 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:40 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:40 --> Total execution time: 0.0425
INFO - 2023-03-07 01:56:41 --> Config Class Initialized
INFO - 2023-03-07 01:56:41 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:41 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:41 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:41 --> URI Class Initialized
INFO - 2023-03-07 01:56:41 --> Router Class Initialized
INFO - 2023-03-07 01:56:41 --> Output Class Initialized
INFO - 2023-03-07 01:56:41 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:41 --> Input Class Initialized
INFO - 2023-03-07 01:56:41 --> Language Class Initialized
INFO - 2023-03-07 01:56:41 --> Loader Class Initialized
INFO - 2023-03-07 01:56:41 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:41 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:41 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:41 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:41 --> Model "Login_model" initialized
INFO - 2023-03-07 01:56:41 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:41 --> Total execution time: 0.0394
INFO - 2023-03-07 01:56:41 --> Config Class Initialized
INFO - 2023-03-07 01:56:41 --> Hooks Class Initialized
DEBUG - 2023-03-07 01:56:41 --> UTF-8 Support Enabled
INFO - 2023-03-07 01:56:41 --> Utf8 Class Initialized
INFO - 2023-03-07 01:56:41 --> URI Class Initialized
INFO - 2023-03-07 01:56:41 --> Router Class Initialized
INFO - 2023-03-07 01:56:41 --> Output Class Initialized
INFO - 2023-03-07 01:56:41 --> Security Class Initialized
DEBUG - 2023-03-07 01:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 01:56:41 --> Input Class Initialized
INFO - 2023-03-07 01:56:41 --> Language Class Initialized
INFO - 2023-03-07 01:56:41 --> Loader Class Initialized
INFO - 2023-03-07 01:56:41 --> Controller Class Initialized
DEBUG - 2023-03-07 01:56:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 01:56:41 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:41 --> Model "Cluster_model" initialized
INFO - 2023-03-07 01:56:41 --> Database Driver Class Initialized
INFO - 2023-03-07 01:56:41 --> Model "Login_model" initialized
INFO - 2023-03-07 01:56:41 --> Final output sent to browser
DEBUG - 2023-03-07 01:56:41 --> Total execution time: 0.0369
INFO - 2023-03-07 02:12:24 --> Config Class Initialized
INFO - 2023-03-07 02:12:24 --> Hooks Class Initialized
DEBUG - 2023-03-07 02:12:24 --> UTF-8 Support Enabled
INFO - 2023-03-07 02:12:24 --> Utf8 Class Initialized
INFO - 2023-03-07 02:12:24 --> URI Class Initialized
INFO - 2023-03-07 02:12:24 --> Router Class Initialized
INFO - 2023-03-07 02:12:24 --> Output Class Initialized
INFO - 2023-03-07 02:12:24 --> Security Class Initialized
DEBUG - 2023-03-07 02:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 02:12:24 --> Input Class Initialized
INFO - 2023-03-07 02:12:24 --> Language Class Initialized
INFO - 2023-03-07 02:12:24 --> Loader Class Initialized
INFO - 2023-03-07 02:12:24 --> Controller Class Initialized
DEBUG - 2023-03-07 02:12:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 02:12:24 --> Database Driver Class Initialized
INFO - 2023-03-07 02:12:24 --> Model "Cluster_model" initialized
INFO - 2023-03-07 02:12:24 --> Final output sent to browser
DEBUG - 2023-03-07 02:12:24 --> Total execution time: 0.0174
INFO - 2023-03-07 02:12:24 --> Config Class Initialized
INFO - 2023-03-07 02:12:24 --> Hooks Class Initialized
DEBUG - 2023-03-07 02:12:24 --> UTF-8 Support Enabled
INFO - 2023-03-07 02:12:24 --> Utf8 Class Initialized
INFO - 2023-03-07 02:12:24 --> URI Class Initialized
INFO - 2023-03-07 02:12:24 --> Router Class Initialized
INFO - 2023-03-07 02:12:24 --> Output Class Initialized
INFO - 2023-03-07 02:12:24 --> Security Class Initialized
DEBUG - 2023-03-07 02:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 02:12:24 --> Input Class Initialized
INFO - 2023-03-07 02:12:24 --> Language Class Initialized
INFO - 2023-03-07 02:12:24 --> Loader Class Initialized
INFO - 2023-03-07 02:12:24 --> Controller Class Initialized
DEBUG - 2023-03-07 02:12:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 02:12:24 --> Database Driver Class Initialized
INFO - 2023-03-07 02:12:24 --> Model "Cluster_model" initialized
INFO - 2023-03-07 02:12:24 --> Final output sent to browser
DEBUG - 2023-03-07 02:12:24 --> Total execution time: 0.0949
INFO - 2023-03-07 03:03:16 --> Config Class Initialized
INFO - 2023-03-07 03:03:16 --> Hooks Class Initialized
DEBUG - 2023-03-07 03:03:16 --> UTF-8 Support Enabled
INFO - 2023-03-07 03:03:16 --> Utf8 Class Initialized
INFO - 2023-03-07 03:03:16 --> URI Class Initialized
INFO - 2023-03-07 03:03:16 --> Router Class Initialized
INFO - 2023-03-07 03:03:16 --> Output Class Initialized
INFO - 2023-03-07 03:03:16 --> Security Class Initialized
DEBUG - 2023-03-07 03:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 03:03:16 --> Input Class Initialized
INFO - 2023-03-07 03:03:16 --> Language Class Initialized
INFO - 2023-03-07 03:03:16 --> Loader Class Initialized
INFO - 2023-03-07 03:03:16 --> Controller Class Initialized
DEBUG - 2023-03-07 03:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 03:03:16 --> Database Driver Class Initialized
INFO - 2023-03-07 03:03:16 --> Model "Cluster_model" initialized
INFO - 2023-03-07 03:03:16 --> Final output sent to browser
DEBUG - 2023-03-07 03:03:16 --> Total execution time: 0.0377
INFO - 2023-03-07 03:03:16 --> Config Class Initialized
INFO - 2023-03-07 03:03:16 --> Hooks Class Initialized
DEBUG - 2023-03-07 03:03:16 --> UTF-8 Support Enabled
INFO - 2023-03-07 03:03:16 --> Utf8 Class Initialized
INFO - 2023-03-07 03:03:16 --> URI Class Initialized
INFO - 2023-03-07 03:03:16 --> Router Class Initialized
INFO - 2023-03-07 03:03:16 --> Output Class Initialized
INFO - 2023-03-07 03:03:16 --> Security Class Initialized
DEBUG - 2023-03-07 03:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 03:03:16 --> Input Class Initialized
INFO - 2023-03-07 03:03:16 --> Language Class Initialized
INFO - 2023-03-07 03:03:16 --> Loader Class Initialized
INFO - 2023-03-07 03:03:16 --> Controller Class Initialized
DEBUG - 2023-03-07 03:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 03:03:16 --> Database Driver Class Initialized
INFO - 2023-03-07 03:03:16 --> Model "Cluster_model" initialized
INFO - 2023-03-07 03:03:16 --> Final output sent to browser
DEBUG - 2023-03-07 03:03:16 --> Total execution time: 0.0728
INFO - 2023-03-07 03:03:19 --> Config Class Initialized
INFO - 2023-03-07 03:03:19 --> Hooks Class Initialized
DEBUG - 2023-03-07 03:03:19 --> UTF-8 Support Enabled
INFO - 2023-03-07 03:03:19 --> Utf8 Class Initialized
INFO - 2023-03-07 03:03:19 --> URI Class Initialized
INFO - 2023-03-07 03:03:19 --> Router Class Initialized
INFO - 2023-03-07 03:03:19 --> Output Class Initialized
INFO - 2023-03-07 03:03:19 --> Security Class Initialized
DEBUG - 2023-03-07 03:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 03:03:19 --> Input Class Initialized
INFO - 2023-03-07 03:03:19 --> Language Class Initialized
INFO - 2023-03-07 03:03:19 --> Loader Class Initialized
INFO - 2023-03-07 03:03:19 --> Controller Class Initialized
DEBUG - 2023-03-07 03:03:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 03:03:19 --> Database Driver Class Initialized
INFO - 2023-03-07 03:03:19 --> Model "Cluster_model" initialized
INFO - 2023-03-07 03:03:19 --> Database Driver Class Initialized
INFO - 2023-03-07 03:03:19 --> Model "Login_model" initialized
INFO - 2023-03-07 03:03:19 --> Final output sent to browser
DEBUG - 2023-03-07 03:03:19 --> Total execution time: 0.0456
INFO - 2023-03-07 03:03:19 --> Config Class Initialized
INFO - 2023-03-07 03:03:19 --> Hooks Class Initialized
DEBUG - 2023-03-07 03:03:19 --> UTF-8 Support Enabled
INFO - 2023-03-07 03:03:19 --> Utf8 Class Initialized
INFO - 2023-03-07 03:03:19 --> URI Class Initialized
INFO - 2023-03-07 03:03:19 --> Router Class Initialized
INFO - 2023-03-07 03:03:19 --> Output Class Initialized
INFO - 2023-03-07 03:03:19 --> Security Class Initialized
DEBUG - 2023-03-07 03:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 03:03:19 --> Input Class Initialized
INFO - 2023-03-07 03:03:19 --> Language Class Initialized
INFO - 2023-03-07 03:03:19 --> Loader Class Initialized
INFO - 2023-03-07 03:03:19 --> Controller Class Initialized
DEBUG - 2023-03-07 03:03:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 03:03:19 --> Database Driver Class Initialized
INFO - 2023-03-07 03:03:19 --> Model "Cluster_model" initialized
INFO - 2023-03-07 03:03:19 --> Database Driver Class Initialized
INFO - 2023-03-07 03:03:19 --> Model "Login_model" initialized
INFO - 2023-03-07 03:03:19 --> Final output sent to browser
DEBUG - 2023-03-07 03:03:19 --> Total execution time: 0.0375
INFO - 2023-03-07 03:33:58 --> Config Class Initialized
INFO - 2023-03-07 03:33:58 --> Hooks Class Initialized
DEBUG - 2023-03-07 03:33:58 --> UTF-8 Support Enabled
INFO - 2023-03-07 03:33:58 --> Utf8 Class Initialized
INFO - 2023-03-07 03:33:58 --> URI Class Initialized
INFO - 2023-03-07 03:33:58 --> Router Class Initialized
INFO - 2023-03-07 03:33:58 --> Output Class Initialized
INFO - 2023-03-07 03:33:58 --> Security Class Initialized
DEBUG - 2023-03-07 03:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 03:33:58 --> Input Class Initialized
INFO - 2023-03-07 03:33:58 --> Language Class Initialized
INFO - 2023-03-07 03:33:58 --> Loader Class Initialized
INFO - 2023-03-07 03:33:58 --> Controller Class Initialized
DEBUG - 2023-03-07 03:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 03:33:58 --> Database Driver Class Initialized
INFO - 2023-03-07 03:33:58 --> Model "Cluster_model" initialized
INFO - 2023-03-07 03:33:58 --> Final output sent to browser
DEBUG - 2023-03-07 03:33:58 --> Total execution time: 0.0394
INFO - 2023-03-07 03:33:58 --> Config Class Initialized
INFO - 2023-03-07 03:33:58 --> Hooks Class Initialized
DEBUG - 2023-03-07 03:33:58 --> UTF-8 Support Enabled
INFO - 2023-03-07 03:33:58 --> Utf8 Class Initialized
INFO - 2023-03-07 03:33:58 --> URI Class Initialized
INFO - 2023-03-07 03:33:58 --> Router Class Initialized
INFO - 2023-03-07 03:33:58 --> Output Class Initialized
INFO - 2023-03-07 03:33:58 --> Security Class Initialized
DEBUG - 2023-03-07 03:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 03:33:58 --> Input Class Initialized
INFO - 2023-03-07 03:33:58 --> Language Class Initialized
INFO - 2023-03-07 03:33:58 --> Loader Class Initialized
INFO - 2023-03-07 03:33:58 --> Controller Class Initialized
DEBUG - 2023-03-07 03:33:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 03:33:58 --> Database Driver Class Initialized
INFO - 2023-03-07 03:33:58 --> Model "Cluster_model" initialized
INFO - 2023-03-07 03:33:58 --> Final output sent to browser
DEBUG - 2023-03-07 03:33:58 --> Total execution time: 0.0707
INFO - 2023-03-07 03:35:17 --> Config Class Initialized
INFO - 2023-03-07 03:35:17 --> Hooks Class Initialized
DEBUG - 2023-03-07 03:35:17 --> UTF-8 Support Enabled
INFO - 2023-03-07 03:35:17 --> Utf8 Class Initialized
INFO - 2023-03-07 03:35:17 --> URI Class Initialized
INFO - 2023-03-07 03:35:17 --> Router Class Initialized
INFO - 2023-03-07 03:35:17 --> Output Class Initialized
INFO - 2023-03-07 03:35:17 --> Security Class Initialized
DEBUG - 2023-03-07 03:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 03:35:17 --> Input Class Initialized
INFO - 2023-03-07 03:35:17 --> Language Class Initialized
INFO - 2023-03-07 03:35:17 --> Loader Class Initialized
INFO - 2023-03-07 03:35:17 --> Controller Class Initialized
DEBUG - 2023-03-07 03:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 03:35:17 --> Database Driver Class Initialized
INFO - 2023-03-07 03:35:17 --> Model "Cluster_model" initialized
INFO - 2023-03-07 03:35:17 --> Final output sent to browser
DEBUG - 2023-03-07 03:35:17 --> Total execution time: 0.0165
INFO - 2023-03-07 03:35:17 --> Config Class Initialized
INFO - 2023-03-07 03:35:17 --> Hooks Class Initialized
DEBUG - 2023-03-07 03:35:17 --> UTF-8 Support Enabled
INFO - 2023-03-07 03:35:17 --> Utf8 Class Initialized
INFO - 2023-03-07 03:35:17 --> URI Class Initialized
INFO - 2023-03-07 03:35:17 --> Router Class Initialized
INFO - 2023-03-07 03:35:17 --> Output Class Initialized
INFO - 2023-03-07 03:35:17 --> Security Class Initialized
DEBUG - 2023-03-07 03:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 03:35:17 --> Input Class Initialized
INFO - 2023-03-07 03:35:17 --> Language Class Initialized
INFO - 2023-03-07 03:35:17 --> Loader Class Initialized
INFO - 2023-03-07 03:35:17 --> Controller Class Initialized
DEBUG - 2023-03-07 03:35:17 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 03:35:17 --> Database Driver Class Initialized
INFO - 2023-03-07 03:35:17 --> Model "Cluster_model" initialized
INFO - 2023-03-07 03:35:17 --> Final output sent to browser
DEBUG - 2023-03-07 03:35:17 --> Total execution time: 0.0544
INFO - 2023-03-07 05:43:58 --> Config Class Initialized
INFO - 2023-03-07 05:43:58 --> Hooks Class Initialized
DEBUG - 2023-03-07 05:43:58 --> UTF-8 Support Enabled
INFO - 2023-03-07 05:43:58 --> Utf8 Class Initialized
INFO - 2023-03-07 05:43:58 --> URI Class Initialized
INFO - 2023-03-07 05:43:58 --> Router Class Initialized
INFO - 2023-03-07 05:43:58 --> Output Class Initialized
INFO - 2023-03-07 05:43:58 --> Security Class Initialized
DEBUG - 2023-03-07 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 05:43:58 --> Input Class Initialized
INFO - 2023-03-07 05:43:58 --> Language Class Initialized
INFO - 2023-03-07 05:43:58 --> Loader Class Initialized
INFO - 2023-03-07 05:43:58 --> Controller Class Initialized
DEBUG - 2023-03-07 05:43:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 05:43:58 --> Database Driver Class Initialized
INFO - 2023-03-07 05:43:58 --> Model "Cluster_model" initialized
INFO - 2023-03-07 05:43:58 --> Final output sent to browser
DEBUG - 2023-03-07 05:43:58 --> Total execution time: 0.0320
INFO - 2023-03-07 05:43:58 --> Config Class Initialized
INFO - 2023-03-07 05:43:58 --> Hooks Class Initialized
DEBUG - 2023-03-07 05:43:58 --> UTF-8 Support Enabled
INFO - 2023-03-07 05:43:58 --> Utf8 Class Initialized
INFO - 2023-03-07 05:43:58 --> URI Class Initialized
INFO - 2023-03-07 05:43:58 --> Router Class Initialized
INFO - 2023-03-07 05:43:58 --> Output Class Initialized
INFO - 2023-03-07 05:43:58 --> Security Class Initialized
DEBUG - 2023-03-07 05:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 05:43:58 --> Input Class Initialized
INFO - 2023-03-07 05:43:58 --> Language Class Initialized
INFO - 2023-03-07 05:43:58 --> Loader Class Initialized
INFO - 2023-03-07 05:43:58 --> Controller Class Initialized
DEBUG - 2023-03-07 05:43:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 05:43:58 --> Database Driver Class Initialized
INFO - 2023-03-07 05:43:58 --> Model "Cluster_model" initialized
INFO - 2023-03-07 05:43:58 --> Final output sent to browser
DEBUG - 2023-03-07 05:43:58 --> Total execution time: 0.0702
INFO - 2023-03-07 07:21:32 --> Config Class Initialized
INFO - 2023-03-07 07:21:32 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:21:32 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:21:32 --> Utf8 Class Initialized
INFO - 2023-03-07 07:21:32 --> URI Class Initialized
INFO - 2023-03-07 07:21:32 --> Router Class Initialized
INFO - 2023-03-07 07:21:32 --> Output Class Initialized
INFO - 2023-03-07 07:21:32 --> Security Class Initialized
DEBUG - 2023-03-07 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:21:32 --> Input Class Initialized
INFO - 2023-03-07 07:21:32 --> Language Class Initialized
INFO - 2023-03-07 07:21:32 --> Loader Class Initialized
INFO - 2023-03-07 07:21:32 --> Controller Class Initialized
DEBUG - 2023-03-07 07:21:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:21:32 --> Database Driver Class Initialized
INFO - 2023-03-07 07:21:32 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:21:32 --> Final output sent to browser
DEBUG - 2023-03-07 07:21:32 --> Total execution time: 0.0216
INFO - 2023-03-07 07:21:32 --> Config Class Initialized
INFO - 2023-03-07 07:21:32 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:21:32 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:21:32 --> Utf8 Class Initialized
INFO - 2023-03-07 07:21:32 --> URI Class Initialized
INFO - 2023-03-07 07:21:32 --> Router Class Initialized
INFO - 2023-03-07 07:21:32 --> Output Class Initialized
INFO - 2023-03-07 07:21:32 --> Security Class Initialized
DEBUG - 2023-03-07 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:21:32 --> Input Class Initialized
INFO - 2023-03-07 07:21:32 --> Language Class Initialized
INFO - 2023-03-07 07:21:32 --> Loader Class Initialized
INFO - 2023-03-07 07:21:32 --> Controller Class Initialized
DEBUG - 2023-03-07 07:21:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:21:32 --> Database Driver Class Initialized
INFO - 2023-03-07 07:21:32 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:21:32 --> Final output sent to browser
DEBUG - 2023-03-07 07:21:32 --> Total execution time: 0.0662
INFO - 2023-03-07 07:21:34 --> Config Class Initialized
INFO - 2023-03-07 07:21:34 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:21:34 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:21:34 --> Utf8 Class Initialized
INFO - 2023-03-07 07:21:34 --> URI Class Initialized
INFO - 2023-03-07 07:21:34 --> Router Class Initialized
INFO - 2023-03-07 07:21:34 --> Output Class Initialized
INFO - 2023-03-07 07:21:34 --> Security Class Initialized
DEBUG - 2023-03-07 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:21:34 --> Input Class Initialized
INFO - 2023-03-07 07:21:34 --> Language Class Initialized
INFO - 2023-03-07 07:21:34 --> Loader Class Initialized
INFO - 2023-03-07 07:21:34 --> Controller Class Initialized
DEBUG - 2023-03-07 07:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:21:34 --> Database Driver Class Initialized
INFO - 2023-03-07 07:21:34 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:21:34 --> Database Driver Class Initialized
INFO - 2023-03-07 07:21:34 --> Model "Login_model" initialized
INFO - 2023-03-07 07:21:34 --> Final output sent to browser
DEBUG - 2023-03-07 07:21:34 --> Total execution time: 0.1446
INFO - 2023-03-07 07:21:34 --> Config Class Initialized
INFO - 2023-03-07 07:21:34 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:21:34 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:21:34 --> Utf8 Class Initialized
INFO - 2023-03-07 07:21:34 --> URI Class Initialized
INFO - 2023-03-07 07:21:34 --> Router Class Initialized
INFO - 2023-03-07 07:21:34 --> Output Class Initialized
INFO - 2023-03-07 07:21:34 --> Security Class Initialized
DEBUG - 2023-03-07 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:21:34 --> Input Class Initialized
INFO - 2023-03-07 07:21:34 --> Language Class Initialized
INFO - 2023-03-07 07:21:34 --> Loader Class Initialized
INFO - 2023-03-07 07:21:34 --> Controller Class Initialized
DEBUG - 2023-03-07 07:21:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:21:34 --> Database Driver Class Initialized
INFO - 2023-03-07 07:21:34 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:21:34 --> Database Driver Class Initialized
INFO - 2023-03-07 07:21:34 --> Model "Login_model" initialized
INFO - 2023-03-07 07:21:35 --> Final output sent to browser
DEBUG - 2023-03-07 07:21:35 --> Total execution time: 0.0799
INFO - 2023-03-07 07:25:10 --> Config Class Initialized
INFO - 2023-03-07 07:25:10 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:25:10 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:25:10 --> Utf8 Class Initialized
INFO - 2023-03-07 07:25:10 --> URI Class Initialized
INFO - 2023-03-07 07:25:10 --> Router Class Initialized
INFO - 2023-03-07 07:25:10 --> Output Class Initialized
INFO - 2023-03-07 07:25:10 --> Security Class Initialized
DEBUG - 2023-03-07 07:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:25:10 --> Input Class Initialized
INFO - 2023-03-07 07:25:10 --> Language Class Initialized
INFO - 2023-03-07 07:25:10 --> Loader Class Initialized
INFO - 2023-03-07 07:25:10 --> Controller Class Initialized
DEBUG - 2023-03-07 07:25:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:25:10 --> Database Driver Class Initialized
INFO - 2023-03-07 07:25:10 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:25:10 --> Final output sent to browser
DEBUG - 2023-03-07 07:25:10 --> Total execution time: 0.0421
INFO - 2023-03-07 07:25:10 --> Config Class Initialized
INFO - 2023-03-07 07:25:10 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:25:10 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:25:10 --> Utf8 Class Initialized
INFO - 2023-03-07 07:25:10 --> URI Class Initialized
INFO - 2023-03-07 07:25:10 --> Router Class Initialized
INFO - 2023-03-07 07:25:10 --> Output Class Initialized
INFO - 2023-03-07 07:25:10 --> Security Class Initialized
DEBUG - 2023-03-07 07:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:25:10 --> Input Class Initialized
INFO - 2023-03-07 07:25:10 --> Language Class Initialized
INFO - 2023-03-07 07:25:10 --> Loader Class Initialized
INFO - 2023-03-07 07:25:10 --> Controller Class Initialized
DEBUG - 2023-03-07 07:25:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:25:10 --> Database Driver Class Initialized
INFO - 2023-03-07 07:25:10 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:25:10 --> Final output sent to browser
DEBUG - 2023-03-07 07:25:10 --> Total execution time: 0.1077
INFO - 2023-03-07 07:25:13 --> Config Class Initialized
INFO - 2023-03-07 07:25:13 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:25:13 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:25:13 --> Utf8 Class Initialized
INFO - 2023-03-07 07:25:13 --> URI Class Initialized
INFO - 2023-03-07 07:25:13 --> Router Class Initialized
INFO - 2023-03-07 07:25:13 --> Output Class Initialized
INFO - 2023-03-07 07:25:13 --> Security Class Initialized
DEBUG - 2023-03-07 07:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:25:13 --> Input Class Initialized
INFO - 2023-03-07 07:25:13 --> Language Class Initialized
INFO - 2023-03-07 07:25:13 --> Loader Class Initialized
INFO - 2023-03-07 07:25:13 --> Controller Class Initialized
DEBUG - 2023-03-07 07:25:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:25:13 --> Database Driver Class Initialized
INFO - 2023-03-07 07:25:13 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:25:13 --> Final output sent to browser
DEBUG - 2023-03-07 07:25:13 --> Total execution time: 0.0154
INFO - 2023-03-07 07:25:13 --> Config Class Initialized
INFO - 2023-03-07 07:25:13 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:25:13 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:25:13 --> Utf8 Class Initialized
INFO - 2023-03-07 07:25:13 --> URI Class Initialized
INFO - 2023-03-07 07:25:13 --> Router Class Initialized
INFO - 2023-03-07 07:25:13 --> Output Class Initialized
INFO - 2023-03-07 07:25:13 --> Security Class Initialized
DEBUG - 2023-03-07 07:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:25:13 --> Input Class Initialized
INFO - 2023-03-07 07:25:13 --> Language Class Initialized
INFO - 2023-03-07 07:25:13 --> Loader Class Initialized
INFO - 2023-03-07 07:25:13 --> Controller Class Initialized
DEBUG - 2023-03-07 07:25:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:25:13 --> Database Driver Class Initialized
INFO - 2023-03-07 07:25:13 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:25:13 --> Final output sent to browser
DEBUG - 2023-03-07 07:25:13 --> Total execution time: 0.0551
INFO - 2023-03-07 07:25:15 --> Config Class Initialized
INFO - 2023-03-07 07:25:15 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:25:15 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:25:15 --> Utf8 Class Initialized
INFO - 2023-03-07 07:25:15 --> URI Class Initialized
INFO - 2023-03-07 07:25:15 --> Router Class Initialized
INFO - 2023-03-07 07:25:15 --> Output Class Initialized
INFO - 2023-03-07 07:25:15 --> Security Class Initialized
DEBUG - 2023-03-07 07:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:25:15 --> Input Class Initialized
INFO - 2023-03-07 07:25:15 --> Language Class Initialized
INFO - 2023-03-07 07:25:15 --> Loader Class Initialized
INFO - 2023-03-07 07:25:15 --> Controller Class Initialized
DEBUG - 2023-03-07 07:25:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:25:15 --> Database Driver Class Initialized
INFO - 2023-03-07 07:25:15 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:25:15 --> Database Driver Class Initialized
INFO - 2023-03-07 07:25:15 --> Model "Login_model" initialized
INFO - 2023-03-07 07:25:15 --> Final output sent to browser
DEBUG - 2023-03-07 07:25:15 --> Total execution time: 0.0421
INFO - 2023-03-07 07:25:15 --> Config Class Initialized
INFO - 2023-03-07 07:25:15 --> Hooks Class Initialized
DEBUG - 2023-03-07 07:25:15 --> UTF-8 Support Enabled
INFO - 2023-03-07 07:25:15 --> Utf8 Class Initialized
INFO - 2023-03-07 07:25:15 --> URI Class Initialized
INFO - 2023-03-07 07:25:15 --> Router Class Initialized
INFO - 2023-03-07 07:25:15 --> Output Class Initialized
INFO - 2023-03-07 07:25:15 --> Security Class Initialized
DEBUG - 2023-03-07 07:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 07:25:15 --> Input Class Initialized
INFO - 2023-03-07 07:25:15 --> Language Class Initialized
INFO - 2023-03-07 07:25:15 --> Loader Class Initialized
INFO - 2023-03-07 07:25:15 --> Controller Class Initialized
DEBUG - 2023-03-07 07:25:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 07:25:15 --> Database Driver Class Initialized
INFO - 2023-03-07 07:25:15 --> Model "Cluster_model" initialized
INFO - 2023-03-07 07:25:16 --> Database Driver Class Initialized
INFO - 2023-03-07 07:25:16 --> Model "Login_model" initialized
INFO - 2023-03-07 07:25:16 --> Final output sent to browser
DEBUG - 2023-03-07 07:25:16 --> Total execution time: 0.1180
INFO - 2023-03-07 08:20:37 --> Config Class Initialized
INFO - 2023-03-07 08:20:37 --> Hooks Class Initialized
DEBUG - 2023-03-07 08:20:37 --> UTF-8 Support Enabled
INFO - 2023-03-07 08:20:37 --> Utf8 Class Initialized
INFO - 2023-03-07 08:20:37 --> URI Class Initialized
INFO - 2023-03-07 08:20:37 --> Router Class Initialized
INFO - 2023-03-07 08:20:37 --> Output Class Initialized
INFO - 2023-03-07 08:20:37 --> Security Class Initialized
DEBUG - 2023-03-07 08:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 08:20:37 --> Input Class Initialized
INFO - 2023-03-07 08:20:37 --> Language Class Initialized
INFO - 2023-03-07 08:20:37 --> Loader Class Initialized
INFO - 2023-03-07 08:20:37 --> Controller Class Initialized
DEBUG - 2023-03-07 08:20:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 08:20:37 --> Database Driver Class Initialized
INFO - 2023-03-07 08:20:37 --> Model "Cluster_model" initialized
INFO - 2023-03-07 08:20:37 --> Final output sent to browser
DEBUG - 2023-03-07 08:20:37 --> Total execution time: 0.0177
INFO - 2023-03-07 08:20:37 --> Config Class Initialized
INFO - 2023-03-07 08:20:37 --> Hooks Class Initialized
DEBUG - 2023-03-07 08:20:37 --> UTF-8 Support Enabled
INFO - 2023-03-07 08:20:37 --> Utf8 Class Initialized
INFO - 2023-03-07 08:20:37 --> URI Class Initialized
INFO - 2023-03-07 08:20:37 --> Router Class Initialized
INFO - 2023-03-07 08:20:37 --> Output Class Initialized
INFO - 2023-03-07 08:20:37 --> Security Class Initialized
DEBUG - 2023-03-07 08:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 08:20:37 --> Input Class Initialized
INFO - 2023-03-07 08:20:37 --> Language Class Initialized
INFO - 2023-03-07 08:20:37 --> Loader Class Initialized
INFO - 2023-03-07 08:20:37 --> Controller Class Initialized
DEBUG - 2023-03-07 08:20:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 08:20:37 --> Database Driver Class Initialized
INFO - 2023-03-07 08:20:37 --> Model "Cluster_model" initialized
INFO - 2023-03-07 08:20:37 --> Final output sent to browser
DEBUG - 2023-03-07 08:20:37 --> Total execution time: 0.0146
INFO - 2023-03-07 09:45:34 --> Config Class Initialized
INFO - 2023-03-07 09:45:34 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:45:34 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:45:34 --> Utf8 Class Initialized
INFO - 2023-03-07 09:45:34 --> URI Class Initialized
INFO - 2023-03-07 09:45:34 --> Router Class Initialized
INFO - 2023-03-07 09:45:34 --> Output Class Initialized
INFO - 2023-03-07 09:45:34 --> Security Class Initialized
DEBUG - 2023-03-07 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:45:34 --> Input Class Initialized
INFO - 2023-03-07 09:45:34 --> Language Class Initialized
INFO - 2023-03-07 09:45:34 --> Loader Class Initialized
INFO - 2023-03-07 09:45:34 --> Controller Class Initialized
INFO - 2023-03-07 09:45:34 --> Helper loaded: form_helper
INFO - 2023-03-07 09:45:34 --> Helper loaded: url_helper
INFO - 2023-03-07 09:48:08 --> Config Class Initialized
INFO - 2023-03-07 09:48:08 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:48:08 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:48:08 --> Utf8 Class Initialized
INFO - 2023-03-07 09:48:08 --> URI Class Initialized
INFO - 2023-03-07 09:48:08 --> Router Class Initialized
INFO - 2023-03-07 09:48:08 --> Output Class Initialized
INFO - 2023-03-07 09:48:08 --> Security Class Initialized
DEBUG - 2023-03-07 09:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:48:08 --> Input Class Initialized
INFO - 2023-03-07 09:48:08 --> Language Class Initialized
INFO - 2023-03-07 09:48:08 --> Loader Class Initialized
INFO - 2023-03-07 09:48:08 --> Controller Class Initialized
INFO - 2023-03-07 09:48:08 --> Helper loaded: form_helper
INFO - 2023-03-07 09:48:08 --> Helper loaded: url_helper
INFO - 2023-03-07 09:48:19 --> Config Class Initialized
INFO - 2023-03-07 09:48:19 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:48:19 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:48:19 --> Utf8 Class Initialized
INFO - 2023-03-07 09:48:19 --> URI Class Initialized
INFO - 2023-03-07 09:48:19 --> Router Class Initialized
INFO - 2023-03-07 09:48:19 --> Output Class Initialized
INFO - 2023-03-07 09:48:19 --> Security Class Initialized
DEBUG - 2023-03-07 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:48:19 --> Input Class Initialized
INFO - 2023-03-07 09:48:19 --> Language Class Initialized
INFO - 2023-03-07 09:48:19 --> Loader Class Initialized
INFO - 2023-03-07 09:48:19 --> Controller Class Initialized
INFO - 2023-03-07 09:48:19 --> Helper loaded: form_helper
INFO - 2023-03-07 09:48:19 --> Helper loaded: url_helper
INFO - 2023-03-07 09:48:20 --> Config Class Initialized
INFO - 2023-03-07 09:48:20 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:48:20 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:48:20 --> Utf8 Class Initialized
INFO - 2023-03-07 09:48:20 --> URI Class Initialized
INFO - 2023-03-07 09:48:20 --> Router Class Initialized
INFO - 2023-03-07 09:48:20 --> Output Class Initialized
INFO - 2023-03-07 09:48:20 --> Security Class Initialized
DEBUG - 2023-03-07 09:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:48:20 --> Input Class Initialized
INFO - 2023-03-07 09:48:20 --> Language Class Initialized
ERROR - 2023-03-07 09:48:20 --> 404 Page Not Found: Faviconico/index
INFO - 2023-03-07 09:49:39 --> Config Class Initialized
INFO - 2023-03-07 09:49:39 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:49:39 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:49:39 --> Utf8 Class Initialized
INFO - 2023-03-07 09:49:39 --> URI Class Initialized
INFO - 2023-03-07 09:49:39 --> Router Class Initialized
INFO - 2023-03-07 09:49:39 --> Output Class Initialized
INFO - 2023-03-07 09:49:39 --> Security Class Initialized
DEBUG - 2023-03-07 09:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:49:39 --> Input Class Initialized
INFO - 2023-03-07 09:49:39 --> Language Class Initialized
INFO - 2023-03-07 09:49:39 --> Loader Class Initialized
INFO - 2023-03-07 09:49:39 --> Controller Class Initialized
INFO - 2023-03-07 09:49:39 --> Helper loaded: form_helper
INFO - 2023-03-07 09:49:39 --> Helper loaded: url_helper
INFO - 2023-03-07 09:50:35 --> Config Class Initialized
INFO - 2023-03-07 09:50:35 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:50:35 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:50:35 --> Utf8 Class Initialized
INFO - 2023-03-07 09:50:35 --> URI Class Initialized
INFO - 2023-03-07 09:50:35 --> Router Class Initialized
INFO - 2023-03-07 09:50:35 --> Output Class Initialized
INFO - 2023-03-07 09:50:35 --> Security Class Initialized
DEBUG - 2023-03-07 09:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:50:35 --> Input Class Initialized
INFO - 2023-03-07 09:50:35 --> Language Class Initialized
INFO - 2023-03-07 09:50:35 --> Loader Class Initialized
INFO - 2023-03-07 09:50:35 --> Controller Class Initialized
INFO - 2023-03-07 09:50:35 --> Helper loaded: form_helper
INFO - 2023-03-07 09:50:35 --> Helper loaded: url_helper
INFO - 2023-03-07 09:52:12 --> Config Class Initialized
INFO - 2023-03-07 09:52:12 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:52:12 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:52:13 --> Utf8 Class Initialized
INFO - 2023-03-07 09:52:13 --> URI Class Initialized
INFO - 2023-03-07 09:52:13 --> Router Class Initialized
INFO - 2023-03-07 09:52:13 --> Output Class Initialized
INFO - 2023-03-07 09:52:13 --> Security Class Initialized
DEBUG - 2023-03-07 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:52:13 --> Input Class Initialized
INFO - 2023-03-07 09:52:13 --> Language Class Initialized
INFO - 2023-03-07 09:52:13 --> Loader Class Initialized
INFO - 2023-03-07 09:52:13 --> Controller Class Initialized
INFO - 2023-03-07 09:52:13 --> Helper loaded: form_helper
INFO - 2023-03-07 09:52:13 --> Helper loaded: url_helper
INFO - 2023-03-07 09:52:14 --> Config Class Initialized
INFO - 2023-03-07 09:52:14 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:52:14 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:52:14 --> Utf8 Class Initialized
INFO - 2023-03-07 09:52:14 --> URI Class Initialized
INFO - 2023-03-07 09:52:14 --> Router Class Initialized
INFO - 2023-03-07 09:52:14 --> Output Class Initialized
INFO - 2023-03-07 09:52:14 --> Security Class Initialized
DEBUG - 2023-03-07 09:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:52:14 --> Input Class Initialized
INFO - 2023-03-07 09:52:14 --> Language Class Initialized
INFO - 2023-03-07 09:52:14 --> Loader Class Initialized
INFO - 2023-03-07 09:52:14 --> Controller Class Initialized
INFO - 2023-03-07 09:52:14 --> Helper loaded: form_helper
INFO - 2023-03-07 09:52:14 --> Helper loaded: url_helper
INFO - 2023-03-07 09:52:15 --> Config Class Initialized
INFO - 2023-03-07 09:52:15 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:52:15 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:52:15 --> Utf8 Class Initialized
INFO - 2023-03-07 09:52:15 --> URI Class Initialized
INFO - 2023-03-07 09:52:15 --> Router Class Initialized
INFO - 2023-03-07 09:52:15 --> Output Class Initialized
INFO - 2023-03-07 09:52:15 --> Security Class Initialized
DEBUG - 2023-03-07 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:52:15 --> Input Class Initialized
INFO - 2023-03-07 09:52:15 --> Language Class Initialized
INFO - 2023-03-07 09:52:15 --> Loader Class Initialized
INFO - 2023-03-07 09:52:15 --> Controller Class Initialized
INFO - 2023-03-07 09:52:15 --> Helper loaded: form_helper
INFO - 2023-03-07 09:52:15 --> Helper loaded: url_helper
INFO - 2023-03-07 09:53:04 --> Config Class Initialized
INFO - 2023-03-07 09:53:04 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:04 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:04 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:04 --> URI Class Initialized
INFO - 2023-03-07 09:53:04 --> Router Class Initialized
INFO - 2023-03-07 09:53:04 --> Output Class Initialized
INFO - 2023-03-07 09:53:04 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:04 --> Input Class Initialized
INFO - 2023-03-07 09:53:04 --> Language Class Initialized
INFO - 2023-03-07 09:53:04 --> Loader Class Initialized
INFO - 2023-03-07 09:53:04 --> Controller Class Initialized
INFO - 2023-03-07 09:53:04 --> Helper loaded: form_helper
INFO - 2023-03-07 09:53:04 --> Helper loaded: url_helper
INFO - 2023-03-07 09:53:05 --> Config Class Initialized
INFO - 2023-03-07 09:53:05 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:05 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:05 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:05 --> URI Class Initialized
INFO - 2023-03-07 09:53:05 --> Router Class Initialized
INFO - 2023-03-07 09:53:05 --> Output Class Initialized
INFO - 2023-03-07 09:53:05 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:05 --> Input Class Initialized
INFO - 2023-03-07 09:53:05 --> Language Class Initialized
INFO - 2023-03-07 09:53:05 --> Loader Class Initialized
INFO - 2023-03-07 09:53:05 --> Controller Class Initialized
INFO - 2023-03-07 09:53:05 --> Helper loaded: form_helper
INFO - 2023-03-07 09:53:05 --> Helper loaded: url_helper
INFO - 2023-03-07 09:53:06 --> Config Class Initialized
INFO - 2023-03-07 09:53:06 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:06 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:06 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:06 --> URI Class Initialized
INFO - 2023-03-07 09:53:06 --> Router Class Initialized
INFO - 2023-03-07 09:53:06 --> Output Class Initialized
INFO - 2023-03-07 09:53:06 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:06 --> Input Class Initialized
INFO - 2023-03-07 09:53:06 --> Language Class Initialized
INFO - 2023-03-07 09:53:06 --> Loader Class Initialized
INFO - 2023-03-07 09:53:06 --> Controller Class Initialized
INFO - 2023-03-07 09:53:06 --> Helper loaded: form_helper
INFO - 2023-03-07 09:53:06 --> Helper loaded: url_helper
INFO - 2023-03-07 09:53:10 --> Config Class Initialized
INFO - 2023-03-07 09:53:10 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:10 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:10 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:10 --> URI Class Initialized
INFO - 2023-03-07 09:53:10 --> Router Class Initialized
INFO - 2023-03-07 09:53:10 --> Output Class Initialized
INFO - 2023-03-07 09:53:10 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:10 --> Input Class Initialized
INFO - 2023-03-07 09:53:10 --> Language Class Initialized
ERROR - 2023-03-07 09:53:10 --> 404 Page Not Found: /index
INFO - 2023-03-07 09:53:18 --> Config Class Initialized
INFO - 2023-03-07 09:53:18 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:18 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:18 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:18 --> URI Class Initialized
INFO - 2023-03-07 09:53:18 --> Router Class Initialized
INFO - 2023-03-07 09:53:18 --> Output Class Initialized
INFO - 2023-03-07 09:53:18 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:18 --> Input Class Initialized
INFO - 2023-03-07 09:53:18 --> Language Class Initialized
INFO - 2023-03-07 09:53:18 --> Loader Class Initialized
INFO - 2023-03-07 09:53:18 --> Controller Class Initialized
INFO - 2023-03-07 09:53:18 --> Helper loaded: form_helper
INFO - 2023-03-07 09:53:18 --> Helper loaded: url_helper
INFO - 2023-03-07 09:53:21 --> Config Class Initialized
INFO - 2023-03-07 09:53:21 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:21 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:21 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:21 --> URI Class Initialized
INFO - 2023-03-07 09:53:21 --> Router Class Initialized
INFO - 2023-03-07 09:53:21 --> Output Class Initialized
INFO - 2023-03-07 09:53:21 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:21 --> Input Class Initialized
INFO - 2023-03-07 09:53:21 --> Language Class Initialized
INFO - 2023-03-07 09:53:21 --> Loader Class Initialized
INFO - 2023-03-07 09:53:21 --> Controller Class Initialized
INFO - 2023-03-07 09:53:21 --> Helper loaded: form_helper
INFO - 2023-03-07 09:53:21 --> Helper loaded: url_helper
INFO - 2023-03-07 09:53:37 --> Config Class Initialized
INFO - 2023-03-07 09:53:37 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:37 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:37 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:37 --> URI Class Initialized
INFO - 2023-03-07 09:53:37 --> Router Class Initialized
INFO - 2023-03-07 09:53:37 --> Output Class Initialized
INFO - 2023-03-07 09:53:37 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:37 --> Input Class Initialized
INFO - 2023-03-07 09:53:37 --> Language Class Initialized
INFO - 2023-03-07 09:53:37 --> Loader Class Initialized
INFO - 2023-03-07 09:53:37 --> Controller Class Initialized
INFO - 2023-03-07 09:53:37 --> Helper loaded: form_helper
INFO - 2023-03-07 09:53:37 --> Helper loaded: url_helper
INFO - 2023-03-07 09:53:38 --> Config Class Initialized
INFO - 2023-03-07 09:53:38 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:38 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:38 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:38 --> URI Class Initialized
INFO - 2023-03-07 09:53:38 --> Router Class Initialized
INFO - 2023-03-07 09:53:38 --> Output Class Initialized
INFO - 2023-03-07 09:53:38 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:38 --> Input Class Initialized
INFO - 2023-03-07 09:53:38 --> Language Class Initialized
INFO - 2023-03-07 09:53:38 --> Loader Class Initialized
INFO - 2023-03-07 09:53:38 --> Controller Class Initialized
INFO - 2023-03-07 09:53:38 --> Helper loaded: form_helper
INFO - 2023-03-07 09:53:38 --> Helper loaded: url_helper
INFO - 2023-03-07 09:53:39 --> Config Class Initialized
INFO - 2023-03-07 09:53:39 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:53:39 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:53:39 --> Utf8 Class Initialized
INFO - 2023-03-07 09:53:39 --> URI Class Initialized
INFO - 2023-03-07 09:53:39 --> Router Class Initialized
INFO - 2023-03-07 09:53:39 --> Output Class Initialized
INFO - 2023-03-07 09:53:39 --> Security Class Initialized
DEBUG - 2023-03-07 09:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:53:39 --> Input Class Initialized
INFO - 2023-03-07 09:53:39 --> Language Class Initialized
INFO - 2023-03-07 09:53:39 --> Loader Class Initialized
INFO - 2023-03-07 09:53:39 --> Controller Class Initialized
INFO - 2023-03-07 09:53:39 --> Helper loaded: form_helper
INFO - 2023-03-07 09:53:39 --> Helper loaded: url_helper
INFO - 2023-03-07 09:55:51 --> Config Class Initialized
INFO - 2023-03-07 09:55:51 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:55:51 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:55:51 --> Utf8 Class Initialized
INFO - 2023-03-07 09:55:51 --> URI Class Initialized
INFO - 2023-03-07 09:55:51 --> Router Class Initialized
INFO - 2023-03-07 09:55:51 --> Output Class Initialized
INFO - 2023-03-07 09:55:51 --> Security Class Initialized
DEBUG - 2023-03-07 09:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:55:51 --> Input Class Initialized
INFO - 2023-03-07 09:55:51 --> Language Class Initialized
INFO - 2023-03-07 09:55:51 --> Loader Class Initialized
INFO - 2023-03-07 09:55:51 --> Controller Class Initialized
INFO - 2023-03-07 09:55:51 --> Helper loaded: form_helper
INFO - 2023-03-07 09:55:51 --> Helper loaded: url_helper
DEBUG - 2023-03-07 09:55:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:55:51 --> Model "Change_model" initialized
INFO - 2023-03-07 09:55:51 --> Model "Grafana_model" initialized
INFO - 2023-03-07 09:55:51 --> Final output sent to browser
DEBUG - 2023-03-07 09:55:51 --> Total execution time: 0.0856
INFO - 2023-03-07 09:56:11 --> Config Class Initialized
INFO - 2023-03-07 09:56:11 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:56:11 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:56:11 --> Utf8 Class Initialized
INFO - 2023-03-07 09:56:11 --> URI Class Initialized
INFO - 2023-03-07 09:56:11 --> Router Class Initialized
INFO - 2023-03-07 09:56:11 --> Output Class Initialized
INFO - 2023-03-07 09:56:11 --> Security Class Initialized
DEBUG - 2023-03-07 09:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:56:11 --> Input Class Initialized
INFO - 2023-03-07 09:56:11 --> Language Class Initialized
INFO - 2023-03-07 09:56:11 --> Loader Class Initialized
INFO - 2023-03-07 09:56:11 --> Controller Class Initialized
INFO - 2023-03-07 09:56:11 --> Helper loaded: form_helper
INFO - 2023-03-07 09:56:11 --> Helper loaded: url_helper
INFO - 2023-03-07 09:56:16 --> Config Class Initialized
INFO - 2023-03-07 09:56:16 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:56:16 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:56:16 --> Utf8 Class Initialized
INFO - 2023-03-07 09:56:16 --> URI Class Initialized
INFO - 2023-03-07 09:56:16 --> Router Class Initialized
INFO - 2023-03-07 09:56:16 --> Output Class Initialized
INFO - 2023-03-07 09:56:16 --> Security Class Initialized
DEBUG - 2023-03-07 09:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:56:16 --> Input Class Initialized
INFO - 2023-03-07 09:56:16 --> Language Class Initialized
INFO - 2023-03-07 09:56:16 --> Loader Class Initialized
INFO - 2023-03-07 09:56:16 --> Controller Class Initialized
INFO - 2023-03-07 09:56:16 --> Helper loaded: form_helper
INFO - 2023-03-07 09:56:16 --> Helper loaded: url_helper
INFO - 2023-03-07 09:56:39 --> Config Class Initialized
INFO - 2023-03-07 09:56:39 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:56:39 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:56:39 --> Utf8 Class Initialized
INFO - 2023-03-07 09:56:39 --> URI Class Initialized
INFO - 2023-03-07 09:56:39 --> Router Class Initialized
INFO - 2023-03-07 09:56:39 --> Output Class Initialized
INFO - 2023-03-07 09:56:39 --> Security Class Initialized
DEBUG - 2023-03-07 09:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:56:39 --> Input Class Initialized
INFO - 2023-03-07 09:56:39 --> Language Class Initialized
INFO - 2023-03-07 09:56:39 --> Loader Class Initialized
INFO - 2023-03-07 09:56:39 --> Controller Class Initialized
INFO - 2023-03-07 09:56:39 --> Helper loaded: form_helper
INFO - 2023-03-07 09:56:39 --> Helper loaded: url_helper
DEBUG - 2023-03-07 09:56:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:56:39 --> Model "Change_model" initialized
INFO - 2023-03-07 09:56:39 --> Model "Grafana_model" initialized
INFO - 2023-03-07 09:56:39 --> Final output sent to browser
DEBUG - 2023-03-07 09:56:39 --> Total execution time: 0.0487
INFO - 2023-03-07 09:57:09 --> Config Class Initialized
INFO - 2023-03-07 09:57:09 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:57:09 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:57:09 --> Utf8 Class Initialized
INFO - 2023-03-07 09:57:09 --> URI Class Initialized
INFO - 2023-03-07 09:57:09 --> Router Class Initialized
INFO - 2023-03-07 09:57:09 --> Output Class Initialized
INFO - 2023-03-07 09:57:09 --> Security Class Initialized
DEBUG - 2023-03-07 09:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:57:09 --> Input Class Initialized
INFO - 2023-03-07 09:57:09 --> Language Class Initialized
INFO - 2023-03-07 09:57:09 --> Loader Class Initialized
INFO - 2023-03-07 09:57:09 --> Controller Class Initialized
INFO - 2023-03-07 09:57:09 --> Helper loaded: form_helper
INFO - 2023-03-07 09:57:09 --> Helper loaded: url_helper
INFO - 2023-03-07 09:57:35 --> Config Class Initialized
INFO - 2023-03-07 09:57:35 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:57:35 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:57:35 --> Utf8 Class Initialized
INFO - 2023-03-07 09:57:35 --> URI Class Initialized
INFO - 2023-03-07 09:57:35 --> Router Class Initialized
INFO - 2023-03-07 09:57:35 --> Output Class Initialized
INFO - 2023-03-07 09:57:35 --> Security Class Initialized
DEBUG - 2023-03-07 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:57:35 --> Input Class Initialized
INFO - 2023-03-07 09:57:35 --> Language Class Initialized
INFO - 2023-03-07 09:57:35 --> Loader Class Initialized
INFO - 2023-03-07 09:57:35 --> Controller Class Initialized
INFO - 2023-03-07 09:57:35 --> Helper loaded: form_helper
INFO - 2023-03-07 09:57:35 --> Helper loaded: url_helper
INFO - 2023-03-07 09:57:36 --> Config Class Initialized
INFO - 2023-03-07 09:57:36 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:57:36 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:57:36 --> Utf8 Class Initialized
INFO - 2023-03-07 09:57:36 --> URI Class Initialized
INFO - 2023-03-07 09:57:36 --> Router Class Initialized
INFO - 2023-03-07 09:57:36 --> Output Class Initialized
INFO - 2023-03-07 09:57:36 --> Security Class Initialized
DEBUG - 2023-03-07 09:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:57:36 --> Input Class Initialized
INFO - 2023-03-07 09:57:36 --> Language Class Initialized
INFO - 2023-03-07 09:57:36 --> Loader Class Initialized
INFO - 2023-03-07 09:57:36 --> Controller Class Initialized
INFO - 2023-03-07 09:57:36 --> Helper loaded: form_helper
INFO - 2023-03-07 09:57:36 --> Helper loaded: url_helper
INFO - 2023-03-07 09:58:00 --> Config Class Initialized
INFO - 2023-03-07 09:58:00 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:58:00 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:58:00 --> Utf8 Class Initialized
INFO - 2023-03-07 09:58:00 --> URI Class Initialized
INFO - 2023-03-07 09:58:00 --> Router Class Initialized
INFO - 2023-03-07 09:58:00 --> Output Class Initialized
INFO - 2023-03-07 09:58:00 --> Security Class Initialized
DEBUG - 2023-03-07 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:58:00 --> Input Class Initialized
INFO - 2023-03-07 09:58:00 --> Language Class Initialized
INFO - 2023-03-07 09:58:00 --> Loader Class Initialized
INFO - 2023-03-07 09:58:00 --> Controller Class Initialized
INFO - 2023-03-07 09:58:00 --> Helper loaded: form_helper
INFO - 2023-03-07 09:58:00 --> Helper loaded: url_helper
INFO - 2023-03-07 09:58:02 --> Config Class Initialized
INFO - 2023-03-07 09:58:02 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:58:02 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:58:02 --> Utf8 Class Initialized
INFO - 2023-03-07 09:58:02 --> URI Class Initialized
INFO - 2023-03-07 09:58:02 --> Router Class Initialized
INFO - 2023-03-07 09:58:02 --> Output Class Initialized
INFO - 2023-03-07 09:58:02 --> Security Class Initialized
DEBUG - 2023-03-07 09:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:58:02 --> Input Class Initialized
INFO - 2023-03-07 09:58:02 --> Language Class Initialized
INFO - 2023-03-07 09:58:02 --> Loader Class Initialized
INFO - 2023-03-07 09:58:02 --> Controller Class Initialized
INFO - 2023-03-07 09:58:02 --> Helper loaded: form_helper
INFO - 2023-03-07 09:58:02 --> Helper loaded: url_helper
INFO - 2023-03-07 09:58:16 --> Config Class Initialized
INFO - 2023-03-07 09:58:16 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:58:16 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:58:16 --> Utf8 Class Initialized
INFO - 2023-03-07 09:58:16 --> URI Class Initialized
INFO - 2023-03-07 09:58:16 --> Router Class Initialized
INFO - 2023-03-07 09:58:16 --> Output Class Initialized
INFO - 2023-03-07 09:58:16 --> Security Class Initialized
DEBUG - 2023-03-07 09:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:58:16 --> Input Class Initialized
INFO - 2023-03-07 09:58:16 --> Language Class Initialized
INFO - 2023-03-07 09:58:16 --> Loader Class Initialized
INFO - 2023-03-07 09:58:16 --> Controller Class Initialized
INFO - 2023-03-07 09:58:16 --> Helper loaded: form_helper
INFO - 2023-03-07 09:58:16 --> Helper loaded: url_helper
INFO - 2023-03-07 09:59:29 --> Config Class Initialized
INFO - 2023-03-07 09:59:29 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:59:29 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:59:29 --> Utf8 Class Initialized
INFO - 2023-03-07 09:59:29 --> URI Class Initialized
INFO - 2023-03-07 09:59:29 --> Router Class Initialized
INFO - 2023-03-07 09:59:29 --> Output Class Initialized
INFO - 2023-03-07 09:59:29 --> Security Class Initialized
DEBUG - 2023-03-07 09:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:59:29 --> Input Class Initialized
INFO - 2023-03-07 09:59:29 --> Language Class Initialized
INFO - 2023-03-07 09:59:29 --> Loader Class Initialized
INFO - 2023-03-07 09:59:29 --> Controller Class Initialized
INFO - 2023-03-07 09:59:29 --> Helper loaded: form_helper
INFO - 2023-03-07 09:59:29 --> Helper loaded: url_helper
DEBUG - 2023-03-07 09:59:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:59:29 --> Model "Change_model" initialized
INFO - 2023-03-07 09:59:29 --> Model "Grafana_model" initialized
INFO - 2023-03-07 09:59:29 --> Final output sent to browser
DEBUG - 2023-03-07 09:59:29 --> Total execution time: 0.0283
INFO - 2023-03-07 09:59:30 --> Config Class Initialized
INFO - 2023-03-07 09:59:30 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:59:30 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:59:30 --> Utf8 Class Initialized
INFO - 2023-03-07 09:59:30 --> URI Class Initialized
INFO - 2023-03-07 09:59:30 --> Router Class Initialized
INFO - 2023-03-07 09:59:30 --> Output Class Initialized
INFO - 2023-03-07 09:59:30 --> Security Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:59:30 --> Input Class Initialized
INFO - 2023-03-07 09:59:30 --> Language Class Initialized
INFO - 2023-03-07 09:59:30 --> Loader Class Initialized
INFO - 2023-03-07 09:59:30 --> Controller Class Initialized
INFO - 2023-03-07 09:59:30 --> Helper loaded: form_helper
INFO - 2023-03-07 09:59:30 --> Helper loaded: url_helper
DEBUG - 2023-03-07 09:59:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:59:30 --> Final output sent to browser
DEBUG - 2023-03-07 09:59:30 --> Total execution time: 0.0054
INFO - 2023-03-07 09:59:30 --> Config Class Initialized
INFO - 2023-03-07 09:59:30 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:59:30 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:59:30 --> Utf8 Class Initialized
INFO - 2023-03-07 09:59:30 --> URI Class Initialized
INFO - 2023-03-07 09:59:30 --> Router Class Initialized
INFO - 2023-03-07 09:59:30 --> Output Class Initialized
INFO - 2023-03-07 09:59:30 --> Security Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:59:30 --> Input Class Initialized
INFO - 2023-03-07 09:59:30 --> Language Class Initialized
INFO - 2023-03-07 09:59:30 --> Loader Class Initialized
INFO - 2023-03-07 09:59:30 --> Controller Class Initialized
INFO - 2023-03-07 09:59:30 --> Helper loaded: form_helper
INFO - 2023-03-07 09:59:30 --> Helper loaded: url_helper
DEBUG - 2023-03-07 09:59:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:59:30 --> Database Driver Class Initialized
INFO - 2023-03-07 09:59:30 --> Model "Login_model" initialized
INFO - 2023-03-07 09:59:30 --> Final output sent to browser
DEBUG - 2023-03-07 09:59:30 --> Total execution time: 0.0176
INFO - 2023-03-07 09:59:30 --> Config Class Initialized
INFO - 2023-03-07 09:59:30 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:59:30 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:59:30 --> Utf8 Class Initialized
INFO - 2023-03-07 09:59:30 --> URI Class Initialized
INFO - 2023-03-07 09:59:30 --> Router Class Initialized
INFO - 2023-03-07 09:59:30 --> Output Class Initialized
INFO - 2023-03-07 09:59:30 --> Security Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:59:30 --> Input Class Initialized
INFO - 2023-03-07 09:59:30 --> Language Class Initialized
INFO - 2023-03-07 09:59:30 --> Loader Class Initialized
INFO - 2023-03-07 09:59:30 --> Controller Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:59:30 --> Database Driver Class Initialized
INFO - 2023-03-07 09:59:30 --> Model "Cluster_model" initialized
INFO - 2023-03-07 09:59:30 --> Final output sent to browser
DEBUG - 2023-03-07 09:59:30 --> Total execution time: 0.0629
INFO - 2023-03-07 09:59:30 --> Config Class Initialized
INFO - 2023-03-07 09:59:30 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:59:30 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:59:30 --> Utf8 Class Initialized
INFO - 2023-03-07 09:59:30 --> URI Class Initialized
INFO - 2023-03-07 09:59:30 --> Router Class Initialized
INFO - 2023-03-07 09:59:30 --> Output Class Initialized
INFO - 2023-03-07 09:59:30 --> Security Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:59:30 --> Input Class Initialized
INFO - 2023-03-07 09:59:30 --> Language Class Initialized
INFO - 2023-03-07 09:59:30 --> Loader Class Initialized
INFO - 2023-03-07 09:59:30 --> Controller Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:59:30 --> Database Driver Class Initialized
INFO - 2023-03-07 09:59:30 --> Model "Cluster_model" initialized
INFO - 2023-03-07 09:59:30 --> Final output sent to browser
DEBUG - 2023-03-07 09:59:30 --> Total execution time: 0.0268
INFO - 2023-03-07 09:59:30 --> Config Class Initialized
INFO - 2023-03-07 09:59:30 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:59:30 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:59:30 --> Utf8 Class Initialized
INFO - 2023-03-07 09:59:30 --> URI Class Initialized
INFO - 2023-03-07 09:59:30 --> Router Class Initialized
INFO - 2023-03-07 09:59:30 --> Output Class Initialized
INFO - 2023-03-07 09:59:30 --> Security Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:59:30 --> Input Class Initialized
INFO - 2023-03-07 09:59:30 --> Language Class Initialized
INFO - 2023-03-07 09:59:30 --> Loader Class Initialized
INFO - 2023-03-07 09:59:30 --> Controller Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:59:30 --> Database Driver Class Initialized
INFO - 2023-03-07 09:59:30 --> Model "Cluster_model" initialized
INFO - 2023-03-07 09:59:30 --> Database Driver Class Initialized
INFO - 2023-03-07 09:59:30 --> Model "Login_model" initialized
INFO - 2023-03-07 09:59:30 --> Final output sent to browser
DEBUG - 2023-03-07 09:59:30 --> Total execution time: 0.0710
INFO - 2023-03-07 09:59:30 --> Config Class Initialized
INFO - 2023-03-07 09:59:30 --> Hooks Class Initialized
DEBUG - 2023-03-07 09:59:30 --> UTF-8 Support Enabled
INFO - 2023-03-07 09:59:30 --> Utf8 Class Initialized
INFO - 2023-03-07 09:59:30 --> URI Class Initialized
INFO - 2023-03-07 09:59:30 --> Router Class Initialized
INFO - 2023-03-07 09:59:30 --> Output Class Initialized
INFO - 2023-03-07 09:59:30 --> Security Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 09:59:30 --> Input Class Initialized
INFO - 2023-03-07 09:59:30 --> Language Class Initialized
INFO - 2023-03-07 09:59:30 --> Loader Class Initialized
INFO - 2023-03-07 09:59:30 --> Controller Class Initialized
DEBUG - 2023-03-07 09:59:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 09:59:30 --> Database Driver Class Initialized
INFO - 2023-03-07 09:59:30 --> Model "Cluster_model" initialized
INFO - 2023-03-07 09:59:30 --> Database Driver Class Initialized
INFO - 2023-03-07 09:59:30 --> Model "Login_model" initialized
INFO - 2023-03-07 09:59:30 --> Final output sent to browser
DEBUG - 2023-03-07 09:59:30 --> Total execution time: 0.0786
INFO - 2023-03-07 12:45:45 --> Config Class Initialized
INFO - 2023-03-07 12:45:45 --> Hooks Class Initialized
DEBUG - 2023-03-07 12:45:45 --> UTF-8 Support Enabled
INFO - 2023-03-07 12:45:45 --> Utf8 Class Initialized
INFO - 2023-03-07 12:45:45 --> URI Class Initialized
INFO - 2023-03-07 12:45:45 --> Router Class Initialized
INFO - 2023-03-07 12:45:45 --> Output Class Initialized
INFO - 2023-03-07 12:45:45 --> Security Class Initialized
DEBUG - 2023-03-07 12:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-07 12:45:45 --> Input Class Initialized
INFO - 2023-03-07 12:45:45 --> Language Class Initialized
INFO - 2023-03-07 12:45:45 --> Loader Class Initialized
INFO - 2023-03-07 12:45:45 --> Controller Class Initialized
DEBUG - 2023-03-07 12:45:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-07 12:45:45 --> Database Driver Class Initialized
ERROR - 2023-03-07 12:45:55 --> Unable to connect to the database
INFO - 2023-03-07 12:45:55 --> Language file loaded: language/english/db_lang.php
