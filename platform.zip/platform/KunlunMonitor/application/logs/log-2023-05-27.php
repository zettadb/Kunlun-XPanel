<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-27 04:11:44 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-27 04:11:44 --> Config Class Initialized
INFO - 2023-05-27 04:11:44 --> Hooks Class Initialized
INFO - 2023-05-27 04:11:44 --> Hooks Class Initialized
DEBUG - 2023-05-27 04:11:44 --> UTF-8 Support Enabled
DEBUG - 2023-05-27 04:11:44 --> UTF-8 Support Enabled
INFO - 2023-05-27 04:11:44 --> Utf8 Class Initialized
INFO - 2023-05-27 04:11:44 --> Utf8 Class Initialized
INFO - 2023-05-27 04:11:44 --> URI Class Initialized
INFO - 2023-05-27 04:11:44 --> URI Class Initialized
INFO - 2023-05-27 04:11:44 --> Router Class Initialized
INFO - 2023-05-27 04:11:44 --> Router Class Initialized
INFO - 2023-05-27 04:11:44 --> Output Class Initialized
INFO - 2023-05-27 04:11:44 --> Output Class Initialized
INFO - 2023-05-27 04:11:44 --> Security Class Initialized
INFO - 2023-05-27 04:11:44 --> Security Class Initialized
DEBUG - 2023-05-27 04:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-27 04:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 04:11:44 --> Input Class Initialized
INFO - 2023-05-27 04:11:44 --> Input Class Initialized
INFO - 2023-05-27 04:11:44 --> Language Class Initialized
INFO - 2023-05-27 04:11:44 --> Language Class Initialized
INFO - 2023-05-27 04:11:44 --> Loader Class Initialized
INFO - 2023-05-27 04:11:44 --> Loader Class Initialized
INFO - 2023-05-27 04:11:44 --> Controller Class Initialized
INFO - 2023-05-27 04:11:44 --> Controller Class Initialized
DEBUG - 2023-05-27 04:11:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-05-27 04:11:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-27 04:11:44 --> Database Driver Class Initialized
INFO - 2023-05-27 04:11:44 --> Database Driver Class Initialized
ERROR - 2023-05-27 04:11:54 --> Unable to connect to the database
ERROR - 2023-05-27 04:11:54 --> Unable to connect to the database
INFO - 2023-05-27 04:11:54 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-27 04:11:54 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-27 04:12:54 --> Config Class Initialized
INFO - 2023-05-27 04:12:54 --> Config Class Initialized
INFO - 2023-05-27 04:12:54 --> Hooks Class Initialized
INFO - 2023-05-27 04:12:54 --> Hooks Class Initialized
DEBUG - 2023-05-27 04:12:54 --> UTF-8 Support Enabled
DEBUG - 2023-05-27 04:12:54 --> UTF-8 Support Enabled
INFO - 2023-05-27 04:12:54 --> Utf8 Class Initialized
INFO - 2023-05-27 04:12:54 --> Utf8 Class Initialized
INFO - 2023-05-27 04:12:54 --> URI Class Initialized
INFO - 2023-05-27 04:12:54 --> URI Class Initialized
INFO - 2023-05-27 04:12:54 --> Router Class Initialized
INFO - 2023-05-27 04:12:54 --> Router Class Initialized
INFO - 2023-05-27 04:12:54 --> Output Class Initialized
INFO - 2023-05-27 04:12:54 --> Output Class Initialized
INFO - 2023-05-27 04:12:55 --> Security Class Initialized
INFO - 2023-05-27 04:12:55 --> Security Class Initialized
DEBUG - 2023-05-27 04:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-05-27 04:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 04:12:55 --> Input Class Initialized
INFO - 2023-05-27 04:12:55 --> Input Class Initialized
INFO - 2023-05-27 04:12:55 --> Language Class Initialized
INFO - 2023-05-27 04:12:55 --> Language Class Initialized
INFO - 2023-05-27 04:12:55 --> Loader Class Initialized
INFO - 2023-05-27 04:12:55 --> Controller Class Initialized
INFO - 2023-05-27 04:12:55 --> Loader Class Initialized
DEBUG - 2023-05-27 04:12:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-27 04:12:55 --> Controller Class Initialized
DEBUG - 2023-05-27 04:12:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-27 04:12:55 --> Database Driver Class Initialized
INFO - 2023-05-27 04:12:55 --> Database Driver Class Initialized
INFO - 2023-05-27 04:12:58 --> Config Class Initialized
INFO - 2023-05-27 04:12:58 --> Hooks Class Initialized
DEBUG - 2023-05-27 04:12:58 --> UTF-8 Support Enabled
INFO - 2023-05-27 04:12:58 --> Utf8 Class Initialized
INFO - 2023-05-27 04:12:58 --> URI Class Initialized
INFO - 2023-05-27 04:12:58 --> Router Class Initialized
INFO - 2023-05-27 04:12:58 --> Output Class Initialized
INFO - 2023-05-27 04:12:58 --> Security Class Initialized
DEBUG - 2023-05-27 04:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 04:12:58 --> Input Class Initialized
INFO - 2023-05-27 04:12:58 --> Language Class Initialized
INFO - 2023-05-27 04:12:58 --> Loader Class Initialized
INFO - 2023-05-27 04:12:58 --> Controller Class Initialized
DEBUG - 2023-05-27 04:12:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-27 04:12:58 --> Final output sent to browser
DEBUG - 2023-05-27 04:12:58 --> Total execution time: 0.1360
INFO - 2023-05-27 04:12:58 --> Config Class Initialized
INFO - 2023-05-27 04:12:58 --> Hooks Class Initialized
DEBUG - 2023-05-27 04:12:58 --> UTF-8 Support Enabled
INFO - 2023-05-27 04:12:58 --> Utf8 Class Initialized
INFO - 2023-05-27 04:12:58 --> URI Class Initialized
INFO - 2023-05-27 04:12:58 --> Router Class Initialized
INFO - 2023-05-27 04:12:58 --> Output Class Initialized
INFO - 2023-05-27 04:12:58 --> Security Class Initialized
DEBUG - 2023-05-27 04:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 04:12:58 --> Input Class Initialized
INFO - 2023-05-27 04:12:58 --> Language Class Initialized
INFO - 2023-05-27 04:12:58 --> Loader Class Initialized
INFO - 2023-05-27 04:12:58 --> Controller Class Initialized
DEBUG - 2023-05-27 04:12:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-27 04:12:58 --> Database Driver Class Initialized
INFO - 2023-05-27 04:12:59 --> Config Class Initialized
INFO - 2023-05-27 04:12:59 --> Hooks Class Initialized
DEBUG - 2023-05-27 04:12:59 --> UTF-8 Support Enabled
INFO - 2023-05-27 04:12:59 --> Utf8 Class Initialized
INFO - 2023-05-27 04:12:59 --> URI Class Initialized
INFO - 2023-05-27 04:12:59 --> Router Class Initialized
INFO - 2023-05-27 04:12:59 --> Output Class Initialized
INFO - 2023-05-27 04:12:59 --> Security Class Initialized
DEBUG - 2023-05-27 04:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-27 04:12:59 --> Input Class Initialized
INFO - 2023-05-27 04:12:59 --> Language Class Initialized
INFO - 2023-05-27 04:12:59 --> Loader Class Initialized
INFO - 2023-05-27 04:12:59 --> Controller Class Initialized
DEBUG - 2023-05-27 04:12:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-05-27 04:12:59 --> Database Driver Class Initialized
ERROR - 2023-05-27 04:13:05 --> Unable to connect to the database
INFO - 2023-05-27 04:13:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-05-27 04:13:05 --> Unable to connect to the database
INFO - 2023-05-27 04:13:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-05-27 04:13:08 --> Unable to connect to the database
INFO - 2023-05-27 04:13:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-05-27 04:13:09 --> Unable to connect to the database
INFO - 2023-05-27 04:13:09 --> Model "Login_model" initialized
ERROR - 2023-05-27 04:13:19 --> Unable to connect to the database
ERROR - 2023-05-27 04:13:19 --> Query error: Connection timed out - Invalid query: select count(id) as count,id from kunlun_user where name='super_dba' group by id;
INFO - 2023-05-27 04:13:19 --> Final output sent to browser
DEBUG - 2023-05-27 04:13:19 --> Total execution time: 20.2492
