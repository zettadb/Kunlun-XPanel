<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-10 01:54:11 --> Config Class Initialized
INFO - 2023-01-10 01:54:11 --> Hooks Class Initialized
DEBUG - 2023-01-10 01:54:11 --> UTF-8 Support Enabled
INFO - 2023-01-10 01:54:11 --> Utf8 Class Initialized
INFO - 2023-01-10 01:54:11 --> URI Class Initialized
INFO - 2023-01-10 01:54:11 --> Router Class Initialized
INFO - 2023-01-10 01:54:11 --> Output Class Initialized
INFO - 2023-01-10 01:54:11 --> Security Class Initialized
DEBUG - 2023-01-10 01:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 01:54:11 --> Input Class Initialized
INFO - 2023-01-10 01:54:11 --> Language Class Initialized
ERROR - 2023-01-10 01:54:11 --> 404 Page Not Found: /index
INFO - 2023-01-10 01:55:01 --> Config Class Initialized
INFO - 2023-01-10 01:55:01 --> Hooks Class Initialized
DEBUG - 2023-01-10 01:55:01 --> UTF-8 Support Enabled
INFO - 2023-01-10 01:55:01 --> Utf8 Class Initialized
INFO - 2023-01-10 01:55:01 --> URI Class Initialized
INFO - 2023-01-10 01:55:01 --> Router Class Initialized
INFO - 2023-01-10 01:55:01 --> Output Class Initialized
INFO - 2023-01-10 01:55:01 --> Security Class Initialized
DEBUG - 2023-01-10 01:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 01:55:01 --> Input Class Initialized
INFO - 2023-01-10 01:55:01 --> Language Class Initialized
INFO - 2023-01-10 01:55:01 --> Loader Class Initialized
INFO - 2023-01-10 01:55:01 --> Controller Class Initialized
INFO - 2023-01-10 01:55:01 --> Helper loaded: form_helper
INFO - 2023-01-10 01:55:01 --> Helper loaded: url_helper
DEBUG - 2023-01-10 01:55:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 01:55:01 --> Model "Change_model" initialized
INFO - 2023-01-10 01:55:03 --> Config Class Initialized
INFO - 2023-01-10 01:55:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 01:55:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 01:55:03 --> Utf8 Class Initialized
INFO - 2023-01-10 01:55:03 --> URI Class Initialized
INFO - 2023-01-10 01:55:03 --> Router Class Initialized
INFO - 2023-01-10 01:55:03 --> Output Class Initialized
INFO - 2023-01-10 01:55:03 --> Security Class Initialized
DEBUG - 2023-01-10 01:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 01:55:03 --> Input Class Initialized
INFO - 2023-01-10 01:55:03 --> Language Class Initialized
INFO - 2023-01-10 01:55:03 --> Loader Class Initialized
INFO - 2023-01-10 01:55:03 --> Controller Class Initialized
INFO - 2023-01-10 01:55:03 --> Helper loaded: form_helper
INFO - 2023-01-10 01:55:03 --> Helper loaded: url_helper
DEBUG - 2023-01-10 01:55:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 01:55:03 --> Model "Change_model" initialized
INFO - 2023-01-10 01:58:01 --> Final output sent to browser
DEBUG - 2023-01-10 01:58:01 --> Total execution time: 180.2962
INFO - 2023-01-10 01:58:03 --> Final output sent to browser
DEBUG - 2023-01-10 01:58:03 --> Total execution time: 180.3193
INFO - 2023-01-10 06:00:26 --> Config Class Initialized
INFO - 2023-01-10 06:00:26 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:00:26 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:00:26 --> Utf8 Class Initialized
INFO - 2023-01-10 06:00:26 --> URI Class Initialized
INFO - 2023-01-10 06:00:26 --> Router Class Initialized
INFO - 2023-01-10 06:00:26 --> Output Class Initialized
INFO - 2023-01-10 06:00:26 --> Security Class Initialized
DEBUG - 2023-01-10 06:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:00:26 --> Input Class Initialized
INFO - 2023-01-10 06:00:26 --> Language Class Initialized
ERROR - 2023-01-10 06:00:26 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:00:33 --> Config Class Initialized
INFO - 2023-01-10 06:00:33 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:00:33 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:00:33 --> Utf8 Class Initialized
INFO - 2023-01-10 06:00:33 --> URI Class Initialized
INFO - 2023-01-10 06:00:33 --> Router Class Initialized
INFO - 2023-01-10 06:00:33 --> Output Class Initialized
INFO - 2023-01-10 06:00:33 --> Security Class Initialized
DEBUG - 2023-01-10 06:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:00:33 --> Input Class Initialized
INFO - 2023-01-10 06:00:33 --> Language Class Initialized
ERROR - 2023-01-10 06:00:33 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:01:38 --> Config Class Initialized
INFO - 2023-01-10 06:01:38 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:01:38 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:01:38 --> Utf8 Class Initialized
INFO - 2023-01-10 06:01:38 --> URI Class Initialized
INFO - 2023-01-10 06:01:38 --> Router Class Initialized
INFO - 2023-01-10 06:01:38 --> Output Class Initialized
INFO - 2023-01-10 06:01:38 --> Security Class Initialized
DEBUG - 2023-01-10 06:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:01:38 --> Input Class Initialized
INFO - 2023-01-10 06:01:38 --> Language Class Initialized
ERROR - 2023-01-10 06:01:38 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:01:39 --> Config Class Initialized
INFO - 2023-01-10 06:01:39 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:01:39 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:01:39 --> Utf8 Class Initialized
INFO - 2023-01-10 06:01:39 --> URI Class Initialized
INFO - 2023-01-10 06:01:39 --> Router Class Initialized
INFO - 2023-01-10 06:01:39 --> Output Class Initialized
INFO - 2023-01-10 06:01:39 --> Security Class Initialized
DEBUG - 2023-01-10 06:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:01:39 --> Input Class Initialized
INFO - 2023-01-10 06:01:39 --> Language Class Initialized
ERROR - 2023-01-10 06:01:39 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:02:12 --> Config Class Initialized
INFO - 2023-01-10 06:02:12 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:02:12 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:02:12 --> Utf8 Class Initialized
INFO - 2023-01-10 06:02:12 --> URI Class Initialized
INFO - 2023-01-10 06:02:12 --> Router Class Initialized
INFO - 2023-01-10 06:02:12 --> Output Class Initialized
INFO - 2023-01-10 06:02:12 --> Security Class Initialized
DEBUG - 2023-01-10 06:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:02:12 --> Input Class Initialized
INFO - 2023-01-10 06:02:12 --> Language Class Initialized
ERROR - 2023-01-10 06:02:12 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:03:12 --> Config Class Initialized
INFO - 2023-01-10 06:03:12 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:03:12 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:03:12 --> Utf8 Class Initialized
INFO - 2023-01-10 06:03:12 --> URI Class Initialized
INFO - 2023-01-10 06:03:12 --> Router Class Initialized
INFO - 2023-01-10 06:03:12 --> Output Class Initialized
INFO - 2023-01-10 06:03:12 --> Security Class Initialized
DEBUG - 2023-01-10 06:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:03:12 --> Input Class Initialized
INFO - 2023-01-10 06:03:12 --> Language Class Initialized
ERROR - 2023-01-10 06:03:12 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:03:16 --> Config Class Initialized
INFO - 2023-01-10 06:03:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:03:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:03:16 --> Utf8 Class Initialized
INFO - 2023-01-10 06:03:16 --> URI Class Initialized
INFO - 2023-01-10 06:03:16 --> Router Class Initialized
INFO - 2023-01-10 06:03:16 --> Output Class Initialized
INFO - 2023-01-10 06:03:16 --> Security Class Initialized
DEBUG - 2023-01-10 06:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:03:16 --> Input Class Initialized
INFO - 2023-01-10 06:03:16 --> Language Class Initialized
ERROR - 2023-01-10 06:03:16 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:03:17 --> Config Class Initialized
INFO - 2023-01-10 06:03:17 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:03:17 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:03:17 --> Utf8 Class Initialized
INFO - 2023-01-10 06:03:17 --> URI Class Initialized
INFO - 2023-01-10 06:03:17 --> Router Class Initialized
INFO - 2023-01-10 06:03:17 --> Output Class Initialized
INFO - 2023-01-10 06:03:17 --> Security Class Initialized
DEBUG - 2023-01-10 06:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:03:17 --> Input Class Initialized
INFO - 2023-01-10 06:03:17 --> Language Class Initialized
ERROR - 2023-01-10 06:03:17 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:04:03 --> Config Class Initialized
INFO - 2023-01-10 06:04:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:04:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:04:03 --> Utf8 Class Initialized
INFO - 2023-01-10 06:04:03 --> URI Class Initialized
INFO - 2023-01-10 06:04:03 --> Router Class Initialized
INFO - 2023-01-10 06:04:03 --> Output Class Initialized
INFO - 2023-01-10 06:04:03 --> Security Class Initialized
DEBUG - 2023-01-10 06:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:04:03 --> Input Class Initialized
INFO - 2023-01-10 06:04:03 --> Language Class Initialized
ERROR - 2023-01-10 06:04:03 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:05:40 --> Config Class Initialized
INFO - 2023-01-10 06:05:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:05:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:05:40 --> Utf8 Class Initialized
INFO - 2023-01-10 06:05:40 --> URI Class Initialized
INFO - 2023-01-10 06:05:40 --> Router Class Initialized
INFO - 2023-01-10 06:05:40 --> Output Class Initialized
INFO - 2023-01-10 06:05:40 --> Security Class Initialized
DEBUG - 2023-01-10 06:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:05:40 --> Input Class Initialized
INFO - 2023-01-10 06:05:40 --> Language Class Initialized
ERROR - 2023-01-10 06:05:40 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:05:40 --> Config Class Initialized
INFO - 2023-01-10 06:05:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:05:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:05:40 --> Utf8 Class Initialized
INFO - 2023-01-10 06:05:40 --> URI Class Initialized
INFO - 2023-01-10 06:05:40 --> Router Class Initialized
INFO - 2023-01-10 06:05:40 --> Output Class Initialized
INFO - 2023-01-10 06:05:40 --> Security Class Initialized
DEBUG - 2023-01-10 06:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:05:40 --> Input Class Initialized
INFO - 2023-01-10 06:05:40 --> Language Class Initialized
ERROR - 2023-01-10 06:05:40 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:05:41 --> Config Class Initialized
INFO - 2023-01-10 06:05:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:05:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:05:41 --> Utf8 Class Initialized
INFO - 2023-01-10 06:05:41 --> URI Class Initialized
INFO - 2023-01-10 06:05:41 --> Router Class Initialized
INFO - 2023-01-10 06:05:41 --> Output Class Initialized
INFO - 2023-01-10 06:05:41 --> Security Class Initialized
DEBUG - 2023-01-10 06:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:05:41 --> Input Class Initialized
INFO - 2023-01-10 06:05:41 --> Language Class Initialized
ERROR - 2023-01-10 06:05:41 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:15:08 --> Config Class Initialized
INFO - 2023-01-10 06:15:08 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:15:08 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:15:08 --> Utf8 Class Initialized
INFO - 2023-01-10 06:15:08 --> URI Class Initialized
INFO - 2023-01-10 06:15:08 --> Router Class Initialized
INFO - 2023-01-10 06:15:08 --> Output Class Initialized
INFO - 2023-01-10 06:15:08 --> Security Class Initialized
DEBUG - 2023-01-10 06:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:15:08 --> Input Class Initialized
INFO - 2023-01-10 06:15:08 --> Language Class Initialized
ERROR - 2023-01-10 06:15:08 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:18:20 --> Config Class Initialized
INFO - 2023-01-10 06:18:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:18:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:18:20 --> Utf8 Class Initialized
INFO - 2023-01-10 06:18:20 --> URI Class Initialized
INFO - 2023-01-10 06:18:20 --> Router Class Initialized
INFO - 2023-01-10 06:18:20 --> Output Class Initialized
INFO - 2023-01-10 06:18:20 --> Security Class Initialized
DEBUG - 2023-01-10 06:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:18:20 --> Input Class Initialized
INFO - 2023-01-10 06:18:20 --> Language Class Initialized
ERROR - 2023-01-10 06:18:20 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:18:21 --> Config Class Initialized
INFO - 2023-01-10 06:18:21 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:18:21 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:18:21 --> Utf8 Class Initialized
INFO - 2023-01-10 06:18:21 --> URI Class Initialized
INFO - 2023-01-10 06:18:21 --> Router Class Initialized
INFO - 2023-01-10 06:18:21 --> Output Class Initialized
INFO - 2023-01-10 06:18:21 --> Security Class Initialized
DEBUG - 2023-01-10 06:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:18:21 --> Input Class Initialized
INFO - 2023-01-10 06:18:21 --> Language Class Initialized
ERROR - 2023-01-10 06:18:21 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:18:22 --> Config Class Initialized
INFO - 2023-01-10 06:18:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:18:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:18:22 --> Utf8 Class Initialized
INFO - 2023-01-10 06:18:22 --> URI Class Initialized
INFO - 2023-01-10 06:18:22 --> Router Class Initialized
INFO - 2023-01-10 06:18:22 --> Output Class Initialized
INFO - 2023-01-10 06:18:22 --> Security Class Initialized
DEBUG - 2023-01-10 06:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:18:22 --> Input Class Initialized
INFO - 2023-01-10 06:18:22 --> Language Class Initialized
ERROR - 2023-01-10 06:18:22 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:18:23 --> Config Class Initialized
INFO - 2023-01-10 06:18:23 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:18:23 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:18:23 --> Utf8 Class Initialized
INFO - 2023-01-10 06:18:23 --> URI Class Initialized
INFO - 2023-01-10 06:18:23 --> Router Class Initialized
INFO - 2023-01-10 06:18:23 --> Output Class Initialized
INFO - 2023-01-10 06:18:23 --> Security Class Initialized
DEBUG - 2023-01-10 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:18:23 --> Input Class Initialized
INFO - 2023-01-10 06:18:23 --> Language Class Initialized
ERROR - 2023-01-10 06:18:23 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:18:32 --> Config Class Initialized
INFO - 2023-01-10 06:18:32 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:18:32 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:18:32 --> Utf8 Class Initialized
INFO - 2023-01-10 06:18:32 --> URI Class Initialized
INFO - 2023-01-10 06:18:32 --> Router Class Initialized
INFO - 2023-01-10 06:18:32 --> Output Class Initialized
INFO - 2023-01-10 06:18:32 --> Security Class Initialized
DEBUG - 2023-01-10 06:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:18:32 --> Input Class Initialized
INFO - 2023-01-10 06:18:32 --> Language Class Initialized
ERROR - 2023-01-10 06:18:32 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:20:34 --> Config Class Initialized
INFO - 2023-01-10 06:20:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:20:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:20:34 --> Utf8 Class Initialized
INFO - 2023-01-10 06:20:34 --> URI Class Initialized
INFO - 2023-01-10 06:20:34 --> Router Class Initialized
INFO - 2023-01-10 06:20:34 --> Output Class Initialized
INFO - 2023-01-10 06:20:34 --> Security Class Initialized
DEBUG - 2023-01-10 06:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:20:34 --> Input Class Initialized
INFO - 2023-01-10 06:20:34 --> Language Class Initialized
ERROR - 2023-01-10 06:20:34 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:20:34 --> Config Class Initialized
INFO - 2023-01-10 06:20:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:20:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:20:34 --> Utf8 Class Initialized
INFO - 2023-01-10 06:20:34 --> URI Class Initialized
INFO - 2023-01-10 06:20:34 --> Router Class Initialized
INFO - 2023-01-10 06:20:34 --> Output Class Initialized
INFO - 2023-01-10 06:20:34 --> Security Class Initialized
DEBUG - 2023-01-10 06:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:20:34 --> Input Class Initialized
INFO - 2023-01-10 06:20:34 --> Language Class Initialized
ERROR - 2023-01-10 06:20:34 --> 404 Page Not Found: Faviconico/index
INFO - 2023-01-10 06:21:38 --> Config Class Initialized
INFO - 2023-01-10 06:21:38 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:21:38 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:21:38 --> Utf8 Class Initialized
INFO - 2023-01-10 06:21:38 --> URI Class Initialized
INFO - 2023-01-10 06:21:38 --> Router Class Initialized
INFO - 2023-01-10 06:21:38 --> Output Class Initialized
INFO - 2023-01-10 06:21:38 --> Security Class Initialized
DEBUG - 2023-01-10 06:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:21:38 --> Input Class Initialized
INFO - 2023-01-10 06:21:38 --> Language Class Initialized
ERROR - 2023-01-10 06:21:38 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:31:28 --> Config Class Initialized
INFO - 2023-01-10 06:31:28 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:31:28 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:31:28 --> Utf8 Class Initialized
INFO - 2023-01-10 06:31:28 --> URI Class Initialized
INFO - 2023-01-10 06:31:28 --> Router Class Initialized
INFO - 2023-01-10 06:31:28 --> Output Class Initialized
INFO - 2023-01-10 06:31:28 --> Security Class Initialized
DEBUG - 2023-01-10 06:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:31:28 --> Input Class Initialized
INFO - 2023-01-10 06:31:28 --> Language Class Initialized
ERROR - 2023-01-10 06:31:28 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:31:51 --> Config Class Initialized
INFO - 2023-01-10 06:31:51 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:31:51 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:31:51 --> Utf8 Class Initialized
INFO - 2023-01-10 06:31:51 --> URI Class Initialized
INFO - 2023-01-10 06:31:51 --> Router Class Initialized
INFO - 2023-01-10 06:31:51 --> Output Class Initialized
INFO - 2023-01-10 06:31:51 --> Security Class Initialized
DEBUG - 2023-01-10 06:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:31:51 --> Input Class Initialized
INFO - 2023-01-10 06:31:51 --> Language Class Initialized
ERROR - 2023-01-10 06:31:51 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:35:27 --> Config Class Initialized
INFO - 2023-01-10 06:35:27 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:35:27 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:35:27 --> Utf8 Class Initialized
INFO - 2023-01-10 06:35:27 --> URI Class Initialized
INFO - 2023-01-10 06:35:27 --> Router Class Initialized
INFO - 2023-01-10 06:35:27 --> Output Class Initialized
INFO - 2023-01-10 06:35:27 --> Security Class Initialized
DEBUG - 2023-01-10 06:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:35:27 --> Input Class Initialized
INFO - 2023-01-10 06:35:27 --> Language Class Initialized
ERROR - 2023-01-10 06:35:27 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:36:10 --> Config Class Initialized
INFO - 2023-01-10 06:36:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:36:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:36:10 --> Utf8 Class Initialized
INFO - 2023-01-10 06:36:10 --> URI Class Initialized
INFO - 2023-01-10 06:36:10 --> Router Class Initialized
INFO - 2023-01-10 06:36:10 --> Output Class Initialized
INFO - 2023-01-10 06:36:10 --> Security Class Initialized
DEBUG - 2023-01-10 06:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:36:10 --> Input Class Initialized
INFO - 2023-01-10 06:36:10 --> Language Class Initialized
ERROR - 2023-01-10 06:36:10 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:36:11 --> Config Class Initialized
INFO - 2023-01-10 06:36:11 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:36:11 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:36:11 --> Utf8 Class Initialized
INFO - 2023-01-10 06:36:11 --> URI Class Initialized
INFO - 2023-01-10 06:36:11 --> Router Class Initialized
INFO - 2023-01-10 06:36:11 --> Output Class Initialized
INFO - 2023-01-10 06:36:11 --> Security Class Initialized
DEBUG - 2023-01-10 06:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:36:11 --> Input Class Initialized
INFO - 2023-01-10 06:36:11 --> Language Class Initialized
ERROR - 2023-01-10 06:36:11 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:38:12 --> Config Class Initialized
INFO - 2023-01-10 06:38:12 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:38:12 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:38:12 --> Utf8 Class Initialized
INFO - 2023-01-10 06:38:12 --> URI Class Initialized
INFO - 2023-01-10 06:38:12 --> Router Class Initialized
INFO - 2023-01-10 06:38:12 --> Output Class Initialized
INFO - 2023-01-10 06:38:12 --> Security Class Initialized
DEBUG - 2023-01-10 06:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:38:12 --> Input Class Initialized
INFO - 2023-01-10 06:38:12 --> Language Class Initialized
ERROR - 2023-01-10 06:38:12 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:38:13 --> Config Class Initialized
INFO - 2023-01-10 06:38:13 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:38:13 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:38:13 --> Utf8 Class Initialized
INFO - 2023-01-10 06:38:13 --> URI Class Initialized
INFO - 2023-01-10 06:38:13 --> Router Class Initialized
INFO - 2023-01-10 06:38:13 --> Output Class Initialized
INFO - 2023-01-10 06:38:13 --> Security Class Initialized
DEBUG - 2023-01-10 06:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:38:13 --> Input Class Initialized
INFO - 2023-01-10 06:38:13 --> Language Class Initialized
ERROR - 2023-01-10 06:38:13 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:39:07 --> Config Class Initialized
INFO - 2023-01-10 06:39:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:39:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:39:07 --> Utf8 Class Initialized
INFO - 2023-01-10 06:39:07 --> URI Class Initialized
INFO - 2023-01-10 06:39:07 --> Router Class Initialized
INFO - 2023-01-10 06:39:07 --> Output Class Initialized
INFO - 2023-01-10 06:39:07 --> Security Class Initialized
DEBUG - 2023-01-10 06:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:39:07 --> Input Class Initialized
INFO - 2023-01-10 06:39:07 --> Language Class Initialized
ERROR - 2023-01-10 06:39:07 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:39:07 --> Config Class Initialized
INFO - 2023-01-10 06:39:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:39:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:39:07 --> Utf8 Class Initialized
INFO - 2023-01-10 06:39:07 --> URI Class Initialized
INFO - 2023-01-10 06:39:07 --> Router Class Initialized
INFO - 2023-01-10 06:39:07 --> Output Class Initialized
INFO - 2023-01-10 06:39:07 --> Security Class Initialized
DEBUG - 2023-01-10 06:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:39:07 --> Input Class Initialized
INFO - 2023-01-10 06:39:07 --> Language Class Initialized
ERROR - 2023-01-10 06:39:07 --> 404 Page Not Found: Faviconico/index
INFO - 2023-01-10 06:41:04 --> Config Class Initialized
INFO - 2023-01-10 06:41:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:41:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:41:04 --> Utf8 Class Initialized
INFO - 2023-01-10 06:41:04 --> URI Class Initialized
INFO - 2023-01-10 06:41:04 --> Router Class Initialized
INFO - 2023-01-10 06:41:04 --> Output Class Initialized
INFO - 2023-01-10 06:41:04 --> Security Class Initialized
DEBUG - 2023-01-10 06:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:41:04 --> Input Class Initialized
INFO - 2023-01-10 06:41:04 --> Language Class Initialized
ERROR - 2023-01-10 06:41:04 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:41:05 --> Config Class Initialized
INFO - 2023-01-10 06:41:05 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:41:05 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:41:05 --> Utf8 Class Initialized
INFO - 2023-01-10 06:41:05 --> URI Class Initialized
INFO - 2023-01-10 06:41:05 --> Router Class Initialized
INFO - 2023-01-10 06:41:05 --> Output Class Initialized
INFO - 2023-01-10 06:41:05 --> Security Class Initialized
DEBUG - 2023-01-10 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:41:05 --> Input Class Initialized
INFO - 2023-01-10 06:41:05 --> Language Class Initialized
ERROR - 2023-01-10 06:41:05 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:42:10 --> Config Class Initialized
INFO - 2023-01-10 06:42:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:42:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:42:10 --> Utf8 Class Initialized
INFO - 2023-01-10 06:42:10 --> URI Class Initialized
INFO - 2023-01-10 06:42:10 --> Router Class Initialized
INFO - 2023-01-10 06:42:10 --> Output Class Initialized
INFO - 2023-01-10 06:42:10 --> Security Class Initialized
DEBUG - 2023-01-10 06:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:42:10 --> Input Class Initialized
INFO - 2023-01-10 06:42:10 --> Language Class Initialized
ERROR - 2023-01-10 06:42:10 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:52:17 --> Config Class Initialized
INFO - 2023-01-10 06:52:17 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:52:17 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:52:17 --> Utf8 Class Initialized
INFO - 2023-01-10 06:52:17 --> URI Class Initialized
INFO - 2023-01-10 06:52:17 --> Router Class Initialized
INFO - 2023-01-10 06:52:17 --> Output Class Initialized
INFO - 2023-01-10 06:52:17 --> Security Class Initialized
DEBUG - 2023-01-10 06:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:52:17 --> Input Class Initialized
INFO - 2023-01-10 06:52:17 --> Language Class Initialized
ERROR - 2023-01-10 06:52:17 --> 404 Page Not Found: /index
INFO - 2023-01-10 06:55:46 --> Config Class Initialized
INFO - 2023-01-10 06:55:46 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:55:46 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:55:46 --> Utf8 Class Initialized
INFO - 2023-01-10 06:55:46 --> URI Class Initialized
INFO - 2023-01-10 06:55:46 --> Router Class Initialized
INFO - 2023-01-10 06:55:46 --> Output Class Initialized
INFO - 2023-01-10 06:55:46 --> Security Class Initialized
DEBUG - 2023-01-10 06:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:55:46 --> Input Class Initialized
INFO - 2023-01-10 06:55:46 --> Language Class Initialized
INFO - 2023-01-10 06:55:46 --> Loader Class Initialized
INFO - 2023-01-10 06:55:46 --> Controller Class Initialized
DEBUG - 2023-01-10 06:55:46 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 06:55:46 --> Database Driver Class Initialized
ERROR - 2023-01-10 06:55:53 --> Unable to connect to the database
INFO - 2023-01-10 06:55:53 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-10 06:56:01 --> Config Class Initialized
INFO - 2023-01-10 06:56:01 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:56:01 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:56:01 --> Utf8 Class Initialized
INFO - 2023-01-10 06:56:01 --> URI Class Initialized
INFO - 2023-01-10 06:56:01 --> Router Class Initialized
INFO - 2023-01-10 06:56:01 --> Output Class Initialized
INFO - 2023-01-10 06:56:01 --> Security Class Initialized
DEBUG - 2023-01-10 06:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:56:01 --> Input Class Initialized
INFO - 2023-01-10 06:56:01 --> Language Class Initialized
INFO - 2023-01-10 06:56:01 --> Loader Class Initialized
INFO - 2023-01-10 06:56:01 --> Controller Class Initialized
DEBUG - 2023-01-10 06:56:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 06:56:01 --> Database Driver Class Initialized
ERROR - 2023-01-10 06:56:09 --> Unable to connect to the database
INFO - 2023-01-10 06:56:09 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-10 06:56:26 --> Config Class Initialized
INFO - 2023-01-10 06:56:26 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:56:26 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:56:26 --> Utf8 Class Initialized
INFO - 2023-01-10 06:56:26 --> URI Class Initialized
INFO - 2023-01-10 06:56:26 --> Router Class Initialized
INFO - 2023-01-10 06:56:26 --> Output Class Initialized
INFO - 2023-01-10 06:56:26 --> Security Class Initialized
DEBUG - 2023-01-10 06:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:56:26 --> Input Class Initialized
INFO - 2023-01-10 06:56:26 --> Language Class Initialized
INFO - 2023-01-10 06:56:26 --> Loader Class Initialized
INFO - 2023-01-10 06:56:26 --> Controller Class Initialized
INFO - 2023-01-10 06:56:26 --> Helper loaded: form_helper
INFO - 2023-01-10 06:56:26 --> Helper loaded: url_helper
DEBUG - 2023-01-10 06:56:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 06:56:26 --> Model "Change_model" initialized
INFO - 2023-01-10 06:56:47 --> Final output sent to browser
DEBUG - 2023-01-10 06:56:47 --> Total execution time: 21.2975
INFO - 2023-01-10 06:56:54 --> Config Class Initialized
INFO - 2023-01-10 06:56:54 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:56:54 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:56:54 --> Utf8 Class Initialized
INFO - 2023-01-10 06:56:54 --> URI Class Initialized
INFO - 2023-01-10 06:56:54 --> Router Class Initialized
INFO - 2023-01-10 06:56:54 --> Output Class Initialized
INFO - 2023-01-10 06:56:54 --> Security Class Initialized
DEBUG - 2023-01-10 06:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:56:54 --> Input Class Initialized
INFO - 2023-01-10 06:56:54 --> Language Class Initialized
INFO - 2023-01-10 06:56:54 --> Loader Class Initialized
INFO - 2023-01-10 06:56:54 --> Controller Class Initialized
INFO - 2023-01-10 06:56:54 --> Helper loaded: form_helper
INFO - 2023-01-10 06:56:54 --> Helper loaded: url_helper
DEBUG - 2023-01-10 06:56:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 06:56:54 --> Model "Change_model" initialized
INFO - 2023-01-10 06:57:16 --> Final output sent to browser
DEBUG - 2023-01-10 06:57:16 --> Total execution time: 21.3082
INFO - 2023-01-10 06:57:45 --> Config Class Initialized
INFO - 2023-01-10 06:57:45 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:57:45 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:57:45 --> Utf8 Class Initialized
INFO - 2023-01-10 06:57:45 --> URI Class Initialized
INFO - 2023-01-10 06:57:45 --> Router Class Initialized
INFO - 2023-01-10 06:57:45 --> Output Class Initialized
INFO - 2023-01-10 06:57:45 --> Security Class Initialized
DEBUG - 2023-01-10 06:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:57:45 --> Input Class Initialized
INFO - 2023-01-10 06:57:45 --> Language Class Initialized
INFO - 2023-01-10 06:57:45 --> Loader Class Initialized
INFO - 2023-01-10 06:57:45 --> Controller Class Initialized
INFO - 2023-01-10 06:57:45 --> Helper loaded: form_helper
INFO - 2023-01-10 06:57:45 --> Helper loaded: url_helper
DEBUG - 2023-01-10 06:57:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 06:58:03 --> Config Class Initialized
INFO - 2023-01-10 06:58:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:58:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:58:03 --> Utf8 Class Initialized
INFO - 2023-01-10 06:58:03 --> URI Class Initialized
INFO - 2023-01-10 06:58:03 --> Router Class Initialized
INFO - 2023-01-10 06:58:03 --> Output Class Initialized
INFO - 2023-01-10 06:58:03 --> Security Class Initialized
DEBUG - 2023-01-10 06:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:58:03 --> Input Class Initialized
INFO - 2023-01-10 06:58:03 --> Language Class Initialized
INFO - 2023-01-10 06:58:03 --> Loader Class Initialized
INFO - 2023-01-10 06:58:03 --> Controller Class Initialized
INFO - 2023-01-10 06:58:03 --> Helper loaded: form_helper
INFO - 2023-01-10 06:58:03 --> Helper loaded: url_helper
DEBUG - 2023-01-10 06:58:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 06:58:03 --> Model "Change_model" initialized
INFO - 2023-01-10 06:58:24 --> Final output sent to browser
DEBUG - 2023-01-10 06:58:24 --> Total execution time: 21.2720
INFO - 2023-01-10 06:59:40 --> Config Class Initialized
INFO - 2023-01-10 06:59:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:59:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:59:40 --> Utf8 Class Initialized
INFO - 2023-01-10 06:59:40 --> URI Class Initialized
INFO - 2023-01-10 06:59:40 --> Router Class Initialized
INFO - 2023-01-10 06:59:40 --> Output Class Initialized
INFO - 2023-01-10 06:59:40 --> Security Class Initialized
DEBUG - 2023-01-10 06:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:59:40 --> Input Class Initialized
INFO - 2023-01-10 06:59:40 --> Language Class Initialized
INFO - 2023-01-10 06:59:40 --> Loader Class Initialized
INFO - 2023-01-10 06:59:40 --> Controller Class Initialized
INFO - 2023-01-10 06:59:40 --> Helper loaded: form_helper
INFO - 2023-01-10 06:59:40 --> Helper loaded: url_helper
DEBUG - 2023-01-10 06:59:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 06:59:40 --> Model "Change_model" initialized
INFO - 2023-01-10 06:59:41 --> Config Class Initialized
INFO - 2023-01-10 06:59:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 06:59:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 06:59:41 --> Utf8 Class Initialized
INFO - 2023-01-10 06:59:41 --> URI Class Initialized
INFO - 2023-01-10 06:59:41 --> Router Class Initialized
INFO - 2023-01-10 06:59:41 --> Output Class Initialized
INFO - 2023-01-10 06:59:41 --> Security Class Initialized
DEBUG - 2023-01-10 06:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 06:59:41 --> Input Class Initialized
INFO - 2023-01-10 06:59:41 --> Language Class Initialized
INFO - 2023-01-10 06:59:41 --> Loader Class Initialized
INFO - 2023-01-10 06:59:41 --> Controller Class Initialized
INFO - 2023-01-10 06:59:41 --> Helper loaded: form_helper
INFO - 2023-01-10 06:59:41 --> Helper loaded: url_helper
DEBUG - 2023-01-10 06:59:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 06:59:41 --> Model "Change_model" initialized
INFO - 2023-01-10 07:00:00 --> Final output sent to browser
INFO - 2023-01-10 07:00:00 --> Final output sent to browser
DEBUG - 2023-01-10 07:00:00 --> Total execution time: 19.3428
DEBUG - 2023-01-10 07:00:00 --> Total execution time: 20.4637
INFO - 2023-01-10 07:00:04 --> Config Class Initialized
INFO - 2023-01-10 07:00:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:00:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:00:04 --> Utf8 Class Initialized
INFO - 2023-01-10 07:00:04 --> URI Class Initialized
INFO - 2023-01-10 07:00:04 --> Router Class Initialized
INFO - 2023-01-10 07:00:04 --> Output Class Initialized
INFO - 2023-01-10 07:00:04 --> Security Class Initialized
DEBUG - 2023-01-10 07:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:00:04 --> Input Class Initialized
INFO - 2023-01-10 07:00:04 --> Language Class Initialized
INFO - 2023-01-10 07:00:04 --> Loader Class Initialized
INFO - 2023-01-10 07:00:04 --> Controller Class Initialized
INFO - 2023-01-10 07:00:04 --> Helper loaded: form_helper
INFO - 2023-01-10 07:00:04 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:00:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:00:04 --> Model "Change_model" initialized
INFO - 2023-01-10 07:00:04 --> Config Class Initialized
INFO - 2023-01-10 07:00:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:00:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:00:04 --> Utf8 Class Initialized
INFO - 2023-01-10 07:00:04 --> URI Class Initialized
INFO - 2023-01-10 07:00:04 --> Router Class Initialized
INFO - 2023-01-10 07:00:04 --> Output Class Initialized
INFO - 2023-01-10 07:00:04 --> Security Class Initialized
DEBUG - 2023-01-10 07:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:00:04 --> Input Class Initialized
INFO - 2023-01-10 07:00:04 --> Language Class Initialized
INFO - 2023-01-10 07:00:04 --> Loader Class Initialized
INFO - 2023-01-10 07:00:04 --> Controller Class Initialized
INFO - 2023-01-10 07:00:04 --> Helper loaded: form_helper
INFO - 2023-01-10 07:00:04 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:00:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:00:04 --> Model "Change_model" initialized
INFO - 2023-01-10 07:00:25 --> Final output sent to browser
INFO - 2023-01-10 07:00:25 --> Final output sent to browser
DEBUG - 2023-01-10 07:00:25 --> Total execution time: 20.2849
DEBUG - 2023-01-10 07:00:25 --> Total execution time: 20.6456
INFO - 2023-01-10 07:00:35 --> Config Class Initialized
INFO - 2023-01-10 07:00:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:00:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:00:35 --> Utf8 Class Initialized
INFO - 2023-01-10 07:00:35 --> URI Class Initialized
INFO - 2023-01-10 07:00:35 --> Router Class Initialized
INFO - 2023-01-10 07:00:35 --> Output Class Initialized
INFO - 2023-01-10 07:00:35 --> Security Class Initialized
DEBUG - 2023-01-10 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:00:35 --> Input Class Initialized
INFO - 2023-01-10 07:00:35 --> Language Class Initialized
INFO - 2023-01-10 07:00:35 --> Loader Class Initialized
INFO - 2023-01-10 07:00:35 --> Controller Class Initialized
INFO - 2023-01-10 07:00:35 --> Helper loaded: form_helper
INFO - 2023-01-10 07:00:35 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:00:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:00:35 --> Model "Change_model" initialized
INFO - 2023-01-10 07:00:35 --> Config Class Initialized
INFO - 2023-01-10 07:00:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:00:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:00:35 --> Utf8 Class Initialized
INFO - 2023-01-10 07:00:35 --> URI Class Initialized
INFO - 2023-01-10 07:00:35 --> Router Class Initialized
INFO - 2023-01-10 07:00:35 --> Output Class Initialized
INFO - 2023-01-10 07:00:35 --> Security Class Initialized
DEBUG - 2023-01-10 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:00:35 --> Input Class Initialized
INFO - 2023-01-10 07:00:35 --> Language Class Initialized
INFO - 2023-01-10 07:00:35 --> Loader Class Initialized
INFO - 2023-01-10 07:00:35 --> Controller Class Initialized
INFO - 2023-01-10 07:00:35 --> Helper loaded: form_helper
INFO - 2023-01-10 07:00:35 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:00:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:00:35 --> Model "Change_model" initialized
INFO - 2023-01-10 07:02:18 --> Config Class Initialized
INFO - 2023-01-10 07:02:18 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:18 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:18 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:18 --> URI Class Initialized
INFO - 2023-01-10 07:02:18 --> Router Class Initialized
INFO - 2023-01-10 07:02:18 --> Output Class Initialized
INFO - 2023-01-10 07:02:18 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:18 --> Input Class Initialized
INFO - 2023-01-10 07:02:18 --> Language Class Initialized
INFO - 2023-01-10 07:02:18 --> Loader Class Initialized
INFO - 2023-01-10 07:02:18 --> Controller Class Initialized
INFO - 2023-01-10 07:02:18 --> Helper loaded: form_helper
INFO - 2023-01-10 07:02:18 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:02:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:18 --> Model "Change_model" initialized
INFO - 2023-01-10 07:02:19 --> Config Class Initialized
INFO - 2023-01-10 07:02:19 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:19 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:19 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:19 --> URI Class Initialized
INFO - 2023-01-10 07:02:19 --> Router Class Initialized
INFO - 2023-01-10 07:02:19 --> Output Class Initialized
INFO - 2023-01-10 07:02:19 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:19 --> Input Class Initialized
INFO - 2023-01-10 07:02:19 --> Language Class Initialized
INFO - 2023-01-10 07:02:19 --> Loader Class Initialized
INFO - 2023-01-10 07:02:19 --> Controller Class Initialized
INFO - 2023-01-10 07:02:19 --> Helper loaded: form_helper
INFO - 2023-01-10 07:02:19 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:02:19 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:19 --> Model "Change_model" initialized
INFO - 2023-01-10 07:02:29 --> Config Class Initialized
INFO - 2023-01-10 07:02:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:29 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:29 --> URI Class Initialized
INFO - 2023-01-10 07:02:29 --> Router Class Initialized
INFO - 2023-01-10 07:02:29 --> Output Class Initialized
INFO - 2023-01-10 07:02:29 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:29 --> Input Class Initialized
INFO - 2023-01-10 07:02:29 --> Language Class Initialized
INFO - 2023-01-10 07:02:29 --> Loader Class Initialized
INFO - 2023-01-10 07:02:29 --> Controller Class Initialized
INFO - 2023-01-10 07:02:29 --> Helper loaded: form_helper
INFO - 2023-01-10 07:02:29 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:02:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:29 --> Model "Change_model" initialized
INFO - 2023-01-10 07:02:29 --> Model "Grafana_model" initialized
INFO - 2023-01-10 07:02:29 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:29 --> Total execution time: 0.0657
INFO - 2023-01-10 07:02:29 --> Config Class Initialized
INFO - 2023-01-10 07:02:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:29 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:29 --> URI Class Initialized
INFO - 2023-01-10 07:02:29 --> Router Class Initialized
INFO - 2023-01-10 07:02:29 --> Output Class Initialized
INFO - 2023-01-10 07:02:29 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:29 --> Input Class Initialized
INFO - 2023-01-10 07:02:29 --> Language Class Initialized
INFO - 2023-01-10 07:02:29 --> Loader Class Initialized
INFO - 2023-01-10 07:02:29 --> Controller Class Initialized
INFO - 2023-01-10 07:02:29 --> Helper loaded: form_helper
INFO - 2023-01-10 07:02:29 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:02:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:29 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:29 --> Total execution time: 0.0136
INFO - 2023-01-10 07:02:29 --> Config Class Initialized
INFO - 2023-01-10 07:02:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:29 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:29 --> URI Class Initialized
INFO - 2023-01-10 07:02:29 --> Router Class Initialized
INFO - 2023-01-10 07:02:29 --> Output Class Initialized
INFO - 2023-01-10 07:02:29 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:29 --> Input Class Initialized
INFO - 2023-01-10 07:02:29 --> Language Class Initialized
INFO - 2023-01-10 07:02:29 --> Loader Class Initialized
INFO - 2023-01-10 07:02:29 --> Controller Class Initialized
INFO - 2023-01-10 07:02:29 --> Helper loaded: form_helper
INFO - 2023-01-10 07:02:29 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:02:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:29 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:29 --> Model "Login_model" initialized
INFO - 2023-01-10 07:02:29 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:29 --> Total execution time: 0.0464
INFO - 2023-01-10 07:02:41 --> Config Class Initialized
INFO - 2023-01-10 07:02:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:41 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:41 --> URI Class Initialized
INFO - 2023-01-10 07:02:41 --> Router Class Initialized
INFO - 2023-01-10 07:02:41 --> Output Class Initialized
INFO - 2023-01-10 07:02:41 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:41 --> Input Class Initialized
INFO - 2023-01-10 07:02:41 --> Language Class Initialized
INFO - 2023-01-10 07:02:41 --> Loader Class Initialized
INFO - 2023-01-10 07:02:41 --> Controller Class Initialized
INFO - 2023-01-10 07:02:41 --> Helper loaded: form_helper
INFO - 2023-01-10 07:02:41 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:41 --> Model "Change_model" initialized
INFO - 2023-01-10 07:02:41 --> Model "Grafana_model" initialized
INFO - 2023-01-10 07:02:41 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:41 --> Total execution time: 0.1246
INFO - 2023-01-10 07:02:41 --> Config Class Initialized
INFO - 2023-01-10 07:02:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:41 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:41 --> URI Class Initialized
INFO - 2023-01-10 07:02:41 --> Router Class Initialized
INFO - 2023-01-10 07:02:41 --> Output Class Initialized
INFO - 2023-01-10 07:02:41 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:41 --> Input Class Initialized
INFO - 2023-01-10 07:02:41 --> Language Class Initialized
INFO - 2023-01-10 07:02:41 --> Loader Class Initialized
INFO - 2023-01-10 07:02:41 --> Controller Class Initialized
INFO - 2023-01-10 07:02:41 --> Helper loaded: form_helper
INFO - 2023-01-10 07:02:41 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:41 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:41 --> Total execution time: 0.1267
INFO - 2023-01-10 07:02:41 --> Config Class Initialized
INFO - 2023-01-10 07:02:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:41 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:41 --> URI Class Initialized
INFO - 2023-01-10 07:02:41 --> Router Class Initialized
INFO - 2023-01-10 07:02:41 --> Output Class Initialized
INFO - 2023-01-10 07:02:41 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:41 --> Input Class Initialized
INFO - 2023-01-10 07:02:41 --> Language Class Initialized
INFO - 2023-01-10 07:02:41 --> Loader Class Initialized
INFO - 2023-01-10 07:02:41 --> Controller Class Initialized
INFO - 2023-01-10 07:02:41 --> Helper loaded: form_helper
INFO - 2023-01-10 07:02:41 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:41 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:41 --> Model "Login_model" initialized
INFO - 2023-01-10 07:02:41 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:41 --> Total execution time: 0.0249
INFO - 2023-01-10 07:02:41 --> Config Class Initialized
INFO - 2023-01-10 07:02:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:41 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:41 --> URI Class Initialized
INFO - 2023-01-10 07:02:41 --> Router Class Initialized
INFO - 2023-01-10 07:02:41 --> Output Class Initialized
INFO - 2023-01-10 07:02:41 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:41 --> Input Class Initialized
INFO - 2023-01-10 07:02:41 --> Language Class Initialized
INFO - 2023-01-10 07:02:41 --> Loader Class Initialized
INFO - 2023-01-10 07:02:41 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:41 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:41 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:42 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:42 --> Total execution time: 0.0911
INFO - 2023-01-10 07:02:42 --> Config Class Initialized
INFO - 2023-01-10 07:02:42 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:42 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:42 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:42 --> URI Class Initialized
INFO - 2023-01-10 07:02:42 --> Router Class Initialized
INFO - 2023-01-10 07:02:42 --> Output Class Initialized
INFO - 2023-01-10 07:02:42 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:42 --> Input Class Initialized
INFO - 2023-01-10 07:02:42 --> Language Class Initialized
INFO - 2023-01-10 07:02:42 --> Loader Class Initialized
INFO - 2023-01-10 07:02:42 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:42 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:42 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:42 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:42 --> Total execution time: 0.0444
INFO - 2023-01-10 07:02:43 --> Config Class Initialized
INFO - 2023-01-10 07:02:43 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:43 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:43 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:43 --> URI Class Initialized
INFO - 2023-01-10 07:02:43 --> Router Class Initialized
INFO - 2023-01-10 07:02:43 --> Output Class Initialized
INFO - 2023-01-10 07:02:43 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:43 --> Input Class Initialized
INFO - 2023-01-10 07:02:43 --> Language Class Initialized
INFO - 2023-01-10 07:02:43 --> Loader Class Initialized
INFO - 2023-01-10 07:02:43 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:43 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:43 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:43 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:43 --> Total execution time: 0.1657
INFO - 2023-01-10 07:02:43 --> Config Class Initialized
INFO - 2023-01-10 07:02:43 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:43 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:43 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:43 --> URI Class Initialized
INFO - 2023-01-10 07:02:43 --> Router Class Initialized
INFO - 2023-01-10 07:02:43 --> Output Class Initialized
INFO - 2023-01-10 07:02:43 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:43 --> Input Class Initialized
INFO - 2023-01-10 07:02:43 --> Language Class Initialized
INFO - 2023-01-10 07:02:43 --> Loader Class Initialized
INFO - 2023-01-10 07:02:43 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:43 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:43 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:43 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:43 --> Total execution time: 0.0605
INFO - 2023-01-10 07:02:54 --> Config Class Initialized
INFO - 2023-01-10 07:02:54 --> Config Class Initialized
INFO - 2023-01-10 07:02:54 --> Hooks Class Initialized
INFO - 2023-01-10 07:02:54 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:02:54 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:54 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:54 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:54 --> URI Class Initialized
INFO - 2023-01-10 07:02:54 --> URI Class Initialized
INFO - 2023-01-10 07:02:54 --> Router Class Initialized
INFO - 2023-01-10 07:02:54 --> Router Class Initialized
INFO - 2023-01-10 07:02:54 --> Output Class Initialized
INFO - 2023-01-10 07:02:54 --> Output Class Initialized
INFO - 2023-01-10 07:02:54 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:54 --> Input Class Initialized
INFO - 2023-01-10 07:02:54 --> Language Class Initialized
INFO - 2023-01-10 07:02:54 --> Security Class Initialized
INFO - 2023-01-10 07:02:54 --> Loader Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:54 --> Input Class Initialized
INFO - 2023-01-10 07:02:54 --> Controller Class Initialized
INFO - 2023-01-10 07:02:54 --> Language Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:54 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:54 --> Loader Class Initialized
INFO - 2023-01-10 07:02:54 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:54 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:54 --> Total execution time: 0.0247
INFO - 2023-01-10 07:02:54 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:54 --> Config Class Initialized
INFO - 2023-01-10 07:02:54 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:54 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:54 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:54 --> URI Class Initialized
INFO - 2023-01-10 07:02:54 --> Router Class Initialized
INFO - 2023-01-10 07:02:54 --> Output Class Initialized
INFO - 2023-01-10 07:02:54 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:54 --> Input Class Initialized
INFO - 2023-01-10 07:02:54 --> Language Class Initialized
INFO - 2023-01-10 07:02:54 --> Final output sent to browser
INFO - 2023-01-10 07:02:54 --> Loader Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Total execution time: 0.0732
INFO - 2023-01-10 07:02:54 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:54 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:54 --> Config Class Initialized
INFO - 2023-01-10 07:02:54 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:54 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:54 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:54 --> Model "Login_model" initialized
INFO - 2023-01-10 07:02:54 --> URI Class Initialized
INFO - 2023-01-10 07:02:54 --> Router Class Initialized
INFO - 2023-01-10 07:02:54 --> Output Class Initialized
INFO - 2023-01-10 07:02:54 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:54 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:54 --> Input Class Initialized
INFO - 2023-01-10 07:02:54 --> Language Class Initialized
INFO - 2023-01-10 07:02:54 --> Loader Class Initialized
INFO - 2023-01-10 07:02:54 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:54 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:54 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:54 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:54 --> Total execution time: 0.0677
INFO - 2023-01-10 07:02:54 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:54 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:54 --> Total execution time: 0.0655
INFO - 2023-01-10 07:02:57 --> Config Class Initialized
INFO - 2023-01-10 07:02:57 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:57 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:57 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:57 --> URI Class Initialized
INFO - 2023-01-10 07:02:57 --> Router Class Initialized
INFO - 2023-01-10 07:02:57 --> Output Class Initialized
INFO - 2023-01-10 07:02:57 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:57 --> Input Class Initialized
INFO - 2023-01-10 07:02:57 --> Language Class Initialized
INFO - 2023-01-10 07:02:57 --> Loader Class Initialized
INFO - 2023-01-10 07:02:57 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:57 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:57 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:57 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:57 --> Total execution time: 0.2586
INFO - 2023-01-10 07:02:57 --> Config Class Initialized
INFO - 2023-01-10 07:02:57 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:02:57 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:57 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:57 --> URI Class Initialized
INFO - 2023-01-10 07:02:57 --> Router Class Initialized
INFO - 2023-01-10 07:02:57 --> Output Class Initialized
INFO - 2023-01-10 07:02:57 --> Security Class Initialized
DEBUG - 2023-01-10 07:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:57 --> Input Class Initialized
INFO - 2023-01-10 07:02:57 --> Language Class Initialized
INFO - 2023-01-10 07:02:57 --> Loader Class Initialized
INFO - 2023-01-10 07:02:57 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:57 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:57 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:57 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:57 --> Total execution time: 0.1704
INFO - 2023-01-10 07:02:58 --> Config Class Initialized
INFO - 2023-01-10 07:02:58 --> Hooks Class Initialized
INFO - 2023-01-10 07:02:58 --> Config Class Initialized
DEBUG - 2023-01-10 07:02:58 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:58 --> Hooks Class Initialized
INFO - 2023-01-10 07:02:58 --> Utf8 Class Initialized
DEBUG - 2023-01-10 07:02:58 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:02:58 --> URI Class Initialized
INFO - 2023-01-10 07:02:58 --> Utf8 Class Initialized
INFO - 2023-01-10 07:02:58 --> Router Class Initialized
INFO - 2023-01-10 07:02:58 --> URI Class Initialized
INFO - 2023-01-10 07:02:58 --> Output Class Initialized
INFO - 2023-01-10 07:02:58 --> Router Class Initialized
INFO - 2023-01-10 07:02:58 --> Security Class Initialized
INFO - 2023-01-10 07:02:58 --> Output Class Initialized
DEBUG - 2023-01-10 07:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:58 --> Security Class Initialized
INFO - 2023-01-10 07:02:58 --> Input Class Initialized
DEBUG - 2023-01-10 07:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:02:58 --> Language Class Initialized
INFO - 2023-01-10 07:02:58 --> Input Class Initialized
INFO - 2023-01-10 07:02:58 --> Language Class Initialized
INFO - 2023-01-10 07:02:58 --> Loader Class Initialized
INFO - 2023-01-10 07:02:58 --> Loader Class Initialized
INFO - 2023-01-10 07:02:58 --> Controller Class Initialized
INFO - 2023-01-10 07:02:58 --> Controller Class Initialized
DEBUG - 2023-01-10 07:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:02:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:02:58 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:58 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:58 --> Model "Login_model" initialized
INFO - 2023-01-10 07:02:58 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:02:58 --> Database Driver Class Initialized
INFO - 2023-01-10 07:02:58 --> Final output sent to browser
DEBUG - 2023-01-10 07:02:58 --> Total execution time: 0.2250
INFO - 2023-01-10 07:03:00 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:00 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:00 --> Total execution time: 1.3646
INFO - 2023-01-10 07:03:02 --> Config Class Initialized
INFO - 2023-01-10 07:03:02 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:02 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:02 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:02 --> URI Class Initialized
INFO - 2023-01-10 07:03:02 --> Router Class Initialized
INFO - 2023-01-10 07:03:02 --> Output Class Initialized
INFO - 2023-01-10 07:03:02 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:02 --> Input Class Initialized
INFO - 2023-01-10 07:03:02 --> Language Class Initialized
INFO - 2023-01-10 07:03:02 --> Loader Class Initialized
INFO - 2023-01-10 07:03:02 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:02 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:02 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:02 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:02 --> Total execution time: 0.0491
INFO - 2023-01-10 07:03:02 --> Config Class Initialized
INFO - 2023-01-10 07:03:02 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:02 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:02 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:02 --> URI Class Initialized
INFO - 2023-01-10 07:03:02 --> Router Class Initialized
INFO - 2023-01-10 07:03:02 --> Output Class Initialized
INFO - 2023-01-10 07:03:02 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:02 --> Input Class Initialized
INFO - 2023-01-10 07:03:02 --> Language Class Initialized
INFO - 2023-01-10 07:03:02 --> Loader Class Initialized
INFO - 2023-01-10 07:03:02 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:02 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:02 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:02 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:02 --> Total execution time: 0.0629
INFO - 2023-01-10 07:03:03 --> Config Class Initialized
INFO - 2023-01-10 07:03:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:03 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:03 --> URI Class Initialized
INFO - 2023-01-10 07:03:03 --> Router Class Initialized
INFO - 2023-01-10 07:03:03 --> Output Class Initialized
INFO - 2023-01-10 07:03:03 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:03 --> Input Class Initialized
INFO - 2023-01-10 07:03:03 --> Language Class Initialized
INFO - 2023-01-10 07:03:03 --> Loader Class Initialized
INFO - 2023-01-10 07:03:03 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:03 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:03 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:03 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:03 --> Total execution time: 0.0621
INFO - 2023-01-10 07:03:03 --> Config Class Initialized
INFO - 2023-01-10 07:03:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:03 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:03 --> URI Class Initialized
INFO - 2023-01-10 07:03:03 --> Router Class Initialized
INFO - 2023-01-10 07:03:03 --> Output Class Initialized
INFO - 2023-01-10 07:03:03 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:03 --> Input Class Initialized
INFO - 2023-01-10 07:03:03 --> Language Class Initialized
INFO - 2023-01-10 07:03:03 --> Loader Class Initialized
INFO - 2023-01-10 07:03:03 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:03 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:03 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:03 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:03 --> Total execution time: 0.0243
INFO - 2023-01-10 07:03:09 --> Config Class Initialized
INFO - 2023-01-10 07:03:09 --> Config Class Initialized
INFO - 2023-01-10 07:03:09 --> Hooks Class Initialized
INFO - 2023-01-10 07:03:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:03:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:09 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:09 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:09 --> URI Class Initialized
INFO - 2023-01-10 07:03:09 --> URI Class Initialized
INFO - 2023-01-10 07:03:09 --> Router Class Initialized
INFO - 2023-01-10 07:03:09 --> Router Class Initialized
INFO - 2023-01-10 07:03:09 --> Output Class Initialized
INFO - 2023-01-10 07:03:09 --> Output Class Initialized
INFO - 2023-01-10 07:03:09 --> Security Class Initialized
INFO - 2023-01-10 07:03:09 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-10 07:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:09 --> Input Class Initialized
INFO - 2023-01-10 07:03:09 --> Input Class Initialized
INFO - 2023-01-10 07:03:09 --> Language Class Initialized
INFO - 2023-01-10 07:03:09 --> Language Class Initialized
INFO - 2023-01-10 07:03:09 --> Loader Class Initialized
INFO - 2023-01-10 07:03:09 --> Loader Class Initialized
INFO - 2023-01-10 07:03:09 --> Controller Class Initialized
INFO - 2023-01-10 07:03:09 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:03:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:09 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:09 --> Total execution time: 0.0261
INFO - 2023-01-10 07:03:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:09 --> Config Class Initialized
INFO - 2023-01-10 07:03:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:09 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:09 --> URI Class Initialized
INFO - 2023-01-10 07:03:09 --> Router Class Initialized
INFO - 2023-01-10 07:03:09 --> Output Class Initialized
INFO - 2023-01-10 07:03:09 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:09 --> Input Class Initialized
INFO - 2023-01-10 07:03:09 --> Language Class Initialized
INFO - 2023-01-10 07:03:09 --> Loader Class Initialized
INFO - 2023-01-10 07:03:09 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:09 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:09 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:09 --> Total execution time: 0.0504
INFO - 2023-01-10 07:03:09 --> Model "Login_model" initialized
INFO - 2023-01-10 07:03:09 --> Config Class Initialized
INFO - 2023-01-10 07:03:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:09 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:09 --> URI Class Initialized
INFO - 2023-01-10 07:03:09 --> Router Class Initialized
INFO - 2023-01-10 07:03:09 --> Output Class Initialized
INFO - 2023-01-10 07:03:09 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:09 --> Input Class Initialized
INFO - 2023-01-10 07:03:09 --> Language Class Initialized
INFO - 2023-01-10 07:03:09 --> Loader Class Initialized
INFO - 2023-01-10 07:03:09 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:09 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:09 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:09 --> Total execution time: 0.0445
INFO - 2023-01-10 07:03:09 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:09 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:09 --> Total execution time: 0.0801
INFO - 2023-01-10 07:03:10 --> Config Class Initialized
INFO - 2023-01-10 07:03:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:10 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:10 --> URI Class Initialized
INFO - 2023-01-10 07:03:10 --> Router Class Initialized
INFO - 2023-01-10 07:03:10 --> Output Class Initialized
INFO - 2023-01-10 07:03:10 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:10 --> Input Class Initialized
INFO - 2023-01-10 07:03:10 --> Language Class Initialized
INFO - 2023-01-10 07:03:10 --> Loader Class Initialized
INFO - 2023-01-10 07:03:10 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:10 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:10 --> Total execution time: 0.0290
INFO - 2023-01-10 07:03:10 --> Config Class Initialized
INFO - 2023-01-10 07:03:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:10 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:10 --> URI Class Initialized
INFO - 2023-01-10 07:03:10 --> Router Class Initialized
INFO - 2023-01-10 07:03:10 --> Output Class Initialized
INFO - 2023-01-10 07:03:10 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:10 --> Input Class Initialized
INFO - 2023-01-10 07:03:10 --> Language Class Initialized
INFO - 2023-01-10 07:03:10 --> Loader Class Initialized
INFO - 2023-01-10 07:03:10 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:10 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:10 --> Total execution time: 0.0624
INFO - 2023-01-10 07:03:16 --> Config Class Initialized
INFO - 2023-01-10 07:03:16 --> Hooks Class Initialized
INFO - 2023-01-10 07:03:16 --> Config Class Initialized
INFO - 2023-01-10 07:03:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:16 --> URI Class Initialized
DEBUG - 2023-01-10 07:03:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:16 --> Router Class Initialized
INFO - 2023-01-10 07:03:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:16 --> Output Class Initialized
INFO - 2023-01-10 07:03:16 --> URI Class Initialized
INFO - 2023-01-10 07:03:16 --> Security Class Initialized
INFO - 2023-01-10 07:03:16 --> Router Class Initialized
DEBUG - 2023-01-10 07:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:16 --> Output Class Initialized
INFO - 2023-01-10 07:03:16 --> Input Class Initialized
INFO - 2023-01-10 07:03:16 --> Security Class Initialized
INFO - 2023-01-10 07:03:16 --> Language Class Initialized
DEBUG - 2023-01-10 07:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:16 --> Input Class Initialized
INFO - 2023-01-10 07:03:16 --> Loader Class Initialized
INFO - 2023-01-10 07:03:16 --> Language Class Initialized
INFO - 2023-01-10 07:03:16 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:16 --> Loader Class Initialized
INFO - 2023-01-10 07:03:16 --> Controller Class Initialized
INFO - 2023-01-10 07:03:16 --> Database Driver Class Initialized
DEBUG - 2023-01-10 07:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:16 --> Total execution time: 0.0924
INFO - 2023-01-10 07:03:16 --> Config Class Initialized
INFO - 2023-01-10 07:03:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:16 --> URI Class Initialized
INFO - 2023-01-10 07:03:16 --> Router Class Initialized
INFO - 2023-01-10 07:03:16 --> Output Class Initialized
INFO - 2023-01-10 07:03:16 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:16 --> Input Class Initialized
INFO - 2023-01-10 07:03:16 --> Language Class Initialized
INFO - 2023-01-10 07:03:16 --> Loader Class Initialized
INFO - 2023-01-10 07:03:16 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:16 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:16 --> Total execution time: 0.1622
INFO - 2023-01-10 07:03:16 --> Model "Login_model" initialized
INFO - 2023-01-10 07:03:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:16 --> Config Class Initialized
INFO - 2023-01-10 07:03:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:16 --> URI Class Initialized
INFO - 2023-01-10 07:03:16 --> Router Class Initialized
INFO - 2023-01-10 07:03:16 --> Output Class Initialized
INFO - 2023-01-10 07:03:16 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:16 --> Input Class Initialized
INFO - 2023-01-10 07:03:16 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:16 --> Language Class Initialized
INFO - 2023-01-10 07:03:16 --> Loader Class Initialized
INFO - 2023-01-10 07:03:16 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:16 --> Total execution time: 0.1498
INFO - 2023-01-10 07:03:16 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:16 --> Total execution time: 0.1830
INFO - 2023-01-10 07:03:21 --> Config Class Initialized
INFO - 2023-01-10 07:03:21 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:21 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:21 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:21 --> URI Class Initialized
INFO - 2023-01-10 07:03:21 --> Router Class Initialized
INFO - 2023-01-10 07:03:21 --> Output Class Initialized
INFO - 2023-01-10 07:03:21 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:21 --> Input Class Initialized
INFO - 2023-01-10 07:03:21 --> Language Class Initialized
INFO - 2023-01-10 07:03:21 --> Loader Class Initialized
INFO - 2023-01-10 07:03:21 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:21 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:21 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:21 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:21 --> Total execution time: 0.1486
INFO - 2023-01-10 07:03:21 --> Config Class Initialized
INFO - 2023-01-10 07:03:21 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:21 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:21 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:21 --> URI Class Initialized
INFO - 2023-01-10 07:03:21 --> Router Class Initialized
INFO - 2023-01-10 07:03:21 --> Output Class Initialized
INFO - 2023-01-10 07:03:21 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:21 --> Input Class Initialized
INFO - 2023-01-10 07:03:21 --> Language Class Initialized
INFO - 2023-01-10 07:03:21 --> Loader Class Initialized
INFO - 2023-01-10 07:03:21 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:21 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:21 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:21 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:21 --> Total execution time: 0.0894
INFO - 2023-01-10 07:03:22 --> Config Class Initialized
INFO - 2023-01-10 07:03:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:22 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:22 --> URI Class Initialized
INFO - 2023-01-10 07:03:22 --> Router Class Initialized
INFO - 2023-01-10 07:03:22 --> Output Class Initialized
INFO - 2023-01-10 07:03:22 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:22 --> Input Class Initialized
INFO - 2023-01-10 07:03:22 --> Language Class Initialized
INFO - 2023-01-10 07:03:22 --> Loader Class Initialized
INFO - 2023-01-10 07:03:22 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:22 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:22 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:22 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:22 --> Total execution time: 0.1109
INFO - 2023-01-10 07:03:22 --> Config Class Initialized
INFO - 2023-01-10 07:03:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:03:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:03:22 --> Utf8 Class Initialized
INFO - 2023-01-10 07:03:22 --> URI Class Initialized
INFO - 2023-01-10 07:03:22 --> Router Class Initialized
INFO - 2023-01-10 07:03:22 --> Output Class Initialized
INFO - 2023-01-10 07:03:22 --> Security Class Initialized
DEBUG - 2023-01-10 07:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:03:22 --> Input Class Initialized
INFO - 2023-01-10 07:03:22 --> Language Class Initialized
INFO - 2023-01-10 07:03:22 --> Loader Class Initialized
INFO - 2023-01-10 07:03:22 --> Controller Class Initialized
DEBUG - 2023-01-10 07:03:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:03:22 --> Database Driver Class Initialized
INFO - 2023-01-10 07:03:22 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:03:22 --> Final output sent to browser
DEBUG - 2023-01-10 07:03:22 --> Total execution time: 0.0390
INFO - 2023-01-10 07:04:43 --> Config Class Initialized
INFO - 2023-01-10 07:04:43 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:04:43 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:04:43 --> Utf8 Class Initialized
INFO - 2023-01-10 07:04:43 --> URI Class Initialized
INFO - 2023-01-10 07:04:43 --> Router Class Initialized
INFO - 2023-01-10 07:04:43 --> Output Class Initialized
INFO - 2023-01-10 07:04:43 --> Security Class Initialized
DEBUG - 2023-01-10 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:04:43 --> Input Class Initialized
INFO - 2023-01-10 07:04:43 --> Language Class Initialized
INFO - 2023-01-10 07:04:43 --> Loader Class Initialized
INFO - 2023-01-10 07:04:43 --> Controller Class Initialized
DEBUG - 2023-01-10 07:04:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:04:43 --> Database Driver Class Initialized
INFO - 2023-01-10 07:04:43 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:04:43 --> Final output sent to browser
DEBUG - 2023-01-10 07:04:43 --> Total execution time: 0.0569
INFO - 2023-01-10 07:04:43 --> Config Class Initialized
INFO - 2023-01-10 07:04:43 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:04:43 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:04:43 --> Utf8 Class Initialized
INFO - 2023-01-10 07:04:43 --> URI Class Initialized
INFO - 2023-01-10 07:04:43 --> Router Class Initialized
INFO - 2023-01-10 07:04:43 --> Output Class Initialized
INFO - 2023-01-10 07:04:43 --> Security Class Initialized
DEBUG - 2023-01-10 07:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:04:43 --> Input Class Initialized
INFO - 2023-01-10 07:04:43 --> Language Class Initialized
INFO - 2023-01-10 07:04:43 --> Loader Class Initialized
INFO - 2023-01-10 07:04:43 --> Controller Class Initialized
DEBUG - 2023-01-10 07:04:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:04:43 --> Database Driver Class Initialized
INFO - 2023-01-10 07:04:43 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:04:43 --> Final output sent to browser
DEBUG - 2023-01-10 07:04:44 --> Total execution time: 0.0757
INFO - 2023-01-10 07:16:15 --> Config Class Initialized
INFO - 2023-01-10 07:16:15 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:16:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:16:15 --> Utf8 Class Initialized
INFO - 2023-01-10 07:16:15 --> URI Class Initialized
INFO - 2023-01-10 07:16:15 --> Router Class Initialized
INFO - 2023-01-10 07:16:15 --> Output Class Initialized
INFO - 2023-01-10 07:16:15 --> Security Class Initialized
DEBUG - 2023-01-10 07:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:16:15 --> Input Class Initialized
INFO - 2023-01-10 07:16:15 --> Language Class Initialized
INFO - 2023-01-10 07:16:15 --> Loader Class Initialized
INFO - 2023-01-10 07:16:15 --> Controller Class Initialized
INFO - 2023-01-10 07:16:15 --> Helper loaded: form_helper
INFO - 2023-01-10 07:16:15 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:16:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:16:15 --> Model "Change_model" initialized
INFO - 2023-01-10 07:16:15 --> Model "Grafana_model" initialized
INFO - 2023-01-10 07:16:15 --> Final output sent to browser
DEBUG - 2023-01-10 07:16:15 --> Total execution time: 0.0383
INFO - 2023-01-10 07:16:15 --> Config Class Initialized
INFO - 2023-01-10 07:16:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:16:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:16:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:16:16 --> URI Class Initialized
INFO - 2023-01-10 07:16:16 --> Router Class Initialized
INFO - 2023-01-10 07:16:16 --> Output Class Initialized
INFO - 2023-01-10 07:16:16 --> Security Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:16:16 --> Input Class Initialized
INFO - 2023-01-10 07:16:16 --> Language Class Initialized
INFO - 2023-01-10 07:16:16 --> Loader Class Initialized
INFO - 2023-01-10 07:16:16 --> Controller Class Initialized
INFO - 2023-01-10 07:16:16 --> Helper loaded: form_helper
INFO - 2023-01-10 07:16:16 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:16:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:16:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:16:16 --> Total execution time: 0.0433
INFO - 2023-01-10 07:16:16 --> Config Class Initialized
INFO - 2023-01-10 07:16:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:16:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:16:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:16:16 --> URI Class Initialized
INFO - 2023-01-10 07:16:16 --> Router Class Initialized
INFO - 2023-01-10 07:16:16 --> Output Class Initialized
INFO - 2023-01-10 07:16:16 --> Security Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:16:16 --> Input Class Initialized
INFO - 2023-01-10 07:16:16 --> Language Class Initialized
INFO - 2023-01-10 07:16:16 --> Loader Class Initialized
INFO - 2023-01-10 07:16:16 --> Controller Class Initialized
INFO - 2023-01-10 07:16:16 --> Helper loaded: form_helper
INFO - 2023-01-10 07:16:16 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:16:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:16:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:16:16 --> Model "Login_model" initialized
INFO - 2023-01-10 07:16:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:16:16 --> Total execution time: 0.0188
INFO - 2023-01-10 07:16:16 --> Config Class Initialized
INFO - 2023-01-10 07:16:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:16:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:16:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:16:16 --> URI Class Initialized
INFO - 2023-01-10 07:16:16 --> Router Class Initialized
INFO - 2023-01-10 07:16:16 --> Output Class Initialized
INFO - 2023-01-10 07:16:16 --> Security Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:16:16 --> Input Class Initialized
INFO - 2023-01-10 07:16:16 --> Language Class Initialized
INFO - 2023-01-10 07:16:16 --> Loader Class Initialized
INFO - 2023-01-10 07:16:16 --> Controller Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:16:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:16:16 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:16:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:16:16 --> Total execution time: 0.0198
INFO - 2023-01-10 07:16:16 --> Config Class Initialized
INFO - 2023-01-10 07:16:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:16:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:16:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:16:16 --> URI Class Initialized
INFO - 2023-01-10 07:16:16 --> Router Class Initialized
INFO - 2023-01-10 07:16:16 --> Output Class Initialized
INFO - 2023-01-10 07:16:16 --> Security Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:16:16 --> Input Class Initialized
INFO - 2023-01-10 07:16:16 --> Language Class Initialized
INFO - 2023-01-10 07:16:16 --> Loader Class Initialized
INFO - 2023-01-10 07:16:16 --> Controller Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:16:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:16:16 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:16:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:16:16 --> Total execution time: 0.0243
INFO - 2023-01-10 07:16:16 --> Config Class Initialized
INFO - 2023-01-10 07:16:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:16:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:16:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:16:16 --> URI Class Initialized
INFO - 2023-01-10 07:16:16 --> Router Class Initialized
INFO - 2023-01-10 07:16:16 --> Output Class Initialized
INFO - 2023-01-10 07:16:16 --> Security Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:16:16 --> Input Class Initialized
INFO - 2023-01-10 07:16:16 --> Language Class Initialized
INFO - 2023-01-10 07:16:16 --> Loader Class Initialized
INFO - 2023-01-10 07:16:16 --> Controller Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:16:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:16:16 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:16:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:16:16 --> Model "Login_model" initialized
INFO - 2023-01-10 07:16:16 --> Final output sent to browser
DEBUG - 2023-01-10 07:16:16 --> Total execution time: 0.0740
INFO - 2023-01-10 07:16:16 --> Config Class Initialized
INFO - 2023-01-10 07:16:16 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:16:16 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:16:16 --> Utf8 Class Initialized
INFO - 2023-01-10 07:16:16 --> URI Class Initialized
INFO - 2023-01-10 07:16:16 --> Router Class Initialized
INFO - 2023-01-10 07:16:16 --> Output Class Initialized
INFO - 2023-01-10 07:16:16 --> Security Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:16:16 --> Input Class Initialized
INFO - 2023-01-10 07:16:16 --> Language Class Initialized
INFO - 2023-01-10 07:16:16 --> Loader Class Initialized
INFO - 2023-01-10 07:16:16 --> Controller Class Initialized
DEBUG - 2023-01-10 07:16:16 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:16:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:16:16 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:16:16 --> Database Driver Class Initialized
INFO - 2023-01-10 07:16:16 --> Model "Login_model" initialized
INFO - 2023-01-10 07:16:17 --> Final output sent to browser
DEBUG - 2023-01-10 07:16:17 --> Total execution time: 0.2130
INFO - 2023-01-10 07:17:22 --> Config Class Initialized
INFO - 2023-01-10 07:17:22 --> Config Class Initialized
INFO - 2023-01-10 07:17:22 --> Hooks Class Initialized
INFO - 2023-01-10 07:17:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:17:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:17:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:17:22 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:22 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:22 --> URI Class Initialized
INFO - 2023-01-10 07:17:22 --> URI Class Initialized
INFO - 2023-01-10 07:17:22 --> Router Class Initialized
INFO - 2023-01-10 07:17:22 --> Output Class Initialized
INFO - 2023-01-10 07:17:22 --> Router Class Initialized
INFO - 2023-01-10 07:17:22 --> Security Class Initialized
INFO - 2023-01-10 07:17:22 --> Output Class Initialized
DEBUG - 2023-01-10 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:22 --> Security Class Initialized
INFO - 2023-01-10 07:17:22 --> Input Class Initialized
DEBUG - 2023-01-10 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:22 --> Input Class Initialized
INFO - 2023-01-10 07:17:22 --> Language Class Initialized
INFO - 2023-01-10 07:17:22 --> Language Class Initialized
INFO - 2023-01-10 07:17:22 --> Loader Class Initialized
INFO - 2023-01-10 07:17:22 --> Loader Class Initialized
INFO - 2023-01-10 07:17:22 --> Controller Class Initialized
INFO - 2023-01-10 07:17:22 --> Controller Class Initialized
DEBUG - 2023-01-10 07:17:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:17:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:17:22 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:22 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:22 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:22 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:22 --> Final output sent to browser
DEBUG - 2023-01-10 07:17:22 --> Total execution time: 0.0253
INFO - 2023-01-10 07:17:22 --> Config Class Initialized
INFO - 2023-01-10 07:17:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:17:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:17:22 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:22 --> URI Class Initialized
INFO - 2023-01-10 07:17:22 --> Router Class Initialized
INFO - 2023-01-10 07:17:22 --> Output Class Initialized
INFO - 2023-01-10 07:17:22 --> Security Class Initialized
DEBUG - 2023-01-10 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:22 --> Input Class Initialized
INFO - 2023-01-10 07:17:22 --> Language Class Initialized
INFO - 2023-01-10 07:17:22 --> Loader Class Initialized
INFO - 2023-01-10 07:17:22 --> Controller Class Initialized
DEBUG - 2023-01-10 07:17:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:17:22 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:22 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:22 --> Final output sent to browser
DEBUG - 2023-01-10 07:17:22 --> Total execution time: 0.0137
INFO - 2023-01-10 07:17:22 --> Config Class Initialized
INFO - 2023-01-10 07:17:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:17:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:17:22 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:22 --> URI Class Initialized
INFO - 2023-01-10 07:17:22 --> Router Class Initialized
INFO - 2023-01-10 07:17:22 --> Output Class Initialized
INFO - 2023-01-10 07:17:22 --> Security Class Initialized
DEBUG - 2023-01-10 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:22 --> Input Class Initialized
INFO - 2023-01-10 07:17:22 --> Language Class Initialized
INFO - 2023-01-10 07:17:22 --> Loader Class Initialized
INFO - 2023-01-10 07:17:22 --> Controller Class Initialized
DEBUG - 2023-01-10 07:17:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:17:22 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:22 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:29 --> Config Class Initialized
INFO - 2023-01-10 07:17:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:17:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:17:29 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:29 --> URI Class Initialized
INFO - 2023-01-10 07:17:29 --> Router Class Initialized
INFO - 2023-01-10 07:17:29 --> Output Class Initialized
INFO - 2023-01-10 07:17:29 --> Security Class Initialized
DEBUG - 2023-01-10 07:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:29 --> Input Class Initialized
INFO - 2023-01-10 07:17:29 --> Language Class Initialized
INFO - 2023-01-10 07:17:29 --> Loader Class Initialized
INFO - 2023-01-10 07:17:29 --> Controller Class Initialized
DEBUG - 2023-01-10 07:17:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:17:29 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:29 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:29 --> Final output sent to browser
DEBUG - 2023-01-10 07:17:29 --> Total execution time: 0.0168
INFO - 2023-01-10 07:17:34 --> Config Class Initialized
INFO - 2023-01-10 07:17:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:17:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:17:34 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:34 --> URI Class Initialized
INFO - 2023-01-10 07:17:34 --> Router Class Initialized
INFO - 2023-01-10 07:17:34 --> Output Class Initialized
INFO - 2023-01-10 07:17:34 --> Security Class Initialized
DEBUG - 2023-01-10 07:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:34 --> Input Class Initialized
INFO - 2023-01-10 07:17:34 --> Language Class Initialized
INFO - 2023-01-10 07:17:34 --> Loader Class Initialized
INFO - 2023-01-10 07:17:34 --> Controller Class Initialized
DEBUG - 2023-01-10 07:17:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:17:34 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:34 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:44 --> Config Class Initialized
INFO - 2023-01-10 07:17:44 --> Config Class Initialized
INFO - 2023-01-10 07:17:44 --> Hooks Class Initialized
INFO - 2023-01-10 07:17:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:17:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:17:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:17:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:44 --> URI Class Initialized
INFO - 2023-01-10 07:17:44 --> URI Class Initialized
INFO - 2023-01-10 07:17:44 --> Router Class Initialized
INFO - 2023-01-10 07:17:44 --> Router Class Initialized
INFO - 2023-01-10 07:17:44 --> Output Class Initialized
INFO - 2023-01-10 07:17:44 --> Output Class Initialized
INFO - 2023-01-10 07:17:44 --> Security Class Initialized
INFO - 2023-01-10 07:17:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-10 07:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:44 --> Input Class Initialized
INFO - 2023-01-10 07:17:44 --> Input Class Initialized
INFO - 2023-01-10 07:17:44 --> Language Class Initialized
INFO - 2023-01-10 07:17:44 --> Language Class Initialized
INFO - 2023-01-10 07:17:44 --> Loader Class Initialized
INFO - 2023-01-10 07:17:44 --> Loader Class Initialized
INFO - 2023-01-10 07:17:44 --> Controller Class Initialized
INFO - 2023-01-10 07:17:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:17:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:17:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:17:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:44 --> Final output sent to browser
DEBUG - 2023-01-10 07:17:44 --> Total execution time: 0.0200
INFO - 2023-01-10 07:17:44 --> Config Class Initialized
INFO - 2023-01-10 07:17:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:17:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:17:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:44 --> URI Class Initialized
INFO - 2023-01-10 07:17:44 --> Router Class Initialized
INFO - 2023-01-10 07:17:44 --> Output Class Initialized
INFO - 2023-01-10 07:17:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:44 --> Input Class Initialized
INFO - 2023-01-10 07:17:44 --> Language Class Initialized
INFO - 2023-01-10 07:17:44 --> Loader Class Initialized
INFO - 2023-01-10 07:17:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:17:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:17:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:17:44 --> Config Class Initialized
INFO - 2023-01-10 07:17:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:17:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:17:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:17:44 --> Final output sent to browser
INFO - 2023-01-10 07:17:44 --> URI Class Initialized
DEBUG - 2023-01-10 07:17:44 --> Total execution time: 0.0143
INFO - 2023-01-10 07:17:44 --> Router Class Initialized
INFO - 2023-01-10 07:17:44 --> Output Class Initialized
INFO - 2023-01-10 07:17:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:17:44 --> Input Class Initialized
INFO - 2023-01-10 07:17:44 --> Language Class Initialized
INFO - 2023-01-10 07:17:44 --> Loader Class Initialized
INFO - 2023-01-10 07:17:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:17:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:17:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:17:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:18:01 --> Config Class Initialized
INFO - 2023-01-10 07:18:01 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:18:01 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:18:01 --> Utf8 Class Initialized
INFO - 2023-01-10 07:18:01 --> URI Class Initialized
INFO - 2023-01-10 07:18:01 --> Router Class Initialized
INFO - 2023-01-10 07:18:01 --> Output Class Initialized
INFO - 2023-01-10 07:18:01 --> Security Class Initialized
DEBUG - 2023-01-10 07:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:18:01 --> Input Class Initialized
INFO - 2023-01-10 07:18:01 --> Language Class Initialized
INFO - 2023-01-10 07:18:01 --> Loader Class Initialized
INFO - 2023-01-10 07:18:01 --> Controller Class Initialized
DEBUG - 2023-01-10 07:18:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:18:01 --> Database Driver Class Initialized
INFO - 2023-01-10 07:18:01 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:19:55 --> Config Class Initialized
INFO - 2023-01-10 07:19:55 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:19:55 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:19:55 --> Utf8 Class Initialized
INFO - 2023-01-10 07:19:55 --> URI Class Initialized
INFO - 2023-01-10 07:19:55 --> Router Class Initialized
INFO - 2023-01-10 07:19:55 --> Output Class Initialized
INFO - 2023-01-10 07:19:55 --> Security Class Initialized
DEBUG - 2023-01-10 07:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:19:55 --> Input Class Initialized
INFO - 2023-01-10 07:19:55 --> Language Class Initialized
INFO - 2023-01-10 07:19:55 --> Loader Class Initialized
INFO - 2023-01-10 07:19:55 --> Controller Class Initialized
DEBUG - 2023-01-10 07:19:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:19:55 --> Database Driver Class Initialized
INFO - 2023-01-10 07:19:55 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:20:45 --> Config Class Initialized
INFO - 2023-01-10 07:20:45 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:20:45 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:20:45 --> Utf8 Class Initialized
INFO - 2023-01-10 07:20:45 --> URI Class Initialized
INFO - 2023-01-10 07:20:45 --> Router Class Initialized
INFO - 2023-01-10 07:20:45 --> Output Class Initialized
INFO - 2023-01-10 07:20:45 --> Security Class Initialized
DEBUG - 2023-01-10 07:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:20:45 --> Input Class Initialized
INFO - 2023-01-10 07:20:45 --> Language Class Initialized
INFO - 2023-01-10 07:20:45 --> Loader Class Initialized
INFO - 2023-01-10 07:20:45 --> Controller Class Initialized
DEBUG - 2023-01-10 07:20:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:20:45 --> Database Driver Class Initialized
INFO - 2023-01-10 07:20:45 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:22:12 --> Config Class Initialized
INFO - 2023-01-10 07:22:12 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:22:12 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:22:12 --> Utf8 Class Initialized
INFO - 2023-01-10 07:22:12 --> URI Class Initialized
INFO - 2023-01-10 07:22:12 --> Router Class Initialized
INFO - 2023-01-10 07:22:12 --> Output Class Initialized
INFO - 2023-01-10 07:22:12 --> Security Class Initialized
DEBUG - 2023-01-10 07:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:22:12 --> Input Class Initialized
INFO - 2023-01-10 07:22:12 --> Language Class Initialized
INFO - 2023-01-10 07:22:12 --> Loader Class Initialized
INFO - 2023-01-10 07:22:12 --> Controller Class Initialized
DEBUG - 2023-01-10 07:22:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:22:12 --> Database Driver Class Initialized
INFO - 2023-01-10 07:22:12 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:22:27 --> Config Class Initialized
INFO - 2023-01-10 07:22:27 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:22:27 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:22:27 --> Utf8 Class Initialized
INFO - 2023-01-10 07:22:27 --> URI Class Initialized
INFO - 2023-01-10 07:22:27 --> Router Class Initialized
INFO - 2023-01-10 07:22:27 --> Output Class Initialized
INFO - 2023-01-10 07:22:27 --> Security Class Initialized
DEBUG - 2023-01-10 07:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:22:27 --> Input Class Initialized
INFO - 2023-01-10 07:22:27 --> Language Class Initialized
INFO - 2023-01-10 07:22:27 --> Loader Class Initialized
INFO - 2023-01-10 07:22:27 --> Controller Class Initialized
DEBUG - 2023-01-10 07:22:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:22:27 --> Database Driver Class Initialized
INFO - 2023-01-10 07:22:27 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:29:28 --> Config Class Initialized
INFO - 2023-01-10 07:29:28 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:29:28 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:29:28 --> Utf8 Class Initialized
INFO - 2023-01-10 07:29:28 --> URI Class Initialized
INFO - 2023-01-10 07:29:28 --> Router Class Initialized
INFO - 2023-01-10 07:29:28 --> Output Class Initialized
INFO - 2023-01-10 07:29:28 --> Security Class Initialized
DEBUG - 2023-01-10 07:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:29:28 --> Input Class Initialized
INFO - 2023-01-10 07:29:28 --> Language Class Initialized
INFO - 2023-01-10 07:29:28 --> Loader Class Initialized
INFO - 2023-01-10 07:29:28 --> Controller Class Initialized
DEBUG - 2023-01-10 07:29:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:29:28 --> Database Driver Class Initialized
INFO - 2023-01-10 07:29:28 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:29:36 --> Config Class Initialized
INFO - 2023-01-10 07:29:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:29:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:29:36 --> Utf8 Class Initialized
INFO - 2023-01-10 07:29:36 --> URI Class Initialized
INFO - 2023-01-10 07:29:36 --> Router Class Initialized
INFO - 2023-01-10 07:29:36 --> Output Class Initialized
INFO - 2023-01-10 07:29:36 --> Security Class Initialized
DEBUG - 2023-01-10 07:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:29:36 --> Input Class Initialized
INFO - 2023-01-10 07:29:36 --> Language Class Initialized
INFO - 2023-01-10 07:29:36 --> Loader Class Initialized
INFO - 2023-01-10 07:29:36 --> Controller Class Initialized
DEBUG - 2023-01-10 07:29:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:29:36 --> Database Driver Class Initialized
INFO - 2023-01-10 07:29:36 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:06 --> Config Class Initialized
INFO - 2023-01-10 07:30:06 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:06 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:06 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:06 --> URI Class Initialized
INFO - 2023-01-10 07:30:06 --> Router Class Initialized
INFO - 2023-01-10 07:30:06 --> Output Class Initialized
INFO - 2023-01-10 07:30:06 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:06 --> Input Class Initialized
INFO - 2023-01-10 07:30:06 --> Language Class Initialized
INFO - 2023-01-10 07:30:06 --> Loader Class Initialized
INFO - 2023-01-10 07:30:06 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:06 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:06 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:06 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:20 --> Config Class Initialized
INFO - 2023-01-10 07:30:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:20 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:20 --> URI Class Initialized
INFO - 2023-01-10 07:30:20 --> Router Class Initialized
INFO - 2023-01-10 07:30:20 --> Output Class Initialized
INFO - 2023-01-10 07:30:20 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:20 --> Input Class Initialized
INFO - 2023-01-10 07:30:20 --> Language Class Initialized
INFO - 2023-01-10 07:30:20 --> Loader Class Initialized
INFO - 2023-01-10 07:30:20 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:20 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:20 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:20 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:20 --> Model "Login_model" initialized
INFO - 2023-01-10 07:30:20 --> Final output sent to browser
DEBUG - 2023-01-10 07:30:20 --> Total execution time: 0.1596
INFO - 2023-01-10 07:30:20 --> Config Class Initialized
INFO - 2023-01-10 07:30:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:20 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:20 --> URI Class Initialized
INFO - 2023-01-10 07:30:20 --> Router Class Initialized
INFO - 2023-01-10 07:30:20 --> Output Class Initialized
INFO - 2023-01-10 07:30:20 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:20 --> Input Class Initialized
INFO - 2023-01-10 07:30:20 --> Language Class Initialized
INFO - 2023-01-10 07:30:20 --> Loader Class Initialized
INFO - 2023-01-10 07:30:20 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:20 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:21 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:21 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:21 --> Model "Login_model" initialized
INFO - 2023-01-10 07:30:21 --> Final output sent to browser
DEBUG - 2023-01-10 07:30:21 --> Total execution time: 0.0631
INFO - 2023-01-10 07:30:25 --> Config Class Initialized
INFO - 2023-01-10 07:30:25 --> Config Class Initialized
INFO - 2023-01-10 07:30:25 --> Hooks Class Initialized
INFO - 2023-01-10 07:30:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:30:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:25 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:25 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:25 --> URI Class Initialized
INFO - 2023-01-10 07:30:25 --> URI Class Initialized
INFO - 2023-01-10 07:30:25 --> Router Class Initialized
INFO - 2023-01-10 07:30:25 --> Router Class Initialized
INFO - 2023-01-10 07:30:25 --> Output Class Initialized
INFO - 2023-01-10 07:30:25 --> Output Class Initialized
INFO - 2023-01-10 07:30:25 --> Security Class Initialized
INFO - 2023-01-10 07:30:25 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-10 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:25 --> Input Class Initialized
INFO - 2023-01-10 07:30:25 --> Input Class Initialized
INFO - 2023-01-10 07:30:25 --> Language Class Initialized
INFO - 2023-01-10 07:30:25 --> Language Class Initialized
INFO - 2023-01-10 07:30:25 --> Loader Class Initialized
INFO - 2023-01-10 07:30:25 --> Loader Class Initialized
INFO - 2023-01-10 07:30:25 --> Controller Class Initialized
INFO - 2023-01-10 07:30:25 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:25 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:25 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:25 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:25 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:25 --> Final output sent to browser
DEBUG - 2023-01-10 07:30:25 --> Total execution time: 0.0194
INFO - 2023-01-10 07:30:25 --> Config Class Initialized
INFO - 2023-01-10 07:30:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:25 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:25 --> URI Class Initialized
INFO - 2023-01-10 07:30:25 --> Router Class Initialized
INFO - 2023-01-10 07:30:25 --> Output Class Initialized
INFO - 2023-01-10 07:30:25 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:25 --> Input Class Initialized
INFO - 2023-01-10 07:30:25 --> Language Class Initialized
INFO - 2023-01-10 07:30:25 --> Loader Class Initialized
INFO - 2023-01-10 07:30:25 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:25 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:25 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:25 --> Final output sent to browser
INFO - 2023-01-10 07:30:25 --> Config Class Initialized
INFO - 2023-01-10 07:30:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:25 --> Total execution time: 0.1016
DEBUG - 2023-01-10 07:30:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:25 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:25 --> URI Class Initialized
INFO - 2023-01-10 07:30:25 --> Router Class Initialized
INFO - 2023-01-10 07:30:25 --> Output Class Initialized
INFO - 2023-01-10 07:30:25 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:25 --> Input Class Initialized
INFO - 2023-01-10 07:30:25 --> Language Class Initialized
INFO - 2023-01-10 07:30:25 --> Loader Class Initialized
INFO - 2023-01-10 07:30:25 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:25 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:25 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:41 --> Config Class Initialized
INFO - 2023-01-10 07:30:41 --> Config Class Initialized
INFO - 2023-01-10 07:30:41 --> Hooks Class Initialized
INFO - 2023-01-10 07:30:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:30:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:41 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:41 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:41 --> URI Class Initialized
INFO - 2023-01-10 07:30:41 --> URI Class Initialized
INFO - 2023-01-10 07:30:41 --> Router Class Initialized
INFO - 2023-01-10 07:30:41 --> Router Class Initialized
INFO - 2023-01-10 07:30:41 --> Output Class Initialized
INFO - 2023-01-10 07:30:41 --> Output Class Initialized
INFO - 2023-01-10 07:30:41 --> Security Class Initialized
INFO - 2023-01-10 07:30:41 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-10 07:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:41 --> Input Class Initialized
INFO - 2023-01-10 07:30:41 --> Input Class Initialized
INFO - 2023-01-10 07:30:41 --> Language Class Initialized
INFO - 2023-01-10 07:30:41 --> Language Class Initialized
INFO - 2023-01-10 07:30:41 --> Loader Class Initialized
INFO - 2023-01-10 07:30:41 --> Loader Class Initialized
INFO - 2023-01-10 07:30:41 --> Controller Class Initialized
INFO - 2023-01-10 07:30:41 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:30:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:41 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:41 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:41 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:41 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:41 --> Final output sent to browser
DEBUG - 2023-01-10 07:30:41 --> Total execution time: 0.0222
INFO - 2023-01-10 07:30:41 --> Config Class Initialized
INFO - 2023-01-10 07:30:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:41 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:41 --> URI Class Initialized
INFO - 2023-01-10 07:30:41 --> Router Class Initialized
INFO - 2023-01-10 07:30:41 --> Output Class Initialized
INFO - 2023-01-10 07:30:41 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:41 --> Input Class Initialized
INFO - 2023-01-10 07:30:41 --> Language Class Initialized
INFO - 2023-01-10 07:30:41 --> Loader Class Initialized
INFO - 2023-01-10 07:30:41 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:41 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:41 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:30:41 --> Final output sent to browser
DEBUG - 2023-01-10 07:30:41 --> Total execution time: 0.0186
INFO - 2023-01-10 07:30:41 --> Config Class Initialized
INFO - 2023-01-10 07:30:41 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:30:41 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:30:41 --> Utf8 Class Initialized
INFO - 2023-01-10 07:30:41 --> URI Class Initialized
INFO - 2023-01-10 07:30:41 --> Router Class Initialized
INFO - 2023-01-10 07:30:41 --> Output Class Initialized
INFO - 2023-01-10 07:30:41 --> Security Class Initialized
DEBUG - 2023-01-10 07:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:30:41 --> Input Class Initialized
INFO - 2023-01-10 07:30:41 --> Language Class Initialized
INFO - 2023-01-10 07:30:41 --> Loader Class Initialized
INFO - 2023-01-10 07:30:41 --> Controller Class Initialized
DEBUG - 2023-01-10 07:30:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:30:41 --> Database Driver Class Initialized
INFO - 2023-01-10 07:30:41 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:31:09 --> Config Class Initialized
INFO - 2023-01-10 07:31:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:31:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:31:09 --> Utf8 Class Initialized
INFO - 2023-01-10 07:31:09 --> URI Class Initialized
INFO - 2023-01-10 07:31:09 --> Router Class Initialized
INFO - 2023-01-10 07:31:09 --> Output Class Initialized
INFO - 2023-01-10 07:31:09 --> Security Class Initialized
DEBUG - 2023-01-10 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:31:09 --> Input Class Initialized
INFO - 2023-01-10 07:31:09 --> Language Class Initialized
INFO - 2023-01-10 07:31:09 --> Loader Class Initialized
INFO - 2023-01-10 07:31:09 --> Controller Class Initialized
DEBUG - 2023-01-10 07:31:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:31:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:31:09 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:33:15 --> Config Class Initialized
INFO - 2023-01-10 07:33:15 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:33:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:33:15 --> Utf8 Class Initialized
INFO - 2023-01-10 07:33:15 --> URI Class Initialized
INFO - 2023-01-10 07:33:15 --> Router Class Initialized
INFO - 2023-01-10 07:33:15 --> Output Class Initialized
INFO - 2023-01-10 07:33:15 --> Security Class Initialized
DEBUG - 2023-01-10 07:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:33:15 --> Input Class Initialized
INFO - 2023-01-10 07:33:15 --> Language Class Initialized
INFO - 2023-01-10 07:33:15 --> Loader Class Initialized
INFO - 2023-01-10 07:33:15 --> Controller Class Initialized
DEBUG - 2023-01-10 07:33:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:33:15 --> Database Driver Class Initialized
INFO - 2023-01-10 07:33:15 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:33:59 --> Config Class Initialized
INFO - 2023-01-10 07:33:59 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:33:59 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:33:59 --> Utf8 Class Initialized
INFO - 2023-01-10 07:33:59 --> URI Class Initialized
INFO - 2023-01-10 07:33:59 --> Router Class Initialized
INFO - 2023-01-10 07:33:59 --> Output Class Initialized
INFO - 2023-01-10 07:33:59 --> Security Class Initialized
DEBUG - 2023-01-10 07:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:33:59 --> Input Class Initialized
INFO - 2023-01-10 07:33:59 --> Language Class Initialized
INFO - 2023-01-10 07:33:59 --> Loader Class Initialized
INFO - 2023-01-10 07:33:59 --> Controller Class Initialized
DEBUG - 2023-01-10 07:33:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:33:59 --> Database Driver Class Initialized
INFO - 2023-01-10 07:33:59 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:34:02 --> Config Class Initialized
INFO - 2023-01-10 07:34:02 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:34:02 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:34:02 --> Utf8 Class Initialized
INFO - 2023-01-10 07:34:02 --> URI Class Initialized
INFO - 2023-01-10 07:34:02 --> Router Class Initialized
INFO - 2023-01-10 07:34:02 --> Output Class Initialized
INFO - 2023-01-10 07:34:02 --> Security Class Initialized
DEBUG - 2023-01-10 07:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:34:02 --> Input Class Initialized
INFO - 2023-01-10 07:34:02 --> Language Class Initialized
INFO - 2023-01-10 07:34:02 --> Loader Class Initialized
INFO - 2023-01-10 07:34:02 --> Controller Class Initialized
DEBUG - 2023-01-10 07:34:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:34:02 --> Database Driver Class Initialized
INFO - 2023-01-10 07:34:02 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:34:09 --> Config Class Initialized
INFO - 2023-01-10 07:34:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:34:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:34:09 --> Utf8 Class Initialized
INFO - 2023-01-10 07:34:09 --> URI Class Initialized
INFO - 2023-01-10 07:34:09 --> Router Class Initialized
INFO - 2023-01-10 07:34:09 --> Output Class Initialized
INFO - 2023-01-10 07:34:09 --> Security Class Initialized
DEBUG - 2023-01-10 07:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:34:09 --> Input Class Initialized
INFO - 2023-01-10 07:34:09 --> Language Class Initialized
INFO - 2023-01-10 07:34:09 --> Loader Class Initialized
INFO - 2023-01-10 07:34:10 --> Controller Class Initialized
DEBUG - 2023-01-10 07:34:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:34:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:34:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:34:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:34:10 --> Model "Login_model" initialized
INFO - 2023-01-10 07:34:10 --> Final output sent to browser
DEBUG - 2023-01-10 07:34:10 --> Total execution time: 0.3108
INFO - 2023-01-10 07:34:10 --> Config Class Initialized
INFO - 2023-01-10 07:34:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:34:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:34:10 --> Utf8 Class Initialized
INFO - 2023-01-10 07:34:10 --> URI Class Initialized
INFO - 2023-01-10 07:34:10 --> Router Class Initialized
INFO - 2023-01-10 07:34:10 --> Output Class Initialized
INFO - 2023-01-10 07:34:10 --> Security Class Initialized
DEBUG - 2023-01-10 07:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:34:10 --> Input Class Initialized
INFO - 2023-01-10 07:34:10 --> Language Class Initialized
INFO - 2023-01-10 07:34:10 --> Loader Class Initialized
INFO - 2023-01-10 07:34:10 --> Controller Class Initialized
DEBUG - 2023-01-10 07:34:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:34:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:34:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:34:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:34:10 --> Model "Login_model" initialized
INFO - 2023-01-10 07:34:10 --> Final output sent to browser
DEBUG - 2023-01-10 07:34:10 --> Total execution time: 0.0613
INFO - 2023-01-10 07:34:15 --> Config Class Initialized
INFO - 2023-01-10 07:34:15 --> Config Class Initialized
INFO - 2023-01-10 07:34:15 --> Hooks Class Initialized
INFO - 2023-01-10 07:34:15 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:34:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:34:15 --> Utf8 Class Initialized
DEBUG - 2023-01-10 07:34:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:34:15 --> Utf8 Class Initialized
INFO - 2023-01-10 07:34:15 --> URI Class Initialized
INFO - 2023-01-10 07:34:15 --> URI Class Initialized
INFO - 2023-01-10 07:34:15 --> Router Class Initialized
INFO - 2023-01-10 07:34:15 --> Router Class Initialized
INFO - 2023-01-10 07:34:15 --> Output Class Initialized
INFO - 2023-01-10 07:34:15 --> Security Class Initialized
INFO - 2023-01-10 07:34:15 --> Output Class Initialized
DEBUG - 2023-01-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:34:15 --> Security Class Initialized
INFO - 2023-01-10 07:34:15 --> Input Class Initialized
DEBUG - 2023-01-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:34:15 --> Language Class Initialized
INFO - 2023-01-10 07:34:15 --> Input Class Initialized
INFO - 2023-01-10 07:34:15 --> Loader Class Initialized
INFO - 2023-01-10 07:34:15 --> Controller Class Initialized
INFO - 2023-01-10 07:34:15 --> Language Class Initialized
DEBUG - 2023-01-10 07:34:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:34:15 --> Loader Class Initialized
INFO - 2023-01-10 07:34:15 --> Controller Class Initialized
INFO - 2023-01-10 07:34:15 --> Database Driver Class Initialized
DEBUG - 2023-01-10 07:34:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:34:15 --> Database Driver Class Initialized
INFO - 2023-01-10 07:34:15 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:34:15 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:34:15 --> Final output sent to browser
DEBUG - 2023-01-10 07:34:15 --> Total execution time: 0.0271
INFO - 2023-01-10 07:34:15 --> Config Class Initialized
INFO - 2023-01-10 07:34:15 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:34:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:34:15 --> Utf8 Class Initialized
INFO - 2023-01-10 07:34:15 --> URI Class Initialized
INFO - 2023-01-10 07:34:15 --> Router Class Initialized
INFO - 2023-01-10 07:34:15 --> Output Class Initialized
INFO - 2023-01-10 07:34:15 --> Security Class Initialized
DEBUG - 2023-01-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:34:15 --> Input Class Initialized
INFO - 2023-01-10 07:34:15 --> Language Class Initialized
INFO - 2023-01-10 07:34:15 --> Loader Class Initialized
INFO - 2023-01-10 07:34:15 --> Controller Class Initialized
DEBUG - 2023-01-10 07:34:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:34:15 --> Database Driver Class Initialized
INFO - 2023-01-10 07:34:15 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:34:15 --> Config Class Initialized
INFO - 2023-01-10 07:34:15 --> Hooks Class Initialized
INFO - 2023-01-10 07:34:15 --> Final output sent to browser
DEBUG - 2023-01-10 07:34:15 --> Total execution time: 0.0189
DEBUG - 2023-01-10 07:34:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:34:15 --> Utf8 Class Initialized
INFO - 2023-01-10 07:34:15 --> URI Class Initialized
INFO - 2023-01-10 07:34:15 --> Router Class Initialized
INFO - 2023-01-10 07:34:15 --> Output Class Initialized
INFO - 2023-01-10 07:34:15 --> Security Class Initialized
DEBUG - 2023-01-10 07:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:34:15 --> Input Class Initialized
INFO - 2023-01-10 07:34:15 --> Language Class Initialized
INFO - 2023-01-10 07:34:15 --> Loader Class Initialized
INFO - 2023-01-10 07:34:15 --> Controller Class Initialized
DEBUG - 2023-01-10 07:34:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:34:15 --> Database Driver Class Initialized
INFO - 2023-01-10 07:34:15 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:35:03 --> Config Class Initialized
INFO - 2023-01-10 07:35:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:35:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:35:03 --> Utf8 Class Initialized
INFO - 2023-01-10 07:35:03 --> URI Class Initialized
INFO - 2023-01-10 07:35:03 --> Router Class Initialized
INFO - 2023-01-10 07:35:03 --> Output Class Initialized
INFO - 2023-01-10 07:35:03 --> Security Class Initialized
DEBUG - 2023-01-10 07:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:35:03 --> Input Class Initialized
INFO - 2023-01-10 07:35:03 --> Language Class Initialized
INFO - 2023-01-10 07:35:03 --> Loader Class Initialized
INFO - 2023-01-10 07:35:03 --> Controller Class Initialized
DEBUG - 2023-01-10 07:35:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:35:03 --> Database Driver Class Initialized
INFO - 2023-01-10 07:35:03 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:35:03 --> Database Driver Class Initialized
INFO - 2023-01-10 07:35:03 --> Model "Login_model" initialized
INFO - 2023-01-10 07:35:03 --> Final output sent to browser
DEBUG - 2023-01-10 07:35:03 --> Total execution time: 0.2409
INFO - 2023-01-10 07:35:04 --> Config Class Initialized
INFO - 2023-01-10 07:35:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:35:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:35:04 --> Utf8 Class Initialized
INFO - 2023-01-10 07:35:04 --> URI Class Initialized
INFO - 2023-01-10 07:35:04 --> Router Class Initialized
INFO - 2023-01-10 07:35:04 --> Output Class Initialized
INFO - 2023-01-10 07:35:04 --> Security Class Initialized
DEBUG - 2023-01-10 07:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:35:04 --> Input Class Initialized
INFO - 2023-01-10 07:35:04 --> Language Class Initialized
INFO - 2023-01-10 07:35:04 --> Loader Class Initialized
INFO - 2023-01-10 07:35:04 --> Controller Class Initialized
DEBUG - 2023-01-10 07:35:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:35:04 --> Database Driver Class Initialized
INFO - 2023-01-10 07:35:04 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:35:04 --> Database Driver Class Initialized
INFO - 2023-01-10 07:35:04 --> Model "Login_model" initialized
INFO - 2023-01-10 07:35:04 --> Final output sent to browser
DEBUG - 2023-01-10 07:35:04 --> Total execution time: 0.2016
INFO - 2023-01-10 07:35:10 --> Config Class Initialized
INFO - 2023-01-10 07:35:10 --> Config Class Initialized
INFO - 2023-01-10 07:35:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:35:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:35:10 --> Hooks Class Initialized
INFO - 2023-01-10 07:35:10 --> Utf8 Class Initialized
DEBUG - 2023-01-10 07:35:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:35:10 --> URI Class Initialized
INFO - 2023-01-10 07:35:10 --> Utf8 Class Initialized
INFO - 2023-01-10 07:35:10 --> URI Class Initialized
INFO - 2023-01-10 07:35:10 --> Router Class Initialized
INFO - 2023-01-10 07:35:10 --> Router Class Initialized
INFO - 2023-01-10 07:35:10 --> Output Class Initialized
INFO - 2023-01-10 07:35:10 --> Output Class Initialized
INFO - 2023-01-10 07:35:10 --> Security Class Initialized
INFO - 2023-01-10 07:35:10 --> Security Class Initialized
DEBUG - 2023-01-10 07:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-10 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:35:10 --> Input Class Initialized
INFO - 2023-01-10 07:35:10 --> Language Class Initialized
INFO - 2023-01-10 07:35:10 --> Input Class Initialized
INFO - 2023-01-10 07:35:10 --> Language Class Initialized
INFO - 2023-01-10 07:35:10 --> Loader Class Initialized
INFO - 2023-01-10 07:35:10 --> Loader Class Initialized
INFO - 2023-01-10 07:35:10 --> Controller Class Initialized
INFO - 2023-01-10 07:35:10 --> Controller Class Initialized
DEBUG - 2023-01-10 07:35:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:35:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:35:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:35:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:35:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:35:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:35:10 --> Final output sent to browser
DEBUG - 2023-01-10 07:35:10 --> Total execution time: 0.0414
INFO - 2023-01-10 07:35:10 --> Config Class Initialized
INFO - 2023-01-10 07:35:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:35:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:35:10 --> Utf8 Class Initialized
INFO - 2023-01-10 07:35:10 --> URI Class Initialized
INFO - 2023-01-10 07:35:10 --> Router Class Initialized
INFO - 2023-01-10 07:35:10 --> Output Class Initialized
INFO - 2023-01-10 07:35:10 --> Security Class Initialized
DEBUG - 2023-01-10 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:35:10 --> Input Class Initialized
INFO - 2023-01-10 07:35:10 --> Language Class Initialized
INFO - 2023-01-10 07:35:10 --> Loader Class Initialized
INFO - 2023-01-10 07:35:10 --> Controller Class Initialized
DEBUG - 2023-01-10 07:35:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:35:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:35:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:35:10 --> Final output sent to browser
DEBUG - 2023-01-10 07:35:10 --> Total execution time: 0.1118
INFO - 2023-01-10 07:35:10 --> Config Class Initialized
INFO - 2023-01-10 07:35:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:35:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:35:10 --> Utf8 Class Initialized
INFO - 2023-01-10 07:35:10 --> URI Class Initialized
INFO - 2023-01-10 07:35:10 --> Router Class Initialized
INFO - 2023-01-10 07:35:10 --> Output Class Initialized
INFO - 2023-01-10 07:35:10 --> Security Class Initialized
DEBUG - 2023-01-10 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:35:10 --> Input Class Initialized
INFO - 2023-01-10 07:35:10 --> Language Class Initialized
INFO - 2023-01-10 07:35:10 --> Loader Class Initialized
INFO - 2023-01-10 07:35:10 --> Controller Class Initialized
DEBUG - 2023-01-10 07:35:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:35:10 --> Database Driver Class Initialized
INFO - 2023-01-10 07:35:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:36:30 --> Config Class Initialized
INFO - 2023-01-10 07:36:30 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:36:30 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:36:30 --> Utf8 Class Initialized
INFO - 2023-01-10 07:36:30 --> URI Class Initialized
INFO - 2023-01-10 07:36:30 --> Router Class Initialized
INFO - 2023-01-10 07:36:30 --> Output Class Initialized
INFO - 2023-01-10 07:36:30 --> Security Class Initialized
DEBUG - 2023-01-10 07:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:36:30 --> Input Class Initialized
INFO - 2023-01-10 07:36:30 --> Language Class Initialized
INFO - 2023-01-10 07:36:30 --> Loader Class Initialized
INFO - 2023-01-10 07:36:30 --> Controller Class Initialized
DEBUG - 2023-01-10 07:36:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:36:30 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:30 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:36:30 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:30 --> Model "Login_model" initialized
INFO - 2023-01-10 07:36:30 --> Final output sent to browser
DEBUG - 2023-01-10 07:36:30 --> Total execution time: 0.2078
INFO - 2023-01-10 07:36:30 --> Config Class Initialized
INFO - 2023-01-10 07:36:30 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:36:30 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:36:30 --> Utf8 Class Initialized
INFO - 2023-01-10 07:36:30 --> URI Class Initialized
INFO - 2023-01-10 07:36:30 --> Router Class Initialized
INFO - 2023-01-10 07:36:30 --> Output Class Initialized
INFO - 2023-01-10 07:36:30 --> Security Class Initialized
DEBUG - 2023-01-10 07:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:36:30 --> Input Class Initialized
INFO - 2023-01-10 07:36:30 --> Language Class Initialized
INFO - 2023-01-10 07:36:30 --> Loader Class Initialized
INFO - 2023-01-10 07:36:30 --> Controller Class Initialized
DEBUG - 2023-01-10 07:36:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:36:30 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:30 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:36:30 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:30 --> Model "Login_model" initialized
INFO - 2023-01-10 07:36:30 --> Final output sent to browser
DEBUG - 2023-01-10 07:36:30 --> Total execution time: 0.2491
INFO - 2023-01-10 07:36:42 --> Config Class Initialized
INFO - 2023-01-10 07:36:42 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:36:42 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:36:42 --> Utf8 Class Initialized
INFO - 2023-01-10 07:36:42 --> URI Class Initialized
INFO - 2023-01-10 07:36:42 --> Router Class Initialized
INFO - 2023-01-10 07:36:42 --> Output Class Initialized
INFO - 2023-01-10 07:36:42 --> Security Class Initialized
DEBUG - 2023-01-10 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:36:42 --> Input Class Initialized
INFO - 2023-01-10 07:36:42 --> Language Class Initialized
INFO - 2023-01-10 07:36:42 --> Loader Class Initialized
INFO - 2023-01-10 07:36:42 --> Controller Class Initialized
DEBUG - 2023-01-10 07:36:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:36:42 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:42 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:36:42 --> Final output sent to browser
DEBUG - 2023-01-10 07:36:42 --> Total execution time: 0.0333
INFO - 2023-01-10 07:36:42 --> Config Class Initialized
INFO - 2023-01-10 07:36:42 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:36:42 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:36:42 --> Utf8 Class Initialized
INFO - 2023-01-10 07:36:42 --> URI Class Initialized
INFO - 2023-01-10 07:36:42 --> Router Class Initialized
INFO - 2023-01-10 07:36:42 --> Output Class Initialized
INFO - 2023-01-10 07:36:42 --> Security Class Initialized
DEBUG - 2023-01-10 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:36:42 --> Input Class Initialized
INFO - 2023-01-10 07:36:42 --> Language Class Initialized
INFO - 2023-01-10 07:36:42 --> Loader Class Initialized
INFO - 2023-01-10 07:36:42 --> Controller Class Initialized
DEBUG - 2023-01-10 07:36:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:36:42 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:42 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:36:42 --> Final output sent to browser
DEBUG - 2023-01-10 07:36:42 --> Total execution time: 0.0215
INFO - 2023-01-10 07:36:44 --> Config Class Initialized
INFO - 2023-01-10 07:36:44 --> Config Class Initialized
INFO - 2023-01-10 07:36:44 --> Hooks Class Initialized
INFO - 2023-01-10 07:36:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:36:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:36:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:36:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:36:44 --> URI Class Initialized
INFO - 2023-01-10 07:36:44 --> URI Class Initialized
INFO - 2023-01-10 07:36:44 --> Router Class Initialized
INFO - 2023-01-10 07:36:44 --> Router Class Initialized
INFO - 2023-01-10 07:36:44 --> Output Class Initialized
INFO - 2023-01-10 07:36:44 --> Output Class Initialized
INFO - 2023-01-10 07:36:44 --> Security Class Initialized
INFO - 2023-01-10 07:36:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-10 07:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:36:44 --> Input Class Initialized
INFO - 2023-01-10 07:36:44 --> Input Class Initialized
INFO - 2023-01-10 07:36:44 --> Language Class Initialized
INFO - 2023-01-10 07:36:44 --> Language Class Initialized
INFO - 2023-01-10 07:36:44 --> Loader Class Initialized
INFO - 2023-01-10 07:36:44 --> Loader Class Initialized
INFO - 2023-01-10 07:36:44 --> Controller Class Initialized
INFO - 2023-01-10 07:36:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:36:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:36:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:36:44 --> Final output sent to browser
DEBUG - 2023-01-10 07:36:44 --> Total execution time: 0.0288
INFO - 2023-01-10 07:36:44 --> Config Class Initialized
INFO - 2023-01-10 07:36:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:36:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:36:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:36:44 --> URI Class Initialized
INFO - 2023-01-10 07:36:44 --> Router Class Initialized
INFO - 2023-01-10 07:36:44 --> Output Class Initialized
INFO - 2023-01-10 07:36:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:36:44 --> Input Class Initialized
INFO - 2023-01-10 07:36:44 --> Language Class Initialized
INFO - 2023-01-10 07:36:44 --> Loader Class Initialized
INFO - 2023-01-10 07:36:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:36:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:36:44 --> Final output sent to browser
DEBUG - 2023-01-10 07:36:44 --> Total execution time: 0.0582
INFO - 2023-01-10 07:36:44 --> Config Class Initialized
INFO - 2023-01-10 07:36:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:36:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:36:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:36:44 --> URI Class Initialized
INFO - 2023-01-10 07:36:44 --> Router Class Initialized
INFO - 2023-01-10 07:36:44 --> Output Class Initialized
INFO - 2023-01-10 07:36:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:36:44 --> Input Class Initialized
INFO - 2023-01-10 07:36:44 --> Language Class Initialized
INFO - 2023-01-10 07:36:44 --> Loader Class Initialized
INFO - 2023-01-10 07:36:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:36:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:36:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:36:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:44 --> Config Class Initialized
INFO - 2023-01-10 07:51:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:44 --> URI Class Initialized
INFO - 2023-01-10 07:51:44 --> Router Class Initialized
INFO - 2023-01-10 07:51:44 --> Output Class Initialized
INFO - 2023-01-10 07:51:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:44 --> Input Class Initialized
INFO - 2023-01-10 07:51:44 --> Language Class Initialized
INFO - 2023-01-10 07:51:44 --> Loader Class Initialized
INFO - 2023-01-10 07:51:44 --> Controller Class Initialized
INFO - 2023-01-10 07:51:44 --> Helper loaded: form_helper
INFO - 2023-01-10 07:51:44 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:51:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:44 --> Model "Change_model" initialized
INFO - 2023-01-10 07:51:44 --> Model "Grafana_model" initialized
INFO - 2023-01-10 07:51:44 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:44 --> Total execution time: 0.0406
INFO - 2023-01-10 07:51:44 --> Config Class Initialized
INFO - 2023-01-10 07:51:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:44 --> URI Class Initialized
INFO - 2023-01-10 07:51:44 --> Router Class Initialized
INFO - 2023-01-10 07:51:44 --> Output Class Initialized
INFO - 2023-01-10 07:51:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:44 --> Input Class Initialized
INFO - 2023-01-10 07:51:44 --> Language Class Initialized
INFO - 2023-01-10 07:51:44 --> Loader Class Initialized
INFO - 2023-01-10 07:51:44 --> Controller Class Initialized
INFO - 2023-01-10 07:51:44 --> Helper loaded: form_helper
INFO - 2023-01-10 07:51:44 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:51:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:44 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:44 --> Total execution time: 0.0026
INFO - 2023-01-10 07:51:44 --> Config Class Initialized
INFO - 2023-01-10 07:51:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:44 --> URI Class Initialized
INFO - 2023-01-10 07:51:44 --> Router Class Initialized
INFO - 2023-01-10 07:51:44 --> Output Class Initialized
INFO - 2023-01-10 07:51:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:44 --> Input Class Initialized
INFO - 2023-01-10 07:51:44 --> Language Class Initialized
INFO - 2023-01-10 07:51:44 --> Loader Class Initialized
INFO - 2023-01-10 07:51:44 --> Controller Class Initialized
INFO - 2023-01-10 07:51:44 --> Helper loaded: form_helper
INFO - 2023-01-10 07:51:44 --> Helper loaded: url_helper
DEBUG - 2023-01-10 07:51:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:44 --> Model "Login_model" initialized
INFO - 2023-01-10 07:51:44 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:44 --> Total execution time: 0.0153
INFO - 2023-01-10 07:51:44 --> Config Class Initialized
INFO - 2023-01-10 07:51:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:44 --> URI Class Initialized
INFO - 2023-01-10 07:51:44 --> Router Class Initialized
INFO - 2023-01-10 07:51:44 --> Output Class Initialized
INFO - 2023-01-10 07:51:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:44 --> Input Class Initialized
INFO - 2023-01-10 07:51:44 --> Language Class Initialized
INFO - 2023-01-10 07:51:44 --> Loader Class Initialized
INFO - 2023-01-10 07:51:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:44 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:44 --> Total execution time: 0.0525
INFO - 2023-01-10 07:51:44 --> Config Class Initialized
INFO - 2023-01-10 07:51:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:44 --> URI Class Initialized
INFO - 2023-01-10 07:51:44 --> Router Class Initialized
INFO - 2023-01-10 07:51:44 --> Output Class Initialized
INFO - 2023-01-10 07:51:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:44 --> Input Class Initialized
INFO - 2023-01-10 07:51:44 --> Language Class Initialized
INFO - 2023-01-10 07:51:44 --> Loader Class Initialized
INFO - 2023-01-10 07:51:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:44 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:44 --> Total execution time: 0.0125
INFO - 2023-01-10 07:51:44 --> Config Class Initialized
INFO - 2023-01-10 07:51:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:44 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:44 --> URI Class Initialized
INFO - 2023-01-10 07:51:44 --> Router Class Initialized
INFO - 2023-01-10 07:51:44 --> Output Class Initialized
INFO - 2023-01-10 07:51:44 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:44 --> Input Class Initialized
INFO - 2023-01-10 07:51:44 --> Language Class Initialized
INFO - 2023-01-10 07:51:44 --> Loader Class Initialized
INFO - 2023-01-10 07:51:44 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:44 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:44 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:44 --> Model "Login_model" initialized
INFO - 2023-01-10 07:51:45 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:45 --> Total execution time: 0.1071
INFO - 2023-01-10 07:51:45 --> Config Class Initialized
INFO - 2023-01-10 07:51:45 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:45 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:45 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:45 --> URI Class Initialized
INFO - 2023-01-10 07:51:45 --> Router Class Initialized
INFO - 2023-01-10 07:51:45 --> Output Class Initialized
INFO - 2023-01-10 07:51:45 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:45 --> Input Class Initialized
INFO - 2023-01-10 07:51:45 --> Language Class Initialized
INFO - 2023-01-10 07:51:45 --> Loader Class Initialized
INFO - 2023-01-10 07:51:45 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:45 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:45 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:45 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:45 --> Model "Login_model" initialized
INFO - 2023-01-10 07:51:45 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:45 --> Total execution time: 0.0766
INFO - 2023-01-10 07:51:48 --> Config Class Initialized
INFO - 2023-01-10 07:51:48 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:48 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:48 --> URI Class Initialized
INFO - 2023-01-10 07:51:48 --> Router Class Initialized
INFO - 2023-01-10 07:51:48 --> Output Class Initialized
INFO - 2023-01-10 07:51:48 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:48 --> Input Class Initialized
INFO - 2023-01-10 07:51:48 --> Language Class Initialized
INFO - 2023-01-10 07:51:48 --> Loader Class Initialized
INFO - 2023-01-10 07:51:48 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:48 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:48 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:48 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:48 --> Total execution time: 0.0588
INFO - 2023-01-10 07:51:48 --> Config Class Initialized
INFO - 2023-01-10 07:51:48 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:48 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:48 --> URI Class Initialized
INFO - 2023-01-10 07:51:48 --> Router Class Initialized
INFO - 2023-01-10 07:51:48 --> Output Class Initialized
INFO - 2023-01-10 07:51:48 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:48 --> Input Class Initialized
INFO - 2023-01-10 07:51:48 --> Language Class Initialized
INFO - 2023-01-10 07:51:48 --> Loader Class Initialized
INFO - 2023-01-10 07:51:48 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:48 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:48 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:48 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:48 --> Total execution time: 0.0947
INFO - 2023-01-10 07:51:49 --> Config Class Initialized
INFO - 2023-01-10 07:51:49 --> Hooks Class Initialized
INFO - 2023-01-10 07:51:49 --> Config Class Initialized
DEBUG - 2023-01-10 07:51:49 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:49 --> Hooks Class Initialized
INFO - 2023-01-10 07:51:49 --> Utf8 Class Initialized
DEBUG - 2023-01-10 07:51:49 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:49 --> URI Class Initialized
INFO - 2023-01-10 07:51:49 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:49 --> Router Class Initialized
INFO - 2023-01-10 07:51:49 --> URI Class Initialized
INFO - 2023-01-10 07:51:49 --> Output Class Initialized
INFO - 2023-01-10 07:51:49 --> Router Class Initialized
INFO - 2023-01-10 07:51:49 --> Security Class Initialized
INFO - 2023-01-10 07:51:49 --> Output Class Initialized
DEBUG - 2023-01-10 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:49 --> Security Class Initialized
INFO - 2023-01-10 07:51:49 --> Input Class Initialized
DEBUG - 2023-01-10 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:49 --> Language Class Initialized
INFO - 2023-01-10 07:51:49 --> Input Class Initialized
INFO - 2023-01-10 07:51:49 --> Language Class Initialized
INFO - 2023-01-10 07:51:49 --> Loader Class Initialized
INFO - 2023-01-10 07:51:49 --> Loader Class Initialized
INFO - 2023-01-10 07:51:49 --> Controller Class Initialized
INFO - 2023-01-10 07:51:49 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:51:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:49 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:49 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:49 --> Total execution time: 0.0048
INFO - 2023-01-10 07:51:49 --> Config Class Initialized
INFO - 2023-01-10 07:51:49 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:49 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:49 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:49 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:49 --> URI Class Initialized
INFO - 2023-01-10 07:51:49 --> Router Class Initialized
INFO - 2023-01-10 07:51:49 --> Output Class Initialized
INFO - 2023-01-10 07:51:49 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:49 --> Input Class Initialized
INFO - 2023-01-10 07:51:49 --> Language Class Initialized
INFO - 2023-01-10 07:51:49 --> Loader Class Initialized
INFO - 2023-01-10 07:51:49 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:49 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:49 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:49 --> Total execution time: 0.0509
INFO - 2023-01-10 07:51:49 --> Config Class Initialized
INFO - 2023-01-10 07:51:49 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:49 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:49 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:49 --> URI Class Initialized
INFO - 2023-01-10 07:51:49 --> Router Class Initialized
INFO - 2023-01-10 07:51:49 --> Output Class Initialized
INFO - 2023-01-10 07:51:49 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:49 --> Input Class Initialized
INFO - 2023-01-10 07:51:49 --> Language Class Initialized
INFO - 2023-01-10 07:51:49 --> Loader Class Initialized
INFO - 2023-01-10 07:51:49 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:49 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:49 --> Model "Login_model" initialized
INFO - 2023-01-10 07:51:49 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:49 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:49 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:49 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:49 --> Total execution time: 0.0178
INFO - 2023-01-10 07:51:49 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:49 --> Total execution time: 0.0661
INFO - 2023-01-10 07:51:53 --> Config Class Initialized
INFO - 2023-01-10 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:53 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:53 --> URI Class Initialized
INFO - 2023-01-10 07:51:53 --> Router Class Initialized
INFO - 2023-01-10 07:51:53 --> Output Class Initialized
INFO - 2023-01-10 07:51:53 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:53 --> Input Class Initialized
INFO - 2023-01-10 07:51:53 --> Language Class Initialized
INFO - 2023-01-10 07:51:53 --> Loader Class Initialized
INFO - 2023-01-10 07:51:53 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:53 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:53 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:53 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:53 --> Total execution time: 0.0194
INFO - 2023-01-10 07:51:53 --> Config Class Initialized
INFO - 2023-01-10 07:51:53 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:51:53 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:51:53 --> Utf8 Class Initialized
INFO - 2023-01-10 07:51:53 --> URI Class Initialized
INFO - 2023-01-10 07:51:53 --> Router Class Initialized
INFO - 2023-01-10 07:51:53 --> Output Class Initialized
INFO - 2023-01-10 07:51:53 --> Security Class Initialized
DEBUG - 2023-01-10 07:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:51:53 --> Input Class Initialized
INFO - 2023-01-10 07:51:53 --> Language Class Initialized
INFO - 2023-01-10 07:51:53 --> Loader Class Initialized
INFO - 2023-01-10 07:51:53 --> Controller Class Initialized
DEBUG - 2023-01-10 07:51:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:51:53 --> Database Driver Class Initialized
INFO - 2023-01-10 07:51:53 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:51:53 --> Final output sent to browser
DEBUG - 2023-01-10 07:51:53 --> Total execution time: 0.0570
INFO - 2023-01-10 07:52:00 --> Config Class Initialized
INFO - 2023-01-10 07:52:00 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:52:00 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:52:00 --> Utf8 Class Initialized
INFO - 2023-01-10 07:52:00 --> URI Class Initialized
INFO - 2023-01-10 07:52:00 --> Router Class Initialized
INFO - 2023-01-10 07:52:00 --> Output Class Initialized
INFO - 2023-01-10 07:52:00 --> Security Class Initialized
DEBUG - 2023-01-10 07:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:52:00 --> Input Class Initialized
INFO - 2023-01-10 07:52:00 --> Language Class Initialized
INFO - 2023-01-10 07:52:00 --> Loader Class Initialized
INFO - 2023-01-10 07:52:00 --> Controller Class Initialized
DEBUG - 2023-01-10 07:52:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:52:00 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:00 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:00 --> Model "Login_model" initialized
INFO - 2023-01-10 07:52:00 --> Final output sent to browser
DEBUG - 2023-01-10 07:52:00 --> Total execution time: 0.0339
INFO - 2023-01-10 07:52:00 --> Config Class Initialized
INFO - 2023-01-10 07:52:00 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:52:00 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:52:00 --> Utf8 Class Initialized
INFO - 2023-01-10 07:52:00 --> URI Class Initialized
INFO - 2023-01-10 07:52:00 --> Router Class Initialized
INFO - 2023-01-10 07:52:00 --> Output Class Initialized
INFO - 2023-01-10 07:52:00 --> Security Class Initialized
DEBUG - 2023-01-10 07:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:52:00 --> Input Class Initialized
INFO - 2023-01-10 07:52:00 --> Language Class Initialized
INFO - 2023-01-10 07:52:00 --> Loader Class Initialized
INFO - 2023-01-10 07:52:00 --> Controller Class Initialized
DEBUG - 2023-01-10 07:52:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:52:00 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:00 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:00 --> Model "Login_model" initialized
INFO - 2023-01-10 07:52:00 --> Final output sent to browser
DEBUG - 2023-01-10 07:52:00 --> Total execution time: 0.0640
INFO - 2023-01-10 07:52:02 --> Config Class Initialized
INFO - 2023-01-10 07:52:02 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:52:02 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:52:02 --> Utf8 Class Initialized
INFO - 2023-01-10 07:52:02 --> URI Class Initialized
INFO - 2023-01-10 07:52:02 --> Router Class Initialized
INFO - 2023-01-10 07:52:02 --> Output Class Initialized
INFO - 2023-01-10 07:52:02 --> Security Class Initialized
DEBUG - 2023-01-10 07:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:52:02 --> Input Class Initialized
INFO - 2023-01-10 07:52:02 --> Language Class Initialized
INFO - 2023-01-10 07:52:02 --> Loader Class Initialized
INFO - 2023-01-10 07:52:02 --> Controller Class Initialized
DEBUG - 2023-01-10 07:52:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:52:02 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:02 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:02 --> Model "Login_model" initialized
INFO - 2023-01-10 07:52:02 --> Final output sent to browser
DEBUG - 2023-01-10 07:52:02 --> Total execution time: 0.0272
INFO - 2023-01-10 07:52:02 --> Config Class Initialized
INFO - 2023-01-10 07:52:02 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:52:02 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:52:02 --> Utf8 Class Initialized
INFO - 2023-01-10 07:52:02 --> URI Class Initialized
INFO - 2023-01-10 07:52:02 --> Router Class Initialized
INFO - 2023-01-10 07:52:02 --> Output Class Initialized
INFO - 2023-01-10 07:52:02 --> Security Class Initialized
DEBUG - 2023-01-10 07:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:52:02 --> Input Class Initialized
INFO - 2023-01-10 07:52:02 --> Language Class Initialized
INFO - 2023-01-10 07:52:02 --> Loader Class Initialized
INFO - 2023-01-10 07:52:02 --> Controller Class Initialized
DEBUG - 2023-01-10 07:52:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:52:02 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:02 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:02 --> Model "Login_model" initialized
INFO - 2023-01-10 07:52:02 --> Final output sent to browser
DEBUG - 2023-01-10 07:52:02 --> Total execution time: 0.0617
INFO - 2023-01-10 07:52:09 --> Config Class Initialized
INFO - 2023-01-10 07:52:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:52:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:52:09 --> Utf8 Class Initialized
INFO - 2023-01-10 07:52:09 --> URI Class Initialized
INFO - 2023-01-10 07:52:09 --> Router Class Initialized
INFO - 2023-01-10 07:52:09 --> Output Class Initialized
INFO - 2023-01-10 07:52:09 --> Security Class Initialized
DEBUG - 2023-01-10 07:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:52:09 --> Input Class Initialized
INFO - 2023-01-10 07:52:09 --> Language Class Initialized
INFO - 2023-01-10 07:52:09 --> Loader Class Initialized
INFO - 2023-01-10 07:52:09 --> Controller Class Initialized
DEBUG - 2023-01-10 07:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:52:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:09 --> Model "Login_model" initialized
ERROR - 2023-01-10 07:52:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%te%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%te%'
ERROR - 2023-01-10 07:52:09 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 07:52:09 --> Config Class Initialized
INFO - 2023-01-10 07:52:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:52:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:52:09 --> Utf8 Class Initialized
INFO - 2023-01-10 07:52:09 --> URI Class Initialized
INFO - 2023-01-10 07:52:09 --> Router Class Initialized
INFO - 2023-01-10 07:52:09 --> Output Class Initialized
INFO - 2023-01-10 07:52:09 --> Security Class Initialized
DEBUG - 2023-01-10 07:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:52:09 --> Input Class Initialized
INFO - 2023-01-10 07:52:09 --> Language Class Initialized
INFO - 2023-01-10 07:52:09 --> Loader Class Initialized
INFO - 2023-01-10 07:52:09 --> Controller Class Initialized
DEBUG - 2023-01-10 07:52:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:52:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:09 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:09 --> Model "Login_model" initialized
ERROR - 2023-01-10 07:52:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%te%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%te%'
ERROR - 2023-01-10 07:52:09 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 07:52:18 --> Config Class Initialized
INFO - 2023-01-10 07:52:18 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:52:18 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:52:18 --> Utf8 Class Initialized
INFO - 2023-01-10 07:52:18 --> URI Class Initialized
INFO - 2023-01-10 07:52:18 --> Router Class Initialized
INFO - 2023-01-10 07:52:18 --> Output Class Initialized
INFO - 2023-01-10 07:52:18 --> Security Class Initialized
DEBUG - 2023-01-10 07:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:52:18 --> Input Class Initialized
INFO - 2023-01-10 07:52:18 --> Language Class Initialized
INFO - 2023-01-10 07:52:18 --> Loader Class Initialized
INFO - 2023-01-10 07:52:18 --> Controller Class Initialized
DEBUG - 2023-01-10 07:52:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:52:18 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:18 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:18 --> Model "Login_model" initialized
ERROR - 2023-01-10 07:52:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%te%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%te%'
ERROR - 2023-01-10 07:52:18 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 07:52:18 --> Config Class Initialized
INFO - 2023-01-10 07:52:18 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:52:18 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:52:18 --> Utf8 Class Initialized
INFO - 2023-01-10 07:52:18 --> URI Class Initialized
INFO - 2023-01-10 07:52:18 --> Router Class Initialized
INFO - 2023-01-10 07:52:18 --> Output Class Initialized
INFO - 2023-01-10 07:52:18 --> Security Class Initialized
DEBUG - 2023-01-10 07:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:52:18 --> Input Class Initialized
INFO - 2023-01-10 07:52:18 --> Language Class Initialized
INFO - 2023-01-10 07:52:18 --> Loader Class Initialized
INFO - 2023-01-10 07:52:18 --> Controller Class Initialized
DEBUG - 2023-01-10 07:52:18 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:52:18 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:18 --> Database Driver Class Initialized
INFO - 2023-01-10 07:52:18 --> Model "Login_model" initialized
ERROR - 2023-01-10 07:52:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%te%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%te%'
ERROR - 2023-01-10 07:52:18 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 07:56:37 --> Config Class Initialized
INFO - 2023-01-10 07:56:37 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:56:37 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:56:37 --> Utf8 Class Initialized
INFO - 2023-01-10 07:56:37 --> URI Class Initialized
INFO - 2023-01-10 07:56:37 --> Router Class Initialized
INFO - 2023-01-10 07:56:37 --> Output Class Initialized
INFO - 2023-01-10 07:56:37 --> Security Class Initialized
DEBUG - 2023-01-10 07:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:56:37 --> Input Class Initialized
INFO - 2023-01-10 07:56:37 --> Language Class Initialized
INFO - 2023-01-10 07:56:37 --> Loader Class Initialized
INFO - 2023-01-10 07:56:37 --> Controller Class Initialized
DEBUG - 2023-01-10 07:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:56:37 --> Database Driver Class Initialized
INFO - 2023-01-10 07:56:37 --> Database Driver Class Initialized
INFO - 2023-01-10 07:56:37 --> Model "Login_model" initialized
INFO - 2023-01-10 07:56:37 --> Final output sent to browser
DEBUG - 2023-01-10 07:56:37 --> Total execution time: 0.1085
INFO - 2023-01-10 07:56:37 --> Config Class Initialized
INFO - 2023-01-10 07:56:37 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:56:37 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:56:37 --> Utf8 Class Initialized
INFO - 2023-01-10 07:56:37 --> URI Class Initialized
INFO - 2023-01-10 07:56:37 --> Router Class Initialized
INFO - 2023-01-10 07:56:37 --> Output Class Initialized
INFO - 2023-01-10 07:56:37 --> Security Class Initialized
DEBUG - 2023-01-10 07:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:56:37 --> Input Class Initialized
INFO - 2023-01-10 07:56:37 --> Language Class Initialized
INFO - 2023-01-10 07:56:37 --> Loader Class Initialized
INFO - 2023-01-10 07:56:37 --> Controller Class Initialized
DEBUG - 2023-01-10 07:56:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:56:37 --> Database Driver Class Initialized
INFO - 2023-01-10 07:56:37 --> Database Driver Class Initialized
INFO - 2023-01-10 07:56:37 --> Model "Login_model" initialized
INFO - 2023-01-10 07:56:37 --> Final output sent to browser
DEBUG - 2023-01-10 07:56:37 --> Total execution time: 0.1097
INFO - 2023-01-10 07:57:26 --> Config Class Initialized
INFO - 2023-01-10 07:57:26 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:26 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:26 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:26 --> URI Class Initialized
INFO - 2023-01-10 07:57:26 --> Router Class Initialized
INFO - 2023-01-10 07:57:26 --> Output Class Initialized
INFO - 2023-01-10 07:57:26 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:26 --> Input Class Initialized
INFO - 2023-01-10 07:57:26 --> Language Class Initialized
INFO - 2023-01-10 07:57:26 --> Loader Class Initialized
INFO - 2023-01-10 07:57:26 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:26 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:26 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:26 --> Model "Login_model" initialized
ERROR - 2023-01-10 07:57:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 07:57:26 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 07:57:26 --> Config Class Initialized
INFO - 2023-01-10 07:57:26 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:26 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:26 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:26 --> URI Class Initialized
INFO - 2023-01-10 07:57:26 --> Router Class Initialized
INFO - 2023-01-10 07:57:26 --> Output Class Initialized
INFO - 2023-01-10 07:57:26 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:26 --> Input Class Initialized
INFO - 2023-01-10 07:57:26 --> Language Class Initialized
INFO - 2023-01-10 07:57:26 --> Loader Class Initialized
INFO - 2023-01-10 07:57:26 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:26 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:26 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:26 --> Model "Login_model" initialized
ERROR - 2023-01-10 07:57:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 07:57:26 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 07:57:28 --> Config Class Initialized
INFO - 2023-01-10 07:57:28 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:28 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:28 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:28 --> URI Class Initialized
INFO - 2023-01-10 07:57:28 --> Router Class Initialized
INFO - 2023-01-10 07:57:28 --> Output Class Initialized
INFO - 2023-01-10 07:57:28 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:28 --> Input Class Initialized
INFO - 2023-01-10 07:57:28 --> Language Class Initialized
INFO - 2023-01-10 07:57:28 --> Loader Class Initialized
INFO - 2023-01-10 07:57:28 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:28 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:28 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:28 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:28 --> Final output sent to browser
DEBUG - 2023-01-10 07:57:28 --> Total execution time: 0.0285
INFO - 2023-01-10 07:57:28 --> Config Class Initialized
INFO - 2023-01-10 07:57:28 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:28 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:28 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:28 --> URI Class Initialized
INFO - 2023-01-10 07:57:28 --> Router Class Initialized
INFO - 2023-01-10 07:57:28 --> Output Class Initialized
INFO - 2023-01-10 07:57:28 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:28 --> Input Class Initialized
INFO - 2023-01-10 07:57:28 --> Language Class Initialized
INFO - 2023-01-10 07:57:28 --> Loader Class Initialized
INFO - 2023-01-10 07:57:28 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:28 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:28 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:28 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:28 --> Final output sent to browser
DEBUG - 2023-01-10 07:57:28 --> Total execution time: 0.0588
INFO - 2023-01-10 07:57:31 --> Config Class Initialized
INFO - 2023-01-10 07:57:31 --> Config Class Initialized
INFO - 2023-01-10 07:57:31 --> Config Class Initialized
INFO - 2023-01-10 07:57:31 --> Hooks Class Initialized
INFO - 2023-01-10 07:57:31 --> Hooks Class Initialized
INFO - 2023-01-10 07:57:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:57:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:31 --> Utf8 Class Initialized
DEBUG - 2023-01-10 07:57:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:31 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:31 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:31 --> URI Class Initialized
INFO - 2023-01-10 07:57:31 --> URI Class Initialized
INFO - 2023-01-10 07:57:31 --> Router Class Initialized
INFO - 2023-01-10 07:57:31 --> Output Class Initialized
INFO - 2023-01-10 07:57:31 --> Security Class Initialized
INFO - 2023-01-10 07:57:31 --> Router Class Initialized
INFO - 2023-01-10 07:57:31 --> URI Class Initialized
INFO - 2023-01-10 07:57:31 --> Output Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:31 --> Input Class Initialized
INFO - 2023-01-10 07:57:31 --> Router Class Initialized
INFO - 2023-01-10 07:57:31 --> Security Class Initialized
INFO - 2023-01-10 07:57:31 --> Language Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:31 --> Output Class Initialized
INFO - 2023-01-10 07:57:31 --> Loader Class Initialized
INFO - 2023-01-10 07:57:31 --> Input Class Initialized
INFO - 2023-01-10 07:57:31 --> Security Class Initialized
INFO - 2023-01-10 07:57:31 --> Controller Class Initialized
INFO - 2023-01-10 07:57:31 --> Language Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:31 --> Loader Class Initialized
INFO - 2023-01-10 07:57:31 --> Input Class Initialized
INFO - 2023-01-10 07:57:31 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:31 --> Controller Class Initialized
INFO - 2023-01-10 07:57:31 --> Language Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:31 --> Loader Class Initialized
INFO - 2023-01-10 07:57:31 --> Controller Class Initialized
INFO - 2023-01-10 07:57:31 --> Database Driver Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:31 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:31 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:31 --> Final output sent to browser
INFO - 2023-01-10 07:57:31 --> Final output sent to browser
DEBUG - 2023-01-10 07:57:31 --> Total execution time: 0.0365
DEBUG - 2023-01-10 07:57:31 --> Total execution time: 0.0368
INFO - 2023-01-10 07:57:31 --> Config Class Initialized
INFO - 2023-01-10 07:57:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:31 --> Config Class Initialized
INFO - 2023-01-10 07:57:31 --> Final output sent to browser
DEBUG - 2023-01-10 07:57:31 --> Total execution time: 0.0467
INFO - 2023-01-10 07:57:31 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:31 --> Hooks Class Initialized
INFO - 2023-01-10 07:57:31 --> URI Class Initialized
DEBUG - 2023-01-10 07:57:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:31 --> Router Class Initialized
INFO - 2023-01-10 07:57:31 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:31 --> Output Class Initialized
INFO - 2023-01-10 07:57:31 --> URI Class Initialized
INFO - 2023-01-10 07:57:31 --> Security Class Initialized
INFO - 2023-01-10 07:57:31 --> Router Class Initialized
INFO - 2023-01-10 07:57:31 --> Config Class Initialized
INFO - 2023-01-10 07:57:31 --> Output Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:31 --> Hooks Class Initialized
INFO - 2023-01-10 07:57:31 --> Security Class Initialized
INFO - 2023-01-10 07:57:31 --> Input Class Initialized
DEBUG - 2023-01-10 07:57:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:31 --> Language Class Initialized
INFO - 2023-01-10 07:57:31 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:31 --> Input Class Initialized
INFO - 2023-01-10 07:57:31 --> URI Class Initialized
INFO - 2023-01-10 07:57:31 --> Language Class Initialized
INFO - 2023-01-10 07:57:31 --> Loader Class Initialized
INFO - 2023-01-10 07:57:31 --> Router Class Initialized
INFO - 2023-01-10 07:57:31 --> Loader Class Initialized
INFO - 2023-01-10 07:57:31 --> Controller Class Initialized
INFO - 2023-01-10 07:57:31 --> Output Class Initialized
INFO - 2023-01-10 07:57:31 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:31 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:31 --> Final output sent to browser
INFO - 2023-01-10 07:57:31 --> Input Class Initialized
INFO - 2023-01-10 07:57:31 --> Database Driver Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Total execution time: 0.0437
INFO - 2023-01-10 07:57:31 --> Language Class Initialized
INFO - 2023-01-10 07:57:31 --> Loader Class Initialized
INFO - 2023-01-10 07:57:31 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:31 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:31 --> Config Class Initialized
INFO - 2023-01-10 07:57:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:31 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:31 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:31 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:31 --> URI Class Initialized
INFO - 2023-01-10 07:57:32 --> Router Class Initialized
INFO - 2023-01-10 07:57:32 --> Output Class Initialized
INFO - 2023-01-10 07:57:32 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:32 --> Input Class Initialized
INFO - 2023-01-10 07:57:32 --> Language Class Initialized
INFO - 2023-01-10 07:57:32 --> Loader Class Initialized
INFO - 2023-01-10 07:57:32 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:32 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:32 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:32 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:32 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:32 --> Final output sent to browser
INFO - 2023-01-10 07:57:32 --> Final output sent to browser
DEBUG - 2023-01-10 07:57:32 --> Total execution time: 0.0952
DEBUG - 2023-01-10 07:57:32 --> Total execution time: 0.0565
INFO - 2023-01-10 07:57:32 --> Config Class Initialized
INFO - 2023-01-10 07:57:32 --> Final output sent to browser
INFO - 2023-01-10 07:57:32 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:32 --> Total execution time: 0.0616
DEBUG - 2023-01-10 07:57:32 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:32 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:32 --> URI Class Initialized
INFO - 2023-01-10 07:57:32 --> Router Class Initialized
INFO - 2023-01-10 07:57:32 --> Output Class Initialized
INFO - 2023-01-10 07:57:32 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:32 --> Input Class Initialized
INFO - 2023-01-10 07:57:32 --> Language Class Initialized
INFO - 2023-01-10 07:57:32 --> Loader Class Initialized
INFO - 2023-01-10 07:57:32 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:32 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:32 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:32 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:32 --> Model "Cluster_model" initialized
INFO - 2023-01-10 07:57:32 --> Final output sent to browser
DEBUG - 2023-01-10 07:57:32 --> Total execution time: 0.1036
INFO - 2023-01-10 07:57:34 --> Config Class Initialized
INFO - 2023-01-10 07:57:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:34 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:34 --> URI Class Initialized
INFO - 2023-01-10 07:57:34 --> Router Class Initialized
INFO - 2023-01-10 07:57:34 --> Output Class Initialized
INFO - 2023-01-10 07:57:34 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:34 --> Input Class Initialized
INFO - 2023-01-10 07:57:34 --> Language Class Initialized
INFO - 2023-01-10 07:57:34 --> Loader Class Initialized
INFO - 2023-01-10 07:57:34 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:34 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:34 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:34 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:34 --> Final output sent to browser
DEBUG - 2023-01-10 07:57:34 --> Total execution time: 0.0531
INFO - 2023-01-10 07:57:34 --> Config Class Initialized
INFO - 2023-01-10 07:57:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:34 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:34 --> URI Class Initialized
INFO - 2023-01-10 07:57:34 --> Router Class Initialized
INFO - 2023-01-10 07:57:34 --> Output Class Initialized
INFO - 2023-01-10 07:57:34 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:34 --> Input Class Initialized
INFO - 2023-01-10 07:57:34 --> Language Class Initialized
INFO - 2023-01-10 07:57:34 --> Loader Class Initialized
INFO - 2023-01-10 07:57:34 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:34 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:34 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:34 --> Model "Login_model" initialized
INFO - 2023-01-10 07:57:34 --> Final output sent to browser
DEBUG - 2023-01-10 07:57:34 --> Total execution time: 0.0581
INFO - 2023-01-10 07:57:40 --> Config Class Initialized
INFO - 2023-01-10 07:57:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:40 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:40 --> URI Class Initialized
INFO - 2023-01-10 07:57:40 --> Router Class Initialized
INFO - 2023-01-10 07:57:40 --> Output Class Initialized
INFO - 2023-01-10 07:57:40 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:40 --> Input Class Initialized
INFO - 2023-01-10 07:57:40 --> Language Class Initialized
INFO - 2023-01-10 07:57:40 --> Loader Class Initialized
INFO - 2023-01-10 07:57:40 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:40 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:40 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:40 --> Model "Login_model" initialized
ERROR - 2023-01-10 07:57:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 07:57:40 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 07:57:40 --> Config Class Initialized
INFO - 2023-01-10 07:57:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 07:57:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 07:57:40 --> Utf8 Class Initialized
INFO - 2023-01-10 07:57:40 --> URI Class Initialized
INFO - 2023-01-10 07:57:40 --> Router Class Initialized
INFO - 2023-01-10 07:57:40 --> Output Class Initialized
INFO - 2023-01-10 07:57:40 --> Security Class Initialized
DEBUG - 2023-01-10 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 07:57:40 --> Input Class Initialized
INFO - 2023-01-10 07:57:40 --> Language Class Initialized
INFO - 2023-01-10 07:57:40 --> Loader Class Initialized
INFO - 2023-01-10 07:57:40 --> Controller Class Initialized
DEBUG - 2023-01-10 07:57:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 07:57:40 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:40 --> Database Driver Class Initialized
INFO - 2023-01-10 07:57:40 --> Model "Login_model" initialized
ERROR - 2023-01-10 07:57:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 07:57:40 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 08:48:38 --> Config Class Initialized
INFO - 2023-01-10 08:48:38 --> Hooks Class Initialized
DEBUG - 2023-01-10 08:48:39 --> UTF-8 Support Enabled
INFO - 2023-01-10 08:48:39 --> Utf8 Class Initialized
INFO - 2023-01-10 08:48:39 --> URI Class Initialized
INFO - 2023-01-10 08:48:39 --> Router Class Initialized
INFO - 2023-01-10 08:48:39 --> Output Class Initialized
INFO - 2023-01-10 08:48:39 --> Security Class Initialized
DEBUG - 2023-01-10 08:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 08:48:39 --> Input Class Initialized
INFO - 2023-01-10 08:48:39 --> Language Class Initialized
INFO - 2023-01-10 08:48:39 --> Loader Class Initialized
INFO - 2023-01-10 08:48:39 --> Controller Class Initialized
INFO - 2023-01-10 08:48:39 --> Helper loaded: form_helper
INFO - 2023-01-10 08:48:39 --> Helper loaded: url_helper
DEBUG - 2023-01-10 08:48:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 08:48:39 --> Model "Change_model" initialized
INFO - 2023-01-10 08:50:08 --> Config Class Initialized
INFO - 2023-01-10 08:50:08 --> Hooks Class Initialized
DEBUG - 2023-01-10 08:50:08 --> UTF-8 Support Enabled
INFO - 2023-01-10 08:50:08 --> Utf8 Class Initialized
INFO - 2023-01-10 08:50:08 --> URI Class Initialized
INFO - 2023-01-10 08:50:08 --> Router Class Initialized
INFO - 2023-01-10 08:50:08 --> Output Class Initialized
INFO - 2023-01-10 08:50:08 --> Security Class Initialized
DEBUG - 2023-01-10 08:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 08:50:08 --> Input Class Initialized
INFO - 2023-01-10 08:50:08 --> Language Class Initialized
INFO - 2023-01-10 08:50:08 --> Loader Class Initialized
INFO - 2023-01-10 08:50:08 --> Controller Class Initialized
INFO - 2023-01-10 08:50:09 --> Helper loaded: form_helper
INFO - 2023-01-10 08:50:09 --> Helper loaded: url_helper
DEBUG - 2023-01-10 08:50:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 08:50:09 --> Model "Change_model" initialized
INFO - 2023-01-10 09:03:01 --> Config Class Initialized
INFO - 2023-01-10 09:03:01 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:03:01 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:03:01 --> Utf8 Class Initialized
INFO - 2023-01-10 09:03:01 --> URI Class Initialized
INFO - 2023-01-10 09:03:01 --> Router Class Initialized
INFO - 2023-01-10 09:03:01 --> Output Class Initialized
INFO - 2023-01-10 09:03:01 --> Security Class Initialized
DEBUG - 2023-01-10 09:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:03:01 --> Input Class Initialized
INFO - 2023-01-10 09:03:01 --> Language Class Initialized
INFO - 2023-01-10 09:03:01 --> Loader Class Initialized
INFO - 2023-01-10 09:03:01 --> Controller Class Initialized
INFO - 2023-01-10 09:03:01 --> Helper loaded: form_helper
INFO - 2023-01-10 09:03:01 --> Helper loaded: url_helper
DEBUG - 2023-01-10 09:03:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:03:01 --> Model "Change_model" initialized
INFO - 2023-01-10 09:06:01 --> Final output sent to browser
DEBUG - 2023-01-10 09:06:01 --> Total execution time: 180.2618
INFO - 2023-01-10 09:08:40 --> Config Class Initialized
INFO - 2023-01-10 09:08:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:08:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:08:40 --> Utf8 Class Initialized
INFO - 2023-01-10 09:08:40 --> URI Class Initialized
INFO - 2023-01-10 09:08:40 --> Router Class Initialized
INFO - 2023-01-10 09:08:40 --> Output Class Initialized
INFO - 2023-01-10 09:08:40 --> Security Class Initialized
DEBUG - 2023-01-10 09:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:08:40 --> Input Class Initialized
INFO - 2023-01-10 09:08:40 --> Language Class Initialized
INFO - 2023-01-10 09:08:40 --> Loader Class Initialized
INFO - 2023-01-10 09:08:40 --> Controller Class Initialized
DEBUG - 2023-01-10 09:08:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:08:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:40 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:08:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:40 --> Model "Login_model" initialized
INFO - 2023-01-10 09:08:40 --> Final output sent to browser
DEBUG - 2023-01-10 09:08:40 --> Total execution time: 0.1442
INFO - 2023-01-10 09:08:40 --> Config Class Initialized
INFO - 2023-01-10 09:08:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:08:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:08:40 --> Utf8 Class Initialized
INFO - 2023-01-10 09:08:40 --> URI Class Initialized
INFO - 2023-01-10 09:08:40 --> Router Class Initialized
INFO - 2023-01-10 09:08:40 --> Output Class Initialized
INFO - 2023-01-10 09:08:40 --> Security Class Initialized
DEBUG - 2023-01-10 09:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:08:40 --> Input Class Initialized
INFO - 2023-01-10 09:08:40 --> Language Class Initialized
INFO - 2023-01-10 09:08:40 --> Loader Class Initialized
INFO - 2023-01-10 09:08:40 --> Controller Class Initialized
DEBUG - 2023-01-10 09:08:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:08:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:40 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:08:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:40 --> Model "Login_model" initialized
INFO - 2023-01-10 09:08:40 --> Final output sent to browser
DEBUG - 2023-01-10 09:08:40 --> Total execution time: 0.1057
INFO - 2023-01-10 09:08:48 --> Config Class Initialized
INFO - 2023-01-10 09:08:48 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:08:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:08:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:08:48 --> URI Class Initialized
INFO - 2023-01-10 09:08:48 --> Router Class Initialized
INFO - 2023-01-10 09:08:48 --> Output Class Initialized
INFO - 2023-01-10 09:08:48 --> Security Class Initialized
DEBUG - 2023-01-10 09:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:08:48 --> Input Class Initialized
INFO - 2023-01-10 09:08:48 --> Language Class Initialized
INFO - 2023-01-10 09:08:48 --> Loader Class Initialized
INFO - 2023-01-10 09:08:48 --> Controller Class Initialized
DEBUG - 2023-01-10 09:08:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:08:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:48 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:08:58 --> Config Class Initialized
INFO - 2023-01-10 09:08:58 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:08:58 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:08:58 --> Utf8 Class Initialized
INFO - 2023-01-10 09:08:58 --> URI Class Initialized
INFO - 2023-01-10 09:08:58 --> Router Class Initialized
INFO - 2023-01-10 09:08:58 --> Output Class Initialized
INFO - 2023-01-10 09:08:58 --> Security Class Initialized
DEBUG - 2023-01-10 09:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:08:58 --> Input Class Initialized
INFO - 2023-01-10 09:08:58 --> Language Class Initialized
INFO - 2023-01-10 09:08:58 --> Loader Class Initialized
INFO - 2023-01-10 09:08:58 --> Controller Class Initialized
DEBUG - 2023-01-10 09:08:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:08:58 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:58 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:58 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:08:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:08:58 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:08:58 --> Config Class Initialized
INFO - 2023-01-10 09:08:58 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:08:58 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:08:58 --> Utf8 Class Initialized
INFO - 2023-01-10 09:08:58 --> URI Class Initialized
INFO - 2023-01-10 09:08:58 --> Router Class Initialized
INFO - 2023-01-10 09:08:58 --> Output Class Initialized
INFO - 2023-01-10 09:08:58 --> Security Class Initialized
DEBUG - 2023-01-10 09:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:08:58 --> Input Class Initialized
INFO - 2023-01-10 09:08:58 --> Language Class Initialized
INFO - 2023-01-10 09:08:58 --> Loader Class Initialized
INFO - 2023-01-10 09:08:58 --> Controller Class Initialized
DEBUG - 2023-01-10 09:08:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:08:58 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:58 --> Database Driver Class Initialized
INFO - 2023-01-10 09:08:58 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:08:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:08:58 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(55): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:10:35 --> Config Class Initialized
INFO - 2023-01-10 09:10:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:10:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:10:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:10:35 --> URI Class Initialized
INFO - 2023-01-10 09:10:35 --> Router Class Initialized
INFO - 2023-01-10 09:10:35 --> Output Class Initialized
INFO - 2023-01-10 09:10:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:10:35 --> Input Class Initialized
INFO - 2023-01-10 09:10:35 --> Language Class Initialized
INFO - 2023-01-10 09:10:35 --> Loader Class Initialized
INFO - 2023-01-10 09:10:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:10:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:10:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:10:35 --> Model "Login_model" initialized
INFO - 2023-01-10 09:10:35 --> Config Class Initialized
INFO - 2023-01-10 09:10:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:10:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:10:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:10:35 --> URI Class Initialized
INFO - 2023-01-10 09:10:35 --> Router Class Initialized
INFO - 2023-01-10 09:10:35 --> Output Class Initialized
INFO - 2023-01-10 09:10:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:10:35 --> Input Class Initialized
INFO - 2023-01-10 09:10:35 --> Language Class Initialized
INFO - 2023-01-10 09:10:35 --> Loader Class Initialized
INFO - 2023-01-10 09:10:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:10:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:10:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:10:35 --> Model "Login_model" initialized
INFO - 2023-01-10 09:11:04 --> Config Class Initialized
INFO - 2023-01-10 09:11:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:11:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:11:04 --> Utf8 Class Initialized
INFO - 2023-01-10 09:11:04 --> URI Class Initialized
INFO - 2023-01-10 09:11:04 --> Router Class Initialized
INFO - 2023-01-10 09:11:04 --> Output Class Initialized
INFO - 2023-01-10 09:11:04 --> Security Class Initialized
DEBUG - 2023-01-10 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:11:04 --> Input Class Initialized
INFO - 2023-01-10 09:11:04 --> Language Class Initialized
INFO - 2023-01-10 09:11:04 --> Loader Class Initialized
INFO - 2023-01-10 09:11:04 --> Controller Class Initialized
DEBUG - 2023-01-10 09:11:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:11:04 --> Database Driver Class Initialized
INFO - 2023-01-10 09:11:04 --> Database Driver Class Initialized
INFO - 2023-01-10 09:11:04 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:11:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:11:04 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:11:04 --> Config Class Initialized
INFO - 2023-01-10 09:11:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:11:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:11:04 --> Utf8 Class Initialized
INFO - 2023-01-10 09:11:04 --> URI Class Initialized
INFO - 2023-01-10 09:11:04 --> Router Class Initialized
INFO - 2023-01-10 09:11:04 --> Output Class Initialized
INFO - 2023-01-10 09:11:04 --> Security Class Initialized
DEBUG - 2023-01-10 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:11:04 --> Input Class Initialized
INFO - 2023-01-10 09:11:04 --> Language Class Initialized
INFO - 2023-01-10 09:11:04 --> Loader Class Initialized
INFO - 2023-01-10 09:11:04 --> Controller Class Initialized
DEBUG - 2023-01-10 09:11:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:11:04 --> Database Driver Class Initialized
INFO - 2023-01-10 09:11:04 --> Database Driver Class Initialized
INFO - 2023-01-10 09:11:04 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:11:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:11:04 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:12:13 --> Config Class Initialized
INFO - 2023-01-10 09:12:13 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:12:13 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:12:13 --> Utf8 Class Initialized
INFO - 2023-01-10 09:12:13 --> URI Class Initialized
INFO - 2023-01-10 09:12:13 --> Router Class Initialized
INFO - 2023-01-10 09:12:13 --> Output Class Initialized
INFO - 2023-01-10 09:12:13 --> Security Class Initialized
DEBUG - 2023-01-10 09:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:12:13 --> Input Class Initialized
INFO - 2023-01-10 09:12:13 --> Language Class Initialized
INFO - 2023-01-10 09:12:13 --> Loader Class Initialized
INFO - 2023-01-10 09:12:13 --> Controller Class Initialized
DEBUG - 2023-01-10 09:12:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:12:13 --> Database Driver Class Initialized
INFO - 2023-01-10 09:12:13 --> Database Driver Class Initialized
INFO - 2023-01-10 09:12:13 --> Model "Login_model" initialized
INFO - 2023-01-10 09:12:13 --> Config Class Initialized
INFO - 2023-01-10 09:12:13 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:12:13 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:12:13 --> Utf8 Class Initialized
INFO - 2023-01-10 09:12:13 --> URI Class Initialized
INFO - 2023-01-10 09:12:13 --> Router Class Initialized
INFO - 2023-01-10 09:12:13 --> Output Class Initialized
INFO - 2023-01-10 09:12:13 --> Security Class Initialized
DEBUG - 2023-01-10 09:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:12:13 --> Input Class Initialized
INFO - 2023-01-10 09:12:13 --> Language Class Initialized
INFO - 2023-01-10 09:12:13 --> Loader Class Initialized
INFO - 2023-01-10 09:12:13 --> Controller Class Initialized
DEBUG - 2023-01-10 09:12:13 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:12:13 --> Database Driver Class Initialized
INFO - 2023-01-10 09:12:13 --> Database Driver Class Initialized
INFO - 2023-01-10 09:12:13 --> Model "Login_model" initialized
INFO - 2023-01-10 09:13:29 --> Config Class Initialized
INFO - 2023-01-10 09:13:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:13:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:13:29 --> Utf8 Class Initialized
INFO - 2023-01-10 09:13:29 --> URI Class Initialized
INFO - 2023-01-10 09:13:29 --> Router Class Initialized
INFO - 2023-01-10 09:13:29 --> Output Class Initialized
INFO - 2023-01-10 09:13:29 --> Security Class Initialized
DEBUG - 2023-01-10 09:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:13:29 --> Input Class Initialized
INFO - 2023-01-10 09:13:29 --> Language Class Initialized
INFO - 2023-01-10 09:13:29 --> Loader Class Initialized
INFO - 2023-01-10 09:13:29 --> Controller Class Initialized
DEBUG - 2023-01-10 09:13:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:13:29 --> Database Driver Class Initialized
INFO - 2023-01-10 09:13:29 --> Database Driver Class Initialized
INFO - 2023-01-10 09:13:29 --> Model "Login_model" initialized
INFO - 2023-01-10 09:13:29 --> Config Class Initialized
INFO - 2023-01-10 09:13:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:13:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:13:29 --> Utf8 Class Initialized
INFO - 2023-01-10 09:13:29 --> URI Class Initialized
INFO - 2023-01-10 09:13:29 --> Router Class Initialized
INFO - 2023-01-10 09:13:29 --> Output Class Initialized
INFO - 2023-01-10 09:13:29 --> Security Class Initialized
DEBUG - 2023-01-10 09:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:13:29 --> Input Class Initialized
INFO - 2023-01-10 09:13:29 --> Language Class Initialized
INFO - 2023-01-10 09:13:29 --> Loader Class Initialized
INFO - 2023-01-10 09:13:29 --> Controller Class Initialized
DEBUG - 2023-01-10 09:13:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:13:29 --> Database Driver Class Initialized
INFO - 2023-01-10 09:13:29 --> Database Driver Class Initialized
INFO - 2023-01-10 09:13:29 --> Model "Login_model" initialized
INFO - 2023-01-10 09:13:47 --> Config Class Initialized
INFO - 2023-01-10 09:13:47 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:13:47 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:13:47 --> Utf8 Class Initialized
INFO - 2023-01-10 09:13:47 --> URI Class Initialized
INFO - 2023-01-10 09:13:47 --> Router Class Initialized
INFO - 2023-01-10 09:13:47 --> Output Class Initialized
INFO - 2023-01-10 09:13:47 --> Security Class Initialized
DEBUG - 2023-01-10 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:13:47 --> Input Class Initialized
INFO - 2023-01-10 09:13:47 --> Language Class Initialized
INFO - 2023-01-10 09:13:47 --> Loader Class Initialized
INFO - 2023-01-10 09:13:47 --> Controller Class Initialized
DEBUG - 2023-01-10 09:13:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:13:47 --> Database Driver Class Initialized
INFO - 2023-01-10 09:13:47 --> Database Driver Class Initialized
INFO - 2023-01-10 09:13:47 --> Model "Login_model" initialized
INFO - 2023-01-10 09:13:47 --> Config Class Initialized
INFO - 2023-01-10 09:13:47 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:13:47 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:13:47 --> Utf8 Class Initialized
INFO - 2023-01-10 09:13:47 --> URI Class Initialized
INFO - 2023-01-10 09:13:47 --> Router Class Initialized
INFO - 2023-01-10 09:13:47 --> Output Class Initialized
INFO - 2023-01-10 09:13:47 --> Security Class Initialized
DEBUG - 2023-01-10 09:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:13:47 --> Input Class Initialized
INFO - 2023-01-10 09:13:47 --> Language Class Initialized
INFO - 2023-01-10 09:13:47 --> Loader Class Initialized
INFO - 2023-01-10 09:13:47 --> Controller Class Initialized
DEBUG - 2023-01-10 09:13:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:13:47 --> Database Driver Class Initialized
INFO - 2023-01-10 09:13:47 --> Database Driver Class Initialized
INFO - 2023-01-10 09:13:47 --> Model "Login_model" initialized
INFO - 2023-01-10 09:14:21 --> Config Class Initialized
INFO - 2023-01-10 09:14:21 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:14:21 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:14:21 --> Utf8 Class Initialized
INFO - 2023-01-10 09:14:21 --> URI Class Initialized
INFO - 2023-01-10 09:14:21 --> Router Class Initialized
INFO - 2023-01-10 09:14:21 --> Output Class Initialized
INFO - 2023-01-10 09:14:21 --> Security Class Initialized
DEBUG - 2023-01-10 09:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:14:21 --> Input Class Initialized
INFO - 2023-01-10 09:14:21 --> Language Class Initialized
INFO - 2023-01-10 09:14:21 --> Loader Class Initialized
INFO - 2023-01-10 09:14:21 --> Controller Class Initialized
DEBUG - 2023-01-10 09:14:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:14:21 --> Database Driver Class Initialized
INFO - 2023-01-10 09:14:21 --> Database Driver Class Initialized
INFO - 2023-01-10 09:14:21 --> Model "Login_model" initialized
INFO - 2023-01-10 09:14:21 --> Config Class Initialized
INFO - 2023-01-10 09:14:21 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:14:21 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:14:21 --> Utf8 Class Initialized
INFO - 2023-01-10 09:14:21 --> URI Class Initialized
INFO - 2023-01-10 09:14:21 --> Router Class Initialized
INFO - 2023-01-10 09:14:21 --> Output Class Initialized
INFO - 2023-01-10 09:14:21 --> Security Class Initialized
DEBUG - 2023-01-10 09:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:14:21 --> Input Class Initialized
INFO - 2023-01-10 09:14:21 --> Language Class Initialized
INFO - 2023-01-10 09:14:21 --> Loader Class Initialized
INFO - 2023-01-10 09:14:21 --> Controller Class Initialized
DEBUG - 2023-01-10 09:14:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:14:21 --> Database Driver Class Initialized
INFO - 2023-01-10 09:14:21 --> Database Driver Class Initialized
INFO - 2023-01-10 09:14:21 --> Model "Login_model" initialized
INFO - 2023-01-10 09:15:03 --> Config Class Initialized
INFO - 2023-01-10 09:15:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:03 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:03 --> URI Class Initialized
INFO - 2023-01-10 09:15:03 --> Router Class Initialized
INFO - 2023-01-10 09:15:03 --> Output Class Initialized
INFO - 2023-01-10 09:15:03 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:03 --> Input Class Initialized
INFO - 2023-01-10 09:15:03 --> Language Class Initialized
INFO - 2023-01-10 09:15:03 --> Loader Class Initialized
INFO - 2023-01-10 09:15:03 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:03 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:03 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:03 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:15:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:15:03 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:15:03 --> Config Class Initialized
INFO - 2023-01-10 09:15:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:03 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:03 --> URI Class Initialized
INFO - 2023-01-10 09:15:03 --> Router Class Initialized
INFO - 2023-01-10 09:15:03 --> Output Class Initialized
INFO - 2023-01-10 09:15:03 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:03 --> Input Class Initialized
INFO - 2023-01-10 09:15:03 --> Language Class Initialized
INFO - 2023-01-10 09:15:03 --> Loader Class Initialized
INFO - 2023-01-10 09:15:03 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:03 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:03 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:03 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:15:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:15:03 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:15:04 --> Config Class Initialized
INFO - 2023-01-10 09:15:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:04 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:04 --> URI Class Initialized
INFO - 2023-01-10 09:15:04 --> Router Class Initialized
INFO - 2023-01-10 09:15:04 --> Output Class Initialized
INFO - 2023-01-10 09:15:04 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:04 --> Input Class Initialized
INFO - 2023-01-10 09:15:04 --> Language Class Initialized
INFO - 2023-01-10 09:15:04 --> Loader Class Initialized
INFO - 2023-01-10 09:15:04 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:04 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:04 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:04 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:15:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:15:04 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:15:12 --> Config Class Initialized
INFO - 2023-01-10 09:15:12 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:12 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:12 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:12 --> URI Class Initialized
INFO - 2023-01-10 09:15:12 --> Router Class Initialized
INFO - 2023-01-10 09:15:12 --> Output Class Initialized
INFO - 2023-01-10 09:15:12 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:12 --> Input Class Initialized
INFO - 2023-01-10 09:15:12 --> Language Class Initialized
INFO - 2023-01-10 09:15:12 --> Loader Class Initialized
INFO - 2023-01-10 09:15:12 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:12 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:12 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:12 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:15:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:15:12 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:15:12 --> Config Class Initialized
INFO - 2023-01-10 09:15:12 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:12 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:12 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:12 --> URI Class Initialized
INFO - 2023-01-10 09:15:12 --> Router Class Initialized
INFO - 2023-01-10 09:15:12 --> Output Class Initialized
INFO - 2023-01-10 09:15:12 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:12 --> Input Class Initialized
INFO - 2023-01-10 09:15:12 --> Language Class Initialized
INFO - 2023-01-10 09:15:12 --> Loader Class Initialized
INFO - 2023-01-10 09:15:12 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:12 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:12 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:12 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:15:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:15:12 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:15:35 --> Config Class Initialized
INFO - 2023-01-10 09:15:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:35 --> URI Class Initialized
INFO - 2023-01-10 09:15:35 --> Router Class Initialized
INFO - 2023-01-10 09:15:35 --> Output Class Initialized
INFO - 2023-01-10 09:15:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:35 --> Input Class Initialized
INFO - 2023-01-10 09:15:35 --> Language Class Initialized
INFO - 2023-01-10 09:15:35 --> Loader Class Initialized
INFO - 2023-01-10 09:15:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:35 --> Config Class Initialized
INFO - 2023-01-10 09:15:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:35 --> URI Class Initialized
INFO - 2023-01-10 09:15:35 --> Router Class Initialized
INFO - 2023-01-10 09:15:35 --> Output Class Initialized
INFO - 2023-01-10 09:15:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:35 --> Input Class Initialized
INFO - 2023-01-10 09:15:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:35 --> Language Class Initialized
INFO - 2023-01-10 09:15:35 --> Loader Class Initialized
INFO - 2023-01-10 09:15:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:35 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:15:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
INFO - 2023-01-10 09:15:35 --> Database Driver Class Initialized
ERROR - 2023-01-10 09:15:35 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:15:35 --> Config Class Initialized
INFO - 2023-01-10 09:15:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:35 --> URI Class Initialized
INFO - 2023-01-10 09:15:35 --> Router Class Initialized
INFO - 2023-01-10 09:15:35 --> Output Class Initialized
INFO - 2023-01-10 09:15:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:35 --> Input Class Initialized
INFO - 2023-01-10 09:15:35 --> Language Class Initialized
INFO - 2023-01-10 09:15:35 --> Model "Login_model" initialized
INFO - 2023-01-10 09:15:35 --> Loader Class Initialized
INFO - 2023-01-10 09:15:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:35 --> Database Driver Class Initialized
ERROR - 2023-01-10 09:15:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:15:35 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:15:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:35 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:15:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:15:35 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:15:35 --> Config Class Initialized
INFO - 2023-01-10 09:15:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:15:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:15:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:15:35 --> URI Class Initialized
INFO - 2023-01-10 09:15:35 --> Router Class Initialized
INFO - 2023-01-10 09:15:35 --> Output Class Initialized
INFO - 2023-01-10 09:15:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:15:35 --> Input Class Initialized
INFO - 2023-01-10 09:15:35 --> Language Class Initialized
INFO - 2023-01-10 09:15:35 --> Loader Class Initialized
INFO - 2023-01-10 09:15:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:15:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:15:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:15:35 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:15:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%y%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%y%'
ERROR - 2023-01-10 09:15:35 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:16:07 --> Config Class Initialized
INFO - 2023-01-10 09:16:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:16:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:16:07 --> Utf8 Class Initialized
INFO - 2023-01-10 09:16:07 --> URI Class Initialized
INFO - 2023-01-10 09:16:07 --> Router Class Initialized
INFO - 2023-01-10 09:16:07 --> Output Class Initialized
INFO - 2023-01-10 09:16:07 --> Security Class Initialized
DEBUG - 2023-01-10 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:16:07 --> Input Class Initialized
INFO - 2023-01-10 09:16:07 --> Language Class Initialized
INFO - 2023-01-10 09:16:07 --> Loader Class Initialized
INFO - 2023-01-10 09:16:07 --> Controller Class Initialized
DEBUG - 2023-01-10 09:16:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:16:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:16:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:16:07 --> Model "Login_model" initialized
INFO - 2023-01-10 09:16:07 --> Config Class Initialized
INFO - 2023-01-10 09:16:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:16:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:16:07 --> Utf8 Class Initialized
INFO - 2023-01-10 09:16:07 --> URI Class Initialized
INFO - 2023-01-10 09:16:07 --> Router Class Initialized
INFO - 2023-01-10 09:16:07 --> Output Class Initialized
INFO - 2023-01-10 09:16:07 --> Security Class Initialized
DEBUG - 2023-01-10 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:16:07 --> Input Class Initialized
INFO - 2023-01-10 09:16:07 --> Language Class Initialized
INFO - 2023-01-10 09:16:07 --> Loader Class Initialized
INFO - 2023-01-10 09:16:07 --> Controller Class Initialized
DEBUG - 2023-01-10 09:16:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:16:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:16:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:16:07 --> Model "Login_model" initialized
INFO - 2023-01-10 09:16:07 --> Config Class Initialized
INFO - 2023-01-10 09:16:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:16:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:16:07 --> Utf8 Class Initialized
INFO - 2023-01-10 09:16:07 --> URI Class Initialized
INFO - 2023-01-10 09:16:07 --> Router Class Initialized
INFO - 2023-01-10 09:16:07 --> Output Class Initialized
INFO - 2023-01-10 09:16:07 --> Security Class Initialized
DEBUG - 2023-01-10 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:16:07 --> Input Class Initialized
INFO - 2023-01-10 09:16:07 --> Language Class Initialized
INFO - 2023-01-10 09:16:07 --> Loader Class Initialized
INFO - 2023-01-10 09:16:07 --> Controller Class Initialized
DEBUG - 2023-01-10 09:16:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:16:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:16:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:16:07 --> Model "Login_model" initialized
INFO - 2023-01-10 09:16:08 --> Config Class Initialized
INFO - 2023-01-10 09:16:08 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:16:08 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:16:08 --> Utf8 Class Initialized
INFO - 2023-01-10 09:16:08 --> URI Class Initialized
INFO - 2023-01-10 09:16:08 --> Router Class Initialized
INFO - 2023-01-10 09:16:08 --> Output Class Initialized
INFO - 2023-01-10 09:16:08 --> Security Class Initialized
DEBUG - 2023-01-10 09:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:16:08 --> Input Class Initialized
INFO - 2023-01-10 09:16:08 --> Language Class Initialized
INFO - 2023-01-10 09:16:08 --> Loader Class Initialized
INFO - 2023-01-10 09:16:08 --> Controller Class Initialized
DEBUG - 2023-01-10 09:16:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:16:08 --> Database Driver Class Initialized
INFO - 2023-01-10 09:16:08 --> Database Driver Class Initialized
INFO - 2023-01-10 09:16:08 --> Model "Login_model" initialized
INFO - 2023-01-10 09:17:32 --> Config Class Initialized
INFO - 2023-01-10 09:17:32 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:17:32 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:17:32 --> Utf8 Class Initialized
INFO - 2023-01-10 09:17:32 --> URI Class Initialized
INFO - 2023-01-10 09:17:32 --> Router Class Initialized
INFO - 2023-01-10 09:17:32 --> Output Class Initialized
INFO - 2023-01-10 09:17:32 --> Security Class Initialized
DEBUG - 2023-01-10 09:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:17:32 --> Input Class Initialized
INFO - 2023-01-10 09:17:32 --> Language Class Initialized
INFO - 2023-01-10 09:17:32 --> Loader Class Initialized
INFO - 2023-01-10 09:17:32 --> Controller Class Initialized
DEBUG - 2023-01-10 09:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:17:32 --> Database Driver Class Initialized
INFO - 2023-01-10 09:17:32 --> Database Driver Class Initialized
INFO - 2023-01-10 09:17:32 --> Model "Login_model" initialized
INFO - 2023-01-10 09:17:32 --> Config Class Initialized
INFO - 2023-01-10 09:17:32 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:17:32 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:17:32 --> Utf8 Class Initialized
INFO - 2023-01-10 09:17:32 --> URI Class Initialized
INFO - 2023-01-10 09:17:32 --> Router Class Initialized
INFO - 2023-01-10 09:17:32 --> Output Class Initialized
INFO - 2023-01-10 09:17:32 --> Security Class Initialized
DEBUG - 2023-01-10 09:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:17:32 --> Input Class Initialized
INFO - 2023-01-10 09:17:32 --> Language Class Initialized
INFO - 2023-01-10 09:17:32 --> Loader Class Initialized
INFO - 2023-01-10 09:17:32 --> Controller Class Initialized
DEBUG - 2023-01-10 09:17:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:17:32 --> Database Driver Class Initialized
INFO - 2023-01-10 09:17:32 --> Database Driver Class Initialized
INFO - 2023-01-10 09:17:32 --> Model "Login_model" initialized
INFO - 2023-01-10 09:18:28 --> Config Class Initialized
INFO - 2023-01-10 09:18:28 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:18:28 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:18:28 --> Utf8 Class Initialized
INFO - 2023-01-10 09:18:28 --> URI Class Initialized
INFO - 2023-01-10 09:18:28 --> Router Class Initialized
INFO - 2023-01-10 09:18:28 --> Output Class Initialized
INFO - 2023-01-10 09:18:28 --> Security Class Initialized
DEBUG - 2023-01-10 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:18:28 --> Input Class Initialized
INFO - 2023-01-10 09:18:28 --> Language Class Initialized
INFO - 2023-01-10 09:18:28 --> Loader Class Initialized
INFO - 2023-01-10 09:18:28 --> Controller Class Initialized
DEBUG - 2023-01-10 09:18:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:18:28 --> Database Driver Class Initialized
INFO - 2023-01-10 09:18:28 --> Database Driver Class Initialized
INFO - 2023-01-10 09:18:28 --> Model "Login_model" initialized
INFO - 2023-01-10 09:18:28 --> Final output sent to browser
DEBUG - 2023-01-10 09:18:28 --> Total execution time: 0.0409
INFO - 2023-01-10 09:18:28 --> Config Class Initialized
INFO - 2023-01-10 09:18:28 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:18:28 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:18:28 --> Utf8 Class Initialized
INFO - 2023-01-10 09:18:28 --> URI Class Initialized
INFO - 2023-01-10 09:18:28 --> Router Class Initialized
INFO - 2023-01-10 09:18:28 --> Output Class Initialized
INFO - 2023-01-10 09:18:28 --> Security Class Initialized
DEBUG - 2023-01-10 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:18:28 --> Input Class Initialized
INFO - 2023-01-10 09:18:28 --> Language Class Initialized
INFO - 2023-01-10 09:18:28 --> Loader Class Initialized
INFO - 2023-01-10 09:18:28 --> Controller Class Initialized
DEBUG - 2023-01-10 09:18:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:18:28 --> Database Driver Class Initialized
INFO - 2023-01-10 09:18:28 --> Database Driver Class Initialized
INFO - 2023-01-10 09:18:28 --> Model "Login_model" initialized
INFO - 2023-01-10 09:18:28 --> Final output sent to browser
DEBUG - 2023-01-10 09:18:28 --> Total execution time: 0.0632
INFO - 2023-01-10 09:18:31 --> Config Class Initialized
INFO - 2023-01-10 09:18:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:18:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:18:31 --> Utf8 Class Initialized
INFO - 2023-01-10 09:18:31 --> URI Class Initialized
INFO - 2023-01-10 09:18:31 --> Router Class Initialized
INFO - 2023-01-10 09:18:31 --> Output Class Initialized
INFO - 2023-01-10 09:18:31 --> Security Class Initialized
DEBUG - 2023-01-10 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:18:31 --> Input Class Initialized
INFO - 2023-01-10 09:18:31 --> Language Class Initialized
INFO - 2023-01-10 09:18:31 --> Loader Class Initialized
INFO - 2023-01-10 09:18:31 --> Controller Class Initialized
DEBUG - 2023-01-10 09:18:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:18:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:18:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:18:31 --> Model "Login_model" initialized
INFO - 2023-01-10 09:18:31 --> Final output sent to browser
DEBUG - 2023-01-10 09:18:31 --> Total execution time: 0.0443
INFO - 2023-01-10 09:18:31 --> Config Class Initialized
INFO - 2023-01-10 09:18:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:18:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:18:31 --> Utf8 Class Initialized
INFO - 2023-01-10 09:18:31 --> URI Class Initialized
INFO - 2023-01-10 09:18:31 --> Router Class Initialized
INFO - 2023-01-10 09:18:31 --> Output Class Initialized
INFO - 2023-01-10 09:18:31 --> Security Class Initialized
DEBUG - 2023-01-10 09:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:18:31 --> Input Class Initialized
INFO - 2023-01-10 09:18:31 --> Language Class Initialized
INFO - 2023-01-10 09:18:31 --> Loader Class Initialized
INFO - 2023-01-10 09:18:31 --> Controller Class Initialized
DEBUG - 2023-01-10 09:18:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:18:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:18:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:18:31 --> Model "Login_model" initialized
INFO - 2023-01-10 09:18:31 --> Final output sent to browser
DEBUG - 2023-01-10 09:18:31 --> Total execution time: 0.0305
INFO - 2023-01-10 09:19:00 --> Config Class Initialized
INFO - 2023-01-10 09:19:00 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:19:00 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:19:00 --> Utf8 Class Initialized
INFO - 2023-01-10 09:19:00 --> URI Class Initialized
INFO - 2023-01-10 09:19:00 --> Router Class Initialized
INFO - 2023-01-10 09:19:00 --> Output Class Initialized
INFO - 2023-01-10 09:19:00 --> Security Class Initialized
DEBUG - 2023-01-10 09:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:19:00 --> Input Class Initialized
INFO - 2023-01-10 09:19:00 --> Language Class Initialized
INFO - 2023-01-10 09:19:00 --> Loader Class Initialized
INFO - 2023-01-10 09:19:00 --> Controller Class Initialized
DEBUG - 2023-01-10 09:19:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:19:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:00 --> Model "Login_model" initialized
INFO - 2023-01-10 09:19:00 --> Final output sent to browser
DEBUG - 2023-01-10 09:19:00 --> Total execution time: 0.0468
INFO - 2023-01-10 09:19:00 --> Config Class Initialized
INFO - 2023-01-10 09:19:00 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:19:00 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:19:00 --> Utf8 Class Initialized
INFO - 2023-01-10 09:19:00 --> URI Class Initialized
INFO - 2023-01-10 09:19:00 --> Router Class Initialized
INFO - 2023-01-10 09:19:00 --> Output Class Initialized
INFO - 2023-01-10 09:19:00 --> Security Class Initialized
DEBUG - 2023-01-10 09:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:19:00 --> Input Class Initialized
INFO - 2023-01-10 09:19:00 --> Language Class Initialized
INFO - 2023-01-10 09:19:00 --> Loader Class Initialized
INFO - 2023-01-10 09:19:00 --> Controller Class Initialized
DEBUG - 2023-01-10 09:19:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:19:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:00 --> Model "Login_model" initialized
INFO - 2023-01-10 09:19:00 --> Final output sent to browser
DEBUG - 2023-01-10 09:19:00 --> Total execution time: 0.0372
INFO - 2023-01-10 09:19:02 --> Config Class Initialized
INFO - 2023-01-10 09:19:02 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:19:02 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:19:02 --> Utf8 Class Initialized
INFO - 2023-01-10 09:19:02 --> URI Class Initialized
INFO - 2023-01-10 09:19:02 --> Router Class Initialized
INFO - 2023-01-10 09:19:02 --> Output Class Initialized
INFO - 2023-01-10 09:19:02 --> Security Class Initialized
DEBUG - 2023-01-10 09:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:19:02 --> Input Class Initialized
INFO - 2023-01-10 09:19:02 --> Language Class Initialized
INFO - 2023-01-10 09:19:02 --> Loader Class Initialized
INFO - 2023-01-10 09:19:02 --> Controller Class Initialized
DEBUG - 2023-01-10 09:19:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:19:02 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:02 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:02 --> Model "Login_model" initialized
INFO - 2023-01-10 09:19:02 --> Config Class Initialized
INFO - 2023-01-10 09:19:02 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:19:02 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:19:02 --> Utf8 Class Initialized
INFO - 2023-01-10 09:19:02 --> URI Class Initialized
INFO - 2023-01-10 09:19:02 --> Router Class Initialized
INFO - 2023-01-10 09:19:02 --> Output Class Initialized
INFO - 2023-01-10 09:19:02 --> Security Class Initialized
DEBUG - 2023-01-10 09:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:19:02 --> Input Class Initialized
INFO - 2023-01-10 09:19:02 --> Language Class Initialized
INFO - 2023-01-10 09:19:02 --> Loader Class Initialized
INFO - 2023-01-10 09:19:02 --> Controller Class Initialized
DEBUG - 2023-01-10 09:19:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:19:02 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:02 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:02 --> Model "Login_model" initialized
INFO - 2023-01-10 09:19:22 --> Config Class Initialized
INFO - 2023-01-10 09:19:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:19:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:19:22 --> Utf8 Class Initialized
INFO - 2023-01-10 09:19:22 --> URI Class Initialized
INFO - 2023-01-10 09:19:22 --> Router Class Initialized
INFO - 2023-01-10 09:19:22 --> Output Class Initialized
INFO - 2023-01-10 09:19:22 --> Security Class Initialized
DEBUG - 2023-01-10 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:19:22 --> Input Class Initialized
INFO - 2023-01-10 09:19:22 --> Language Class Initialized
INFO - 2023-01-10 09:19:22 --> Loader Class Initialized
INFO - 2023-01-10 09:19:22 --> Controller Class Initialized
DEBUG - 2023-01-10 09:19:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:19:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:22 --> Model "Login_model" initialized
INFO - 2023-01-10 09:19:22 --> Final output sent to browser
DEBUG - 2023-01-10 09:19:22 --> Total execution time: 0.0321
INFO - 2023-01-10 09:19:23 --> Config Class Initialized
INFO - 2023-01-10 09:19:23 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:19:23 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:19:23 --> Utf8 Class Initialized
INFO - 2023-01-10 09:19:23 --> URI Class Initialized
INFO - 2023-01-10 09:19:23 --> Router Class Initialized
INFO - 2023-01-10 09:19:23 --> Output Class Initialized
INFO - 2023-01-10 09:19:23 --> Security Class Initialized
DEBUG - 2023-01-10 09:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:19:23 --> Input Class Initialized
INFO - 2023-01-10 09:19:23 --> Language Class Initialized
INFO - 2023-01-10 09:19:23 --> Loader Class Initialized
INFO - 2023-01-10 09:19:23 --> Controller Class Initialized
DEBUG - 2023-01-10 09:19:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:19:23 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:23 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:23 --> Model "Login_model" initialized
INFO - 2023-01-10 09:19:23 --> Final output sent to browser
DEBUG - 2023-01-10 09:19:23 --> Total execution time: 0.0335
INFO - 2023-01-10 09:19:25 --> Config Class Initialized
INFO - 2023-01-10 09:19:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:19:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:19:25 --> Utf8 Class Initialized
INFO - 2023-01-10 09:19:25 --> URI Class Initialized
INFO - 2023-01-10 09:19:25 --> Router Class Initialized
INFO - 2023-01-10 09:19:25 --> Output Class Initialized
INFO - 2023-01-10 09:19:25 --> Security Class Initialized
DEBUG - 2023-01-10 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:19:25 --> Input Class Initialized
INFO - 2023-01-10 09:19:25 --> Language Class Initialized
INFO - 2023-01-10 09:19:25 --> Loader Class Initialized
INFO - 2023-01-10 09:19:25 --> Controller Class Initialized
DEBUG - 2023-01-10 09:19:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:19:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:25 --> Model "Login_model" initialized
INFO - 2023-01-10 09:19:25 --> Config Class Initialized
INFO - 2023-01-10 09:19:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:19:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:19:25 --> Utf8 Class Initialized
INFO - 2023-01-10 09:19:25 --> URI Class Initialized
INFO - 2023-01-10 09:19:25 --> Router Class Initialized
INFO - 2023-01-10 09:19:25 --> Output Class Initialized
INFO - 2023-01-10 09:19:25 --> Security Class Initialized
DEBUG - 2023-01-10 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:19:25 --> Input Class Initialized
INFO - 2023-01-10 09:19:25 --> Language Class Initialized
INFO - 2023-01-10 09:19:25 --> Loader Class Initialized
INFO - 2023-01-10 09:19:25 --> Controller Class Initialized
DEBUG - 2023-01-10 09:19:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:19:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:19:25 --> Model "Login_model" initialized
INFO - 2023-01-10 09:21:48 --> Config Class Initialized
INFO - 2023-01-10 09:21:48 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:21:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:21:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:21:48 --> URI Class Initialized
INFO - 2023-01-10 09:21:48 --> Router Class Initialized
INFO - 2023-01-10 09:21:48 --> Output Class Initialized
INFO - 2023-01-10 09:21:48 --> Security Class Initialized
DEBUG - 2023-01-10 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:21:48 --> Input Class Initialized
INFO - 2023-01-10 09:21:48 --> Language Class Initialized
INFO - 2023-01-10 09:21:48 --> Loader Class Initialized
INFO - 2023-01-10 09:21:48 --> Controller Class Initialized
DEBUG - 2023-01-10 09:21:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:21:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:48 --> Model "Login_model" initialized
INFO - 2023-01-10 09:21:48 --> Final output sent to browser
DEBUG - 2023-01-10 09:21:48 --> Total execution time: 0.0250
INFO - 2023-01-10 09:21:48 --> Config Class Initialized
INFO - 2023-01-10 09:21:48 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:21:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:21:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:21:48 --> URI Class Initialized
INFO - 2023-01-10 09:21:48 --> Router Class Initialized
INFO - 2023-01-10 09:21:48 --> Output Class Initialized
INFO - 2023-01-10 09:21:48 --> Security Class Initialized
DEBUG - 2023-01-10 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:21:48 --> Input Class Initialized
INFO - 2023-01-10 09:21:48 --> Language Class Initialized
INFO - 2023-01-10 09:21:48 --> Loader Class Initialized
INFO - 2023-01-10 09:21:48 --> Controller Class Initialized
DEBUG - 2023-01-10 09:21:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:21:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:48 --> Model "Login_model" initialized
INFO - 2023-01-10 09:21:48 --> Final output sent to browser
DEBUG - 2023-01-10 09:21:48 --> Total execution time: 0.0250
INFO - 2023-01-10 09:21:50 --> Config Class Initialized
INFO - 2023-01-10 09:21:50 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:21:50 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:21:50 --> Utf8 Class Initialized
INFO - 2023-01-10 09:21:50 --> URI Class Initialized
INFO - 2023-01-10 09:21:50 --> Router Class Initialized
INFO - 2023-01-10 09:21:50 --> Output Class Initialized
INFO - 2023-01-10 09:21:50 --> Security Class Initialized
DEBUG - 2023-01-10 09:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:21:50 --> Input Class Initialized
INFO - 2023-01-10 09:21:50 --> Language Class Initialized
INFO - 2023-01-10 09:21:50 --> Loader Class Initialized
INFO - 2023-01-10 09:21:50 --> Controller Class Initialized
DEBUG - 2023-01-10 09:21:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:21:50 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:50 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:50 --> Model "Login_model" initialized
INFO - 2023-01-10 09:21:50 --> Final output sent to browser
DEBUG - 2023-01-10 09:21:50 --> Total execution time: 0.0290
INFO - 2023-01-10 09:21:50 --> Config Class Initialized
INFO - 2023-01-10 09:21:50 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:21:50 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:21:50 --> Utf8 Class Initialized
INFO - 2023-01-10 09:21:50 --> URI Class Initialized
INFO - 2023-01-10 09:21:50 --> Router Class Initialized
INFO - 2023-01-10 09:21:50 --> Output Class Initialized
INFO - 2023-01-10 09:21:50 --> Security Class Initialized
DEBUG - 2023-01-10 09:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:21:50 --> Input Class Initialized
INFO - 2023-01-10 09:21:50 --> Language Class Initialized
INFO - 2023-01-10 09:21:50 --> Loader Class Initialized
INFO - 2023-01-10 09:21:50 --> Controller Class Initialized
DEBUG - 2023-01-10 09:21:50 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:21:50 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:50 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:50 --> Model "Login_model" initialized
INFO - 2023-01-10 09:21:50 --> Final output sent to browser
DEBUG - 2023-01-10 09:21:50 --> Total execution time: 0.0216
INFO - 2023-01-10 09:21:53 --> Config Class Initialized
INFO - 2023-01-10 09:21:53 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:21:53 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:21:53 --> Utf8 Class Initialized
INFO - 2023-01-10 09:21:53 --> URI Class Initialized
INFO - 2023-01-10 09:21:53 --> Router Class Initialized
INFO - 2023-01-10 09:21:53 --> Output Class Initialized
INFO - 2023-01-10 09:21:53 --> Security Class Initialized
DEBUG - 2023-01-10 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:21:53 --> Input Class Initialized
INFO - 2023-01-10 09:21:53 --> Language Class Initialized
INFO - 2023-01-10 09:21:53 --> Loader Class Initialized
INFO - 2023-01-10 09:21:53 --> Controller Class Initialized
DEBUG - 2023-01-10 09:21:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:21:53 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:53 --> Database Driver Class Initialized
INFO - 2023-01-10 09:21:53 --> Model "Login_model" initialized
INFO - 2023-01-10 09:21:53 --> Final output sent to browser
DEBUG - 2023-01-10 09:21:53 --> Total execution time: 0.0290
INFO - 2023-01-10 09:22:00 --> Config Class Initialized
INFO - 2023-01-10 09:22:00 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:22:00 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:22:00 --> Utf8 Class Initialized
INFO - 2023-01-10 09:22:00 --> URI Class Initialized
INFO - 2023-01-10 09:22:00 --> Router Class Initialized
INFO - 2023-01-10 09:22:00 --> Output Class Initialized
INFO - 2023-01-10 09:22:00 --> Security Class Initialized
DEBUG - 2023-01-10 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:22:00 --> Input Class Initialized
INFO - 2023-01-10 09:22:00 --> Language Class Initialized
INFO - 2023-01-10 09:22:00 --> Loader Class Initialized
INFO - 2023-01-10 09:22:00 --> Controller Class Initialized
DEBUG - 2023-01-10 09:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:22:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:22:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:22:00 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:22:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%qq%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%qq%'
ERROR - 2023-01-10 09:22:00 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:22:00 --> Config Class Initialized
INFO - 2023-01-10 09:22:00 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:22:00 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:22:00 --> Utf8 Class Initialized
INFO - 2023-01-10 09:22:00 --> URI Class Initialized
INFO - 2023-01-10 09:22:00 --> Router Class Initialized
INFO - 2023-01-10 09:22:00 --> Output Class Initialized
INFO - 2023-01-10 09:22:00 --> Security Class Initialized
DEBUG - 2023-01-10 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:22:00 --> Input Class Initialized
INFO - 2023-01-10 09:22:00 --> Language Class Initialized
INFO - 2023-01-10 09:22:00 --> Loader Class Initialized
INFO - 2023-01-10 09:22:00 --> Controller Class Initialized
DEBUG - 2023-01-10 09:22:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:22:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:22:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:22:00 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:22:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%qq%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%qq%'
ERROR - 2023-01-10 09:22:00 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 15
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:22:25 --> Config Class Initialized
INFO - 2023-01-10 09:22:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:22:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:22:25 --> Utf8 Class Initialized
INFO - 2023-01-10 09:22:25 --> URI Class Initialized
INFO - 2023-01-10 09:22:25 --> Router Class Initialized
INFO - 2023-01-10 09:22:25 --> Output Class Initialized
INFO - 2023-01-10 09:22:25 --> Security Class Initialized
DEBUG - 2023-01-10 09:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:22:25 --> Input Class Initialized
INFO - 2023-01-10 09:22:25 --> Language Class Initialized
INFO - 2023-01-10 09:22:25 --> Loader Class Initialized
INFO - 2023-01-10 09:22:25 --> Controller Class Initialized
DEBUG - 2023-01-10 09:22:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:22:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:22:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:22:25 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:22:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%qq%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%qq%'
ERROR - 2023-01-10 09:22:25 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 16
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:22:25 --> Config Class Initialized
INFO - 2023-01-10 09:22:26 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:22:26 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:22:26 --> Utf8 Class Initialized
INFO - 2023-01-10 09:22:26 --> URI Class Initialized
INFO - 2023-01-10 09:22:26 --> Router Class Initialized
INFO - 2023-01-10 09:22:26 --> Output Class Initialized
INFO - 2023-01-10 09:22:26 --> Security Class Initialized
DEBUG - 2023-01-10 09:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:22:26 --> Input Class Initialized
INFO - 2023-01-10 09:22:26 --> Language Class Initialized
INFO - 2023-01-10 09:22:26 --> Loader Class Initialized
INFO - 2023-01-10 09:22:26 --> Controller Class Initialized
DEBUG - 2023-01-10 09:22:26 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:22:26 --> Database Driver Class Initialized
INFO - 2023-01-10 09:22:26 --> Database Driver Class Initialized
INFO - 2023-01-10 09:22:26 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:22:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%qq%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%qq%'
ERROR - 2023-01-10 09:22:26 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 16
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:23:07 --> Config Class Initialized
INFO - 2023-01-10 09:23:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:23:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:23:07 --> Utf8 Class Initialized
INFO - 2023-01-10 09:23:07 --> URI Class Initialized
INFO - 2023-01-10 09:23:07 --> Router Class Initialized
INFO - 2023-01-10 09:23:07 --> Output Class Initialized
INFO - 2023-01-10 09:23:07 --> Security Class Initialized
DEBUG - 2023-01-10 09:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:23:07 --> Input Class Initialized
INFO - 2023-01-10 09:23:07 --> Language Class Initialized
INFO - 2023-01-10 09:23:07 --> Loader Class Initialized
INFO - 2023-01-10 09:23:07 --> Controller Class Initialized
DEBUG - 2023-01-10 09:23:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:23:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:07 --> Model "Login_model" initialized
INFO - 2023-01-10 09:23:07 --> Final output sent to browser
DEBUG - 2023-01-10 09:23:07 --> Total execution time: 0.0388
INFO - 2023-01-10 09:23:07 --> Config Class Initialized
INFO - 2023-01-10 09:23:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:23:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:23:07 --> Utf8 Class Initialized
INFO - 2023-01-10 09:23:07 --> URI Class Initialized
INFO - 2023-01-10 09:23:07 --> Router Class Initialized
INFO - 2023-01-10 09:23:07 --> Output Class Initialized
INFO - 2023-01-10 09:23:07 --> Security Class Initialized
DEBUG - 2023-01-10 09:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:23:07 --> Input Class Initialized
INFO - 2023-01-10 09:23:07 --> Language Class Initialized
INFO - 2023-01-10 09:23:07 --> Loader Class Initialized
INFO - 2023-01-10 09:23:07 --> Controller Class Initialized
DEBUG - 2023-01-10 09:23:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:23:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:07 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:07 --> Model "Login_model" initialized
INFO - 2023-01-10 09:23:07 --> Final output sent to browser
DEBUG - 2023-01-10 09:23:07 --> Total execution time: 0.0337
INFO - 2023-01-10 09:23:56 --> Config Class Initialized
INFO - 2023-01-10 09:23:56 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:23:56 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:23:56 --> Utf8 Class Initialized
INFO - 2023-01-10 09:23:56 --> URI Class Initialized
INFO - 2023-01-10 09:23:56 --> Router Class Initialized
INFO - 2023-01-10 09:23:56 --> Output Class Initialized
INFO - 2023-01-10 09:23:56 --> Security Class Initialized
DEBUG - 2023-01-10 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:23:56 --> Input Class Initialized
INFO - 2023-01-10 09:23:56 --> Language Class Initialized
INFO - 2023-01-10 09:23:56 --> Loader Class Initialized
INFO - 2023-01-10 09:23:56 --> Controller Class Initialized
DEBUG - 2023-01-10 09:23:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:23:56 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:56 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:56 --> Model "Login_model" initialized
INFO - 2023-01-10 09:23:56 --> Final output sent to browser
DEBUG - 2023-01-10 09:23:56 --> Total execution time: 0.0736
INFO - 2023-01-10 09:23:56 --> Config Class Initialized
INFO - 2023-01-10 09:23:56 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:23:56 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:23:56 --> Utf8 Class Initialized
INFO - 2023-01-10 09:23:56 --> URI Class Initialized
INFO - 2023-01-10 09:23:56 --> Router Class Initialized
INFO - 2023-01-10 09:23:56 --> Output Class Initialized
INFO - 2023-01-10 09:23:56 --> Security Class Initialized
DEBUG - 2023-01-10 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:23:56 --> Input Class Initialized
INFO - 2023-01-10 09:23:56 --> Language Class Initialized
INFO - 2023-01-10 09:23:56 --> Loader Class Initialized
INFO - 2023-01-10 09:23:56 --> Controller Class Initialized
DEBUG - 2023-01-10 09:23:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:23:56 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:56 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:56 --> Model "Login_model" initialized
INFO - 2023-01-10 09:23:56 --> Final output sent to browser
DEBUG - 2023-01-10 09:23:56 --> Total execution time: 0.1120
INFO - 2023-01-10 09:23:58 --> Config Class Initialized
INFO - 2023-01-10 09:23:58 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:23:58 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:23:58 --> Utf8 Class Initialized
INFO - 2023-01-10 09:23:58 --> URI Class Initialized
INFO - 2023-01-10 09:23:58 --> Router Class Initialized
INFO - 2023-01-10 09:23:58 --> Output Class Initialized
INFO - 2023-01-10 09:23:58 --> Security Class Initialized
DEBUG - 2023-01-10 09:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:23:58 --> Input Class Initialized
INFO - 2023-01-10 09:23:58 --> Language Class Initialized
INFO - 2023-01-10 09:23:58 --> Loader Class Initialized
INFO - 2023-01-10 09:23:58 --> Controller Class Initialized
DEBUG - 2023-01-10 09:23:58 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:23:58 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:58 --> Database Driver Class Initialized
INFO - 2023-01-10 09:23:58 --> Model "Login_model" initialized
INFO - 2023-01-10 09:23:58 --> Final output sent to browser
DEBUG - 2023-01-10 09:23:58 --> Total execution time: 0.0308
INFO - 2023-01-10 09:23:59 --> Config Class Initialized
INFO - 2023-01-10 09:23:59 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:23:59 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:23:59 --> Utf8 Class Initialized
INFO - 2023-01-10 09:23:59 --> URI Class Initialized
INFO - 2023-01-10 09:23:59 --> Router Class Initialized
INFO - 2023-01-10 09:23:59 --> Output Class Initialized
INFO - 2023-01-10 09:23:59 --> Security Class Initialized
DEBUG - 2023-01-10 09:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:23:59 --> Input Class Initialized
INFO - 2023-01-10 09:23:59 --> Language Class Initialized
INFO - 2023-01-10 09:23:59 --> Loader Class Initialized
INFO - 2023-01-10 09:23:59 --> Controller Class Initialized
DEBUG - 2023-01-10 09:23:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:23:59 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:00 --> Model "Login_model" initialized
INFO - 2023-01-10 09:24:00 --> Final output sent to browser
DEBUG - 2023-01-10 09:24:00 --> Total execution time: 0.0354
INFO - 2023-01-10 09:24:01 --> Config Class Initialized
INFO - 2023-01-10 09:24:01 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:24:01 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:24:01 --> Utf8 Class Initialized
INFO - 2023-01-10 09:24:01 --> URI Class Initialized
INFO - 2023-01-10 09:24:01 --> Router Class Initialized
INFO - 2023-01-10 09:24:01 --> Output Class Initialized
INFO - 2023-01-10 09:24:01 --> Security Class Initialized
DEBUG - 2023-01-10 09:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:24:01 --> Input Class Initialized
INFO - 2023-01-10 09:24:01 --> Language Class Initialized
INFO - 2023-01-10 09:24:01 --> Loader Class Initialized
INFO - 2023-01-10 09:24:01 --> Controller Class Initialized
DEBUG - 2023-01-10 09:24:01 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:24:01 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:01 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:01 --> Model "Login_model" initialized
INFO - 2023-01-10 09:24:01 --> Final output sent to browser
DEBUG - 2023-01-10 09:24:01 --> Total execution time: 0.0317
INFO - 2023-01-10 09:24:08 --> Config Class Initialized
INFO - 2023-01-10 09:24:08 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:24:08 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:24:08 --> Utf8 Class Initialized
INFO - 2023-01-10 09:24:08 --> URI Class Initialized
INFO - 2023-01-10 09:24:08 --> Router Class Initialized
INFO - 2023-01-10 09:24:08 --> Output Class Initialized
INFO - 2023-01-10 09:24:08 --> Security Class Initialized
DEBUG - 2023-01-10 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:24:08 --> Input Class Initialized
INFO - 2023-01-10 09:24:08 --> Language Class Initialized
INFO - 2023-01-10 09:24:08 --> Loader Class Initialized
INFO - 2023-01-10 09:24:08 --> Controller Class Initialized
DEBUG - 2023-01-10 09:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:24:08 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:08 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:08 --> Model "Login_model" initialized
INFO - 2023-01-10 09:24:08 --> Final output sent to browser
DEBUG - 2023-01-10 09:24:08 --> Total execution time: 0.0338
INFO - 2023-01-10 09:24:08 --> Config Class Initialized
INFO - 2023-01-10 09:24:08 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:24:08 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:24:08 --> Utf8 Class Initialized
INFO - 2023-01-10 09:24:08 --> URI Class Initialized
INFO - 2023-01-10 09:24:08 --> Router Class Initialized
INFO - 2023-01-10 09:24:08 --> Output Class Initialized
INFO - 2023-01-10 09:24:08 --> Security Class Initialized
DEBUG - 2023-01-10 09:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:24:08 --> Input Class Initialized
INFO - 2023-01-10 09:24:08 --> Language Class Initialized
INFO - 2023-01-10 09:24:08 --> Loader Class Initialized
INFO - 2023-01-10 09:24:08 --> Controller Class Initialized
DEBUG - 2023-01-10 09:24:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:24:08 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:08 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:08 --> Model "Login_model" initialized
INFO - 2023-01-10 09:24:08 --> Final output sent to browser
DEBUG - 2023-01-10 09:24:08 --> Total execution time: 0.0280
INFO - 2023-01-10 09:24:20 --> Config Class Initialized
INFO - 2023-01-10 09:24:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:24:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:24:20 --> Utf8 Class Initialized
INFO - 2023-01-10 09:24:20 --> URI Class Initialized
INFO - 2023-01-10 09:24:20 --> Router Class Initialized
INFO - 2023-01-10 09:24:20 --> Output Class Initialized
INFO - 2023-01-10 09:24:20 --> Security Class Initialized
DEBUG - 2023-01-10 09:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:24:20 --> Input Class Initialized
INFO - 2023-01-10 09:24:20 --> Language Class Initialized
INFO - 2023-01-10 09:24:20 --> Loader Class Initialized
INFO - 2023-01-10 09:24:20 --> Controller Class Initialized
DEBUG - 2023-01-10 09:24:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:24:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:20 --> Model "Login_model" initialized
INFO - 2023-01-10 09:24:20 --> Final output sent to browser
DEBUG - 2023-01-10 09:24:20 --> Total execution time: 0.0826
INFO - 2023-01-10 09:24:20 --> Config Class Initialized
INFO - 2023-01-10 09:24:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:24:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:24:20 --> Utf8 Class Initialized
INFO - 2023-01-10 09:24:20 --> URI Class Initialized
INFO - 2023-01-10 09:24:20 --> Router Class Initialized
INFO - 2023-01-10 09:24:20 --> Output Class Initialized
INFO - 2023-01-10 09:24:20 --> Security Class Initialized
DEBUG - 2023-01-10 09:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:24:20 --> Input Class Initialized
INFO - 2023-01-10 09:24:20 --> Language Class Initialized
INFO - 2023-01-10 09:24:20 --> Loader Class Initialized
INFO - 2023-01-10 09:24:20 --> Controller Class Initialized
DEBUG - 2023-01-10 09:24:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:24:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:20 --> Model "Login_model" initialized
INFO - 2023-01-10 09:24:20 --> Final output sent to browser
DEBUG - 2023-01-10 09:24:20 --> Total execution time: 0.1277
INFO - 2023-01-10 09:24:47 --> Config Class Initialized
INFO - 2023-01-10 09:24:47 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:24:47 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:24:47 --> Utf8 Class Initialized
INFO - 2023-01-10 09:24:47 --> URI Class Initialized
INFO - 2023-01-10 09:24:47 --> Router Class Initialized
INFO - 2023-01-10 09:24:47 --> Output Class Initialized
INFO - 2023-01-10 09:24:47 --> Security Class Initialized
DEBUG - 2023-01-10 09:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:24:47 --> Input Class Initialized
INFO - 2023-01-10 09:24:47 --> Language Class Initialized
INFO - 2023-01-10 09:24:47 --> Loader Class Initialized
INFO - 2023-01-10 09:24:47 --> Controller Class Initialized
DEBUG - 2023-01-10 09:24:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:24:47 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:47 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:47 --> Model "Login_model" initialized
INFO - 2023-01-10 09:24:47 --> Final output sent to browser
DEBUG - 2023-01-10 09:24:47 --> Total execution time: 0.0438
INFO - 2023-01-10 09:24:47 --> Config Class Initialized
INFO - 2023-01-10 09:24:47 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:24:47 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:24:47 --> Utf8 Class Initialized
INFO - 2023-01-10 09:24:47 --> URI Class Initialized
INFO - 2023-01-10 09:24:47 --> Router Class Initialized
INFO - 2023-01-10 09:24:47 --> Output Class Initialized
INFO - 2023-01-10 09:24:47 --> Security Class Initialized
DEBUG - 2023-01-10 09:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:24:47 --> Input Class Initialized
INFO - 2023-01-10 09:24:47 --> Language Class Initialized
INFO - 2023-01-10 09:24:47 --> Loader Class Initialized
INFO - 2023-01-10 09:24:47 --> Controller Class Initialized
DEBUG - 2023-01-10 09:24:47 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:24:47 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:47 --> Database Driver Class Initialized
INFO - 2023-01-10 09:24:47 --> Model "Login_model" initialized
INFO - 2023-01-10 09:24:47 --> Final output sent to browser
DEBUG - 2023-01-10 09:24:47 --> Total execution time: 0.0354
INFO - 2023-01-10 09:25:54 --> Config Class Initialized
INFO - 2023-01-10 09:25:54 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:25:54 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:25:54 --> Utf8 Class Initialized
INFO - 2023-01-10 09:25:54 --> URI Class Initialized
INFO - 2023-01-10 09:25:54 --> Router Class Initialized
INFO - 2023-01-10 09:25:54 --> Output Class Initialized
INFO - 2023-01-10 09:25:54 --> Security Class Initialized
DEBUG - 2023-01-10 09:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:25:54 --> Input Class Initialized
INFO - 2023-01-10 09:25:54 --> Language Class Initialized
INFO - 2023-01-10 09:25:54 --> Loader Class Initialized
INFO - 2023-01-10 09:25:54 --> Controller Class Initialized
DEBUG - 2023-01-10 09:25:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:25:54 --> Database Driver Class Initialized
INFO - 2023-01-10 09:25:54 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:25:54 --> Database Driver Class Initialized
INFO - 2023-01-10 09:25:54 --> Model "Login_model" initialized
INFO - 2023-01-10 09:25:54 --> Final output sent to browser
DEBUG - 2023-01-10 09:25:54 --> Total execution time: 0.1555
INFO - 2023-01-10 09:25:54 --> Config Class Initialized
INFO - 2023-01-10 09:25:54 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:25:54 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:25:54 --> Utf8 Class Initialized
INFO - 2023-01-10 09:25:54 --> URI Class Initialized
INFO - 2023-01-10 09:25:54 --> Router Class Initialized
INFO - 2023-01-10 09:25:54 --> Output Class Initialized
INFO - 2023-01-10 09:25:54 --> Security Class Initialized
DEBUG - 2023-01-10 09:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:25:54 --> Input Class Initialized
INFO - 2023-01-10 09:25:54 --> Language Class Initialized
INFO - 2023-01-10 09:25:54 --> Loader Class Initialized
INFO - 2023-01-10 09:25:54 --> Controller Class Initialized
DEBUG - 2023-01-10 09:25:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:25:54 --> Database Driver Class Initialized
INFO - 2023-01-10 09:25:54 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:25:54 --> Database Driver Class Initialized
INFO - 2023-01-10 09:25:54 --> Model "Login_model" initialized
INFO - 2023-01-10 09:25:54 --> Final output sent to browser
DEBUG - 2023-01-10 09:25:54 --> Total execution time: 0.1399
INFO - 2023-01-10 09:25:57 --> Config Class Initialized
INFO - 2023-01-10 09:25:57 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:25:57 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:25:57 --> Utf8 Class Initialized
INFO - 2023-01-10 09:25:57 --> URI Class Initialized
INFO - 2023-01-10 09:25:57 --> Router Class Initialized
INFO - 2023-01-10 09:25:57 --> Output Class Initialized
INFO - 2023-01-10 09:25:57 --> Security Class Initialized
DEBUG - 2023-01-10 09:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:25:57 --> Input Class Initialized
INFO - 2023-01-10 09:25:57 --> Language Class Initialized
INFO - 2023-01-10 09:25:57 --> Loader Class Initialized
INFO - 2023-01-10 09:25:57 --> Controller Class Initialized
DEBUG - 2023-01-10 09:25:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:25:57 --> Database Driver Class Initialized
INFO - 2023-01-10 09:25:57 --> Database Driver Class Initialized
INFO - 2023-01-10 09:25:57 --> Model "Login_model" initialized
INFO - 2023-01-10 09:25:57 --> Final output sent to browser
DEBUG - 2023-01-10 09:25:57 --> Total execution time: 0.0397
INFO - 2023-01-10 09:25:57 --> Config Class Initialized
INFO - 2023-01-10 09:25:57 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:25:57 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:25:57 --> Utf8 Class Initialized
INFO - 2023-01-10 09:25:57 --> URI Class Initialized
INFO - 2023-01-10 09:25:57 --> Router Class Initialized
INFO - 2023-01-10 09:25:57 --> Output Class Initialized
INFO - 2023-01-10 09:25:57 --> Security Class Initialized
DEBUG - 2023-01-10 09:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:25:57 --> Input Class Initialized
INFO - 2023-01-10 09:25:57 --> Language Class Initialized
INFO - 2023-01-10 09:25:57 --> Loader Class Initialized
INFO - 2023-01-10 09:25:57 --> Controller Class Initialized
DEBUG - 2023-01-10 09:25:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:25:57 --> Database Driver Class Initialized
INFO - 2023-01-10 09:25:57 --> Database Driver Class Initialized
INFO - 2023-01-10 09:25:57 --> Model "Login_model" initialized
INFO - 2023-01-10 09:25:57 --> Final output sent to browser
DEBUG - 2023-01-10 09:25:57 --> Total execution time: 0.0280
INFO - 2023-01-10 09:26:10 --> Config Class Initialized
INFO - 2023-01-10 09:26:10 --> Hooks Class Initialized
INFO - 2023-01-10 09:26:10 --> Config Class Initialized
DEBUG - 2023-01-10 09:26:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:10 --> Hooks Class Initialized
INFO - 2023-01-10 09:26:10 --> Utf8 Class Initialized
DEBUG - 2023-01-10 09:26:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:10 --> URI Class Initialized
INFO - 2023-01-10 09:26:10 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:10 --> Router Class Initialized
INFO - 2023-01-10 09:26:10 --> URI Class Initialized
INFO - 2023-01-10 09:26:10 --> Output Class Initialized
INFO - 2023-01-10 09:26:10 --> Security Class Initialized
INFO - 2023-01-10 09:26:10 --> Router Class Initialized
DEBUG - 2023-01-10 09:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:10 --> Input Class Initialized
INFO - 2023-01-10 09:26:10 --> Output Class Initialized
INFO - 2023-01-10 09:26:10 --> Language Class Initialized
INFO - 2023-01-10 09:26:10 --> Security Class Initialized
INFO - 2023-01-10 09:26:10 --> Loader Class Initialized
DEBUG - 2023-01-10 09:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:10 --> Controller Class Initialized
INFO - 2023-01-10 09:26:10 --> Input Class Initialized
DEBUG - 2023-01-10 09:26:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:10 --> Language Class Initialized
INFO - 2023-01-10 09:26:10 --> Loader Class Initialized
INFO - 2023-01-10 09:26:10 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:10 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:10 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:10 --> Total execution time: 0.0091
INFO - 2023-01-10 09:26:10 --> Config Class Initialized
INFO - 2023-01-10 09:26:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:26:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:26:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:10 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:10 --> URI Class Initialized
INFO - 2023-01-10 09:26:10 --> Router Class Initialized
INFO - 2023-01-10 09:26:10 --> Output Class Initialized
INFO - 2023-01-10 09:26:10 --> Security Class Initialized
DEBUG - 2023-01-10 09:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:10 --> Input Class Initialized
INFO - 2023-01-10 09:26:10 --> Language Class Initialized
INFO - 2023-01-10 09:26:10 --> Loader Class Initialized
INFO - 2023-01-10 09:26:10 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:10 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:10 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:10 --> Total execution time: 0.0589
INFO - 2023-01-10 09:26:10 --> Config Class Initialized
INFO - 2023-01-10 09:26:10 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:26:10 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:10 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:10 --> URI Class Initialized
INFO - 2023-01-10 09:26:10 --> Router Class Initialized
INFO - 2023-01-10 09:26:10 --> Output Class Initialized
INFO - 2023-01-10 09:26:10 --> Security Class Initialized
DEBUG - 2023-01-10 09:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:10 --> Input Class Initialized
INFO - 2023-01-10 09:26:10 --> Language Class Initialized
INFO - 2023-01-10 09:26:10 --> Model "Login_model" initialized
INFO - 2023-01-10 09:26:10 --> Loader Class Initialized
INFO - 2023-01-10 09:26:10 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:10 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:10 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:10 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:10 --> Total execution time: 0.0554
INFO - 2023-01-10 09:26:10 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:26:10 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:10 --> Total execution time: 0.0581
INFO - 2023-01-10 09:26:12 --> Config Class Initialized
INFO - 2023-01-10 09:26:12 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:26:12 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:12 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:12 --> URI Class Initialized
INFO - 2023-01-10 09:26:12 --> Router Class Initialized
INFO - 2023-01-10 09:26:12 --> Output Class Initialized
INFO - 2023-01-10 09:26:12 --> Security Class Initialized
DEBUG - 2023-01-10 09:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:12 --> Input Class Initialized
INFO - 2023-01-10 09:26:12 --> Language Class Initialized
INFO - 2023-01-10 09:26:12 --> Loader Class Initialized
INFO - 2023-01-10 09:26:12 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:12 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:12 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:26:12 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:12 --> Model "Login_model" initialized
INFO - 2023-01-10 09:26:12 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:12 --> Total execution time: 0.0732
INFO - 2023-01-10 09:26:12 --> Config Class Initialized
INFO - 2023-01-10 09:26:12 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:26:12 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:12 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:12 --> URI Class Initialized
INFO - 2023-01-10 09:26:12 --> Router Class Initialized
INFO - 2023-01-10 09:26:12 --> Output Class Initialized
INFO - 2023-01-10 09:26:12 --> Security Class Initialized
DEBUG - 2023-01-10 09:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:12 --> Input Class Initialized
INFO - 2023-01-10 09:26:12 --> Language Class Initialized
INFO - 2023-01-10 09:26:12 --> Loader Class Initialized
INFO - 2023-01-10 09:26:12 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:12 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:12 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:12 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:26:12 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:12 --> Model "Login_model" initialized
INFO - 2023-01-10 09:26:12 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:12 --> Total execution time: 0.0992
INFO - 2023-01-10 09:26:33 --> Config Class Initialized
INFO - 2023-01-10 09:26:33 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:26:33 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:33 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:33 --> URI Class Initialized
INFO - 2023-01-10 09:26:33 --> Router Class Initialized
INFO - 2023-01-10 09:26:33 --> Output Class Initialized
INFO - 2023-01-10 09:26:33 --> Security Class Initialized
DEBUG - 2023-01-10 09:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:33 --> Input Class Initialized
INFO - 2023-01-10 09:26:33 --> Language Class Initialized
INFO - 2023-01-10 09:26:33 --> Loader Class Initialized
INFO - 2023-01-10 09:26:33 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:33 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:33 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:33 --> Model "Login_model" initialized
INFO - 2023-01-10 09:26:33 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:33 --> Total execution time: 0.0224
INFO - 2023-01-10 09:26:33 --> Config Class Initialized
INFO - 2023-01-10 09:26:33 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:26:33 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:33 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:33 --> URI Class Initialized
INFO - 2023-01-10 09:26:33 --> Router Class Initialized
INFO - 2023-01-10 09:26:33 --> Output Class Initialized
INFO - 2023-01-10 09:26:33 --> Security Class Initialized
DEBUG - 2023-01-10 09:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:33 --> Input Class Initialized
INFO - 2023-01-10 09:26:33 --> Language Class Initialized
INFO - 2023-01-10 09:26:33 --> Loader Class Initialized
INFO - 2023-01-10 09:26:33 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:33 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:33 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:33 --> Model "Login_model" initialized
INFO - 2023-01-10 09:26:33 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:33 --> Total execution time: 0.0236
INFO - 2023-01-10 09:26:36 --> Config Class Initialized
INFO - 2023-01-10 09:26:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:26:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:36 --> URI Class Initialized
INFO - 2023-01-10 09:26:36 --> Router Class Initialized
INFO - 2023-01-10 09:26:36 --> Output Class Initialized
INFO - 2023-01-10 09:26:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:36 --> Input Class Initialized
INFO - 2023-01-10 09:26:36 --> Language Class Initialized
INFO - 2023-01-10 09:26:36 --> Loader Class Initialized
INFO - 2023-01-10 09:26:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:36 --> Model "Login_model" initialized
INFO - 2023-01-10 09:26:36 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:36 --> Total execution time: 0.0253
INFO - 2023-01-10 09:26:36 --> Config Class Initialized
INFO - 2023-01-10 09:26:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:26:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:26:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:26:36 --> URI Class Initialized
INFO - 2023-01-10 09:26:36 --> Router Class Initialized
INFO - 2023-01-10 09:26:36 --> Output Class Initialized
INFO - 2023-01-10 09:26:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:26:36 --> Input Class Initialized
INFO - 2023-01-10 09:26:36 --> Language Class Initialized
INFO - 2023-01-10 09:26:36 --> Loader Class Initialized
INFO - 2023-01-10 09:26:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:26:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:26:36 --> Model "Login_model" initialized
INFO - 2023-01-10 09:26:36 --> Final output sent to browser
DEBUG - 2023-01-10 09:26:36 --> Total execution time: 0.0209
INFO - 2023-01-10 09:27:20 --> Config Class Initialized
INFO - 2023-01-10 09:27:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:20 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:20 --> URI Class Initialized
INFO - 2023-01-10 09:27:20 --> Router Class Initialized
INFO - 2023-01-10 09:27:20 --> Output Class Initialized
INFO - 2023-01-10 09:27:20 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:20 --> Input Class Initialized
INFO - 2023-01-10 09:27:20 --> Language Class Initialized
INFO - 2023-01-10 09:27:20 --> Loader Class Initialized
INFO - 2023-01-10 09:27:20 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:20 --> Model "Login_model" initialized
INFO - 2023-01-10 09:27:20 --> Final output sent to browser
DEBUG - 2023-01-10 09:27:20 --> Total execution time: 0.2081
INFO - 2023-01-10 09:27:20 --> Config Class Initialized
INFO - 2023-01-10 09:27:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:20 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:20 --> URI Class Initialized
INFO - 2023-01-10 09:27:20 --> Router Class Initialized
INFO - 2023-01-10 09:27:20 --> Output Class Initialized
INFO - 2023-01-10 09:27:20 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:20 --> Input Class Initialized
INFO - 2023-01-10 09:27:20 --> Language Class Initialized
INFO - 2023-01-10 09:27:20 --> Loader Class Initialized
INFO - 2023-01-10 09:27:20 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:20 --> Model "Login_model" initialized
INFO - 2023-01-10 09:27:20 --> Final output sent to browser
DEBUG - 2023-01-10 09:27:20 --> Total execution time: 0.1301
INFO - 2023-01-10 09:27:25 --> Config Class Initialized
INFO - 2023-01-10 09:27:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:25 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:25 --> URI Class Initialized
INFO - 2023-01-10 09:27:25 --> Router Class Initialized
INFO - 2023-01-10 09:27:25 --> Output Class Initialized
INFO - 2023-01-10 09:27:25 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:25 --> Input Class Initialized
INFO - 2023-01-10 09:27:25 --> Language Class Initialized
INFO - 2023-01-10 09:27:25 --> Loader Class Initialized
INFO - 2023-01-10 09:27:25 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:25 --> Model "Login_model" initialized
INFO - 2023-01-10 09:27:25 --> Final output sent to browser
DEBUG - 2023-01-10 09:27:25 --> Total execution time: 0.0539
INFO - 2023-01-10 09:27:25 --> Config Class Initialized
INFO - 2023-01-10 09:27:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:25 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:25 --> URI Class Initialized
INFO - 2023-01-10 09:27:25 --> Router Class Initialized
INFO - 2023-01-10 09:27:25 --> Output Class Initialized
INFO - 2023-01-10 09:27:25 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:25 --> Input Class Initialized
INFO - 2023-01-10 09:27:25 --> Language Class Initialized
INFO - 2023-01-10 09:27:25 --> Loader Class Initialized
INFO - 2023-01-10 09:27:25 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:25 --> Model "Login_model" initialized
INFO - 2023-01-10 09:27:25 --> Final output sent to browser
DEBUG - 2023-01-10 09:27:25 --> Total execution time: 0.0810
INFO - 2023-01-10 09:27:27 --> Config Class Initialized
INFO - 2023-01-10 09:27:27 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:27 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:27 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:27 --> URI Class Initialized
INFO - 2023-01-10 09:27:27 --> Router Class Initialized
INFO - 2023-01-10 09:27:27 --> Output Class Initialized
INFO - 2023-01-10 09:27:27 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:27 --> Input Class Initialized
INFO - 2023-01-10 09:27:27 --> Language Class Initialized
INFO - 2023-01-10 09:27:27 --> Loader Class Initialized
INFO - 2023-01-10 09:27:27 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:27 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:27 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:27 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:27 --> Model "Login_model" initialized
INFO - 2023-01-10 09:27:27 --> Final output sent to browser
DEBUG - 2023-01-10 09:27:27 --> Total execution time: 0.0495
INFO - 2023-01-10 09:27:29 --> Config Class Initialized
INFO - 2023-01-10 09:27:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:29 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:29 --> URI Class Initialized
INFO - 2023-01-10 09:27:29 --> Router Class Initialized
INFO - 2023-01-10 09:27:29 --> Output Class Initialized
INFO - 2023-01-10 09:27:29 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:29 --> Input Class Initialized
INFO - 2023-01-10 09:27:29 --> Language Class Initialized
INFO - 2023-01-10 09:27:29 --> Loader Class Initialized
INFO - 2023-01-10 09:27:29 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:29 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:29 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:29 --> Model "Login_model" initialized
INFO - 2023-01-10 09:27:29 --> Final output sent to browser
DEBUG - 2023-01-10 09:27:29 --> Total execution time: 0.0662
INFO - 2023-01-10 09:27:40 --> Config Class Initialized
INFO - 2023-01-10 09:27:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:40 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:40 --> URI Class Initialized
INFO - 2023-01-10 09:27:40 --> Router Class Initialized
INFO - 2023-01-10 09:27:40 --> Output Class Initialized
INFO - 2023-01-10 09:27:40 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:40 --> Input Class Initialized
INFO - 2023-01-10 09:27:40 --> Language Class Initialized
INFO - 2023-01-10 09:27:40 --> Loader Class Initialized
INFO - 2023-01-10 09:27:40 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:40 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:27:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:27:40 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:27:40 --> Config Class Initialized
INFO - 2023-01-10 09:27:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:40 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:40 --> URI Class Initialized
INFO - 2023-01-10 09:27:40 --> Router Class Initialized
INFO - 2023-01-10 09:27:40 --> Output Class Initialized
INFO - 2023-01-10 09:27:40 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:40 --> Input Class Initialized
INFO - 2023-01-10 09:27:40 --> Language Class Initialized
INFO - 2023-01-10 09:27:40 --> Loader Class Initialized
INFO - 2023-01-10 09:27:40 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:40 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:27:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:27:40 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:27:44 --> Config Class Initialized
INFO - 2023-01-10 09:27:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:27:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:27:44 --> Utf8 Class Initialized
INFO - 2023-01-10 09:27:44 --> URI Class Initialized
INFO - 2023-01-10 09:27:44 --> Router Class Initialized
INFO - 2023-01-10 09:27:44 --> Output Class Initialized
INFO - 2023-01-10 09:27:44 --> Security Class Initialized
DEBUG - 2023-01-10 09:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:27:44 --> Input Class Initialized
INFO - 2023-01-10 09:27:44 --> Language Class Initialized
INFO - 2023-01-10 09:27:44 --> Loader Class Initialized
INFO - 2023-01-10 09:27:44 --> Controller Class Initialized
DEBUG - 2023-01-10 09:27:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:27:44 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:44 --> Database Driver Class Initialized
INFO - 2023-01-10 09:27:44 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:27:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:27:44 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:30:34 --> Config Class Initialized
INFO - 2023-01-10 09:30:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:30:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:30:34 --> Utf8 Class Initialized
INFO - 2023-01-10 09:30:34 --> URI Class Initialized
INFO - 2023-01-10 09:30:34 --> Router Class Initialized
INFO - 2023-01-10 09:30:34 --> Output Class Initialized
INFO - 2023-01-10 09:30:34 --> Security Class Initialized
DEBUG - 2023-01-10 09:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:30:34 --> Input Class Initialized
INFO - 2023-01-10 09:30:34 --> Language Class Initialized
INFO - 2023-01-10 09:30:34 --> Loader Class Initialized
INFO - 2023-01-10 09:30:34 --> Controller Class Initialized
DEBUG - 2023-01-10 09:30:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:30:34 --> Database Driver Class Initialized
INFO - 2023-01-10 09:30:34 --> Database Driver Class Initialized
INFO - 2023-01-10 09:30:34 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:30:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:30:34 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 16
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:30:34 --> Config Class Initialized
INFO - 2023-01-10 09:30:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:30:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:30:34 --> Utf8 Class Initialized
INFO - 2023-01-10 09:30:34 --> URI Class Initialized
INFO - 2023-01-10 09:30:34 --> Router Class Initialized
INFO - 2023-01-10 09:30:34 --> Output Class Initialized
INFO - 2023-01-10 09:30:34 --> Security Class Initialized
DEBUG - 2023-01-10 09:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:30:34 --> Input Class Initialized
INFO - 2023-01-10 09:30:34 --> Language Class Initialized
INFO - 2023-01-10 09:30:34 --> Loader Class Initialized
INFO - 2023-01-10 09:30:34 --> Controller Class Initialized
DEBUG - 2023-01-10 09:30:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:30:34 --> Database Driver Class Initialized
INFO - 2023-01-10 09:30:34 --> Database Driver Class Initialized
INFO - 2023-01-10 09:30:34 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:30:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:30:34 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 16
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:30:35 --> Config Class Initialized
INFO - 2023-01-10 09:30:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:30:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:30:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:30:35 --> URI Class Initialized
INFO - 2023-01-10 09:30:35 --> Router Class Initialized
INFO - 2023-01-10 09:30:35 --> Output Class Initialized
INFO - 2023-01-10 09:30:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:30:35 --> Input Class Initialized
INFO - 2023-01-10 09:30:35 --> Language Class Initialized
INFO - 2023-01-10 09:30:35 --> Loader Class Initialized
INFO - 2023-01-10 09:30:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:30:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:30:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:30:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:30:35 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:30:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:30:35 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 16
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:31:05 --> Config Class Initialized
INFO - 2023-01-10 09:31:05 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:31:05 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:31:05 --> Utf8 Class Initialized
INFO - 2023-01-10 09:31:05 --> URI Class Initialized
INFO - 2023-01-10 09:31:05 --> Router Class Initialized
INFO - 2023-01-10 09:31:05 --> Output Class Initialized
INFO - 2023-01-10 09:31:05 --> Security Class Initialized
DEBUG - 2023-01-10 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:31:05 --> Input Class Initialized
INFO - 2023-01-10 09:31:05 --> Language Class Initialized
INFO - 2023-01-10 09:31:05 --> Loader Class Initialized
INFO - 2023-01-10 09:31:05 --> Controller Class Initialized
DEBUG - 2023-01-10 09:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:31:05 --> Database Driver Class Initialized
INFO - 2023-01-10 09:31:05 --> Database Driver Class Initialized
INFO - 2023-01-10 09:31:05 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:31:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:31:05 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 16
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:31:05 --> Config Class Initialized
INFO - 2023-01-10 09:31:05 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:31:05 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:31:05 --> Utf8 Class Initialized
INFO - 2023-01-10 09:31:05 --> URI Class Initialized
INFO - 2023-01-10 09:31:05 --> Router Class Initialized
INFO - 2023-01-10 09:31:05 --> Output Class Initialized
INFO - 2023-01-10 09:31:05 --> Security Class Initialized
DEBUG - 2023-01-10 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:31:05 --> Input Class Initialized
INFO - 2023-01-10 09:31:05 --> Language Class Initialized
INFO - 2023-01-10 09:31:05 --> Loader Class Initialized
INFO - 2023-01-10 09:31:05 --> Controller Class Initialized
DEBUG - 2023-01-10 09:31:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:31:05 --> Database Driver Class Initialized
INFO - 2023-01-10 09:31:05 --> Database Driver Class Initialized
INFO - 2023-01-10 09:31:05 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:31:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:31:05 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 16
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:31:49 --> Config Class Initialized
INFO - 2023-01-10 09:31:49 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:31:49 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:31:49 --> Utf8 Class Initialized
INFO - 2023-01-10 09:31:49 --> URI Class Initialized
INFO - 2023-01-10 09:31:49 --> Router Class Initialized
INFO - 2023-01-10 09:31:49 --> Output Class Initialized
INFO - 2023-01-10 09:31:49 --> Security Class Initialized
DEBUG - 2023-01-10 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:31:49 --> Input Class Initialized
INFO - 2023-01-10 09:31:49 --> Language Class Initialized
INFO - 2023-01-10 09:31:49 --> Loader Class Initialized
INFO - 2023-01-10 09:31:49 --> Controller Class Initialized
DEBUG - 2023-01-10 09:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:31:49 --> Database Driver Class Initialized
INFO - 2023-01-10 09:31:49 --> Database Driver Class Initialized
INFO - 2023-01-10 09:31:49 --> Model "Login_model" initialized
INFO - 2023-01-10 09:31:49 --> Config Class Initialized
INFO - 2023-01-10 09:31:49 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:31:49 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:31:49 --> Utf8 Class Initialized
INFO - 2023-01-10 09:31:49 --> URI Class Initialized
INFO - 2023-01-10 09:31:49 --> Router Class Initialized
INFO - 2023-01-10 09:31:49 --> Output Class Initialized
INFO - 2023-01-10 09:31:49 --> Security Class Initialized
DEBUG - 2023-01-10 09:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:31:49 --> Input Class Initialized
INFO - 2023-01-10 09:31:49 --> Language Class Initialized
INFO - 2023-01-10 09:31:49 --> Loader Class Initialized
INFO - 2023-01-10 09:31:49 --> Controller Class Initialized
DEBUG - 2023-01-10 09:31:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:31:49 --> Database Driver Class Initialized
INFO - 2023-01-10 09:31:49 --> Database Driver Class Initialized
INFO - 2023-01-10 09:31:49 --> Model "Login_model" initialized
INFO - 2023-01-10 09:32:11 --> Config Class Initialized
INFO - 2023-01-10 09:32:11 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:32:11 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:32:11 --> Utf8 Class Initialized
INFO - 2023-01-10 09:32:11 --> URI Class Initialized
INFO - 2023-01-10 09:32:11 --> Router Class Initialized
INFO - 2023-01-10 09:32:11 --> Output Class Initialized
INFO - 2023-01-10 09:32:11 --> Security Class Initialized
DEBUG - 2023-01-10 09:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:32:11 --> Input Class Initialized
INFO - 2023-01-10 09:32:11 --> Language Class Initialized
INFO - 2023-01-10 09:32:11 --> Loader Class Initialized
INFO - 2023-01-10 09:32:11 --> Controller Class Initialized
DEBUG - 2023-01-10 09:32:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:32:11 --> Database Driver Class Initialized
INFO - 2023-01-10 09:32:11 --> Database Driver Class Initialized
INFO - 2023-01-10 09:32:11 --> Model "Login_model" initialized
INFO - 2023-01-10 09:32:11 --> Config Class Initialized
INFO - 2023-01-10 09:32:11 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:32:11 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:32:11 --> Utf8 Class Initialized
INFO - 2023-01-10 09:32:11 --> URI Class Initialized
INFO - 2023-01-10 09:32:11 --> Router Class Initialized
INFO - 2023-01-10 09:32:11 --> Output Class Initialized
INFO - 2023-01-10 09:32:11 --> Security Class Initialized
DEBUG - 2023-01-10 09:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:32:11 --> Input Class Initialized
INFO - 2023-01-10 09:32:11 --> Language Class Initialized
INFO - 2023-01-10 09:32:11 --> Loader Class Initialized
INFO - 2023-01-10 09:32:11 --> Controller Class Initialized
DEBUG - 2023-01-10 09:32:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:32:11 --> Database Driver Class Initialized
INFO - 2023-01-10 09:32:11 --> Database Driver Class Initialized
INFO - 2023-01-10 09:32:11 --> Model "Login_model" initialized
INFO - 2023-01-10 09:32:21 --> Config Class Initialized
INFO - 2023-01-10 09:32:21 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:32:21 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:32:21 --> Utf8 Class Initialized
INFO - 2023-01-10 09:32:21 --> URI Class Initialized
INFO - 2023-01-10 09:32:21 --> Router Class Initialized
INFO - 2023-01-10 09:32:21 --> Output Class Initialized
INFO - 2023-01-10 09:32:21 --> Security Class Initialized
DEBUG - 2023-01-10 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:32:21 --> Input Class Initialized
INFO - 2023-01-10 09:32:21 --> Language Class Initialized
INFO - 2023-01-10 09:32:21 --> Loader Class Initialized
INFO - 2023-01-10 09:32:21 --> Controller Class Initialized
DEBUG - 2023-01-10 09:32:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:32:21 --> Database Driver Class Initialized
INFO - 2023-01-10 09:32:21 --> Database Driver Class Initialized
INFO - 2023-01-10 09:32:21 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:32:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:32:21 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:32:21 --> Config Class Initialized
INFO - 2023-01-10 09:32:21 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:32:21 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:32:21 --> Utf8 Class Initialized
INFO - 2023-01-10 09:32:21 --> URI Class Initialized
INFO - 2023-01-10 09:32:21 --> Router Class Initialized
INFO - 2023-01-10 09:32:21 --> Output Class Initialized
INFO - 2023-01-10 09:32:21 --> Security Class Initialized
DEBUG - 2023-01-10 09:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:32:21 --> Input Class Initialized
INFO - 2023-01-10 09:32:21 --> Language Class Initialized
INFO - 2023-01-10 09:32:21 --> Loader Class Initialized
INFO - 2023-01-10 09:32:21 --> Controller Class Initialized
DEBUG - 2023-01-10 09:32:21 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:32:21 --> Database Driver Class Initialized
INFO - 2023-01-10 09:32:21 --> Database Driver Class Initialized
INFO - 2023-01-10 09:32:21 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:32:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:32:21 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:33:32 --> Config Class Initialized
INFO - 2023-01-10 09:33:32 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:33:32 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:33:32 --> Utf8 Class Initialized
INFO - 2023-01-10 09:33:32 --> URI Class Initialized
INFO - 2023-01-10 09:33:32 --> Router Class Initialized
INFO - 2023-01-10 09:33:32 --> Output Class Initialized
INFO - 2023-01-10 09:33:32 --> Security Class Initialized
DEBUG - 2023-01-10 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:33:32 --> Input Class Initialized
INFO - 2023-01-10 09:33:32 --> Language Class Initialized
INFO - 2023-01-10 09:33:32 --> Loader Class Initialized
INFO - 2023-01-10 09:33:32 --> Controller Class Initialized
DEBUG - 2023-01-10 09:33:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:33:32 --> Database Driver Class Initialized
INFO - 2023-01-10 09:33:32 --> Database Driver Class Initialized
INFO - 2023-01-10 09:33:32 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:33:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:33:32 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:33:32 --> Config Class Initialized
INFO - 2023-01-10 09:33:32 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:33:32 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:33:32 --> Utf8 Class Initialized
INFO - 2023-01-10 09:33:32 --> URI Class Initialized
INFO - 2023-01-10 09:33:32 --> Router Class Initialized
INFO - 2023-01-10 09:33:32 --> Output Class Initialized
INFO - 2023-01-10 09:33:32 --> Security Class Initialized
DEBUG - 2023-01-10 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:33:32 --> Input Class Initialized
INFO - 2023-01-10 09:33:32 --> Language Class Initialized
INFO - 2023-01-10 09:33:32 --> Loader Class Initialized
INFO - 2023-01-10 09:33:32 --> Controller Class Initialized
DEBUG - 2023-01-10 09:33:32 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:33:32 --> Database Driver Class Initialized
INFO - 2023-01-10 09:33:32 --> Database Driver Class Initialized
INFO - 2023-01-10 09:33:32 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:33:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:33:32 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:34:20 --> Config Class Initialized
INFO - 2023-01-10 09:34:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:34:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:34:20 --> Utf8 Class Initialized
INFO - 2023-01-10 09:34:20 --> URI Class Initialized
INFO - 2023-01-10 09:34:20 --> Router Class Initialized
INFO - 2023-01-10 09:34:20 --> Output Class Initialized
INFO - 2023-01-10 09:34:20 --> Security Class Initialized
DEBUG - 2023-01-10 09:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:34:20 --> Input Class Initialized
INFO - 2023-01-10 09:34:20 --> Language Class Initialized
INFO - 2023-01-10 09:34:20 --> Loader Class Initialized
INFO - 2023-01-10 09:34:20 --> Controller Class Initialized
DEBUG - 2023-01-10 09:34:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:34:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:20 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:34:20 --> Exception of type 'Error' occurred with Message: Call to a member function row() on null in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(42): Login_model->getList('select id, name...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:34:20 --> Config Class Initialized
INFO - 2023-01-10 09:34:20 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:34:20 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:34:20 --> Utf8 Class Initialized
INFO - 2023-01-10 09:34:20 --> URI Class Initialized
INFO - 2023-01-10 09:34:20 --> Router Class Initialized
INFO - 2023-01-10 09:34:20 --> Output Class Initialized
INFO - 2023-01-10 09:34:20 --> Security Class Initialized
DEBUG - 2023-01-10 09:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:34:20 --> Input Class Initialized
INFO - 2023-01-10 09:34:20 --> Language Class Initialized
INFO - 2023-01-10 09:34:20 --> Loader Class Initialized
INFO - 2023-01-10 09:34:20 --> Controller Class Initialized
DEBUG - 2023-01-10 09:34:20 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:34:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:20 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:20 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:34:20 --> Exception of type 'Error' occurred with Message: Call to a member function row() on null in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(42): Login_model->getList('select id, name...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:34:24 --> Config Class Initialized
INFO - 2023-01-10 09:34:24 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:34:24 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:34:24 --> Utf8 Class Initialized
INFO - 2023-01-10 09:34:24 --> URI Class Initialized
INFO - 2023-01-10 09:34:24 --> Router Class Initialized
INFO - 2023-01-10 09:34:24 --> Output Class Initialized
INFO - 2023-01-10 09:34:24 --> Security Class Initialized
DEBUG - 2023-01-10 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:34:24 --> Input Class Initialized
INFO - 2023-01-10 09:34:24 --> Language Class Initialized
INFO - 2023-01-10 09:34:24 --> Loader Class Initialized
INFO - 2023-01-10 09:34:24 --> Controller Class Initialized
DEBUG - 2023-01-10 09:34:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:34:24 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:24 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:24 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:34:24 --> Exception of type 'Error' occurred with Message: Call to a member function row() on null in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(42): Login_model->getList('select id, name...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:34:35 --> Config Class Initialized
INFO - 2023-01-10 09:34:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:34:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:34:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:34:35 --> URI Class Initialized
INFO - 2023-01-10 09:34:35 --> Router Class Initialized
INFO - 2023-01-10 09:34:35 --> Output Class Initialized
INFO - 2023-01-10 09:34:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:34:35 --> Input Class Initialized
INFO - 2023-01-10 09:34:35 --> Language Class Initialized
INFO - 2023-01-10 09:34:35 --> Loader Class Initialized
INFO - 2023-01-10 09:34:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:34:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:34:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:35 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:34:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:34:35 --> Exception of type 'Error' occurred with Message: Call to a member function row() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:34:35 --> Config Class Initialized
INFO - 2023-01-10 09:34:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:34:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:34:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:34:35 --> URI Class Initialized
INFO - 2023-01-10 09:34:35 --> Router Class Initialized
INFO - 2023-01-10 09:34:35 --> Output Class Initialized
INFO - 2023-01-10 09:34:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:34:35 --> Input Class Initialized
INFO - 2023-01-10 09:34:35 --> Language Class Initialized
INFO - 2023-01-10 09:34:35 --> Loader Class Initialized
INFO - 2023-01-10 09:34:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:34:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:34:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:35 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:34:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:34:35 --> Exception of type 'Error' occurred with Message: Call to a member function row() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:34:36 --> Config Class Initialized
INFO - 2023-01-10 09:34:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:34:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:34:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:34:36 --> URI Class Initialized
INFO - 2023-01-10 09:34:36 --> Router Class Initialized
INFO - 2023-01-10 09:34:36 --> Output Class Initialized
INFO - 2023-01-10 09:34:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:34:36 --> Input Class Initialized
INFO - 2023-01-10 09:34:36 --> Language Class Initialized
INFO - 2023-01-10 09:34:36 --> Loader Class Initialized
INFO - 2023-01-10 09:34:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:34:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:34:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:34:36 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:34:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:34:36 --> Exception of type 'Error' occurred with Message: Call to a member function row() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 18
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:35:39 --> Config Class Initialized
INFO - 2023-01-10 09:35:39 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:35:39 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:35:39 --> Utf8 Class Initialized
INFO - 2023-01-10 09:35:39 --> URI Class Initialized
INFO - 2023-01-10 09:35:39 --> Router Class Initialized
INFO - 2023-01-10 09:35:39 --> Output Class Initialized
INFO - 2023-01-10 09:35:39 --> Security Class Initialized
DEBUG - 2023-01-10 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:35:39 --> Input Class Initialized
INFO - 2023-01-10 09:35:39 --> Language Class Initialized
INFO - 2023-01-10 09:35:39 --> Loader Class Initialized
INFO - 2023-01-10 09:35:39 --> Controller Class Initialized
DEBUG - 2023-01-10 09:35:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:35:39 --> Database Driver Class Initialized
INFO - 2023-01-10 09:35:39 --> Database Driver Class Initialized
INFO - 2023-01-10 09:35:39 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:35:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:35:39 --> Exception of type 'Error' occurred with Message: Call to a member function row() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 19
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:35:39 --> Config Class Initialized
INFO - 2023-01-10 09:35:39 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:35:39 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:35:39 --> Utf8 Class Initialized
INFO - 2023-01-10 09:35:39 --> URI Class Initialized
INFO - 2023-01-10 09:35:39 --> Router Class Initialized
INFO - 2023-01-10 09:35:39 --> Output Class Initialized
INFO - 2023-01-10 09:35:39 --> Security Class Initialized
DEBUG - 2023-01-10 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:35:39 --> Input Class Initialized
INFO - 2023-01-10 09:35:39 --> Language Class Initialized
INFO - 2023-01-10 09:35:39 --> Loader Class Initialized
INFO - 2023-01-10 09:35:39 --> Controller Class Initialized
DEBUG - 2023-01-10 09:35:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:35:39 --> Database Driver Class Initialized
INFO - 2023-01-10 09:35:39 --> Database Driver Class Initialized
INFO - 2023-01-10 09:35:39 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:35:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
ERROR - 2023-01-10 09:35:39 --> Exception of type 'Error' occurred with Message: Call to a member function row() on boolean in File /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/models/Login_model.php at Line 19
 Backtrace 
#0 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/controllers/user/User.php(56): Login_model->getList('select count(id...')
#1 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/system/core/CodeIgniter.php(532): User->userList()
#2 /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/index.php(305): require_once('/Users/helayd/D...')
#3 {main}
INFO - 2023-01-10 09:36:22 --> Config Class Initialized
INFO - 2023-01-10 09:36:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:36:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:36:22 --> Utf8 Class Initialized
INFO - 2023-01-10 09:36:22 --> URI Class Initialized
INFO - 2023-01-10 09:36:22 --> Router Class Initialized
INFO - 2023-01-10 09:36:22 --> Output Class Initialized
INFO - 2023-01-10 09:36:22 --> Security Class Initialized
DEBUG - 2023-01-10 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:36:22 --> Input Class Initialized
INFO - 2023-01-10 09:36:22 --> Language Class Initialized
INFO - 2023-01-10 09:36:22 --> Loader Class Initialized
INFO - 2023-01-10 09:36:22 --> Controller Class Initialized
DEBUG - 2023-01-10 09:36:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:36:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:22 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:36:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
INFO - 2023-01-10 09:36:22 --> Config Class Initialized
INFO - 2023-01-10 09:36:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:36:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:36:22 --> Utf8 Class Initialized
INFO - 2023-01-10 09:36:22 --> URI Class Initialized
INFO - 2023-01-10 09:36:22 --> Router Class Initialized
INFO - 2023-01-10 09:36:22 --> Output Class Initialized
INFO - 2023-01-10 09:36:22 --> Security Class Initialized
DEBUG - 2023-01-10 09:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:36:22 --> Input Class Initialized
INFO - 2023-01-10 09:36:22 --> Language Class Initialized
INFO - 2023-01-10 09:36:22 --> Loader Class Initialized
INFO - 2023-01-10 09:36:22 --> Controller Class Initialized
DEBUG - 2023-01-10 09:36:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:36:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:22 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:36:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
INFO - 2023-01-10 09:36:24 --> Config Class Initialized
INFO - 2023-01-10 09:36:24 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:36:24 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:36:24 --> Utf8 Class Initialized
INFO - 2023-01-10 09:36:24 --> URI Class Initialized
INFO - 2023-01-10 09:36:24 --> Router Class Initialized
INFO - 2023-01-10 09:36:24 --> Output Class Initialized
INFO - 2023-01-10 09:36:24 --> Security Class Initialized
DEBUG - 2023-01-10 09:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:36:24 --> Input Class Initialized
INFO - 2023-01-10 09:36:24 --> Language Class Initialized
INFO - 2023-01-10 09:36:24 --> Loader Class Initialized
INFO - 2023-01-10 09:36:24 --> Controller Class Initialized
DEBUG - 2023-01-10 09:36:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:36:24 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:24 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:24 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:36:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
INFO - 2023-01-10 09:36:28 --> Config Class Initialized
INFO - 2023-01-10 09:36:28 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:36:28 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:36:28 --> Utf8 Class Initialized
INFO - 2023-01-10 09:36:28 --> URI Class Initialized
INFO - 2023-01-10 09:36:28 --> Router Class Initialized
INFO - 2023-01-10 09:36:28 --> Output Class Initialized
INFO - 2023-01-10 09:36:28 --> Security Class Initialized
DEBUG - 2023-01-10 09:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:36:28 --> Input Class Initialized
INFO - 2023-01-10 09:36:28 --> Language Class Initialized
INFO - 2023-01-10 09:36:28 --> Loader Class Initialized
INFO - 2023-01-10 09:36:28 --> Controller Class Initialized
DEBUG - 2023-01-10 09:36:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:36:28 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:28 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:28 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:36:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
INFO - 2023-01-10 09:36:28 --> Config Class Initialized
INFO - 2023-01-10 09:36:28 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:36:28 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:36:28 --> Utf8 Class Initialized
INFO - 2023-01-10 09:36:28 --> URI Class Initialized
INFO - 2023-01-10 09:36:28 --> Router Class Initialized
INFO - 2023-01-10 09:36:28 --> Output Class Initialized
INFO - 2023-01-10 09:36:28 --> Security Class Initialized
DEBUG - 2023-01-10 09:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:36:28 --> Input Class Initialized
INFO - 2023-01-10 09:36:28 --> Language Class Initialized
INFO - 2023-01-10 09:36:28 --> Loader Class Initialized
INFO - 2023-01-10 09:36:28 --> Controller Class Initialized
DEBUG - 2023-01-10 09:36:28 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:36:28 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:28 --> Database Driver Class Initialized
INFO - 2023-01-10 09:36:28 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:36:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
INFO - 2023-01-10 09:37:15 --> Config Class Initialized
INFO - 2023-01-10 09:37:15 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:15 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:15 --> URI Class Initialized
INFO - 2023-01-10 09:37:15 --> Router Class Initialized
INFO - 2023-01-10 09:37:15 --> Output Class Initialized
INFO - 2023-01-10 09:37:15 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:15 --> Input Class Initialized
INFO - 2023-01-10 09:37:15 --> Language Class Initialized
INFO - 2023-01-10 09:37:15 --> Loader Class Initialized
INFO - 2023-01-10 09:37:15 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:15 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:15 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:15 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:37:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
INFO - 2023-01-10 09:37:15 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:15 --> Total execution time: 0.0366
INFO - 2023-01-10 09:37:15 --> Config Class Initialized
INFO - 2023-01-10 09:37:15 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:15 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:15 --> URI Class Initialized
INFO - 2023-01-10 09:37:15 --> Router Class Initialized
INFO - 2023-01-10 09:37:15 --> Output Class Initialized
INFO - 2023-01-10 09:37:15 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:15 --> Input Class Initialized
INFO - 2023-01-10 09:37:15 --> Language Class Initialized
INFO - 2023-01-10 09:37:15 --> Loader Class Initialized
INFO - 2023-01-10 09:37:15 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:15 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:15 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:15 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:37:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%test1%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%test1%'
INFO - 2023-01-10 09:37:15 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:15 --> Total execution time: 0.0415
INFO - 2023-01-10 09:37:22 --> Config Class Initialized
INFO - 2023-01-10 09:37:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:22 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:22 --> URI Class Initialized
INFO - 2023-01-10 09:37:22 --> Router Class Initialized
INFO - 2023-01-10 09:37:22 --> Output Class Initialized
INFO - 2023-01-10 09:37:22 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:22 --> Input Class Initialized
INFO - 2023-01-10 09:37:22 --> Language Class Initialized
INFO - 2023-01-10 09:37:22 --> Loader Class Initialized
INFO - 2023-01-10 09:37:22 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:22 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:22 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:22 --> Total execution time: 0.0504
INFO - 2023-01-10 09:37:22 --> Config Class Initialized
INFO - 2023-01-10 09:37:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:22 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:22 --> URI Class Initialized
INFO - 2023-01-10 09:37:22 --> Router Class Initialized
INFO - 2023-01-10 09:37:22 --> Output Class Initialized
INFO - 2023-01-10 09:37:22 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:22 --> Input Class Initialized
INFO - 2023-01-10 09:37:22 --> Language Class Initialized
INFO - 2023-01-10 09:37:22 --> Loader Class Initialized
INFO - 2023-01-10 09:37:22 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:22 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:22 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:22 --> Total execution time: 0.0450
INFO - 2023-01-10 09:37:24 --> Config Class Initialized
INFO - 2023-01-10 09:37:24 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:24 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:24 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:24 --> URI Class Initialized
INFO - 2023-01-10 09:37:24 --> Router Class Initialized
INFO - 2023-01-10 09:37:24 --> Output Class Initialized
INFO - 2023-01-10 09:37:24 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:24 --> Input Class Initialized
INFO - 2023-01-10 09:37:24 --> Language Class Initialized
INFO - 2023-01-10 09:37:24 --> Loader Class Initialized
INFO - 2023-01-10 09:37:24 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:24 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:24 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:25 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:25 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:25 --> Total execution time: 0.0777
INFO - 2023-01-10 09:37:25 --> Config Class Initialized
INFO - 2023-01-10 09:37:25 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:25 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:25 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:25 --> URI Class Initialized
INFO - 2023-01-10 09:37:25 --> Router Class Initialized
INFO - 2023-01-10 09:37:25 --> Output Class Initialized
INFO - 2023-01-10 09:37:25 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:25 --> Input Class Initialized
INFO - 2023-01-10 09:37:25 --> Language Class Initialized
INFO - 2023-01-10 09:37:25 --> Loader Class Initialized
INFO - 2023-01-10 09:37:25 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:25 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:25 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:25 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:25 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:25 --> Total execution time: 0.0356
INFO - 2023-01-10 09:37:31 --> Config Class Initialized
INFO - 2023-01-10 09:37:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:31 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:31 --> URI Class Initialized
INFO - 2023-01-10 09:37:31 --> Router Class Initialized
INFO - 2023-01-10 09:37:31 --> Output Class Initialized
INFO - 2023-01-10 09:37:31 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:31 --> Input Class Initialized
INFO - 2023-01-10 09:37:31 --> Language Class Initialized
INFO - 2023-01-10 09:37:31 --> Loader Class Initialized
INFO - 2023-01-10 09:37:31 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:31 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:31 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:31 --> Total execution time: 0.0489
INFO - 2023-01-10 09:37:31 --> Config Class Initialized
INFO - 2023-01-10 09:37:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:31 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:31 --> URI Class Initialized
INFO - 2023-01-10 09:37:31 --> Router Class Initialized
INFO - 2023-01-10 09:37:31 --> Output Class Initialized
INFO - 2023-01-10 09:37:31 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:31 --> Input Class Initialized
INFO - 2023-01-10 09:37:31 --> Language Class Initialized
INFO - 2023-01-10 09:37:31 --> Loader Class Initialized
INFO - 2023-01-10 09:37:31 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:31 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:31 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:31 --> Total execution time: 0.0596
INFO - 2023-01-10 09:37:33 --> Config Class Initialized
INFO - 2023-01-10 09:37:33 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:33 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:33 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:33 --> URI Class Initialized
INFO - 2023-01-10 09:37:33 --> Router Class Initialized
INFO - 2023-01-10 09:37:33 --> Output Class Initialized
INFO - 2023-01-10 09:37:33 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:33 --> Input Class Initialized
INFO - 2023-01-10 09:37:33 --> Language Class Initialized
INFO - 2023-01-10 09:37:33 --> Loader Class Initialized
INFO - 2023-01-10 09:37:33 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:33 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:33 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:33 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:33 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:33 --> Total execution time: 0.0740
INFO - 2023-01-10 09:37:33 --> Config Class Initialized
INFO - 2023-01-10 09:37:33 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:33 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:33 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:33 --> URI Class Initialized
INFO - 2023-01-10 09:37:33 --> Router Class Initialized
INFO - 2023-01-10 09:37:33 --> Output Class Initialized
INFO - 2023-01-10 09:37:33 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:33 --> Input Class Initialized
INFO - 2023-01-10 09:37:33 --> Language Class Initialized
INFO - 2023-01-10 09:37:33 --> Loader Class Initialized
INFO - 2023-01-10 09:37:33 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:33 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:33 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:33 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:33 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:33 --> Total execution time: 0.0475
INFO - 2023-01-10 09:37:35 --> Config Class Initialized
INFO - 2023-01-10 09:37:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:35 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:35 --> URI Class Initialized
INFO - 2023-01-10 09:37:35 --> Router Class Initialized
INFO - 2023-01-10 09:37:35 --> Output Class Initialized
INFO - 2023-01-10 09:37:35 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:35 --> Input Class Initialized
INFO - 2023-01-10 09:37:35 --> Language Class Initialized
INFO - 2023-01-10 09:37:35 --> Loader Class Initialized
INFO - 2023-01-10 09:37:35 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:35 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:35 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:35 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:35 --> Total execution time: 0.0534
INFO - 2023-01-10 09:37:40 --> Config Class Initialized
INFO - 2023-01-10 09:37:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:40 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:40 --> URI Class Initialized
INFO - 2023-01-10 09:37:40 --> Router Class Initialized
INFO - 2023-01-10 09:37:40 --> Output Class Initialized
INFO - 2023-01-10 09:37:40 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:40 --> Input Class Initialized
INFO - 2023-01-10 09:37:40 --> Language Class Initialized
INFO - 2023-01-10 09:37:40 --> Loader Class Initialized
INFO - 2023-01-10 09:37:40 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:40 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:37:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%t%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%t%'
INFO - 2023-01-10 09:37:40 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:40 --> Total execution time: 0.0466
INFO - 2023-01-10 09:37:40 --> Config Class Initialized
INFO - 2023-01-10 09:37:40 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:40 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:40 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:40 --> URI Class Initialized
INFO - 2023-01-10 09:37:40 --> Router Class Initialized
INFO - 2023-01-10 09:37:40 --> Output Class Initialized
INFO - 2023-01-10 09:37:40 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:40 --> Input Class Initialized
INFO - 2023-01-10 09:37:40 --> Language Class Initialized
INFO - 2023-01-10 09:37:40 --> Loader Class Initialized
INFO - 2023-01-10 09:37:40 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:40 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:40 --> Model "Login_model" initialized
ERROR - 2023-01-10 09:37:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%t%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%t%'
INFO - 2023-01-10 09:37:40 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:40 --> Total execution time: 0.0434
INFO - 2023-01-10 09:37:45 --> Config Class Initialized
INFO - 2023-01-10 09:37:45 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:45 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:45 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:45 --> URI Class Initialized
INFO - 2023-01-10 09:37:45 --> Router Class Initialized
INFO - 2023-01-10 09:37:45 --> Output Class Initialized
INFO - 2023-01-10 09:37:45 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:45 --> Input Class Initialized
INFO - 2023-01-10 09:37:45 --> Language Class Initialized
INFO - 2023-01-10 09:37:45 --> Loader Class Initialized
INFO - 2023-01-10 09:37:45 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:45 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:45 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:45 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:45 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:45 --> Total execution time: 0.0434
INFO - 2023-01-10 09:37:45 --> Config Class Initialized
INFO - 2023-01-10 09:37:45 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:45 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:45 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:45 --> URI Class Initialized
INFO - 2023-01-10 09:37:45 --> Router Class Initialized
INFO - 2023-01-10 09:37:45 --> Output Class Initialized
INFO - 2023-01-10 09:37:45 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:45 --> Input Class Initialized
INFO - 2023-01-10 09:37:45 --> Language Class Initialized
INFO - 2023-01-10 09:37:45 --> Loader Class Initialized
INFO - 2023-01-10 09:37:45 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:45 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:45 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:45 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:45 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:45 --> Total execution time: 0.0273
INFO - 2023-01-10 09:37:48 --> Config Class Initialized
INFO - 2023-01-10 09:37:48 --> Hooks Class Initialized
INFO - 2023-01-10 09:37:48 --> Config Class Initialized
INFO - 2023-01-10 09:37:48 --> Config Class Initialized
INFO - 2023-01-10 09:37:48 --> Hooks Class Initialized
INFO - 2023-01-10 09:37:48 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-10 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:48 --> Utf8 Class Initialized
DEBUG - 2023-01-10 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:48 --> URI Class Initialized
INFO - 2023-01-10 09:37:48 --> URI Class Initialized
INFO - 2023-01-10 09:37:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:48 --> Router Class Initialized
INFO - 2023-01-10 09:37:48 --> Router Class Initialized
INFO - 2023-01-10 09:37:48 --> URI Class Initialized
INFO - 2023-01-10 09:37:48 --> Output Class Initialized
INFO - 2023-01-10 09:37:48 --> Output Class Initialized
INFO - 2023-01-10 09:37:48 --> Security Class Initialized
INFO - 2023-01-10 09:37:48 --> Router Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:48 --> Security Class Initialized
INFO - 2023-01-10 09:37:48 --> Output Class Initialized
INFO - 2023-01-10 09:37:48 --> Input Class Initialized
INFO - 2023-01-10 09:37:48 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:48 --> Language Class Initialized
INFO - 2023-01-10 09:37:48 --> Input Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:48 --> Input Class Initialized
INFO - 2023-01-10 09:37:48 --> Language Class Initialized
INFO - 2023-01-10 09:37:48 --> Loader Class Initialized
INFO - 2023-01-10 09:37:48 --> Language Class Initialized
INFO - 2023-01-10 09:37:48 --> Loader Class Initialized
INFO - 2023-01-10 09:37:48 --> Controller Class Initialized
INFO - 2023-01-10 09:37:48 --> Controller Class Initialized
INFO - 2023-01-10 09:37:48 --> Loader Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-10 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:48 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:48 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:48 --> Final output sent to browser
INFO - 2023-01-10 09:37:48 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:48 --> Total execution time: 0.0272
DEBUG - 2023-01-10 09:37:48 --> Total execution time: 0.0274
INFO - 2023-01-10 09:37:48 --> Config Class Initialized
INFO - 2023-01-10 09:37:48 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:48 --> URI Class Initialized
INFO - 2023-01-10 09:37:48 --> Config Class Initialized
INFO - 2023-01-10 09:37:48 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:48 --> Total execution time: 0.0411
INFO - 2023-01-10 09:37:48 --> Hooks Class Initialized
INFO - 2023-01-10 09:37:48 --> Router Class Initialized
DEBUG - 2023-01-10 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:48 --> Output Class Initialized
INFO - 2023-01-10 09:37:48 --> Security Class Initialized
INFO - 2023-01-10 09:37:48 --> URI Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:48 --> Config Class Initialized
INFO - 2023-01-10 09:37:48 --> Input Class Initialized
INFO - 2023-01-10 09:37:48 --> Router Class Initialized
INFO - 2023-01-10 09:37:48 --> Hooks Class Initialized
INFO - 2023-01-10 09:37:48 --> Language Class Initialized
INFO - 2023-01-10 09:37:48 --> Output Class Initialized
INFO - 2023-01-10 09:37:48 --> Loader Class Initialized
DEBUG - 2023-01-10 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:48 --> Controller Class Initialized
INFO - 2023-01-10 09:37:48 --> URI Class Initialized
INFO - 2023-01-10 09:37:48 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:48 --> Router Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:48 --> Output Class Initialized
INFO - 2023-01-10 09:37:48 --> Final output sent to browser
INFO - 2023-01-10 09:37:48 --> Input Class Initialized
INFO - 2023-01-10 09:37:48 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Total execution time: 0.0872
DEBUG - 2023-01-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:48 --> Language Class Initialized
INFO - 2023-01-10 09:37:48 --> Input Class Initialized
INFO - 2023-01-10 09:37:48 --> Loader Class Initialized
INFO - 2023-01-10 09:37:48 --> Language Class Initialized
INFO - 2023-01-10 09:37:48 --> Controller Class Initialized
INFO - 2023-01-10 09:37:48 --> Loader Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:48 --> Controller Class Initialized
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:48 --> Config Class Initialized
INFO - 2023-01-10 09:37:48 --> Hooks Class Initialized
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
DEBUG - 2023-01-10 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:48 --> URI Class Initialized
INFO - 2023-01-10 09:37:48 --> Router Class Initialized
INFO - 2023-01-10 09:37:48 --> Output Class Initialized
INFO - 2023-01-10 09:37:48 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:48 --> Input Class Initialized
INFO - 2023-01-10 09:37:48 --> Language Class Initialized
INFO - 2023-01-10 09:37:48 --> Loader Class Initialized
INFO - 2023-01-10 09:37:48 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:48 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:48 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:48 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:48 --> Final output sent to browser
INFO - 2023-01-10 09:37:48 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:48 --> Total execution time: 0.0769
DEBUG - 2023-01-10 09:37:48 --> Total execution time: 0.1171
INFO - 2023-01-10 09:37:48 --> Config Class Initialized
INFO - 2023-01-10 09:37:48 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:48 --> Total execution time: 0.0373
INFO - 2023-01-10 09:37:48 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:48 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:48 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:48 --> URI Class Initialized
INFO - 2023-01-10 09:37:48 --> Router Class Initialized
INFO - 2023-01-10 09:37:48 --> Output Class Initialized
INFO - 2023-01-10 09:37:48 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:48 --> Input Class Initialized
INFO - 2023-01-10 09:37:48 --> Language Class Initialized
INFO - 2023-01-10 09:37:48 --> Loader Class Initialized
INFO - 2023-01-10 09:37:48 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:48 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:48 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:48 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:48 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:37:48 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:48 --> Total execution time: 0.1205
INFO - 2023-01-10 09:37:49 --> Config Class Initialized
INFO - 2023-01-10 09:37:49 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:49 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:49 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:49 --> URI Class Initialized
INFO - 2023-01-10 09:37:49 --> Router Class Initialized
INFO - 2023-01-10 09:37:49 --> Output Class Initialized
INFO - 2023-01-10 09:37:49 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:49 --> Input Class Initialized
INFO - 2023-01-10 09:37:49 --> Language Class Initialized
INFO - 2023-01-10 09:37:49 --> Loader Class Initialized
INFO - 2023-01-10 09:37:49 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:49 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:49 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:49 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:49 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:49 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:49 --> Total execution time: 0.0316
INFO - 2023-01-10 09:37:51 --> Config Class Initialized
INFO - 2023-01-10 09:37:51 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:51 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:51 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:51 --> URI Class Initialized
INFO - 2023-01-10 09:37:51 --> Router Class Initialized
INFO - 2023-01-10 09:37:51 --> Output Class Initialized
INFO - 2023-01-10 09:37:51 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:51 --> Input Class Initialized
INFO - 2023-01-10 09:37:51 --> Language Class Initialized
INFO - 2023-01-10 09:37:51 --> Loader Class Initialized
INFO - 2023-01-10 09:37:51 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:51 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:51 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:51 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:51 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:51 --> Total execution time: 0.0375
INFO - 2023-01-10 09:37:51 --> Config Class Initialized
INFO - 2023-01-10 09:37:51 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:51 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:51 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:51 --> URI Class Initialized
INFO - 2023-01-10 09:37:51 --> Router Class Initialized
INFO - 2023-01-10 09:37:51 --> Output Class Initialized
INFO - 2023-01-10 09:37:51 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:51 --> Input Class Initialized
INFO - 2023-01-10 09:37:51 --> Language Class Initialized
INFO - 2023-01-10 09:37:51 --> Loader Class Initialized
INFO - 2023-01-10 09:37:51 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:51 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:51 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:51 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:51 --> Model "Login_model" initialized
INFO - 2023-01-10 09:37:51 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:51 --> Total execution time: 0.0279
INFO - 2023-01-10 09:37:56 --> Config Class Initialized
INFO - 2023-01-10 09:37:56 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:56 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:56 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:56 --> URI Class Initialized
INFO - 2023-01-10 09:37:56 --> Router Class Initialized
INFO - 2023-01-10 09:37:56 --> Output Class Initialized
INFO - 2023-01-10 09:37:56 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:56 --> Input Class Initialized
INFO - 2023-01-10 09:37:56 --> Language Class Initialized
INFO - 2023-01-10 09:37:56 --> Loader Class Initialized
INFO - 2023-01-10 09:37:56 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:56 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:56 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:37:56 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:56 --> Total execution time: 0.0267
INFO - 2023-01-10 09:37:56 --> Config Class Initialized
INFO - 2023-01-10 09:37:56 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:56 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:56 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:56 --> URI Class Initialized
INFO - 2023-01-10 09:37:56 --> Router Class Initialized
INFO - 2023-01-10 09:37:56 --> Output Class Initialized
INFO - 2023-01-10 09:37:56 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:56 --> Input Class Initialized
INFO - 2023-01-10 09:37:56 --> Language Class Initialized
INFO - 2023-01-10 09:37:56 --> Loader Class Initialized
INFO - 2023-01-10 09:37:56 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:56 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:56 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:37:56 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:56 --> Total execution time: 0.0182
INFO - 2023-01-10 09:37:59 --> Config Class Initialized
INFO - 2023-01-10 09:37:59 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:59 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:59 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:59 --> URI Class Initialized
INFO - 2023-01-10 09:37:59 --> Router Class Initialized
INFO - 2023-01-10 09:37:59 --> Output Class Initialized
INFO - 2023-01-10 09:37:59 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:59 --> Input Class Initialized
INFO - 2023-01-10 09:37:59 --> Language Class Initialized
INFO - 2023-01-10 09:37:59 --> Loader Class Initialized
INFO - 2023-01-10 09:37:59 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:59 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:59 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:37:59 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:59 --> Total execution time: 0.0296
INFO - 2023-01-10 09:37:59 --> Config Class Initialized
INFO - 2023-01-10 09:37:59 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:37:59 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:37:59 --> Utf8 Class Initialized
INFO - 2023-01-10 09:37:59 --> URI Class Initialized
INFO - 2023-01-10 09:37:59 --> Router Class Initialized
INFO - 2023-01-10 09:37:59 --> Output Class Initialized
INFO - 2023-01-10 09:37:59 --> Security Class Initialized
DEBUG - 2023-01-10 09:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:37:59 --> Input Class Initialized
INFO - 2023-01-10 09:37:59 --> Language Class Initialized
INFO - 2023-01-10 09:37:59 --> Loader Class Initialized
INFO - 2023-01-10 09:37:59 --> Controller Class Initialized
DEBUG - 2023-01-10 09:37:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:37:59 --> Database Driver Class Initialized
INFO - 2023-01-10 09:37:59 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:37:59 --> Final output sent to browser
DEBUG - 2023-01-10 09:37:59 --> Total execution time: 0.0216
INFO - 2023-01-10 09:38:36 --> Config Class Initialized
INFO - 2023-01-10 09:38:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:38:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:38:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:38:36 --> URI Class Initialized
INFO - 2023-01-10 09:38:36 --> Router Class Initialized
INFO - 2023-01-10 09:38:36 --> Output Class Initialized
INFO - 2023-01-10 09:38:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:38:36 --> Input Class Initialized
INFO - 2023-01-10 09:38:36 --> Language Class Initialized
INFO - 2023-01-10 09:38:36 --> Loader Class Initialized
INFO - 2023-01-10 09:38:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:38:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:38:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:38:36 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:38:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:38:36 --> Model "Login_model" initialized
INFO - 2023-01-10 09:38:36 --> Final output sent to browser
DEBUG - 2023-01-10 09:38:36 --> Total execution time: 0.0837
INFO - 2023-01-10 09:38:36 --> Config Class Initialized
INFO - 2023-01-10 09:38:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:38:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:38:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:38:36 --> URI Class Initialized
INFO - 2023-01-10 09:38:36 --> Router Class Initialized
INFO - 2023-01-10 09:38:36 --> Output Class Initialized
INFO - 2023-01-10 09:38:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:38:36 --> Input Class Initialized
INFO - 2023-01-10 09:38:36 --> Language Class Initialized
INFO - 2023-01-10 09:38:36 --> Loader Class Initialized
INFO - 2023-01-10 09:38:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:38:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:38:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:38:36 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:38:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:38:36 --> Model "Login_model" initialized
INFO - 2023-01-10 09:38:36 --> Final output sent to browser
DEBUG - 2023-01-10 09:38:36 --> Total execution time: 0.0716
INFO - 2023-01-10 09:39:23 --> Config Class Initialized
INFO - 2023-01-10 09:39:23 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:23 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:23 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:23 --> URI Class Initialized
INFO - 2023-01-10 09:39:23 --> Router Class Initialized
INFO - 2023-01-10 09:39:23 --> Output Class Initialized
INFO - 2023-01-10 09:39:23 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:23 --> Input Class Initialized
INFO - 2023-01-10 09:39:23 --> Language Class Initialized
INFO - 2023-01-10 09:39:23 --> Loader Class Initialized
INFO - 2023-01-10 09:39:23 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:23 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:23 --> Total execution time: 0.0094
INFO - 2023-01-10 09:39:23 --> Config Class Initialized
INFO - 2023-01-10 09:39:23 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:23 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:23 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:23 --> URI Class Initialized
INFO - 2023-01-10 09:39:23 --> Router Class Initialized
INFO - 2023-01-10 09:39:23 --> Output Class Initialized
INFO - 2023-01-10 09:39:23 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:23 --> Input Class Initialized
INFO - 2023-01-10 09:39:23 --> Language Class Initialized
INFO - 2023-01-10 09:39:23 --> Loader Class Initialized
INFO - 2023-01-10 09:39:23 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:23 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:23 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:23 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:39:23 --> Model "Node_model" initialized
INFO - 2023-01-10 09:39:23 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:39:23 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:23 --> Total execution time: 0.0224
INFO - 2023-01-10 09:39:45 --> Config Class Initialized
INFO - 2023-01-10 09:39:45 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:45 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:45 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:45 --> URI Class Initialized
INFO - 2023-01-10 09:39:45 --> Router Class Initialized
INFO - 2023-01-10 09:39:45 --> Output Class Initialized
INFO - 2023-01-10 09:39:45 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:45 --> Input Class Initialized
INFO - 2023-01-10 09:39:45 --> Language Class Initialized
INFO - 2023-01-10 09:39:45 --> Loader Class Initialized
INFO - 2023-01-10 09:39:45 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:45 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:45 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:39:45 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:45 --> Model "Login_model" initialized
INFO - 2023-01-10 09:39:45 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:45 --> Total execution time: 0.1654
INFO - 2023-01-10 09:39:45 --> Config Class Initialized
INFO - 2023-01-10 09:39:45 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:45 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:45 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:45 --> URI Class Initialized
INFO - 2023-01-10 09:39:45 --> Router Class Initialized
INFO - 2023-01-10 09:39:45 --> Output Class Initialized
INFO - 2023-01-10 09:39:45 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:45 --> Input Class Initialized
INFO - 2023-01-10 09:39:45 --> Language Class Initialized
INFO - 2023-01-10 09:39:45 --> Loader Class Initialized
INFO - 2023-01-10 09:39:45 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:45 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:45 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:45 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:39:45 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:45 --> Model "Login_model" initialized
INFO - 2023-01-10 09:39:46 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:46 --> Total execution time: 0.3395
INFO - 2023-01-10 09:39:55 --> Config Class Initialized
INFO - 2023-01-10 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:55 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:55 --> URI Class Initialized
INFO - 2023-01-10 09:39:55 --> Router Class Initialized
INFO - 2023-01-10 09:39:55 --> Output Class Initialized
INFO - 2023-01-10 09:39:55 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:55 --> Input Class Initialized
INFO - 2023-01-10 09:39:55 --> Language Class Initialized
INFO - 2023-01-10 09:39:55 --> Loader Class Initialized
INFO - 2023-01-10 09:39:55 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:55 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:55 --> Total execution time: 0.0067
INFO - 2023-01-10 09:39:55 --> Config Class Initialized
INFO - 2023-01-10 09:39:55 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:55 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:55 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:55 --> URI Class Initialized
INFO - 2023-01-10 09:39:55 --> Router Class Initialized
INFO - 2023-01-10 09:39:55 --> Output Class Initialized
INFO - 2023-01-10 09:39:55 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:55 --> Input Class Initialized
INFO - 2023-01-10 09:39:55 --> Language Class Initialized
INFO - 2023-01-10 09:39:55 --> Loader Class Initialized
INFO - 2023-01-10 09:39:55 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:55 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:55 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:55 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:39:55 --> Model "Node_model" initialized
INFO - 2023-01-10 09:39:55 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:39:55 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:55 --> Total execution time: 0.0280
INFO - 2023-01-10 09:39:56 --> Config Class Initialized
INFO - 2023-01-10 09:39:56 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:56 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:56 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:56 --> URI Class Initialized
INFO - 2023-01-10 09:39:56 --> Router Class Initialized
INFO - 2023-01-10 09:39:56 --> Output Class Initialized
INFO - 2023-01-10 09:39:56 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:56 --> Input Class Initialized
INFO - 2023-01-10 09:39:56 --> Language Class Initialized
INFO - 2023-01-10 09:39:56 --> Loader Class Initialized
INFO - 2023-01-10 09:39:56 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:56 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:56 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:39:56 --> Model "Node_model" initialized
INFO - 2023-01-10 09:39:56 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:39:56 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:56 --> Total execution time: 0.0270
INFO - 2023-01-10 09:39:57 --> Config Class Initialized
INFO - 2023-01-10 09:39:57 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:57 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:57 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:57 --> URI Class Initialized
INFO - 2023-01-10 09:39:57 --> Router Class Initialized
INFO - 2023-01-10 09:39:57 --> Output Class Initialized
INFO - 2023-01-10 09:39:57 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:57 --> Input Class Initialized
INFO - 2023-01-10 09:39:57 --> Language Class Initialized
INFO - 2023-01-10 09:39:57 --> Loader Class Initialized
INFO - 2023-01-10 09:39:57 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:57 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:57 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:39:57 --> Model "Node_model" initialized
INFO - 2023-01-10 09:39:57 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:39:57 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:57 --> Total execution time: 0.0238
INFO - 2023-01-10 09:39:57 --> Config Class Initialized
INFO - 2023-01-10 09:39:57 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:39:57 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:39:57 --> Utf8 Class Initialized
INFO - 2023-01-10 09:39:57 --> URI Class Initialized
INFO - 2023-01-10 09:39:57 --> Router Class Initialized
INFO - 2023-01-10 09:39:57 --> Output Class Initialized
INFO - 2023-01-10 09:39:57 --> Security Class Initialized
DEBUG - 2023-01-10 09:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:39:57 --> Input Class Initialized
INFO - 2023-01-10 09:39:57 --> Language Class Initialized
INFO - 2023-01-10 09:39:57 --> Loader Class Initialized
INFO - 2023-01-10 09:39:57 --> Controller Class Initialized
DEBUG - 2023-01-10 09:39:57 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:39:57 --> Database Driver Class Initialized
INFO - 2023-01-10 09:39:57 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:39:57 --> Model "Node_model" initialized
INFO - 2023-01-10 09:39:57 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:39:57 --> Final output sent to browser
DEBUG - 2023-01-10 09:39:57 --> Total execution time: 0.0260
INFO - 2023-01-10 09:40:00 --> Config Class Initialized
INFO - 2023-01-10 09:40:00 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:40:00 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:40:00 --> Utf8 Class Initialized
INFO - 2023-01-10 09:40:00 --> URI Class Initialized
INFO - 2023-01-10 09:40:00 --> Router Class Initialized
INFO - 2023-01-10 09:40:00 --> Output Class Initialized
INFO - 2023-01-10 09:40:00 --> Security Class Initialized
DEBUG - 2023-01-10 09:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:40:00 --> Input Class Initialized
INFO - 2023-01-10 09:40:00 --> Language Class Initialized
INFO - 2023-01-10 09:40:00 --> Loader Class Initialized
INFO - 2023-01-10 09:40:00 --> Controller Class Initialized
DEBUG - 2023-01-10 09:40:00 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:40:00 --> Database Driver Class Initialized
INFO - 2023-01-10 09:40:00 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:40:00 --> Model "Node_model" initialized
INFO - 2023-01-10 09:40:00 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:40:00 --> Final output sent to browser
DEBUG - 2023-01-10 09:40:00 --> Total execution time: 0.0226
INFO - 2023-01-10 09:41:36 --> Config Class Initialized
INFO - 2023-01-10 09:41:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:41:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:41:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:41:36 --> URI Class Initialized
INFO - 2023-01-10 09:41:36 --> Router Class Initialized
INFO - 2023-01-10 09:41:36 --> Output Class Initialized
INFO - 2023-01-10 09:41:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:41:36 --> Input Class Initialized
INFO - 2023-01-10 09:41:36 --> Language Class Initialized
INFO - 2023-01-10 09:41:36 --> Loader Class Initialized
INFO - 2023-01-10 09:41:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:41:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:41:36 --> Final output sent to browser
DEBUG - 2023-01-10 09:41:36 --> Total execution time: 0.0044
INFO - 2023-01-10 09:41:36 --> Config Class Initialized
INFO - 2023-01-10 09:41:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:41:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:41:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:41:36 --> URI Class Initialized
INFO - 2023-01-10 09:41:36 --> Router Class Initialized
INFO - 2023-01-10 09:41:36 --> Output Class Initialized
INFO - 2023-01-10 09:41:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:41:36 --> Input Class Initialized
INFO - 2023-01-10 09:41:36 --> Language Class Initialized
INFO - 2023-01-10 09:41:36 --> Loader Class Initialized
INFO - 2023-01-10 09:41:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:41:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:41:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:41:36 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:41:36 --> Model "Node_model" initialized
INFO - 2023-01-10 09:41:36 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:41:36 --> Final output sent to browser
DEBUG - 2023-01-10 09:41:36 --> Total execution time: 0.0225
INFO - 2023-01-10 09:41:44 --> Config Class Initialized
INFO - 2023-01-10 09:41:44 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:41:44 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:41:44 --> Utf8 Class Initialized
INFO - 2023-01-10 09:41:44 --> URI Class Initialized
INFO - 2023-01-10 09:41:44 --> Router Class Initialized
INFO - 2023-01-10 09:41:44 --> Output Class Initialized
INFO - 2023-01-10 09:41:44 --> Security Class Initialized
DEBUG - 2023-01-10 09:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:41:44 --> Input Class Initialized
INFO - 2023-01-10 09:41:44 --> Language Class Initialized
INFO - 2023-01-10 09:41:44 --> Loader Class Initialized
INFO - 2023-01-10 09:41:44 --> Controller Class Initialized
DEBUG - 2023-01-10 09:41:44 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:41:44 --> Final output sent to browser
DEBUG - 2023-01-10 09:41:44 --> Total execution time: 0.0069
INFO - 2023-01-10 09:41:52 --> Config Class Initialized
INFO - 2023-01-10 09:41:52 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:41:52 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:41:52 --> Utf8 Class Initialized
INFO - 2023-01-10 09:41:52 --> URI Class Initialized
INFO - 2023-01-10 09:41:52 --> Router Class Initialized
INFO - 2023-01-10 09:41:52 --> Output Class Initialized
INFO - 2023-01-10 09:41:52 --> Security Class Initialized
DEBUG - 2023-01-10 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:41:52 --> Input Class Initialized
INFO - 2023-01-10 09:41:52 --> Language Class Initialized
INFO - 2023-01-10 09:41:52 --> Loader Class Initialized
INFO - 2023-01-10 09:41:52 --> Controller Class Initialized
DEBUG - 2023-01-10 09:41:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:41:52 --> Final output sent to browser
DEBUG - 2023-01-10 09:41:52 --> Total execution time: 0.0048
INFO - 2023-01-10 09:41:52 --> Config Class Initialized
INFO - 2023-01-10 09:41:52 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:41:52 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:41:52 --> Utf8 Class Initialized
INFO - 2023-01-10 09:41:52 --> URI Class Initialized
INFO - 2023-01-10 09:41:52 --> Router Class Initialized
INFO - 2023-01-10 09:41:52 --> Output Class Initialized
INFO - 2023-01-10 09:41:52 --> Security Class Initialized
DEBUG - 2023-01-10 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:41:52 --> Input Class Initialized
INFO - 2023-01-10 09:41:52 --> Language Class Initialized
INFO - 2023-01-10 09:41:52 --> Loader Class Initialized
INFO - 2023-01-10 09:41:52 --> Controller Class Initialized
DEBUG - 2023-01-10 09:41:52 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:41:52 --> Database Driver Class Initialized
INFO - 2023-01-10 09:41:52 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:41:52 --> Model "Node_model" initialized
INFO - 2023-01-10 09:41:52 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:41:52 --> Final output sent to browser
DEBUG - 2023-01-10 09:41:52 --> Total execution time: 0.0180
INFO - 2023-01-10 09:46:22 --> Config Class Initialized
INFO - 2023-01-10 09:46:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:46:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:46:22 --> Utf8 Class Initialized
INFO - 2023-01-10 09:46:22 --> URI Class Initialized
INFO - 2023-01-10 09:46:22 --> Router Class Initialized
INFO - 2023-01-10 09:46:22 --> Output Class Initialized
INFO - 2023-01-10 09:46:22 --> Security Class Initialized
DEBUG - 2023-01-10 09:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:46:22 --> Input Class Initialized
INFO - 2023-01-10 09:46:22 --> Language Class Initialized
INFO - 2023-01-10 09:46:22 --> Loader Class Initialized
INFO - 2023-01-10 09:46:22 --> Controller Class Initialized
DEBUG - 2023-01-10 09:46:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:46:22 --> Final output sent to browser
DEBUG - 2023-01-10 09:46:22 --> Total execution time: 0.0098
INFO - 2023-01-10 09:46:22 --> Config Class Initialized
INFO - 2023-01-10 09:46:22 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:46:22 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:46:22 --> Utf8 Class Initialized
INFO - 2023-01-10 09:46:22 --> URI Class Initialized
INFO - 2023-01-10 09:46:22 --> Router Class Initialized
INFO - 2023-01-10 09:46:22 --> Output Class Initialized
INFO - 2023-01-10 09:46:22 --> Security Class Initialized
DEBUG - 2023-01-10 09:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:46:22 --> Input Class Initialized
INFO - 2023-01-10 09:46:22 --> Language Class Initialized
INFO - 2023-01-10 09:46:22 --> Loader Class Initialized
INFO - 2023-01-10 09:46:22 --> Controller Class Initialized
DEBUG - 2023-01-10 09:46:22 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:46:22 --> Database Driver Class Initialized
INFO - 2023-01-10 09:46:22 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:46:22 --> Model "Node_model" initialized
INFO - 2023-01-10 09:49:36 --> Config Class Initialized
INFO - 2023-01-10 09:49:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:49:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:49:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:49:36 --> URI Class Initialized
INFO - 2023-01-10 09:49:36 --> Router Class Initialized
INFO - 2023-01-10 09:49:36 --> Output Class Initialized
INFO - 2023-01-10 09:49:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:49:36 --> Input Class Initialized
INFO - 2023-01-10 09:49:36 --> Language Class Initialized
INFO - 2023-01-10 09:49:36 --> Loader Class Initialized
INFO - 2023-01-10 09:49:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:49:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:49:36 --> Final output sent to browser
DEBUG - 2023-01-10 09:49:36 --> Total execution time: 0.0150
INFO - 2023-01-10 09:49:36 --> Config Class Initialized
INFO - 2023-01-10 09:49:36 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:49:36 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:49:36 --> Utf8 Class Initialized
INFO - 2023-01-10 09:49:36 --> URI Class Initialized
INFO - 2023-01-10 09:49:36 --> Router Class Initialized
INFO - 2023-01-10 09:49:36 --> Output Class Initialized
INFO - 2023-01-10 09:49:36 --> Security Class Initialized
DEBUG - 2023-01-10 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:49:36 --> Input Class Initialized
INFO - 2023-01-10 09:49:36 --> Language Class Initialized
INFO - 2023-01-10 09:49:36 --> Loader Class Initialized
INFO - 2023-01-10 09:49:36 --> Controller Class Initialized
DEBUG - 2023-01-10 09:49:36 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:49:36 --> Database Driver Class Initialized
INFO - 2023-01-10 09:49:36 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:49:36 --> Model "Node_model" initialized
INFO - 2023-01-10 09:49:36 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:49:36 --> Final output sent to browser
DEBUG - 2023-01-10 09:49:36 --> Total execution time: 0.0300
INFO - 2023-01-10 09:50:09 --> Config Class Initialized
INFO - 2023-01-10 09:50:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:50:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:50:09 --> Utf8 Class Initialized
INFO - 2023-01-10 09:50:09 --> URI Class Initialized
INFO - 2023-01-10 09:50:09 --> Router Class Initialized
INFO - 2023-01-10 09:50:09 --> Output Class Initialized
INFO - 2023-01-10 09:50:09 --> Security Class Initialized
DEBUG - 2023-01-10 09:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:50:09 --> Input Class Initialized
INFO - 2023-01-10 09:50:09 --> Language Class Initialized
INFO - 2023-01-10 09:50:09 --> Loader Class Initialized
INFO - 2023-01-10 09:50:09 --> Controller Class Initialized
DEBUG - 2023-01-10 09:50:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:50:09 --> Final output sent to browser
DEBUG - 2023-01-10 09:50:09 --> Total execution time: 0.0109
INFO - 2023-01-10 09:50:09 --> Config Class Initialized
INFO - 2023-01-10 09:50:09 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:50:09 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:50:09 --> Utf8 Class Initialized
INFO - 2023-01-10 09:50:09 --> URI Class Initialized
INFO - 2023-01-10 09:50:09 --> Router Class Initialized
INFO - 2023-01-10 09:50:09 --> Output Class Initialized
INFO - 2023-01-10 09:50:09 --> Security Class Initialized
DEBUG - 2023-01-10 09:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:50:09 --> Input Class Initialized
INFO - 2023-01-10 09:50:09 --> Language Class Initialized
INFO - 2023-01-10 09:50:09 --> Loader Class Initialized
INFO - 2023-01-10 09:50:09 --> Controller Class Initialized
DEBUG - 2023-01-10 09:50:09 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:50:09 --> Database Driver Class Initialized
INFO - 2023-01-10 09:50:09 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:50:09 --> Model "Node_model" initialized
INFO - 2023-01-10 09:50:10 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:50:10 --> Final output sent to browser
DEBUG - 2023-01-10 09:50:10 --> Total execution time: 0.0311
INFO - 2023-01-10 09:51:31 --> Config Class Initialized
INFO - 2023-01-10 09:51:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:51:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:51:31 --> Utf8 Class Initialized
INFO - 2023-01-10 09:51:31 --> URI Class Initialized
INFO - 2023-01-10 09:51:31 --> Router Class Initialized
INFO - 2023-01-10 09:51:31 --> Output Class Initialized
INFO - 2023-01-10 09:51:31 --> Security Class Initialized
DEBUG - 2023-01-10 09:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:51:31 --> Input Class Initialized
INFO - 2023-01-10 09:51:31 --> Language Class Initialized
INFO - 2023-01-10 09:51:31 --> Loader Class Initialized
INFO - 2023-01-10 09:51:31 --> Controller Class Initialized
DEBUG - 2023-01-10 09:51:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:51:31 --> Final output sent to browser
DEBUG - 2023-01-10 09:51:31 --> Total execution time: 0.0137
INFO - 2023-01-10 09:51:31 --> Config Class Initialized
INFO - 2023-01-10 09:51:31 --> Hooks Class Initialized
DEBUG - 2023-01-10 09:51:31 --> UTF-8 Support Enabled
INFO - 2023-01-10 09:51:31 --> Utf8 Class Initialized
INFO - 2023-01-10 09:51:31 --> URI Class Initialized
INFO - 2023-01-10 09:51:31 --> Router Class Initialized
INFO - 2023-01-10 09:51:31 --> Output Class Initialized
INFO - 2023-01-10 09:51:31 --> Security Class Initialized
DEBUG - 2023-01-10 09:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 09:51:31 --> Input Class Initialized
INFO - 2023-01-10 09:51:31 --> Language Class Initialized
INFO - 2023-01-10 09:51:31 --> Loader Class Initialized
INFO - 2023-01-10 09:51:31 --> Controller Class Initialized
DEBUG - 2023-01-10 09:51:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 09:51:31 --> Database Driver Class Initialized
INFO - 2023-01-10 09:51:31 --> Model "Cluster_model" initialized
INFO - 2023-01-10 09:51:31 --> Model "Node_model" initialized
INFO - 2023-01-10 09:51:31 --> Model "Grafana_model" initialized
INFO - 2023-01-10 09:51:31 --> Final output sent to browser
DEBUG - 2023-01-10 09:51:31 --> Total execution time: 0.0642
INFO - 2023-01-10 10:00:29 --> Config Class Initialized
INFO - 2023-01-10 10:00:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:00:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:00:29 --> Utf8 Class Initialized
INFO - 2023-01-10 10:00:29 --> URI Class Initialized
INFO - 2023-01-10 10:00:29 --> Router Class Initialized
INFO - 2023-01-10 10:00:29 --> Output Class Initialized
INFO - 2023-01-10 10:00:29 --> Security Class Initialized
DEBUG - 2023-01-10 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:00:29 --> Input Class Initialized
INFO - 2023-01-10 10:00:29 --> Language Class Initialized
INFO - 2023-01-10 10:00:29 --> Loader Class Initialized
INFO - 2023-01-10 10:00:29 --> Controller Class Initialized
DEBUG - 2023-01-10 10:00:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:00:29 --> Database Driver Class Initialized
INFO - 2023-01-10 10:00:29 --> Database Driver Class Initialized
INFO - 2023-01-10 10:00:29 --> Model "Login_model" initialized
INFO - 2023-01-10 10:00:29 --> Final output sent to browser
DEBUG - 2023-01-10 10:00:29 --> Total execution time: 0.2324
INFO - 2023-01-10 10:00:29 --> Config Class Initialized
INFO - 2023-01-10 10:00:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:00:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:00:29 --> Utf8 Class Initialized
INFO - 2023-01-10 10:00:29 --> URI Class Initialized
INFO - 2023-01-10 10:00:29 --> Router Class Initialized
INFO - 2023-01-10 10:00:29 --> Output Class Initialized
INFO - 2023-01-10 10:00:29 --> Security Class Initialized
DEBUG - 2023-01-10 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:00:29 --> Input Class Initialized
INFO - 2023-01-10 10:00:29 --> Language Class Initialized
INFO - 2023-01-10 10:00:29 --> Loader Class Initialized
INFO - 2023-01-10 10:00:29 --> Controller Class Initialized
DEBUG - 2023-01-10 10:00:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:00:29 --> Database Driver Class Initialized
INFO - 2023-01-10 10:00:29 --> Database Driver Class Initialized
INFO - 2023-01-10 10:00:30 --> Model "Login_model" initialized
INFO - 2023-01-10 10:00:30 --> Final output sent to browser
DEBUG - 2023-01-10 10:00:30 --> Total execution time: 0.2713
INFO - 2023-01-10 10:00:33 --> Config Class Initialized
INFO - 2023-01-10 10:00:33 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:00:33 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:00:33 --> Utf8 Class Initialized
INFO - 2023-01-10 10:00:33 --> URI Class Initialized
INFO - 2023-01-10 10:00:33 --> Router Class Initialized
INFO - 2023-01-10 10:00:33 --> Output Class Initialized
INFO - 2023-01-10 10:00:33 --> Security Class Initialized
DEBUG - 2023-01-10 10:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:00:33 --> Input Class Initialized
INFO - 2023-01-10 10:00:33 --> Language Class Initialized
INFO - 2023-01-10 10:00:33 --> Loader Class Initialized
INFO - 2023-01-10 10:00:33 --> Controller Class Initialized
DEBUG - 2023-01-10 10:00:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:00:33 --> Database Driver Class Initialized
INFO - 2023-01-10 10:00:33 --> Database Driver Class Initialized
INFO - 2023-01-10 10:00:33 --> Model "Login_model" initialized
ERROR - 2023-01-10 10:00:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%t%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%t%'
INFO - 2023-01-10 10:00:33 --> Final output sent to browser
DEBUG - 2023-01-10 10:00:33 --> Total execution time: 0.2306
INFO - 2023-01-10 10:00:33 --> Config Class Initialized
INFO - 2023-01-10 10:00:33 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:00:33 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:00:33 --> Utf8 Class Initialized
INFO - 2023-01-10 10:00:33 --> URI Class Initialized
INFO - 2023-01-10 10:00:33 --> Router Class Initialized
INFO - 2023-01-10 10:00:33 --> Output Class Initialized
INFO - 2023-01-10 10:00:33 --> Security Class Initialized
DEBUG - 2023-01-10 10:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:00:33 --> Input Class Initialized
INFO - 2023-01-10 10:00:33 --> Language Class Initialized
INFO - 2023-01-10 10:00:33 --> Loader Class Initialized
INFO - 2023-01-10 10:00:33 --> Controller Class Initialized
DEBUG - 2023-01-10 10:00:33 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:00:33 --> Database Driver Class Initialized
INFO - 2023-01-10 10:00:33 --> Database Driver Class Initialized
INFO - 2023-01-10 10:00:34 --> Model "Login_model" initialized
ERROR - 2023-01-10 10:00:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and  name like '%t%'' at line 1 - Invalid query: select count(id) as count from kunlun_user  and  name like '%t%'
INFO - 2023-01-10 10:00:34 --> Final output sent to browser
DEBUG - 2023-01-10 10:00:34 --> Total execution time: 0.2233
INFO - 2023-01-10 10:02:30 --> Config Class Initialized
INFO - 2023-01-10 10:02:30 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:02:30 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:02:30 --> Utf8 Class Initialized
INFO - 2023-01-10 10:02:30 --> URI Class Initialized
INFO - 2023-01-10 10:02:30 --> Router Class Initialized
INFO - 2023-01-10 10:02:30 --> Output Class Initialized
INFO - 2023-01-10 10:02:30 --> Security Class Initialized
DEBUG - 2023-01-10 10:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:02:30 --> Input Class Initialized
INFO - 2023-01-10 10:02:30 --> Language Class Initialized
INFO - 2023-01-10 10:02:30 --> Loader Class Initialized
INFO - 2023-01-10 10:02:30 --> Controller Class Initialized
DEBUG - 2023-01-10 10:02:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:02:30 --> Final output sent to browser
DEBUG - 2023-01-10 10:02:30 --> Total execution time: 0.0043
INFO - 2023-01-10 10:02:30 --> Config Class Initialized
INFO - 2023-01-10 10:02:30 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:02:30 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:02:30 --> Utf8 Class Initialized
INFO - 2023-01-10 10:02:30 --> URI Class Initialized
INFO - 2023-01-10 10:02:30 --> Router Class Initialized
INFO - 2023-01-10 10:02:30 --> Output Class Initialized
INFO - 2023-01-10 10:02:30 --> Security Class Initialized
DEBUG - 2023-01-10 10:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:02:30 --> Input Class Initialized
INFO - 2023-01-10 10:02:30 --> Language Class Initialized
INFO - 2023-01-10 10:02:30 --> Loader Class Initialized
INFO - 2023-01-10 10:02:30 --> Controller Class Initialized
DEBUG - 2023-01-10 10:02:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:02:30 --> Database Driver Class Initialized
INFO - 2023-01-10 10:02:30 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:02:30 --> Model "Node_model" initialized
INFO - 2023-01-10 10:02:30 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:02:30 --> Final output sent to browser
DEBUG - 2023-01-10 10:02:30 --> Total execution time: 0.1676
INFO - 2023-01-10 10:03:29 --> Config Class Initialized
INFO - 2023-01-10 10:03:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:03:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:03:29 --> Utf8 Class Initialized
INFO - 2023-01-10 10:03:29 --> URI Class Initialized
INFO - 2023-01-10 10:03:29 --> Router Class Initialized
INFO - 2023-01-10 10:03:29 --> Output Class Initialized
INFO - 2023-01-10 10:03:29 --> Security Class Initialized
DEBUG - 2023-01-10 10:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:03:29 --> Input Class Initialized
INFO - 2023-01-10 10:03:29 --> Language Class Initialized
INFO - 2023-01-10 10:03:29 --> Loader Class Initialized
INFO - 2023-01-10 10:03:29 --> Controller Class Initialized
DEBUG - 2023-01-10 10:03:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:03:29 --> Final output sent to browser
DEBUG - 2023-01-10 10:03:29 --> Total execution time: 0.0050
INFO - 2023-01-10 10:03:29 --> Config Class Initialized
INFO - 2023-01-10 10:03:29 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:03:29 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:03:29 --> Utf8 Class Initialized
INFO - 2023-01-10 10:03:29 --> URI Class Initialized
INFO - 2023-01-10 10:03:29 --> Router Class Initialized
INFO - 2023-01-10 10:03:29 --> Output Class Initialized
INFO - 2023-01-10 10:03:29 --> Security Class Initialized
DEBUG - 2023-01-10 10:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:03:29 --> Input Class Initialized
INFO - 2023-01-10 10:03:29 --> Language Class Initialized
INFO - 2023-01-10 10:03:29 --> Loader Class Initialized
INFO - 2023-01-10 10:03:29 --> Controller Class Initialized
DEBUG - 2023-01-10 10:03:29 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:03:29 --> Database Driver Class Initialized
INFO - 2023-01-10 10:03:29 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:03:29 --> Model "Node_model" initialized
INFO - 2023-01-10 10:03:29 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:03:29 --> Final output sent to browser
DEBUG - 2023-01-10 10:03:29 --> Total execution time: 0.1751
INFO - 2023-01-10 10:04:39 --> Config Class Initialized
INFO - 2023-01-10 10:04:39 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:04:39 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:04:39 --> Utf8 Class Initialized
INFO - 2023-01-10 10:04:39 --> URI Class Initialized
INFO - 2023-01-10 10:04:39 --> Router Class Initialized
INFO - 2023-01-10 10:04:39 --> Output Class Initialized
INFO - 2023-01-10 10:04:39 --> Security Class Initialized
DEBUG - 2023-01-10 10:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:04:39 --> Input Class Initialized
INFO - 2023-01-10 10:04:39 --> Language Class Initialized
INFO - 2023-01-10 10:04:39 --> Loader Class Initialized
INFO - 2023-01-10 10:04:39 --> Controller Class Initialized
DEBUG - 2023-01-10 10:04:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:04:39 --> Final output sent to browser
DEBUG - 2023-01-10 10:04:39 --> Total execution time: 0.0040
INFO - 2023-01-10 10:04:39 --> Config Class Initialized
INFO - 2023-01-10 10:04:39 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:04:39 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:04:39 --> Utf8 Class Initialized
INFO - 2023-01-10 10:04:39 --> URI Class Initialized
INFO - 2023-01-10 10:04:39 --> Router Class Initialized
INFO - 2023-01-10 10:04:39 --> Output Class Initialized
INFO - 2023-01-10 10:04:39 --> Security Class Initialized
DEBUG - 2023-01-10 10:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:04:39 --> Input Class Initialized
INFO - 2023-01-10 10:04:39 --> Language Class Initialized
INFO - 2023-01-10 10:04:39 --> Loader Class Initialized
INFO - 2023-01-10 10:04:39 --> Controller Class Initialized
DEBUG - 2023-01-10 10:04:39 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:04:39 --> Database Driver Class Initialized
INFO - 2023-01-10 10:04:39 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:04:39 --> Model "Node_model" initialized
INFO - 2023-01-10 10:04:39 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:04:39 --> Final output sent to browser
DEBUG - 2023-01-10 10:04:39 --> Total execution time: 0.1834
INFO - 2023-01-10 10:05:11 --> Config Class Initialized
INFO - 2023-01-10 10:05:11 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:05:11 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:05:11 --> Utf8 Class Initialized
INFO - 2023-01-10 10:05:11 --> URI Class Initialized
INFO - 2023-01-10 10:05:11 --> Router Class Initialized
INFO - 2023-01-10 10:05:11 --> Output Class Initialized
INFO - 2023-01-10 10:05:11 --> Security Class Initialized
DEBUG - 2023-01-10 10:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:05:11 --> Input Class Initialized
INFO - 2023-01-10 10:05:11 --> Language Class Initialized
INFO - 2023-01-10 10:05:11 --> Loader Class Initialized
INFO - 2023-01-10 10:05:11 --> Controller Class Initialized
DEBUG - 2023-01-10 10:05:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:05:11 --> Final output sent to browser
DEBUG - 2023-01-10 10:05:11 --> Total execution time: 0.0054
INFO - 2023-01-10 10:05:11 --> Config Class Initialized
INFO - 2023-01-10 10:05:11 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:05:11 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:05:11 --> Utf8 Class Initialized
INFO - 2023-01-10 10:05:11 --> URI Class Initialized
INFO - 2023-01-10 10:05:11 --> Router Class Initialized
INFO - 2023-01-10 10:05:11 --> Output Class Initialized
INFO - 2023-01-10 10:05:11 --> Security Class Initialized
DEBUG - 2023-01-10 10:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:05:11 --> Input Class Initialized
INFO - 2023-01-10 10:05:11 --> Language Class Initialized
INFO - 2023-01-10 10:05:11 --> Loader Class Initialized
INFO - 2023-01-10 10:05:11 --> Controller Class Initialized
DEBUG - 2023-01-10 10:05:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:05:11 --> Database Driver Class Initialized
INFO - 2023-01-10 10:05:11 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:05:11 --> Model "Node_model" initialized
INFO - 2023-01-10 10:05:11 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:05:11 --> Final output sent to browser
DEBUG - 2023-01-10 10:05:11 --> Total execution time: 0.0263
INFO - 2023-01-10 10:05:37 --> Config Class Initialized
INFO - 2023-01-10 10:05:37 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:05:37 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:05:37 --> Utf8 Class Initialized
INFO - 2023-01-10 10:05:37 --> URI Class Initialized
INFO - 2023-01-10 10:05:37 --> Router Class Initialized
INFO - 2023-01-10 10:05:37 --> Output Class Initialized
INFO - 2023-01-10 10:05:37 --> Security Class Initialized
DEBUG - 2023-01-10 10:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:05:37 --> Input Class Initialized
INFO - 2023-01-10 10:05:37 --> Language Class Initialized
INFO - 2023-01-10 10:05:37 --> Loader Class Initialized
INFO - 2023-01-10 10:05:37 --> Controller Class Initialized
DEBUG - 2023-01-10 10:05:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:05:37 --> Final output sent to browser
DEBUG - 2023-01-10 10:05:37 --> Total execution time: 0.0060
INFO - 2023-01-10 10:05:37 --> Config Class Initialized
INFO - 2023-01-10 10:05:37 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:05:37 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:05:37 --> Utf8 Class Initialized
INFO - 2023-01-10 10:05:37 --> URI Class Initialized
INFO - 2023-01-10 10:05:37 --> Router Class Initialized
INFO - 2023-01-10 10:05:37 --> Output Class Initialized
INFO - 2023-01-10 10:05:37 --> Security Class Initialized
DEBUG - 2023-01-10 10:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:05:37 --> Input Class Initialized
INFO - 2023-01-10 10:05:37 --> Language Class Initialized
INFO - 2023-01-10 10:05:37 --> Loader Class Initialized
INFO - 2023-01-10 10:05:37 --> Controller Class Initialized
DEBUG - 2023-01-10 10:05:37 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:05:37 --> Database Driver Class Initialized
INFO - 2023-01-10 10:05:37 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:05:37 --> Model "Node_model" initialized
INFO - 2023-01-10 10:05:37 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:05:37 --> Final output sent to browser
DEBUG - 2023-01-10 10:05:37 --> Total execution time: 0.0297
INFO - 2023-01-10 10:07:03 --> Config Class Initialized
INFO - 2023-01-10 10:07:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:07:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:07:03 --> Utf8 Class Initialized
INFO - 2023-01-10 10:07:03 --> URI Class Initialized
INFO - 2023-01-10 10:07:03 --> Router Class Initialized
INFO - 2023-01-10 10:07:03 --> Output Class Initialized
INFO - 2023-01-10 10:07:03 --> Security Class Initialized
DEBUG - 2023-01-10 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:07:03 --> Input Class Initialized
INFO - 2023-01-10 10:07:03 --> Language Class Initialized
INFO - 2023-01-10 10:07:03 --> Loader Class Initialized
INFO - 2023-01-10 10:07:03 --> Controller Class Initialized
DEBUG - 2023-01-10 10:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:07:03 --> Final output sent to browser
DEBUG - 2023-01-10 10:07:03 --> Total execution time: 0.0328
INFO - 2023-01-10 10:07:03 --> Config Class Initialized
INFO - 2023-01-10 10:07:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:07:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:07:03 --> Utf8 Class Initialized
INFO - 2023-01-10 10:07:03 --> URI Class Initialized
INFO - 2023-01-10 10:07:03 --> Router Class Initialized
INFO - 2023-01-10 10:07:03 --> Output Class Initialized
INFO - 2023-01-10 10:07:03 --> Security Class Initialized
DEBUG - 2023-01-10 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:07:03 --> Input Class Initialized
INFO - 2023-01-10 10:07:03 --> Language Class Initialized
INFO - 2023-01-10 10:07:03 --> Loader Class Initialized
INFO - 2023-01-10 10:07:03 --> Controller Class Initialized
DEBUG - 2023-01-10 10:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:07:03 --> Database Driver Class Initialized
INFO - 2023-01-10 10:07:03 --> Config Class Initialized
INFO - 2023-01-10 10:07:03 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:07:03 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:07:03 --> Utf8 Class Initialized
INFO - 2023-01-10 10:07:03 --> URI Class Initialized
INFO - 2023-01-10 10:07:03 --> Router Class Initialized
INFO - 2023-01-10 10:07:03 --> Output Class Initialized
INFO - 2023-01-10 10:07:03 --> Security Class Initialized
DEBUG - 2023-01-10 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:07:03 --> Input Class Initialized
INFO - 2023-01-10 10:07:03 --> Language Class Initialized
INFO - 2023-01-10 10:07:03 --> Loader Class Initialized
INFO - 2023-01-10 10:07:03 --> Controller Class Initialized
DEBUG - 2023-01-10 10:07:03 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:07:03 --> Database Driver Class Initialized
INFO - 2023-01-10 10:07:04 --> Config Class Initialized
INFO - 2023-01-10 10:07:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:07:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:07:04 --> Utf8 Class Initialized
INFO - 2023-01-10 10:07:04 --> URI Class Initialized
INFO - 2023-01-10 10:07:04 --> Router Class Initialized
INFO - 2023-01-10 10:07:04 --> Output Class Initialized
INFO - 2023-01-10 10:07:04 --> Security Class Initialized
DEBUG - 2023-01-10 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:07:04 --> Input Class Initialized
INFO - 2023-01-10 10:07:04 --> Language Class Initialized
INFO - 2023-01-10 10:07:04 --> Loader Class Initialized
INFO - 2023-01-10 10:07:04 --> Controller Class Initialized
DEBUG - 2023-01-10 10:07:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:07:04 --> Database Driver Class Initialized
INFO - 2023-01-10 10:07:04 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:07:04 --> Model "Node_model" initialized
INFO - 2023-01-10 10:07:04 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:07:04 --> Final output sent to browser
DEBUG - 2023-01-10 10:07:04 --> Total execution time: 1.0456
INFO - 2023-01-10 10:07:04 --> Config Class Initialized
INFO - 2023-01-10 10:07:04 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:07:04 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:07:04 --> Utf8 Class Initialized
INFO - 2023-01-10 10:07:04 --> URI Class Initialized
INFO - 2023-01-10 10:07:04 --> Router Class Initialized
INFO - 2023-01-10 10:07:04 --> Output Class Initialized
INFO - 2023-01-10 10:07:04 --> Security Class Initialized
DEBUG - 2023-01-10 10:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:07:04 --> Input Class Initialized
INFO - 2023-01-10 10:07:04 --> Language Class Initialized
INFO - 2023-01-10 10:07:04 --> Loader Class Initialized
INFO - 2023-01-10 10:07:04 --> Controller Class Initialized
DEBUG - 2023-01-10 10:07:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:07:04 --> Database Driver Class Initialized
INFO - 2023-01-10 10:07:04 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:07:04 --> Model "Node_model" initialized
INFO - 2023-01-10 10:07:04 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:07:04 --> Final output sent to browser
DEBUG - 2023-01-10 10:07:04 --> Total execution time: 0.1096
INFO - 2023-01-10 10:07:05 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:07:05 --> Model "Node_model" initialized
INFO - 2023-01-10 10:07:05 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:07:05 --> Final output sent to browser
DEBUG - 2023-01-10 10:07:05 --> Total execution time: 2.0598
INFO - 2023-01-10 10:07:05 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:07:05 --> Model "Node_model" initialized
INFO - 2023-01-10 10:07:05 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:07:05 --> Final output sent to browser
DEBUG - 2023-01-10 10:07:05 --> Total execution time: 1.0433
INFO - 2023-01-10 10:09:11 --> Config Class Initialized
INFO - 2023-01-10 10:09:11 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:09:11 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:09:11 --> Utf8 Class Initialized
INFO - 2023-01-10 10:09:11 --> URI Class Initialized
INFO - 2023-01-10 10:09:11 --> Router Class Initialized
INFO - 2023-01-10 10:09:11 --> Output Class Initialized
INFO - 2023-01-10 10:09:11 --> Security Class Initialized
DEBUG - 2023-01-10 10:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:09:11 --> Input Class Initialized
INFO - 2023-01-10 10:09:11 --> Language Class Initialized
INFO - 2023-01-10 10:09:11 --> Loader Class Initialized
INFO - 2023-01-10 10:09:11 --> Controller Class Initialized
DEBUG - 2023-01-10 10:09:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:09:11 --> Final output sent to browser
DEBUG - 2023-01-10 10:09:11 --> Total execution time: 0.0348
INFO - 2023-01-10 10:09:11 --> Config Class Initialized
INFO - 2023-01-10 10:09:11 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:09:11 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:09:11 --> Utf8 Class Initialized
INFO - 2023-01-10 10:09:11 --> URI Class Initialized
INFO - 2023-01-10 10:09:11 --> Router Class Initialized
INFO - 2023-01-10 10:09:11 --> Output Class Initialized
INFO - 2023-01-10 10:09:11 --> Security Class Initialized
DEBUG - 2023-01-10 10:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:09:11 --> Input Class Initialized
INFO - 2023-01-10 10:09:11 --> Language Class Initialized
INFO - 2023-01-10 10:09:11 --> Loader Class Initialized
INFO - 2023-01-10 10:09:11 --> Controller Class Initialized
DEBUG - 2023-01-10 10:09:11 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:09:11 --> Database Driver Class Initialized
INFO - 2023-01-10 10:09:11 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:09:11 --> Model "Node_model" initialized
INFO - 2023-01-10 10:09:11 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:09:11 --> Final output sent to browser
DEBUG - 2023-01-10 10:09:11 --> Total execution time: 0.0324
INFO - 2023-01-10 10:09:43 --> Config Class Initialized
INFO - 2023-01-10 10:09:43 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:09:43 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:09:43 --> Utf8 Class Initialized
INFO - 2023-01-10 10:09:43 --> URI Class Initialized
INFO - 2023-01-10 10:09:43 --> Router Class Initialized
INFO - 2023-01-10 10:09:43 --> Output Class Initialized
INFO - 2023-01-10 10:09:43 --> Security Class Initialized
DEBUG - 2023-01-10 10:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:09:43 --> Input Class Initialized
INFO - 2023-01-10 10:09:43 --> Language Class Initialized
INFO - 2023-01-10 10:09:43 --> Loader Class Initialized
INFO - 2023-01-10 10:09:43 --> Controller Class Initialized
DEBUG - 2023-01-10 10:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:09:43 --> Final output sent to browser
DEBUG - 2023-01-10 10:09:43 --> Total execution time: 0.0089
INFO - 2023-01-10 10:09:43 --> Config Class Initialized
INFO - 2023-01-10 10:09:43 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:09:43 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:09:43 --> Utf8 Class Initialized
INFO - 2023-01-10 10:09:43 --> URI Class Initialized
INFO - 2023-01-10 10:09:43 --> Router Class Initialized
INFO - 2023-01-10 10:09:43 --> Output Class Initialized
INFO - 2023-01-10 10:09:43 --> Security Class Initialized
DEBUG - 2023-01-10 10:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:09:43 --> Input Class Initialized
INFO - 2023-01-10 10:09:43 --> Language Class Initialized
INFO - 2023-01-10 10:09:43 --> Loader Class Initialized
INFO - 2023-01-10 10:09:43 --> Controller Class Initialized
DEBUG - 2023-01-10 10:09:43 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:09:43 --> Database Driver Class Initialized
INFO - 2023-01-10 10:09:43 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:09:43 --> Model "Node_model" initialized
INFO - 2023-01-10 10:09:43 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:10:15 --> Config Class Initialized
INFO - 2023-01-10 10:10:15 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:10:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:10:15 --> Utf8 Class Initialized
INFO - 2023-01-10 10:10:15 --> URI Class Initialized
INFO - 2023-01-10 10:10:15 --> Router Class Initialized
INFO - 2023-01-10 10:10:15 --> Output Class Initialized
INFO - 2023-01-10 10:10:15 --> Security Class Initialized
DEBUG - 2023-01-10 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:10:15 --> Input Class Initialized
INFO - 2023-01-10 10:10:15 --> Language Class Initialized
INFO - 2023-01-10 10:10:15 --> Loader Class Initialized
INFO - 2023-01-10 10:10:15 --> Controller Class Initialized
DEBUG - 2023-01-10 10:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:10:15 --> Final output sent to browser
DEBUG - 2023-01-10 10:10:15 --> Total execution time: 0.0105
INFO - 2023-01-10 10:10:15 --> Config Class Initialized
INFO - 2023-01-10 10:10:15 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:10:15 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:10:15 --> Utf8 Class Initialized
INFO - 2023-01-10 10:10:15 --> URI Class Initialized
INFO - 2023-01-10 10:10:15 --> Router Class Initialized
INFO - 2023-01-10 10:10:15 --> Output Class Initialized
INFO - 2023-01-10 10:10:15 --> Security Class Initialized
DEBUG - 2023-01-10 10:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:10:15 --> Input Class Initialized
INFO - 2023-01-10 10:10:15 --> Language Class Initialized
INFO - 2023-01-10 10:10:15 --> Loader Class Initialized
INFO - 2023-01-10 10:10:15 --> Controller Class Initialized
DEBUG - 2023-01-10 10:10:15 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:10:15 --> Database Driver Class Initialized
INFO - 2023-01-10 10:10:15 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:10:15 --> Model "Node_model" initialized
INFO - 2023-01-10 10:10:15 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:10:35 --> Config Class Initialized
INFO - 2023-01-10 10:10:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:10:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:10:35 --> Utf8 Class Initialized
INFO - 2023-01-10 10:10:35 --> URI Class Initialized
INFO - 2023-01-10 10:10:35 --> Router Class Initialized
INFO - 2023-01-10 10:10:35 --> Output Class Initialized
INFO - 2023-01-10 10:10:35 --> Security Class Initialized
DEBUG - 2023-01-10 10:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:10:35 --> Input Class Initialized
INFO - 2023-01-10 10:10:35 --> Language Class Initialized
INFO - 2023-01-10 10:10:35 --> Loader Class Initialized
INFO - 2023-01-10 10:10:35 --> Controller Class Initialized
DEBUG - 2023-01-10 10:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:10:35 --> Final output sent to browser
DEBUG - 2023-01-10 10:10:35 --> Total execution time: 0.0187
INFO - 2023-01-10 10:10:35 --> Config Class Initialized
INFO - 2023-01-10 10:10:35 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:10:35 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:10:35 --> Utf8 Class Initialized
INFO - 2023-01-10 10:10:35 --> URI Class Initialized
INFO - 2023-01-10 10:10:35 --> Router Class Initialized
INFO - 2023-01-10 10:10:35 --> Output Class Initialized
INFO - 2023-01-10 10:10:35 --> Security Class Initialized
DEBUG - 2023-01-10 10:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:10:35 --> Input Class Initialized
INFO - 2023-01-10 10:10:35 --> Language Class Initialized
INFO - 2023-01-10 10:10:35 --> Loader Class Initialized
INFO - 2023-01-10 10:10:35 --> Controller Class Initialized
DEBUG - 2023-01-10 10:10:35 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:10:35 --> Database Driver Class Initialized
INFO - 2023-01-10 10:10:35 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:10:35 --> Model "Node_model" initialized
INFO - 2023-01-10 10:10:35 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:11:34 --> Config Class Initialized
INFO - 2023-01-10 10:11:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:11:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:11:34 --> Utf8 Class Initialized
INFO - 2023-01-10 10:11:34 --> URI Class Initialized
INFO - 2023-01-10 10:11:34 --> Router Class Initialized
INFO - 2023-01-10 10:11:34 --> Output Class Initialized
INFO - 2023-01-10 10:11:34 --> Security Class Initialized
DEBUG - 2023-01-10 10:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:11:34 --> Input Class Initialized
INFO - 2023-01-10 10:11:34 --> Language Class Initialized
INFO - 2023-01-10 10:11:34 --> Loader Class Initialized
INFO - 2023-01-10 10:11:34 --> Controller Class Initialized
DEBUG - 2023-01-10 10:11:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:11:34 --> Final output sent to browser
DEBUG - 2023-01-10 10:11:34 --> Total execution time: 0.0177
INFO - 2023-01-10 10:11:34 --> Config Class Initialized
INFO - 2023-01-10 10:11:34 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:11:34 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:11:34 --> Utf8 Class Initialized
INFO - 2023-01-10 10:11:34 --> URI Class Initialized
INFO - 2023-01-10 10:11:34 --> Router Class Initialized
INFO - 2023-01-10 10:11:34 --> Output Class Initialized
INFO - 2023-01-10 10:11:34 --> Security Class Initialized
DEBUG - 2023-01-10 10:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:11:34 --> Input Class Initialized
INFO - 2023-01-10 10:11:34 --> Language Class Initialized
INFO - 2023-01-10 10:11:34 --> Loader Class Initialized
INFO - 2023-01-10 10:11:34 --> Controller Class Initialized
DEBUG - 2023-01-10 10:11:34 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:11:34 --> Database Driver Class Initialized
INFO - 2023-01-10 10:11:34 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:11:34 --> Model "Node_model" initialized
INFO - 2023-01-10 10:11:34 --> Model "Grafana_model" initialized
INFO - 2023-01-10 10:21:07 --> Config Class Initialized
INFO - 2023-01-10 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:21:07 --> Utf8 Class Initialized
INFO - 2023-01-10 10:21:07 --> URI Class Initialized
INFO - 2023-01-10 10:21:07 --> Router Class Initialized
INFO - 2023-01-10 10:21:07 --> Output Class Initialized
INFO - 2023-01-10 10:21:07 --> Security Class Initialized
DEBUG - 2023-01-10 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:21:07 --> Input Class Initialized
INFO - 2023-01-10 10:21:07 --> Language Class Initialized
INFO - 2023-01-10 10:21:07 --> Loader Class Initialized
INFO - 2023-01-10 10:21:07 --> Controller Class Initialized
DEBUG - 2023-01-10 10:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:21:07 --> Database Driver Class Initialized
INFO - 2023-01-10 10:21:07 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:21:07 --> Database Driver Class Initialized
INFO - 2023-01-10 10:21:07 --> Model "Login_model" initialized
INFO - 2023-01-10 10:21:07 --> Final output sent to browser
DEBUG - 2023-01-10 10:21:07 --> Total execution time: 0.2155
INFO - 2023-01-10 10:21:07 --> Config Class Initialized
INFO - 2023-01-10 10:21:07 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:21:07 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:21:07 --> Utf8 Class Initialized
INFO - 2023-01-10 10:21:07 --> URI Class Initialized
INFO - 2023-01-10 10:21:07 --> Router Class Initialized
INFO - 2023-01-10 10:21:07 --> Output Class Initialized
INFO - 2023-01-10 10:21:07 --> Security Class Initialized
DEBUG - 2023-01-10 10:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:21:07 --> Input Class Initialized
INFO - 2023-01-10 10:21:07 --> Language Class Initialized
INFO - 2023-01-10 10:21:07 --> Loader Class Initialized
INFO - 2023-01-10 10:21:07 --> Controller Class Initialized
DEBUG - 2023-01-10 10:21:07 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:21:07 --> Database Driver Class Initialized
INFO - 2023-01-10 10:21:07 --> Model "Cluster_model" initialized
INFO - 2023-01-10 10:21:07 --> Database Driver Class Initialized
INFO - 2023-01-10 10:21:07 --> Model "Login_model" initialized
INFO - 2023-01-10 10:21:07 --> Final output sent to browser
DEBUG - 2023-01-10 10:21:07 --> Total execution time: 0.1137
INFO - 2023-01-10 10:21:08 --> Config Class Initialized
INFO - 2023-01-10 10:21:08 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:21:08 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:21:08 --> Utf8 Class Initialized
INFO - 2023-01-10 10:21:08 --> URI Class Initialized
INFO - 2023-01-10 10:21:08 --> Router Class Initialized
INFO - 2023-01-10 10:21:08 --> Output Class Initialized
INFO - 2023-01-10 10:21:08 --> Security Class Initialized
DEBUG - 2023-01-10 10:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:21:08 --> Input Class Initialized
INFO - 2023-01-10 10:21:08 --> Language Class Initialized
INFO - 2023-01-10 10:21:08 --> Loader Class Initialized
INFO - 2023-01-10 10:21:08 --> Controller Class Initialized
DEBUG - 2023-01-10 10:21:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:21:08 --> Database Driver Class Initialized
INFO - 2023-01-10 10:21:08 --> Database Driver Class Initialized
INFO - 2023-01-10 10:21:08 --> Model "Login_model" initialized
INFO - 2023-01-10 10:21:08 --> Final output sent to browser
DEBUG - 2023-01-10 10:21:08 --> Total execution time: 0.1252
INFO - 2023-01-10 10:21:08 --> Config Class Initialized
INFO - 2023-01-10 10:21:08 --> Hooks Class Initialized
DEBUG - 2023-01-10 10:21:08 --> UTF-8 Support Enabled
INFO - 2023-01-10 10:21:08 --> Utf8 Class Initialized
INFO - 2023-01-10 10:21:08 --> URI Class Initialized
INFO - 2023-01-10 10:21:08 --> Router Class Initialized
INFO - 2023-01-10 10:21:08 --> Output Class Initialized
INFO - 2023-01-10 10:21:08 --> Security Class Initialized
DEBUG - 2023-01-10 10:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 10:21:08 --> Input Class Initialized
INFO - 2023-01-10 10:21:08 --> Language Class Initialized
INFO - 2023-01-10 10:21:08 --> Loader Class Initialized
INFO - 2023-01-10 10:21:08 --> Controller Class Initialized
DEBUG - 2023-01-10 10:21:08 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 10:21:08 --> Database Driver Class Initialized
INFO - 2023-01-10 10:21:08 --> Database Driver Class Initialized
INFO - 2023-01-10 10:21:08 --> Model "Login_model" initialized
INFO - 2023-01-10 10:21:08 --> Final output sent to browser
DEBUG - 2023-01-10 10:21:08 --> Total execution time: 0.0611
INFO - 2023-01-10 15:07:56 --> Config Class Initialized
INFO - 2023-01-10 15:07:56 --> Hooks Class Initialized
DEBUG - 2023-01-10 15:07:56 --> UTF-8 Support Enabled
INFO - 2023-01-10 15:07:56 --> Utf8 Class Initialized
INFO - 2023-01-10 15:07:56 --> URI Class Initialized
INFO - 2023-01-10 15:07:56 --> Router Class Initialized
INFO - 2023-01-10 15:07:56 --> Output Class Initialized
INFO - 2023-01-10 15:07:56 --> Security Class Initialized
DEBUG - 2023-01-10 15:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 15:07:56 --> Input Class Initialized
INFO - 2023-01-10 15:07:56 --> Language Class Initialized
INFO - 2023-01-10 15:07:56 --> Loader Class Initialized
INFO - 2023-01-10 15:07:56 --> Controller Class Initialized
DEBUG - 2023-01-10 15:07:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 15:07:56 --> Database Driver Class Initialized
INFO - 2023-01-10 15:08:02 --> Config Class Initialized
INFO - 2023-01-10 15:08:02 --> Hooks Class Initialized
DEBUG - 2023-01-10 15:08:02 --> UTF-8 Support Enabled
INFO - 2023-01-10 15:08:02 --> Utf8 Class Initialized
INFO - 2023-01-10 15:08:02 --> URI Class Initialized
INFO - 2023-01-10 15:08:02 --> Router Class Initialized
INFO - 2023-01-10 15:08:02 --> Output Class Initialized
INFO - 2023-01-10 15:08:02 --> Security Class Initialized
DEBUG - 2023-01-10 15:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 15:08:02 --> Input Class Initialized
INFO - 2023-01-10 15:08:02 --> Language Class Initialized
INFO - 2023-01-10 15:08:02 --> Loader Class Initialized
INFO - 2023-01-10 15:08:02 --> Controller Class Initialized
DEBUG - 2023-01-10 15:08:02 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 15:08:02 --> Database Driver Class Initialized
ERROR - 2023-01-10 15:08:03 --> Unable to connect to the database
INFO - 2023-01-10 15:08:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-01-10 15:08:07 --> Unable to connect to the database
INFO - 2023-01-10 15:08:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-01-10 15:25:59 --> Config Class Initialized
INFO - 2023-01-10 15:25:59 --> Hooks Class Initialized
DEBUG - 2023-01-10 15:25:59 --> UTF-8 Support Enabled
INFO - 2023-01-10 15:25:59 --> Utf8 Class Initialized
INFO - 2023-01-10 15:25:59 --> URI Class Initialized
INFO - 2023-01-10 15:25:59 --> Router Class Initialized
INFO - 2023-01-10 15:25:59 --> Output Class Initialized
INFO - 2023-01-10 15:25:59 --> Security Class Initialized
DEBUG - 2023-01-10 15:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-10 15:25:59 --> Input Class Initialized
INFO - 2023-01-10 15:25:59 --> Language Class Initialized
INFO - 2023-01-10 15:25:59 --> Loader Class Initialized
INFO - 2023-01-10 15:25:59 --> Controller Class Initialized
INFO - 2023-01-10 15:25:59 --> Helper loaded: form_helper
INFO - 2023-01-10 15:25:59 --> Helper loaded: url_helper
DEBUG - 2023-01-10 15:25:59 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-10 15:25:59 --> Model "Change_model" initialized
INFO - 2023-01-10 15:26:20 --> Final output sent to browser
DEBUG - 2023-01-10 15:26:20 --> Total execution time: 21.2742
