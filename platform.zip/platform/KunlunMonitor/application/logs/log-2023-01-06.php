<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-06 09:51:02 --> Config Class Initialized
INFO - 2023-01-06 09:51:02 --> Hooks Class Initialized
DEBUG - 2023-01-06 09:51:02 --> UTF-8 Support Enabled
INFO - 2023-01-06 09:51:02 --> Utf8 Class Initialized
INFO - 2023-01-06 09:51:02 --> URI Class Initialized
INFO - 2023-01-06 09:51:02 --> Router Class Initialized
INFO - 2023-01-06 09:51:02 --> Output Class Initialized
INFO - 2023-01-06 09:51:02 --> Security Class Initialized
DEBUG - 2023-01-06 09:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 09:51:02 --> Input Class Initialized
INFO - 2023-01-06 09:51:02 --> Language Class Initialized
INFO - 2023-01-06 09:51:02 --> Loader Class Initialized
INFO - 2023-01-06 09:51:02 --> Controller Class Initialized
INFO - 2023-01-06 09:51:02 --> Helper loaded: form_helper
INFO - 2023-01-06 09:51:02 --> Helper loaded: url_helper
DEBUG - 2023-01-06 09:51:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 09:51:02 --> Model "Change_model" initialized
INFO - 2023-01-06 09:51:34 --> Config Class Initialized
INFO - 2023-01-06 09:51:34 --> Hooks Class Initialized
DEBUG - 2023-01-06 09:51:34 --> UTF-8 Support Enabled
INFO - 2023-01-06 09:51:34 --> Utf8 Class Initialized
INFO - 2023-01-06 09:51:34 --> URI Class Initialized
INFO - 2023-01-06 09:51:34 --> Router Class Initialized
INFO - 2023-01-06 09:51:34 --> Output Class Initialized
INFO - 2023-01-06 09:51:34 --> Security Class Initialized
DEBUG - 2023-01-06 09:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 09:51:34 --> Input Class Initialized
INFO - 2023-01-06 09:51:34 --> Language Class Initialized
INFO - 2023-01-06 09:51:34 --> Loader Class Initialized
INFO - 2023-01-06 09:51:34 --> Controller Class Initialized
INFO - 2023-01-06 09:51:34 --> Helper loaded: form_helper
INFO - 2023-01-06 09:51:34 --> Helper loaded: url_helper
DEBUG - 2023-01-06 09:51:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 09:51:34 --> Model "Change_model" initialized
INFO - 2023-01-06 09:52:11 --> Config Class Initialized
INFO - 2023-01-06 09:52:11 --> Hooks Class Initialized
DEBUG - 2023-01-06 09:52:11 --> UTF-8 Support Enabled
INFO - 2023-01-06 09:52:11 --> Utf8 Class Initialized
INFO - 2023-01-06 09:52:11 --> URI Class Initialized
INFO - 2023-01-06 09:52:11 --> Router Class Initialized
INFO - 2023-01-06 09:52:11 --> Output Class Initialized
INFO - 2023-01-06 09:52:11 --> Security Class Initialized
DEBUG - 2023-01-06 09:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 09:52:11 --> Input Class Initialized
INFO - 2023-01-06 09:52:11 --> Language Class Initialized
INFO - 2023-01-06 09:52:11 --> Loader Class Initialized
INFO - 2023-01-06 09:52:11 --> Controller Class Initialized
INFO - 2023-01-06 09:52:11 --> Helper loaded: form_helper
INFO - 2023-01-06 09:52:11 --> Helper loaded: url_helper
DEBUG - 2023-01-06 09:52:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 09:52:11 --> Model "Change_model" initialized
INFO - 2023-01-06 09:53:37 --> Config Class Initialized
INFO - 2023-01-06 09:53:37 --> Hooks Class Initialized
DEBUG - 2023-01-06 09:53:37 --> UTF-8 Support Enabled
INFO - 2023-01-06 09:53:37 --> Utf8 Class Initialized
INFO - 2023-01-06 09:53:37 --> URI Class Initialized
INFO - 2023-01-06 09:53:37 --> Router Class Initialized
INFO - 2023-01-06 09:53:37 --> Output Class Initialized
INFO - 2023-01-06 09:53:37 --> Security Class Initialized
DEBUG - 2023-01-06 09:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 09:53:37 --> Input Class Initialized
INFO - 2023-01-06 09:53:37 --> Language Class Initialized
INFO - 2023-01-06 09:53:37 --> Loader Class Initialized
INFO - 2023-01-06 09:53:37 --> Controller Class Initialized
INFO - 2023-01-06 09:53:37 --> Helper loaded: form_helper
INFO - 2023-01-06 09:53:37 --> Helper loaded: url_helper
DEBUG - 2023-01-06 09:53:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 09:53:37 --> Model "Change_model" initialized
INFO - 2023-01-06 09:54:02 --> Final output sent to browser
DEBUG - 2023-01-06 09:54:02 --> Total execution time: 180.3747
INFO - 2023-01-06 09:54:22 --> Config Class Initialized
INFO - 2023-01-06 09:54:22 --> Hooks Class Initialized
DEBUG - 2023-01-06 09:54:22 --> UTF-8 Support Enabled
INFO - 2023-01-06 09:54:22 --> Utf8 Class Initialized
INFO - 2023-01-06 09:54:22 --> URI Class Initialized
INFO - 2023-01-06 09:54:22 --> Router Class Initialized
INFO - 2023-01-06 09:54:22 --> Output Class Initialized
INFO - 2023-01-06 09:54:22 --> Security Class Initialized
DEBUG - 2023-01-06 09:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 09:54:22 --> Input Class Initialized
INFO - 2023-01-06 09:54:22 --> Language Class Initialized
INFO - 2023-01-06 09:54:22 --> Loader Class Initialized
INFO - 2023-01-06 09:54:22 --> Controller Class Initialized
INFO - 2023-01-06 09:54:22 --> Helper loaded: form_helper
INFO - 2023-01-06 09:54:22 --> Helper loaded: url_helper
DEBUG - 2023-01-06 09:54:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 09:54:22 --> Model "Change_model" initialized
INFO - 2023-01-06 09:54:34 --> Final output sent to browser
DEBUG - 2023-01-06 09:54:34 --> Total execution time: 180.2599
INFO - 2023-01-06 09:55:11 --> Final output sent to browser
DEBUG - 2023-01-06 09:55:11 --> Total execution time: 180.2279
INFO - 2023-01-06 09:56:37 --> Final output sent to browser
DEBUG - 2023-01-06 09:56:37 --> Total execution time: 180.2542
INFO - 2023-01-06 09:57:22 --> Final output sent to browser
DEBUG - 2023-01-06 09:57:22 --> Total execution time: 180.2801
INFO - 2023-01-06 10:05:36 --> Config Class Initialized
INFO - 2023-01-06 10:05:36 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:05:36 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:05:36 --> Utf8 Class Initialized
INFO - 2023-01-06 10:05:36 --> URI Class Initialized
INFO - 2023-01-06 10:05:36 --> Router Class Initialized
INFO - 2023-01-06 10:05:36 --> Output Class Initialized
INFO - 2023-01-06 10:05:36 --> Security Class Initialized
DEBUG - 2023-01-06 10:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:05:36 --> Input Class Initialized
INFO - 2023-01-06 10:05:36 --> Language Class Initialized
INFO - 2023-01-06 10:05:36 --> Loader Class Initialized
INFO - 2023-01-06 10:05:36 --> Controller Class Initialized
INFO - 2023-01-06 10:05:36 --> Helper loaded: form_helper
INFO - 2023-01-06 10:05:36 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:05:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:05:36 --> Model "Change_model" initialized
INFO - 2023-01-06 10:08:36 --> Final output sent to browser
DEBUG - 2023-01-06 10:08:36 --> Total execution time: 180.3183
INFO - 2023-01-06 10:16:28 --> Config Class Initialized
INFO - 2023-01-06 10:16:28 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:16:28 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:16:28 --> Utf8 Class Initialized
INFO - 2023-01-06 10:16:28 --> URI Class Initialized
INFO - 2023-01-06 10:16:28 --> Router Class Initialized
INFO - 2023-01-06 10:16:28 --> Output Class Initialized
INFO - 2023-01-06 10:16:28 --> Security Class Initialized
DEBUG - 2023-01-06 10:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:16:28 --> Input Class Initialized
INFO - 2023-01-06 10:16:28 --> Language Class Initialized
INFO - 2023-01-06 10:16:28 --> Loader Class Initialized
INFO - 2023-01-06 10:16:28 --> Controller Class Initialized
INFO - 2023-01-06 10:16:28 --> Helper loaded: form_helper
INFO - 2023-01-06 10:16:28 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:16:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:16:28 --> Model "Change_model" initialized
INFO - 2023-01-06 10:17:04 --> Config Class Initialized
INFO - 2023-01-06 10:17:04 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:17:04 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:17:04 --> Utf8 Class Initialized
INFO - 2023-01-06 10:17:04 --> URI Class Initialized
INFO - 2023-01-06 10:17:04 --> Router Class Initialized
INFO - 2023-01-06 10:17:04 --> Output Class Initialized
INFO - 2023-01-06 10:17:04 --> Security Class Initialized
DEBUG - 2023-01-06 10:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:17:04 --> Input Class Initialized
INFO - 2023-01-06 10:17:04 --> Language Class Initialized
INFO - 2023-01-06 10:17:04 --> Loader Class Initialized
INFO - 2023-01-06 10:17:04 --> Controller Class Initialized
INFO - 2023-01-06 10:17:04 --> Helper loaded: form_helper
INFO - 2023-01-06 10:17:04 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:17:04 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:19:29 --> Final output sent to browser
DEBUG - 2023-01-06 10:19:29 --> Total execution time: 180.2878
INFO - 2023-01-06 10:20:05 --> Config Class Initialized
INFO - 2023-01-06 10:20:05 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:20:05 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:20:05 --> Utf8 Class Initialized
INFO - 2023-01-06 10:20:05 --> URI Class Initialized
INFO - 2023-01-06 10:20:05 --> Router Class Initialized
INFO - 2023-01-06 10:20:05 --> Output Class Initialized
INFO - 2023-01-06 10:20:05 --> Security Class Initialized
DEBUG - 2023-01-06 10:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:20:05 --> Input Class Initialized
INFO - 2023-01-06 10:20:05 --> Language Class Initialized
INFO - 2023-01-06 10:20:05 --> Loader Class Initialized
INFO - 2023-01-06 10:20:05 --> Controller Class Initialized
INFO - 2023-01-06 10:20:05 --> Helper loaded: form_helper
INFO - 2023-01-06 10:20:05 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:20:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:20:05 --> Model "Change_model" initialized
INFO - 2023-01-06 10:21:09 --> Config Class Initialized
INFO - 2023-01-06 10:21:09 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:21:09 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:21:09 --> Utf8 Class Initialized
INFO - 2023-01-06 10:21:09 --> URI Class Initialized
INFO - 2023-01-06 10:21:09 --> Router Class Initialized
INFO - 2023-01-06 10:21:09 --> Output Class Initialized
INFO - 2023-01-06 10:21:09 --> Security Class Initialized
DEBUG - 2023-01-06 10:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:21:09 --> Input Class Initialized
INFO - 2023-01-06 10:21:09 --> Language Class Initialized
INFO - 2023-01-06 10:21:09 --> Loader Class Initialized
INFO - 2023-01-06 10:21:09 --> Controller Class Initialized
INFO - 2023-01-06 10:21:09 --> Helper loaded: form_helper
INFO - 2023-01-06 10:21:09 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:21:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:21:09 --> Model "Change_model" initialized
INFO - 2023-01-06 10:21:58 --> Config Class Initialized
INFO - 2023-01-06 10:21:58 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:21:58 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:21:58 --> Utf8 Class Initialized
INFO - 2023-01-06 10:21:58 --> URI Class Initialized
INFO - 2023-01-06 10:21:58 --> Router Class Initialized
INFO - 2023-01-06 10:21:58 --> Output Class Initialized
INFO - 2023-01-06 10:21:58 --> Security Class Initialized
DEBUG - 2023-01-06 10:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:21:58 --> Input Class Initialized
INFO - 2023-01-06 10:21:58 --> Language Class Initialized
INFO - 2023-01-06 10:21:58 --> Loader Class Initialized
INFO - 2023-01-06 10:21:58 --> Controller Class Initialized
INFO - 2023-01-06 10:21:58 --> Helper loaded: form_helper
INFO - 2023-01-06 10:21:58 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:21:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:21:58 --> Model "Change_model" initialized
INFO - 2023-01-06 10:30:59 --> Config Class Initialized
INFO - 2023-01-06 10:30:59 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:30:59 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:30:59 --> Utf8 Class Initialized
INFO - 2023-01-06 10:30:59 --> URI Class Initialized
INFO - 2023-01-06 10:30:59 --> Router Class Initialized
INFO - 2023-01-06 10:30:59 --> Output Class Initialized
INFO - 2023-01-06 10:31:00 --> Security Class Initialized
DEBUG - 2023-01-06 10:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:31:00 --> Input Class Initialized
INFO - 2023-01-06 10:31:00 --> Language Class Initialized
INFO - 2023-01-06 10:31:00 --> Loader Class Initialized
INFO - 2023-01-06 10:31:00 --> Controller Class Initialized
INFO - 2023-01-06 10:31:01 --> Helper loaded: form_helper
INFO - 2023-01-06 10:31:01 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:31:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:31:01 --> Model "Change_model" initialized
INFO - 2023-01-06 10:32:06 --> Config Class Initialized
INFO - 2023-01-06 10:32:06 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:32:06 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:32:06 --> Utf8 Class Initialized
INFO - 2023-01-06 10:32:06 --> URI Class Initialized
INFO - 2023-01-06 10:32:06 --> Router Class Initialized
INFO - 2023-01-06 10:32:06 --> Output Class Initialized
INFO - 2023-01-06 10:32:06 --> Security Class Initialized
DEBUG - 2023-01-06 10:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:32:06 --> Input Class Initialized
INFO - 2023-01-06 10:32:06 --> Language Class Initialized
INFO - 2023-01-06 10:32:06 --> Loader Class Initialized
INFO - 2023-01-06 10:32:06 --> Controller Class Initialized
INFO - 2023-01-06 10:32:06 --> Helper loaded: form_helper
INFO - 2023-01-06 10:32:06 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:32:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:32:07 --> Model "Change_model" initialized
INFO - 2023-01-06 10:34:01 --> Final output sent to browser
DEBUG - 2023-01-06 10:34:01 --> Total execution time: 182.4826
INFO - 2023-01-06 10:34:20 --> Config Class Initialized
INFO - 2023-01-06 10:34:20 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:34:20 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:34:20 --> Utf8 Class Initialized
INFO - 2023-01-06 10:34:20 --> URI Class Initialized
INFO - 2023-01-06 10:34:20 --> Router Class Initialized
INFO - 2023-01-06 10:34:20 --> Output Class Initialized
INFO - 2023-01-06 10:34:20 --> Security Class Initialized
DEBUG - 2023-01-06 10:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:34:20 --> Input Class Initialized
INFO - 2023-01-06 10:34:20 --> Language Class Initialized
INFO - 2023-01-06 10:34:20 --> Loader Class Initialized
INFO - 2023-01-06 10:34:20 --> Controller Class Initialized
INFO - 2023-01-06 10:34:20 --> Helper loaded: form_helper
INFO - 2023-01-06 10:34:20 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:34:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:34:20 --> Model "Change_model" initialized
INFO - 2023-01-06 10:35:07 --> Final output sent to browser
DEBUG - 2023-01-06 10:35:07 --> Total execution time: 180.9640
INFO - 2023-01-06 10:35:54 --> Config Class Initialized
INFO - 2023-01-06 10:35:54 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:35:54 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:35:54 --> Utf8 Class Initialized
INFO - 2023-01-06 10:35:54 --> URI Class Initialized
INFO - 2023-01-06 10:35:54 --> Router Class Initialized
INFO - 2023-01-06 10:35:54 --> Output Class Initialized
INFO - 2023-01-06 10:35:54 --> Security Class Initialized
DEBUG - 2023-01-06 10:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:35:54 --> Input Class Initialized
INFO - 2023-01-06 10:35:54 --> Language Class Initialized
INFO - 2023-01-06 10:35:55 --> Loader Class Initialized
INFO - 2023-01-06 10:35:55 --> Controller Class Initialized
INFO - 2023-01-06 10:35:55 --> Helper loaded: form_helper
INFO - 2023-01-06 10:35:55 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:35:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:35:55 --> Model "Change_model" initialized
INFO - 2023-01-06 10:36:14 --> Config Class Initialized
INFO - 2023-01-06 10:36:14 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:36:14 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:36:14 --> Utf8 Class Initialized
INFO - 2023-01-06 10:36:14 --> URI Class Initialized
INFO - 2023-01-06 10:36:14 --> Router Class Initialized
INFO - 2023-01-06 10:36:14 --> Output Class Initialized
INFO - 2023-01-06 10:36:14 --> Security Class Initialized
DEBUG - 2023-01-06 10:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:36:14 --> Input Class Initialized
INFO - 2023-01-06 10:36:14 --> Language Class Initialized
INFO - 2023-01-06 10:36:14 --> Loader Class Initialized
INFO - 2023-01-06 10:36:14 --> Controller Class Initialized
INFO - 2023-01-06 10:36:14 --> Helper loaded: form_helper
INFO - 2023-01-06 10:36:14 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:36:14 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:37:20 --> Final output sent to browser
DEBUG - 2023-01-06 10:37:20 --> Total execution time: 180.6818
INFO - 2023-01-06 10:37:36 --> Config Class Initialized
INFO - 2023-01-06 10:37:36 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:37:36 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:37:36 --> Utf8 Class Initialized
INFO - 2023-01-06 10:37:36 --> URI Class Initialized
INFO - 2023-01-06 10:37:36 --> Router Class Initialized
INFO - 2023-01-06 10:37:36 --> Output Class Initialized
INFO - 2023-01-06 10:37:36 --> Security Class Initialized
DEBUG - 2023-01-06 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:37:36 --> Input Class Initialized
INFO - 2023-01-06 10:37:36 --> Language Class Initialized
INFO - 2023-01-06 10:37:36 --> Loader Class Initialized
INFO - 2023-01-06 10:37:36 --> Controller Class Initialized
INFO - 2023-01-06 10:37:36 --> Helper loaded: form_helper
INFO - 2023-01-06 10:37:36 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:37:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:37:58 --> Config Class Initialized
INFO - 2023-01-06 10:37:58 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:37:58 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:37:58 --> Utf8 Class Initialized
INFO - 2023-01-06 10:37:58 --> URI Class Initialized
INFO - 2023-01-06 10:37:58 --> Router Class Initialized
INFO - 2023-01-06 10:37:58 --> Output Class Initialized
INFO - 2023-01-06 10:37:58 --> Security Class Initialized
DEBUG - 2023-01-06 10:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:37:58 --> Input Class Initialized
INFO - 2023-01-06 10:37:58 --> Language Class Initialized
INFO - 2023-01-06 10:37:58 --> Loader Class Initialized
INFO - 2023-01-06 10:37:58 --> Controller Class Initialized
INFO - 2023-01-06 10:37:58 --> Helper loaded: form_helper
INFO - 2023-01-06 10:37:58 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:37:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:38:55 --> Final output sent to browser
DEBUG - 2023-01-06 10:38:55 --> Total execution time: 181.8380
INFO - 2023-01-06 10:39:53 --> Config Class Initialized
INFO - 2023-01-06 10:39:53 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:39:53 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:39:53 --> Utf8 Class Initialized
INFO - 2023-01-06 10:39:53 --> URI Class Initialized
INFO - 2023-01-06 10:39:53 --> Router Class Initialized
INFO - 2023-01-06 10:39:53 --> Output Class Initialized
INFO - 2023-01-06 10:39:53 --> Security Class Initialized
DEBUG - 2023-01-06 10:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:39:53 --> Input Class Initialized
INFO - 2023-01-06 10:39:53 --> Language Class Initialized
INFO - 2023-01-06 10:39:53 --> Loader Class Initialized
INFO - 2023-01-06 10:39:53 --> Controller Class Initialized
INFO - 2023-01-06 10:39:53 --> Helper loaded: form_helper
INFO - 2023-01-06 10:39:53 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:39:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:39:53 --> Model "Change_model" initialized
INFO - 2023-01-06 10:42:50 --> Config Class Initialized
INFO - 2023-01-06 10:42:50 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:42:50 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:42:50 --> Utf8 Class Initialized
INFO - 2023-01-06 10:42:50 --> URI Class Initialized
INFO - 2023-01-06 10:42:50 --> Router Class Initialized
INFO - 2023-01-06 10:42:50 --> Output Class Initialized
INFO - 2023-01-06 10:42:50 --> Security Class Initialized
DEBUG - 2023-01-06 10:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:42:50 --> Input Class Initialized
INFO - 2023-01-06 10:42:50 --> Language Class Initialized
INFO - 2023-01-06 10:42:50 --> Loader Class Initialized
INFO - 2023-01-06 10:42:50 --> Controller Class Initialized
INFO - 2023-01-06 10:42:50 --> Helper loaded: form_helper
INFO - 2023-01-06 10:42:50 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:42:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:42:50 --> Model "Change_model" initialized
INFO - 2023-01-06 10:42:53 --> Final output sent to browser
DEBUG - 2023-01-06 10:42:53 --> Total execution time: 180.2996
INFO - 2023-01-06 10:45:08 --> Config Class Initialized
INFO - 2023-01-06 10:45:08 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:45:08 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:45:08 --> Utf8 Class Initialized
INFO - 2023-01-06 10:45:08 --> URI Class Initialized
INFO - 2023-01-06 10:45:08 --> Router Class Initialized
INFO - 2023-01-06 10:45:08 --> Output Class Initialized
INFO - 2023-01-06 10:45:08 --> Security Class Initialized
DEBUG - 2023-01-06 10:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:45:08 --> Input Class Initialized
INFO - 2023-01-06 10:45:08 --> Language Class Initialized
INFO - 2023-01-06 10:45:08 --> Loader Class Initialized
INFO - 2023-01-06 10:45:08 --> Controller Class Initialized
INFO - 2023-01-06 10:45:08 --> Helper loaded: form_helper
INFO - 2023-01-06 10:45:08 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:45:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:45:26 --> Config Class Initialized
INFO - 2023-01-06 10:45:26 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:45:26 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:45:26 --> Utf8 Class Initialized
INFO - 2023-01-06 10:45:26 --> URI Class Initialized
INFO - 2023-01-06 10:45:26 --> Router Class Initialized
INFO - 2023-01-06 10:45:26 --> Output Class Initialized
INFO - 2023-01-06 10:45:27 --> Security Class Initialized
DEBUG - 2023-01-06 10:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:45:27 --> Input Class Initialized
INFO - 2023-01-06 10:45:27 --> Language Class Initialized
INFO - 2023-01-06 10:45:27 --> Loader Class Initialized
INFO - 2023-01-06 10:45:27 --> Controller Class Initialized
INFO - 2023-01-06 10:45:27 --> Helper loaded: form_helper
INFO - 2023-01-06 10:45:27 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:45:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:45:27 --> Model "Change_model" initialized
INFO - 2023-01-06 10:45:50 --> Final output sent to browser
DEBUG - 2023-01-06 10:45:50 --> Total execution time: 180.2596
INFO - 2023-01-06 10:47:47 --> Config Class Initialized
INFO - 2023-01-06 10:47:47 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:47:47 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:47:47 --> Utf8 Class Initialized
INFO - 2023-01-06 10:47:47 --> URI Class Initialized
INFO - 2023-01-06 10:47:47 --> Router Class Initialized
INFO - 2023-01-06 10:47:47 --> Output Class Initialized
INFO - 2023-01-06 10:47:47 --> Security Class Initialized
DEBUG - 2023-01-06 10:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:47:47 --> Input Class Initialized
INFO - 2023-01-06 10:47:47 --> Language Class Initialized
INFO - 2023-01-06 10:47:47 --> Loader Class Initialized
INFO - 2023-01-06 10:47:47 --> Controller Class Initialized
INFO - 2023-01-06 10:47:47 --> Helper loaded: form_helper
INFO - 2023-01-06 10:47:47 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:47:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:47:47 --> Model "Change_model" initialized
INFO - 2023-01-06 10:48:10 --> Config Class Initialized
INFO - 2023-01-06 10:48:10 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:48:10 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:48:10 --> Utf8 Class Initialized
INFO - 2023-01-06 10:48:10 --> URI Class Initialized
INFO - 2023-01-06 10:48:10 --> Router Class Initialized
INFO - 2023-01-06 10:48:10 --> Output Class Initialized
INFO - 2023-01-06 10:48:10 --> Security Class Initialized
DEBUG - 2023-01-06 10:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:48:10 --> Input Class Initialized
INFO - 2023-01-06 10:48:10 --> Language Class Initialized
INFO - 2023-01-06 10:48:10 --> Loader Class Initialized
INFO - 2023-01-06 10:48:10 --> Controller Class Initialized
INFO - 2023-01-06 10:48:10 --> Helper loaded: form_helper
INFO - 2023-01-06 10:48:10 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:48:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:48:10 --> Model "Change_model" initialized
INFO - 2023-01-06 10:48:49 --> Config Class Initialized
INFO - 2023-01-06 10:48:49 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:48:49 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:48:49 --> Utf8 Class Initialized
INFO - 2023-01-06 10:48:49 --> URI Class Initialized
INFO - 2023-01-06 10:48:49 --> Router Class Initialized
INFO - 2023-01-06 10:48:49 --> Output Class Initialized
INFO - 2023-01-06 10:48:49 --> Security Class Initialized
DEBUG - 2023-01-06 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:48:49 --> Input Class Initialized
INFO - 2023-01-06 10:48:49 --> Language Class Initialized
INFO - 2023-01-06 10:48:49 --> Loader Class Initialized
INFO - 2023-01-06 10:48:49 --> Controller Class Initialized
INFO - 2023-01-06 10:48:49 --> Helper loaded: form_helper
INFO - 2023-01-06 10:48:49 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:48:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:48:49 --> Model "Change_model" initialized
INFO - 2023-01-06 10:49:05 --> Config Class Initialized
INFO - 2023-01-06 10:49:05 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:49:05 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:49:05 --> Utf8 Class Initialized
INFO - 2023-01-06 10:49:05 --> URI Class Initialized
INFO - 2023-01-06 10:49:05 --> Router Class Initialized
INFO - 2023-01-06 10:49:05 --> Output Class Initialized
INFO - 2023-01-06 10:49:05 --> Security Class Initialized
DEBUG - 2023-01-06 10:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:49:06 --> Input Class Initialized
INFO - 2023-01-06 10:49:06 --> Language Class Initialized
INFO - 2023-01-06 10:49:06 --> Loader Class Initialized
INFO - 2023-01-06 10:49:06 --> Controller Class Initialized
INFO - 2023-01-06 10:49:06 --> Helper loaded: form_helper
INFO - 2023-01-06 10:49:06 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:49:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:49:06 --> Model "Change_model" initialized
INFO - 2023-01-06 10:51:25 --> Config Class Initialized
INFO - 2023-01-06 10:51:25 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:51:25 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:51:25 --> Utf8 Class Initialized
INFO - 2023-01-06 10:51:25 --> URI Class Initialized
INFO - 2023-01-06 10:51:25 --> Router Class Initialized
INFO - 2023-01-06 10:51:25 --> Output Class Initialized
INFO - 2023-01-06 10:51:25 --> Security Class Initialized
DEBUG - 2023-01-06 10:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:51:25 --> Input Class Initialized
INFO - 2023-01-06 10:51:25 --> Language Class Initialized
INFO - 2023-01-06 10:51:25 --> Loader Class Initialized
INFO - 2023-01-06 10:51:25 --> Controller Class Initialized
INFO - 2023-01-06 10:51:25 --> Helper loaded: form_helper
INFO - 2023-01-06 10:51:25 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:51:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:51:25 --> Model "Change_model" initialized
INFO - 2023-01-06 10:53:35 --> Config Class Initialized
INFO - 2023-01-06 10:53:35 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:53:35 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:53:35 --> Utf8 Class Initialized
INFO - 2023-01-06 10:53:35 --> URI Class Initialized
INFO - 2023-01-06 10:53:35 --> Router Class Initialized
INFO - 2023-01-06 10:53:35 --> Output Class Initialized
INFO - 2023-01-06 10:53:35 --> Security Class Initialized
DEBUG - 2023-01-06 10:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:53:35 --> Input Class Initialized
INFO - 2023-01-06 10:53:35 --> Language Class Initialized
INFO - 2023-01-06 10:53:35 --> Loader Class Initialized
INFO - 2023-01-06 10:53:35 --> Controller Class Initialized
INFO - 2023-01-06 10:53:35 --> Helper loaded: form_helper
INFO - 2023-01-06 10:53:35 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:53:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:53:35 --> Model "Change_model" initialized
INFO - 2023-01-06 10:53:36 --> Config Class Initialized
INFO - 2023-01-06 10:53:36 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:53:36 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:53:36 --> Utf8 Class Initialized
INFO - 2023-01-06 10:53:36 --> URI Class Initialized
INFO - 2023-01-06 10:53:36 --> Router Class Initialized
INFO - 2023-01-06 10:53:36 --> Output Class Initialized
INFO - 2023-01-06 10:53:36 --> Security Class Initialized
DEBUG - 2023-01-06 10:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:53:36 --> Input Class Initialized
INFO - 2023-01-06 10:53:36 --> Language Class Initialized
INFO - 2023-01-06 10:53:36 --> Loader Class Initialized
INFO - 2023-01-06 10:53:36 --> Controller Class Initialized
INFO - 2023-01-06 10:53:36 --> Helper loaded: form_helper
INFO - 2023-01-06 10:53:36 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:53:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:53:36 --> Model "Change_model" initialized
INFO - 2023-01-06 10:53:37 --> Config Class Initialized
INFO - 2023-01-06 10:53:37 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:53:37 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:53:37 --> Utf8 Class Initialized
INFO - 2023-01-06 10:53:37 --> URI Class Initialized
INFO - 2023-01-06 10:53:37 --> Router Class Initialized
INFO - 2023-01-06 10:53:37 --> Output Class Initialized
INFO - 2023-01-06 10:53:37 --> Security Class Initialized
DEBUG - 2023-01-06 10:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:53:37 --> Input Class Initialized
INFO - 2023-01-06 10:53:37 --> Language Class Initialized
INFO - 2023-01-06 10:53:37 --> Loader Class Initialized
INFO - 2023-01-06 10:53:37 --> Controller Class Initialized
INFO - 2023-01-06 10:53:37 --> Helper loaded: form_helper
INFO - 2023-01-06 10:53:37 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:53:37 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:53:37 --> Model "Change_model" initialized
INFO - 2023-01-06 10:53:57 --> Config Class Initialized
INFO - 2023-01-06 10:53:57 --> Hooks Class Initialized
DEBUG - 2023-01-06 10:53:57 --> UTF-8 Support Enabled
INFO - 2023-01-06 10:53:57 --> Utf8 Class Initialized
INFO - 2023-01-06 10:53:57 --> URI Class Initialized
INFO - 2023-01-06 10:53:57 --> Router Class Initialized
INFO - 2023-01-06 10:53:57 --> Output Class Initialized
INFO - 2023-01-06 10:53:57 --> Security Class Initialized
DEBUG - 2023-01-06 10:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 10:53:57 --> Input Class Initialized
INFO - 2023-01-06 10:53:57 --> Language Class Initialized
INFO - 2023-01-06 10:53:57 --> Loader Class Initialized
INFO - 2023-01-06 10:53:57 --> Controller Class Initialized
INFO - 2023-01-06 10:53:57 --> Helper loaded: form_helper
INFO - 2023-01-06 10:53:57 --> Helper loaded: url_helper
DEBUG - 2023-01-06 10:53:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 10:53:57 --> Model "Change_model" initialized
INFO - 2023-01-06 11:09:48 --> Config Class Initialized
INFO - 2023-01-06 11:09:48 --> Hooks Class Initialized
DEBUG - 2023-01-06 11:09:48 --> UTF-8 Support Enabled
INFO - 2023-01-06 11:09:48 --> Utf8 Class Initialized
INFO - 2023-01-06 11:09:48 --> URI Class Initialized
INFO - 2023-01-06 11:09:48 --> Router Class Initialized
INFO - 2023-01-06 11:09:48 --> Output Class Initialized
INFO - 2023-01-06 11:09:48 --> Security Class Initialized
DEBUG - 2023-01-06 11:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-06 11:09:48 --> Input Class Initialized
INFO - 2023-01-06 11:09:48 --> Language Class Initialized
INFO - 2023-01-06 11:09:48 --> Loader Class Initialized
INFO - 2023-01-06 11:09:48 --> Controller Class Initialized
INFO - 2023-01-06 11:09:48 --> Helper loaded: form_helper
INFO - 2023-01-06 11:09:48 --> Helper loaded: url_helper
DEBUG - 2023-01-06 11:09:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-06 11:09:48 --> Model "Change_model" initialized
