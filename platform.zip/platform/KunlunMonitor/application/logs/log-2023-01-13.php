<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-13 01:43:53 --> Config Class Initialized
INFO - 2023-01-13 01:43:53 --> Hooks Class Initialized
DEBUG - 2023-01-13 01:43:53 --> UTF-8 Support Enabled
INFO - 2023-01-13 01:43:53 --> Utf8 Class Initialized
INFO - 2023-01-13 01:43:53 --> URI Class Initialized
INFO - 2023-01-13 01:43:53 --> Router Class Initialized
INFO - 2023-01-13 01:43:53 --> Output Class Initialized
INFO - 2023-01-13 01:43:53 --> Security Class Initialized
DEBUG - 2023-01-13 01:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 01:43:53 --> Input Class Initialized
INFO - 2023-01-13 01:43:53 --> Language Class Initialized
INFO - 2023-01-13 01:43:53 --> Loader Class Initialized
INFO - 2023-01-13 01:43:53 --> Controller Class Initialized
DEBUG - 2023-01-13 01:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 01:43:53 --> Database Driver Class Initialized
INFO - 2023-01-13 01:43:53 --> Model "Cluster_model" initialized
INFO - 2023-01-13 01:43:53 --> Final output sent to browser
DEBUG - 2023-01-13 01:43:53 --> Total execution time: 0.0736
INFO - 2023-01-13 01:43:53 --> Config Class Initialized
INFO - 2023-01-13 01:43:53 --> Hooks Class Initialized
DEBUG - 2023-01-13 01:43:53 --> UTF-8 Support Enabled
INFO - 2023-01-13 01:43:53 --> Utf8 Class Initialized
INFO - 2023-01-13 01:43:53 --> URI Class Initialized
INFO - 2023-01-13 01:43:53 --> Router Class Initialized
INFO - 2023-01-13 01:43:53 --> Output Class Initialized
INFO - 2023-01-13 01:43:53 --> Security Class Initialized
DEBUG - 2023-01-13 01:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 01:43:53 --> Input Class Initialized
INFO - 2023-01-13 01:43:53 --> Language Class Initialized
INFO - 2023-01-13 01:43:53 --> Loader Class Initialized
INFO - 2023-01-13 01:43:53 --> Controller Class Initialized
DEBUG - 2023-01-13 01:43:53 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 01:43:53 --> Database Driver Class Initialized
INFO - 2023-01-13 01:43:53 --> Model "Cluster_model" initialized
INFO - 2023-01-13 01:43:53 --> Final output sent to browser
DEBUG - 2023-01-13 01:43:53 --> Total execution time: 0.0819
INFO - 2023-01-13 02:32:04 --> Config Class Initialized
INFO - 2023-01-13 02:32:04 --> Hooks Class Initialized
INFO - 2023-01-13 02:32:04 --> Config Class Initialized
INFO - 2023-01-13 02:32:04 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:32:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 02:32:04 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:32:04 --> Utf8 Class Initialized
INFO - 2023-01-13 02:32:04 --> Utf8 Class Initialized
INFO - 2023-01-13 02:32:04 --> URI Class Initialized
INFO - 2023-01-13 02:32:04 --> URI Class Initialized
INFO - 2023-01-13 02:32:04 --> Router Class Initialized
INFO - 2023-01-13 02:32:04 --> Router Class Initialized
INFO - 2023-01-13 02:32:04 --> Output Class Initialized
INFO - 2023-01-13 02:32:04 --> Output Class Initialized
INFO - 2023-01-13 02:32:04 --> Security Class Initialized
INFO - 2023-01-13 02:32:04 --> Security Class Initialized
DEBUG - 2023-01-13 02:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:32:04 --> Input Class Initialized
INFO - 2023-01-13 02:32:04 --> Input Class Initialized
INFO - 2023-01-13 02:32:04 --> Language Class Initialized
INFO - 2023-01-13 02:32:04 --> Language Class Initialized
INFO - 2023-01-13 02:32:04 --> Loader Class Initialized
INFO - 2023-01-13 02:32:04 --> Loader Class Initialized
INFO - 2023-01-13 02:32:04 --> Controller Class Initialized
INFO - 2023-01-13 02:32:04 --> Controller Class Initialized
DEBUG - 2023-01-13 02:32:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-13 02:32:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 02:32:04 --> Final output sent to browser
DEBUG - 2023-01-13 02:32:04 --> Total execution time: 0.0054
INFO - 2023-01-13 02:32:04 --> Database Driver Class Initialized
INFO - 2023-01-13 02:32:04 --> Config Class Initialized
INFO - 2023-01-13 02:32:04 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:32:04 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:32:04 --> Utf8 Class Initialized
INFO - 2023-01-13 02:32:04 --> URI Class Initialized
INFO - 2023-01-13 02:32:04 --> Router Class Initialized
INFO - 2023-01-13 02:32:04 --> Output Class Initialized
INFO - 2023-01-13 02:32:04 --> Security Class Initialized
DEBUG - 2023-01-13 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:32:04 --> Input Class Initialized
INFO - 2023-01-13 02:32:04 --> Language Class Initialized
INFO - 2023-01-13 02:32:04 --> Loader Class Initialized
INFO - 2023-01-13 02:32:04 --> Controller Class Initialized
DEBUG - 2023-01-13 02:32:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 02:32:04 --> Database Driver Class Initialized
INFO - 2023-01-13 02:32:04 --> Model "Cluster_model" initialized
INFO - 2023-01-13 02:32:04 --> Model "Login_model" initialized
INFO - 2023-01-13 02:32:04 --> Database Driver Class Initialized
INFO - 2023-01-13 02:32:04 --> Final output sent to browser
DEBUG - 2023-01-13 02:32:04 --> Total execution time: 0.0671
INFO - 2023-01-13 02:32:04 --> Config Class Initialized
INFO - 2023-01-13 02:32:04 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:32:04 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:32:04 --> Utf8 Class Initialized
INFO - 2023-01-13 02:32:04 --> URI Class Initialized
INFO - 2023-01-13 02:32:04 --> Router Class Initialized
INFO - 2023-01-13 02:32:04 --> Model "Cluster_model" initialized
INFO - 2023-01-13 02:32:04 --> Output Class Initialized
INFO - 2023-01-13 02:32:04 --> Security Class Initialized
DEBUG - 2023-01-13 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:32:04 --> Input Class Initialized
INFO - 2023-01-13 02:32:04 --> Language Class Initialized
INFO - 2023-01-13 02:32:04 --> Loader Class Initialized
INFO - 2023-01-13 02:32:04 --> Controller Class Initialized
DEBUG - 2023-01-13 02:32:04 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 02:32:04 --> Database Driver Class Initialized
INFO - 2023-01-13 02:32:04 --> Final output sent to browser
DEBUG - 2023-01-13 02:32:04 --> Total execution time: 0.0652
INFO - 2023-01-13 02:32:04 --> Model "Cluster_model" initialized
INFO - 2023-01-13 02:32:04 --> Final output sent to browser
DEBUG - 2023-01-13 02:32:04 --> Total execution time: 0.0549
INFO - 2023-01-13 02:47:54 --> Config Class Initialized
INFO - 2023-01-13 02:47:54 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:47:54 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:47:54 --> Utf8 Class Initialized
INFO - 2023-01-13 02:47:54 --> URI Class Initialized
INFO - 2023-01-13 02:47:54 --> Router Class Initialized
INFO - 2023-01-13 02:47:54 --> Output Class Initialized
INFO - 2023-01-13 02:47:54 --> Security Class Initialized
DEBUG - 2023-01-13 02:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:47:54 --> Input Class Initialized
INFO - 2023-01-13 02:47:54 --> Language Class Initialized
INFO - 2023-01-13 02:47:54 --> Loader Class Initialized
INFO - 2023-01-13 02:47:54 --> Controller Class Initialized
DEBUG - 2023-01-13 02:47:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 02:47:54 --> Database Driver Class Initialized
INFO - 2023-01-13 02:47:54 --> Model "Cluster_model" initialized
INFO - 2023-01-13 02:47:54 --> Final output sent to browser
DEBUG - 2023-01-13 02:47:54 --> Total execution time: 0.0472
INFO - 2023-01-13 02:47:54 --> Config Class Initialized
INFO - 2023-01-13 02:47:54 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:47:54 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:47:54 --> Utf8 Class Initialized
INFO - 2023-01-13 02:47:54 --> URI Class Initialized
INFO - 2023-01-13 02:47:54 --> Router Class Initialized
INFO - 2023-01-13 02:47:54 --> Output Class Initialized
INFO - 2023-01-13 02:47:54 --> Security Class Initialized
DEBUG - 2023-01-13 02:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:47:54 --> Input Class Initialized
INFO - 2023-01-13 02:47:54 --> Language Class Initialized
INFO - 2023-01-13 02:47:54 --> Loader Class Initialized
INFO - 2023-01-13 02:47:54 --> Controller Class Initialized
DEBUG - 2023-01-13 02:47:54 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 02:47:54 --> Database Driver Class Initialized
INFO - 2023-01-13 02:47:54 --> Model "Cluster_model" initialized
INFO - 2023-01-13 02:47:54 --> Final output sent to browser
DEBUG - 2023-01-13 02:47:54 --> Total execution time: 0.0863
INFO - 2023-01-13 02:47:56 --> Config Class Initialized
INFO - 2023-01-13 02:47:56 --> Config Class Initialized
INFO - 2023-01-13 02:47:56 --> Hooks Class Initialized
INFO - 2023-01-13 02:47:56 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:47:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 02:47:56 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:47:56 --> Utf8 Class Initialized
INFO - 2023-01-13 02:47:56 --> Utf8 Class Initialized
INFO - 2023-01-13 02:47:56 --> URI Class Initialized
INFO - 2023-01-13 02:47:56 --> URI Class Initialized
INFO - 2023-01-13 02:47:56 --> Router Class Initialized
INFO - 2023-01-13 02:47:56 --> Router Class Initialized
INFO - 2023-01-13 02:47:56 --> Output Class Initialized
INFO - 2023-01-13 02:47:56 --> Output Class Initialized
INFO - 2023-01-13 02:47:56 --> Security Class Initialized
INFO - 2023-01-13 02:47:56 --> Security Class Initialized
DEBUG - 2023-01-13 02:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 02:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:47:56 --> Input Class Initialized
INFO - 2023-01-13 02:47:56 --> Input Class Initialized
INFO - 2023-01-13 02:47:56 --> Language Class Initialized
INFO - 2023-01-13 02:47:56 --> Language Class Initialized
INFO - 2023-01-13 02:47:56 --> Loader Class Initialized
INFO - 2023-01-13 02:47:56 --> Loader Class Initialized
INFO - 2023-01-13 02:47:56 --> Controller Class Initialized
INFO - 2023-01-13 02:47:56 --> Controller Class Initialized
DEBUG - 2023-01-13 02:47:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
DEBUG - 2023-01-13 02:47:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 02:47:56 --> Final output sent to browser
INFO - 2023-01-13 02:47:56 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:47:56 --> Total execution time: 0.0047
INFO - 2023-01-13 02:47:56 --> Config Class Initialized
INFO - 2023-01-13 02:47:56 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:47:56 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:47:56 --> Utf8 Class Initialized
INFO - 2023-01-13 02:47:56 --> URI Class Initialized
INFO - 2023-01-13 02:47:56 --> Router Class Initialized
INFO - 2023-01-13 02:47:56 --> Output Class Initialized
INFO - 2023-01-13 02:47:56 --> Security Class Initialized
DEBUG - 2023-01-13 02:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:47:56 --> Input Class Initialized
INFO - 2023-01-13 02:47:56 --> Language Class Initialized
INFO - 2023-01-13 02:47:56 --> Loader Class Initialized
INFO - 2023-01-13 02:47:56 --> Controller Class Initialized
DEBUG - 2023-01-13 02:47:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 02:47:56 --> Database Driver Class Initialized
INFO - 2023-01-13 02:47:56 --> Model "Cluster_model" initialized
INFO - 2023-01-13 02:47:56 --> Model "Login_model" initialized
INFO - 2023-01-13 02:47:56 --> Final output sent to browser
INFO - 2023-01-13 02:47:56 --> Database Driver Class Initialized
DEBUG - 2023-01-13 02:47:56 --> Total execution time: 0.0199
INFO - 2023-01-13 02:47:56 --> Config Class Initialized
INFO - 2023-01-13 02:47:56 --> Hooks Class Initialized
DEBUG - 2023-01-13 02:47:56 --> UTF-8 Support Enabled
INFO - 2023-01-13 02:47:56 --> Utf8 Class Initialized
INFO - 2023-01-13 02:47:56 --> URI Class Initialized
INFO - 2023-01-13 02:47:56 --> Router Class Initialized
INFO - 2023-01-13 02:47:56 --> Output Class Initialized
INFO - 2023-01-13 02:47:56 --> Security Class Initialized
DEBUG - 2023-01-13 02:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 02:47:56 --> Input Class Initialized
INFO - 2023-01-13 02:47:56 --> Language Class Initialized
INFO - 2023-01-13 02:47:56 --> Loader Class Initialized
INFO - 2023-01-13 02:47:56 --> Controller Class Initialized
DEBUG - 2023-01-13 02:47:56 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 02:47:56 --> Database Driver Class Initialized
INFO - 2023-01-13 02:47:56 --> Model "Cluster_model" initialized
INFO - 2023-01-13 02:47:56 --> Final output sent to browser
DEBUG - 2023-01-13 02:47:56 --> Total execution time: 0.0228
INFO - 2023-01-13 02:47:56 --> Model "Cluster_model" initialized
INFO - 2023-01-13 02:47:56 --> Final output sent to browser
DEBUG - 2023-01-13 02:47:56 --> Total execution time: 0.0531
INFO - 2023-01-13 03:10:05 --> Config Class Initialized
INFO - 2023-01-13 03:10:05 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:10:05 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:10:05 --> Utf8 Class Initialized
INFO - 2023-01-13 03:10:05 --> URI Class Initialized
INFO - 2023-01-13 03:10:05 --> Router Class Initialized
INFO - 2023-01-13 03:10:05 --> Output Class Initialized
INFO - 2023-01-13 03:10:05 --> Security Class Initialized
DEBUG - 2023-01-13 03:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:10:05 --> Input Class Initialized
INFO - 2023-01-13 03:10:05 --> Language Class Initialized
INFO - 2023-01-13 03:10:05 --> Loader Class Initialized
INFO - 2023-01-13 03:10:05 --> Controller Class Initialized
DEBUG - 2023-01-13 03:10:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 03:10:05 --> Database Driver Class Initialized
INFO - 2023-01-13 03:10:05 --> Model "Cluster_model" initialized
INFO - 2023-01-13 03:10:05 --> Final output sent to browser
DEBUG - 2023-01-13 03:10:05 --> Total execution time: 0.0536
INFO - 2023-01-13 03:10:05 --> Config Class Initialized
INFO - 2023-01-13 03:10:05 --> Hooks Class Initialized
DEBUG - 2023-01-13 03:10:05 --> UTF-8 Support Enabled
INFO - 2023-01-13 03:10:05 --> Utf8 Class Initialized
INFO - 2023-01-13 03:10:05 --> URI Class Initialized
INFO - 2023-01-13 03:10:05 --> Router Class Initialized
INFO - 2023-01-13 03:10:05 --> Output Class Initialized
INFO - 2023-01-13 03:10:05 --> Security Class Initialized
DEBUG - 2023-01-13 03:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 03:10:05 --> Input Class Initialized
INFO - 2023-01-13 03:10:05 --> Language Class Initialized
INFO - 2023-01-13 03:10:05 --> Loader Class Initialized
INFO - 2023-01-13 03:10:05 --> Controller Class Initialized
DEBUG - 2023-01-13 03:10:05 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 03:10:05 --> Database Driver Class Initialized
INFO - 2023-01-13 03:10:05 --> Model "Cluster_model" initialized
INFO - 2023-01-13 03:10:05 --> Final output sent to browser
DEBUG - 2023-01-13 03:10:05 --> Total execution time: 0.0402
INFO - 2023-01-13 10:09:42 --> Config Class Initialized
INFO - 2023-01-13 10:09:42 --> Hooks Class Initialized
DEBUG - 2023-01-13 10:09:42 --> UTF-8 Support Enabled
INFO - 2023-01-13 10:09:42 --> Utf8 Class Initialized
INFO - 2023-01-13 10:09:42 --> URI Class Initialized
INFO - 2023-01-13 10:09:42 --> Router Class Initialized
INFO - 2023-01-13 10:09:42 --> Output Class Initialized
INFO - 2023-01-13 10:09:42 --> Security Class Initialized
DEBUG - 2023-01-13 10:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-13 10:09:42 --> Input Class Initialized
INFO - 2023-01-13 10:09:42 --> Language Class Initialized
INFO - 2023-01-13 10:09:42 --> Loader Class Initialized
INFO - 2023-01-13 10:09:42 --> Controller Class Initialized
DEBUG - 2023-01-13 10:09:42 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-01-13 10:09:42 --> Database Driver Class Initialized
ERROR - 2023-01-13 10:09:49 --> Unable to connect to the database
INFO - 2023-01-13 10:09:49 --> Language file loaded: language/english/db_lang.php
