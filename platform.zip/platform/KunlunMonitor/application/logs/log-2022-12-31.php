<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-31 02:14:10 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:10 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:10 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:10 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:10 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:10 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
ERROR - 2022-12-31 02:14:10 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:10 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
ERROR - 2022-12-31 02:14:10 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:14:10 --> Config Class Initialized
INFO - 2022-12-31 02:14:10 --> Config Class Initialized
INFO - 2022-12-31 02:14:10 --> Config Class Initialized
INFO - 2022-12-31 02:14:10 --> Hooks Class Initialized
INFO - 2022-12-31 02:14:10 --> Hooks Class Initialized
INFO - 2022-12-31 02:14:10 --> Hooks Class Initialized
ERROR - 2022-12-31 02:14:10 --> Unable to connect to the database
INFO - 2022-12-31 02:14:10 --> Model "Login_model" initialized
DEBUG - 2022-12-31 02:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 02:14:10 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:10 --> Utf8 Class Initialized
DEBUG - 2022-12-31 02:14:10 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:10 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:10 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:10 --> URI Class Initialized
INFO - 2022-12-31 02:14:10 --> URI Class Initialized
INFO - 2022-12-31 02:14:10 --> URI Class Initialized
INFO - 2022-12-31 02:14:10 --> Router Class Initialized
INFO - 2022-12-31 02:14:10 --> Router Class Initialized
INFO - 2022-12-31 02:14:10 --> Router Class Initialized
INFO - 2022-12-31 02:14:10 --> Output Class Initialized
INFO - 2022-12-31 02:14:10 --> Output Class Initialized
INFO - 2022-12-31 02:14:10 --> Output Class Initialized
INFO - 2022-12-31 02:14:10 --> Security Class Initialized
INFO - 2022-12-31 02:14:10 --> Security Class Initialized
INFO - 2022-12-31 02:14:10 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:10 --> Input Class Initialized
DEBUG - 2022-12-31 02:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 02:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:10 --> Input Class Initialized
INFO - 2022-12-31 02:14:10 --> Input Class Initialized
INFO - 2022-12-31 02:14:10 --> Language Class Initialized
INFO - 2022-12-31 02:14:10 --> Language Class Initialized
INFO - 2022-12-31 02:14:10 --> Language Class Initialized
INFO - 2022-12-31 02:14:10 --> Loader Class Initialized
INFO - 2022-12-31 02:14:10 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:10 --> Loader Class Initialized
INFO - 2022-12-31 02:14:10 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:10 --> Loader Class Initialized
INFO - 2022-12-31 02:14:10 --> Controller Class Initialized
INFO - 2022-12-31 02:14:10 --> Database Driver Class Initialized
DEBUG - 2022-12-31 02:14:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:10 --> Database Driver Class Initialized
INFO - 2022-12-31 02:14:10 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:10 --> Unable to connect to the database
INFO - 2022-12-31 02:14:10 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:14:10 --> Config Class Initialized
INFO - 2022-12-31 02:14:10 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:10 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:10 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:10 --> URI Class Initialized
INFO - 2022-12-31 02:14:10 --> Router Class Initialized
INFO - 2022-12-31 02:14:10 --> Output Class Initialized
INFO - 2022-12-31 02:14:10 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:10 --> Input Class Initialized
INFO - 2022-12-31 02:14:10 --> Language Class Initialized
INFO - 2022-12-31 02:14:11 --> Loader Class Initialized
INFO - 2022-12-31 02:14:11 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:11 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:20 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:20 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:20 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:14:20 --> Config Class Initialized
INFO - 2022-12-31 02:14:20 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:20 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:20 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:20 --> URI Class Initialized
INFO - 2022-12-31 02:14:20 --> Router Class Initialized
INFO - 2022-12-31 02:14:20 --> Output Class Initialized
INFO - 2022-12-31 02:14:20 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:20 --> Input Class Initialized
INFO - 2022-12-31 02:14:20 --> Language Class Initialized
INFO - 2022-12-31 02:14:20 --> Loader Class Initialized
INFO - 2022-12-31 02:14:20 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:20 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:20 --> Unable to connect to the database
INFO - 2022-12-31 02:14:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-12-31 02:14:20 --> Unable to connect to the database
INFO - 2022-12-31 02:14:20 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:14:20 --> Unable to connect to the database
INFO - 2022-12-31 02:14:20 --> Model "Login_model" initialized
INFO - 2022-12-31 02:14:20 --> Config Class Initialized
INFO - 2022-12-31 02:14:20 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:20 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:20 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:20 --> URI Class Initialized
INFO - 2022-12-31 02:14:20 --> Router Class Initialized
INFO - 2022-12-31 02:14:21 --> Output Class Initialized
INFO - 2022-12-31 02:14:21 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:21 --> Input Class Initialized
INFO - 2022-12-31 02:14:21 --> Language Class Initialized
INFO - 2022-12-31 02:14:21 --> Loader Class Initialized
INFO - 2022-12-31 02:14:21 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-31 02:14:21 --> Unable to connect to the database
INFO - 2022-12-31 02:14:21 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:14:21 --> Database Driver Class Initialized
INFO - 2022-12-31 02:14:21 --> Config Class Initialized
INFO - 2022-12-31 02:14:21 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:21 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:21 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:21 --> URI Class Initialized
INFO - 2022-12-31 02:14:21 --> Router Class Initialized
INFO - 2022-12-31 02:14:21 --> Output Class Initialized
INFO - 2022-12-31 02:14:21 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:21 --> Input Class Initialized
INFO - 2022-12-31 02:14:21 --> Language Class Initialized
INFO - 2022-12-31 02:14:21 --> Loader Class Initialized
INFO - 2022-12-31 02:14:21 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:21 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:30 --> Unable to connect to the database
INFO - 2022-12-31 02:14:30 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:14:30 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:30 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:30 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:30 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:30 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
ERROR - 2022-12-31 02:14:30 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:14:30 --> Config Class Initialized
INFO - 2022-12-31 02:14:30 --> Hooks Class Initialized
INFO - 2022-12-31 02:14:30 --> Config Class Initialized
INFO - 2022-12-31 02:14:30 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 02:14:30 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:30 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:30 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:30 --> URI Class Initialized
INFO - 2022-12-31 02:14:30 --> URI Class Initialized
INFO - 2022-12-31 02:14:30 --> Router Class Initialized
INFO - 2022-12-31 02:14:30 --> Router Class Initialized
INFO - 2022-12-31 02:14:30 --> Output Class Initialized
INFO - 2022-12-31 02:14:30 --> Output Class Initialized
INFO - 2022-12-31 02:14:30 --> Security Class Initialized
INFO - 2022-12-31 02:14:30 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 02:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:30 --> Input Class Initialized
INFO - 2022-12-31 02:14:30 --> Input Class Initialized
INFO - 2022-12-31 02:14:30 --> Language Class Initialized
INFO - 2022-12-31 02:14:30 --> Language Class Initialized
INFO - 2022-12-31 02:14:30 --> Loader Class Initialized
INFO - 2022-12-31 02:14:30 --> Loader Class Initialized
INFO - 2022-12-31 02:14:30 --> Controller Class Initialized
INFO - 2022-12-31 02:14:30 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-31 02:14:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:30 --> Database Driver Class Initialized
INFO - 2022-12-31 02:14:30 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:31 --> Unable to connect to the database
INFO - 2022-12-31 02:14:31 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:14:31 --> Config Class Initialized
INFO - 2022-12-31 02:14:31 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:31 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:31 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:31 --> URI Class Initialized
INFO - 2022-12-31 02:14:31 --> Router Class Initialized
INFO - 2022-12-31 02:14:31 --> Output Class Initialized
INFO - 2022-12-31 02:14:31 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:31 --> Input Class Initialized
INFO - 2022-12-31 02:14:31 --> Language Class Initialized
INFO - 2022-12-31 02:14:31 --> Loader Class Initialized
ERROR - 2022-12-31 02:14:31 --> Unable to connect to the database
INFO - 2022-12-31 02:14:31 --> Model "Login_model" initialized
INFO - 2022-12-31 02:14:31 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:31 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:40 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:40 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:40 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:14:40 --> Config Class Initialized
INFO - 2022-12-31 02:14:40 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:40 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:40 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:40 --> URI Class Initialized
INFO - 2022-12-31 02:14:40 --> Router Class Initialized
INFO - 2022-12-31 02:14:40 --> Output Class Initialized
INFO - 2022-12-31 02:14:40 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:40 --> Input Class Initialized
INFO - 2022-12-31 02:14:40 --> Language Class Initialized
INFO - 2022-12-31 02:14:40 --> Loader Class Initialized
INFO - 2022-12-31 02:14:40 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:40 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:40 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:40 --> Unable to connect to the database
INFO - 2022-12-31 02:14:40 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:14:40 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:14:40 --> Config Class Initialized
INFO - 2022-12-31 02:14:40 --> Config Class Initialized
INFO - 2022-12-31 02:14:40 --> Hooks Class Initialized
INFO - 2022-12-31 02:14:40 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-31 02:14:40 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:40 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:40 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:40 --> URI Class Initialized
INFO - 2022-12-31 02:14:40 --> URI Class Initialized
INFO - 2022-12-31 02:14:40 --> Router Class Initialized
INFO - 2022-12-31 02:14:40 --> Router Class Initialized
INFO - 2022-12-31 02:14:40 --> Output Class Initialized
INFO - 2022-12-31 02:14:40 --> Output Class Initialized
INFO - 2022-12-31 02:14:40 --> Security Class Initialized
INFO - 2022-12-31 02:14:40 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 02:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:40 --> Input Class Initialized
INFO - 2022-12-31 02:14:40 --> Input Class Initialized
INFO - 2022-12-31 02:14:40 --> Language Class Initialized
INFO - 2022-12-31 02:14:40 --> Language Class Initialized
INFO - 2022-12-31 02:14:40 --> Loader Class Initialized
INFO - 2022-12-31 02:14:40 --> Loader Class Initialized
INFO - 2022-12-31 02:14:40 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:40 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:40 --> Database Driver Class Initialized
INFO - 2022-12-31 02:14:40 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:41 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:41 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:41 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
ERROR - 2022-12-31 02:14:41 --> Unable to connect to the database
INFO - 2022-12-31 02:14:41 --> Model "Login_model" initialized
INFO - 2022-12-31 02:14:41 --> Config Class Initialized
INFO - 2022-12-31 02:14:41 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:41 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:41 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:41 --> URI Class Initialized
INFO - 2022-12-31 02:14:41 --> Router Class Initialized
INFO - 2022-12-31 02:14:41 --> Output Class Initialized
INFO - 2022-12-31 02:14:41 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:41 --> Input Class Initialized
INFO - 2022-12-31 02:14:41 --> Language Class Initialized
INFO - 2022-12-31 02:14:41 --> Loader Class Initialized
INFO - 2022-12-31 02:14:41 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:42 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:50 --> Unable to connect to the database
INFO - 2022-12-31 02:14:50 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:14:50 --> Unable to connect to the database
INFO - 2022-12-31 02:14:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-12-31 02:14:50 --> Unable to connect to the database
INFO - 2022-12-31 02:14:50 --> Model "Login_model" initialized
INFO - 2022-12-31 02:14:50 --> Config Class Initialized
INFO - 2022-12-31 02:14:50 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:50 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:50 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:50 --> URI Class Initialized
INFO - 2022-12-31 02:14:50 --> Router Class Initialized
INFO - 2022-12-31 02:14:50 --> Output Class Initialized
INFO - 2022-12-31 02:14:50 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:50 --> Input Class Initialized
INFO - 2022-12-31 02:14:50 --> Language Class Initialized
INFO - 2022-12-31 02:14:50 --> Loader Class Initialized
INFO - 2022-12-31 02:14:50 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:50 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:51 --> Unable to connect to the database
ERROR - 2022-12-31 02:14:51 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:14:51 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:14:51 --> Config Class Initialized
INFO - 2022-12-31 02:14:51 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:51 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:51 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:51 --> URI Class Initialized
INFO - 2022-12-31 02:14:51 --> Router Class Initialized
INFO - 2022-12-31 02:14:51 --> Output Class Initialized
INFO - 2022-12-31 02:14:51 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:51 --> Input Class Initialized
INFO - 2022-12-31 02:14:51 --> Language Class Initialized
INFO - 2022-12-31 02:14:52 --> Loader Class Initialized
INFO - 2022-12-31 02:14:52 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:52 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:14:52 --> Unable to connect to the database
INFO - 2022-12-31 02:14:52 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:14:52 --> Config Class Initialized
INFO - 2022-12-31 02:14:52 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:14:52 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:14:52 --> Utf8 Class Initialized
INFO - 2022-12-31 02:14:52 --> URI Class Initialized
INFO - 2022-12-31 02:14:52 --> Router Class Initialized
INFO - 2022-12-31 02:14:52 --> Output Class Initialized
INFO - 2022-12-31 02:14:52 --> Security Class Initialized
DEBUG - 2022-12-31 02:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:14:52 --> Input Class Initialized
INFO - 2022-12-31 02:14:52 --> Language Class Initialized
INFO - 2022-12-31 02:14:52 --> Loader Class Initialized
INFO - 2022-12-31 02:14:52 --> Controller Class Initialized
DEBUG - 2022-12-31 02:14:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:14:52 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:00 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:00 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:00 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:00 --> Config Class Initialized
INFO - 2022-12-31 02:15:00 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:00 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:00 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:00 --> URI Class Initialized
INFO - 2022-12-31 02:15:00 --> Router Class Initialized
INFO - 2022-12-31 02:15:00 --> Output Class Initialized
INFO - 2022-12-31 02:15:00 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:00 --> Input Class Initialized
INFO - 2022-12-31 02:15:00 --> Language Class Initialized
INFO - 2022-12-31 02:15:00 --> Loader Class Initialized
INFO - 2022-12-31 02:15:00 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:00 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:00 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:00 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:00 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:00 --> Config Class Initialized
INFO - 2022-12-31 02:15:00 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:00 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:00 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:00 --> URI Class Initialized
INFO - 2022-12-31 02:15:00 --> Router Class Initialized
INFO - 2022-12-31 02:15:00 --> Output Class Initialized
INFO - 2022-12-31 02:15:00 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:00 --> Input Class Initialized
INFO - 2022-12-31 02:15:00 --> Language Class Initialized
INFO - 2022-12-31 02:15:00 --> Loader Class Initialized
INFO - 2022-12-31 02:15:00 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:00 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-31 02:15:01 --> Unable to connect to the database
INFO - 2022-12-31 02:15:01 --> Model "Login_model" initialized
INFO - 2022-12-31 02:15:01 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:02 --> Unable to connect to the database
INFO - 2022-12-31 02:15:02 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:15:02 --> Config Class Initialized
INFO - 2022-12-31 02:15:02 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:02 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:02 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:02 --> URI Class Initialized
INFO - 2022-12-31 02:15:02 --> Router Class Initialized
INFO - 2022-12-31 02:15:02 --> Output Class Initialized
INFO - 2022-12-31 02:15:02 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:02 --> Input Class Initialized
INFO - 2022-12-31 02:15:02 --> Language Class Initialized
INFO - 2022-12-31 02:15:02 --> Loader Class Initialized
INFO - 2022-12-31 02:15:02 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:02 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:02 --> Unable to connect to the database
INFO - 2022-12-31 02:15:02 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:15:10 --> Unable to connect to the database
INFO - 2022-12-31 02:15:10 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:15:10 --> Config Class Initialized
INFO - 2022-12-31 02:15:10 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:10 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:10 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:10 --> URI Class Initialized
INFO - 2022-12-31 02:15:10 --> Router Class Initialized
INFO - 2022-12-31 02:15:10 --> Output Class Initialized
INFO - 2022-12-31 02:15:10 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:10 --> Input Class Initialized
INFO - 2022-12-31 02:15:10 --> Language Class Initialized
INFO - 2022-12-31 02:15:10 --> Loader Class Initialized
INFO - 2022-12-31 02:15:10 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:10 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:11 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:11 --> Unable to connect to the database
INFO - 2022-12-31 02:15:11 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:15:11 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:11 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:11 --> Config Class Initialized
INFO - 2022-12-31 02:15:11 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:11 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:11 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:11 --> URI Class Initialized
INFO - 2022-12-31 02:15:11 --> Router Class Initialized
INFO - 2022-12-31 02:15:11 --> Output Class Initialized
INFO - 2022-12-31 02:15:11 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:11 --> Input Class Initialized
INFO - 2022-12-31 02:15:11 --> Language Class Initialized
INFO - 2022-12-31 02:15:11 --> Loader Class Initialized
INFO - 2022-12-31 02:15:11 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:11 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:12 --> Unable to connect to the database
INFO - 2022-12-31 02:15:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-12-31 02:15:12 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:12 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:12 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:12 --> Config Class Initialized
INFO - 2022-12-31 02:15:12 --> Hooks Class Initialized
INFO - 2022-12-31 02:15:12 --> Config Class Initialized
INFO - 2022-12-31 02:15:12 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:12 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:12 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:12 --> URI Class Initialized
DEBUG - 2022-12-31 02:15:12 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:12 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:12 --> Router Class Initialized
INFO - 2022-12-31 02:15:12 --> URI Class Initialized
INFO - 2022-12-31 02:15:12 --> Router Class Initialized
INFO - 2022-12-31 02:15:12 --> Output Class Initialized
INFO - 2022-12-31 02:15:12 --> Output Class Initialized
INFO - 2022-12-31 02:15:12 --> Security Class Initialized
INFO - 2022-12-31 02:15:12 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:12 --> Input Class Initialized
DEBUG - 2022-12-31 02:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:12 --> Input Class Initialized
INFO - 2022-12-31 02:15:12 --> Language Class Initialized
INFO - 2022-12-31 02:15:12 --> Language Class Initialized
INFO - 2022-12-31 02:15:12 --> Loader Class Initialized
INFO - 2022-12-31 02:15:12 --> Loader Class Initialized
INFO - 2022-12-31 02:15:12 --> Controller Class Initialized
INFO - 2022-12-31 02:15:12 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-31 02:15:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:12 --> Database Driver Class Initialized
INFO - 2022-12-31 02:15:12 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:20 --> Unable to connect to the database
INFO - 2022-12-31 02:15:20 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:15:21 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:21 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:21 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:21 --> Config Class Initialized
INFO - 2022-12-31 02:15:21 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:21 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:21 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:21 --> URI Class Initialized
INFO - 2022-12-31 02:15:21 --> Router Class Initialized
INFO - 2022-12-31 02:15:21 --> Output Class Initialized
INFO - 2022-12-31 02:15:21 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:21 --> Input Class Initialized
INFO - 2022-12-31 02:15:21 --> Language Class Initialized
INFO - 2022-12-31 02:15:21 --> Loader Class Initialized
ERROR - 2022-12-31 02:15:21 --> Unable to connect to the database
INFO - 2022-12-31 02:15:21 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:15:21 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:21 --> Database Driver Class Initialized
INFO - 2022-12-31 02:15:21 --> Config Class Initialized
INFO - 2022-12-31 02:15:21 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:21 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:21 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:21 --> URI Class Initialized
INFO - 2022-12-31 02:15:21 --> Router Class Initialized
INFO - 2022-12-31 02:15:21 --> Output Class Initialized
INFO - 2022-12-31 02:15:21 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:21 --> Input Class Initialized
INFO - 2022-12-31 02:15:21 --> Language Class Initialized
INFO - 2022-12-31 02:15:21 --> Loader Class Initialized
INFO - 2022-12-31 02:15:21 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:21 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:22 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:22 --> Unable to connect to the database
INFO - 2022-12-31 02:15:22 --> Model "Login_model" initialized
INFO - 2022-12-31 02:15:22 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:15:22 --> Config Class Initialized
INFO - 2022-12-31 02:15:22 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:22 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:22 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:22 --> URI Class Initialized
INFO - 2022-12-31 02:15:22 --> Router Class Initialized
INFO - 2022-12-31 02:15:22 --> Output Class Initialized
INFO - 2022-12-31 02:15:22 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:22 --> Input Class Initialized
INFO - 2022-12-31 02:15:22 --> Language Class Initialized
INFO - 2022-12-31 02:15:22 --> Loader Class Initialized
INFO - 2022-12-31 02:15:22 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:22 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:30 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:30 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:30 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:30 --> Config Class Initialized
INFO - 2022-12-31 02:15:30 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:30 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:30 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:30 --> URI Class Initialized
INFO - 2022-12-31 02:15:30 --> Router Class Initialized
INFO - 2022-12-31 02:15:30 --> Output Class Initialized
INFO - 2022-12-31 02:15:30 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:30 --> Input Class Initialized
INFO - 2022-12-31 02:15:30 --> Language Class Initialized
INFO - 2022-12-31 02:15:30 --> Loader Class Initialized
INFO - 2022-12-31 02:15:30 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:30 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:31 --> Unable to connect to the database
INFO - 2022-12-31 02:15:31 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:15:31 --> Unable to connect to the database
INFO - 2022-12-31 02:15:31 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:15:31 --> Config Class Initialized
INFO - 2022-12-31 02:15:31 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:31 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:31 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:31 --> URI Class Initialized
INFO - 2022-12-31 02:15:31 --> Router Class Initialized
INFO - 2022-12-31 02:15:31 --> Output Class Initialized
INFO - 2022-12-31 02:15:31 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:31 --> Input Class Initialized
INFO - 2022-12-31 02:15:31 --> Language Class Initialized
INFO - 2022-12-31 02:15:31 --> Loader Class Initialized
INFO - 2022-12-31 02:15:31 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:31 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:32 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:32 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:32 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:32 --> Config Class Initialized
INFO - 2022-12-31 02:15:32 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:32 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:32 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:32 --> URI Class Initialized
INFO - 2022-12-31 02:15:32 --> Router Class Initialized
INFO - 2022-12-31 02:15:32 --> Output Class Initialized
INFO - 2022-12-31 02:15:32 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:32 --> Input Class Initialized
INFO - 2022-12-31 02:15:32 --> Language Class Initialized
ERROR - 2022-12-31 02:15:32 --> Unable to connect to the database
INFO - 2022-12-31 02:15:32 --> Model "Login_model" initialized
INFO - 2022-12-31 02:15:32 --> Loader Class Initialized
INFO - 2022-12-31 02:15:32 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:32 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:40 --> Unable to connect to the database
INFO - 2022-12-31 02:15:40 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:15:41 --> Config Class Initialized
INFO - 2022-12-31 02:15:41 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:41 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:41 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:41 --> URI Class Initialized
INFO - 2022-12-31 02:15:41 --> Router Class Initialized
INFO - 2022-12-31 02:15:41 --> Output Class Initialized
INFO - 2022-12-31 02:15:41 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:41 --> Input Class Initialized
INFO - 2022-12-31 02:15:41 --> Language Class Initialized
INFO - 2022-12-31 02:15:41 --> Loader Class Initialized
INFO - 2022-12-31 02:15:41 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:41 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:41 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:41 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:41 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:41 --> Config Class Initialized
INFO - 2022-12-31 02:15:41 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:41 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:41 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:41 --> URI Class Initialized
INFO - 2022-12-31 02:15:41 --> Router Class Initialized
INFO - 2022-12-31 02:15:41 --> Output Class Initialized
INFO - 2022-12-31 02:15:41 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:41 --> Input Class Initialized
INFO - 2022-12-31 02:15:41 --> Language Class Initialized
INFO - 2022-12-31 02:15:41 --> Loader Class Initialized
INFO - 2022-12-31 02:15:41 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:41 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:41 --> Unable to connect to the database
INFO - 2022-12-31 02:15:41 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:15:42 --> Unable to connect to the database
ERROR - 2022-12-31 02:15:42 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:15:42 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:42 --> Config Class Initialized
ERROR - 2022-12-31 02:15:42 --> Unable to connect to the database
INFO - 2022-12-31 02:15:42 --> Hooks Class Initialized
INFO - 2022-12-31 02:15:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2022-12-31 02:15:42 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:42 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:42 --> URI Class Initialized
INFO - 2022-12-31 02:15:42 --> Config Class Initialized
INFO - 2022-12-31 02:15:42 --> Hooks Class Initialized
INFO - 2022-12-31 02:15:42 --> Router Class Initialized
INFO - 2022-12-31 02:15:42 --> Output Class Initialized
DEBUG - 2022-12-31 02:15:42 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:42 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:42 --> Security Class Initialized
INFO - 2022-12-31 02:15:42 --> URI Class Initialized
DEBUG - 2022-12-31 02:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:42 --> Input Class Initialized
INFO - 2022-12-31 02:15:42 --> Router Class Initialized
INFO - 2022-12-31 02:15:42 --> Language Class Initialized
INFO - 2022-12-31 02:15:42 --> Output Class Initialized
INFO - 2022-12-31 02:15:42 --> Loader Class Initialized
INFO - 2022-12-31 02:15:42 --> Security Class Initialized
INFO - 2022-12-31 02:15:42 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-31 02:15:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:42 --> Input Class Initialized
INFO - 2022-12-31 02:15:42 --> Language Class Initialized
INFO - 2022-12-31 02:15:42 --> Database Driver Class Initialized
INFO - 2022-12-31 02:15:42 --> Loader Class Initialized
INFO - 2022-12-31 02:15:42 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:42 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:51 --> Unable to connect to the database
INFO - 2022-12-31 02:15:51 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:15:51 --> Unable to connect to the database
INFO - 2022-12-31 02:15:51 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:15:51 --> Config Class Initialized
INFO - 2022-12-31 02:15:51 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:51 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:51 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:51 --> URI Class Initialized
INFO - 2022-12-31 02:15:51 --> Router Class Initialized
INFO - 2022-12-31 02:15:51 --> Output Class Initialized
INFO - 2022-12-31 02:15:51 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:51 --> Input Class Initialized
INFO - 2022-12-31 02:15:51 --> Language Class Initialized
INFO - 2022-12-31 02:15:51 --> Loader Class Initialized
ERROR - 2022-12-31 02:15:51 --> Unable to connect to the database
INFO - 2022-12-31 02:15:51 --> Controller Class Initialized
ERROR - 2022-12-31 02:15:51 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
DEBUG - 2022-12-31 02:15:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-31 02:15:51 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:15:51 --> Config Class Initialized
INFO - 2022-12-31 02:15:51 --> Hooks Class Initialized
INFO - 2022-12-31 02:15:51 --> Database Driver Class Initialized
DEBUG - 2022-12-31 02:15:51 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:51 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:51 --> URI Class Initialized
INFO - 2022-12-31 02:15:51 --> Router Class Initialized
INFO - 2022-12-31 02:15:51 --> Output Class Initialized
INFO - 2022-12-31 02:15:51 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:51 --> Input Class Initialized
INFO - 2022-12-31 02:15:51 --> Language Class Initialized
INFO - 2022-12-31 02:15:51 --> Loader Class Initialized
INFO - 2022-12-31 02:15:51 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:51 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:15:52 --> Unable to connect to the database
INFO - 2022-12-31 02:15:52 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:15:52 --> Unable to connect to the database
INFO - 2022-12-31 02:15:52 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:15:52 --> Config Class Initialized
INFO - 2022-12-31 02:15:52 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:15:52 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:15:52 --> Utf8 Class Initialized
INFO - 2022-12-31 02:15:52 --> URI Class Initialized
INFO - 2022-12-31 02:15:52 --> Router Class Initialized
INFO - 2022-12-31 02:15:52 --> Output Class Initialized
INFO - 2022-12-31 02:15:52 --> Security Class Initialized
DEBUG - 2022-12-31 02:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:15:52 --> Input Class Initialized
INFO - 2022-12-31 02:15:52 --> Language Class Initialized
INFO - 2022-12-31 02:15:52 --> Loader Class Initialized
INFO - 2022-12-31 02:15:52 --> Controller Class Initialized
DEBUG - 2022-12-31 02:15:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:15:52 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:16:01 --> Unable to connect to the database
ERROR - 2022-12-31 02:16:01 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:16:01 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:16:01 --> Config Class Initialized
INFO - 2022-12-31 02:16:01 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:16:01 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:16:01 --> Utf8 Class Initialized
INFO - 2022-12-31 02:16:01 --> URI Class Initialized
INFO - 2022-12-31 02:16:01 --> Router Class Initialized
INFO - 2022-12-31 02:16:01 --> Output Class Initialized
INFO - 2022-12-31 02:16:01 --> Security Class Initialized
DEBUG - 2022-12-31 02:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:16:01 --> Input Class Initialized
INFO - 2022-12-31 02:16:01 --> Language Class Initialized
INFO - 2022-12-31 02:16:01 --> Loader Class Initialized
INFO - 2022-12-31 02:16:01 --> Controller Class Initialized
DEBUG - 2022-12-31 02:16:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:16:01 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:16:01 --> Unable to connect to the database
INFO - 2022-12-31 02:16:01 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:16:01 --> Unable to connect to the database
INFO - 2022-12-31 02:16:01 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:16:01 --> Config Class Initialized
INFO - 2022-12-31 02:16:01 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:16:01 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:16:01 --> Utf8 Class Initialized
INFO - 2022-12-31 02:16:01 --> URI Class Initialized
INFO - 2022-12-31 02:16:01 --> Router Class Initialized
INFO - 2022-12-31 02:16:01 --> Output Class Initialized
INFO - 2022-12-31 02:16:01 --> Security Class Initialized
DEBUG - 2022-12-31 02:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:16:01 --> Input Class Initialized
INFO - 2022-12-31 02:16:01 --> Language Class Initialized
INFO - 2022-12-31 02:16:01 --> Loader Class Initialized
INFO - 2022-12-31 02:16:01 --> Controller Class Initialized
DEBUG - 2022-12-31 02:16:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:16:01 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:16:02 --> Unable to connect to the database
ERROR - 2022-12-31 02:16:02 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:16:02 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:16:02 --> Config Class Initialized
INFO - 2022-12-31 02:16:02 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:16:02 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:16:02 --> Utf8 Class Initialized
INFO - 2022-12-31 02:16:02 --> URI Class Initialized
INFO - 2022-12-31 02:16:02 --> Router Class Initialized
INFO - 2022-12-31 02:16:02 --> Output Class Initialized
INFO - 2022-12-31 02:16:02 --> Security Class Initialized
DEBUG - 2022-12-31 02:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:16:02 --> Input Class Initialized
INFO - 2022-12-31 02:16:02 --> Language Class Initialized
INFO - 2022-12-31 02:16:02 --> Loader Class Initialized
INFO - 2022-12-31 02:16:02 --> Controller Class Initialized
DEBUG - 2022-12-31 02:16:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:16:02 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:16:02 --> Unable to connect to the database
INFO - 2022-12-31 02:16:02 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:16:11 --> Unable to connect to the database
INFO - 2022-12-31 02:16:11 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:16:11 --> Config Class Initialized
INFO - 2022-12-31 02:16:11 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:16:11 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:16:11 --> Utf8 Class Initialized
INFO - 2022-12-31 02:16:11 --> URI Class Initialized
INFO - 2022-12-31 02:16:11 --> Router Class Initialized
INFO - 2022-12-31 02:16:11 --> Output Class Initialized
INFO - 2022-12-31 02:16:11 --> Security Class Initialized
DEBUG - 2022-12-31 02:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:16:11 --> Input Class Initialized
INFO - 2022-12-31 02:16:11 --> Language Class Initialized
INFO - 2022-12-31 02:16:11 --> Loader Class Initialized
INFO - 2022-12-31 02:16:11 --> Controller Class Initialized
DEBUG - 2022-12-31 02:16:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:16:11 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:16:11 --> Unable to connect to the database
ERROR - 2022-12-31 02:16:11 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:16:11 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
INFO - 2022-12-31 02:16:11 --> Config Class Initialized
INFO - 2022-12-31 02:16:11 --> Hooks Class Initialized
DEBUG - 2022-12-31 02:16:11 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:16:11 --> Utf8 Class Initialized
INFO - 2022-12-31 02:16:11 --> URI Class Initialized
INFO - 2022-12-31 02:16:11 --> Router Class Initialized
INFO - 2022-12-31 02:16:11 --> Output Class Initialized
INFO - 2022-12-31 02:16:11 --> Security Class Initialized
DEBUG - 2022-12-31 02:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:16:11 --> Input Class Initialized
INFO - 2022-12-31 02:16:11 --> Language Class Initialized
INFO - 2022-12-31 02:16:11 --> Loader Class Initialized
INFO - 2022-12-31 02:16:11 --> Controller Class Initialized
DEBUG - 2022-12-31 02:16:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:16:11 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:16:11 --> Unable to connect to the database
INFO - 2022-12-31 02:16:11 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:16:12 --> Unable to connect to the database
INFO - 2022-12-31 02:16:12 --> Language file loaded: language/english/db_lang.php
INFO - 2022-12-31 02:16:12 --> Config Class Initialized
INFO - 2022-12-31 02:16:12 --> Hooks Class Initialized
ERROR - 2022-12-31 02:16:12 --> Unable to connect to the database
ERROR - 2022-12-31 02:16:12 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:16:12 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
DEBUG - 2022-12-31 02:16:12 --> UTF-8 Support Enabled
INFO - 2022-12-31 02:16:12 --> Utf8 Class Initialized
INFO - 2022-12-31 02:16:12 --> URI Class Initialized
INFO - 2022-12-31 02:16:12 --> Router Class Initialized
INFO - 2022-12-31 02:16:12 --> Output Class Initialized
INFO - 2022-12-31 02:16:12 --> Security Class Initialized
DEBUG - 2022-12-31 02:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-31 02:16:12 --> Input Class Initialized
INFO - 2022-12-31 02:16:13 --> Language Class Initialized
INFO - 2022-12-31 02:16:13 --> Loader Class Initialized
INFO - 2022-12-31 02:16:13 --> Controller Class Initialized
DEBUG - 2022-12-31 02:16:13 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-31 02:16:13 --> Database Driver Class Initialized
ERROR - 2022-12-31 02:16:21 --> Unable to connect to the database
INFO - 2022-12-31 02:16:21 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:16:21 --> Unable to connect to the database
INFO - 2022-12-31 02:16:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2022-12-31 02:16:21 --> Unable to connect to the database
ERROR - 2022-12-31 02:16:21 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:16:21 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
ERROR - 2022-12-31 02:16:23 --> Unable to connect to the database
INFO - 2022-12-31 02:16:23 --> Model "Login_model" initialized
ERROR - 2022-12-31 02:16:31 --> Unable to connect to the database
ERROR - 2022-12-31 02:16:31 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:16:31 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
ERROR - 2022-12-31 02:16:33 --> Unable to connect to the database
ERROR - 2022-12-31 02:16:33 --> Query error: Connection timed out - Invalid query: select id from kunlun_user where name='super_dba';
ERROR - 2022-12-31 02:16:33 --> Exception of type 'Error' occurred with Message: Call to a member function num_rows() on boolean in File /var/www/html/KunlunMonitor/application/models/Login_model.php at Line 11
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php(3556): Login_model->getList('select id from ...')
#1 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getClusterMonitor()
#2 /var/www/html/KunlunMonitor/index.php(304): require_once('/var/www/html/K...')
#3 {main}
