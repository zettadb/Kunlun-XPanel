<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-25 01:31:30 --> Config Class Initialized
INFO - 2023-03-25 01:31:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:31:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:31:31 --> Utf8 Class Initialized
INFO - 2023-03-25 01:31:31 --> URI Class Initialized
INFO - 2023-03-25 01:31:31 --> Router Class Initialized
INFO - 2023-03-25 01:31:31 --> Output Class Initialized
INFO - 2023-03-25 01:31:31 --> Security Class Initialized
DEBUG - 2023-03-25 01:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:31:31 --> Input Class Initialized
INFO - 2023-03-25 01:31:31 --> Language Class Initialized
INFO - 2023-03-25 01:31:31 --> Loader Class Initialized
INFO - 2023-03-25 01:31:31 --> Controller Class Initialized
DEBUG - 2023-03-25 01:31:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:31:31 --> Database Driver Class Initialized
INFO - 2023-03-25 01:31:31 --> Config Class Initialized
INFO - 2023-03-25 01:31:31 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:31:31 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:31:31 --> Utf8 Class Initialized
INFO - 2023-03-25 01:31:31 --> URI Class Initialized
INFO - 2023-03-25 01:31:31 --> Router Class Initialized
INFO - 2023-03-25 01:31:31 --> Output Class Initialized
INFO - 2023-03-25 01:31:31 --> Security Class Initialized
DEBUG - 2023-03-25 01:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:31:31 --> Input Class Initialized
INFO - 2023-03-25 01:31:31 --> Language Class Initialized
INFO - 2023-03-25 01:31:31 --> Loader Class Initialized
INFO - 2023-03-25 01:31:31 --> Controller Class Initialized
DEBUG - 2023-03-25 01:31:31 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:31:31 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:31:41 --> Unable to connect to the database
INFO - 2023-03-25 01:31:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-25 01:31:41 --> Unable to connect to the database
INFO - 2023-03-25 01:31:41 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:31:41 --> Unable to connect to the database
ERROR - 2023-03-25 01:31:41 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:31:41 --> Final output sent to browser
DEBUG - 2023-03-25 01:31:41 --> Total execution time: 10.0404
INFO - 2023-03-25 01:31:41 --> Config Class Initialized
INFO - 2023-03-25 01:31:41 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:31:41 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:31:41 --> Utf8 Class Initialized
INFO - 2023-03-25 01:31:41 --> URI Class Initialized
INFO - 2023-03-25 01:31:41 --> Router Class Initialized
INFO - 2023-03-25 01:31:41 --> Output Class Initialized
INFO - 2023-03-25 01:31:41 --> Security Class Initialized
DEBUG - 2023-03-25 01:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:31:41 --> Input Class Initialized
INFO - 2023-03-25 01:31:41 --> Language Class Initialized
INFO - 2023-03-25 01:31:41 --> Loader Class Initialized
INFO - 2023-03-25 01:31:41 --> Controller Class Initialized
DEBUG - 2023-03-25 01:31:41 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:31:41 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:31:41 --> Unable to connect to the database
INFO - 2023-03-25 01:31:41 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:31:41 --> Unable to connect to the database
ERROR - 2023-03-25 01:31:41 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:31:41 --> Final output sent to browser
DEBUG - 2023-03-25 01:31:41 --> Total execution time: 0.0458
INFO - 2023-03-25 01:32:30 --> Config Class Initialized
INFO - 2023-03-25 01:32:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:32:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:32:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:32:30 --> URI Class Initialized
INFO - 2023-03-25 01:32:30 --> Router Class Initialized
INFO - 2023-03-25 01:32:30 --> Output Class Initialized
INFO - 2023-03-25 01:32:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:32:30 --> Input Class Initialized
INFO - 2023-03-25 01:32:30 --> Language Class Initialized
INFO - 2023-03-25 01:32:30 --> Config Class Initialized
INFO - 2023-03-25 01:32:30 --> Loader Class Initialized
INFO - 2023-03-25 01:32:30 --> Hooks Class Initialized
INFO - 2023-03-25 01:32:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:32:30 --> UTF-8 Support Enabled
DEBUG - 2023-03-25 01:32:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:32:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:32:30 --> URI Class Initialized
INFO - 2023-03-25 01:32:30 --> Database Driver Class Initialized
INFO - 2023-03-25 01:32:30 --> Router Class Initialized
INFO - 2023-03-25 01:32:30 --> Output Class Initialized
INFO - 2023-03-25 01:32:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:32:30 --> Input Class Initialized
INFO - 2023-03-25 01:32:30 --> Language Class Initialized
INFO - 2023-03-25 01:32:30 --> Loader Class Initialized
INFO - 2023-03-25 01:32:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:32:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:32:30 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:32:40 --> Unable to connect to the database
INFO - 2023-03-25 01:32:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-25 01:32:40 --> Unable to connect to the database
INFO - 2023-03-25 01:32:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:32:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:32:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:32:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:32:40 --> Total execution time: 10.0108
INFO - 2023-03-25 01:32:40 --> Config Class Initialized
INFO - 2023-03-25 01:32:40 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:32:40 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:32:40 --> Utf8 Class Initialized
INFO - 2023-03-25 01:32:40 --> URI Class Initialized
INFO - 2023-03-25 01:32:40 --> Router Class Initialized
INFO - 2023-03-25 01:32:40 --> Output Class Initialized
INFO - 2023-03-25 01:32:40 --> Security Class Initialized
DEBUG - 2023-03-25 01:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:32:40 --> Input Class Initialized
INFO - 2023-03-25 01:32:40 --> Language Class Initialized
INFO - 2023-03-25 01:32:40 --> Loader Class Initialized
INFO - 2023-03-25 01:32:40 --> Controller Class Initialized
DEBUG - 2023-03-25 01:32:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:32:40 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:32:40 --> Unable to connect to the database
INFO - 2023-03-25 01:32:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:32:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:32:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:32:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:32:40 --> Total execution time: 0.0116
INFO - 2023-03-25 01:33:30 --> Config Class Initialized
INFO - 2023-03-25 01:33:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:33:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:33:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:33:30 --> URI Class Initialized
INFO - 2023-03-25 01:33:30 --> Router Class Initialized
INFO - 2023-03-25 01:33:30 --> Output Class Initialized
INFO - 2023-03-25 01:33:30 --> Security Class Initialized
INFO - 2023-03-25 01:33:30 --> Config Class Initialized
DEBUG - 2023-03-25 01:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:33:30 --> Hooks Class Initialized
INFO - 2023-03-25 01:33:30 --> Input Class Initialized
INFO - 2023-03-25 01:33:30 --> Language Class Initialized
DEBUG - 2023-03-25 01:33:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:33:30 --> Loader Class Initialized
INFO - 2023-03-25 01:33:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:33:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:33:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:33:30 --> URI Class Initialized
INFO - 2023-03-25 01:33:30 --> Router Class Initialized
INFO - 2023-03-25 01:33:30 --> Output Class Initialized
INFO - 2023-03-25 01:33:30 --> Database Driver Class Initialized
INFO - 2023-03-25 01:33:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:33:30 --> Input Class Initialized
INFO - 2023-03-25 01:33:30 --> Language Class Initialized
INFO - 2023-03-25 01:33:30 --> Loader Class Initialized
INFO - 2023-03-25 01:33:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:33:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:33:30 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:33:40 --> Unable to connect to the database
INFO - 2023-03-25 01:33:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-25 01:33:40 --> Unable to connect to the database
INFO - 2023-03-25 01:33:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:33:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:33:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:33:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:33:40 --> Total execution time: 10.0052
INFO - 2023-03-25 01:33:40 --> Config Class Initialized
INFO - 2023-03-25 01:33:40 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:33:40 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:33:40 --> Utf8 Class Initialized
INFO - 2023-03-25 01:33:40 --> URI Class Initialized
INFO - 2023-03-25 01:33:40 --> Router Class Initialized
INFO - 2023-03-25 01:33:40 --> Output Class Initialized
INFO - 2023-03-25 01:33:40 --> Security Class Initialized
DEBUG - 2023-03-25 01:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:33:40 --> Input Class Initialized
INFO - 2023-03-25 01:33:40 --> Language Class Initialized
INFO - 2023-03-25 01:33:40 --> Loader Class Initialized
INFO - 2023-03-25 01:33:40 --> Controller Class Initialized
DEBUG - 2023-03-25 01:33:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:33:40 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:33:40 --> Unable to connect to the database
INFO - 2023-03-25 01:33:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:33:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:33:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:33:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:33:40 --> Total execution time: 0.0058
INFO - 2023-03-25 01:34:30 --> Config Class Initialized
INFO - 2023-03-25 01:34:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:34:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:34:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:34:30 --> URI Class Initialized
INFO - 2023-03-25 01:34:30 --> Router Class Initialized
INFO - 2023-03-25 01:34:30 --> Output Class Initialized
INFO - 2023-03-25 01:34:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:34:30 --> Input Class Initialized
INFO - 2023-03-25 01:34:30 --> Language Class Initialized
INFO - 2023-03-25 01:34:30 --> Loader Class Initialized
INFO - 2023-03-25 01:34:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:34:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:34:30 --> Database Driver Class Initialized
INFO - 2023-03-25 01:34:30 --> Config Class Initialized
INFO - 2023-03-25 01:34:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:34:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:34:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:34:30 --> URI Class Initialized
INFO - 2023-03-25 01:34:30 --> Router Class Initialized
INFO - 2023-03-25 01:34:30 --> Output Class Initialized
INFO - 2023-03-25 01:34:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:34:30 --> Input Class Initialized
INFO - 2023-03-25 01:34:30 --> Language Class Initialized
INFO - 2023-03-25 01:34:30 --> Loader Class Initialized
INFO - 2023-03-25 01:34:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:34:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:34:30 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:34:40 --> Unable to connect to the database
INFO - 2023-03-25 01:34:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-25 01:34:40 --> Unable to connect to the database
INFO - 2023-03-25 01:34:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:34:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:34:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:34:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:34:40 --> Total execution time: 10.0048
INFO - 2023-03-25 01:34:40 --> Config Class Initialized
INFO - 2023-03-25 01:34:40 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:34:40 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:34:40 --> Utf8 Class Initialized
INFO - 2023-03-25 01:34:40 --> URI Class Initialized
INFO - 2023-03-25 01:34:40 --> Router Class Initialized
INFO - 2023-03-25 01:34:40 --> Output Class Initialized
INFO - 2023-03-25 01:34:40 --> Security Class Initialized
DEBUG - 2023-03-25 01:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:34:40 --> Input Class Initialized
INFO - 2023-03-25 01:34:40 --> Language Class Initialized
INFO - 2023-03-25 01:34:40 --> Loader Class Initialized
INFO - 2023-03-25 01:34:40 --> Controller Class Initialized
DEBUG - 2023-03-25 01:34:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:34:40 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:34:40 --> Unable to connect to the database
INFO - 2023-03-25 01:34:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:34:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:34:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:34:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:34:40 --> Total execution time: 0.0063
INFO - 2023-03-25 01:35:30 --> Config Class Initialized
INFO - 2023-03-25 01:35:30 --> Hooks Class Initialized
INFO - 2023-03-25 01:35:30 --> Config Class Initialized
INFO - 2023-03-25 01:35:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:35:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:35:30 --> Utf8 Class Initialized
DEBUG - 2023-03-25 01:35:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:35:30 --> URI Class Initialized
INFO - 2023-03-25 01:35:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:35:30 --> URI Class Initialized
INFO - 2023-03-25 01:35:30 --> Router Class Initialized
INFO - 2023-03-25 01:35:30 --> Output Class Initialized
INFO - 2023-03-25 01:35:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:35:30 --> Input Class Initialized
INFO - 2023-03-25 01:35:30 --> Language Class Initialized
INFO - 2023-03-25 01:35:30 --> Loader Class Initialized
INFO - 2023-03-25 01:35:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:35:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:35:30 --> Router Class Initialized
INFO - 2023-03-25 01:35:30 --> Database Driver Class Initialized
INFO - 2023-03-25 01:35:30 --> Output Class Initialized
INFO - 2023-03-25 01:35:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:35:30 --> Input Class Initialized
INFO - 2023-03-25 01:35:30 --> Language Class Initialized
INFO - 2023-03-25 01:35:30 --> Loader Class Initialized
INFO - 2023-03-25 01:35:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:35:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:35:30 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:35:40 --> Unable to connect to the database
INFO - 2023-03-25 01:35:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:35:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:35:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:35:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:35:40 --> Total execution time: 10.0199
INFO - 2023-03-25 01:35:40 --> Config Class Initialized
INFO - 2023-03-25 01:35:40 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:35:40 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:35:40 --> Utf8 Class Initialized
INFO - 2023-03-25 01:35:40 --> URI Class Initialized
INFO - 2023-03-25 01:35:40 --> Router Class Initialized
INFO - 2023-03-25 01:35:40 --> Output Class Initialized
INFO - 2023-03-25 01:35:40 --> Security Class Initialized
DEBUG - 2023-03-25 01:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:35:40 --> Input Class Initialized
INFO - 2023-03-25 01:35:40 --> Language Class Initialized
INFO - 2023-03-25 01:35:40 --> Loader Class Initialized
INFO - 2023-03-25 01:35:40 --> Controller Class Initialized
DEBUG - 2023-03-25 01:35:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:35:40 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:35:40 --> Unable to connect to the database
INFO - 2023-03-25 01:35:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:35:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:35:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:35:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:35:40 --> Total execution time: 0.0032
ERROR - 2023-03-25 01:35:40 --> Unable to connect to the database
INFO - 2023-03-25 01:35:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-25 01:36:30 --> Config Class Initialized
INFO - 2023-03-25 01:36:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:36:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:36:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:36:30 --> Config Class Initialized
INFO - 2023-03-25 01:36:30 --> URI Class Initialized
INFO - 2023-03-25 01:36:30 --> Hooks Class Initialized
INFO - 2023-03-25 01:36:30 --> Router Class Initialized
DEBUG - 2023-03-25 01:36:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:36:30 --> Output Class Initialized
INFO - 2023-03-25 01:36:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:36:30 --> Security Class Initialized
INFO - 2023-03-25 01:36:30 --> URI Class Initialized
DEBUG - 2023-03-25 01:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:36:30 --> Router Class Initialized
INFO - 2023-03-25 01:36:30 --> Input Class Initialized
INFO - 2023-03-25 01:36:30 --> Output Class Initialized
INFO - 2023-03-25 01:36:30 --> Language Class Initialized
INFO - 2023-03-25 01:36:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:36:30 --> Loader Class Initialized
INFO - 2023-03-25 01:36:30 --> Input Class Initialized
INFO - 2023-03-25 01:36:30 --> Controller Class Initialized
INFO - 2023-03-25 01:36:30 --> Language Class Initialized
DEBUG - 2023-03-25 01:36:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:36:30 --> Loader Class Initialized
INFO - 2023-03-25 01:36:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:36:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:36:30 --> Database Driver Class Initialized
INFO - 2023-03-25 01:36:30 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:36:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:36:40 --> Unable to connect to the database
INFO - 2023-03-25 01:36:40 --> Model "Login_model" initialized
INFO - 2023-03-25 01:36:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2023-03-25 01:36:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:36:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:36:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:36:40 --> Total execution time: 10.0888
INFO - 2023-03-25 01:36:40 --> Config Class Initialized
INFO - 2023-03-25 01:36:40 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:36:40 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:36:40 --> Utf8 Class Initialized
INFO - 2023-03-25 01:36:40 --> URI Class Initialized
INFO - 2023-03-25 01:36:40 --> Router Class Initialized
INFO - 2023-03-25 01:36:40 --> Output Class Initialized
INFO - 2023-03-25 01:36:40 --> Security Class Initialized
DEBUG - 2023-03-25 01:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:36:40 --> Input Class Initialized
INFO - 2023-03-25 01:36:40 --> Language Class Initialized
INFO - 2023-03-25 01:36:40 --> Loader Class Initialized
INFO - 2023-03-25 01:36:40 --> Controller Class Initialized
DEBUG - 2023-03-25 01:36:40 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:36:40 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:36:40 --> Unable to connect to the database
INFO - 2023-03-25 01:36:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:36:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:36:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:36:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:36:40 --> Total execution time: 0.0429
INFO - 2023-03-25 01:37:30 --> Config Class Initialized
INFO - 2023-03-25 01:37:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:37:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:37:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:37:30 --> URI Class Initialized
INFO - 2023-03-25 01:37:30 --> Router Class Initialized
INFO - 2023-03-25 01:37:30 --> Output Class Initialized
INFO - 2023-03-25 01:37:30 --> Security Class Initialized
INFO - 2023-03-25 01:37:30 --> Config Class Initialized
INFO - 2023-03-25 01:37:30 --> Hooks Class Initialized
DEBUG - 2023-03-25 01:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:37:30 --> Input Class Initialized
DEBUG - 2023-03-25 01:37:30 --> UTF-8 Support Enabled
INFO - 2023-03-25 01:37:30 --> Language Class Initialized
INFO - 2023-03-25 01:37:30 --> Utf8 Class Initialized
INFO - 2023-03-25 01:37:30 --> URI Class Initialized
INFO - 2023-03-25 01:37:30 --> Loader Class Initialized
INFO - 2023-03-25 01:37:30 --> Router Class Initialized
INFO - 2023-03-25 01:37:30 --> Controller Class Initialized
INFO - 2023-03-25 01:37:30 --> Output Class Initialized
DEBUG - 2023-03-25 01:37:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:37:30 --> Security Class Initialized
DEBUG - 2023-03-25 01:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-25 01:37:30 --> Database Driver Class Initialized
INFO - 2023-03-25 01:37:30 --> Input Class Initialized
INFO - 2023-03-25 01:37:30 --> Language Class Initialized
INFO - 2023-03-25 01:37:30 --> Loader Class Initialized
INFO - 2023-03-25 01:37:30 --> Controller Class Initialized
DEBUG - 2023-03-25 01:37:30 --> Config file loaded: /Users/helayd/Documents/GitHub/Kunlun-XPanel/KunlunMonitor/application/config/myconfig.php
INFO - 2023-03-25 01:37:30 --> Database Driver Class Initialized
ERROR - 2023-03-25 01:37:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:37:40 --> Unable to connect to the database
INFO - 2023-03-25 01:37:40 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-25 01:37:40 --> Model "Login_model" initialized
ERROR - 2023-03-25 01:37:40 --> Unable to connect to the database
ERROR - 2023-03-25 01:37:40 --> Query error: Host is down - Invalid query: select id from kunlun_user where name='super_dba';
INFO - 2023-03-25 01:37:40 --> Final output sent to browser
DEBUG - 2023-03-25 01:37:40 --> Total execution time: 10.0052
