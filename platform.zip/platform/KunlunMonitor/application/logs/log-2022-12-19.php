<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-19 06:37:48 --> Config Class Initialized
INFO - 2022-12-19 06:37:48 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:37:48 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:37:48 --> Utf8 Class Initialized
INFO - 2022-12-19 06:37:48 --> URI Class Initialized
INFO - 2022-12-19 06:37:48 --> Router Class Initialized
INFO - 2022-12-19 06:37:48 --> Output Class Initialized
INFO - 2022-12-19 06:37:48 --> Security Class Initialized
DEBUG - 2022-12-19 06:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:37:48 --> Input Class Initialized
INFO - 2022-12-19 06:37:48 --> Language Class Initialized
INFO - 2022-12-19 06:37:48 --> Loader Class Initialized
INFO - 2022-12-19 06:37:48 --> Controller Class Initialized
INFO - 2022-12-19 06:37:48 --> Helper loaded: form_helper
INFO - 2022-12-19 06:37:48 --> Helper loaded: url_helper
DEBUG - 2022-12-19 06:37:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:37:48 --> Model "Change_model" initialized
ERROR - 2022-12-19 06:37:48 --> Exception of type 'Error' occurred with Message: Call to undefined function mysqli_report() in File /var/www/html/KunlunMonitor/application/models/Change_model.php at Line 18
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/Login.php(690): Change_model->getMysql('192.168.0.128', 10016, 'pgx', 'pgx_pwd', 'kunlun_metadata...', 'select hostaddr...')
#1 /var/www/html/KunlunMonitor/application/controllers/Login.php(468): Login->getMeta('192.168.0.128', 10016)
#2 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Login->modifyParam()
#3 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#4 {main}
INFO - 2022-12-19 06:38:19 --> Config Class Initialized
INFO - 2022-12-19 06:38:19 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:38:19 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:38:19 --> Utf8 Class Initialized
INFO - 2022-12-19 06:38:19 --> URI Class Initialized
INFO - 2022-12-19 06:38:19 --> Router Class Initialized
INFO - 2022-12-19 06:38:19 --> Output Class Initialized
INFO - 2022-12-19 06:38:19 --> Security Class Initialized
DEBUG - 2022-12-19 06:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:38:19 --> Input Class Initialized
INFO - 2022-12-19 06:38:19 --> Language Class Initialized
INFO - 2022-12-19 06:38:19 --> Loader Class Initialized
INFO - 2022-12-19 06:38:19 --> Controller Class Initialized
INFO - 2022-12-19 06:38:19 --> Helper loaded: form_helper
INFO - 2022-12-19 06:38:19 --> Helper loaded: url_helper
DEBUG - 2022-12-19 06:38:19 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:38:19 --> Model "Change_model" initialized
ERROR - 2022-12-19 06:38:19 --> Exception of type 'Error' occurred with Message: Call to undefined function mysqli_report() in File /var/www/html/KunlunMonitor/application/models/Change_model.php at Line 18
 Backtrace 
#0 /var/www/html/KunlunMonitor/application/controllers/Login.php(690): Change_model->getMysql('192.168.0.128', 10016, 'pgx', 'pgx_pwd', 'kunlun_metadata...', 'select hostaddr...')
#1 /var/www/html/KunlunMonitor/application/controllers/Login.php(468): Login->getMeta('192.168.0.128', 10016)
#2 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Login->modifyParam()
#3 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#4 {main}
INFO - 2022-12-19 06:49:24 --> Config Class Initialized
INFO - 2022-12-19 06:49:24 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:24 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:24 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:24 --> URI Class Initialized
INFO - 2022-12-19 06:49:24 --> Router Class Initialized
INFO - 2022-12-19 06:49:24 --> Output Class Initialized
INFO - 2022-12-19 06:49:24 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:24 --> Input Class Initialized
INFO - 2022-12-19 06:49:24 --> Language Class Initialized
INFO - 2022-12-19 06:49:24 --> Loader Class Initialized
INFO - 2022-12-19 06:49:24 --> Controller Class Initialized
INFO - 2022-12-19 06:49:24 --> Helper loaded: form_helper
INFO - 2022-12-19 06:49:24 --> Helper loaded: url_helper
DEBUG - 2022-12-19 06:49:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:24 --> Model "Change_model" initialized
INFO - 2022-12-19 06:49:24 --> Model "Grafana_model" initialized
INFO - 2022-12-19 06:49:24 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:24 --> Total execution time: 0.2390
INFO - 2022-12-19 06:49:24 --> Config Class Initialized
INFO - 2022-12-19 06:49:24 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:24 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:24 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:24 --> URI Class Initialized
INFO - 2022-12-19 06:49:24 --> Router Class Initialized
INFO - 2022-12-19 06:49:24 --> Output Class Initialized
INFO - 2022-12-19 06:49:24 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:24 --> Input Class Initialized
INFO - 2022-12-19 06:49:24 --> Language Class Initialized
INFO - 2022-12-19 06:49:24 --> Loader Class Initialized
INFO - 2022-12-19 06:49:24 --> Controller Class Initialized
INFO - 2022-12-19 06:49:24 --> Helper loaded: form_helper
INFO - 2022-12-19 06:49:24 --> Helper loaded: url_helper
DEBUG - 2022-12-19 06:49:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:24 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:24 --> Total execution time: 0.1229
INFO - 2022-12-19 06:49:24 --> Config Class Initialized
INFO - 2022-12-19 06:49:24 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:24 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:24 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:24 --> URI Class Initialized
INFO - 2022-12-19 06:49:25 --> Router Class Initialized
INFO - 2022-12-19 06:49:25 --> Output Class Initialized
INFO - 2022-12-19 06:49:25 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:25 --> Input Class Initialized
INFO - 2022-12-19 06:49:25 --> Language Class Initialized
INFO - 2022-12-19 06:49:25 --> Loader Class Initialized
INFO - 2022-12-19 06:49:25 --> Controller Class Initialized
INFO - 2022-12-19 06:49:25 --> Helper loaded: form_helper
INFO - 2022-12-19 06:49:25 --> Helper loaded: url_helper
DEBUG - 2022-12-19 06:49:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:25 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:25 --> Model "Login_model" initialized
INFO - 2022-12-19 06:49:25 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:25 --> Total execution time: 0.1736
INFO - 2022-12-19 06:49:25 --> Config Class Initialized
INFO - 2022-12-19 06:49:25 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:25 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:25 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:25 --> URI Class Initialized
INFO - 2022-12-19 06:49:25 --> Router Class Initialized
INFO - 2022-12-19 06:49:25 --> Output Class Initialized
INFO - 2022-12-19 06:49:25 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:25 --> Input Class Initialized
INFO - 2022-12-19 06:49:25 --> Language Class Initialized
INFO - 2022-12-19 06:49:25 --> Loader Class Initialized
INFO - 2022-12-19 06:49:25 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:25 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:25 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:25 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:25 --> Total execution time: 0.1643
INFO - 2022-12-19 06:49:25 --> Config Class Initialized
INFO - 2022-12-19 06:49:25 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:25 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:25 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:25 --> URI Class Initialized
INFO - 2022-12-19 06:49:25 --> Router Class Initialized
INFO - 2022-12-19 06:49:25 --> Output Class Initialized
INFO - 2022-12-19 06:49:25 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:25 --> Input Class Initialized
INFO - 2022-12-19 06:49:25 --> Language Class Initialized
INFO - 2022-12-19 06:49:25 --> Loader Class Initialized
INFO - 2022-12-19 06:49:25 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:25 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:25 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:25 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:25 --> Total execution time: 0.1295
INFO - 2022-12-19 06:49:26 --> Config Class Initialized
INFO - 2022-12-19 06:49:26 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:26 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:26 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:26 --> URI Class Initialized
INFO - 2022-12-19 06:49:26 --> Router Class Initialized
INFO - 2022-12-19 06:49:26 --> Output Class Initialized
INFO - 2022-12-19 06:49:26 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:26 --> Input Class Initialized
INFO - 2022-12-19 06:49:26 --> Language Class Initialized
INFO - 2022-12-19 06:49:26 --> Loader Class Initialized
INFO - 2022-12-19 06:49:26 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:26 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:26 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:26 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:26 --> Model "Login_model" initialized
INFO - 2022-12-19 06:49:26 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:26 --> Total execution time: 0.4308
INFO - 2022-12-19 06:49:26 --> Config Class Initialized
INFO - 2022-12-19 06:49:26 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:26 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:26 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:26 --> URI Class Initialized
INFO - 2022-12-19 06:49:26 --> Router Class Initialized
INFO - 2022-12-19 06:49:26 --> Output Class Initialized
INFO - 2022-12-19 06:49:26 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:26 --> Input Class Initialized
INFO - 2022-12-19 06:49:26 --> Language Class Initialized
INFO - 2022-12-19 06:49:26 --> Loader Class Initialized
INFO - 2022-12-19 06:49:26 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:26 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:26 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:26 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:26 --> Model "Login_model" initialized
INFO - 2022-12-19 06:49:26 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:26 --> Total execution time: 0.2074
INFO - 2022-12-19 06:49:32 --> Config Class Initialized
INFO - 2022-12-19 06:49:32 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:32 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:32 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:32 --> URI Class Initialized
INFO - 2022-12-19 06:49:32 --> Router Class Initialized
INFO - 2022-12-19 06:49:32 --> Output Class Initialized
INFO - 2022-12-19 06:49:32 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:32 --> Input Class Initialized
INFO - 2022-12-19 06:49:32 --> Language Class Initialized
INFO - 2022-12-19 06:49:32 --> Loader Class Initialized
INFO - 2022-12-19 06:49:32 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:32 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:32 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:32 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:32 --> Total execution time: 0.1655
INFO - 2022-12-19 06:49:32 --> Config Class Initialized
INFO - 2022-12-19 06:49:32 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:32 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:32 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:32 --> URI Class Initialized
INFO - 2022-12-19 06:49:32 --> Router Class Initialized
INFO - 2022-12-19 06:49:32 --> Output Class Initialized
INFO - 2022-12-19 06:49:32 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:32 --> Input Class Initialized
INFO - 2022-12-19 06:49:32 --> Language Class Initialized
INFO - 2022-12-19 06:49:32 --> Loader Class Initialized
INFO - 2022-12-19 06:49:32 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:32 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:32 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:32 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:32 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:32 --> Total execution time: 0.1607
INFO - 2022-12-19 06:49:35 --> Config Class Initialized
INFO - 2022-12-19 06:49:35 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:35 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:35 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:35 --> URI Class Initialized
INFO - 2022-12-19 06:49:35 --> Router Class Initialized
INFO - 2022-12-19 06:49:35 --> Output Class Initialized
INFO - 2022-12-19 06:49:35 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:35 --> Input Class Initialized
INFO - 2022-12-19 06:49:35 --> Language Class Initialized
INFO - 2022-12-19 06:49:35 --> Loader Class Initialized
INFO - 2022-12-19 06:49:35 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:35 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:35 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:35 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:35 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:35 --> Total execution time: 0.1486
INFO - 2022-12-19 06:49:35 --> Config Class Initialized
INFO - 2022-12-19 06:49:35 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:35 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:35 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:35 --> URI Class Initialized
INFO - 2022-12-19 06:49:35 --> Router Class Initialized
INFO - 2022-12-19 06:49:35 --> Output Class Initialized
INFO - 2022-12-19 06:49:35 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:35 --> Input Class Initialized
INFO - 2022-12-19 06:49:35 --> Language Class Initialized
INFO - 2022-12-19 06:49:36 --> Loader Class Initialized
INFO - 2022-12-19 06:49:36 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:36 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:36 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:36 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:36 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:36 --> Total execution time: 0.1439
INFO - 2022-12-19 06:49:39 --> Config Class Initialized
INFO - 2022-12-19 06:49:39 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:39 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:39 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:39 --> URI Class Initialized
INFO - 2022-12-19 06:49:39 --> Router Class Initialized
INFO - 2022-12-19 06:49:39 --> Output Class Initialized
INFO - 2022-12-19 06:49:39 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:39 --> Input Class Initialized
INFO - 2022-12-19 06:49:39 --> Language Class Initialized
INFO - 2022-12-19 06:49:39 --> Loader Class Initialized
INFO - 2022-12-19 06:49:39 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:39 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:39 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:39 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:39 --> Model "Login_model" initialized
INFO - 2022-12-19 06:49:40 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:40 --> Total execution time: 0.2276
INFO - 2022-12-19 06:49:40 --> Config Class Initialized
INFO - 2022-12-19 06:49:40 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:40 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:40 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:40 --> URI Class Initialized
INFO - 2022-12-19 06:49:40 --> Router Class Initialized
INFO - 2022-12-19 06:49:40 --> Output Class Initialized
INFO - 2022-12-19 06:49:40 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:40 --> Input Class Initialized
INFO - 2022-12-19 06:49:40 --> Language Class Initialized
INFO - 2022-12-19 06:49:40 --> Loader Class Initialized
INFO - 2022-12-19 06:49:40 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:40 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:40 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:40 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:40 --> Model "Login_model" initialized
INFO - 2022-12-19 06:49:40 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:40 --> Total execution time: 0.2256
INFO - 2022-12-19 06:49:44 --> Config Class Initialized
INFO - 2022-12-19 06:49:44 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:44 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:44 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:44 --> URI Class Initialized
INFO - 2022-12-19 06:49:44 --> Router Class Initialized
INFO - 2022-12-19 06:49:44 --> Output Class Initialized
INFO - 2022-12-19 06:49:44 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:44 --> Input Class Initialized
INFO - 2022-12-19 06:49:44 --> Language Class Initialized
INFO - 2022-12-19 06:49:44 --> Loader Class Initialized
INFO - 2022-12-19 06:49:44 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 06:49:44 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 06:49:44 --> Config Class Initialized
INFO - 2022-12-19 06:49:44 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:44 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:44 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:44 --> URI Class Initialized
INFO - 2022-12-19 06:49:44 --> Router Class Initialized
INFO - 2022-12-19 06:49:44 --> Output Class Initialized
INFO - 2022-12-19 06:49:44 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:44 --> Input Class Initialized
INFO - 2022-12-19 06:49:44 --> Language Class Initialized
INFO - 2022-12-19 06:49:44 --> Loader Class Initialized
INFO - 2022-12-19 06:49:44 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 06:49:44 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 06:49:45 --> Config Class Initialized
INFO - 2022-12-19 06:49:45 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:46 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:46 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:46 --> URI Class Initialized
INFO - 2022-12-19 06:49:46 --> Router Class Initialized
INFO - 2022-12-19 06:49:46 --> Output Class Initialized
INFO - 2022-12-19 06:49:46 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:46 --> Input Class Initialized
INFO - 2022-12-19 06:49:46 --> Language Class Initialized
INFO - 2022-12-19 06:49:46 --> Loader Class Initialized
INFO - 2022-12-19 06:49:46 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:46 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:46 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:46 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:46 --> Total execution time: 0.1340
INFO - 2022-12-19 06:49:46 --> Config Class Initialized
INFO - 2022-12-19 06:49:46 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:46 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:46 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:46 --> URI Class Initialized
INFO - 2022-12-19 06:49:46 --> Router Class Initialized
INFO - 2022-12-19 06:49:46 --> Output Class Initialized
INFO - 2022-12-19 06:49:46 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:46 --> Input Class Initialized
INFO - 2022-12-19 06:49:46 --> Language Class Initialized
INFO - 2022-12-19 06:49:46 --> Loader Class Initialized
INFO - 2022-12-19 06:49:46 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:46 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:46 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:46 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:46 --> Total execution time: 0.1526
INFO - 2022-12-19 06:49:49 --> Config Class Initialized
INFO - 2022-12-19 06:49:49 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:49 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:49 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:49 --> URI Class Initialized
INFO - 2022-12-19 06:49:49 --> Router Class Initialized
INFO - 2022-12-19 06:49:49 --> Output Class Initialized
INFO - 2022-12-19 06:49:49 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:49 --> Input Class Initialized
INFO - 2022-12-19 06:49:49 --> Language Class Initialized
INFO - 2022-12-19 06:49:49 --> Loader Class Initialized
INFO - 2022-12-19 06:49:49 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:49 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:49 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:49 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:49 --> Total execution time: 0.1418
INFO - 2022-12-19 06:49:49 --> Config Class Initialized
INFO - 2022-12-19 06:49:49 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:49 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:49 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:49 --> URI Class Initialized
INFO - 2022-12-19 06:49:49 --> Router Class Initialized
INFO - 2022-12-19 06:49:49 --> Output Class Initialized
INFO - 2022-12-19 06:49:49 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:49 --> Input Class Initialized
INFO - 2022-12-19 06:49:49 --> Language Class Initialized
INFO - 2022-12-19 06:49:49 --> Loader Class Initialized
INFO - 2022-12-19 06:49:49 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:49 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:49 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:49 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:49 --> Total execution time: 0.1349
INFO - 2022-12-19 06:49:52 --> Config Class Initialized
INFO - 2022-12-19 06:49:52 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:52 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:52 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:52 --> URI Class Initialized
INFO - 2022-12-19 06:49:53 --> Router Class Initialized
INFO - 2022-12-19 06:49:53 --> Output Class Initialized
INFO - 2022-12-19 06:49:53 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:53 --> Input Class Initialized
INFO - 2022-12-19 06:49:53 --> Language Class Initialized
INFO - 2022-12-19 06:49:53 --> Loader Class Initialized
INFO - 2022-12-19 06:49:53 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 06:49:53 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 06:49:53 --> Config Class Initialized
INFO - 2022-12-19 06:49:53 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:53 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:53 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:53 --> URI Class Initialized
INFO - 2022-12-19 06:49:53 --> Router Class Initialized
INFO - 2022-12-19 06:49:53 --> Output Class Initialized
INFO - 2022-12-19 06:49:53 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:53 --> Input Class Initialized
INFO - 2022-12-19 06:49:53 --> Language Class Initialized
INFO - 2022-12-19 06:49:53 --> Loader Class Initialized
INFO - 2022-12-19 06:49:53 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:53 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 06:49:53 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 06:49:57 --> Config Class Initialized
INFO - 2022-12-19 06:49:57 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:57 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:57 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:57 --> URI Class Initialized
INFO - 2022-12-19 06:49:57 --> Router Class Initialized
INFO - 2022-12-19 06:49:57 --> Output Class Initialized
INFO - 2022-12-19 06:49:57 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:57 --> Input Class Initialized
INFO - 2022-12-19 06:49:57 --> Language Class Initialized
INFO - 2022-12-19 06:49:57 --> Loader Class Initialized
INFO - 2022-12-19 06:49:57 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:57 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:57 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:57 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:57 --> Total execution time: 0.1342
INFO - 2022-12-19 06:49:57 --> Config Class Initialized
INFO - 2022-12-19 06:49:57 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:57 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:57 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:57 --> URI Class Initialized
INFO - 2022-12-19 06:49:57 --> Router Class Initialized
INFO - 2022-12-19 06:49:57 --> Output Class Initialized
INFO - 2022-12-19 06:49:57 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:57 --> Input Class Initialized
INFO - 2022-12-19 06:49:57 --> Language Class Initialized
INFO - 2022-12-19 06:49:57 --> Loader Class Initialized
INFO - 2022-12-19 06:49:57 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 06:49:57 --> Database Driver Class Initialized
INFO - 2022-12-19 06:49:57 --> Model "Cluster_model" initialized
INFO - 2022-12-19 06:49:57 --> Final output sent to browser
DEBUG - 2022-12-19 06:49:57 --> Total execution time: 0.1412
INFO - 2022-12-19 06:49:58 --> Config Class Initialized
INFO - 2022-12-19 06:49:58 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:58 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:58 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:58 --> URI Class Initialized
INFO - 2022-12-19 06:49:58 --> Router Class Initialized
INFO - 2022-12-19 06:49:58 --> Output Class Initialized
INFO - 2022-12-19 06:49:58 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:58 --> Input Class Initialized
INFO - 2022-12-19 06:49:58 --> Language Class Initialized
INFO - 2022-12-19 06:49:58 --> Loader Class Initialized
INFO - 2022-12-19 06:49:58 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 06:49:58 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 06:49:59 --> Config Class Initialized
INFO - 2022-12-19 06:49:59 --> Hooks Class Initialized
DEBUG - 2022-12-19 06:49:59 --> UTF-8 Support Enabled
INFO - 2022-12-19 06:49:59 --> Utf8 Class Initialized
INFO - 2022-12-19 06:49:59 --> URI Class Initialized
INFO - 2022-12-19 06:49:59 --> Router Class Initialized
INFO - 2022-12-19 06:49:59 --> Output Class Initialized
INFO - 2022-12-19 06:49:59 --> Security Class Initialized
DEBUG - 2022-12-19 06:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 06:49:59 --> Input Class Initialized
INFO - 2022-12-19 06:49:59 --> Language Class Initialized
INFO - 2022-12-19 06:49:59 --> Loader Class Initialized
INFO - 2022-12-19 06:49:59 --> Controller Class Initialized
DEBUG - 2022-12-19 06:49:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 06:49:59 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:15:52 --> Config Class Initialized
INFO - 2022-12-19 07:15:52 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:15:52 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:15:52 --> Utf8 Class Initialized
INFO - 2022-12-19 07:15:52 --> URI Class Initialized
INFO - 2022-12-19 07:15:52 --> Router Class Initialized
INFO - 2022-12-19 07:15:52 --> Output Class Initialized
INFO - 2022-12-19 07:15:52 --> Security Class Initialized
DEBUG - 2022-12-19 07:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:15:52 --> Input Class Initialized
INFO - 2022-12-19 07:15:52 --> Language Class Initialized
INFO - 2022-12-19 07:15:52 --> Loader Class Initialized
INFO - 2022-12-19 07:15:52 --> Controller Class Initialized
DEBUG - 2022-12-19 07:15:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:15:52 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:15:52 --> Config Class Initialized
INFO - 2022-12-19 07:15:52 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:15:52 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:15:52 --> Utf8 Class Initialized
INFO - 2022-12-19 07:15:52 --> URI Class Initialized
INFO - 2022-12-19 07:15:52 --> Router Class Initialized
INFO - 2022-12-19 07:15:52 --> Output Class Initialized
INFO - 2022-12-19 07:15:52 --> Security Class Initialized
DEBUG - 2022-12-19 07:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:15:52 --> Input Class Initialized
INFO - 2022-12-19 07:15:52 --> Language Class Initialized
INFO - 2022-12-19 07:15:52 --> Loader Class Initialized
INFO - 2022-12-19 07:15:52 --> Controller Class Initialized
DEBUG - 2022-12-19 07:15:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:15:52 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:16:14 --> Config Class Initialized
INFO - 2022-12-19 07:16:14 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:16:15 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:16:15 --> Utf8 Class Initialized
INFO - 2022-12-19 07:16:15 --> URI Class Initialized
INFO - 2022-12-19 07:16:15 --> Router Class Initialized
INFO - 2022-12-19 07:16:15 --> Output Class Initialized
INFO - 2022-12-19 07:16:15 --> Security Class Initialized
DEBUG - 2022-12-19 07:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:16:15 --> Input Class Initialized
INFO - 2022-12-19 07:16:15 --> Language Class Initialized
INFO - 2022-12-19 07:16:15 --> Loader Class Initialized
INFO - 2022-12-19 07:16:15 --> Controller Class Initialized
DEBUG - 2022-12-19 07:16:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:16:15 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:16:15 --> Config Class Initialized
INFO - 2022-12-19 07:16:15 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:16:15 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:16:15 --> Utf8 Class Initialized
INFO - 2022-12-19 07:16:15 --> URI Class Initialized
INFO - 2022-12-19 07:16:15 --> Router Class Initialized
INFO - 2022-12-19 07:16:15 --> Output Class Initialized
INFO - 2022-12-19 07:16:15 --> Security Class Initialized
DEBUG - 2022-12-19 07:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:16:15 --> Input Class Initialized
INFO - 2022-12-19 07:16:15 --> Language Class Initialized
INFO - 2022-12-19 07:16:15 --> Loader Class Initialized
INFO - 2022-12-19 07:16:15 --> Controller Class Initialized
DEBUG - 2022-12-19 07:16:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:16:15 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:16:50 --> Config Class Initialized
INFO - 2022-12-19 07:16:50 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:16:50 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:16:50 --> Utf8 Class Initialized
INFO - 2022-12-19 07:16:50 --> URI Class Initialized
INFO - 2022-12-19 07:16:50 --> Router Class Initialized
INFO - 2022-12-19 07:16:50 --> Output Class Initialized
INFO - 2022-12-19 07:16:50 --> Security Class Initialized
DEBUG - 2022-12-19 07:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:16:50 --> Input Class Initialized
INFO - 2022-12-19 07:16:50 --> Language Class Initialized
INFO - 2022-12-19 07:16:50 --> Loader Class Initialized
INFO - 2022-12-19 07:16:50 --> Controller Class Initialized
DEBUG - 2022-12-19 07:16:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:16:50 --> Config Class Initialized
INFO - 2022-12-19 07:16:50 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:16:50 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:16:50 --> Utf8 Class Initialized
INFO - 2022-12-19 07:16:50 --> URI Class Initialized
INFO - 2022-12-19 07:16:50 --> Router Class Initialized
INFO - 2022-12-19 07:16:50 --> Output Class Initialized
INFO - 2022-12-19 07:16:50 --> Security Class Initialized
DEBUG - 2022-12-19 07:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:16:50 --> Input Class Initialized
INFO - 2022-12-19 07:16:50 --> Language Class Initialized
INFO - 2022-12-19 07:16:50 --> Loader Class Initialized
INFO - 2022-12-19 07:16:50 --> Controller Class Initialized
DEBUG - 2022-12-19 07:16:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:17:10 --> Config Class Initialized
INFO - 2022-12-19 07:17:10 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-19 07:17:11 --> URI Class Initialized
INFO - 2022-12-19 07:17:11 --> Router Class Initialized
INFO - 2022-12-19 07:17:11 --> Output Class Initialized
INFO - 2022-12-19 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-19 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:17:11 --> Input Class Initialized
INFO - 2022-12-19 07:17:11 --> Language Class Initialized
INFO - 2022-12-19 07:17:11 --> Loader Class Initialized
INFO - 2022-12-19 07:17:11 --> Controller Class Initialized
DEBUG - 2022-12-19 07:17:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:17:11 --> Config Class Initialized
INFO - 2022-12-19 07:17:11 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:17:11 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:17:11 --> Utf8 Class Initialized
INFO - 2022-12-19 07:17:11 --> URI Class Initialized
INFO - 2022-12-19 07:17:11 --> Router Class Initialized
INFO - 2022-12-19 07:17:11 --> Output Class Initialized
INFO - 2022-12-19 07:17:11 --> Security Class Initialized
DEBUG - 2022-12-19 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:17:11 --> Input Class Initialized
INFO - 2022-12-19 07:17:11 --> Language Class Initialized
INFO - 2022-12-19 07:17:11 --> Loader Class Initialized
INFO - 2022-12-19 07:17:11 --> Controller Class Initialized
DEBUG - 2022-12-19 07:17:11 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:17:16 --> Config Class Initialized
INFO - 2022-12-19 07:17:16 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:17:16 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:17:16 --> Utf8 Class Initialized
INFO - 2022-12-19 07:17:16 --> URI Class Initialized
INFO - 2022-12-19 07:17:16 --> Router Class Initialized
INFO - 2022-12-19 07:17:16 --> Output Class Initialized
INFO - 2022-12-19 07:17:16 --> Security Class Initialized
DEBUG - 2022-12-19 07:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:17:16 --> Input Class Initialized
INFO - 2022-12-19 07:17:16 --> Language Class Initialized
INFO - 2022-12-19 07:17:16 --> Loader Class Initialized
INFO - 2022-12-19 07:17:16 --> Controller Class Initialized
DEBUG - 2022-12-19 07:17:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:17:19 --> Config Class Initialized
INFO - 2022-12-19 07:17:19 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:17:19 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:17:19 --> Utf8 Class Initialized
INFO - 2022-12-19 07:17:19 --> URI Class Initialized
INFO - 2022-12-19 07:17:19 --> Router Class Initialized
INFO - 2022-12-19 07:17:19 --> Output Class Initialized
INFO - 2022-12-19 07:17:20 --> Security Class Initialized
DEBUG - 2022-12-19 07:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:17:20 --> Input Class Initialized
INFO - 2022-12-19 07:17:20 --> Language Class Initialized
INFO - 2022-12-19 07:17:20 --> Loader Class Initialized
INFO - 2022-12-19 07:17:20 --> Controller Class Initialized
DEBUG - 2022-12-19 07:17:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:17:38 --> Config Class Initialized
INFO - 2022-12-19 07:17:38 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:17:38 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:17:38 --> Utf8 Class Initialized
INFO - 2022-12-19 07:17:38 --> URI Class Initialized
INFO - 2022-12-19 07:17:38 --> Router Class Initialized
INFO - 2022-12-19 07:17:38 --> Output Class Initialized
INFO - 2022-12-19 07:17:39 --> Security Class Initialized
DEBUG - 2022-12-19 07:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:17:39 --> Input Class Initialized
INFO - 2022-12-19 07:17:39 --> Language Class Initialized
INFO - 2022-12-19 07:17:39 --> Loader Class Initialized
INFO - 2022-12-19 07:17:39 --> Controller Class Initialized
DEBUG - 2022-12-19 07:17:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:17:46 --> Config Class Initialized
INFO - 2022-12-19 07:17:46 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:17:46 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:17:46 --> Utf8 Class Initialized
INFO - 2022-12-19 07:17:46 --> URI Class Initialized
INFO - 2022-12-19 07:17:46 --> Router Class Initialized
INFO - 2022-12-19 07:17:46 --> Output Class Initialized
INFO - 2022-12-19 07:17:46 --> Security Class Initialized
DEBUG - 2022-12-19 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:17:47 --> Input Class Initialized
INFO - 2022-12-19 07:17:47 --> Language Class Initialized
INFO - 2022-12-19 07:17:47 --> Loader Class Initialized
INFO - 2022-12-19 07:17:47 --> Controller Class Initialized
DEBUG - 2022-12-19 07:17:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:19:42 --> Config Class Initialized
INFO - 2022-12-19 07:19:42 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:19:42 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:19:42 --> Utf8 Class Initialized
INFO - 2022-12-19 07:19:42 --> URI Class Initialized
INFO - 2022-12-19 07:19:42 --> Router Class Initialized
INFO - 2022-12-19 07:19:42 --> Output Class Initialized
INFO - 2022-12-19 07:19:42 --> Security Class Initialized
DEBUG - 2022-12-19 07:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:19:42 --> Input Class Initialized
INFO - 2022-12-19 07:19:42 --> Language Class Initialized
INFO - 2022-12-19 07:19:42 --> Loader Class Initialized
INFO - 2022-12-19 07:19:42 --> Controller Class Initialized
DEBUG - 2022-12-19 07:19:42 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:19:46 --> Config Class Initialized
INFO - 2022-12-19 07:19:46 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:19:46 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:19:46 --> Utf8 Class Initialized
INFO - 2022-12-19 07:19:46 --> URI Class Initialized
INFO - 2022-12-19 07:19:46 --> Router Class Initialized
INFO - 2022-12-19 07:19:46 --> Output Class Initialized
INFO - 2022-12-19 07:19:46 --> Security Class Initialized
DEBUG - 2022-12-19 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:19:46 --> Input Class Initialized
INFO - 2022-12-19 07:19:46 --> Language Class Initialized
INFO - 2022-12-19 07:19:46 --> Loader Class Initialized
INFO - 2022-12-19 07:19:46 --> Controller Class Initialized
DEBUG - 2022-12-19 07:19:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:19:56 --> Config Class Initialized
INFO - 2022-12-19 07:19:56 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:19:56 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:19:56 --> Utf8 Class Initialized
INFO - 2022-12-19 07:19:56 --> URI Class Initialized
INFO - 2022-12-19 07:19:56 --> Router Class Initialized
INFO - 2022-12-19 07:19:56 --> Output Class Initialized
INFO - 2022-12-19 07:19:56 --> Security Class Initialized
DEBUG - 2022-12-19 07:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:19:57 --> Input Class Initialized
INFO - 2022-12-19 07:19:57 --> Language Class Initialized
INFO - 2022-12-19 07:19:57 --> Loader Class Initialized
INFO - 2022-12-19 07:19:57 --> Controller Class Initialized
DEBUG - 2022-12-19 07:19:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:24:56 --> Config Class Initialized
INFO - 2022-12-19 07:24:56 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:24:56 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:24:57 --> Utf8 Class Initialized
INFO - 2022-12-19 07:24:57 --> URI Class Initialized
INFO - 2022-12-19 07:24:57 --> Router Class Initialized
INFO - 2022-12-19 07:24:57 --> Output Class Initialized
INFO - 2022-12-19 07:24:57 --> Security Class Initialized
DEBUG - 2022-12-19 07:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:24:57 --> Input Class Initialized
INFO - 2022-12-19 07:24:57 --> Language Class Initialized
INFO - 2022-12-19 07:24:57 --> Loader Class Initialized
INFO - 2022-12-19 07:24:57 --> Controller Class Initialized
DEBUG - 2022-12-19 07:24:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:25:28 --> Config Class Initialized
INFO - 2022-12-19 07:25:28 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:25:28 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:25:28 --> Utf8 Class Initialized
INFO - 2022-12-19 07:25:28 --> URI Class Initialized
INFO - 2022-12-19 07:25:28 --> Router Class Initialized
INFO - 2022-12-19 07:25:28 --> Output Class Initialized
INFO - 2022-12-19 07:25:28 --> Security Class Initialized
DEBUG - 2022-12-19 07:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:25:28 --> Input Class Initialized
INFO - 2022-12-19 07:25:28 --> Language Class Initialized
INFO - 2022-12-19 07:25:28 --> Loader Class Initialized
INFO - 2022-12-19 07:25:28 --> Controller Class Initialized
DEBUG - 2022-12-19 07:25:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:25:28 --> Config Class Initialized
INFO - 2022-12-19 07:25:28 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:25:28 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:25:28 --> Utf8 Class Initialized
INFO - 2022-12-19 07:25:28 --> URI Class Initialized
INFO - 2022-12-19 07:25:28 --> Router Class Initialized
INFO - 2022-12-19 07:25:28 --> Output Class Initialized
INFO - 2022-12-19 07:25:28 --> Security Class Initialized
DEBUG - 2022-12-19 07:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:25:28 --> Input Class Initialized
INFO - 2022-12-19 07:25:28 --> Language Class Initialized
INFO - 2022-12-19 07:25:28 --> Loader Class Initialized
INFO - 2022-12-19 07:25:28 --> Controller Class Initialized
DEBUG - 2022-12-19 07:25:28 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:25:57 --> Config Class Initialized
INFO - 2022-12-19 07:25:57 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:25:57 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:25:57 --> Utf8 Class Initialized
INFO - 2022-12-19 07:25:57 --> URI Class Initialized
INFO - 2022-12-19 07:25:57 --> Router Class Initialized
INFO - 2022-12-19 07:25:57 --> Output Class Initialized
INFO - 2022-12-19 07:25:57 --> Security Class Initialized
DEBUG - 2022-12-19 07:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:25:57 --> Input Class Initialized
INFO - 2022-12-19 07:25:57 --> Language Class Initialized
INFO - 2022-12-19 07:25:57 --> Loader Class Initialized
INFO - 2022-12-19 07:25:57 --> Controller Class Initialized
DEBUG - 2022-12-19 07:25:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:25:57 --> Config Class Initialized
INFO - 2022-12-19 07:25:57 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:25:57 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:25:57 --> Utf8 Class Initialized
INFO - 2022-12-19 07:25:57 --> URI Class Initialized
INFO - 2022-12-19 07:25:57 --> Router Class Initialized
INFO - 2022-12-19 07:25:57 --> Output Class Initialized
INFO - 2022-12-19 07:25:57 --> Security Class Initialized
DEBUG - 2022-12-19 07:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:25:57 --> Input Class Initialized
INFO - 2022-12-19 07:25:57 --> Language Class Initialized
INFO - 2022-12-19 07:25:57 --> Loader Class Initialized
INFO - 2022-12-19 07:25:57 --> Controller Class Initialized
DEBUG - 2022-12-19 07:25:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:26:15 --> Config Class Initialized
INFO - 2022-12-19 07:26:15 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:26:15 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:26:15 --> Utf8 Class Initialized
INFO - 2022-12-19 07:26:15 --> URI Class Initialized
INFO - 2022-12-19 07:26:15 --> Router Class Initialized
INFO - 2022-12-19 07:26:15 --> Output Class Initialized
INFO - 2022-12-19 07:26:15 --> Security Class Initialized
DEBUG - 2022-12-19 07:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:26:15 --> Input Class Initialized
INFO - 2022-12-19 07:26:15 --> Language Class Initialized
INFO - 2022-12-19 07:26:15 --> Loader Class Initialized
INFO - 2022-12-19 07:26:15 --> Controller Class Initialized
DEBUG - 2022-12-19 07:26:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:26:16 --> Config Class Initialized
INFO - 2022-12-19 07:26:16 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:26:16 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:26:16 --> Utf8 Class Initialized
INFO - 2022-12-19 07:26:16 --> URI Class Initialized
INFO - 2022-12-19 07:26:16 --> Router Class Initialized
INFO - 2022-12-19 07:26:16 --> Output Class Initialized
INFO - 2022-12-19 07:26:16 --> Security Class Initialized
DEBUG - 2022-12-19 07:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:26:16 --> Input Class Initialized
INFO - 2022-12-19 07:26:16 --> Language Class Initialized
INFO - 2022-12-19 07:26:16 --> Loader Class Initialized
INFO - 2022-12-19 07:26:16 --> Controller Class Initialized
DEBUG - 2022-12-19 07:26:16 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:29:58 --> Config Class Initialized
INFO - 2022-12-19 07:29:58 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:29:58 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:29:58 --> Utf8 Class Initialized
INFO - 2022-12-19 07:29:58 --> URI Class Initialized
INFO - 2022-12-19 07:29:58 --> Router Class Initialized
INFO - 2022-12-19 07:29:58 --> Output Class Initialized
INFO - 2022-12-19 07:29:58 --> Security Class Initialized
DEBUG - 2022-12-19 07:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:29:58 --> Input Class Initialized
INFO - 2022-12-19 07:29:58 --> Language Class Initialized
INFO - 2022-12-19 07:29:58 --> Loader Class Initialized
INFO - 2022-12-19 07:29:58 --> Controller Class Initialized
DEBUG - 2022-12-19 07:29:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:29:58 --> Database Driver Class Initialized
INFO - 2022-12-19 07:29:58 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:29:58 --> Final output sent to browser
DEBUG - 2022-12-19 07:29:58 --> Total execution time: 0.3088
INFO - 2022-12-19 07:29:58 --> Config Class Initialized
INFO - 2022-12-19 07:29:58 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:29:58 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:29:58 --> Utf8 Class Initialized
INFO - 2022-12-19 07:29:59 --> URI Class Initialized
INFO - 2022-12-19 07:29:59 --> Router Class Initialized
INFO - 2022-12-19 07:29:59 --> Output Class Initialized
INFO - 2022-12-19 07:29:59 --> Security Class Initialized
DEBUG - 2022-12-19 07:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:29:59 --> Input Class Initialized
INFO - 2022-12-19 07:29:59 --> Language Class Initialized
INFO - 2022-12-19 07:29:59 --> Loader Class Initialized
INFO - 2022-12-19 07:29:59 --> Controller Class Initialized
DEBUG - 2022-12-19 07:29:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:29:59 --> Database Driver Class Initialized
INFO - 2022-12-19 07:29:59 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:29:59 --> Final output sent to browser
DEBUG - 2022-12-19 07:29:59 --> Total execution time: 0.2512
INFO - 2022-12-19 07:30:01 --> Config Class Initialized
INFO - 2022-12-19 07:30:01 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:30:01 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:30:01 --> Utf8 Class Initialized
INFO - 2022-12-19 07:30:01 --> URI Class Initialized
INFO - 2022-12-19 07:30:01 --> Router Class Initialized
INFO - 2022-12-19 07:30:01 --> Output Class Initialized
INFO - 2022-12-19 07:30:01 --> Security Class Initialized
DEBUG - 2022-12-19 07:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:30:01 --> Input Class Initialized
INFO - 2022-12-19 07:30:01 --> Language Class Initialized
INFO - 2022-12-19 07:30:01 --> Loader Class Initialized
INFO - 2022-12-19 07:30:01 --> Controller Class Initialized
DEBUG - 2022-12-19 07:30:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:30:01 --> Config Class Initialized
INFO - 2022-12-19 07:30:01 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:30:01 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:30:01 --> Utf8 Class Initialized
INFO - 2022-12-19 07:30:01 --> URI Class Initialized
INFO - 2022-12-19 07:30:01 --> Router Class Initialized
INFO - 2022-12-19 07:30:01 --> Output Class Initialized
INFO - 2022-12-19 07:30:01 --> Security Class Initialized
DEBUG - 2022-12-19 07:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:30:01 --> Input Class Initialized
INFO - 2022-12-19 07:30:01 --> Language Class Initialized
INFO - 2022-12-19 07:30:01 --> Loader Class Initialized
INFO - 2022-12-19 07:30:02 --> Controller Class Initialized
DEBUG - 2022-12-19 07:30:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:30:19 --> Config Class Initialized
INFO - 2022-12-19 07:30:19 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:30:19 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:30:19 --> Utf8 Class Initialized
INFO - 2022-12-19 07:30:19 --> URI Class Initialized
INFO - 2022-12-19 07:30:19 --> Router Class Initialized
INFO - 2022-12-19 07:30:19 --> Output Class Initialized
INFO - 2022-12-19 07:30:19 --> Security Class Initialized
DEBUG - 2022-12-19 07:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:30:19 --> Input Class Initialized
INFO - 2022-12-19 07:30:19 --> Language Class Initialized
INFO - 2022-12-19 07:30:19 --> Loader Class Initialized
INFO - 2022-12-19 07:30:19 --> Controller Class Initialized
DEBUG - 2022-12-19 07:30:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:30:20 --> Database Driver Class Initialized
INFO - 2022-12-19 07:30:20 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:30:20 --> Final output sent to browser
DEBUG - 2022-12-19 07:30:20 --> Total execution time: 0.3951
INFO - 2022-12-19 07:30:20 --> Config Class Initialized
INFO - 2022-12-19 07:30:20 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:30:20 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:30:20 --> Utf8 Class Initialized
INFO - 2022-12-19 07:30:20 --> URI Class Initialized
INFO - 2022-12-19 07:30:20 --> Router Class Initialized
INFO - 2022-12-19 07:30:20 --> Output Class Initialized
INFO - 2022-12-19 07:30:20 --> Security Class Initialized
DEBUG - 2022-12-19 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:30:20 --> Input Class Initialized
INFO - 2022-12-19 07:30:20 --> Language Class Initialized
INFO - 2022-12-19 07:30:20 --> Loader Class Initialized
INFO - 2022-12-19 07:30:20 --> Controller Class Initialized
DEBUG - 2022-12-19 07:30:20 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:30:20 --> Database Driver Class Initialized
INFO - 2022-12-19 07:30:20 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:30:20 --> Final output sent to browser
DEBUG - 2022-12-19 07:30:20 --> Total execution time: 0.3562
INFO - 2022-12-19 07:30:21 --> Config Class Initialized
INFO - 2022-12-19 07:30:21 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:30:21 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:30:21 --> Utf8 Class Initialized
INFO - 2022-12-19 07:30:21 --> URI Class Initialized
INFO - 2022-12-19 07:30:21 --> Router Class Initialized
INFO - 2022-12-19 07:30:21 --> Output Class Initialized
INFO - 2022-12-19 07:30:21 --> Security Class Initialized
DEBUG - 2022-12-19 07:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:30:21 --> Input Class Initialized
INFO - 2022-12-19 07:30:21 --> Language Class Initialized
INFO - 2022-12-19 07:30:21 --> Loader Class Initialized
INFO - 2022-12-19 07:30:21 --> Controller Class Initialized
DEBUG - 2022-12-19 07:30:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:30:21 --> Config Class Initialized
INFO - 2022-12-19 07:30:21 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:30:21 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:30:21 --> Utf8 Class Initialized
INFO - 2022-12-19 07:30:21 --> URI Class Initialized
INFO - 2022-12-19 07:30:21 --> Router Class Initialized
INFO - 2022-12-19 07:30:21 --> Output Class Initialized
INFO - 2022-12-19 07:30:21 --> Security Class Initialized
DEBUG - 2022-12-19 07:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:30:22 --> Input Class Initialized
INFO - 2022-12-19 07:30:22 --> Language Class Initialized
INFO - 2022-12-19 07:30:22 --> Loader Class Initialized
INFO - 2022-12-19 07:30:22 --> Controller Class Initialized
DEBUG - 2022-12-19 07:30:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:34:08 --> Config Class Initialized
INFO - 2022-12-19 07:34:08 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:34:08 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:34:08 --> Utf8 Class Initialized
INFO - 2022-12-19 07:34:08 --> URI Class Initialized
INFO - 2022-12-19 07:34:08 --> Router Class Initialized
INFO - 2022-12-19 07:34:08 --> Output Class Initialized
INFO - 2022-12-19 07:34:08 --> Security Class Initialized
DEBUG - 2022-12-19 07:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:34:08 --> Input Class Initialized
INFO - 2022-12-19 07:34:08 --> Language Class Initialized
INFO - 2022-12-19 07:34:08 --> Loader Class Initialized
INFO - 2022-12-19 07:34:08 --> Controller Class Initialized
DEBUG - 2022-12-19 07:34:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:34:08 --> Database Driver Class Initialized
INFO - 2022-12-19 07:34:08 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:34:08 --> Final output sent to browser
DEBUG - 2022-12-19 07:34:08 --> Total execution time: 0.2844
INFO - 2022-12-19 07:34:08 --> Config Class Initialized
INFO - 2022-12-19 07:34:08 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:34:08 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:34:08 --> Utf8 Class Initialized
INFO - 2022-12-19 07:34:08 --> URI Class Initialized
INFO - 2022-12-19 07:34:08 --> Router Class Initialized
INFO - 2022-12-19 07:34:08 --> Output Class Initialized
INFO - 2022-12-19 07:34:08 --> Security Class Initialized
DEBUG - 2022-12-19 07:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:34:08 --> Input Class Initialized
INFO - 2022-12-19 07:34:08 --> Language Class Initialized
INFO - 2022-12-19 07:34:08 --> Loader Class Initialized
INFO - 2022-12-19 07:34:08 --> Controller Class Initialized
DEBUG - 2022-12-19 07:34:08 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:34:08 --> Database Driver Class Initialized
INFO - 2022-12-19 07:34:08 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:34:08 --> Final output sent to browser
DEBUG - 2022-12-19 07:34:08 --> Total execution time: 0.2006
INFO - 2022-12-19 07:34:09 --> Config Class Initialized
INFO - 2022-12-19 07:34:09 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:34:09 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:34:09 --> Utf8 Class Initialized
INFO - 2022-12-19 07:34:09 --> URI Class Initialized
INFO - 2022-12-19 07:34:09 --> Router Class Initialized
INFO - 2022-12-19 07:34:09 --> Output Class Initialized
INFO - 2022-12-19 07:34:09 --> Security Class Initialized
DEBUG - 2022-12-19 07:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:34:09 --> Input Class Initialized
INFO - 2022-12-19 07:34:09 --> Language Class Initialized
INFO - 2022-12-19 07:34:09 --> Loader Class Initialized
INFO - 2022-12-19 07:34:09 --> Controller Class Initialized
DEBUG - 2022-12-19 07:34:09 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:34:10 --> Config Class Initialized
INFO - 2022-12-19 07:34:10 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:34:10 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:34:10 --> Utf8 Class Initialized
INFO - 2022-12-19 07:34:10 --> URI Class Initialized
INFO - 2022-12-19 07:34:10 --> Router Class Initialized
INFO - 2022-12-19 07:34:10 --> Output Class Initialized
INFO - 2022-12-19 07:34:10 --> Security Class Initialized
DEBUG - 2022-12-19 07:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:34:10 --> Input Class Initialized
INFO - 2022-12-19 07:34:10 --> Language Class Initialized
INFO - 2022-12-19 07:34:10 --> Loader Class Initialized
INFO - 2022-12-19 07:34:10 --> Controller Class Initialized
DEBUG - 2022-12-19 07:34:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:34:40 --> Config Class Initialized
INFO - 2022-12-19 07:34:40 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:34:40 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:34:40 --> Utf8 Class Initialized
INFO - 2022-12-19 07:34:40 --> URI Class Initialized
INFO - 2022-12-19 07:34:40 --> Router Class Initialized
INFO - 2022-12-19 07:34:40 --> Output Class Initialized
INFO - 2022-12-19 07:34:40 --> Security Class Initialized
DEBUG - 2022-12-19 07:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:34:40 --> Input Class Initialized
INFO - 2022-12-19 07:34:40 --> Language Class Initialized
INFO - 2022-12-19 07:34:40 --> Loader Class Initialized
INFO - 2022-12-19 07:34:40 --> Controller Class Initialized
DEBUG - 2022-12-19 07:34:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:34:40 --> Database Driver Class Initialized
INFO - 2022-12-19 07:34:40 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:34:40 --> Final output sent to browser
DEBUG - 2022-12-19 07:34:40 --> Total execution time: 0.3747
INFO - 2022-12-19 07:34:40 --> Config Class Initialized
INFO - 2022-12-19 07:34:40 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:34:40 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:34:40 --> Utf8 Class Initialized
INFO - 2022-12-19 07:34:40 --> URI Class Initialized
INFO - 2022-12-19 07:34:40 --> Router Class Initialized
INFO - 2022-12-19 07:34:40 --> Output Class Initialized
INFO - 2022-12-19 07:34:40 --> Security Class Initialized
DEBUG - 2022-12-19 07:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:34:40 --> Input Class Initialized
INFO - 2022-12-19 07:34:40 --> Language Class Initialized
INFO - 2022-12-19 07:34:40 --> Loader Class Initialized
INFO - 2022-12-19 07:34:40 --> Controller Class Initialized
DEBUG - 2022-12-19 07:34:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:34:40 --> Database Driver Class Initialized
INFO - 2022-12-19 07:34:40 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:34:41 --> Final output sent to browser
DEBUG - 2022-12-19 07:34:41 --> Total execution time: 0.3175
INFO - 2022-12-19 07:34:41 --> Config Class Initialized
INFO - 2022-12-19 07:34:41 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:34:41 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:34:41 --> Utf8 Class Initialized
INFO - 2022-12-19 07:34:41 --> URI Class Initialized
INFO - 2022-12-19 07:34:41 --> Router Class Initialized
INFO - 2022-12-19 07:34:41 --> Output Class Initialized
INFO - 2022-12-19 07:34:41 --> Security Class Initialized
DEBUG - 2022-12-19 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:34:41 --> Input Class Initialized
INFO - 2022-12-19 07:34:41 --> Language Class Initialized
INFO - 2022-12-19 07:34:41 --> Loader Class Initialized
INFO - 2022-12-19 07:34:41 --> Controller Class Initialized
DEBUG - 2022-12-19 07:34:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:34:41 --> Config Class Initialized
INFO - 2022-12-19 07:34:41 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:34:41 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:34:41 --> Utf8 Class Initialized
INFO - 2022-12-19 07:34:41 --> URI Class Initialized
INFO - 2022-12-19 07:34:41 --> Router Class Initialized
INFO - 2022-12-19 07:34:41 --> Output Class Initialized
INFO - 2022-12-19 07:34:41 --> Security Class Initialized
DEBUG - 2022-12-19 07:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:34:41 --> Input Class Initialized
INFO - 2022-12-19 07:34:41 --> Language Class Initialized
INFO - 2022-12-19 07:34:41 --> Loader Class Initialized
INFO - 2022-12-19 07:34:41 --> Controller Class Initialized
DEBUG - 2022-12-19 07:34:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:35:20 --> Config Class Initialized
INFO - 2022-12-19 07:35:20 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:35:20 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:35:20 --> Utf8 Class Initialized
INFO - 2022-12-19 07:35:21 --> URI Class Initialized
INFO - 2022-12-19 07:35:21 --> Router Class Initialized
INFO - 2022-12-19 07:35:21 --> Output Class Initialized
INFO - 2022-12-19 07:35:21 --> Security Class Initialized
DEBUG - 2022-12-19 07:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:35:21 --> Input Class Initialized
INFO - 2022-12-19 07:35:21 --> Language Class Initialized
INFO - 2022-12-19 07:35:21 --> Loader Class Initialized
INFO - 2022-12-19 07:35:21 --> Controller Class Initialized
DEBUG - 2022-12-19 07:35:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:35:21 --> Database Driver Class Initialized
INFO - 2022-12-19 07:35:21 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:35:21 --> Final output sent to browser
DEBUG - 2022-12-19 07:35:21 --> Total execution time: 0.3501
INFO - 2022-12-19 07:35:21 --> Config Class Initialized
INFO - 2022-12-19 07:35:21 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:35:21 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:35:21 --> Utf8 Class Initialized
INFO - 2022-12-19 07:35:21 --> URI Class Initialized
INFO - 2022-12-19 07:35:21 --> Router Class Initialized
INFO - 2022-12-19 07:35:21 --> Output Class Initialized
INFO - 2022-12-19 07:35:21 --> Security Class Initialized
DEBUG - 2022-12-19 07:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:35:21 --> Input Class Initialized
INFO - 2022-12-19 07:35:21 --> Language Class Initialized
INFO - 2022-12-19 07:35:21 --> Loader Class Initialized
INFO - 2022-12-19 07:35:21 --> Controller Class Initialized
DEBUG - 2022-12-19 07:35:21 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:35:21 --> Database Driver Class Initialized
INFO - 2022-12-19 07:35:21 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:35:21 --> Final output sent to browser
DEBUG - 2022-12-19 07:35:21 --> Total execution time: 0.3809
INFO - 2022-12-19 07:35:21 --> Config Class Initialized
INFO - 2022-12-19 07:35:21 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:35:21 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:35:21 --> Utf8 Class Initialized
INFO - 2022-12-19 07:35:21 --> URI Class Initialized
INFO - 2022-12-19 07:35:22 --> Router Class Initialized
INFO - 2022-12-19 07:35:22 --> Output Class Initialized
INFO - 2022-12-19 07:35:22 --> Security Class Initialized
DEBUG - 2022-12-19 07:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:35:22 --> Input Class Initialized
INFO - 2022-12-19 07:35:22 --> Language Class Initialized
INFO - 2022-12-19 07:35:22 --> Loader Class Initialized
INFO - 2022-12-19 07:35:22 --> Controller Class Initialized
DEBUG - 2022-12-19 07:35:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:35:22 --> Exception of type 'Error' occurred with Message: Call to undefined function getallheaders() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:35:22 --> Config Class Initialized
INFO - 2022-12-19 07:35:22 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:35:22 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:35:22 --> Utf8 Class Initialized
INFO - 2022-12-19 07:35:22 --> URI Class Initialized
INFO - 2022-12-19 07:35:22 --> Router Class Initialized
INFO - 2022-12-19 07:35:22 --> Output Class Initialized
INFO - 2022-12-19 07:35:22 --> Security Class Initialized
DEBUG - 2022-12-19 07:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:35:22 --> Input Class Initialized
INFO - 2022-12-19 07:35:22 --> Language Class Initialized
INFO - 2022-12-19 07:35:22 --> Loader Class Initialized
INFO - 2022-12-19 07:35:22 --> Controller Class Initialized
DEBUG - 2022-12-19 07:35:22 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:35:22 --> Exception of type 'Error' occurred with Message: Call to undefined function getallheaders() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 482
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:38:40 --> Config Class Initialized
INFO - 2022-12-19 07:38:40 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:38:40 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:38:40 --> Utf8 Class Initialized
INFO - 2022-12-19 07:38:40 --> URI Class Initialized
INFO - 2022-12-19 07:38:40 --> Router Class Initialized
INFO - 2022-12-19 07:38:40 --> Output Class Initialized
INFO - 2022-12-19 07:38:40 --> Security Class Initialized
DEBUG - 2022-12-19 07:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:38:40 --> Input Class Initialized
INFO - 2022-12-19 07:38:40 --> Language Class Initialized
INFO - 2022-12-19 07:38:40 --> Loader Class Initialized
INFO - 2022-12-19 07:38:40 --> Controller Class Initialized
DEBUG - 2022-12-19 07:38:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:39:39 --> Config Class Initialized
INFO - 2022-12-19 07:39:39 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:39:39 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:39:39 --> Utf8 Class Initialized
INFO - 2022-12-19 07:39:39 --> URI Class Initialized
INFO - 2022-12-19 07:39:39 --> Router Class Initialized
INFO - 2022-12-19 07:39:39 --> Output Class Initialized
INFO - 2022-12-19 07:39:39 --> Security Class Initialized
DEBUG - 2022-12-19 07:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:39:39 --> Input Class Initialized
INFO - 2022-12-19 07:39:39 --> Language Class Initialized
INFO - 2022-12-19 07:39:39 --> Loader Class Initialized
INFO - 2022-12-19 07:39:39 --> Controller Class Initialized
DEBUG - 2022-12-19 07:39:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:39:39 --> Database Driver Class Initialized
INFO - 2022-12-19 07:39:39 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:39:39 --> Final output sent to browser
DEBUG - 2022-12-19 07:39:39 --> Total execution time: 0.1398
INFO - 2022-12-19 07:39:39 --> Config Class Initialized
INFO - 2022-12-19 07:39:39 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:39:39 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:39:39 --> Utf8 Class Initialized
INFO - 2022-12-19 07:39:39 --> URI Class Initialized
INFO - 2022-12-19 07:39:39 --> Router Class Initialized
INFO - 2022-12-19 07:39:39 --> Output Class Initialized
INFO - 2022-12-19 07:39:39 --> Security Class Initialized
DEBUG - 2022-12-19 07:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:39:39 --> Input Class Initialized
INFO - 2022-12-19 07:39:39 --> Language Class Initialized
INFO - 2022-12-19 07:39:39 --> Loader Class Initialized
INFO - 2022-12-19 07:39:39 --> Controller Class Initialized
DEBUG - 2022-12-19 07:39:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:39:39 --> Database Driver Class Initialized
INFO - 2022-12-19 07:39:39 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:39:39 --> Final output sent to browser
DEBUG - 2022-12-19 07:39:39 --> Total execution time: 0.1392
INFO - 2022-12-19 07:39:40 --> Config Class Initialized
INFO - 2022-12-19 07:39:40 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:39:40 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:39:40 --> Utf8 Class Initialized
INFO - 2022-12-19 07:39:40 --> URI Class Initialized
INFO - 2022-12-19 07:39:40 --> Router Class Initialized
INFO - 2022-12-19 07:39:40 --> Output Class Initialized
INFO - 2022-12-19 07:39:40 --> Security Class Initialized
DEBUG - 2022-12-19 07:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:39:40 --> Input Class Initialized
INFO - 2022-12-19 07:39:40 --> Language Class Initialized
INFO - 2022-12-19 07:39:40 --> Loader Class Initialized
INFO - 2022-12-19 07:39:40 --> Controller Class Initialized
DEBUG - 2022-12-19 07:39:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:39:40 --> Config Class Initialized
INFO - 2022-12-19 07:39:40 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:39:40 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:39:40 --> Utf8 Class Initialized
INFO - 2022-12-19 07:39:40 --> URI Class Initialized
INFO - 2022-12-19 07:39:40 --> Router Class Initialized
INFO - 2022-12-19 07:39:40 --> Output Class Initialized
INFO - 2022-12-19 07:39:40 --> Security Class Initialized
DEBUG - 2022-12-19 07:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:39:40 --> Input Class Initialized
INFO - 2022-12-19 07:39:40 --> Language Class Initialized
INFO - 2022-12-19 07:39:40 --> Loader Class Initialized
INFO - 2022-12-19 07:39:40 --> Controller Class Initialized
DEBUG - 2022-12-19 07:39:40 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:42:49 --> Config Class Initialized
INFO - 2022-12-19 07:42:49 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:42:49 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:42:49 --> Utf8 Class Initialized
INFO - 2022-12-19 07:42:49 --> URI Class Initialized
INFO - 2022-12-19 07:42:49 --> Router Class Initialized
INFO - 2022-12-19 07:42:49 --> Output Class Initialized
INFO - 2022-12-19 07:42:49 --> Security Class Initialized
DEBUG - 2022-12-19 07:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:42:49 --> Input Class Initialized
INFO - 2022-12-19 07:42:49 --> Language Class Initialized
INFO - 2022-12-19 07:42:49 --> Loader Class Initialized
INFO - 2022-12-19 07:42:49 --> Controller Class Initialized
DEBUG - 2022-12-19 07:42:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:43:54 --> Config Class Initialized
INFO - 2022-12-19 07:43:54 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:43:54 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:43:54 --> Utf8 Class Initialized
INFO - 2022-12-19 07:43:54 --> URI Class Initialized
INFO - 2022-12-19 07:43:54 --> Router Class Initialized
INFO - 2022-12-19 07:43:55 --> Output Class Initialized
INFO - 2022-12-19 07:43:55 --> Security Class Initialized
DEBUG - 2022-12-19 07:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:43:55 --> Input Class Initialized
INFO - 2022-12-19 07:43:55 --> Language Class Initialized
INFO - 2022-12-19 07:43:55 --> Loader Class Initialized
INFO - 2022-12-19 07:43:55 --> Controller Class Initialized
DEBUG - 2022-12-19 07:43:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:43:55 --> Database Driver Class Initialized
INFO - 2022-12-19 07:43:55 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:43:55 --> Final output sent to browser
DEBUG - 2022-12-19 07:43:55 --> Total execution time: 0.1608
INFO - 2022-12-19 07:43:55 --> Config Class Initialized
INFO - 2022-12-19 07:43:55 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:43:55 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:43:55 --> Utf8 Class Initialized
INFO - 2022-12-19 07:43:55 --> URI Class Initialized
INFO - 2022-12-19 07:43:55 --> Router Class Initialized
INFO - 2022-12-19 07:43:55 --> Output Class Initialized
INFO - 2022-12-19 07:43:55 --> Security Class Initialized
DEBUG - 2022-12-19 07:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:43:55 --> Input Class Initialized
INFO - 2022-12-19 07:43:55 --> Language Class Initialized
INFO - 2022-12-19 07:43:55 --> Loader Class Initialized
INFO - 2022-12-19 07:43:55 --> Controller Class Initialized
DEBUG - 2022-12-19 07:43:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:43:55 --> Database Driver Class Initialized
INFO - 2022-12-19 07:43:55 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:43:55 --> Final output sent to browser
DEBUG - 2022-12-19 07:43:55 --> Total execution time: 0.1478
INFO - 2022-12-19 07:43:56 --> Config Class Initialized
INFO - 2022-12-19 07:43:56 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:43:56 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:43:56 --> Utf8 Class Initialized
INFO - 2022-12-19 07:43:56 --> URI Class Initialized
INFO - 2022-12-19 07:43:56 --> Router Class Initialized
INFO - 2022-12-19 07:43:56 --> Output Class Initialized
INFO - 2022-12-19 07:43:56 --> Security Class Initialized
DEBUG - 2022-12-19 07:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:43:56 --> Input Class Initialized
INFO - 2022-12-19 07:43:56 --> Language Class Initialized
INFO - 2022-12-19 07:43:56 --> Loader Class Initialized
INFO - 2022-12-19 07:43:56 --> Controller Class Initialized
DEBUG - 2022-12-19 07:43:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:43:56 --> Config Class Initialized
INFO - 2022-12-19 07:43:56 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:43:56 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:43:56 --> Utf8 Class Initialized
INFO - 2022-12-19 07:43:56 --> URI Class Initialized
INFO - 2022-12-19 07:43:56 --> Router Class Initialized
INFO - 2022-12-19 07:43:56 --> Output Class Initialized
INFO - 2022-12-19 07:43:56 --> Security Class Initialized
DEBUG - 2022-12-19 07:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:43:56 --> Input Class Initialized
INFO - 2022-12-19 07:43:56 --> Language Class Initialized
INFO - 2022-12-19 07:43:56 --> Loader Class Initialized
INFO - 2022-12-19 07:43:56 --> Controller Class Initialized
DEBUG - 2022-12-19 07:43:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:53:06 --> Config Class Initialized
INFO - 2022-12-19 07:53:06 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:53:06 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:53:06 --> Utf8 Class Initialized
INFO - 2022-12-19 07:53:06 --> URI Class Initialized
INFO - 2022-12-19 07:53:06 --> Router Class Initialized
INFO - 2022-12-19 07:53:06 --> Output Class Initialized
INFO - 2022-12-19 07:53:06 --> Security Class Initialized
DEBUG - 2022-12-19 07:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:53:06 --> Input Class Initialized
INFO - 2022-12-19 07:53:06 --> Language Class Initialized
INFO - 2022-12-19 07:53:06 --> Loader Class Initialized
INFO - 2022-12-19 07:53:06 --> Controller Class Initialized
DEBUG - 2022-12-19 07:53:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:53:06 --> Database Driver Class Initialized
INFO - 2022-12-19 07:53:06 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:53:06 --> Final output sent to browser
DEBUG - 2022-12-19 07:53:06 --> Total execution time: 0.1759
INFO - 2022-12-19 07:53:06 --> Config Class Initialized
INFO - 2022-12-19 07:53:06 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:53:06 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:53:06 --> Utf8 Class Initialized
INFO - 2022-12-19 07:53:06 --> URI Class Initialized
INFO - 2022-12-19 07:53:06 --> Router Class Initialized
INFO - 2022-12-19 07:53:06 --> Output Class Initialized
INFO - 2022-12-19 07:53:06 --> Security Class Initialized
DEBUG - 2022-12-19 07:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:53:06 --> Input Class Initialized
INFO - 2022-12-19 07:53:06 --> Language Class Initialized
INFO - 2022-12-19 07:53:06 --> Loader Class Initialized
INFO - 2022-12-19 07:53:06 --> Controller Class Initialized
DEBUG - 2022-12-19 07:53:06 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:53:06 --> Database Driver Class Initialized
INFO - 2022-12-19 07:53:06 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:53:06 --> Final output sent to browser
DEBUG - 2022-12-19 07:53:06 --> Total execution time: 0.1489
INFO - 2022-12-19 07:53:07 --> Config Class Initialized
INFO - 2022-12-19 07:53:07 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:53:07 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:53:07 --> Utf8 Class Initialized
INFO - 2022-12-19 07:53:07 --> URI Class Initialized
INFO - 2022-12-19 07:53:07 --> Router Class Initialized
INFO - 2022-12-19 07:53:07 --> Output Class Initialized
INFO - 2022-12-19 07:53:07 --> Security Class Initialized
DEBUG - 2022-12-19 07:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:53:07 --> Input Class Initialized
INFO - 2022-12-19 07:53:07 --> Language Class Initialized
INFO - 2022-12-19 07:53:07 --> Loader Class Initialized
INFO - 2022-12-19 07:53:07 --> Controller Class Initialized
DEBUG - 2022-12-19 07:53:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:53:07 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 483
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:53:07 --> Config Class Initialized
INFO - 2022-12-19 07:53:07 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:53:07 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:53:07 --> Utf8 Class Initialized
INFO - 2022-12-19 07:53:07 --> URI Class Initialized
INFO - 2022-12-19 07:53:07 --> Router Class Initialized
INFO - 2022-12-19 07:53:07 --> Output Class Initialized
INFO - 2022-12-19 07:53:07 --> Security Class Initialized
DEBUG - 2022-12-19 07:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:53:07 --> Input Class Initialized
INFO - 2022-12-19 07:53:07 --> Language Class Initialized
INFO - 2022-12-19 07:53:07 --> Loader Class Initialized
INFO - 2022-12-19 07:53:07 --> Controller Class Initialized
DEBUG - 2022-12-19 07:53:07 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:53:07 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 483
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:54:24 --> Config Class Initialized
INFO - 2022-12-19 07:54:24 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:54:24 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:54:24 --> Utf8 Class Initialized
INFO - 2022-12-19 07:54:24 --> URI Class Initialized
INFO - 2022-12-19 07:54:24 --> Router Class Initialized
INFO - 2022-12-19 07:54:24 --> Output Class Initialized
INFO - 2022-12-19 07:54:24 --> Security Class Initialized
DEBUG - 2022-12-19 07:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:54:24 --> Input Class Initialized
INFO - 2022-12-19 07:54:24 --> Language Class Initialized
INFO - 2022-12-19 07:54:24 --> Loader Class Initialized
INFO - 2022-12-19 07:54:24 --> Controller Class Initialized
DEBUG - 2022-12-19 07:54:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:54:24 --> Database Driver Class Initialized
INFO - 2022-12-19 07:54:24 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:54:24 --> Final output sent to browser
DEBUG - 2022-12-19 07:54:24 --> Total execution time: 0.1816
INFO - 2022-12-19 07:54:24 --> Config Class Initialized
INFO - 2022-12-19 07:54:24 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:54:24 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:54:24 --> Utf8 Class Initialized
INFO - 2022-12-19 07:54:24 --> URI Class Initialized
INFO - 2022-12-19 07:54:24 --> Router Class Initialized
INFO - 2022-12-19 07:54:24 --> Output Class Initialized
INFO - 2022-12-19 07:54:24 --> Security Class Initialized
DEBUG - 2022-12-19 07:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:54:24 --> Input Class Initialized
INFO - 2022-12-19 07:54:24 --> Language Class Initialized
INFO - 2022-12-19 07:54:24 --> Loader Class Initialized
INFO - 2022-12-19 07:54:24 --> Controller Class Initialized
DEBUG - 2022-12-19 07:54:24 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:54:24 --> Database Driver Class Initialized
INFO - 2022-12-19 07:54:24 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:54:24 --> Final output sent to browser
DEBUG - 2022-12-19 07:54:24 --> Total execution time: 0.1504
INFO - 2022-12-19 07:54:27 --> Config Class Initialized
INFO - 2022-12-19 07:54:27 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:54:27 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:54:27 --> Utf8 Class Initialized
INFO - 2022-12-19 07:54:27 --> URI Class Initialized
INFO - 2022-12-19 07:54:27 --> Router Class Initialized
INFO - 2022-12-19 07:54:27 --> Output Class Initialized
INFO - 2022-12-19 07:54:27 --> Security Class Initialized
DEBUG - 2022-12-19 07:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:54:27 --> Input Class Initialized
INFO - 2022-12-19 07:54:27 --> Language Class Initialized
INFO - 2022-12-19 07:54:27 --> Loader Class Initialized
INFO - 2022-12-19 07:54:27 --> Controller Class Initialized
DEBUG - 2022-12-19 07:54:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:54:27 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 1231
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getEffectCluster()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:54:27 --> Config Class Initialized
INFO - 2022-12-19 07:54:27 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:54:27 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:54:27 --> Utf8 Class Initialized
INFO - 2022-12-19 07:54:27 --> URI Class Initialized
INFO - 2022-12-19 07:54:27 --> Router Class Initialized
INFO - 2022-12-19 07:54:27 --> Output Class Initialized
INFO - 2022-12-19 07:54:27 --> Security Class Initialized
DEBUG - 2022-12-19 07:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:54:27 --> Input Class Initialized
INFO - 2022-12-19 07:54:27 --> Language Class Initialized
INFO - 2022-12-19 07:54:27 --> Loader Class Initialized
INFO - 2022-12-19 07:54:27 --> Controller Class Initialized
DEBUG - 2022-12-19 07:54:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:54:27 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 1231
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getEffectCluster()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:54:30 --> Config Class Initialized
INFO - 2022-12-19 07:54:30 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:54:30 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:54:30 --> Utf8 Class Initialized
INFO - 2022-12-19 07:54:30 --> URI Class Initialized
INFO - 2022-12-19 07:54:30 --> Router Class Initialized
INFO - 2022-12-19 07:54:30 --> Output Class Initialized
INFO - 2022-12-19 07:54:30 --> Security Class Initialized
DEBUG - 2022-12-19 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:54:30 --> Input Class Initialized
INFO - 2022-12-19 07:54:30 --> Language Class Initialized
INFO - 2022-12-19 07:54:30 --> Loader Class Initialized
INFO - 2022-12-19 07:54:30 --> Controller Class Initialized
DEBUG - 2022-12-19 07:54:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:54:30 --> Database Driver Class Initialized
INFO - 2022-12-19 07:54:30 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:54:30 --> Final output sent to browser
DEBUG - 2022-12-19 07:54:30 --> Total execution time: 0.1555
INFO - 2022-12-19 07:54:30 --> Config Class Initialized
INFO - 2022-12-19 07:54:30 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:54:30 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:54:30 --> Utf8 Class Initialized
INFO - 2022-12-19 07:54:30 --> URI Class Initialized
INFO - 2022-12-19 07:54:30 --> Router Class Initialized
INFO - 2022-12-19 07:54:30 --> Output Class Initialized
INFO - 2022-12-19 07:54:30 --> Security Class Initialized
DEBUG - 2022-12-19 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:54:30 --> Input Class Initialized
INFO - 2022-12-19 07:54:30 --> Language Class Initialized
INFO - 2022-12-19 07:54:30 --> Loader Class Initialized
INFO - 2022-12-19 07:54:30 --> Controller Class Initialized
DEBUG - 2022-12-19 07:54:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:54:31 --> Database Driver Class Initialized
INFO - 2022-12-19 07:54:31 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:54:31 --> Final output sent to browser
DEBUG - 2022-12-19 07:54:31 --> Total execution time: 0.1543
INFO - 2022-12-19 07:54:33 --> Config Class Initialized
INFO - 2022-12-19 07:54:33 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:54:33 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:54:33 --> Utf8 Class Initialized
INFO - 2022-12-19 07:54:33 --> URI Class Initialized
INFO - 2022-12-19 07:54:33 --> Router Class Initialized
INFO - 2022-12-19 07:54:33 --> Output Class Initialized
INFO - 2022-12-19 07:54:33 --> Security Class Initialized
DEBUG - 2022-12-19 07:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:54:33 --> Input Class Initialized
INFO - 2022-12-19 07:54:33 --> Language Class Initialized
INFO - 2022-12-19 07:54:33 --> Loader Class Initialized
INFO - 2022-12-19 07:54:33 --> Controller Class Initialized
DEBUG - 2022-12-19 07:54:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:54:33 --> Database Driver Class Initialized
INFO - 2022-12-19 07:54:33 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:54:33 --> Database Driver Class Initialized
INFO - 2022-12-19 07:54:33 --> Model "Login_model" initialized
INFO - 2022-12-19 07:54:33 --> Final output sent to browser
DEBUG - 2022-12-19 07:54:33 --> Total execution time: 0.2184
INFO - 2022-12-19 07:54:33 --> Config Class Initialized
INFO - 2022-12-19 07:54:33 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:54:33 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:54:33 --> Utf8 Class Initialized
INFO - 2022-12-19 07:54:33 --> URI Class Initialized
INFO - 2022-12-19 07:54:33 --> Router Class Initialized
INFO - 2022-12-19 07:54:33 --> Output Class Initialized
INFO - 2022-12-19 07:54:33 --> Security Class Initialized
DEBUG - 2022-12-19 07:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:54:33 --> Input Class Initialized
INFO - 2022-12-19 07:54:33 --> Language Class Initialized
INFO - 2022-12-19 07:54:33 --> Loader Class Initialized
INFO - 2022-12-19 07:54:33 --> Controller Class Initialized
DEBUG - 2022-12-19 07:54:33 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:54:33 --> Database Driver Class Initialized
INFO - 2022-12-19 07:54:33 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:54:33 --> Database Driver Class Initialized
INFO - 2022-12-19 07:54:33 --> Model "Login_model" initialized
INFO - 2022-12-19 07:54:33 --> Final output sent to browser
DEBUG - 2022-12-19 07:54:33 --> Total execution time: 0.2204
INFO - 2022-12-19 07:56:43 --> Config Class Initialized
INFO - 2022-12-19 07:56:43 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:56:43 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:56:43 --> Utf8 Class Initialized
INFO - 2022-12-19 07:56:43 --> URI Class Initialized
INFO - 2022-12-19 07:56:43 --> Router Class Initialized
INFO - 2022-12-19 07:56:43 --> Output Class Initialized
INFO - 2022-12-19 07:56:43 --> Security Class Initialized
DEBUG - 2022-12-19 07:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:56:44 --> Input Class Initialized
INFO - 2022-12-19 07:56:44 --> Language Class Initialized
INFO - 2022-12-19 07:56:44 --> Loader Class Initialized
INFO - 2022-12-19 07:56:44 --> Controller Class Initialized
DEBUG - 2022-12-19 07:56:44 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:56:44 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 483
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:57:30 --> Config Class Initialized
INFO - 2022-12-19 07:57:30 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:57:30 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:57:30 --> Utf8 Class Initialized
INFO - 2022-12-19 07:57:30 --> URI Class Initialized
INFO - 2022-12-19 07:57:30 --> Router Class Initialized
INFO - 2022-12-19 07:57:30 --> Output Class Initialized
INFO - 2022-12-19 07:57:30 --> Security Class Initialized
DEBUG - 2022-12-19 07:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:57:30 --> Input Class Initialized
INFO - 2022-12-19 07:57:30 --> Language Class Initialized
INFO - 2022-12-19 07:57:30 --> Loader Class Initialized
INFO - 2022-12-19 07:57:30 --> Controller Class Initialized
DEBUG - 2022-12-19 07:57:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:57:30 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 483
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:57:30 --> Config Class Initialized
INFO - 2022-12-19 07:57:30 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:57:30 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:57:30 --> Utf8 Class Initialized
INFO - 2022-12-19 07:57:30 --> URI Class Initialized
INFO - 2022-12-19 07:57:30 --> Router Class Initialized
INFO - 2022-12-19 07:57:30 --> Output Class Initialized
INFO - 2022-12-19 07:57:30 --> Security Class Initialized
DEBUG - 2022-12-19 07:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:57:30 --> Input Class Initialized
INFO - 2022-12-19 07:57:30 --> Language Class Initialized
INFO - 2022-12-19 07:57:30 --> Loader Class Initialized
INFO - 2022-12-19 07:57:30 --> Controller Class Initialized
DEBUG - 2022-12-19 07:57:30 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
ERROR - 2022-12-19 07:57:30 --> Exception of type 'Error' occurred with Message: Call to undefined function apache_request_headers() in File /var/www/html/KunlunMonitor/application/controllers/user/Cluster.php at Line 483
 Backtrace 
#0 /var/www/html/KunlunMonitor/system/core/CodeIgniter.php(532): Cluster->getShards()
#1 /var/www/html/KunlunMonitor/index.php(288): require_once('/var/www/html/K...')
#2 {main}
INFO - 2022-12-19 07:57:31 --> Config Class Initialized
INFO - 2022-12-19 07:57:31 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:57:31 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:57:31 --> Utf8 Class Initialized
INFO - 2022-12-19 07:57:31 --> URI Class Initialized
INFO - 2022-12-19 07:57:31 --> Router Class Initialized
INFO - 2022-12-19 07:57:31 --> Output Class Initialized
INFO - 2022-12-19 07:57:31 --> Security Class Initialized
DEBUG - 2022-12-19 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:57:31 --> Input Class Initialized
INFO - 2022-12-19 07:57:31 --> Language Class Initialized
INFO - 2022-12-19 07:57:31 --> Loader Class Initialized
INFO - 2022-12-19 07:57:31 --> Controller Class Initialized
DEBUG - 2022-12-19 07:57:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:57:31 --> Database Driver Class Initialized
INFO - 2022-12-19 07:57:31 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:57:31 --> Final output sent to browser
DEBUG - 2022-12-19 07:57:31 --> Total execution time: 0.1530
INFO - 2022-12-19 07:57:31 --> Config Class Initialized
INFO - 2022-12-19 07:57:31 --> Hooks Class Initialized
DEBUG - 2022-12-19 07:57:31 --> UTF-8 Support Enabled
INFO - 2022-12-19 07:57:31 --> Utf8 Class Initialized
INFO - 2022-12-19 07:57:31 --> URI Class Initialized
INFO - 2022-12-19 07:57:31 --> Router Class Initialized
INFO - 2022-12-19 07:57:31 --> Output Class Initialized
INFO - 2022-12-19 07:57:31 --> Security Class Initialized
DEBUG - 2022-12-19 07:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 07:57:31 --> Input Class Initialized
INFO - 2022-12-19 07:57:31 --> Language Class Initialized
INFO - 2022-12-19 07:57:31 --> Loader Class Initialized
INFO - 2022-12-19 07:57:31 --> Controller Class Initialized
DEBUG - 2022-12-19 07:57:31 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 07:57:31 --> Database Driver Class Initialized
INFO - 2022-12-19 07:57:31 --> Model "Cluster_model" initialized
INFO - 2022-12-19 07:57:31 --> Final output sent to browser
DEBUG - 2022-12-19 07:57:31 --> Total execution time: 0.1571
INFO - 2022-12-19 08:03:25 --> Config Class Initialized
INFO - 2022-12-19 08:03:25 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:25 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:25 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:25 --> URI Class Initialized
INFO - 2022-12-19 08:03:25 --> Router Class Initialized
INFO - 2022-12-19 08:03:25 --> Output Class Initialized
INFO - 2022-12-19 08:03:25 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:25 --> Input Class Initialized
INFO - 2022-12-19 08:03:25 --> Language Class Initialized
INFO - 2022-12-19 08:03:25 --> Loader Class Initialized
INFO - 2022-12-19 08:03:25 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:25 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:25 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:25 --> Total execution time: 0.1209
INFO - 2022-12-19 08:03:26 --> Config Class Initialized
INFO - 2022-12-19 08:03:26 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:26 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:26 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:26 --> URI Class Initialized
INFO - 2022-12-19 08:03:26 --> Router Class Initialized
INFO - 2022-12-19 08:03:26 --> Output Class Initialized
INFO - 2022-12-19 08:03:26 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:26 --> Input Class Initialized
INFO - 2022-12-19 08:03:26 --> Language Class Initialized
INFO - 2022-12-19 08:03:26 --> Loader Class Initialized
INFO - 2022-12-19 08:03:26 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:26 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:26 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:26 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:26 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:26 --> Total execution time: 0.1548
INFO - 2022-12-19 08:03:38 --> Config Class Initialized
INFO - 2022-12-19 08:03:38 --> Hooks Class Initialized
INFO - 2022-12-19 08:03:38 --> Config Class Initialized
INFO - 2022-12-19 08:03:38 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:38 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:38 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:39 --> URI Class Initialized
DEBUG - 2022-12-19 08:03:39 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:39 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:39 --> Router Class Initialized
INFO - 2022-12-19 08:03:39 --> URI Class Initialized
INFO - 2022-12-19 08:03:39 --> Output Class Initialized
INFO - 2022-12-19 08:03:39 --> Security Class Initialized
INFO - 2022-12-19 08:03:39 --> Router Class Initialized
DEBUG - 2022-12-19 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:39 --> Input Class Initialized
INFO - 2022-12-19 08:03:39 --> Output Class Initialized
INFO - 2022-12-19 08:03:39 --> Language Class Initialized
INFO - 2022-12-19 08:03:39 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:39 --> Input Class Initialized
INFO - 2022-12-19 08:03:39 --> Loader Class Initialized
INFO - 2022-12-19 08:03:39 --> Language Class Initialized
INFO - 2022-12-19 08:03:39 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:39 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:39 --> Total execution time: 0.1689
INFO - 2022-12-19 08:03:39 --> Loader Class Initialized
INFO - 2022-12-19 08:03:39 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:39 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:39 --> Total execution time: 0.1935
INFO - 2022-12-19 08:03:39 --> Config Class Initialized
INFO - 2022-12-19 08:03:39 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:39 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:39 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:39 --> URI Class Initialized
INFO - 2022-12-19 08:03:39 --> Config Class Initialized
INFO - 2022-12-19 08:03:39 --> Hooks Class Initialized
INFO - 2022-12-19 08:03:39 --> Router Class Initialized
DEBUG - 2022-12-19 08:03:39 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:39 --> Output Class Initialized
INFO - 2022-12-19 08:03:39 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:39 --> Security Class Initialized
INFO - 2022-12-19 08:03:39 --> URI Class Initialized
DEBUG - 2022-12-19 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:39 --> Input Class Initialized
INFO - 2022-12-19 08:03:39 --> Router Class Initialized
INFO - 2022-12-19 08:03:39 --> Language Class Initialized
INFO - 2022-12-19 08:03:39 --> Output Class Initialized
INFO - 2022-12-19 08:03:39 --> Loader Class Initialized
INFO - 2022-12-19 08:03:39 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:39 --> Controller Class Initialized
INFO - 2022-12-19 08:03:39 --> Input Class Initialized
DEBUG - 2022-12-19 08:03:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:39 --> Language Class Initialized
INFO - 2022-12-19 08:03:39 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:39 --> Loader Class Initialized
INFO - 2022-12-19 08:03:39 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:39 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:39 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:39 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:39 --> Total execution time: 0.2399
INFO - 2022-12-19 08:03:39 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:39 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:39 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:39 --> Total execution time: 0.2540
INFO - 2022-12-19 08:03:45 --> Config Class Initialized
INFO - 2022-12-19 08:03:45 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:45 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:45 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:45 --> URI Class Initialized
INFO - 2022-12-19 08:03:45 --> Router Class Initialized
INFO - 2022-12-19 08:03:45 --> Output Class Initialized
INFO - 2022-12-19 08:03:45 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:45 --> Input Class Initialized
INFO - 2022-12-19 08:03:45 --> Language Class Initialized
INFO - 2022-12-19 08:03:45 --> Loader Class Initialized
INFO - 2022-12-19 08:03:45 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:45 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:45 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:45 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:45 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:45 --> Total execution time: 0.1478
INFO - 2022-12-19 08:03:46 --> Config Class Initialized
INFO - 2022-12-19 08:03:46 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:46 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:46 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:46 --> URI Class Initialized
INFO - 2022-12-19 08:03:46 --> Router Class Initialized
INFO - 2022-12-19 08:03:46 --> Output Class Initialized
INFO - 2022-12-19 08:03:46 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:46 --> Input Class Initialized
INFO - 2022-12-19 08:03:46 --> Language Class Initialized
INFO - 2022-12-19 08:03:46 --> Loader Class Initialized
INFO - 2022-12-19 08:03:46 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:46 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:46 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:46 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:46 --> Total execution time: 0.1456
INFO - 2022-12-19 08:03:47 --> Config Class Initialized
INFO - 2022-12-19 08:03:47 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:47 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:47 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:47 --> URI Class Initialized
INFO - 2022-12-19 08:03:47 --> Router Class Initialized
INFO - 2022-12-19 08:03:47 --> Output Class Initialized
INFO - 2022-12-19 08:03:47 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:47 --> Input Class Initialized
INFO - 2022-12-19 08:03:47 --> Language Class Initialized
INFO - 2022-12-19 08:03:47 --> Loader Class Initialized
INFO - 2022-12-19 08:03:47 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:47 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:47 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:47 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:47 --> Total execution time: 0.1461
INFO - 2022-12-19 08:03:47 --> Config Class Initialized
INFO - 2022-12-19 08:03:47 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:47 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:47 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:47 --> URI Class Initialized
INFO - 2022-12-19 08:03:47 --> Router Class Initialized
INFO - 2022-12-19 08:03:47 --> Output Class Initialized
INFO - 2022-12-19 08:03:48 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:48 --> Input Class Initialized
INFO - 2022-12-19 08:03:48 --> Language Class Initialized
INFO - 2022-12-19 08:03:48 --> Loader Class Initialized
INFO - 2022-12-19 08:03:48 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:48 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:48 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:48 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:48 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:48 --> Total execution time: 0.1494
INFO - 2022-12-19 08:03:50 --> Config Class Initialized
INFO - 2022-12-19 08:03:50 --> Hooks Class Initialized
INFO - 2022-12-19 08:03:50 --> Config Class Initialized
INFO - 2022-12-19 08:03:50 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:50 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:50 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:50 --> URI Class Initialized
DEBUG - 2022-12-19 08:03:50 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:50 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:50 --> Router Class Initialized
INFO - 2022-12-19 08:03:50 --> URI Class Initialized
INFO - 2022-12-19 08:03:50 --> Output Class Initialized
INFO - 2022-12-19 08:03:50 --> Router Class Initialized
INFO - 2022-12-19 08:03:50 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:50 --> Output Class Initialized
INFO - 2022-12-19 08:03:50 --> Input Class Initialized
INFO - 2022-12-19 08:03:50 --> Language Class Initialized
INFO - 2022-12-19 08:03:50 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:50 --> Input Class Initialized
INFO - 2022-12-19 08:03:50 --> Language Class Initialized
INFO - 2022-12-19 08:03:50 --> Loader Class Initialized
INFO - 2022-12-19 08:03:50 --> Controller Class Initialized
INFO - 2022-12-19 08:03:50 --> Loader Class Initialized
DEBUG - 2022-12-19 08:03:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:50 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:50 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:50 --> Total execution time: 0.1854
INFO - 2022-12-19 08:03:50 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:50 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:50 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:50 --> Total execution time: 0.2381
INFO - 2022-12-19 08:03:50 --> Config Class Initialized
INFO - 2022-12-19 08:03:50 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:50 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:50 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:50 --> Config Class Initialized
INFO - 2022-12-19 08:03:50 --> URI Class Initialized
INFO - 2022-12-19 08:03:50 --> Hooks Class Initialized
INFO - 2022-12-19 08:03:50 --> Router Class Initialized
DEBUG - 2022-12-19 08:03:50 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:50 --> Output Class Initialized
INFO - 2022-12-19 08:03:50 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:50 --> Security Class Initialized
INFO - 2022-12-19 08:03:50 --> URI Class Initialized
DEBUG - 2022-12-19 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:50 --> Input Class Initialized
INFO - 2022-12-19 08:03:50 --> Router Class Initialized
INFO - 2022-12-19 08:03:50 --> Language Class Initialized
INFO - 2022-12-19 08:03:50 --> Output Class Initialized
INFO - 2022-12-19 08:03:50 --> Security Class Initialized
INFO - 2022-12-19 08:03:50 --> Loader Class Initialized
DEBUG - 2022-12-19 08:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:50 --> Controller Class Initialized
INFO - 2022-12-19 08:03:50 --> Input Class Initialized
DEBUG - 2022-12-19 08:03:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:50 --> Language Class Initialized
INFO - 2022-12-19 08:03:50 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:50 --> Loader Class Initialized
INFO - 2022-12-19 08:03:50 --> Controller Class Initialized
INFO - 2022-12-19 08:03:50 --> Model "Login_model" initialized
DEBUG - 2022-12-19 08:03:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:50 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:50 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:50 --> Final output sent to browser
INFO - 2022-12-19 08:03:50 --> Database Driver Class Initialized
DEBUG - 2022-12-19 08:03:50 --> Total execution time: 0.2502
INFO - 2022-12-19 08:03:50 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:50 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:50 --> Total execution time: 0.2365
INFO - 2022-12-19 08:03:52 --> Config Class Initialized
INFO - 2022-12-19 08:03:52 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:52 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:52 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:52 --> URI Class Initialized
INFO - 2022-12-19 08:03:52 --> Router Class Initialized
INFO - 2022-12-19 08:03:52 --> Output Class Initialized
INFO - 2022-12-19 08:03:52 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:52 --> Input Class Initialized
INFO - 2022-12-19 08:03:52 --> Language Class Initialized
INFO - 2022-12-19 08:03:52 --> Loader Class Initialized
INFO - 2022-12-19 08:03:52 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:52 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:52 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:52 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:52 --> Model "Login_model" initialized
INFO - 2022-12-19 08:03:52 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:52 --> Total execution time: 0.2283
INFO - 2022-12-19 08:03:52 --> Config Class Initialized
INFO - 2022-12-19 08:03:52 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:52 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:52 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:52 --> URI Class Initialized
INFO - 2022-12-19 08:03:52 --> Router Class Initialized
INFO - 2022-12-19 08:03:52 --> Output Class Initialized
INFO - 2022-12-19 08:03:52 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:52 --> Input Class Initialized
INFO - 2022-12-19 08:03:52 --> Language Class Initialized
INFO - 2022-12-19 08:03:52 --> Loader Class Initialized
INFO - 2022-12-19 08:03:52 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:52 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:52 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:52 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:52 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:52 --> Model "Login_model" initialized
INFO - 2022-12-19 08:03:52 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:52 --> Total execution time: 0.2075
INFO - 2022-12-19 08:03:58 --> Config Class Initialized
INFO - 2022-12-19 08:03:58 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:58 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:58 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:58 --> URI Class Initialized
INFO - 2022-12-19 08:03:58 --> Router Class Initialized
INFO - 2022-12-19 08:03:58 --> Output Class Initialized
INFO - 2022-12-19 08:03:58 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:58 --> Input Class Initialized
INFO - 2022-12-19 08:03:58 --> Language Class Initialized
INFO - 2022-12-19 08:03:58 --> Loader Class Initialized
INFO - 2022-12-19 08:03:58 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:58 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:58 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:58 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:58 --> Total execution time: 0.1485
INFO - 2022-12-19 08:03:58 --> Config Class Initialized
INFO - 2022-12-19 08:03:58 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:03:58 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:03:58 --> Utf8 Class Initialized
INFO - 2022-12-19 08:03:58 --> URI Class Initialized
INFO - 2022-12-19 08:03:58 --> Router Class Initialized
INFO - 2022-12-19 08:03:58 --> Output Class Initialized
INFO - 2022-12-19 08:03:58 --> Security Class Initialized
DEBUG - 2022-12-19 08:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:03:58 --> Input Class Initialized
INFO - 2022-12-19 08:03:58 --> Language Class Initialized
INFO - 2022-12-19 08:03:58 --> Loader Class Initialized
INFO - 2022-12-19 08:03:58 --> Controller Class Initialized
DEBUG - 2022-12-19 08:03:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:03:58 --> Database Driver Class Initialized
INFO - 2022-12-19 08:03:58 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:03:58 --> Final output sent to browser
DEBUG - 2022-12-19 08:03:58 --> Total execution time: 0.1373
INFO - 2022-12-19 08:04:02 --> Config Class Initialized
INFO - 2022-12-19 08:04:02 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:02 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:02 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:02 --> URI Class Initialized
INFO - 2022-12-19 08:04:02 --> Router Class Initialized
INFO - 2022-12-19 08:04:02 --> Output Class Initialized
INFO - 2022-12-19 08:04:02 --> Security Class Initialized
DEBUG - 2022-12-19 08:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:02 --> Input Class Initialized
INFO - 2022-12-19 08:04:02 --> Language Class Initialized
INFO - 2022-12-19 08:04:02 --> Loader Class Initialized
INFO - 2022-12-19 08:04:02 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:02 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:02 --> Total execution time: 0.0996
INFO - 2022-12-19 08:04:02 --> Config Class Initialized
INFO - 2022-12-19 08:04:02 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:02 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:02 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:02 --> URI Class Initialized
INFO - 2022-12-19 08:04:02 --> Router Class Initialized
INFO - 2022-12-19 08:04:02 --> Output Class Initialized
INFO - 2022-12-19 08:04:02 --> Security Class Initialized
DEBUG - 2022-12-19 08:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:02 --> Input Class Initialized
INFO - 2022-12-19 08:04:02 --> Language Class Initialized
INFO - 2022-12-19 08:04:02 --> Loader Class Initialized
INFO - 2022-12-19 08:04:02 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:02 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:02 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:02 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:02 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:02 --> Total execution time: 0.1160
INFO - 2022-12-19 08:04:05 --> Config Class Initialized
INFO - 2022-12-19 08:04:05 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:05 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:05 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:05 --> URI Class Initialized
INFO - 2022-12-19 08:04:05 --> Router Class Initialized
INFO - 2022-12-19 08:04:05 --> Output Class Initialized
INFO - 2022-12-19 08:04:05 --> Security Class Initialized
DEBUG - 2022-12-19 08:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:05 --> Input Class Initialized
INFO - 2022-12-19 08:04:05 --> Language Class Initialized
INFO - 2022-12-19 08:04:05 --> Loader Class Initialized
INFO - 2022-12-19 08:04:05 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:05 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:05 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:05 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:05 --> Total execution time: 0.1466
INFO - 2022-12-19 08:04:05 --> Config Class Initialized
INFO - 2022-12-19 08:04:05 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:05 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:05 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:05 --> URI Class Initialized
INFO - 2022-12-19 08:04:05 --> Router Class Initialized
INFO - 2022-12-19 08:04:05 --> Output Class Initialized
INFO - 2022-12-19 08:04:05 --> Security Class Initialized
DEBUG - 2022-12-19 08:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:05 --> Input Class Initialized
INFO - 2022-12-19 08:04:05 --> Language Class Initialized
INFO - 2022-12-19 08:04:05 --> Loader Class Initialized
INFO - 2022-12-19 08:04:05 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:05 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:05 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:05 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:05 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:05 --> Total execution time: 0.1371
INFO - 2022-12-19 08:04:10 --> Config Class Initialized
INFO - 2022-12-19 08:04:10 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:10 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:10 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:10 --> URI Class Initialized
INFO - 2022-12-19 08:04:10 --> Router Class Initialized
INFO - 2022-12-19 08:04:10 --> Output Class Initialized
INFO - 2022-12-19 08:04:10 --> Security Class Initialized
DEBUG - 2022-12-19 08:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:10 --> Input Class Initialized
INFO - 2022-12-19 08:04:10 --> Language Class Initialized
INFO - 2022-12-19 08:04:10 --> Loader Class Initialized
INFO - 2022-12-19 08:04:10 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:10 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:10 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:10 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:10 --> Model "Login_model" initialized
INFO - 2022-12-19 08:04:10 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:10 --> Total execution time: 0.2232
INFO - 2022-12-19 08:04:10 --> Config Class Initialized
INFO - 2022-12-19 08:04:10 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:10 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:10 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:10 --> URI Class Initialized
INFO - 2022-12-19 08:04:10 --> Router Class Initialized
INFO - 2022-12-19 08:04:10 --> Output Class Initialized
INFO - 2022-12-19 08:04:10 --> Security Class Initialized
DEBUG - 2022-12-19 08:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:10 --> Input Class Initialized
INFO - 2022-12-19 08:04:10 --> Language Class Initialized
INFO - 2022-12-19 08:04:10 --> Loader Class Initialized
INFO - 2022-12-19 08:04:10 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:10 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:10 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:11 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:11 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:11 --> Model "Login_model" initialized
INFO - 2022-12-19 08:04:11 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:11 --> Total execution time: 0.2106
INFO - 2022-12-19 08:04:34 --> Config Class Initialized
INFO - 2022-12-19 08:04:34 --> Hooks Class Initialized
INFO - 2022-12-19 08:04:34 --> Config Class Initialized
INFO - 2022-12-19 08:04:34 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:34 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:34 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:34 --> URI Class Initialized
DEBUG - 2022-12-19 08:04:34 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:34 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:34 --> Router Class Initialized
INFO - 2022-12-19 08:04:34 --> URI Class Initialized
INFO - 2022-12-19 08:04:34 --> Output Class Initialized
INFO - 2022-12-19 08:04:34 --> Router Class Initialized
INFO - 2022-12-19 08:04:34 --> Security Class Initialized
INFO - 2022-12-19 08:04:34 --> Output Class Initialized
DEBUG - 2022-12-19 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:34 --> Input Class Initialized
INFO - 2022-12-19 08:04:34 --> Security Class Initialized
INFO - 2022-12-19 08:04:34 --> Language Class Initialized
DEBUG - 2022-12-19 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:34 --> Input Class Initialized
INFO - 2022-12-19 08:04:34 --> Language Class Initialized
INFO - 2022-12-19 08:04:34 --> Loader Class Initialized
INFO - 2022-12-19 08:04:34 --> Controller Class Initialized
INFO - 2022-12-19 08:04:34 --> Loader Class Initialized
DEBUG - 2022-12-19 08:04:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:34 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:34 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:34 --> Total execution time: 0.1684
INFO - 2022-12-19 08:04:34 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:34 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:34 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:34 --> Total execution time: 0.2166
INFO - 2022-12-19 08:04:34 --> Config Class Initialized
INFO - 2022-12-19 08:04:34 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:34 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:34 --> Config Class Initialized
INFO - 2022-12-19 08:04:34 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:34 --> Hooks Class Initialized
INFO - 2022-12-19 08:04:34 --> URI Class Initialized
DEBUG - 2022-12-19 08:04:34 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:34 --> Router Class Initialized
INFO - 2022-12-19 08:04:34 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:34 --> Output Class Initialized
INFO - 2022-12-19 08:04:34 --> URI Class Initialized
INFO - 2022-12-19 08:04:34 --> Security Class Initialized
INFO - 2022-12-19 08:04:34 --> Router Class Initialized
DEBUG - 2022-12-19 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:34 --> Input Class Initialized
INFO - 2022-12-19 08:04:34 --> Output Class Initialized
INFO - 2022-12-19 08:04:34 --> Language Class Initialized
INFO - 2022-12-19 08:04:34 --> Security Class Initialized
INFO - 2022-12-19 08:04:34 --> Loader Class Initialized
DEBUG - 2022-12-19 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:34 --> Input Class Initialized
INFO - 2022-12-19 08:04:34 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:34 --> Language Class Initialized
INFO - 2022-12-19 08:04:34 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:34 --> Loader Class Initialized
INFO - 2022-12-19 08:04:34 --> Controller Class Initialized
INFO - 2022-12-19 08:04:34 --> Model "Login_model" initialized
DEBUG - 2022-12-19 08:04:34 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:34 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:34 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:34 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:34 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:34 --> Total execution time: 0.2539
INFO - 2022-12-19 08:04:34 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:34 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:34 --> Total execution time: 0.2320
INFO - 2022-12-19 08:04:38 --> Config Class Initialized
INFO - 2022-12-19 08:04:38 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:38 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:38 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:38 --> URI Class Initialized
INFO - 2022-12-19 08:04:38 --> Router Class Initialized
INFO - 2022-12-19 08:04:38 --> Output Class Initialized
INFO - 2022-12-19 08:04:38 --> Security Class Initialized
DEBUG - 2022-12-19 08:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:38 --> Input Class Initialized
INFO - 2022-12-19 08:04:38 --> Language Class Initialized
INFO - 2022-12-19 08:04:38 --> Loader Class Initialized
INFO - 2022-12-19 08:04:38 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:38 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:38 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:38 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:38 --> Model "Login_model" initialized
INFO - 2022-12-19 08:04:38 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:38 --> Total execution time: 0.2288
INFO - 2022-12-19 08:04:38 --> Config Class Initialized
INFO - 2022-12-19 08:04:38 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:04:38 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:04:38 --> Utf8 Class Initialized
INFO - 2022-12-19 08:04:38 --> URI Class Initialized
INFO - 2022-12-19 08:04:38 --> Router Class Initialized
INFO - 2022-12-19 08:04:38 --> Output Class Initialized
INFO - 2022-12-19 08:04:38 --> Security Class Initialized
DEBUG - 2022-12-19 08:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:04:38 --> Input Class Initialized
INFO - 2022-12-19 08:04:38 --> Language Class Initialized
INFO - 2022-12-19 08:04:38 --> Loader Class Initialized
INFO - 2022-12-19 08:04:38 --> Controller Class Initialized
DEBUG - 2022-12-19 08:04:38 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:04:38 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:38 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:04:38 --> Database Driver Class Initialized
INFO - 2022-12-19 08:04:38 --> Model "Login_model" initialized
INFO - 2022-12-19 08:04:39 --> Final output sent to browser
DEBUG - 2022-12-19 08:04:39 --> Total execution time: 0.2286
INFO - 2022-12-19 08:07:46 --> Config Class Initialized
INFO - 2022-12-19 08:07:46 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:46 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:46 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:46 --> URI Class Initialized
INFO - 2022-12-19 08:07:46 --> Router Class Initialized
INFO - 2022-12-19 08:07:46 --> Output Class Initialized
INFO - 2022-12-19 08:07:46 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:46 --> Input Class Initialized
INFO - 2022-12-19 08:07:46 --> Language Class Initialized
INFO - 2022-12-19 08:07:46 --> Loader Class Initialized
INFO - 2022-12-19 08:07:46 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:46 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:46 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:46 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:46 --> Total execution time: 0.1475
INFO - 2022-12-19 08:07:46 --> Config Class Initialized
INFO - 2022-12-19 08:07:46 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:46 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:46 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:46 --> URI Class Initialized
INFO - 2022-12-19 08:07:46 --> Router Class Initialized
INFO - 2022-12-19 08:07:46 --> Output Class Initialized
INFO - 2022-12-19 08:07:46 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:46 --> Input Class Initialized
INFO - 2022-12-19 08:07:46 --> Language Class Initialized
INFO - 2022-12-19 08:07:46 --> Loader Class Initialized
INFO - 2022-12-19 08:07:46 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:46 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:46 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:46 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:46 --> Total execution time: 0.1520
INFO - 2022-12-19 08:07:49 --> Config Class Initialized
INFO - 2022-12-19 08:07:49 --> Config Class Initialized
INFO - 2022-12-19 08:07:49 --> Hooks Class Initialized
INFO - 2022-12-19 08:07:49 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-19 08:07:49 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:49 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:49 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:49 --> URI Class Initialized
INFO - 2022-12-19 08:07:49 --> URI Class Initialized
INFO - 2022-12-19 08:07:49 --> Router Class Initialized
INFO - 2022-12-19 08:07:49 --> Router Class Initialized
INFO - 2022-12-19 08:07:49 --> Output Class Initialized
INFO - 2022-12-19 08:07:49 --> Output Class Initialized
INFO - 2022-12-19 08:07:49 --> Security Class Initialized
INFO - 2022-12-19 08:07:49 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-19 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:49 --> Input Class Initialized
INFO - 2022-12-19 08:07:49 --> Input Class Initialized
INFO - 2022-12-19 08:07:49 --> Language Class Initialized
INFO - 2022-12-19 08:07:49 --> Language Class Initialized
INFO - 2022-12-19 08:07:49 --> Loader Class Initialized
INFO - 2022-12-19 08:07:49 --> Controller Class Initialized
INFO - 2022-12-19 08:07:49 --> Loader Class Initialized
DEBUG - 2022-12-19 08:07:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:49 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:49 --> Total execution time: 0.1599
INFO - 2022-12-19 08:07:49 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:49 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:49 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:49 --> Config Class Initialized
INFO - 2022-12-19 08:07:49 --> Hooks Class Initialized
INFO - 2022-12-19 08:07:49 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:49 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:49 --> Total execution time: 0.2343
DEBUG - 2022-12-19 08:07:49 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:49 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:49 --> URI Class Initialized
INFO - 2022-12-19 08:07:49 --> Router Class Initialized
INFO - 2022-12-19 08:07:49 --> Config Class Initialized
INFO - 2022-12-19 08:07:49 --> Hooks Class Initialized
INFO - 2022-12-19 08:07:49 --> Output Class Initialized
INFO - 2022-12-19 08:07:49 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:49 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:49 --> Utf8 Class Initialized
DEBUG - 2022-12-19 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:50 --> Input Class Initialized
INFO - 2022-12-19 08:07:50 --> URI Class Initialized
INFO - 2022-12-19 08:07:50 --> Language Class Initialized
INFO - 2022-12-19 08:07:50 --> Router Class Initialized
INFO - 2022-12-19 08:07:50 --> Loader Class Initialized
INFO - 2022-12-19 08:07:50 --> Output Class Initialized
INFO - 2022-12-19 08:07:50 --> Controller Class Initialized
INFO - 2022-12-19 08:07:50 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-19 08:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:50 --> Input Class Initialized
INFO - 2022-12-19 08:07:50 --> Language Class Initialized
INFO - 2022-12-19 08:07:50 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:50 --> Model "Login_model" initialized
INFO - 2022-12-19 08:07:50 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:50 --> Loader Class Initialized
INFO - 2022-12-19 08:07:50 --> Controller Class Initialized
INFO - 2022-12-19 08:07:50 --> Model "Cluster_model" initialized
DEBUG - 2022-12-19 08:07:50 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:50 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:50 --> Total execution time: 0.2779
INFO - 2022-12-19 08:07:50 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:50 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:50 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:50 --> Total execution time: 0.2543
INFO - 2022-12-19 08:07:51 --> Config Class Initialized
INFO - 2022-12-19 08:07:51 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:51 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:51 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:51 --> URI Class Initialized
INFO - 2022-12-19 08:07:51 --> Router Class Initialized
INFO - 2022-12-19 08:07:51 --> Output Class Initialized
INFO - 2022-12-19 08:07:51 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:51 --> Input Class Initialized
INFO - 2022-12-19 08:07:51 --> Language Class Initialized
INFO - 2022-12-19 08:07:51 --> Loader Class Initialized
INFO - 2022-12-19 08:07:51 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:51 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:51 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:51 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:51 --> Total execution time: 0.1549
INFO - 2022-12-19 08:07:51 --> Config Class Initialized
INFO - 2022-12-19 08:07:51 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:51 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:51 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:51 --> URI Class Initialized
INFO - 2022-12-19 08:07:51 --> Router Class Initialized
INFO - 2022-12-19 08:07:51 --> Output Class Initialized
INFO - 2022-12-19 08:07:51 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:51 --> Input Class Initialized
INFO - 2022-12-19 08:07:51 --> Language Class Initialized
INFO - 2022-12-19 08:07:51 --> Loader Class Initialized
INFO - 2022-12-19 08:07:51 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:51 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:51 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:51 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:51 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:51 --> Total execution time: 0.1449
INFO - 2022-12-19 08:07:54 --> Config Class Initialized
INFO - 2022-12-19 08:07:54 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:54 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:54 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:54 --> URI Class Initialized
INFO - 2022-12-19 08:07:54 --> Router Class Initialized
INFO - 2022-12-19 08:07:54 --> Output Class Initialized
INFO - 2022-12-19 08:07:54 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:54 --> Input Class Initialized
INFO - 2022-12-19 08:07:54 --> Language Class Initialized
INFO - 2022-12-19 08:07:54 --> Loader Class Initialized
INFO - 2022-12-19 08:07:54 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:54 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:54 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:54 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:54 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:54 --> Total execution time: 0.1482
INFO - 2022-12-19 08:07:54 --> Config Class Initialized
INFO - 2022-12-19 08:07:54 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:54 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:54 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:54 --> URI Class Initialized
INFO - 2022-12-19 08:07:54 --> Router Class Initialized
INFO - 2022-12-19 08:07:54 --> Output Class Initialized
INFO - 2022-12-19 08:07:54 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:54 --> Input Class Initialized
INFO - 2022-12-19 08:07:54 --> Language Class Initialized
INFO - 2022-12-19 08:07:55 --> Loader Class Initialized
INFO - 2022-12-19 08:07:55 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:55 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:55 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:55 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:55 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:55 --> Total execution time: 0.1442
INFO - 2022-12-19 08:07:58 --> Config Class Initialized
INFO - 2022-12-19 08:07:58 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:58 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:58 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:58 --> URI Class Initialized
INFO - 2022-12-19 08:07:58 --> Router Class Initialized
INFO - 2022-12-19 08:07:58 --> Output Class Initialized
INFO - 2022-12-19 08:07:58 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:58 --> Input Class Initialized
INFO - 2022-12-19 08:07:58 --> Language Class Initialized
INFO - 2022-12-19 08:07:58 --> Loader Class Initialized
INFO - 2022-12-19 08:07:58 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:58 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:58 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:58 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:58 --> Total execution time: 0.1535
INFO - 2022-12-19 08:07:58 --> Config Class Initialized
INFO - 2022-12-19 08:07:58 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:07:58 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:07:58 --> Utf8 Class Initialized
INFO - 2022-12-19 08:07:58 --> URI Class Initialized
INFO - 2022-12-19 08:07:58 --> Router Class Initialized
INFO - 2022-12-19 08:07:58 --> Output Class Initialized
INFO - 2022-12-19 08:07:58 --> Security Class Initialized
DEBUG - 2022-12-19 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:07:58 --> Input Class Initialized
INFO - 2022-12-19 08:07:58 --> Language Class Initialized
INFO - 2022-12-19 08:07:58 --> Loader Class Initialized
INFO - 2022-12-19 08:07:58 --> Controller Class Initialized
DEBUG - 2022-12-19 08:07:58 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:07:58 --> Database Driver Class Initialized
INFO - 2022-12-19 08:07:58 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:07:58 --> Final output sent to browser
DEBUG - 2022-12-19 08:07:58 --> Total execution time: 0.1492
INFO - 2022-12-19 08:24:11 --> Config Class Initialized
INFO - 2022-12-19 08:24:11 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:24:12 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:24:12 --> Utf8 Class Initialized
INFO - 2022-12-19 08:24:12 --> URI Class Initialized
INFO - 2022-12-19 08:24:12 --> Router Class Initialized
INFO - 2022-12-19 08:24:12 --> Output Class Initialized
INFO - 2022-12-19 08:24:12 --> Security Class Initialized
DEBUG - 2022-12-19 08:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:24:12 --> Input Class Initialized
INFO - 2022-12-19 08:24:12 --> Language Class Initialized
INFO - 2022-12-19 08:24:12 --> Loader Class Initialized
INFO - 2022-12-19 08:24:12 --> Controller Class Initialized
DEBUG - 2022-12-19 08:24:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:24:12 --> Database Driver Class Initialized
INFO - 2022-12-19 08:24:12 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:24:12 --> Final output sent to browser
DEBUG - 2022-12-19 08:24:12 --> Total execution time: 0.1597
INFO - 2022-12-19 08:24:12 --> Config Class Initialized
INFO - 2022-12-19 08:24:12 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:24:12 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:24:12 --> Utf8 Class Initialized
INFO - 2022-12-19 08:24:12 --> URI Class Initialized
INFO - 2022-12-19 08:24:12 --> Router Class Initialized
INFO - 2022-12-19 08:24:12 --> Output Class Initialized
INFO - 2022-12-19 08:24:12 --> Security Class Initialized
DEBUG - 2022-12-19 08:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:24:12 --> Input Class Initialized
INFO - 2022-12-19 08:24:12 --> Language Class Initialized
INFO - 2022-12-19 08:24:12 --> Loader Class Initialized
INFO - 2022-12-19 08:24:12 --> Controller Class Initialized
DEBUG - 2022-12-19 08:24:12 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:24:12 --> Database Driver Class Initialized
INFO - 2022-12-19 08:24:12 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:24:12 --> Final output sent to browser
DEBUG - 2022-12-19 08:24:12 --> Total execution time: 0.1559
INFO - 2022-12-19 08:24:15 --> Config Class Initialized
INFO - 2022-12-19 08:24:15 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:24:15 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:24:15 --> Utf8 Class Initialized
INFO - 2022-12-19 08:24:15 --> URI Class Initialized
INFO - 2022-12-19 08:24:15 --> Router Class Initialized
INFO - 2022-12-19 08:24:15 --> Output Class Initialized
INFO - 2022-12-19 08:24:15 --> Security Class Initialized
DEBUG - 2022-12-19 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:24:15 --> Input Class Initialized
INFO - 2022-12-19 08:24:15 --> Language Class Initialized
INFO - 2022-12-19 08:24:15 --> Loader Class Initialized
INFO - 2022-12-19 08:24:15 --> Controller Class Initialized
DEBUG - 2022-12-19 08:24:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:24:15 --> Database Driver Class Initialized
INFO - 2022-12-19 08:24:15 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:24:15 --> Database Driver Class Initialized
INFO - 2022-12-19 08:24:15 --> Model "Login_model" initialized
INFO - 2022-12-19 08:24:15 --> Final output sent to browser
DEBUG - 2022-12-19 08:24:15 --> Total execution time: 0.2555
INFO - 2022-12-19 08:24:15 --> Config Class Initialized
INFO - 2022-12-19 08:24:15 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:24:15 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:24:15 --> Utf8 Class Initialized
INFO - 2022-12-19 08:24:15 --> URI Class Initialized
INFO - 2022-12-19 08:24:15 --> Router Class Initialized
INFO - 2022-12-19 08:24:15 --> Output Class Initialized
INFO - 2022-12-19 08:24:15 --> Security Class Initialized
DEBUG - 2022-12-19 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:24:15 --> Input Class Initialized
INFO - 2022-12-19 08:24:15 --> Language Class Initialized
INFO - 2022-12-19 08:24:15 --> Loader Class Initialized
INFO - 2022-12-19 08:24:15 --> Controller Class Initialized
DEBUG - 2022-12-19 08:24:15 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:24:15 --> Database Driver Class Initialized
INFO - 2022-12-19 08:24:15 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:24:15 --> Database Driver Class Initialized
INFO - 2022-12-19 08:24:15 --> Model "Login_model" initialized
INFO - 2022-12-19 08:24:15 --> Final output sent to browser
DEBUG - 2022-12-19 08:24:15 --> Total execution time: 0.2642
INFO - 2022-12-19 08:42:03 --> Config Class Initialized
INFO - 2022-12-19 08:42:03 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:42:03 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:42:03 --> Utf8 Class Initialized
INFO - 2022-12-19 08:42:03 --> URI Class Initialized
INFO - 2022-12-19 08:42:03 --> Router Class Initialized
INFO - 2022-12-19 08:42:03 --> Output Class Initialized
INFO - 2022-12-19 08:42:03 --> Security Class Initialized
DEBUG - 2022-12-19 08:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:42:03 --> Input Class Initialized
INFO - 2022-12-19 08:42:03 --> Language Class Initialized
INFO - 2022-12-19 08:42:03 --> Loader Class Initialized
INFO - 2022-12-19 08:42:03 --> Controller Class Initialized
DEBUG - 2022-12-19 08:42:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:42:03 --> Database Driver Class Initialized
INFO - 2022-12-19 08:42:03 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:42:03 --> Final output sent to browser
DEBUG - 2022-12-19 08:42:03 --> Total execution time: 0.1660
INFO - 2022-12-19 08:42:03 --> Config Class Initialized
INFO - 2022-12-19 08:42:03 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:42:03 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:42:03 --> Utf8 Class Initialized
INFO - 2022-12-19 08:42:03 --> URI Class Initialized
INFO - 2022-12-19 08:42:03 --> Router Class Initialized
INFO - 2022-12-19 08:42:03 --> Output Class Initialized
INFO - 2022-12-19 08:42:03 --> Security Class Initialized
DEBUG - 2022-12-19 08:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:42:03 --> Input Class Initialized
INFO - 2022-12-19 08:42:03 --> Language Class Initialized
INFO - 2022-12-19 08:42:03 --> Loader Class Initialized
INFO - 2022-12-19 08:42:03 --> Controller Class Initialized
DEBUG - 2022-12-19 08:42:03 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:42:03 --> Database Driver Class Initialized
INFO - 2022-12-19 08:42:03 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:42:03 --> Final output sent to browser
DEBUG - 2022-12-19 08:42:03 --> Total execution time: 0.1582
INFO - 2022-12-19 08:59:59 --> Config Class Initialized
INFO - 2022-12-19 08:59:59 --> Config Class Initialized
INFO - 2022-12-19 08:59:59 --> Hooks Class Initialized
INFO - 2022-12-19 08:59:59 --> Hooks Class Initialized
DEBUG - 2022-12-19 08:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-19 08:59:59 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:59:59 --> Utf8 Class Initialized
INFO - 2022-12-19 08:59:59 --> Utf8 Class Initialized
INFO - 2022-12-19 08:59:59 --> URI Class Initialized
INFO - 2022-12-19 08:59:59 --> URI Class Initialized
INFO - 2022-12-19 08:59:59 --> Router Class Initialized
INFO - 2022-12-19 08:59:59 --> Router Class Initialized
INFO - 2022-12-19 08:59:59 --> Output Class Initialized
INFO - 2022-12-19 08:59:59 --> Output Class Initialized
INFO - 2022-12-19 08:59:59 --> Security Class Initialized
INFO - 2022-12-19 08:59:59 --> Security Class Initialized
DEBUG - 2022-12-19 08:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-19 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:59:59 --> Input Class Initialized
INFO - 2022-12-19 08:59:59 --> Input Class Initialized
INFO - 2022-12-19 08:59:59 --> Language Class Initialized
INFO - 2022-12-19 08:59:59 --> Language Class Initialized
INFO - 2022-12-19 08:59:59 --> Loader Class Initialized
INFO - 2022-12-19 08:59:59 --> Loader Class Initialized
INFO - 2022-12-19 08:59:59 --> Controller Class Initialized
INFO - 2022-12-19 08:59:59 --> Controller Class Initialized
DEBUG - 2022-12-19 08:59:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-19 08:59:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:59:59 --> Final output sent to browser
DEBUG - 2022-12-19 08:59:59 --> Total execution time: 0.2233
INFO - 2022-12-19 08:59:59 --> Database Driver Class Initialized
INFO - 2022-12-19 08:59:59 --> Config Class Initialized
INFO - 2022-12-19 08:59:59 --> Hooks Class Initialized
INFO - 2022-12-19 08:59:59 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:59:59 --> Final output sent to browser
DEBUG - 2022-12-19 08:59:59 --> Total execution time: 0.2976
DEBUG - 2022-12-19 08:59:59 --> UTF-8 Support Enabled
INFO - 2022-12-19 08:59:59 --> Utf8 Class Initialized
INFO - 2022-12-19 08:59:59 --> URI Class Initialized
INFO - 2022-12-19 08:59:59 --> Router Class Initialized
INFO - 2022-12-19 08:59:59 --> Config Class Initialized
INFO - 2022-12-19 08:59:59 --> Hooks Class Initialized
INFO - 2022-12-19 08:59:59 --> Output Class Initialized
INFO - 2022-12-19 08:59:59 --> Security Class Initialized
DEBUG - 2022-12-19 08:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-19 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:59:59 --> Utf8 Class Initialized
INFO - 2022-12-19 08:59:59 --> Input Class Initialized
INFO - 2022-12-19 08:59:59 --> URI Class Initialized
INFO - 2022-12-19 08:59:59 --> Language Class Initialized
INFO - 2022-12-19 08:59:59 --> Router Class Initialized
INFO - 2022-12-19 08:59:59 --> Loader Class Initialized
INFO - 2022-12-19 08:59:59 --> Output Class Initialized
INFO - 2022-12-19 08:59:59 --> Controller Class Initialized
DEBUG - 2022-12-19 08:59:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:59:59 --> Security Class Initialized
DEBUG - 2022-12-19 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 08:59:59 --> Input Class Initialized
INFO - 2022-12-19 08:59:59 --> Database Driver Class Initialized
INFO - 2022-12-19 08:59:59 --> Language Class Initialized
INFO - 2022-12-19 08:59:59 --> Model "Login_model" initialized
INFO - 2022-12-19 08:59:59 --> Loader Class Initialized
INFO - 2022-12-19 08:59:59 --> Controller Class Initialized
INFO - 2022-12-19 08:59:59 --> Database Driver Class Initialized
DEBUG - 2022-12-19 08:59:59 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 08:59:59 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:59:59 --> Final output sent to browser
INFO - 2022-12-19 08:59:59 --> Database Driver Class Initialized
DEBUG - 2022-12-19 08:59:59 --> Total execution time: 0.2638
INFO - 2022-12-19 08:59:59 --> Model "Cluster_model" initialized
INFO - 2022-12-19 08:59:59 --> Final output sent to browser
DEBUG - 2022-12-19 08:59:59 --> Total execution time: 0.2370
INFO - 2022-12-19 09:00:01 --> Config Class Initialized
INFO - 2022-12-19 09:00:01 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:00:01 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:00:01 --> Utf8 Class Initialized
INFO - 2022-12-19 09:00:01 --> URI Class Initialized
INFO - 2022-12-19 09:00:01 --> Router Class Initialized
INFO - 2022-12-19 09:00:01 --> Output Class Initialized
INFO - 2022-12-19 09:00:01 --> Security Class Initialized
DEBUG - 2022-12-19 09:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:00:01 --> Input Class Initialized
INFO - 2022-12-19 09:00:01 --> Language Class Initialized
INFO - 2022-12-19 09:00:01 --> Loader Class Initialized
INFO - 2022-12-19 09:00:01 --> Controller Class Initialized
DEBUG - 2022-12-19 09:00:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:00:01 --> Database Driver Class Initialized
INFO - 2022-12-19 09:00:01 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:00:01 --> Database Driver Class Initialized
INFO - 2022-12-19 09:00:01 --> Model "Login_model" initialized
INFO - 2022-12-19 09:00:01 --> Final output sent to browser
DEBUG - 2022-12-19 09:00:01 --> Total execution time: 0.2385
INFO - 2022-12-19 09:00:01 --> Config Class Initialized
INFO - 2022-12-19 09:00:01 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:00:01 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:00:01 --> Utf8 Class Initialized
INFO - 2022-12-19 09:00:01 --> URI Class Initialized
INFO - 2022-12-19 09:00:01 --> Router Class Initialized
INFO - 2022-12-19 09:00:01 --> Output Class Initialized
INFO - 2022-12-19 09:00:01 --> Security Class Initialized
DEBUG - 2022-12-19 09:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:00:01 --> Input Class Initialized
INFO - 2022-12-19 09:00:01 --> Language Class Initialized
INFO - 2022-12-19 09:00:01 --> Loader Class Initialized
INFO - 2022-12-19 09:00:01 --> Controller Class Initialized
DEBUG - 2022-12-19 09:00:01 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:00:01 --> Database Driver Class Initialized
INFO - 2022-12-19 09:00:01 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:00:01 --> Database Driver Class Initialized
INFO - 2022-12-19 09:00:01 --> Model "Login_model" initialized
INFO - 2022-12-19 09:00:01 --> Final output sent to browser
DEBUG - 2022-12-19 09:00:01 --> Total execution time: 0.2402
INFO - 2022-12-19 09:14:41 --> Config Class Initialized
INFO - 2022-12-19 09:14:41 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:14:41 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:14:41 --> Utf8 Class Initialized
INFO - 2022-12-19 09:14:41 --> URI Class Initialized
INFO - 2022-12-19 09:14:41 --> Router Class Initialized
INFO - 2022-12-19 09:14:41 --> Output Class Initialized
INFO - 2022-12-19 09:14:41 --> Security Class Initialized
DEBUG - 2022-12-19 09:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:14:41 --> Input Class Initialized
INFO - 2022-12-19 09:14:41 --> Language Class Initialized
INFO - 2022-12-19 09:14:41 --> Loader Class Initialized
INFO - 2022-12-19 09:14:41 --> Controller Class Initialized
DEBUG - 2022-12-19 09:14:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:14:41 --> Database Driver Class Initialized
INFO - 2022-12-19 09:14:41 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:14:41 --> Final output sent to browser
DEBUG - 2022-12-19 09:14:41 --> Total execution time: 0.1367
INFO - 2022-12-19 09:14:41 --> Config Class Initialized
INFO - 2022-12-19 09:14:41 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:14:41 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:14:41 --> Utf8 Class Initialized
INFO - 2022-12-19 09:14:41 --> URI Class Initialized
INFO - 2022-12-19 09:14:41 --> Router Class Initialized
INFO - 2022-12-19 09:14:41 --> Output Class Initialized
INFO - 2022-12-19 09:14:41 --> Security Class Initialized
DEBUG - 2022-12-19 09:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:14:41 --> Input Class Initialized
INFO - 2022-12-19 09:14:41 --> Language Class Initialized
INFO - 2022-12-19 09:14:41 --> Loader Class Initialized
INFO - 2022-12-19 09:14:41 --> Controller Class Initialized
DEBUG - 2022-12-19 09:14:41 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:14:41 --> Database Driver Class Initialized
INFO - 2022-12-19 09:14:41 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:14:41 --> Final output sent to browser
DEBUG - 2022-12-19 09:14:41 --> Total execution time: 0.2392
INFO - 2022-12-19 09:14:43 --> Config Class Initialized
INFO - 2022-12-19 09:14:43 --> Config Class Initialized
INFO - 2022-12-19 09:14:43 --> Hooks Class Initialized
INFO - 2022-12-19 09:14:43 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-19 09:14:43 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:14:43 --> Utf8 Class Initialized
INFO - 2022-12-19 09:14:43 --> Utf8 Class Initialized
INFO - 2022-12-19 09:14:43 --> URI Class Initialized
INFO - 2022-12-19 09:14:43 --> URI Class Initialized
INFO - 2022-12-19 09:14:43 --> Router Class Initialized
INFO - 2022-12-19 09:14:43 --> Router Class Initialized
INFO - 2022-12-19 09:14:43 --> Output Class Initialized
INFO - 2022-12-19 09:14:43 --> Output Class Initialized
INFO - 2022-12-19 09:14:43 --> Security Class Initialized
INFO - 2022-12-19 09:14:43 --> Security Class Initialized
DEBUG - 2022-12-19 09:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-19 09:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:14:43 --> Input Class Initialized
INFO - 2022-12-19 09:14:43 --> Input Class Initialized
INFO - 2022-12-19 09:14:43 --> Language Class Initialized
INFO - 2022-12-19 09:14:43 --> Language Class Initialized
INFO - 2022-12-19 09:14:43 --> Loader Class Initialized
INFO - 2022-12-19 09:14:43 --> Loader Class Initialized
INFO - 2022-12-19 09:14:43 --> Controller Class Initialized
INFO - 2022-12-19 09:14:43 --> Controller Class Initialized
DEBUG - 2022-12-19 09:14:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-19 09:14:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:14:43 --> Final output sent to browser
DEBUG - 2022-12-19 09:14:43 --> Total execution time: 0.1560
INFO - 2022-12-19 09:14:43 --> Database Driver Class Initialized
INFO - 2022-12-19 09:14:43 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:14:43 --> Final output sent to browser
DEBUG - 2022-12-19 09:14:43 --> Total execution time: 0.2091
INFO - 2022-12-19 09:14:43 --> Config Class Initialized
INFO - 2022-12-19 09:14:43 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:14:43 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:14:43 --> Utf8 Class Initialized
INFO - 2022-12-19 09:14:43 --> Config Class Initialized
INFO - 2022-12-19 09:14:43 --> URI Class Initialized
INFO - 2022-12-19 09:14:43 --> Hooks Class Initialized
INFO - 2022-12-19 09:14:43 --> Router Class Initialized
DEBUG - 2022-12-19 09:14:43 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:14:43 --> Utf8 Class Initialized
INFO - 2022-12-19 09:14:43 --> Output Class Initialized
INFO - 2022-12-19 09:14:43 --> URI Class Initialized
INFO - 2022-12-19 09:14:43 --> Security Class Initialized
DEBUG - 2022-12-19 09:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:14:43 --> Router Class Initialized
INFO - 2022-12-19 09:14:43 --> Input Class Initialized
INFO - 2022-12-19 09:14:43 --> Language Class Initialized
INFO - 2022-12-19 09:14:43 --> Output Class Initialized
INFO - 2022-12-19 09:14:43 --> Security Class Initialized
INFO - 2022-12-19 09:14:43 --> Loader Class Initialized
DEBUG - 2022-12-19 09:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:14:43 --> Input Class Initialized
INFO - 2022-12-19 09:14:43 --> Controller Class Initialized
INFO - 2022-12-19 09:14:43 --> Language Class Initialized
DEBUG - 2022-12-19 09:14:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:14:43 --> Loader Class Initialized
INFO - 2022-12-19 09:14:43 --> Database Driver Class Initialized
INFO - 2022-12-19 09:14:43 --> Controller Class Initialized
INFO - 2022-12-19 09:14:43 --> Model "Login_model" initialized
DEBUG - 2022-12-19 09:14:43 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:14:43 --> Database Driver Class Initialized
INFO - 2022-12-19 09:14:43 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:14:43 --> Database Driver Class Initialized
INFO - 2022-12-19 09:14:43 --> Final output sent to browser
DEBUG - 2022-12-19 09:14:43 --> Total execution time: 0.2535
INFO - 2022-12-19 09:14:43 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:14:43 --> Final output sent to browser
DEBUG - 2022-12-19 09:14:43 --> Total execution time: 0.2353
INFO - 2022-12-19 09:14:46 --> Config Class Initialized
INFO - 2022-12-19 09:14:46 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:14:46 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:14:46 --> Utf8 Class Initialized
INFO - 2022-12-19 09:14:46 --> URI Class Initialized
INFO - 2022-12-19 09:14:46 --> Router Class Initialized
INFO - 2022-12-19 09:14:46 --> Output Class Initialized
INFO - 2022-12-19 09:14:46 --> Security Class Initialized
DEBUG - 2022-12-19 09:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:14:46 --> Input Class Initialized
INFO - 2022-12-19 09:14:46 --> Language Class Initialized
INFO - 2022-12-19 09:14:46 --> Loader Class Initialized
INFO - 2022-12-19 09:14:46 --> Controller Class Initialized
DEBUG - 2022-12-19 09:14:46 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:14:46 --> Database Driver Class Initialized
INFO - 2022-12-19 09:14:46 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:14:46 --> Final output sent to browser
DEBUG - 2022-12-19 09:14:46 --> Total execution time: 0.1401
INFO - 2022-12-19 09:14:47 --> Config Class Initialized
INFO - 2022-12-19 09:14:47 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:14:47 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:14:47 --> Utf8 Class Initialized
INFO - 2022-12-19 09:14:47 --> URI Class Initialized
INFO - 2022-12-19 09:14:47 --> Router Class Initialized
INFO - 2022-12-19 09:14:47 --> Output Class Initialized
INFO - 2022-12-19 09:14:47 --> Security Class Initialized
DEBUG - 2022-12-19 09:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:14:47 --> Input Class Initialized
INFO - 2022-12-19 09:14:47 --> Language Class Initialized
INFO - 2022-12-19 09:14:47 --> Loader Class Initialized
INFO - 2022-12-19 09:14:47 --> Controller Class Initialized
DEBUG - 2022-12-19 09:14:47 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:14:47 --> Database Driver Class Initialized
INFO - 2022-12-19 09:14:47 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:14:47 --> Final output sent to browser
DEBUG - 2022-12-19 09:14:47 --> Total execution time: 0.1445
INFO - 2022-12-19 09:16:56 --> Config Class Initialized
INFO - 2022-12-19 09:16:56 --> Config Class Initialized
INFO - 2022-12-19 09:16:56 --> Hooks Class Initialized
INFO - 2022-12-19 09:16:56 --> Hooks Class Initialized
DEBUG - 2022-12-19 09:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-19 09:16:56 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:16:56 --> Utf8 Class Initialized
INFO - 2022-12-19 09:16:56 --> Utf8 Class Initialized
INFO - 2022-12-19 09:16:56 --> URI Class Initialized
INFO - 2022-12-19 09:16:56 --> URI Class Initialized
INFO - 2022-12-19 09:16:56 --> Router Class Initialized
INFO - 2022-12-19 09:16:56 --> Router Class Initialized
INFO - 2022-12-19 09:16:56 --> Output Class Initialized
INFO - 2022-12-19 09:16:56 --> Output Class Initialized
INFO - 2022-12-19 09:16:56 --> Security Class Initialized
INFO - 2022-12-19 09:16:56 --> Security Class Initialized
DEBUG - 2022-12-19 09:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-19 09:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:16:56 --> Input Class Initialized
INFO - 2022-12-19 09:16:56 --> Input Class Initialized
INFO - 2022-12-19 09:16:56 --> Language Class Initialized
INFO - 2022-12-19 09:16:56 --> Language Class Initialized
INFO - 2022-12-19 09:16:56 --> Loader Class Initialized
INFO - 2022-12-19 09:16:56 --> Loader Class Initialized
INFO - 2022-12-19 09:16:56 --> Controller Class Initialized
INFO - 2022-12-19 09:16:56 --> Controller Class Initialized
DEBUG - 2022-12-19 09:16:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-19 09:16:56 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:16:56 --> Final output sent to browser
DEBUG - 2022-12-19 09:16:56 --> Total execution time: 0.1820
INFO - 2022-12-19 09:16:56 --> Database Driver Class Initialized
INFO - 2022-12-19 09:16:56 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:16:56 --> Config Class Initialized
INFO - 2022-12-19 09:16:56 --> Hooks Class Initialized
INFO - 2022-12-19 09:16:56 --> Final output sent to browser
DEBUG - 2022-12-19 09:16:56 --> Total execution time: 0.2438
DEBUG - 2022-12-19 09:16:56 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:16:57 --> Utf8 Class Initialized
INFO - 2022-12-19 09:16:57 --> URI Class Initialized
INFO - 2022-12-19 09:16:57 --> Config Class Initialized
INFO - 2022-12-19 09:16:57 --> Hooks Class Initialized
INFO - 2022-12-19 09:16:57 --> Router Class Initialized
INFO - 2022-12-19 09:16:57 --> Output Class Initialized
DEBUG - 2022-12-19 09:16:57 --> UTF-8 Support Enabled
INFO - 2022-12-19 09:16:57 --> Utf8 Class Initialized
INFO - 2022-12-19 09:16:57 --> Security Class Initialized
INFO - 2022-12-19 09:16:57 --> URI Class Initialized
DEBUG - 2022-12-19 09:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:16:57 --> Input Class Initialized
INFO - 2022-12-19 09:16:57 --> Router Class Initialized
INFO - 2022-12-19 09:16:57 --> Language Class Initialized
INFO - 2022-12-19 09:16:57 --> Output Class Initialized
INFO - 2022-12-19 09:16:57 --> Loader Class Initialized
INFO - 2022-12-19 09:16:57 --> Security Class Initialized
INFO - 2022-12-19 09:16:57 --> Controller Class Initialized
DEBUG - 2022-12-19 09:16:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
DEBUG - 2022-12-19 09:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 09:16:57 --> Input Class Initialized
INFO - 2022-12-19 09:16:57 --> Language Class Initialized
INFO - 2022-12-19 09:16:57 --> Database Driver Class Initialized
INFO - 2022-12-19 09:16:57 --> Loader Class Initialized
INFO - 2022-12-19 09:16:57 --> Model "Login_model" initialized
INFO - 2022-12-19 09:16:57 --> Controller Class Initialized
DEBUG - 2022-12-19 09:16:57 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 09:16:57 --> Database Driver Class Initialized
INFO - 2022-12-19 09:16:57 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:16:57 --> Final output sent to browser
INFO - 2022-12-19 09:16:57 --> Database Driver Class Initialized
DEBUG - 2022-12-19 09:16:57 --> Total execution time: 0.2768
INFO - 2022-12-19 09:16:57 --> Model "Cluster_model" initialized
INFO - 2022-12-19 09:16:57 --> Final output sent to browser
DEBUG - 2022-12-19 09:16:57 --> Total execution time: 0.2460
INFO - 2022-12-19 16:42:27 --> Config Class Initialized
INFO - 2022-12-19 16:42:27 --> Hooks Class Initialized
DEBUG - 2022-12-19 16:42:27 --> UTF-8 Support Enabled
INFO - 2022-12-19 16:42:27 --> Utf8 Class Initialized
INFO - 2022-12-19 16:42:27 --> URI Class Initialized
INFO - 2022-12-19 16:42:27 --> Router Class Initialized
INFO - 2022-12-19 16:42:27 --> Output Class Initialized
INFO - 2022-12-19 16:42:27 --> Security Class Initialized
DEBUG - 2022-12-19 16:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-19 16:42:27 --> Input Class Initialized
INFO - 2022-12-19 16:42:27 --> Language Class Initialized
INFO - 2022-12-19 16:42:27 --> Loader Class Initialized
INFO - 2022-12-19 16:42:27 --> Controller Class Initialized
DEBUG - 2022-12-19 16:42:27 --> Config file loaded: /var/www/html/KunlunMonitor/application/config/myconfig.php
INFO - 2022-12-19 16:42:27 --> Database Driver Class Initialized
ERROR - 2022-12-19 16:42:37 --> Unable to connect to the database
INFO - 2022-12-19 16:42:37 --> Language file loaded: language/english/db_lang.php
